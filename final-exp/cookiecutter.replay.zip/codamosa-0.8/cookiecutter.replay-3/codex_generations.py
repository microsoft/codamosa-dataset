

# Generated at 2022-06-11 20:22:14.374234
# Unit test for function dump
def test_dump():
    replay_dir = 'test_data/test_replay'
    template_name = 'test_data/test_replay/test'
    context = {'cookiecutter': {'name': 'Basic Project', 'project_slug': 'basic_project', 'project_name': 'Basic Project',
                                'author_name': 'David Yang', 'email': 'david@davidyang.ca', 'description': 'The example project for Cookiecutter',
                                'domain_name': 'example.com', 'version': '0.1.0', 'timezone': 'Canada/Eastern', 'use_pycharm': 'y',
                                'use_docker': 'y', 'open_source_license': 'MIT', 'year': '2016'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:22:18.006571
# Unit test for function load
def test_load():
    replay_dir = '/Users/xiaoliang.tang/git_repo/my-cookiecutter/'
    template_name = 'python-backend'
    context = load(replay_dir, template_name)
    print(context)

# Generated at 2022-06-11 20:22:23.075610
# Unit test for function dump
def test_dump():
    print('test_dump')
    replay_dir = './test_cookiecutter/templates/test_template'
    template_name = 'test_template'
    context = {'cookiecutter': {'full_name': 'Tianli Xu', 'email': 'tianli.xu@outlook.com'}}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:22:27.796243
# Unit test for function dump
def test_dump():
    template_name = 'mytemplate/'
    replay_dir = 'xxxxxx/'
    context = {'cookiecutter': {'full_name': 'Jane Doe', 'email': 'janedoe@example.com'}}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:22:30.163434
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = 'example.json'
    context = load(replay_dir, template_name)

    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:22:39.724848
# Unit test for function load
def test_load():
    import os
    import shutil
    foo = os.path.abspath(os.path.dirname(__file__))
    parent = os.path.dirname(foo)
    replay_dir = os.path.join(parent, 'cookiecutter/tests/test-replay/')
    template_name = 'dummy.json'
    replay_file = get_file_name(replay_dir, template_name)
    print('replay_file:')
    print(replay_file)
    context = load(replay_dir, template_name)
    print('context: ')
    print(context)
    shutil.rmtree(replay_dir)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:22:44.400452
# Unit test for function load
def test_load():
    template_name = "my_template"
    replay_dir = "my_replay_dir"
    context = {}
    context["cookiecutter"] = "cookiecutter_value"
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-11 20:22:47.473215
# Unit test for function load
def test_load():
    context=load('replay', 'cookiecutter-pypackage')
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'

# Generated at 2022-06-11 20:22:49.552020
# Unit test for function load
def test_load():
    assert load('/Users/arjun/Documents/GitHub/cookiecutter-pypackage/tests/test.json', 'cookiecutter.json')


# Generated at 2022-06-11 20:22:53.462233
# Unit test for function load
def test_load():
    import json
    # Create a test directory
    dir_path = os.path.join(os.path.dirname(__file__), 'templates', 'test_load')
    if not os.path.exists(os.path.join(dir_path, 'replay')):
        os.mkdir(os.path.join(dir_path, 'replay'))
    # Create a context file
    test_context = {"full_name": "Test",
                    "project_name": "Test",
                    "email": "test@test.com",
                    "github_username": "testusername",
                    "github_repo": "testrepo",
                    "cookiecutter": {"_template": os.path.join(dir_path, "cookiecutter.json")},
                    "version": "0.1.0"}


# Generated at 2022-06-11 20:22:58.327702
# Unit test for function load
def test_load():
    context = load("/Users/yu-hsiang/code/cookiecutter-template/cookiecutter-flask/", "cookiecutter.json")

# Generated at 2022-06-11 20:23:04.658638
# Unit test for function load
def test_load():

    replay_dir = '/home/babak/Documents/Projects/cookiecutter/tests/test-data/fake-repo-pre/'
    template_name = "fake-repo-pre/{{cookiecutter.my_name}}"
    context = load(replay_dir, template_name)
    print(context)
    print(context['cookiecutter'])


# Generated at 2022-06-11 20:23:10.403324
# Unit test for function load
def test_load():
    replay_dir = '/Users/lizhe/cookiecutter-learn/tests/test-load'
    template_name = 'test_load'
    context = load(replay_dir, template_name)
    assert context.get('cookiecutter') == {
        'template_name': template_name
    }


# Generated at 2022-06-11 20:23:20.095279
# Unit test for function load
def test_load():
    """Unit test for function load"""
    import sys
    import unittest

    class TestCookiecutterUtils(unittest.TestCase):
        # Test the functions run normally
        def test_load_normal(self):
            result = load('/Users/mac/.cookiecutters', 'fake_template')
            self.assertEqual(result['cookiecutter']['replay_dir'], '/Users/mac/.cookiecutters', 'Should get replay dir')
            self.assertEqual(result['cookiecutter']['no_input'], False, 'Should get no input status')
        # Test the functions run with Exception
        def test_load_exception(self):
            #Test with template name not str
            with self.assertRaises(TypeError):
                load('/Users/mac/.cookiecutters', 1)

# Generated at 2022-06-11 20:23:27.326474
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {
        'project_name': 'cookiecutter-pypackage',
        'author_name': 'Audrey Roy',
        'email': 'audreyr@example.com',
        'github_username': 'audreyr',
        'description': 'A Python package project template.',
        'open_source_license': 'MIT license',
        'pypi_username': 'audreyr',
        'repo_name': 'cookiecutter-pypackage',
    }}
    dump('.', 'cookiecutter-pypackage', context)
    assert 'cookiecutter-pypackage.json' in os.listdir('.')


# Generated at 2022-06-11 20:23:30.331200
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.getcwd(), 'cookiecutter/tests/test-load')
    template_name = 'test-load'
    context = load(replay_dir, template_name)
    return context


# Generated at 2022-06-11 20:23:38.787575
# Unit test for function dump
def test_dump():
    file_name = 'my_dumptest.json'
    replay_dir = 'test'
    
    template_name = '{{cookiecutter.project_name}}'
    context = {'cookiecutter': {'project_name': 'test_dump'}}
    dump(replay_dir, template_name, context)
    
    assert os.path.exists(os.path.join(replay_dir, file_name)) 
    os.remove(os.path.join(replay_dir, file_name))
    
    template_name = 'test.json'
    context = {'cookiecutter': {'project_name': 'test_dump'}}
    dump(replay_dir, template_name, context)
    

# Generated at 2022-06-11 20:23:49.090438
# Unit test for function load
def test_load():
    reload(replay)
    context = replay.load('tests/test-replay', 'test-template')
    assert isinstance(context, dict)
    assert context['cookiecutter']['repo_dir'] == \
        'https://github.com/audreyr/cookiecutter-pypackage.git'
    assert context['cookiecutter']['full_name'] == 'Your Name'
    assert context['cookiecutter']['email'] == 'your@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Test Project'
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-test-project'
    assert context['cookiecutter']['release_date'] == '2014-12-17'


# Generated at 2022-06-11 20:23:57.653219
# Unit test for function load
def test_load():
    """Test for load"""
    replay_dir = 'test_fixtures/repl_dir'
    template_name = 'test_replay'  
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context

    replay_dir = 'test_fixtures/repl_dir'
    template_name = 'test_replay.json'  
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context

    replay_dir = 'test_fixtures'
    template_name = 'test_replay.json'  
    try:
        context = load(replay_dir, template_name)
    except IOError as e:
        assert True
    else:
        assert False

# Generated at 2022-06-11 20:24:03.073250
# Unit test for function load
def test_load():
    """Unit test for function load."""
    assert load('../../tests/test-replays/', 'default') == {"cookiecutter": {"full_name": "Your name", "project_name": "Hello World", "repo_name": "helloworld", "release_date": "2013-01-01", "year": "2013"}}



# Generated at 2022-06-11 20:24:11.111008
# Unit test for function dump
def test_dump():
    # Make sure the file is created successfully
    dump('tests/test-output/replay', '{{cookiecutter.project_slug}}',
        {'cookiecutter': {'project_slug': 'testing_dump'}})
    assert os.path.isfile('tests/test-output/replay/testing_dump.json')

    # Make sure the file has the right content
    with open('tests/test-output/replay/testing_dump.json', 'r') as infile:
        actual = json.load(infile)
    expected = {'cookiecutter': {'project_slug': 'testing_dump'}}
    assert actual == expected

    # Make sure TypeError is raised for str and dict

# Generated at 2022-06-11 20:24:16.002790
# Unit test for function load
def test_load():
    replay_dir = 'C:/Program Files (x86)/Git/bin/cookiecutter-example'
    template_name = 'cookiecutter-example'
    context = load(replay_dir, template_name)
    print (context)


# Generated at 2022-06-11 20:24:18.622470
# Unit test for function load
def test_load():
    replay_dir='./cookiecutter'
    template_name='template.json'
    context=load(replay_dir, template_name)
    assert 'cookiecutter' in context
    

# Generated at 2022-06-11 20:24:22.423527
# Unit test for function load
def test_load():
    dict = load('D:\Study\python\cookiecutter-master\cookiecutter-master\tests\\',
    'tests\\fake-repo-tmpl')
    print(dict)

# Generated at 2022-06-11 20:24:25.687605
# Unit test for function load
def test_load():
    test_load = load('tests/test-replay', 'tests/test-repo')
    print("test_load[" + str(test_load) + "]")


# Generated at 2022-06-11 20:24:29.527860
# Unit test for function load
def test_load():
    directory = '/home/adam/PycharmProjects/cookiecutter-custom/cookiecutter'
    template_name = 'demo'
    context = load(directory, template_name)
    print(context)


# Generated at 2022-06-11 20:24:39.641125
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    template_name = 'cookiecutter-pypackage'
    replay_file = get_file_name("replay", template_name)
    os.system("cookiecutter https://github.com/audreyr/cookiecutter-pypackage.git --no-input")

# Generated at 2022-06-11 20:24:46.014146
# Unit test for function load
def test_load():
    expected = {
        'cookiecutter': {
            'cookiecutter_license': 'MIT',
            'author_email': 'example@example.com',
            'author_name': 'Alex',
            'open_source_license': 'MIT',
            'project_name': 'Test Project',
            'project_short_description': 'Test project',
            'repo_name': 'test-project',
            'year': '2018'
        }
    }
    assert expected == load('.', 'cookiecutter-pypackage-test')


# Generated at 2022-06-11 20:24:48.047794
# Unit test for function load
def test_load():
    load("/Users/mohit/Downloads/mohit/CMS-280/cookiecutter-flask-master/cookiecutter/", "cookiecutter.json")

# Generated at 2022-06-11 20:24:55.720850
# Unit test for function dump
def test_dump():
    replay_dir = 'TESTDIR'
    template_name = 'TESTNNAME'
    pwd = os.getcwd()
    replay_file = 'TESTDIR' + '/' + template_name + 'json'

    # function should not raise an error
    dump(replay_dir, template_name, {'cookiecutter': {'name': 'James'}})

    # assert that file was created
    assert(os.path.isfile(replay_file))
    assert(os.path.isfile('TESTDIR'))

    # cleanup
    os.remove(replay_file)
    os.chdir(pwd)
    os.rmdir('TESTDIR')


# Generated at 2022-06-11 20:25:01.039633
# Unit test for function dump
def test_dump():
    replay_dir = "template/test"
    template_name = "test"
    context = {"cookiecutter":{"test": "test"}}
    dump(replay_dir, template_name, context)
    file_name = get_file_name(replay_dir, template_name)
    #os.remove(file_name)



# Generated at 2022-06-11 20:25:05.125662
# Unit test for function load
def test_load():
    """Test function name: load
    :return:
    """
    # random_string.json file should exist under the current directory.
    current_dir = os.path.dirname(os.path.abspath(__file__))
    template_name = "random_string.json"
    replay_dir = current_dir
    context1 = load(replay_dir, template_name)
    assert isinstance(context1, dict)


# Generated at 2022-06-11 20:25:14.965436
# Unit test for function dump
def test_dump():
    """
    Unit test for function dump

    Note: Test should not be run in parallel
    """
    # Set test variables
    replay_dir = 'test_cookiecutter_replay'
    template_name = 'test_template_name'
    input_context = {
        'cookiecutter': {
            'test': 'test_value',
            'test_int': 1,
            'test_float': 1.1,
            'test_list': [1, 2, 3],
            'test_dict': {'test_key': 'test_value'},
            'test_nonetype': None
        }
    }
    output_context = input_context.copy()

    # If a file with the same name already exists, remove it

# Generated at 2022-06-11 20:25:19.734920
# Unit test for function load
def test_load():
    template_name = 'first-project'
    replay_dir = 'replay'
    with open('replay/first-project.json') as infile:
        context = json.load(infile)

    load_con = load(replay_dir, template_name)
    assert load_con == context


# Generated at 2022-06-11 20:25:23.122688
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'ReactWeb'
    replay_dir = '../replay'
    context = load(replay_dir, template_name)
    print(context)

# Generated at 2022-06-11 20:25:33.173564
# Unit test for function load
def test_load():
    context = load('/Users/alejandro/Documents/cours-esiee/année-3/semestre-6/gestion-projets-logiciel/TP/algo_tp/tp2/cookiecutter-algo-tp2/tests/test-load' ,
                   'cookiecutter.json')
    assert(context["cookiecutter"]["repo_name"] == "Algo-Projets-Logiciel-TP2")
    assert(context["cookiecutter"]["full_name"] == "Alejandro Cornejo")
    assert(context["cookiecutter"]["email"] == "alejandro.cornejo-paez@esiee.fr")
    assert(context["cookiecutter"]["project_slug"] == "TP2")

# Generated at 2022-06-11 20:25:35.375405
# Unit test for function load
def test_load():
    replay_dir='/Users/yulu/Documents/Cookiecutter_Repo/cookiecutter/tests/test-replay/'
    template_name='pytest'
    load(replay_dir, template_name)



# Generated at 2022-06-11 20:25:36.876833
# Unit test for function load
def test_load():
    context = load("test_replay_files","cookiecutter-golang")
    assert context['cookiecutter']['app_name'] == 'cookiecutter-golang'

# Generated at 2022-06-11 20:25:38.114291
# Unit test for function load
def test_load():
    context = load('tests/replay/', 'example-app')
    assert context is not None
    assert len(context) > 0



# Generated at 2022-06-11 20:25:47.658476
# Unit test for function load
def test_load():
    # Create a directory
    replay_dir = './test_replay'
    make_sure_path_exists(replay_dir)
    # Create a json file
    template_name = 'test_template'
    file_name = get_file_name(replay_dir, template_name)
    with open(file_name, 'w') as outfile:
        json.dump({'cookiecutter': {'hello': 'world'}}, outfile, indent=2)
    # Test
    assert(load(replay_dir, template_name) == {'cookiecutter': {'hello': 'world'}})
    # Delete the directory
    os.rmdir(replay_dir)


# Generated at 2022-06-11 20:25:53.353699
# Unit test for function load
def test_load():
    replay_dir = os.path.normpath('/Users/guyang/.cookiecutters/example')
    template_name = 'example'
    context = load(replay_dir,template_name)
    print(context)


# Generated at 2022-06-11 20:25:59.064474
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.getcwd(), 'tests', 'replay')
    template_name = 'maintainer-info'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['email'] == 'pdonorio@gmail.com'

# Generated at 2022-06-11 20:26:01.812569
# Unit test for function dump
def test_dump():
    try:
        dump(replay_dir = 'tests/fixtures/files/replay_files', template_name = 'sample_json', context = 'sample_context')
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-11 20:26:07.739322
# Unit test for function load
def test_load():
    # Set up fake context to load
    fake_context = {"cookiecutter": {"cookiecutter_dict": {"a": "b"}}}

    # Write fake context out to disk
    dump(replay_dir="tests/fake-repo-pre/", template_name="fake-repo-pre", context=fake_context)

    # Load fake context from disk
    loaded_context = load(replay_dir="tests/fake-repo-pre/", template_name="fake-repo-pre")

    # Compare the loaded context with the original context
    assert loaded_context == fake_context


# Generated at 2022-06-11 20:26:13.440962
# Unit test for function load
def test_load():
    """Unit test for function load"""
    result = load('/home/peter/pythonprojects/python_training/cookiecutter-master/tests/test_replay', 'tests/fake-repo-pre/')
    assert result =={'cookiecutter': {'fake_option': 'Awesome', '_copy_without_render': ['docs', '{{cookiecutter.repo_name}}']}}

# Generated at 2022-06-11 20:26:18.871973
# Unit test for function load
def test_load():

    # Check that a dictionary is returned
    assert type(load(replay_dir = 'some_dir', template_name = 'some_template')) is dict

    # Check that a KeyError is raised when missing cookiecutter key
    with pytest.raises(ValueError) as ValueError:
        load(replay_dir = 'some_dir', template_name = 'some_template')

# Generated at 2022-06-11 20:26:19.880987
# Unit test for function dump
def test_dump():
    assert True


# Generated at 2022-06-11 20:26:26.146790
# Unit test for function load

# Generated at 2022-06-11 20:26:34.739964
# Unit test for function load
def test_load():
    template_name = '_test_load'
    replay_dir = 'tests/replays'
    # Create file
    context = {
        'cookiecutter': {
            '_test_load': 'tests/data/tests',
            'project_name': 'Loading Test'
        }
    }
    dump(replay_dir, template_name, context)
    # Read file
    new_context = load(replay_dir, template_name)
    assert context == new_context
    # Delete file
    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-11 20:26:44.407253
# Unit test for function load

# Generated at 2022-06-11 20:26:55.935555
# Unit test for function load
def test_load():
    """Test successful load with valid template name."""
    import logging
    import sys

    log = logging.getLogger(__name__)
    # Create a handler to write to the system's standard error
    handler = logging.StreamHandler(sys.stderr)
    # Set the logging level to error
    handler.setLevel(logging.ERROR)
    # Format the logs to include the level, the name
    # of the logger, and the message
    formatter = logging.Formatter(
        '%(levelname)s:%(name)s:%(message)s'
    )
    # Attach the formatter to the handler
    handler.setFormatter(formatter)
    # Attach the handler to the logger
    log.addHandler(handler)
    log.setLevel(logging.ERROR)

    correct_dict

# Generated at 2022-06-11 20:26:58.488632
# Unit test for function load
def test_load():
    load('/tmp', 'test')

# Test stdout
#python -m doctest -v cookiecutter/replay.py
#python -m doctest cookiecutter/replay.py

# Generated at 2022-06-11 20:27:03.866761
# Unit test for function dump
def test_dump():
    """Test for the dump function."""
    result = dump('some_replay_dir', 'some_template_name', {'some_key': 'some_value'})
    assert result == None
    #Assert that an error is raised if the directory is not created
    assert result == IOError
    #Assert that the template name is a string
    assert result == TypeError
    #Assert that the context is a dict
    assert result == TypeError
    #Assert that the context contains the cookiecutter key
    assert result == ValueError



# Generated at 2022-06-11 20:27:10.348979
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = os.getcwd()
    template_name = 'test_template'

# Generated at 2022-06-11 20:27:18.593802
# Unit test for function dump
def test_dump():
    import tempfile
    import shutil
    import os.path

    dir_name = tempfile.mkdtemp()
    template_name = 'python_package'
    context = {
        'cookiecutter': {
            'project_name': 'Cookiecutter',
        }
    }
    dump(dir_name, template_name, context)

    context_returned = load(dir_name, template_name)
    assert context == context_returned

    file_name = os.path.join(dir_name, template_name + '.json')
    assert os.path.isfile(file_name), 'Replay file does not exist.'

    shutil.rmtree(dir_name)

# Generated at 2022-06-11 20:27:20.264608
# Unit test for function dump
def test_dump():
    """Test for function dump."""
    return True

# Generated at 2022-06-11 20:27:27.994309
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import json
    from os.path import join as pjoin
    from os import getcwd

    root = getcwd()
    # Test directory
    tmp_dir = pjoin(root, 'tmp')
    replay_dir = pjoin(root, 'replay')

    template_test = 'twindb'
    empty_context = {'cookiecutter': {}}
    # Create replay file
    dump(replay_dir, template_test, empty_context)
    context = load(replay_dir, template_test)
    assert context == empty_context

# Generated at 2022-06-11 20:27:38.165949
# Unit test for function load
def test_load():
    """Test load function."""
    tmp_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    expected_context = {
        'cookiecutter': {
            'project_name': 'Test Project',
            'project_slug': 'test-project',
            'repo_name': 'test_project',
            'year': '2013',
            'month': '02',
            'full_name': 'Your Name',
            'email': 'you@example.com',
            'description': 'A short description of the project.',
            'version': '0.1.0',
            'open_source_license': 'MIT license'
        }
    }

    context = load(tmp_dir, template_name)
    assert context == expected_context

# Generated at 2022-06-11 20:27:42.100023
# Unit test for function load
def test_load():
    context = load("tests", "pyproject-cookiecutter")
    assert 'cookiecutter' in context
    assert 'project_name' in context['cookiecutter']
    assert 'repo_name' in context['cookiecutter']

# Generated at 2022-06-11 20:27:47.569715
# Unit test for function load
def test_load():
    """Test loading replay file."""
    replay_dir = '/Users/david/cookiecutter/example_replay_dir'
    template_name = 'example_template/project_name'

    context = load(replay_dir=replay_dir, template_name=template_name)

    expected = {'cookiecutter': {
                    'project_name': 'example_template',
                    'author_name': 'Gustavo Picon',
                    'open_source_license': 'MIT license'}}

    assert context == expected

# Generated at 2022-06-11 20:27:53.648769
# Unit test for function load
def test_load():
    input_file = 'test.json'
    template_name = 'template'
    context = {'cookiecutter': {'test': 1}}
    with open(input_file, 'w') as infile:
        json.dump(context, infile, indent=2)
    result = load('.', template_name)
    assert result == context


# Generated at 2022-06-11 20:27:58.162066
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/test-dump'
    template_name = 'replay-test'
    context = {'cookiecutter': {'test': 'dump'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:28:01.868750
# Unit test for function load
def test_load():
    print(load('/Users/amittiwari/Desktop/MachineLearning/drey-cookiecutter-clojure-lib/cookiecutter', 'cookiecutter'))
# test_load()

# Generated at 2022-06-11 20:28:04.931542
# Unit test for function load
def test_load():
    context = load('/Users/zhaoxiaoke/private/formatter_repo/cookiecutter-template-aws', 'cookiecutter.json')
    print(context)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:28:09.931020
# Unit test for function load
def test_load():
    context = load('/home/cookiecutter/tests/tests/files/fake-repo-pre/',
                   'fake-repo-pre')
    assert isinstance(context, dict)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'


# Generated at 2022-06-11 20:28:16.258706
# Unit test for function load
def test_load():
    # Create a test directory
    import shutil
    replay_dir = './test_replay_dir'
    shutil.rmtree(replay_dir, ignore_errors=True)

    # Create a test json file
    template_name = 'test_template'
    context = {'test_key': 'test_value'}
    dump(replay_dir, template_name, context)

    # Verify the result
    actual_context = load(replay_dir, template_name)
    assert actual_context == context

    # Delete test directory
    shutil.rmtree(replay_dir, ignore_errors=True)



# Generated at 2022-06-11 20:28:19.017601
# Unit test for function load
def test_load():
    context = load('tests/test-replay', 'tests/fake-repo-pre')
    assert(context["_template"]) == 'fake-repo-pre'


# Generated at 2022-06-11 20:28:22.337342
# Unit test for function load
def test_load():
    "Unit test for function load"
    context = load(os.path.expanduser('~/.cookiecutters'), 'cookiecutter-pypackage')
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['project_name'] == 'cookiecutter-pypackage'



# Generated at 2022-06-11 20:28:28.173848
# Unit test for function dump
def test_dump():
    """Test dump function"""

    template_name = 'test'
    context = {'cookiecutter': {'full_name': 'Test'}}

    replay_dir = 'replay_dir'
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        test_context = json.load(infile)
    
    assert context == test_context

    os.remove(replay_file)
    os.rmdir(replay_dir)


# Generated at 2022-06-11 20:28:30.916860
# Unit test for function load
def test_load():
    replay_dir = os.getcwd()
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    assert context
    print(context)

# Generated at 2022-06-11 20:28:38.674360
# Unit test for function load
def test_load():
    # Test the function load
    context = load("../../cookiecutter-template-project/replay", "cookiecutter.json")
    assert context['cookiecutter'] is not None

# Generated at 2022-06-11 20:28:45.143377
# Unit test for function load
def test_load():
    import pytest
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl/'
    test_load_context = load(replay_dir, template_name)
    test_load_context = load(replay_dir, template_name)
    # Test if context contains cookiecutter key
    assert 'cookiecutter' in test_load_context
    # Test if context has the same values and keys
    assert test_load_context['cookiecutter'] == {
        u'source_repo': u'https://github.com/hackebrot/cookiecutter-pypackage.git', u'project_slug': u'fake'}


# Generated at 2022-06-11 20:28:50.376360
# Unit test for function load
def test_load():
    """
    A function to test the load function.

    Returns:
        None
    """
    import json
    template = load("tests/test-replay-dir/", "cookiecutter-pypackage")
    with open("tests/test-replay-dir/cookiecutter-pypackage.json", 'r') as outfile:
        context = json.load(outfile)
    assert template == context


# Generated at 2022-06-11 20:28:54.019331
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'
    test_dic = {'cookiecutter': 
    {'author_email': '', 'author_name': '', 'full_name': '', 'github_username': '', 'project_name': 'test', 'repo_name': 'test4', 'short_description': ''}}
    test_name = 'test4'
    dump(replay_dir, test_name, test_dic)


# Generated at 2022-06-11 20:28:57.316998
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),'test_load/replay')
    template_name = 'test_load'
    context = load(replay_dir,template_name)
    print(context)


# Generated at 2022-06-11 20:29:01.006798
# Unit test for function load
def test_load():
    replay_dir = os.path.expanduser('~/.cookiecutter_replay')
    template_name = 'first_project'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:29:04.467216
# Unit test for function load
def test_load():
    replay_dir = '{{cookiecutter.repo_name}}/tests/test_files/replay'
    template_name = 'test_load'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:29:10.499706
# Unit test for function dump
def test_dump():
    import os
    os.environ["REPLAY_DIR"] = 'replay'
    os.environ["TEMPLATE_NAME"] = 'project_name'
    os.environ["CONTEXT"] = 'context'
    os.environ["CONTEXT['cookiecutter']"] = 'cookiecutter'
    assert dump


# Generated at 2022-06-11 20:29:16.080201
# Unit test for function load
def test_load():
    replay_dir='replay'
    template_name='test'
    context={'cookiecutter':{'replay':'1abc'}}
    dump(replay_dir, template_name, context)
    new_context=load(replay_dir, template_name)
    if new_context!=context:
        print('Load replay context failed!')
        exit(1)
    else:
        print('Load replay context succeed!')


# Generated at 2022-06-11 20:29:20.010874
# Unit test for function load
def test_load():
    replay_dir = 'test_load'
    context = {'cookiecutter': 'test_load'}
    template_name = 'hello_world'
    dump(replay_dir, template_name, context)

    assert load(replay_dir, template_name) == context


# Generated at 2022-06-11 20:29:35.113932
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = '~/cookiecutter-replay'
    context = {'cookiecutter': {'user': 'jason'}}
    
    dump(replay_dir, template_name, context)

# Generated at 2022-06-11 20:29:43.591430
# Unit test for function dump
def test_dump():
    """Unit test for function dump.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    # Setup a context
    context = {'cookiecutter': {}}
    context['cookiecutter']['full_name'] = 'Jan Holthuis'
    context['cookiecutter']['email'] = 'jan.holthuis@mailbox.org'
    context['cookiecutter']['project_name'] = 'cookiecutter-pypackage'
    context['cookiecutter']['project_slug'] = 'cookiecutter-pypackage'

    # Create a replay folder at temporary directory
    replay_dir = os.path.join(os.path.gettempdir(), 'replay')

# Generated at 2022-06-11 20:29:48.554198
# Unit test for function dump
def test_dump():
    replay_dir = "/Users/admin/Desktop/duckling/tmp/tests/fake-repo-pre/replay"
    template_name = "fake-repo-pre"
    context = {"cookiecutter": {"full_name": "Test User", "email": "test@example.com", "github_username": "Test User", "project_name": "test_project", "project_slug": "test_project", "project_short_description": '""', "pypi_username": "Test User", "version": "0.1.0", "project_license": "MIT"}}
    result = dump(replay_dir, template_name, context)
    expected_result = "{}/fake-repo-pre.json".format(replay_dir)

# Generated at 2022-06-11 20:29:52.462746
# Unit test for function dump
def test_dump():
     tname = "test"
     tdir = "test_dir"
     tcontext = {"first_name": "Sherlock", "last_name": "Holmes", "cookiecutter": {"replay": true }}
     dump(tdir, tname, tcontext)
     return

print('Testing Replay Dump')
test_dump()

# Generated at 2022-06-11 20:29:54.428487
# Unit test for function load
def test_load():
    values = {"cookiecutter": {"project_name": "foo", "project_slug": "bar"}}
    context = load("replay_dir", "project")
    assert values == context


# Generated at 2022-06-11 20:30:01.082278
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'testing'
    template_name = 'test'
    context = {}
    context['cookiecutter'] = {'project_name': 'test_name'}
    dump(replay_dir, template_name, context)

    assert os.path.isfile(get_file_name(replay_dir, template_name))

    # clean up
    os.remove(get_file_name(replay_dir, template_name))
    os.rmdir(replay_dir)



# Generated at 2022-06-11 20:30:09.194003
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'name': 'Your Name'}, 'name': 'Your Name', 'full_name': 'Your Name', 'email': 'youremail@domain.com', 'github_username': 'yourgithubusername', 'project_name': 'Your project name'}
    dump(os.path.join(os.getcwd(), 'tests', 'files', '.cookiecutters'), 'PACKT', context)
    context['cookiecutter']['name'] = 'Your Name 2'
    dump(os.path.join(os.getcwd(), 'tests', 'files', '.cookiecutters'), 'PACKT', context)


# Generated at 2022-06-11 20:30:14.346583
# Unit test for function dump
def test_dump():
    template_name = "{0}".format(input())
    context = raw_input()
    dump('/home/paul/Documents/projects/cookiecutter/tests/files/fake-repo-pre/', template_name, context)
    assert context == load('/home/paul/Documents/projects/cookiecutter/tests/files/fake-repo-pre/', template_name)

# Generated at 2022-06-11 20:30:22.050708
# Unit test for function dump
def test_dump():
    replay_dir = './tests/test-dump'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-11 20:30:30.713969
# Unit test for function load
def test_load():
    import json
    import os
    """Unit test for function load."""
    # Create a replay directory
    replay_dir = os.path.join(os.getcwd(), 'test')
    if not os.path.exists(replay_dir):
        os.mkdir(replay_dir)

    # Create a template name
    template_name = 'test_load.json'

    # Create a context
    context = {'test_load': {'test': 'data'}}

    # Write the context to the replay directory
    with open(os.path.join(replay_dir, template_name), 'w') as outfile:
        json.dump(context, outfile, indent=2)

    # Read the context from the replay directory
    context2 = load(replay_dir, template_name)

    # Compare

# Generated at 2022-06-11 20:31:02.576306
# Unit test for function load
def test_load():
    replay_dir = 'D:/cookiecutter-master/cookiecutter/tests/test-replay/load'
    template_name = 'my-great-new-project'
    context = load(replay_dir, template_name)
    print(context)
    assert context == {'cookiecutter': {'full_name': 'Monty Python', 'email': 'monty@python.com', 'project_name': 'Flying Circus', 'github_username': 'montypython', 'project_slug': 'flying-circus', 'project_license': 'BSD license', 'select_language': 'English', 'pypi_username': 'flying-circus', 'version': '0.1.0', 'year': '1970'},'_template': 'my-great-new-project'}


# Generated at 2022-06-11 20:31:10.737918
# Unit test for function load
def test_load():
    # First test case
    replay_dir = '/home/user/replay/'
    template_name = 'test/test'
    context = load(replay_dir, template_name)
    assert context['test'] == 'test', "Wrong value of test"
    # Second test case
    replay_dir = '/home/user/replay/'
    template_name = 'test/test.json'
    context = load(replay_dir, template_name)
    assert context['test'] == 'test', "Wrong value of test"
    # Third test case
    replay_dir = '/home/user/replay/'
    template_name = 'test/test.json'
    context = load(replay_dir, template_name)
    assert context['test'] == 'test', "Wrong value of test"


# Generated at 2022-06-11 20:31:16.753811
# Unit test for function load
def test_load():
    import os
    import json

    replay_dir = os.path.expanduser('~/.cookiecutter_replay/tests/replay_files')
    template_name = 'example'
    context = load(replay_dir, template_name)

    with open(os.path.expanduser('~/.cookiecutter_replay/tests/test_replay.json'), 'r') as infile:
        j = json.load(infile)
    assert context == j

# Generated at 2022-06-11 20:31:23.689130
# Unit test for function load
def test_load():
    """Test function load"""
    replay_dir = 'test_load'
    template_name = 'replay'

    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    if not isinstance(template_name, str):
        raise TypeError('Template name is required to be of type str')



    context = {'cookiecutter':{'name':'cookie cutter', 'version':'1.0'}}

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    with open(replay_file, 'r') as infile:
        context = json

# Generated at 2022-06-11 20:31:31.173525
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.abspath('./tests/files')
    template_name = 'input_hook_test'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert context['cookiecutter']['full_name'] == 'First Last'
    assert context['cookiecutter']['email'] == 'first.last@example.com'



# Generated at 2022-06-11 20:31:33.740928
# Unit test for function load
def test_load():
    template_name = "jenkins-plugin"
    replay_dir = "/tmp"

    with open("/tmp/jenkins-plugin.json", 'r') as infile:
        context = json.load(infile)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    return context

# Generated at 2022-06-11 20:31:38.459104
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    from cookiecutter.main import cookiecutter

    template = 'tests/test-cookiecutters/fake-repo-pre'
    output_dir = 'tests/test-output'

    cookiecutter(
        template,
        no_input=True,
        replay=False,
        output_dir=output_dir
    )

# Generated at 2022-06-11 20:31:47.237047
# Unit test for function load
def test_load():
    replay_file = get_file_name('/Users/anhnguyen/Desktop/Beta/cookiecutter-django/cookiecutter-django/tests/fixtures/',
                                'cookiecutter.json')
    context = load('/Users/anhnguyen/Desktop/Beta/cookiecutter-django/cookiecutter-django/tests/fixtures/',
                   'cookiecutter.json')
    with open(replay_file, 'r') as infile:
        expected_context = json.load(infile)
    if context != expected_context:
        raise AssertionError('Context is not the same as the content of fixture')
    print('Assertion test passed (test_load)')



# Generated at 2022-06-11 20:31:50.309836
# Unit test for function dump
def test_dump():
    replay_dir = '/playground/replay'
    template_name = 'template'
    context = dict(template='Test')

    dump(replay_dir, template_name, context)

    assert True


# Generated at 2022-06-11 20:31:52.934962
# Unit test for function load
def test_load():
    context = load('/home/lun/Downloads/cookiecutter-django', 'cookiecutter-django')