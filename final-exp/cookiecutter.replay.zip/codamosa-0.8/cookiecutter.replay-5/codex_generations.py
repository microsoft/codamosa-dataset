

# Generated at 2022-06-11 20:22:06.611872
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('./', 'test') == './test.json'
    assert get_file_name('./', 'test.json') == './test.json'



# Generated at 2022-06-11 20:22:13.305016
# Unit test for function load
def test_load():
    replay_dir = 'replay_json_test'
    template_name = 'replay_test'
    context = {'cookiecutter': {'full_name': 'Tal Safran', 'email': 'talsafran@gmail.com'}}
    dump(replay_dir, template_name, context)

    loaded_context = load(replay_dir, template_name)
    assert loaded_context['cookiecutter']['full_name'] == 'Tal Safran'
    assert loaded_context['cookiecutter']['email'] == 'talsafran@gmail.com'

# Generated at 2022-06-11 20:22:19.399434
# Unit test for function load
def test_load():
    template_name = 'my_test_template'
    replay_dir = './test_replay'
    expected_context = {'cookiecutter': {'blah': 'blah blah blah'}}
    dump(replay_dir, template_name, expected_context)
    context = load(replay_dir, template_name)
    assert(context==expected_context)



# Generated at 2022-06-11 20:22:23.240903
# Unit test for function get_file_name
def test_get_file_name():
    directory = '/tmp/cookiecutter/replay'
    template_name = 'cookiecutter-pypackage'
    replay_file = get_file_name(directory, template_name)
    assert replay_file == '/tmp/cookiecutter/replay/cookiecutter-pypackage.json'

# Generated at 2022-06-11 20:22:26.101428
# Unit test for function load
def test_load():
    """Test that load creates a context for the replay file."""
    replay_dir = "./tests/files/tests/example-repo"
    template_name = "project"
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)

# Generated at 2022-06-11 20:22:28.463487
# Unit test for function load
def test_load():
    """Test loading a file."""
    context = load("/home/cookiecutter/test", "cookiecutter.json")
    print(context)


# Main program

# Generated at 2022-06-11 20:22:30.505378
# Unit test for function load
def test_load():
    assert(load('tests/', 'config.json') == {'cookiecutter': {'config': {'somvar': 'Some value'}}})


# Generated at 2022-06-11 20:22:39.000753
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    from cookiecutter.replay import get_file_name
    import os

    result = get_file_name('/a/dir', 'a_file')
    expected = '/a/dir/a_file.json'
    assert result == expected

    result = get_file_name('/a/dir', 'another_file.json')
    expected = '/a/dir/another_file.json'
    assert result == expected

    result = get_file_name('/a/dir/', 'another_file.json')
    expected = '/a/dir/another_file.json'
    assert result == expected

# Generated at 2022-06-11 20:22:43.835167
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    replay_file = 'tests/test-replay/foo.json'
    with open(replay_file, 'r') as infile:
        context = json.load(infile)
    assert context == load(replay_dir, 'foo')

# Generated at 2022-06-11 20:22:46.347092
# Unit test for function get_file_name
def test_get_file_name():
	assert get_file_name('replay', 'template_name') == 'replay\\template_name.json'
	assert get_file_name('replay', 'template_name.json') == 'replay\\template_name.json'


# Generated at 2022-06-11 20:22:54.836541
# Unit test for function dump
def test_dump():
    test_dir = "tests/replay_dir"
    test_template_name = "tests/{{cookiecutter.project_slug}}"
    context = {
        'cookiecutter': {
            'key1': 'val1'
        },
        'other_key': 'other_val'
    }
    dump(test_dir, test_template_name, context)
    assert load(test_dir, test_template_name) == context



# Generated at 2022-06-11 20:22:57.876041
# Unit test for function load
def test_load():
    replay_dir = '~/Desktop/cookiecutter/cookiecutter/tests/test-output/requests'
    template_name = 'https:gitlab.com:replay'
    context = load(replay_dir, template_name)
    #print(context)
    return context

# Generated at 2022-06-11 20:23:06.471786
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    from cookiecutter.config import DEFAULT_CONFIG

    template_name = '{{cookiecutter.project_name}}-{{cookiecutter.project_slug}}'
    replay_dir = DEFAULT_CONFIG['replay_dir']

    context = cookiecutter(
        'tests/test-cookies/simple/',
        replay_dir=replay_dir,
        extra_context={'cookiecutter': {'project_name': 'Simple Example',
                                        'project_slug': 'simple_example'}}
    )
    replay = load(replay_dir, template_name)

    assert replay == context



# Generated at 2022-06-11 20:23:10.462816
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    replay_dir = 'tests/test-dump'
    template_name = 'test-template'
    context = {'cookiecutter': {'project_name': 'Foobar'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile('tests/test-dump/test-template.json')
    assert open('tests/test-dump/test-template.json').read() == '{\n  "cookiecutter": {\n    "project_name": "Foobar"\n  }\n}'
    os.remove('tests/test-dump/test-template.json')
    os.rmdir('tests/test-dump')

# Generated at 2022-06-11 20:23:13.459967
# Unit test for function load
def test_load():
    replay_dir='/Users/lanb/Documents/GitHub/cookiecutter-pypackage-minimal/tests/fixtures'
    template_name='fixture.json'
    load(replay_dir,template_name)

# Generated at 2022-06-11 20:23:17.141501
# Unit test for function load
def test_load():
    replay_dir = 'something'
    template_name = 'cookiecutter'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['dummy'] == 'Dummy content'


# Generated at 2022-06-11 20:23:26.031296
# Unit test for function dump
def test_dump():
    replay_file = '/Users/aishwaryasivasubramaniam/Documents/GitHub/cookiecutter/tests/test-replay/cookiecutter-pypackage-minimal.json'

# Generated at 2022-06-11 20:23:27.023406
# Unit test for function load
def test_load():
    context = load("replay", "template")


# Generated at 2022-06-11 20:23:34.606164
# Unit test for function load
def test_load():
#     template_name = 'test_template'
#     replay_dir = 'test_replay_dir'
#     replay_file = 'test_replay_file'
#     template_file = 'test_template_file'
    replay_dir = os.path.join(os.path.dirname(__file__), 'test', 'test_template')
    template_name = 'test_template'
    replay_file = get_file_name(replay_dir, template_name)
    template_file = os.path.join(replay_dir, template_name + '.json')
    print('template_file: {}'.format(template_file))
    print('replay_file: {}'.format(replay_file))
    with open(template_file, 'r') as infile:
        context = json.load

# Generated at 2022-06-11 20:23:36.583127
# Unit test for function load
def test_load():
    assert load('/home/bluetears/Documents/apps/cookiecutter-django/cookiecutters', 'cookiecutter-django')

# Generated at 2022-06-11 20:23:41.615385
# Unit test for function load
def test_load():
    assert(load("../cookiecutter_test/","cookiecutter.json")=={ "cookiecutter": { "name": "yoyi" } })

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-11 20:23:44.740088
# Unit test for function load
def test_load():
    os.environ['REPLAY_DIR'] = 'test_replay_dir/'

    load('test_replay_dir/', '_test_replay_file')


# Generated at 2022-06-11 20:23:47.427715
# Unit test for function load
def test_load():
    replay_dir = '~/workspace/pyzillow/tests/fixtures'
    template_name = 'cookiecutter-pypackage'

    load(replay_dir, template_name)

# Generated at 2022-06-11 20:23:56.976273
# Unit test for function load
def test_load():
    # Arrange
    # Create dummy data to store in json file
    context = {'cookiecutter': {'full_name': 'Test Name'}}
    # Create a new temporary directory, and set it to replay_dir
    import tempfile
    replay_dir = tempfile.mkdtemp()
    # Create json file to store context
    template_name = 'test_template'
    with open(os.path.join( replay_dir,template_name+'.json'), 'w') as outfile:
        json.dump(context, outfile, indent=2)
    # Act
    # Call load function to retrieve data from json file
    result = load(replay_dir, template_name)
    # Assert
    # Compare result with dummy data
    assert result == context

# Generated at 2022-06-11 20:24:03.469604
# Unit test for function load
def test_load():
    print("testing load")
    replay_dir = os.path.dirname(__file__) + "/test"
    template_name = "example_template"
    context = load(replay_dir, template_name)
    assert context is not None
    assert "cookiecutter" in context
    assert "project_name" in context["cookiecutter"]
    assert context["cookiecutter"]["project_name"] == "Example Project"



# Generated at 2022-06-11 20:24:09.341753
# Unit test for function dump
def test_dump():
    # defining the template context
    template_name = "helloworld-template"
    context = {
        "name": "cindy",
        "project_name": "HelloWorld",
        "language": "C++",
        "platform": "Windows",
        "framework": "OpenCV"
    }

    # replay_dir is a directory that saves the json file
    replay_dir = "C:/Users/Cindy/cookiecutters/"

    # write the context to replay_dir
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:24:17.159129
# Unit test for function load
def test_load():
    with open("/home/qilu/cookiecutter-master/tests/test-load/replay_dir/cookiecutter-pypackage-sh.json", 'r') as infile:
        context = json.load(infile)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')
    assert(context['cookiecutter']['full_name'] == '{{cookiecutter.full_name}}')
    return context



# Generated at 2022-06-11 20:24:21.144342
# Unit test for function dump
def test_dump():
    replay_dir = 'replay_dir'
    template_name = 'templ_name'
    context = {'cookiecutter': {'project_name': 'test_project'}}
    dump(replay_dir, template_name, context)
    cf = get_file_name(replay_dir, template_name)
    assert os.path.isfile(cf)
    assert os.stat(cf).st_size != 0


# Generated at 2022-06-11 20:24:29.227529
# Unit test for function load
def test_load():
    test_replay_dir = "test_replay_dir"
    test_template_name = "test_template_name"
    test_context = {'cookiecutter': 'test_context_value'}
    # Test passing a non-string template name
    try:
        load(test_replay_dir, 1)
        assert False
    except TypeError as e:
        assert True
    # Test passing a string template name
    dump(test_replay_dir, test_template_name, test_context)
    try:
        assert load(test_replay_dir, test_template_name) == test_context
    except Exception as e:
        assert False
    # Test passing a non-dict context

# Generated at 2022-06-11 20:24:39.368641
# Unit test for function load
def test_load():
    reload_dir = os.path.join(os.curdir, 'tests', 'test-load')

    test_name = 'test_load'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-11 20:24:43.650668
# Unit test for function load
def test_load():
    context = load("../tests/test_data/test_repo/fake_repo", "fake_template")

    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert isinstance(context['cookiecutter'], dict)

# Generated at 2022-06-11 20:24:44.544793
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-11 20:24:51.211632
# Unit test for function load
def test_load():
    cwd = os.getcwd()
    replay_dir = os.path.join(cwd, 'tests/files/replay')
    template_name = 'foobarbaz'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert 'project_name' in context['cookiecutter']
    assert context['cookiecutter']['project_name'] == 'Cookie Monster'
    assert 'repo_name' in context['cookiecutter']
    assert context['cookiecutter']['repo_name'] == 'cookiecutter-foobarbaz'

# Generated at 2022-06-11 20:25:00.780989
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'_copy_without_render': 'foo'}}
    dump(replay_dir='tests/files/replay',
         template_name='test',
         context=context)
    assert os.path.isfile('tests/files/replay/test.json')

    #Test error case
    try:
        dump(replay_dir='tests/files/replay',
             template_name=5,
             context=context)
    except TypeError:
        assert True
    else:
        assert False

    try:
        dump(replay_dir='tests/files/replay',
             template_name='test',
             context='barf')
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-11 20:25:03.578180
# Unit test for function load
def test_load():
    # Initialize replay_dir, template_name
    replay_dir, template_name = '/home/idies/workspace/Storage/isocolab/rpci/rpci_conda/rpci_conda_replay', 'rpci_conda'

    # Call function load
    context_dict = load(replay_dir, template_name)

    # Print the context_dict
    print(context_dict)


# Generated at 2022-06-11 20:25:05.390771
# Unit test for function load
def test_load():
    load('/Users/ruihaohuang/Desktop/python-cookbook/cookiecutter-jquery/tests/test-output', 'test-template')


# Generated at 2022-06-11 20:25:15.260074
# Unit test for function load
def test_load():
    context = load('replay', 'diogenes-59')
    assert context['project_name'] == 'DIOGENES'
    assert context['project_slug'] == 'diogenes'
    assert context['project_short_description'] == 'A Project to implement complex network analysis in Python'
    assert context['use_pytest'] == False
    assert context['use_pypi_deployment_with_travis'] == False
    assert context['use_docker'] == False
    assert context['pypi_username'] == 'anonymous'
    assert context['command_line_interface'] == 'click'
    assert context['github_username'] == 'widdowquinn'
    assert context['open_source_license'] == 'MIT license'
    assert context['project_version'] == '0.0.1'

# Generated at 2022-06-11 20:25:18.843712
# Unit test for function load
def test_load():
    replay_data = load('/home/yangling/nb_courses/test_project/cookiecutter', 'cookiecutter.json')
    print(replay_data)

test_load()

# Generated at 2022-06-11 20:25:27.516410
# Unit test for function load
def test_load():
    ''' Called directly from cmd line to test if the function load works.'''

    from cookiecutter.main import cookiecutter

    replay_dir = 'tests/test-replay'
    template_name = 'tests/test-template'

    # Dump a template
    cookiecutter(template_name, replay_dir=replay_dir)

    # Load context from dump and run it again
    context = load(replay_dir, template_name)
    cookiecutter(
        template_name, no_input=True, output_dir='tests/test-output',
        replay=context
    )



# Generated at 2022-06-11 20:25:33.544491
# Unit test for function load
def test_load():
    """Test loading data from file."""
    replay_dir = os.path.abspath('test.json')

    data = {
        'cookiecutter': {
            'abc': 's',
        }
    }

    with open(replay_dir, 'w') as infile:
        json.dump(data, infile)

    context = load(os.path.dirname(replay_dir), os.path.basename(replay_dir))

    assert context == data

    os.remove(replay_dir)



# Generated at 2022-06-11 20:25:42.797886
# Unit test for function load
def test_load():
    from cookiecutter import main
    import click
    import pytest
    import os

# Generated at 2022-06-11 20:25:47.088804
# Unit test for function load
def test_load():
    replay_dir = 'C:/Users/Administrator/Desktop/cookiecutter/tests/test-replay'
    template_name = 'pycharm_project'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:25:52.694564
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.dirname(os.getcwd()),"tests/fixtures/fake-repo-pre/")
    template_name = "fake-repo-pre"
    context = load(replay_dir, template_name)
    assert "cookiecutter" in context


# Generated at 2022-06-11 20:25:53.649868
# Unit test for function load
def test_load():
    load()

# Generated at 2022-06-11 20:26:01.447682
# Unit test for function load
def test_load():
    """Test load()."""
    import cookiecutter.main

    replay_dir = 'tests/test-replay'

    # Create a replay file
    template_name = 'tests/fake-repo-tmpl'
    context = cookiecutter.main.generate_context(
        template=template_name,
        default_context={'full_name': 'Audrey Roy'},
        context_file=None,
        output_dir='.'
    )
    dump(replay_dir, template_name, context)
    context_replayed = load(replay_dir, template_name)
    assert context == context_replayed



# Generated at 2022-06-11 20:26:06.245196
# Unit test for function load
def test_load():
    test_load.context = load('replay', 'cookiecutter-pypackage')
    if 'cookiecutter' in test_load.context:
        print("This is the file we just loaded:")
        print(test_load.context)
    else:
        print("This file was not loaded:")


# Generated at 2022-06-11 20:26:11.678831
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-bootstrap'
    replay_dir = 'cookiecutter/tests/fixtures'
    context=load(replay_dir, template_name)
    assert context.get('cookiecutter').get('full_name') == 'Foo Bar'


# Generated at 2022-06-11 20:26:22.454065
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join('tests','fixtures','cookiecutter','replay','simple')
    template_name = 'simple'
    context = {
        "cookiecutter": {
            "full_name": "Cookiecutter",
            "email": "audreyr@example.com",
            "github_username": "audreyr",
            "project_name": "Cookiecutter Simple Project",
            "project_slug": "cookiecutter-simple-project"
        }
    }
    dump(replay_dir, template_name, context)
    expected_path = os.path.join('tests','fixtures','cookiecutter','replay','simple','simple.json')
    assert os.path.isfile(expected_path)


# Generated at 2022-06-11 20:26:24.170227
# Unit test for function load
def test_load():
    with open('replay_tests.json', 'r') as infile:
        context = json.load(infile)


# Generated at 2022-06-11 20:26:26.560447
# Unit test for function load
def test_load():
    context = load('~/.cookiecutters', '{{cookiecutter.project_name}}')
    assert context['cookiecutter']['project_name'] == 'test_project'

# Generated at 2022-06-11 20:26:31.871296
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('C:/Users/wangx/Desktop/project/cookiecutter-flask', 'flask-mini')
    print(context)


# Generated at 2022-06-11 20:26:37.824990
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    # cookiecutter('/Users/skye/PycharmProjects/aws_cookiecutter_template/aws_cookiecutter_template/', no_input=True, extra_context={'project_name':'test_project'})
    cookiecutter('/Users/skye/PycharmProjects/aws_cookiecutter_template/aws_cookiecutter_template/', replay_dir='/Users/skye/PycharmProjects/aws_cookiecutter_template/replay')

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:26:42.888445
# Unit test for function load
def test_load():
    """Unit test for function load"""
    template_name = 'test'
    context = {'cookiecutter': {'test': 123}}
    replay_dir = 'tests/replay_dir'

    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)

    assert loaded_context == context

# Generated at 2022-06-11 20:26:46.909134
# Unit test for function load
def test_load():
    import tempfile
    from cookiecutter.utils import rmtree

    tmp_dir = tempfile.mkdtemp()
    template_name = 'test123'
    context = {}
    context['cookiecutter'] = {
        'repo_dir': '{{ cookiecutter.repo_dir }}',
        'repo_name': '{{ cookiecutter.repo_name }}',
        'project_name': '{{ cookiecutter.project_name }}',
    }
    dump(tmp_dir, template_name, context)

    try:
        new_context = load(tmp_dir, template_name)
        assert context == new_context
    finally:
        rmtree(tmp_dir)

# Generated at 2022-06-11 20:26:56.291995
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    template_name = 'test_template'
    replay_dir = './tests/test_replay_dir'
    context = {
        'cookiecutter': {
            'full_name': 'test name'
        }
    }
    dump(replay_dir, template_name, context)
    # Check that the correct file exists
    assert os.path.exists('./tests/test_replay_dir/test_template.json') == True
    # Check that the file contains the correct data
    with open('./tests/test_replay_dir/test_template.json', 'r') as f:
        assert json.load(f) == context


# Generated at 2022-06-11 20:27:04.164602
# Unit test for function load
def test_load():
    import json, pprint
    from cookiecutter.main import cookiecutter
    from cookiecutter.replay import load

    template_name = '{{cookiecutter.template_name}}'

    replay_dir = cookiecutter(
        '.',
        no_input=True,
        replay_dir='./tests/test-load-replay-dir',
        extra_context={'template_name': '{{cookiecutter.template_name}}'},
    )
    replay_file = load(replay_dir, template_name)


# Generated at 2022-06-11 20:27:09.053868
# Unit test for function dump
def test_dump():
    from cookiecutter.main import cookiecutter
    replay_dir = 'tmp'
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'project_name': 'Any Project'}}
    dump(replay_dir, template_name, context)

    #try to create new project
    cookiecutter(template_name, no_input=True, replay=True)
    assert os.path.exists('tmp\\cookiecutter-pypackage\\setup.py')


# Generated at 2022-06-11 20:27:16.321660
# Unit test for function load
def test_load():
    # create some test data and write a file
    test_context = {'foo': 'bar', 'cookiecutter':{'replay_dir': '.'}}
    test_filename = 'test.json'
    # write test data
    dump('.', test_filename, test_context)
    # load test data
    result = load('.', test_filename)
    # remove test file
    os.remove(test_filename)
    assert result == test_context

test_load()

# Generated at 2022-06-11 20:27:20.323842
# Unit test for function load
def test_load():
    assert load("/Users/Soniya/Projects/cookiecutter-pypackage", 'cookiecutter.json')['cookiecutter']['package_name'] == 'TestRishab'
    
    

# Generated at 2022-06-11 20:27:20.898453
# Unit test for function load
def test_load():
    pass

# Generated at 2022-06-11 20:27:27.531475
# Unit test for function load
def test_load():
    template_name = "test"
    replay_dir = "./replay/"
    load(replay_dir, template_name)


# Generated at 2022-06-11 20:27:31.467500
# Unit test for function load
def test_load():
    import json

    template_name = '{{cookiecutter.project_name}}'
    replay_dir = os.getcwd()

    with open(os.path.join('tests/test-repo', 'cookiecutter.json') , 'r') as infile:
        context = json.load(infile)

    dump(replay_dir, template_name, context)

    result = load(replay_dir, template_name)

    assert context == result

    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-11 20:27:35.709345
# Unit test for function load
def test_load():
    assert load(os.path.expanduser('~/.cookiecutters'), 'cookiecutter-pypackage')['cookiecutter']['project_name'] == 'pypackage'

# Generated at 2022-06-11 20:27:40.941881
# Unit test for function dump
def test_dump():
    template_name = "test"
    context = {'cookiecutter': {"replay_dir": "test"}}
    replay_dir = "test"
    file_name = "./test/test.json"
    assert get_file_name(replay_dir, template_name) == file_name
    assert dump(replay_dir, template_name, context) is None
    assert os.path.isfile(file_name) is True
    os.remove(file_name)
    assert (get_file_name(replay_dir, template_name+".json")) == file_name
    assert (dump(replay_dir, template_name+".json", context)) is None
    assert os.path.isfile(file_name) is True
    os.remove(file_name)



# Generated at 2022-06-11 20:27:48.750061
# Unit test for function dump
def test_dump():
    replay_dir = os.getcwd()
    template_name = "test_template"
    context = {'cookiecutter': {'template_name': template_name, 'replay_dir': replay_dir}}
    # 1. exceptions
    for item in ['', [], 1, None, {}]:
        try:
            dump(item, template_name, context)
        except Exception as e:
            assert(isinstance(e, TypeError))

        try:
            dump(replay_dir, item, context)
        except Exception as e:
            assert(isinstance(e, TypeError))

        try:
            dump(replay_dir, template_name, item)
        except Exception as e:
            assert(isinstance(e, TypeError))

# Generated at 2022-06-11 20:27:55.713950
# Unit test for function load

# Generated at 2022-06-11 20:28:01.292712
# Unit test for function load
def test_load():
    # If a replay dir exists, then the replay will be loaded
    assert 'cookiecutter' in load('./tests/test-output', 'test-template')
    # If a replay dir does not exist, then an error will be raised
    try:
        assert 'cookiecutter' in load('./fake-replay-dir', 'test-template')
        assert 1 == 0
    except IOError:
        assert 1 == 1
    # If the context does not contain a 'cookiecutter' key, an error will be raised
    try:
        load('./tests/test-output', 'test-template').pop('cookiecutter')
        assert 'cookiecutter' in load('./tests/test-output', 'test-template')
        assert 1 == 0
    except ValueError:
        assert 1 == 1
    # If the template

# Generated at 2022-06-11 20:28:03.145877
# Unit test for function load
def test_load():
    load(r"C:\Users\pengwang\Desktop\snippets\cookiecutter", "index.html")



# Generated at 2022-06-11 20:28:05.175210
# Unit test for function load
def test_load():
    context = load('/home/jaehongseo/Desktop/replay', 'template_dir')
    assert isinstance(context, dict)


# Generated at 2022-06-11 20:28:14.151526
# Unit test for function load
def test_load():
    replay_dir="test_data"
    template_name="test_template"
    context=load(replay_dir, template_name)
    assert context['cookiecutter']['full_name']=='John Smith'
    assert context['cookiecutter']['project_name']=='Python Project'
    assert context['cookiecutter']['email']=='john@example.com'
    assert context['cookiecutter']['github_username']=='me'
    assert context['cookiecutter']['project_short_description']=='TODO: write a short description of your project'
    assert context['cookiecutter']['version']=='0.1.0'
    assert context['cookiecutter']['release']=='0.1.0'

# Generated at 2022-06-11 20:28:30.102468
# Unit test for function load
def test_load():
    replay_dir = os.path.abspath('/home/travis/build/dresende/cookiecutter-django-crud/tests/fixtures/fake-replay-dir')
    assert isinstance(load(replay_dir, 'fake-repo-pre/'), dict)
    assert isinstance(load(replay_dir, 'fake-repo-pre/{{cookiecutter.repo_name}}'), dict)
    assert isinstance(load(replay_dir, 'fake-repo-pre/{{cookiecutter.repo_name}}/'), dict)
    assert isinstance(load(replay_dir, 'fake-repo-pre/{{cookiecutter.repo_name}}/{{cookiecutter.project_name}}'), dict)

# Generated at 2022-06-11 20:28:33.080781
# Unit test for function load
def test_load():
    assert load('tests/test-replay', 'no-valid-key') == {
        'cookiecutter': {},
    }

# Generated at 2022-06-11 20:28:37.106695
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.expanduser("~"), '.cookiecutters')
    template_name = "cookiecutter-pypackage"
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:28:40.469539
# Unit test for function load
def test_load():
    """Test function load."""
    context = load('replay', 'master')
    print(context)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:28:42.883816
# Unit test for function load
def test_load():
    replay_dir = '/Users/luoqiaoen/Desktop/git/cookiecutter-pypackage-minimal'
    template_name = 'cookiecutter.json'
    load(replay_dir, template_name)



# Generated at 2022-06-11 20:28:46.534884
# Unit test for function load
def test_load():
    context = load(replay_dir='/Users/mattar/Development/trello/trello-cookiecutter/tests',
              template_name='trello-app')
    print(context)

# Generated at 2022-06-11 20:28:53.557285
# Unit test for function load
def test_load():
    # Setup test
    template_name = 'audreyr/cookiecutter-pypackage'
    replay_dir = "/home/audreyr/projects/cookiecutter/cookiecutter/tests/test-replay"
    # Perform test
    context = load(replay_dir, template_name)
    # Verify results
    assert isinstance(context, dict)
    assert isinstance(context['cookiecutter'], dict)
    assert context['full_name'] == 'Audrey Roy Greenfeld'
    assert context['email'] == 'audreyr@example.com'
    assert context['project_name'] == 'Python Boilerplate'
    assert context['project_slug'] == 'python-boilerplate'


# Generated at 2022-06-11 20:28:56.836452
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = r'/Users/paul/repos/cookiecutter-pypackage'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print (context)


# Generated at 2022-06-11 20:29:03.665556
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    from tempfile import TemporaryDirectory
    from pprint import pprint
    tmpdir = TemporaryDirectory()

    cookiecutter(
        'tests/test-replay/',
        no_input=True,
        replay=True,
        overwrite_if_exists=True,
        output_dir=tmpdir.name,
    )
    pprint(load(tmpdir.name, 'test-template'))


# Generated at 2022-06-11 20:29:14.533000
# Unit test for function load

# Generated at 2022-06-11 20:29:40.929601
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir='Tests/test-output/replay',
                   template_name=template_name)
    assert template_name in context


# Generated at 2022-06-11 20:29:42.663392
# Unit test for function load
def test_load():
    assert(load('test_replay_dir', 'test_template_name') == {'cookiecutter': {'replay': True}})


# Generated at 2022-06-11 20:29:44.502432
# Unit test for function load
def test_load():
    assert isinstance(load('cookiecutter.replay/tests/test_data/', 'foo'), dict)


# Generated at 2022-06-11 20:29:45.454104
# Unit test for function load
def test_load():
    '''Load a file in a specified location'''
    pass

# Generated at 2022-06-11 20:29:48.233542
# Unit test for function load
def test_load():
    replay_dir = 'replay'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context

test_load()

# Generated at 2022-06-11 20:29:51.007559
# Unit test for function load
def test_load():
    replay_data = load('C:/Users/Zachary/AppData/Local/cookiecutter_TEAM_PROJECT/replay','cookiecutter')
    print(replay_data)


# Generated at 2022-06-11 20:29:53.116947
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-pypackage'
    replay_dir = 'C:\\Users\\kylep\\'
    print(load(replay_dir, template_name))


# Generated at 2022-06-11 20:29:56.331901
# Unit test for function load
def test_load():
    replay_dir = 'mytmpl_replay'
    template_name = 'mytmpl'
    context = {
        'cookiecutter': {'full_name': 'Test User',
                          'project_name': 'Test Project'}
    }
    dump(replay_dir, template_name, context)
    context2 = load(replay_dir, template_name)
    assert context == context2
    # os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-11 20:29:59.179694
# Unit test for function load
def test_load():
    context = load("test/test2/replay/test2_example_com/", "test2_example_com")
    assert(context["cookiecutter"]["repo_name"] == "test2_example_com")

# Generated at 2022-06-11 20:30:00.536514
# Unit test for function load
def test_load():
    context = load(replay_dir = "../..", template_name = "")

# Generated at 2022-06-11 20:31:20.643762
# Unit test for function load
def test_load():
    assert 'cookiecutter' in load('~/.cookiecutter_replay', 'cookiecutter-pypackage')


# Generated at 2022-06-11 20:31:22.020691
# Unit test for function load
def test_load():
    context = load('data', 'second_test_template')
    assert 'cookiecutter' in context

# Generated at 2022-06-11 20:31:32.969608
# Unit test for function load
def test_load():
    #
    #test for successful loading
    replay_dir = '~/cookiecutter_dir'
    template_name = 'test'
    context = {'cookiecutter':1, 'Test': 2}
    dump(replay_dir, template_name, context)
    actual = load(replay_dir, template_name)
    assert actual == context
    #
    # test for unsuccessful template name type loading
    try:
        load(replay_dir, 1)
    except TypeError as e:
        assert type(e) == TypeError
    #
    # test for unsuccessful cookiecutter key loading
    context_bad = {'Test': 2}
    dump(replay_dir, template_name, context_bad)

# Generated at 2022-06-11 20:31:40.677661
# Unit test for function load
def test_load():
    replay_dir = os.getcwd()
    replay_file = get_file_name(replay_dir, 'dummy/project_name')
    context = {'cookiecutter': {'project_name': 'name1', 'pypi_username': 'user1'}}
    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)
    context = load(replay_dir, 'dummy/project_name')
    assert context.get('cookiecutter', {}).get('project_name') == 'name1'
    assert context.get('cookiecutter', {}).get('pypi_username') == 'user1'

# Generated at 2022-06-11 20:31:45.397432
# Unit test for function load
def test_load():
    """Unit test for load function."""
    from pprint import pprint

    replay_dir = 'tests/fake-repo-pre/'
    template_name = 'fake-repo-pre'

    context = load(replay_dir, template_name)
    pprint(context)


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:31:47.617521
# Unit test for function load
def test_load():
    assert load('test_load', 'test_load') == {'cookiecutter': {'name': 'name', 'cmd_args': {}}}

# Generated at 2022-06-11 20:31:52.905871
# Unit test for function dump
def test_dump():
    """
    Test the dump function by constructing a simple context, creating a
    replay directory and calling dump.
    """
    context = {
        'cookiecutter': {
            'full_name': 'Edward L. Loper',
            'email': 'edloper@example.com',
        }
    }
    replay_dir = 'test_setup/test_replay_dir'
    template_name = 'test'

    dump(replay_dir, template_name, context)

# Generated at 2022-06-11 20:31:57.209949
# Unit test for function load
def test_load():
    """Test function load."""
    replay_dir = 'tests/files/replay'
    template_name = 'simple'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Samuel Kolb'


# Generated at 2022-06-11 20:32:02.859010
# Unit test for function load
def test_load():
    path = "./cc_pypackage"
    l = load(path, 'cc_pypackage')
    assert l['cookiecutter']['project_name'] == 'Python Package'
    assert l['cookiecutter']['repo_name'] == 'python_package'
    assert l['cookiecutter']['author_name'] == 'Audrey Roy Greenfeld'
    assert l['cookiecutter']['email'] == 'aroy@alum.mit.edu'
    assert l['cookiecutter']['description'] == 'A Python package project template.'
    assert l['cookiecutter']['version'] == '0.1.0'
    assert l['cookiecutter']['open_source_license'] == 'MIT license'
