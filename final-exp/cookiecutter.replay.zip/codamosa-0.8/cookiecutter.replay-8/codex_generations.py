

# Generated at 2022-06-11 20:22:12.446479
# Unit test for function load
def test_load():
    import os, json
    from tempfile import mkdtemp
    from shutil import rmtree

    # Create a temporary directory
    tmp_dir = mkdtemp()
    replay_dir = os.path.join(tmp_dir, 'myreplaydir')
    # Create the replay dir
    os.mkdir(replay_dir)
    my_context = {'cookiecutter': {'name': 'faker'}}
    my_template_name = 'fake-name'
    my_replay_file = get_file_name(replay_dir, my_template_name)
    with open(my_replay_file, 'w') as outfile:
        json.dump(my_context, outfile, indent=2)

    result = load(replay_dir, my_template_name)

# Generated at 2022-06-11 20:22:15.031707
# Unit test for function load
def test_load():
    try:
        #from cookiecutter.replay import load
        r = load('path', 'temp_name')
        assert r is None
    except:
        assert True


# Generated at 2022-06-11 20:22:24.761680
# Unit test for function dump
def test_dump():
    #arrange
    replay_dir = os.path.join(os.getcwd(), 'test_dir')
    template_name = "test_dir"
    context = {"cookiecutter": {'full_name': 'First Last', 'email': 'example@example.com', 'github_username': 'example'}}
    #act
    dump(replay_dir, template_name, context)
    
    replay_file = get_file_name(replay_dir, template_name)
    assert not os.path.exists(replay_file)
    with open(replay_file, 'r') as file:
        file_json = json.load(file)
    
    assert file_json == context
    os.remove(replay_file)
    os.rmdir(replay_dir)

#

# Generated at 2022-06-11 20:22:27.609955
# Unit test for function load
def test_load():
    context = load(r'C:\Users\chena\PycharmProjects\cookiecutter\cookiecutter-pypackage', 'cookiecutter.json')
    print(context)


# Generated at 2022-06-11 20:22:31.817587
# Unit test for function load
def test_load():
    template_name = "Test-Python3.x-config-default"
    result = load("./", template_name)
    assert(result['cookiecutter']['full_name'] == 'your name')
    result['cookiecutter']['full_name'] = 'shekai'
    assert(result['cookiecutter']['full_name'] == 'shekai')

# Generated at 2022-06-11 20:22:40.795682
# Unit test for function get_file_name
def test_get_file_name():
    """Create a test for get_file_name()."""
    replay_files = [
        ('/home/asim/python/cookiecutter/', 'cookiecutter.json', True),
        ('/home/asim/python/cookiecutter/', 'cookiecutter', False),
        ('/home/asim/python/cookiecutter/', 'cookiecutter.', True),
        ('/home/asim/python/cookiecutter/', '.json', True),
        ('/home/asim/python/cookiecutter/', '', True),
        ('/home/asim/python/cookiecutter/','.json', True),
    ]

# Generated at 2022-06-11 20:22:46.465881
# Unit test for function load
def test_load():
    replay_dir = '/tmp/test_load'
    template_name = 'test_load'
    context = {'cookiecutter': {'replay_test': 1, 'replay_test2': 2}}
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['replay_test'] == 1
    assert context['cookiecutter']['replay_test2'] == 2


# Generated at 2022-06-11 20:22:50.185534
# Unit test for function load
def test_load():
    import os
    from cookiecutter.replay import load
    replay_dir = os.getcwd()
    template_name = 'openstack'
    context = load(replay_dir, template_name)
    print(context)
    assert isinstance(context, dict), 'dict type'


# Generated at 2022-06-11 20:22:53.297429
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay_dir','template_name')=='replay_dir/template_name.json'


# Generated at 2022-06-11 20:23:00.721385
# Unit test for function load

# Generated at 2022-06-11 20:23:04.765694
# Unit test for function load
def test_load():
    context = load('..', 'test')
    assert isinstance(context, dict)
    assert context != None


# Generated at 2022-06-11 20:23:14.519784
# Unit test for function load
def test_load():
    # Create the context dictionary
    context = {
        'replay_dir': 'tests/tests/files',
        'template_name': 'example-replay',
        'cookiecutter': {
            'full_name': 'Vincent Driessen',
            'email': 'vincent@datafox.nl',
            'project_name': 'Cookiecutter-Pypackage'
        }
    }

    # Load the context
    context = load(context['replay_dir'], context['template_name'])
    assert context == {'cookiecutter': {'email': 'vincent@datafox.nl', 'full_name': 'Vincent Driessen', 'project_name': 'Cookiecutter-Pypackage'}}


# Generated at 2022-06-11 20:23:18.933984
# Unit test for function dump
def test_dump():
    template_name = 'test_template'
    replay_dir = 'C:\\Users\\kjs09\\django-develop\\cookiecutter.replay'
    context = {'cookiecutter': {'nodir': True}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:23:27.326322
# Unit test for function dump
def test_dump():
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()

    template_name = 'my-repo'
    context = {
        "cookiecutter": {
            "author_name": "Joe Bloggs",
            "email": "joe.bloggs@gmail.com",
            "full_name": "Joe Bloggs",
            "github_username": "joe-bloggs",
            "project_name": "my-repo",
            "project_slug": "my-repo",
            "project_short_description": "Automatically generated test repo",
            "version": "0.1.0"
        }
    }

    dump(temp_dir, template_name, context)


# Generated at 2022-06-11 20:23:28.938536
# Unit test for function load
def test_load():
    context = load('/tmp', 'cookiecutter-pypackage')
    assert isinstance(context, dict)

# Generated at 2022-06-11 20:23:29.916763
# Unit test for function load
def test_load():
    assert(isinstance(load('templates', 'json'), dict))


# Generated at 2022-06-11 20:23:31.471042
# Unit test for function load
def test_load():
    """Unit test for function load."""
    res = load('cookiecutter', 'cookiecutter')

# Generated at 2022-06-11 20:23:39.685707
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'abc'
    context = {
        'cookiecutter': {
            'first_name': 'Nan',
            'last_name': 'Zhang',
            'email': 'test@test.test',
            'github_username': 'test',
            'project_name': 'test',
            'project_slug': 'test',
            'pypi_username': 'test',
            'year': '2013',
            'version': '0.1.0',
            'full_name': 'Nan Zhang',
            'today': '2013-01-10',
        }
    }

    dump(replay_dir='tests/test-replay', template_name=template_name, context=context)

# Generated at 2022-06-11 20:23:49.421138
# Unit test for function load
def test_load():
    replay_dir = os.path.expanduser('~/.cookiecutters/')
    template_name = 'replay_test_template'

# Generated at 2022-06-11 20:23:57.867799
# Unit test for function load
def test_load():
    # Create the temp directory
    template_name = 'hello-world-json'
    replay_dir = 'C:\\Users\\User\\Desktop\\temp'
    os.mkdir(replay_dir)
    # Create json file
    with open('C:\\Users\\User\\Desktop\\temp\\hello-world-json.json', 'w') as outfile:
        json.dump({'cookiecutter': {'full_name': 'user'}}, outfile, indent=2)
    context = load(replay_dir,template_name)
    if 'cookiecutter' not in context:
        raise Exception('Error: the context is not contain a cookiecutter key')
    print('test_load() finished')


# Generated at 2022-06-11 20:24:03.823040
# Unit test for function load
def test_load():
    context = load(replay_dir='/Users/jiaweiliu/CloudStation/jiaweiliu/Research/Software/Cookiecutter/tests/fake-repo-pre', template_name='fake-repo-pre')
    print (context)

# Generated at 2022-06-11 20:24:10.809029
# Unit test for function load
def test_load():
    """Unit test for function dump."""
    import json
    import os

    template_name = 'test'
    replay_dir = 'test_{{cookiecutter.project_name}}_replay'

    # Create test directory
    if not os.path.exists(replay_dir):
        os.makedirs(replay_dir)

    # Save json data to file

# Generated at 2022-06-11 20:24:18.151678
# Unit test for function dump
def test_dump():
    from cookiecutter.replay import dump
    import os
    import tempfile
    template_name = "test_cookiecutter"
    context = {"cookiecutter": {"replay": "haha"}}
    replay_dir = tempfile.gettempdir()
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)


# Generated at 2022-06-11 20:24:20.722878
# Unit test for function load
def test_load():
    replay_dir=os.path.dirname(os.path.realpath(__file__))
    template_name="cookiecutter-pypackage"
    context=load(replay_dir,template_name)
    print(context)

# test_load()

# Generated at 2022-06-11 20:24:25.687173
# Unit test for function load
def test_load():
    replay_dir = "C:/Users/USER/Desktop/py-cookiecutter/cookiecutter-pypackage/"
    template_name = "cookiecutter-pypackage"
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-11 20:24:36.424231
# Unit test for function load
def test_load():
    # Load non-existing file
    try:
        load('nofile.json')
    except FileNotFoundError as e:
        #expected Exception
        pass
    else:
        # Unexpected exception
        assert False

    # Load valid file
    assert load('valid.json') == {
        'cookiecutter': {'full_name': 'First Last', 'email': 'test@test.test'}
    }

    # Load file without cookiecutter key
    try:
        load('without_cookiecutter.json')
    except ValueError as e:
        #expected Exception
        pass
    else:
        # Unexpected exception
        assert False

    # Load file with wrong type
    try:
        load('wrongtype.json')
    except TypeError as e:
        #expected Exception
        pass

# Generated at 2022-06-11 20:24:43.462256
# Unit test for function load
def test_load():
    replay_dir = 'fake_dir'
    template_name = 'fake_template'

    try:
        load(replay_dir, 'fake_template')
        raise AssertionError('Expected ValueError')
    except ValueError as e:
        assert str(e) == 'No such file or directory: \'fake_dir\''

    try:
        load(replay_dir, template_name)
        raise AssertionError('Expected ValueError')
    except ValueError as e:
        assert str(e) == 'Context is required to contain a cookiecutter key'


test_load()

# Generated at 2022-06-11 20:24:45.978493
# Unit test for function load
def test_load():
    context = load('.', 'cookiecutter.json')
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['repo_name'] is None

# Generated at 2022-06-11 20:24:53.911042
# Unit test for function load
def test_load():
    """Unit test for load function."""
    template_name = 'cookiecutter-pypackage'
    sample_context = {
        'author': 'somebody',
        'author_email': 'email@email.com',
        'description': "my description",
        'full_name': 'fname lname',
        'name': 'package_name',
        'open_source_license': 'MIT',
        'python_version': '3.6',
        'repo_name': 'package_name',
        'use_pytest': 'y'
    }
    current_dir = os.path.abspath(os.path.dirname(__file__))
    replay_dir = os.path.join(current_dir, 'replay')


# Generated at 2022-06-11 20:24:57.902682
# Unit test for function load
def test_load():
    replay_dir = ".cookiecutter-replay"
    template_name = "py_cli"
    context = load(replay_dir, template_name)
    assert context["cookiecutter"]["full_name"] == "Haiyu Zhu"


# Generated at 2022-06-11 20:25:04.776387
# Unit test for function dump
def test_dump():
    """Unit test for dump()."""
    print('Running test for dump')
    template_name = 'test'
    context = {'test': 'test'}
    replay_dir = os.path.abspath('./tests/test-files/test-replay')

    dump(replay_dir, template_name, context)

    assert os.path.exists(os.path.join(replay_dir, 'test.json'))

    # Clean up
    os.remove(os.path.join(replay_dir, 'test.json'))


# Generated at 2022-06-11 20:25:06.476137
# Unit test for function load
def test_load():
    """Unit test for function load of replay.py"""
    context = load('replay', 'test_template')
    assert isinstance(context, dict)


# Generated at 2022-06-11 20:25:08.795239
# Unit test for function load
def test_load():
    load_replay_dir = 'C:\\Users\\kelley\\Desktop\\GitHub\\cookiecutter-c-project'
    load_template_name = 'template'
    print (load(load_replay_dir, load_template_name))
    print('done')


# Generated at 2022-06-11 20:25:11.511861
# Unit test for function load
def test_load():
    assert load('/Users/kyle_yuan/Downloads/','cookiecutter-pypackage')


# Generated at 2022-06-11 20:25:14.964561
# Unit test for function load
def test_load():
    print("Unit test for load function")
    context = load("replay_dir","template_name")
    print(context)
    print("-------------------")


# Generated at 2022-06-11 20:25:20.270919
# Unit test for function load
def test_load():
    # Create test context
    replay_dir = 'test_replay_dir'
    context = {'cookiecutter': {'_copy_without_render': ['ignored_file']}}

    # Write context to file
    template_name = 'test_template'
    dump(replay_dir, template_name, context)

    # Open file and check context
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-11 20:25:31.523498
# Unit test for function dump
def test_dump():
    """Test dump function."""
    import shutil
    import tempfile
    import pytest
    #############
    # Setup
    #############
    replay_dir = tempfile.mktemp()
    template_name = 'test_template_name'
    context = dict(
        cookiecutter=dict(
            template_name='test_template_name',
            version='0.0.0!',
            path=os.path.join(replay_dir, 'test_template_name')
        )
    )
    #############
    # Test
    #############
    # 1. Creating the directory
    assert not make_sure_path_exists(replay_dir)
    dump(replay_dir, template_name, context)

# Generated at 2022-06-11 20:25:37.782575
# Unit test for function load

# Generated at 2022-06-11 20:25:46.700003
# Unit test for function load
def test_load():
  """
  Simple unit test function to test load function in replay.py
  """
  template_name = "{{cookiecutter.coffee_type}}"
  context = {'cookiecutter': {'coffee_type': 'espresso'}}

  replay_dir = 'replay'
  dump(replay_dir, template_name, context)

  loaded_context = load(replay_dir, template_name)

  if(loaded_context == context):
    print("test_load passed!")
  else:
    print("test_load failed!")
    print("loaded_context: " + str(loaded_context))
    print("context: " + str(context))

test_load()

# Generated at 2022-06-11 20:25:54.640282
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'project_name': 'audrey',
            'description': 'A simple Python project',
            'author_name': 'Audrey Roy',
            'author_email': 'audreyr@example.com',
            'year': '2016',
            'github_username': 'audreyr'
        }
    }
    template_name = 'audrey/roy'
    replay_dir = os.path.expanduser("~/.cookiecutters")
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:26:05.626596
# Unit test for function load
def test_load():
    template_name = 'Test_load_template'
    replay_dir = os.path.expanduser('~/Desktop/Templates')
    context = {'cookiecutter': {'project_name': 'XYZ-project',
                'author_name': 'A.N. Author', 'description': 'description',
                'open_source_license': 'MIT license', 'domain': 'python',
                }}
    dump(replay_dir, template_name, context)
    template_name = 'Test_load_template.json'
    replay_dir = os.path.expanduser('~/Desktop/Templates')
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'XYZ-project'


# Generated at 2022-06-11 20:26:14.883319
# Unit test for function load
def test_load():
    """Test function load(): load replay file."""
    os.mkdir("replay_test")
    f = open("replay_test/test_load.json", "w+")
    f.write("{}")
    # f.write("{\"cookiecutter\":{\"_copy_without_render\" : [\"_copy_without_render\"]}}")
    f.close()

    assert load("replay_test", "test_load") == {}
    # assert load("replay_test", "test_load") == {"cookiecutter":{"_copy_without_render" : ["_copy_without_render"]}}

    os.remove("replay_test/test_load.json")
    os.rmdir("replay_test")
    print("test_load() pass.")



# Generated at 2022-06-11 20:26:18.288218
# Unit test for function load
def test_load():
    context = load('./tests/test-load', 'foo')
    assert(context['cookiecutter']['replay_file_name'] == './tests/test-load/foo.json')



# Generated at 2022-06-11 20:26:20.306764
# Unit test for function load
def test_load():
    print (load(replay_dir, template_name))
    print (load(replay_dir, template_name))

# Generated at 2022-06-11 20:26:26.286584
# Unit test for function dump
def test_dump():
    replay_dir = 'test_replays'
    template_name = 'test_template'
    context = {'cookiecutter': {'name': 'test_name', 'email': 'test_email'}}

    test_replay_file = get_file_name(replay_dir, template_name)

    if os.path.isfile(test_replay_file):
        os.remove(test_replay_file)

    dump(replay_dir, template_name, context)

    if not os.path.isfile(test_replay_file):
        raise IOError('Unable to create test replay dir')
    if not os.path.isdir(replay_dir):
        raise IOError('Test replay dir is not directory')

    os.remove(test_replay_file)
    os.rmd

# Generated at 2022-06-11 20:26:28.411212
# Unit test for function load
def test_load():
    load('/tmp', 'temp.json')

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:26:32.618217
# Unit test for function dump
def test_dump():
    replay_dir = 'C:/Users/hong/cookiecutter-django-master/tests/test-output/replay'
    dump(replay_dir, "pyproj.json", {'cookiecutter': {'project_name': 'foobar'}})



# Generated at 2022-06-11 20:26:36.239193
# Unit test for function load
def test_load():
    replay_dir = "coookiecutter/tests/test-output/cookiecutter-tests-run"
    test_data = load(replay_dir, "test_project")
    assert(test_data.get("cookiecutter").get("project_slug") == "test_project")


# Generated at 2022-06-11 20:26:44.170572
# Unit test for function load
def test_load():
    # Create a replay file
    replay_dir = '/Users/sumyatthu/git/cookiecutter/tests/test-load'
    template_name = 'test.json'
    context = {
        'cookiecutter': {
            'full_name': 'Sumyat Thu',
            'email': 'sumyat.thu@gmail.com'
        }
    }
    dump(replay_dir, template_name, context)

    # Load context from file
    loaded_context = load(replay_dir, template_name)
    print(loaded_context)

    # Validating loaded context
    assert loaded_context == context

# Generated at 2022-06-11 20:26:46.092039
# Unit test for function load
def test_load():
    assert load('tests/files/tests_replay', 'tests_replay') == {'cookiecutter': {'cookiecutter': 'tests/files/tests_replay'}}

# Generated at 2022-06-11 20:27:01.257070
# Unit test for function load
def test_load():
    # create a test directory and template to test with
    replay_dir = 'test-replay'
    template_name = 'test-template'
    template_file = get_file_name(replay_dir, template_name)

    # define some test data to dump
    test_data = {
        'key1': 'value1',
        'key2': 'value2',
    }

    # dump the test data to the directory
    dump(replay_dir, template_name, test_data)

    # assert that the dump was successful
    assert os.path.isfile(template_file)

    # load the template from the directory
    loaded_data = load(replay_dir, template_name)

    # assert that the loaded data is the same as the test data
    assert test_data == loaded_data

    # remove

# Generated at 2022-06-11 20:27:07.154861
# Unit test for function dump
def test_dump():
    # 1.Test for IOError
    try:
        # False path.
        dump(replay_dir='F:/cookiecutter/replays', template_name='cookiecutter-pypackage', context={})
    except IOError as e:
        print('1.1.Test for IOError:', e)
    else:
        print('1.1.Test for IOError:')
    try:
        # None path.
        dump(replay_dir=None, template_name='cookiecutter-pypackage', context={})
    except IOError as e:
        print('1.2.Test for IOError:', e)
    else:
        print('1.2.Test for IOError:')

# Generated at 2022-06-11 20:27:10.369127
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('replay','example')
    assert type(context['cookiecutter']) is dict
    assert 'full_name' in context['cookiecutter']



# Generated at 2022-06-11 20:27:12.228702
# Unit test for function load
def test_load():

    file_name = load(replay_dir, template_name)
    assert file_name == 'file_name'

# Generated at 2022-06-11 20:27:17.690654
# Unit test for function load
def test_load():
    load(token[0],token[1])
    load(token[0],token[2])

    load(token[1],token[0])
    load(token[1],token[1])
    load(token[1],token[2])

    load(token[2],token[0])
    load(token[2],token[1])
    load(token[2],token[2])


# Generated at 2022-06-11 20:27:23.065063
# Unit test for function load
def test_load():
    assert isinstance( load("C:/cookie", "Test"), dict), "The loaded json should be a dict"
    assert isinstance( load("C:/cookie", "Test")['cookiecutter'], dict), "The loaded json should contain a cookiecutter key"
    try:
        load("C:/cookie", 4)
    except TypeError:
        assert True


# Generated at 2022-06-11 20:27:27.203082
# Unit test for function load
def test_load():
    context = load('/home/zachary/PycharmProjects/python/cookiecutter-master/cookiecutter/replay','cookiecutter.json')
    # print(type(context))
    print(context)


# Generated at 2022-06-11 20:27:27.632147
# Unit test for function load
def test_load():
    assert load("", "")


# Generated at 2022-06-11 20:27:31.017743
# Unit test for function load
def test_load():
    replay_dir = os.path.join('my_dir')
    template_name = 'my_dir'
    context = {'cookiecutter': {'name': 'HelloWorld', 'version': '0.0.1'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name)['cookiecutter']['name'] == 'HelloWorld'



# Generated at 2022-06-11 20:27:39.878141
# Unit test for function dump
def test_dump():
    # 1. Create a dict with Cookiecutter key
    context = dict(
        cookiecutter=dict(
            full_name='Donald Trump',
            email='donald.trump@example.com',
            project_name='Make America Great Again',
        ))
    # 2. Create an empty replay directory
    replay_dir = os.path.join('.', 'replay')
    make_sure_path_exists(replay_dir)
    # 3. Save the dict to a file in the replay directory
    template_name = "test"
    dump(replay_dir, template_name, context)
    # 4. Read the file
    context = load(replay_dir, template_name)
    # 5. Check the content of the dict is correct

# Generated at 2022-06-11 20:27:55.219464
# Unit test for function load
def test_load():
    # Create a temp directory with a file.
    from cookiecutter.utils import work_in
    import tempfile
    tmpd = tempfile.mkdtemp()
    foo = {'foo': 'bar'}
    with work_in(tmpd):
        with open("foo.json", 'w') as f:
            json.dump(foo, f)
        result = load(".", "foo")
        assert result == foo
    # Cleanup
    import shutil
    shutil.rmtree(tmpd)



# Generated at 2022-06-11 20:28:00.390830
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/replay'
    template_name = 'pypackage'
    context = {
        'cookiecutter': {
            'author_name': 'Elmo',
            'email': 'elmo@sesamestreet.org',
            'full_name': 'Elmo',
            'project_name': 'elmosproject',
            'project_short_description': 'This is a short description',
            'release_date': '2014-01-01',
            'year': '2014'
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:28:03.475318
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/'
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-11 20:28:06.875782
# Unit test for function load
def test_load():
    """
    Tests for function load
    """
    replay_dir = os.path.join('tests', 'test-replay')
    template_name = 'test-repo'

    context = load(replay_dir, template_name)
    assert isinstance(context, dict), 'The return type should be a dict'
    assert 'cookiecutter' in context, 'Context is required to contain a cookiecutter key'



# Generated at 2022-06-11 20:28:13.753095
# Unit test for function load
def test_load():
    """Test function load"""
    test_context = {'cookiecutter': {'key1': 'value1', 'key2': 'value2'}}
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    dump(replay_dir, template_name, test_context)
    loaded_context = load(replay_dir, template_name)
    os.remove(get_file_name(replay_dir, template_name))
    assert test_context == loaded_context



# Generated at 2022-06-11 20:28:16.763706
# Unit test for function dump
def test_dump():
    dir_path = os.getcwd()
    replay_dir = os.path.join(dir_path, 'cookiecutter.replay')
    context = {'cookiecutter': {'name': 'test_dump', 'package_name': 'test_dump'}}
    dump(replay_dir, 'test_dump', context)


# Generated at 2022-06-11 20:28:20.323427
# Unit test for function load
def test_load():
    template_name = 'test'
    context = {'cookiecutter': 'test'}
    replay_dir = 'tests/replay'

    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert loaded_context == context

# Generated at 2022-06-11 20:28:22.932087
# Unit test for function load
def test_load():
    load('/Users/jiancui/Documents/Cookiecutter-Simp/', 'cookiecutter-simp.json')

# Generated at 2022-06-11 20:28:29.431977
# Unit test for function load
def test_load():
    # Set replay_dir to the os.getcwd value
    replay_dir = os.getcwd()
    # Set template_name to the string 'my-repo'
    template_name = 'my-repo'
    # Set expected to a hard coded dictionary value
    # {'cookiecutter': {'full_name': 'Your full name', 'email': 'Your email address', 'project_name': 'Your project'}}
    expected = {'cookiecutter': {'full_name': 'Your full name', 'email':'Your email address', 'project_name': 'Your project'}}
    # Set actual equal to load(replay_dir, template_name)
    actual = load(replay_dir, template_name)
    # Assert that expected and actual are the same
    assert actual == expected


# Generated at 2022-06-11 20:28:34.362872
# Unit test for function load
def test_load():
    replay_dir = 'c:\\tmp\\cookiecutter'
    template_name = 'abc.json'
    context = {'cookiecutter': {'abc': '123'}}
    dump(replay_dir, template_name, context)
    context2 = load(replay_dir, template_name)
    print(context2)


# Generated at 2022-06-11 20:29:05.748998
# Unit test for function load
def test_load():
    """test load function."""
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    template_name = 'gh:audreyr/cookiecutter-pypackage'

    # test of template name not of str type
    try:
        load(replay_dir, dict())
    except TypeError:
        pass
    else:
        raise AssertionError

    # test of context does not contain a cookiecutter key
    context = {'foo':'bar'}
    try:
        dump(replay_dir, template_name, context)
        load(replay_dir, template_name)
    except ValueError:
        pass
    else:
        raise AssertionError

    # test of sucessful loading

# Generated at 2022-06-11 20:29:09.521998
# Unit test for function load
def test_load():
    d = "/home/cai/cookiecutter-pypackage"
    n = "{{ cookiecutter.project_name }}"
    c = load(d,n)
    print(c)

# Generated at 2022-06-11 20:29:10.759692
# Unit test for function load
def test_load():
    assert load(replay_dir, template_name) == context



# Generated at 2022-06-11 20:29:19.748794
# Unit test for function load
def test_load():
    """Test unit for load function."""
    from cookiecutter import config
    temp_context = {
        'cookiecutter': {
            'replay_dir': config.DEFAULT_REPLAY_DIR,
            'no_input': True,
            'overwrite_if_exists': True
        }
    }


    # dump json test
    replay_dir = temp_context['cookiecutter']['replay_dir']
    template_name = 'test_template'
    dump(replay_dir, template_name, temp_context)

    # load test
    context = load(replay_dir, template_name)

    assert temp_context == context

    # clean up
    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-11 20:29:29.750521
# Unit test for function load
def test_load():
    replay_dir = './replays_dir'
    template_name = 'test'

# Generated at 2022-06-11 20:29:31.418626
# Unit test for function load
def test_load():
    context = load('/Users/jianlianggao/PycharmProjects/untitled1', 's')
    print(context)


# Generated at 2022-06-11 20:29:38.196056
# Unit test for function load
def test_load():
    [os.remove(f) for f in os.listdir('replay') if f != '.gitkeep']
    context = {'foo': 'bar', 'b': 'c'}
    dump('replay/', 'test', context)
    context2 = load('replay/', 'test')
    assert context == context2


# Generated at 2022-06-11 20:29:44.797953
# Unit test for function load
def test_load():
    import json
    from cookiecutter.utils import rmtree

    # Unit test for function load
    context = {'cookiecutter': {
        'full_name': 'Bernard Tyers',
        'email': 'bernardtyers@example.com',
        'github_username': 'bernardtyers',
        'project_name': 'pytest',
        'project_slug': 'pytest',
        'pypi_username': 'bernardtyers',
        'release_date': '2013-07-07',
        'use_pypi_deployment_with_travis': 'y'}}

    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'
    dump(replay_dir, template_name, context)
    context2

# Generated at 2022-06-11 20:29:48.607460
# Unit test for function load
def test_load():
    d = {}
    d['cookiecutter'] = {}
    d['cookiecutter']['project_name'] = 'Test Project'
    d['cookiecutter']['author_name'] = 'Tester McTestface'
    dump('tmp', 'testload', d)
    c = load('tmp', 'testload')
    assert(c == d)

# Generated at 2022-06-11 20:29:51.080689
# Unit test for function load
def test_load():
    context = load(os.getcwd(), 'test_template')
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:30:19.412836
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'repo_dir': '.',
            'full_name': 'Mayur Chavan',
            'email': 'mayur.chavan@mayur.com'
        }
    }

    replay_dir = 'tests/test_data/'
    template_name = 'test_dump'

    try:
        dump(replay_dir, template_name, context)
        assert True
    except Exception:
        assert False



# Generated at 2022-06-11 20:30:23.728897
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = '../data/replay/'
    template_name = 'mytemplate'
    context = load(replay_dir, template_name)

    assert isinstance(context, dict) is True
    assert 'cookiecutter' in context is True

    return


# Generated at 2022-06-11 20:30:28.971345
# Unit test for function load
def test_load():
    rd = '/Users/yusi/Dropbox/yusi/python/project/dir/cookiecutter/'
    json_file = 'replay-20181018-220254.json'
    c = load(rd,json_file)
    print(c)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:30:30.913318
# Unit test for function load
def test_load():
    replay_dir = './cookiecutter-examples/'
    template_name = 'pypackage'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:30:32.974386
# Unit test for function load
def test_load():
    assert 'cookiecutter' in load('/', 'https://github.com/daviddias/cookiecutter-zf2-project')

# Generated at 2022-06-11 20:30:37.327522
# Unit test for function load
def test_load():
    """Tests for function load."""
    import tempfile

    template_name='testtemplate'
    with tempfile.TemporaryDirectory() as replay_dir:
        context = load(replay_dir,template_name)
        assert context == {} 
        dump(replay_dir, template_name, context)
        context = load(replay_dir, template_name)
        assert context == {}


# Generated at 2022-06-11 20:30:42.479468
# Unit test for function load
def test_load():
    """Read json data from file."""
    if not isinstance(template_name, str):
        raise TypeError('Template name is required to be of type str')

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    return context

# Generated at 2022-06-11 20:30:49.341995
# Unit test for function dump
def test_dump():
    # create a folder 'test_dump'
    replay_dir = 'test_dump'
    make_sure_path_exists(replay_dir)
    # template_name is the json file name
    template_name = 'test'
    # create a dictionary context, which contains a 'cookiecutter' key
    context = {"cookiecutter":{}}
    # call dump function to save the context under a json file
    dump(replay_dir, template_name, context)
    # read the context using function load
    context = load(replay_dir, template_name)
    print('context: ', context)

# test the unit test
if __name__ == "__main__":
    test_dump()

# Generated at 2022-06-11 20:30:50.874495
# Unit test for function load
def test_load():
    assert load('/Users/tianyiz/Documents/GitHub/Cookiecutters/cookiecutter-example', 'cookiecutter-example')

# Generated at 2022-06-11 20:30:56.190858
# Unit test for function dump
def test_dump():
    """Test function dump."""
    import tempfile
    import os
    temp_directory = tempfile.mkdtemp()
    context = {'key': 'value'}
    template_name = 'test_template'
    dump(temp_directory, template_name, context)
    context_stored = load(temp_directory, template_name)
    assert context_stored['key'] == 'value'
    os.rmdir(temp_directory)


# Generated at 2022-06-11 20:31:51.560614
# Unit test for function load
def test_load():
    if __name__ == '__main__':
        load('', '')

# Generated at 2022-06-11 20:31:57.021356
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = 'tests/test_replay_dir'
    context = {'cookiecutter': {'first_name': 'Audrey', 'last_name': 'Roy'}}
    dump(replay_dir, template_name, context)
    if os.path.isfile('./tests/test_replay_dir/test.json'):
        return True
    else:
        return False


# Generated at 2022-06-11 20:32:02.903781
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'

    # Delete the replay file if it exists
    replay_file = get_file_name(replay_dir, 'cookiecutter-pypackage')
    if os.path.exists(replay_file):
        os.remove(replay_file)
