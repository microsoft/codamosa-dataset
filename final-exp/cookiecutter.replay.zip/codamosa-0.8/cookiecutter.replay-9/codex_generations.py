

# Generated at 2022-06-11 20:22:06.380490
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/test', 'test') == '/test/test.json'
    assert get_file_name('test', 'test') == 'test/test.json'
    assert get_file_name('test', 'test.json') == 'test/test.json'

# Generated at 2022-06-11 20:22:12.187418
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name function."""
    test_replay_dir = './test/replay'
    test_template_name = 'template_name'
    test_file_name = get_file_name(test_replay_dir, test_template_name)

    assert test_file_name == './test/replay/template_name.json'

if __name__ == "__main__":
    test_get_file_name()
    print("Everything passed")

# Generated at 2022-06-11 20:22:19.286980
# Unit test for function dump
def test_dump():
    from tempfile import mkdtemp
    from shutil import rmtree

    replay_dir = mkdtemp()
    try:
        template_name = 'template'
        context = {'foo': 'bar',
                   'cookiecutter': {'replay': True}
                   }
        dump(replay_dir, template_name, context)
        replay_file = get_file_name(replay_dir, template_name)
        os.stat(replay_file)
    finally:
        rmtree(replay_dir)

# Generated at 2022-06-11 20:22:21.704645
# Unit test for function load
def test_load():
    assert isinstance(load(os.path.expanduser('~/.cookiecutters'), 'pytest'), dict)


# Generated at 2022-06-11 20:22:28.324952
# Unit test for function dump
def test_dump():
    # Create a replay directory
    replay_dir = 'tests/files/fake-replay-dir'
    if not os.path.exists(replay_dir):
        os.makedirs(replay_dir)
    # Dump replay data
    template_name = 'fake-template'
    context = {'cookiecutter': {'foo': 'another fake string'}}
    dump(replay_dir, template_name, context)
    # Load replay data
    context_loaded = load(replay_dir, template_name)
    # Compare the loaded data with the dumped data
    assert context == context_loaded, ('The loaded replay data is not the same '
                                       'as the dumped data')
    # Delete all files in replay directory
    replay_file = get_file_name(replay_dir, template_name)


# Generated at 2022-06-11 20:22:36.209130
# Unit test for function dump
def test_dump():
    replay_dir = 'test_data'
    template_name = 'test_template'
    context = {'cookiecutter': {'replay_name': '{{cookiecutter.project_slug}}',
                                'replay_context':
                                    {'cookiecutter':
                                         {'project_slug': '123',
                                          'project_name' : 'test',
                                          'author_name' : 'LJY'}}
                                }
               }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:22:39.389366
# Unit test for function load
def test_load():
    replay_file = get_file_name("", "{% now 'utc', '%y-%m-%d.%H%M%S' %}_project")
    with open(replay_file, 'r') as infile:
        context = json.load(infile)
    return context

# Generated at 2022-06-11 20:22:44.808726
# Unit test for function dump
def test_dump():
    assert dump('/home/abhishek/PycharmProjects/cookiecutter_py/cookiecutter/replay', 'Cookie Cutter',
                {'cookiecutter': {'project_name': 'My Project',
                                  'package_name': 'my_package',
                                  'open_source_license': 'MIT license'}}) is None


# Generated at 2022-06-11 20:22:46.117990
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-11 20:22:54.799249
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'cookiecutter-pypackage'
    replay_dir = os.path.abspath(os.path.expanduser('~'))
    # test for a sucessful output
    try:
        filename = get_file_name(replay_dir, template_name)
        assert os.path.isfile(filename) is False
    except Exception as e:
        assert 1
    # test for an exception
    try:
        filename = get_file_name(replay_dir, 5)
        assert 1
    except TypeError as e:
        assert 0


# Generated at 2022-06-11 20:22:58.687591
# Unit test for function load
def test_load():
    context = load("replay_dir", "cookiecutter-pypackage")
    print(context.keys())


# Generated at 2022-06-11 20:23:07.658642
# Unit test for function load

# Generated at 2022-06-11 20:23:10.633099
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutter_replay')
    template_name = 'py_battle'
    load(replay_dir, template_name)

# Generated at 2022-06-11 20:23:20.321650
# Unit test for function dump
def test_dump():
    """Test if dump is working propely."""
    replay_dir = os.path.join(os.getcwd(), 'tests')
    cookiecutter_dict = {
        "full_name": "Your Name",
        "email": "your@email.com",
        "github_username": "your-github-username",
        "project_name": "awesome_project",
        "project_slug": "awesome_project",
        "pypi_username": "your-pypi-username",
        "repo_name": "awesome_project",
        "cookiecutter": {
            "replay_dir": replay_dir,
            "no_input": True
        }
    }
    template_name = 'cookiecutter-pypackage'

    # the test file is removed if it already exists

# Generated at 2022-06-11 20:23:22.532229
# Unit test for function load
def test_load():
    content = load('/home/travis/build/audreyr/cookiecutter/tests/test-replay/', 'nope')
    assert type(content) == dict

# Generated at 2022-06-11 20:23:27.851927
# Unit test for function load
def test_load():
  c = load(replay_dir='./', template_name='cookiecutter-pypackage')
  print(c)
  c = load(replay_dir='~/fake_dir/', template_name='cookiecutter-pypackage')

# Tests
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        if sys.argv[1] == "test":
            test_load()
    else:
      print("No argument given")

# Generated at 2022-06-11 20:23:29.910540
# Unit test for function load
def test_load():
    """Unit test that load function throws correct error messages."""
    with pytest.raises(TypeError):
        load('tests/test-replay', 2)

    with pytest.raises(ValueError):
        load('tests/test-replay', 'basic')

# Generated at 2022-06-11 20:23:33.115612
# Unit test for function load
def test_load():
    template_name = "top_level"
    replay_dir = "tests/files/replay"
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:23:38.448077
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join('tests', 'files', 'replies')
    template_name = 'good-pyproject'
    context = {'cookiecutter': {'name': 'project_name', 'template': 'project_template'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(os.path.join(replay_dir, template_name + '.json'))



# Generated at 2022-06-11 20:23:41.575601
# Unit test for function load
def test_load():
    assert load('tests/test-replay/', 'test-name')['cookiecutter'] == {'name': 'first-dummy-name'}



# Generated at 2022-06-11 20:23:47.145718
# Unit test for function load
def test_load():
    context = load("tests/test-output", "audreyt/cookiecutter-pypackage")
    assert 'cookiecutter' in context, "Context must contain cookiecutter key."


# Generated at 2022-06-11 20:23:50.191502
# Unit test for function load
def test_load():
    dump('/Users/huangzhang/Desktop/cookiecutter-django-master/cookiecutter-django-master/apolo/tests/test_replay/','test',{'cookiecutter':'123','a':'b'})
    context = load('/Users/huangzhang/Desktop/cookiecutter-django-master/cookiecutter-django-master/apolo/tests/test_replay/','test')
    print(context)

# Generated at 2022-06-11 20:23:52.945664
# Unit test for function load
def test_load():
    """Test the load function."""
    with pytest.raises(TypeError):
        load('tst_dir', None)



# Generated at 2022-06-11 20:23:56.545723
# Unit test for function load
def test_load():
    import os
    replay_dir = os.environ['REPLAY_DIR']
    template_name = os.environ['TEMPLATE_NAME']
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:24:03.606756
# Unit test for function load
def test_load():
    replay_dir = 'replay'
    template_name = 'test_template'
    context = {'cookiecutter': {'first_name': 'John',
                                    'last_name': 'Doe',
                                    'email': 'john@gmail.com',
                                    'github_username': 'johndoe'}

                }
    dump(replay_dir,template_name,context)
    context1 = load(replay_dir, template_name)
    print(context1)


# Generated at 2022-06-11 20:24:06.379077
# Unit test for function load
def test_load():
    import pprint
    
    pprint.pprint(load("E:\\replay","sdgdsfdf"))

# Generated at 2022-06-11 20:24:11.463144
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-pypackage'
    replay_dir = '{{cookiecutter.replay_dir}}'
    context = load(replay_dir, template_name)
    context.update({"name": "asd"})
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:24:15.473809
# Unit test for function load
def test_load():
    context = load("/home/vikram/Documents/cookiecutter/cookiecutter/tests", "test_hooks")
    print("This is the loaded context: \n", context)



# Generated at 2022-06-11 20:24:21.220657
# Unit test for function dump
def test_dump():
    # Given
    import tempfile
    replay_dir = tempfile.mkdtemp()
    template_name = 'test'
    context = {'cookiecutter': {'full_name': 'test'}}

    # When
    dump(replay_dir, template_name, context)

    # Then
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)

    # Cleanup
    os.remove(replay_file)
    os.rmdir(replay_dir)


# Generated at 2022-06-11 20:24:29.226807
# Unit test for function load
def test_load():
    replay_dir = "replay_dir"
    template_name = "template_name"
    
    # Need to create replay_dir first
    os.makedirs(replay_dir)

    # Write context as a test file
    context_str = "{\"name\" : \"testing\", \"cookiecutter\": {\"replay\": true}}" 
    test_file = get_file_name(replay_dir, template_name)
    with open(test_file, 'w') as outfile:
        outfile.write(context_str)

    # Read test file 
    context = load(replay_dir, template_name)
    if context['name'] == "testing" and context['cookiecutter']['replay']:
        print("Test passed!")
    else:
        print("Test failed!")



# Generated at 2022-06-11 20:24:43.341830
# Unit test for function dump
def test_dump():
    replay_dir = "tests/test_replay_dir"
    if not os.path.isdir(replay_dir):
        os.mkdir(replay_dir)

    template_name = "test_context"
    context = {}
    extra_context = {}
    extra_context["cookiecutter"] = {}

    dump(replay_dir, template_name, context)

    file_name = get_file_name(replay_dir, template_name)
    with open(file_name, 'r') as infile:
        assert infile.read() == json.dumps(context)

    os.remove(file_name)
    os.rmdir(replay_dir)


# Generated at 2022-06-11 20:24:47.092039
# Unit test for function dump
def test_dump():
    replay_dir = '/home/shweta/Desktop/cookiecutter/tests/test-replay'
    template_name = 'test-replay'
    dump(replay_dir, template_name, {})
    assert os.path.isfile(get_file_name(replay_dir, template_name))


# Generated at 2022-06-11 20:24:52.979310
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = '~/cookiecutter-replay'
    template_name = 'foobar'

    # raise exception
    try:
        load('', template_name)
        assert False
    except TypeError:
        assert True

    try:
        load(replay_dir, 123)
        assert False
    except TypeError:
        assert True

    # pass
    context = load(replay_dir, template_name)
    context.update({'foo': 'bar'})
    context.update({'buz': 'qux'})
    assert True

# Generated at 2022-06-11 20:25:01.007466
# Unit test for function dump
def test_dump():
    from cookiecutter.main import cookiecutter
    template_name = cookiecutter(
        'tests/test-repo-pre/',
        no_input=True,
        replay_dir='/tmp/cookiecutter-replay/'
    )

    with open(get_file_name('/tmp/cookiecutter-replay/', template_name)) as infile:
        replay_data = json.load(infile)

        assert replay_data['cookiecutter']['full_name'] == 'Audrey Roy'
        assert replay_data['cookiecutter']['email'] == 'audreyr@gmail.com'

# Generated at 2022-06-11 20:25:03.205739
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load(replay_dir="replay", template_name="example")
    assert context['cookiecutter']['full_name'] == 'Test name'



# Generated at 2022-06-11 20:25:08.278545
# Unit test for function load
def test_load():
    replay_dir = 'D:/CC'
    templates_dir = 'D:'
    template_name = './python_module'

    json_file = 'D:/CC/test.json'
    # Dump test
    '''
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['module_name'] = 'sample2'
    dump(replay_dir, template_name, context)
    '''
    # Load test
    context = load(replay_dir, template_name)
    print(context)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:25:13.543848
# Unit test for function load
def test_load():
    replay_dir = "E:/OneDrive/Study/Git/PythonPlayground/cookiecutter/cookiecutter/tests/test-replay"
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)


test_load()

# Generated at 2022-06-11 20:25:18.386464
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = "./"
    template_name = "./"
    context = {'name': 'Hello world!'}
    try:
        dump(replay_dir, template_name, context)
    except Exception as e:
        print(e)


# Generated at 2022-06-11 20:25:29.561659
# Unit test for function load
def test_load():
    """test load func."""

# Generated at 2022-06-11 20:25:31.807148
# Unit test for function load
def test_load():
    """Unit test for function load()."""
    json_data = load('/home/azty/.cookiecutters/', 'noproject')
    assert True


# Generated at 2022-06-11 20:25:43.852364
# Unit test for function dump
def test_dump():
    assert True == True


# Generated at 2022-06-11 20:25:54.442534
# Unit test for function dump
def test_dump():
    replay_dir = os.path.abspath('test_dir')
    context = {'cookiecutter': {'author_name': 'Ricky'}}
    template_name = 'test_template'
    replay_file = get_file_name(replay_dir, template_name)
    dump(replay_dir, template_name, context)

    # verify the file is created
    assert(os.path.isfile(replay_file))

    # verify the content is equal to expected
    with open(replay_file, 'r') as infile:
        data = json.load(infile)
        assert(data == context)

    # clean up
    os.remove(replay_file)


# Generated at 2022-06-11 20:26:04.721089
# Unit test for function load
def test_load():
    """Unit test for function load"""
    import tempfile
    directory = tempfile.mkdtemp()

# Generated at 2022-06-11 20:26:05.443072
# Unit test for function load
def test_load():
    assert True

# Generated at 2022-06-11 20:26:14.738522
# Unit test for function load
def test_load():
    # Create a temporary directory and add fake replay json file
    import tempfile
    from contextlib import contextmanager

    @contextmanager
    def temporary_directory():
        directory = tempfile.mkdtemp()
        try:
            yield directory
        finally:
            pass

    with temporary_directory() as temp_dir:
        template_name = 'fake_template'
        json_content = {'cookiecutter': ['fake_value', ]}
        json_file = get_file_name(temp_dir, template_name)
        with open(json_file, 'w') as outfile:
            json.dump(json_content, outfile, indent=2)
        # Load file
        context = load(temp_dir, template_name)
        assert context['cookiecutter'] == ['fake_value', ]
        # Try to load

# Generated at 2022-06-11 20:26:21.476725
# Unit test for function load
def test_load():
    """Unit test for function load."""
    load_exception = False
    ctx = {}
    try:
        ctx = load('/home/lijiang/tmp', 'test_template')
    except IOError as e:
        load_exception = True
        print ('Failed to load data from json file')

    if load_exception == False:
        print ('Load data from json file {}'.format(ctx))


# Generated at 2022-06-11 20:26:24.740691
# Unit test for function load
def test_load():
    load('/Users/i.kantor/PycharmProjects/cookiecutter/cookiecutter_project/cookiecutter-pypackage/tests/fixtures/test-checkout-subdir',
         'tests/fixtures/test-checkout-subdir/{{cookiecutter.repo_name}}')

# Generated at 2022-06-11 20:26:35.414490
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'cookiecutter-pypackage'
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    replay_file = get_file_name(replay_dir, template_name)

    if os.path.isfile(replay_file):
        os.remove(replay_file)


# Generated at 2022-06-11 20:26:44.683325
# Unit test for function load
def test_load():
    # Test if the function can pass the type test.
    with open('replay_temp.json', 'w') as infile:
        json.dump({}, infile)
    load('replay_temp.json')
    # Test if the function can pass the wrong type input
    with open('replay_temp.json', 'w') as infile:
        json.dump({"key": "value"}, infile)
    try:
        load('replay_temp.json')
    except TypeError:
        pass
    else:
        print("Should raise an error.")
    # Test if the function can pass the wrong type input
    with open('replay_temp.json', 'w') as infile:
        json.dump({}, infile)

# Generated at 2022-06-11 20:26:50.329627
# Unit test for function load
def test_load():
    temp = load("/Users/karthikmaddukuri/Desktop/Automation/", "cookiecutter.json")
    assert temp == {'cookiecutter': {'project_name': 'Cookiecutter Project', 'author_name': 'Karthik Maddukuri', 'email': 'karthikmaddukuri@gmail.com', 'github_username': 'kmadd1', 'description': 'What this is'}}
    return True


# Generated at 2022-06-11 20:27:17.146699
# Unit test for function load
def test_load():
    template_dir = os.path.dirname(os.path.realpath(__file__))
    replay_dir = os.path.join(template_dir, '../replay')
    template_name = 'default'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:27:21.838232
# Unit test for function load
def test_load():
    replay_dir = "../tests/test-load-replay/"
    template_name = "test_load"
    context = load(replay_dir, template_name)
    assert context["cookiecutter"]["author_name"] == "Test-load-unit-test"

# Generated at 2022-06-11 20:27:29.875303
# Unit test for function load
def test_load():
    json_name=".cookiecutterrc"
    json_data={}
    json_data["cookiecutter"]={}
    json_data["cookiecutter"]["full_name"]="test_user"
    json_data["cookiecutter"]["email"]="test@user.com"
    with open(json_name,'w') as jsonfile:
        json.dump(json_data,jsonfile)
    result = load("",json_name)
    os.remove(json_name)
    if "cookiecutter" not in result or "full_name" not in result["cookiecutter"] or "email" not in result["cookiecutter"]:
        assert False


# Generated at 2022-06-11 20:27:39.360951
# Unit test for function dump

# Generated at 2022-06-11 20:27:41.936932
# Unit test for function load
def test_load():
    context = load('replay', 'chalmers_test')
    # Check if cookiecutter key exists in context
    assert 'cookiecutter' in context

# Generated at 2022-06-11 20:27:43.690999
# Unit test for function load
def test_load():
    context = load('./', 'sample_replay')
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:27:46.461661
# Unit test for function load
def test_load():
    replay_dir = "/Users/catherine/Desktop/cookiecutter-data-science/tests/test-load"
    template_name = "molly-test.json"
    load(replay_dir, template_name)


# Generated at 2022-06-11 20:27:49.338163
# Unit test for function load
def test_load():
    context = load('../', 'tests')
    assert context['cookiecutter']
    assert context['cookiecutter']['year'] == 2017



# Generated at 2022-06-11 20:27:55.045074
# Unit test for function dump
def test_dump():
    replay_dir = 'replay'
    make_sure_path_exists(replay_dir)

    context = {
        'cookiecutter': {
            'project_name': 'Hello World',
            'project_slug': 'hello-world',
            'author_name': 'Sophia',
            'email': 'sophia@example.com',
            'description': 'Some description'
        }
    }

    dump(replay_dir, 'DumpTest', context)

    assert os.path.exists(os.path.join(replay_dir, 'DumpTest.json'))



# Generated at 2022-06-11 20:27:56.317365
# Unit test for function load
def test_load():
    assert load(replay_dir, template_name)


# Generated at 2022-06-11 20:28:46.802585
# Unit test for function load
def test_load():
    from pathlib import Path
    import shutil
    from os.path import join
    from tempfile import TemporaryDirectory


# Generated at 2022-06-11 20:28:50.985832
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'
    template_name = 'test-template'
    context = {'cookiecutter': {'test-key': 'test-value',
                                'test-key-two': 'test-value-two'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:28:58.443729
# Unit test for function dump
def test_dump():
    template_name = 'sample'
    replay_dir = 'sample'


# Generated at 2022-06-11 20:29:06.281718
# Unit test for function load
def test_load():
    """Unit test for load."""
    import contextlib
    import tempfile
    json_string = '''
    {
      "replay": {
        "cookiecutter": {
          "name": "choco",
          "version": "1.0.0"
        }
      }
    }
    '''
    with tempfile.TemporaryDirectory() as replay_dir:
        replay_file = get_file_name(replay_dir, 'replay')
        with contextlib.closing(open(replay_file, 'w')) as outfile:
            outfile.write(json_string)
        context = load(replay_dir, 'replay')
        assert context == {'replay': {'cookiecutter': {'name': 'choco', 'version': '1.0.0'}}}

# Generated at 2022-06-11 20:29:12.760192
# Unit test for function load
def test_load():
    replay_dir = './tests'
    template_name = 'template_1'
    json_dic = {}
    context_dic = {}

    context_dic['cookiecutter'] = {}
    json_dic['cookiecutter'] = {}

    dump(replay_dir, template_name, json_dic)
    context_l = load(replay_dir, template_name)
    assert context_l == context_dic

# Generated at 2022-06-11 20:29:16.078652
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load(replay_dir='/Users/eok/Downloads/cookiecutter-pypackage-minimal-master/tests/test-data/test_json', template_name='test_json.json')
    print(context)

test_load()

# Generated at 2022-06-11 20:29:22.459206
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.join(os.path.abspath('.'),'cookiecutter_template')
    # replay_dir = os.path.join(os.path.abspath('.'),'cookiecutter_template','{{cookiecutter.template_name}}')
    replay_file = "{{cookiecutter.template_name}}.json"
    template_name = "{{cookiecutter.template_name}}"
    context = load(replay_dir,template_name)
    print(context)

# Generated at 2022-06-11 20:29:30.300224
# Unit test for function load
def test_load():
    # Test that invalid template name throws error
    template_name = 1
    replay_dir = 'foo/bar'
    try:
        load(replay_dir, template_name)
    except TypeError:
        pass
    else:
        assert False

    template_name = 'foo.json'
    replay_dir = 'bar'

    # Test that context is of type dict
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)

    # Test that cookiecutter exists in context
    assert 'cookiecutter' in context


# Generated at 2022-06-11 20:29:39.382047
# Unit test for function load
def test_load():
    import json
    import os
    import tempfile

    tdir = tempfile.mkdtemp()

    replay_file = os.path.join(tdir, 'replay.json')

    test_context = {
        'cookiecutter': {
            'somekey': 'somevalue',
            'anotherkey': 'anothervalue'
        }
    }

    with open(replay_file, 'w') as outfile:
        json.dump(test_context, outfile, indent=2)

    result = load(tdir, 'replay')

    assert result == test_context

# Generated at 2022-06-11 20:29:41.229864
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = 'example_template'
    context = load(replay_dir, template_name)
    print(json.dumps(context, indent=4))



# Generated at 2022-06-11 20:31:29.416682
# Unit test for function load
def test_load():
    file_name = "abcd"
    req_key = "cookiecutter"
    req_val = "test"
    template_name = "defg"
    dict1 = dict({req_key:req_val})
    dump(file_name, template_name, dict1)

    dict2 = load(file_name, template_name)
    print(dict2)

    assert req_val == dict2[req_key]
    


# Generated at 2022-06-11 20:31:34.514670
# Unit test for function load
def test_load():
    from shutil import rmtree
    from tempfile import mkdtemp
    from pprint import pprint

    context = {'cookiecutter': {'test_key': 'test_value'}}
    template_name = 'test'

    replay_dir = mkdtemp()
    try:
        replay_file = get_file_name(replay_dir, template_name)
        dump(replay_dir, template_name, context)
        assert os.path.isfile(replay_file)

        loaded = load(replay_dir, template_name)
        assert loaded == context
    finally:
        rmtree(replay_dir)

# Generated at 2022-06-11 20:31:43.656697
# Unit test for function load
def test_load():
    # Create a replay file
    replay_file = get_file_name("/home/ec2-user/environment/git/cookiecutter-testing/cookiecutter-3/replay/", "test")
    with open(replay_file, 'w') as outfile:
        json.dump({"cookiecutter":{"full_name":"","github_username":"","email":"","project_name":""},"_template":{"full_name":"","github_username":"","email":"","project_name":""},"test":"test"}, outfile, indent=2)

    # Try to load from a replay file that does not exist
    # Should throw ValueError

# Generated at 2022-06-11 20:31:52.819330
# Unit test for function dump
def test_dump():
    from cookiecutter.exceptions import FailedHookException
    from cookiecutter.main import cookiecutter
    import tempfile
    import shutil
    import sys

    template_path = os.path.join(os.path.dirname(__file__), "../tests/test-hooks")
    replay_path = tempfile.mkdtemp()
    render_path = tempfile.mkdtemp()
    shutil.copytree(template_path, os.path.join(replay_path, '.'))
    shutil.copytree(template_path, os.path.join(render_path, '.'))

    # Check that failed hooks make don't continue
    sys.argv = [sys.argv[0], render_path, '--no-input', '--replay-dir', replay_path]

# Generated at 2022-06-11 20:31:59.620785
# Unit test for function dump
def test_dump():
    replay_dir = os.path.abspath(os.path.join(os.path.dirname(
        os.path.abspath(__file__)), 'tests'))
    template_name = 'amirhossein111333'
    context = {
        'amir': 'hossein',
        'cookiecutter': {}
    }
    dump(replay_dir, template_name, context)
    with open(os.path.join(replay_dir, template_name + '.json'), 'r') as infile:
        assert json.load(infile) == context



# Generated at 2022-06-11 20:32:06.007536
# Unit test for function load
def test_load():
    assert load("tests/test-replay/replay_dir", "test-template") == {"cookiecutter": {
        "_copy_without_render": ["README.md"],
        "_template": "test-template",
        "full_name": "Test User",
        "email": "test_user@example.com",
        "project_name": "Test Project"
    }}
