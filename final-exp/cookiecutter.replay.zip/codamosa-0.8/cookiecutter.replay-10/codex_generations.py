

# Generated at 2022-06-11 20:22:15.113110
# Unit test for function dump
def test_dump():
    from cookiecutter.read_user_config import get_replay_dir
    import shutil
    replay_dir = get_replay_dir()
    template_name = '_test_test_test'
    context = {'cookiecutter': {'_test_test_test': 'test_test_test'}}
    try:
        dump(replay_dir, template_name, context)
        context_result = load(replay_dir, template_name)
    finally:
        replay_file = get_file_name(replay_dir, template_name)
        os.remove(replay_file)
    assert context == context_result

if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-11 20:22:22.340173
# Unit test for function dump
def test_dump():
    replay_file = "testdump.json" # The file to be recorded
    context = {}
    context['cookiecutter'] = {} # append the context
    context['cookiecutter']['username'] = 'Anonymouse' # append the context
    dump(replay_file, "knk", context) # call dump function
    context1 = {}
    context1 = load(replay_file, "knk") # load the context from the file
    print(context1)
    assert context1 == context
    os.remove('testdump.json')

# Generated at 2022-06-11 20:22:25.586040
# Unit test for function dump
def test_dump():
    # The following code would generate an IOError
    dump('/', 'test_replay', {})


# Generated at 2022-06-11 20:22:28.237223
# Unit test for function load
def test_load():
    replay_dir = "tests/files/replay_dir"
    template_name = "template1"
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-11 20:22:38.069573
# Unit test for function dump
def test_dump():
    from cookiecutter.generate import generate_context
    from cookiecutter.main import cookiecutter
    msg = 'Unable to create replay dir at {}'.format("/tmp")
    try:
        context = generate_context("/Users/hanhanwu/Github/Cookiecutter-Data-Science", {"full_name": "Hanhan Wu"})
        cookiecutter("/Users/hanhanwu/Github/Cookiecutter-Data-Science", no_input=True, replay=True, replay_dir="/tmp", extra_context=context)
    except ValueError as e:
        assert msg in str(e)
        assert repr(e) == repr(ValueError(msg))
    except AssertionError as e:
        raise e


# Generated at 2022-06-11 20:22:39.716439
# Unit test for function dump
def test_dump():
    assert os.path.isfile('cookiecutter.json') == True


# Generated at 2022-06-11 20:22:45.562412
# Unit test for function load
def test_load():
    template_name = '{{cookiecutter.repo_name}}'
    context = {'cookiecutter': {'repo_name': 'my_repo'}}
    replay_file = get_file_name('/tmp', template_name)
    try:
        dump('/tmp', template_name, context)
        # assert load without exception
        load('/tmp', template_name)
    finally:
        os.remove(replay_file)

# Generated at 2022-06-11 20:22:56.210085
# Unit test for function dump
def test_dump():
    replay_dir = './cookiecutter.replay'
    template_name = 'test_template'
    context = {
        'cookiecutter': {
            'full_name': 'James Bowen',
            'email': 'jamesbowen@example.com',
            'project_name': 'hello world',
            'project_slug': 'helloworld',
            'pypi_username': 'j4mesbowen'
        }
    }
    dump(replay_dir, template_name, context)
    new_context = load(replay_dir, template_name)
    assert context == new_context
    os.remove(get_file_name(replay_dir, template_name))
    os.rmdir(replay_dir)

# Generated at 2022-06-11 20:23:06.295587
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('', 'my-template') == 'my-template.json'
    assert get_file_name('', 'my-template.json') == 'my-template.json'
    assert get_file_name('', '~/my-template') == '~/my-template.json'
    assert get_file_name('', 'C:\my-template') == 'C:\my-template.json'
    assert get_file_name('/tmp', 'my-template') == '/tmp/my-template.json'
    assert get_file_name('/tmp', 'my-template.json') == '/tmp/my-template.json'
    assert get_file_name('/tmp', '~/my-template') == '/tmp/~/my-template.json'

# Generated at 2022-06-11 20:23:09.920293
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replay_dir'
    for name in [
            'full_name.json',
            'full.name',
            'full.name.json',
            'fu.l.l.na.me',
            'fu.l.l.na.me.json',
            'full_name',
            'full.name.',
            'full.name..json',
            'fu.l.l.na.me.json.',
    ]:
        assert os.path.join(replay_dir, name + '.json') == get_file_name(replay_dir, name)

# Generated at 2022-06-11 20:23:17.140618
# Unit test for function load
def test_load():
    f = os.path.join('/Users/sanketbhatt/sanketbhatt/cookiecutter-india', 'tests', 'test_replay', 'basic.json')
    context = load('/Users/sanketbhatt/sanketbhatt/cookiecutter-india/tests/test_replay/', 'basic')
    assert(context['cookiecutter']['project_slug'] == 'cookiecutter-india')

# Generated at 2022-06-11 20:23:24.676710
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter import replay
    from cookiecutter.main import cookiecutter
    import os

    template_name = "user/python-package"
    replay_dir = os.path.join(os.getcwd(), "test_files", "replay")

    context = replay.load(replay_dir, template_name)
    cookiecutter(
        template=template_name,
        extra_context=context['cookiecutter'],
        no_input=True,
        replay=True
    )


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-11 20:23:32.494320
# Unit test for function dump
def test_dump():
    template_name = "Test"
    replay_dir = os.path.dirname(os.path.abspath(__file__))
    replay_file = get_file_name(replay_dir, template_name)
    context = {
        "cookiecutter": {
            "full_name": "Test",
            "email": "test@test.com",
            "github_username": "Test"
        }
    }

    try:
        dump(replay_dir, template_name, context)
        assert os.path.exists(replay_file), "replay file does not exist"
    finally:
        try:
            os.remove(replay_file)
        except OSError:
            pass


# Generated at 2022-06-11 20:23:37.361792
# Unit test for function dump
def test_dump():
    cookie_dir = os.path.dirname(__file__)
    replay_dir = os.path.join(cookie_dir, 'tests/test-replay')
    template_name = 'template-name'
    context = {'cookiecutter': {'repo_dir': '.'}}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-11 20:23:38.986906
# Unit test for function load
def test_load():
    context = load('test_replay', 'test_replay/my_template')
    assert(context)


# Generated at 2022-06-11 20:23:41.313078
# Unit test for function load
def test_load():
    print(load('/home/dave/.cookiecutters', 'cookiecutter-pypackage')) 


# Generated at 2022-06-11 20:23:44.255314
# Unit test for function load
def test_load():
    assert (isinstance(load('/Users/fenglu/Documents/Cookiecutter_project/cookiecutter/tests/test_dir', 'cookiecutter.json'), dict))


# Generated at 2022-06-11 20:23:46.135822
# Unit test for function load
def test_load():
    """Test the load function."""
    print(load(replay_dir, template_name))


# Generated at 2022-06-11 20:23:49.308796
# Unit test for function load
def test_load():
    with open('test/test_load.json', 'r') as infile:
        context = json.load(infile)
        result = load('./test', 'test_load')
        assert result == context


# Generated at 2022-06-11 20:23:52.945765
# Unit test for function load
def test_load():
    assert load('./cookiecutter-pypackage2', 'cookiecutter-pypackage2') != None
    assert load('./cookiecutter-pypackage2', 'cookiecutter-pypackage') == None



# Generated at 2022-06-11 20:23:58.409512
# Unit test for function dump
def test_dump():
    replay_dir = 'replay-dir'
    template_name = 'template-name'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'aroy@example.com'
        }
    }

    dump(replay_dir, template_name, context)
    data = load(replay_dir, template_name)

    assert data == context

# Generated at 2022-06-11 20:24:03.903577
# Unit test for function load
def test_load():
    replay_dir = "/Users/zhexu/Desktop/cookiecutter-boilerplate/tests/files"
    template_name = "test_cookiecutter_json"
    context = load(replay_dir, template_name)
    print(context)


if __name__ == "__main__":
    test_load()

# Generated at 2022-06-11 20:24:07.176379
# Unit test for function load
def test_load():
    replay_dir = "/Users/filipebrito/Temp/cookiecutter-test/"
    template_name = "cc_filipebrito.template"
    load(replay_dir, template_name)

# Generated at 2022-06-11 20:24:17.565981
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.abspath(get_replay_dir())
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)
    ## {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com',
    ##                   'project_name': 'Cookiecutter Pypackage',
    ##                   'version': '0.1.0', 'package_name': 'cookiecutter_pypackage',
    ##                   'repo_name': 'cookiecutter-pypackage', 'year': '2014'}}


# Generated at 2022-06-11 20:24:18.779089
# Unit test for function load
def test_load():
    print(load('D:\Cookiecutter\Log', 'log_base.json'))

# Generated at 2022-06-11 20:24:25.494219
# Unit test for function load
def test_load():
    template_name = 'test'
    context = {'cookiecutter': {'project_name': 'test'}}
    replay_dir = 'test/replay'
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.rename(replay_dir, 'test/replay_bak')

# Generated at 2022-06-11 20:24:32.229662
# Unit test for function load
def test_load():
    """Unit test function load."""
    import json
    import os
    replay_dir = '~/.cookiecutters'
    template_name = 'cookiecutter-pypackage'
    replay_file = '~/.cookiecutters/cookiecutter-pypackage.json'
    file = os.path.expanduser(replay_file)
    with open(file, 'r') as infile:
        context = json.load(infile)
    assert context == load(replay_dir, template_name)

# Generated at 2022-06-11 20:24:42.265129
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import cookiecutter
    import numpy as np
    from cookiecutter.main import cookiecutter

    # Test cookiecutter.replay.load
    replay_dir = os.path.join(cookiecutter._replay_dir, 'tests')
    template_name = 'cookiecutter-pypackage'
    context = cookiecutter.replay.load(replay_dir, template_name)
    assert context['cookiecutter']['project_slug'] == 'cookiecutter-pypackage'
    assert context['full_name'] == 'Audrey Roy Greenfeld'
    assert np.allclose(context['open_source_license'], 'MIT license')
    assert np.allclose(context['email'], 'audreyr@example.com')
    assert np

# Generated at 2022-06-11 20:24:45.978177
# Unit test for function load
def test_load():
    """Test load()."""
    # Test for TypeError for template_name
    assert load('repo_dir', 1) == TypeError

    # Test for ValueError for context
    assert load('repo_dir', 'template_name') == ValueError

    assert load('repo_dir', 'template_name') == ''

# Generated at 2022-06-11 20:24:53.910465
# Unit test for function load
def test_load():
    replay_dir = 'cookiecutter/tests/test-output/replay'
    template_name = 'basic_project'

    context = load(replay_dir, template_name)
    assert context['cookiecutter']['author_name'] == 'Your Name Here'
    assert context['cookiecutter']['open_source_license'] == 'BSD License'
    assert context['cookiecutter']['project_slug'] == 'basicproject'
    assert context['cookiecutter']['project_name'] == 'Basic Project'
    assert context['cookiecutter']['project_short_description'] == '"Basic Project"'
    assert context['cookiecutter']['version'] == '0.1.0'
    assert context['cookiecutter']['year'] == '2014'


# Generated at 2022-06-11 20:25:01.262683
# Unit test for function load
def test_load():
    temp_dir = "./tests/"
    template_name = "./tests/python-cli-package"
    correct_result = {'_template': './tests/python-cli-package', 'cookiecutter': {}, 'replay_dir': 'tests/replay'}
    result = load(temp_dir, template_name)
    assert result == correct_result



# Generated at 2022-06-11 20:25:06.081705
# Unit test for function dump
def test_dump():
    """unit test for function dump"""
    replay_dir = os.path.join(os.path.abspath('.'), 'fake_replay_dir')
    template_name = 'fake_template'
    context = {'cookiecutter': {'name': 'fake_name', 'version': 'fake_version'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, 'fake_template.json')) is True


# Generated at 2022-06-11 20:25:10.055237
# Unit test for function load
def test_load():
    """Test load."""
    template_name = "test"
    sub_dir = "replay_test"
    replay_dir = os.path.join(os.getcwd(), sub_dir)
    context = {
        "cookiecutter": {
            "email": "test@test.com"
        }
    }

    assert not os.path.exists(replay_dir)
    dump(replay_dir, template_name, context)

    result = load(replay_dir, template_name)

    assert result == context
    assert os.path.exists(replay_dir)

# Generated at 2022-06-11 20:25:13.797012
# Unit test for function load
def test_load():
    replay_dir = "cookiecutter.tests/tests/replay"
    template_name = "cookiecutter_jquery"
    context = load(replay_dir, template_name)


# Generated at 2022-06-11 20:25:21.064534
# Unit test for function dump
def test_dump():
    """."""
    replay_dir = '/home/yue/Desktop/cookiecutter-/'
    template_name = 'cookiecutter-pypackage-TEST'
    try:
        dump(replay_dir, template_name, {'cookiecutter':'test'})
    except IOError:
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))
    except TypeError:
        raise TypeError('Template name is required to be of type str')
    except ValueError:
        raise ValueError('Context is required to contain a cookiecutter key')
 

# Generated at 2022-06-11 20:25:26.407327
# Unit test for function load
def test_load():
    assert load('/tmp', 'adamj') == {'cookiecutter': {'full_name': 'Adam Johnson',\
            'email': 'me@adamj.eu',\
            'project_name': 'my-repo',\
            'repo_name': 'my-repo',\
            'year': '2017'}}

# Generated at 2022-06-11 20:25:33.741420
# Unit test for function load
def test_load():
    """Unit test for function load"""
    context = load(os.path.join(os.path.dirname(__file__), '../fake-repo-pre/'), 'fake-repo-pre')
    assert context is not None
    assert 'cookiecutter' in context
    assert context['cookiecutter'] is not None
    assert 'repo_name' in context['cookiecutter']
    assert context['cookiecutter']['repo_name'] == '{%- if cookiecutter.project_name == "Example" -%}Better Example{%- else -%}{{ cookiecutter.project_name }}{%- endif -%}'


# Generated at 2022-06-11 20:25:36.738788
# Unit test for function load
def test_load():
    """Test function load."""
    replay_dir = 'tests/test-load/'
    template_name = 'github/audreyr/cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy'



# Generated at 2022-06-11 20:25:43.236910
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter.main import cookiecutter
    test_dir = 'tests/test-load'
    test_repo = 'tests/fake-repo-pre/'

    context = cookiecutter(test_repo, no_input=True, replay=True, overwrite_if_exists=True)
    template_name = context.get('cookiecutter').get('repo_dir')
    replay_dir = os.path.join(test_dir, '.cookiecutters_replay')
    load(replay_dir, template_name)

# Generated at 2022-06-11 20:25:47.170032
# Unit test for function dump
def test_dump():
    replay_dir = 'my-replay-dir'
    template_name = 'my-template-name'
    context = {'key1': 'value1'}

    dump(replay_dir, template_name, context)


# Generated at 2022-06-11 20:25:55.230920
# Unit test for function load
def test_load():
    context = load('C:\\Users\\User\\Desktop\\Cookiecutter\\cookiecutter-pypackage//cookiecutter-replay', 'test')
    assert 'test' in context
    assert 'test' in context['cookiecutter']

# Generated at 2022-06-11 20:25:59.611581
# Unit test for function load
def test_load():
    if __name__ == '__main__':
        replay_dir = os.path.expanduser('~/.cookiecutters')
        template_name = 'cookiecutter-pypackage'
        context = load(replay_dir, template_name)
        print('context=',context)
    

# Generated at 2022-06-11 20:26:04.195835
# Unit test for function dump
def test_dump():
    replay_dir = './tests/fake-repo'
    template_name = 'fake-repo'
    context = {'cookiecutter': {'full_name': 'Vu Diep'}}
    dump(replay_dir, template_name, context)
    # Verify the context is stored in replay file
    os.path.isfile('./tests/fake-repo/fake-repo.json')
    os.remove('./tests/fake-repo/fake-repo.json')
    

# Generated at 2022-06-11 20:26:06.509301
# Unit test for function load
def test_load():
    print("Testing load()...")
    context = load('./tests/fake-repo-pre', 'fake-repo-pre')
    print(context)

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-11 20:26:15.253023
# Unit test for function dump
def test_dump():
    replay_dir = 'E:/projects/python/cookiecutter-master/cookiecutter-master/tests/test-data/replay'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-11 20:26:24.514888
# Unit test for function dump
def test_dump():
    """Test for function dump"""
    # change working directory to path containing test_dump.py
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    d = os.path.join(os.getcwd(), 'test')
    t = 'template'
    c = {}
    try:
        dump(d, t, c)
    except Exception as e:
        assert str(e) == 'Context is required to contain a cookiecutter key'
        print(str(e))

    c['cookiecutter'] = 'hello world'
    try:
        dump(d, 5, c)
    except Exception as e:
        assert str(e) == 'Template name is required to be of type str'
        print(str(e))

# Generated at 2022-06-11 20:26:35.244738
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.utils import rmtree
    import os
    import shutil
    import tempfile
    import logging
    import json

    logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    here = os.path.abspath(os.path.dirname(__file__))
    replay_dir = os.path.join(here, 'test_replay', 'not_existing')
    template = 'tests/test-repo-pre/'
    name = 'foobar'

    logger.debug('template=%s', template)

# Generated at 2022-06-11 20:26:43.970982
# Unit test for function dump
def test_dump():
    """Test replay dump function."""
    replay_dir = 'tests/files/fake-replay/'
    template_name = "django-cookie"
    context = {
        'cookiecutter': {
            'project_name': 'Django Cookie',
            'repo_name': 'django-cookie',
            'version': '0.0.1',
            'timezone': 'America/Los_Angeles',
        }
    }

    dump(replay_dir, template_name, context)

    with open(replay_dir + template_name + ".json", "r") as read_file:
        data = json.load(read_file)
        assert data == context


# Generated at 2022-06-11 20:26:47.462112
# Unit test for function load
def test_load():
    replay_file = 'C:\\Users\\tibor\\Documents\\GitHub\\cookiecutter-master\\cookiecutter\\tests\\test-replay\\test_replay_load.json'
    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    print(context['cookiecutter'])

# Generated at 2022-06-11 20:26:57.554976
# Unit test for function load
def test_load():
    """Unit test for function load."""
    import tempfile
    from shutil import rmtree
    from cookiecutter.utils import rmtree

    try:
        tmp_dir = tempfile.mkdtemp()

        my_dict = {
            'cookiecutter': {
                'full_name': 'Full Name',
                'email': 'noreply@example.com',
            }
        }

        dump(tmp_dir, 'mydict', my_dict)
        context = load(tmp_dir, 'mydict')

        assert context['cookiecutter']['full_name'] == 'Full Name'
        assert context['cookiecutter']['email'] == 'noreply@example.com'

    finally:
        rmtree(tmp_dir)

# Generated at 2022-06-11 20:27:15.209996
# Unit test for function load
def test_load():
    test_replay_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../cookiecutter/tests/test-replay-dir')

    template_context = load(test_replay_dir, 'pypackage')
    assert template_context['cookiecutter']['project_name'] == 'Test Project'

# Generated at 2022-06-11 20:27:22.673012
# Unit test for function load
def test_load():
    """Load a context from file."""
    context = load('tests/test-output', 'example_replay_file')
    assert 'cookiecutter' in context
    assert context == {
        'cookiecutter': {
            'full_name': 'Example Name',
            'email': 'example@example.com',
            'project_slug': 'example_project',
            'project_name': 'Example Project',
            'project_description': 'Description goes here',
            'version': '1.2.0'
        }
    }

# Unit tests for function dump

# Generated at 2022-06-11 20:27:27.166169
# Unit test for function load
def test_load():
    # basic test
    context = load('C:/Users/Xiaoyu/git/template', 'cookiecutter-pypackage')
    assert(context.get('cookiecutter').get('name') == 'cookiecutter-pypackage')

# Generated at 2022-06-11 20:27:31.606151
# Unit test for function load
def test_load():
    """Test function load."""
    replay_dir = 'tests/files'
    template_name = 'bakesale'
    context = load(replay_dir, template_name)
    assert isinstance(context['cookiecutter'], dict)
    assert isinstance(context['cookiecutter']['repo_dir'], str)
    assert context['cookiecutter']['repo_dir'] == 'bakesale'
    assert isinstance(context['cookiecutter']['output_dir'], str)
    assert context['cookiecutter']['output_dir'] == 'bakesale-repo'

# Generated at 2022-06-11 20:27:39.975140
# Unit test for function load
def test_load():
    """
    Unit test for function load().
    :return: True
    """
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'

    context = load(replay_dir, template_name)

# Generated at 2022-06-11 20:27:41.773285
# Unit test for function load
def test_load():
	load('../', 'cookiecutter.json')



# Generated at 2022-06-11 20:27:48.575664
# Unit test for function dump
def test_dump():
    # Create a test template and a fake record
    template_name = '_test_template'
    replay_dir = '.cookiecutters'
    context = {
        'cookiecutter': {
            '_copy_without_render': [
                '_cookiecutter_meta',
                '.pre-commit-config.yaml',
                '*.yaml',
                '*.yml'
            ],
            'repo_name': '{{ cookiecutter.project_slug }}',
            'project_name': 'TEST-NAME'
        }
    }

    # Test dump
    dump(replay_dir, template_name, context)

    # Test load
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-11 20:27:54.301012
# Unit test for function dump
def test_dump():
    """Test dump function."""
    template = {
        'cookiecutter': {}
    }

    replay_dir = '.cookiecutters'
    template_path = 'example'
    dump(replay_dir, template_path, template)

    # Check that the replay file exists
    play_file = get_file_name(replay_dir, template_path)
    assert os.path.exists(play_file)

    # Remove the replay file
    os.remove(play_file)
    assert not os.path.exists(play_file)



# Generated at 2022-06-11 20:27:55.009032
# Unit test for function dump
def test_dump():
    pass

# Generated at 2022-06-11 20:28:01.021759
# Unit test for function load
def test_load():
    """Test function load."""

    # Can't load template that doesn't exist
    try:
        load(replay_dir='./', template_name='nope')
        assert False
    except IOError:
        assert True

    # Can't load template that isn't a .json file
    try:
        load(replay_dir='./tests/test-replay/', template_name='test')
        assert False
    except IOError:
        assert True

    # Can load template that does exist
    try:
        load(replay_dir='./tests/test-replay/', template_name='test.json')
        assert True
    except:
        assert False

    # Can't load a replay file that's not JSON

# Generated at 2022-06-11 20:28:18.077618
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = "test_tamplate"
    replay_dir = "."
    context = {"cookiecutter": {"full_name": "Kamil Hismatullin", "project_name": "Hello", "project_type": "python_cmdline"}}
    # FUNCTION CALL
    dump(replay_dir, template_name, context)
    # load the context, we just dumped
    context_read = load(replay_dir, template_name)
    
    # TEST
    assert context == context_read
    # clear the testing dump
    os.remove(get_file_name(replay_dir, template_name))
test_load()


# Generated at 2022-06-11 20:28:23.311727
# Unit test for function dump
def test_dump():
    replay_dir = './tests/files/'
    template_name = 'replay_test'
    context = {'cookiecutter': {'key1': 'value1', 'key2': 2}}
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['key1'] == 'value1'


# Generated at 2022-06-11 20:28:29.679547
# Unit test for function load
def test_load():
    replay_dir = os.path.expanduser('~/.cookiecutter_replay/')
    template_name = 'cookiecutter-pypackage'
    result = load(replay_dir, template_name)

# Generated at 2022-06-11 20:28:34.110799
# Unit test for function load
def test_load():
    replay_dir = os.path.abspath(os.path.expanduser('~/.cookiecutter_replay'))
    template_name = 'cookiecutter-pypackage'
    result = load(replay_dir, template_name)
    print(result)


# Generated at 2022-06-11 20:28:43.779142
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter import replay
    from cookiecutter.exceptions import ReplayException
    from cookiecutter.main import cookiecutter
    from os import path
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()

    childdir = path.join(path.dirname(__file__), '../', 'child')
    shutil.copytree(childdir, path.join(tmpdir, 'child'))
    cookiecutter(tmpdir, extra_context={'foo': 'bar'}, replay=True)

    replay_dir = path.join(tmpdir, 'replay')
    # Note the use of two slashes in the path on Windows
    replay_file = path.join(replay_dir, 'child//.json')

# Generated at 2022-06-11 20:28:50.235954
# Unit test for function dump
def test_dump():
    replay_dir = 'testDir'
    template_name = 'testName'
    context = {'cookiecutter': {'name': 'testName'}}
    dump(replay_dir, template_name, context)
    assert(os.path.exists('testDir'))
    assert(os.path.isfile('testDir/testName.json'))
    os.remove('testDir/testName.json')
    os.rmdir('testDir')


# Generated at 2022-06-11 20:28:52.328356
# Unit test for function load
def test_load():
    print(load(os.path.join(os.path.dirname(__file__), 'user_dir'), 'cookiecutter-pypackage/cookiecutter.json'))


# Generated at 2022-06-11 20:28:55.131938
# Unit test for function load
def test_load():
    assert load('/home/citrus/test', '__test__') == {'cookiecutter': {'_template': 'test/test'}}

# unit test for function get_file_name

# Generated at 2022-06-11 20:29:00.179278
# Unit test for function load
def test_load():
    import os
    import shutil
    test_dir = os.path.join(os.getcwd(), 'tests/test-load')
    replay_dir = os.path.join(test_dir, 'replay')
    shutil.copytree(os.path.join(os.getcwd(), 'tests/fake-repo-pre'), test_dir)
    template_name = 'fake-repo-pre'
    context = load(replay_dir, template_name)
    assert 'project_name' in context.get('cookiecutter', {})
    assert context.get('cookiecutter').get('project_name') == 'Cookiecutter-pypackage'
    shutil.rmtree(test_dir)


# Generated at 2022-06-11 20:29:06.910318
# Unit test for function dump
def test_dump():
    """Unit test to check file is written"""

# Generated at 2022-06-11 20:29:32.759939
# Unit test for function load
def test_load():
    assert load(replay_dir="",template_name="")


# Generated at 2022-06-11 20:29:36.908838
# Unit test for function load
def test_load():
    #test case for load
    replay_dir = r'D:\Workspace\cookiecutter'
    template_name = 'cookiecutter-pypackage-min'
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-11 20:29:42.258178
# Unit test for function load
def test_load():
    """Unit test to test load."""
    replay_dir = r'C:\Users\anujv\Desktop\cookiecutter\replay'
    template_name = 'test_replay'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context, 'Expected a key "cookiecutter"'
    assert context['cookiecutter']['_template'], 'Expected a key "_template"'


# Generated at 2022-06-11 20:29:48.104200
# Unit test for function load
def test_load():
    # Load a file with invalid context: No cookiecutter key
    replay_dir = 'tests/test-replay'
    template_name = 'tests/test-repo-pre/{{cookiecutter.repo_name}}/'
    try:
        load(replay_dir, template_name)
    except Exception as e:
        assert(str(e) == 'Context is required to contain a cookiecutter key')

    # Load a file with non-existent template name
    replay_dir = 'tests/test-replay'
    template_name = 'tests/test-repo-pre/non-existent/'

# Generated at 2022-06-11 20:29:54.398613
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    replay_dir = '/Users/jianghao/.cookiecutters/cookiecutter-pypackage'
    template_name = 'cookiecutter-pypackage'
    cookiecutter(template_name, replay_dir=replay_dir, no_input=True)
    replay_dir = '/Users/jianghao/.cookiecutters/cookiecutter-pypackage/mypackage'
    template_name = 'cookiecutter-pypackage/mypackage'
    cookiecutter(template_name, replay_dir=replay_dir, no_input=True)



# Generated at 2022-06-11 20:29:58.675210
# Unit test for function load
def test_load():
    """Test the load function."""
    # Initialize variables
    replay_dir = 'tests/files/replay'
    template_name = 'example'
    expected = {'cookiecutter': {'full_name': 'Audrey Roy'}}

    # Test
    actual = load(replay_dir, template_name)

    # Verify
    assert expected == actual

# Generated at 2022-06-11 20:30:07.134299
# Unit test for function load
def test_load():
    test_data = '{"cookiecutter":{"foo":"bar","cookiecutter":{"baz":"dog"}}}'
    random_file = os.path.join('/tmp', __file__)
    with open(random_file, 'w') as infile:
        infile.write(test_data)

    context = load(os.path.dirname(random_file), os.path.basename(random_file))
    assert 'foo' in context['cookiecutter']
    assert 'baz' in context['cookiecutter']['cookiecutter']
    assert context['cookiecutter']['cookiecutter']['baz'] == 'dog'

# Generated at 2022-06-11 20:30:10.126505
# Unit test for function load
def test_load():
    """test load function."""
    #with open('test_data.json', 'r') as f:
    with open('test_data.json', 'r') as f:
        test_data = json.load(f)
    if __name__ == '__main__':
        assert test_data == load('replays', 'cookiecutter-pypackage')



# Generated at 2022-06-11 20:30:16.237205
# Unit test for function load
def test_load():
    """Unit test for function load."""
    assert type(load('/home/hilpisch/.cookiecutters/', 'informatik.de')) == dict
    # assert load('/home/hilpisch/.cookiecutters/', 'informatik.de') is dict
    # assert load('/home/hilpisch/.cookiecutters/', 'informatik.de') != dict
    return True


# Generated at 2022-06-11 20:30:19.668247
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = 'test/test_dir'
    context = {'cookiecutter': {'test': '123'}}

    dump(replay_dir, template_name, context)
    result = load(replay_dir, template_name)
    assert context == result

