

# Generated at 2022-06-23 16:23:23.139632
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join(os.getcwd(), 'test_replay_dir')
    template_name = 'test_template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, template_name+'.json')



# Generated at 2022-06-23 16:23:33.793225
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(replay_dir_test, 'test')
    template_name = 'test'
    context = {'cookiecutter': {'a': '1', 'b': '2'}}
    dump(replay_dir, template_name, context)
    file_path = os.path.join(replay_dir, template_name + '.json')
    with open(file_path, 'r') as replay_file:
        context_loaded = json.load(replay_file)
    assert(context_loaded == context)
    os.remove(file_path)
    os.rmdir(replay_dir)


# Generated at 2022-06-23 16:23:44.002258
# Unit test for function dump
def test_dump():
    from cookiecutter import main
    import shutil
    import os
    import json
    import sys

    # Create replay dir
    replay_dir = 'tests/test-replay'

# Generated at 2022-06-23 16:23:48.858465
# Unit test for function dump
def test_dump():
    replay_dir = 'replay'
    template_name = 'naruto_cookie'
    context = {
        'cookiecutter': {
            'full_name': 'Naruto Uzumaki',
            'email': 'Senju_Hashirama@konoha.com',
            'github_username': 'Senju_Hashirama',
            'project_name': 'Konoha-project',
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:23:53.121506
# Unit test for function load
def test_load():
    test_context = load('cookiecutter.replay', 'f8a-service-template')
    assert 'cookiecutter' in test_context
    assert 'project_slug' in test_context['cookiecutter'].keys()

# Generated at 2022-06-23 16:23:56.765768
# Unit test for function load
def test_load():
    replay_dir = "tests/test-data/dict-config-splitting"
    template_name = "tests/test-repo-pre/"
    context = load(replay_dir, template_name)
    print(context)

# Generated at 2022-06-23 16:23:58.235560
# Unit test for function get_file_name
def test_get_file_name():
    # TODO: test the function
    return True


# Generated at 2022-06-23 16:24:01.249337
# Unit test for function load
def test_load():
    assert load('/tmp/cookiecutter', 'template') == {'cookiecutter': {'_template': 'Django-Cookiecutter'}}


# Generated at 2022-06-23 16:24:05.379718
# Unit test for function load
def test_load():
    """Load the context from a replay file"""
    template_name='t1'
    replay_file = get_file_name('replay_files', template_name)
    context=load('replay_files',template_name)
    assert(context)


# Generated at 2022-06-23 16:24:14.012545
# Unit test for function dump

# Generated at 2022-06-23 16:24:19.525339
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.expanduser('~/.cookiecutter_replay')
    template_name = 'g'

    file_name = get_file_name(replay_dir, template_name)

    assert file_name == os.path.join(replay_dir, template_name + '.json')



# Generated at 2022-06-23 16:24:22.785401
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "tests/files/replay_dir"
    template_name = "tests/files/cookiecutters/fake-repo-tmpl"
    assert get_file_name(replay_dir, template_name) == "tests/files/replay_dir/fake-repo-tmpl.json"

# Generated at 2022-06-23 16:24:29.673413
# Unit test for function load
def test_load():

    replay_dir = os.path.abspath(os.path.join('~', '.cookiecutters'))
    template_name = 'test/test'

    replay_file = get_file_name(replay_dir, template_name)


# Generated at 2022-06-23 16:24:41.614379
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.getcwd(),os.path.dirname(__file__), '..', '..', '.cookiecutters')
    template_name = 'cookiecutter-pypackage'
    replay_file = get_file_name(replay_dir, template_name)
    if not os.path.exists(replay_file):
        raise ValueError('Replay file %s does not exist', replay_file)
    else:
        context = load(replay_dir, template_name)

# Generated at 2022-06-23 16:24:47.258713
# Unit test for function dump
def test_dump():
    """Unit test for dump function"""
    template_name = 'template_name'
    replay_dir = 'test_dir'
    context = {
        'cookiecutter': 'aaa',
    }
    dump(replay_dir, template_name, context)
    load_context = load(replay_dir, template_name)
    assert load_context == context

# Generated at 2022-06-23 16:24:51.537755
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "."
    template_name = "testfile"

    assert(get_file_name(replay_dir,template_name) == ".\\testfile.json")


# Generated at 2022-06-23 16:25:01.171903
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'test_replay'
    template_name = 'test_template'
    context = {'cookiecutter': {'test_key': 'test_value'}}
    dump(replay_dir, template_name, context)
    # Assert file was created
    file_path = get_file_name(replay_dir, template_name)
    assert os.path.exists(file_path)
    # Assert directory was created
    assert os.path.exists(replay_dir)
    # Cleanup
    os.remove(file_path)
    os.rmdir(replay_dir)


if __name__ == '__main__':
    import pytest

# Generated at 2022-06-23 16:25:05.682613
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = '.'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == './template.json'


# Generated at 2022-06-23 16:25:14.145578
# Unit test for function load
def test_load():
    """Test for the load function."""
    print("\n  Testing load function.")
    assert load('.', 'doesntexist') is None

# Generated at 2022-06-23 16:25:18.534936
# Unit test for function dump
def test_dump():
    replay_dir = 'F:\\Python\\projects\\test'
    template_name = 'test.json'
    context = {'cookiecutter': {
        'full_name': 'test'
    }}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-23 16:25:26.520911
# Unit test for function get_file_name
def test_get_file_name():

    # Given
    replay_dir = "tests/test-replay/"
    template_name = "cookiecutter-pypackage"
    expect_file_name = "tests/test-replay/cookiecutter-pypackage.json"

    # When
    actual_file_name = get_file_name(replay_dir, template_name)

    # Then
    assert (expect_file_name == actual_file_name)


# Generated at 2022-06-23 16:25:32.788179
# Unit test for function load
def test_load():
    template_name = "test_t"
    replay_dir = "/home/yiding/Projects/cookie_cutter_auto_fill/test_load"
    context = {'cookiecutter':{'username':"Yiding",'email':"yidingning@u.nus.edu"}}
    dump(replay_dir, template_name, context)
    context_new = load(replay_dir, template_name)
    assert(context == context_new)



# Generated at 2022-06-23 16:25:43.588384
# Unit test for function dump
def test_dump():
    """Generate the 'template1' file."""
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'cookiecutter-pypackage',
            'project_slug': 'cookiecutterpypackage',
            'pypi_username': 'audreyr',
            'release_date': '2013-06-01',
            'version': '0.1.0',
            'command_line_interface': 'argparse',
            'license': 'MIT license'
        }
    }
    replay_dir = './tests/replay'
    template_name = 'template1'

# Generated at 2022-06-23 16:25:53.951976
# Unit test for function load
def test_load():
    # Set up a test directory to act as a replay_dir
    replay_dir = 'tests/{{cookiecutter.repo_name}}/test_replay_dir'

    # Create the given replay_dir
    make_sure_path_exists(replay_dir)

    # The two variables below were generated from a real run of cookiecutter
    # using this repository as the template
    template_name = 'cookiecutter-pypackage-demo'

# Generated at 2022-06-23 16:25:57.210716
# Unit test for function get_file_name
def test_get_file_name():
    '''
    Function: get_file_name
    '''
    file_name = get_file_name('/home', 'organization/project')
    assert file_name == '/home/organization/project.json'


# Generated at 2022-06-23 16:26:05.058485
# Unit test for function get_file_name
def test_get_file_name():
    result = get_file_name('/dummyFolderName', 'dummyTemplateName')
    assert result == '/dummyFolderName/dummyTemplateName.json'
    assert not get_file_name('/dummyFolderName', 'dummyTemplateName.json') == '/dummyFolderName/dummyTemplateName.json'
    assert not get_file_name('/dummyFolderName.json', 'dummyTemplateName') == '/dummyFolderName/dummyTemplateName.json'
    assert not get_file_name('/dummyFolderName.json', 'dummyTemplateName.json') == '/dummyFolderName/dummyTemplateName.json'
    assert get_file_name('/dummyFolderName.json', 'dummyTemplateName.json') == '/dummyFolderName.json/dummyTemplateName.json'

# Generated at 2022-06-23 16:26:08.380807
# Unit test for function load
def test_load():
    replay_dir = "./tests/fixtures/replay/"
    assert isinstance(load(replay_dir, "cookiecutter.json"),
                      dict) is True


# Generated at 2022-06-23 16:26:18.116107
# Unit test for function dump
def test_dump():
    context = {
        "cookiecutter": {
            "full_name": "Your Name",
            "email": "your@email.com",
            "github_username": "your_github_username",
            "project_name": "foobar",
            "project_slug": "foobar",
        }
    }
    replay_dir = '.replay'
    template_name = 'Cookiecutter-pypackage'

    # run
    dump(replay_dir, template_name, context)

    # check if replay file exist
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file) is True


# Generated at 2022-06-23 16:26:22.584225
# Unit test for function get_file_name
def test_get_file_name():
    test = get_file_name("some_dir","some_file")
    # Assert that the file has been created
    assert test == "some_dir\\some_file.json"


# Generated at 2022-06-23 16:26:27.072160
# Unit test for function dump
def test_dump():
    """Test for dumping contents to a file."""
    if not os.path.exists('tests/files/test-replay-dump'):
        os.makedirs('tests/files/test-replay-dump')
    dump('tests/files/test-replay-dump', 'replay_file', {'cookiecutter': {'full_name': 'Full Name'}})
    assert os.path.exists('tests/files/test-replay-dump/replay_file.json')



# Generated at 2022-06-23 16:26:30.574981
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'abc'
    replay_dir = 'dir'
    assert get_file_name(replay_dir, template_name) == 'dir/abc.json'


# Generated at 2022-06-23 16:26:40.755141
# Unit test for function load
def test_load():
    replay_dir = 'tests/fake-repo-1'
    template_name = 'fake-repo-1'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['project_name'] == 'My Test Project'
    assert context['cookiecutter']['author_name'] == 'Owais Lane'
    assert context['cookiecutter']['email'] == 'owaislane@example.com'
    assert context['cookiecutter']['description'] == 'A short description of the project.'
    assert context['cookiecutter']['domain_name'] == 'example.com'
    assert context['cookiecutter']['version'] == '0.1.0'

# Generated at 2022-06-23 16:26:50.741355
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "dummy_dir"
    # Test case 1: check file name with no extension
    template_name = "dummy_template"
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == "dummy_dir/dummy_template.json"
    # Test case 2: check file name with .json extension (should not change)
    template_name = "dummy_template.json"
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == "dummy_dir/dummy_template.json"
    # Test case 3: check file name with .jsonx extension (should change to json)
    template_name = "dummy_template.jsonx"

# Generated at 2022-06-23 16:26:55.713445
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/tmp', 'test-repo') == '/tmp/test-repo.json'
    assert get_file_name('/tmp', 'test-repo.json') == '/tmp/test-repo.json'
    assert get_file_name('/tmp', 'test-repo.json.json') == '/tmp/test-repo.json.json'

# Generated at 2022-06-23 16:27:05.330360
# Unit test for function dump
def test_dump():
    """Test dump()."""
    path = '/tmp/test-replay-dir'
    template_name = 'cookiecutter-pypackage-minimal'
    context = {
        'full_name': 'Audrey Roy',
        'email': 'audreyr@example.com',
        'github_username': 'audreyr',
        'project_name': 'cookiecutter-pypackage-minimal',
        'project_slug': 'cookiecutter-pypackage-minimal',
        'repo_name': 'cookiecutter-pypackage-minimal',
        'release_date': '2014-04-01',
        'version': '0.1.0',
        'cookiecutter': {
            'replay_dir': path
        }
    }

# Generated at 2022-06-23 16:27:11.568353
# Unit test for function get_file_name
def test_get_file_name():
    """
    Test to make sure the get_file_name function get the file name correctly.
    """
    replay_dir = "replay"
    file_name = 'template.json'
    extracted_file = get_file_name(replay_dir, file_name)
    assert extracted_file == 'replay/template.json'
    return None

# Generated at 2022-06-23 16:27:19.237615
# Unit test for function dump
def test_dump():
    assert make_sure_path_exists('/tmp') == True
    assert isinstance(template_name, str) == True
    assert isinstance(context, dict) == True
    assert 'cookiecutter' in context == True
    assert isinstance(get_file_name('/tmp', 'abc.json') == str) == True
    assert os.path.join('/tmp', 'abc.json') == '/tmp/abc.json'
    assert dump('/tmp', 'abc.json', {'key': 'value'}) == None
    assert ContextLoader.get_context('/tmp/abc.json') != None


# Generated at 2022-06-23 16:27:25.396862
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir="tests"
    template_name="a"
    assert get_file_name(replay_dir, template_name) == "tests/a.json"
    template_name="a.json"
    assert get_file_name(replay_dir, template_name) == "tests/a.json"
    template_name="b.txt"
    assert get_file_name(replay_dir, template_name) == "tests/b.json"
    

# Generated at 2022-06-23 16:27:36.942003
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/tmp/cookiecutter-testing/replay'
    template_name = 'testing_template1'
    template_name2 = 'testing_template2.json'
    template_name3 = 'testing_template3.json'
    assert os.path.join(replay_dir, 'testing_template1.json') == get_file_name(replay_dir, template_name)
    assert os.path.join(replay_dir, template_name2) == get_file_name(replay_dir, template_name2)
    assert os.path.join(replay_dir, template_name3) == get_file_name(replay_dir, template_name3)


# Generated at 2022-06-23 16:27:42.426341
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    c = {'cookiecutter':{'name':'name'}}
    d = '.tmp'
    t = 'test_template'
    dump(d, t, c)
    context = load(d, t)
    assert context == c
    os.remove(get_file_name(d, t))

# Generated at 2022-06-23 16:27:45.265775
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'test'
    replay_dir = '/home/'
    expected = '/home/test.json'
    assert get_file_name(replay_dir, template_name) == expected

# Generated at 2022-06-23 16:27:57.301191
# Unit test for function load
def test_load():
    """
    Simple unit test for function load.
    """
    import os
    import shutil
    from tempfile import mkdtemp
    test_context = dict()
    test_context['cookiecutter'] = dict()
    test_context['cookiecutter']['full_name'] = 'Scott Walton'
    test_context['cookiecutter']['company_name'] = 'Blue Yonder'
    test_context['cookiecutter']['package_name'] = 'scottwalton'
    test_context['cookiecutter']['package_version'] = '0.0.1'
    test_context['cookiecutter']['author_email'] = 'scottw@blueyonder.co.uk'

# Generated at 2022-06-23 16:28:01.455757
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.getcwd(), 'tests/test-replay')
    template_name = 'test'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict) == True

# Generated at 2022-06-23 16:28:07.662653
# Unit test for function dump
def test_dump():
    file_name = "my_dict"
    replay_dir = "/home/user/Documents/Cookie/replays"
    context = {"cookiecutter": {"full_name": "Audrey Roy Greenfeld", "email": "audreyr@example.com", "github_username": "audreyr"}}
    try:
        dump(replay_dir, file_name, context)
    except:
        print("Couldn't dump file")
test_dump()


# Generated at 2022-06-23 16:28:19.500915
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import os
    import shutil
    import tempfile
    from cookiecutter.replay import dump
    from cookiecutter import DEFAULT_CONTEXT

    # Clean up from previous test if needed
    test_dir = 'tests/test-replay'
    if os.path.exists(test_dir):
        shutil.rmtree(test_dir)

    # Create temp environment
    template_name = 'jinja2-python-cli'
    temp_dir = tempfile.mkdtemp()

    # Write json to file
    dump(temp_dir, template_name, DEFAULT_CONTEXT)

    # Verify the file exists
    assert os.path.exists(os.path.join(temp_dir, 'jinja2-python-cli.json'))

    # Verify

# Generated at 2022-06-23 16:28:23.846929
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replay_dir'
    template_name = 'python-package'
    file_name = get_file_name(replay_dir, template_name)
    expected_file_name = 'replay_dir/python-package.json'
    assert file_name == expected_file_name


# Generated at 2022-06-23 16:28:30.933687
# Unit test for function dump
def test_dump():
    replay_dir = '/Users/raychen/test_cookiecutter/test_replay'
    template_name = 'test_template_name'
    context = {'cookiecutter': {'test_key': 'test_value'}}
    expect_result = '{\n  "cookiecutter": {\n    "test_key": "test_value"\n  }\n}'
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        context = json.load(infile)
    assert (json.dumps(context, indent=2) == expect_result)


# Generated at 2022-06-23 16:28:35.075933
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = './'
    template_name = 'sample'
    suffix = '.json'
    file_name = get_file_name(replay_dir, template_name)
    expected_file_name = './sample.json'
    if file_name != expected_file_name:
        raise AssertionError('File name is incorrect')

# Generated at 2022-06-23 16:28:45.433926
# Unit test for function dump
def test_dump():
    import datetime

    template_name = "test_dir"
    context = {
        "cookiecutter": {
            "full_name": "Audrey Roy Greenfeld",
            "email": "audreyr@example.com",
            "github_username": "audreyr",
            "project_name": "Test Project",
            "project_short_description": "Test short description.",
            "pypi_username": "audreyr",
            "version": "0.1.0",
            "now": datetime.datetime(2015, 11, 24, 22, 23),
        }
    }
    replay_dir = "test_replay_dump"
    dump(replay_dir, template_name, context)

    assert os.path.exists(replay_dir) == True

    # Clean up
   

# Generated at 2022-06-23 16:28:49.091728
# Unit test for function load
def test_load():
    template_name = 'example_project'
    replay_dir = './'
    replay_file = get_file_name(replay_dir, template_name)
    context = load(replay_dir, template_name)
    print(replay_file)
    print(context)


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:29:01.931670
# Unit test for function load

# Generated at 2022-06-23 16:29:08.076002
# Unit test for function load
def test_load():
    fake_context = {"cookiecutter": {}}
    config = {
        'replay_dir': os.path.abspath(os.path.join(__file__, '..', '..', '..', 'tests')),
        'template': 'fake'
    }
    dump(config['replay_dir'], config['template'], fake_context)
    actual_context = load(config['replay_dir'], config['template'])
    assert fake_context == actual_context

# Generated at 2022-06-23 16:29:15.257128
# Unit test for function dump
def test_dump():
    """Unit test for function dump()."""
    test_dir = os.path.dirname(os.path.abspath(__file__))
    replay_dir = os.path.join(test_dir, 'test_data')
    template_name = 'test_template'
    context = {'cookiecutter': {'project_name': 'Hello World'}}

    dump(replay_dir=replay_dir, template_name=template_name, context=context)
    c = load(replay_dir=replay_dir, template_name=template_name)
    assert context == c


# Generated at 2022-06-23 16:29:23.340962
# Unit test for function dump
def test_dump():
    """Test dump function."""
    from cookiecutter import replay
    import os.path

    replay_dir = "tests/test-replay/"
    expected_file = os.path.join(replay_dir, "test_dump.json")
    # if file exists, remove it for testing
    if os.path.isfile(expected_file):
        os.remove(expected_file)
    replay.dump(replay_dir, "test_dump", {"cookiecutter": {"test": "test"}})
    assert os.path.isfile(expected_file)
    os.remove(expected_file)


# Generated at 2022-06-23 16:29:27.549803
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/maurya/Documents/cookiecutter/cookiecutter-pypackage/replay'
    template_name = 'example_1'
    result = get_file_name(replay_dir, template_name)
    assert result == '/home/maurya/Documents/cookiecutter/cookiecutter-pypackage/replay/example_1.json'


# Generated at 2022-06-23 16:29:38.259207
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test_replay'
    template_name = 'json_template'
    test_context = {'cookiecutter': {'project_slug': 'json_project', 'repo_name': 'json_repo'}}
    dump(replay_dir, template_name, test_context)

    if not os.path.exists(replay_dir):
        raise IOError('Failed to make replay dir for tests')

    replay_file = get_file_name(replay_dir, template_name)
    if not os.path.exists(replay_file):
        raise IOError('Failed to create replay file')

    if not os.path.isfile(replay_file):
        raise IOError('Failed to create replay file')


# Generated at 2022-06-23 16:29:48.341650
# Unit test for function load
def test_load():
    """Unit test for function load."""
    template_name = 'template_name'
    context = {
        'cookiecutter': {
            'name': 'name',
            'email': 'email',
            'github_username': 'github_username',
        }
    }
    replay_dir = 'replay_dir'
    if not os.path.exists(replay_dir):
        os.makedirs(replay_dir)
    replay_file = get_file_name(replay_dir, template_name)
    json_data = json.dumps(context, indent=2)
    f = open(replay_file, 'w+')
    f.write(json_data)
    f.close()

    result = load(replay_dir, template_name)

# Generated at 2022-06-23 16:29:53.422604
# Unit test for function load
def test_load():
    filename = "test_files/test_cc_replay.json"
    result = load(replay_dir="test_files", template_name=filename)
    assert isinstance(result, dict), "Expected the results to be of type dict; instead got a {}".format(type(result))


# Generated at 2022-06-23 16:29:57.746967
# Unit test for function dump
def test_dump():
    from cookiecutter.main import cookiecutter
    import tempfile
    template = 'https://github.com/RohanShah27/cookiecutter-data-science.git'
    replay_dir = tempfile.mkdtemp()
    context = cookiecutter(template, replay_dir=replay_dir, no_input=True)
    dump(replay_dir, template, context)


# Generated at 2022-06-23 16:30:02.129423
# Unit test for function load
def test_load():
    replay_dir = os.path.expanduser('~/.cookiecutters/')
    template_name = 'my_project/'
    context = load(replay_dir, template_name)
    dump(replay_dir, template_name, context)

# Generated at 2022-06-23 16:30:12.886813
# Unit test for function dump
def test_dump():
    template_name = 'cookiecutter-pypackage'
    replay_dir = 'tests/files/fake-replay'
    context = {'cookiecutter': {'_template': template_name, 'full_name': 'Mr. Cookie',
               'email': 'cookies@fake.com', 'project_name': 'hello-world',
               'repo_name': 'hello-world', 'year': '2016', 'project_slug': 'hello-world',
               'description': 'A simple Python package', 'version': '0.1.0', 'use_pytest': True,
               'command_line_interface': 'click'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:30:14.520761
# Unit test for function load
def test_load():
    assert load('replay/', 'param1') == {'cookiecutter': {'test_param': 'param_value'}}


# Generated at 2022-06-23 16:30:20.528878
# Unit test for function load
def test_load():
    replay_dir = 'replay'
    template_name = 'foo_template.json'
    context = {'cookiecutter': {'full_name': 'test'}}
    dump(replay_dir, template_name, context)
    context_from_file = load(replay_dir, template_name)
    assert context_from_file['cookiecutter']['full_name'] == 'test'

# Generated at 2022-06-23 16:30:30.236503
# Unit test for function dump
def test_dump():
    # Create a directory and write something in it.
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'Nearest Neighbors',
            'project_short_description': 'Nearest Neighbors',
            'pypi_username': 'audreyr',
            'version': '0.1',
            'release_date': '2014/03/18',
            'open_source_license': 'MIT license',
        },
    }

    replay_dir = "test"
    template_name = "test"
    dump(replay_dir, template_name, context)

    #Check if function really created a file and stored data

# Generated at 2022-06-23 16:30:35.411992
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = '/fake_replay_dir'
    template_name = 'fake_template_name'
    assert get_file_name(replay_dir, template_name) == '/fake_replay_dir/fake_template_name.json'

    template_name = 'fake_template_name.json'
    assert get_file_name(replay_dir, template_name) == '/fake_replay_dir/fake_template_name.json'

# Generated at 2022-06-23 16:30:40.861464
# Unit test for function get_file_name
def test_get_file_name():
    import tempfile
    replay_dir = tempfile.mkdtemp()
    template_name = 'test_name'
    expected_file_name = os.path.join(replay_dir, 'test_name.json')
    assert get_file_name(replay_dir, template_name) == expected_file_name

# Generated at 2022-06-23 16:30:46.942590
# Unit test for function dump
def test_dump():
    from cookiecutter import config
    replay_dir = os.path.join(config.USER_DIR, 'cookiecutter_replay')

# Generated at 2022-06-23 16:30:50.686096
# Unit test for function load
def test_load():
    test_dir = 'C:/Users/aalem/Desktop/Open_Source/learning_cookiecutter/tests'
    template_name = 'date_context'

    assert(
        load(test_dir, template_name) ==
        {'cookiecutter': {'last_year': '2017'}}
    )



# Generated at 2022-06-23 16:30:57.365508
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = 'test_replay_dir'
    template_name = 'test_file_name'

    result = get_file_name(replay_dir, template_name)
    assert result == os.path.join(replay_dir, template_name + '.json')

    result = get_file_name(replay_dir, template_name + '.json')
    assert result == os.path.join(replay_dir, template_name + '.json')

# Generated at 2022-06-23 16:31:00.866869
# Unit test for function load
def test_load():
    template_name = 'button'
    replay_dir = 'replay'
    context = load(replay_dir=replay_dir, template_name=template_name)
    print(context)

#Unit test for function dump

# Generated at 2022-06-23 16:31:03.134567
# Unit test for function load
def test_load():
    context = load('/tmp/.cookiecutter_replay', 'dummy_name')
    assert len(context) > 0
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:31:13.892637
# Unit test for function dump
def test_dump():
    """Test dump function."""
    context = {
        'cookiecutter': {
            'full_name': 'Test Full Name',
            'email': 'test@email.com',
        }
    }

    replay_dir = 'tests/replay'
    template_name = 'tests/fake-repo-tmpl'

    dump(replay_dir=replay_dir, template_name=template_name, context=context)

    assert os.path.exists(replay_dir)

    # Delete the file so that it does not interfere
    os.remove(get_file_name(replay_dir, template_name))

    # Remove the directory as it is empty
    os.rmdir(replay_dir)


# Generated at 2022-06-23 16:31:19.071912
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/tmp'
    template_name = 'python_package_template'

    file_name = get_file_name(replay_dir, template_name)

    assert file_name == '/tmp/python_package_template.json'

# Generated at 2022-06-23 16:31:22.905186
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    assert(get_file_name('replay_dir', 'template_name.json') == 'replay_dir/template_name.json')
    assert(get_file_name('replay_dir', 'template_name') == 'replay_dir/template_name.json')

# Generated at 2022-06-23 16:31:27.675740
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = '/Users/test/replay'
    template_name = 'test_template'
    file_name = 'test_template.json'
    result = get_file_name(replay_dir, template_name)
    assert result == os.path.join(replay_dir, file_name)


# Generated at 2022-06-23 16:31:33.706808
# Unit test for function load
def test_load():
    """Unit tests for function load."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.config import DEFAULT_CONFIG
    from click.testing import CliRunner
    from tempfile import mkdtemp
    from shutil import rmtree
    import os

    replay_dir = mkdtemp()
    results_dir = mkdtemp()
    context = cookiecutter(
        'tests/test-templates/tests-cookiecutter-j2',
        no_input=True,
        replay_dir=replay_dir,
        output_dir=results_dir
    )

# Generated at 2022-06-23 16:31:43.138583
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = './tests/files/fake-repo-pre/'
    context = {'cookiecutter': {'default_context': 'foo'}}
    template_name = 'fake-repo-pre/'
    replay_file = get_file_name(replay_dir, template_name)
    dump(replay_dir, template_name, context)

    with open(replay_file, 'r') as infile:
        context = json.load(infile)
    assert context['cookiecutter']['default_context'] == 'foo'
    os.remove(replay_file)



# Generated at 2022-06-23 16:31:53.232637
# Unit test for function dump
def test_dump():
    import shutil
    shutil.rmtree("./tests/false_project")
    replay_dir = './tests/replay'

    # Test for invalid indent value
    replay_file = get_file_name(replay_dir, template_name='false_project')
    context = {
            "cookiecutter": {
                "full_name": "Tesingfull_name",
                "email": "Testing@gmail.com",
                "github_username": "Testingusername",
                "project_name": "Testingproject",
                "project_short_description": "Testingdescription",
                "version": "0.1.0",
                "year": "2018",
                "github_repo": "Testing/Testing"
            }
        }


# Generated at 2022-06-23 16:32:01.634857
# Unit test for function load
def test_load():
    PWD = os.path.dirname(__file__)
    context = load(PWD, "replay")
    assert context == {
        "cookiecutter": {
            "name": "project",
            "version": "0.1.0",
            "description": "A short description of the project.",
            "license": "MIT",
            "author": "Audrey Roy Greenfeld",
            "email": "audreyr@example.com",
            "url": "https://github.com/audreyr/cookiecutter-pypackage",
            "zip_safe": false
        }
    }

# Generated at 2022-06-23 16:32:08.128192
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = 'tests/test-output'
    context = {'cookiecutter': {'full_name': 'First Last'}}

    try:
        dump(replay_dir, template_name, context)
        context_loaded = load(replay_dir, template_name)
        print('passed')
    except IOError as e:
        print(e)
        print('failed')


# Generated at 2022-06-23 16:32:13.595100
# Unit test for function get_file_name
def test_get_file_name():
    CWD = os.path.dirname(__file__)
    replay_dir = os.path.join(CWD, '../test_replay_dir')
    assert(get_file_name(replay_dir, 'template1') == '../test_replay_dir/template1.json')
    assert(get_file_name(replay_dir, 'template2.json') == '../test_replay_dir/template2.json')

# Generated at 2022-06-23 16:32:19.656442
# Unit test for function load
def test_load():
    test_dict = dict()
    test_dict["cookiecutter"] = dict()
    test_dict["cookiecutter"]["project_name"] = "test_project"
    test_dict["cookiecutter"]["revision"] = "test_revision"
    test_dict["cookiecutter"]["description"] = "test_description"
    test_dict["cookiecutter"]["full_name"] = "test_full_name"
    test_dict["cookiecutter"]["email"] = "test_email"
    test_dict["cookiecutter"]["github_username"] = "test_username"
    test_dict["cookiecutter"]["domain_name"] = "test_domain"
    test_dict["cookiecutter"]["version"] = "v0.0.1"
    test_

# Generated at 2022-06-23 16:32:28.615412
# Unit test for function dump
def test_dump():
    replay_dir = 'cookiecutter_replay'
    template_name = 'json_test'
    context = {'cookiecutter': {'license': 'MIT', 'project_name': 'test_write'}}
    # Positive test
    try:
        dump(replay_dir, template_name, context)
    except IOError:
        print('Unable to create replay dir at ' + replay_dir)
    except TypeError:
        print('Template name is required to be of type str')
    except ValueError:
        print('Context is required to contain a cookiecutter key')

    # Negative test template_name = 1
    template_name = 1
    try:
        dump(replay_dir, template_name, context)
    except TypeError:
        print('Template name is required to be of type str')

    #

# Generated at 2022-06-23 16:32:36.295956
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'a/b/c'
    template_name = 'foo'
    file_name = '{}/{}.json'.format(replay_dir, template_name)
    assert file_name == get_file_name(replay_dir, template_name)

    # Test that suffix is not added if already present
    template_name_with_suffix = 'foo.json'
    file_name = '{}/{}'.format(replay_dir, template_name_with_suffix)
    assert file_name == get_file_name(replay_dir, template_name_with_suffix)

# Generated at 2022-06-23 16:32:40.573896
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/tmp', 'my_template') == '/tmp/my_template.json'
    assert get_file_name('/tmp', 'my_template.json') == '/tmp/my_template.json'

# Generated at 2022-06-23 16:32:47.463776
# Unit test for function load
def test_load():
    os.mkdir('test_replay')
    replay_file = get_file_name('test_replay', 'test_replay')

    with open(replay_file, 'w') as outfile:
        json.dump({'test': 'test', 'test2': 'test2'}, outfile, indent=2)

    context = load('test_replay', 'test_replay')

    assert context == {'test': 'test', 'test2': 'test2'}

    os.remove(replay_file)
    os.rmdir('test_replay')

# Generated at 2022-06-23 16:32:48.660097
# Unit test for function dump
def test_dump():
    assert(True)



# Generated at 2022-06-23 16:32:50.258116
# Unit test for function load
def test_load():
    """Unit test for function load."""
    assert load({''}.json, )

# Generated at 2022-06-23 16:32:54.179983
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('dir', 'template') == 'dir/template.json'
    assert get_file_name('dir', 'template.json') == 'dir/template.json'
    assert get_file_name('dir/', 'template') == 'dir/template.json'

# Generated at 2022-06-23 16:33:05.866030
# Unit test for function load
def test_load():
    replay_dir = os.getcwd()
    template_name="Unit_test"
    file_name=get_file_name(replay_dir, template_name)
    context = load(replay_dir, template_name)
    assert(file_name=="/Users/shuojin/Desktop/test/Unit_test.json")
    assert(context["cookiecutter"]["repo_dir"]==".")

# Generated at 2022-06-23 16:33:12.047820
# Unit test for function load
def test_load():
    # Create test_load/testfile.json
    # with contents
    # {"cookiecutter" : {"test": "abcd"}}

    # Open test_load/testfile.json
    # if exists, then read content
    # check if "abcd" is there, if yes
    # success, else fail.
    # remove test_load/testfile.json
    # remove test_load
    return

# Generated at 2022-06-23 16:33:19.038787
# Unit test for function dump
def test_dump():
    replay_dir = os.path.dirname(__file__) + '/test_replay_dir'
    context = {'cookiecutter': {'full_name': 'Full Name'}}
    template_name = 'test_template'
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert(context['cookiecutter']['full_name'] == 'Full Name')
