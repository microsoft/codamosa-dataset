

# Generated at 2022-06-23 16:23:21.226010
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'cookiecutter'
    template_name = 'cookiecutter-pypackage'
    assert get_file_name(replay_dir, template_name) == 'cookiecutter/cookiecutter-pypackage.json'

# Generated at 2022-06-23 16:23:27.094720
# Unit test for function load
def test_load():
    import json
    import os

    replay_dir = './'
    template_name = 'unit_test'
    replay_file = get_file_name(replay_dir, template_name)
    if os.path.isfile(replay_file):
        os.remove(replay_file)
    with open(replay_file, 'w') as outfile:
        json.dump({'cookiecutter': {}}, outfile, indent=2)
    assert isinstance(load(replay_dir, template_name), dict)
    os.remove(replay_file)


# Generated at 2022-06-23 16:23:28.139033
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-23 16:23:37.625775
# Unit test for function dump
def test_dump():
    # Original context
    c1 = {
        'cookiecutter': {
            'open_source_license': 'MIT license',
            'full_name': 'Sam Joseph',
            'project_name': 'Awesome Python App'
        }
    }

    # New context
    c2 = {
        'cookiecutter': {
            'open_source_license': 'MIT license',
            'full_name': 'Samantha Anne Joseph',
            'project_name': 'Django Awesome Python App'
        }
    }

    # Serialize
    dump('/tmp/', 'cookiecutter-pypackage', c1)
    # Deserialize
    c2_from_c1 = load('/tmp/', 'cookiecutter-pypackage')

    # Verify

# Generated at 2022-06-23 16:23:41.285944
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("/tmp", "test") == os.path.join("/tmp", "test.json")
    assert get_file_name("/tmp", "test.json") == os.path.join("/tmp", "test.json")

# Generated at 2022-06-23 16:23:52.734707
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'test': 'This is a test'}}
    replay_dir = os.path.join('tests', 'test-replay')
    template_name = 'test-template'
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context

    context = {'cookiecutter': {'test': 'This is a test with space'}}
    replay_dir = os.path.join('tests', 'test-replay')
    template_name = 'test-template-with-space'
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context

    context = {'cookiecutter': {'test': 'This is a test with space'}}
    replay_dir

# Generated at 2022-06-23 16:23:55.593559
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name"""
    assert get_file_name('/tmp', 'my_template_name') == '/tmp/my_template_name.json'


# Generated at 2022-06-23 16:24:01.464008
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/home/user/replays/', 'cookiecutter-pypackage') == '/home/user/replays/cookiecutter-pypackage.json'
    assert get_file_name('/home/user/replays/', 'cookiecutter-pypackage.json') == '/home/user/replays/cookiecutter-pypackage.json'


# Generated at 2022-06-23 16:24:04.426782
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = '.'
    context = load(replay_dir, template_name)

# Generated at 2022-06-23 16:24:08.973134
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            "abcd": "defg",
            "t": "b"
        }
    }
    dump(replay_dir="./tests/fake", template_name="a.json", context=context)


# Generated at 2022-06-23 16:24:15.285183
# Unit test for function load
def test_load():
    """Unit test for function load(replay_dir, template_name)"""
    template_name = "test"
    replay_dir = os.path.dirname(os.path.abspath(__file__))
    message = load(replay_dir, template_name)
    message1 = load(os.path.join(replay_dir, '../replay'), template_name)
    assert message1['cookiecutter'] == message['cookiecutter']


# Generated at 2022-06-23 16:24:22.542072
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replay/test'
    template_name = 'test/test_template'
    file_name = 'test_template.json'
    assert(get_file_name(replay_dir, template_name) == replay_dir + '/' + file_name)

    template_name = 'test/test_template.json'
    file_name = 'test_template.json'
    assert(get_file_name(replay_dir, template_name) == replay_dir + '/' + file_name)

test_get_file_name()

# Generated at 2022-06-23 16:24:25.613920
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "."
    template_name = "sample"
    assert get_file_name(replay_dir, template_name) == ("./sample.json")


# Generated at 2022-06-23 16:24:28.223900
# Unit test for function load
def test_load():
	a = load('/Users/Anusha/Desktop/softwareDefectPrediction/data/', 'calgary_corpus')
	print(a)


# Generated at 2022-06-23 16:24:30.690936
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('my_dir', 'my_template.json') == 'my_dir/my_template.json'
    assert get_file_name('my_dir', 'my_template') == 'my_dir/my_template.json'



# Generated at 2022-06-23 16:24:38.320936
# Unit test for function load
def test_load():
    """Tests the load function for the replay module."""
    context = load("/home/matthew/Documents/GitHub/cookiecutter-mf/cookiecutter-mf/tests/sample_templates", "cookiecutter-pypackage")

    assert("./tests/sample_templates/cookiecutter-pypackage" == context["cookiecutter"]["repo_dir"])


# Generated at 2022-06-23 16:24:45.051532
# Unit test for function load
def test_load():
    template_name = 'test_template'
    context = {'cookiecutter': {'name': 'Name', 'version': '0.1'}}
    replay_dir = 'tests/replay'
    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)
    assert context == context_loaded

# Generated at 2022-06-23 16:24:47.937503
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('./dir', 'test') == './dir/test.json'
    assert get_file_name('./dir', 'test.json') == './dir/test.json'


# Generated at 2022-06-23 16:24:58.990572
# Unit test for function load
def test_load():

    import unittest
    import json
    import os

    class TestNotExistFile(unittest.TestCase):
        def test_nonexist_file(self):
            with self.assertRaises(IOError):
                load('tests', 'nonexist_file')
    unittest.main()

    class TestNotDictFile(unittest.TestCase):
        def test_not_dict_file(self):
            with self.assertRaises(ValueError):
                load('tests', 'not_dict_file')
    unittest.main()

    class TestNotCookiecutterFile(unittest.TestCase):
        def test_not_cookiecutter_file(self):
            with self.assertRaises(ValueError):
                load('tests', 'not_cookiecutter_file')
   

# Generated at 2022-06-23 16:25:02.095626
# Unit test for function get_file_name
def test_get_file_name():
    # No suffix if template name ends with '.json'
    assert 'foo.json' == get_file_name('bar', 'foo.json')
    # Otherwise add suffix
    assert 'foo.json' == get_file_name('bar', 'foo')

# Generated at 2022-06-23 16:25:07.123622
# Unit test for function load
def test_load():
    replay_dir = 'tests/files/tests/test_load'
    template_name = 'TEMPLATE_NAME'
    context = None
    # context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-23 16:25:09.532012
# Unit test for function load
def test_load():
    template_name = 'test'
    context = load('./test_load', template_name)
    assert context['email'] == 'email@email.com'

# Generated at 2022-06-23 16:25:14.454522
# Unit test for function dump
def test_dump():
    template_name = 'base'
    context = {
        'cookiecutter': {'name': 'base'}
    }
    replay_dir = os.path.join(os.path.dirname(__file__), 'test')
    make_sure_path_exists(replay_dir)
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))

# Generated at 2022-06-23 16:25:20.917325
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-load'
    assert (load(replay_dir, 'dummy') == {'cookiecutter': {
        'full_name': 'Monty Python',
        'email': 'monty@python.org',
        'github_username': 'montypython',
        'project_name': 'dummy',
        'project_slug': 'dummy',
        'replay_file': 'dummy.json',
    }, 'project_name': 'Dummy'})


# Generated at 2022-06-23 16:25:31.727879
# Unit test for function get_file_name
def test_get_file_name():
    # Case 1: Replaydir is empty
    replaydir = ''
    template_name = 'test_template'
    file_name = get_file_name(replaydir, template_name)
    assert file_name == 'test_template.json'

    # Case 2: Replaydir is not empty and template_name is empty
    replaydir = 'templates'
    template_name = ''
    file_name = get_file_name(replaydir, template_name)
    assert file_name == 'templates/ .json'

    # Case 3: Replaydir and template_name are not empty, template_name has a 'json' file extension
    replaydir = 'templates'
    template_name = 'test_template.json'
    file_name = get_file_name(replaydir, template_name)
    assert file

# Generated at 2022-06-23 16:25:39.157673
# Unit test for function dump
def test_dump():
    template_name = 'project_name'
    replay_dir = '/home/user/cookiecutters/some_template'

# Generated at 2022-06-23 16:25:47.661770
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.abspath(os.getcwd()), 'tests/test-replay')
    template_name = 'key_valid'
    context = {'cookiecutter': {'key': 'value'}}
    valid_result = {'cookiecutter': {'key': 'value'}}
    dump(replay_dir, template_name, context)
    with open(os.path.join(replay_dir, template_name + '.json'), 'r') as infile:
        assert json.load(infile) == valid_result


# Generated at 2022-06-23 16:25:52.904578
# Unit test for function dump
def test_dump():
    """Test for function dump."""
    context = {'cookiecutter': {'A': 'B'}}
    template_name = 'A'
    replay_dir = './replays'
    replay_file = './replays/A.json'

    dump(replay_dir, template_name, context)

    with open(replay_file, 'r') as infile:
        stored_context = json.load(infile)


    assert context == stored_context


# Generated at 2022-06-23 16:26:01.524004
# Unit test for function dump
def test_dump():
    replay_dir = 'test'
    template_name = 'test_template'
    context = {
        'cookiecutter': {
            'full_name': 'A. U. Thor',
            'email': 'author@example.com'
        }
    }
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, '{}.json'.format(template_name)))
    with open(os.path.join(replay_dir, '{}.json'.format(template_name)), 'r') as infile:
        content = infile.read()
    assert "cookiecutter" in content
    assert "full_name" in content
    assert "email" in content



# Generated at 2022-06-23 16:26:03.945320
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test_data'
    template_name = 'simple'
    file_name = get_file_name(replay_dir, template_name)
    assert template_name + '.json' == file_name


# Generated at 2022-06-23 16:26:15.496998
# Unit test for function dump
def test_dump():
    """Ensure dump function works."""
    import tempfile
    import shutil

    template_name = 'TESTTEMPLATE'
    context = {
        'cookiecutter': {
            'ctx': {
                'temp_var': True
            }
        }
    }

# Generated at 2022-06-23 16:26:23.638360
# Unit test for function get_file_name
def test_get_file_name():
    # Test 1
    replay_dir = 'processed-cookiecutters'
    template_name = 'oscar-cookiecutter'

    expected_file_name = 'processed-cookiecutters/oscar-cookiecutter.json'

    assert get_file_name(replay_dir, template_name) == expected_file_name

    # Test 2
    replay_dir = 'processed-cookiecutters'
    template_name = 'oscar-cookiecutter.json'

    expected_file_name = 'processed-cookiecutters/oscar-cookiecutter.json'

    assert get_file_name(replay_dir, template_name) == expected_file_name

# Generated at 2022-06-23 16:26:27.361430
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replay'
    template_name = 'test_template'
    assert get_file_name(replay_dir, template_name) == os.path.join('replay', 'test_template.json')
    template_name = 'test_template.json'
    assert get_file_name(replay_dir, template_name) == os.path.join('replay', 'test_template.json')


# Generated at 2022-06-23 16:26:32.175747
# Unit test for function get_file_name
def test_get_file_name():
    template = "https://github.com/audreyr/cookiecutter-pypackage.git"
    replay_dir = 'replay'
    assert get_file_name(replay_dir, template) == replay_dir+"/"+template+'.json'



# Generated at 2022-06-23 16:26:36.697315
# Unit test for function get_file_name
def test_get_file_name():
    '''
        This functions tests whether the file name returned is the same as the one
        that we have given as input.
    '''
    replay_dir = "replay_dir"
    template_name = "template_name"
    get_file_name(replay_dir, template_name)
    
    

# Generated at 2022-06-23 16:26:41.961041
# Unit test for function load
def test_load():
   result = load("./cookiecutters/django-project/fakereplay", "cookiecutter.json")
   # Check if the result is a dict
   assert isinstance(result, dict)
   # Check if the result contains a 'cookiecutter' key
   assert 'cookiecutter' in result



# Generated at 2022-06-23 16:26:47.110536
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = "C:\\Users\\jianw\\Desktop\\cookiecutter-pypackage\\tests\\test-replay"
    template_name = "cookiecutter-pypackage"
    context = load(replay_dir, template_name)
    assert context != None


# Generated at 2022-06-23 16:26:50.243332
# Unit test for function load
def test_load():
    context = load("C:/Users/qcq/Desktop/test", "C:/Users/qcq/Desktop/test/cookiecutter.json")
    print(context)
    print("the type of context is: " + str(type(context)))


# Generated at 2022-06-23 16:26:51.435975
# Unit test for function load
def test_load():
    assert isinstance(load('C:\/../','test'), dict)


# Generated at 2022-06-23 16:26:56.500798
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/path'
    template_name = 'a_file.json'
    assert get_file_name(replay_dir, template_name) == 'a_file.json'

    template_name = 'a_file'
    assert get_file_name(replay_dir, template_name) == 'a_file.json'

test_get_file_name()

# Generated at 2022-06-23 16:27:03.774554
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/replay'
    template_name = 'example'
    context = {
        "cookiecutter": {
            "full_name": "Audrey Roy",
            "email": "audreyr@example.com",
            "github_username": "audreyr",
            "project_name": "My Project",
            "project_slug": "my_project",
            "repo_name": "My Project"
        }
    }

    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:27:06.549606
# Unit test for function load
def test_load():
    context = load('samples', 'first_repo')
    assert context['cookiecutter']['repo_name'] == 'first-repo'
    assert context['cookiecutter']['description'] == 'First repo'

# Generated at 2022-06-23 16:27:17.319705
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.dirname(
        os.path.abspath(__file__)), 'tests/test_dump_replay/')
    template_name = 'example_repo'
    context = {'cookiecutter': {'full_name': 'Audrey Roy',
                                'email': 'audreyr@example.com',
                                'github_username': 'audreyr',
                                'project_name': 'cookiecutter-pypackage',
                                'project_slug': 'cookiecutter-pypackage',
                                'release_date': '2014/10/01',
                                'year': '2012'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:27:24.469554
# Unit test for function load
def test_load():
    """Load test."""
    template_name = 'replay_test'

    # Test when file does not exist
    with pytest.raises(IOError):
        replay_dir = './bogus'
        context = load(replay_dir, template_name)

    # Test when file is valid
    replay_dir = './cookiecutter-replay'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['full_name'] == 'John Smith'

# Generated at 2022-06-23 16:27:36.631942
# Unit test for function load
def test_load():
    context = load('/Users/lijm/.cookiecutters', 'Cookiecutter-pypackage')
    # print('context: {}'.format(context))
    # assert context == '{"_template": "Cookiecutter-pypackage", "cookiecutter": {"_template": "Cookiecutter-pypackage", "author_email": "lijm@xyz.com", "author_name": "lijm", "description": "A Python package project template", "github_username": "lijm", "open_source_license": "pypi-standard", "pypi_username": "lijm", "project_name": "project", "use_pytest": "y", "year": "2018"}}\n'


# Generated at 2022-06-23 16:27:47.168306
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-out/replays'
    template_name = 'lixx333666/cookiecutter-pypackage-minimal'

# Generated at 2022-06-23 16:27:55.254913
# Unit test for function dump
def test_dump():
    template_name = "test_template"
    replay_dir = os.path.dirname(os.path.realpath(__file__))
    # create a context for testing dump
    context = {}
    context["cookiecutter"] = {}
    context["cookiecutter"]["name"] = "Roger Rabbit"
    context["cookiecutter"]["age"] = 25

    # call the dump function and write the data to file
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:28:00.078337
# Unit test for function dump
def test_dump():
    replay_dir = "tests/test-output/"
    template_name = "test1"
    context = {'cookiecutter': {'id': 'test'}}
    dump(replay_dir, template_name, context)
    assert 1 == 1


# Generated at 2022-06-23 16:28:02.831517
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = 'cookie'
    assert(load(replay_dir, template_name))

#Unit test for function load

# Generated at 2022-06-23 16:28:11.115583
# Unit test for function dump
def test_dump():
    replay_dir = 'replay/'
    template_name = 'cookiecutter/j2cli'

# Generated at 2022-06-23 16:28:21.086490
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join('/tmp', 'replay')

    file_name = get_file_name(replay_dir, 'foobar')
    assert file_name == os.path.join(replay_dir, 'foobar.json')

    file_name = get_file_name(replay_dir, 'foobar.json')
    assert file_name == os.path.join(replay_dir, 'foobar.json')

    try:
        get_file_name(replay_dir, None)
        assert False
    except TypeError:
        assert True

    try:
        get_file_name(replay_dir, 10)
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-23 16:28:29.029886
# Unit test for function dump
def test_dump():
    # Parameters
    replay_dir = 'tests/files/test-replay'
    template_name = 'test_cookiecutter'
    context = {'cookiecutter': {'author': 'anonymous'}}
    # Function call
    dump(replay_dir, template_name, context)
    # Assertion
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.exists(replay_file)
    os.remove(replay_file)


# Generated at 2022-06-23 16:28:31.831366
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("temp", "test") == "temp/test.json"
    assert get_file_name("temp", "test.json") == "temp/test.json"


# Generated at 2022-06-23 16:28:35.464087
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/foo', 'bar') == '/foo/bar.json'
    assert get_file_name('/foo', 'bar.json') == '/foo/bar.json'
    assert get_file_name('/foo', '/bar.json') == '/foo/bar.json'

# Generated at 2022-06-23 16:28:44.844064
# Unit test for function load
def test_load():
    cookiecutter_json = os.path.join(os.path.dirname(__file__), 'cookiecutter.json')

    if os.path.exists(cookiecutter_json):
        os.remove(cookiecutter_json)

    context = load(os.path.dirname(__file__), 'cookiecutter')

    assert context['project_name'] == 'hook_test'
    assert context['repo_name'] == 'cookiecutter-hook-test'

    replay_file = os.path.join(os.path.dirname(__file__), 'cookiecutter.json')
    if os.path.exists(replay_file):
        os.remove(replay_file)

# Generated at 2022-06-23 16:28:50.577466
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = os.path.join(os.path.abspath(os.getcwd()), 'temp_replay')
    dump(replay_dir, 'potato', {'cookiecutter': {'foo': 'bar'}})
    assert len(os.listdir(replay_dir)) == 1
    context = load(replay_dir, 'potato')
    assert len(context) == 1
    assert 'cookiecutter' in context
    assert len(context['cookiecutter']) == 1
    assert 'foo' in context['cookiecutter']
    assert context['cookiecutter']['foo'] == 'bar'

# Generated at 2022-06-23 16:28:58.131351
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for get_file_name function."""
    assert get_file_name('.', 'cc_test') == './cc_test.json'
    assert get_file_name('.', 'cc_test.json') == './cc_test.json'
    assert get_file_name('/', 'cc_test.json') == '/cc_test.json'


# Generated at 2022-06-23 16:29:06.123633
# Unit test for function dump
def test_dump():

	directory = "C:/Users/johne/Desktop/replay_dir"
	template_name = "template_name"
	context = "context" #check context here

	#check if replay_dir is of type string
	assert isinstance(directory, str), "replay_dir is not of type string"

	#check if template_name is of type string
	assert isinstance(template_name, str), "template_name is not of type string"

	#check if context is of type dict
	assert isinstance(context, dict), "context is not of type dict"

	
#Unit test for function load

# Generated at 2022-06-23 16:29:09.957018
# Unit test for function load
def test_load():
    replay_dir = '/Users/sypark/GitHub/cookiecutter-data-science/tests/test-replay'
    template_name = 'xgboost'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Seongyeol Park'


# Generated at 2022-06-23 16:29:15.337763
# Unit test for function dump
def test_dump():
    replay_dir = "cookiecutter/tests/test-data/replay"
    template_name = "test_template"
    context = {'context': "test context"}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    print(replay_file)

    with open(replay_file, 'r') as infile:
        data = json.load(infile)
    print(data)



# Generated at 2022-06-23 16:29:19.197778
# Unit test for function get_file_name
def test_get_file_name():
    expected_result = '/tmp/cookiecutter-replay/test.json'
    result = replay.get_file_name('/tmp/cookiecutter-replay', 'test')
    assert result == expected_result
    

# Generated at 2022-06-23 16:29:25.137762
# Unit test for function get_file_name
def test_get_file_name():
    """Test the function get_file_name"""
    rdir = 'replay_dir'
    tname = 'test_template'
    fn = get_file_name(rdir, tname)
    assert fn == 'replay_dir/test_template.json'
    tname = 'test_template.json'
    fn = get_file_name(rdir, tname)
    assert fn == 'replay_dir/test_template.json'


# Generated at 2022-06-23 16:29:32.267918
# Unit test for function load
def test_load():
    os.chdir('..')
    replay_dir = os.path.join(os.getcwd(), "tests", "test-replay")
    template_name = "test"
    context = load(replay_dir, template_name)
    assert context

    template_name = "test.json"
    context = load(replay_dir, template_name)
    assert context


# Generated at 2022-06-23 16:29:38.450762
# Unit test for function load
def test_load():
    template_name = 'test'
    replay_dir = 'test_data'
    context = {
        'cookiecutter': {
            template_name: 'value1'
        }
    }
    dump(replay_dir, template_name, context)
    infile = load(replay_dir, template_name)
    assert template_name in infile['cookiecutter']
    assert infile['cookiecutter'][template_name] == 'value1'
    os.remove(os.path.join(replay_dir, template_name))


# Generated at 2022-06-23 16:29:40.021030
# Unit test for function load
def test_load():
    """Test load"""
    context = load('.', 'context.json')
    print(context)



# Generated at 2022-06-23 16:29:42.081419
# Unit test for function load
def test_load():
	replay_dir = "/Users/carlan/Desktop/uncreditable_repos/cookiecutter/tests/test-output"
	template_name = "full_replay_template"

# Generated at 2022-06-23 16:29:48.290608
# Unit test for function get_file_name
def test_get_file_name():
    # Test proper io
    replay_dir = './'
    template_name = 'template'
    assert get_file_name(replay_dir, template_name) == './template.json'

    # Test proper io
    replay_dir = './'
    template_name = 'template.json'
    assert get_file_name(replay_dir, template_name) == './template.json'

    # Test error handling
    replay_dir = './'
    template_name = None
    try:
        get_file_name(replay_dir, template_name)
    except TypeError as e:
        assert str(e) == 'Template name is required to be of type str'



# Generated at 2022-06-23 16:29:52.237116
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/user/development/cookiecutters'
    template_name = 'Python Package'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/home/user/development/cookiecutters/Python Package.json'


# Generated at 2022-06-23 16:29:56.249934
# Unit test for function dump
def test_dump():
    """function test_dump"""
    replay_dir = 'tst_replay_dir'
    template_name = 'template_name'
    context = {'cookiecutter': {'cookiecutter': 'cookiecutter', 'project_name': 'project_name'}}
    dump(replay_dir, template_name, context)
    print("Unit test for function dump passed")


# Generated at 2022-06-23 16:29:59.026393
# Unit test for function get_file_name
def test_get_file_name():
    result = get_file_name("./", "name")
    assert result == './name.json'



# Generated at 2022-06-23 16:30:03.053088
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests/files/testsite'
    template_name = 'testsite'
    assert get_file_name(replay_dir, template_name) == 'tests/files/testsite/testsite.json'

# Generated at 2022-06-23 16:30:07.655281
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'c:\\abc\\abc'
    template_name = 'abc'
    file_name = get_file_name(replay_dir, template_name)
    print(file_name)
    assert file_name == 'c:\\abc\\abc\\abc.json'



# Generated at 2022-06-23 16:30:13.968212
# Unit test for function dump
def test_dump():
	replay_dir = 'replay_test'
	template_name = 'kickoff_test'
	context = {'cookiecutter': {'test': 'blabla'}}
	dump(replay_dir, template_name, context)
	context_loaded = load(replay_dir, template_name)
	assert context_loaded == {'cookiecutter': {'test': 'blabla'}}


# Generated at 2022-06-23 16:30:25.250834
# Unit test for function load
def test_load():
    """Unit test for function load."""

# Generated at 2022-06-23 16:30:28.021446
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "some_dir"
    template_name = "some_template"
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, template_name + '.json')

# Generated at 2022-06-23 16:30:30.934920
# Unit test for function dump
def test_dump():
    context={'cookiecutter': {'a': 1, 'b': 2, 'c': 3}}
    replay_dir = '/Users/hwu/test_test/replay'
    template_name = 'test'
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:30:36.420420
# Unit test for function dump
def test_dump():
    replay_dir = 'my_replay_dir'
    template_name = 'my_template_name'
    context = {}
    context['cookiecutter'] = {}
    dump(replay_dir, template_name, context)
    file_name = get_file_name(replay_dir,template_name)
    assert os.path.isfile(file_name)
    

# Generated at 2022-06-23 16:30:44.042561
# Unit test for function dump
def test_dump():
    """Test dump function."""
    assert dump("replay", "tests/fixtures/fake-repo-tmpl", {'cookiecutter': {'replay': True}})
    os.remove("replay/tests_fixtures_fake-repo-tmpl.json")
    assert not make_sure_path_exists("replay")
    assert make_sure_path_exists("replay")
    assert not os.path.isfile("replay/tests_fixtures_fake-repo-tmpl.json")

# Generated at 2022-06-23 16:30:47.403259
# Unit test for function load
def test_load():
    """Unit test for function load"""
    template_name = 'cookiecutter-pypackage'
    replay_file = '{}.json'.format(template_name)
    if os.path.exists(replay_file):
        loaded_context = load('.', template_name)
        assert loaded_context['cookiecutter']['project_name'] == 'Hello World'


# Generated at 2022-06-23 16:30:54.417884
# Unit test for function dump

# Generated at 2022-06-23 16:31:04.165448
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    replay_dir = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                              'test_replay'))
    template_name = 'test_template'
    context = {'cookiecutter': {'full_name': 'Test', 'email': 'test@test.com'}}


# Generated at 2022-06-23 16:31:10.593261
# Unit test for function dump
def test_dump():
    import tempfile
    context = {"cookiecutter": {}}
    with tempfile.TemporaryDirectory() as temp_dir:
        dump(temp_dir, "test_dump", context)

        replay_file = get_file_name(temp_dir, "test_dump")
        replay_context = load(temp_dir, "test_dump")



# Generated at 2022-06-23 16:31:16.137790
# Unit test for function load
def test_load():
    replay_dir = '/home/dean/Documents/University/2019/Semester_2/COSC2671/cookiecutter-django/tests/test-repo/replays'
    replay_file = get_file_name(replay_dir, 'cookiecutter-django')
    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    print(context)


# Generated at 2022-06-23 16:31:21.317120
# Unit test for function load
def test_load():
    """Test that load works"""
    replay = dict(cookiecutter=dict(hello='world', b=3))

    my_path = '/tmp'
    dump(my_path, 'test', replay)
    result = load(my_path, 'test')
    assert replay == result
    os.remove(get_file_name(my_path, 'test'))

# Generated at 2022-06-23 16:31:29.049174
# Unit test for function get_file_name
def test_get_file_name():
    abs_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'tests', 'test-replay')
    replay_dir = abs_path 
    template_name = 'test-template'
    test_file = get_file_name(replay_dir, template_name)
    assert(test_file == os.path.join(abs_path, 'test-template.json'))

    template_name = 'test-template.json'
    test_file = get_file_name(replay_dir, template_name)
    assert(test_file == os.path.join(abs_path, 'test-template.json'))


# Generated at 2022-06-23 16:31:31.804905
# Unit test for function load
def test_load():
    """Unit test for function load"""
    replay_dir = ".cookiecutters"
    template_name = "audreyr/cookiecutter-pypackage"
    load(replay_dir, template_name)



# Generated at 2022-06-23 16:31:34.640484
# Unit test for function dump
def test_dump():
    dir = './tests/test-output/'
    dump(dir, 'test.json', {'cookiecutter': {'foo': 'bar'}})
    assert os.path.isfile('./tests/test-output/test.json')


# Generated at 2022-06-23 16:31:43.561268
# Unit test for function dump
def test_dump():
    import shutil
    try:
        replay_dir = '/tmp/cookiecutter'
        template_name = 'example_repo'
        context = {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld', 'email': 'audreyr@example.com'}}

        dump(replay_dir, template_name, context)

        assert os.path.exists(replay_dir)
        assert os.path.exists(get_file_name(replay_dir, template_name))
    finally:
        shutil.rmtree(replay_dir)


# Generated at 2022-06-23 16:31:50.047567
# Unit test for function dump
def test_dump():
    """Test dump function."""
    import tempfile

    template_name='hello'
    replay_dir = tempfile.mkdtemp()
    dump(replay_dir, template_name, {'cookiecutter': {'name':'go'}})
    expected_file_name = os.path.join(replay_dir, 'hello.json')
    assert os.path.exists(expected_file_name)



# Generated at 2022-06-23 16:31:51.783076
# Unit test for function load
def test_load():
    assert(load("replay", "default") == {"cookiecutter": {}})

# Generated at 2022-06-23 16:32:02.148648
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'abc'
    result = get_file_name('replay_dir', template_name)
    assert result == 'replay_dir/abc.json'
    template_name = 'xxx.json'
    result = get_file_name('replay_dir', template_name)
    assert result == 'replay_dir/xxx.json'
    template_name = 'xxx.json.json.json'
    result = get_file_name('replay_dir', template_name)
    assert result == 'replay_dir/xxx.json.json.json.json'
    template_name = 'xxx.j'
    result = get_file_name('replay_dir', template_name)
    assert result == 'replay_dir/xxx.j.json'

# Generated at 2022-06-23 16:32:05.631967
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = './'
    template_name = 'template1'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-23 16:32:08.895899
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "replay_dir"
    template_name = "name.json"
    assert get_file_name(replay_dir, template_name) == "replay_dir/name.json"


# Generated at 2022-06-23 16:32:13.302755
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    template_name = 'foo'
    replay_dir = '/tmp'
    expected_file_name = '/tmp/foo.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == expected_file_name


# Generated at 2022-06-23 16:32:18.399293
# Unit test for function get_file_name
def test_get_file_name():
    dir_path = 'test_replay_dir'
    template_name = 'test'
    file_name = get_file_name(dir_path, template_name)
    assert file_name == os.path.join(dir_path, template_name + '.json')


# Generated at 2022-06-23 16:32:27.842520
# Unit test for function dump
def test_dump():
    from contextlib import contextmanager
    from io import StringIO
    from tempfile import TemporaryDirectory

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:32:33.225691
# Unit test for function dump
def test_dump():
    replay_dir='/home/khurram/Desktop/cookiecutter/cookiecutter-sample-template/test'
    template_name='test_temp_name'
    context={'cookiecutter': {'first_name': 'test', 'last_name': 'test'}}
    dump(replay_dir=replay_dir,template_name=template_name,context=context)
    assert True


# Generated at 2022-06-23 16:32:36.394586
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test'
    template_name = 'template_name'
    assert get_file_name(replay_dir, template_name) == 'test/template_name.json'


# Generated at 2022-06-23 16:32:46.438294
# Unit test for function dump
def test_dump():
    """ Test for function dump. """
    replay_dir = './tests/fixtures/replay'
    template_name = 'fake'
    context = {'cookiecutter': {'project_name': 'testingfileio', 'repo_name': 'testingfileio'}}
    dump(replay_dir, template_name, context)
    # Load and test fucntion test_load to see if file is saved with correct info
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'testingfileio'
    # delete testing file
    replay_file = get_file_name(replay_dir, template_name)
    os.remove(replay_file)

# Generated at 2022-06-23 16:32:54.655687
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay-dir', 'template-name') == 'replay-dir/template-name.json'
    assert get_file_name('replay-dir', 'template-name.json') == 'replay-dir/template-name.json'
    assert get_file_name('../replay-dir', 'template-name') == '../replay-dir/template-name.json'
    assert get_file_name('replay-dir/', '/template-name') == 'replay-dir//template-name.json'



# Generated at 2022-06-23 16:33:00.645948
# Unit test for function dump
def test_dump():
    dump("temp_dir", "test_template", {
        "cookiecutter": {
            "full_name": "Nathaniel J. Smith",
            "email": "nathaniel@njs.net",
            "project_name": "my-new-project"
        }
    })



# Generated at 2022-06-23 16:33:03.569954
# Unit test for function load
def test_load():
    assert load('/Users/nikunjlad/Code/cookiecutter.replay/cookiecutter/replay', 'python_django') is not None


# Generated at 2022-06-23 16:33:08.701424
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/tmp/'
    template_name = 'project_name'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '{}{}.json'.format(replay_dir, template_name)

# Generated at 2022-06-23 16:33:15.964934
# Unit test for function load
def test_load():

    replay_dir = './replay'
    template_name = 'cookiecutter-pypackage'
    
    replay_file = get_file_name(replay_dir, template_name)
    
    with open(replay_file) as infile:
        context = json.load(infile)
        
    assert 'cookiecutter' in context

    return context



# Generated at 2022-06-23 16:33:21.910064
# Unit test for function load
def test_load():
    import os, shutil
    os.system("mkdir -p ~/Desktop/test")
    os.system("cp replay ~/Desktop/test")
    replay_dir = "~/Desktop/test"
    template_name = "replay"

    try:
        context = load(replay_dir, template_name)
        print(context)
        assert('cookiecutter' in context)
    except Exception as e:
        print(e)
    finally:
        shutil.rmtree(os.path.expanduser(replay_dir))

if __name__ == '__main__':
    test_load()