

# Generated at 2022-06-23 16:23:20.312212
# Unit test for function dump
def test_dump():
    replay_dir = 'C:\\Users\\shihao\\Desktop'
    template_name = 'test'
    context = {'cookiecutter':{'code_language':'python3'}}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-23 16:23:22.036419
# Unit test for function load
def test_load():
    load('~/.cookiecutters/', 'cookiecutter-pypackage')


# Generated at 2022-06-23 16:23:28.763844
# Unit test for function dump
def test_dump():
    """docstring for test_dump."""
    # Arrange
    test_template_name = 'mytemplate'
    test_context = {
        'cookiecutter':
        {
            'replay_dir': 'replay',
            'cookiecutter_dict':
            {
                'testvar': 'test'
            },
            'default_context':
            {
                'foo': 'bar'
            }
        }
    }

    # Act
    dump(test_context['cookiecutter']['replay_dir'], test_template_name,
         test_context)

    # Assert
    # Replay file exists
    assert os.path.exists(
        os.path.join('./replay', test_template_name + '.json')
    )

    # Replay file is readable

# Generated at 2022-06-23 16:23:30.483561
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = 'Test'
    result = get_file_name(replay_dir, template_name)
    expected = './Test.json'

    assert result == expected


# Generated at 2022-06-23 16:23:38.933747
# Unit test for function load
def test_load():
    # setup replay file for unittest
    template_name = 'python-package'
    replay_dir = 'cc_tests/tests/test-load-replay'
    replay_file = '{}/{}.json'.format(replay_dir, template_name)

    replay_context = {}

# Generated at 2022-06-23 16:23:43.699665
# Unit test for function dump
def test_dump():
    """Test the function dump."""
    import tempfile
    temp_replay_dir = tempfile.mkdtemp()
    template_name = 'testing_template'
    context = {'key': 'value', 'cookiecutter':{'a':1, 'b':2}}
    dump(temp_replay_dir, template_name, context)
    assert load(temp_replay_dir, template_name) == context



# Generated at 2022-06-23 16:23:52.822204
# Unit test for function load
def test_load():
    replay_dir = pjoin('tests', 'test-load')
    template_name = 'test-load'

    # Test file does not exist
    try:
        load(replay_dir, template_name)
        assert False
    except IOError:
        pass

    # Test normal case
    context = {'cookiecutter': {'name': 'test'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    assert context == load(replay_dir, template_name + '.json')



# Generated at 2022-06-23 16:24:01.354965
# Unit test for function get_file_name
def test_get_file_name():
    template_name = "template_name"
    replay_dir = os.path.expanduser('.')
    file_name = template_name + ".json"
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name)

    template_name = "template_name.json"
    replay_dir = os.path.expanduser('.')
    file_name = template_name
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name)


# Generated at 2022-06-23 16:24:05.106055
# Unit test for function load
def test_load():
    assert load('.','cookiecutter')
    assert not load('',"cookiecutter")
    assert not load('','cookiecutter')
    assert not load('./','cookiecutter')
    assert not load('../','cookiecutter')

# Generated at 2022-06-23 16:24:13.604628
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name(r'C:\User\Documents\Git\cookiecutter-project', 'cookiecutter-poject') == r'C:\User\Documents\Git\cookiecutter-project\cookiecutter-poject.json'
    assert get_file_name(r'C:\User\Documents\Git\cookiecutter-project', 'cookiecutter-poject.json') == r'C:\User\Documents\Git\cookiecutter-project\cookiecutter-poject.json'
    assert get_file_name('C:\\User\\Documents\\Git\\cookiecutter-project', 'cookiecutter-poject') == 'C:\\User\\Documents\\Git\\cookiecutter-project\\cookiecutter-poject.json'

# Generated at 2022-06-23 16:24:17.539575
# Unit test for function load
def test_load():
    test_context = {"cookiecutter": {"first_name": "YourFirstNameHere", "last_name": "YourLastNameHere"}}
    test_data = load("tests/test-data/replay/", "bionic-python")
    assert test_data == test_context


# Generated at 2022-06-23 16:24:23.045010
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('./', 'foo') == './foo.json'
    assert get_file_name('./', 'foo.json') == './foo.json'
    assert get_file_name('/tmp', 'foo') == '/tmp/foo.json'
    assert get_file_name('/tmp', 'foo.json') == '/tmp/foo.json'

# Generated at 2022-06-23 16:24:26.043330
# Unit test for function load
def test_load():
    context = load("/home/jannis/.cookiecutters", "test_load")
    if 'cookiecutter' in context and 'project_name' in context['cookiecutter']:
        print("it worked")
    else:
        print("it dindt work")



# Generated at 2022-06-23 16:24:28.608733
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests/replay'
    template_name = 'tests/fake-repo-pre/'
    assert get_file_name(replay_dir, template_name) == 'tests/replay/fake-repo-pre.json'


# Generated at 2022-06-23 16:24:41.326741
# Unit test for function load
def test_load():
    """Unit test for load"""
    if '{{cookiecutter.repo_name}}' == 'replace_me_repo_name':
        # use repo name as a switch to decide whether to run unit test
        # unit test should be run with a new repository
        return
    from tempfile import mkdtemp
    from shutil import rmtree
    import os
    import json
    import sys

    repo_name = '{{cookiecutter.repo_name}}'
    template_name = '{{cookiecutter.github_repo_name}}'
    cookiecutter_dict = {'cookiecutter': {'repo_name': repo_name}}
    replay_dir = mkdtemp(dir=os.getcwd())
    dump(replay_dir, template_name, cookiecutter_dict)
    response = load

# Generated at 2022-06-23 16:24:50.471533
# Unit test for function dump
def test_dump():
	# Test case 1: replay_dir doesn't exist
	replay_dir = 'test_replay'
	template_name = 'test_template'
	context = {'cookiecutter': {'foo': 'bar', 'baz': 'qux'}}
	
	# If replay_dir doesn't exist, should create replay_dir and dump context
	dump(replay_dir, template_name, context)
	assert os.path.isdir(replay_dir)
	
	# Test case 2: replay_dir exists
	replay_dir = 'test_replay'
	template_name = 'test2_template'
	context = {'cookiecutter': {'foo': 'bar', 'baz': 'qux'}}
	
	# If replay_dir exists, should not create replay_dir or dump context
	

# Generated at 2022-06-23 16:24:56.375374
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/replay'
    template_name = 'foobar'
    context = {
        'cookiecutter': {
            '_template': template_name,
            'full_name': 'Jane Doe',
        }
    }
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-23 16:24:59.874284
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test to check the function get_file_name"""
    assert get_file_name('replay_dir', 'template_name') == 'replay_dir/template_name.json'
    assert get_file_name('replay_dir', 'template_name.json') == 'replay_dir/template_name.json'


# Generated at 2022-06-23 16:25:00.729203
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-23 16:25:05.864756
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('a', 'b') == 'a/b.json'
    assert get_file_name('a', 'b.json') == 'a/b.json'
    assert get_file_name('a/c', 'b') == 'a/c/b.json'
    assert get_file_name('a/c', 'b.json') == 'a/c/b.json'
    assert get_file_name('a/c/', 'b') == 'a/c/b.json'
    assert get_file_name('a/c/', 'b.json') == 'a/c/b.json'

# Generated at 2022-06-23 16:25:09.286000
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'my_template'
    replay_file = get_file_name(replay_dir = "replay_dir", template_name = template_name)
    assert replay_file == "replay_dir/my_template.json"


# Generated at 2022-06-23 16:25:13.052946
# Unit test for function load

# Generated at 2022-06-23 16:25:18.517252
# Unit test for function load
def test_load():
    """Test load function."""
    import tempfile
    # Create replay_dir and context file for testing
    tmp_dir = tempfile.mkdtemp()
    replay_dir = os.path.join(tmp_dir, ".cookiecutters_replay")
    template_name = "basic_data_science"

# Generated at 2022-06-23 16:25:25.487857
# Unit test for function get_file_name
def test_get_file_name():
    """Test for get_file_name function."""
    template_name = 'my_template'
    replay_dir = 'my_replay_dir'
    expected_file_name = 'my_replay_dir/my_template.json'
    actual_file_name = get_file_name(replay_dir, template_name)
    assert actual_file_name == expected_file_name


# Generated at 2022-06-23 16:25:28.625504
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for get_file_name function."""
    path = get_file_name("~/replay", "test")
    assert path == os.path.join("~/replay", "test.json")



# Generated at 2022-06-23 16:25:37.148737
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name()."""
    # Scenario 1: Replay file name without path and without .json extension
    # Expected: replay path with .json extension added
    replay_dir = os.path.expanduser('~/.cookiecutters')
    template_name = 'my_template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == template_name + '.json', "Template name is wrong"

    # Scenario 2: Replay file name with path and without .json extension
    # Expected: replay path with .json extension added
    replay_dir = os.path.expanduser('~/temp')
    template_name = 'my_template'
    file_name = get_file_name(replay_dir, template_name)

# Generated at 2022-06-23 16:25:42.900712
# Unit test for function dump
def test_dump():
    """Test function dump."""
    from tempfile import mkdtemp
    from shutil import rmtree

    tmp_dir = mkdtemp()

    try:
        dump(tmp_dir, 'dummy_project', {'cookiecutter': 'metadata'})
        assert True
    except:
        assert False
    rmtree(tmp_dir)



# Generated at 2022-06-23 16:25:46.583777
# Unit test for function load
def test_load():
    context = load('/tmp/cookiecutter-replay', 'template1')
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

# Generated at 2022-06-23 16:25:51.687251
# Unit test for function dump
def test_dump():
    """."""
    try:
        context = {'cookiecutter': {'replay': True}}
        replay_dir = '/tmp/cc/'
        dump(replay_dir, 'test', context)
        loaded_context = load(replay_dir, 'test')
        assert loaded_context == context
    except IOError:
        assert False
    except TypeError:
        assert False
    except ValueError:
        assert False

# Generated at 2022-06-23 16:26:00.625567
# Unit test for function dump
def test_dump():
    replay_dir = '/tmp'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:26:06.098033
# Unit test for function load
def test_load():
    """Test function load."""
    template_current_dir = os.path.dirname(os.path.abspath(__file__))
    template_name = "test_file"
    file_name = get_file_name(template_current_dir, template_name)
    context = {'cookiecutter': {'replay': True}}
    with open(file_name, 'w') as outfile:
        json.dump(context, outfile, indent=2)
    context = load(template_current_dir, template_name)
    assert context == {'cookiecutter': {'replay': True}}



# Generated at 2022-06-23 16:26:12.577559
# Unit test for function get_file_name
def test_get_file_name():
    """Function test for function get_file_name()"""
    import os

    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    temp_name = 'foo'
    file_name = 'foo.json'
    file_path = os.path.join(replay_dir, file_name)
    assert file_path == get_file_name(replay_dir, temp_name)


# Generated at 2022-06-23 16:26:16.364468
# Unit test for function load
def test_load():
    result = load('C:\\Users\\user\\AppData\\Local\\cookiecutter\\replay', 'C:\\Users\\user\\Desktop\\test_load\\test_load.json')
    print(result)
    
    

# Generated at 2022-06-23 16:26:19.724999
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test'
    template_name = 'test'
    ans = 'test/test.json'
    got = get_file_name(replay_dir, template_name)
    assert ans == got

# Generated at 2022-06-23 16:26:22.472875
# Unit test for function load
def test_load():
    load("/home/jimmy/code/pocc/cookiecutter/cookiecutter", "unknown")



# Generated at 2022-06-23 16:26:29.906617
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = "tests/test-load"
    template_name = "test-load"
    # test without 'cookiecutter' in loaded context
    try:
        load(replay_dir, template_name)
        assert False
    except ValueError:
        assert True

    # test with 'cookiecutter' in loaded context
    template_name = "test-load-with-cookiecutter"
    context = load(replay_dir, template_name)
    assert "cookiecutter" in context


# Generated at 2022-06-23 16:26:35.486365
# Unit test for function dump
def test_dump():
    replay_dir = 'test'
    template_name = 'test'
    context = {
        'cookiecutter': {
            'full_name': 'Filip Dąbrowski'
        }
    }

    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)

    assert loaded_context == context

# Generated at 2022-06-23 16:26:41.096119
# Unit test for function load
def test_load():
    """Test load."""
    _replay_dir = os.path.abspath(os.path.join(os.getcwd(), os.pardir))
    _file_name = 'cookiecutter-pypackage'
    _context = load(_replay_dir, _file_name)
    print(_context)

# Generated at 2022-06-23 16:26:44.159962
# Unit test for function load
def test_load():
    template_name = 'https://github.com/audreyr/cookiecutter-pypackage'
    replay_dir = 'C:\\Users\\Jasper\\PycharmProjects\\king-cookie\\replay'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context

# Generated at 2022-06-23 16:26:52.376608
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    from cookiecutter.main import cookiecutter
    import tempfile

    temp_path = tempfile.mkdtemp()
    template_name = 'dummy_template'
    template_path = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fake-repo-pre')
    template_url = 'file://{}'.format(template_path)

    def gen_context():
        """Generate context."""
        context = cookiecutter(
            template_url,
            no_input=True,
            replay_dir=temp_path,
            output_dir=temp_path,
            overwrite_if_exists=True
        )
        return context

    context = gen_context()

    # Check dump replay file

# Generated at 2022-06-23 16:26:55.899838
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/Users/Tom/Desktop/cookiecutter-jQuery/replay'
    template_name = 'jquery_plugin'
    file_name = 'jquery_plugin.json'
    assert file_name == get_file_name(replay_dir, template_name)


# Generated at 2022-06-23 16:27:05.485750
# Unit test for function dump
def test_dump():
    replay_dir = '../tests/replay/'
    template_name = 'cookiecutter-pypackage'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'project_name': 'My Test Project',
            'repo_name': 'mytestproject',
            'project_slug': 'mytestproject',
            'project_short_description': 'A short description of my project.',
            'version': '0.1.0',
            'release': '0.1.0',
            'timezone': 'UTC',
            'project_license': 'BSD license'
        }
    }

# Generated at 2022-06-23 16:27:10.058117
# Unit test for function load
def test_load():
    replay_dir = "replay_tests/tests"
    template_name = "tmpqNvDH"
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:27:15.745857
# Unit test for function load
def test_load():
    replay_dir = 'tests/files/test-replay'
    template_name = 'example'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['full_name'] == 'Audrey Roy Greenfeld'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'


# Generated at 2022-06-23 16:27:24.026621
# Unit test for function dump
def test_dump():
    context = dict()
    context['cookiecutter'] = dict()
    context['cookiecutter']['full_name'] = 'Fabien'
    context['cookiecutter']['email'] = 'fabien@linux.com'
    context['extra_context'] = dict()
    context['extra_context']['university'] = 'EPFL'
    context['extra_context']['department'] = 'IC'
    dump('/tmp', 'replay_test', context)
    assert os.path.isfile('/tmp/replay_test.json') == True


# Generated at 2022-06-23 16:27:26.021082
# Unit test for function load
def test_load():
    context= load("",'demo')
    assert context['cookiecutter'] !='demo'
    assert context['cookiecutter'] !='demo/json'


# Generated at 2022-06-23 16:27:32.006708
# Unit test for function dump
def test_dump():
    """Test ccc to dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'test-dump'
    context = {
            'cookiecutter': {
                'full_name': "Paul Finch",
                'email': "paul@example.com",
                'github_username': "paulfinch",
                'replay_dir': replay_dir,
                'template_name': template_name,
                'replay': True
            }
        }
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))



# Generated at 2022-06-23 16:27:35.984917
# Unit test for function load
def test_load():
    replay_dir="/tmp"
    template_name="test"
    try:
        load(replay_dir, template_name)
    except ValueError:
        return True
    return False


# Generated at 2022-06-23 16:27:41.132501
# Unit test for function get_file_name
def test_get_file_name():
    ret = get_file_name('.', '.json')
    assert ret == '.json.json'
    ret = get_file_name('.', 'json')
    assert ret == 'json.json'
    ret = get_file_name('.', 'json.json')
    assert ret == 'json.json.json'

# Generated at 2022-06-23 16:27:46.267364
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'someplace'
    template_name = 'project_name'

    file_name = 'project_name.json'
    # check that expected file_name is the same as the actual file_name
    assert get_file_name(replay_dir, template_name) == file_name, \
        'Error: function get_file_name returned the wrong file_name'


# Generated at 2022-06-23 16:27:52.314482
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "test_dir1"
    template_name = "test_template"
    replay_file = "test_dir1/test_template.json"
    assert get_file_name(replay_dir, template_name) == replay_file


# Generated at 2022-06-23 16:28:02.882908
# Unit test for function dump
def test_dump():
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    context = {'cookiecutter': {'a': 'b'}}

    dump(replay_dir, template_name, context)

    assert os.path.exists(get_file_name(replay_dir, template_name)) is True

    os.remove(get_file_name(replay_dir, template_name))
    assert os.path.exists(get_file_name(replay_dir, template_name)) is False

    os.rmdir(replay_dir)
    assert os.path.exists(replay_dir) is False



# Generated at 2022-06-23 16:28:05.482573
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    assert get_file_name('replay_dir', 'template_name') == 'replay_dir/template_name.json'
    assert get_file_name('replay_dir', 'template_name.json') == 'replay_dir/template_name.json'

# Generated at 2022-06-23 16:28:12.326385
# Unit test for function get_file_name
def test_get_file_name():
    '''Test unit get_file_name.'''
    file_name = get_file_name('target', 'test')
    assert file_name == 'target/test.json'

    file_name = get_file_name('target/', 'test')
    assert file_name == 'target/test.json'

    file_name = get_file_name('/target', 'test')
    assert file_name == '/target/test.json'

    file_name = get_file_name('/target/', 'test')
    assert file_name == '/target/test.json'

    file_name = get_file_name('target', 'test.json')
    assert file_name == 'target/test.json'

    file_name = get_file_name('target/', 'test.json')
    assert file_name

# Generated at 2022-06-23 16:28:16.516709
# Unit test for function load
def test_load():
    temp_dir = "/Users/maxmarsden/cookiecutter_test"
    template_name = "python_cli"
    r = load(temp_dir, template_name)
    print(r)


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:28:22.816487
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.dir_name}}') 
    template_name = '{{cookiecutter.dir_name}}'
    expected_file_name = os.path.join(replay_dir, template_name) + '.json'
    assert get_file_name(replay_dir, template_name) == expected_file_name


# Generated at 2022-06-23 16:28:29.903029
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/Users/gunjan/cookiecutter-data-science/tmp_replay/"
    template_name1 = "cookiecutter-data-science"
    template_name2 = "cookiecutter-data-science.json"
    assert(get_file_name(replay_dir, template_name1) == "/Users/gunjan/cookiecutter-data-science/tmp_replay/cookiecutter-data-science.json")
    assert(get_file_name(replay_dir, template_name2) == "/Users/gunjan/cookiecutter-data-science/tmp_replay/cookiecutter-data-science.json")

# Generated at 2022-06-23 16:28:38.336281
# Unit test for function get_file_name
def test_get_file_name():
    # test with  existing directory
    replay_dir = "/tmp"
    template_name = "template"
    # Test with non existant directory
    replay_dir1 = "/tmp/vivek"
    template_name1 = "template1"
    # Test with empty directory
    replay_dir2 = ""
    template_name2 = "template2"
    assert(get_file_name(replay_dir, template_name) == "/tmp/template.json")
    assert(get_file_name(replay_dir1, template_name1) == "/tmp/vivek/template1.json" and os.path.isdir("/tmp/vivek"))
    assert(get_file_name(replay_dir2, template_name2) == "/template2.json")
    

# Generated at 2022-06-23 16:28:43.789004
# Unit test for function get_file_name
def test_get_file_name():
    """ Test the get_file_name function"""
    #assert get_file_name("test","test") == "test/test.json"
    #assert get_file_name("test","test.json") == "test/test.json"
    assert get_file_name('test', 'test.json') == 'test/test.json'
    assert get_file_name('test', 'test') == 'test/test.json'


# Generated at 2022-06-23 16:28:50.478199
# Unit test for function load
def test_load():
    from cookiecutter.replay import load
    from mock import patch

    template_name = 'mock_template'

    @patch('cookiecutter.replay.json')
    def mock_load(context, mock_json):
        mock_json.load.return_value = context
        context = load('mock_dir', template_name)
        return context

    # Test if context is retured from function
    context = {'cookiecutter': {'key': 'value'}}
    returned_context = mock_load(context)
    assert returned_context == context

    # Test if TypeError is raised if template name is not a string
    try:
        mock_load({'cookiecutter': {'key': 'value'}}, template_name=None)
    except TypeError:
        pass
    else:
        raise Ass

# Generated at 2022-06-23 16:28:53.811119
# Unit test for function load
def test_load():
    TemplateName = 'template'
    ReplayDir = './'
    Response = load(ReplayDir, TemplateName)
    print(Response)


# Generated at 2022-06-23 16:28:57.785899
# Unit test for function dump
def test_dump():
	dump('/tmp/', 'replay_test', {'replay_test': {'replay_test': 'replay_test'}})


# Generated at 2022-06-23 16:29:00.708897
# Unit test for function get_file_name
def test_get_file_name():
    name = 'test.json'
    expected_name = 'test.json'
    assert(get_file_name('/tmp', name) == expected_name)


# Generated at 2022-06-23 16:29:05.306397
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = '../cookiecutter'
    template_name = 'json_test'
    context = {'cookiecutter': {'name': 'chaos'}}
    dump(replay_dir, template_name, context)


if __name__ == "__main__":
    test_dump()

# Generated at 2022-06-23 16:29:09.757081
# Unit test for function load
def test_load():
    try:
        "Successfully load"
        load("Tests/fixtures/replay", 'test')
    except TypeError:
        "Failed to load"
        assert False
    assert True

# Generated at 2022-06-23 16:29:14.281268
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/test'
    template_name = 'template'
    assert (get_file_name(replay_dir, template_name) == '/home/test/template.json')

    template_name = 'template.json'
    assert (get_file_name(replay_dir, template_name) == '/home/test/template.json')

# Generated at 2022-06-23 16:29:23.942571
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir1 = 'replay-dir'
    template_name1 = 'template-name'
    replay_file_name1 = get_file_name(replay_dir1, template_name1)
    assert(replay_file_name1 == 'replay-dir/template-name.json')

    replay_dir2 = 'replay-dir'
    template_name2 = 'template-name.json'
    replay_file_name2 = get_file_name(replay_dir2, template_name2)
    assert(replay_file_name2 == 'replay-dir/template-name.json')


# Generated at 2022-06-23 16:29:25.977098
# Unit test for function load
def test_load():
    replay_dir = os.getcwd()
    template_name = "test"
    ans = load(replay_dir, template_name)

# Generated at 2022-06-23 16:29:28.604397
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {}}
    template_name='test'
    replay_dir='./replay'
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))


# Generated at 2022-06-23 16:29:37.525342
# Unit test for function dump
def test_dump():
    from cookiecutter import config
    import shutil
    replay_path = os.path.join(config.USER_HOME, 'cookiecutters_replay')

    if os.path.exists(replay_path):
        shutil.rmtree(replay_path)

    assert make_sure_path_exists(replay_path)

    try:
        dump(replay_path, 'foo', {'cookiecutter': {'name': 'foo'},
             'cookiecutter_replay': 'bar'})
    except Exception:
        raise
    else:
        shutil.rmtree(replay_path)


# Generated at 2022-06-23 16:29:44.746855
# Unit test for function load
def test_load():
    with open('./cookiecutter_replay_tests/file.json', 'r') as f:
        config = json.load(f)
    context = load('./cookiecutter_replay_tests', 'file')
    test_passed = True
    for k, v in config.iteritems():
        if isinstance(v, dict):
            for k2, v2 in v.iteritems():
                if v2 != context[k][k2]:
                    test_passed = False
                    break
        elif v != context[k]:
            test_passed = False

    assert test_passed == True


# Generated at 2022-06-23 16:29:48.146347
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = 'foobar'
    file_name = get_file_name(replay_dir, template_name)
    assert(file_name == './foobar.json')

# Generated at 2022-06-23 16:29:50.871568
# Unit test for function get_file_name
def test_get_file_name():
    a = get_file_name('home/pramod','pramod')
    assert a == 'home/pramod/pramod.json'



# Generated at 2022-06-23 16:29:53.005620
# Unit test for function load
def test_load():
    """Unit test for function load."""
    try:
        load('replays', 'foobar')
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-23 16:30:00.020043
# Unit test for function load

# Generated at 2022-06-23 16:30:04.302173
# Unit test for function load
def test_load():
    replay_dir = 'test_cookiecutter'
    template_name = 'django_project'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Django Project'

# Generated at 2022-06-23 16:30:11.607815
# Unit test for function dump
def test_dump():
    """Unit test for function dump"""
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    context = {'key': 'value'}
    template_name = 'foobar'
    dump(tmp_dir, template_name, context)
    ret = load(tmp_dir, template_name)
    assert context == ret
    os.removedirs(tmp_dir)

if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-23 16:30:15.290194
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('test_replay_dir', 'test_template_name') == 'test_replay_dir/test_template_name.json'

    assert get_file_name('test_replay_dir', 'test_template_name.json') == 'test_replay_dir/test_template_name.json'



# Generated at 2022-06-23 16:30:17.636914
# Unit test for function load
def test_load():
    """Unit Test"""
    load('/home/sushant/Cookiecutter/test/test_project', 'hello_world')

# Generated at 2022-06-23 16:30:28.074950
# Unit test for function load
def test_load():
    os.chdir('tests/files')
    ### 
    template_name = 'fake_repo_pre/'
    replay_dir = '../fake-repo/'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    ### 
    template_name = '.pre/'
    replay_dir = '../fake-repo/'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    ### 
    template_name = '.pre/'
    replay_dir = '../fake-repo/'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)

# Generated at 2022-06-23 16:30:31.128890
# Unit test for function load
def test_load():
    context = load(replay_dir = "/Users/vincentsu/Downloads/cookiecutter-pypackage-minimal/cookiecutter.json",
    template_name = "cookiecutter-pypackage-minimal")
    assert (context["cookiecutter"]["full_name"] == "Vincent Su")

# Generated at 2022-06-23 16:30:33.258913
# Unit test for function load
def test_load():
    """Test for function load."""
    context = load("/home/dongzhihui/Workspace/github/cookiecutter/tests/test_files", "config.json")



# Generated at 2022-06-23 16:30:41.223452
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/replay/'
    template_name = '{{ cookiecutter.repo_name }}'
    context = {'cookiecutter': {'repo_name': 'pydata-cheatsheets'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile('tests/files/replay/pydata-cheatsheets.json') == True
    os.remove('tests/files/replay/pydata-cheatsheets.json')


# Generated at 2022-06-23 16:30:44.223075
# Unit test for function load
def test_load():
    # Simplest test case
    context = load('.', 'cookiecutter-pypackage')
    test_file_path = 'tests/test_cookiecutter_replay_load.json'
    with open(test_file_path) as data_file:
        test_data = json.load(data_file)

    assert context == test_data
    

# Generated at 2022-06-23 16:30:52.471975
# Unit test for function dump
def test_dump():
    tmp_dir_obj = TemporaryDirectory()
    tmp_dir = tmp_dir_obj.name
    template_name = 'test_template'
    context = {
        'cookiecutter': {
            'repo_dir': '.',
            'extra_context': {
                'full_name': 'Alfred E. Neuman',
                'email': 'alfred@mgzn.com',
                'github_username': 'alfredneuman',
            },
        }
    }
    dump(tmp_dir, template_name, context)
    file_path = os.path.join(tmp_dir, '{}.json'.format(template_name))
    assert os.path.exists(file_path)
    tmp_dir_obj.cleanup()


# Generated at 2022-06-23 16:30:56.643892
# Unit test for function get_file_name
def test_get_file_name():
    result = get_file_name("path/to/dir", "name")
    assert(result) == "path/to/dir/name.json"

    result = get_file_name("path/to/dir", "name.json")
    assert(result) == "path/to/dir/name.json"


# Generated at 2022-06-23 16:31:04.891262
# Unit test for function load
def test_load():
    template_name = "test_load"
    replay_dir = "/Users/daniel/Desktop/cookiecutter-dagster-module"

    context = {
        "cookiecutter": {
            "project_slug": "test_load",
            "project_name": "test_load",
            "author_name": "Dan",
            "email": "",
            "description": "",
            "version": "0.1.0",
            "open_source_license": "Apache Software License 2.0"
        }
    }

    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context



# Generated at 2022-06-23 16:31:09.880362
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output'
    template_name = 'test'
    context = {
        'cookiecutter': {
            'pymodule_name': 'pym',
            'pymodule_path': 'pym',
            'full_name': 'First Last',
            'email': 'user@example.com'
        }
    }
    dump(replay_dir, template_name, context)
    # Load data again and check it
    context2 = load(replay_dir, template_name)
    if context != context2:
        raise ValueError('Dumped and loaded contexts are not equal')



# Generated at 2022-06-23 16:31:12.024655
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.expanduser('~/.cookiecutters/replay')
    template_name = 'test_template'

    file_name = get_file_name(replay_dir, template_name)

    assert file_name == os.path.join(replay_dir, template_name + '.json'), 'File name is not correct'

# Generated at 2022-06-23 16:31:18.212656
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'some_path'
    template_name = 'template_name'

    expected = os.path.join(replay_dir, template_name + '.json')

    actual = get_file_name(replay_dir, template_name)

    assert expected == actual



# Generated at 2022-06-23 16:31:21.027202
# Unit test for function load
def test_load():
    context = load("replay", "cookiecutter-pypackage")
    print(context['cookiecutter']['project_name'])


# Generated at 2022-06-23 16:31:22.371806
# Unit test for function load
def test_load():
    context = load("/Users/Shubh/.cookiecutters","django_project")
    print(context)

# Generated at 2022-06-23 16:31:27.528211
# Unit test for function get_file_name
def test_get_file_name():
    test_dict = {
        'replay_dir': 'tests/data/not_a_path',
        'template_name': 'example',
        'expected_result': 'tests/data/not_a_path/example.json',
    }
    assert get_file_name(
        test_dict['replay_dir'],
        test_dict['template_name']
    ) == test_dict['expected_result']

# Generated at 2022-06-23 16:31:31.688076
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    assert get_file_name('', 'doop') == 'doop.json'
    assert get_file_name('', 'doop.json') == 'doop.json'
    assert get_file_name('p', 'doop') == os.path.join('p', 'doop.json')
    assert get_file_name('p', 'doop.json') == os.path.join('p', 'doop.json')

# Generated at 2022-06-23 16:31:34.539121
# Unit test for function load
def test_load():
    replay_dir = '/home/howard'
    template_name = 'python_boilerplate'
    template_name = get_file_name(replay_dir, template_name)
    load(replay_dir, template_name)


# Generated at 2022-06-23 16:31:46.198611
# Unit test for function load
def test_load():
    replay_dir = '/home/pratika/cookiecutter-pypackage-min/cookiecutter-pypackage-min'
    template_name = '{{cookiecutter.project_slug}}'

# Generated at 2022-06-23 16:31:50.305544
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('test_dir', 'test_name.json') == 'test_dir/test_name.json'
    assert get_file_name('test_dir', 'test_name') == 'test_dir/test_name.json'

# Generated at 2022-06-23 16:31:52.450302
# Unit test for function load
def test_load():
    data = load(os.path.expanduser('~/Desktop/macro_analysis/cookiecutter'), 'cookiecutter.json')
    print(data)


# Generated at 2022-06-23 16:32:02.178119
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join("C:\\", "Users", "someone", "cookiecutter-test")

    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    template_name = "json_example"
    context = {"cookiecutter": {"a": "b", "c": "d"}}

    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'r') as infile:
        data = json.load(infile)

    assert data == context



# Generated at 2022-06-23 16:32:12.541026
# Unit test for function dump
def test_dump():
    # test file name
    assert os.path.join('.', 'test_template.json') == get_file_name('.', 'test_template')
    assert os.path.join('.', 'test_template.json') == get_file_name('.', 'test_template.json')

    # test dump
    replay_dir = 'test_replay'
    template_name = 'test_template'
    context = {'cookiecutter': {'test_key': 'test_value'}}
    dump(replay_dir, template_name, context)

    # test load
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter': {'test_key': 'test_value'}}


if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-23 16:32:19.366951
# Unit test for function load
def test_load():
    """Unit test for function load"""
    context = load("/home/shawn/projects/cookiecutter-pypackage", "cookiecutter.json")
    print("\nContext: ")
    print(context)
    print("\nContext[cookiecutter]")
    print(context["cookiecutter"])


if __name__ == "__main__":
    test_load()

# Generated at 2022-06-23 16:32:22.102996
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.abspath('.'), 'tests/test-output/')
    context = {'cookiecutter': {'project_name': "Test Project"}}
    template_name = '{{cookiecutter.project_name}}'
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, template_name + '.json'))



# Generated at 2022-06-23 16:32:23.916127
# Unit test for function load
def test_load():
    assert load('~/.cookiecutters/', 'cookiecutter-pypackage')



# Generated at 2022-06-23 16:32:35.235176
# Unit test for function get_file_name

# Generated at 2022-06-23 16:32:43.390363
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'full_name': 'Test User',
            'email': 'test@example.org'
        }
    }
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    dump(replay_dir, template_name, context)
    assert(get_file_name(replay_dir, template_name))
    assert(load(replay_dir, template_name))



# Generated at 2022-06-23 16:32:54.783472
# Unit test for function load

# Generated at 2022-06-23 16:33:05.680143
# Unit test for function dump
def test_dump():
    
    template_name = 'test'
    replay_dir = 'replay_test'
    test_cxt = {'cookiecutter': {'cookie_name': 'cookiecutter'}}
    path = os.path.join(replay_dir, 'test.json')
    if os.path.exists(path):
        os.remove(path)
        
    dump(replay_dir, template_name, test_cxt)
    
    assert os.path.exists(path)
    
    with open(path, 'r') as infile:
        context = json.load(infile)
    
    assert context == test_cxt
    assert isinstance(context, dict)
    os.remove(path)


# Generated at 2022-06-23 16:33:16.315844
# Unit test for function dump
def test_dump():
    test_dir = os.path.join(os.path.dirname(__file__), '_test_replay')
    context = {'cookiecutter':{'full_name':'Hoang-Nam Nguyen',\
                                'email':'hoangnam.nguyen@student.uantwerpen.be',\
                                'project_name':'TestProject'}}
    dump(test_dir, 'TestProject', context)

    assert os.path.exists(os.path.join(test_dir, 'TestProject.json'))
    os.remove(os.path.join(test_dir, 'TestProject.json'))
