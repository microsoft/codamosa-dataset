

# Generated at 2022-06-23 16:23:24.055951
# Unit test for function get_file_name
def test_get_file_name():
	assert get_file_name("", "") == ""
	assert get_file_name("", "abc") == "abc"
	assert get_file_name("", "abc.json") == "abc.json"
	assert get_file_name("/root", "abc.json") == "/root/abc.json"
	assert get_file_name("/root", "") == "/root/"
	assert get_file_name("/root/", "abc.json") == "/root/abc.json"
	assert get_file_name("/root/", "abc") == "/root/abc.json"

# Generated at 2022-06-23 16:23:35.405885
# Unit test for function dump
def test_dump():
    test_replay_dir = 'test_replay_dir'

# Generated at 2022-06-23 16:23:39.951838
# Unit test for function get_file_name
def test_get_file_name():
    """Test the get_file_name function."""
    assert get_file_name('replay-dir', 'tester') == 'replay-dir/tester.json'
    assert get_file_name('replay-dir', 'tester.json') == 'replay-dir/tester.json'

# Generated at 2022-06-23 16:23:44.909406
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('foo', 'bar') == os.path.join('foo', 'bar.json')
    assert get_file_name('foo', 'bar.json') == os.path.join('foo', 'bar.json')
    assert get_file_name('/tmp', 'bar') == os.path.join('/tmp', 'bar.json')
    assert get_file_name('/tmp', 'bar.json') == os.path.join('/tmp', 'bar.json')


# Generated at 2022-06-23 16:23:53.294135
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = os.path.join(
        os.path.expanduser('~'), 'cookiecutter-replay'
    )
    template_name = 'test'
    context = {
        'cookiecutter': {
            'name': 'Roy',
            'full_name': 'Roy Hyunjin Han',
            'email': 'rhh2@illinois.edu',
        }
    }

    # Assert that file is created
    assert not os.path.isfile(get_file_name(replay_dir, template_name))
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))

    # Assert that file is correct

# Generated at 2022-06-23 16:24:04.629017
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    template_name = 'micropython-lib/blinker'
    context = {
        'cookiecutter': {
            'author_name': 'Louis',
            'author_email': 'louis@w3.org',
            'github_username': 'LouisYan',
            'library_name': 'blinker',
            'project_url': 'https://github.com/louiscklaw/blinker',
            'year': '2018',
            'full_name': 'Louis Yan'
        }
    }

    dump(replay_dir, template_name, context)

# Generated at 2022-06-23 16:24:10.771744
# Unit test for function dump
def test_dump():
    """test dump."""
    replay_dir = 'tests/files'
    template_name = 'author-name'
    context = {
        'cookiecutter': {
            'author_name': 'Test',
            'email': 'test@example.com',
        }
    }
    dump(replay_dir, template_name, context)
    new_context = load(replay_dir, template_name)
    assert new_context == context


# Generated at 2022-06-23 16:24:16.615381
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    template_name = 'temp'
    replay_dir = 'result'
    context = {'cookiecutter' : 'test'}
    
    # Dump
    dump(replay_dir, template_name, context)
    
    # Load
    result = load(replay_dir, template_name)
    
    # Check result
    assert result['cookiecutter'] == 'test'



# Generated at 2022-06-23 16:24:20.318350
# Unit test for function get_file_name
def test_get_file_name():
    expected = '/home/replay/test.json'
    assert get_file_name('/home/replay', 'test') == expected, 'Unexpected file name'

# Generated at 2022-06-23 16:24:25.055850
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('dir', 'name') == 'dir/name.json'
    assert get_file_name('dir/', 'name.json') == 'dir/name.json'
    assert get_file_name('dir\\', 'name.json') == 'dir\\name.json'
    assert get_file_name('dir/', 'name') == 'dir/name.json'

# Generated at 2022-06-23 16:24:28.800309
# Unit test for function get_file_name
def test_get_file_name():
    """Test the get_file_name function."""
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    assert get_file_name(replay_dir, template_name) == 'test_replay_dir/test_template_name.json'

# Generated at 2022-06-23 16:24:41.436888
# Unit test for function load
def test_load():

    # Create a dummy reopen_file
    dummy_reopen_file = os.path.join('.', '.cc_dump.json')

    # Create a dummy context
    dummy_context = {'cookiecutter': {
        'repo_dir': '.',
        'context_file': '.',
        'default_context': True}}

    with open(dummy_reopen_file, 'w') as dummy_file:
        json.dump(dummy_context, dummy_file, indent=2)

    # Call load function
    load_context = load('.', '.cc_dump')

    # We don't check for equality because the function return
    # a OrderedDict instead of an usual Dict

# Generated at 2022-06-23 16:24:45.760194
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("test_dir", "test_template") == "test_dir/test_template.json"
    assert get_file_name("test_dir", "test_template.json") == "test_dir/test_template.json"

# Generated at 2022-06-23 16:24:51.846740
# Unit test for function get_file_name
def test_get_file_name():

    template_name = 'example'
    replay_dir = '/Users/niels/.cookiecutters_cache'
    assert '/Users/niels/.cookiecutters_cache/example.json' == (get_file_name(replay_dir, template_name))


# unit test for function dump

# Generated at 2022-06-23 16:25:00.448715
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    import shutil
    import json

    replay_dir = tempfile.mkdtemp()
    template_name = 'testing'
    context = {'cookiecutter': {'replay_dir': replay_dir}}
    dump(replay_dir, template_name, context, 'abc')

    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        obj = json.load(infile)

    assert obj == {'cookiecutter': {'replay_dir': replay_dir}}
    shutil.rmtree(replay_dir)

# Generated at 2022-06-23 16:25:05.474999
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = 'test'
    context = {'cookiecutter': {'full_name': 'Francesco Pierfederici'}}
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    print(context)
    os.remove(get_file_name(replay_dir, template_name))


if __name__ == "__main__":
    test_load()

# Generated at 2022-06-23 16:25:12.836424
# Unit test for function dump
def test_dump():
    """Unit test for function dump"""
    import tempfile
    template_name = 'template_to_dump'
    context = {
        'cookiecutter': {},
        '_template': template_name
    }
    replay_dir = tempfile.mkdtemp()

    dump(replay_dir, template_name, context)

    # check if file dumps

    file_name = get_file_name(replay_dir, template_name)
    assert os.path.isfile(file_name) == True
    # check if file read and parsed
    loaded_context = load(replay_dir, template_name)
    assert loaded_context == context



# Generated at 2022-06-23 16:25:19.426277
# Unit test for function load
def test_load():
    """Unit test for function load"""
    global currentpath
    global replay_dir

    with open(os.path.join(currentpath,'test_load.json')) as f:
        context = json.load(f)
        print(context)

    dump(replay_dir,'test_load.json', context)

    context2 = load(replay_dir, 'test_load.json')

    if(context == context2):
        print('Succeed!')



# Generated at 2022-06-23 16:25:26.668656
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('.', 'test1') == "./test1.json"
    assert get_file_name('.', 'test2.json') == "./test2.json"
    assert get_file_name('.', 'test3.nope') == "./test3.nope.json"
    assert get_file_name('../', 'test4') == "../test4.json"

# Generated at 2022-06-23 16:25:34.610122
# Unit test for function dump
def test_dump():
    import json
    import os
    import sys
    import tempfile
    replay_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 16:25:38.649652
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/mary/Desktop/'
    template_name = 'cookie'
    assert (get_file_name(replay_dir, template_name) == '/home/mary/Desktop/cookie.json')
    template_name = 'cookie.json'
    assert (get_file_name(replay_dir, template_name) == '/home/mary/Desktop/cookie.json')
    return True


# Generated at 2022-06-23 16:25:49.414653
# Unit test for function dump
def test_dump():
    """
    Testing the dump function.
    """
    import os
    import shutil
    from cookiecutter import replay

    import tempfile

    test_template_name = 'test-replay'

    # Test with a non-existing directory
    test_replay_dir = os.path.join(tempfile.mkdtemp(), 'not-existing-replay')
    test_context = {'replay_test_key': 'replay_test_value'}
    test_data = {'cookiecutter': {test_template_name: test_context}}

    replay.dump(test_replay_dir, test_template_name, test_data)

    replay_file = get_file_name(test_replay_dir, test_template_name)
    assert os.path.exists(replay_file)



# Generated at 2022-06-23 16:25:59.742554
# Unit test for function dump
def test_dump():
    import shutil
    template_name = 'pdf_conversion'
    if os.path.exists('replay'):
        shutil.rmtree('replay')
    os.makedirs('replay')

# Generated at 2022-06-23 16:26:02.785885
# Unit test for function get_file_name
def test_get_file_name():

    assert get_file_name('/tmp', 'asdf') == '/tmp/asdf.json'
    assert get_file_name('/tmp', 'asdf.json') == '/tmp/asdf.json'



# Generated at 2022-06-23 16:26:07.872165
# Unit test for function load
def test_load():
    """ Test function load """
    context = load('./tests/test-output/replays', 'test-template')
    print ("The context is ")
    print (context)


# Generated at 2022-06-23 16:26:18.479296
# Unit test for function dump
def test_dump():
    """Test to check the functionality of the dump function."""
    # 1) Check to raise error if not given a string as template name
    replay_dir = '/tmp'
    template_name = True
    context = {'cookiecutter': {'key': 'value'}}
    try:
        dump(replay_dir, template_name, context)
    except TypeError as e:
        assert 'str' in str(e)

    # 2) Check to raise error if given a non-dict as context
    template_name = 'cookiecutter-template'
    context = ['cookiecutter', {'key': 'value'}]
    try:
        dump(replay_dir, template_name, context)
    except TypeError as e:
        assert 'dict' in str(e)

    # 3) Check to raise error if given

# Generated at 2022-06-23 16:26:26.494657
# Unit test for function dump
def test_dump():
    global replay_dir
    replay_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'replay'))
    global template_name
    global context

    template_name = 'TEST REPLAY DUMP'
    context = {'cookiecutter': {'full_name': 'test_name'},
               'test_context': 'TEST CONTEXT'}

    dump(replay_dir, template_name, context)



# Generated at 2022-06-23 16:26:31.586314
# Unit test for function dump
def test_dump():
    replay_dir = 'temptest'
    template_name = 'test'
    context = {'cookiecutter': {'full_name': 'Tuan Tran', 'email': 'tuan@tuan.org'}}
    dump(replay_dir, template_name, context)
    
    

# Generated at 2022-06-23 16:26:35.131858
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'test_template'
    replay_dir = 'test_replay_dir'
    assert get_file_name(replay_dir, template_name) == 'test_replay_dir/test_template.json'


# Generated at 2022-06-23 16:26:45.472929
# Unit test for function dump
def test_dump():
    """Test  dump."""
    import json
    import shutil
    import tempfile

    # Test dump function
    temp_dir = tempfile.mkdtemp()
    try:
        dump(temp_dir, 'foo', {'cookiecutter': {'hello': 'world'}})
        file_name = os.path.join(temp_dir, 'foo.json')
        with open(file_name, 'r') as infile:
            actual_data = json.load(infile)
        assert actual_data == {'cookiecutter': {'hello': 'world'}}
    finally:
        shutil.rmtree(temp_dir)


# Generated at 2022-06-23 16:26:52.152035
# Unit test for function load
def test_load():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    replay_dir = os.path.join(current_dir, "replay_dir")

    test_data = {}

    f = open(os.path.join(replay_dir, "test.json"), "w+") 
    f.write("{}")
    f.close()

    assert load(replay_dir, "test") == test_data

    # Test load with wrong input
    try: 
        load(replay_dir, os.path.join(replay_dir, "test"))
        assert False
    except:
        assert True


# Generated at 2022-06-23 16:27:01.454292
# Unit test for function dump
def test_dump():
    """Test for dump function."""
    import tempfile

    with tempfile.TemporaryDirectory() as replay_dir:
        from cookiecutter.replay import dump, load

        template_name = 'foobarbaz'

        context = {
            'cookiecutter': {
                'full_name': 'Audrey Roy',
                'email': 'audreyr@example.com',
            }
        }

        dump(replay_dir, template_name, context)
        assert os.path.exists(
            os.path.join(replay_dir, '{}.json'.format(template_name))
        )

        loaded_context = load(replay_dir, template_name)
        assert loaded_context == context


# Generated at 2022-06-23 16:27:09.341402
# Unit test for function dump
def test_dump():
    # Create a context for the function
    context = dict()
    context['cookiecutter'] = dict()
    context['cookiecutter']['full_name'] = 'Benjamin S. Meyers'
    context['cookiecutter']['email'] = 'ben@benmyers.net'
    context['cookiecutter']['github_username'] = 'bsmeyers'
    context['cookiecutter']['project_name'] = 'test'
    context['cookiecutter']['project_short_description'] = 'test'
    context['cookiecutter']['release_date'] = '2017-02-24'
    # Create a temporary directory to store the replay file
    replay_dir = '/tmp/replay'
    # Create a template_name for the replay file
    template_name = 'template_name'
   

# Generated at 2022-06-23 16:27:17.812775
# Unit test for function get_file_name
def test_get_file_name():
    # Test when file_name is not suffixed with '.json'
    replay_dir = "."
    template_name = "template_name"
    file_name = get_file_name(replay_dir, template_name)
    assert(file_name == os.path.join(replay_dir, 'template_name.json'))

    # Test when file_name is suffixed with '.json'
    template_name = "template_name.json"
    file_name = get_file_name(replay_dir, template_name)
    assert(file_name == os.path.join(replay_dir, 'template_name.json'))



# Generated at 2022-06-23 16:27:21.589987
# Unit test for function load
def test_load():
    template_name = "master"
    replay_dir = r"E:\Codes\Github\Cookiecutter-template\cookiecutter\tests\fixtures\fake-repo-pre"
    context = load(replay_dir,template_name)
    print(context)


# Generated at 2022-06-23 16:27:28.001739
# Unit test for function dump
def test_dump():
    data = {'cookiecutter': {'test': 'test_data'}}
    replay_dir = '~/.cookiecutters'
    template_name = 'test'
    try:
        dump(replay_dir, template_name, data)
    except IOError as e:
        print(e)
        assert False
    except TypeError as e:
        print(e)
        assert False
    except ValueError as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-23 16:27:36.587821
# Unit test for function load
def test_load():
    """Load sample data form replay file."""
    replay_file = "https://github.com/jeazy/cookiecutter-django-rest.git"
    replay_dir = os.path.expanduser("~/.cookiecutters")
    context = load(replay_dir, replay_file)
    formatted_context = json.dumps(context, sort_keys=True, indent=4)
    print(formatted_context)

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-23 16:27:41.563757
# Unit test for function dump
def test_dump():
    replay_dir = 'D:/Download/bbbb'
    template_name = 'D:/Download/ccc'
    context = dict(template_name=template_name, cookiecutter={'some': 'key'})

    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:27:44.177897
# Unit test for function load
def test_load():
    context = load('my_dir', 'my_template')
    print(context)
    
if __name__ == "__main__":
    test_load()

# Generated at 2022-06-23 16:27:48.964839
# Unit test for function load
def test_load():
    replay_dir = 'C:/Users/gujit/replay_dir'
    template_name = 'template_name'
    #context = {'cookiecutter':{'full_name':'Joe', 'email': 'joe@mama.com'}}
    context = {'cookiecutter':{}}
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    print(context)

test_load()

# Generated at 2022-06-23 16:27:59.059520
# Unit test for function dump
def test_dump():
    # create a temporary directory for testing.
    import tempfile
    dirpath = tempfile.mkdtemp()
    # create a replay_dict for testing.
    replay_dict = {
        'cookiecutter': {
            'full_name': 'Pengfei Lin',
            'email': 'linpf3@mail2.sysu.edu.cn',
            'project_slug': 'test'
        }
    }
    
    # dump the replay_dict to replay_file
    dump(dirpath,'test', replay_dict)
    # load the replay_file
    ret_dict = load(dirpath, 'test')
    # compare the replay_dict with ret_dict
    assert (replay_dict == ret_dict)

if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-23 16:28:03.993041
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name"""
    replay_dir = './replay'
    template_name = 'temp_name.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == './replay/temp_name.json'

#############################################################################

# Generated at 2022-06-23 16:28:11.796414
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.expanduser('~'), 'tmp')
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:28:22.816742
# Unit test for function dump
def test_dump():
    """test function dump in replay.py."""
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'

# Generated at 2022-06-23 16:28:30.987708
# Unit test for function load
def test_load():
    template_name = "test"
    replay_dir = "."
    template_context = {
        'name': 'fake',
        'version': '0.0.1',
        'description': 'fake',
        'long_description': 'long fake',
        'author_name': 'fake',
        'open_source_license': 'fake',
        'email': 'fake@example.com',
        'github_username': 'fake',
        'project_name': 'fake',
        'release_date': '2018-02-22',
        'year': '2018',
        'use_pypi_deployment_with_travis': 'y',
        'console_scripts': 'cli.py',
    }


# Generated at 2022-06-23 16:28:39.226660
# Unit test for function load
def test_load():
    """Unit test for function load."""
    from cookiecutter.main import cookiecutter
    import shutil

    template = 'tests/test-data/fake-repo-tmpl'
    extra_context = {
        'full_name': "Your Name",
        'email': "your_email@example.com",
    }
    replay_dir = 'tests/test-data/fake-repo-pre/'

    template_name = os.path.basename(template).split(".")[0]
    os.chdir(template)
    shutil.rmtree(replay_dir, ignore_errors=True)

    cookiecutter(template, extra_context=extra_context, replay_dir=replay_dir)
    context = load(replay_dir, template_name)


# Generated at 2022-06-23 16:28:47.592998
# Unit test for function get_file_name
def test_get_file_name():

    #positive test cases
    assert 'test1.json' == get_file_name("test", "test1")
    assert 'test2.json' == get_file_name("test", "test2")
    assert 'test3.json' == get_file_name("test/another test", "test3")

    #negative test cases
    assert 'test2.json' != get_file_name("test", "test1")
    assert 'test4.json' != get_file_name("test", "test2")
    assert 'test5.json' != get_file_name("test/another test", "test3")


# Generated at 2022-06-23 16:28:49.882767
# Unit test for function get_file_name
def test_get_file_name():
    file_name = get_file_name('replays/file.json', 'test')
    assert file_name == 'replays/file.json'

# Generated at 2022-06-23 16:28:51.374234
# Unit test for function load
def test_load():
    load(replay_dir, template_name)


# Generated at 2022-06-23 16:29:04.058417
# Unit test for function load
def test_load():
    # create replay_dir
    replay_dir = './test_replay'
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    # create replay_file

# Generated at 2022-06-23 16:29:14.133288
# Unit test for function dump
def test_dump():
    """test the cookiecutter.replay.dump function"""
    template_name = 'template_name'
    context = {
        'cookiecutter': {
            'foo': 'bar',
        }
    }
    replay_dir = "./test_replay_dir"

    if os.path.exists(replay_dir):
        shutil.rmtree(replay_dir)

    dump(replay_dir, template_name, context)

    # check that file was created
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.exists(replay_file)

    shutil.rmtree(replay_dir)



# Generated at 2022-06-23 16:29:24.805739
# Unit test for function load
def test_load():
    # path exists
    replay_dir = os.getcwd()
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))
        assert os.path.exists(replay_dir)
    #template_name not str
    try:
        load(1,2)
        assert False
    except TypeError:
        assert True
    #template_name is str
    template_name = 'test'
    if not isinstance(template_name, str):
        raise TypeError('Template name is required to be of type str')
    assert isinstance(template_name, str)
    #replay_file no exist
    replay_file = get_file_name(replay_dir, template_name)

# Generated at 2022-06-23 16:29:35.671371
# Unit test for function dump
def test_dump():
    replay_dir = 'insert_replay_dir'
    template_name = 'insert_template_name'
    
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['full_name'] = 'insert_full_name'
    context['cookiecutter']['email'] = 'insert_email'
    context['cookiecutter']['project_slug'] = 'insert_project_slug'

    dump(replay_dir, template_name, context)

    file_test = get_file_name(replay_dir, template_name)

    with open(file_test, 'r') as infile:
        context_test = json.load(infile)

    assert context == context_test
    

# Generated at 2022-06-23 16:29:39.095091
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = 'foobaz'
    file_name = get_file_name(replay_dir, template_name)
    assert os.path.join(replay_dir, 'foobaz.json') == file_name


# Generated at 2022-06-23 16:29:41.114874
# Unit test for function load
def test_load():
    os.chdir('tests')
    load('tests', 'cookiecutter-pypackage')



# Generated at 2022-06-23 16:29:44.979463
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name function."""
    assert get_file_name('replay_dir', 'template_name') == 'replay_dir/template_name.json'
    assert get_file_name('replay_dir', 'template_name.json') == 'replay_dir/template_name.json'


# Generated at 2022-06-23 16:29:47.598796
# Unit test for function load
def test_load():
    context = load('~/.cookiecutter_replay', 'cookiecutter-pypackage')
    print(context)


# Generated at 2022-06-23 16:29:54.843310
# Unit test for function dump
def test_dump():
    import tempfile
    with tempfile.TemporaryDirectory('cookiecutter') as tmpdirname:
        template_name = 'Test 1'
        context = {
            'cookiecutter': {
                'test': 'this is a test'
            }
        }
        dump(tmpdirname, template_name, context)
        filepath = os.path.join(tmpdirname, 'test-1.json')
        print(filepath)
        with open(filepath, 'r') as infile:
            data = json.load(infile)
            print(data)
            assert data['cookiecutter'] == context['cookiecutter']

# Generated at 2022-06-23 16:29:59.439597
# Unit test for function get_file_name
def test_get_file_name():
    """Test get file name."""
    template_name = 'Test'
    replay_dir = '/test/'
    assert get_file_name(replay_dir, template_name) == '/test/Test.json'


# Generated at 2022-06-23 16:30:04.098509
# Unit test for function load
def test_load():
    import os
    template_dir = os.path.join(os.path.dirname(__file__), "template")
    context = load(template_dir, "project_name")
    assert context == {'cookiecutter': {'project_name': 'Template'}}

# Generated at 2022-06-23 16:30:12.249003
# Unit test for function load
def test_load():

	replay_dir = '/Users/dongchunyi/Desktop/test_replay'
	template_name = '/Users/dongchunyi/Desktop/test_replay/cookiecutter-pypackage'
	context = {'cookiecutter': {}}

	assert(os.path.exists(replay_dir) == True)
	assert(os.path.exists(template_name) == True)
	assert(isinstance(context, dict) == True)
	assert('cookiecutter' in context)


# Generated at 2022-06-23 16:30:17.238552
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "../../tests/test-output/"
    template = "Test"

    assert (get_file_name(replay_dir, template) ==
            "../../tests/test-output/Test.json")

    template = "Test.json"
    assert (get_file_name(replay_dir, template) ==
            "../../tests/test-output/Test.json")



# Generated at 2022-06-23 16:30:23.103001
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    context = {
        'cookiecutter': {
            'a': '1',
            'b': '2'
        }
    }

    dump(
        replay_dir='/tmp',
        template_name='my_template',
        context=context
    )

    os.remove(get_file_name('/tmp', 'my_template'))

# Generated at 2022-06-23 16:30:26.571623
# Unit test for function load
def test_load():
    replay_dir = r'./tests/replay'
    template_name = 'example-repo'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:30:30.358988
# Unit test for function dump
def test_dump():
    replay_dir = "C:\Temp"
    template_name = "TestTemplate"
    context = {"cookiecutter": {'name': 'Test'}}
    expected = get_file_name(replay_dir, template_name)
    actual = dump(replay_dir, template_name, context)
    assert expected == actual


# Generated at 2022-06-23 16:30:37.581393
# Unit test for function get_file_name
def test_get_file_name():
    import re
    import inspect
    from cookiecutter.utils import rmtree

    replay_dir = os.path.dirname(os.path.realpath(__file__)) + '/test_replay'
    current_function_name = inspect.stack()[0][3]

    # Create a mock of template_name
    template_name = 'mock_template_name'

    # Create a mock of file_name
    suffix = '.json'
    file_name = '{}{}'.format(template_name, suffix)

    # Set expected output
    expected_output = os.path.join(replay_dir, file_name)

    # Test get_file_name function
    assert get_file_name(replay_dir, template_name) == expected_output

    # Delete replay directory

# Generated at 2022-06-23 16:30:44.365615
# Unit test for function load
def test_load():
    context = load(os.path.dirname(os.path.realpath(__file__)), '../demo/cookiecutter.json')
    assert context == {'cookiecutter': {'project_name': 'Cookiecutter Demo', 'repo_name': 'cookiecutter-demo', 'project_version': '0.1.0', 'use_pypi_deployment_with_travis': 'y', 'command_line_interface': 'invoker', 'open_source_license': 'MIT license'}}

# Generated at 2022-06-23 16:30:49.374496
# Unit test for function load
def test_load():
    from pprint import pprint as pp
    replay_dir = r'e:\vcs\cookiecutter-python-cli\tests\test-replay'
    template_name = 'cookiecutter-pypackage-minimal'
    context = load(replay_dir, template_name)
    pp(context)


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:30:51.978412
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('./', 'template') == './template.json', 'File name is wrong'

    assert get_file_name('./', 'template.json') == './template.json', 'File name is wrong'


# Generated at 2022-06-23 16:30:58.637872
# Unit test for function load
def test_load():
    if not isinstance("test_template", str):
        raise TypeError('Template name is required to be of type str')

    replay_file = get_file_name("test_template", "replay")

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    print("Context: " + str(context))
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    return context

# Generated at 2022-06-23 16:31:02.476949
# Unit test for function load
def test_load():
    replay_dir = '/Users/shiwenli/Documents/GitHub/Cookiecutter/tests/test-output/.cookiecutters'
    template_name = 'test-cookiecutter-json'
    context = load(replay_dir,template_name)
    print(context)


# Generated at 2022-06-23 16:31:09.631808
# Unit test for function dump
def test_dump():
    import shutil
    context = {'cookiecutter':{
        'full_name': 'Audrey Roy',
        'email': 'audreyr@example.com',
        'project_name': '{{cookiecutter.project_name}}',
        'project_slug': '{{cookiecutter.project_slug}}'
    }}
    replay_dir = '.cookiecutter-replay'
    template_name = 'cookiecutter-pypackage'
    dump(replay_dir=replay_dir, template_name=template_name, context=context)
    assert os.path.isdir(replay_dir)
    assert os.path.isfile(get_file_name(replay_dir, template_name))
    shutil.rmtree(replay_dir)
    assert not os.path

# Generated at 2022-06-23 16:31:19.043610
# Unit test for function dump
def test_dump():
    replay_dir = '/Users/kumar017/PycharmProjects/python-cookiecutter-test/test/test_files'
    template_name = 'test_template'
    context = {
        "cookiecutter": {
            "project_name": "test_project_name"
        }
    }

    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    if not isinstance(template_name, str):
        raise TypeError('Template name is required to be of type str')

    if not isinstance(context, dict):
        raise TypeError('Context is required to be of type dict')


# Generated at 2022-06-23 16:31:23.011870
# Unit test for function load
def test_load():
    """Unit test for load function."""
    context = load('replay', 'defaults')
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')
    else:
        print('Passed')


# Generated at 2022-06-23 16:31:31.069976
# Unit test for function dump
def test_dump():
	replay_dir = 'tests/test-replay'
	template_name = 'tests/fake-repo-pre/{{cookiecutter.project_slug}}/'

# Generated at 2022-06-23 16:31:34.523244
# Unit test for function dump
def test_dump():
    replay_dir = 'test_dump'
    template_name = 'test_template'
    context =  {'cookiecutter': {'_template': 'test_template'}, 'cookiecutter1': {'_template': 'test_template'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(os.path.join(replay_dir, template_name+'.json'))
    if os.path.exists(replay_dir):
        os.rmdir(replay_dir)


# Generated at 2022-06-23 16:31:45.803951
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/replay'
    template_name = 'cloned-repo-subs-all-users'
    context = {
        'cookiecutter': {
            'full_name': 'Amy',
            'email': 'amy@example.com',
            'replay_dir': 'foo',
            'replay': True,
            'replay_no_input': False,
            'replay_stop_at': '',
            'replay_reset_at': '',
            'replay_arg_files': []
        }
    }
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, template_name + '.json'))


# Generated at 2022-06-23 16:31:53.123695
# Unit test for function dump
def test_dump():
    """Test if we can dump data"""
    replay_dir = "/tmp/test/replay"
    template_name = "test_dump.json"
    context = {'name': 'bogus', 'cookiecutter': {}, 'project_slug': "bogus-project"}
    dump(replay_dir, template_name, context)
    expected_file_name = "{}/{}".format(replay_dir, template_name)
    assert os.path.exists(expected_file_name)
    os.remove(expected_file_name)
    os.rmdir(replay_dir)

# Generated at 2022-06-23 16:32:00.389737
# Unit test for function dump
def test_dump():
    test_context = {'cookiecutter': {'project_name': 'test_proj_name'}}
    test_template = 'test_templ'
    test_replay_dir = 'test_dir'
    dump(test_replay_dir, test_template, test_context)
    result = load(test_replay_dir, test_template)
    assert(test_context == result)

if __name__ == "__main__":
    test_dump()

# Generated at 2022-06-23 16:32:11.260727
# Unit test for function dump
def test_dump():
    # trash
    import shutil
    trash = os.path.join(os.getcwd(), "trash")
    save = os.path.join(os.getcwd(), "save")
    if os.path.exists(trash):
        shutil.rmtree(trash)
    if os.path.exists(save):
        shutil.rmtree(save)

    os.makedirs(trash)
    os.makedirs(save)

    context = {'cookiecutter': {'name': 'Joe'}}
    template_name = 'test_dump'
    replay_dir = 'save'

    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:32:20.641507
# Unit test for function get_file_name
def test_get_file_name():
    """Test for function get_file_name"""
    print("Test for function get_file_name")

    try:
        replay_dir = "tmp"
        template_name = "test"
        assert get_file_name(replay_dir, template_name) == "tmp/test.json"
    except AssertionError:
        print("get_file_name test failed")
        print(get_file_name(replay_dir, template_name))
        return
    print("get_file_name test passed")



# Generated at 2022-06-23 16:32:30.089204
# Unit test for function get_file_name
def test_get_file_name():
    # create a test dir
    replay_dir = './test/replay_dir'
    # template name is an absolute path name
    template_name = '/Users/maysc/Repos/cookiecutter-django/{{cookiecutter.repo_name}}'
    # expected result
    expected = './test/replay_dir/{{cookiecutter.repo_name}}.json'
    # get the actual file name
    actual = get_file_name(replay_dir, template_name)
    # compare the actual with the expected result
    assert actual == expected


# Generated at 2022-06-23 16:32:38.630519
# Unit test for function dump
def test_dump():
    from cookiecutter.replay import dump
    from tempfile import mkdtemp
    from shutil import rmtree
    # Create temporary directory
    temp_dir = mkdtemp()
    # Create test context
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['full_name'] = 'John Doe'
    context['cookiecutter']['email'] = 'john.doe@example.com'
    context['cookiecutter']['github_username'] = 'johndoe'
    context['cookiecutter']['project_name'] = 'Example project'
    context['cookiecutter']['project_slug'] = 'example_project'
    context['cookiecutter']['version'] = '0.0.1'

# Generated at 2022-06-23 16:32:40.520050
# Unit test for function load
def test_load():
    context = load(os.path.expanduser('~/.cookiecutters'), 'python')
    assert context is not None

# Generated at 2022-06-23 16:32:45.808763
# Unit test for function dump
def test_dump():
    replay_dir = r'C:\Temp' #Set the directory where you want to store the json file
    template_name = 'mytemplate' #Set the name of the template you are testing
    context = {'cookiecutter':{'full_name': 'Test Name', 'email': 'test@email.com'}}
    dump(replay_dir, template_name, context)
    

# Generated at 2022-06-23 16:32:47.006941
# Unit test for function dump
def test_dump():
    """."""
    assert not dump('replay_dir', 'template_name', {})

# Generated at 2022-06-23 16:32:49.060961
# Unit test for function load
def test_load():

    context = load('replay', 'cc_cookiecutter')
    assert len(context) > 0

# Generated at 2022-06-23 16:32:53.491420
# Unit test for function get_file_name
def test_get_file_name():
    # Test 1 : template_name is 'example'
    assert(get_file_name("/home", "example") == "/home/example.json")
    # Test 2 : template_name is not a str
    assert_raises(TypeError, get_file_name, "/home", 123)


# Generated at 2022-06-23 16:33:00.886830
# Unit test for function dump
def test_dump():
    import os
    from cookiecutter.main import cookiecutter

    if os.path.exists('/tmp/cookiecutter-replay/output'):
        os.system("rm -rf /tmp/cookiecutter-replay/output")

    # Test replay is created when dump=True
    os.system("rm -rf /tmp/cookiecutter-replay")
    context = cookiecutter('tests/test-output/', replay_dir='/tmp/cookiecutter-replay', dump=True)
    assert os.path.exists('/tmp/cookiecutter-replay/output.json')

    # Test replay is not created when dump=False
    os.system("rm -rf /tmp/cookiecutter-replay")

# Generated at 2022-06-23 16:33:08.773365
# Unit test for function load
def test_load():
    """Unit test for function load"""
    test_replay_dir = 'tests/files/test-replay'

    # Test for wrong input type for template_name
    try:
        load(test_replay_dir, 1)
    except TypeError as error:
        assert str(error) == 'Template name is required to be of type str'
    else:
        raise RuntimeError('Should raise TypeError')

    # Test for non-existing replay file
    try:
        load(test_replay_dir, 'invalid-replay')
    except FileNotFoundError as error:
        assert error.filename == 'invalid-replay.json'
    else:
        raise RuntimeError('Should raise FileNotFoundError')

    # Test for valid replay file

# Generated at 2022-06-23 16:33:18.325468
# Unit test for function dump
def test_dump():
    """Test the dump fucntion"""
    test_dir = 'test_dir'
    test_template_name = 'test_template_name'
    test_context = {'cookiecutter': 'test_context'}

    dump(test_dir, test_template_name, test_context)

    assert os.path.isdir(test_dir)
    assert os.path.isfile(get_file_name(test_dir, test_template_name))

    os.remove(get_file_name(test_dir, test_template_name))
    os.rmdir(test_dir)
