

# Generated at 2022-06-23 16:23:17.574051
# Unit test for function load
def test_load():
    context = load('/tmp/cookiecutter-replay', 'miacro/cookiecutter-pypackage.git')
    assert isinstance(context, dict) == True
    assert context.get('cookiecutter') != None


# Generated at 2022-06-23 16:23:26.538649
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.dirname(__file__), 'replay')
    template_name = 'cookiecutter-pypackage'
    context = {
        'cookiecutter': {
            'project_name': 'project_name_X',
            'project_slug': 'project_slug_X',
            'author_name': 'author_name_X',
            'email': 'email_X',
            'description': 'description_X',
            'domain_name': 'domain_name_X',
            'version': 'version_X',
            'year': 'year_X',
            'full_name': 'full_name_X',
            'timezone': 'timezone_X'
        }
    }

# Generated at 2022-06-23 16:23:33.019220
# Unit test for function load
def test_load():
    """ Unit test for load """
    file_name = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    file_name = os.path.join(file_name, 'cookiecutter-django')
    context = load(file_name, 'replay')
    assert context is not None, "Can not load context from replay file."
    context = json.dumps(context, indent=2)
    print(context)



# Generated at 2022-06-23 16:23:40.345752
# Unit test for function dump
def test_dump():
    """Unit test for dump."""
    replay_dir = 'test_dump'
    template_name = 'test_template'

# Generated at 2022-06-23 16:23:45.812177
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = './cookiecutter/replay'
    template_name = 'default'
    expected_file_name = './cookiecutter/replay/default.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == expected_file_name



# Generated at 2022-06-23 16:23:55.296686
# Unit test for function load
def test_load():
    """Unit test to test value of load function."""
    dir = os.getcwd()
    template_name = '_cookiecutter'
    replay_dir = os.path.join(dir, template_name)
    replay_file = 'test_load.json'
    replay_file_path = os.path.join(replay_dir, replay_file)

    with open(replay_file_path, 'w') as outfile:
        json.dump({"cookiecutter": "test_load"}, outfile, indent=2)

    contex = load(replay_dir, replay_file)

    assert contex['cookiecutter'] == 'test_load'

    os.remove(replay_file_path)


# Generated at 2022-06-23 16:24:02.853966
# Unit test for function get_file_name
def test_get_file_name():
    t_dir = '/home/jacob/Desktop/cookiecutter-pypackage-minimal'
    t_name = 'abc'
    assert get_file_name(t_dir, t_name) == '/home/jacob/Desktop/cookiecutter-pypackage-minimal/abc.json'
    t_name = 'abc.json'
    assert get_file_name(t_dir, t_name) == '/home/jacob/Desktop/cookiecutter-pypackage-minimal/abc.json'


# Generated at 2022-06-23 16:24:09.142290
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay_karthi', 'template_name') == 'replay_karthi/template_name.json'
    assert get_file_name('replay_karthi/', 'template_name.json') == 'replay_karthi/template_name.json'
    assert get_file_name('replay_karthi', 'template_name.json') == 'replay_karthi/template_name.json'


# Unit test to check the output of the function dump

# Generated at 2022-06-23 16:24:11.142102
# Unit test for function load
def test_load():
    load('/home/student/code/cookiecutter-pypackage', 'cookiecutter.json')

# Generated at 2022-06-23 16:24:15.622959
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'fake/replay/path'
    template_name = 'fake/template/name'
    expected_file_name = os.path.join(replay_dir, template_name + '.json')
    assert get_file_name(replay_dir, template_name) == expected_file_name



# Generated at 2022-06-23 16:24:19.752091
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('test', 'temp') == 'test/temp.json'
    assert get_file_name('test/', 'temp') == 'test/temp.json'


# Generated at 2022-06-23 16:24:24.062097
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests/files/fake-replay-dir'
    template_name = 'fake-project'
    assert get_file_name(replay_dir, template_name) == 'tests/files/fake-replay-dir/fake-project.json'

test_get_file_name()

# Generated at 2022-06-23 16:24:26.989792
# Unit test for function dump
def test_dump():
    template_name="template_name"
    context={'cookiecutter':{}}
    replay_dir = "./"
    dump(replay_dir,template_name,context)


# Generated at 2022-06-23 16:24:29.829049
# Unit test for function get_file_name
def test_get_file_name():
    # Arrange
    replay_dir = "d"
    template_name = "t"
    # Act
    result = get_file_name(replay_dir, template_name)

    # Assert
    assert result == "d/t.json"


# Generated at 2022-06-23 16:24:33.887358
# Unit test for function load
def test_load():
    data = load('/Users/hztang/NU/cookicutter', 'cookiecutter-pypackage')
    assert(data != None)
    assert(data['cookiecutter']['project_name'] == 'My Test Project')



# Generated at 2022-06-23 16:24:41.031375
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'hi'
    template_name = 'hi.json'
    expected_result = 'hi/hi.json'
    assert get_file_name(replay_dir, template_name) == expected_result

    template_name = 'hi'
    expected_result = 'hi/hi.json'
    assert get_file_name(replay_dir, template_name) == expected_result


# Generated at 2022-06-23 16:24:50.257401
# Unit test for function load
def test_load():
    import os.path
    import tempfile
    from cookiecutter.main import cookiecutter

    # Test the `load` function against the same data that was recorded
    # by the `dump` function.

    temp_dir = tempfile.mkdtemp()
    template_name = 'test_template'
    context = {'cookiecutter': {'key': 'value'}}
    try:
        dump(temp_dir, template_name, context)
        assert os.path.exists(os.path.join(temp_dir, '{}.json'.format(template_name)))
        loaded_context = load(temp_dir, template_name)
        assert context == loaded_context
    finally:
        os.remove(os.path.join(temp_dir, '{}.json'.format(template_name)))
        os.r

# Generated at 2022-06-23 16:24:53.013951
# Unit test for function load
def test_load():
    context_path = load('./tests/fake-repo-tmpl/', 'fake-repo-tmpl')
    assert 'cookiecutter' in context_path

# Generated at 2022-06-23 16:24:58.710148
# Unit test for function dump
def test_dump():
    replay_dir = "tests"
    template_name = "test"
    context = {"cookiecutter":{"name": "test_name","version": "0.1.0"}}
    dump(replay_dir, template_name, context)
    file_name = get_file_name(replay_dir, template_name)
    assert os.path.isfile(file_name)
    os.remove(file_name)


# Generated at 2022-06-23 16:25:02.782820
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name."""
    replay_dir = "replay_dir"
    template_name = "template_name"
    actual = get_file_name(replay_dir, template_name)
    expected = os.path.join(replay_dir, "{}.json".format(template_name))
    assert actual == expected


# Generated at 2022-06-23 16:25:04.936166
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('./replay', './some_dir/some_file') == './replay/some_dir/some_file.json'

# Generated at 2022-06-23 16:25:10.422836
# Unit test for function get_file_name
def test_get_file_name():
    if get_file_name('test_replay_dir', 'test_template_name') != 'test_replay_dir/test_template_name.json':
        raise ValueError('get_file_name is incorrect!')
    if get_file_name('test_replay_dir', 'test_template_name.json') != 'test_replay_dir/test_template_name.json':
        raise ValueError('get_file_name is incorrect!')


# Generated at 2022-06-23 16:25:16.583812
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = '/tmp'
    template_name = 'template'
    file_name = 'template.json'
    assert get_file_name(replay_dir, template_name) == '/tmp/template.json'


# Generated at 2022-06-23 16:25:24.225314
# Unit test for function dump
def test_dump():
    """
    test_dump is a unit test function for function dump in replay.

    This function test that the function is behave as expected.

    Parameters
    ----------
    replay_dir : str
        Replay directory to save data of a template
    template_name : str
        Template name
    context : dict
        Data of a template

    Returns
    -------
    bool
        If the test success or not.
    """
    import tempfile
    from cookiecutter.utils import rmtree

    # Prepare directory for replay
    replay_dir = tempfile.mkdtemp()

    # Prepare data for dump
    template_name = 'template_name'
    context = {'cookiecutter': {'key': 'value'}}

    # Sample dump

# Generated at 2022-06-23 16:25:32.241826
# Unit test for function get_file_name
def test_get_file_name():
    """Function test_get_file_name."""
    # print(get_file_name('abc', 'abc'))
    assert get_file_name('abc', 'abc') == 'abc/abc.json'
    assert get_file_name('abc', 'abc.json') == 'abc/abc.json'
    assert get_file_name('abc/', 'abc.json') == 'abc/abc.json'
    assert get_file_name('abc', 'abc.json.py') == 'abc/abc.json.py'
    # print(get_file_name('abc', 'abc.json.py'))


# Generated at 2022-06-23 16:25:36.221337
# Unit test for function dump
def test_dump():
    replay_dir = 'replay_dir'
    template_name = 'foo'
    make_sure_path_exists(replay_dir)
    context = {"cookiecutter": {"project_name": "foo", "project_slug": "foo"}}
    # Should not raise any error
    dump(replay_dir, template_name, context)



# Generated at 2022-06-23 16:25:39.561707
# Unit test for function dump
def test_dump():
    """Test for function dump"""
    dir_name = 'test_dir'
    template_name = 'test_template'
    context = {'cookiecutter': {'full_name': 'test_name'}, 'test_variable': 'test_value'}
    dump(dir_name, template_name, context)
    context_read = load(dir_name, template_name)
    assert context == context_read

# Generated at 2022-06-23 16:25:41.551946
# Unit test for function load
def test_load():
    replay_dir = '/home/walid/Bureau/test_proj/cookiecutter-master/tests/fake-repo-pre/'
    template_name = 'fake-repo-pre'
    results = load(replay_dir, template_name)
    print(results)



# Generated at 2022-06-23 16:25:42.542424
# Unit test for function load
def test_load():
    assert load('','') is not None

# Generated at 2022-06-23 16:25:52.506257
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import tempfile
    import shutil
    from cookiecutter.main import cookiecutter

    template = "https://github.com/audreyr/cookiecutter-pypackage.git"


# Generated at 2022-06-23 16:25:56.632747
# Unit test for function load
def test_load():
    """Unit test for function load"""
    replay_file = 'tests/files/invalid.json'
    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

# Generated at 2022-06-23 16:26:04.711731
# Unit test for function dump
def test_dump():
    replays_dir = '.replay'
    template_name = 'cookiecutter-pypackage-min'
    replay_file = get_file_name(replays_dir, template_name)
    context = {'cookiecutter': {'full_name': 'Han Xiang',
    'email': 'hanxiang.frank.xh@gmail.com', 'project_name': 'project_name_test',
    'project_slug': 'project_slug_test', 'release_date': '2017-05-11', 'version': '0.0.1'
    }
    }
    dump(replays_dir, template_name, context)
    with open(replay_file, 'r') as infile:
        context_file = json.load(infile)
    assert context == context_file


# Generated at 2022-06-23 16:26:10.139059
# Unit test for function dump
def test_dump():
    """Test for dump function."""
    template_name = 'cookiecutter-pytest'
    context = {
        'cookiecutter': {'test': 'test'}
    }
    replay_dir = 'replay'
    dump(replay_dir, template_name, context)



# Generated at 2022-06-23 16:26:14.322008
# Unit test for function dump
def test_dump():
    """Test for function dump."""
    project_name = 'mock_project'
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    dump(replay_dir, project_name, {'cookiecutter':{'name': 'Test Cookiecutter'}})


# Generated at 2022-06-23 16:26:18.765056
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = 'replays'
    template_name = 'random_name'
    assert get_file_name(replay_dir, template_name) == 'replays/random_name.json'



# Generated at 2022-06-23 16:26:22.093579
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'abc'
    template_name = 'xyz'
    file_name = 'xyz.json'
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name)

# Generated at 2022-06-23 16:26:28.474143
# Unit test for function dump
def test_dump():
    """Test dump function"""
    replay_dir = 'C:/Users/Administrator/Documents/GitHub/cookiecutter/tests/test-replay'
    template_name = '.'
    context = {
            "cookiecutter": {
                "full_name": "Your Name",
                "email": "your@email.com",
                "replay_dir": "C:/Users/Administrator/Documents/GitHub/cookiecutter/tests/test-replay",
                "replay_file": "C:/Users/Administrator/Documents/GitHub/cookiecutter/tests/test-replay/context.json"
            }
        }
    dump(replay_dir, template_name, context)
    s = os.path.getsize(replay_dir + '/context.json')
    assert s > 0

# Generated at 2022-06-23 16:26:29.864811
# Unit test for function load
def test_load():
    pass


# Generated at 2022-06-23 16:26:34.345082
# Unit test for function dump
def test_dump():
    """test_dump."""
    #test = 'Hi'
    replay_dir = '/Users/replay'
    template_name = 'test'
    context = {'cookiecutter': 'Hello'}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-23 16:26:46.515241
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "C:/Users/Neel/PycharmProjects/cookiecutter/tests/test-output/replay"
    template_name = "tests/test-template"
    assert get_file_name(replay_dir, template_name) == "C:/Users/Neel/PycharmProjects/cookiecutter/tests/test-output/replay\\tests/test-template.json"

    replay_dir = "C:/Users/Neel/PycharmProjects/cookiecutter/tests/test-output/replay"
    template_name = "tests/test-template.json"

# Generated at 2022-06-23 16:26:49.999638
# Unit test for function load
def test_load():
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    context = {'cookiecutter': {'args': '1', 'config': '2'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) is not None

# Generated at 2022-06-23 16:26:51.973465
# Unit test for function get_file_name
def test_get_file_name():
    template_name = "test"
    replay_dir = "tmp"
    get_file_name(replay_dir, template_name)

# Generated at 2022-06-23 16:26:56.500604
# Unit test for function dump
def test_dump():
    """Testing function dump."""
    from test.test_utils import TEMPLATE_DIR
    dump(TEMPLATE_DIR, "cookiecutter", {'cookiecutter': {'foo': 'bar'}})
    assert os.path.isfile(os.path.join(TEMPLATE_DIR, "cookiecutter.json"))


# Generated at 2022-06-23 16:27:00.976364
# Unit test for function dump
def test_dump():
    replay_dir = "/home/kabir/cookiecutter-pypackage"
    template_name = "cookiecutter-pypackage"
    context = {"key1": "value1", "key2": "value2"}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:27:09.037234
# Unit test for function load
def test_load():
    if not __name__ == "__main__":
        print("This file is meant to be run as a script.\n"
              "Tests are in test_cookiecutter_replay.py")
        return

    test_replay_dir = 'tests/test-data/replay'
    test_template = 'fake-repo-pre'

    test_context = load(test_replay_dir, test_template)
    print(test_context)
    assert isinstance(test_context, dict)
    assert 'cookiecutter' in test_context
    assert isinstance(test_context['cookiecutter'], dict)
    assert 'replay_dir' in test_context['cookiecutter']
    assert test_context['cookiecutter']['replay_dir'] == test_replay_dir

# Generated at 2022-06-23 16:27:15.870391
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for get_file_name."""
    # assert output of function equals expected value
    assert get_file_name("", "template") == "template.json"
    assert get_file_name("", "template.json") == "template.json"

    # assert IOError exception thrown when replay_dir does not exist
    try:
        get_file_name("test", "template")
        assert False
    except IOError:
        assert True


# Unit tests for function load

# Generated at 2022-06-23 16:27:23.817266
# Unit test for function dump
def test_dump():
    from cookiecutter import prompt
    from os import chdir
    from tempfile import mkdtemp
    from shutil import rmtree
    from cookiecutter import config as c_config
    
    c = c_config.Config({'replay_dir': mkdtemp()})
    context = {'cookiecutter': {'name': 'Adrien'}}
    dump(c.get_value('replay_dir'), 'test_template', context)
    assert load(c.get_value('replay_dir'), 'test_template') == context
    

# Generated at 2022-06-23 16:27:26.507352
# Unit test for function load
def test_load():
    test_dict = {'cookiecutter': {'blah': 'blah'}}
    dump('', 'test_load', test_dict)
    load('', 'test_load')
    os.remove('test_load.json')



# Generated at 2022-06-23 16:27:31.865790
# Unit test for function dump
def test_dump():
    replay_dir = '~/.cookiecutter_replay'
    template_name = '{{cookiecutter.repo_name}}'
    context = {
        "cookiecutter": {
            "repo_name": "Boring Project",
            "project_name": "Boring Project",
            "use_pypi_deployment_with_travis": "n",
            "open_source_license": "Not open source",
            "command_line_interface": "No command-line interface"
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:27:35.375687
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = '.json'

    assert get_file_name(replay_dir, template_name) == './sample_template.json'

# Generated at 2022-06-23 16:27:46.098962
# Unit test for function dump
def test_dump():
    replay_dir = './tests/test-dump'
    template_name = 'mytemplatename'
    context = {'cookiecutter': {'hello': 'world'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name)) is True
    os.remove(get_file_name(replay_dir, template_name))
    assert os.path.exists(get_file_name(replay_dir, template_name)) is False
    # Test if make_sure_path_exists fails
    os.rmdir(replay_dir)
    assert make_sure_path_exists(replay_dir) is False


# Generated at 2022-06-23 16:27:56.723447
# Unit test for function load
def test_load():
    """Test load function."""
    tempate_name = 'test_template'
    replay_dir = '/tmp/tests/replay'
    context = {
        "cookiecutter": {
            "project_name": "cookiecutter-pypackage",
            "repo_name": "cookiecutter-pypackage",
            "author_name": "Your Name",
            "email": "you@yourdomain.com",
            "year": "2015"
        }
    }
    dump(replay_dir, tempate_name, context)
    loaded = load(replay_dir, tempate_name)
    assert loaded == context


# Generated at 2022-06-23 16:28:06.377631
# Unit test for function dump
def test_dump():
    """Unit test for function dump"""
    template_name = 'django_project'
    context = {'cookiecutter': {'project_name': 'project_name'}}
    replay_dir = 'tests/files/replay'
    dump(replay_dir, template_name, context)
    # check the existing of file

# Generated at 2022-06-23 16:28:11.626572
# Unit test for function load
def test_load():
    cookie = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'project_name': 'Cookiecutter-Simple Python Project',
            'project_slug': 'cookiecutter-simple-python-project',
            'version': '0.1.0'}}
    template_name = 'cookiecutter-simple-python-project'
    replay_dir = 'replay'
    template_context = load(replay_dir, template_name)
    assert cookie == template_context

# Generated at 2022-06-23 16:28:20.113512
# Unit test for function get_file_name
def test_get_file_name():
    """"Unit test for get_file_name()."""
    assert get_file_name('', 'foo') == 'foo.json'
    assert get_file_name('', 'foo.json') == 'foo.json'

    assert get_file_name('/tmp', 'foo') == '/tmp/foo.json'
    assert get_file_name('/tmp', 'foo.json') == '/tmp/foo.json'

    assert get_file_name('/tmp/', 'foo.json') == '/tmp/foo.json'

    try:
        get_file_name(123, 'foo.json')
    except TypeError:
        pass

# Generated at 2022-06-23 16:28:26.786020
# Unit test for function dump
def test_dump():
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    context = {'cookiecutter': 'context'}
    assert dump(replay_dir, template_name, context)
    assert dump(replay_dir, 'template_name.json', context)
    assert not dump(replay_dir, '', context)
    assert not dump(replay_dir, 'template_name', '')
    assert not dump(replay_dir, template_name, '')



# Generated at 2022-06-23 16:28:30.260439
# Unit test for function get_file_name
def test_get_file_name():
    """Test that the get_file_name function returns the correct path to file."""
    template_name = 'template_name'
    replay_dir = '/path/to/replay'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/path/to/replay/template_name.json'

# Generated at 2022-06-23 16:28:38.758621
# Unit test for function get_file_name
def test_get_file_name():
    """Test the get_file_name function."""
    home_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters/')
    replay_dir = os.path.join(home_dir, 'replay/')
    template_name = "cookiecutter_xyz"

    if not os.path.exists(home_dir):
        os.makedirs(home_dir)
    if not os.path.exists(replay_dir):
        os.makedirs(replay_dir)

    # When testing the function, we firstly create a replay dir and then do the testing
    # If we only create a replay dir when the function need to use it, we have no certain
    # that the replay dir is at right path or not, so it's better to create a replay dir
    #

# Generated at 2022-06-23 16:28:47.438741
# Unit test for function dump
def test_dump():
    """Test function dump."""
    template_name = "test_template"
    replay_dir = './test_replay'
    context = {
        "cookiecutter": {
            "project_name": "test_project",
            "example_key": "example_value"
        }
    }

    # Test with not existing replay_dir
    try:
        dump(replay_dir, template_name, context)
    except IOError as e:
        print(e)

    # Test with existing replay_dir, but wrong type of template_name
    try:
        dump(replay_dir, 1, context)
    except TypeError as e:
        print(e)

    # Test with existing replay_dir, existing template_name, but wrong type of context

# Generated at 2022-06-23 16:28:59.822403
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    from shutil import rmtree
    from tempfile import mkdtemp
    import os
    import json

    # create a temp dir
    replay_dir = mkdtemp()

    context = {'cookiecutter': {'full_name': 'Avinash Sajjanshetty'}}
    template_name = 'cookiecutter-pypackage'
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        data = json.load(infile)

    assert data == context

    # cleanup
    rmtree(replay_dir)



# Generated at 2022-06-23 16:29:01.821698
# Unit test for function load
def test_load():
    assert load('test_replay_dir', 'test_template_name') == {'cookiecutter': ''}

# Generated at 2022-06-23 16:29:10.724867
# Unit test for function dump
def test_dump():
    """
    Unit test for function dump.
    """

    print("\nTesting function dump")

    # These tests are for a made up value of replay_dir
    replay_dir = '~/Documents/Python/cookiecutter-cli/tests/fake-repo-templates/'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:29:14.874815
# Unit test for function dump
def test_dump():
    test_info = {'cookiecutter': {'name': 'test', 'description': 'description of the test'}}
    dump('temp', 'temp_test', test_info)
    with open('temp/temp_test.json', 'r') as infile:
        data = json.load(infile)
    assert data == test_info


# Generated at 2022-06-23 16:29:25.267241
# Unit test for function load

# Generated at 2022-06-23 16:29:28.673746
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import shutil
    import tempfile

    replay_dir = tempfile.mkdtemp()
    template_name = 'test'

    try:
        dump(replay_dir, template_name, {})
        assert load(replay_dir, template_name) == {}
    finally:
        shutil.rmtree(replay_dir)

# Generated at 2022-06-23 16:29:33.962817
# Unit test for function dump
def test_dump():
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['project_name'] = 'Test'
    context['cookiecutter']['author_name'] = 'Me'

    dump(replay_dir='./', template_name='test', context=context)


# Generated at 2022-06-23 16:29:39.763756
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = './'
    template_name = 'mytemplate'
    template_name_json = 'mytemplate.json'
    assert get_file_name(replay_dir, template_name) == './mytemplate.json'
    assert get_file_name(replay_dir, template_name_json) == './mytemplate.json'



# Generated at 2022-06-23 16:29:44.180670
# Unit test for function load
def test_load():
    """Unit test for function load."""
    expected_list = ["cookiecutter.json", "cookiecutter/json"]
    replay_dir = "test"
    template_name = "test_template"
    result = load(replay_dir, template_name)
    assert expected_list == result["cookiecutter"]


# Generated at 2022-06-23 16:29:50.519835
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    template_name = "cookiecutter-pypackage"
    replay_dir = os.path.join(os.getcwd(), "tests")
    replay_file = get_file_name(replay_dir, template_name)
    assert replay_file == os.path.join(replay_dir, "cookiecutter-pypackage.json")


# Generated at 2022-06-23 16:29:57.845575
# Unit test for function dump
def test_dump():
    ctx = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@gmail.com',
            'project_name': 'cookiecutter-pypackage',
            'repo_name': 'cookiecutter-pypackage',
            'pypi_username': 'audreyr',
            'open_source_license': 'BSD license',
            'year': '2013',
            'release_date': datetime.datetime(2013, 7, 17),
            'version': '0.1.0',
            'use_travis': True,
        }
    }

    replay_dir = os.path.join('tests', 'replay')
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:30:04.098598
# Unit test for function dump
def test_dump():
    replay_dir = './tests/files/'
    template_name = 'dummy_template'
    context = {
        'cookiecutter': {
            'project_name': 'project'
        }
    }

    dump(replay_dir, template_name, context)

    loaded = load(replay_dir, template_name)
    assert loaded == context



# Generated at 2022-06-23 16:30:12.189091
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = '../tests/test-output'

    context = {'cookiecutter':
               {'project_name': 'test1', 'full_name': 'test2', 'email_address': 'test3'}}
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)
    os.remove(replay_file)


# Generated at 2022-06-23 16:30:15.493801
# Unit test for function load
def test_load():
    """Unit test for function load."""
    path = '.'
    template = 'cookiecutter-pypackage'
    context = load(path, template)

    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:30:22.219983
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = '/tmp'
    context = {'cookiecutter': 'test'}

    dump(replay_dir, template_name, context)

    try:
        _ = load(replay_dir, template_name)
    except Exception:
        assert False

    # clean up
    replay_file = get_file_name(replay_dir, template_name)
    os.remove(replay_file)

# Generated at 2022-06-23 16:30:31.550478
# Unit test for function dump
def test_dump():
    # Path exists
    replay_dir = 'cookiecutter/tests/test-replay'
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld', 'email': 'aroy@example.com', 'project_name': 'cookiecutter-pypackage', 'project_short_description': 'A short description of the project.', 'pypi_username': 'audreyr', 'github_username': 'audreyr'}}

    dump(replay_dir, template_name, context)
    assert(os.path.isfile(get_file_name(replay_dir, template_name)) == True)
    os.remove(get_file_name(replay_dir, template_name))
    # Path doesn't exist


# Generated at 2022-06-23 16:30:34.325945
# Unit test for function load
def test_load():
    try:
        load("wrongPath", "wrongTemplate")
    except Exception as e:
        assert type(e) == IOError
        print("Test load: Passed")



# Generated at 2022-06-23 16:30:36.420389
# Unit test for function load
def test_load():
    assert load('/Users/khuangaf/Desktop/cookiecutter-example', 'example') is not None

# Generated at 2022-06-23 16:30:44.691114
# Unit test for function get_file_name
def test_get_file_name():
    '''Test for the function get_file_name.
    So the function will get the file name.
    '''
    # Test case 1: normal case
    base_dir = os.path.join('test','templates','pypackage','replay')
    template_name = 'template'
    exp_file_name = get_file_name(base_dir, template_name)
    print(exp_file_name)
    assert exp_file_name == os.path.join('test','templates','pypackage','replay','template.json')
    
    

# Generated at 2022-06-23 16:30:52.072189
# Unit test for function load
def test_load():
    """
    Test if load gives expected results.
    """
    template_name = "tests/fake-repo-pre/{{cookiecutter.repo_name}}"
    dir_name = "tests/replay/tests/fake-repo-pre"
    loaded = load(dir_name, template_name)
    expected = {u'cookiecutter': {u'email': u'audreyr@example.com', u'full_name': u'Audrey Roy', u'github_username': u'audreyr', u'repo_name': u'cookiecutter-pypackage', u'year': u'2013'}}
    assert loaded == expected


# Generated at 2022-06-23 16:30:53.452837
# Unit test for function load
def test_load():
    context = load('', 'python_package')
    print(context)

# Generated at 2022-06-23 16:31:00.169709
# Unit test for function load
def test_load():
    template_name = "hello"
    replay_dir = "/tmp"
    context = {'cookiecutter': {'key1': 'value1'}}

    # write to file
    dump(replay_dir, template_name, context)
    # read from file
    context2 = load(replay_dir, template_name)

    assert context['cookiecutter']['key1'] == context2['cookiecutter']['key1']

# Generated at 2022-06-23 16:31:01.826080
# Unit test for function load
def test_load():
    context=load(os.getcwd(),"__init__.py")
    assert context is not None



# Generated at 2022-06-23 16:31:07.971426
# Unit test for function get_file_name
def test_get_file_name():
    """ test get_file_name() """
    template_name = 'foobar'
    replay_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'tests/test-data/'
    )
    # test without '.json'
    assert get_file_name(replay_dir, template_name) == replay_dir + '/foobar.json'
    # test with '.json'
    template_name += '.json'
    assert get_file_name(replay_dir, template_name) == replay_dir + '/foobar.json'



# Generated at 2022-06-23 16:31:11.892795
# Unit test for function get_file_name
def test_get_file_name():
    res = get_file_name(os.path.join(os.path.expanduser('~'), '.cookiecutters'), 'simple')
    assert res == os.path.join(os.path.expanduser('~'), '.cookiecutters', 'simple.json')


# Generated at 2022-06-23 16:31:17.114141
# Unit test for function load
def test_load():
    template_name = 'mycookiecutterproject'
    replay_dir = './tests/test_replay'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert 'project_name' in context['cookiecutter']


# Generated at 2022-06-23 16:31:20.763838
# Unit test for function get_file_name
def test_get_file_name():
    """Test to return the proper file name"""
    template_name = 'test'
    replay_dir = '/tmp/'
    file_name = 'test.json'
    assert file_name == get_file_name(replay_dir, template_name)


# Generated at 2022-06-23 16:31:23.470519
# Unit test for function get_file_name
def test_get_file_name():
    assert os.path.join('replay_dir', 'file.json') == get_file_name('replay_dir', 'file')
    assert os.path.join('replay_dir', 'file.json') == get_file_name('replay_dir', 'file.json')

# Generated at 2022-06-23 16:31:31.237570
# Unit test for function dump
def test_dump():
    replay_dir = '/Users/chenxuzheng/code/github/dpy-cli/tests/fake-repo-pre/'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:31:33.852987
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'test'
    suffix = '.json'
    replay_dir = 'test'
    assert get_file_name(replay_dir, template_name) == 'test/test.json'


# Generated at 2022-06-23 16:31:45.282565
# Unit test for function dump
def test_dump():
    """Test for dump."""
    repo_dir=os.path.abspath('../..')
    replay_dir = os.path.join(repo_dir, '.cookiecutters_replay')
    template_name = "pypackage"

# Generated at 2022-06-23 16:31:54.610860
# Unit test for function dump
def test_dump():
    replay_dir = '~/.cookiecutter_replay'
    template_name = '{{cookiecutter.repo_name}}'

# Generated at 2022-06-23 16:32:02.461720
# Unit test for function load
def test_load():
    """Unit test for function load."""
    dict_context = {'cookiecutter':{'0':'1', '2':'3'}}
    replay_dir = os.path.join(os.getcwd(), '.cookiecutters/replay')
    template_name = 'test'
    dump(replay_dir, template_name, dict_context)
    context = load(replay_dir, template_name)
    if not isinstance(context, dict):
        raise TypeError('The return value of load should be of type dict')
    if context != dict_context:
        raise ValueError('The content of json file should be dict_context')


# Generated at 2022-06-23 16:32:06.314003
# Unit test for function load
def test_load():
    """Test load function."""
    context = load('./cookiecutter/tests/test-replay/', 'replay-test')
    assert context['cookiecutter']['full_name'] == 'David B. Harris'



# Generated at 2022-06-23 16:32:11.156059
# Unit test for function get_file_name
def test_get_file_name():
    """
    Unit test for function get_file_name.
    """
    replay_file = get_file_name("../replay", "test")
    assert replay_file == "../replay/test.json"
    replay_file = get_file_name("../replay", "test.json")
    assert replay_file == "../replay/test.json"

# Generated at 2022-06-23 16:32:14.789249
# Unit test for function load
def test_load():
    expected = {'cookiecutter': {'full_name': 'Louis Malinowski', 'github_username': 'louism-nz', 'project_name': 'Cookiecutter-Bare'}}
    actual = load('./test_replay', 'test_template')
    assert expected == actual


# Generated at 2022-06-23 16:32:20.119671
# Unit test for function dump
def test_dump():
    with open("test_replay.json", "w") as outfile:
        json.dump({"a": "b"}, outfile, ensure_ascii=True, indent=2)

    with open("test_replay.json", "r") as infile:
        result = json.load(infile)
    assert result == {"a": "b"}


# Generated at 2022-06-23 16:32:27.808322
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir_1 = "test_path"
    template_name_1 = "test_template"
    file_name_1 = os.path.join(replay_dir_1, template_name_1 + ".json")
    assert get_file_name(replay_dir_1, template_name_1) == file_name_1
    template_name_2 = "test_template.json"
    file_name_2 = os.path.join(replay_dir_1, template_name_2)
    assert get_file_name(replay_dir_1, template_name_2) == file_name_2


# Generated at 2022-06-23 16:32:36.977530
# Unit test for function get_file_name
def test_get_file_name():
    name = get_file_name('/home/test/testfile.json', 'test')
    name_test = '/home/test/testfile.json.test+test.json'
    assert name == name_test

    name = get_file_name('/home/test/testfile.json', 'test+test')
    name_test = '/home/test/testfile.json.test+test.json'
    assert name == name_test

    name = get_file_name('/home/test/testfile.json', 'test.test')
    name_test = '/home/test/testfile.json.test.test.json'
    assert name == name_test

    name = get_file_name('/home/test/testfile.json', 'test.test.test')

# Generated at 2022-06-23 16:32:40.471326
# Unit test for function load
def test_load():
    replay_dir = "tests/test-load/"
    template_name = "template0"
    print(load(replay_dir, template_name))
    return


# Generated at 2022-06-23 16:32:43.974882
# Unit test for function dump
def test_dump():
    template_name = 'name'
    replay_dir = './replay-directory'
    context = { 'cookiecutter': {'name': 'Paul'} }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:32:46.608931
# Unit test for function load
def test_load():
    assert isinstance(load('cookiecutter/tests/test-replay', 'test-no-ext'), dict)
    assert isinstance(load('cookiecutter/tests/test-replay', 'test.json'), dict)

# Generated at 2022-06-23 16:32:50.879214
# Unit test for function load
def test_load():
    template_name = 'cookiecutter-pypackage'
    replay_dir = 'replay'
    result = load(replay_dir, template_name)
    assert 'cookiecutter' in result


# Generated at 2022-06-23 16:32:57.302195
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'Test_1'
    template_name = 'abc.json'
    file_name = 'abc.json'
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name)

    replay_dir = 'Test_2'
    template_name = 'abc'
    file_name = 'abc.json'
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name)


# Generated at 2022-06-23 16:33:02.412405
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'test'
    replay_dir = '/home/user/cookiecutter-replay'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/home/user/cookiecutter-replay/test.json'


# Generated at 2022-06-23 16:33:09.373814
# Unit test for function dump
def test_dump():
    import pytest
    import sys
    import shutil
    sys.path.append('../')
    from cookiecutter.user_config import DEFAULT_CONFIG
    from cookiecutter.prompt import read_user_variable
    from cookiecutter.main import cookiecutter
    from cookiecutter.config import get_user_config, get_config_from_dict
    from cookiecutter.replay import dump, load

    user_config = get_user_config()
    config_dict = get_config_from_dict(user_config['default_context'],
                                       DEFAULT_CONFIG, None, None)
    context = read_user_variables(
        config_dict, context_file=None, default_context=False
    )

    dump(replay_dir, template_name, context)
    context2

# Generated at 2022-06-23 16:33:16.320984
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join('/tmp', 'cookiecutter')
    template_name = 'test.json'
    context = {"cookiecutter":{"full_name":"Cookiecutter","email":"test@test.com"}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
