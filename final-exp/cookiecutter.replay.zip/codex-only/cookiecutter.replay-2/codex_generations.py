

# Generated at 2022-06-23 16:23:17.572282
# Unit test for function load
def test_load():
    """Test function load."""
    #TODO: unit test for function load
    pass

# Generated at 2022-06-23 16:23:21.526329
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests/files'
    template_name = 'test_template'
    expected = 'tests/files/test_template.json'
    assert get_file_name(replay_dir, template_name) == expected

# Unit tests for function dump

# Generated at 2022-06-23 16:23:23.805867
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay_dir','template_name') == 'replay_dir/template_name.json'



# Generated at 2022-06-23 16:23:35.364366
# Unit test for function load
def test_load():
    """load test."""
    from cookiecutter.utils import rmtree
    from cookiecutter.main import cookiecutter

    cwd = os.getcwd()
    pwd = os.path.dirname(os.path.abspath(__file__))

    result = cookiecutter(
        'tests/test-repo-tmpl/',
        no_input=True,
        overwrite_if_exists=True,
        replay_dir=os.path.join(cwd, 'tests/test-replay-dir')
    )
    replay_dir = os.path.join(cwd, 'tests/test-replay-dir')
    template_name = 'tests/test-repo-tmpl'
    context = load(replay_dir, template_name)

# Generated at 2022-06-23 16:23:39.225276
# Unit test for function get_file_name
def test_get_file_name():
    assert(get_file_name('dir', 'dir') == 'dir/dir.json')
    assert(get_file_name('dir', 'dir.json') == 'dir/dir.json')

# Unit test function dump and load

# Generated at 2022-06-23 16:23:41.157489
# Unit test for function dump
def test_dump():
	d = {'key1': 'value1', 'key3': 'value3'}
	dump('temp', 'test', d)


# Generated at 2022-06-23 16:23:43.686154
# Unit test for function get_file_name
def test_get_file_name():
    expected = '/home/user/cc_replay/template_name.json'
    assert get_file_name('/home/user/cc_replay', 'template_name') == expected

# Generated at 2022-06-23 16:23:47.936271
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for get_file_name."""
    assert get_file_name('/home/', 'my_template') == '/home/my_template.json'
    assert get_file_name('/home/', 'my_template.json') == '/home/my_template.json'

# Generated at 2022-06-23 16:23:53.947072
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/vagrant/cookiecutter-pypackage'
    template_name = 'cookiecutter-pypackage'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name=='/home/vagrant/cookiecutter-pypackage/cookiecutter-pypackage.json'
    print('Test passed.')

# Generated at 2022-06-23 16:24:05.206716
# Unit test for function load
def test_load():
    # create a mock template name and context
    template_name = 'test_template_name'
    context = {'cookiecutter': {'test1': 'test1', 'test2': 'test2'}}

    # dump the context to json file
    dump('./tests/fake-replay-dir', template_name, context)

    # load the context from json file
    load_context = load('./tests/fake-replay-dir', template_name)

    # remove the json file
    os.remove(get_file_name('./tests/fake-replay-dir', template_name))

    # check whether the context loaded from file is the same with the context dumped
    assert context == load_context

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:24:10.451111
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    from cookiecutter.replay import get_file_name
    template_name = 'author/name'
    replay_dir = '/tmp'
    expected_output = '/tmp/author/name.json'
    output = get_file_name(replay_dir, template_name)
    assert output == expected_output


# Generated at 2022-06-23 16:24:20.848379
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'first_template.json'
    replay_dir = ''
    test_file_name = get_file_name(replay_dir, template_name)
    assert test_file_name == os.path.join(replay_dir, template_name)

    template_name = 'first_template'
    test_file_name = get_file_name(replay_dir, template_name)
    assert test_file_name == os.path.join(replay_dir, 'first_template.json')

    replay_dir = '/path/to/replay/dir'
    test_file_name = get_file_name(replay_dir, template_name)
    assert test_file_name == os.path.join(replay_dir, 'first_template.json')



# Generated at 2022-06-23 16:24:29.799031
# Unit test for function dump
def test_dump():
    # Generate the 'replay' directory
    replay_dir = os.path.join('.', 'replay')
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    # Generate the 'replay' file
    replay_file = os.path.join(replay_dir, 'test.json')

# Generated at 2022-06-23 16:24:39.472908
# Unit test for function load
def test_load():          
    template_name = 'C:/Users/tiany/Desktop/cookiecutter-python'
    replay_dir = 'C:/Users/tiany/Desktop/cookiecutter-python/replay'
    template_name = 'C:/Users/tiany/Desktop/cookiecutter-python'
    replay_dir = 'C:/Users/tiany/Desktop/cookiecutter-python/replay'
    try:
        context = load(replay_dir, template_name)
    except TypeError as e:
        print(e)


# Generated at 2022-06-23 16:24:44.194602
# Unit test for function load
def test_load():
    s = "{{cookiecutter.name}}"
    context = {"cookiecutter": {"name": "lei"}}
    assert s.format(**context) == "lei"

# Generated at 2022-06-23 16:24:50.201997
# Unit test for function load
def test_load():
    template_name = 'test'
    context = {'cookiecutter':{'test':'test'}}
    replay_dir = 'C:\\Users\\Kolan\\replay_dir'
    file_name = get_file_name(replay_dir,template_name)

    with open(file_name, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    with open(file_name, 'r') as infile:
        context = json.load(infile)
    assert context['cookiecutter']['test'] == 'test'



# Generated at 2022-06-23 16:24:58.492780
# Unit test for function dump
def test_dump():
    replay_dir = 'TestDirectory'
    template_name = 'TestTemplate'
    context = {'cookiecutter': {'full_name': 'TestName'}}
    dump(replay_dir, template_name, context)
    filename, reads = get_file_name(replay_dir, template_name), open(get_file_name(replay_dir, template_name), 'r').read()
    with open(filename, 'r') as readfile:
        data = json.load(readfile)
        assert data == context
    os.remove(filename)
    assert not os.path.exists(filename)


# Generated at 2022-06-23 16:25:04.097114
# Unit test for function dump
def test_dump():
    try:
        dump('', [], {})
        assert False
    except TypeError:
        assert True
    try:
        dump('', '', [])
        assert False
    except TypeError:
        assert True
    try:
        dump('', '', {})
        assert False
    except ValueError:
        assert True
    try:
        dump('', '', {'cookiecutter': ''})
        assert True
    except ValueError:
        assert False

if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-23 16:25:08.020797
# Unit test for function get_file_name
def test_get_file_name():
    """
    Get the name of file.
    """
    replay_dir = os.path.join('../','replay')
    template_name = 'hulucat'
    assert(get_file_name(replay_dir, template_name) == '../replay/hulucat.json')


# Generated at 2022-06-23 16:25:12.018196
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = "/Users/xinglong/Desktop/cookiecutter/test_dir"
    template_name = "cc_test0"
    context = {'cookiecutter': {'test_key0': 'test_value0'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:25:15.346278
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('test', 'test') == 'test/test.json'
    assert get_file_name('test', 'test.json') == 'test/test.json'

# Generated at 2022-06-23 16:25:21.685826
# Unit test for function dump
def test_dump():
    replay_dir = 'cookiecutter/templates/tests/test-output/test_replay_dir'
    template_name = 'test_template'
    data = {'cookiecutter': {'test-key': 'test-value'}}
    dump(replay_dir, template_name, data)
    data_loaded = load(replay_dir, template_name)
    assert data_loaded == data
    os.remove('cookiecutter/templates/tests/test-output/test_replay_dir/test_template.json')


# Generated at 2022-06-23 16:25:25.852813
# Unit test for function dump
def test_dump():
    """Unit test for function dump"""
    from cookiecutter.main import cookiecutter
    context = cookiecutter("/home/matt/Documents/mattmccaskey/pzm-scripts/cookiecutter-pzm/", no_input=True, replay=True)
    dump("/home/matt/Documents/mattmccaskey/pzm-scripts/replay/", "test_dump", context)
    context2 = load("/home/matt/Documents/mattmccaskey/pzm-scripts/replay/", "test_dump")
    assert(context['cookiecutter']['dataset'] == context2['cookiecutter']['dataset'])


# Generated at 2022-06-23 16:25:31.107355
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/nirav/python-projects/replay'
    template_name = 'gh:niravsanghavi/cookiecutter-pypackage'
    file_name = 'gh:niravsanghavi/cookiecutter-pypackage.json'
    assert get_file_name(replay_dir, template_name) == file_name


# Generated at 2022-06-23 16:25:37.562403
# Unit test for function dump
def test_dump():
    """Test for dump function."""
    template_name = "test_dump"
    replay_dir = './'
    context = {"cookiecutter": {'test': 'test'}}
    dump(replay_dir, template_name, context)

    context_file = get_file_name(replay_dir, template_name)
    with open(context_file, 'r') as infile:
        context = json.load(infile)
    os.remove(context_file)

    assert 'cookiecutter' in context
    assert context['cookiecutter'] == {'test': 'test'}



# Generated at 2022-06-23 16:25:48.038090
# Unit test for function load
def test_load():
    # Test for missing key
    try:
        replay_dir = 'tests/test-load/'
        template_name = 'test_load'
        load(replay_dir, template_name)
    except ValueError:
        # Test passes
        return
    else:
        # Test fails
        raise ValueError('load did not raise expected error')

    # Test for missing file
    try:
        replay_dir = 'tests/test-load/'
        template_name = 'file-does-not-exist'
        load(replay_dir, template_name)
    except IOError:
        # Test passes
        return
    else:
        # Test fails
        raise IOError('load did not raise expected error')

test_load()


# Generated at 2022-06-23 16:25:51.244002
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name"""
    try:
        assert get_file_name('dir', 'name') == 'dir/name.json'
        assert get_file_name('dir', 'name.json') == 'dir/name.json'
    except:
        raise

# Generated at 2022-06-23 16:25:55.264256
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/replay/'
    template_name = 'cookie_test'
    context = {'abc':'abc','def':'def','ghi':'ghi','jkl':'jkl','mno':'mno'}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:26:00.573933
# Unit test for function get_file_name
def test_get_file_name():
	"""
	"""
	replay_dir = '/home/jkaminski/Work/cookiecutters/tests_cookiecutter/04_simple_project'
	template_name = 'my_project_name'

	assert get_file_name(replay_dir, template_name) == '/home/jkaminski/Work/cookiecutters/tests_cookiecutter/04_simple_project/my_project_name.json'


# Generated at 2022-06-23 16:26:05.367790
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'test_replay_dir'
    template_name = 'test_template'
    context = {'cookiecutter': {'project_name': 'test_project'}}
    dump(replay_dir, template_name, context)
    test_file_name = get_file_name(replay_dir, template_name)
    assert os.path.exists(test_file_name)
    os.remove(test_file_name)


# Generated at 2022-06-23 16:26:10.260654
# Unit test for function dump
def test_dump():
    """Test for dump() function."""
    import json
    replay_dir = './replay/'
    template_name = './templates/tests/fake-repo-pre/'
    context = {'cookiecutter':
               {
                   'full_name': 'Tommaso Barbugli',
                   'email': 'tbarbugli@gmail.com',
                   'company': 'ACME',
                   'project_name': 'Thing',
                   'project_short_description': 'A short description of the project.',
                   'pypi_username': 'tbarbugli',
               },
               '_template': template_name
               }
    dump(replay_dir, template_name, context)

# Generated at 2022-06-23 16:26:12.662501
# Unit test for function dump
def test_dump():
    json_dict = {'cookiecutter':{}}
    assert isinstance(json_dict, dict)
    with open('test.json', 'w') as outfile:
        json.dump(json_dict, outfile, indent=2)

if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-23 16:26:18.008461
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = '../tests/test_replay'
    context = { 'cookiecutter': { 'name': 'test' } }
    dump(replay_dir, template_name, context)
    return os.path.isfile(get_file_name(replay_dir, template_name))


# Generated at 2022-06-23 16:26:24.786017
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join('.', 'tests', 'test_replay_dir')
    template_name = 'test_template'
    context = {
        'cookiecutter': {
            '_template': template_name,
            'name': 'Test Project'
        }
    }
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        from_file = json.load(infile)
        assert from_file == context
    

# Generated at 2022-06-23 16:26:26.149727
# Unit test for function dump
def test_dump():
    assert(True)


# Generated at 2022-06-23 16:26:32.348646
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('~/projects/cookiecutter/tests/test_replay', 'test') == '~/projects/cookiecutter/tests/test_replay/test.json'
    assert get_file_name('~/projects/cookiecutter/tests/test_replay', 'test.json') == '~/projects/cookiecutter/tests/test_replay/test.json'


# Generated at 2022-06-23 16:26:38.495044
# Unit test for function dump
def test_dump():
    # Test the function
    from cookiecutter.prompt import read_user_variable, prompt_for_config
    context = prompt_for_config(read_user_variable)

    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre/'

    dump(replay_dir, template_name, context)
    for k, v in context.items():
        assert v == load(replay_dir, template_name)[k]

# Generated at 2022-06-23 16:26:47.245741
# Unit test for function load
def test_load():
    template_name = "invalid_context"
    replay_dir = "/tmp"
    replay_file = get_file_name(replay_dir, template_name)
    try:
        with open(replay_file, 'a') as infile:
            infile.write("invalid_context")
        load(replay_dir, template_name)
        assert False
    except ValueError as e:
        assert True
        print(e)
    finally:
        os.remove(replay_file)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:26:51.410026
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replay_dir'
    for template_name in ['foo', 'bar.json']:
        file_name = get_file_name(replay_dir, template_name)
        assert isinstance(file_name, str)
        assert os.path.basename(file_name) == template_name + '.json'
        assert os.path.dirname(file_name) == replay_dir

# Generated at 2022-06-23 16:27:01.761179
# Unit test for function get_file_name
def test_get_file_name():
    # Test with no suffix
    replay_dir1 = '/home/test/cookiecutter-replay'
    template_name1 = 'cookiecutter-pypackage'
    file_name1 = get_file_name(replay_dir1, template_name1)
    expecet_file_name1 = '/home/test/cookiecutter-replay/cookiecutter-pypackage.json'
    assert file_name1 == expecet_file_name1

    # Test with suffix
    replay_dir2 = '/home/test/cookiecutter-replay'
    template_name2 = 'cookiecutter-pypackage.json'
    file_name2 = get_file_name(replay_dir2, template_name2)

# Generated at 2022-06-23 16:27:05.677277
# Unit test for function get_file_name
def test_get_file_name():
    name = 'template'
    result = get_file_name('.', name)
    assert result == os.path.join('.', 'template.json')

    name = 'template.json'
    result = get_file_name('.', name)
    assert result == os.path.join('.', 'template.json')



# Generated at 2022-06-23 16:27:10.714844
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'cookiecutter_tests/tests/test-replay'
    expected_file_name = 'cookiecutter_tests/tests/test-replay/example_name.json'
    actual_file_name = get_file_name(replay_dir, 'example_name')
    assert expected_file_name == actual_file_name
    print("Unit test for function get_file_name")
    print("Expected file name: ", expected_file_name)
    print("Actual file name: ", actual_file_name)
    print("Test for function get_file_name successful")


# Generated at 2022-06-23 16:27:19.401062
# Unit test for function dump
def test_dump():
    """Test dump()."""
    replay_dir = os.path.join(os.path.dirname(__file__), '../tests/fake-repo-pre/')
    template_name = 'fakerepo-pre'
    context = {
      "cookiecutter": {
        "encoding": "UTF-8",
        "pytest_plugin": "pytest11",
        "release_date": "2017-11-21",
        "repo_name": "My Fake Python Project",
        "repo_slug": "my-fake-python-project",
        "year": "2017"
      }
    }
    file_name = get_file_name(replay_dir, template_name)
    print(file_name)
    dump(replay_dir, template_name, context)

# Generated at 2022-06-23 16:27:25.294960
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/Users/zhaoyongjian/Documents/Python/GitHub/cookiecutter/cookiecutter/tests/test-replay/'
    template_name = 'template_name'
    assert get_file_name(replay_dir, template_name) == '/Users/zhaoyongjian/Documents/Python/GitHub/cookiecutter/cookiecutter/tests/test-replay/template_name.json'


# Generated at 2022-06-23 16:27:29.294864
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = '~/replay'
    template_name = 'template'
    suffix = '.json'
    expected = os.path.join(replay_dir, template_name+suffix)
    actual = get_file_name(replay_dir, template_name)
    assert actual == expected
    return expected

# Generated at 2022-06-23 16:27:37.245012
# Unit test for function dump
def test_dump():
    template_name = 'tmp'
    context = {
        'cookiecutter': {
            'replay': 'test'
        }
    }

    dump('test', template_name, context)

    replay_file = 'test/tmp.json'
    with open(replay_file, 'r') as infile:
        read_context = json.load(infile)

    os.remove(replay_file)
    os.rmdir('test')

    assert read_context == context

test_dump()

# Generated at 2022-06-23 16:27:47.637772
# Unit test for function load
def test_load():
    """Unit tests for function load."""
    import json
    import os
    import shutil

    from cookiecutter.replay import dump, load


# Generated at 2022-06-23 16:27:55.948233
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/Users/sarawali"
    template_name = "sarawali"
    expected_output = "/Users/sarawali/sarawali.json"
    print("replay_dir is",replay_dir)
    output = get_file_name(replay_dir,template_name)
    print("expected output is",expected_output)
    print("output is",output)
    if output == expected_output:
        raise "get_file_name is working"


# Generated at 2022-06-23 16:28:07.041863
# Unit test for function dump
def test_dump():    # pragma: no cover
    import shutil
    # clean the replay directory if it exists
    replay_dir = 'test_replay'
    if os.path.exists(replay_dir):
        shutil.rmtree('test_replay')

    # dump some data in test_replay
    dump_data = {'cookiecutter': {}}
    dump('test_replay', 'test_template', dump_data)

    # read the data from test_replay
    load_data = load('test_replay', 'test_template')

    # remove the replay directory and the test_template.json
    if os.path.exists(replay_dir):
        shutil.rmtree('test_replay')

    assert dump_data == load_data

# Generated at 2022-06-23 16:28:10.310547
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'full_name': 'Evan Chang', 'email': 'evan.chang@yale.edu'}}
    replay_dir = 'replay_dir'
    template_name = 'python_package'
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:28:15.361848
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    replay_dir = 'replays'
    template_name = 'cookiecutter-pypackage'
    assert get_file_name(replay_dir, template_name) == 'replays/cookiecutter-pypackage.json'


# Generated at 2022-06-23 16:28:19.726797
# Unit test for function dump
def test_dump():
    context = dict(cookiecutter=dict(test='test'))
    template_name = 'test'
    replay_dir = 'cookiecutter/tests/test-replay'
    dump(replay_dir, template_name, context)
    assert True


# Generated at 2022-06-23 16:28:21.905586
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("./", "base") == "./base.json"
    assert get_file_name("./", "base.json") == "./base.json"

# Generated at 2022-06-23 16:28:25.805064
# Unit test for function load
def test_load():
    replay_dir = '/Users/yujiayang/Desktop/GitHub/yujia-yang.github.io'
    template_name = 'index.md'
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-23 16:28:27.499192
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('./replay', 'template_name') == './replay/template_name.json'


# Generated at 2022-06-23 16:28:34.421659
# Unit test for function dump
def test_dump():
    """Save dict to json file."""
    import tempfile
    import shutil
    import json
    template_name = 'test_template'
    temporary_directory = tempfile.mkdtemp()
    context = {
        'cookiecutter': {
            'repo_dir': '.',
            'context': {
                'cookiecutter': {
                    'project_name': 'Test Project Name',
                    'project_slug': 'test_project_name',
                    'author_name': 'Test Author Name',
                }
            }
        }
    }
    dump(temporary_directory, template_name, context)
    assert os.path.isfile(os.path.join(temporary_directory, template_name+".json")) == True
    shutil.rmtree(temporary_directory)

# Generated at 2022-06-23 16:28:39.357424
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'key': 'value'}}
    replay_dir = 'test_dir'
    template_name = 'test_template'
    dump(replay_dir, template_name, context)
    assert os.path.exists(replay_dir)
    

# Generated at 2022-06-23 16:28:41.716158
# Unit test for function get_file_name
def test_get_file_name():
	assert get_file_name("replay/", "template_name") == "replay/template_name.json"
	assert get_file_name("replay/", "template_name.json") == "replay/template_name.json"

# Generated at 2022-06-23 16:28:49.230151
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/tmp', 'abc/xyz') == '/tmp/abc/xyz'
    assert get_file_name('/tmp', 'abc/xyz.json') == '/tmp/abc/xyz.json'
    assert get_file_name('/tmp', 'abc/xyz') == '/tmp/abc/xyz'
    assert get_file_name('/tmp', 'abc/xyz') == '/tmp/abc/xyz'
    assert get_file_name('/tmp', 'abc/xyz') == '/tmp/abc/xyz'
    assert get_file_name('/tmp', 'abc/xyz') == '/tmp/abc/xyz'
    assert get_file_name('/tmp', 'abc/xyz') == '/tmp/abc/xyz'
    assert get_file_

# Generated at 2022-06-23 16:29:02.140600
# Unit test for function load
def test_load():
    assert load('../tests/fixtures/fake-repo-pre/', 'json1.json') == {'cookiecutter':{'full_name':'Audrey Roy','email':'audreyr@example.com','project_name':'json1','repo_name':'json1','project_short_description':'A short description of the project.','_template':'https://github.com/shaoziyang/cookiecutter-pypackage.git'}}

# Generated at 2022-06-23 16:29:07.524390
# Unit test for function dump
def test_dump():
    replay_dir = 'D:\\CODE\\python\\vscode\\cookiecutter\\tests\\test-output\\replay'
    template_name = 'jinja2'
    context = {'cookiecutter': {
    'full_name': 'Audrey Roy Greenfeld',
    'email': 'audreyr@example.com'
    }}

    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:29:13.552815
# Unit test for function dump
def test_dump():
    context = {'cookiecutter': {'name': 'john-lennon', 'email': 'lennon@thebeatles.com'}}
    template_name = 'beatles'
    replay_dir = 'replay'
    dump(replay_dir, template_name, context)
    # Verify that JSON file is created
    replay_file = get_file_name(replay_dir, template_name)
    if os.path.isfile(replay_file):
        print("JSON file created")
        print (open(replay_file).read())
    else:
        print("JSON file not created")


# Generated at 2022-06-23 16:29:18.320977
# Unit test for function load
def test_load():
    context = load(replay_dir='/Users/jkamalas/code/ccut/tests/test-replay', template_name='pyctdev/cookiecutter-pytest-plugin')
    assert(context['cookiecutter']['package_slug'] == 'pytest-cookiecutter')

# Generated at 2022-06-23 16:29:24.442189
# Unit test for function get_file_name
def test_get_file_name():
    """check whether the file name is valid."""
    assert get_file_name("E:\project\\repo_dir\python\\template_dir", "test1.json") == "E:\project\\repo_dir\python\\template_dir\\test1.json"
    assert get_file_name("E:\project\\repo_dir\python\\template_dir", "test2") == "E:\project\\repo_dir\python\\template_dir\\test2.json"


# Generated at 2022-06-23 16:29:30.766036
# Unit test for function dump
def test_dump():
    """Test the dump function."""
    context = {
        "project_name": "Example Project",
        "repo_name": "example_repo",
        "cookiecutter": {
            "full_name": "Your Name",
            "email": "your@email.com",
            "github_username": "your_github_username",
            "sublime_text_extensions": "sublime_text_extensions",
            "pycharm_extensions": "pycharm_extensions"
        }
    }


# Generated at 2022-06-23 16:29:41.193631
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    from cookiecutter.config import DEFAULT_CONFIG
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    from cookiecutter.prompt import prompt_for_config
    from tests.test_utils import TEST_TEMPLATE_DIR

    replay_dir = os.path.join(TEST_TEMPLATE_DIR, 'replay_files')
    no_input = {"cookiecutter": {"full_name": "Simon Belak", "email": "simon.belak@gmail.com"}}

    cookiecutter(TEST_TEMPLATE_DIR, no_input=no_input, replay_dir=replay_dir)


# Generated at 2022-06-23 16:29:45.968348
# Unit test for function get_file_name
def test_get_file_name():
    test_dir = 'test_dir'
    test_template_name = 'test_template_name'
    assert get_file_name(test_dir, test_template_name) == os.path.join(test_dir, 'test_template_name.json')
    assert get_file_name(test_dir, test_template_name + '.json') == os.path.join(test_dir, 'test_template_name.json')


# Generated at 2022-06-23 16:29:55.416212
# Unit test for function dump
def test_dump():
    import shutil
    from os.path import exists, join, dirname
    from tempfile import mkdtemp
    from json import loads, dumps

    tmp_dir = mkdtemp()

    replay_dict = {
        'cookiecutter': {
            'repo_dir': '.',
            'no_input': True,
            'extra_context': {
                'foo': 'bar',
            }
        }
    }

    dump(tmp_dir, 'foobar', replay_dict)

    assert exists(join(tmp_dir, 'foobar.json'))

    with open(join(tmp_dir, 'foobar.json'), 'r') as fp:
        replay_dict = loads(fp.read())


# Generated at 2022-06-23 16:30:05.665547
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/home/rajat/Desktop"
    template_name = "Cookiecutter"
    file_name = "/home/rajat/Desktop/Cookiecutter.json"
    assert(file_name == get_file_name(replay_dir, template_name))

    replay_dir = "/home/rajat/Desktop"
    template_name = "Cookiecutter.json"
    file_name = "/home/rajat/Desktop/Cookiecutter.json"
    assert(file_name == get_file_name(replay_dir, template_name))


# Generated at 2022-06-23 16:30:08.869639
# Unit test for function load
def test_load():
    replay_dir='C:\\Users\\shangliu\\Desktop\\test'
    template_name='test'
    context=load(replay_dir,template_name)
    print(context)


# Generated at 2022-06-23 16:30:14.078572
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join(os.path.expanduser("~"), ".cookiecutters")
    template_name = "https://github.com/pydanny/cookiecutter-django.git"
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, template_name + ".json")


# Generated at 2022-06-23 16:30:20.483749
# Unit test for function get_file_name
def test_get_file_name():
    assert(get_file_name('./', 'default_context') == './default_context.json')
    assert(get_file_name('./', 'default_context.json') == './default_context.json')
    assert(get_file_name('.', 'default_context') == './default_context.json')
    assert(get_file_name('.', 'default_context.json') == './default_context.json')

# Generated at 2022-06-23 16:30:27.298404
# Unit test for function load
def test_load():
    from cookiecutter import replay
    replay_dir = os.path.join(os.path.dirname(replay.__file__), "tests", "test-replay")
    template_name = "test_template"
    context = replay.load(replay_dir, template_name)
    print(context)
    assert context['cookiecutter']['name'] == 'Some name'
    assert context['cookiecutter']['project_name'] == 'Some name'


# Generated at 2022-06-23 16:30:32.121145
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join(os.getcwd(), "replays")
    template_name = "../tests/fake-repo-pre/{{cookiecutter.project_name}}"
    file_name = '../tests/fake-repo-pre/{{cookiecutter.project_name}}.json'
    assert get_file_name(replay_dir, template_name) == file_name


# Generated at 2022-06-23 16:30:38.595793
# Unit test for function load
def test_load():
    assert load('.', 'cookiecutter-pypackage') != None

# Generated at 2022-06-23 16:30:40.385125
# Unit test for function load
def test_load():
    context = load("../","context.json")
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:30:49.704268
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay'

    if os.path.isdir(replay_dir):
        shutil.rmtree(replay_dir)

    template_name = 'test-template1'
    context = {'cookiecutter': {'full_name': 'Jane Doe'}}
    dump(replay_dir, template_name, context)

    file_name = get_file_name(replay_dir, template_name)
    file_content = open(file_name, 'r').read()
    assert file_content == '{\n  "cookiecutter": {\n    "full_name": "Jane Doe"\n  }\n}'

    # Clean up test
    if os.path.isdir(replay_dir):
        shutil.rmtree(replay_dir)

# Generated at 2022-06-23 16:30:54.038315
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "test_replay_dir"
    template_name = "test_template"
    suffix = ".json"
    file_name = "test_template.json"
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name)


# Generated at 2022-06-23 16:30:58.538103
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('home/naree/', 'naree') == 'home/naree/naree.json'
    assert get_file_name('home/naree/', 'naree.json') == 'home/naree/naree.json'


# Generated at 2022-06-23 16:31:03.378656
# Unit test for function dump
def test_dump():
    import shutil
    template_name = 'test'
    replay_dir = 'test'
    context = {'cookiecutter': 'test'}
    try:
        dump(template_name, replay_dir, context)
        assert dump(template_name, replay_dir, context) == None
    except IOError:
        pass
    shutil.rmtree(replay_dir)
    


# Generated at 2022-06-23 16:31:09.901508
# Unit test for function dump
def test_dump():
    test_replay_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_replay/')
    test_context = {
        'cookiecutter': {
            'full_name': 'First Last',
            'email': 'first.last@gmail.com',
            'github_username': 'first-last',
            'project_name': 'Test project',
            'project_short_description': 'A short description of the project.',
            'pypi_username': 'first_last',
            'use_pycharm': 'n',
            'open_source_license': 'MIT',
        },
    }
    test_template_name = 'test_template'

    if os.path.exists(test_replay_dir):
        os.r

# Generated at 2022-06-23 16:31:11.246246
# Unit test for function load
def test_load():
    assert load('replay', 'django-cookiecutter') is not None

# Generated at 2022-06-23 16:31:20.184294
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    from cookiecutter.main import cookiecutter
    replay_dir = os.path.join(os.path.dirname(cookiecutter.__file__),
        'tests/test-output/')
    context = {'cookiecutter': {'replay': True}, 'full_name': 'Test'}
    template_name = 'tests/fake-repo-tmpl'
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    os.remove(get_file_name(replay_dir, template_name))
    
if __name__ == "__main__":
    test_dump()

# Generated at 2022-06-23 16:31:24.125271
# Unit test for function dump
def test_dump():
    replay_dir = '~/hooks/tests/replay_dir'
    template_name = '~/hooks/tests/template_name'
    context = {'cookiecutter': {}}

    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:31:31.548529
# Unit test for function dump
def test_dump():
    import sys
    import json
    def fake_make_sure_path_exists():
        return True
    def fake_open(filename, mode):
        return sys.stdout
    def fake_get_file_name(replay_dir, template_name):
        return 'test_dump.json'
    replay_dir = '.'
    template_name = 'template_name'
    context = {'cookiecutter': {'replay': 'bar'}}
    _open = open
    try:
        open = fake_open
        make_sure_path_exists = fake_make_sure_path_exists
        get_file_name = fake_get_file_name
        dump(replay_dir, template_name, context)
    except:
        pass
    finally:
        open = _open
        print

# Generated at 2022-06-23 16:31:36.003202
# Unit test for function dump
def test_dump():
    replay_dir = '/tmp/'
    template_name = 'mytemplate'
    context = {'cookiecutter': {'name': 'example'}}
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        data = json.load(infile)
    os.remove(replay_file)
    assert data == context


# Generated at 2022-06-23 16:31:41.499195
# Unit test for function load
def test_load():
    """Test the load function of cookiecutter.replay."""
    # Set up a fixture with a directory and a json file
    replay_dir = 'tests/fixtures/replay_dir/'
    file_name = 'tests/fixtures/replay_dir/template.json'

    # The file has something to write
    context = load(replay_dir, 'template')
    return context

# Generated at 2022-06-23 16:31:46.296349
# Unit test for function load
def test_load():
    context = load("{{cookiecutter.project_name}}/tests/test_load_data/", "sample")
    assert(context["cookiecutter"]["project_name"] == "repo_name")
    assert(context["cookiecutter"]["year"] == "2019")

# Generated at 2022-06-23 16:31:50.001361
# Unit test for function load
def test_load():
    replay_dir = "replay-dir"
    template_name = "template-name"
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:31:51.872947
# Unit test for function load
def test_load():
    assert load('~', 'test') == {'cookiecutter': {}}

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:31:57.789943
# Unit test for function get_file_name
def test_get_file_name():
    """test for function get_file_name."""
    replay_dir = os.getcwd()
    template_name = 'helloworld'
    filename = get_file_name(replay_dir, template_name)
    assert filename == os.path.join(replay_dir, 'helloworld.json')


# Generated at 2022-06-23 16:32:04.093968
# Unit test for function load
def test_load():
    template_name = 'template_name'
    replay_dir = 'replay_dir'
    context = {'cookiecutter': {'a':'a'}}
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter': {'a':'a'}}



# Generated at 2022-06-23 16:32:10.416647
# Unit test for function get_file_name
def test_get_file_name():
    """Test for function get_file_name."""
    replay_dir = '.'
    template_name = '{{cookiecutter.repo_name}}'
    file_name = get_file_name(replay_dir, template_name)
    print(file_name)
    assert file_name == os.path.join('.', '{{cookiecutter.repo_name}}.json'), \
        'Wrong file_name'


# Generated at 2022-06-23 16:32:14.339720
# Unit test for function load
def test_load():
    template_name = 'C:\\Users\\luoy2\\workspace\\Cookiecutter-Data-Science\\cookiecutter-data-science'
    replay_dir = 'C:\\Users\\luoy2\\workspace'
    context = load(replay_dir, template_name)
    print(context)

# Generated at 2022-06-23 16:32:21.014339
# Unit test for function load
def test_load():
    test_dict = {
        'foo': 'bar',
        'baz': 'biz',
        'cookiecutter': {
            'another': {
                'test': 'success'
            }
        }
    }
    expected_template_name = 'test_template.json'

    test_dir = 'tests/test-replay-dir'
    expected_file_path = os.path.join(test_dir, expected_template_name)

    # Check that it loads an existing json file correctly
    with open(expected_file_path, 'w') as outfile:
        json.dump(test_dict, outfile, indent=2)

    actual_context = load(test_dir, expected_template_name)

    assert actual_context == test_dict

    # Check that it raises a ValueError if it doesn't have

# Generated at 2022-06-23 16:32:27.293285
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    replay_dir = 'tests/files/hello-world-template'
    template_name = 'my_template'
    assert (get_file_name(replay_dir, template_name) ==
            'tests/files/hello-world-template/my_template.json')


# Generated at 2022-06-23 16:32:30.541911
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('replay_test', 'cookiecutter-pypackage')
    assert context['cookiecutter']['project_name'] == 'real_project'



# Generated at 2022-06-23 16:32:32.677587
# Unit test for function load
def test_load():
    context = load(os.getcwd(), '.cookiecutter.json')
    print('context:', context)
    return context


# Generated at 2022-06-23 16:32:36.298308
# Unit test for function dump
def test_dump():
    # create a context that looks like the output of 'read_user_vars' in main.py
    context = {
        "cookiecutter": {
            "full_name": "Monty Python",
            "email": "python@example.com",
            "github_username": "montypython",
            "project_name": "Context Test Project",
            "project_slug": "project-slug-context-test-project",
            "repo_name": "Context Test Project",
            "select_framework": "django",
            "repo_url": ""
        },
    }
    replay_dir = '/tmp/cookiecutter-replay/'
    template_name = 'cookiecutter-pypackage'
    dump(replay_dir, template_name, context)

# Generated at 2022-06-23 16:32:40.571419
# Unit test for function get_file_name
def test_get_file_name():
    # test
    assert "cookiecutter.json" == get_file_name("/tmp", "cookiecutter")
    assert "cookiecutter1.json" == get_file_name("/tmp", "cookiecutter1.json")


# Generated at 2022-06-23 16:32:46.849939
# Unit test for function dump
def test_dump():
    replay_dir = 'C:\\Users\\cwj\\Documents\\GitHub\\cookiecutter-py-package\\tests\\test_file\\replay\\'
    template_name = 'cookiecutter-py-package'
    context = {'cookiecutter': {'full_name': 'Weinan Tang', 'email': 'tangwn@outlook.com', 'github_username': 'cwj0312'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:32:53.780959
# Unit test for function get_file_name
def test_get_file_name():
    """Test the function get_file_name."""
    assert get_file_name('/some/path', 'cookiecutter-pypackage') == os.path.join('/some/path', 'cookiecutter-pypackage.json')
    assert get_file_name('/some/path', 'cookiecutter-pypackage.json') == os.path.join('/some/path', 'cookiecutter-pypackage.json')


# Generated at 2022-06-23 16:32:57.162340
# Unit test for function load
def test_load():
    """Test load function."""
    replay_dir = '~/.cookiecutters'
    template_name = 'cookiecutter-pypackage'

    try:
        context = load(replay_dir, template_name)
    except TypeError as e:
        print('TypeError:\n{}'.format(e))
    except ValueError as e:
        print('ValueError:\n{}'.format(e))
    else:
        print('Return context: {}'.format(context))


# Generated at 2022-06-23 16:33:00.336006
# Unit test for function load
def test_load():
	"""
	Test the load function
	"""
	return load("./templates/", "./templates/cookiecutter-pypackage")

# Generated at 2022-06-23 16:33:01.685547
# Unit test for function load
def test_load():
    assert load('', 'test') is not None

# Generated at 2022-06-23 16:33:09.087699
# Unit test for function dump
def test_dump():
    # Test for cookiecutter naming error
    replay_dir = 'replay'
    template_name = 'test'
    context = {}
    str_test = 'Context is required to contain a cookiecutter key'
    try:
        dump(replay_dir, template_name, context)
    except Exception as e:
        assert type(e) == ValueError
        assert str(e) == str_test
    # Test for correct file name
    context['cookiecutter'] = ''
    expected_str = 'replay/test.json'
    assert dump(replay_dir, template_name, context) == expected_str
    # Test for correct file name with json extension
    template_name = 'test.json'
    expected_str = 'replay/test.json'

# Generated at 2022-06-23 16:33:10.213215
# Unit test for function load
def test_load():
    pass



# Generated at 2022-06-23 16:33:15.314844
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/tmp/cookiecutter/replay'
    template_name = 'template'
    result = get_file_name(replay_dir, template_name)
    assert result == '/tmp/cookiecutter/replay/template.json'


# Generated at 2022-06-23 16:33:20.999463
# Unit test for function dump
def test_dump():
    test_context = {
        'cookiecutter': {
            'name': 'test',
            'version': '1.0.0',
            'author_email': 'test@test.com',
            'description': 'test',
            'keywods': 'test, keywods',
        }
    }
    dump('cookiecutter_replay', 'test', test_context)
    assert os.path.isfile(get_file_name('cookiecutter_replay', 'test')) == True

