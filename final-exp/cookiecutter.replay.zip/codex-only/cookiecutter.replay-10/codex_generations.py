

# Generated at 2022-06-23 16:23:24.505515
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    template_name = '{{cookiecutter.author}}-{{cookiecutter.repo_name}}'
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['author'] = 'bibby'
    context['cookiecutter']['repo_name'] = 'test'
    context['cookiecutter']['project_name'] = 'test'
    context['cookiecutter']['email'] = 'bibby.liu@gmail.com'
    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    print(loaded_context)



# Generated at 2022-06-23 16:23:34.749563
# Unit test for function dump
def test_dump():
    template_name = 'testtemplate'
    context = {
        'cookiecutter': {
            'pypackage_name': 'unit-test-dump',
            'pypackage_version': '0.0.10',
            'author_name': 'Zhang Zhiyu',
            'email': 'zyzhang.cn@gmail.com',
            'description': 'unit test for function dump in file replay.py',
            'github_project_name': 'unit-test-dump',
            'source_control_url': 'https://github.com/zyzhang/unit-test-dump',
            'year': '2018',
        }
    }
    dump('./', template_name, context)


# Generated at 2022-06-23 16:23:41.286414
# Unit test for function dump
def test_dump():
    template_name = "test"
    context = dict(
        cookiecutter=dict(
            full_name='Some-Name',
            email='email@example.com',
            github_username='someusername'
        )
    )
    replay_dir = "./replay_dir"
    dump(replay_dir, template_name, context)
    assert(os.path.exists("./replay_dir/test.json"))


# Generated at 2022-06-23 16:23:50.651930
# Unit test for function get_file_name
def test_get_file_name():
    # Test missing argument
    try:
        get_file_name()
        assert False
    except TypeError:
        assert True

    # Test non-string argument
    try:
        get_file_name(7, 'a')
        assert False
    except TypeError:
        assert True
    try:
        get_file_name('a', 7)
        assert False
    except TypeError:
        assert True

    assert get_file_name('a', 'b') == 'a/b.json'
    assert get_file_name('a', 'b.json') == 'a/b.json'



# Generated at 2022-06-23 16:23:56.718089
# Unit test for function load
def test_load():
    """Test for the load function."""
    import json
    import os

    file_name = 'test_load.json'
    replay_file = os.path.join(os.getcwd(), file_name)

    data = {'cookiecutter': {'project_name': 'test'}}

    with open(replay_file, 'w') as outfile:
        json.dump(data, outfile, indent=2)

    context = load(os.getcwd(), file_name)

    assert context['cookiecutter']['project_name'] == 'test'

    os.remove(replay_file)


# Generated at 2022-06-23 16:24:06.041644
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    template_name = 'tests/fake-repo-pre/{{cookiecutter.repo_name}}'
    context = {
        'cookiecutter': {
            'repo_name': 'audreyr',
            'repo_description': 'Audrey Roy'
        }
    }
    dump(replay_dir, template_name, context)

    expected_file = os.path.join(replay_dir, 'tests/fake-repo-pre/audreyr.json')
    assert os.path.exists(expected_file)
    os.remove(expected_file)


# Generated at 2022-06-23 16:24:09.654623
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "replay-dir"
    template_name = "template-name"
    res = get_file_name(replay_dir, template_name)
    assert(res == "replay-dir/template-name.json")


# Generated at 2022-06-23 16:24:13.991960
# Unit test for function load
def test_load():
    """to test the function load"""
    context = load('~/.cookiecutters', 'git@github.com:charlespeters/cookiecutter-pypackage.git')
    assertion = 'cookiecutter' in context
    assert assertion, 'the data loaded from file must contain the cookiecuter key'

#unit test for function dump

# Generated at 2022-06-23 16:24:23.776679
# Unit test for function dump
def test_dump():
    replay_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'tests', 'test_files', 'doc-tests', 'test-replay'))
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:24:25.022653
# Unit test for function load
def test_load():
    assert load(replay_dir, template_name)


# Generated at 2022-06-23 16:24:30.511070
# Unit test for function load
def test_load():
    cookie_name = 'cookie_name'
    replay_dir = '/Users/jdumas/dev/cookiecutter/cookiecutter/tests/test-load-replay'
    context = {"cookiecutter": {cookie_name: cookie_name}}
    dump(replay_dir, 'test', context)
    new_context = load(replay_dir, 'test')
    assert new_context["cookiecutter"][cookie_name] == cookie_name

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:24:33.887628
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'test_dir'
    template_name = 'template_name'
    assert get_file_name(replay_dir, template_name) == 'test_dir/template_name.json'

# Generated at 2022-06-23 16:24:41.612263
# Unit test for function get_file_name
def test_get_file_name():
    expected_file_name_1 = "dummy/test.json"
    actual_file_name_1 = get_file_name("dummy", "test")
    assert actual_file_name_1 == expected_file_name_1

    expected_file_name_2 = "dummy2/test2.json"
    actual_file_name_2 = get_file_name("dummy2", "test2.json")
    assert actual_file_name_2 == expected_file_name_2


# Generated at 2022-06-23 16:24:45.619082
# Unit test for function load
def test_load():
    context = load(os.getcwd(), 'helloworld')
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')


# Generated at 2022-06-23 16:24:54.275356
# Unit test for function dump
def test_dump():
    replay_dir = os.path.expanduser('~/.cookiecutters/replay')
    template_name = "test"
    context = {'cookiecutter': {'name': 'tester'}}
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['name'] == 'tester'
    os.remove(get_file_name(replay_dir, template_name))
    

# Generated at 2022-06-23 16:24:59.456032
# Unit test for function load
def test_load():
    replay_dir = '~/new_pythonex/cookiecutter-master/cookiecutter/tests/test-data/fake-replay/'
    template_name = '~/new_pythonex/cookiecutter-master/cookiecutter/tests/test-data/fake-repo-tmpl/'

# Generated at 2022-06-23 16:25:04.928973
# Unit test for function load
def test_load():
    template_name = "test_template"
    replay_dir = "tests/replay_dir"
    context = {
    "cookiecutter": {
      "full_name": "Your Name",
      "email": "Your Email",
      "github_username": "Your GitHub user name",
      "project_name": "replay-dump"
    }
  }
    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert context == loaded_context
    os.remove("./tests/replay_dir/test_template.json")

# Generated at 2022-06-23 16:25:07.512742
# Unit test for function dump
def test_dump():
    # This is a test of dump
    # This will test the dump function
    assert dump
    # This is a test of test
    # This will test the test function
    assert test
    assert test_dump

# Generated at 2022-06-23 16:25:14.584919
# Unit test for function get_file_name
def test_get_file_name():
    test_replay_dir = 'replay_dir'
    test_template_name = 'test_name'

    # Test replay dir, template name, and default suffix
    file_name = get_file_name(test_replay_dir, test_template_name)
    assert file_name == 'replay_dir/test_name.json'

    # Test replay dir, template name, and suffix in template name
    test_template_name = 'test_name.json'
    file_name = get_file_name(test_replay_dir, test_template_name)
    assert file_name == 'replay_dir/test_name.json'


# Generated at 2022-06-23 16:25:19.225450
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('path/to/replay_dir', 'template_name') == 'path/to/replay_dir/template_name.json'
    assert get_file_name('path/to/replay_dir', 'template_name.json') == 'path/to/replay_dir/template_name.json'


# Generated at 2022-06-23 16:25:31.194857
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = 'test'
    expected_file_name = os.path.join('.', 'test.json')

    file_name = get_file_name(replay_dir, template_name)
    assert expected_file_name == file_name

    template_name = os.path.join('test', 'test')
    expected_file_name = os.path.join('.', 'test-test.json')

    file_name = get_file_name(replay_dir, template_name)
    assert expected_file_name == file_name

    template_name = 'test.json'
    expected_file_name = os.path.join('.', 'test.json')

    file_name = get_file_name(replay_dir, template_name)

# Generated at 2022-06-23 16:25:38.619333
# Unit test for function dump
def test_dump():
    """Test that a file is written correctly."""
    from tempfile import mkdtemp
    from cookiecutter.utils import rmtree
    # Make a temporary directory to store the JSON file
    replay = mkdtemp()

    # Make a temporary directory to be used only during the test
    tmp_dir = mkdtemp()

    template_name = os.path.join(tmp_dir, 'template_name')
    context = os.path.join(tmp_dir, 'context')

    dump(replay, template_name, context)

    # Make sure the file has been written
    assert os.path.isfile(os.path.join(replay, 'replay_file'))

    # Remove the temporary directory
    rmtree(replay)
    rmtree(tmp_dir)

# Generated at 2022-06-23 16:25:46.006674
# Unit test for function dump
def test_dump():
    """Function test for def dump(replay_dir, template_name, context)."""
    test_dir = 'tests/files'
    test_tem = 'test/files/repo'
    test_cont = {'cookiecutter': {'name': 'Travis CI', 'website': 'https://travis-ci.org/', 'repo': 'https://github.com/travis-ci/travis-ci/'}}
    dump(test_dir, test_tem, test_cont)


# Generated at 2022-06-23 16:25:50.562152
# Unit test for function load
def test_load():
    # Test for loading data from replay file
    replay_dir = 'tests'
    template_name = 'test'
    context = load(replay_dir, template_name)

    assert 'cookiecutter' in context
    assert context['cookiecutter']['project_name'] == 'Test'
    assert context['cookiecutter']['name'] == 'test'

# Generated at 2022-06-23 16:25:54.601590
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/'
    template_name = 'tests/fake-repo-pre/{{cookiecutter.project_name}}'
    context = {'cookiecutter': {'project_name': 'foobar'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:26:01.826286
# Unit test for function get_file_name
def test_get_file_name():
    # happy path
    replay_dir = './replays'
    template_name = 'template_name'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == './replays/template_name.json', 'wrong file name'

    # happy path with suffix already provided
    replay_dir = './replays'
    template_name = 'template_name.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == './replays/template_name.json', 'wrong file name'


# Generated at 2022-06-23 16:26:07.834690
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    from cookiecutter.replay import dump
    from tempfile import mkdtemp
    import os
    import json
    import shutil
    from cookiecutter.utils import make_sure_path_exists

    replay_dir = mkdtemp()

    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    template_name = 'cookiecutter-pypackage'

    dump(replay_dir, template_name, context)

    file_name = get_file_name(replay_dir, template_name)
    assert os.path.isfile(file_name)

    with open(file_name) as json_file:
        loaded_context = json.load(json_file)
        assert context == loaded_context

    shutil.r

# Generated at 2022-06-23 16:26:11.037751
# Unit test for function get_file_name
def test_get_file_name():
    if not isinstance(get_file_name('repo/path', 'the_file'), str):
        raise TypeError('The method get_file_name is required to be of type str')


# Generated at 2022-06-23 16:26:14.056248
# Unit test for function load
def test_load():
    replay_dir = 'tests/files/replay'
    template_name = 'foobar'

    context = load(replay_dir, template_name)

    assert isinstance(context, dict)
    assert 'cookiecutter' in context

# Generated at 2022-06-23 16:26:21.632118
# Unit test for function load
def test_load():
    #test_replay_dir='/Users/david/PycharmProjects/cookiecutter-Qbox/tests/test-replay'
    test_replay_dir='/Users/xinhe/Dropbox/Git/cookiecutter-qbox/tests/test-replay'
    test_replay_file='qbox_in_fortran'
    context=load(test_replay_dir,template_name=test_replay_file)
    print(context)
#============================
if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:26:26.649443
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/Users/linlin/Desktop/cookie_replay'
    template_name = 'cookiecutter-pypackage'
    file_name = get_file_name(replay_dir, template_name)
    print ("test get_file_name result: ", file_name)
    assert file_name == '/Users/linlin/Desktop/cookie_replay/cookiecutter-pypackage.json'
    


if __name__ == '__main__':
    test_get_file_name()

# Generated at 2022-06-23 16:26:30.488999
# Unit test for function load
def test_load():
    assert load('.', '{% raw %}{{ cookiecutter.repo_name }}{% endraw %}')['cookiecutter']['repo_name'] == 'cookiecutter-pypackage'


# Generated at 2022-06-23 16:26:35.999735
# Unit test for function get_file_name
def test_get_file_name():
    test_template_name = '{{ cookiecutter.repo_name }}'
    test_replay_dir = 'tests/test-output/replay'

    assert get_file_name(test_replay_dir, test_template_name) == 'tests/test-output/replay/{{ cookiecutter.repo_name }}.json'


# Generated at 2022-06-23 16:26:47.849936
# Unit test for function dump
def test_dump():
    replay_dir = '.tests_cookiecutter'
    template_name = 'test_template'
    context = {'cookiecutter': {'full_name': 'james', 'email': 'james@example.com'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(replay_dir) is True
    assert os.path.isdir(replay_dir) is True
    replay_file = os.path.join(replay_dir, template_name + '.json')
    assert os.path.exists(replay_file) is True
    assert os.path.isfile(replay_file) is True
    # Unit test for function load
    temp = load(replay_dir, template_name)

# Generated at 2022-06-23 16:26:56.863896
# Unit test for function dump
def test_dump():
    """Test dump."""
    try:
        dump('', '', '')
        raise AssertionError('This is not a valid directory')
    except IOError:
        pass
    try:
        dump('Temp', 'Temp', 'Temp')
        raise AssertionError('This is not a valid template name')
    except TypeError:
        pass
    try:
        dump('Temp', 'Temp', '')
        raise AssertionError('This is not a valid context')
    except TypeError:
        pass
    try:
        dump('Temp', 'Temp', 'Temp')
        raise AssertionError('This is not a valid context value')
    except ValueError:
        pass


# Generated at 2022-06-23 16:27:05.133049
# Unit test for function dump
def test_dump():
    replay_dir = "./tests/test_replay_dir"
    template_name = "test_template"
    context = { "cookiecutter": { "first_name": "Daniel", "company": "datascience.com" } }
    dump(replay_dir, template_name, context)
    
    # Check if file has been created successfully
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)

    # Check the context has been correctly saved
    context_from_file = load(replay_dir, template_name)
    assert context == context_from_file


# Generated at 2022-06-23 16:27:16.447444
# Unit test for function load
def test_load():
    template_name = 'unittest_replay'
    template_context = {
        'cookiecutter': {
            'name': 'replay',
            'licence': 'unittest_replay_licence',
            'email': 'unittest_replay@example.com',
        },
    }
    replay_dir = 'cookiecutter/.cookiecutters_replay'
    replay_file = 'replay.json'
    dump(replay_dir, template_name, template_context)
    try:
        assert load(replay_dir, template_name) == template_context
    except AssertionError:
        assert False
    finally:
        os.remove(os.path.join(replay_dir, replay_file))


# Generated at 2022-06-23 16:27:23.012870
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replay'
    template_name = 'a'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'replay/a.json'
    template_name = 'a.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'replay/a.json'


# Generated at 2022-06-23 16:27:24.854759
# Unit test for function get_file_name
def test_get_file_name():
    result = get_file_name('./', '.cookiecutterrc')
    assert result == './.cookiecutterrc.json'

# Generated at 2022-06-23 16:27:25.392010
# Unit test for function dump
def test_dump():
    assert 1 == 1

# Generated at 2022-06-23 16:27:35.833624
# Unit test for function get_file_name
def test_get_file_name():
    """Test for get_file_name function."""
    assert get_file_name('path/to/dir', 'template_name') == 'path/to/dir/template_name.json'
    assert get_file_name('path/to/dir', 'template_name.json') == 'path/to/dir/template_name.json'
    assert get_file_name('path/to/dir', 'template_name.json/') == 'path/to/dir/template_name.json.json'

if __name__ == "__main__":
    test_get_file_name()

# Generated at 2022-06-23 16:27:46.681050
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join('tests', 'test-replay-dir')
    template_name = os.path.join('tests', 'fake-repo-pre', '{{cookiecutter.repo_name}}')
    context = {'cookiecutter': {'full_name': 'Audrey Roy',
                                'email': 'audreyr@example.com',
                                'github_username': 'audreyr',
                                'project_name': 'My Project',
                                'project_slug': 'my_project',
                                'release_date': '2014-10-03',
                                'pypi_username': 'audreyr',
                                'copyright_holder': 'Audrey Roy'}}

# Generated at 2022-06-23 16:27:58.156277
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import os
    import shutil
    import tempfile

    replay_dir = tempfile.mkdtemp()
    template_name = 'test'

    context = {'cookiecutter': {'foo': 'bar'}}

    dump(replay_dir, template_name, context)

    # Check that a file with the correct name was created
    assert os.path.exists(get_file_name(replay_dir, template_name))

    # Check that the contents of the file is correct
    contents = '''\
{
  "cookiecutter": {
    "foo": "bar"
  }
}
'''
    assert open(get_file_name(replay_dir, template_name)).read() == contents

    # Clean up

# Generated at 2022-06-23 16:28:08.725429
# Unit test for function load
def test_load():
    data_path = os.path.join(os.path.dirname(__file__), 'data', 'test_json')
    filename = os.path.join(data_path, 'test.json')
    context = load(data_path, 'test')

# Generated at 2022-06-23 16:28:15.265404
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '~/test'
    template_name = 'first-template'
    expected_result = '~/test/first-template.json'
    actual_result = get_file_name(replay_dir, template_name)
    assert actual_result == expected_result, \
        "test_get_file_name() failed"


# Generated at 2022-06-23 16:28:18.158095
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('path', 'template') == 'path/template.json'
    assert get_file_name('path', 'template.json') == 'path/template.json'

# Generated at 2022-06-23 16:28:26.198380
# Unit test for function load
def test_load():
    file = './cookiecutter.json'
    context = load('./', file)
    # context = load('./', './cookiecutter.json')
    print('\ncontext =', context)
    print('context[\'cookiecutter\'] =', context['cookiecutter'])
    print('context[\'cookiecutter\'][\'app_name\'] =', context['cookiecutter']['app_name'])
    print('context[\'cookiecutter\'][\'project_slug\'] =', context['cookiecutter']['project_slug'])


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:28:30.527711
# Unit test for function get_file_name
def test_get_file_name():
    filename = 'test.json'
    print('test start')
    result = get_file_name('/test/test/test', filename)
    assert result == '/test/test/test/test.json'
    print('test success')

# Generated at 2022-06-23 16:28:32.521297
# Unit test for function get_file_name
def test_get_file_name():
    value = get_file_name('data', 'cookiecutter.json')
    assert value == 'data\\cookiecutter.json'


# Generated at 2022-06-23 16:28:38.164626
# Unit test for function dump
def test_dump():
    """Function to test dump, the function that writes to a json file."""
    x = {'cookiecutter': {'timezone': 'Europe/Paris'}}
    replay_dir = '/home/kirandeep/Replay'
    template_name = 'test_dump'
    dump(replay_dir, template_name, x)
    y = load(replay_dir, template_name)
    assert y == x
    os.remove('/home/kirandeep/Replay/test_dump.json')
    return

# Generated at 2022-06-23 16:28:42.324653
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.getcwd(), 'tests/test-replay')
    template_name = 'foobar'
    context = load(replay_dir, template_name)

# Generated at 2022-06-23 16:28:49.612316
# Unit test for function load
def test_load():
    context = load(replay_dir='D:\\Cookiecutter-TEMPLATES\\cookiecutter-pypackage-minimal', template_name='cookiecutter-pypackage-minimal.json')
    word = context['_template']
    print(word)
    assert word == 'cookiecutter-pypackage-minimal.json'
    # print(context)
    # context = load(replay_dir='D:\\Cookiecutter-TEMPLATES\\cookiecutter-pypackage-minimal', template_name='cookiecutter-pypackage-minimal.json')
    # word = context['_template']
    # print(word)
    # assert word == 'cookiecutter-pypackage-minimal.json'



# Generated at 2022-06-23 16:28:57.115248
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.getcwd(),'test')
    template_name = 'test_template'
    context = {"cookiecutter": {}}
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')
    return context


# Generated at 2022-06-23 16:29:02.296254
# Unit test for function load
def test_load():
    template_name = "test_load"
    replay_dir = "/tmp/.cookiecutters/"
    context = {"cookiecutter": {"something": ".", "anotherthing": "."}}
    dump(replay_dir, template_name, context)
    result_context = load(replay_dir, template_name)
    assert context == result_context

# Generated at 2022-06-23 16:29:14.056757
# Unit test for function load
def test_load():
    # context = load(replay_dir='test_replay_dir', template_name='abcdef')
    # print(context)
    template_name = 'abcdef'
    replay_dir = 'test_replay_dir'
    replay_file = get_file_name(replay_dir, template_name)
    print(replay_file)

# Generated at 2022-06-23 16:29:19.095569
# Unit test for function dump
def test_dump():
    template_name = 'D:\Download\cookiecutter-pypackage-minimal'
    context = {'cookiecutter': {'project_name': 'My Project'}}
    replay_dir = 'D:\\test'
    dump(replay_dir, template_name, context)
    

# Generated at 2022-06-23 16:29:21.825423
# Unit test for function load
def test_load():
    context = load('replay', 'template_name')
    print(context)
    return

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:29:26.260040
# Unit test for function dump
def test_dump():
    """
    Basic unit test for dump.
    """
    replay_dir = 'tests/files/test-dump'
    template_name = 'test-dump-replay-file'
    context = {
        'cookiecutter': {
            'test_key': 'test_val'
        }
    }
    dump(replay_dir, template_name, context)



# Generated at 2022-06-23 16:29:35.128042
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'project_name': 'Cool Project',
            'project_slug': 'cool-project',
            'author_name': 'Bruno Alla',
        }
    }
    import tempfile
    temp_dir = tempfile.mkdtemp()
    template_name = 'output_test_dump'
    dump(temp_dir, template_name, context)
    assert os.path.isfile(get_file_name(temp_dir, template_name))


# Generated at 2022-06-23 16:29:39.350166
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join('tests', 'files', 'replays')
    file_name = get_file_name(replay_dir, 'helloworld')
    assert file_name == os.path.join('tests', 'files', 'replays', 'helloworld.json')


# Generated at 2022-06-23 16:29:43.270430
# Unit test for function dump
def test_dump():
    replay_dir = 'empty_dir'
    template_name = 'template_name'
    context = {
        'cookiecutter': {
            'cookiecutter_dict': {}
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:29:48.300752
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test."""
    re_dir = '/home/kira/cookiecutter_test'
    name = 'cookiecutter'
    file_name = 'cookiecutter.json'
    assert get_file_name(re_dir, name) == os.path.join(re_dir, file_name)


# Generated at 2022-06-23 16:29:58.054132
# Unit test for function get_file_name
def test_get_file_name():
    assert (get_file_name('replay', 'file') == 'replay/file.json')
    assert (get_file_name('replay/', 'file') == 'replay//file.json')
    assert (get_file_name('replay', 'file.json') == 'replay/file.json')
    assert (get_file_name('', 'file') == 'file.json')
    assert (get_file_name('.', 'file') == './file.json')
    assert (get_file_name('..', 'file') == '../file.json')
    assert (get_file_name('../', 'file') == '../file.json')
    assert (get_file_name('../..', 'file') == '../../file.json')

test_get_file_name()

# Generated at 2022-06-23 16:30:03.053211
# Unit test for function load
def test_load():
    """Checks if load function works properly"""
    # "Test fails if the expected output is incorrect"
    assert load('tests/test-replay/', 'test-rep') == {'cookiecutter': {'full_name': 'Unknown'}, 'project_name': 'Test-rep'}



# Generated at 2022-06-23 16:30:06.109852
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    assert get_file_name('C://', 'cookie')=='C://\\cookie.json'


# Generated at 2022-06-23 16:30:15.929080
# Unit test for function load
def test_load():
    """
    Test load.
    """
    template_name="test_load"
    replay_dir = template_name
    context={
            "cookiecutter": {
                "full_name": "User Name",
                "email": "user@example.com",
                "github_username": "username",
                "project_name": "Sample Project",
                "project_slug": "sample_project",
                "project_short_description": "A short description of the project.",
                "pypi_username": "username",
                "release_date": "2013-01-01",
                "year": "2013",
                "use_mkdocs": "y",
                "project_license": "BSD license"
            }
        }
    dump(replay_dir, template_name, context)
    context_loaded=load

# Generated at 2022-06-23 16:30:26.788210
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    context = {'cookiecutter': {'full_name': 'Mathias Bynens', 'email': 'mathias@mailinator.com', 'github_username': 'mathiasbynens', 'project_name': 'example', 'project_slug': 'example', 'project_short_description': 'An example project.', 'project_license': 'MIT license', 'version': '0.1.0', 'release_date': '2015-03-03', 'year': '2015'}}
    file_name = 'cookiecutter.context'
    replay_dir = 'cookiecutter_json'
    template_name = 'cookiecutter-pypackage'
    dump(replay_dir, template_name, context)

# Generated at 2022-06-23 16:30:31.179260
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('foo','bar') == 'foo/bar.json'
    assert get_file_name('foo','bar.json') == 'foo/bar.json' # Already ends with .json
    assert get_file_name('foo','bar.baz.json') == 'foo/bar.baz.json' # Nested file name
    assert not get_file_name('foo','.bar') # Starts with .
    assert not get_file_name('foo','/bar') # Contains /

# Generated at 2022-06-23 16:30:42.367379
# Unit test for function load
def test_load():
    """Test if the value we load from a file is the same as the one we dumped."""
    test_template_name = 'test_load_data'
    test_replay_file = '{}.json'.format(test_template_name)
    test_replay_dir = '/tmp'
    test_context = {
        'cookiecutter': {
            '_template': test_template_name
        },
        'key1': 'value1',
        'key2': 'value2'
    }
    test_loaded_context = {
        'cookiecutter': {
            '_template': test_template_name,
            'key1': 'value1',
            'key2': 'value2'
        }
    }
    dump(test_replay_dir, test_template_name, test_context)


# Generated at 2022-06-23 16:30:51.423457
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils
    import os

    try:
        del os.environ['COOKIECUTTER_REPLAY_DIR']
    except KeyError:
        pass

    import tempfile

    temp_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_dir, 'replay'))
    os.mkdir(os.path.join(temp_dir, 'templates'))
    os.mkdir(os.path.join(temp_dir, 'templates', 'my-template'))

    # copy template files
    template_path = os.path.join(temp_dir, 'templates')

# Generated at 2022-06-23 16:31:01.396601
# Unit test for function get_file_name
def test_get_file_name():
    """Test the get_file_name function"""

    # User enter a correct path
    replay_dir = "/home/john/cookicutter/files/"
    template_name = "cookie"

    assert get_file_name(replay_dir, template_name) == "/home/john/cookicutter/files/cookie.json"

    # User enter a wrong path
    replay_dir = "/home/john/cookicutter/files/"
    template_name = "cooki"

    assert get_file_name(replay_dir, template_name) != "/home/john/cookicutter/files/cooki.json"

    # User enter a wrong path, but name still correct
    replay_dir = "/home/john/cookicutter/files/"
    template_name = "cook"


# Generated at 2022-06-23 16:31:08.769162
# Unit test for function load
def test_load():
    print('Testing load')
    import os
    import shutil
    temp_dir = './temp'
    os.makedirs(temp_dir, exist_ok=True)
    rdir = os.path.join(temp_dir, 'replay')
    tdir = os.path.join(temp_dir, 'template')
    os.makedirs(rdir, exist_ok=True)
    os.makedirs(tdir, exist_ok=True)
    
    # Create a fake template
    template_name = 'fake'
    template_file = os.path.join(tdir, template_name + '.json')

# Generated at 2022-06-23 16:31:11.844063
# Unit test for function load
def test_load():
    context = load('/Users/lucaslou/my_blog', 'my_blog_cookiecutter')
    assert isinstance(context,dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:31:14.196910
# Unit test for function load
def test_load():
    assert load('/Users/yinxia/.cookiecutters', 'cookiecutter-pypackage')



# Generated at 2022-06-23 16:31:26.076060
# Unit test for function dump
def test_dump():
    import tempfile
    import shutil
    from cookiecutter.utils import pprint

    replay_dir = tempfile.mkdtemp()
    template_name = 'Python Package'

# Generated at 2022-06-23 16:31:32.847697
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = "cookiecutter"
    template_name = "cookiecutter-pypackage-minimal"
    context = {"cookiecutter": "cookiecutter"}
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, template_name + ".json"))
    os.remove(os.path.join(replay_dir, template_name + ".json"))
    os.removedirs(replay_dir)


# Generated at 2022-06-23 16:31:41.084281
# Unit test for function load
def test_load():
    # Create random directory and json file
    random_dir = './test_load'
    template_name = './test_load/test.json'
    context = {'cookiecutter': {'name': 'Test'}}
    os.mkdir(random_dir)
    with open(template_name, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    # Try to load from this directory
    new_context = load(random_dir, template_name)
    assert context == new_context

    # Remove temporary files
    os.remove(template_name)
    os.rmdir(random_dir)

# Generated at 2022-06-23 16:31:45.429294
# Unit test for function dump
def test_dump():
    template_name = "test"
    context = {"cookiecutter": {"test": "test"}, 2: 2}
    dump("./", template_name, context)
    assert load("./", template_name) == context


# Generated at 2022-06-23 16:31:49.393460
# Unit test for function get_file_name
def test_get_file_name():
    template_name = "Cookiecutter"
    replay_dir = "./replay"
    file_name = "Cookiecutter.json"
    assert (get_file_name(replay_dir, template_name) == file_name)



# Generated at 2022-06-23 16:31:51.989339
# Unit test for function load
def test_load():
    """unit test for function load."""
    context = load('tests/test-data/fake-repo-pre/', 'fake-repo-pre')
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:31:54.844909
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("replay_dir", "template_name") == "replay_dir/template_name.json"
    assert get_file_name("replay_dir", "template_name.json") == "replay_dir/template_name.json"

# Generated at 2022-06-23 16:32:00.704922
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/'
    template_name = 'test'
    context = {
        'cookiecutter': {
            'test1': 'test1'
        },
        'test2': 'test2'
    }
    dump(replay_dir, template_name, context)
    assert os.path.isfile(os.path.join(replay_dir, 'test.json'))



# Generated at 2022-06-23 16:32:09.891025
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tmp/test_get_file_name'
    template_name = 'test'
    output = os.path.join(replay_dir, 'test.json')
    assert output == get_file_name(replay_dir, template_name)
    template_name = 'test.json'
    output = os.path.join(replay_dir, 'test.json')
    assert output == get_file_name(replay_dir, template_name)
    template_name = '.json'
    output = os.path.join(replay_dir, '.json.json')
    assert output == get_file_name(replay_dir, template_name)

# Generated at 2022-06-23 16:32:13.551364
# Unit test for function load
def test_load():
    d=load('/home/user/Desktop/Cookiecutter-python-project/{{ cookiecutter.repo_name }}/tests/fake_replay_dir', 'fake_template_name')
    import pprint
    pprint.pprint(d)


# Generated at 2022-06-23 16:32:16.954328
# Unit test for function dump
def test_dump():
    replay_dir = '~/cookiecutter_replay_test/'
    template_name = 'test_template_2'
    context = {'cookiecutter':
               {
                   'name': 'Austin',
               }
              }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:32:22.377582
# Unit test for function get_file_name
def test_get_file_name():
    dir = 'replay_dir'
    name = 'example_repo'
    name2 = 'example_repo.json'
    response = get_file_name(dir, name)
    response2 = get_file_name(dir, name2)
    assert response == 'replay_dir/example_repo.json'
    assert response2 == 'replay_dir/example_repo.json'



# Generated at 2022-06-23 16:32:31.038307
# Unit test for function get_file_name
def test_get_file_name():
    """Test for get_file_name."""
    replay_dir = 'test'
    template_name = 'template'
    template_name_with_suffix = 'template.json'
    test_file_name = get_file_name(replay_dir, template_name)
    test_file_name_with_suffix = get_file_name(replay_dir, template_name_with_suffix)
    assert(test_file_name == 'test/template.json')
    assert(test_file_name_with_suffix == 'test/template.json')

# Generated at 2022-06-23 16:32:36.296584
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/Users/keiraqian/.cookiecutters/'
    a = get_file_name(replay_dir, "cookiecutter-pypackage")
    b = get_file_name(replay_dir, "cookiecutter-pypackage.json")
    assert a == '/Users/keiraqian/.cookiecutters/cookiecutter-pypackage.json'
    assert a == b



# Generated at 2022-06-23 16:32:46.358520
# Unit test for function load
def test_load():
    replay_dir = os.path.expanduser('~')
    template_name = 'test'
    context = {'cookiecutter': {'repo_dir': '~/test', 'full_name': 'test_name'}}
    replay_file = os.path.expanduser('~/' + template_name + '.json')
    open(replay_file, 'w').close()
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    with open(replay_file, 'r') as infile:
        assert infile.readline() != ''
    os.remove(replay_file)


# Generated at 2022-06-23 16:32:49.188885
# Unit test for function get_file_name
def test_get_file_name():
    """Test for function get_file_name."""
    replay_dir = "replay"
    template_name = "test"
    
    assert get_file_name(replay_dir, template_name) == "replay/test.json"


# Generated at 2022-06-23 16:32:57.094314
# Unit test for function dump
def test_dump():
    """Unit test for dump(replay_dir, template_name, context)"""
    from cookiecutter.main import cookiecutter
    import tempfile
    
    # Dump context to replay file
    replay_dir = tempfile.mkdtemp()
    template_name = 'abc'
    context = cookiecutter('.', replay_dir=replay_dir, no_input=True)
    context['cookiecutter']['other_variable'] = 'x'
    dump(replay_dir, template_name, context)
    tempfile.rmtree(replay_dir)
    assert os.path.exists(replay_file), 'Replay file not created'

# Generated at 2022-06-23 16:33:07.143619
# Unit test for function dump
def test_dump():
    """Test dump function."""
    test_context = {'cookiecutter': {'full_name': 'Karl Riesenhuber', 'email': 'karl.riesenhuber@gmail.com', 'repo_name': 'test_repo', 'repo_name_lowercase': 'test_repo'}}
    template_name = 'test_template'
    test_replay_dir = os.path.join(os.getcwd(), 'test_replay_dir')
    dump(test_replay_dir, template_name, test_context)
    loaded_context = load(test_replay_dir, template_name)
    assert test_context == loaded_context
    os.remove(os.path.join(os.getcwd(), 'test_replay_dir', 'test_template.json'))

# Generated at 2022-06-23 16:33:10.463849
# Unit test for function get_file_name
def test_get_file_name():
    file_name = get_file_name('/home/cookiecutter', 'template1')
    assert file_name == '/home/cookiecutter/template1.json'

# Generated at 2022-06-23 16:33:20.707233
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    template_name = "https://github.com/jacebrowning/template-python-console"
    replay_dir = './replay'