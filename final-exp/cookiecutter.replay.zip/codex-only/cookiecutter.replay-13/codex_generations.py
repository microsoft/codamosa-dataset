

# Generated at 2022-06-23 16:23:22.083781
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name."""
    assert get_file_name('test_dir', 'template') == 'test_dir/template.json'
    assert get_file_name('test_dir2', 'template2.json') == 'test_dir2/template2.json'

# Generated at 2022-06-23 16:23:28.763964
# Unit test for function dump
def test_dump():

    replay_dir="/Users/hu/tools/cookiecutter-master/cookiecutter/tests/test-replay"
    template_name="class"

# Generated at 2022-06-23 16:23:35.448778
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '~/.cookiecutter_replay'
    template_name = 'foo'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '~/.cookiecutter_replay/foo.json'
    template_name = 'foo.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '~/.cookiecutter_replay/foo.json'


# Generated at 2022-06-23 16:23:44.541765
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    import shutil
    import re
    import inspect
    abs_path = inspect.getfile(inspect.currentframe())
    abs_dir = os.path.dirname(abs_path)
    replay_dir = os.path.join(abs_dir, 'test_replay_dir')
    if os.path.exists(replay_dir):
        shutil.rmtree(replay_dir)
    template_name = 'my_template'
    context1 = {
        'cookiecutter': {
            'full_name': 'First Last',
            'email': 'first.last@example.com',
            'project_name': 'My Project'
        }
    }

# Generated at 2022-06-23 16:23:52.584106
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/Users/joshuamaguire/Dropbox/projects/tlv/python/cookiecutter/cookiecutter/tests/test-replay'
    template_name = 'some_name'
    result = get_file_name(replay_dir, template_name)
    print(result)
    assert result == '/Users/joshuamaguire/Dropbox/projects/tlv/python/cookiecutter/cookiecutter/tests/test-replay/some_name.json'


# Generated at 2022-06-23 16:24:02.323163
# Unit test for function dump
def test_dump():
    """Test cookiecutter.replay.dump."""
    replay_dir = os.path.abspath('.')  # Hack to get unit test working
    with open('tests/files/replay-data.json', encoding='utf-8') as json_file:
        expected_context = json.load(json_file)
    template_name = 'test'
    context = expected_context

    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert context == expected_context

    # Clean up
    file_name = get_file_name(replay_dir, template_name)
    os.remove(file_name)

# Generated at 2022-06-23 16:24:06.257977
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/foo/bar', 'baz') == '/foo/bar/baz.json'
    assert get_file_name('/foo/bar', 'baz.json') == '/foo/bar/baz.json'


# Generated at 2022-06-23 16:24:11.987155
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'test_template'
    context = {'cookiecutter': {'test': 'dump'}}
    
    dump(replay_dir, template_name, context)
    context_file = get_file_name(replay_dir, template_name)
    with open(context_file) as data_file:
        data = json.load(data_file)  
    assert data['cookiecutter']['test'] == 'dump'


# Generated at 2022-06-23 16:24:17.587397
# Unit test for function load
def test_load():
    # Initialize replay_dir
    replay_dir = os.path.join(os.getcwd(), 'replay_dir')
    # Initialize template_name
    template_name = 'foo_template'
    # Initialize context
    context = {"cookiecutter": {"full_name": "Foo Bar", "email": "foo.bar@foobar.com"}}

    # Write context to replay file
    dump(replay_dir, template_name, context)

    # Load context from replay file
    loaded_context = load(replay_dir,'foo_template')

    # Clean up
    os.remove(os.path.join(replay_dir, 'foo_template.json'))

    assert context == loaded_context


# Generated at 2022-06-23 16:24:24.161961
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'cookiecutter_test'
    template_name = 'mytemplate'
    suffix = '.json' if not template_name.endswith('.json') else ''
    file_name = '{}{}'.format(template_name, suffix)
    expected_result = os.path.join(replay_dir, file_name)
    result = get_file_name(replay_dir, template_name)
    assert result == expected_result


# Generated at 2022-06-23 16:24:29.451863
# Unit test for function get_file_name
def test_get_file_name():
    """test function get_file_name."""
    # arrange
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    return_value = os.path.join(replay_dir, 'test_template_name.json')

    # act
    replay_file = get_file_name(replay_dir, template_name)

    # assert
    assert replay_file == return_value


# Generated at 2022-06-23 16:24:33.645351
# Unit test for function load
def test_load():
    template_name = 'python_package'
    replay_dir = os.path.join('tests', 'test-replay')
    context = load(replay_dir, template_name)
    assert context['cookiecutter'] != {}


# Generated at 2022-06-23 16:24:39.800099
# Unit test for function dump
def test_dump():
    template_name = 'test_name'
    replay_dir = '.'
    context = {'cookiecutter': {}}
    dump(replay_dir, template_name, context)
    assert os.path.exists('{}.json'.format(template_name))
    os.remove('{}.json'.format(template_name))


# Generated at 2022-06-23 16:24:46.862361
# Unit test for function get_file_name
def test_get_file_name():
    replays_dir = '/tmp'
    template_name = 'test'
    rf = get_file_name(replays_dir, template_name)
    assert rf == '/tmp/test.json'
    template_name = 'test.json'
    rf = get_file_name(replays_dir, template_name)
    assert rf == '/tmp/test.json'



# Generated at 2022-06-23 16:24:53.353501
# Unit test for function dump
def test_dump():
    """Simple test of dump."""
    template_name = 'test'
    context = {'cookiecutter': {'name': 'myproject'}}
    replay_dir = '/tmp'
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-23 16:24:56.843012
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/home', 'my_template') == '/home/my_template.json'
    assert get_file_name('/home', 'my_template.json') == '/home/my_template.json'

# Generated at 2022-06-23 16:24:59.360449
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay_dir', 'template') == 'replay_dir/template.json'
    assert get_file_name('replay_dir', 'template.json') == 'replay_dir/template.json'

# Generated at 2022-06-23 16:25:03.213819
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '{{ cookiecutter.replay_dir }}'
    template_name = '{{ cookiecutter.full_name }}'

    assert get_file_name(replay_dir, template_name) == '{{ cookiecutter.replay_dir }}/{{ cookiecutter.full_name }}.json'


#Unit test for function load

# Generated at 2022-06-23 16:25:11.982281
# Unit test for function dump
def test_dump():
        context = {
            "cookiecutter": {
                "project_name": "fakedict",
                "email": "[email protected]"
            }
        }

        replay_dir = 'fakedir'
        template_name = 'cocktail'
        try:
            dump(replay_dir, template_name, context)
        except IOError as err:
            print("Wrong replay_dir: {}".format(err))

        try:
            # template_name is not a str
            dump(replay_dir, 0, context)
        except TypeError as err:
            print("Input template_name is not a str: {}".format(err))


# Generated at 2022-06-23 16:25:13.897160
# Unit test for function get_file_name
def test_get_file_name():
    file_name = get_file_name('replay','cookiecutter-pypackage')
    assert file_name == 'replay/cookiecutter-pypackage.json'

# Generated at 2022-06-23 16:25:16.446176
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.path.dirname(os.path.abspath(__file__))
    template_name = 'testtemplate'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:25:19.713713
# Unit test for function get_file_name
def test_get_file_name():
    name = 'cookiecutter'
    dir_ = '/tmp'
    file_name = 'cookiecutter.json'

    assert get_file_name(dir_, name) == os.path.join(dir_, file_name)



# Generated at 2022-06-23 16:25:27.351686
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("/", "mongodb-rest-api") == "\\mongodb-rest-api.json"
    assert get_file_name("/", "mongodb-rest-api.json") == "\\mongodb-rest-api.json"
    assert get_file_name("/", "mongodb-rest-api.txt") == "\\mongodb-rest-api.txt.json"


# Generated at 2022-06-23 16:25:34.107438
# Unit test for function load
def test_load():
    """Test function load."""
    replay_dir = 'tests/files/test-replay'
    template_name = 'test-replay'
    test = load(replay_dir, template_name)
    assert test['cookiecutter'] == 'fake'
    assert test['project_name'] == 'Project Name'
    assert test['project_slug'] == 'project_slug'
    assert test['repo_name'] == 'project_name'
    assert test['author_name'] == 'Author Name'
    assert test['email'] == 'author@example.com'

# Generated at 2022-06-23 16:25:36.741739
# Unit test for function load
def test_load():
    """Access load() function from outside this file.

    :return: empty
    """

# Generated at 2022-06-23 16:25:47.975024
# Unit test for function load
def test_load():
    template_dir = '/Users/jkang/cookiecutter-ng2/'
    template_name = 'cookiecutter-ng2'
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    replay_file = get_file_name(replay_dir, template_name)
    # replay_file = '/Users/jkang/cookiecutter-ng2/.cookiecutter.json'
    # template_file = '/Users/jkang/cookiecutter-ng2/cookiecutter.json'
    # template_data = json.load(open(template_file, 'r'))
    # template_data.pop('cookiecutter', None)
    # # print(replay_data)
    # replay_data = get_replay_data(template_

# Generated at 2022-06-23 16:25:54.515616
# Unit test for function dump
def test_dump():
    """test function dump."""
    replay_dir = 'replay_dir'
    context = {
            'cookiecutter': {
              'full_name': 'Audrey Roy Greenfeld',
              'email': 'audreyr@example.com',
              'github_username': 'audreyr'
            }
          }
    template_name = 'test_config'
    dump(replay_dir, template_name, context)
    assert os.path.isfile(replay_dir + os.sep + template_name + '.json')


# Generated at 2022-06-23 16:25:56.263804
# Unit test for function load
def test_load():
    print(load('./replay', 'replay/pip.json'))


# Generated at 2022-06-23 16:26:04.502006
# Unit test for function dump
def test_dump():
    replay_dir = "tests/test-output"
    template_name = "cookiecutter-pypackage"
    context = {
        "cookiecutter": {
            "full_name": "Audrey Roy Greenfeld",
            "email": "audreyr@example.com",
            "project_name": "Cookiecutter",
            "project_slug": "cookiecutter",
            "release_date": "2015-05-12",
            "year": "2015",
            "version": "0.6.1",
            "repo_name": "cookiecutter"
        },
        "package_name": "cookiecutter",
        "pypi_username": "audreyr",
        "github_username": "audreyr",
        "open_source_license": "MIT license"
    }

# Generated at 2022-06-23 16:26:08.971698
# Unit test for function load
def test_load():
    """Test function load."""
    template_name = 'j2_test'
    replay_dir = './tests/test-replay'
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-23 16:26:13.052599
# Unit test for function dump
def test_dump():
    replay_dir = '../tests/files/replay'
    template_name = '{{cookiecutter.repo_name}}'
    context = 'cookiecutter'
    dump(replay_dir, template_name, context)
    assert os.path.exists(replay_dir)


# Generated at 2022-06-23 16:26:18.114450
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '../replay'
    template_name = 'template'
    file_path = get_file_name(replay_dir, template_name)
    if file_path == '../replay/template.json':
        return 0
    else:
        raise ValueError('File path did not match')
    return


# Generated at 2022-06-23 16:26:26.169357
# Unit test for function dump
def test_dump():
    import tempfile
    assert make_sure_path_exists(tempfile.gettempdir())
    replay_dir = tempfile.mkdtemp(prefix='cookiecutter-',suffix='-replay')
    assert make_sure_path_exists(replay_dir)
    template_name = 'cookiecutter-pypackage'
    cookiecutter = {'full_name':'rijo','email':'rijo@rijo.me','github_username':'rijogeorge','project_name':'cookiecutter-pypackage'}
    context = {'cookiecutter':cookiecutter,}
    dump(replay_dir,template_name,context)
    expected = os.path.join(replay_dir,template_name+'.json')
    assert os.path.isfile(expected)

# Generated at 2022-06-23 16:26:34.945475
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/replay_test'

    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'project_name': 'django-py3'}}

    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)

    assert os.path.exists(replay_file)



# Generated at 2022-06-23 16:26:41.705002
# Unit test for function get_file_name
def test_get_file_name():
    # Replay file should have .json at the end
    assert get_file_name('tests/fixtures/replay', 'my_template') == 'tests/fixtures/replay/my_template.json'
    # Replay file should not have .json at the end if template_name already contains it
    assert get_file_name('tests/fixtures/replay', 'my_template.json') == 'tests/fixtures/replay/my_template.json'

# Generated at 2022-06-23 16:26:46.560446
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    assert get_file_name('replay_dir', 'foobar') == 'replay_dir/foobar.json'
    assert get_file_name('replay_dir', 'foobar.json') == 'replay_dir/foobar.json'

# Generated at 2022-06-23 16:26:51.441714
# Unit test for function load
def test_load():
    """Ensure that the loading function is working properly."""
    template_name =  "test_template"
    replay_dir = os.path.dirname(os.path.abspath(__file__))

    context = { 'foo': 'bar'}
    dump(replay_dir, template_name, context)

    result = load(replay_dir, template_name)
    assert result

    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-23 16:26:56.157594
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/tmp'
    template_name = 'foo'
    assert get_file_name(replay_dir, template_name) == '/tmp/foo.json'
    template_name = 'foo.json'
    assert get_file_name(replay_dir, template_name) == '/tmp/foo.json'



# Generated at 2022-06-23 16:27:04.775332
# Unit test for function dump
def test_dump():
    # create replay directory
    replay_dir = 'home/replay'
    # test for valid input
    if not isinstance(replay_dir, str):
        raise TypeError('Replay directory is required to be of type str')
    if not isinstance(template_name, str):
        raise TypeError('Template name is required to be of type str')
    if not isinstance(context, dict):
        raise TypeError('Context is required to be of type dict')
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')
    replay_file = get_file_name(replay_dir, template_name)

    # test for repeated key




# Generated at 2022-06-23 16:27:09.570616
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('path/to/dir', 'test') == 'path/to/dir/test.json'
    assert get_file_name('path/to/dir', 'test.json') == 'path/to/dir/test.json'


# Generated at 2022-06-23 16:27:13.421058
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name(replay_dir='C:\\Users\\koura\\Desktop', 
    template_name="test") == 'C:\\Users\\koura\\Desktop\\test.json'

# Generated at 2022-06-23 16:27:17.568166
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = '/tmp/foo'
    template_name = 'bar'
    context = {'cookiecutter': {'name': 'test_dump'}}
    dump(replay_dir, template_name, context)

    # Read back
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-23 16:27:23.448319
# Unit test for function load
def test_load():
    """Testing the load function.
    """
    from cookiecutter.config import DEFAULT_CONFIG

    replay_dir = os.path.join(DEFAULT_CONFIG['replay_dir'], 'tests')
    template_name = 'cookiecutter-pypackage'

    context = load(replay_dir, template_name)

    assert isinstance(context, dict)
    assert 'cookiecutter' in context



# Generated at 2022-06-23 16:27:31.941259
# Unit test for function load
def test_load():
    replay_dir = "/home/yuming/pycharm_project/cookiecutter/my_test/test_dir"
    template_name = "test_replay"
    context = {"cookiecutter":{"cookiecutter":{"project_name": "test_replay"}}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, "test_replay.json") == context


if __name__ == "__main__":
    test_load()
    print("All test passed!")

# Generated at 2022-06-23 16:27:37.288489
# Unit test for function dump
def test_dump():
    cookiecutter_dict = dict()

    context = {"cookiecutter": cookiecutter_dict}

    replay_dir = os.path.join(os.path.dirname(__file__), '..', 'tests/test-replay')
    dump(replay_dir, "test_dump", context)



# Generated at 2022-06-23 16:27:47.677259
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.getcwd(), 'tests/files/replies')
    template_name = 'my-awesome-project'

# Generated at 2022-06-23 16:27:55.003020
# Unit test for function dump
def test_dump():
    replay_dir = 'test'
    template_name = 'test_name'
    context = {
        'cookiecutter': {
            'full_name': 'test_name',
            'email': 'test@email.com',
        }
    }

    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-23 16:28:06.508039
# Unit test for function dump
def test_dump():
    global context
    # Test Replay Directory
    replay_dir = 'test_replay_dir/'
    
    # Test template name
    template_name = 'example_cookiecutter_template/'
    # Load the context

# Generated at 2022-06-23 16:28:17.250540
# Unit test for function dump
def test_dump():
    # replay file name
    template_name = "test"
    # replay directory
    replay_dir = "/home/fabio/Desktop/TOOLS/cookiecutter_test/Replay_Tests/"
    # replay context
    context = {'cookiecutter': {"full_name": "Fabio Zambetta", "email": "fabio.zambetta@gmail.com", "github_username": "zambett", "project_name": "cookiecutter_test"}}
    dump(replay_dir, template_name, context)
    context2 = load(replay_dir, template_name)
    assert context2 == context
#test_dump()

# Generated at 2022-06-23 16:28:23.613194
# Unit test for function load
def test_load():
#    context = load('/home/victim/.cookiecutters/django-project', 'replay_django-project')
    context = load('/home/victim/.cookiecutters/cookiecutter-django-crud', 'replay_cookiecutter-django-crud')
    print(context)
    print(type(context))
    print(context['timezone'])

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:28:26.577313
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/home/test/', 'test') == '/home/test/test.json'
    assert get_file_name('/home/test/', 'test.json') == '/home/test/test.json'



# Generated at 2022-06-23 16:28:31.918758
# Unit test for function dump
def test_dump():
    from cookiecutter.main import cookiecutter
    from cookiecutter.main import cookiecutter
    template = 'tests/test-output/cookiecutter-json-file/'
    context = cookiecutter(template, no_input=True)
    assert dum

# Generated at 2022-06-23 16:28:35.535331
# Unit test for function load
def test_load():
    context = {}
    context["cookiecutter"] = {}
    replay_dir = ".test_replay_dir"
    template_name = "test_template"
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context



# Generated at 2022-06-23 16:28:42.282043
# Unit test for function load
def test_load():
    d = {'cookiecutter': {'repo_name': 'test_load', 'full_name': 'test_load'},
         'project': {}}
    dump('tests/test-load', 'load_test', d)
    loaded = load('tests/test-load', 'load_test')

    for item in d.keys():
        for key in d[item].keys():
            assert(loaded[item][key] == d[item][key])

# Generated at 2022-06-23 16:28:47.920222
# Unit test for function get_file_name
def test_get_file_name():
    """Get file name test."""
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'

    assert get_file_name(replay_dir, template_name) == 'test_replay_dir/test_template_name.json'



# Generated at 2022-06-23 16:28:51.696465
# Unit test for function load
def test_load():
    """Unit test for function load."""
    data = load()
    print(data)
    assert 'Hello' in data['cookiecutter']
    assert data['cookiecutter']['cookiecutter.replay'] == True


# Generated at 2022-06-23 16:28:57.497786
# Unit test for function load
def test_load():
    tmpdir = os.path.dirname(os.path.abspath(__file__))
    try:
        context = load(tmpdir, 'foo')
    except ValueError:
        print("Test pass.")
    else:
        print("Test fail.")



# Generated at 2022-06-23 16:29:02.995302
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/Users/sharonqcai/Documents/cookiecutter-example/replay/"
    template_name = "jquery"
    assert get_file_name(replay_dir, template_name) == \
    "/Users/sharonqcai/Documents/cookiecutter-example/replay/jquery.json"




# Generated at 2022-06-23 16:29:06.280548
# Unit test for function dump
def test_dump():
    assert(dump('~/cookiecutter-replay', 'django', {'cookiecutter':'testing'}) == '~/cookiecutter-replay/.json')


# Generated at 2022-06-23 16:29:14.478541
# Unit test for function load
def test_load():
    def test_load(replay_dir, template_name):
        """Read json data from file."""
        if not isinstance(template_name, str):
            raise TypeError('Template name is required to be of type str')

        replay_file = get_file_name(replay_dir, template_name)

        with open(replay_file, 'r') as infile:
            context = json.load(infile)

        if 'cookiecutter' not in context:
            raise ValueError('Context is required to contain a cookiecutter key')

        return context

# Generated at 2022-06-23 16:29:25.078934
# Unit test for function dump
def test_dump():
    # define context and template_name
    context = {"cookiecutter": {"first_name": "Audrey", "last_name": "Roy", "email": "audreyr@example.com", "github_username": "audreyr"}, "package_name": "cookiecutter-pypackage", "project_name": "Test", "repo_name": "test", "project_short_description": "A short description of the project", "pypi_username": "audreyr", "version": "0.1.0", "use_pytest": "y", "command_line_interface": "Click", "open_source_license": "MIT license"}
    template_name = 'cookiecutter-pypackage'
    # Call dump
    dump('../',template_name,context)
    
    

# Generated at 2022-06-23 16:29:28.990646
# Unit test for function dump
def test_dump():
    replay_dir = 'replay'
    template_name = 'test_dump'
    context = {'cookiecutter': {'hello': 'world'}}
    dump(replay_dir, template_name, context)
    result = load(replay_dir, template_name)
    assert context == result
    os.remove('replay/test_dump.json')
    os.rmdir('replay')


# Generated at 2022-06-23 16:29:31.387512
# Unit test for function load
def test_load():
    assert load({}, '') == None


# Generated at 2022-06-23 16:29:34.830781
# Unit test for function get_file_name
def test_get_file_name():
    template_name = "mytemplate"
    replay_dir = "/path/to/dir"
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == "/path/to/dir/mytemplate.json"

# Generated at 2022-06-23 16:29:44.919038
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name:
    object: replay_dir, template_name
    """
    # test case 1
    current = os.getcwd()
    replay = os.path.join(current, "TEST_GET_FILE_NAME1")
    template_name = "data/json"
    result = os.path.join(replay, "data/json.json")
    assert get_file_name(replay, template_name) == result
    # test case 2
    replay = os.path.join(current, "TEST_GET_FILE_NAME2")
    template_name = "data/json.json"
    result = os.path.join(replay, "data/json.json")
    assert get_file_name(replay, template_name) == result


# Generated at 2022-06-23 16:29:51.513260
# Unit test for function dump
def test_dump():
    replay_dir = os.path.dirname(os.path.realpath('__file__')) + '/replay'
    template_name = 'test_template'

    # Create context for function dump
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['test'] = 'test'
    context['cookiecutter']['test2'] = 'test2'

    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:29:54.498542
# Unit test for function load

# Generated at 2022-06-23 16:29:59.537638
# Unit test for function load
def test_load():
    context = load('../../tests/files/replay', 'tests/files/fake-repo-tmpl')
    print(context)
    testContext = {'cookiecutter': {'fake_key': 'fake_value'}}
    assert testContext == context


# Generated at 2022-06-23 16:30:03.227884
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'some_dir'
    template = 'some_template'

    assert get_file_name(replay_dir, template) == 'some_dir/some_template.json'

# Generated at 2022-06-23 16:30:04.852817
# Unit test for function load
def test_load():
    return load('','tests/fixtures/fake-repo-tmpl/')

# Generated at 2022-06-23 16:30:07.470788
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests/test-replay'
    template_name = 'cookiecutter-pypackage'
    f_name = get_file_name(replay_dir, template_name)
    assert f_name == 'tests/test-replay/cookiecutter-pypackage.json'


# Generated at 2022-06-23 16:30:11.459247
# Unit test for function get_file_name
def test_get_file_name():
    if get_file_name('replay_dir', 'template_name') == 'replay_dir/template_name.json':
        return True
    else:
        return False


# Generated at 2022-06-23 16:30:15.154412
# Unit test for function dump
def test_dump():
    template_name = 'python_package'
    replay_dir = r'C:\Users\liuchao\Desktop\demo'
    context = {'cookiecutter': {'package_name': 'demo'}}
    dump(replay_dir,template_name, context)

if __name__=='__main__':
    test_dump()

# Generated at 2022-06-23 16:30:18.994914
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '~/replay'
    template_name = 'a-b-c'
    assert get_file_name(replay_dir, template_name) == '~/replay/a-b-c.json'


# Generated at 2022-06-23 16:30:20.350373
# Unit test for function dump
def test_dump():
    """Test for function dump"""
    pass


# Generated at 2022-06-23 16:30:29.090403
# Unit test for function load
def test_load():
    dump("/Users/zhaoqingxuan/Mycode/cookiecutter-yihong/testreplay", "test_load_replay_file", {"cookiecutter": "test_load_cookiecutter", "testing": "test_load"})
    context = load("/Users/zhaoqingxuan/Mycode/cookiecutter-yihong/testreplay", "test_load_replay_file")
    if context["cookiecutter"] != "test_load_cookiecutter":
        return False
    if context["testing"] != "test_load":
        return False
    if "cookiecutter" not in context:
        return False
    return True


# Generated at 2022-06-23 16:30:33.559214
# Unit test for function load
def test_load():
    # Not a str type
    try:
        load('replay_dir', 'temp_name')
    except TypeError:
        print("load: needs a string as template_name")
    # No cookiecutter key
    try:
        load('replay_dir', 'template_name')
    except ValueError:
        print("load: need a cookiecutter key")

test_load()

# Generated at 2022-06-23 16:30:42.737351
# Unit test for function get_file_name
def test_get_file_name():
    # When template_name ends with .json (replay file already exists)
    template_name = 'foo.json'
    file_name = 'foo.json'
    replay_dir = './tests/files/'
    result = get_file_name(replay_dir, template_name)
    assert file_name == result

    # When template_name doesn't end with .json (replay file doesn't exist)
    template_name = 'foo'
    file_name = 'foo.json'
    replay_dir = './tests/files/'
    result = get_file_name(replay_dir, template_name)
    assert file_name == result



# Generated at 2022-06-23 16:30:48.318893
# Unit test for function dump
def test_dump():
	replay_dir = 'replay_dir'
	template_name = 'my_new_project'
	context = {'cookiecutter': {'author_email': 'julien@bouquillon.com', 'open_source_license': 'MIT'}, 'default_context': {'__version__': '1.2.3'}}
	dump(replay_dir, template_name, context)
	
	

# Generated at 2022-06-23 16:30:50.144030
# Unit test for function load
def test_load():
    context = load('/Users/admin/template_test_dir/test_dir', 'test_dir')
    print(context)



# Generated at 2022-06-23 16:31:00.308166
# Unit test for function dump
def test_dump():
    test_replay_dir = './test_replay_dir'
    test_template_name = 'test_template'
    test_context = {
        'cookiecutter': {
            'author': 'author',
            'description': 'description',
            'email': 'author@email.com',
            'full_name': 'author',
            'project_name': 'project_name',
            'project_slug': 'project_slug',
            'repo_name': 'repo_name',
            'use_pycharm': 'y',
            'use_vagrant': 'n',
            'year': '2015',
        }
    }
    replay_file = get_file_name(test_replay_dir, test_template_name)

# Generated at 2022-06-23 16:31:06.588122
# Unit test for function dump
def test_dump():
    replay_dir = "unit_test_replays"
    template_name = "unit_test"
    context = {
        'cookiecutter': {
            'name': "Test",
            'short_name': "test"
        }
    }
    dump(replay_dir, template_name, context)

    context_file_name = get_file_name(replay_dir, template_name)
    assert os.path.isfile(context_file_name)

    os.remove(context_file_name)
    os.removedirs(replay_dir)



# Generated at 2022-06-23 16:31:15.490814
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.getcwd(), 'replay_test')
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'_template': template_name}}
    dump(replay_dir, template_name, context)
    expected_filepath = os.path.join(replay_dir, 'cookiecutter-pypackage.json')
    assert os.path.isfile(expected_filepath), "Replay file not created"
    os.remove(expected_filepath)
    os.rmdir(replay_dir)


# Generated at 2022-06-23 16:31:20.742754
# Unit test for function load
def test_load():
    context = load('.', 'tests/files/cookiecutter.json')
    # In this file the context value is a float
    assert float == type(context['cookiecutter']['project_version'])
    # In this file the context value is a boolean
    assert bool == type(context['cookiecutter']['cli'])

# Generated at 2022-06-23 16:31:23.491194
# Unit test for function get_file_name
def test_get_file_name():
    directory = '/test'
    name = 'template'
    result = get_file_name(directory, name)
    assert result == '/test/template.json'


# Generated at 2022-06-23 16:31:30.241999
# Unit test for function dump
def test_dump():
    """Unit test for function dump"""
    replay_dir = 'test_dump'
    template_name = 'test_template'
    context = {'cookiecutter': {'name': 'test_cookiecutter'}}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)

    with open(replay_file, 'r') as infile:
        content = json.load(infile)
        assert content == context

    os.remove(replay_file)
    os.removedirs(replay_dir)



# Generated at 2022-06-23 16:31:34.919067
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("./test_replay/", "test") == \
        "./test_replay/test.json"
    assert get_file_name("./test_replay/", "test.json") == \
        "./test_replay/test.json"


# Generated at 2022-06-23 16:31:43.919578
# Unit test for function get_file_name
def test_get_file_name():
    if os.path.exists('/tmp/cookiecutter_tests'):
        os.removedirs('/tmp/cookiecutter_tests')
    os.mkdir('/tmp/cookiecutter_tests')
    tmp_dir = '/tmp/cookiecutter_tests'
    assert get_file_name(tmp_dir, 'name') == '/tmp/cookiecutter_tests/name.json'
    assert get_file_name(tmp_dir, 'name.json') == '/tmp/cookiecutter_tests/name.json'
    os.removedirs('/tmp/cookiecutter_tests')

# Generated at 2022-06-23 16:31:46.049664
# Unit test for function load
def test_load():
    """Unit test for function load."""
    result = load('replay_dir', 'template_name')


# Generated at 2022-06-23 16:31:52.742047
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = '/tmp/replay_test'
    template_name = 'test_load'
    context = {
        "cookiecutter": {
            "extension": "html",
            "test_load": True,
            "till_test": True
        }
    }
    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert loaded_context == context


# Generated at 2022-06-23 16:31:57.049408
# Unit test for function load
def test_load():
    replay_context = load('replay', 'cookiecutter-pypackage')
    assert replay_context == {'cookiecutter': {'_template': '.'}}


# Generated at 2022-06-23 16:32:03.545189
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    template_name = 'test_template'
    context = {'cookiecutter': {'cookiecutter': {'name': 'test', 'version': '0.1.1'}}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:32:07.707162
# Unit test for function load
def test_load():
    template_name = 'template_name'
    context = {'cookiecutter': 'key'}
    dump('replay_dir', template_name, context)
    ret_context = load('replay_dir', template_name)
    assert ret_context == context



# Generated at 2022-06-23 16:32:16.740787
# Unit test for function dump
def test_dump():
    replay = {
        "cookiecutter": {
            "project_name": "Bok Choy",
            "project_slug": "bok-choy",
            "author_name": "edX",
            "author_email": "dev@edx.org",
            "release_date": "2013/12/30",
            "year": "2013",
            "version": "0.1.0",
            "description": "A small green vegetable of the cabbage family.",
            "domain_name": "bokchoy.edx.org",
            "open_source_license": "BSD",
            "timezone": "UTC",
            "use_pytest": "y"
        }
    }

# Generated at 2022-06-23 16:32:23.233247
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'project_name': 'Test project',
            'owner_name': 'Test owner'
        }
    }
    replay_dir = '~/replay_testing'
    template_name = 'Example-repo'
    try:
        dump(replay_dir, template_name, context)
    except IOError:
        print("IOError")
    except TypeError:
        print("TypeError")
    except ValueError:
        print("ValueError")


# Generated at 2022-06-23 16:32:34.593001
# Unit test for function dump
def test_dump():
    replay_dir = os.getcwd()

# Generated at 2022-06-23 16:32:42.943034
# Unit test for function dump
def test_dump():

    test_me = {
        "cookiecutter": {
            "project_name": "My Project",
            "repo_name": "{{ cookiecutter.project_name|lower|replace(' ', '_') }}",
            "author_name": "Monty Python",
            "email": "monty@python.org",
            "release_date": "2013-04-01",
        },
    }

    test_file = get_file_name('test_repos', 'test_template') + '.test.json'

    dump('test_repos', 'test_template.test.json', test_me)

    with open(test_file) as json_file:
        data = json.load(json_file)

        assert data == test_me

# Generated at 2022-06-23 16:32:47.675983
# Unit test for function dump
def test_dump():
    dump('~/.cookiecutters/replay', 'test_template',
         {'cookiecutter': {'name': 'test_name', 'email': 'test@email.com'}})


if __name__ == '__main__':
    import sys
    sys.exit(test_dump())

# Generated at 2022-06-23 16:32:57.401265
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for get_file_name"""
    replay_dir = '/Users/name/cookiecutter'
    template_name = 'cookiecutter-pypackage'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/Users/name/cookiecutter/cookiecutter-pypackage.json'

    replay_dir = '/Users/name/cookiecutter'
    template_name = 'cookiecutter-pypackage.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/Users/name/cookiecutter/cookiecutter-pypackage.json'

    replay_dir = '/Users/name/cookiecutter'

# Generated at 2022-06-23 16:33:06.523101
# Unit test for function load
def test_load():
    context = load('~/.cookiecutters/', 'pypackage/')
    assert context['cookiecutter']['project_name'] == 'Python Package'
    assert context['cookiecutter']['repo_name'] == 'pypackage'
    assert context['cookiecutter']['package_name'] == 'pypackage'
    assert context['cookiecutter']['author_name'] == 'Your Name'
    assert context['cookiecutter']['email'] == 'You@Example.com'
    assert context['cookiecutter']['description'] == 'A short description of the project.'
    assert context['cookiecutter']['open_source_license'] == 'MIT'

# Generated at 2022-06-23 16:33:10.161589
# Unit test for function get_file_name
def test_get_file_name():
    template_name = "test"
    replay_dir = "/tmp/test"
    file_name = "test.json"
    return get_file_name(replay_dir, template_name)



# Generated at 2022-06-23 16:33:16.659749
# Unit test for function get_file_name
def test_get_file_name():
    """
    Test get_file_name function.
    """
    assert get_file_name('tests', 'cookiecutter.json') == 'tests/cookiecutter.json'
    assert get_file_name('tests', 'cookiecutter') == 'tests/cookiecutter.json'
    assert get_file_name('tests', 'cookiecutter.jso') == 'tests/cookiecutter.jso.json'

# Generated at 2022-06-23 16:33:22.129996
# Unit test for function load
def test_load():
    TEST_DIR = 'test'
    test_template_name = 'test_template'
    test_context = {'cookiecutter': {'foo': 'bar'}}
    dump(TEST_DIR, test_template_name, test_context)
    loaded_context = load(TEST_DIR, test_template_name)
    assert loaded_context == test_context

    try:
        os.remove('test/{}.json'.format(test_template_name))
        os.rmdir(TEST_DIR)
    except FileNotFoundError:
        pass