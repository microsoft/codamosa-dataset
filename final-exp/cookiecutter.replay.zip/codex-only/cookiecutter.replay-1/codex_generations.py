

# Generated at 2022-06-23 16:23:24.346095
# Unit test for function dump
def test_dump():
    replay_dir = 'test_dump'
    template_name = 'UnitTest'
    context = {
        'cookiecutter': {
            'full_name': 'Jane Doe',
            'email': 'janedoe@example.com',
            'github_username': 'janedoe',
            'project_name': 'test_dump',
            'repo_name': 'janedoe/test_dump'
        }
    }
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        assert True == os.path.exists(replay_file)
        assert context == json.load(infile)

    os.remove(replay_file)


# Generated at 2022-06-23 16:23:28.592990
# Unit test for function load
def test_load():
    c = load('/home/arkhitech/Projects/ArkhiTech/VirtualEnv/cookiecutter-django', 'https://github.com/pydanny/cookiecutter-django')
    print(c)



# Generated at 2022-06-23 16:23:37.135273
# Unit test for function dump
def test_dump():
    """Test function dump."""
    import os
    import shutil

    replay_dir = 'tmp/'

    try:
        shutil.rmtree(replay_dir)
    except:
        pass

    template_name = 'test_template'
    context = {
        'cookiecutter': {
            'test_key': 'test_value'
        }
    }
    dump(replay_dir, template_name, context)
    assert os.path.exists(os.path.join(replay_dir, '{}.json'.format(template_name)))

    try:
        shutil.rmtree(replay_dir)
    except:
        pass



# Generated at 2022-06-23 16:23:39.775465
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay', 'acme-inc') == 'replay/acme-inc.json'



# Generated at 2022-06-23 16:23:45.726538
# Unit test for function get_file_name
def test_get_file_name():
    name = "test_name"
    replay_dir = "replay_dir"

    assert get_file_name(replay_dir, name) == replay_dir + "/test_name.json"
    assert get_file_name(replay_dir, name+".json") == replay_dir + "/test_name.json"

# Generated at 2022-06-23 16:23:52.180426
# Unit test for function dump
def test_dump():
    """Test dump function."""
    replay_dir = '/tmp/cookiecutter_rep'
    template_name = 'template'
    context = {'cookiecutter':{'project_name': 'Test'}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))



# Generated at 2022-06-23 16:23:57.354991
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "G:\cookiecutter\cookiecutter-pypackage"
    template_name = "cookiecutter-pypackage"
    assert get_file_name(replay_dir, template_name) == "G:\cookiecutter\cookiecutter-pypackage\cookiecutter-pypackage.json"


# Generated at 2022-06-23 16:24:04.427721
# Unit test for function dump
def test_dump():
    """Test function dump."""
    import tempfile
    file_name = tempfile.mkdtemp() + '/test_dump.json'
    test_context = {
        'cookiecutter': {'test_key': 'test_value'}
    }
    dump(replay_dir=file_name,
         template_name='test_context',
         context=test_context)
    assert (file_name == 'test_context.json')



# Generated at 2022-06-23 16:24:12.697163
# Unit test for function dump
def test_dump():
    """Test to make sure we can dump"""

# Generated at 2022-06-23 16:24:15.431801
# Unit test for function load
def test_load():
    assert load('./tests/files/tests/fake-repo-tmpl', 'fake-repo')['cookiecutter']['project_name'] == 'Fake Project'

# Generated at 2022-06-23 16:24:21.318088
# Unit test for function get_file_name
def test_get_file_name():
    assert(get_file_name('/tmp', 'something') == '/tmp/something.json')
    assert(get_file_name('/tmp', 'something.json') == '/tmp/something.json')
    assert(get_file_name('./tmp', 'something') == './tmp/something.json')
    assert(get_file_name('./tmp', 'something.json') == './tmp/something.json')

# Generated at 2022-06-23 16:24:24.235116
# Unit test for function load
def test_load():
    replay_dir = "~/.cookiecutters"
    template_name = "cookiecutter-pypackage"
    context = load(replay_dir, template_name)
    print(context)


# Generated at 2022-06-23 16:24:27.462979
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('dir', 'template_name') == 'dir/template_name.json'
    assert get_file_name('dir', 'template_name.json') == 'dir/template_name.json'


# Generated at 2022-06-23 16:24:32.399458
# Unit test for function load
def test_load():
	replay_dir ="~/Projects/projects/cookiecutter-flask-foundation/tests/replay_dir"
	replay_file = "~/Projects/projects/cookiecutter-flask-foundation/tests/replay_dir/cookiecutter-flask-foundation.json"

# Generated at 2022-06-23 16:24:36.619553
# Unit test for function get_file_name
def test_get_file_name():
    """Test file names."""
    assert get_file_name("replay_dir", "template_name") == "replay_dir\\template_name.json"


# Generated at 2022-06-23 16:24:40.065610
# Unit test for function load
def test_load():
    context = load('/home/trang/Documents/Coding/cookiecutter-pypackage-minimal/','cookiecutter.json')
    assert isinstance(context, dict), 'Context is not loaded properly'


# Generated at 2022-06-23 16:24:49.415779
# Unit test for function dump
def test_dump():
    """Test the function dump."""
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'project_name': 'My Cute Python Project',
            'project_slug': 'my-cute-python-project',
        }
    }
    dump(replay_dir, template_name, context)
    context_from_file = load(replay_dir, template_name)
    assert context == context_from_file


if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-23 16:24:54.377175
# Unit test for function dump
def test_dump():
    input_dir = '/Users/iain/Documents/Software/Code/cookiecutter-pypackage'
    replay_dir = '/Users/iain/Documents/Software/Code/replay'
    replay_file = '/Users/iain/Documents/Software/Code/replay/cookiecutter-pypackage.json'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:24:58.196860
# Unit test for function get_file_name
def test_get_file_name():
    """Test for naming the replay file."""
    replay_dir = '/test'
    template_name = 'regex.json'
    assert get_file_name(replay_dir, template_name) == '/test/regex.json'


# Generated at 2022-06-23 16:25:00.306706
# Unit test for function load
def test_load():
    context = load('test_replay', 'test_template_name')
    assert context['cookiecutter']['project_name'] == 'Lorem Ipsum'


# Generated at 2022-06-23 16:25:03.971815
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'C:\\Users\\Cookiecutter'
    template_name = 'Cookiecutter'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'C:\\Users\\Cookiecutter\\Cookiecutter.json'


# Generated at 2022-06-23 16:25:12.704529
# Unit test for function dump
def test_dump():
    from cookiecutter import replay
    from cookiecutter import utils
    from cookiecutter.main import cookiecutter
    import shutil
    import os
    from tempfile import mkdtemp

    shutil.copytree(os.path.dirname(
        os.path.abspath(__file__)),
                    'cookiecutter-replay-test')
    os.chdir('cookiecutter-replay-test')


# Generated at 2022-06-23 16:25:22.080365
# Unit test for function load
def test_load():
    replay_dir = './'
    template_name = './tests/test-load.json'

# Generated at 2022-06-23 16:25:31.286155
# Unit test for function load
def test_load():
    replay_dir = 'dummy_replay_dir'
    context = {
        'mock_data': 'mock_data',
        'cookiecutter': {
            'mock_data': 'mock_data',
            'default_context': {
                'mock_data': 'mock_data'
            }
        }
    }
    template_name = 'mock_template_name'
    dump(replay_dir, template_name, context)
    file_name = get_file_name(replay_dir, template_name)
    assert os.path.exists(file_name)
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-23 16:25:37.422649
# Unit test for function dump
def test_dump():
    """Test that dump() writes out a replay file."""
    replay_dir = 'tests/test-replay'
    template_name = 'gh:audreyr/cookiecutter-pypackage'
    context = {
        'cookiecutter': {
            'full_name': "Your Name",
            'email': "youremail@mail.com",
        }
    }
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)

    assert os.path.isfile(replay_file)


# Generated at 2022-06-23 16:25:43.247625
# Unit test for function dump
def test_dump():
    replay_dir = '/tmp/dump'
    template_name = 'template_name'
    context = {'key1':'value1','key2':'value2'}
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)



# Generated at 2022-06-23 16:25:53.485343
# Unit test for function dump
def test_dump():
    """Test function dump."""
    replay_dir = 'tmp'
    template_name = 'template_name'
    context = {
        'some_key': 'some_value',
        'some_key2': 'some_value2',
        'cookiecutter': {
            'some_key': 'some_value'
        }
    }
    dump(replay_dir, template_name, context)

    with open(os.path.join(replay_dir, template_name), 'r') as f:
        dict = json.load(f)
        assert dict['some_key'] == context['some_key']
        assert dict['some_key2'] == context['some_key2']
        assert dict['cookiecutter']['some_key'] == context['cookiecutter']['some_key']



# Generated at 2022-06-23 16:26:02.368440
# Unit test for function load
def test_load():
    # Create replay dir for testing
    replay_dir = '/home/wei/workspace/cookiecutter-templates/replay'
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))

    # Create replay file for testing
    replay_file = get_file_name(replay_dir, 'test_file')
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))
    context = {'cookiecutter': {}}
    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    # Test loading file

# Generated at 2022-06-23 16:26:05.598195
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'TEMPLATE'
    replay_dir = 'TEST_PATH'
    suffix = '.json'
    file_name = '{}{}'.format(template_name, suffix)
    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name)


# Generated at 2022-06-23 16:26:07.768680
# Unit test for function load
def test_load():
    context = load('~/.cookiecutters', 'foo')

    assert context is not None


# Generated at 2022-06-23 16:26:13.441055
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    assert get_file_name('/tmp/replay_dir', 'cookiecutter-pypackage') == '/tmp/replay_dir/cookiecutter-pypackage.json'

    try:
        get_file_name('/tmp/replay_dir', {})
    except TypeError as e:
        assert str(e) == 'Template name is required to be of type str'

# Generated at 2022-06-23 16:26:22.718540
# Unit test for function dump
def test_dump():
    """Test the dump function with a valid context."""
    replay_dir = 'tests/test_replay'
    if not make_sure_path_exists(replay_dir):
        raise IOError('Failed to create directory {}'.format(replay_dir))
    template_name = 'test'
    context = {
        'cookiecutter': {
            'full_name': 'Test user',
            'email': 'test@example.com',
            'github_username': 'test',
        }
    }
    dump(replay_dir, template_name, context)

    # Check that the replay file was created
    assert os.path.isfile(get_file_name(replay_dir, template_name))



# Generated at 2022-06-23 16:26:28.707047
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    from cookiecutter.main import cookiecutter
    from cookiecutter.replay import dump
    from cookiecutter.replay import load
    import os

    # Prepare for testing

# Generated at 2022-06-23 16:26:36.768925
# Unit test for function dump
def test_dump():
    """Unit test for dump function."""
    template_name = '{{cookiecutter.repo_name}}'
    replay_dir = os.path.join('tests', 'files', 'replay')
    context = {'cookiecutter': {'repo_name': 'myrepo'}}
    exp_fname = os.path.join(replay_dir, 'myrepo.json')
    dump(replay_dir, template_name, context)
    assert os.path.exists(exp_fname)
    os.remove(exp_fname)


# Generated at 2022-06-23 16:26:40.478033
# Unit test for function get_file_name
def test_get_file_name():
    """Test get file name."""
    template_dir = '../'
    template_name = 'abc'
    file_name = '../abc.json'
    assert(get_file_name(template_dir, template_name) == file_name)


# Generated at 2022-06-23 16:26:50.578294
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output/replay'
    make_sure_path_exists(replay_dir)
    template_name = 'tests/fake-repo-pre/'
    context = {
        'cookiecutter': {
            'project_name': 'Auditok',
            'project_slug': 'auditok',
            'pypi_username': 'auditok',
            'author_name': 'Cyrille Rossant',
            'email': 'rossant@github.com',
            'description': 'Auditory stream tokenizer',
            'domain_name': 'auditok.readthedocs.io',
            'version': '0.1.0',
            'timezone': 'UTC',
        }
    }

# Generated at 2022-06-23 16:26:56.863581
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/tmp'
    template_name = 'simple-python-project'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/tmp/simple-python-project.json'

    template_name = 'simple-python-project.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/tmp/simple-python-project.json'



# Generated at 2022-06-23 16:27:03.131907
# Unit test for function load
def test_load():
    # to test load function
    dir = "../test_data/test_replay/"
    template_name = "test_load"
    ans = {
      "cookiecutter":
      {
        "full_name": "test",
        "email": "test@test.com",
        "github_username": "test",
        "project_name": "test"
      }
    }
    out = load(dir, template_name)
    assert out == ans


# Generated at 2022-06-23 16:27:10.131895
# Unit test for function load
def test_load():
    """Test the load function."""
    import sys, os.path
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from cookiecutter.main import cookiecutter

    template_name = 'my-first-repo'
    output_dir = os.path.join(os.path.dirname(__file__), '..', 'tests')
    context = cookiecutter(
        template_name, replay_dir=output_dir, no_input=True
    )

    test_context = load(output_dir, template_name)

    assert(context == test_context)

    os.remove(os.path.join(output_dir, template_name) + '.json')



# Generated at 2022-06-23 16:27:18.151042
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-output'
    template_name = 'gh-default-master'
    context = {
        'cookiecutter': {
            'full_name': 'dummy',
            'email': 'dummy@dummy.com',
            'repo_name': 'dummy-repo',
            }
        }
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.isfile(replay_file)
    os.remove(replay_file)


# Generated at 2022-06-23 16:27:24.668447
# Unit test for function load
def test_load():
    """Test cookiecutter.replay.load()."""
    if not isinstance(template_name, str):
        raise TypeError('Template name is required to be of type str')

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    return context


# Generated at 2022-06-23 16:27:32.049339
# Unit test for function load
def test_load():
    test_context = {'cookiecutter': {'full_name': 'Alex', 'email': 'test@test.com'}}
    test_template = 'test_template'
    test_replay_dir = 'test_replay_dir'
    dump(test_replay_dir, test_template, test_context)
    context = load(test_replay_dir, test_template)
    assert context == test_context, 'Test for load failed'

# Generated at 2022-06-23 16:27:36.679004
# Unit test for function dump
def test_dump():
    context = dict(title='test', cookiecutter={'cookiecutter': {'version': 1}})
    replay_dir = './'
    template_name = 'test_replay'
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:27:47.207593
# Unit test for function load
def test_load():
    """Test load function."""
    # Create a temporary directory to store the replay file
    import tempfile
    import shutil
    replay_dir = tempfile.mkdtemp()
    # Create the replay file
    template_name = 'my-template'
    replay_data = {'cookiecutter': {'full_name': 'Example Name', 'email': 'example@example.com'}}
    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'w') as outfile:
        json.dump(replay_data, outfile, indent=2)
    # Test load function
    context = load(replay_dir, template_name)
    assert replay_data == context
    # Clean up
    shutil.rmtree(replay_dir)

# Generated at 2022-06-23 16:27:51.713336
# Unit test for function load
def test_load():
    replay_dir = '/Users/yuan/Desktop/replay_files'
    template_name = 'classicalmusic/project_name'
    context = load(replay_dir, template_name)
    print(context)

# Generated at 2022-06-23 16:27:57.423768
# Unit test for function load
def test_load():
    replay_dir = 'replay_dir'
    template_name = 'test_template'
    context = {'test_key1': 'test_value1', 'test_key2': 'test_value2'}
    dump(replay_dir, template_name, context)

    result = load(replay_dir, template_name)

    assert result == context

# Generated at 2022-06-23 16:28:02.831836
# Unit test for function get_file_name
def test_get_file_name():

    file_name = 'example.json'
    replay_dir = '/tmp/cookiecutter/replay'
    result = get_file_name(replay_dir, file_name)

    template_name = 'example'

    assert result == os.path.join(replay_dir, '{}.json'.format(template_name))



# Generated at 2022-06-23 16:28:06.084924
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = 'test'
    filename = get_file_name(replay_dir, template_name)
    assert filename == './test.json'


# Generated at 2022-06-23 16:28:11.154888
# Unit test for function get_file_name
def test_get_file_name():
    assert os.path.join('test', 'foo.json') == get_file_name('test', 'foo.json')
    assert os.path.join('test', 'foo') == get_file_name('test', 'foo')

# Generated at 2022-06-23 16:28:16.174228
# Unit test for function get_file_name
def test_get_file_name():
    """Test for function get_file_name."""
    replay_dir = "/home/user/cookiecutterfiles"
    template_name = "template"
    assert get_file_name(replay_dir, template_name) == '/home/user/cookiecutterfiles/template.json'


# Generated at 2022-06-23 16:28:24.925745
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'some_dir'
    template_name = 'my_template'
    template_name_with_json = 'my_template.json'
    file_name = 'my_template.json'
    file_name_with_json = 'my_template.json.json'

    assert(get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name))
    assert(get_file_name(replay_dir, template_name_with_json) == os.path.join(replay_dir, file_name_with_json))



# Generated at 2022-06-23 16:28:28.000151
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/usr/'
    template_name = 'package_mod'
    print(get_file_name(replay_dir, template_name))

if __name__=='__main__':
    test_get_file_name()

# Generated at 2022-06-23 16:28:35.503945
# Unit test for function dump
def test_dump():
    replay_dir = "~/.cookiecutter_replay"
    template_name = "cc_test3"

# Generated at 2022-06-23 16:28:45.819237
# Unit test for function load
def test_load():
    replay_dir = os.path.join(os.path.abspath(os.path.curdir), 'tests/test-replay')
    replay_file = 'tests/test-replay/example_replay.json'
    template_name = 'example_replay.json'
    real_context = {
        '_template': 'tests/fake-repo-tmpl',
        'cookiecutter': {'repo_dir': 'tests/fake-repo', 'repo_url': 'https://github.com/tests/fake-repo'},
        'full_name': 'Audrey Roy',
        'email': 'audreyr@example.com',
        'project': 'Cookiecutter Pylibrary'
    }
    dict_context = load(replay_dir, template_name)
   

# Generated at 2022-06-23 16:28:50.853585
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutter')
    replay_file = os.path.join(replay_dir, 'testdump.json')
    template_name = 'testdump'
    dump_context = {'cookiecutter': {'a': 'b'}}
    dump(replay_dir, template_name, dump_context)
    assert os.path.exists(replay_file)
    loaded_context = load(replay_dir, 'testdump')
    assert loaded_context == dump_context
    os.remove(replay_file)


# Generated at 2022-06-23 16:28:59.319259
# Unit test for function get_file_name
def test_get_file_name():
    test_dir_name = '~/temp'
    test_file_name = 'test_file'
    file_name = get_file_name(test_dir_name, test_file_name)
    assert file_name == '~/temp/test_file.json'
    file_name = get_file_name(test_dir_name, test_file_name + '.json')
    assert file_name == '~/temp/test_file.json'



# Generated at 2022-06-23 16:29:07.737099
# Unit test for function get_file_name
def test_get_file_name():
    expected1 = r'C:\Users\Cookiecutter\replay\C:\Users\Cookiecutter\test.json'
    expected2 = r'C:\Users\Cookiecutter\test.json'
    template_name1 = r'C:\Users\Cookiecutter\test'
    template_name2 = r'C:\Users\Cookiecutter\test.json'
    assert expected1 == get_file_name(r'C:\Users\Cookiecutter\replay', template_name1)
    assert expected2 == get_file_name(r'C:\Users\Cookiecutter\replay', template_name2)


# Generated at 2022-06-23 16:29:11.199862
# Unit test for function load
def test_load():
    context = load('test_replay','cookiecutter-pypackage')
    print(context)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:29:18.330537
# Unit test for function get_file_name
def test_get_file_name():
    print(get_file_name('a', 'b'))
    print(get_file_name('a', 'b.json'))
    try: 
        get_file_name(1, 'b.json')
    except TypeError: 
        print('TypeError')
    try: 
        get_file_name('a', 1)
    except TypeError: 
        print('TypeError')

# Generated at 2022-06-23 16:29:22.818097
# Unit test for function load
def test_load():
    replay_dir = "./cookiecutter"
    template_name = "ubuntu_rq"
    context = load(replay_dir, template_name)
    print("context: ", context)
    for k in context:
        print("key: ", k, " value: ", context[k])



# Generated at 2022-06-23 16:29:25.954739
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("../test_replay_folder", "test") == "../test_replay_folder/test.json"
    assert get_file_name("../test_replay_folder", "test.json") == "../test_replay_folder/test.json"

# Generated at 2022-06-23 16:29:31.741844
# Unit test for function load
def test_load():
    """Unit test for function load."""
    # create replay file
    test_file_name = "test_file.json"
    test_replay_file_name = os.path.join("tests", "replay", test_file_name)
    test_context = {"cookiecutter": {"replay": True}}
    with open(test_replay_file_name, 'w') as outfile:
        json.dump(test_context, outfile, indent=2)

    # test load
    context = load("tests/replay/", test_file_name)
    assert context == test_context

    # remove replay file
    os.remove(test_replay_file_name)

    # Case where replay file doesn't exist

# Generated at 2022-06-23 16:29:36.111158
# Unit test for function get_file_name
def test_get_file_name():
    """Test get_file_name function."""
    replay_dir = "path/to/replay"
    template_name = "template_name"
    suffix = ".json"
    
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == "path/to/replay/template_name.json"


# Generated at 2022-06-23 16:29:40.056592
# Unit test for function load
def test_load():

    template_name = "cookiecutter-pypackage"
    replay_dir = "/home/louis/.cookiecutters"
    context = load(replay_dir, template_name)
    print(context["cookiecutter"])


if __name__ == "__main__":
    test_load()

# Generated at 2022-06-23 16:29:50.256928
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    require_dir = '/tmp/test_load'
    os.system('rm -rf ' + require_dir)
    os.mkdir(require_dir)
    cookiecutter(template='.', replay_dir=require_dir)
    context = load(require_dir, '.')
    assert context == {
        "cookiecutter": {
            "full_name": "",
            "email": "",
            "github_username": "",
            "repo_name": "",
            "project_name": "",
            "project_short_description": "",
            "pypi_username": ""
        }
    }
    os.system('rm -rf ' + require_dir)


# Generated at 2022-06-23 16:29:58.714516
# Unit test for function load
def test_load():
    import json
    replay_dir = '/tmp'
    template_name = 'template'
    replay_file = get_file_name(replay_dir, template_name)
    context = {
        "cookiecutter": {
            "full_name": "Your Name",
            "email": "your_email@example.com",
            "github_username": "your_github_username",
            "project_name": "Cookiecutter Example Project",
            "project_slug": "cookiecutter-example-project",
            "project_short_description": "A short description of the project.",
            "release_date": "2013-07-10",
            "year": "2013",
            "version": "0.1.0",
            "end_year": "2013"
        }
    }


# Generated at 2022-06-23 16:30:09.994595
# Unit test for function dump
def test_dump():
    oldName = "previousTemplateName"
    expectedName = "previousTemplateName.json"

    oldContext = {'cookiecutter' : 'templateName', 'var2' : 'value2'}
    oldPath = "testDir"
    expectedPath = "testDir/previousTemplateName.json"

    dump(oldPath, oldName, oldContext)
    assert (os.path.isfile(expectedPath) == True)

    with open(expectedPath, 'r') as infile:
        context = json.load(infile)

    assert(context['cookiecutter'] == oldContext['cookiecutter'])
    assert(context['var2'] == oldContext['var2'])

    os.remove(expectedPath)


# Generated at 2022-06-23 16:30:17.712850
# Unit test for function dump
def test_dump():
    """Test dump function."""
    from cookiecutter import replay
    from cookiecutter import replay as _replay
    from cookiecutter.prompt import read_user_choice
    from mock import patch

    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    template_name = 'my_project'
    test_context = {
        'cookiecutter': {
            'full_name': 'Jeff Forcier',
            'email': 'jeff@bitprophet.org',
            'github_username': 'bitprophet',
        }
    }


# Generated at 2022-06-23 16:30:23.623475
# Unit test for function dump
def test_dump():
    """Unit test for function dump"""
    replay_dir = 'tests/test-output/' + 'replay/'
    template_name = 'tests/fake-repo-pre/'
    context = {'cookiecutter': {'repo_dir': template_name}}
    try:
        dump(replay_dir, template_name, context)
    except:
        pass


# Generated at 2022-06-23 16:30:28.121240
# Unit test for function dump
def test_dump():
    json_file = '{{ cookiecutter.project_slug}}.json'
    replay_dir = 'temp'
    context = {
        "cookiecutter": {
            "project_name": "Project",
            "project_slug": "project",
            "author_name": "Name"
        }
    }
    dump(replay_dir, json_file, context)


# Generated at 2022-06-23 16:30:29.879906
# Unit test for function load
def test_load():
    assert load('./tests/replay', 'json') == {'cookiecutter': {'abc': 'a'}}


# Generated at 2022-06-23 16:30:36.592680
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.join(os.getcwd(), 'tests/files/replay-dir')
    template_name = 'cookiecutter-pypackage'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, 'cookiecutter-pypackage.json')

    template_name = 'cookiecutter-pypackage.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, 'cookiecutter-pypackage.json')


# Generated at 2022-06-23 16:30:41.223728
# Unit test for function load
def test_load():
    template_name = 'cmpt770'
    replay_dir = 'tests/test-replay'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:30:46.906473
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = 'dummy_template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'dummy_template.json'

    template_name = 'dummy_template.json'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'dummy_template.json'



# Generated at 2022-06-23 16:30:49.702943
# Unit test for function load
def test_load():
    """Test load file."""
    assert load("./tests/files/.cookiecutter_replay", "{{cookiecutter.project_slug}}")["cookiecutter"]["project_slug"] == "hello_world"


# Generated at 2022-06-23 16:30:52.504555
# Unit test for function load
def test_load():
    context = load(replay_dir='replay', template_name='cookiecutter-pypackage-minimal')
    #print(context)
    assert context['cookiecutter']['package_name'] == 'cookiecutter-pypackage-minimal'



# Generated at 2022-06-23 16:30:55.555843
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('toto', 'toto') == 'toto/toto.json'
    assert get_file_name('toto', 'toto.json') == 'toto/toto.json'

# Generated at 2022-06-23 16:30:59.880529
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/daniel/cookiecutter/tests/replay'
    template_name = 'foo'
    result = '/home/daniel/cookiecutter/tests/replay/foo.json'
    assert result == get_file_name(replay_dir, template_name)


# Generated at 2022-06-23 16:31:04.474640
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'c:/'
    template_name = 'aproject'
    if(get_file_name(replay_dir, template_name) != 'c:/aproject.json'):
        raise Exception('test_write_json_context_to_file FAILED!')
    print('test_write_json_context_to_file PASSED!')


# Generated at 2022-06-23 16:31:15.915736
# Unit test for function load
def test_load():
	import unittest
	from unittest import TestCase
	from unittest import main
	class Test_Cookiecutter_Replay(TestCase):
	    def setUp(self):
	        self.replay_dir = 'tests/test-load-replay'
	        self.template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:31:21.401402
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    template_name = 'unit_test'
    replay_dir = 'test'
    context = {'cookiecutter': {'test': 'hello'}}
    dump(replay_dir, template_name, context)
    result = load(replay_dir, template_name)
    assert result['cookiecutter']['test'] == context['cookiecutter']['test']


# Generated at 2022-06-23 16:31:25.876719
# Unit test for function dump
def test_dump():
    replay_dir = '../../.cookiecutters'
    template_name = 'python-package'
    context = {'cookiecutter':{'full_name':'Trent'}}

    try:
        dump(replay_dir, template_name, context)
    except Exception as e:
        print(e)


# Generated at 2022-06-23 16:31:29.848899
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    from cookiecutter.config import DEFAULT_REPLAY_DIR
    template_name = 'my-template'
    file_name = get_file_name(DEFAULT_REPLAY_DIR, template_name)
    assert file_name == os.path.join(DEFAULT_REPLAY_DIR, template_name + '.json')



# Generated at 2022-06-23 16:31:34.769095
# Unit test for function dump
def test_dump():
    import tempfile
    replay_dir = tempfile.mkdtemp()
    template_name = 'test'
    context = {'cookiecutter': {'project_slug': 'test'}}
    dump(replay_dir, template_name, context)
    file_name = os.path.join(replay_dir, 'test.json')
    assert os.path.isfile(file_name)
    import shutil
    shutil.rmtree(replay_dir)


# Generated at 2022-06-23 16:31:40.781361
# Unit test for function get_file_name

# Generated at 2022-06-23 16:31:48.739097
# Unit test for function dump
def test_dump():
    import tempfile
    with tempfile.TemporaryDirectory() as tmp_dir:
        dump(replay_dir=tmp_dir, template_name='{{cookiecutter.test}}', context={'cookiecutter': {'test': 'test'}})
        context = load(replay_dir=tmp_dir, template_name='{{cookiecutter.test}}')
        assert context['cookiecutter']['test'] == 'test'

if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-23 16:31:52.711217
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('/Users/michaelherman/cookiecutter', 'cookiecutter-pypackage') == '/Users/michaelherman/cookiecutter/cookiecutter-pypackage.json'


# Generated at 2022-06-23 16:31:56.853236
# Unit test for function dump
def test_dump():
    "test dump function"
    replay_dir = os.path.join(os.path.expanduser('~'), 'some', 'random', 'dir')
    context = {
        'cookiecutter': {
            'project_name': 'Project name',
            'full_name': 'Full Name',
        }
    }
    try:
        dump(replay_dir, 'projects', context)
    except Exception as e:
        print(e)
        assert False
    assert True


# Generated at 2022-06-23 16:32:04.150896
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.getcwd(), 'tests', 'test_replay')
    template_name = "test_cookiecutter"
    context = {
        'cookiecutter': {
            'repo_dir': '~\\dev\\cookiecutter',
            'context': {'test_context': 0}
        }
    }

    dump(replay_dir, template_name, context)
    # Test for new file
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.exists(replay_file)

    # Test for new replay file
    with open(replay_file) as data_file:
        data = json.load(data_file)
    assert data == context

    # Cleanup

# Generated at 2022-06-23 16:32:11.831309
# Unit test for function get_file_name
def test_get_file_name():
    """Test for function get_file_name."""
    replay_dir = 'test_replay'
    template_name = 'test_cookie'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, 'test_cookie.json')
    file_name = get_file_name(replay_dir, template_name + '.json')
    assert file_name == os.path.join(replay_dir, 'test_cookie.json')



# Generated at 2022-06-23 16:32:14.422174
# Unit test for function load
def test_load():
    context = load('tests/test-data/fake-repo-pre/', 'fake-repo-pre')
    print(context)
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:32:18.677170
# Unit test for function load
def test_load():
    """Test load function."""
    template_name = 'https://github.com/audreyr/cookiecutter-pypackage'
    replay_dir = 'tests/files/replay'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['package_name'] == 'foopackage'
    assert context['cookiecutter']['project_name'] == 'Foo Project'

# Generated at 2022-06-23 16:32:28.019896
# Unit test for function load
def test_load():
    template_name = 'a_template_name'
    working_directory = os.getcwd()
    replay_dir = working_directory + '/replay_test'
    if not os.path.exists(replay_dir):
        os.mkdir(replay_dir)
    test_file = get_file_name(replay_dir, template_name)
    test_context = {'cookiecutter': {'template_name': 'test_template_name',
                                     'test_val': 'test_val'}}
    with open(test_file, 'w') as test_file:
        json.dump(test_context, test_file)
    assert load(replay_dir, template_name) == test_context
    assert os.path.exists(test_file)

# Generated at 2022-06-23 16:32:30.591387
# Unit test for function load
def test_load():
    template_name = 'test_template'
    context = load(replay_dir, template_name)
    print(context)
    return context


# Generated at 2022-06-23 16:32:35.079357
# Unit test for function dump
def test_dump():
    """Unit test to test the dump function."""
    replay_dir = 'tests/files/test_contexts'
    template_name = 'dummy_repo'
    context = {'cookiecutter': {'author_name': 'Temporary Name'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:32:39.382991
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'home'
    template_name = '.template'
    file_name = 'home/.template.json'
    assert get_file_name(replay_dir, template_name) == file_name

# Generated at 2022-06-23 16:32:48.586079
# Unit test for function load
def test_load():
    # creating the replay directory
    replay_dir = '../../replays'

    # creating the template name
    template_name = '../test_templates/using_cookiecutter'

    # creating the dictionary for context

# Generated at 2022-06-23 16:32:56.488585
# Unit test for function dump
def test_dump():
    
    dir_name = 'temp'
    template_name = 'temp'
    context = dict()
    context['cookiecutter'] = dict()
    context['cookiecutter']['full_name'] = 'riya'
    dump(dir_name, template_name, context)
    
    # check if storage file is created
    storage_file = dir_name + '/' + template_name + '.json'
    assert os.path.exists(storage_file)
    
    # delete storage file
    os.remove(storage_file)
    
    # delete storage dir
    os.rmdir(dir_name)
   

# Generated at 2022-06-23 16:33:06.894739
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    assert get_file_name('replay', 'template') == 'replay/template.json'
    assert get_file_name('replay', 'template.json') == 'replay/template.json'
    assert get_file_name('replay', '/template') == 'replay/template.json'
    assert get_file_name('replay', 'template/') == 'replay/template.json'
    assert get_file_name('replay', 'template/') == 'replay/template.json'
    assert get_file_name('replay', 'template\\') == 'replay/template.json'
    assert get_file_name('replay', '\\template') == 'replay/template.json'

# Generated at 2022-06-23 16:33:11.342045
# Unit test for function dump
def test_dump():
    template_name = 'test'
    replay_dir = 'tests/replay'
    context = {'cookiecutter': {'project_name': 'Test'}}
    assert dump(replay_dir, template_name, context) == None


# Generated at 2022-06-23 16:33:17.591081
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    # Checks if the suffix is added properly
    assert get_file_name('/a', 'b') == '/a/b.json'
    assert get_file_name('/a/', 'b') == '/a/b.json'
    assert get_file_name('a', 'b') == 'a/b.json'
    assert get_file_name('a/', 'b') == 'a/b.json'
    # Checks if the suffix is not added twice
    assert get_file_name('/a', 'b.json') == '/a/b.json'
    assert get_file_name('/a/', 'b.json') == '/a/b.json'
    assert get_file_name('a', 'b.json') == 'a/b.json'