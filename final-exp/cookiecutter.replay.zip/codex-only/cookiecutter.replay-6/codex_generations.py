

# Generated at 2022-06-23 16:23:21.115085
# Unit test for function load
def test_load():
    assert load(replay_dir = 'C:\\Users\\Dell\\cookiecutter_projects', template_name = 'cookiecutter-pypackage')



# Generated at 2022-06-23 16:23:25.122141
# Unit test for function dump

# Generated at 2022-06-23 16:23:28.087486
# Unit test for function load
def test_load():
    """Unit test for function load."""
    context = load('tests/test-replay', 'bacon')
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:23:36.175292
# Unit test for function get_file_name
def test_get_file_name():
    # For multiple file names, we want to make sure the suffix is appended to
    # the file name
    assert(get_file_name('cookiecutter', 'abc') == 'cookiecutter/abc.json')
    assert(get_file_name('cookiecutter', 'abc.json') == 'cookiecutter/abc.json')

    # For a directory, there is no suffix appended to the file name
    assert(get_file_name('cookiecutter/', 'abc') == 'cookiecutter/abc.json')
    assert(get_file_name('cookiecutter/', 'abc.json') == 'cookiecutter/abc.json')

# Generated at 2022-06-23 16:23:42.603474
# Unit test for function dump
def test_dump():
    replay_dir = "test"
    template_name = "cc_test.json"
    context = {"cookiecutter": {"full_name": "Test"}}

    dump(replay_dir, template_name, context)

    output_file = get_file_name("test", "cc_test.json")

    assert os.path.isfile(output_file) is True

    with open(output_file, 'r') as infile:
        assert json.load(infile) == context


# Generated at 2022-06-23 16:23:51.982742
# Unit test for function dump
def test_dump():
    replay_dir = '/home/jiatao/code/cookiecutter-pypackage/.replay'
    template_name = 'cookiecutter-pypackage'
    context = {
        "cookiecutter": {
            "full_name": "Jiatao Gu",
            "email": "jiatao.gu@gmail.com",
            "project_name": "Cookiecutter-Pypackage",
            "pypi_username": "jiatao",
            "github_username": "jiatao",
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:23:55.295919
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/tmp/replay_dir'
    template_name = 'template_name'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/tmp/replay_dir/template_name.json'


# Generated at 2022-06-23 16:24:02.427294
# Unit test for function dump
def test_dump():
    replay_dir = 'test/test_dump'
    template_name = 'test'
    context = {'cookiecutter': {'replay': {'test_replay': 1}}}
    dump(replay_dir, template_name, context)

    with open(get_file_name(replay_dir, template_name), 'r') as f:
        data = json.load(f)
        assert context['cookiecutter'] == data['cookiecutter'], 'dump method write file error'


# Generated at 2022-06-23 16:24:11.079130
# Unit test for function load
def test_load():
    # create a template_name
    template_name = "dummy"
    # create a replay file in the same directory as this file
    replay_file = get_file_name(os.path.dirname(__file__), template_name)
    # create a context for the test

# Generated at 2022-06-23 16:24:15.199829
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.getcwd()
    template_name = 'template_name'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, template_name+'.json')


# Generated at 2022-06-23 16:24:20.362536
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('.', 'test') == './test.json'
    assert get_file_name('.', 'test.json') == './test.json'
    assert isinstance(get_file_name('.', 'test'), str)
    assert isinstance(get_file_name('.', 'test.json'), str)

# Generated at 2022-06-23 16:24:26.832837
# Unit test for function dump
def test_dump():
    import tempfile
    import shutil
    import filecmp



    replay_dir = tempfile.mkdtemp()
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'default_context': {}}}
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))
    shutil.rmtree(replay_dir)


# Generated at 2022-06-23 16:24:29.449159
# Unit test for function get_file_name
def test_get_file_name():
    for name in ['test.json', 'test']:
        assert get_file_name('.', name) == './test.json'

# Generated at 2022-06-23 16:24:38.321316
# Unit test for function load
def test_load():
    """ Functionality test for cookiecutter.replay.load """
    test_dir = os.path.dirname(os.path.abspath(__file__))
    cc_dir = os.path.join(test_dir, "..")

    try:
        context = load(replay_dir=cc_dir, template_name="template")
    except Exception as e:
        raise e
    finally:
        pass

    if context:
        return True
    else:
        raise False



# Generated at 2022-06-23 16:24:44.672567
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "./"
    template_name = "bla"

    assert get_file_name(replay_dir, template_name) == "./bla.json"

    template_name = "bla.json"

    assert get_file_name(replay_dir, template_name) == "./bla.json"

# Generated at 2022-06-23 16:24:47.901226
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'test'
    replay_dir = './test_replay'

    output = get_file_name(replay_dir, template_name)
    expected = './test_replay/test.json'

    assert output == expected


# Generated at 2022-06-23 16:24:58.992520
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.expanduser('~'),'.cookiecutter-replay')
    if os.path.exists(replay_dir):
        raise IOError('File exists,please delete it first')
    dump(replay_dir,'test',{"test":"test"})
    if not os.path.exists(replay_dir):
        raise IOError('File not exists')
    if not os.path.exists(os.path.join(replay_dir,'test.json')):
        raise IOError('File not exists')
    os.remove(os.path.join(replay_dir,'test.json'))
    os.rmdir(replay_dir)

# Generated at 2022-06-23 16:25:03.761037
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    replay_dir = '/home/tom/replay'
    template_name = 'hello'
    template_name2 = 'hello.json'
    assert get_file_name(replay_dir, template_name) == '/home/tom/replay/hello.json'
    assert get_file_name(replay_dir, template_name2) == '/home/tom/replay/hello.json'
    

# Generated at 2022-06-23 16:25:05.641342
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("replay_dir", "template_name") == "replay_dir/template_name.json"



# Generated at 2022-06-23 16:25:11.484117
# Unit test for function dump
def test_dump():
    """Unit test dump."""
    replay_dir = "/Users/derek/Projects/cookiecutter"
    template_name = "test"
    context = {
        'cookiecutter': {},
        'full_name': 'Derek Schultz',
        'email': 'derek@schultz.com',
        'project_name': 'test',
        'project_slug': 'test'
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:25:21.666285
# Unit test for function load
def test_load():
    from cookiecutter import config
    # get the config
    replay_dir = config.DEFAULT_REPLAY_DIR
    template_name = 'pypackage'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context.keys()
    assert 'full_name' in context['cookiecutter'].keys()
    assert 'project_name' in context['cookiecutter'].keys()
    assert 'package_name' in context['cookiecutter'].keys()
    assert 'email' in context['cookiecutter'].keys()
    assert 'description' in context['cookiecutter'].keys()
    assert 'version' in context['cookiecutter'].keys()
    assert 'domain_name' in context['cookiecutter'].keys()


# Generated at 2022-06-23 16:25:23.634499
# Unit test for function load
def test_load():
    assert load('cookiecutter.yaml') == '1'

# Generated at 2022-06-23 16:25:25.314419
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay_dir', 'template_name') == 'template_name.json'
    assert get_file_name('replay_dir', 'template_name.json') == 'template_name.json'



# Generated at 2022-06-23 16:25:33.252340
# Unit test for function load
def test_load():
    """ Unit test for function load """
    from_dict = {'cookiecutter': {'full_name': 'Test User', 'email': 'test@example.com'}}
    dump('/tmp/replay', '{{ cookiecutter.repo_name }}', from_dict)
    to_dict = load('/tmp/replay', '{{ cookiecutter.repo_name }}')
    assert from_dict == to_dict
    os.remove('/tmp/replay/{{ cookiecutter.repo_name }}.json')
    os.rmdir('/tmp/replay')
# /test_load


# Generated at 2022-06-23 16:25:41.018193
# Unit test for function dump
def test_dump():
    replay_dir = 'C:\\Users\\i030458\\Documents\\GitHub\\Python\\cookiecutter'
    template_name = 'dummy'
    context = {
        'cookiecutter':
        {
            "full_name": "Audrius Butkevicius",
            "email": "audrius.butkevicius@sap.com",
            "github_username": "audrius-butkevicius"
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:25:44.128834
# Unit test for function load
def test_load():
    d = load('/home/xieyihui/Desktop/replay/', 'basic-g')
    print(d)
    
    
if __name__ == "__main__":
    test_load()
    print('end')

# Generated at 2022-06-23 16:25:48.708794
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'replays'
    template_name = 'foobar'
    result = get_file_name(replay_dir, template_name)
    assert(result == '{0}/{1}.json'.format(replay_dir, template_name))


# Generated at 2022-06-23 16:25:52.853743
# Unit test for function load
def test_load():
    replay_dir = 'D:/Day/MyPython/Python-CookieCutter/tests/fixtures/tests/'
    template_name = 'Audrey-Roy-Full-Stack-Dev'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context

# Generated at 2022-06-23 16:25:57.932962
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "/home/dennis/projects/cookiecutter-pypackage-minimal/cookiecutter-pypackage-minimal/.cookiecutter-test/"
    template_name = "cookiecutter-pypackage-minimal"
    fn = get_file_name(replay_dir, template_name)
    assert fn == replay_dir + template_name + ".json"

# Generated at 2022-06-23 16:26:04.259068
# Unit test for function load
def test_load():
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name.json'

    replay_file = get_file_name(replay_dir, template_name)
    if os.path.exists(replay_file):
        os.remove(replay_file)
    context = dict(cookiecutter='test_cookiecutter')
    dump(replay_dir, template_name, context)

    assert load(replay_dir, template_name) == context

    os.remove(replay_file)
    assert not os.path.exists(replay_file)

# Generated at 2022-06-23 16:26:06.677408
# Unit test for function get_file_name
def test_get_file_name():
    return get_file_name('/tmp', 'test')


# Generated at 2022-06-23 16:26:15.400445
# Unit test for function load
def test_load():
    """
    test_load.
    """
    repo_dir = os.path.dirname(os.path.abspath(__file__))
    replay_dir = os.path.join(repo_dir, 'tests', 'test-replay')
    template_name = 'test-repo'
    context = load(replay_dir, template_name)
    assert context.get('cookiecutter').get('full_name') == 'Peter Odding'
    assert context.get('cookiecutter').get('email') == 'peter.odding@paylogic.eu'
    assert context.get('cookiecutter').get('repo_name') == 'test-repo'

# Generated at 2022-06-23 16:26:18.852796
# Unit test for function load
def test_load():
    context = load(r'D:\Projects\initiate-python-project\tests\skeleton\cookiecutter\replay', 'requirements')
    print(context['cookiecutter'])


# Generated at 2022-06-23 16:26:24.320685
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    replay_dir = '/tmp/replay'
    template_name = 'my_template'

    filename = get_file_name(replay_dir, template_name)
    assert filename == '/tmp/replay/my_template.json'

    template_name = 'my_template.json'
    filename = get_file_name(replay_dir, template_name)
    assert filename == '/tmp/replay/my_template.json'


# Generated at 2022-06-23 16:26:26.660934
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("~/home","cookiecutter_test") == "~/home/cookiecutter_test"


# Generated at 2022-06-23 16:26:35.138058
# Unit test for function load
def test_load():
    json_file_path = '/Users/Lei/GitHub/cookiecutter-django/json_file'
    load_result = load(json_file_path, 'cookiecutter.json')
    assert load_result['project_name'] == 'Cookiecutter Django'
    assert load_result['project_slug'] == 'cookiecutter-django'
    assert load_result['project_short_description'] == 'A Cookiecutter template for creating production-ready Django projects quickly.'
    assert load_result['project_long_description'] == 'A full-featured Django project template.'

# Generated at 2022-06-23 16:26:36.564959
# Unit test for function load
def test_load():
    print(load('replay', 'cookiecutter'))


# Generated at 2022-06-23 16:26:45.278963
# Unit test for function dump
def test_dump():
    replay_dir = '../tests/fake-repo-pre/'
    template_name = 'fake_repo_pre'
    context = {'cookiecutter': {'full_name': 'Audrey Roy'}}
    dump(replay_dir, template_name, context)

    assert open(os.path.join(replay_dir,template_name+'.json'), 'r').read() == '{\n  "cookiecutter": {\n    "full_name": "Audrey Roy"\n  }\n}'


# Generated at 2022-06-23 16:26:46.972708
# Unit test for function load
def test_load():
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-23 16:26:55.172479
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'path/to/replay_dir'
    template_name = 'template_name'
    file_name = get_file_name(replay_dir, template_name)
    assert isinstance(file_name, str)
    assert file_name == 'path/to/replay_dir/template_name.json'
    # Test that the input path is normalized
    file_name = get_file_name('/path/to/replay_dir', template_name)
    assert file_name == '/path/to/replay_dir/template_name.json'
    # Test that the file name is retained
    file_name = get_file_name(replay_dir, 'template_name.json')
    assert file_name == 'path/to/replay_dir/template_name.json'


# Generated at 2022-06-23 16:26:58.258314
# Unit test for function get_file_name
def test_get_file_name():
    """Test 1."""
    replay_dir = '.'
    template_name = 'test'
    assert get_file_name(replay_dir, template_name) == 'test.json'


# Generated at 2022-06-23 16:27:02.659341
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "tests/test-output/"
    template_name = "cookiecutter-pypackage"
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == "tests/test-output/cookiecutter-pypackage.json"


# Generated at 2022-06-23 16:27:10.056221
# Unit test for function load
def test_load():
    """Test replay."""
    from cookiecutter.config import get_user_config
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    user_config = get_user_config(
        context_file='tests/test-repo/cookiecutter.json'
    )
    del user_config['no_input']

    template = 'tests/test-repo'
    replay_dir = 'tests/test-repo/{{cookiecutter.repo_name}}/'
    context = cookiecutter(
        template,
        replay_dir=replay_dir,
        no_input=True,
        extra_context=user_config['cookiecutter'])

    assert context is not None

    dumped_context = load(replay_dir, template)

    # Ensure the non-

# Generated at 2022-06-23 16:27:13.220851
# Unit test for function load
def test_load():
    res = load(replay_dir="test_dir", template_name="test_template")
    assert res['cookiecutter'] == res['cookiecutter']

# Generated at 2022-06-23 16:27:16.518448
# Unit test for function load
def test_load():
    template_name = 'simple_project'
    replay_dir = '/Users/yucheng/.cookiecutter_replay'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context, 'Context is required to contain a cookiecutter key'

# Generated at 2022-06-23 16:27:25.063131
# Unit test for function dump
def test_dump():
    replay_dir = os.getcwd()+"/replay"
    template_name = "mytest"
    context = {
        'cookiecutter': {
            'full_name': 'Your Name',
            'email': 'Your email',
            'project_name': 'Project name',
            'project_slug': 'slug',
            'description': 'description',
            'repo_name': 'repo_name',
            'version': 'version',
            'open_source_license': 'license',
        }
    }

    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:27:31.003796
# Unit test for function get_file_name
def test_get_file_name():

    assert get_file_name('/tmp/test', 'cookiecutter-pypackage') == '/tmp/test/cookiecutter-pypackage.json'
    assert get_file_name('/tmp/test', 'cookiecutter-pypackage.json') == '/tmp/test/cookiecutter-pypackage.json'

# Generated at 2022-06-23 16:27:39.176424
# Unit test for function dump
def test_dump():
    """Test function dump."""
    temp_template = 'TEMPLATE'
    temp_replay_dir = 'tests/test_replay_dir'
    temp_context = {'cookiecutter': {'name': 'name', 'a': 'a', 'b': 'b'}}

    dump(temp_replay_dir, temp_template, temp_context)

    path = get_file_name(temp_replay_dir, temp_template)
    assert os.path.isfile(path) == True



# Generated at 2022-06-23 16:27:44.173494
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/tmp/replay/'
    template_name = 'cookiecutter-pypackage'
    file_name = get_file_name(replay_dir, template_name)
    print(file_name)
    file_name = get_file_name(replay_dir, template_name + ".json")
    print(file_name)


# Generated at 2022-06-23 16:27:47.382023
# Unit test for function get_file_name
def test_get_file_name():
    template_name = "mynewtemplate"
    replay_dir = os.path.join(os.path.expanduser('~'), '.cookiecutters')
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == os.path.join(replay_dir, template_name+'.json')


# Generated at 2022-06-23 16:27:52.314194
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'abc'
    replay_dir = '/tmp/cookicutter'
    assert get_file_name(replay_dir, template_name) =='/tmp/cookicutter/abc.json'


# Generated at 2022-06-23 16:27:57.270359
# Unit test for function get_file_name
def test_get_file_name():
    """Test for method get_file_name."""
    template_name = 'test'
    replay_dir = 'replay'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'replay/test.json'



# Generated at 2022-06-23 16:28:04.888827
# Unit test for function dump
def test_dump():
    from pytest import raises
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as td:
        dump(td, 'test', {'cookiecutter': {}})
        with raises(TypeError):
            dump(td, 1, {})
        with raises(TypeError):
            dump(td, 'test', 1)
        with raises(ValueError):
            dump(td, 'test', {})
        with raises(IOError):
            dump('/invalid', 'test', {'cookiecutter': {}})



# Generated at 2022-06-23 16:28:06.204723
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '.'
    template_name = 'example'
    print(get_file_name(replay_dir, template_name))

# Generated at 2022-06-23 16:28:12.608831
# Unit test for function load
def test_load():
    """Simple test case for load."""

# Generated at 2022-06-23 16:28:16.042128
# Unit test for function load
def test_load():
    context = load("C:/Users/Cookie/Desktop/Bachelorthesis/Test/cookiecutter/replay", "cookiecutter-pypackage")
    print (context)



# Generated at 2022-06-23 16:28:21.429161
# Unit test for function load
def test_load():
    replay_file = get_file_name("/Users/replay_dir/", "template_name")
    with open(replay_file, 'r') as infile:
        context = json.load(infile)
    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')
    return context


# Generated at 2022-06-23 16:28:27.169393
# Unit test for function dump
def test_dump():
    replay_dir = "./tests/test-output/replay/dump"
    template_name = "replay_test"
    context = {"cookiecutter": {'full_name': 'Full Name', 'email': 'email@example.com'}}
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    os.remove(replay_file)


# Generated at 2022-06-23 16:28:32.848476
# Unit test for function get_file_name
def test_get_file_name():
    """test for get_file_name"""
    replay_dir = "this_is_a_test"
    template_name = "test"
    test_file_name = get_file_name(replay_dir, template_name)
    assert test_file_name == os.path.join(replay_dir, template_name + ".json")


# Generated at 2022-06-23 16:28:36.704353
# Unit test for function load
def test_load():
    replay_dir='C:\\Users\\Edmond.L.n\\Desktop\\cookiecutter-pypackage-minimal'
    template_name='cookiecutter.json'
    try:
        context=load(replay_dir,template_name)
    except Exception as e:
        print(e.args)
    else:
        print('Success')
        

# Generated at 2022-06-23 16:28:41.975698
# Unit test for function get_file_name
def test_get_file_name():
    """Test the get_file_name function."""
    replay_dir = '/tmp'
    template_name = 'test-repo'
    expected_file_name = '/tmp/test-repo.json'
    file_name = get_file_name(replay_dir,template_name)
    assert file_name == expected_file_name

# Generated at 2022-06-23 16:28:46.961329
# Unit test for function load
def test_load():
    import pytest
    test_template = "test_template"
    test_context = {"cookiecutter": {
        "full_name": "test_fullname",
        "email": "test_email",
        "test_field": "test_value"
    }}
    dump("test_replay_dir", test_template, test_context)

    loaded_context = load("test_replay_dir", test_template)

    assert test_context == loaded_context

# Generated at 2022-06-23 16:28:59.544884
# Unit test for function dump
def test_dump():
    replay_dir = r'C:\Users\Owner\Desktop\GitHub\cookiecutter-pypackage-minimal'
    template_name = "template"

# Generated at 2022-06-23 16:29:08.243441
# Unit test for function dump
def test_dump():
  replay_dir = '/tmp/cookiecutter'
  template_name = 'test_template'
  context = {'cookiecutter': {'test_key': 'test_value'}}
  dump(replay_dir, template_name, context)

  replay_file = get_file_name(replay_dir, template_name)
  with open(replay_file, 'r') as infile:
    new_context = json.load(infile)

  try:
    assert(context == new_context)
  except AssertionError:
    print('Dump failed. Did not write correct value to file.')
  finally:
    os.remove(replay_file)



# Generated at 2022-06-23 16:29:14.055409
# Unit test for function dump
def test_dump():
    replay_dir='replay'
    template_name='127.0.0.1'
    context='{"cookiecutter":{"full_name":"Ran Wang","email":"wangr3@rpi.edu","project_name":"Ranzc","directory_name":"Ranzc","open_source_license":"MIT license"}}'
    json=dump(replay_dir, template_name, context)
    return json


# Generated at 2022-06-23 16:29:17.692993
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    template_name = "template_name"
    context = {"key": "value"}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:29:26.849556
# Unit test for function dump
def test_dump():
    reload(sys)
    sys.setdefaultencoding('utf8')
    replay_dir = '/home/happygirlzt/code/python/cookiecutter/cookiecutter/replay'
    template_name = 'django-pypackage'

# Generated at 2022-06-23 16:29:28.913892
# Unit test for function load
def test_load():
    import doctest
    doctest.testmod(verbose=True)
    doctest.testfile('docs/load.rst', verbose=True)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-23 16:29:32.406696
# Unit test for function load
def test_load():
    """Unit test for function load."""
    assert isinstance(load('/tmp/batman', 'jee'), dict)



# Generated at 2022-06-23 16:29:35.418425
# Unit test for function get_file_name
def test_get_file_name():
    result = os.path.join(os.getcwd(), 'tmp', 'cookiecutter_replay', 'repo.json')
    assert get_file_name('tmp/cookiecutter_replay', 'repo') == result



# Generated at 2022-06-23 16:29:40.252977
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/tmp/replay'
    old_template_name = 'cookiecutter-pypackage'
    expected_file_name = os.path.join(replay_dir, 'cookiecutter-pypackage.json')
    file_name = get_file_name(replay_dir, old_template_name)
    assert file_name == expected_file_name

# Generated at 2022-06-23 16:29:44.261287
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/adria/cookiecutter_replay'
    template_name = 'sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfs'
    file_name = get_file_name(replay_dir, template_name)
    print('get_file_name = {}'.format(file_name))


# Generated at 2022-06-23 16:29:51.692022
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name."""
    assert get_file_name(os.getcwd(), 'test') == os.path.join(os.getcwd(), 'test.json')
    assert get_file_name(os.getcwd(), 'test.json') == os.path.join(os.getcwd(), 'test.json')
    assert get_file_name(os.getcwd(), 'test.json.json') == os.path.join(os.getcwd(), 'test.json.json')


# Generated at 2022-06-23 16:29:56.809717
# Unit test for function dump
def test_dump():
    replay_dir = 'test_repo'
    template_name = 'test_template'
    context = {'cookiecutter': 'foo'}
    dump(replay_dir, template_name, context)
    assert get_file_name(replay_dir, template_name) == 'test_repo/test_template.json'
    assert os.path.isfile(os.path.join(replay_dir, "test_template.json"))

if __name__ == "__main__":
    test_dump()

# Generated at 2022-06-23 16:29:59.585664
# Unit test for function load
def test_load():
    _context = load("./replays", "fg2gh")
    assert isinstance(_context, dict)
    assert "cookiecutter" in _context

# Generated at 2022-06-23 16:30:04.661835
# Unit test for function dump
def test_dump():
    replay_dir = "C:/Users/wuhui/Desktop/cookiecutter_repo_test"
    template_name = "template_name"
    context = {'cookiecutter': 'cookiecutter', 'test': 'test'}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:30:12.715480
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    template_name = 'hackathon'
    context = {'replay_dir' : 'replay', 'template_name' : 'Hackathon',
               'cookiecutter': {'repo_dir': 'repository', 'context' : 'ROOT'}}
    try:
        dump(context['replay_dir'], context['template_name'], context)
    except (IOError, TypeError, ValueError) as error:
        return False
    return True


# Generated at 2022-06-23 16:30:14.934110
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('./tests/test_data', 'some_template') == './tests/test_data/some_template.json'


# Generated at 2022-06-23 16:30:19.538325
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/fixtures/test-replay'
    template_name = 'dummy-replay'
    context = {'cookiecutter': {'full_name': 'GCI-2018'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-23 16:30:24.548610
# Unit test for function dump
def test_dump():
    """Test function dump."""
    replay_dir='/home/minh'
    template_name='test.json'
    context={'cookiecutter':'THANG','b':'b','c':'c'}

    result=dump(replay_dir, template_name, context)
    assert result =='/home/minh'


# Generated at 2022-06-23 16:30:29.181547
# Unit test for function get_file_name
def test_get_file_name():
    """Test the get_file_name function."""
    replay_dir = 'tests/fake-repo-pre/'
    template_name = 'fake-repo-pre/tests/fake-repo-pre'
    assert get_file_name(replay_dir, template_name) == "tests/fake-repo-pre/tests_fake-repo-pre.json"


# Generated at 2022-06-23 16:30:36.793870
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '~/cookiecutter/replay'
    template_name1 = 'gh:audreyr/cookiecutter-pypackage'
    template_name2 = 'https://github.com/audreyr/cookiecutter-pypackage.git'
    template_name3 = 'https://github.com/audreyr/cookiecutter-pypackage.git#asdf'
    assert get_file_name(replay_dir, template_name1) == os.path.join(os.path.expanduser(replay_dir), template_name1 + '.json')
    assert get_file_name(replay_dir, template_name2) == os.path.join(os.path.expanduser(replay_dir), template_name2 + '.json')
    assert get_file

# Generated at 2022-06-23 16:30:44.365722
# Unit test for function get_file_name
def test_get_file_name():
    # Replace get_file_name function in replay to allow reading from a known location
    global get_file_name
    def get_file_name(replay_dir, template_name):
        return '{}/{}'.format(replay_dir, 'stub.json')

    template_name = 'stub'
    replay_dir = 'tests/replay'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == 'tests/replay/stub.json'


# Generated at 2022-06-23 16:30:45.266696
# Unit test for function dump
def test_dump():
    assert True


# Generated at 2022-06-23 16:30:47.956090
# Unit test for function dump
def test_dump():
    r = "new_directory"
    t = "my_template"
    c = {'cookiecutter': {'_copy_without_render': ['toto.txt']}}
    try:
        dump(r,t,c)
    except :
        return False
    return True


# Generated at 2022-06-23 16:30:53.993088
# Unit test for function load
def test_load():
    # Setup a test directory
    import tempfile

    replay_dir = tempfile.mkdtemp()

    # Add a file
    template_name = 'test'
    context = {'cookiecutter': {'full_name': 'Test User'}}

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    # Load file
    loaded = load(replay_dir, template_name)

    assert loaded == context

    os.remove(replay_file)
    os.rmdir(replay_dir)

# Generated at 2022-06-23 16:30:56.362546
# Unit test for function load
def test_load():
    load('{"cookiecutter" : {"project_name" : "Project Name", "role" : "Role"}}')


# Generated at 2022-06-23 16:31:00.308433
# Unit test for function load
def test_load():
    """Test load function."""
    context = load("/Users/kaixuan/Documents/GitHub/FCP_PCA_TEST/cookiecutter-pypackage", "pypackage")
    print(context)
    return context



# Generated at 2022-06-23 16:31:03.561296
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '/home/foo/bar'
    template_name = 'template'
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == '/home/foo/bar/template.json'



# Generated at 2022-06-23 16:31:06.216152
# Unit test for function load
def test_load():
    replay_dir = "test"
    template_name = "test_template"
    assert isinstance(load(replay_dir, template_name), dict)


# Generated at 2022-06-23 16:31:11.620028
# Unit test for function get_file_name
def test_get_file_name():
    # Test 1
    replay_dir = "~/my_replay_dir"
    template_name = "my_template"
    output = "~/my_replay_dir/my_template.json"
    assert get_file_name(replay_dir, template_name) == output
    # Test 2
    replay_dir = "~/replay"
    template_name = "template.json"
    output = "~/replay/template.json"
    assert get_file_name(replay_dir, template_name) == output
    # Test 3
    replay_dir = "~/replay"
    template_name = "sub_dir/template.json"
    output = "~/replay/sub_dir/template.json"

# Generated at 2022-06-23 16:31:16.170600
# Unit test for function dump
def test_dump():
    dummy_replay_dir = 'tests/files/dummy_replay_dir'
    dummy_template_name = 'tests/files/dummy_template_name'
    dummy_context = 'tests/files/dummy_context'
    dump(dummy_replay_dir, dummy_template_name, dummy_context)


# Generated at 2022-06-23 16:31:24.305241
# Unit test for function dump
def test_dump():
    import os
    import shutil
    from os.path import abspath, dirname, join

    here = abspath(dirname(__file__))
    replay_dir = abspath(join(here, 'cookiecutter'))

    template_name = 'test'
    context = {'cookiecutter': 'secret'}

    try:
        dump(replay_dir, template_name, context)
        context_actual = load(replay_dir, template_name)

        assert context_actual == context
    finally:
        shutil.rmtree(replay_dir, ignore_errors=True)

# Generated at 2022-06-23 16:31:27.980476
# Unit test for function load
def test_load():
    assert load('replay', 'cookiecutter-demo')

    try:
        load(3.14,'cookiecutter-demo')
    except TypeError:
        print("Template name is required to be of type str")
        print("Temporary test case for load function passed!")
    else:
        assert False


# Generated at 2022-06-23 16:31:30.143577
# Unit test for function load
def test_load():
    replay_dir = '/Users/jonathan/Documents/dev/cookiecutter-replay'

    context = load(replay_dir, 'makina-states-cookiecutter')
    print(context)

# Generated at 2022-06-23 16:31:32.194206
# Unit test for function get_file_name
def test_get_file_name():

    replayedir = 'testreplay'
    template_name = 'test_template'
    replayfile = get_file_name(replayedir, template_name)
    assert replayfile == 'testreplay/test_template.json'


# Generated at 2022-06-23 16:31:36.011779
# Unit test for function load
def test_load():
    replay_dir = '{{ cookiecutter.replay_dir }}'
    template_name = '{{ cookiecutter.template_name }}'
    if __name__ == '__main__':
        load(replay_dir, template_name)


# Generated at 2022-06-23 16:31:40.032886
# Unit test for function load
def test_load():
    """Test function load."""
    replay_dir = 'cookiecutter/tests/test-load'
    template_name = 'cookiecutter/tests/test-load/{{cookiecutter.repo_name}}'

    context = {
        'cookiecutter': {
            'project_name': 'Hello World',
            'repo_name': 'helloworld',
            'development_status': '1 - Planning',
        }
    }

    dump(replay_dir, template_name, context)
    context_ret = load(replay_dir, template_name)

    assert 'project_name' in context_ret['cookiecutter']
    assert context['cookiecutter']['project_name'] == context_ret['cookiecutter']['project_name']

# Generated at 2022-06-23 16:31:41.319047
# Unit test for function load
def test_load():
    """Test the function load."""
    return


# Generated at 2022-06-23 16:31:51.398864
# Unit test for function dump
def test_dump():
    tmp_dir = os.path.join(os.getcwd(), 'tmp')
    file_name = 'valid_file'
    context = {'cookiecutter':{'full_name':'Foo Bar', 'email':'contact@bar.com'}}
    dump(tmp_dir, file_name, context)

    f = open(os.path.join(tmp_dir, file_name + '.json'), 'r')
    assert f.read() == json.dumps(context, indent=2)
    f.close()
    os.remove(os.path.join(tmp_dir, file_name + '.json'))
    os.rmdir(tmp_dir)


# Generated at 2022-06-23 16:31:55.362428
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '~/Desktop'
    assert get_file_name(replay_dir, '123') == '~/Desktop/123'
    assert get_file_name(replay_dir, '123.json') == '~/Desktop/123.json'
    assert get_file_name(replay_dir, '123.json') == '~/Desktop/123.json'
    


# Generated at 2022-06-23 16:31:58.755211
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('~/cookiecutters', 'cookiecutter-pipproject') == '/home/jessica/cookiecutters/cookiecutter-pipproject.json'


# Generated at 2022-06-23 16:32:02.791477
# Unit test for function load
def test_load():
    replay_dir = './tests/test-replay'
    template_name = 'test-template'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context


# Generated at 2022-06-23 16:32:10.364424
# Unit test for function load
def test_load():
    expected_context = {
        'cookiecutter': {
            'project_name': 'My Test Project',
            '_template': '.',
            'repo_name': 'cookiecutter-pypackage'
        }
    }
    path_to_testfile = os.path.join(
        os.path.dirname(__file__),
        '../fixtures/replay/cookiecutter-pypackage.json'
    )
    assert load(path_to_testfile, 'cookiecutter-pypackage') == expected_context

# Generated at 2022-06-23 16:32:14.667460
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('', 'test') == 'test.json'
    assert get_file_name('', 'test.json') == 'test.json'
    assert get_file_name('abc', 'test') == 'abc/test.json'
    assert get_file_name('abc', 'test.json') == 'abc/test.json'

# Generated at 2022-06-23 16:32:19.016911
# Unit test for function dump
def test_dump():
    from cookiecutter.replay import dump
    from cookiecutter import utils
    temp_dir = utils.get_user_dir()
    replay_dir = os.path.join(temp_dir, 'cookiecutters_replay')
    template_name = 'template_name'
    context = 'context'
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert context == 'context'


# Generated at 2022-06-23 16:32:22.298212
# Unit test for function load
def test_load():
    """Unit test for function load."""
    replay_dir = os.getcwd()
    template_name = 'travis-deployment-example'
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-23 16:32:31.840118
# Unit test for function dump
def test_dump():
    """An example of a unit test for the function dump."""
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-tmpl'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'project_name': 'cookiecutter-pypackage',
        },
    }
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))


# Generated at 2022-06-23 16:32:39.597933
# Unit test for function load
def test_load():
    """Unit test for function load."""
    try:
        load('does/not/exist', 'test_name')
    except TypeError:
        pass
    except Exception as e:
        assert False, e

    try:
        load(None, 'test_name')
    except TypeError:
        pass
    except Exception as e:
        assert False, e

    try:
        load('tests/fixtures/replay', None)
    except TypeError:
        pass
    except Exception as e:
        assert False, e

    replay_dir = 'tests/fixtures/replay'
    template_name = 'fake_context'

    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert isinstance(context, dict)

# Generated at 2022-06-23 16:32:48.207679
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join('test', 'files', 'test-replay-dir')
    context = {
        'cookiecutter': {
            'full_name': 'Your Name',
            'email': 'Your email',
            'project_name': 'project name',
            'repo_name': 'repo_name',
            'description': 'description',
            'version': 'version',
            'open_source_license': 'open_source_license'
        }
    }
    dump(replay_dir, 'foobar', context)

    test_file = os.path.join(replay_dir, 'foobar.json')
    assert os.path.exists(test_file)


# Generated at 2022-06-23 16:32:52.768860
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = '~/Documents'
    template_name = 'new-repo'
    file_name = 'new-repo.json'

    assert get_file_name(replay_dir, template_name) == os.path.join(replay_dir, file_name)


# Generated at 2022-06-23 16:32:57.496204
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = os.path.abspath('test_replay_dir')
    template_name = 'test_template_name'

    file_name = get_file_name(replay_dir, template_name)

    assert file_name == os.path.abspath(os.path.join(replay_dir, template_name+'.json')), 'file_name is incorrect'

    # Unit test for function load

# Generated at 2022-06-23 16:33:07.383916
# Unit test for function dump
def test_dump():
    replay_dir = 'cookiecutter/tests/test-output/replay'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-23 16:33:12.174518
# Unit test for function get_file_name
def test_get_file_name():
    """Unit test for function get_file_name."""
    assert get_file_name('./testcase', 'test.json') == './testcase/test.json'
    assert get_file_name('./testcase', 'test') == './testcase/test.json'


# Generated at 2022-06-23 16:33:21.076460
# Unit test for function dump
def test_dump():
    directory = os.path.join(
        os.path.expanduser('~'),
        'cookiecutters'
    )
    replay_dir = os.path.join(directory, '.cookiecutter_replay')
    template_name = 'example-template'
    context = {
        'cookiecutter': {
            'full_name': 'Test User',
            'email': 'test@user.com',
            'github_username': 'testuser',
            'project_name': 'example-project'
        }
    }
    dump(replay_dir, template_name, context)
    os.remove(os.path.join(replay_dir, template_name + '.json'))
