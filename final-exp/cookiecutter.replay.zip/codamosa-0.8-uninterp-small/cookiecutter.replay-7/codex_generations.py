

# Generated at 2022-06-25 15:33:00.405711
# Unit test for function load
def test_load():
    dump('./', 'test_0.json', {'cookiecutter': {'first_name': 'potato'}})
    dict_0 = load('./', 'test_0.json')
    assert dict_0['cookiecutter']['first_name'] == 'potato'

# Generated at 2022-06-25 15:33:03.423352
# Unit test for function load
def test_load():

    # Call function load
    res = load()

    assert res['version'] == '0.0.0'

# Generated at 2022-06-25 15:33:12.987126
# Unit test for function load
def test_load():
    # Arrange
    replay_dir = './'
    template_name = 'cookiecutter-pypackage'
    expected = {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'project_slug': 'cookiecutter-pypackage',
            'project_name': 'Cookiecutter PyPackage',
            'project_short_description':
            'A cookiecutter template for a Python package.',
            'pypi_username': 'audreyr',
            'version': '0.1.0',
            'release_date': '2016-05-29',
            'year': '2016',
        }
    }

    # Act
    actual = load(replay_dir, template_name)

# Generated at 2022-06-25 15:33:14.672634
# Unit test for function load
def test_load():
    assert calls.tuple_0(var_0) is not None

# Generated at 2022-06-25 15:33:19.561148
# Unit test for function load
def test_load():
    import os

    # Assign parameter.
    params = {
        'replay_dir': os.path.abspath('.'),
        'template_name': 'test_foo',
    }
    context = {
        'cookiecutter': {
            'foo': 'bar',
        }
    }

    # Load data
    load(**params)

    # Generate a file.
    dump(**params, context=context)

    # Load data
    load(**params)


# Generated at 2022-06-25 15:33:28.747466
# Unit test for function get_file_name
def test_get_file_name():
    tuple_0 = r'home\files\replays'
    dict_0 = r'home\files\replays\template_name.json'
    var_0 = get_file_name(tuple_0, dict_0)
    assert file_name == r'home\files\replays\template_name.json', 'Expected template_name.json'

    tuple_1 = r'home\files\replays'
    dict_1 = 'template_name'
    var_0 = get_file_name(tuple_1, dict_1)
    assert file_name == r'home\files\replays\template_name.json', 'Expected template_name.json'

    tuple_2 = None
    dict_2 = 'home\files\replays\template_name.json'
    var_0 = get

# Generated at 2022-06-25 15:33:32.093992
# Unit test for function load
def test_load():
    # print('\n\n')
    # test_case_0()
    pass

# main() function.

# Generated at 2022-06-25 15:33:37.365872
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "tuple_0"
    template_name = "tuple_1"
    var_0 = get_file_name(replay_dir, template_name)
    assert var_0 == r'tuple_0/tuple_1.json', """File name "tuple_0/tuple_1.json" doesn't match expected result "r'tuple_0/tuple_1.json'" """


# Generated at 2022-06-25 15:33:38.635345
# Unit test for function load
def test_load():
    if __name__ == '__main__':
        test_case_0()


# Generated at 2022-06-25 15:33:40.926363
# Unit test for function load
def test_load():
    # Load arguments
    replay_dir = ""  # TODO
    template_name = ""  # TODO
    assert load(replay_dir, template_name)


# Generated at 2022-06-25 15:33:42.991856
# Unit test for function load
def test_load():
    test_case_0()



# Generated at 2022-06-25 15:33:46.976738
# Unit test for function dump
def test_dump():
    replay_dir = '~/.cookiecutter_replay/'
    template_name = '~/.cookiecutter_replay/'
    context = dump(replay_dir, template_name, context)
    assert dump(replay_dir, template_name, context) == '~/.cookiecutter_replay/~/.cookiecutter_replay/.json'

# Generated at 2022-06-25 15:33:50.993827
# Unit test for function load
def test_load():
    for _ in range(10):
        # Test for exception: TypeError
        try:
            load(b'\xb0\xe7V\x1e\xf7|>c\x14\x06+\x8f\x89\x87\x9f', None)
            var_0 = load(b'\xb0\xe7V\x1e\xf7|>c\x14\x06+\x8f\x89\x87\x9f',b'\xb0\xe7V\x1e\xf7|>c\x14\x06+\x8f\x89\x87\x9f')
        except TypeError:
            pass
            

# Generated at 2022-06-25 15:33:57.465600
# Unit test for function load
def test_load():
    bytes_0 = b'\x19\xf2p\xb3Y\xa1t%\xb9\xf1X\x8eW'
    str_0 = '~/.cookiecutter_replay/'
    var_0 = load(str_0, str_0)
    assert str(var_0) == 'None'


# Generated at 2022-06-25 15:34:00.135129
# Unit test for function load
def test_load():
    str_0 = '~/.cookiecutter_replay/'
    with pytest.raises(ValueError):
        var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:34:01.373986
# Unit test for function load
def test_load():
    t0 = test_case_0()

# Generated at 2022-06-25 15:34:07.020802
# Unit test for function load
def test_load():
    str_0 = 'Do not use this template: {{ cookiecutter.is_a_cookiecutter_bug }}. We recommend that you use {{ cookiecutter.project_name }} instead.'
    bytes_0 = b'\x19\xf2p\xb3Y\xa1t%\xb9\xf1X\x8eW'
    str_1 = '~/.cookiecutter_replay/'
    var_0 = load(str_1, str_1)
    print(var_0)


# Generated at 2022-06-25 15:34:12.195378
# Unit test for function load
def test_load():
    replay_dir = b'~/.cookiecutter_replay/'
    template_name = b'~/.cookiecutter_replay/'
    load(replay_dir, template_name)


# Generated at 2022-06-25 15:34:21.422434
# Unit test for function load
def test_load():
    print ('test_load')
    # test_case_0
    print ('test_case_0')
    str_0 = '/tmp/cookiecutter-tests/tests/tests_for_replay/replay_dir'
    str_1 = '/tmp/cookiecutter-tests/tests/tests_for_replay/replay_dir'
    dict_0 = load(str_0, str_1)
    string_0 = 'cookiecutter'
    assert string_0 in dict_0
    int_0 = 1
    assert dict_0[string_0]['full_name'] == int_0
    int_1 = 2
    assert dict_0[string_0]['email'] == int_1
    string_1 = 'Tests for Replay  '

# Generated at 2022-06-25 15:34:27.656272
# Unit test for function dump
def test_dump():
    """Test that the ``foo`` function returns ``0``."""
    # Setup
    tempdir = tempfile.mkdtemp()
    context = {'cookiecutter': {'project_name': 'Foo Bar'}}
    try:
        dump(tempdir, 'fake', context)
        # Exercise
        result = load(tempdir, 'fake')
    finally:
        shutil.rmtree(tempdir)
    # Verify
    assert result == context

# Generated at 2022-06-25 15:34:38.047100
# Unit test for function load
def test_load():
    assert list(load(b'\x19\xf2p\xb3Y\xa1t%\xb9\xf1X\x8eW', b'\x19\xf2p\xb3Y\xa1t%\xb9\xf1X\x8eW'))[0] == list(load(b'\x19\xf2p\xb3Y\xa1t%\xb9\xf1X\x8eW', b'\x19\xf2p\xb3Y\xa1t%\xb9\xf1X\x8eW'))[0]


# Generated at 2022-06-25 15:34:41.576619
# Unit test for function load
def test_load():
    replay_dir = "~/.cookiecutter_replay/"
    template_name = "foo_project"
    context = dict(cookiecutter = dict(foo = "bar"))
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-25 15:34:42.322860
# Unit test for function load
def test_load():
    assert True


# Generated at 2022-06-25 15:34:46.004633
# Unit test for function dump
def test_dump():
    dir_0 = '~/.cookiecutter_replay/'
    str_0 = 'test_dump'
    dict_0 = {'test': 'test', 'testdict': {'testdictitem': True}}
    # dump(dir_0, str_0, dict_0)
    # assertEqual(expected, dump(replay_dir, template_name, context))


# Generated at 2022-06-25 15:34:46.857210
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:34:50.859908
# Unit test for function load
def test_load():
    dump('.cookiecutter_replay', '.cookiecutter_replay',
         {'cookiecutter': {}})

    expected = {'cookiecutter': {}}
    actual = load('.cookiecutter_replay', '.cookiecutter_replay')
    assert expected == actual


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:34:51.596865
# Unit test for function load
def test_load():
    test_case_0()



# Generated at 2022-06-25 15:34:56.854700
# Unit test for function dump
def test_dump():
    replay_dir = '~/.cookiecutter_replay/'
    template_name = '~/.cookiecutter_replay/'
    context = {'cookiecutter': {'_template': '~/.cookiecutter_replay/'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:35:04.094103
# Unit test for function load
def test_load():
    bytes_0 = b'\x19\xf2p\xb3Y\xa1t%\xb9\xf1X\x8eW'
    str_0 = '~/.cookiecutter_replay/'
    var_0 = load(str_0, str_0)
    # print(var_0)
    assert str(type(var_0)) == "<class \'dict\'>"



# Generated at 2022-06-25 15:35:05.715748
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except Exception as err:
        print("Exception in test case 0: {}".format(err))


# Generated at 2022-06-25 15:35:12.654480
# Unit test for function load
def test_load():
    str_0 = './'
    var_0 = load(str_0, str_0)
    assert var_0 == {}


# Generated at 2022-06-25 15:35:19.543238
# Unit test for function dump
def test_dump():
    str_0 = './'
    dict_0 = dict()
    test_case_0()
    test_case_1()
    dump(str_0, str_0, dict_0)
    replay_dir = './'
    template_name = './'
    context = dict()
    dump(replay_dir, template_name, context)



# Generated at 2022-06-25 15:35:26.945781
# Unit test for function load
def test_load():
    import io
    import sys

    captured_output = io.StringIO()
    sys.stdout = captured_output
    test_case_0()
    sys.stdout = sys.__stdout__
    assert captured_output.getvalue().rstrip() == '<module \'cookiecutter.main\' from \'C:\\Users\\Jing\\PycharmProjects\\ljyb\\venv\\lib\\site-packages\\cookiecutter\\main.py\'>'

# Generated at 2022-06-25 15:35:34.275539
# Unit test for function dump
def test_dump():
    replay_dir = '/home/vagrant/www/cookiecutter-pypackage-minimal'
    template_name = 'cookiecutter-pypackage-minimal'

# Generated at 2022-06-25 15:35:36.711977
# Unit test for function load
def test_load():
    str_0 = './'
    var_0 = load(str_0, str_0)
    assert var_0 == {}


# Generated at 2022-06-25 15:35:47.622568
# Unit test for function load
def test_load():
    # Example usage:
    #   >>> load('./', './')
    #   {}
    #   >>> load('./', './')
    #   {}
    #   >>> load('./', './')
    #   {}
    #   >>> load('./', './')
    #   {}
    #   >>> load('./', './')
    #   {}
    #   >>> load('./', './')
    #   {}
    #   >>> load('./', './')
    #   {}
    #   >>> load('./', './')
    #   {}
    assert load('./', './') == {}
    assert load('./', './') == {}
    assert load('./', './') == {}
    assert load('./', './')

# Generated at 2022-06-25 15:35:48.901374
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:35:52.633740
# Unit test for function load
def test_load():
    assert str is not None


# Generated at 2022-06-25 15:35:57.949761
# Unit test for function load
def test_load():
    replay_dir = os.path.dirname(os.path.realpath(__file__))
    context = load(replay_dir, 'test_load')
    assert context['cookiecutter']['full_name'] == 'Test Load'


# Generated at 2022-06-25 15:36:00.083798
# Unit test for function load
def test_load():
    str_0 = './'
    var_0 = load(str_0, str_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 15:36:14.853371
# Unit test for function load
def test_load():

    # Setup
    str_1 = './'
    str_2 = './cookiecutter/'
    str_3 = './cookiecutter.json'


    # Invoke test_case_0
    test_case_0()

    # Test
    assert var_0 is None



# Generated at 2022-06-25 15:36:17.838301
# Unit test for function load
def test_load():
    var_0 = './'
    var_1 = load(var_0, var_0)
    var_2 = load(var_0, var_0)
    assert var_1 == var_2


# Generated at 2022-06-25 15:36:24.841588
# Unit test for function load
def test_load():
    assert load(None, None) != None
    assert load('.gitignore', '.gitignore') == None
    assert load('./', './') != None
    assert load('tests/fixtures/fake-repo-pre', 'fake-repo-pre') != None
    assert load('tests/fixtures/fake-repo-pre/', 'fake-repo-pre/') != None


# Generated at 2022-06-25 15:36:27.986842
# Unit test for function load
def test_load():
    str_0 = './'
    var_0 = load(str_0, str_0)
    assert(1 if var_0 else 0)



# Generated at 2022-06-25 15:36:34.528413
# Unit test for function load
def test_load():
    str_0 = 'None'
    str_1 = './'
    str_2 = './'
    str_3 = './'

    try:
        load(str_0, str_1)
    except TypeError:
        pass
    else:
        raise Exception('Expected TypeError not raised')

    try:
        load(str_2, str_3)
    except ValueError:
        pass
    else:
        raise Exception('Expected ValueError not raised')


# Generated at 2022-06-25 15:36:45.313243
# Unit test for function dump
def test_dump():
    # Test case 0
    replay_dir = "./"
    template_name = "/test_data/test_cookiecutter.json"
    context = {'something': 'something'}
    dump(replay_dir, template_name, context)

    # Test case 1
    replay_dir = "./"
    template_name = "/test_data/test_cookiecutter.json"
    context = {'something': 'something'}
    dump(replay_dir, template_name, context)

    # Test case 2
    replay_dir = "./"
    template_name = "/test_data/test_cookiecutter.json"
    context = {'something': 'something'}
    dump(replay_dir, template_name, context)

    # Test case 3
    replay_dir = "./"
   

# Generated at 2022-06-25 15:36:52.117236
# Unit test for function dump
def test_dump():
    replay_dir = './'
    template_name = 'a'
    context = 'b'
    dump(replay_dir, template_name, context)
    print('First data is', end='')
    print(context)
    print('Second data is', end='')
    print(load(replay_dir, template_name))


if __name__ == '__main__':
    test_case_0()
    test_dump()
    print('cookiecutter.replay test successfully')

# End of file

# Generated at 2022-06-25 15:37:01.613336
# Unit test for function load
def test_load():
	template_name = './'
	replay_dir = './'
	result = load(replay_dir, template_name)

# Generated at 2022-06-25 15:37:07.599542
# Unit test for function dump
def test_dump():
    str_0 = './'
    str_1 = './'
    str_2 = './'
    str_3 = './'
    var_0 = get_file_name(str_0, str_1)
    var_1 = make_sure_path_exists(str_2)
    var_2 = dump(str_3, str_3, var_1)


# Generated at 2022-06-25 15:37:09.559380
# Unit test for function load
def test_load():
    print(load('arg_0', 'arg_1'))


# Generated at 2022-06-25 15:37:29.138038
# Unit test for function dump
def test_dump():
    str_0 = '{}'
    str_1 = 'template_name'
    str_2 = './'
    str_3 = 'replay_dir'
    dict_0 = {str_1: str_0}
    test_dump_0(str_2, str_0, dict_0)
    test_dump_1(str_3, str_0, dict_0)
    test_dump_2(str_3, str_1, dict_0)
    test_dump_3(str_3, str_1, dict_0)
    test_dump_4(str_2, str_1, dict_0)


# Generated at 2022-06-25 15:37:37.699564
# Unit test for function load
def test_load():
    # Test for no_input_provided
    assert load('./', './') == {}
    # Test for no_input_provided
    assert load('./', './') == {}
    # Test for no_input_provided
    assert load('./', './') == {}
    # Test for no_input_provided
    assert load('./', './') == {}
    # Test for no_input_provided
    assert load('./', './') == {}



# Generated at 2022-06-25 15:37:39.895478
# Unit test for function dump
def test_dump():
    template_name = './'
    replay_dir = './'
    context = './'
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:37:45.386091
# Unit test for function load
def test_load():
    try:
        assert callable(load)
    except:
        print('Function "load" is not callable.')
        raise
    try:
        test_case_0()
    except:
        print('Failed test case 0')
        raise


# Generated at 2022-06-25 15:37:51.468321
# Unit test for function load
def test_load():
    replay_dir = './'
    template_name = './'
    context = load(replay_dir, template_name)


# Generated at 2022-06-25 15:37:55.455212
# Unit test for function dump
def test_dump():
    file_name = "abc.json"
    context = {
        "cookiecutter": {
            "name": "Django REST framework",
            "example": "Y",
            "repo_name": "django-rest-framework",
        }
    }
    dump("./", file_name, context)
    # Remove sample file
    os.remove(file_name)

test_case_0()

# Generated at 2022-06-25 15:37:58.040181
# Unit test for function load
def test_load():
    str_0 = './'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:38:00.368164
# Unit test for function load
def test_load():
    assert load("/home/bhavani/workspace/python/cookiecutter-pypackage-minimal/tests/test_replay/empty", "empty") is None

# Generated at 2022-06-25 15:38:01.265435
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:38:03.507918
# Unit test for function dump
def test_dump():
    replay_dir = './'
    template_name = './'
    context = {}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:38:26.683371
# Unit test for function load
def test_load():
    f0 = './'
    c0 = {'cookiecutter': {}}
    dump(f0, f0, c0)
    c1 = load(f0, f0)
    assert c0 == c1

test_load()

# Generated at 2022-06-25 15:38:29.462507
# Unit test for function load
def test_load():
    str_0 = './'
    var_0 = load(str_0, str_0)

    # Test var_0 has the expected type.
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 15:38:31.160514
# Unit test for function load
def test_load():
    assert load('./', './') == {'cookiecutter': {}}

# Generated at 2022-06-25 15:38:32.673127
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:38:34.866979
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except (TypeError, ValueError, IOError) as err:
        print(str(err))


# Generated at 2022-06-25 15:38:36.323900
# Unit test for function load
def test_load():
    str_0 = './'
    str_1 = './'
    var_0 = load(str_0, str_1)

# Generated at 2022-06-25 15:38:38.364437
# Unit test for function load
def test_load():
    str_0 = './'
    var_0 = load(str_0, str_0)
    assert(type(var_0)==dict)


# Generated at 2022-06-25 15:38:41.668789
# Unit test for function load
def test_load():
    assert load('./', './') is not None


# Generated at 2022-06-25 15:38:44.573468
# Unit test for function load
def test_load():
    assert callable(load)
    try:
        load(None, None)
    except TypeError:
        pass
    try:
        load(None, None)
    except ValueError:
        pass


# Generated at 2022-06-25 15:38:50.491293
# Unit test for function dump
def test_dump():
    str_0 = './'
    var_0 = ''
    dict_1 = {'cookiecutter': {}}
    obj_0 = dump(str_0, var_0, dict_1)
    print(obj_0)


# Generated at 2022-06-25 15:39:32.809253
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:39:34.629509
# Unit test for function load
def test_load():
    test_case_0()
    print('\n' + 'All tests passed')


# Generated at 2022-06-25 15:39:36.662252
# Unit test for function load
def test_load():
    global replay_dir
    global template_name
    test_case_0()


# Generated at 2022-06-25 15:39:39.502622
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 15:39:40.747426
# Unit test for function load
def test_load():
    # Set up mock for input 'context'
    
    # Call function load
    #assert(isinstance(result, dict))
    test_case_0()

# Generated at 2022-06-25 15:39:46.932679
# Unit test for function load
def test_load():
    print('Invoking function test_load')
    str_0 = './'
    str_1 = './'
    var_0 = load(str_0, str_1)
    var_1 = 'test'
    if var_0 == var_1:
        print('Success')
    else:
        print('Failed')

if __name__ == '__main__':
    test_case_0()
    test_load()

# Generated at 2022-06-25 15:39:55.236006
# Unit test for function dump
def test_dump():
    str_0 = './'
    str_1 = 'dict_0'
    dict_2 = {
        'cookiecutter': {
            'first_name': 'Sherlock',
            'last_name': 'Holmes',
            'full_name': 'Sherlock Holmes',
            'email': 'sherlock@holmes.co.uk',
            'project_name': 'Cookiecutter Awesome Project',
            'project_short_description': 'An awesome project',
            'pypi_username': 'sholmes',
            'repo_name': 'cookiecutter-awesome-project',
            'select_license': 'MIT license',
            'year': '2017',
        }
    }
    dump(str_0, str_1, dict_2)


# Generated at 2022-06-25 15:39:56.248142
# Unit test for function dump
def test_dump():
    pass



# Generated at 2022-06-25 15:40:03.027164
# Unit test for function load
def test_load():
    # Init test case data
    var_1 = 'test_file_1.json'
    var_2 = {'test': 1}

    # Call function
    test_case_0()

    # Assert
    assert isinstance(var_0, dict)

    # Call function
    dump(str_0, var_1, var_2)
    var_3 = load(str_0, var_1)

    # Assert
    assert var_2 == var_3

# Generated at 2022-06-25 15:40:11.593778
# Unit test for function load
def test_load():
    str_0 = './'
    assert not load(str_0, str_0)
    str_0 = './'
    str_1 = './'
    assert not load(str_0, str_1)
    str_0 = './'
    assert not load(str_0, str_0)
    str_0 = './'
    str_1 = './'
    assert not load(str_0, str_1)


# Generated at 2022-06-25 15:41:51.325098
# Unit test for function dump
def test_dump():
    """Generated test for function dump"""
    
    # Test 0: str_0
    str_0 = './'
    str_1 = './'
    dict_0 = {u'cookiecutter': {u'last_used_dir': u'', u'full_name': u'', u'email': u'', u'project_name': u'', u'project_slug': u'', u'project_dir': u'', u'_copy_without_render': []}}
    dump(str_0, str_1, dict_0)


# Generated at 2022-06-25 15:41:52.320330
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:41:54.614674
# Unit test for function load
def test_load():
    str_0 = './'
    var_0 = load(str_0, str_0)
    assert var_0 is not None


# Generated at 2022-06-25 15:41:58.750851
# Unit test for function load
def test_load():
    test_case_0()

# Generated at 2022-06-25 15:42:03.498977
# Unit test for function load
def test_load():
    str_0 = './'
    var_0 = load(str_0, str_0)
    
    # Test var_0
    assert isinstance(var_0, dict)
    
    # Test var_0 and key cookiecutter
    assert 'cookiecutter' in var_0


# Generated at 2022-06-25 15:42:07.018833
# Unit test for function dump
def test_dump():
    str_0 = 'test_value'
    str_1 = 'test_value'
    var_0 = dump(str_0, str_1, {'cookiecutter': 'test_value'})


# Generated at 2022-06-25 15:42:11.491427
# Unit test for function load
def test_load():
    print('Testing function load')
    try:
        test_case_0()
        test_passed()
    except Exception as e:
        test_failed(e)


# Generated at 2022-06-25 15:42:13.125083
# Unit test for function load
def test_load():
    replay_dir = './'
    template_name = './'

    load(replay_dir, template_name)

# Generated at 2022-06-25 15:42:14.742202
# Unit test for function load
def test_load():
    rpath = '/replay/test'
    str_0 = './test_json'
    assert load(rpath, str_0)['cookiecutter']['abcd'] == 'test'


# Generated at 2022-06-25 15:42:17.012968
# Unit test for function load
def test_load():
    """Test for function load"""
    assert load("./", "./") == {'cookiecutter': {}}, "Expected another value for the output"