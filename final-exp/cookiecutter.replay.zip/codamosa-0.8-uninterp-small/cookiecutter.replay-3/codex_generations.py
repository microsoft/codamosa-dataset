

# Generated at 2022-06-25 15:33:00.301042
# Unit test for function load
def test_load():
    assert test_case_0() == None

# Generated at 2022-06-25 15:33:04.796071
# Unit test for function get_file_name
def test_get_file_name():
    float_0 = 9637.74
    str_0 = '--no-input'
    float_1 = load(float_0, str_0)


# Generated at 2022-06-25 15:33:09.573884
# Unit test for function load
def test_load():
    float_0 = 4615.3
    str_0 = '--no-input'
    data_0 = load(float_0, str_0)


# Generated at 2022-06-25 15:33:14.546446
# Unit test for function load
def test_load():
    str_0 = 'lzgTrzz'
    float_0 = 2873.0
    var_0 = load(str_0, float_0)
    assert 'cookiecutter' in var_0


# Generated at 2022-06-25 15:33:19.932080
# Unit test for function load
def test_load():
    float_0 = 5340.0
    str_0 = '--no-input'
    var_0 = load(float_0, str_0)
    var_1 = load(float_0, str_0)
    var_2 = load(float_0, str_0)
    if (var_1 >= var_0):
        var_0 = float_0 + float_0
    else:
        var_0 = float_0 / var_2
    assert var_2 == 4493.0
    assert var_1 == 4062.0


# Generated at 2022-06-25 15:33:23.179372
# Unit test for function get_file_name
def test_get_file_name():
    """Test function get_file_name"""
    assert get_file_name(2393.5, '--no-input') == '--no-input.json'


# Generated at 2022-06-25 15:33:26.904640
# Unit test for function load
def test_load():
    print('\n\n==== function "load" ====')
    str_0 = '--no-input'
    float_0 = 2285.9
    var_0 = load(float_0, str_0)
    assert isinstance(var_0, dict)
    print('Test case 0: Passed!')


# Generated at 2022-06-25 15:33:37.066234
# Unit test for function dump
def test_dump():
    # Setup test variables
    replay_dir = 'example/generate-a-new-project'
    template_name = 'cookiecutter-pypackage'
    context = {'cookiecutter': {'project_name': 'Example', 'project_slug': 'example', 'author_name': 'Audrey Roy Greenfeld', 'email': 'audreyr@example.com', 'description': 'A short description of the project.', 'domain_name': 'example.com', 'version': '0.1.0', 'timezone': 'UTC', 'year': '2014', 'pypi_username': 'audreyr', 'open_source_license': 'BSD license'}}

    # Run test
    dump(replay_dir, template_name, context)
    
    # Get output

# Generated at 2022-06-25 15:33:41.655569
# Unit test for function load
def test_load():
    float_0 = 2285.9
    str_0 = '--no-input'
    var_0 = load(float_0, str_0)
    replay_dir = '/home/amirouche/src/github.com/'
    str_1 = '--no-input'
    var_1 = load(replay_dir, str_1)
    assert var_0 is var_1


# Generated at 2022-06-25 15:33:50.472915
# Unit test for function dump
def test_dump():
    float_0 = 148.34
    str_0 = '--no-input'
    dict_0 = {
        'cookiecutter':
            {
                'project_name': '{{cookiecutter.repo_name + "_project" }}',
                'repo_name':
                    'cookiecutter-project-template-empty-with-tests',
                'owner_name': 'jacebrowning',
                'description': 'A project template for Cookiecutter',
                'project_slug': '{{cookiecutter.repo_name + "_project" | lower }}',
                'author_name': 'Jace Browning',
                'email': 'jacebrowning@gmail.com',
                'year': 2016,
                'release': '0.0.1',
            }
    }

# Generated at 2022-06-25 15:33:56.325791
# Unit test for function load
def test_load():
    var_0 = None
    var_1 = None
    try:
        load(var_0, var_1)
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-25 15:34:05.665505
# Unit test for function load
def test_load():
    dict_0 = None
    dict_1 = None
    dict_2 = None
    dict_3 = None
    dict_4 = None
    dict_5 = None
    dict_6 = None
    dict_7 = None
    dict_8 = None
    dict_9 = None
    dict_10 = None
    dict_11 = None
    dict_12 = None
    dict_13 = None
    dict_14 = None
    dict_15 = None
    dict_16 = None
    dict_17 = None
    dict_18 = None
    dict_19 = None
    dict_20 = None
    dict_21 = None
    dict_22 = None
    dict_23 = None
    dict_24 = None
    dict_25 = None
    dict_26 = None
    dict_27 = None
    dict_

# Generated at 2022-06-25 15:34:06.982489
# Unit test for function load
def test_load():
    replay_dir = ""
    template_name = ""
    result = load(replay_dir, template_name)
    assert result == None


# Generated at 2022-06-25 15:34:10.144968
# Unit test for function load
def test_load():

    # Test for variable type None
    test_case_0()


# Generated at 2022-06-25 15:34:16.313910
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except TypeError as e:
        if str(e) == 'Template name is required to be of type str':
            print("Success")
        else:
            print("Failure")
    except ValueError as e:
        if str(e) == 'Context is required to contain a cookiecutter key':
            print("Success")
        else:
            print("Failure")


# Generated at 2022-06-25 15:34:23.974294
# Unit test for function load
def test_load():
    # No exception for empty input
    test_dict1 = {'cookiecutter': {}}
    file_name = 'replay_1.json'

# Generated at 2022-06-25 15:34:33.410189
# Unit test for function load
def test_load():
    # Source:
    replay_dir = 'tests/files/replay/'
    template_name = 'foobar'

    # Expected outcome:
    var_0 = {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'Cookiecutter-Pypackage',
            'project_slug': 'cookiecutter-pypackage',
            'repo_name': 'cookiecutter-pypackage'
        }
    }

    # Call function
    var_1 = load(replay_dir, template_name)

    # Compare results

# Generated at 2022-06-25 15:34:34.256564
# Unit test for function load
def test_load():
    pass


# Generated at 2022-06-25 15:34:35.234340
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:34:40.893663
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "."
    template_name = 'simple_1'
    assert get_file_name(replay_dir, template_name) == './simple_1.json'
    template_name = 'simple_2.json'
    assert get_file_name(replay_dir, template_name) == './simple_2.json'


# Generated at 2022-06-25 15:34:48.964204
# Unit test for function dump
def test_dump():
    """Test proper arguments."""
    replay_dir = 'test_replay'
    template_name = 'test_template'
    context = {'cookiecutter': {'key1': 'value1', 'key2': 'value2'}}

    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)

    assert context_loaded == context

    if os.path.exists(replay_dir):
        os.rmdir(replay_dir)



# Generated at 2022-06-25 15:34:52.317362
# Unit test for function load
def test_load():
    replay_dir = '~/dev/cookiecutter_test'
    template_name = 'cookicutter_test'
    context = {}
    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)
    assert context_loaded == context


# Generated at 2022-06-25 15:34:59.900357
# Unit test for function load
def test_load():
    # test case for function load
    input_0 = 'replay_dir'
    input_1 = 'template_name'
    expected_result = (('key1', 'value1'),)

    # we do not need to test for this
    result = load(input_0, input_1)
    assert result == expected_result

    # test case for function load
    input_0 = 'replay_dir'
    input_1 = 'template_name'
    expected_result = (('key1', 'value1'),)

    result = load(input_0, input_1)
    assert result == expected_result


# Generated at 2022-06-25 15:35:09.913164
# Unit test for function load
def test_load():
    print('\nload')

    print('\n# Test case 0:')
    try:
        test_case_0()
        # print('\tExpected:')
        # print('\tActual:')
    except:
        print('\tExpected: load(dict_0, dict_0)\n\tActual: raise')



# Generated at 2022-06-25 15:35:17.043572
# Unit test for function load
def test_load():
    dict_0 = "2012-11-14T13:12:47-03:00"
    dict_1 = "2012-11-14T13:12:47-03:00"
    dict_2 = "2012-11-14T13:12:47-03:00"
    dict_3 = "2012-11-14T13:12:47-03:00"
    dict_4 = "2012-11-14T13:12:47-03:00"
    dict_5 = "2012-11-14T13:12:47-03:00"
    dict_6 = "2012-11-14T13:12:47-03:00"
    dict_7 = "2012-11-14T13:12:47-03:00"

# Generated at 2022-06-25 15:35:27.694856
# Unit test for function load
def test_load():
    template_name = "a"
    replay_dir = "b"

# Generated at 2022-06-25 15:35:34.477489
# Unit test for function load
def test_load():
    dict_0 = None
    dict_1 = "OyEe.Tp$1J"
    var_0 = get_file_name(dict_0, dict_1)
    var_1 = get_file_name(dict_1, dict_0)
    dict_2 = "VuX-Jy1x+u"
    dict_3 = "5{0hMrK~fx"
    dict_4 = {0: dict_0, 1: dict_1, 2: dict_2, 3: dict_3}
    dict_5 = {0: dict_2, 1: dict_3, 2: dict_4, 3: dict_0}
    dict_6 = {0: dict_4, 1: dict_3, 2: dict_1, 3: dict_5}

# Generated at 2022-06-25 15:35:36.148827
# Unit test for function dump
def test_dump():
    assert dump(0,0,0) == None


# Generated at 2022-06-25 15:35:42.339977
# Unit test for function load
def test_load():
    # Case 0
    dict_0 = None
    var_0 = load(dict_0, dict_0)
    assert var_0 is None

    # Case 1
    dict_1 = [None, None, None, None, None]
    var_1 = load(dict_1, dict_1)
    assert var_1 is None

    # Case 2
    dict_2 = [{}, {}, {}, {}, {}]
    var_2 = load(dict_2, dict_2)
    assert var_2 is None


# Generated at 2022-06-25 15:35:52.508723
# Unit test for function dump
def test_dump():
    from cookiecutter import replay
    from cookiecutter.utils import make_sure_path_exists
    import sys

    if sys.version_info[0] == 2:
        import imp
        imp.reload(replay)

    replay_dir = '/tmp/cookiecutter-replay'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-25 15:35:58.962746
# Unit test for function load
def test_load():

    context = load("C:\\Users\\admin\\Desktop\\cookiecutter-pypackage", "C:\\Users\\admin\\Desktop\\cookiecutter-pypackage\\cookiecutter.json")
    assert ('cookiecutter' in context)
    return



# Generated at 2022-06-25 15:36:03.397888
# Unit test for function load
def test_load():
    # Test case #0
    try:
        test_case_0()
    except ValueError as e:
        assert type(e) == ValueError
    except:
        assert False


# Generated at 2022-06-25 15:36:08.537755
# Unit test for function dump
def test_dump():
    assert callable(dump)
    # A TypeError/IOError is expected
    with pytest.raises(TypeError):
        dump(None, None, None)
    # A TypeError/IOError is expected
    with pytest.raises(TypeError):
        dump(None, None, None)
    # A ValueError is expected
    with pytest.raises(ValueError):
        dump(None, None, None)


# Generated at 2022-06-25 15:36:16.865646
# Unit test for function load
def test_load():
    print('Test load')

    replay_dir = 'tests/replay'
    template_name = 'example-repo'
    context = load(replay_dir, template_name)

    # Assert the return value of function load

# Generated at 2022-06-25 15:36:20.933982
# Unit test for function load
def test_load():
    dict_0 = {"cookiecutter": {"author": "Vitor Freitas", "project_name": "Cookiecutter", "project_short_description": "A command-line utility that creates projects from project templates, e.g. creating a Python package project from a Python package project template.", "github_username": "vitorfs"}}
    var_0 = load("replay", "cookiecutter-pypackage")
    assert var_0 == dict_0


# Generated at 2022-06-25 15:36:26.140118
# Unit test for function load
def test_load():
    template_path = "/Users/jakob/Desktop/Code/git/cookie-cutter-test/"
    replay_dir = os.path.join(template_path, ".cookiecutters")
    template_name = "cookiecutter-test"
    context = load(replay_dir, template_name)
    print(context, '\n')


# Generated at 2022-06-25 15:36:36.071999
# Unit test for function load
def test_load():
    dict_0 = "nPlwCvYuxY"
    dict_1 = "ezp7Nm5Aj8"
    dict_2 = "5wtoGgYAX0"
    dict_3 = "JcOqJNdEN7"
    dict_4 = "JcOqJNdEN7"

    # Call function load
    var_0 = load(dict_0, dict_0)
    var_1 = load(dict_1, dict_1)
    var_2 = load(dict_2, dict_2)
    var_3 = load(dict_3, dict_3)
    var_4 = load(dict_4, dict_4)

    # Assertions
    dict_0 = None
    assert var_0 == dict_0
    assert var_1 == dict

# Generated at 2022-06-25 15:36:38.943101
# Unit test for function load
def test_load():
    assert load('replay_dir', 'template_name') == json.load(open(get_file_name('replay_dir', 'template_name'), 'r'))


# Generated at 2022-06-25 15:36:47.060807
# Unit test for function load
def test_load(): 
    replay_dir = "cookiecutter" 
    template_name = "cookiecutter" 
    context = {"cookiecutter": {"full_name": "me", "email": "me@me.com"}, "project": {"name": "foo", "description": "bar"}} 
    expected_result = {"cookiecutter": {"full_name": "me", "email": "me@me.com"}, "project": {"name": "foo", "description": "bar"}} 
    result = load(replay_dir, template_name) 
    assert result == expected_result 


# Generated at 2022-06-25 15:36:52.568657
# Unit test for function dump
def test_dump():
    replay_dir = None
    template_name = None
    context = None
    assert dump(replay_dir, template_name, context) == None


# Generated at 2022-06-25 15:37:03.055168
# Unit test for function load
def test_load():
    dict_0 = 'cookiecutter.json'
    dict_1 = 'cookiecutter.json'
    dict_2 = ''
    dict_3 = 'cookiecutter.yml'
    dict_4 = 'cookiecutter.json'
    dict_5 = {'cookiecutter' : {'project_name' : 'Test', 'repo_name' : 'test2'}}
    dict_6 = {'cookiecutter' : {'project_name' : 'Test', 'repo_name' : 'test2'}}
    dict_7 = 'cookiecutter.json'
    dict_8 = 'cookiecutter.json'
    dict_9 = {'cookiecutter' : {'projet_name' : 'Test', 'repo_name' : 'test2'}}

# Generated at 2022-06-25 15:37:06.335067
# Unit test for function load
def test_load():
    eval_0 = get_file_name(None, None)
    test_case_0(eval_0, eval_0)

# Generated at 2022-06-25 15:37:16.129176
# Unit test for function load
def test_load():
    tpl_0 = 'file_0'
    ctx_0 = {'cookiecutter': {'project_name': 'Test Project for Cookiecutter'}}
    try:
        dump('.', tpl_0, ctx_0)
        ctx_1 = load('.', tpl_0)
        assert ctx_0 == ctx_1
    except:
        print('Exception during testing of load')
        raise
    finally:
        os.remove(tpl_0 + '.json')

# Generated at 2022-06-25 15:37:23.062752
# Unit test for function load
def test_load():
    print("test_load")

    replay_dir = 'home/.cookiecutters'
    template_name = 'template_name'
    context = {'cookiecutter': {'foo': 'bar'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(get_file_name(replay_dir, template_name))

    # test_case_0()



# Generated at 2022-06-25 15:37:31.429874
# Unit test for function dump
def test_dump():
    # Tests with different parameter values.
    # Pass in an absolute directory name.
    # Ensures the path exists.
    # Ensures the path exists.
    # Pass in a relative directory name.
    # Ensures the path exists.
    replay_dir = '.cookiecutter_replay'
    template_name = 'pypackage'
    context = {'cookiecutter': {'_copy_without_render': ['LICENSE', '*.sh']}}
    dump(replay_dir, template_name, context)
    if os.path.isfile('.cookiecutter_replay/pypackage.json'):
        pass
    else:
        raise Exception('Failed to write replay file')



# Generated at 2022-06-25 15:37:41.352901
# Unit test for function load
def test_load():
    assert callable(load)
    context = dict()
    context['cookiecutter'] = dict()
    context['cookiecutter']['full_name'] = 'Test Name'
    context['cookiecutter']['email'] = 'test@email.com'
    context['cookiecutter']['project_name'] = 'Test Project'
    context['project_name'] = 'test-project'

    replay_dir = 'tests/files/replay'

    dump(replay_dir, 'test_context', context)
    r = load(replay_dir, 'test_context')

    assert r['cookiecutter']['full_name'] == "Test Name"
    assert r['cookiecutter']['email'] == "test@email.com"

# Generated at 2022-06-25 15:37:44.446001
# Unit test for function load
def test_load():
    dict_0 = None
    var_0 = load(dict_0, dict_0)


# Generated at 2022-06-25 15:37:48.197936
# Unit test for function load
def test_load():
    replay_dir = "/Users/ppodgor/PycharmProjects/cookiecutter-ws-sdk/{{cookiecutter.sdk_type}}/{{cookiecutter.application_name}}"
    template_name = "{{cookiecutter.application_name}}"
    assert load(replay_dir, template_name)


# Generated at 2022-06-25 15:37:53.522650
# Unit test for function load
def test_load():
    replay_dir = 'test_files/replay'
    template_name = 'test_template'
    context = load(replay_dir, template_name)
    assert context['_template'] == 'test_repo/'
    assert context['cookiecutter'] == {'_template': 'test_repo/'}



# Generated at 2022-06-25 15:37:54.848956
# Unit test for function load
def test_load():
    dict_0 = None
    var_0 = load(dict_0, dict_0)


# Generated at 2022-06-25 15:38:06.668436
# Unit test for function dump
def test_dump():
    template_name = 'cookiecutter-pypackage'
    context = {"cookiecutter": {
                    "full_name": "Audrey Roy Greenfeld",
                    "_copy_without_render": ["azure-pipelines.yml", "tox.ini"],
                    "project_name": "cookiecutter-pypackage",
                    "description": "A Python package project template.",
                    "email": "audreyr@example.com",
                    "year": "2019",
                    "repo_name": "cookiecutter-pypackage",
                    "command_line_interface": "Click",
                    "open_source_license": "MIT license",
                    "version": "0.1.0",
                    "pypi_username": "audreyr"
                }}
    replay_dir = os.path.join

# Generated at 2022-06-25 15:38:08.914191
# Unit test for function load
def test_load():
    print("Unit test for function load")
    test_case_0()

if __name__ == '__main__':
    # test_load()
    pass

# Generated at 2022-06-25 15:38:11.313436
# Unit test for function load
def test_load():
    assert 1

# Generated at 2022-06-25 15:38:15.743418
# Unit test for function dump
def test_dump():
    kwargs = None
    # Error handling case
    with pytest.raises(TypeError) as err:
        try:
            dump(**kwargs)
        except TypeError:
            print("Caught TypeError exception")
        else:
            print("Failed to catch TypeError exception")
        finally:
            pytest.fail("Failed to catch TypeError exception")


# Generated at 2022-06-25 15:38:26.180600
# Unit test for function load
def test_load():
    dict_0 = None
    dict_1 = None
    dict_2 = None
    dict_3 = None
    dict_4 = None
    dict_5 = None
    dict_6 = None
    dict_7 = None
    dict_8 = None
    dict_9 = None
    dict_10 = None
    dict_11 = None
    dict_12 = None
    dict_13 = None
    dict_14 = None
    dict_15 = None
    dict_16 = None
    dict_17 = None
    dict_18 = None
    dict_19 = None
    dict_20 = None
    dict_21 = None
    dict_22 = None
    dict_23 = None
    dict_24 = None
    dict_25 = None
    dict_26 = None
    dict_27 = None
    dict_

# Generated at 2022-06-25 15:38:30.638786
# Unit test for function load
def test_load():
    template = "python-simple-app"
    replay_dir = "replay"
    context = {"cookiecutter": {"repo_slug": "szelectric/my-first-cookicutter"}}
        
    dump(replay_dir, template, context)

    context_in = load(replay_dir, template)

    assert context == context_in

# Generated at 2022-06-25 15:38:34.026362
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except TypeError as e:
        assert 'Template name is required to be of type str' in str(e)
    else:
        assert False



# Generated at 2022-06-25 15:38:36.980506
# Unit test for function load
def test_load():
    context = load('/Users/taylor/gitwork/cookiecutter-pypackage', 'taylor-pypackagetest')
    assert context['_template'] == "taylor-pypackagetest"
    assert context['cookiecutter'] == {}


# Generated at 2022-06-25 15:38:39.035858
# Unit test for function dump
def test_dump():
    replay_dir = None
    template_name = None
    context = None
    result = dump(replay_dir, template_name, context)
    assert result == None



# Generated at 2022-06-25 15:38:50.003703
# Unit test for function load
def test_load():
    path = os.path.abspath(os.path.dirname(__file__))
    replay_dir = os.path.join(path, 'data')
    template_name = 'cookiecutter-pypackage'
    context = {
        'cookiecutter': {
            '_template': 'cookiecutter-pypackage',
            'author_email': 'mike@example.org',
            'author_name': 'Michael Jones',
            'description': 'A PyPI ready Python project template',
            'open_source_license': 'MIT license',
            'project_name': 'My cookiecutter pypackage',
            'repo_name': 'cookiecutter-pypackage',
            'version': '0.1.0',
            'year': '2014'
        }
    }



# Generated at 2022-06-25 15:39:08.983509
# Unit test for function dump
def test_dump():
    # Dump dictionary containing a Cookiecutter key
    template_name = "data/{{cookiecutter.repo_name}}"
    context = {'cookiecutter': {'repo_name': 'Test Project'}}
    replay_dir = 'replay'

    # Write the dictionary to a new file
    dump(replay_dir, template_name, context)

    # Verify JSON file matches dictionary
    file_name = get_file_name(replay_dir, template_name)
    with open(file_name, 'r') as f:
        assert f.read() == str(context)

    # Check for ValueError when dictionary does not contain Cookiecutter key
    new_context = {'dict_key': 'dict_value'}

# Generated at 2022-06-25 15:39:11.649703
# Unit test for function load
def test_load():
    assert True == os.path.exists('tests/files/replay')
    assert 'cookiecutter' in load('tests/files/replay', 'tests/files/replay/cookiecutter.json')


# Generated at 2022-06-25 15:39:20.457293
# Unit test for function load
def test_load():
    # Pass a non-existent directory.
    dict_0 = "dshjh"
    load(dict_0, dict_0)

    # Pass the path of the directory

# Generated at 2022-06-25 15:39:22.468079
# Unit test for function load
def test_load():
    # Test case 0
    dict_0 = None
    var_0 = load(dict_0, dict_0)
    assert var_0 is None


# Generated at 2022-06-25 15:39:30.905387
# Unit test for function load
def test_load():
    template_name = 'bio-project'
    replay_dir = 'replay_dir'
    context = {'cookiecutter': {'author_email': 'contact@rhnvrm.in'}}
    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)
    assert context == context_loaded


test_case_1 = {
    'dict_0': None,
    'dict_1': None,
}
test_case_1['dict_0'] = test_load()
test_case_0()


# Generated at 2022-06-25 15:39:32.354268
# Unit test for function load
def test_load():
    try:
        raise NameError
    except:
        assert True


# Generated at 2022-06-25 15:39:39.426173
# Unit test for function load
def test_load():
    dict_0 = None
    dict_1 = {}
    dict_2 = None
    dict_3 = None
    dict_4 = {}
    dict_5 = {}
    dict_5['cookiecutter'] = dict()
    dict_6 = {}
    dict_7 = {'cookiecutter': dict()}
    dict_8 = {}
    dict_8['cookiecutter'] = dict()
    dict_9 = None
    dict_10 = {}
    dict_10['cookiecutter'] = dict()

    # Call the function
    var_0 = load(dict_0, dict_0)



# Generated at 2022-06-25 15:39:49.113750
# Unit test for function load
def test_load():
    template_name = 'test_data/test'
    replay_dir = 'test_data/replay'

    def test_empty_file():
        replay_file = get_file_name(replay_dir, template_name)
        with open(replay_file, 'w') as outfile:
            outfile.write('')
        try:
            load(replay_dir, template_name)
        except json.decoder.JSONDecodeError:
            return
        assert False, 'Expected JSONDecodeError'

    def test_no_cookiecutter_key():
        replay_file = get_file_name(replay_dir, template_name)
        with open(replay_file, 'w') as outfile:
            json.dump({}, outfile, indent=2)

# Generated at 2022-06-25 15:39:49.933255
# Unit test for function dump
def test_dump():
  test_case_0()


# Generated at 2022-06-25 15:39:55.728495
# Unit test for function load
def test_load():
    replay_dir = './tests/replay_dir/'
    template_name = 'template_name'
    context = {'cookiecutter': {'project_name': 'Hello World!'}}

# Generated at 2022-06-25 15:40:19.609381
# Unit test for function dump
def test_dump():
    replay_dir = ''
    template_name = ''
    context = ''
    try:
        dump(replay_dir, template_name, context)
    except Exception as e:
        pass


# Generated at 2022-06-25 15:40:22.655030
# Unit test for function load
def test_load():
    try:
        assert os.path.exists('replay') == True
        assert os.path.exists('tests') == True
    except AssertionError as e:
        print(e)
        print('test failed')


# Generated at 2022-06-25 15:40:31.003628
# Unit test for function load
def test_load():
    # Test for {'cookiecutter': {'_template': 'project_name'}} with template_name 'project_name'
    dict_0 = {'_template': 'project_name'} 
    replay_dir_0 = 'replay'
    template_name_0 = 'project_name'
    var_0 = load(replay_dir_0, template_name_0)
    assert (var_0 == {'cookiecutter': dict_0})
    # Test for {'cookiecutter': {'_template': 'project_name'}} with template_name 'project_name'
    dict_0 = {'_template': 'project_name'} 
    replay_dir_1 = 'replay'
    template_name_1 = 'project_name'

# Generated at 2022-06-25 15:40:33.285439
# Unit test for function load
def test_load():
    # Test for function load
    test_case_0()


# Generated at 2022-06-25 15:40:37.915560
# Unit test for function dump
def test_dump():
    context = {
        'cookiecutter': {
            'project_name': 'pyname',
            'project_slug': 'pyslug',
            'py_module': 'pymodule',
            'release_date': '01/01/1970',
        }
    }
    dump('replays', 'pyname', context)
    #print(load('replays', 'pyname'))


# Generated at 2022-06-25 15:40:48.053554
# Unit test for function dump
def test_dump():
    value_0 = 'cookiecutter'
    value_1 = -0.0872
    value_2 = value_0
    value_3 = 'cookiecutter'
    value_4 = 'cookiecutter'
    value_5 = 'cookiecutter'
    value_6 = 'cookiecutter'
    value_7 = 'cookiecutter'
    value_8 = -0.0872
    value_9 = 'cookiecutter'
    value_10 = 'cookiecutter'
    value_11 = 'cookiecutter'
    value_12 = 'cookiecutter'
    value_13 = 'cookiecutter'
    value_14 = -0.0872
    value_15 = 'cookiecutter'
    value_16 = 'cookiecutter'
    value_17 = 'cookiecutter'
    value_

# Generated at 2022-06-25 15:40:50.150880
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:40:54.853888
# Unit test for function load
def test_load():
    replay_dir = 'dir'
    template_name = 'str'
    load(replay_dir, template_name)


# Generated at 2022-06-25 15:40:56.725818
# Unit test for function load
def test_load():
	dict_0 = { 'cookiecutter': { 'name': "foo" } }
	assert load("", "bar.json") == dict_0

# Generated at 2022-06-25 15:40:57.324502
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:41:49.995613
# Unit test for function dump
def test_dump():
    str_0 = 'test_template'
    dict_0 = {
        'cookiecutter': {
            'foo': 'bar'
        }
    }
    dump(str_0, str_0, dict_0)


# Generated at 2022-06-25 15:41:56.524514
# Unit test for function dump
def test_dump():
    str_0 = 'test_template'

    dict_0 = dict(cookiecutter=dict(
        full_name='Alex Gaynor',
        email='alex.gaynor@gmail.com',
        github_username='alex',
        project_name=str_0,
        repo_name=str_0,
        project_short_description='A short description of the project.',
        pypi_username='alex',
        year=2012
    ))

    dump(str_0, str_0, dict_0)


# Generated at 2022-06-25 15:41:58.767987
# Unit test for function load
def test_load():
    str_0 = 'test_template'
    var_0 = load(str_0, str_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 15:42:07.088942
# Unit test for function load
def test_load():
    # Testing with a clone of Cookiecutter-Pylibrary
    str_0 = 'test_template'
    str_1 = 'cookiecutter test_template/'
    var_0 = load(str_1, str_0)
    str_2 = '_'
    var_1 = var_0['cookiecutter'][str_2]
    str_3 = 'project_name'
    var_2 = var_1[str_3]
    assert(var_2 == 'Project Name')
    str_4 = 'author_name'
    var_3 = var_1[str_4]
    assert(var_3 == 'Your Name')
    str_5 = 'email'
    var_4 = var_1[str_5]
    assert(var_4 == 'you@example.com')
    str

# Generated at 2022-06-25 15:42:15.765765
# Unit test for function load
def test_load():
    state = {
        'cookiecutter': {
            'project_name': 'Cookiecutter with Multi-line Strings',
            'repo_name': 'cookiecutter-pypackage-mls',
        }
    }

    with open('exit_code.json', 'w') as f:
        f.write(str(state))

    # Load state
    state = load('exit_code.json')
    state.get('repo_name') == 'cookiecutter-pypackage-mls'



# Generated at 2022-06-25 15:42:21.790355
# Unit test for function load
def test_load():
    str_0 = 'test_template'
    var_0 = load(str_0, str_0)
    assert isinstance(var_0, dict)
    assert var_0 == {'cookiecutter': {'first_name': 'James', 'last_name': 'Bond', 'project_name': 'Secret Agent'}}


# Generated at 2022-06-25 15:42:24.248878
# Unit test for function load
def test_load():
    str_0 = 'test_template'
    var_0 = load(str_0, str_0)
	

# Generated at 2022-06-25 15:42:24.868782
# Unit test for function dump
def test_dump():
    assert callable(dump)


# Generated at 2022-06-25 15:42:28.300481
# Unit test for function load
def test_load():
    str_0 = 'test_template'
    var_0 = load(str_0, str_0)
    str_1 = 'cookiecutter'
    str_2 = 'cookiecutter'
    assert (str_1 in var_0)
    assert (var_0[str_2] == 'string')

# Generated at 2022-06-25 15:42:33.139992
# Unit test for function load
def test_load():
    try:
        str_0 = 'test_template'
        var_0 = load(str_0, str_0)
    except ValueError as error_0:
        print('Exception: ', error_0)

try:
    test_case_0()
except ValueError as error_0:
    print('Exception: ', error_0)

try:
    test_load()
except ValueError as error_0:
    print('Exception: ', error_0)