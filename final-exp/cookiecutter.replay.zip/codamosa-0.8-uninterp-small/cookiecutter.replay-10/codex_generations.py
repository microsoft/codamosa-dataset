

# Generated at 2022-06-25 15:33:01.540156
# Unit test for function get_file_name
def test_get_file_name():
    assert os.path.join('test_0', 'test_1.json') == \
        get_file_name('test_0', 'test_1')
    assert os.path.join('test_1', 'test_2.json') == \
        get_file_name('test_1', 'test_2.json')
    assert os.path.join('', 'test_3') == \
        get_file_name('', 'test_3')
    assert os.path.join('', 'test_4.json') == \
        get_file_name('', 'test_4.json')
      

# Generated at 2022-06-25 15:33:07.942600
# Unit test for function load
def test_load():
    str_0 = 'dc@'
    str_1 = '7pPj'
    dict_0 = {}
    dict_0.update({str_0: str_1})
    dict_0 = {str_1: dict_0}
    var_0 = load(str_0, str_0)
    assert var_0 == dict_0


# Generated at 2022-06-25 15:33:12.006988
# Unit test for function load
def test_load():
    str_0 = 'template_cookiecutter_0'
    dict_0 = load(str_0, str_0)
    print(dict_0)


# Generated at 2022-06-25 15:33:16.546687
# Unit test for function load
def test_load():
    str_0 = 'g\x7fL)\r\tH\x0e\x18\x14;\x0f\x1c\x1e\x14,\x0f\x1b\x17\x7f'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:33:17.884302
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:33:21.443203
# Unit test for function load
def test_load():
    str_0 = ''
    var_0 = load(str_0, str_0)

if __name__ == '__main__':
    # test_case_0()
    test_load()

# Generated at 2022-06-25 15:33:26.397646
# Unit test for function get_file_name
def test_get_file_name():
    """Test the get_file_name function."""
    str_0 = 'B)o#Pb7<py?oE9>qW'
    var_0 = get_file_name(str_0, str_0)
    assert var_0 == 'B)o#Pb7<py?oE9>qW.json'


# Generated at 2022-06-25 15:33:31.126947
# Unit test for function get_file_name
def test_get_file_name():
    print('\nTest get_file_name:')
    d = 'replay_dir'
    f = 'foo.json'
    print('\tExpected: {}\tActual: {}'.format(os.path.join(d, f), get_file_name(d, f)))
    f = 'foo'
    print('\tExpected: {}\tActual: {}'.format(os.path.join(d, f + '.json'), get_file_name(d, f)))


# Generated at 2022-06-25 15:33:36.147109
# Unit test for function load
def test_load():
    replay_dir = '%\tb~]G15aiKI}uaN?uQ'
    template_name = '@W}Zayz$d(`T[QO_9R'
    context = load(replay_dir, template_name)
    assert context == '@W}Zayz$d(`T[QO_9R'



# Generated at 2022-06-25 15:33:40.207360
# Unit test for function get_file_name
def test_get_file_name():
    str_0 = 'dNrOJ=1H_3lqo>}Ip"tz'
    str_1 = '?Ib)2Dd1k5&"Ap>@z}xBd'
    var_0 = get_file_name(str_1, str_0)


# Generated at 2022-06-25 15:33:45.343660
# Unit test for function load
def test_load():
    replay_dir = ''; template_name = 'c%\tb~]G15aiKI}uaN?uQ'
    with pytest.raises(TypeError):
        load(replay_dir, template_name)
    return True


# Generated at 2022-06-25 15:33:50.400377
# Unit test for function dump
def test_dump():
    # Test 1.
    str_0 = '%\tb~]G15aiKI}uaN?uQ'
    var_0 = dump(str_0, str_0, str_0)
    # Test 2.
    str_0 = 'q9I8W(a]bvwR=g;~p ]sH}I6'
    var_0 = dump(str_0, str_0, str_0)
    # Test 3.

# Generated at 2022-06-25 15:33:51.722917
# Unit test for function dump
def test_dump():
    pass # build data, call function, and test function output


# Generated at 2022-06-25 15:33:59.566185
# Unit test for function load
def test_load():
    replay_dir = '35Vx*'
    template_name = '%8@h:D4dJ3Z'
    # Test for var_0
    try:
        var_0 = load(replay_dir, template_name)
        assert var_0 is not None
        test_case_0()
    except TypeError:
        print('Failed to test function load')
        print('Unable to parse context.json file')
        return False
    else:
        return True


# Generated at 2022-06-25 15:34:00.999357
# Unit test for function load
def test_load():
    test_case_0()



# Generated at 2022-06-25 15:34:01.927388
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:34:09.642485
# Unit test for function dump
def test_dump():
    str_0 = '%\tb~]G15aiKI}uaN?uQ'
    var_0 = dump(str_0, str_0, str_0)
    str_1 = 'Cc;AyzXsP`o)Q?aA\nsT'

# Generated at 2022-06-25 15:34:19.809394
# Unit test for function load
def test_load():
    dump('test', 'test', 'test')
    str_0 = '\x07\x16\x1d\xff\x16\x1d\xff\xff\x1d\xff\xff\x12'
    var_0 = load('test', 'test')
    var_1 = load('test', 'test')
    str_1 = '\x07\x16\x1d\xff\x16\x1d\xff\xff\x1d\xff\xff\x12'
    assert (var_0 == str_0)
    assert (var_1 == '\x07\x16\x1d\xff\x16\x1d\xff\xff\x1d\xff\xff\x12')
    assert (var_1 == str_1)


# Generated at 2022-06-25 15:34:23.886408
# Unit test for function load
def test_load():
    str_0 = '4pq3{0y'
    str_1 = '%\tb~]G15aiKI}uaN?uQ'
    str_2 = '[vFpY'
    var_0 = load(str_0, str_1)
    str_3 = 'D!9|$'
    str_4 = 'hV(3n'
    str_5 = '1s?s;l'
    var_1 = load(str_3, str_4)
    str_6 = 't/AQ2'
    str_7 = 'w"lN'
    str_8 = 'u*7V$g'
    var_2 = load(str_6, str_7)

# Generated at 2022-06-25 15:34:27.232136
# Unit test for function dump
def test_dump():
    str_0 = '%\tb~]G15aiKI}uaN?uQ'
    var_0 = dump(str_0, str_0, str_0)
    assert var_0 == None


# Generated at 2022-06-25 15:34:33.414610
# Unit test for function load
def test_load():
    str_0 = ':sP\ns*(usIWLnY'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:34:38.466916
# Unit test for function load
def test_load():
    context = load('./cookiecutter', './cookiecutter')
    assert context.get('cookiecutter') is not None
    assert context.get('cookiecutter').get('github_username') is not None
    assert context.get('cookiecutter').get('replay_dir') == './cookiecutter'

# Generated at 2022-06-25 15:34:46.005203
# Unit test for function load
def test_load():
    # We test with a dict that has a string, a int, a list, and a nested dict.
    test_dict = {
        'string': 'Hello World',
        'integer': 1,
        'list': [1, 2, 3],
        'dict': {
            'nested': 'Dict'
        }
    }

    # Create a temporary directory
    with TemporaryDirectory() as tmppath:
        dumped_file_name = os.path.join(tmppath, 'test_dump.json')

        # Dump the test dict to a file
        with open(dumped_file_name, 'w') as outfile:
            json.dump(test_dict, outfile, indent=2)

        # Load the dumped JSON file
        loaded_dict = load(tmppath, 'test_dump.json')



# Generated at 2022-06-25 15:34:47.567600
# Unit test for function load
def test_load():
    assert test_case_0()=={'cookiecutter': {}}

test_load()

# Generated at 2022-06-25 15:34:49.895482
# Unit test for function load
def test_load():
    dump('temp', 'temp', {'temp': 1})
    assert load('temp', 'temp') == {'temp': 1}

    # clean up
    os.remove('temp/temp.json')
    os.rmdir('temp')

# Generated at 2022-06-25 15:34:53.594669
# Unit test for function dump
def test_dump():
    str_1 = 'Ei!YK^'
    str_2 = 'KW$@8'
    dict_0 = {'hello': 'world'}
    str_3 = 'HN[1'
    dump(str_1, str_2, dict_0)
    var_1 = load(str_1, str_2)
    assert (var_1 == dict_0, error_msg(str_3))


# Generated at 2022-06-25 15:34:54.859122
# Unit test for function load
def test_load():
    pass


# Generated at 2022-06-25 15:34:57.628964
# Unit test for function dump
def test_dump():
    test_case_0()


# Generated at 2022-06-25 15:35:08.280644
# Unit test for function dump
def test_dump():
    assert callable(dump)
    assert isinstance(get_file_name('c%R-n@', '?+Tg9b@'), str)
    assert dump('c%R-n@', '?+Tg9b@', {}) is None
    assert dump('c%R-n@', '?+Tg9b@', dict()) is None
    assert dump('c%R-n@', '?+Tg9b@', {}) is None
    assert dump('c%R-n@', '?+Tg9b@', dict()) is None
    assert dump(':sP\ns*(usIWLnY', ':sP\ns*(usIWLnY', {'cookiecutter:': {}}) is None

# Generated at 2022-06-25 15:35:15.716413
# Unit test for function load
def test_load():
    var_1 = {'cookiecutter': {}}
    with open(os.path.normpath('tests/files/test_project.json'), 'w') as var_2:
        json.dump(var_1, var_2)
    var_3 = os.path.normpath('tests/files/test_project.json')
    var_4 = load(str(), var_3)
    assert var_4 != var_1
    var_1 = {'cookiecutter': {'cookiecutter': {}}}
    with open(os.path.normpath('tests/files/test_project.json'), 'w') as var_2:
        json.dump(var_1, var_2)
    assert var_4 != var_1

# Generated at 2022-06-25 15:35:28.529537
# Unit test for function load
def test_load():
    import sys
    import random
    import math
    from contextlib import contextmanager
    from io import StringIO

    @contextmanager
    def capture_stdout():
        capture_out, capture_err = StringIO(), StringIO()
        current_out, current_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = capture_out, capture_err
            yield capture_out, capture_err
        finally:
            sys.stdout, sys.stderr = current_out, current_err

    def random_value():
        return random.randint(0, 10000)

    def random_key():
        return random.choice(['dict', 'list', 'int', 'value'])


# Generated at 2022-06-25 15:35:32.200425
# Unit test for function dump
def test_dump():
    dump('.', '', '')
    dump('.', 'abc', {})
    dump('.', 'abc', {'abc': 123})
    dump('.', 'abc', {'cookiecutter': {}})
    dump('.', 'abc', {'cookiecutter': {'abc': 123}})


# Generated at 2022-06-25 15:35:38.484713
# Unit test for function dump
def test_dump():
    replay_dir = '.cookiecutter'
    template_name = 'test_dump'
    context = {
        'cookiecutter': {
            'project_slug': 'test_dump',
            'project_name': 'test_dump',
        },
    }
    dump(replay_dir, template_name, context)
    var_0 = load(replay_dir, template_name)
    print(var_0)
    assert var_0 == context


# Generated at 2022-06-25 15:35:40.753763
# Unit test for function load
def test_load():
    str_0 = ':sP\ns*(usIWLnY'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:35:42.704842
# Unit test for function load
def test_load():
    str_0 = 'sdfsdfs'
    str.isinstance(test_case_0(), str_0)



# Generated at 2022-06-25 15:35:50.007177
# Unit test for function dump
def test_dump():
    str_0 = 'RG)k}Z'
    str_1 = 'N_pN"D~'
    dict_0 = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr'
        }
    }
    dump(str_0, str_1, dict_0)


# Generated at 2022-06-25 15:36:01.843194
# Unit test for function dump
def test_dump():
    str_0 = 'n!{Ncp&'
    str_1 = 'Pc/i'
    var_0 = load(str_1, str_1)
    try:
        var_0[str((str_1 + str_1)).capitalize()] = var_0[str_1]
        tmp_0 = None
    except KeyError:
        tmp_0 = None
    except TypeError:
        tmp_0 = None
    except ValueError:
        tmp_0 = None
    else:
        tmp_0 = True
    var_0['y?w'] = var_0[str_1]
    var_0[str((str_1 + str_1)).capitalize()] = var_0[str_1]

# Generated at 2022-06-25 15:36:05.613521
# Unit test for function dump
def test_dump():
    str_0 = ':sP\ns*(usIWLnY'
    dict_0 = {'cookiecutter': {'name': 'cookiecutter'}}

    # Call dump
    dump(str_0, str_0, dict_0)


# Generated at 2022-06-25 15:36:10.552815
# Unit test for function dump
def test_dump():
    assert callable(test_case_0)

if __name__ == '__main__':
    test_dump()

# Generated at 2022-06-25 15:36:19.943851
# Unit test for function load
def test_load():
    str_0 = ":sP\ns*(usIWLnY"
    bytes_1 = b":sP\ns*(usIWLnY"
    list_0 = [b":sP\ns*(usIWLnY", ":sP\ns*(usIWLnY"]
    list_1 = [b"", b":sP\ns*(usIWLnY", str_0, bytes_1, list_0]
    # function load with arguments: str_0
    try:
        assert func_load(str_0) == str_0
    except AssertionError:
        print("AssertionError in function load")
    # function load with arguments: bytes_1

# Generated at 2022-06-25 15:36:24.934084
# Unit test for function dump
def test_dump():
    str_0 = ':sP\ns*(usIWLnY'
    dict_0 = {'name': 'main.c'}
    str_1 = 'py.test'
    dump(str_0, str_1, dict_0)


# Generated at 2022-06-25 15:36:29.228312
# Unit test for function load
def test_load():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert 'Template name is required to be of type str' in str(excinfo.value)



# Generated at 2022-06-25 15:36:30.274998
# Unit test for function load
def test_load():
    assert callable(load)

# Generated at 2022-06-25 15:36:37.999195
# Unit test for function load
def test_load():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 15:36:48.433016
# Unit test for function dump
def test_dump():
    str_0 = '\r%\x0fpL^'
    int_0 = 0x4236
    int_1 = 0x5e5e5e
    list_0 = ['a', str_0, int_0, str_0, int_1, str_0]
    str_1 = '^'
    list_1 = [var_0 for var_0 in list_0]
    str_2 = ':sP\ns*(usIWLnY'
    dict_0 = dict()
    dict_0[str_0] = list_1
    dict_0[str_1] = list_1
    dict_0[str_2] = list_1
    dump(str_2, str_2, dict_0)


# Generated at 2022-06-25 15:36:57.863515
# Unit test for function dump
def test_dump():
    var_0 = 'k*_n9\x7f`2/}n)aue'
    var_1 = '1Q'
    print('Testing dump\n')
    var_2 = ':sP\ns*(usIWLnY'
    var_3 = var_2
    var_3 = var_3.rstrip('\n').split('\n')
    var_3 = '\n'.join(var_3[:])
    var_4 = {var_0 : var_3}
    dump(var_1, var_1, var_4)
    var_5 = os.path.exists(var_1)
    assert var_5 == False


# Generated at 2022-06-25 15:37:08.253512
# Unit test for function load
def test_load():
    template_name = 'test_name'
    replay_dir = os.path.join('test_dir')
    context_key = 'cookiecutter'
    context_value = {
        'cookiecutter': {
            'first_name': 'Audrey',
            'last_name': 'Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
        }
    }

    dump(replay_dir, template_name, context_value)
    assert load(replay_dir, template_name).get(context_key) == context_value.get(context_key)

# Generated at 2022-06-25 15:37:16.495065
# Unit test for function dump
def test_dump():
    replay_dir = ':sP\ns*(usIWLnY'
    template_name = ':sP\ns*(usIWLnY'
    context = {'cookiecutter': ':sP\ns*(usIWLnY'}
    replay_file = get_file_name(replay_dir, template_name)
    dump(replay_dir, template_name, context)
    assert os.path.exists(replay_file)



# Generated at 2022-06-25 15:37:28.083236
# Unit test for function load
def test_load():
    str_0 = ':sP\ns*(usIWLnY'
    var_0 = type(str_0)
    assert var_0 is str
    try:
        var_0 = load(str_0, str_0)
        assert False
    except TypeError as exception_0:
        assert type(exception_0) is TypeError
        assert str(exception_0) == 'Template name is required to be of type str'
    str_0 = ''
    str_1 = ''
    try:
        var_0 = load(str_0, str_1)
        assert False
    except ValueError as exception_0:
        assert type(exception_0) is ValueError
        assert str(exception_0) == 'Context is required to contain a cookiecutter key'

# Generated at 2022-06-25 15:37:39.894503
# Unit test for function load

# Generated at 2022-06-25 15:37:41.920078
# Unit test for function load
def test_load():
    assert True == True


# Generated at 2022-06-25 15:37:47.761976
# Unit test for function dump
def test_dump():
    print("test dump")
    str_0 = 'D:\\GitHub\\Cookiecutter-Java\\cookiecutter'
    str_1 = 'my_project'
    dict_0 = {'cookiecutter': {'project_slug': 'my_project'}}
    dump(str_0, str_1, dict_0)



# Generated at 2022-06-25 15:37:51.210514
# Unit test for function load
def test_load():
    context, template_name = test_case_0()
    load(context, template_name)


# Generated at 2022-06-25 15:37:52.136420
# Unit test for function load
def test_load():
    assert callable(load)



# Generated at 2022-06-25 15:37:56.370208
# Unit test for function load
def test_load():
    string_0 = '`rD`P\x18z\x7f5Q\x1b\x19'
    result_0 = load(string_0, 'test_cookiecutter.json')
    assert len(result_0) == 6
    
    

# Generated at 2022-06-25 15:38:00.542446
# Unit test for function load
def test_load():
    dump('/tmp/cookiecutter_tests', 'test_load', {'cookiecutter': {'foo': 'bar'}})
    assert load('/tmp/cookiecutter_tests', 'test_load') == {'cookiecutter': {'foo': 'bar'}}



# Generated at 2022-06-25 15:38:07.310335
# Unit test for function dump
def test_dump():
    from random import randint, choice
    from string import ascii_uppercase
    from os import remove
    from sys import exc_info
    from os.path import join, getmtime

# Generated at 2022-06-25 15:38:14.116021
# Unit test for function load
def test_load():
    template_name = "./test_template"
    test_data = {"cookiecutter": {"_copy_without_render": "{{cookiecutter.test_value}}"}}
    dump(template_name, template_name,test_data)
    assert load(template_name, template_name) == test_data
    os.remove(get_file_name(template_name, template_name))


# Generated at 2022-06-25 15:38:20.149795
# Unit test for function load
def test_load():
    replay_dir = '/home/workspace/test/test_replay/'
    template_name = 'test'
    dump(replay_dir, template_name, {
    'cookiecutter': {
            'license': "Test License",
            'project_name': 'Test Project Name',
            'repo_name': 'test-repo'
        }
    })
    result = load(replay_dir, template_name)
    print(result)


# Generated at 2022-06-25 15:38:26.516289
# Unit test for function load
def test_load():
    # Load from test file
    str_0 = "%s/test_files/test_replay_file.json" % os.curdir
    str_1 = load(str_0, str_0)
    assert str_1 != None
    str_2 = load(str_0, str_0)
    assert str_2 != None
    str_3 = load(str_0, str_0)
    assert str_3 != None


# Generated at 2022-06-25 15:38:30.238746
# Unit test for function load
def test_load():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 15:38:32.721546
# Unit test for function load
def test_load():
    var_1 = test_case_0
    print(var_1)


# Generated at 2022-06-25 15:38:35.259771
# Unit test for function load
def test_load():
    str_0 = 'cookiecutter'
    str_1 = 'cookiecutter-pypackage'
    var_0 = load(str_0, str_1)


# Generated at 2022-06-25 15:38:40.341709
# Unit test for function dump
def test_dump():

    template_name = "test"
    context = {
        'a': '1',
        'b': '2',
        'c': '3',
    }

    # Create
    if (not os.path.exists(template_name)):
        os.makedirs(template_name)

    dump(template_name, template_name, context)

    # Load
    file_context = load(template_name, template_name)

    # Test
    assert context == file_context

test_case_0()
test_dump()

# Generated at 2022-06-25 15:38:50.571272
# Unit test for function load
def test_load():
    replay_dir = os.getcwd()
    template_name = 'audreyr/cookiecutter-pypackage'
    actual = load(replay_dir, template_name)

# Generated at 2022-06-25 15:38:53.969344
# Unit test for function dump
def test_dump():
    assert dump('FZU{wS_#rn!', 'h=X$z:M1mJa', {'cookiecutter': {'full_name': 'Troy Caro', 'email': 'troy@caro.ca'}}) == None


# Generated at 2022-06-25 15:38:55.141066
# Unit test for function load
def test_load():
    assert func_0() == var_0

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:39:05.961512
# Unit test for function dump
def test_dump():
    # Setup
    a = None
    b = None
    c = ':sP\ns*(usIWLnY'
    d = "cookiecutter"
    e = None

    # Act
    dump(a, b, c)
    dump(a, e, e)
    dump(e, d, e)
    dump(e, e, e)
    dump(c, d, c)

if __name__ == '__main__':
    """
    Теперь напишем интерактивный ввод пути к replay и имя шаблона. 
    """

# Generated at 2022-06-25 15:39:15.014961
# Unit test for function dump
def test_dump():
    # Mock template name
    template_name = os.path.join(__file__, '..', '..', 'tests',
                                 'test-template')
    # Mock context
    context = {'cookiecutter': 'test'}
    # Mock replay_dir
    replay_dir = 'replay_dir'
    # Mock replay_file
    replay_file = get_file_name(replay_dir, template_name)

    # Call dump
    dump(replay_dir, template_name, context)

    # Assert that the replay file exists
    assert os.path.exists(replay_file)

    # Cleanup
    os.remove(replay_file)


# Generated at 2022-06-25 15:39:22.039379
# Unit test for function load
def test_load():
    template_name = 'test_name'
    replay_dir    = '.'
    context       = {
        'cookiecutter':
            {
                'cookiecutter': {
                    'name': 'Audrey Roy Greenfeld',
                    'email': 'audreyr@gmail.com',
                    'github_username': 'audreyr',
                    'project_name': '{{ cookiecutter.github_username }}.github.io',
                }
            }
    }

    # test dump
    dump(replay_dir, template_name, context)
    # test load
    content_loaded = load(replay_dir, template_name)
    # test dump and load with string as replay directory
    dump(replay_dir, template_name, context)
    content_loaded = load(replay_dir, template_name)


# Generated at 2022-06-25 15:39:29.306111
# Unit test for function load
def test_load():
    str_0 = '\\'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:39:37.232351
# Unit test for function dump
def test_dump():
    cache_dir = '/tmp'
    project_dir = 'foobar'
    replay_dir = os.path.join(cache_dir, project_dir)
    template_name = 'django-project'
    context = {
        'cookiecutter': {
            'project_name': 'Foobar Project'
        }
    }

    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)

    import json
    with open(replay_file, 'r') as infile:
        assert json.load(infile) == context



# Generated at 2022-06-25 15:39:45.343416
# Unit test for function load
def test_load():
    str_0 = ':sP\ns*(usIWLnY'
    var_0 = load(str_0, str_0)
    assert var_0 == ':sP\ns*(usIWLnY'
    var_0 = load('{:dI5Y1\tS@-', '/=d!M\x0bz]\x7f[')
    assert var_0 == '{:dI5Y1\tS@-'
    var_0 = load('{:dI5Y1\tS@-', '\x0b\x0e\x0c^h\x10\x03\x1ew\x0b!\r')
    assert var_0 == '{:dI5Y1\tS@-'

# Generated at 2022-06-25 15:39:49.421264
# Unit test for function load
def test_load():
    str_0 = ':sP\ns*(usIWLnY'
    var_0 = load(str_0, str_0)
    assert var_0 == {'cookiecutter': {}}


# Generated at 2022-06-25 15:39:57.509643
# Unit test for function load
def test_load():
    str_0 = ':sP\ns*(usIWLnY'
    str_1 = ':sP\ns*(usIWLnY'
    var_0 = load(str_0, str_1)
    assert var_0 is not None
    assert 'cookiecutter' in var_0
    assert var_0['cookiecutter'] == {'baz': 'qux',
                                     'foo': 'bar',
                                     'python_interpreter': 'python3'}


# Generated at 2022-06-25 15:40:06.348021
# Unit test for function load
def test_load():
    str_0 = '\x1be\x1aH\x1e\x0c'
    var_0 = load(str_0, str_0)
    str_1 = '\x1b"\x1c&\x1d^'
    str_2 = '\x1b0\x1d\x10\x1f"'
    str_3 = '\x1b&\x1c\x1a\x1e\x1bA'
    str_4 = '\x1b\x10\x1c\x12\x1d|'
    str_5 = '\x1aX\x1e\x03\x1a\x07'
    str_6 = '\x1b\n\x1d\x1c\x1cN'


# Generated at 2022-06-25 15:40:14.657769
# Unit test for function load

# Generated at 2022-06-25 15:40:16.795345
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except IOError:
        pass
    except TypeError:
        pass
    except ValueError:
        pass


# Generated at 2022-06-25 15:40:19.442902
# Unit test for function load
def test_load():
    assert(test_case_0)

# Generated at 2022-06-25 15:40:24.361634
# Unit test for function load
def test_load():
    var_0 = 'SJ8W:nP*o'
    var_1 = 'XdW*eJj'
    var_0 = load(var_0, var_1)
    var_2 = 'AZV9NS+Z'
    var_3 = 'D\n+A/:y/'
    var_3 = load(var_2, var_3)


# Generated at 2022-06-25 15:40:36.556934
# Unit test for function load
def test_load():
    str_0 = ':sP\ns*(usIWLnY'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:40:38.142277
# Unit test for function load
def test_load():
    str_0 = ':sP\ns*(usIWLnY'
    var_0 = load(str_0, str_0)

# Generated at 2022-06-25 15:40:48.312138
# Unit test for function load
def test_load():
    regex_0 = (b'XyJk\x20f7Kd\x5bV\x20zIBIJ\x5b\x5dV\x20%3D\x20j\x5bGkV\x20!\x3D\x20j\x5b\x5dV\x20%3F\x20j\x5bGkV\x205\x5bVXyJgf\t\x16%E\x20%7B%0Ax%20%7D')
    str_0 = ':sP\ns*(usIWLnY'


# Generated at 2022-06-25 15:40:58.023264
# Unit test for function dump
def test_dump():
    os.environ['TEST_PATH'] = './test_files'
    context = {
        'cookiecutter': {
            'project_name': 'sP\ns*(usIWLnY',
            'project_slug': 'sP\ns*(usIWLnY'
        }
    }
    dump('./test_files', 'sp\nS*(usIWLnY', context)
    var_0 = os.path.exists('./test_files/sp\ns*(usIWLnY.json')
    assert var_0


# Generated at 2022-06-25 15:41:07.388097
# Unit test for function load
def test_load():
    # Test only works if the test files are present
    replay_dir = 'cookiecutter/tests/test-files/replay'

    # Test case #0
    test_case_0()

    # Test case #1
    template_name_1 = 'fake'
    ref_json_1 = os.path.join(replay_dir, 'fake.json')
    with open(ref_json_1, 'r') as infile:
        expected_1 = json.load(infile)
    result_1 = load(replay_dir, template_name_1)
    assert result_1 == expected_1

    # Test case #2
    template_name_2 = 'fake.json'
    ref_json_2 = os.path.join(replay_dir, 'fake.json')

# Generated at 2022-06-25 15:41:08.464850
# Unit test for function load
def test_load():

    assert callable(load)
    # Place additional tests below



# Generated at 2022-06-25 15:41:11.868505
# Unit test for function dump
def test_dump():
    # Case 0
    replay_dir = ':sP\ns*(usIWLnY'
    template_name = ':sP\ns*(usIWLnY'
    context = {'cookiecutter': {'aaa': 'bbb'}}
    dump(replay_dir, template_name, context)


test_dump()

test_case_0()

# Generated at 2022-06-25 15:41:13.473274
# Unit test for function load
def test_load():
    # Test cases
    test_case_0()


# Generated at 2022-06-25 15:41:14.202525
# Unit test for function load
def test_load():
    pass


# Generated at 2022-06-25 15:41:21.739339
# Unit test for function load
def test_load():
    str_0 = ':sP\ns*(usIWLnY'
    dict_0 = load(str_0, str_0)
    assert dict_0 == {'cookiecutter': {'cookiecutter': {'cookiecutter': {}}, 'project_slug': '', 'full_name': '', 'email': '', 'github_username': '', 'project_name': '', 'project_short_description': '', '_template': ':sP\ns*(usIWLnY'}}, 'Assertion failed'


# Generated at 2022-06-25 15:41:50.122283
# Unit test for function load
def test_load():
    # TODO: Add parameters to test_load
    assert(False)


# Generated at 2022-06-25 15:41:55.062438
# Unit test for function load
def test_load():

    # Set up test data
    replay_dir = ':sP\ns*(usIWLnY'
    template_name = ':sP\ns*(usIWLnY'

    # Perform the task
    var_0 = load(replay_dir, template_name)

    # Verify the results
    assert var_0 == None


# Generated at 2022-06-25 15:41:56.830571
# Unit test for function dump
def test_dump():
    assert dump('./temp', 'my_cake', {'cookiecutter': {'hello': 'world'}}) is None


# Generated at 2022-06-25 15:42:03.425082
# Unit test for function load
def test_load():
    assert_equals(load('cookiecutter', ''), {'cookiecutter': {}})
    assert_equals(load('cookiecutter', '/home/user/example_cookiecutter_repo'), {'/home/user/example_cookiecutter_repo': {}})
    assert_equals(load('cookiecutter', '/home/user/example_cookiecutter_repo'), {'/home/user/example_cookiecutter_repo': {}})
    assert_equals(load('cookiecutter', '/home/user/example_cookiecutter_repo'), {'/home/user/example_cookiecutter_repo': {}})
    assert_equals(load('cookiecutter', ''), {'cookiecutter': {}})

# Generated at 2022-06-25 15:42:04.456966
# Unit test for function dump
def test_dump():
    assert callable(dump)


# Generated at 2022-06-25 15:42:16.216629
# Unit test for function load
def test_load():
    from click.testing import CliRunner
    from cookiecutter import main

    runner = CliRunner()
    result = runner.invoke(main.main, ['tests/test-repo-pre/', '--no-input'])
    assert result.exit_code == 0
    assert result.exception is None
    assert result.output.startswith('You\'ve downloaded')

    result = runner.invoke(
        main.main,
        [
            '--replay', 'tests/test-repo-pre/',
            '--no-input', '--debug'
        ]
    )
    assert result.exit_code == 0
    assert result.exception is None
    assert result.output.startswith('You\'ve downloaded')

# Generated at 2022-06-25 15:42:22.596043
# Unit test for function load
def test_load():
    
    # Test Case 0:
    print(test_case_0.__doc__)

    str_0 = ':sP\ns*(usIWLnY'
    var_0 = load(str_0, str_0)
    # Should return load(str_0, str_0)
    assert var_0 == load(str_0, str_0)



# Generated at 2022-06-25 15:42:28.683330
# Unit test for function dump
def test_dump():
    assert dump(1, 1, 1) == True
    assert dump(2, 2, 2) == True
    assert dump(3, 3, 3) == True
    assert dump(4, 4, 4) == True
    assert dump(5, 5, 5) == True
    assert dump(6, 6, 6) == True
    assert dump(7, 7, 7) == True
    assert dump(8, 8, 8) == True
    assert dump(9, 9, 9) == True
    assert dump(10, 10, 10) == True
    assert dump(11, 11, 11) == True
    assert dump(12, 12, 12) == True
    assert dump(13, 13, 13) == True
    assert dump(14, 14, 14) == True
    assert dump(15, 15, 15) == True

# Generated at 2022-06-25 15:42:29.441809
# Unit test for function load
def test_load():
    pass



# Generated at 2022-06-25 15:42:30.281033
# Unit test for function load
def test_load():
    assert load('{', '{')
