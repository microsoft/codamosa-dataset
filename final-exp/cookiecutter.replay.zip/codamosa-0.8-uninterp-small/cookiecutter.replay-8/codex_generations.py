

# Generated at 2022-06-25 15:33:09.575520
# Unit test for function load
def test_load():
    # tests 3, 7, and 11
    int_0 = int('0x1c5fac5e', 16)
    dict_0 = {int_0: int_0}
    var_0 = load(int_0, dict_0)
    print("Unit test for load()")
    print("Testing if var_0 is a dict.")
    try:
        assert(type(var_0) == dict)
    except AssertionError as e:
        print(e)
        print("test_1")
    else:
        print("test_2: passed")
    print("Testing if var_0[\"cookiecutter\"] is a dict.")
    try:
        assert(type(var_0["cookiecutter"]) == dict)
    except AssertionError as e:
        print(e)

# Generated at 2022-06-25 15:33:19.561085
# Unit test for function dump
def test_dump():
    # Create the test cases to test the dump function
    template_name = "test"
    context = {"cookiecutter":{"name":"test_dump"}}
    replay_dir = "test_dump"

    # Should return None
    dump(replay_dir, template_name, context)

    # Test if it returns an error if replay_dir already exists
    # Should return an error
    dump(replay_dir, template_name, context)

    # Test if it returns an error if template_name isn't a string
    # Should return an error
    dump(replay_dir, 34, context)

    # Test if it returns an error if context isn't a dict
    # Should return an error
    dump(replay_dir, template_name, "test")

    # Test if it returns an error if context doesn't contain a cookiecutter key

# Generated at 2022-06-25 15:33:26.834331
# Unit test for function load
def test_load():
    temp_dir = os.path.abspath(
                 os.path.join(os.path.dirname(__file__), os.pardir, 'tests', 'fixtures', 'cookiecutter-replay')
             )
    name = 'foobar'
    context = {'cookiecutter': {'foo': 'bar'}}

    assert dump(temp_dir, name, context) is None
    assert load(temp_dir, name) == context
    assert os.path.exists(get_file_name(temp_dir, name)) is True

# Generated at 2022-06-25 15:33:30.718147
# Unit test for function dump
def test_dump():
    dict_0 = dict()
    dict_0[0] = dict_0
    dict_0[1] = dict_0

    dict_1 = dict()
    dict_1[0] = dict_0
    dict_1[1] = dict_1

    dict_0['retval'] = dict_1
    dict_1['retval'] = dict_0
    test_case_0()


# Generated at 2022-06-25 15:33:36.665393
# Unit test for function get_file_name
def test_get_file_name():
    int_0 = -1697
    dict_0 = {int_0: int_0}
    dict_1 = {int_0: int_0}
    var_0 = get_file_name(int_0, dict_1)
    dict_2 = {int_0: int_0}
    var_1 = get_file_name(int_0, dict_2)
    assert(var_0 == var_1)

# Generated at 2022-06-25 15:33:39.259750
# Unit test for function dump
def test_dump():
    int_0 = -1698
    dict_0 = {int_0: int_0}
    var_0 = dump(int_0, dict_0, int_0)


# Generated at 2022-06-25 15:33:47.487446
# Unit test for function dump
def test_dump():
    data_0 = -1247
    str_0 = 'pw'
    dump(str_0, data_0, str_0)
    data_0 = 196
    str_0 = 'h'
    dump(str_0, data_0, str_0)


# Generated at 2022-06-25 15:33:48.819324
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:33:49.677634
# Unit test for function load
def test_load():
    load(0, 0)



# Generated at 2022-06-25 15:33:56.326423
# Unit test for function load
def test_load():
    # Tries to get into if block, but does not reach it
    dict_1 = {}
    test_load_0 = load(dict_1, dict_1)
    # Tries to get into if block
    test_load_1 = load(20, 20)
    # Tries to get into if block, but does not reach it
    test_load_2 = load(0, 0)



# Generated at 2022-06-25 15:34:02.763451
# Unit test for function load
def test_load():
        replay_dir = '/home/sblair/test/test_cookiecutter_replay'
        template_name = 'cookiecutter-pypackage'
        dict_0 = load(replay_dir, template_name)
        expected_result = var_0
        assert dict_0 == expected_result

        replay_dir = 'tests/test-dir'
        template_name = 'cookiecutter-pypackage'
        dict_1 = load(replay_dir, template_name)
        expected_result = var_1
        assert dict_1 == expected_result


# Generated at 2022-06-25 15:34:10.196320
# Unit test for function load

# Generated at 2022-06-25 15:34:14.406162
# Unit test for function load
def test_load():
    # Test case 0
    var_0 = dict()
    var_1 = dict()
    context = load('test-replay/', var_0, var_1)
    print(">>")
    print(context)
    print("<<")


# Generated at 2022-06-25 15:34:15.521500
# Unit test for function load
def test_load():
    assert load.__doc__ != None


# Generated at 2022-06-25 15:34:20.221340
# Unit test for function load
def test_load():
    assert test_case_0() == False


# Generated at 2022-06-25 15:34:21.586468
# Unit test for function load
def test_load():
    var_1 = load(var_0, var_1)
    assert(False)


# Generated at 2022-06-25 15:34:24.281806
# Unit test for function dump
def test_dump():
    dump("non-exist-dir", "temp-1", var_0)
    dump("replay", "temp-1", var_1)


# Generated at 2022-06-25 15:34:33.739048
# Unit test for function load
def test_load():
    template_name = "Test 1"
    replay_dir = "replaydir\\"

# Generated at 2022-06-25 15:34:41.449389
# Unit test for function load
def test_load():
    # get the location of the current file
    replaying_dir = "./"
    # replay_0
    template_name_0 = "./replaying/ccextractor_testcase_0_uut.json"
    # load the file
    context_0 = load(replaying_dir, template_name_0)
    var_0 = context_0["cookiecutter"]["var_0"]
    var_1 = context_0["cookiecutter"]["var_1"]
    # replay_0
    # test case
    assert var_0 == var_1


# Generated at 2022-06-25 15:34:44.516033
# Unit test for function load
def test_load():
    replay_dir = 'C://Users//admin//Desktop//CSE//cse_527//cookiecutter//cookiecutter//replay'
    template_name = 'test_case_0'
    load(replay_dir, template_name)


# Generated at 2022-06-25 15:34:49.930545
# Unit test for function load
def test_load():
    str_0 = 'test_case_0'
    var_0 = load(str_0, str_0)
    assert var_0 != {}


# Generated at 2022-06-25 15:34:52.706265
# Unit test for function dump
def test_dump():
    str_0 = 'test_dump'
    var_1 = {'cookiecutter': {'name': 'test_dump'}}
    dump(str_0, str_0, var_1)
    var_0 = load(str_0, str_0)
    assert var_0 == var_1

# Generated at 2022-06-25 15:34:56.196581
# Unit test for function load
def test_load():
    str_0 = 'test_load'
    var_0 = load(str_0, str_0)


if __name__ == '__main__':
    test_case_0()
    test_load()

# Generated at 2022-06-25 15:35:07.784745
# Unit test for function dump
def test_dump():
    str_0 = 'test_cookiecutter.replay/'
    str_1 = 'dump_test'
    var_0 = {}
    var_0['cookiecutter'] = {}
    var_0['cookiecutter']['_template'] = {}
    var_0['cookiecutter']['_template']['repo_dir'] = 'repo_dir'
    var_0['cookiecutter']['_template']['repo_url'] = 'repo_url'
    var_0['cookiecutter']['_template']['branch'] = 'branch'
    var_0['cookiecutter']['_template']['tags'] = 'tags'
    var_0['cookiecutter']['_template']['short_description'] = 'short_description'
    var

# Generated at 2022-06-25 15:35:10.053292
# Unit test for function load
def test_load():
    try:
        str_1 = 'test_case_1'
        test_case_0()
    except:
        var_1 = False
    else:
        var_1 = True
    assert var_1


# Generated at 2022-06-25 15:35:15.489002
# Unit test for function load
def test_load():
    test_dir = 'test_dir'
    file_name = 'file_name'
    context = {'cookiecutter': {'a': 'A', 'b':'B'}}
    # create replay file
    try:
        dump(test_dir, file_name, context)
        var_0 = load(test_dir, file_name)
        if var_0 == context:
            print('Pass: function load')
        else:
            print('Fail: function load')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 15:35:18.935309
# Unit test for function load
def test_load():
    assert callable(load)
    # test_case_0
    try:
        test_case_0()
    except Exception as e:
        assert False, "unexpected error: '{}'".format(e)


# Generated at 2022-06-25 15:35:29.000882
# Unit test for function dump
def test_dump():
    if filesys.path.exists('.cookiecutter'):
        shutil.rmtree('.cookiecutter')
    dump('/home/jonathan/.cookiecutter', 'test_templ_0', {})
    dump('/home/jonathan/.cookiecutter', 'test_templ_1', None)
    dump('/home/jonathan/.cookiecutter', 'test_templ_2', {'cookiecutter': {}})
    dump('/home/jonathan/.cookiecutter', 'test_templ_3', {'cookiecutter': {}, 'rep_0': 'rep_val_0'})
    dump('/home/jonathan/.cookiecutter', 'test_templ_4', {'cookiecutter': {}, 'rep_0': {}['test_0']})

# Unit test

# Generated at 2022-06-25 15:35:33.541711
# Unit test for function load
def test_load():
    # Test case 0
    # load('test_case_0', 'test_case_0')
    # Test case 1
    str_0 = 'test_case_1'
    var_0 = load(str_0, str_0)
    assert var_0['cookiecutter']['extra_context'] == {
        'company_name': 'Example, Inc.',
        'project_name': 'Example Project',
        'project_slug': 'example_project',
        'project_short_description': 'A short description of the project.',
        'release_date': '2013-07-10',
        'year': '2013'
    }



# Generated at 2022-06-25 15:35:34.550460
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:35:39.512330
# Unit test for function load
def test_load():
    str_0 = 'test_case_0'
    var_0 = load(str_0, str_0)
    assert var_0 == {'cookiecutter': {'project_slug': 'cookiecutter'}}


# Generated at 2022-06-25 15:35:42.380895
# Unit test for function load
def test_load():
    str_0 = 'test_case_0'
    var_0 = load(str_0, str_0)
    assert(var_0 == {'cookiecutter': {'hello': 'world'}})


# Generated at 2022-06-25 15:35:45.913471
# Unit test for function load
def test_load():
    var_0 = load('test_case_0', 'test_case_0')


# Generated at 2022-06-25 15:35:52.370611
# Unit test for function load
def test_load():
    assert_0 = load('cookiecutter.replay', 'cookiecutter.replay')
    assert_1 = load('cookiecutter.replay', 'cookiecutter.replay')
    assert_2 = load('cookiecutter.replay', 'cookiecutter.replay')

    assert(assert_0 == assert_1)
    assert(assert_0 != assert_2)


# Generated at 2022-06-25 15:35:54.858803
# Unit test for function load
def test_load():
    str_0 = 'test_case_0'
    var_0 = load(str_0, str_0)
    assert var_0 == {'cookiecutter': {'full_name': 'Your Full Name', 'email': 'your@email.com'}}


# Generated at 2022-06-25 15:35:59.340758
# Unit test for function load

# Generated at 2022-06-25 15:36:10.042644
# Unit test for function load
def test_load():
    replay_dir = 'test'
    input_var = 'example_context.json'

# Generated at 2022-06-25 15:36:14.903736
# Unit test for function load
def test_load():
    str_0 = 'test_load'
    var_0 = load(str_0, 'test_load')
    assert isinstance(var_0, dict)
    assert isinstance(var_0['cookiecutter'], dict)
    dump(str_0, str_0, var_0)

# Generated at 2022-06-25 15:36:15.971457
# Unit test for function dump
def test_dump():
    pass



# Generated at 2022-06-25 15:36:17.169424
# Unit test for function load
def test_load():
    # Test 0 - edge case
    test_case_0()

# Generated at 2022-06-25 15:36:25.652276
# Unit test for function dump
def test_dump():
    str_0 = 'dump'
    var_0 = {
        'cookiecutter': {
            '_template': str_0,
            'full_name': str_0,
            'email': str_0,
            'project_name': str_0
        }
    }
    dump(str_0, str_0, var_0)


# Generated at 2022-06-25 15:36:31.001921
# Unit test for function load
def test_load():
    str_0 = 'test_case_0'
    var_0 = load(str_0, str_0)
    print("load(): ", var_0)
    if (var_0[0] == 'test_case_0'):
        return True
    else:
        return False



# Generated at 2022-06-25 15:36:38.497608
# Unit test for function dump
def test_dump():
    import tempfile

    template_name = os.path.basename(__file__).split('.')[0]
    context = {
        'cookiecutter': {
            '_template': '.',
        }
    }

    with tempfile.TemporaryDirectory() as tempdir:
        # Set up temporary directory
        directory_name = os.path.join(tempdir, template_name)
        os.mkdir(directory_name)
        file_name = '.'.join([template_name, 'json'])
        file_path = os.path.join(directory_name, file_name)

        # Test dump
        dump(directory_name, template_name, context)
        # Verify file exists
        assert os.path.exists(file_path) is True
        # Verify file contents

# Generated at 2022-06-25 15:36:39.417672
# Unit test for function load
def test_load():
    assert callable(load)



# Generated at 2022-06-25 15:36:42.947684
# Unit test for function dump
def test_dump():
    dump('replay_dir', 'template_name', {'cookiecutter':{}})
    replay_file = get_file_name('replay_dir', 'template_name')
    os.remove(replay_file)



# Generated at 2022-06-25 15:36:45.696940
# Unit test for function load
def test_load():
    str_0 = 'test_load'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:36:48.433374
# Unit test for function dump
def test_dump():
    str_0 = 'test_case_0'
    var_0 = {'cookiecutter': {'name': 'jm'}}
    dump(str_0, str_0, var_0)


# Generated at 2022-06-25 15:36:51.013491
# Unit test for function dump
def test_dump():
    test_case_0()


# Generated at 2022-06-25 15:36:52.479252
# Unit test for function load
def test_load():
    assert (load('test', 'test'))


# Generated at 2022-06-25 15:36:57.274771
# Unit test for function load
def test_load():
    try:
        load(None, None)
        load(None, "IamString")
    except TypeError as te:
        assert te.message.startswith('Template name is required to be of type str')

# Generated at 2022-06-25 15:37:05.772338
# Unit test for function dump
def test_dump():
    dict_0 = {'cookiecutter' : {}}
    str_0 = 'test_dump'
    dump(str_0, str_0, dict_0)
    var_0 = load(str_0, str_0)
    return var_0


# Generated at 2022-06-25 15:37:15.360835
# Unit test for function load
def test_load():
    try:
        assert load('test_case_1', 'test_case_1') == load('test_case_1', 'test_case_1'), "error test_case_1"
        test_case_0()
    except TypeError as e:
        print("TypeError:", e)
    except ValueError as e:
        print("ValueError:", e)
    else:
        print("success")


# Generated at 2022-06-25 15:37:22.369736
# Unit test for function dump
def test_dump():
    import random, string
    random_string_1 = ''.join(random.choice(string.lowercase) for i in range(24))
    solution = {random_string_1: 'success'}
    dump(random_string_1, random_string_1, solution)
    assert solution == load(random_string_1, random_string_1)
    os.remove(random_string_1 + '.json')


# Generated at 2022-06-25 15:37:26.686134
# Unit test for function load
def test_load():
    str_0 = 'test_case_0'
    str_1 = 'test_case_1'
    var_0 = load(str_0, str_1)
    var_1 = load(str_0, str_1)


# Generated at 2022-06-25 15:37:28.833236
# Unit test for function load
def test_load():
    context = load('tests/files/json_files', 'test_file')
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-25 15:37:37.617187
# Unit test for function dump
def test_dump():
    replay_dir = os.getcwd()
    template_name = 'Unittest'
    context = {'cookiecutter': {'full_name': 'test', 'email': 'test@test.com', 'github_username': 'test', 'project_name': 'test', 'project_slug': 'test', 'project_short_description': 'test', 'pypi_username': 'test'}}
    assert dump(replay_dir, template_name, context) is None


# Generated at 2022-06-25 15:37:38.490191
# Unit test for function load
def test_load():
    # nothing to test
    pass


# Generated at 2022-06-25 15:37:47.211847
# Unit test for function load
def test_load():
    str_0 = 'test_case_0'
    var_0 = load(str_0, str_0)
    var_1 = load('', str_0)
    var_2 = load(str_0, '')
    var_3 = load(str_0, '.')
    var_4 = load(str_0, 'None')
    var_5 = load(str_0, 'ttt')
    var_6 = load(str_0, '...')
    var_7 = load('foo', str_0)


# Generated at 2022-06-25 15:37:52.251078
# Unit test for function load
def test_load():
    from cookiecutter import replay
    replay_dir = 'test_cookiecutter_replay'
    template_name = 'test_load'
    replay.load(replay_dir, template_name)


# Generated at 2022-06-25 15:38:01.308364
# Unit test for function dump
def test_dump():
    mock_replay_dir = '.'
    mock_template_name = 'mock_template_name'
    mock_context = {'cookiecutter': {'mock': 'mock_content'}}
    dump(mock_replay_dir, mock_template_name, mock_context)
    file_name = get_file_name(mock_replay_dir, mock_template_name)
    with open(file_name, 'r') as f:
        assert f.read() == '{\n  "cookiecutter": {\n    "mock": "mock_content"\n  }\n}'
    os.remove(file_name)


# Generated at 2022-06-25 15:38:16.961310
# Unit test for function dump
def test_dump():
    str_0 = 'test_dump'
    var_0 = 'test_dump.json'
    var_1 = 'cookiecutter'
    var_2 = 'test_dump'
    #
    var_3 = get_file_name(str_0, var_0)
    os.makedirs(str_0, exist_ok=True)
    #
    var_4 = dump(str_0, var_0, {var_1: {var_2: ''}})
    assert os.path.isfile(var_3) == True 
    #
    assert os.path.isfile(var_3) == True
    #
    os.remove(var_3)
    os.removedirs(str_0)


# Generated at 2022-06-25 15:38:17.944772
# Unit test for function load
def test_load():
    # Clear function body
    None


# Generated at 2022-06-25 15:38:20.508117
# Unit test for function load
def test_load():
    str_0 = 'test_case_0'
    var_0 = load(str_0, str_0)
    assert var_0 is not None


# Generated at 2022-06-25 15:38:23.645979
# Unit test for function load
def test_load():
    str_0 = 'test_case_0'
    var_0 = load(str_0, str_0)
    assert var_0 is None


# Generated at 2022-06-25 15:38:26.048841
# Unit test for function load
def test_load():
    str_0 = 'test_load'
    var_0 = load(str_0, str_0)
    assert isinstance(var_0, dict) == True



# Generated at 2022-06-25 15:38:36.866253
# Unit test for function load
def test_load():
    expected = {"cookiecutter": {"repo_dir": "cookiecutter-pypackage", "full_name": "Audrey Roy", "zip_file": "cookiecutter-pypackage.zip"}, "pytest": {"project_name": "cookiecutter-pypackage-pytest", "repo_name": "cookiecutter-pypackage-pytest", "project_slug": "cookiecutter-pypackage-pytest", "package_name": "cookiecutter_pypackage_pytest", "author_name": "Audrey Roy", "email": "audreyr@example.com", "description": "A Python package project skeleton with pytest testing.", "release_date": "2013-07-07", "version": "0.1.0", "open_source_license": "BSD license"}}

# Generated at 2022-06-25 15:38:40.241259
# Unit test for function load
def test_load():
    print('Testing load()')

    print('Test case 0')
    try:
        test_case_0()
    except:
        print('Test case 0 failed')
    else:
        print('Test case 0 succeeded')

    print('All test cases succeeded')

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-25 15:38:43.090932
# Unit test for function load
def test_load():
    str_0 = 'test_load'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:38:53.015804
# Unit test for function load
def test_load():
    # Stub: If a replay file is found, we load the replay file
    # If a replay file is not found, we prompt user for context
    # If a non-existing replay directory is inputted, throw an IOError
    # If a non-existent template name is inputted, throw a ValueError
    # If a non-string replay directory is inputted, throw a TypeError
    # If a non-string template name is inputted, throw a TypeError
    pass

test_load()


# Generated at 2022-06-25 15:39:03.854405
# Unit test for function load
def test_load():
    # Test case for load
    str_0 = 'test_case_1'
    var_0 = load(str_0, str_0)
    str_2 = 'cookiecutter'
    str_11 = '_copy_without_render'
    str_10 = 'cookiecutter'
    str_9 = 'replay_dir'
    str_8 = '_copy_without_render'
    str_7 = 'replay_dir'
    str_5 = 'cookiecutter'
    str_6 = 'replay_dir'
    str_3 = 'render'
    str_4 = 'replay_dir'
    str_1 = 'test_case_1'
    var_1 = load(str_1, str_1)
    str_14 = 'cookiecutter'

# Generated at 2022-06-25 15:39:18.607383
# Unit test for function load
def test_load():
    assert callable(load)



# Generated at 2022-06-25 15:39:27.416765
# Unit test for function dump
def test_dump():
    # Create temporary folder to dump context file
    tempfolder = "temp"
    if not os.path.exists(tempfolder):
        os.makedirs(tempfolder)
    # Test dump function with valid input
    dic_0 = {"cookiecutter": {"test_var_0": "var_0", "test_var_1": "var_1"}}
    dump(tempfolder, "test_dump", dic_0)
    assert os.path.exists("temp/test_dump.json")
    # Test dump function with invalid input
    dic_1 = {"cookiecutter": {"test_var_2": "var_2"}}
    try:
        dump(tempfolder, None, dic_1)
    except TypeError:
        pass

# Generated at 2022-06-25 15:39:36.054457
# Unit test for function load
def test_load():

    # Test case 1
    replay_dir = 'test_dir'
    template_name = 'template_name'
    expected = {'cookiecutter': {'key': 'value'}}
    context = load(replay_dir, template_name)
    # assert compare context is equal to expected.

    # Test case 2
    replay_dir = 'test_dir'
    template_name = 'template_name'
    expected = {'cookiecutter': {'key': 'value'}}
    context = {'cookiecutter': {'key': 'value'}}
    dump(replay_dir, template_name, context)
    # assert compare context is equal to expected.


# Generated at 2022-06-25 15:39:42.865451
# Unit test for function dump
def test_dump():
    # Case 0
    # Under normal conditions:
    # Input
    str_0 = 'test_case_0'
    dict_0 = {'test_key_0': 'test_val_0'}
    # Expected
    IOError_0 = False
    # Output
    IOError_1 = False
    try:
        dump(str_0, str_0, dict_0)
    except IOError:
        IOError_1 = True
    print('IOError_0: {}'.format(IOError_0))
    print('IOError_1: {}'.format(IOError_1))
    assert (IOError_0 == IOError_1)
    print('\n')


# Generated at 2022-06-25 15:39:46.610101
# Unit test for function dump
def test_dump():
    str_0 = 'test_dump'
    dict_0 = dict.fromkeys(['test_dump'], 'test_dump')
    str_0 = str(dict_0)
    str_0 = dump(str_0, str_0, dict_0)


# Generated at 2022-06-25 15:39:48.585126
# Unit test for function load
def test_load():
    assert load("test_case_0", "test_case_0") == {}


# Generated at 2022-06-25 15:39:54.059692
# Unit test for function load
def test_load():
    print("start load")
    replay_dir = "test"
    template_name = "cookiecutter.json"
    context = load(replay_dir, template_name)
    if context is not None:
        print("load is ok")
    if 'cookiecutter' in context:
        print("cookiecutter is ok")
    print("end load")
    return context


# Generated at 2022-06-25 15:40:01.157591
# Unit test for function load
def test_load():
    path = os.path.join(os.path.dirname(__file__), 'tests/files/')
    context = {
        'project_name': 'jsonloader',
        'repo_name': 'jsonloader',
        'full_name': 'Your Name',
        'email': 'your.email@example.com'
    }
    dump(path, 'test_case_0', context)
    test_case_0()


# Generated at 2022-06-25 15:40:07.313852
# Unit test for function load
def test_load():
    # Load JSON from str_0
    str_0 = 'test_case_0'
    var_0 = load(str_0, str_0)

    # Check if value of key 'cookiecutter' of var_0 is equal to '{"full_name": "John Doe", "email": "john.doe@example.com", "github_username": "john-doe"}'
    res_0 = var_0['cookiecutter'] == '{"full_name": "John Doe", "email": "john.doe@example.com", "github_username": "john-doe"}'

    # Check if value of key 'replay' of var_0 is equal to 'false'
    res_1 = var_0['replay'] == 'false'

    # Compare res_0 to True
    # assert res_0
   

# Generated at 2022-06-25 15:40:11.055026
# Unit test for function dump
def test_dump():
    dict_0 = {"cookiecutter": {"example_key_1": "some value", "example_key_2": "another value"}}
    str_0 = 'test_dump'
    dump(str_0, str_0, dict_0)


# Generated at 2022-06-25 15:40:50.889543
# Unit test for function load
def test_load():
    str_1 = 'test_case_1'
    var_1 = {'key_1': 'value_1'}
    dump(str_1, str_1, var_1)
    assert load(str_1, str_1) == var_1

    str_2 = 'test_case_2'
    var_2 = {'key_2': {'inner_key_2': 'inner_value_2'}}
    dump(str_2, str_2, var_2)
    assert load(str_2, str_2) == var_2

    str_3 = 'test_case_3'
    var_3 = {'key_3': ['value_3_a', 'value_3_b']}
    dump(str_3, str_3, var_3)

# Generated at 2022-06-25 15:41:00.089927
# Unit test for function load
def test_load():
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'

    replay_file_name = get_file_name(replay_dir, template_name)

    # test that file does not exist
    if os.path.exists(replay_file_name):
        os.remove(replay_file_name)

    # build context
    context = 'test_context'

    # test that context is not dict
    try:
        load(replay_dir, template_name)
    except TypeError as te:
        if str(te) != 'Context is required to be of type dict':
            raise
    else:
        raise AssertionError('Did not see expected exception')


# Generated at 2022-06-25 15:41:08.496412
# Unit test for function load
def test_load():

    # Test with already existing file
    test_file, test_file_name = '/tmp/file1', 'file1.json'
    with open(test_file, 'w') as f:
        f.write('{}')
    result = load(test_file, test_file_name)
    assert result == {}
    os.remove(test_file)

    # Test with non-existent file
    with open(test_file, 'r') as f:
        with pytest.raises(FileNotFoundError):
            load(test_file, test_file_name)
            assert os.path.exists(file=test_file)

    # Test with non-string context
    non_string_context = 123

# Generated at 2022-06-25 15:41:10.996165
# Unit test for function load
def test_load():
    with pytest.raises(TypeError):
        load('')
    with pytest.raises(TypeError):
        load('')
    with pytest.raises(ValueError):
        load('')


# Generated at 2022-06-25 15:41:13.580658
# Unit test for function load
def test_load():
    str_0 = "test load"
    assert load(str_0, str_0) is None
    print("Test successful")


# Generated at 2022-06-25 15:41:16.203309
# Unit test for function load
def test_load():
    str_0 = 'test_load'
    with pytest.raises(ValueError) as error:
        load(str_0, str_0)


# Generated at 2022-06-25 15:41:19.100332
# Unit test for function dump
def test_dump():
    str_0 = 'abc'
    dict_0 = {'abc': 'def'}
    dump(str_0, str_0, dict_0)


# Generated at 2022-06-25 15:41:24.791331
# Unit test for function load
def test_load():
    str_0 = 'test_case_0'
    var_0 = load(str_0, str_0)
    assert var_0 is not None


# Generated at 2022-06-25 15:41:26.840544
# Unit test for function dump
def test_dump():
    # str_0 = "test_case_0"
    # var_0 = dump(str_0, str_0)
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:41:35.239979
# Unit test for function load
def test_load():
    context = {
        'cookiecutter': {
            'name': 'Moo',
            'color': 'Cyan'
        }
    }
    template_name = 'test_case_0'
    dump(template_name, template_name, context)
    context_load = load(template_name, template_name)
    assert context['cookiecutter']['name'] == context_load['cookiecutter']['name']
    assert context['cookiecutter']['color'] == context_load['cookiecutter']['color']



# Generated at 2022-06-25 15:42:35.503804
# Unit test for function load
def test_load():
    assert load('replay', 'cookiecutter-pypackage') == context
    assert load('replay', 'cookiecutter-pypackage.json') == context


# Generated at 2022-06-25 15:42:38.985661
# Unit test for function dump
def test_dump():
    str_0 = 'test_dump'

    assert load({}, 'fail') == None

    assert load(str_0, str_0) == None
    assert dump(str_0, str_0, {'cookiecutter': {'a': 'b'}}) == None

    assert load(str_0, str_0) != None

    assert os.remove(get_file_name(str_0, str_0)) == None

# Generated at 2022-06-25 15:42:45.030744
# Unit test for function dump
def test_dump():
    str_0 = 'dump'
    str_1 = 'test_dump'
    dict_0 = dict()
    dict_0.__setitem__('cookiecutter', dict())
    dump(str_0, str_1, dict_0)


# Generated at 2022-06-25 15:42:46.884444
# Unit test for function load
def test_load():
    """Test load."""
    print(load.__doc__)
    # from cookiecutter import replay
    # replay.load()
    


# Generated at 2022-06-25 15:42:48.218060
# Unit test for function dump
def test_dump():
    var_0 = dump(str_0, str_0, str_0)


# Generated at 2022-06-25 15:42:55.671705
# Unit test for function dump
def test_dump():
    folder = 'my_folder'
    template_name = 'my_template'
    context = {'cookiecutter': {'template_name': template_name}}
    replay_dir = os.path.join('/', 'Users', 'username', '.cookiecutters')

    # Should try and make the replay dir
    dump(replay_dir, template_name, context)
    assert os.path.exists(replay_dir)

    # Should overwrite existing file
    context['cookiecutter']['something_else'] = 'foo'
    dump(replay_dir, template_name, context)

    # Should throw exception
    with pytest.raises(IOError) as err:
        dump('/Users/username/dies', template_name, context)



# Generated at 2022-06-25 15:43:01.145726
# Unit test for function load
def test_load():
    str_0 = 'test_case_1'
    replay_dir = '.'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert context['cookiecutter'].get('_template') == 'https://github.com/audreyr/cookiecutter-pypackage'
    assert context['cookiecutter'].get('full_name') == 'Audrey Roy Greenfeld'
    assert context['cookiecutter'].get('email') == 'audreyr@example.com'
    assert context['cookiecutter'].get('project_name') == 'My Package'
    assert context['cookiecutter'].get('project_slug') == 'my_package'
    assert context['cookiecutter'].get('use_pytest') == True
