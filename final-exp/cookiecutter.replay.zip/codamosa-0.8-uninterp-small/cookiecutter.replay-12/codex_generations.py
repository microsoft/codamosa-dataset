

# Generated at 2022-06-25 15:33:01.040044
# Unit test for function load
def test_load():
    replay_dir = 'test_files/replay'
    template_name = 'test_files\\test_cookiecutter.json'
    context = {}
    context['cookiecutter'] = 'test'
    dump(replay_dir, template_name, context)
    return load(replay_dir, template_name)


if __name__ == '__main__':
    print('Test function load, expected result: test, actual result: ')
    load_result = test_load()
    print(load_result['cookiecutter'])
    print()

# Generated at 2022-06-25 15:33:05.241737
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay', 'template') == 'replay/template.json'
    assert get_file_name('replay', 'template.json') == 'replay/template.json'



# Generated at 2022-06-25 15:33:09.294913
# Unit test for function load
def test_load():
    assert load("/tmp/test-cookiecutter-replay", "test.json") == {"cookiecutter" : "test"}

# Generated at 2022-06-25 15:33:19.415608
# Unit test for function load
def test_load():
    replay_dir = '/run/media/root/Buntu/workspace/pc-client/code/pc'
    template_name = '.'
    context = {'cookiecutter': {'project_name': 'pc', 'project_slug': 'pc', 'project_short_description': 'pc', 'author_name': 'Indradhanush Gupta', 'email': 'gupta.indradhanush@gmail.com', 'github_username': 'indradhanush', 'domain_name': 'github.com', 'version': '0.1.0', 'release': '0.1.0', 'timezone': 'Asia/Kolkata', 'open_source_license': 'BSD', 'pypi_username': 'indradhanush', 'use_pycharm': True}}

# Generated at 2022-06-25 15:33:22.357164
# Unit test for function load
def test_load():
    assert load(os.path.dirname(__file__), os.path.basename(__file__)) is not None


# Generated at 2022-06-25 15:33:29.601176
# Unit test for function dump
def test_dump():
    # Assert if the output of dump equals context
    template_name = "cookiecutter-pypackage"

# Generated at 2022-06-25 15:33:33.904346
# Unit test for function load
def test_load():
    if get_file_name(list_0, list_0):
        if str_0:
            if var_0:
                if list_0:
                    load(list_0, list_0)


# Generated at 2022-06-25 15:33:35.711137
# Unit test for function load
def test_load():
    dump('', '', {})
    load('', '')


# Generated at 2022-06-25 15:33:40.046446
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'replay')
    try:
        dump(replay_dir, 'unittest_replay', {'cookiecutter': {}})
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:33:45.841243
# Unit test for function dump
def test_dump():
    replay_dir = ''
    template_name = ''
    context = ''
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:33:52.710250
# Unit test for function load
def test_load():
    print('***************** unit test for function load *****************')
    replay_dir = os.getcwd() + '/test'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print(context)
    print('***************** end unit test *****************')


# Generated at 2022-06-25 15:33:57.253092
# Unit test for function load
def test_load():
    replay_dir = "./"
    template_name = "cookiecutter-pypackage"
    assert load(replay_dir, template_name)


# Generated at 2022-06-25 15:33:59.840954
# Unit test for function load
def test_load():
    str_0 = 'cookiecutter-pypackage'
    list_0 = load('/home/joseph/.cookiecutters', 'cookiecutter-pypackage')


# Generated at 2022-06-25 15:34:03.670497
# Unit test for function load
def test_load():
    rd = '/home/lucas/PycharmProjects/untitled/sites/cookiecutter-pypackage/test'
    tn = 'test.json'
    # result = load(rd,tn)
    # print(result)



# Generated at 2022-06-25 15:34:10.742996
# Unit test for function dump
def test_dump():
    template_name = 'cookiecutter-pypackage'
    replay_dir = '~/.cookiecutter_replay'

# Generated at 2022-06-25 15:34:12.547582
# Unit test for function dump
def test_dump():
    assert dump() == (str_0)



# Generated at 2022-06-25 15:34:21.712801
# Unit test for function load
def test_load():
    replay_dir = '/Users/jirongxiao/Documents/GitHub/cookiecutter-test/test_replay'
    template_name = 'cookiecutter-pypackage/{{cookiecutter.project_slug}}.json'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict), "return type is 1"
    assert len(context) == 1, "return size is 1"
    assert len(context['cookiecutter']) == 57, "return cookiecutter dict size is 57"
    assert 'project_slug' in context['cookiecutter'], "project_slug is in cookiecutter dict"
    assert 'project_short_description' in context['cookiecutter'], "project_short_description is in cookiecutter dict"

# Generated at 2022-06-25 15:34:25.905087
# Unit test for function load
def test_load():
    replay_0 = 'fake_dir'
    template_name_0 = 'cookiecutter-pypackage'
    # Call load
    load(replay_0, template_name_0)

# Generated at 2022-06-25 15:34:27.386649
# Unit test for function dump
def test_dump():
    assert dump(replay_dir, template_name, context) == '0'


# Generated at 2022-06-25 15:34:37.644220
# Unit test for function load
def test_load():
    test_case_0()

    # Test case where replay_dir is not provided
    replay_dir = None
    template_name = 'test'
    try:
        load(replay_dir, template_name)
        assert False
    except TypeError as e:
        assert str(e) == 'replay_dir is required to be of type str'

    # Test case where template_name is not provided
    replay_dir = 'replay'
    template_name = None
    try:
        load(replay_dir, template_name)
        assert False
    except TypeError as e:
        assert str(e) == 'Template name is required to be of type str'

    # Test case where template_name does not end with '.json'
    replay_dir = 'replay'
    template_name = 'test'
   

# Generated at 2022-06-25 15:34:42.075089
# Unit test for function load
def test_load():
    replay_dir = 'tests/files'
    template_name = 'cookiecutter-pypackage'
    load(replay_dir, template_name)


# Generated at 2022-06-25 15:34:45.131488
# Unit test for function load
def test_load():
    replay_dir = '~/Desktop'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    print("context is: ")
    print(context)

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-25 15:34:46.777641
# Unit test for function load
def test_load():
    # Unknown
    #assert load() == "Unknown"
    return


# Generated at 2022-06-25 15:34:49.860839
# Unit test for function load
def test_load():
    replay_dir = 'C:\\Code\\cookiecutter-pypackage\\tests\\test-replay\\'
    template_name = 'cookiecutter-pypackage.json'
    
    t = load(replay_dir, template_name)


# Generated at 2022-06-25 15:34:55.900232
# Unit test for function dump
def test_dump():
    str_0 = 'cookiecutter-pypackage'
    dict_0 = {"cookiecutter": {"project_slug": "cookiecutter-pypackage", "author_name": "Sayantha", "email": "sayanthagamage@gmail.com", "description": "A Python package", "open_source_license": "MIT", "command_line_interface": "Click", "version": "0.1.0", "use_pytest": "y", "add_travis": "y", "travis_python_versions": "3.6", "github_username": "SayanthaGamage"}}
    dump('/Users/sayanthagamage/projects/cookiecutter-pypackage', 'cookiecutter-pypackage', dict_0)


# Generated at 2022-06-25 15:35:00.475371
# Unit test for function load
def test_load():
    replay_dir = './'
    template_name = 'cookiecutter-pypackage'
    load(replay_dir, template_name)


# Generated at 2022-06-25 15:35:04.791358
# Unit test for function dump
def test_dump():
    pass



# Generated at 2022-06-25 15:35:12.848694
# Unit test for function dump
def test_dump():
    import json
    import tempfile
    import os

    replay_dir = tempfile.mkdtemp()
    template_name = 'cookiecutter-pypackage'
    replay_file = get_file_name(replay_dir, template_name)
    context = {'cookiecutter': {'_template': template_name}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(replay_file)
    with open(replay_file, 'r') as infile:
        c = json.load(infile)
    assert c == context


# Generated at 2022-06-25 15:35:26.130391
# Unit test for function load
def test_load():
    # Test case 0
    dump(os.path.expanduser('~/.cookiecutters'), 'cookiecutter-pypackage', {"cookiecutter":{"full_name": "Your Name", "email": "your_email@example.com"}})
    assert load(os.path.expanduser('~/.cookiecutters'), 'cookiecutter-pypackage') == {"cookiecutter":{"full_name": "Your Name", "email": "your_email@example.com"}}, 'Test case 0 failed'
    # Test case 1
    dump(os.path.expanduser('~/.cookiecutters'), 'cookiecutter-pypackage', {"cookiecutter":{"full_name": "Your Name", "email": "your_email@example.com"}})

# Generated at 2022-06-25 15:35:34.060106
# Unit test for function dump
def test_dump():
    # Sample input for function dump
    replay_dir = '~/cookiecutter-pypackage'
    template_name = 'cookiecutter-pypackage'
    context = 'cookiecutter'

    # Return type tests
    assert isinstance(dump(replay_dir, template_name, context), type(None))


# Generated at 2022-06-25 15:35:40.530689
# Unit test for function load

# Generated at 2022-06-25 15:35:46.488980
# Unit test for function load
def test_load():
    _str = '/tmp/test-cookiecutter-replay'
    _var = load(_str, _str)
    assert _var == {}
    # Test empty value, with type
    str_0 = '/tmp/test-cookiecutter-replay'
    assert load(str_0, str_0) == {}


# Generated at 2022-06-25 15:35:47.606551
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:35:55.955557
# Unit test for function load
def test_load():
    replay_dir = '/tmp/test-cookiecutter-replay'
    template_name = 'test_template'

    try:
        load(replay_dir, template_name)
    except ValueError:
        pass

    os.makedirs(replay_dir)
    replay_file = get_file_name(replay_dir, template_name)
    open(replay_file, 'w')

    try:
        load(replay_dir, template_name)
    except ValueError:
        pass

    context_dict = {'cookiecutter': {'name': 'test_name'}}
    with open(replay_file, 'w') as infile:
        json.dump(context_dict, infile, indent=2)

    loaded = load(replay_dir, template_name)
   

# Generated at 2022-06-25 15:35:57.549242
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:35:59.751061
# Unit test for function dump
def test_dump():
    if not hasattr(dumps, "__doc__"):
        print("Test dump: FAIL")
    else:
        print("Test dump: OK")


# Generated at 2022-06-25 15:36:08.494930
# Unit test for function dump
def test_dump():
    str_0 = '/tmp/test-cookiecutter-replay'
    dict_0 = {'cookiecutter': {'_template': str_0},
              'a': 'a',
              'b': 'b'}
    dict_1 = {'cookiecutter': {'_template': str_0},
              'a': 'a',
              'b': 'b'}
    test_dump = dump(str_0, str_0, dict_0)
    var_0 = load(str_0, str_0)
    assert dict_1 == var_0


# Generated at 2022-06-25 15:36:11.807329
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    str_1 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_1)
    assert var_0 == {}


# Generated at 2022-06-25 15:36:13.311489
# Unit test for function load
def test_load():
    print ('\n***** Start Test for function load *****')
    test_case_0()


# Generated at 2022-06-25 15:36:16.333628
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    str_1 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_1)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 15:36:19.216382
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:36:22.931168
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    str_1 = load(str_0, str_0)
    assert(str_1 == False)


# Generated at 2022-06-25 15:36:30.728130
# Unit test for function load
def test_load():
    os.environ['COOKIECUTTER_REPLAY_DIR'] = '/tmp'
    str_5 = 'test-cookiecutter-replay'
    test_case_0()

# Built-in function test
try:
    test_load()
except:
    print('Test Failed')
else:
    print('Test Passed')

# Built-in function test
try:
    test_load()
except:
    print('Test Failed')
else:
    print('Test Passed')

# Generated at 2022-06-25 15:36:34.276734
# Unit test for function dump
def test_dump():
    os.environ['COOKIECUTTER_REPLAY_DIR'] = '/tmp/test-cookiecutter-replay'
    context = {'cookiecutter': {'project_name': 'Test'}}
    dump('/tmp/test-cookiecutter-replay', 'Test', context)


# Generated at 2022-06-25 15:36:40.857279
# Unit test for function load
def test_load():
    t_0 = (('abc',), 0)
    t_1 = (('abc', 'abc'), 0)
    t_2 = (('abc', 'abc'), 0)

    a_0 = True
    t_0 = (a_0, 0)
    a_0 = False
    t_1 = (a_0, 0)
    a_0 = False
    t_2 = (a_0, 0)

    c_0 = context_get(t_0, t_1, t_2)
    d_0 = dict_get(c_0)
    t_0 = (d_0, 0)
    dump(c_0[0], c_0[1])

# Generated at 2022-06-25 15:36:46.259830
# Unit test for function load
def test_load():
    file_str = 'tests-from-staging'
    template_str = 'tests-from-staging'
    context = load(file_str, template_str)
    print(context)
    assert context == {
        'cookiecutter': {
            '_template': 'tests-from-staging'
        }
    }, "Should return the file contents"


# Generated at 2022-06-25 15:36:55.462400
# Unit test for function dump
def test_dump():
    # Make sure all required params are there
    required_params = [
        'replay_dir',
        'template_name',
        'context',
    ]
    for required_param in required_params:
        if required_param not in kwargs.keys():
            raise ValueError("Required parameter `{required_param}` not found as a keyword argument".format(required_param=required_param))

    replay_dir = kwargs.get('replay_dir', None)
    template_name = kwargs.get('template_name', None)
    context = kwargs.get('context', None)

    # Perform the logic
    demisto.results("Success")


# Generated at 2022-06-25 15:36:58.339524
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)
    assert var_0 == False, 'test_load failed'


# Generated at 2022-06-25 15:37:02.121935
# Unit test for function load
def test_load():
    print("Test load")
    test_case_0()

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-25 15:37:05.386251
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:37:10.973099
# Unit test for function dump
def test_dump():
    str_0 = 'test_str_0'
    var_0 = dump(str_0, str_0, str_0)
    test_case_0()


# Generated at 2022-06-25 15:37:19.756189
# Unit test for function dump
def test_dump():
    str_0 = '/tmp/test-cookiecutter-replay'

#     # Test if directory exists
#     try:
#         if not os.path.exists(str_0):
#             os.mkdir(str_0)
#     except Exception as exp:
#         print(exp.args)
#         assert exp.args[2] == errno.ENOENT
#         #assert exp.args[2] == errno.EEXIST
#         #assert exp.args[2] == errno.ENOTDIR

    # Test if context is a dictionary

# Generated at 2022-06-25 15:37:30.225595
# Unit test for function load
def test_load():
    dummy_replay_dir = '/tmp/test-cookiecutter-replay'
    dummy_template_name = 'test_load'

    template_dir = os.path.dirname(__file__)
    dummy_replay_file = os.path.join(
        template_dir,
        '..',
        '..',
        dummy_replay_dir,
        '{}.json'.format(dummy_template_name)
    )

    with open(dummy_replay_file, 'w') as outfile:
        json.dump({'cookiecutter': {'foo': 'bar'}}, outfile, indent=2)

    actual_context = load(dummy_replay_dir, dummy_template_name)

    assert actual_context == {'cookiecutter': {'foo': 'bar'}}

# Generated at 2022-06-25 15:37:34.115897
# Unit test for function load
def test_load():
    str_0 = '/tmp'
    str_1 = '/tmp'
    var_0 = get_file_name(str_0, str_0)
    var_1 = get_file_name(str_1, str_0)


# Generated at 2022-06-25 15:37:37.063719
# Unit test for function load
def test_load():
    str_1 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_1, str_1)


# Generated at 2022-06-25 15:37:38.939136
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:37:40.692750
# Unit test for function load
def test_load():
    assert False



# Generated at 2022-06-25 15:37:41.608580
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:37:45.641963
# Unit test for function load
def test_load():
    # Test if the function raises an exception for invalid type of parameter template_name (String)
    with pytest.raises(TypeError):
        test_case_0()



# Generated at 2022-06-25 15:37:53.412334
# Unit test for function load
def test_load():
    str_0 = '~'
    str_1 = '~'
    str_2 = '~'
    try:
        var_0 = load(str_0, str_1)
    except IOError:
        var_0 = True
        var_1 = load(str_0, str_2)
    assert var_0 == var_1

# Generated at 2022-06-25 15:38:01.183238
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)
    assert var_0 == {'cookiecutter': {'full_name': 'First Last', 'email': 'first@example.com'}}
    assert str_0 == '/tmp/test-cookiecutter-replay'


# Generated at 2022-06-25 15:38:04.895544
# Unit test for function dump
def test_dump():
    str_0 = '/tmp/test-cookiecutter-replay/test_dump'
    var_0 = dump(str_0, str_0, {'cookiecutter': {'key': 'value'}})
    assert os.path.exists(str_0 + '.json')


# Generated at 2022-06-25 15:38:13.304911
# Unit test for function dump
def test_dump():
    # Template name is required to be of type str
    try:
        replay_dir = "/tmp/test-cookiecutter-replay"
        template_name = 1
        context = {}
        res = dump(replay_dir, template_name, context)
    except TypeError:
        print("Error: Template name is required to be of type str")
    else:
        raise Exception("Expected to raise TypeError")
    # Context is required to be of type dict
    try:
        replay_dir = "/tmp/test-cookiecutter-replay"
        template_name = "/tmp/test-cookiecutter-replay-tmpl"
        context = None
        res = dump(replay_dir, template_name, context)
    except TypeError:
        print("Error: Context is required to be of type dict")
   

# Generated at 2022-06-25 15:38:15.404305
# Unit test for function load
def test_load():
    import unittest
    class TestLoad(unittest.TestCase):
        def test_load(self):
            pass
    unittest.main()

test_case_0()

# Generated at 2022-06-25 15:38:19.445883
# Unit test for function load
def test_load():
    os.environ['COOKIECUTTER_REPLAY_DIR'] = 'tests/fixtures/non-existent'
    try:
        load('tests/fixtures/non-existent', 'doesnt-exist-even-after-this-fixture')
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-25 15:38:22.939467
# Unit test for function dump
def test_dump():
    str_1 = 'template_name'
    str_2 = 'replay_dir'
    var_0 = dump(str_1, str_2, str_0)


# Generated at 2022-06-25 15:38:25.046593
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:38:27.804040
# Unit test for function load
def test_load():
    var_0 = '/tmp/test-cookiecutter-replay'
    try:
        var_1 = load(var_0, var_0)
    except:
        print('load failed')


# Generated at 2022-06-25 15:38:30.161462
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except Exception as err:
        print('Error: load did not pass unit test, error is {}'.format(err))



# Generated at 2022-06-25 15:38:31.781370
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 15:38:41.632852
# Unit test for function load
def test_load():
    str_0 = 0
    str_1 = '/tmp/test-cookiecutter-replay'
    str_2 = {
        'cookiecutter': {
            'full_name': 'Your name',
        }
    }
    dump(str_1, str_1, str_2)
    var_0 = load(str_1, str_1)
    if var_0 == str_2:
        str_0 += 1
    assert str_0 == 1
fixture_function_0()


# Generated at 2022-06-25 15:38:43.745883
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:38:53.968921
# Unit test for function load
def test_load():
    template_name = 'test'
    replay_dir = '/tmp/test-cookiecutter-replay'
    context = {
        'replay': True,
        'cookiecutter': {
            'full_name': 'Test full_name',
            'email': 'test@example.com',
            'github_username': 'test-github-username',
            'project_name': 'test-project-name',
        }
    }
    dump(replay_dir, template_name, context)
    assert context == load(replay_dir, template_name)

# Generated at 2022-06-25 15:38:56.226412
# Unit test for function load
def test_load():
    # Test 1
    str_0 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)

    assert str_0 == '/tmp/test-cookiecutter-replay'
    assert var_0 == {}


# Generated at 2022-06-25 15:38:59.560844
# Unit test for function dump
def test_dump():
    print('Testing function: dump.\n')
    test_case_0()
    print('')


# Generated at 2022-06-25 15:39:09.269819
# Unit test for function load
def test_load():
    template_name = 'test-cookiecutter'
    replay_dir = '/tmp'

    # Test no variables
    var_0 = {'cookiecutter': {}}
    dump(replay_dir, template_name, var_0)
    var_0 = load(replay_dir, template_name)
    assert var_0

    # Test simple variable
    var_1 = {'cookiecutter': {'project_name': 'foobar'}}
    dump(replay_dir, template_name, var_1)
    var_2 = load(replay_dir, template_name)
    assert var_2
    assert var_0 == var_1 == var_2

    # Test escaped variable
    var_3 = {'cookiecutter': {'project_name': 'foo\nbar'}}

# Generated at 2022-06-25 15:39:11.911808
# Unit test for function dump
def test_dump():
    template_name = '/tmp/test-cookiecutter-replay'
    context = {'cookiecutter': {'something': 'else'}}
    dump('/tmp/test-cookiecutter-replay', template_name, context)


# Generated at 2022-06-25 15:39:16.945041
# Unit test for function load
def test_load():
    # Input parameters
    replay_dir = '/tmp/test-cookiecutter-replay'
    template_name = '/tmp/test-cookiecutter-replay'

    # Call the function
    try:
        result = load(replay_dir, template_name)
    except TypeError:
        pass
    else:
        assert False, 'ExpectedTypeError'


# Generated at 2022-06-25 15:39:18.549955
# Unit test for function load
def test_load():
    assert True


# Generated at 2022-06-25 15:39:19.909549
# Unit test for function dump
def test_dump():
    """
    Test `dump` function.
    """
    dump('output', 'output', 'output')



# Generated at 2022-06-25 15:39:33.128671
# Unit test for function load
def test_load():
    # test 0
    try:
        test_case_0()
    except Exception:
        print('{{test_name}}')


# Generated at 2022-06-25 15:39:38.308212
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    str_0 = 'foo'
    int_0 = 0
    float_0 = 0.0
    var_0 = dump(str_0, str_0, str_0)
    var_1 = dump(str_0, str_0, int_0)
    var_2 = dump(str_0, str_0, float_0)


# Generated at 2022-06-25 15:39:39.118785
# Unit test for function load
def test_load():
    test_case_0()

# Generated at 2022-06-25 15:39:44.762906
# Unit test for function dump
def test_dump():
    str_0 = '/tmp/cookiecutter-replay'
    dict_0 = {1: '1'}
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()

    try:
        dump(str_0, str_0, var_0)
    except TypeError:
        pass
    except IOError:
        pass


# Generated at 2022-06-25 15:39:47.663203
# Unit test for function dump
def test_dump():
    str_0 = '/tmp/test-cookiecutterp-replay'
    var_0 = dump(str_0, str_0, dict())


# Generated at 2022-06-25 15:39:49.247014
# Unit test for function load
def test_load():
    # os.mkdir(str_0)
    test_case_0()



# Generated at 2022-06-25 15:39:54.730358
# Unit test for function dump
def test_dump():
    dump('test-cookiecutter-replay', 'test-cookiecutter-replay', {"cookiecutter":{"test_case_0":{"test_0":{"test_1":1}}}})
    pass


# Generated at 2022-06-25 15:39:55.709089
# Unit test for function dump
def test_dump():
    assert True


# Generated at 2022-06-25 15:39:57.474150
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)



# Generated at 2022-06-25 15:40:00.114668
# Unit test for function load
def test_load():
    # test case
    assert test_case_0

# Generated at 2022-06-25 15:40:24.310402
# Unit test for function dump
def test_dump():
    arg0 = 1
    arg1 = 1
    arg2 = 1
    assert dump(arg0, arg1, arg2) == None


# Generated at 2022-06-25 15:40:27.206837
# Unit test for function load
def test_load():
    str_0 = ''
    str_1 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)
    dump(str_1, str_1, str_1)


# Generated at 2022-06-25 15:40:36.785214
# Unit test for function dump
def test_dump():
    str_0 = '/tmp/test-cookiecutter-replay'
    dict_2 = {}
    dict_3 = {}
    dict_3['cookiecutter'] = dict_2
    dump(str_0, str_0, dict_3)
    dump(str_0, str_0, dict_3)
    dump(str_0, str_0, dict_3)
    dump(str_0, str_0, dict_3)
    dump(str_0, str_0, dict_3)
    dump(str_0, str_0, dict_3)
    dump(str_0, str_0, dict_3)
    dump(str_0, str_0, dict_3)
    dump(str_0, str_0, dict_3)

# Generated at 2022-06-25 15:40:37.840041
# Unit test for function load
def test_load():
    # Test for when the function raises an error
    pass


# Generated at 2022-06-25 15:40:48.010250
# Unit test for function load
def test_load():
    os.environ['TEST_COOKIECUTTER_REPLAY_DIR'] = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), 'fixtures'
    )
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-25 15:40:52.621689
# Unit test for function load
def test_load():
    var_1 = '/tmp/.cookiecutters'
    var_2 = '/tmp/.cookiecutters'
    var_3 = load(var_1, var_2)



# Generated at 2022-06-25 15:41:02.133282
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    str_1 = '/tmp/test-cookiecutter-replay/test-case-0.json'
    dict_0 = {}
    dict_0['cookiecutter'] = {
        '_template': 'test-case-0',
        'full_name': 'Your name',
        'email': 'Your email',
        'project_name': 'Hello World',
    }
    json_0 = json.dumps(dict_0)
    f_0 = open(str_1, 'w')
    f_0.write(json_0)
    var_0 = load(str_0, str_0)

# Generated at 2022-06-25 15:41:09.663169
# Unit test for function dump
def test_dump():
    str_0 = 'test-cookiecutter-replay'

# Generated at 2022-06-25 15:41:18.690440
# Unit test for function dump
def test_dump():
    import os
    import shutil
    import tempfile

    if os.path.exists('/tmp/test-cookiecutter-replay'):
        shutil.rmtree('/tmp/test-cookiecutter-replay')

    context = {
        'cookiecutter': {
            'project_dir': '/tmp',
            'project_name': 'test-cookiecutter-replay',
        }
    }

    dump('/tmp', 'test-cookiecutter-replay', context)

    assert os.path.exists('/tmp/test-cookiecutter-replay.json')

    shutil.rmtree('/tmp/test-cookiecutter-replay')



# Generated at 2022-06-25 15:41:25.006688
# Unit test for function load
def test_load():
    str_0 = '/tmp/test-cookiecutter-replay'
    str_1 = 'test-cookiecutter-replay'
    var_0 = load(str_0, str_1)


# Generated at 2022-06-25 15:42:24.114489
# Unit test for function load
def test_load():

    # Test of function load
    str_0 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:42:31.632303
# Unit test for function dump
def test_dump():
    pytest.raises(IOError, dump, '/tmp/test-cookiecutter-replay-01', '/tmp/test-cookiecutter-replay-01', {'cookiecutter': True})
    pytest.raises(TypeError, dump, '/tmp/test-cookiecutter-replay-02', '/tmp/test-cookiecutter-replay-02', {1: True})
    pytest.raises(TypeError, dump, '/tmp/test-cookiecutter-replay-03', {1: True}, {'cookiecutter': True})
    pytest.raises(ValueError, dump, '/tmp/test-cookiecutter-replay-04', '/tmp/test-cookiecutter-replay-04', {1: True})

# Generated at 2022-06-25 15:42:32.682087
# Unit test for function load
def test_load():
    assert callable(load)
    # raise NotImplementedError()


# Generated at 2022-06-25 15:42:35.939180
# Unit test for function load
def test_load():
    
    # Assigning arguments
    replay_dir = 'replica/replica_dir'
    template_name = 'temp/temp_name'

    # Call function
    function_returned = load(replay_dir, template_name)
    
    # Assertions
    assert function_returned is None
    
    

# Generated at 2022-06-25 15:42:40.491417
# Unit test for function load
def test_load():
    import json
    json_obj = json.loads('''{
        "cookiecutter": {
            "full_name": "Your name (or company/team/whatever)",
            "email": "Your email",
            "github_username": "GitHub username"
        }
    }''')
    # TODO: ModuleNotFoundError: No module named '_cffi_backend'
    # import pytest
    # with pytest.raises(RuntimeError) as err:
    #     dump('cookiecutter', 'cookiecutter', json_obj)
    # assert str(err.value) == 'this is a test'
    assert 1 == 1

# Generated at 2022-06-25 15:42:44.579075
# Unit test for function load
def test_load():
    """
    Test function load.
    """
    str_0 = '/tmp/test-cookiecutter-replay'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:42:47.126055
# Unit test for function load
def test_load():
    str_0 = os.path.join('fixtures','replay-test')
    var_0 = load(str_0, str_0)
    assert var_0 == {'cookiecutter': 'test'}


# Generated at 2022-06-25 15:42:49.888632
# Unit test for function load
def test_load():
    with pytest.raises(TypeError):
        load("str_0")
    with pytest.raises(TypeError):
        load("str_0", 42)
