

# Generated at 2022-06-25 15:32:57.678887
# Unit test for function dump
def test_dump():
    str_0 = '6A;A\x0b$w\x06\x1fu\x1a'
    str_1 = 'fh\x7f\x0e\x04\x0cq\x16\x1a'
    str_2 = 'z\x10\t\x0c\x06\x16\x1a'
    float_0 = 984.9197
    var_0 = json.dumps(str_0)
    dump(str_1, float_0, var_0)
    dump(str_2, float_0, var_0)


# Generated at 2022-06-25 15:33:01.507177
# Unit test for function dump
def test_dump():
    print('Test dump')
    replay_dir = 'output'
    template_name = 'some_key'
    context = {'key': 'value'}
    dump(replay_dir, template_name, context)
    replay_file = get_file_name(replay_dir, template_name)
    assert os.path.exists(replay_file)


# Generated at 2022-06-25 15:33:10.007860
# Unit test for function dump
def test_dump():
    f = open('test.json', 'r')
    data = json.load(f)
    f.close()
    dump('replay_tests', 'test_dump.json', data)

    f = open('replay_tests/test_dump.json', 'r')
    str_0 = ']|\x0bB+RSZVCn++$L['
    float_0 = -591.4822
    var_0 = load(str_0, float_0)
    assert(var_0 == data)
    os.remove('replay_tests/test_dump.json')

# Generated at 2022-06-25 15:33:19.589199
# Unit test for function get_file_name
def test_get_file_name():
    str_0 = '.\x08>\x85=\x94\x7f\x01'

# Generated at 2022-06-25 15:33:26.558369
# Unit test for function get_file_name
def test_get_file_name():
    str_0 = 'Cookiecutter #5\\0x5b\\x5d\\x5b\\x5c\\x5d\\x5b\\x5b\\x5d\\x5b'
    str_1 = ']][\\][[]'
    dict_0 = {'foo' : 'not bar'}
    dict_0['foo'] = 'bar'
    dict_1 = dump(str_0, str_1, dict_0)
    print(dict_1)


# Generated at 2022-06-25 15:33:35.308930
# Unit test for function dump
def test_dump():
    # Test 0 - json file should be created
    str_0 = ']|\x0bB+RSZVCn++$L['
    float_0 = -591.4822
    dict_0 = {}
    dict_0['cookiecutter'] = {}
    dict_0['cookiecutter']['xyz'] = 123
    dump(str_0, float_0, dict_0)
    var_0 = load(str_0, float_0)
    if dict_0 == var_0:
        print('SUCCESS 0: Replay file created and could be loaded')
    else:
        print('FAILED 0: Replayed file not loaded correctly')

# Generated at 2022-06-25 15:33:35.852556
# Unit test for function load
def test_load():
    assert True

# Generated at 2022-06-25 15:33:44.095442
# Unit test for function dump
def test_dump():
    str_0 = 'WRfmuO/'
    int_0 = 0
    list_0 = [1, 4, 6]
    var_0 = dump(str_0, int_0, list_0)
    assert var_0 == None
    var_1 = dump('XaJn$h', 2, list_0)
    assert var_1 == None
    float_0 = -1.7e-05
    list_0 = [24, 'u$hV:', 2.5]
    var_2 = dump('zW8_vh*', float_0, list_0)
    assert var_2 == None
    str_0 = '=fA9JSa'
    int_1 = 4
    list_0 = [1, '%iR', 7.5]

# Generated at 2022-06-25 15:33:45.413296
# Unit test for function dump
def test_dump():
    var_0 = dump('../files/', '..\\files/', '..\\files/')


# Generated at 2022-06-25 15:33:51.225603
# Unit test for function load
def test_load():
    str_0 = '[:A+&\x0bIjZa0U6C9uV'
    float_0 = 0.059030932
    #Test with a valid replay file
    load(str_0, float_0)
    #Test with invalid replay file
    load('Replay Files\\Test_Replay_2.json', float_0)
    #Test with invalid replay file name
    load(str_0, float_0)


# Generated at 2022-06-25 15:34:00.702518
# Unit test for function dump
def test_dump():
    path_0 = '.'
    str_0 = '.'
    dict_0 = {n: n for n in range(20)}
    str_1 = 'C:\\Users\\Pc\\Documents\\templates\\test'
    int_0 = os.path.isdir(str_1)
    if int_0 == 1:
        test_case_0()
        test_case_1()
        test_case_2()
        test_case_3()
    int_0 = os.path.isdir(str_1)


# Generated at 2022-06-25 15:34:05.237014
# Unit test for function load
def test_load():
    path = "../tests/files/replay/cookiecutter_replay_with_choices.json"
    with open(path, 'r') as infile:
        context = json.load(infile)

    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['project_name'] == 'foobar'


# Generated at 2022-06-25 15:34:06.010429
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-25 15:34:10.666301
# Unit test for function load
def test_load():
    template_name, replay_dir = '', ''
    var_0 = load(replay_dir, template_name)
    var_1 = load(replay_dir, template_name)
    assert var_0 == var_1


# Generated at 2022-06-25 15:34:18.556292
# Unit test for function load
def test_load():
    str_0 = 'Default answer is used if nothing was entered.\n    '
    var_0 = load(str_0, str_0)
    str_0 = 'Input answer is used if nothing was entered.\n    '
    var_1 = load(str_0, str_0)
    str_0 = 'Default answer is used if nothing was entered.\n    '
    var_0 = load(str_0, str_0)
    str_0 = 'Input answer is used if nothing was entered.\n    '
    var_1 = load(str_0, str_0)


# Generated at 2022-06-25 15:34:30.563370
# Unit test for function load
def test_load():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    str_1 = 'Cookiecutter will ask you for the values of these variables. It will then take\n    those values and use them to fill out the parts of the template surrounded\n    with {{}}.\n    '
    dict_0 = {'text': str_1, 'default': 'Y', 'type': 'confirm'}
    dict_1 = {'prompt': dict_0}
    dict_2 = {'text': 'This is the default project name.', 'default': 'cookiecutter-pypackage', 'type': 'string'}
    dict_3 = {'prompt': dict_2}

# Generated at 2022-06-25 15:34:33.661068
# Unit test for function get_file_name
def test_get_file_name():
    # Initialize
    replay_dir = "abc"
    template_name = "abc"

    # Expected results
    expected_result = "abc/abc.json"

    return expected_result == get_file_name(replay_dir, template_name)


# Generated at 2022-06-25 15:34:34.179289
# Unit test for function load
def test_load():
    pass

# Generated at 2022-06-25 15:34:40.294197
# Unit test for function load
def test_load():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    var_0 = load(str_0, str_0)
    var_1 = load(str_0, str_0)
    var_2 = load(str_0, str_0)
    assert var_0 is not var_1


# Generated at 2022-06-25 15:34:43.695832
# Unit test for function get_file_name
def test_get_file_name():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    assert get_file_name(str_0, str_0)


# Generated at 2022-06-25 15:34:50.900560
# Unit test for function get_file_name
def test_get_file_name():
    str_0 = 'Cookiecutter is a command-line utility that creates projects'
    str_1 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    var_0 = get_file_name(str_0, str_1)
    var_1 = get_file_name(str_0, str_0)
    assert (var_0 == str_0)
    assert (var_1 == str_1)


# Generated at 2022-06-25 15:34:53.317088
# Unit test for function load
def test_load():

    assert(load(str_0, str_0) == var_0)


# Generated at 2022-06-25 15:34:59.782868
# Unit test for function dump
def test_dump():
    """
    Unit test for function dump
    """
    template_name = "my_template"
    replay_dir = "test"
    context = { "cookiecutter": { "project_name": "my_project" }}
    expected_context = context
    expected_replay_dir = replay_dir
    assert dump(replay_dir, template_name, context) == None
    assert get_file_name(replay_dir, template_name) == expected_replay_dir, "dump failed to return expected value."
    os.remove(replay_dir)


# Generated at 2022-06-25 15:35:10.528582
# Unit test for function dump
def test_dump():
    path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    path += "/tests/"
    template = "cookiecutter-pypackage/"
    replay_dir = path + template + "_cookiecutter_replay/"
    file = get_file_name(replay_dir, "cookiecutter-pypackage")
    dump(file, file, {})


# Generated at 2022-06-25 15:35:16.389244
# Unit test for function get_file_name
def test_get_file_name():
    """
    This function tests the get_file_name function.
    """
    temp_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'tests'))
    assert get_file_name(temp_dir, 'template.json') == os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'template.json')
    )
    assert get_file_name(temp_dir, 'template') == os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'template.json')
    )

# Generated at 2022-06-25 15:35:27.272886
# Unit test for function load
def test_load():
    # Test for variable 'context'
    context = {'cookiecutter': {'full_name': 'Nemanja Avramovic'}}
    str_0 = '\nw/Cookie/foo_bar-test/{{full_name}}/test'
    var_0 = load(str_0, str_0)
    assert var_0 == context
    # Test for variable 'str_1'
    str_1 = '\nw/Cookie/foo_bar-test/{{full_name}}/test'
    context = {'cookiecutter': {'full_name': 'Nemanja Avramovic'}}
    var_0 = load(str_1, str_1)
    assert var_0 == context
    # Test for variable 'context'

# Generated at 2022-06-25 15:35:31.520608
# Unit test for function load
def test_load():
    var_0 = load(str, str)
    var_1 = load(str, str)


# Generated at 2022-06-25 15:35:39.196744
# Unit test for function load
def test_load():
    # Dummy function to be replaced.
    def dummy_function():
        pass

    # Creating a mock object to replace the function.
    dummy_function2 = Mock()

    # Replace the dummy function with the mock object.
    with patch('__main__.dummy_function', dummy_function2):
        dummy_function()

    # Make sure the mock object was called by asserting the call count to be 1.
    dummy_function2.assert_called_once()

    # Test the return value of the dummy function.
    assert dummy_function() == True, "Failed to call the dummy function."


# Generated at 2022-06-25 15:35:42.651715
# Unit test for function dump
def test_dump():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    str_1 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    dict_0 = {'cookiecutter': {str_1: {str_1: str_1}}}
    dump(str_0, str_1, dict_0)
    dict_0 = {'cookiecutter': {str_1: {str_1: str_1}}}
    dump(str_0, str_1, dict_0)


# Generated at 2022-06-25 15:35:46.950416
# Unit test for function load
def test_load():
    try:
        test_case_0()
        print('Test case 0: passed')
    except:
        print('Test case 0: error')


# Generated at 2022-06-25 15:35:53.871117
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except Exception as e:
        print("Test case failure detected.")

test_load()

# Generated at 2022-06-25 15:35:58.682929
# Unit test for function get_file_name
def test_get_file_name():
    assert not get_file_name('', 'dummy')
    assert not get_file_name('./', 'dummy')
    assert not get_file_name(r'\\\x', 'dummy')


# Generated at 2022-06-25 15:36:09.093331
# Unit test for function load
def test_load():
    input_0 = r'C:\Users\micha\AppData\Local\Temp\cct5UOT0.j2.py'
    input_1 = r'C:\Users\micha\AppData\Local\Temp\cct5UOT0.j2.py'
    expected_result = {
      "ansible_ssh_pass": "",
      "roles_path": "",
      "ansible_ssh_private_key_file": "",
      "username": "",
      "port": "",
      "ansible_ssh_user": ""
    }
    expected_type = dict

    assert type(load(input_0, input_1)) == expected_type
    assert load(input_0, input_1) == expected_result


# Generated at 2022-06-25 15:36:11.629581
# Unit test for function get_file_name
def test_get_file_name():
    str_0 = "\'./cookiecutter.json'"
    str_1 = "\'./cookiecutter.replay/cookiecutter.json\'"
    var_2 = get_file_name(str_0, str_1)
    str_2 = "\'./cookiecutter.replay/cookiecutter.json\'"
    assert var_2 == str_2

test_get_file_name()



# Generated at 2022-06-25 15:36:19.250515
# Unit test for function dump
def test_dump():
    # Make a temp folder
    current_working_dir = os.getcwd()
    temp_dir = os.path.join(current_working_dir, 'dump')
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)
    # Create a json file
    context = {'cookiecutter':
               {'full_name': 'Elle Green',
                'email': 'elle.green@example.com',
                'project_name': 'my_project',
                'repo_name': 'my_project',
                'project_short_description': 'A short description of the project.',
                'pypi_username': 'audreyr',
                'open_source_license': 'MIT license',
                'github_username': 'audreyr'}}
    json_

# Generated at 2022-06-25 15:36:23.691863
# Unit test for function load
def test_load():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    var_0 = load(str_0, str_0)
    assert var_0 == None


# Generated at 2022-06-25 15:36:31.738154
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name(replay_dir='./tests/files/replay', template_name='{{cookiecutter.repo_name}}') == './tests/files/replay/{{cookiecutter.repo_name}}.json'
    assert get_file_name(replay_dir='./tests/files/replay', template_name='{{cookiecutter.repo_name}}.json') == './tests/files/replay/{{cookiecutter.repo_name}}.json'


# Generated at 2022-06-25 15:36:36.236678
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay_dir', 'template_name') == 'replay_dir/template_name.json'
    assert get_file_name('replay_dir', 'template_name.json') == 'replay_dir/template_name.json'
    assert get_file_name('replay_dir', 'template_name.json.json') == 'replay_dir/template_name.json.json.json'


# Generated at 2022-06-25 15:36:46.975382
# Unit test for function load
def test_load():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    str_1 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    # fn_0 = get_file_name(str_0, str_1)
    # fn_1 = 'D:\\{}.json'.format(str_1)
    # assert fn_0 == fn_1

    str_2 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '

# Generated at 2022-06-25 15:36:50.952851
# Unit test for function load
def test_load():
    pass



# Generated at 2022-06-25 15:36:57.950119
# Unit test for function load
def test_load():
    var_1 = load(str_0, str_0)
    assert var_1 == {'cookiecutter': {'replay': True, 'no_input': True, 'extra_context': {'_copy_without_render': ['{{cookiecutter.project_name}}/{{cookiecutter.repo_name}}']}, 'abbreviations': {}}}


# Generated at 2022-06-25 15:37:09.403245
# Unit test for function load
def test_load():

    # PASS: Test if load is working correctly
    test_case_0()

    # PASS: Test if load is working correctly

# Generated at 2022-06-25 15:37:11.899506
# Unit test for function load
def test_load():
    assert callable(load)
    # Call function load with arguments str_0 and str_0
    test_case_0()


# Generated at 2022-06-25 15:37:16.351961
# Unit test for function load
def test_load():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:37:22.571245
# Unit test for function dump
def test_dump():
    with pytest.raises(RuntimeError):
        dump('Yes', 'No', 'Yes')
    with pytest.raises(TypeError):
        dump(['Yes', 'No'], 'No', 'Yes')
    with pytest.raises(ValueError):
        dump('Yes', 'No', ['Yes'])
    assert dump('Yes', 'No', {'Yes': 'No'}) is None


# Generated at 2022-06-25 15:37:27.238149
# Unit test for function dump
def test_dump():
    template_name = 'my-template'
    context = {
        'cookiecutter': {
            'key': 'value'
        }
    }
    replay_dir = 'replay'
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:37:27.985614
# Unit test for function load
def test_load():
    assert 1==0


# Generated at 2022-06-25 15:37:29.649661
# Unit test for function dump
def test_dump():
    test_case_0()
# }}}

# Generated at 2022-06-25 15:37:32.346040
# Unit test for function load
def test_load():
    """Build a list of test cases."""
    test_case_0()


# Generated at 2022-06-25 15:37:41.932890
# Unit test for function load
def test_load():
    str_1 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    str_2 = 'Writing to file %s'
    str_3 = 'Unable to create replay dir at %s'
    str_4 = 'Context is required to contain a cookiecutter key'
    str_5 = 'Template name is required to be of type str'
    str_6 = 'user_agent'
    str_7 = 'Invalid object'
    str_8 = 'keyboard'
    str_9 = 'Template name is required'
    var_1 = load(str_6, str_6)
    assert var_1 == str_7
    var_2 = load(str_8, str_8)
    assert var_2 == str_7
    var

# Generated at 2022-06-25 15:37:44.917999
# Unit test for function load
def test_load():
    assert 'existing_file' == load('file', 'file')


# Generated at 2022-06-25 15:37:45.902041
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-25 15:37:51.569927
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except Exception as err:
        print("Exception in test case 0:")
        raise err


# Generated at 2022-06-25 15:37:52.434375
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:37:54.949019
# Unit test for function load
def test_load():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:38:03.507764
# Unit test for function load
def test_load():
    # The str_0
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    # The var_0
    var_0 = load(str_0, str_0)
    assert var_0 is None
    # The str_1
    str_1 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    # The var_1
    var_1 = load(str_1, str_1)
    assert var_1 is None


# Generated at 2022-06-25 15:38:07.641856
# Unit test for function load
def test_load():
    var_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    var_1 = load(var_0, var_0)


# Generated at 2022-06-25 15:38:09.423872
# Unit test for function load
def test_load():
    assert callable(load)

if __name__ == '__main__':
    test_case_0()
    test_load()

# Generated at 2022-06-25 15:38:11.313247
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:38:20.507541
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = '.'
    result = load(replay_dir, template_name)
    assert isinstance(result, dict)
    replay_dir = '.'
    template_name = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    result = load(replay_dir, template_name)
    assert isinstance(result, dict)
    replay_dir = '.'
    template_name = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    result = load(replay_dir, template_name)
    assert isinstance(result, dict)
    replay_dir = '.'

# Generated at 2022-06-25 15:38:30.239394
# Unit test for function dump
def test_dump():
    #var_0 = get_file_name('/home/juanalvarez/repos/cookiecutter/tests/fixtures/my_template/.cookiecutter', None)
    replay_dir = '/home/juanalvarez/repos/cookiecutter/tests/fixtures/my_template/.cookiecutter'
    template_name = 'tests'
    context = {'cookiecutter': {u'full_name': u'Juan-Alvarez', u'project_name': u'Cookiecutter for testing', u'email': u'juan.alvarez@juanalvarez.net'}}
    var_0 = dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:38:31.882865
# Unit test for function load
def test_load():
    # Test #0
    ###
    test_case_0()



# Generated at 2022-06-25 15:38:35.221900
# Unit test for function load
def test_load():
    done = False
    while not done:
        try:
            test_case_0()
            done = True
        except (EOFError, KeyboardInterrupt):
            pass

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-25 15:38:37.750492
# Unit test for function load
def test_load():
    var_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    var_1 = dump(var_0, var_0, var_0)

# Generated at 2022-06-25 15:38:42.712715
# Unit test for function load
def test_load():
    import random

    # Test 1
    # Ensure that 'template_name' is a string
    try:
        load(str(random.random()), random.choice([1, 2, 3]))
    except TypeError:
        pass
    else:
        raise AssertionError('Failed test #1')

    # Test 2
    # Ensure that the returned context contains a 'cookiecutter' key
    try:
        load(str(random.random()), str(random.random()))
    except ValueError:
        pass
    else:
        raise AssertionError('Failed test #2')



# Generated at 2022-06-25 15:38:51.934453
# Unit test for function dump
def test_dump():
    print('testing dump')
    if os.path.exists('t3.json'):
        os.remove('t3.json')

    # Create the replay directory if it doesn't exist
    if os.path.exists('t2'):
        os.rmdir('t2')
    os.mkdir('t2')

    dump(
        't2',
        't3',
        {
            'cookiecutter': {
                '_copy_without_render': [],
                'full_name': 'foobar',
                'name': 'baz',
                'project_name': 'hook_test',
                'project_slug': 'hook_test'
            }
        }
    )

    assert os.path.exists('t2/t3.json')

# Generated at 2022-06-25 15:38:53.494996
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 15:39:04.330340
# Unit test for function dump
def test_dump():
	# Testing arguments in the first dump
	os.chdir('../../..')
	template_dir = os.getcwd()
	str_a = '- cookiecutter.json contains "default_context", and no replay_dir is given.'
	assert dump(str_a, str_a, var_0) is None
	# Testing arguments in the second dump
	str_b = 'You want to reuse the context from a previous run.\n\n    You want to modify the context from a previous run.\n    '
	str_c = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
	assert dump(str_b, str_b, var_0) is None
	# Testing arguments in the third dump

# Generated at 2022-06-25 15:39:05.702459
# Unit test for function load
def test_load():
    str_0 = '1'
    str_1 = "prompt_for_config"

    assert callable(load)


# Generated at 2022-06-25 15:39:11.775786
# Unit test for function load
def test_load():
    # prepare
    replay_dir = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    template_name = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '

    # execute
    try:
        context = load(replay_dir, template_name)
    except:
        raise AssertionError('Unexpected Exception')

    # assert
    assert(context['cookiecutter']['full_name'] == 'Your Name')
    assert(context['cookiecutter']['email'] == 'you@example.com')
    assert(context['cookiecutter']['project_name'] == 'Example Cookiecutter Project')

# Generated at 2022-06-25 15:39:21.235749
# Unit test for function dump
def test_dump():
    str_0 = 'buggy'
    str_1 = dump(str_0, str_0, str_0)
    assert str_1 == None
    str_0 = 'invalid'
    str_1 = dump(str_0, str_0, str_0)
    str_2 = 'unable'
    str_3 = 'create'
    str_4 = 'replay'
    str_5 = 'dir'
    str_6 = 'at'
    assert str_1 == IOError('{} to {} {} {} {} {} {}'.format(str_2, str_3, str_4, str_5, str_6, str_0, str_0))


# Generated at 2022-06-25 15:39:23.317918
# Unit test for function dump
def test_dump():
	assert load() == 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '

# Generated at 2022-06-25 15:39:24.486226
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except:
        pass

# Generated at 2022-06-25 15:39:28.315519
# Unit test for function dump
def test_dump():

    try:
        dump(str_0, str_0, var_0)
    except IOError as error_msg:
        print(error_msg)


# Generated at 2022-06-25 15:39:30.136780
# Unit test for function load
def test_load():
    test_case_0()


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-25 15:39:31.031860
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:39:34.043122
# Unit test for function load
def test_load():
    var_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    assert callable(test_case_0)



# Generated at 2022-06-25 15:39:42.354366
# Unit test for function load
def test_load():
    # Create a dict to be dumped to json and then loaded back.
    orig_dict = {'a': 1, 'b': 2, 'c': {'a': 0, 'b': 3}, 'd': [1, 2, 3]}
    # Create a test dict to compare to.
    test_dict = {'a': 1, 'b': 2, 'c': {'a': 0, 'b': 3}, 'd': [1, 2, 3]}
    dict_path = os.path.join(os.getcwd(), 'test_dict.json')

    # Make sure that loading raises an error when the file path to load is missing.
    # assertRaises is in the standard Python unittest library.
    with open(dict_path, 'w') as dict_file:
        json.dump(orig_dict, dict_file)

# Generated at 2022-06-25 15:39:43.088755
# Unit test for function dump
def test_dump():
    assert dump == dump


# Generated at 2022-06-25 15:39:50.070767
# Unit test for function load
def test_load():
    # Create an empty file
    f = open('test_load_file.txt', 'w')
    f.close()
    try:
        # Test if it throws exception when loading empty file
        load('test_load_file.txt', 'test_load')
        # If exception is not thrown then test case fails
        assert False
    except ValueError:
        # Exception is thrown so test case passes
        assert True
    finally:
        # Cleanup the file created for test
        os.remove('test_load_file.txt')


# Generated at 2022-06-25 15:39:56.457666
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:40:00.375747
# Unit test for function load
def test_load():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '


# Generated at 2022-06-25 15:40:03.910583
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join(os.path.curdir, 'replay')
    template_name = 'foobar'
    context = {
        'cookiecutter': {
            'author_name': 'author'
        }
    }
    dump(replay_dir, template_name, context)



# Generated at 2022-06-25 15:40:10.455874
# Unit test for function load
def test_load():
    with raises(TypeError):
        var_1 = load(str, str)

    with raises(ValueError):
        var_1 = load(str, str)

    with raises(TypeError):
        var_1 = load(str, str)

    with raises(ValueError):
        var_1 = load(str, str)


# Generated at 2022-06-25 15:40:11.162612
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:40:11.919834
# Unit test for function load
def test_load():
    assert True


# Generated at 2022-06-25 15:40:18.273643
# Unit test for function dump
def test_dump():
    # Setup
    set_0 = set()
    lst_0 = []
    lst_0.append(set_0)
    str_0 = 'The quick brown fox jumps over the lazy dog.'
    int_0 = 4
    str_1 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    dict_0 = {}
    dict_0.update(str_0='The quick brown fox jumps over the lazy dog.')
    dict_0.update(int_0=4)
    dict_0.update(str_1='Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    ')
    dict_0.update(dict_0={})

# Generated at 2022-06-25 15:40:26.130394
# Unit test for function load
def test_load():
    dict_0 = {
        'static': 'website', 
        'cookiecutter': {
            '_template': 'repository', 
            'project_name': 'Awesome Project', 
            'project_slug': 'awesome_project', 
            'year': '2017', 
            'version': '0.1.0', 
            'repository_name': 'awesome_project', 
            'author_name': 'Dave', 
            'email': 'dave@dave.com', 
            'description': 'An awesome project.', 
            'domain_name': 'example.com', 
            'use_docker': False
        }
    }

# Generated at 2022-06-25 15:40:35.326439
# Unit test for function load
def test_load():
    var_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    var_1 = load(var_0, var_0)
    assert var_1 == {'cookiecutter': {'config_file': 'False', 'default_context': 'False', 'no_input': 'False', 'output_dir': 'False', 'replay': 'False', 'verbose': 'False', 'extra_context': '{}'}}
    byte_0 = bytearray(0)
    var_1 = load(byte_0, byte_0)

# Generated at 2022-06-25 15:40:41.395249
# Unit test for function load
def test_load():
    # Test 1: If the template name is not of type str
    # Expected result: Raise a TypeError exception
    try:
        int_0 = 0
        load(int_0, int_0)
    except TypeError:
        pass
    # Test 2: If the context is not of type dict
    # Expected result: Raise a TypeError exception
    try:
        str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
        var_0 = load(str_0, str_0)
    except TypeError:
        pass
    # Test 3: If cookiecutter is not in the context
    # Expected result: Raise a ValueError exception

# Generated at 2022-06-25 15:40:54.531066
# Unit test for function load
def test_load():
    # Test 1
    replay_dir_1 = "Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    "
    template_name_1 = "Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    "
    context_1 = load(replay_dir_1, template_name_1)
    assert type(context_1) == type({})
    # Test 2
    replay_dir_2 = "Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    "
    template_name_2 = "KeyError"
    context_2 = load(replay_dir_2, template_name_2)

# Generated at 2022-06-25 15:41:03.588606
# Unit test for function dump
def test_dump():
    str_0 = 'prompt_user_with_a_set_of_options_to_choose_from_0001'
    list_0 = [('_id', None), ('age', 'int'), ('date_created', 'datetime'), ('first_name', 'str'), ('last_name', 'str'), ('tags', 'list'), ('manager', 'str'), ('user_id', 'str'), ('_id', None), ('date_created', 'datetime'), ('last_edited', 'datetime'), ('content', 'str')]
    str_1 = 'user'

# Generated at 2022-06-25 15:41:11.027668
# Unit test for function dump
def test_dump():
    str_0 = 'Simple json file.'
    str_1 = 'cookiecutter.context.Context "CookiecutterContext" is read-only'
    str_2 = 'test_dump'
    var_0 = 'Tried to modify the Context of a Context derived from a read-only Context.'
    int_0 = 6
    str_3 = '{{cookiecutter.underline_1}}'
    str_4 = '_'
    str_5 = '{{cookiecutter.underline_4}}'
    str_6 = '{{cookiecutter.underline_5}}'
    str_7 = '{{cookiecutter.slug}}'
    str_8 = '{{cookiecutter.author_email}}'
    str_9 = '{{cookiecutter.email}}'

# Generated at 2022-06-25 15:41:21.503468
# Unit test for function dump

# Generated at 2022-06-25 15:41:25.714407
# Unit test for function load
def test_load():
    assert 1==1


# Generated at 2022-06-25 15:41:32.294833
# Unit test for function load
def test_load():
    var_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    assert callable(load)
    assert isinstance(load(var_0, var_0), dict)


# Generated at 2022-06-25 15:41:37.952121
# Unit test for function load
def test_load():

    str_0 = '/home/vagrant/builds/cookiecutter/tests'
    var_0 = load(str_0, str_0)
    str_1 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    var_1 = load(str_1, str_1)
    str_2 = '/home/vagrant/builds/cookiecutter/tests'
    var_2 = load(str_2, str_2)
    str_3 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    var_3 = load(str_3, str_3)

# Generated at 2022-06-25 15:41:40.807819
# Unit test for function load
def test_load():
    var_0 = str
    var_1 = 'This is a the prompt string.'
    var_2 = load(var_0, var_1)



# Generated at 2022-06-25 15:41:44.434587
# Unit test for function load
def test_load():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:41:54.523768
# Unit test for function dump
def test_dump():
    # Test cases
    try:
        str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
        load(str_0, str_0)
    except Exception as e:
        print(e)
    try:
        str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
        load(str_0, str_0)
    except Exception as e:
        print(e)
    try:
        str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
        load(str_0, str_0)
    except Exception as e:
        print

# Generated at 2022-06-25 15:42:07.111554
# Unit test for function dump
def test_dump():
    str_0 = 'Unable to create replay dir at {replay_dir}'
    str_1 = '.json'
    var_0 = 'Unable to create replay dir at {replay_dir}'
    var_1 = '.json'
    var_2 = 'Template name is required to be of type str'
    var_3 = 'Context is required to be of type dict'
    var_4 = 'Context is required to contain a cookiecutter key'
    var_5 = '{}{}'
    str_2 = 'TestTemplate'
    var_6 = { }
    var_7 = load(str_2, var_6)
    var_8 = dump(str_2, var_6, var_7)



# Generated at 2022-06-25 15:42:11.598735
# Unit test for function load
def test_load():
    print("\nTesting load()")
    try:
        test_case_0()
    except ValueError:
        pass
    except TypeError:
        pass


# Generated at 2022-06-25 15:42:13.693896
# Unit test for function dump
def test_dump():
    assert dump(str_0, str_0, var_0) == None


# Generated at 2022-06-25 15:42:14.658740
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:42:22.190748
# Unit test for function load
def test_load():
    assert not load(
        'Hello, World!',
        'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    ')
    assert load(
        'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    ',
        'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    ')
    assert not load(
        'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    ',
        'Hello, World!')
    assert not load(
        'Hello, World!',
        'Hello, World!')
    test_case_0()

#

# Generated at 2022-06-25 15:42:24.502288
# Unit test for function load
def test_load():
    """
    load function test.

    :return: None
    """
    os.chdir(os.getcwd())
    test_case_0()


# Generated at 2022-06-25 15:42:27.401163
# Unit test for function load
def test_load():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    str_1 = str_0
    assert str_1 == str_0


# Generated at 2022-06-25 15:42:31.170954
# Unit test for function load
def test_load():
    assert not os.path.exists(u'.')
    assert not os.path.exists(u'.')
    assert not os.path.exists(u'.')
    assert not os.path.exists(u'.')
    assert not os.path.exists(u'.')
    assert not os.path.exists(u'.')
    return


# Generated at 2022-06-25 15:42:35.333414
# Unit test for function load
def test_load():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    try:
        load(str_0, str_0)
    except IOError:
        print("FAIL: IOError")
    try:
        load(str_0, str_0)
    except ValueError:
        print("FAIL: ValueError")


# Generated at 2022-06-25 15:42:35.921891
# Unit test for function load
def test_load():
    assert True == True


# Generated at 2022-06-25 15:42:53.641506
# Unit test for function load
def test_load():
    str_0 = 'Prompt user with a set of options to choose from.\n\n    Each of the possible choices is rendered beforehand.\n    '
    try:
        load(str_0, str_0)
    except TypeError:
        print('TypeError caught as expected')
    try:
        load(str_0, str_0)
    except ValueError:
        print('ValueError caught as expected')
