

# Generated at 2022-06-25 15:33:07.749458
# Unit test for function load
def test_load():
    # Test function call
    template_name = './test/fixtures/fake-repo-tmpl.json'
    replay_dir = './test/fixtures/fake-repo'
    #noinspection PyTypeChecker
    assert (load(replay_dir, template_name)) is not None, \
        '"load" function not returning value'


# Generated at 2022-06-25 15:33:10.286824
# Unit test for function load
def test_load():
    # Assertion Error if context is required to contain a cookiecutter key
    with pytest.raises(ValueError, message='Context is required to contain a cookiecutter key'):
        load('replay_dir', 'template_name')


# Generated at 2022-06-25 15:33:13.881740
# Unit test for function load
def test_load():
    name_0 = 'context'
    name_1 = 'cookiecutter'

    assert func_0(name_0, name_0) == 'cookiecutter'

# Generated at 2022-06-25 15:33:14.942719
# Unit test for function load
def test_load():
    print('Testing function load')
    assert load('replay_dir', 'template_name') == None



# Generated at 2022-06-25 15:33:22.049731
# Unit test for function dump
def test_dump():
    replay_dir = os.path.abspath('test')
    template_name = 'test.json'
    context = {
        "cookiecutter": {
            "author_email": "dummy@example.com",
            "author_name": "dummy",
            "description": "test",
            "full_name": "test",
            "open_source_license": "MIT",
        }
    }
    replay_file = get_file_name(replay_dir, template_name)
    dump(replay_dir, template_name, context)
    try:
        assert os.path.exists(replay_file)
    except AssertionError:
        print(replay_file)
    os.remove(replay_file)



# Generated at 2022-06-25 15:33:24.893640
# Unit test for function get_file_name
def test_get_file_name():
    # Test 1
    replay_dir = "test/"
    template_name = "test"
    result = get_file_name(replay_dir, template_name)
    assert result == "test/test.json"


# Generated at 2022-06-25 15:33:28.703769
# Unit test for function dump
def test_dump():
    """Test function dump."""
    # Define a dictionary
    dictionary = {
        "cookiecutter": {
            "aaa": "bbb"
        }
    }
    # Define a string
    string = "."
    # Invoke dump
    dump(dictionary, string, dictionary)


# Generated at 2022-06-25 15:33:38.966923
# Unit test for function load
def test_load():
    import json
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a valid replay file
    template_name = 'test_template'
    replay_dir = os.path.join(temp_dir, 'replay')
    replay_file = get_file_name(replay_dir, template_name)


# Generated at 2022-06-25 15:33:39.965614
# Unit test for function dump
def test_dump():
    assert callable(dump)


# Generated at 2022-06-25 15:33:49.425676
# Unit test for function load
def test_load():
    from hypothesis import given
    from hypothesis.strategies import dictionaries, text
    from hypothesis.strategies import composite
    from hypothesis.strategies import lists

    @composite
    def dict_files(draw):
        key_value_pairs = draw(lists(dictionaries(text(), text(), min_size = 1), min_size = 1))
        key_value_pairs.append({"cookiecutter": "cookiecutter"})
        return key_value_pairs

    @given(dict_files())
    def test_load(dict_file):
        load(dict_file, 'test')

test_case_0()

# Generated at 2022-06-25 15:34:02.883930
# Unit test for function dump
def test_dump():
    context = {}
    cookiecutter = {}
    context['cookiecutter'] = cookiecutter
    cookiecutter['config_file'] = 'test_0/cookiecutter.json'
    cookiecutter['context_file'] = 'test_0/cookiecutter.json'
    cookiecutter['no_input'] = True
    cookiecutter['replay'] = True
    cookiecutter['overwrite_if_exists'] = True
    cookiecutter['output_dir'] = './test_output'
    cookiecutter['default_config'] = {}
    cookiecutter['extra_context'] = {}
    cookiecutter['abbreviations'] = {}
    cookiecutter['skip_if_file_exists'] = []
    cookiecutter['context_key'] = 'cookiecutter'

# Generated at 2022-06-25 15:34:05.353018
# Unit test for function dump
def test_dump():
    load_0 = load(None, None)
    load_1 = load(None, 'test')
    load_2 = load(None, load_1)
    assert(load_2 == load_0)

# Generated at 2022-06-25 15:34:07.407182
# Unit test for function dump
def test_dump():
    replay_dir = 'data/replay'
    template_name = 'test'
    context = {'cookiecutter': {'repo_dir': 'project', 'project_name': 'project_1'}}
    dump(replay_dir, template_name, context)



# Generated at 2022-06-25 15:34:11.514785
# Unit test for function load
def test_load():
    print('Function load:')
    try:
        test_case_0()
    except Exception as e:
        print('\t', e)


# Generated at 2022-06-25 15:34:15.614238
# Unit test for function load
def test_load():
    assert load('/Users/alec.zhang/Documents/cookiecutter-django/example_repo_template/', '{{cookiecutter.repo_name}}')['cookiecutter']['repo_name'] == 'example_repo_template'


# Generated at 2022-06-25 15:34:22.552986
# Unit test for function dump
def test_dump():    
    replay_dir = 'D:/cookiecutter-test/'
    template_name = 'test'
    context = {
        'cookiecutter': {'image_base_name': 'ubuntu'},
        'user': {'full_name': 'keikakubot'},
        'project': {'license': 'MIT', 'repo_name': 'my_project'}
    }
    dump(replay_dir, template_name, context)
    print("Succeeded dump")


# Generated at 2022-06-25 15:34:26.921954
# Unit test for function dump
def test_dump():
    json_0 = {'test_0':'test_1'}
    replay_dir = 'D:\\Graduate\\Graduate_Design\\Cookiecutter\\test\\'
    template_name = 'test_case_0'
    dump(replay_dir, template_name, json_0)


# Generated at 2022-06-25 15:34:31.315594
# Unit test for function load
def test_load():
    replay_dir = './'
    template_name = 'template_name'
    context = {}
    context['cookiecutter'] = {}
    context['cookiecutter']['replay'] = {}
    context['cookiecutter']['replay']['foo'] = 'bar'
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-25 15:34:38.477409
# Unit test for function load
def test_load():
    test_replay_dir = './'
    test_template_name = './'
    test_load(test_replay_dir, test_template_name)
    test_replay_dir = './'
    test_template_name = './1.json'
    test_load(test_replay_dir, test_template_name)
    test_replay_dir = './'
    test_template_name = './1.py'
    test_load(test_replay_dir, test_template_name)
    test_replay_dir = './1.json'
    test_template_name = './'
    test_load(test_replay_dir, test_template_name)
    test_replay_dir = './1.json'

# Generated at 2022-06-25 15:34:41.959473
# Unit test for function load
def test_load():
    make_sure_path_exists('/tmp/cookiecutter-test/')
    dump('/tmp/cookiecutter-test/', 'test', {'cookiecutter': {'test_key': 'test_value'}})
    assert load('/tmp/cookiecutter-test/', 'test')

# Generated at 2022-06-25 15:34:48.753315
# Unit test for function dump
def test_dump():
    str_0 = 'test'
    os.mkdir(str_0)
    dic_0 = {'cookiecutter': 'True'}
    dump(str_0, 'test', dic_0)
    dic_1 = load(str_0, 'test')
    assert(dic_0 == dic_1)
    os.remove(str_0 + '/test.json')
    os.rmdir(str_0)


# Generated at 2022-06-25 15:34:51.362293
# Unit test for function load
def test_load():
    template_name = "str_0"
    result = load(__file__.split('.')[0],template_name)
    expected = "test"
    print(result)
    #assert result == expected


# Generated at 2022-06-25 15:34:56.013550
# Unit test for function load
def test_load():
    template_name = 'test'
    replay_dir = 'tests/test-output/replay/'
    context = load(replay_dir, template_name)
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Packaging'


# Generated at 2022-06-25 15:35:01.935916
# Unit test for function load
def test_load():
    replay_dir = 'tests/files/'
    template_name = 'b'
    context = load(replay_dir, template_name)
    assert context['full_name'] == 'John Smith'


# Generated at 2022-06-25 15:35:07.517466
# Unit test for function load
def test_load():
    tst_sp = os.path.join('tests', 'test-replay')
    replay_dir = os.path.join(tst_sp, 'replay')
    template_name = 'replay'
    context = {u'cookiecutter': {u'pytest_option': u'', u'python_interpreter': u'python3', u'project_name': u'replay', u'author_name': u'Chuhsiang Kuan', u'replay': u'y', u'package_name': u'replay'}}
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context

# Generated at 2022-06-25 15:35:09.159604
# Unit test for function load
def test_load():
    replay_dir = "../"
    template_name= 'test'
    context = load(replay_dir, template_name)
    assert 0


# Generated at 2022-06-25 15:35:12.542086
# Unit test for function dump
def test_dump():
    replay_dir = 'test_replay_dir'
    template_name = 'test_template_name'
    context = {
        'test_context': 'test_context_value'
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:35:16.744828
# Unit test for function dump
def test_dump():
    dump('d:\\replay_dir\\', 'test', {'name': 'zhangsan'})


# Generated at 2022-06-25 15:35:23.959061
# Unit test for function load
def test_load():
    replay_dir = 'replay_dir'
    template_name = 'aligulac'
    result = load(replay_dir,template_name)
    if 'cookiecutter' in result:
        print('cookiecutter key found in result')
    else:
        print('cookiecutter key not found in result')
    if isinstance(result, dict):
        print('result is of type dict')
    else:
        print('result is not of type dict')


# Generated at 2022-06-25 15:35:30.782753
# Unit test for function load
def test_load():
    # Test case 1 : test successfully
    """
    __test_1_replay_dir = r'./test/test_replay_dir'
    __test_1_template_name = r'test_name'
    __test_1_context = {
        'cookiecutter': {
            'author': 'test_name',
            'author_email': 'test@gmail.com'
        }
    }
    dump(__test_1_replay_dir, __test_1_template_name, __test_1_context)
    assert load(__test_1_replay_dir, __test_1_template_name) == __test_1_context
    """

    # Test case 2 : fail - template_name is not type of str

# Generated at 2022-06-25 15:35:41.551356
# Unit test for function dump
def test_dump():
    import os
    import time
    import shutil
    from cookiecutter.config import DEFAULT_CONFIG
    template_dir = os.path.dirname(os.path.dirname(__file__))
    replay_dir = os.path.join(template_dir, 'test_replay_dir')
    template_name = 'test_template'
    context = {'cookiecutter': DEFAULT_CONFIG}
    # check Dir is valid
    assert os.path.exists(template_dir)
    assert 1 == os.path.isdir(template_dir)
    # check file is not exist
    assert 0 == os.path.exists(replay_dir)
    # create Dir
    if not os.path.exists(replay_dir):
        os.mkdir(replay_dir)
    #

# Generated at 2022-06-25 15:35:47.167559
# Unit test for function load
def test_load():
    template_name = 'test'
    replay_dir = '/home/pi/git/py-master/py-101/py-101/cookiecutter-python'
    context = load(replay_dir, template_name)
    print(context)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-25 15:35:49.844995
# Unit test for function load
def test_load():
    assert callable(load)
    assert isinstance(load(test_case_0(),test_case_0()), dict)
 # Unit test for function load

# Generated at 2022-06-25 15:35:57.816618
# Unit test for function load
def test_load():
    replay_dir = './'
    template_name = 'test'
    context = {'cookiecutter': {'project_name': 'test'}}
    dump(replay_dir, template_name, context)
    load(replay_dir, template_name)

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-25 15:36:02.296691
# Unit test for function load
def test_load():

    if load('/Users/sai/cookiecutter-templates/',str_0) is not None:
        print('test_load is passed')
    else:
        print('test_load is failed')


# Generated at 2022-06-25 15:36:11.543379
# Unit test for function dump

# Generated at 2022-06-25 15:36:15.449501
# Unit test for function load
def test_load():
    # Get json information from file
    context = load(os.getcwd(), 'test_context')
    assert context.get('cookiecutter') == {'test_cookiecutter': str_0}


# Generated at 2022-06-25 15:36:18.247590
# Unit test for function load
def test_load():
    assert load(replay_dir='./tests/files/replay', template_name='fake_repo_pre/') != {}
    test_case_0()
    print('All tests completed successfully!')



# Generated at 2022-06-25 15:36:20.704976
# Unit test for function load
def test_load():
    assert True


# Generated at 2022-06-25 15:36:24.247175
# Unit test for function dump
def test_dump():
    # test case 0
    replay_dir = ''
    template_name = ''
    context = ''
    result_0 = dump(replay_dir, template_name, context)
    assert result_0 == None


# Generated at 2022-06-25 15:36:32.873823
# Unit test for function load
def test_load():
    assert callable(load)
    str_0 = 'L(/kO4?F2'
    var_0 = load(str_0, str_0)
    assert type(var_0) is dict
    bool_0 = bool(0)
    try:
        var_0 = load(str_0, bool_0)
    except TypeError:
        var_1 = True
    else:
        assert False
    str_1 = 'yo'
    assert str_0 is str_1


# Generated at 2022-06-25 15:36:33.721907
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:36:36.784570
# Unit test for function load
def test_load():
    str_0 = 'L(/kO4?F2'
    var_0 = load(str_0, str_0)
    var_1 = load(str_0, str_0)
    assert var_0 == var_1, """Failed test for function load."""


# Generated at 2022-06-25 15:36:40.816959
# Unit test for function dump
def test_dump():
    replay_dir = 'replay'
    template_name = 'foo'
    context = {'cookiecutter': {'name': 'foo', 'version': '1.0'}}
    dump(replay_dir, template_name, context)

    # Try it again to make sure it didn't use the wrong context
    context = {'cookiecutter': {'name': 'bar', 'version': '2.0'}}
    dump(replay_dir, template_name, context)
    assert True



# Generated at 2022-06-25 15:36:51.254951
# Unit test for function load

# Generated at 2022-06-25 15:36:53.111880
# Unit test for function load
def test_load():
    str_0 = 'L(/kO4?F2'
    var_0 = load(str_0, str_0)

# Generated at 2022-06-25 15:37:02.023251
# Unit test for function load
def test_load():
    # Setup test data
    replay_dir = '.cookiecutters_replay'
    template_name = 'cookiecutter-pypackage'


# Generated at 2022-06-25 15:37:03.378414
# Unit test for function dump
def test_dump():
    var_0 = load('cookiecutter')


# Generated at 2022-06-25 15:37:08.988512
# Unit test for function dump
def test_dump():
    data = {
        'a': 'b'
    }

    os.system('rm -rf tmp_replay_dir')
    dump('tmp_replay_dir', 'hello', data)
    with open('tmp_replay_dir/hello.json', 'r') as f:
        data_loaded = json.load(f)

    assert data == data_loaded

    os.system('rm -rf tmp_replay_dir')



# Generated at 2022-06-25 15:37:14.333397
# Unit test for function load
def test_load():
    str_0 = 'L(/kO4?F2'
    template_name = str_0
    replay_dir = str_0
    var_0 = load(replay_dir, template_name)
    print(var_0)
    

# Generated at 2022-06-25 15:37:21.522451
# Unit test for function load
def test_load():
    str_0 = 'V7Y_/<Kr~7"'
    str_1 = 'jKz#m^.7x"b'
    var_0 = load(str_0, str_1)
    assert var_0 == None, "Incorrect return value of load()"


# Generated at 2022-06-25 15:37:22.519400
# Unit test for function load
def test_load():
    test_case_0()



# Generated at 2022-06-25 15:37:23.388451
# Unit test for function load
def test_load():
    test_case_0()

# Generated at 2022-06-25 15:37:24.440158
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:37:28.520703
# Unit test for function dump
def test_dump():
    str_0 = 'Xt~k0eb<A'
    dict_0 = dict()
    dict_0['cookiecutter'] = dict_0
    dump(str_0, str_0, dict_0)



# Generated at 2022-06-25 15:37:29.643827
# Unit test for function load
def test_load():
    test_case_0

# Generated at 2022-06-25 15:37:36.940503
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-cases/test-case-0/inputs/replay_dir'
    template_name = 'str_0'
    context = {
        'cookiecutter': {
            '_template': 'str_0',
            'str_0': 'str_0',
        }
    }
    assert dump(replay_dir, template_name, context) is None


# Generated at 2022-06-25 15:37:40.117301
# Unit test for function load
def test_load():
    str_0 = 'L(/kO4?F2'
    var_0 = load(str_0, str_0)
    print(var_0)
    # return the bug-free variable
    return var_0

# Unit test exec

# Generated at 2022-06-25 15:37:46.146920
# Unit test for function load
def test_load():
    str_0 = 'L(/kO4?F2'
    var_0 = load(str_0, str_0)

    str_1 = 'L(/kO4?F2'
    var_1 = load(str_1, str_1)

    assert var_0 == var_1



# Generated at 2022-06-25 15:37:56.992597
# Unit test for function load
def test_load():
    # Assigning the 'tuple_0' the 'load' function with argument 'str_0' and 'str_0'
    tuple_0 = load('str_0', 'str_0')
    # Getting the type of 'tuple_0' (line 2)
    tuple_0_type = type(tuple_0)
    # Getting the type of 'dict' (line 2)
    dict_type_1 = type(dict())

    # Assigning the 'float_0' the 'tuple_0' function with argument 
    float_0 = tuple_0[0]
    # Getting the type of 'float_0' (line 3)
    float_0_type = type(float_0)
    # Getting the type of 'float' (line 3)
    float_type_1 = type(float())

    # Assigning

# Generated at 2022-06-25 15:38:03.845016
# Unit test for function dump
def test_dump():
    str_0 = 'L(/kO4?F2'
    var_0 = dump(str_0, str_0, str_0)


# Generated at 2022-06-25 15:38:05.526360
# Unit test for function dump
def test_dump():
    print("Testing dump()...")

    test_case_0()


# Generated at 2022-06-25 15:38:13.395859
# Unit test for function dump
def test_dump():
    # Create a context with all possible json data types
    context = {
        "key1": "value1",
        "key2": 2,
        "key3": 3.14,
        "key4": True,
        "key5": False,
        "key6": None,
        "key7": ["value1", "value2"],
        "key8": {
            "key1": "value1",
            "key2": 2,
            "key3": 3.14,
            "key4": True,
            "key5": False,
            "key6": None,
        },
    }

    # Create a "cookiecutter" key inside the context
    context["cookiecutter"] = context

    # Create a temporary directory to store the replay file
    replay_dir = "test_files"

# Generated at 2022-06-25 15:38:20.555638
# Unit test for function load
def test_load():
    var_0 = 'U%c]<e} t'
    var_1 = True
    var_3 = '<n/+_'
    var_2 = {var_3 : [('/u9K(1d7}-@', 'i', var_1, True), {'/t>)' : {'Kp*5PZ' : 11, 'z' : (var_1, var_1, True, '/YHd[OIE')}, 'h5' : (var_1, True, (var_1, True), 'F')}]}
    test_case_0()


# Generated at 2022-06-25 15:38:22.014085
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:38:25.045320
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except (TypeError, ValueError, IOError) as ex:
        print(ex)
        assert False
    else:
        assert True


# Generated at 2022-06-25 15:38:30.858032
# Unit test for function dump
def test_dump():
    try:
        dump('v?', '2(FJ5r5', None)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-25 15:38:33.176836
# Unit test for function dump
def test_dump():
    dump('/tmp/foo', 'foobar', {'cookiecutter': {}})


# Generated at 2022-06-25 15:38:35.025979
# Unit test for function load
def test_load():
    # GH-25
    str_0 = 'L(/kO4?F2'
    test_case_0()


# Generated at 2022-06-25 15:38:40.070864
# Unit test for function load
def test_load():
    import os
    import shutil
    import tempfile

    replay_dir = tempfile.mkdtemp()
    template_name = 'project_name'
    context = {
        'cookiecutter': {
            'project_name': 'Hello, world!',
        },
    }
    dump(replay_dir, template_name, context)

    actual = load(replay_dir, template_name)
    assert actual == context

    shutil.rmtree(replay_dir, ignore_errors=True)



# Generated at 2022-06-25 15:38:50.055179
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:38:59.871123
# Unit test for function load
def test_load():

    # Setup
    dir_0 = 'tests/files/replay_data'
    str_0 = 'simple_without_git/context.json'
    file_path_0 = os.path.join(dir_0, str_0)
    expected_value_0 = {'cookiecutter': {'company_name': 'Simple Corp',
                                         'email': 'johndoe@example.com',
                                         'full_name': 'John Doe',
                                         'project_name': 'simple-without-git',
                                         'project_slug': 'simple_without_git'}}

    # Testing
    value_0 = load(dir_0, str_0)
    assert value_0 == expected_value_0


# Generated at 2022-06-25 15:39:00.878997
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:39:05.271894
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-replay'
    template_name = 'tests/fake-repo-pre'
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert context['full_name'] == 'First Last'
    assert context['email'] == 'me@example.com'



# Generated at 2022-06-25 15:39:08.164834
# Unit test for function dump
def test_dump():
    """Test function dump."""
    str_0 = ';g(xA6Kj#'
    dict_0 = dict()
    dict_0.update(cookiecutter='cookiecutter')
    dict_1 = dump(str_0, str_0, dict_0)
    assert dict_1 is None


# Generated at 2022-06-25 15:39:08.880628
# Unit test for function load
def test_load():
    assert(True)


# Generated at 2022-06-25 15:39:09.730515
# Unit test for function load
def test_load():
    assert callable(load)

# Generated at 2022-06-25 15:39:11.133383
# Unit test for function dump
def test_dump():
    with pytest.raises(TypeError):
        dump(None, None, None)



# Generated at 2022-06-25 15:39:12.206165
# Unit test for function load
def test_load():
    print('Test load')
    assert callable(load)
    print('')

# Generated at 2022-06-25 15:39:18.097238
# Unit test for function dump
def test_dump():
    assert callable(dump)
    str_1 = 'h1$'
    dict_0 = dict()
    dict_0[str_1] = str_1
    try:
        dump(str_1, str_1, dict_0)
    except TypeError as e:
        print(e)
    try:
        dump(str_1, str_1, dict_0)
    except ValueError as e:
        print(e)


# Generated at 2022-06-25 15:40:02.186166
# Unit test for function load
def test_load():
    path = os.path.dirname(os.path.realpath(__file__))
    test_file = os.path.join(path, 'tests/files/load.json')

    str_0 = 'L(/kO4?F2'
    var_0 = load(test_file, str_0)
    str_356 = '^Kyh>b}fj'
    str_356 = var_0['cookiecutter'][str_356]
    assert str_356 == 'tests/files'


# Generated at 2022-06-25 15:40:06.398384
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:40:11.131215
# Unit test for function load
def test_load():
    str_0 = 'L(/kO4?F2'
    var_0 = load(str_0, str_0)
    str_1 = 'Hd7zXGv4'
    str_2 = '8W~{a*,v'
    var_1 = load(str_1, str_2)


# Generated at 2022-06-25 15:40:17.611200
# Unit test for function load
def test_load():
    # Verify that the function load() returns a value of type 'dict'
    assert (isinstance(load('substring', 'substring'), dict) == True)

    # Verify that the function load() raises a ValueError when the context does not contain a key 'cookiecutter'
    with pytest.raises(ValueError) as exception_info:
        load('substring', 'substring')
    assert exception_info.match('Context is required to contain a cookiecutter key') == True

    # Verify that the function load() raises a TypeError when the template name is not of type 'str'
    with pytest.raises(TypeError) as exception_info:
        load(42, 42)
    assert exception_info.match('Template name is required to be of type str') == True

    # Verify that the function load() raises an IOError when the replay

# Generated at 2022-06-25 15:40:24.900046
# Unit test for function dump
def test_dump():
    # Setup
    replay_dir = "J4l4>#N6fC"
    template_name = "K5r5Uq3,=b"
    context = { 'cookiecutter' : {"replay_dir":"", "no_input":False, "_copy_without_render":"[cookiecutter.replay]", "template":""} }

    # Exercise
    dump(replay_dir, template_name, context)

    # Verify
    assert os.path.exists(get_file_name(replay_dir, template_name))



# Generated at 2022-06-25 15:40:32.692318
# Unit test for function load
def test_load():
    import os
    import logging
    import sys
    import unittest

    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    class TestCookiecutter(unittest.TestCase):
        @mock.patch('cookiecutter.replay.json.load')
        @mock.patch(
            'cookiecutter.replay.get_file_name', return_value='exists.json'
        )
        @mock.patch('os.path.exists', return_value=True)
        def test_load(self, file_name_mock, exists_mock, json_load_mock):
            load('replay_dir', 'template_name')
            self.assertTrue(file_name_mock.called)

# Generated at 2022-06-25 15:40:34.407941
# Unit test for function load
def test_load():
	var_0 = str
	var_1 = '^Zn8W`'
	var_2 = load(var_0, var_1)


# Generated at 2022-06-25 15:40:37.565341
# Unit test for function load
def test_load():
    var_0 = 100
    var_1 = 'm_?&'
    template_name = 'b-kre'
    var_3 = {}
    dump(var_0, template_name, var_3)
    load(var_0, template_name)

test_load()


# Generated at 2022-06-25 15:40:40.268062
# Unit test for function load
def test_load():
    # Test case 0
    str_0 = 'L(/kO4?F2'
    var_0 = load(str_0, str_0)
    assert var_0 == {}


# Generated at 2022-06-25 15:40:50.434898
# Unit test for function load

# Generated at 2022-06-25 15:41:51.280735
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except IOError as e:
        assert e.args[0] == 'Unable to create replay dir at L(/kO4?F2'

if __name__ == '__main__':
    try:
        test_load()
    except IOError as e:
        print(e)

# Generated at 2022-06-25 15:41:53.409028
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except IOError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:42:01.490176
# Unit test for function load
def test_load():
    n = 'N'
    v = 'V'
    c = 'C'
    d = 'D'
    t = 'T'

    t_replay_dir = n
    t_template_name = v

    t_context = {
        c: {
            n: v
        }
    }

    test_file = get_file_name(t_replay_dir, t_template_name)

    if not make_sure_path_exists(t_replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(t_replay_dir))

    with open(test_file, 'w') as outfile:
        json.dump(t_context, outfile, indent=2)


# Generated at 2022-06-25 15:42:05.211548
# Unit test for function load
def test_load():
    # Assert if load('L(/kO4?F2', 'L(/kO4?F2') raises exceptions
    try:
        load('L(/kO4?F2', 'L(/kO4?F2')
    except ValueError:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-25 15:42:07.991166
# Unit test for function dump
def test_dump():
    file_0 = ''
    assert dump(file_0, file_0, file_0) == None


# Generated at 2022-06-25 15:42:10.653917
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:42:14.000480
# Unit test for function load
def test_load():
    # test_case_0
    str_0 = 'L(/kO4?F2'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:42:14.937707
# Unit test for function load
def test_load():
    assert True


# Generated at 2022-06-25 15:42:17.777431
# Unit test for function load
def test_load():
    str_0 = 'L(/kO4?F2'
    str_1 = 'L(/kO4?F2'
    var_0 = load(str_0, str_1)


# Generated at 2022-06-25 15:42:18.392058
# Unit test for function load
def test_load():
    assert test_case_0() is None