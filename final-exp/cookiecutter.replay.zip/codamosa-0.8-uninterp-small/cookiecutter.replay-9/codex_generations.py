

# Generated at 2022-06-25 15:32:58.417864
# Unit test for function get_file_name
def test_get_file_name():
    assert (get_file_name(0, 0) == 0)

# Generated at 2022-06-25 15:33:07.615388
# Unit test for function dump
def test_dump():
    replay_dir = "."
    template_name = "testtemplate"
    context = {u'cookiecutter': {u'_copy_without_render': [u'LICENSE', u'README.md'], u'license': u'MIT', u'full_name': u'Juan Lopera', u'email': u'juanlopera@example.com', u'project_name': u'cookiecutter-pypackage', u'repo_name': u'cookiecutter-pypackage-test', u'description': u'A Python package project template for Cookiecutter.', u'version': u'0.1.0', u'open_source_license': u'MIT'}}

    # record call count
    open.call_count = 0

    # record arguments
    open.args_list = []

# Generated at 2022-06-25 15:33:11.395515
# Unit test for function dump
def test_dump():
    # TODO: Add more test cases for the function dump
    assert not dump(None, None, None)
    assert not test_dump()


# Generated at 2022-06-25 15:33:13.838215
# Unit test for function load
def test_load():
    float_0 = None
    assert(load(float_0, float_0) == None)


# Generated at 2022-06-25 15:33:15.823607
# Unit test for function load
def test_load():
    replay_dir, template_name = None, None
    result = load(replay_dir, template_name)


# Generated at 2022-06-25 15:33:23.304677
# Unit test for function dump
def test_dump():
    data = {'cookiecutter': {'project_name': 'Hello World!'}}
    template_name = 'tests/files/test-template'

    print("Dumping example data to file")
    dump('.', template_name, data)

    print("Loading example data from file")
    loaded_data = load('.', template_name)

    print("Comparing loaded data to original data")
    assert loaded_data == data



# Generated at 2022-06-25 15:33:30.345698
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "C:/Users/Jake/Desktop"
    template_name = "cookiecutter-pypackage-minimal"
    #test 1
    assert get_file_name(replay_dir, template_name) == "C:/Users/Jake/Desktop/cookiecutter-pypackage-minimal.json", "Test 1 failed"

    #test 2
    replay_dir = "C:/Users/Jake/Desktop"
    template_name = "cookiecutter-pypackage-minimal.json"
    assert get_file_name(replay_dir, template_name) == "C:/Users/Jake/Desktop/cookiecutter-pypackage-minimal.json", "Test 2 failed"


# Generated at 2022-06-25 15:33:40.298053
# Unit test for function load

# Generated at 2022-06-25 15:33:42.082422
# Unit test for function load
def test_load():
    float_0 = None
    var_0 = load(float_0, float_0)
    assert var_0 is None


# Generated at 2022-06-25 15:33:44.265446
# Unit test for function dump
def test_dump():
    filename = "\\\\.\\pipe\\test.txt"
    fd = os.open(filename, os.O_RDONLY)
    os.close(fd)
    os.remove(filename)

# Generated at 2022-06-25 15:33:50.994391
# Unit test for function load
def test_load():
    replay_dir = "C:\Work\cookiecutter-Test"
    template_name = "test"
    str_1 = "\cookiecutter\cookiecutter"
    dict_0 = dict()
    dict_0['cookiecutter'] = str_1
    json_0 = json.dumps(dict_0)
    str_2 = "C:\Work\cookiecutter-Test\test.json"
    if not os.path.exists(str_2):
        fd_0 = os.open(str_2, os.O_WRONLY | os.O_CREAT)
        os.write(fd_0, json_0)
        os.close(fd_0)
    with open(str_2, 'r') as infile:
        t_0 = json.load(infile)
    t

# Generated at 2022-06-25 15:33:55.832241
# Unit test for function load
def test_load():
    replay_dir = 'C:\\'
    template_name = 'C:\\PycharmProjects\\cookiecutter\\tests\\test-data\\{{cookiecutter.repo_name}}'
    load(replay_dir, template_name)


# Generated at 2022-06-25 15:34:04.651812
# Unit test for function dump
def test_dump():
    global str_0
    replay_dir = 'C:\\Users\\me\\AppData\\Local\\Temp\\tmpl0ho4g7t'
    template_name = 'pip-template'
    context = {'cookiecutter': {'author_email': 'bob@example.com', 'project_name': 'cookiecutter-pypackage', 'project_slug': 'cookiecutter-pypackage', 'author_full_name': 'Bob Smith', 'repo_name': 'cookiecutter-pypackage', 'year': '2015', 'open_source_license': 'MIT'}}
    cookiecutter.replay.dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:34:10.615495
# Unit test for function dump
def test_dump():
    assert dump(replay_dir='', template_name='', context={}) == None


# Generated at 2022-06-25 15:34:13.301082
# Unit test for function dump
def test_dump():
    # TODO:
    # it is not easy to test IO operation
    # it is suggested to use mocking
    pass


# Generated at 2022-06-25 15:34:22.171513
# Unit test for function load
def test_load():
    str_0 = os.getcwd() + '\\test.txt'
    str_1 = '{\\rtf1\\fbidis\\ansi\\ansicpg1252\\deff0\\deflang2052{\\fonttbl{\\f0\\fswiss\\fprq2\\fcharset0 Segoe UI;}}\\viewkind4\\uc1\\pard\\ltrpar\\lang2052\\fs18\\par\\cf1\\qc\\cf2\\par\\cf3\\par\\cf4\\par\\lang9 \\f0\\fs24}'

    # Open the file for reading.
    file_0 = open(str_0, 'r')

    # Read the entire file into a string.
    str_2 = file_0.read()

    # Close the file.
    file_0.close()



# Generated at 2022-06-25 15:34:29.202373
# Unit test for function load
def test_load():
    # Test 1
    # template_name = ''
    # replay_dir = 'C:\\Users\\Owner\\Documents\\python\\git\\cookiecutter\\'
    template_name = '.cookiecutter.json'
    replay_dir = 'C:\\Users\\Owner\\Documents\\python\\git\\cookiecutter\\replay\\'
    context = load(replay_dir, template_name)
    print(context)

if __name__ == '__main__':
    #test_case_0()
    test_load()

# Generated at 2022-06-25 15:34:33.182407
# Unit test for function load
def test_load():

    try:
        os.chdir('D:\Repository\git\HoneyPot-build\HoneyPot\\tests')
        test_case_0()
    except Exception:
        print('Error occurs in test load!')
    finally:
        os.chdir('D:\Repository\git\HoneyPot-build\HoneyPot')


# Generated at 2022-06-25 15:34:42.772302
# Unit test for function load
def test_load():
    # generate random string
    # str_0 -- test template_name
    str_0 = os.urandom(random.randint(1,10))

    # replay_dir -- test replay_dir
    replay_dir = os.path.join(os.environ['TMP'],str(uuid.uuid1()))

    with pytest.raises(TypeError):
        load(replay_dir, 1)
    with pytest.raises(ValueError):
        load(replay_dir, str_0)
    with pytest.raises(ValueError):
        context = {'cookiecutter':{'test':'yes'}}
        dump(replay_dir, str_0, context)
        load(replay_dir, str_0)


# Generated at 2022-06-25 15:34:46.709561
# Unit test for function load

# Generated at 2022-06-25 15:34:52.286290
# Unit test for function load
def test_load():
    try:
        float_0 = None
        str_0 = 'C:\\Users\\Kyle\\Desktop\\file.json'
        str_1 = 'C:\\Users\\Kyle\\Desktop\\file.txt'
        str_2 = 'C:\\Users\\Kyle\\Desktop\\file.png'
        var_0 = load(str_2, str_1)
    except ValueError:
        return
    else:
        assert False # Exception not raised


# Generated at 2022-06-25 15:34:57.091513
# Unit test for function dump
def test_dump():
    try:
        dump(None, None, None)
    except Exception as e:
        if isinstance(e, IOError):
            assert(True)
        if isinstance(e, TypeError):
            assert(True)
        if isinstance(e, ValueError):
            assert(True)


# Generated at 2022-06-25 15:35:05.436277
# Unit test for function dump
def test_dump():
    replay_dir = None
    template_name = None
    context = None
    assert dump(replay_dir, template_name, context) == None
    assert dump(replay_dir, template_name, context) == None
    assert dump(replay_dir, template_name, context) == None
    assert dump(replay_dir, template_name, context) == None
    assert dump(replay_dir, template_name, context) == None
    assert dump(replay_dir, template_name, context) == None


# Generated at 2022-06-25 15:35:13.737007
# Unit test for function load
def test_load():
    template_name = 'Test File'
    replay_dir = 'C:\\Users\\kstanoev\\Documents\\GitHub\\cookiecutter-pypackage-minimal'
    var_0 = load(replay_dir, template_name)
    assert var_0 == {
        'cookiecutter': {
            '_template': 'Test File', 'full_name': 'Test File',
            'email': 'test@test.org', 'github_username': 'test',
            'project_name': 'Test File', 'project_short_description': 'Test File',
            'pypi_username': 'test'
        }
    }


# Generated at 2022-06-25 15:35:23.434610
# Unit test for function dump
def test_dump():
    replay_dir = 'test_dump/test_dump_dir'
    template_name = 'test_dump_name'
    context = str({'cookiecutter': {'key_0': 'val_0'}})
    dump(replay_dir, template_name, context)

    expected = {'cookiecutter': {'key_0': 'val_0'}}

    assert load(replay_dir, template_name) == expected, 'Expected: {}, Actual: {}'.format(expected, load(replay_dir, template_name))



# Generated at 2022-06-25 15:35:26.983101
# Unit test for function load
def test_load():
    replay_dir = 'C:\\Users\\S\\git\\cookiecutter-py\\tests\\test-repo1'
    template_name = 'cookiecutter.json'
    json_data = load(replay_dir, template_name)
    assert json_data


# Generated at 2022-06-25 15:35:30.540262
# Unit test for function load
def test_load():
    # Set replay_dir to a path
    replay_dir = None
    # Set template_name to a string
    template_name = None
    # Attempt to load the context from the replay file
    context = load(replay_dir, template_name)


# Generated at 2022-06-25 15:35:31.873473
# Unit test for function load
def test_load():
    float_0 = None
    int_0 = load(float_0, float_0)


# Generated at 2022-06-25 15:35:40.416336
# Unit test for function load
def test_load():
    replay_dir = ''
    template_name = ''
    try:
        load(replay_dir, template_name)
    except TypeError as e:
        assert isinstance(e, TypeError)
    except IOError as e:
        assert isinstance(e, IOError)
    except ValueError as e:
        assert isinstance(e, ValueError)
    with open(replay_dir + template_name, 'w') as file_out:
        file_out.write("Hello world")
    with open(replay_dir + template_name, 'r') as file_in:
        context = json.load(file_in)
        assert isinstance(context, dict)


# Generated at 2022-06-25 15:35:51.158601
# Unit test for function load

# Generated at 2022-06-25 15:35:57.585926
# Unit test for function dump
def test_dump():
    float_0 = None
    var_0 = get_file_name(float_0, float_0)


# Generated at 2022-06-25 15:36:00.083511
# Unit test for function load
def test_load():
    print('\n\nRunning test for load')
    try:
        load(10, 10)
    except TypeError:
        print('Test load: Failed')
        print('Test load: Passed')


# Generated at 2022-06-25 15:36:07.000434
# Unit test for function load
def test_load():
    replay_dir = 'test_dir'
    template_name = 'test_name'
    context = {'context': 1}
    dump(replay_dir, template_name, context)
    result = load(replay_dir, template_name)
    import os
    os.remove(get_file_name(replay_dir, template_name))

    print('load test passed!')
    assert True


# Generated at 2022-06-25 15:36:09.262281
# Unit test for function load
def test_load():
    replay_dir = os.path.expanduser('~')
    template_name = 'foo',
    load(replay_dir, template_name)



# Generated at 2022-06-25 15:36:14.683970
# Unit test for function load
def test_load():
    """Test for load()."""
    # Setup
    replay_dir = 'Cookiecutter'
    template_name = 'a'
    float_0 = None
    # Exercise
    load(replay_dir, template_name)
    # Verify
    float_0 = None
    # Cleanup
    float_0 = None


# Generated at 2022-06-25 15:36:16.446622
# Unit test for function load
def test_load():
    string_0 = load('s0tYO2UC', 'shGZzmyh')


# Generated at 2022-06-25 15:36:22.628649
# Unit test for function load
def test_load():
    keys = {}
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    float_15 = float()
    float_16 = float()
    float_17 = float()
    float_18 = float()
    float_19 = float()
    float_20 = float()
    float_21 = float()
    float_22 = float()
    float_23 = float()
    float_24 = float()
    float_25 = float()
    float

# Generated at 2022-06-25 15:36:24.748992
# Unit test for function load
def test_load():
    replay_dir = None
    template_name = None
    assert load(replay_dir, template_name) is not None


# Generated at 2022-06-25 15:36:35.194689
# Unit test for function load
def test_load():
    replay_dir = os.path.expanduser('~/test_dir')
    template_name = 'my_file'
    json_data = {'cookiecutter': {'hello': 'world'}}

    # Write test_file
    dump(replay_dir, template_name, json_data)

    # Read test_file
    actual_context = load(replay_dir, template_name)
    actual_data = actual_context['cookiecutter']

    # delete test_file
    try:
        os.remove(get_file_name(replay_dir, template_name))
    except OSError:
        pass

    # Test
    msg = 'Load does not fetch expected data'
    assert actual_data == json_data['cookiecutter'], msg


# Generated at 2022-06-25 15:36:37.480505
# Unit test for function load
def test_load():
    replay_dir = 'tmp'
    template_name = 'tmplate'
    assert isinstance(load(replay_dir, template_name), dict)


# Generated at 2022-06-25 15:36:47.144043
# Unit test for function load
def test_load():
    # Tests type checks
    try:
        load()
    except TypeError:
        pass
    else:
        assert False
    # Tests ValueError checks
    try:
        load()
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-25 15:36:51.388660
# Unit test for function dump
def test_dump():
    if not callable(dump):
        raise ValueError(
            'Function is not callable. Check the function name.'
        )
    if not isinstance(dump(None, None, None), None):
        raise ValueError(
            'Function does not return None. Check the return statement.'
        )


# Generated at 2022-06-25 15:36:52.931494
# Unit test for function load
def test_load():
    # ToDo: Provide unit tests
    pass # replace this pass statement with your code


# Generated at 2022-06-25 15:36:55.870624
# Unit test for function load
def test_load():
    replay_dir = None
    template_name = 'bar'
    context = None
    get_file_name = load(replay_dir, template_name)


# Generated at 2022-06-25 15:37:01.531677
# Unit test for function load
def test_load():
    float_0 = None
    var_0 = load(float_0, float_0)


# Generated at 2022-06-25 15:37:02.943257
# Unit test for function dump
def test_dump():
    var_1 = dump(None, None, None)


# Generated at 2022-06-25 15:37:10.268735
# Unit test for function load
def test_load():
    float_0 = None
    int_0 = None
    float_1 = None
    tuple_0 = None
    float_2 = None
    assert float_0 >= float_0
    int_0 = None
    str_0 = None
    assert float_1 != float_2
    assert float_0 >= float_2
    assert float_1 >= float_1
    assert float_1 >= float_2
    assert float_2 != float_2
    str_0 = 'File called {} is not found.'
    assert float_1 != float_0
    assert float_1 >= float_1
    assert float_0 >= float_0
    assert float_2 >= float_1
    load(float_1, int_0)

# Generated at 2022-06-25 15:37:15.464883
# Unit test for function load
def test_load():
    dump('examples/functional/', 'bake-me-cookies', {'cookiecutter': 'is:awesome'})
    context = load('examples/functional/', 'bake-me-cookies')
    assert context == {'cookiecutter': 'is:awesome'}

# Generated at 2022-06-25 15:37:19.338687
# Unit test for function dump
def test_dump():
    replay_dir = './'
    template_name = 'test_templates'
    context = {'cookiecutter': {'hello': 'world'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:37:26.301406
# Unit test for function load
def test_load():
    file_name = 'test.json'
    data = {'keyname': 'somevalue'}
    replay_dir = 'test/test-replay'

    dump(replay_dir, file_name, data)
    ctx = load(replay_dir, file_name)

    assert isinstance(ctx, dict)
    assert ctx['keyname'] == data['keyname']



# Generated at 2022-06-25 15:37:35.514417
# Unit test for function load
def test_load():
    # Creation of the following  variables is required for the unit test
    var_0 = None
    var_1 = None
    load(var_0, var_1)


# Generated at 2022-06-25 15:37:40.933807
# Unit test for function load
def test_load():
    float_0 = None
    expected_0 = None
    replay_dir = float_0
    template_name = float_0
    actual_0 = load(replay_dir, template_name)
    assert actual_0 == expected_0
    context_0 = {}
    expected_0 = None
    replay_dir = float_0
    template_name = float_0
    actual_0 = load(replay_dir, template_name)
    assert actual_0 == expected_0


# Generated at 2022-06-25 15:37:45.242843
# Unit test for function load
def test_load():
    replay_dir = None
    template_name = None
    try:
        load(replay_dir, template_name)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 15:37:46.803920
# Unit test for function load
def test_load():
    float_1 = None
    var_1 = load(float_1, float_1)


# Generated at 2022-06-25 15:37:50.678615
# Unit test for function load
def test_load():
    assert load("dir", "dir") == load("dir", "dir")


# Generated at 2022-06-25 15:37:55.015157
# Unit test for function dump
def test_dump():
    replay_dir = '{}/'.format(os.getcwd())
    template_name = 'template_name'
    context = {'cookiecutter': {'repo_dir': os.getcwd(), 'delimiters': {'variable_start_string': '{{', 'variable_end_string': '}}'}}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:38:00.800274
# Unit test for function dump
def test_dump():
    if __name__ == '__main__':
        rd = 'replays'
        tn = 'template'
        context = {'cookiecutter': {'full_name': 'Samuel Alexander', 'email': 'sam@example.com'}}
        dump(rd, tn, context)
    assert var_0 == 'replays/template.json'


# Generated at 2022-06-25 15:38:08.317962
# Unit test for function load
def test_load():
    print ("Test load() with assert")
    replay_dir = "tests/test-output/replay"
    template_name = "tests/fake-repo-pre/fake_repo_pre/"
    context = {u'cookiecutter': {u'full_name': u'Audrey Roy', u'email': u'audreyr@example.com', u'github_username': u'audreyr'}}
    load(replay_dir, template_name)
    assert context == load(replay_dir, template_name)
    print ("Test load() with assert passed")


# Generated at 2022-06-25 15:38:12.100304
# Unit test for function load
def test_load():
    float_0 = None
    var_0 = load(float_0, float_0)

# Generated at 2022-06-25 15:38:13.287663
# Unit test for function load
def test_load():
    float_0 = None
    var_0 = load(float_0, float_0)

# Generated at 2022-06-25 15:38:26.178105
# Unit test for function load
def test_load():
    replay_dir = None
    template_name = None
    load(replay_dir, template_name)


# Generated at 2022-06-25 15:38:28.930597
# Unit test for function load
def test_load():
    # Test the function load.
    var_0 = load(float_0, float_0)
    assert isinstance(var_0, dict)
    assert var_0['cookiecutter'] == {}



# Generated at 2022-06-25 15:38:32.877921
# Unit test for function load
def test_load():
    # TypeError is raised if the template name is not a string
    try:
        load('/tmp', 1)
        assert False
    except TypeError:
        assert True
    # ValueError is raised if the context does not contain a `cookiecutter` key
    try:
        load('/tmp', 'test-template')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-25 15:38:39.671816
# Unit test for function load
def test_load():
    float_0 = None
    var_0 = load(float_0, float_0)
    assert var_0 == TypeError
    float_0 = None
    var_0 = load(float_0, '{{cookiecutter.project_name}}')
    test_case_0()
    assert var_0 == ValueError
    float_0 = None
    var_0 = load(float_0, '{{cookiecutter.project_name}}')
    assert var_0 == TypeError
    float_0 = None
    var_0 = load(float_0, '{{cookiecutter.project_name}}')
    test_case_0()
    assert var_0 == ValueError
    float_0 = None
    var_0 = load(float_0, '{{cookiecutter.project_name}}')
    assert var_

# Generated at 2022-06-25 15:38:43.561828
# Unit test for function dump
def test_dump():
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    context = {}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:38:50.165199
# Unit test for function load
def test_load():
    replay_dir = ''
    template_name = ''
    ret = load(replay_dir, template_name)
    assert isinstance(ret, dict)
    assert ret == {}


# Generated at 2022-06-25 15:38:51.841327
# Unit test for function dump
def test_dump():
    float_0 = None
    var_0 = dump(float_0, float_0, dict())


# Generated at 2022-06-25 15:38:54.040333
# Unit test for function load
def test_load():
    with pytest.raises(Exception) as excinfo:
        load(replay_dir, template_name)
    assert excinfo.value == expected_result


# Generated at 2022-06-25 15:38:56.230721
# Unit test for function load
def test_load():
    try:
        assert 'cookiecutter' in load('replay', 'cookiecutter.json')
    except (TypeError, ValueError) as error:
        print(error)
    except IOError as error:
        print(error)



# Generated at 2022-06-25 15:39:05.383941
# Unit test for function load
def test_load():

    # fail_context = os.path.join(os.path.dirname(__file__),
    #                             'fixture_files',
    #                             'fail_context.json')

    # os.path.isfile(fail_context)


    replay_dir = os.path.join(os.path.dirname(__file__),
                              'fixture_files',
                              'replay_dir')
    template_name = 'pocoo_flask'

    context = load(replay_dir, template_name)

    assert 'cookiecutter' in context
    assert '_template' in context



# Generated at 2022-06-25 15:39:38.578423
# Unit test for function load
def test_load():

    # We need to set up and restore a replay_dir path (or use temp dir)
    # old path was: replay_dir = '/Users/audreyr/Desktop/cookiecutter-pypackage/tests/test-data/fake-repo-pre/'
    replay_dir = '/Users/audreyr/Desktop/cookiecutter-pypackage/tests/test-data/fake-repo-pre/'
    var_0 = load(replay_dir, 'fake-repo')

# Generated at 2022-06-25 15:39:41.146313
# Unit test for function load
def test_load():
    assert load(None, None) == None
    #assert load('replay_dir', 'template_name') == 'Read json data from file.'
    assert load('replay_dir', 'template_name') == None


# Generated at 2022-06-25 15:39:48.289393
# Unit test for function dump
def test_dump():
    context = {
        "cookiecutter": {
            "full_name": 'Example Name',
            "email": 'example@email.com',
            "project_name": 'Example Project',
            "project_slug": 'example_project',
            "theme": 'default',
            "year": '1985',
            "month": '01'
        }
    }
    replay_dir = '/tmp/cookiecutter-replay'
    template_name = 'example'
    dump(replay_dir, template_name, context)

# Generated at 2022-06-25 15:39:50.289725
# Unit test for function dump
def test_dump():
    assert dump('C:\\Users\\Marian\\Desktop\\projects\\cookiecutter-higher-order\\tests\\test_replay', 'test_dump', {}) == None


# Generated at 2022-06-25 15:39:55.171385
# Unit test for function load
def test_load():
    replay_dir = None
    template_name = None
    assert load(replay_dir, template_name) == context


# Generated at 2022-06-25 15:40:04.886649
# Unit test for function load
def test_load():
    cli_args = {
        'replay': 'tests/test-replay/',
        'no_input': True,
        'extra_context': {
            'full_name': 'Your Name',
            'email': 'your-email@example.com',
            'github_username': 'your-github-username',
            'project_name': 'your-project',
            'project_slug': 'your-slug',
            'project_short_description': 'project description',
            'release_date': '2016-10-24',
            'year': '2016',
            'version': '0.0.1',
        },
    }
    context = load(cli_args['replay'], '.')
    assert 'cookiecutter' in context

# Generated at 2022-06-25 15:40:07.069184
# Unit test for function load
def test_load():
    replay_dir = 'test_dir'
    template_name = 'test_name'
    context = {'cookiecutter': {}}
    result = load(replay_dir, template_name)


# Generated at 2022-06-25 15:40:11.203948
# Unit test for function load
def test_load():
    path = os.path.dirname(__file__)
    replay_dir = os.path.join(path, '../tests/files/replay')
    template_name = 'tests/files/gh-shortcut-raw'
    load(replay_dir, template_name)



# Generated at 2022-06-25 15:40:14.556545
# Unit test for function load
def test_load():
    print('Testing file {}'.format(__file__))
    replay_dir = '/home/vagrant'
    template_name = 'test'

    _context = load(replay_dir, template_name)
    _context = load(None, None)

    print('Done testing')


if __name__ == '__main__':
    test_case_0()
    test_load()

# Generated at 2022-06-25 15:40:22.698741
# Unit test for function load
def test_load():
    # Test error handling.
    # Prepare the input.
    template_name = None

    # Invoke the tested operation.
    try:
        load(template_name, template_name)

        # Verify the result.
        assert False
    except TypeError:
        pass

    # Test error handling.
    # Prepare the input.
    replay_dir = None

    # Invoke the tested operation.
    try:
        load(replay_dir, template_name)

        # Verify the result.
        assert False
    except TypeError:
        pass


# Generated at 2022-06-25 15:41:15.404012
# Unit test for function load
def test_load():
    float_0 = None
    var_0 = load(float_0, float_0)


# Generated at 2022-06-25 15:41:18.652843
# Unit test for function load
def test_load():
    replay_dir = ''
    template_name = ''
    # load(replay_dir, template_name)


# Generated at 2022-06-25 15:41:29.154364
# Unit test for function dump
def test_dump():
    template_name = 'project'
    replay_dir = os.path.join(os.getcwd(), 'replay')
    context = {'cookiecutter': {'full_name': 'dummy',
                                'email': 'dummy@dummy.com',
                                'github_username': 'dummy',
                                'project_name': 'dummy'}}
    dump(replay_dir, template_name, context)
    loaded_context = load(replay_dir, template_name)
    assert loaded_context == context


# Generated at 2022-06-25 15:41:38.074994
# Unit test for function dump
def test_dump():
    float_0 = None
    int_0 = 0
    float_1 = None
    str_0 = ""
    float_2 = None
    str_1 = ""
    float_3 = None
    str_2 = ""
    float_4 = None
    str_3 = ""
    float_5 = None
    str_4 = ""
    float_6 = None
    str_5 = ""
    float_7 = None
    str_6 = ""
    float_8 = None
    str_7 = ""
    float_9 = None
    str_8 = ""
    float_10 = None
    str_9 = ""
    str_10 = ""
    float_11 = None
    str_11 = ""
    float_12 = None
    str_12 = ""
    float_13 = None
    str_

# Generated at 2022-06-25 15:41:39.957927
# Unit test for function dump
def test_dump():
    assert 1 == 1


# Generated at 2022-06-25 15:41:41.690932
# Unit test for function dump
def test_dump():
    float_0 = None
    dict_0 = {'cookiecutter': 'cookiecutter'}
    dump(float_0, float_0, dict_0)


# Generated at 2022-06-25 15:41:45.531947
# Unit test for function load
def test_load():
    try:
        load(0.3555195590404064, 0.3555195590404064)
    except TypeError as e:
        pass
    except ValueError as e:
        pass


# Generated at 2022-06-25 15:41:47.841312
# Unit test for function load
def test_load():
    result = load('test_file_00.json', 'test_file_00.json')
    assert result == {'cookiecutter': {}}



# Generated at 2022-06-25 15:41:50.662899
# Unit test for function load
def test_load():
    float_0 = None
    with pytest.raises(TypeError) as context:
            load(float_0, float_0)


# Generated at 2022-06-25 15:41:56.831160
# Unit test for function load
def test_load():
    replay_dir="home"
    template_name="template_name"
    # Testing for TypeError if template_name is not of type str
    template_name=1
    try:
        load(replay_dir,template_name)
    except TypeError as e:
        pass

    # Testing for ValueError if context is not a dictionary.
    context=None
    try:
        load(replay_dir,template_name)
    except ValueError as e:
        pass

