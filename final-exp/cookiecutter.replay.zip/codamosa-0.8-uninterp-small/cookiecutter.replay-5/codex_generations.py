

# Generated at 2022-06-25 15:33:04.280956
# Unit test for function load
def test_load():
    replay_dir = "replay_dir"
    template_name = "template_name"
    assert load(replay_dir, template_name) == None


# Generated at 2022-06-25 15:33:17.953744
# Unit test for function load
def test_load():
    str_0 = "P8rvZe2Q$92c%zEI"
    str_1 = "3H=Eo5lzbQR!#k_x"

    #Test case with invalid types
    try:
        load(str_0, None)
    except TypeError:
        pass

    #Test case with valid arguments
    try:
        load(str_0, str_1)
    except TypeError:
        pass

    #Test case with None arguments
    try:
        load(None, None)
    except TypeError:
        pass

    #Test case with valid arguments
    try:
        load(str_0, str_1)
    except TypeError:
        pass

    #Test case with invalid argument

# Generated at 2022-06-25 15:33:23.604844
# Unit test for function dump
def test_dump():
    template_name = 'testing'
    replay_dir = '.'
    context = {'cookiecutter': {'biscuit': 'cookie'}}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    os.remove(replay_file)


# Generated at 2022-06-25 15:33:28.180321
# Unit test for function load
def test_load():
    # Must raise TypeError because input is not of type str
    try:
        load(None, None)
    except TypeError as e:
        assert 'Template name is required' in str(e)

    # Must raise ValueError because input does not have required key
    try:
        load('dir', 'file')
    except ValueError as e:
        assert 'Context is required to contain a cookiecutter key' in str(e)


# Generated at 2022-06-25 15:33:38.578153
# Unit test for function load
def test_load():
    # Initialize test values
    int_0 = None
    int_1 = 1
    int_2 = 2
    int_3 = 3
    str_0 = None
    str_1 = ''
    str_2 = 'test_2'
    str_3 = 'test_3'
    str_4 = 'test_4'
    str_5 = 'test_5'
    str_6 = 'test_6'
    str_7 = 'test_7'
    str_8 = 'test_8'
    str_9 = 'test_9'
    str_10 = 'test_10'
    str_11 = 'test_11'
    str_12 = 'test_12'
    str_13 = 'test_13'
    str_14 = 'test_14'

# Generated at 2022-06-25 15:33:42.440216
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('replay_dir', 'benni') == 'replay_dir/benni.json'
    assert get_file_name(None, 'rep') == 'rep.json'
    assert get_file_name('dir_1', 'dir_2') == 'dir_1/dir_2.json'


# Generated at 2022-06-25 15:33:48.506141
# Unit test for function load
def test_load():
    assert callable(load), "Function load not defined"
    try:
        load(str, int)
    except TypeError as e:
        assert type(e) == TypeError, "Expected TypeError but got " + type(e).__name__
    except:
        assert False, "Expected TypeError but got " + sys.exc_info()[0].__name__
    try:
        load(int, str)
    except TypeError as e:
        assert type(e) == TypeError, "Expected TypeError but got " + type(e).__name__
    except:
        assert False, "Expected TypeError but got " + sys.exc_info()[0].__name__

# Generated at 2022-06-25 15:33:54.609095
# Unit test for function load
def test_load():
    replay_dir = os.path.join('tests', 'replay')
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)

    assert context['cookiecutter']['full_name'] == 'Audrey Roy'
    assert context['cookiecutter']['email'] == 'audreyr@example.com'
    assert context['cookiecutter']['project_name'] == 'Cookiecutter Pypackage'

# Generated at 2022-06-25 15:34:05.249006
# Unit test for function load
def test_load():
    replay_dir = "C:\\Users\\Samantha Siegel\\Documents\\Thesis\\Programs\\Project1\\cookiecutter-flask\\tests\\test_replay"
    template_name = "cookiecutter-flask"
    context = "{\"cookiecutter\": {\"project_name\": \"Project1\", \"project_slug\": \"project1\", \"author_name\": \"Samantha Siegel\", \"email\": \"samantha.siegel@colorado.edu\", \"description\": \"This is the project description.\", \"version\": \"0.1.0\", \"open_source_license\": \"MIT\", \"repo_name\": \"cookiecutter-flask\"}}"
    assert type(load(replay_dir, template_name)) == load(replay_dir, template_name)


# Generated at 2022-06-25 15:34:08.615149
# Unit test for function load
def test_load():
    replay_dir = 'dir_0'
    template_name = 'str_0'
    context = load(replay_dir, template_name)
    out_0 = context['cookiecutter']
    out_1 = context['newcontext']
    assert out_0 == 'dict_1' and out_1 == 'dict_2'


# Generated at 2022-06-25 15:34:21.011911
# Unit test for function dump
def test_dump():
    """
    Test if function dump works
    """
    # Test case where dump works
    test_replay_dir = 'test_replay_dir'
    test_template_name = 'test_template_name'
    test_context = {'cookiecutter' : "test_context" }
    try:
        dump(test_replay_dir, test_template_name, test_context)
    except(Exception):
        print("Test case failed")
    # Test case where template name is not string
    test_template_name_2 = 999
    try:
        dump(test_replay_dir, test_template_name_2, test_context)
        print("Test case failed")
    except(TypeError):
        pass
    # Test case where context is not dictionary

# Generated at 2022-06-25 15:34:26.921173
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir_0 = make_sure_path_exists('test_dir')
    template_name_0 = str('test')
    # get_file_name(replay_dir_0, template_name_0)
    # print('replay path is {}'.format(get_file_name(replay_dir_0, template_name_0)))
    # print(test_case_0())


# Generated at 2022-06-25 15:34:29.556751
# Unit test for function dump
def test_dump():
    # Write JSON data to file.
    dump('/tmp', 'test', {'a': 'c', 'b': 'd'})
    assert True


# Generated at 2022-06-25 15:34:39.575441
# Unit test for function get_file_name
def test_get_file_name():
    print('\n# ------------------------------- UNIT TEST ------------------------------- #')
    print('# ------------------------------- get_file_name ------------------------------- #')
    print('# ------------------------------- UNIT TEST ------------------------------- #\n')

    print('\n# ------------------------------- TEST 0 ------------------------------- #')
    print('# ------------------------------- None ------------------------------- #')
    try:
        result_0 = get_file_name(None, None)
        assert result_0 == None
        print('\tPASS: test 0')
    except TypeError as type_error_0:
        print('\tFAIL: test 0')
        print('\t\tTYPE ERROR CAUGHT: {}'.format(type_error_0))
    except AssertionError as assertion_error_0:
        print('\tFAIL: test 0')

# Generated at 2022-06-25 15:34:42.995579
# Unit test for function load
def test_load():
    dump('local', 'template_name', {'cookiecutter': {'key': 'value'}})
    context = load('local', 'template_name')
    if context['cookiecutter']['key'] != 'value':
        return False
    else:
        return True


# Generated at 2022-06-25 15:34:48.998403
# Unit test for function get_file_name
def test_get_file_name():
    cwd = os.getcwd()
    template_name = 'test_template_name'
    expected_get_file_name_0 = os.path.join(cwd,'test_template_name.json')
    print(expected_get_file_name_0)
    result_get_file_name_0 = get_file_name(cwd,template_name)
    assert result_get_file_name_0 == expected_get_file_name_0
    

# Generated at 2022-06-25 15:34:52.382153
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name(replay_dir = 'C:/Users/paul.dreik/AppData/Local/Temp/cc_2V0aOr',
                         template_name = 'jinja2-node') == 'C:/Users/paul.dreik/AppData/Local/Temp/cc_2V0aOr\\jinja2-node.json'


# Generated at 2022-06-25 15:34:56.449780
# Unit test for function load
def test_load():
    x = load('/home/pi/Desktop/diyHue/cookiecutter.json')
    if not x:
        print("Test case 0: successful")
    else:
        print("Test case 0: unsuccessful")


# Generated at 2022-06-25 15:35:06.113291
# Unit test for function dump
def test_dump():
    replay_dir = 'replay_test_dir'
    template_name = 'template_name_str'
    context = {'cookiecutter':{'full_name':'test_full_name', 'github_username':'test_github_username'}}
    try:
        dump(replay_dir, template_name, context)
        context_1 = load(replay_dir, template_name)
        assert context == context_1
        print("Test case 0 passed")
    except NameError:
        print(str_0)
    except AssertionError:
        print("Test case 0 failed")


# Generated at 2022-06-25 15:35:07.540298
# Unit test for function dump
def test_dump():
    str_0 = 'Function dump not defined'


# Generated at 2022-06-25 15:35:14.712096
# Unit test for function load
def test_load():
    print ("This is function load")
    replay_dir = 'replay_dir'
    template_name = 'template_name'
    context = { 
        'cookiecutter': { 
            'replay': [ 
                '{{ *foo }}',
                '{{ *bar }}'
            ],
            'default_context': {
                'foo': 'This is foo',
                'bar': 'This is bar'
            }
        }
    }
    assert context == load(replay_dir, template_name), test_case_0()


# Generated at 2022-06-25 15:35:17.383101
# Unit test for function load
def test_load():
    replay_dir = ""
    template_name = "string"

    try:
        load()
    except TypeError:
        return


# Generated at 2022-06-25 15:35:27.924531
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/replay'
    template_name = 'example_repo'
    # Template name is required to be a str
    try:
        dump(replay_dir, list(), {})
    except TypeError as e:
        assert(str(e) == 'Template name is required to be of type str')
    # Context is required to be a dict
    try:
        dump(replay_dir, template_name, list())
    except TypeError as e:
        assert(str(e) == 'Context is required to be of type dict')
    # Context is required to contain a cookiecutter key
    try:
        dump(replay_dir, template_name, {})
    except ValueError as e:
        assert(str(e) == 'Context is required to contain a cookiecutter key')
    #

# Generated at 2022-06-25 15:35:31.571616
# Unit test for function load
def test_load():
    test_case_0()

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-25 15:35:32.515307
# Unit test for function dump
def test_dump():
    assert dump == 0




# Generated at 2022-06-25 15:35:36.053971
# Unit test for function load

# Generated at 2022-06-25 15:35:37.438586
# Unit test for function load
def test_load():
    assert str_0=='Function load not defined'


# Generated at 2022-06-25 15:35:41.325997
# Unit test for function get_file_name
def test_get_file_name():
    # Test case 0
    # get_file_name('tests/test_files/replay_folders', 'my_template')
    assert get_file_name('tests/test_files/replay_folders', 'my_template') == 'tests/test_files/replay_folders/my_template.json'


# Generated at 2022-06-25 15:35:51.947770
# Unit test for function dump
def test_dump():
    # correct invocation
    try:
        dump('/tmp/cc_replay/', 'cookiecutter-pypackage', {'cookiecutter': {'full_name': 'My Name', 'email': 'myemail@example.com'}})
        str1_0 = 'Success'
    except:
        str1_0 = 'Function dump not defined'
    # invocation with incorrect parameter - template_name
    try:
        dump('/tmp/cc_replay/', None, {'cookiecutter': {'full_name': 'My Name', 'email': 'myemail@example.com'}})
        str1_1 = 'Success'
    except:
        str1_1 = 'Expected exception raised - template_name'
    # invocation with incorrect parameter - context

# Generated at 2022-06-25 15:35:57.535124
# Unit test for function dump
def test_dump():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    cli_arguments = ['cookiecutter', '--no-input', '-f', '-o', '../tests/']
    template_name = '../tests/'
    context = {'cookiecutter': {'full_name': 'Firstname Lastname', 'email': 'example@example.com', 'github_username': 'example', 'project_name': 'Test project', 'project_short_description': 'A short description of the project.', 'release_date': '2014', 'version': '0.1.0'}}
    with patch('sys.argv', cli_arguments) as mock_sys_argv:
        template_path = utils.find_template(template_name)

# Generated at 2022-06-25 15:36:05.254986
# Unit test for function load
def test_load():
    str_0 = 'mi:X\t![kfr.i;AWGF'
    str_1 = 'x\x01{z\x05\x01X>\x1ak\x1a\x0c\x13'
    dict_0 = load(str_0, str_1)
    assert len(dict_0) == 0


# Generated at 2022-06-25 15:36:09.639600
# Unit test for function dump
def test_dump():
    assert not False


# Generated at 2022-06-25 15:36:11.016591
# Unit test for function dump
def test_dump():
    assert dump(False, False, False) == False


# Generated at 2022-06-25 15:36:14.725166
# Unit test for function load
def test_load():
    # Unit test for function load
    replay_dir = "test_replay"
    template_name = "test_template"
    # Call function load
    test_case_0()


# Generated at 2022-06-25 15:36:16.485968
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 15:36:19.075160
# Unit test for function load
def test_load():
    assert load('mi:X\t![kfr.i;AWGF', 'mi:X\t![kfr.i;AWGF') == 'mi:X\t![kfr.i;AWGF'



# Generated at 2022-06-25 15:36:22.843070
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = r'''C:\Users\jhamerski\Documents\repos\cookiecutter-gh-pages'''
    template_name = r'''cookiecutter-gh-pages'''
    expected_file_name = os.path.join(replay_dir, template_name+'.json')
    file_name = get_file_name(replay_dir, template_name)
    assert file_name == expected_file_name


# Generated at 2022-06-25 15:36:27.074531
# Unit test for function load
def test_load():
    try:
        template_name_0 = 'vdm{'
        replay_dir_0 = '\x1d-a>=TjT'
        var_0 = load(replay_dir_0, template_name_0)
    except:
        print('Error during test: load')


# Generated at 2022-06-25 15:36:32.206159
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except TypeError:
        pass

    try:
        var_1 = load(str, str)
    except TypeError:
        pass

    try:
        var_2 = load(str, str)
    except TypeError:
        pass



# Generated at 2022-06-25 15:36:34.934683
# Unit test for function load
def test_load():
    """Test function load."""
    os.chdir('/')
    # Test case 0
    expected_0 = None
    actual_0 = test_case_0()
    assert actual_0 == expected_0

test_load()

# Generated at 2022-06-25 15:36:42.663017
# Unit test for function load
def test_load():
    str_0 = 'nm:aYX\t![kfq.x;EHSB'
    context = load(str_0, str_0)
    assert context['cookiecutter']['replay_dir'] == str_0
    assert context['cookiecutter']['template'] == str_0

# Generated at 2022-06-25 15:36:46.464708
# Unit test for function load
def test_load():
    str_0 = '\x1e\x00\x00\x00'
    template_name = '\x04\x00\x00\x00'
    var_0 = load(template_name, template_name)


# Generated at 2022-06-25 15:36:52.428415
# Unit test for function load
def test_load():
    context_key = 'cookiecutter'
    str_0 = 'replay'
    replay_file = get_file_name(str_0, str_0)
    context = {context_key: 'cookiecutter'}
    with open(replay_file, 'w') as outfile:
        json.dump(context, outfile, indent=2)

    context_returned = load(str_0, str_0)
    assert str_0 == str_0

# Generated at 2022-06-25 15:36:54.129459
# Unit test for function load

# Generated at 2022-06-25 15:36:58.159923
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name('E:\\ACM\\Program\\Codes\\Test', 'mi:X\t![kfr.i;AWGF') == \
    'E:\\ACM\\Program\\Codes\\Test\\mi:X\t![kfr.i;AWGF.json'


# Generated at 2022-06-25 15:37:03.192401
# Unit test for function load
def test_load():
    # stub_file = 'C:\\stub.json'
    # expected = [
    #     'Test'
    # ]
    # actual = load(stub_file, stub_file)
    assert True


# Generated at 2022-06-25 15:37:05.336904
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:37:12.850931
# Unit test for function dump
def test_dump():
    str_0 = 'aY\t;b[%'
    assert dump(os.path.abspath(os.path.join(os.path.dirname(__file__), 'tests/files')), '1', {str_0: {str_0: 'd', 'a': '2|1W>'}}) == None


# Generated at 2022-06-25 15:37:20.702723
# Unit test for function get_file_name
def test_get_file_name():
    str_0 = 'VpY=`d)t^'
    str_1 = 'P~gTlT.'
    var_0 = get_file_name(str_0, str_1)
    var_1 = get_file_name(str_1, str_1)


# Generated at 2022-06-25 15:37:26.551528
# Unit test for function get_file_name
def test_get_file_name():
    template_name = 'test.json'
    replay_dir = os.path.abspath(os.path.join(os.getcwd(), 'files', 'replay'))
    replay_file = get_file_name(replay_dir, template_name)
    assert replay_file == os.path.join(replay_dir, 'test.json')



# Generated at 2022-06-25 15:37:31.682839
# Unit test for function dump
def test_dump():
    print('Testing dump')
    assert(True)


# Generated at 2022-06-25 15:37:37.598113
# Unit test for function load
def test_load():

    # Call function to create mock data
    test_data = test_case_0()

    # Load function as str_0
    str_0 = 'mi:X\t![kfr.i;AWGF'
    from cookiecutter.replay import load
    var_0 = load(str_0, str_0)

    assert (var_0) == test_data


# Generated at 2022-06-25 15:37:40.690014
# Unit test for function load
def test_load():
    # Input parameters
    replay_dir = 'r'
    template_name = 'r'

    var_0 = load(replay_dir, template_name)
    # Assertion error if file_content is None
    assert var_0 == None


# Generated at 2022-06-25 15:37:45.777001
# Unit test for function dump
def test_dump():
    str_0 = 'pS5<g'
    str_1 = 'test_template'
    dict_0 = {'cookiecutter': {'project_name': 'test'}}
    dump(str_0, str_1, dict_0)


# Generated at 2022-06-25 15:37:52.816515
# Unit test for function load
def test_load():
    str_0 = 'dt:C\tY)U*S_[N'
    str_1 = 'mi:X\t![kfr.i;AWGF'
    var_0 = load(str_0, str_1)


# Generated at 2022-06-25 15:37:55.800841
# Unit test for function dump
def test_dump():
    var_0 = 'q|eK/'
    var_1 = 'r5*AGA'
    var_2 = dump(var_0, var_1, var_0)
    assert var_2 == None, "The cookiecutter's dump method did not return the expected value"



# Generated at 2022-06-25 15:37:57.671122
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:38:01.349396
# Unit test for function dump
def test_dump():
    print('Testing dump')
    str_0 = 'mi:X\t![kfr.i;AWGF'
    dict_0 = dict()
    dict_0['cookiecutter'] = dict_0
    dump(str_0, str_0, dict_0)
    print('Testing dump completed')


# Generated at 2022-06-25 15:38:08.194157
# Unit test for function load
def test_load():
    file_name = 'file_name'
    replay_dir = 'replay_dir'
    template_name = 'template_name'

    if not template_name.endswith('.json'):
        if not make_sure_path_exists(replay_dir):
            raise IOError('Unable to create replay dir at {}'.format(replay_dir))
    if not make_sure_path_exists(replay_dir):
        raise IOError('Unable to create replay dir at {}'.format(replay_dir))


# Generated at 2022-06-25 15:38:13.086436
# Unit test for function dump
def test_dump():
    replay_file = dump('c', 'b', {'cookiecutter': {'bootstrap': 'a'}})
    assert 'c.b.json' == replay_file


# Generated at 2022-06-25 15:38:21.697931
# Unit test for function load
def test_load():
    out_1 = load(str(), dict())
    assert out_1 == dict()

    out_2 = load(str(), str())
    assert out_2 == dict()



# Generated at 2022-06-25 15:38:31.060196
# Unit test for function dump
def test_dump():
    # Test if a context is a dictionary
    with open('test_dump.json', 'r') as f:
        context = json.load(f)
    try:
        dump('.', '', context)
        assert False
    except TypeError:
        assert True
    # Test if a template_name is a string
    try:
        dump('.', '', [])
        assert False
    except TypeError:
        assert True
    # Test if a directory exists
    try:
        dump('a', '', context)
        assert False
    except IOError:
        assert True
    # Test if a context contains cookiecutter key
    del context['cookiecutter']
    try:
        dump('.', '', context)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-25 15:38:34.307624
# Unit test for function load
def test_load():
    try:
        assert callable(load)
    except AssertionError as err:
        print('[-] load not callable.\n{0}'.format(err))
        sys.exit(1)


# Generated at 2022-06-25 15:38:36.933892
# Unit test for function load
def test_load():
    str_0 = '4:X\t![kfr.i;AWGF'
    var_0 = load(str_0, str_0)
    assert not isinstance(var_0, str)
    return var_0


# Generated at 2022-06-25 15:38:43.170215
# Unit test for function load
def test_load():
    assert not load("mi:X\t![kfr.i;AWGF", "mi:X\t![kfr.i;AWGF")

if __name__ == "__main__":
    # Unit test for function get_file_name
    get_file_name("E#\x9c\xbd\xa5\xe8\xfd\x91\xcd", "E#\x9c\xbd\xa5\xe8\xfd\x91\xcd")
    # Unit test for function dump
    dump("E#\x9c\xbd\xa5\xe8\xfd\x91\xcd", "E#\x9c\xbd\xa5\xe8\xfd\x91\xcd", {})

# Generated at 2022-06-25 15:38:48.799412
# Unit test for function dump
def test_dump():
    """Test function dump."""
    name = 'test'
    replay_dir = 'output'
    context = {'cookiecutter': {'full_name': 'Boris Feld', 'email': 'lothiraldan@gmail.com'}}

    dump(replay_dir, name, context)

    # Test
    assert os.path.exists(os.path.join(replay_dir, name + '.json'))



# Generated at 2022-06-25 15:38:50.328216
# Unit test for function dump
def test_dump():
    # TODO: Test that the cookiecutter value is present in the file
    pass


# Generated at 2022-06-25 15:38:51.109524
# Unit test for function load
def test_load():
    # Verify that the function returns the proper value
    assert load() == None


# Generated at 2022-06-25 15:38:51.737768
# Unit test for function load
def test_load():
    assert callable(load)

# Generated at 2022-06-25 15:38:54.723204
# Unit test for function load
def test_load():
    str_0 = 'template_name'
    str_1 = 'replay_dir'
    try:
        load(str_0, str_0)
    except TypeError:
        pass
    except:
        assert False
    try:
        load(str_1, str_0)
    except ValueError:
        pass
    except:
        assert False


# Generated at 2022-06-25 15:39:10.833797
# Unit test for function dump

# Generated at 2022-06-25 15:39:14.551589
# Unit test for function load
def test_load():
    try:
        str_0 = 'mi:X\t![kfr.i;AWGF'
        test_case_0()
        print('pass')
    except Exception:
        print('fail')


# Generated at 2022-06-25 15:39:16.718241
# Unit test for function load
def test_load():
    str_1 = '!.+9X-L\t|?'
    str_0 = '6'
    var_2 = load(str_0, str_0)


# Generated at 2022-06-25 15:39:18.425220
# Unit test for function load
def test_load():
    assert callable(load)



# Generated at 2022-06-25 15:39:23.570138
# Unit test for function load
def test_load():
    str_0 = 'h4b4H,0'
    str_1 = '9#!mz'
    str_2 = '$Aca,=J\x7f8(c5U5'
    var_0 = load(str_0, str_1)
    var_1 = load(str_2, str_2)
    if(var_0 != var_1):
        print('FAILED in test_load')

# Script starts from here

if __name__ == "__main__":
    test_load()
    print('Test finished')

# Generated at 2022-06-25 15:39:34.547748
# Unit test for function dump
def test_dump():
    str_0 = '!@#$%^&*()_+-'
    str_1 = './<>?;\'`:"{}|=\]['
    str_2 = 'hello world'
    str_3 = '1234567890'
    str_4 = 'qwertyuiopasdfghjklzxcvbnm'
    str_5 = str_4
    str_6 = 'QWERTY\tUIOPASDFGHJKLZXCVBNM'
    ret_0 = dump(str_0, str_1, str_2)
    assert ret_0 == None
    ret_1 = dump(str_3, str_4, str_5)
    assert ret_1 == None
    ret_2 = dump(str_3, str_4, str_6)
    assert ret_

# Generated at 2022-06-25 15:39:42.716388
# Unit test for function load
def test_load():
    str_0 = 'LrjOw&2\n;KjF?*Aw\tslXv"'
    str_1 = 'Jh%\tCaG5z'
    var_0 = load(str_0, str_1)
    assert var_0["cookiecutter"] ==  {}
    var_1 = load(str_0, str_1)
    assert var_1["cookiecutter"] ==  {}
    str_2 = 'X\tO4N*R;^e!\n'
    var_2 = load(str_0, str_2)
    assert var_2["cookiecutter"] ==  {}
    str_3 = 'rG?'
    str_4 = 'YHXb\n{nI\t'

# Generated at 2022-06-25 15:39:52.400816
# Unit test for function load
def test_load():
    str_0 = 'bzX&OuL;AQV\t<\r'
    str_1 = 'bzX&OuL;AQV\t<\r'
    str_2 = '.\t5=S\nS[H'
    str_3 = '{{cookiecutter.repo_name}}'
    var_0 = load(str_0, str_0)
    assert var_0 == {"cookiecutter": {"repo_name": "my_test_project"}}
    var_1 = load(str_1, str_2)
    assert var_1 == {"cookiecutter": {"repo_name": "{{cookiecutter.repo_name}}"}}


# Generated at 2022-06-25 15:39:57.839482
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except:
        print('Can\'t load function load')


# Generated at 2022-06-25 15:40:06.349427
# Unit test for function dump
def test_dump():
    str_0 = 'mi:X\t![kfr.i;AWGF'
    str_1 = 'mf<w]DY,L&vG8W?U0}6'
    str_2 = 'st8W0~%r=K]Y*[N5_OIt'
    str_3 = 'RKg+^f;@C}mR0Y7`\t=('
    str_4 = 'zD$4VX3x?iu^)V0j1-RE'
    str_5 = '/>|s:sT(T]c%Z9KxG/b_'
    dump(str_0, str_1, str_2)
    dump(str_0, str_3, str_4)

# Generated at 2022-06-25 15:40:52.866174
# Unit test for function dump
def test_dump():
    str_1 = 'mi:X\t![kfr.i;AWGF'
    str_2 = 'mi:X\t![kfr.i;AWGF'
    str_3 = 'mi:X\t![kfr.i;AWGF'
    str_4 = 'mi:X\t![kfr.i;AWGF'
    str_5 = 'mi:X\t![kfr.i;AWGF'
    str_6 = 'mi:X\t![kfr.i;AWGF'
    str_7 = 'mi:X\t![kfr.i;AWGF'
    str_8 = 'mi:X\t![kfr.i;AWGF'
    str_9 = 'mi:X\t![kfr.i;AWGF'
   

# Generated at 2022-06-25 15:40:54.148038
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:41:02.997478
# Unit test for function load
def test_load():
    str_0 = 'mi:X\t![kfr.i;AWGF'
    var_0 = load(str_0, str_0)
    assert type(var_0) == dict
    assert var_0 == {'cookiecutter': {'_copy_without_render': ['setup.py', 'Makefile', 'README.rst']}}
    str_1 = 'mi:X\t![kfr.i;AWGF'
    var_1 = load(str_1, str_1)
    assert type(var_1) == dict
    assert var_1 == {'cookiecutter': {'_copy_without_render': ['setup.py', 'Makefile', 'README.rst']}}


# Generated at 2022-06-25 15:41:04.075440
# Unit test for function load
def test_load():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 15:41:07.586736
# Unit test for function load
def test_load():
    # Test raise exception for invalid input
    try:
        assert(load(1, 1))
    except TypeError as e:
        pass

    try:
        assert(load('path', 'name'))
    except ValueError as e:
        pass

    # Test for normal input
    assert(load('path', str_0))


# Generated at 2022-06-25 15:41:14.882566
# Unit test for function load
def test_load():
    replay_dir = 'n1dji'
    template_name = 'n1dji'

    # Test 1
    try:
        utils.mkdir_p(replay_dir)
    except IOError:
        pass

    f = open(os.path.join(replay_dir, template_name + '.json'), mode='w', encoding='utf-8')
    f.write('{\"cookiecutter\": {\"full_name\": \"hello\",\"email\": \"world\"}}')
    f.close()
    result = load(replay_dir, template_name)
    assert result == {'cookiecutter': {'full_name': 'hello', 'email': 'world'}}



# Generated at 2022-06-25 15:41:20.920591
# Unit test for function load
def test_load():
    replay_dir = 'test_replay_dir'
    template_name = 'test_template'

    dump(replay_dir, template_name, {'cookiecutter': 'bar'})
    context = load(replay_dir, template_name)
    assert context['cookiecutter'] == 'bar'


if __name__ == '__main__':
    import sys
    sys.exit(test_case_0())

# Generated at 2022-06-25 15:41:26.887399
# Unit test for function load
def test_load():
    try:
        assert False
    except AssertionError as e:
        raise(e)
    else:
        pass
    finally:
        pass


# Generated at 2022-06-25 15:41:33.630579
# Unit test for function load
def test_load():
    template_name = 'test_template'
    context = {'cookiecutter': {'name': 'Philippe'}}
    replay_dir = 'tmp'
    dump(replay_dir, template_name, context)
    assert load(replay_dir, template_name) == context
    os.remove(os.path.join(replay_dir, '{}.json'.format(template_name)))
    os.rmdir(replay_dir)



# Generated at 2022-06-25 15:41:36.067370
# Unit test for function load
def test_load():
    context = load("abc", "abc")
    assert context == {'cookiecutter': {'_template': 'abc'}}


# Generated at 2022-06-25 15:42:40.463623
# Unit test for function dump
def test_dump():
    replay_dir = 'test_inputs\\test_dir\\'
    template_name = 'hello_world'
    context = {
        'cookiecutter': {
            'project_name': 'hello_world',
            'repository_name': 'hello_world',
            'author_name': 'Your Name',
            'email': 'youremail@example.com',
            'release_date': '2017-10-29',
            'version': '0.1.0',
            'description': 'hello world project'
        }
    }

    try:
        dump(replay_dir, template_name, context)
    except IOError as e:
        str = 'Unable to create replay dir at {}'.format(replay_dir)
        assert(str == str(e))


# Generated at 2022-06-25 15:42:47.297526
# Unit test for function load
def test_load():
    # Make sure these files exist for the test
    test_files = [
        'test0.json',
        'test1.json'
    ]
    # Test with valid input
    assert load('test', test_files[0]) == {'cookiecutter': {'hello': 'world'}}
    # Test with non-existent file
    try:
        load('test', test_files[1])
    except IOError:
        assert True
    # Test with not a string as template name
    try:
        load('test', {'hello': 'world'})
    except TypeError:
        assert True


# Generated at 2022-06-25 15:42:49.793308
# Unit test for function load
def test_load():
    assert load('abc','abc') == 'abc'
    assert load('abc','abc') !=  'abcd'


# Generated at 2022-06-25 15:42:56.060933
# Unit test for function load
def test_load():
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    str_1 = 'jklhgfedcba'
    str_2 = 'aaaaaa'
    str_3 = 'aaaaaaaa'
    dict_0 = {}
    dict_1 = {}

    for i_0 in range(10,20):
        dict_0[str_0 + str(i_0)] = str(i_0)
    dict_1['cookiecutter'] = dict_0

    dump(str_3,str_0,dict_1)
    dict_1 = load(str_3,str_0)

    print(dict_1)

    os.remove(str_3 + '/' + str_0 + '.json')

# Generated at 2022-06-25 15:42:58.779682
# Unit test for function load
def test_load():
    print('********** Testing load **********')
    # Test case 0
    #
    # Just a bunch of weird characters.
    #
    str_0 = 'mi:X\t![kfr.i;AWGF'
    var_0 = load(str_0, str_0)
    
    
if __name__ == "__main__":
    test_load()