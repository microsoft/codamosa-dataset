

# Generated at 2022-06-25 15:33:01.868631
# Unit test for function load
def test_load():
    str_0 = 'oqw(s/A",sg'
    int_0 = 1024
    var_0 = load(str_0, int_0)
    assert var_0 is None
    assert not var_0
    str_0 = 'oqw(s/A",sg'
    int_0 = 1024
    var_0 = load(str_0, int_0)
    assert var_0 is None
    assert not var_0

# Generated at 2022-06-25 15:33:02.904248
# Unit test for function load
def test_load():
    test_case_0()

# Generated at 2022-06-25 15:33:05.641330
# Unit test for function load
def test_load():
    str_0 = 'asdf'
    test_load_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:33:18.016356
# Unit test for function dump
def test_dump():
    import shutil
    str_0 = 'L("*4%'
    str_1 = './examples'
    str_2 = 'example_nested'
    int_0 = 1024
    dict_0 = {
        'cookiecutter': {'full_name': str_1, 'project_name': str_2, 'email': str_0},
        'other_key': 'other_value'
    }
    dump(str_2, int_0, dict_0)
    str_3 = 'example'
    dict_1 = {
        'cookiecutter': {'full_name': str_2, 'project_name': str_1, 'email': str_2},
        'other_key': 'other_value'
    }
    dump(str_3, int_0, dict_1)


# Generated at 2022-06-25 15:33:23.263729
# Unit test for function load
def test_load():
    try:
        template_name = '../tests/files/cookiecutters/fake-repo-pre/'
        replay_dir = 'replay_dir'
        context = load(replay_dir, template_name)
    except:
        assert False
    else:
        assert type(context) is dict and context != {}


# Generated at 2022-06-25 15:33:29.976452
# Unit test for function load
def test_load():
    str_0 = 's9UVx?_s=s'
    str_1 = 'kI%k50/Q/i1.3/q'
    str_2 = '?&N#/oBzt:F(t4h~Rl'
    str_3 = '|X$>xS2RO5Sl\a3q.n'
    str_4 = 'WuVvcvn*\|X)>xS2RO5Sl\n'
    str_5 = 'B4/b<]pf\./O!o>|X$>xS2RO5Sl\a3q.n'
    str_6 = '~0V<K@t>|X$>xS2RO5Sl\n'

# Generated at 2022-06-25 15:33:33.631692
# Unit test for function load
def test_load():
    str_0 = '!@#$%^&*()_+'
    int_0 = 1024
    load(str_0, int_0)


# Generated at 2022-06-25 15:33:42.942837
# Unit test for function get_file_name
def test_get_file_name():
    str_0 = 'u-kdf{V7sj6P'
    str_1 = '="yDGwz&bljK'
    var_0 = get_file_name(str_0, str_1)
    assert var_0 == '/u-kdf{V7sj6P/="yDGwz&bljK.json'
    str_0 = '0x!h[[.CmZUf'
    str_1 = '7q!j]S a!n"z'
    var_0 = get_file_name(str_0, str_1)
    assert var_0 == '0x!h[[.CmZUf/7q!j]S a!n"z.json'
    str_0 = '{bLFwq3ex_'


# Generated at 2022-06-25 15:33:44.040170
# Unit test for function dump
def test_dump():
    dump(None, 1, 1)


# Generated at 2022-06-25 15:33:49.716769
# Unit test for function dump
def test_dump():
    str_0 = 'oqw(s/A",sg'
    str_1 = '~/G'
    var_0 = dump(str_0, str_1, 1024)
    var_1 = dump(str_0, str_1, 1024)
    var_2 = dump(str_0, str_1, 1024)
    var_3 = dump(str_0, str_1, 1024)
    var_4 = dump(str_0, str_1, 1024)


# Generated at 2022-06-25 15:33:52.824177
# Unit test for function load
def test_load():
    load('', '')


# Generated at 2022-06-25 15:33:53.886274
# Unit test for function load

# Generated at 2022-06-25 15:33:55.163331
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:34:02.386777
# Unit test for function dump
def test_dump():
    try:
        os.mkdir('dump')
    except OSError:
        pass
    context = {'cookiecutter': {'full_name': 'Ravi Hukkeri', 'email': 'hravi@qxf2.com', 'github_username': 'hravi'}}
    dump('dump',  'base_project', context)
    dump('dump/', 'base_project', context)
    dump('dump/', 'base_project.json', context)


# Generated at 2022-06-25 15:34:07.313872
# Unit test for function dump
def test_dump():
    os.environ['REPLAY_DIR_PATH'] = '.'
    try:
        dump('.', 'test', {'cookiecutter': {'full_name': 'Test', 'project_name': 'test'}})
        assert(load('.', 'test') == {'cookiecutter': {'full_name': 'Test', 'project_name': 'test'}})
    finally:
        os.remove('./test.json')


# Generated at 2022-06-25 15:34:10.616205
# Unit test for function load
def test_load():
    str_0 = 'asdf'
    var_0 = load(str_0, str_0)

# Generated at 2022-06-25 15:34:18.555691
# Unit test for function load
def test_load():
    str_1 = 'asdf'
    str_2 = 'asdf'
    str_3 = 'asdf'
    # str_1 is template_name. str_2 is replay_dir.
    generate_file_path = os.path.join(str_2, str_1)
    # Generate replay file.
    with open(generate_file_path, 'w') as f:
        f.write(str_3)
    # Load it.
    output = load(str_2, str_1)
    expected_output = str_3
    assert output == expected_output

# Generated at 2022-06-25 15:34:27.545157
# Unit test for function load
def test_load():
    str_0 = 'Cookiecutter'
    var_0 = load(str_0, str_0)
    assert (var_0 == {'cookiecutter': {'name': 'Cookiecutter'}})

# Generated at 2022-06-25 15:34:38.049543
# Unit test for function dump
def test_dump():
    # Test case 0
    print('Test case 0')
    str_0 = 'asdf'
    dict_0 = dict()
    dict_0['cookiecutter'] = dict()
    dict_0['cookiecutter']['full_name'] = 'John Doe'
    dict_0['cookiecutter']['email'] = 'john@doe.com'
    dict_0['cookiecutter']['github_username'] = 'johndoe'
    dict_0['cookiecutter']['project_name'] = 'My Project'
    dict_0['cookiecutter']['project_short_description'] = 'Short description'
    dict_0['cookiecutter']['open_source_license'] = 'GNU AGPLv3'

# Generated at 2022-06-25 15:34:39.951238
# Unit test for function dump
def test_dump():
    dump_tester_0 = load('asdf', 'asdf')
    assert dump_tester_0 is not None


# Generated at 2022-06-25 15:34:43.683948
# Unit test for function dump
def test_dump():
    str_0 = 'wtKiH'
    str_1 = 'zsHbG'
    var_0 = dump(str_1, str_1, str_0)


# Generated at 2022-06-25 15:34:45.898671
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except Exception as e:
        var_1 = type(e)


# Generated at 2022-06-25 15:34:49.973039
# Unit test for function dump
def test_dump():
    str_0 = 'asdf'
    str_1 = 'qwer'
    str_2 = 'zxcv'
    str_3 = 'uiop'
    dump(str_0, str_1, str_2)
    dump(str_0, str_1, str_2)
    dump(str_0, str_1, str_2)


# Generated at 2022-06-25 15:34:58.542199
# Unit test for function load
def test_load():
    # str, str -> dict
    # Example: test case 0
    str_0 = 'cookiecutter-pypackage'
    str_1 = 'cookiecutter.json'
    dict_0 = load(str_0, str_1)
    assert type(dict_0) == dict
    # Example: test case 1
    str_2 = 'cookiecutter-pypackage'
    str_3 = 'cookiecutter.json'
    dict_1 = load(str_2, str_3)
    assert type(dict_1) == dict


# Generated at 2022-06-25 15:35:08.057685
# Unit test for function dump
def test_dump():
    dump('dump_test_0','dump_test_1',{})
    dump('dump_test_2','dump_test_3',{'cookiecutter': {'asdf':'asdf'}})
    dump('dump_test_4','dump_test_5',{'cookiecutter': {'asdf':'asdf'}, 'asdf':'asdf'})
    dump('dump_test_6','dump_test_7',{'cookiecutter': {'asdf':'asdf'}, 'asdf':'asdf', 'sadf':'asdf', 'asg':'asdf'})
    dump('dump_test_8','dump_test_9',{'asdf':'asdf', 'sadf':'asdf', 'asg':'asdf'})


# Generated at 2022-06-25 15:35:14.891957
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-repo-pre/'
    template_name = 'boilerplate'
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter': {'_copy_without_render': ['CHANGELOG.rst', 'LICENSE'], '_copy_without_render_root': ['requirements.txt'], 'full_name': 'Audrey Roy', 'github_username': 'audreyr', 'project_name': 'project_name', 'project_short_description': 'A short description of the project.', 'project_slug': 'project-slug', 'release_date': '2014-08-27'}}



# Generated at 2022-06-25 15:35:16.892188
# Unit test for function load
def test_load():
    assert not load('foo', 'bar')


# Generated at 2022-06-25 15:35:25.437378
# Unit test for function load
def test_load():
    replay_dir = '/replay_dir/'
    template_name = 'template_name'

    if not isinstance(template_name, str):
        raise TypeError('Template name is required to be of type str')

    replay_file = get_file_name(replay_dir, template_name)

    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    if 'cookiecutter' not in context:
        raise ValueError('Context is required to contain a cookiecutter key')

    return context

# Generated at 2022-06-25 15:35:28.021274
# Unit test for function dump
def test_dump():
    str_1 = 'asdf'
    dump(str_1, str_1, var_0)
    dump(str_1, str_1, var_0)
    dump(str_1, str_1, var_0)

# Generated at 2022-06-25 15:35:31.736249
# Unit test for function load
def test_load():
    class_0 = Bunch
    class_0.bacon = 'eggs'
    class_1 = object
    int_0 = 0
    pytest.raises(TypeError, load, class_1, int_0)
    pytest.raises(ValueError, load, class_0, int_0)


# Generated at 2022-06-25 15:35:39.024280
# Unit test for function load
def test_load():
    print("test_load()")
    replay_dir = os.environ.get("TEST_DATA_PATH") + "/"
    template_name = "test_playbook"
    context = load(replay_dir, template_name)
    print(context)
    assert "cookiecutter" in context

if __name__ == '__main__':
    test_case_0() # for pdb
    test_load()

# Generated at 2022-06-25 15:35:47.297194
# Unit test for function load
def test_load():
    # Test template_name type
    try:
        str_0 = 'asdf'
        load(str_0, str_0)
    except TypeError:
        pass
    replay_dir_0 = 'asdf'
    try:
        load(replay_dir_0, str_0)
    except ValueError:
        pass

    # Test template_name content
    replay_dir_0 = 'asdf'
    try:
        load(replay_dir_0, str_0)
    except ValueError:
        pass


# Generated at 2022-06-25 15:35:49.321326
# Unit test for function load
def test_load():
    # Arguments
    replay_dir = './tests/fake-repo-pre/'
 

# Generated at 2022-06-25 15:36:01.615127
# Unit test for function dump
def test_dump():
    import os.path
    import json
    # write a test json string to a file
    test_json_string = {'a':1, 'b':2, 'c':3}
    with open('test_dump.txt', 'w') as f:
            json.dump(test_json_string, f)
    # confirm the file was created
    assert(os.path.isfile('test_dump.txt'))
    # confirm the file has a json format
    with open('test_dump.txt', 'r') as f:
        read_string = json.loads(f.read())
    for key in read_string:
        assert(key in test_json_string)
    # delete the test file
    os.remove('test_dump.txt')


# Generated at 2022-06-25 15:36:03.892748
# Unit test for function load
def test_load():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 15:36:10.327279
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    import os

    json_file = cookiecutter('tests/fake-repo-tmpl', no_input=True)
    json_file_path = os.path.join(json_file['cookiecutter']['_replay_dir'], 'fake-repo.json')
    with open(json_file_path, 'r', encoding='utf-8') as raw_json:
        json_in_memory = json.load(raw_json)
    assert json_file == json_in_memory


# Generated at 2022-06-25 15:36:11.280017
# Unit test for function load
def test_load():
    assert load() == 'expected'


# Generated at 2022-06-25 15:36:17.838161
# Unit test for function dump
def test_dump():
    replay_dir = '/tmp'
    template_name = 'test'
    context = {'cookiecutter': {'project_name': 'test'}}
    dump(replay_dir, template_name, context)
    if not os.path.isfile(get_file_name(replay_dir, template_name)):
        print(os.path.isfile(get_file_name(replay_dir, template_name)))
        test_case_0()

# Generated at 2022-06-25 15:36:19.091106
# Unit test for function load
def test_load():
    assert load('../replay/', 'asdf') == 'asdf'


# Generated at 2022-06-25 15:36:31.232366
# Unit test for function dump
def test_dump():
    # Verify that the replay json file was dumped with the same content
    # in context and it was dumped in the same file path.
    from cookiecutter import replay
    import os
    import json
    import random, string
    # Append some random string to the replay directory so that it will not 
    # overwrite existing replay files on the system. 
    replay_dir = os.path.join(os.path.expanduser('~'), ".cookiecutters{}".format(''.join([random.choice(string.ascii_letters) for i in range(10)])))
    template_name = "test_replay_json"
    # Verify that the context dict has all the required keys.

# Generated at 2022-06-25 15:36:43.720750
# Unit test for function dump
def test_dump():
    # Test exception case
    try:
        dump([], {}, [])
        assert(False)
    except Exception as e:
        assert(str(e) == "Unable to create replay dir at []")
    try:
        dump({}, {}, [])
        assert(False)
    except Exception as e:
        assert(str(e) == "Template name is required to be of type str")
    try:
        dump([], '', [])
        assert(False)
    except Exception as e:
        assert(str(e) == "Context is required to be of type dict")
    try:
        dump([], '', {})
        assert(False)
    except Exception as e:
        assert(str(e) == "Context is required to contain a cookiecutter key")


# Generated at 2022-06-25 15:36:49.487619
# Unit test for function load
def test_load():
    replay_dir = 'C:\\Users\\cgonzales\\PycharmProjects\\cookiecutter-replay\\cookiecutter-replay\\tests\\replay_dir'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    str_0 = context['cookiecutter']['full_name']


# Generated at 2022-06-25 15:36:55.284060
# Unit test for function load
def test_load():
    function_name = 'load'
    print('\nRunning test for function: {}'.format(function_name))
    try:
        pass
        # load()
    except Exception as e:
        print('\nFunction {} failed test with error: {}'.format(function_name, e))
    else:
        print('\nFunction {} passed all tests!'.format(function_name))


# Generated at 2022-06-25 15:36:58.255257
# Unit test for function load
def test_load():
    # Write test passes
    print("Testing load function...")
    print("Passing test case 0...")
    try:
        load('./replay')
    except IOError:
        print("Test case 0 passed")

# Generated at 2022-06-25 15:37:05.580190
# Unit test for function load
def test_load():
    replay_dir = '/Users/brianspeir/cookiecutter/brianspeir/cookiecutter-pypackage'
    template_name = '/Users/brianspeir/cookiecutter/brianspeir/cookiecutter-pypackage'
    #context =
    load(replay_dir, template_name)


# Generated at 2022-06-25 15:37:12.482446
# Unit test for function load
def test_load():
    setUp()
    str_0 = 'bk'
    str_1 = 'cn'
    obj_0 = Context(str_0)
    obj_0.__setitem__(str_1, str_0)
    load(obj_0, str_0)
    tearDown()


# Generated at 2022-06-25 15:37:16.811530
# Unit test for function load
def test_load():
    try:
        load('/home/xiao/code/python/cookiecutter/tests/test-replay-dir/', 'test-repo-name')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 15:37:20.654751
# Unit test for function load
def test_load():
    try:
        load(1, 1)
    except:
        print('yes')



if __name__ == '__main__':
    #test_load()
    test_case_0()

# Generated at 2022-06-25 15:37:22.039808
# Unit test for function load
def test_load():
    assert isinstance(load('', 'template_name'), dict)


# Generated at 2022-06-25 15:37:25.962287
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = 'template'
    # check that the function does not raise exceptions
    context = load(replay_dir, template_name)




# Generated at 2022-06-25 15:37:33.173437
# Unit test for function load
def test_load():
    template_name = 'asdf'
    dir_name = os.path.join(os.getcwd(),'test')
    context = load(dir_name, template_name)
    assert isinstance(context, dict) is True
    

# Generated at 2022-06-25 15:37:44.298800
# Unit test for function load
def test_load():
    asserts = [
        'assert',
        'be',
        'close',
        'False',
        'equal',
        'except',
        'finally',
        'not',
        'ok',
        'raises',
        'True'
    ]
    for assert_ in asserts:
        if assert_ in globals():
            del globals()[assert_]
    replay_dir = 'test_load'
    template_name = 'test_load'
    context = test_case_0()
    dump(replay_dir, template_name, context)
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter': {'replay_file': "{}/test_load.json".format(replay_dir)}}

# Generated at 2022-06-25 15:37:48.359584
# Unit test for function load
def test_load():
    print('Testing function load...')
    test_load_0()
    test_load_1()
    test_load_2()
    test_load_3()
    test_load_4()
    test_load_5()
    test_load_6()
    test_load_7()
    test_load_8()
    test_load_9()


# Generated at 2022-06-25 15:37:54.841864
# Unit test for function load
def test_load():
    replay_dir = 'tests/test-cases/test-case-0/fake-replay-dir/'
    template_name = 'fake-repo'

# Generated at 2022-06-25 15:37:57.672281
# Unit test for function load
def test_load():
    assert (load(None, None) == None)

# Generated at 2022-06-25 15:38:02.042205
# Unit test for function load
def test_load():
    replay_dir = 'C:\\Users\\jpsun\\PycharmProjects\\Cookiecutter\\cookiecutter\\replay\\tests\\test_files'
    template_name = 'dummy'
    context = load(replay_dir, template_name)
    
    return context


if __name__ == '__main__':
    context = test_load()

# Generated at 2022-06-25 15:38:04.264092
# Unit test for function load
def test_load():
    try:
        load('./', 'my_template')
        print("Unit test function load: Success")
    except:
        print("Unit test function load: Failed")


# Generated at 2022-06-25 15:38:08.073693
# Unit test for function dump
def test_dump():
    str_0 = 'asdf'
    #print(locals())
    context = locals()
    replay_dir = 'replay'
    template_name = 'test'
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:38:12.792023
# Unit test for function dump
def test_dump():
    replay_dir_0 = 'temp',
    template_name_0 = str_0
    context_0 = dict()
    test_case_0()


# Generated at 2022-06-25 15:38:14.663360
# Unit test for function load
def test_load():
    assert dump('./tests/test-replay', 'test', {'cookiecutter': {}}) == get_file_name('./tests/test-replay', 'test')


# Generated at 2022-06-25 15:38:21.880013
# Unit test for function load
def test_load():
    # Assert type
    assert(type(load(str_0,str_0)) == dict)



# Generated at 2022-06-25 15:38:24.553031
# Unit test for function load
def test_load():
    replay_dir = ''
    template_name = ''
    output = load(replay_dir, template_name)
    assert output == dict()


# Generated at 2022-06-25 15:38:29.417249
# Unit test for function load
def test_load():
    try:
        load('asdf/asf', 'asdf')
    except TypeError:
        pass

    try:
        load('asdf', 'asdf')
    except TypeError:
        pass

    try:
        load('asdf', 1)
    except TypeError:
        pass

    try:
        load('asdf', [])
    except TypeError:
        pass


# Generated at 2022-06-25 15:38:32.673228
# Unit test for function dump
def test_dump():
    replay_dir = 'D:\\source code\\Test\\lcmstaging'
    template_name = 'lcmstaging'
    context = {'cookiecutter':'lcmstaging'}
    dump(replay_dir, template_name, context)
    context_1 = load(replay_dir, template_name)
    assert context == context_1

# Generated at 2022-06-25 15:38:38.203443
# Unit test for function dump
def test_dump():
    str_1 = 'asdf'
    os.system("rm -rf /tmp/cookiecutter-test")
    return
    os.makedirs("/tmp/cookiecutter-test")
    dump("/tmp/cookiecutter-test", str_1, None)
    fp = open("/tmp/cookiecutter-test/asdf.json", 'r')
    read_str = fp.read()
    assert read_str == 'null'
    fp.close()
    os.system("rm -rf /tmp/cookiecutter-test")


# Generated at 2022-06-25 15:38:42.933743
# Unit test for function load
def test_load():
    context = get_file_name('/etc', 'template_name')
    if context is not None:
        print('test_load success')
    else:
        print('test_load failed')


# Generated at 2022-06-25 15:38:50.168550
# Unit test for function load
def test_load():
    print('in test_load')
    context = load('replay', 'google/py-gapic')
    print('context: ', context)
    print('context[cookiecutter]: ', context['cookiecutter'])

# Generated at 2022-06-25 15:38:53.823008
# Unit test for function load
def test_load():
    #Assert exceptions are raised
    try:
        context = load(str_0, str_0)
    except TypeError as e:
        assert(True)

    try:
        context = load(str_0, str_0)
    except ValueError as e:
        assert(True)


# Generated at 2022-06-25 15:39:04.715190
# Unit test for function load
def test_load():
    str_0 = 'asdf'
    str_1 = 'a'
    str_2 = 'a1'
    str_3 = 'a2'
    str_4 = 'a3'
    str_5 = 'a4'
    str_6 = 'a5'
    str_7 = 'a6'
    str_8 = 'a7'
    str_9 = 'a8'
    str_10 = 'a9'
    str_11 = 'a10'
    str_12 = 'a11'
    str_13 = 'a12'
    str_14 = 'a13'
    str_15 = 'a14'
    str_16 = 'a15'
    str_17 = 'a16'
    str_18 = 'a17'
    str_19 = 'a18'


# Generated at 2022-06-25 15:39:09.271078
# Unit test for function load
def test_load():
    replay_dir = 'C:\\Users\\kevin\\.cookiecutters_replay\\'
    out1 = load(replay_dir, 'jekyll-cookiecutter')
    assert(out1 == {u'cookiecutter': {u'_template': u'jekyll-cookiecutter'}})

test_load()

# Generated at 2022-06-25 15:39:23.126285
# Unit test for function load
def test_load():
    str_0 = load('replay', 'my-cookiecutter')
    print(str_0)



# Generated at 2022-06-25 15:39:23.704396
# Unit test for function load
def test_load():
    pass

# Generated at 2022-06-25 15:39:31.594746
# Unit test for function load
def test_load():
    # call the function
    # assert the expected result
    replay_dir = 'test_load_replay_dir'
    template_name = 'test_load_template_name'
    context = {"cookiecutter": {"full_name": "Firstname Lastname", "email": "test@test.com", "github_username": "test"}}
    dump(replay_dir, template_name, context)
    new_context = load(replay_dir, template_name)
    assert new_context == context



# Generated at 2022-06-25 15:39:40.729837
# Unit test for function load
def test_load():
    try:
        assert load.__annotations__ == {'replay_dir': str, 'template_name': str, 'return': object}
        assert type(load('asdf', 'asdf')) is object
    except AssertionError:
        print("Error in loading function.\nExpected type: str, str, object\nActual type: %s, %s, %s" % (type('asdf'), type('asdf'), type(load('asdf', 'asdf'))))

# Generated at 2022-06-25 15:39:42.986636
# Unit test for function load
def test_load():
    result = load('cookiecutter',
                           '{{ cookiecutter.project_name }}')
    assert result


# Generated at 2022-06-25 15:39:45.393116
# Unit test for function load
def test_load():
    replay_dir = 'C:\\user\\.cookiecutters'
    template_name = 'a\\b\\c'
    load(replay_dir, template_name)


# Generated at 2022-06-25 15:39:50.706120
# Unit test for function load
def test_load():
    replay_dir = 'testdir'
    template_name = 'testfile.json'
    dump(replay_dir, template_name, {'cookiecutter': {'key': 'value'}})
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert context['cookiecutter']['key'] == 'value'

# Generated at 2022-06-25 15:39:54.170598
# Unit test for function load
def test_load():

    return


# Generated at 2022-06-25 15:40:00.239310
# Unit test for function load
def test_load():
    replay_dir = 'sample_output'
    template_name = 'sample_1'
    context = load(replay_dir, template_name)
    assert(context['cookiecutter']['repo_name'] == template_name)
    assert(context['cookiecutter']['year'] == '2016')


# Generated at 2022-06-25 15:40:02.380951
# Unit test for function load
def test_load():
    print("\ntest_load")
    context = {}
    print(context)
    test_case_0()
    print(context)


# Generated at 2022-06-25 15:40:14.113322
# Unit test for function load
def test_load():
    test_case_0()

# Generated at 2022-06-25 15:40:15.384002
# Unit test for function dump
def test_dump():
    assert dump
    test_case_0()


# Generated at 2022-06-25 15:40:19.128270
# Unit test for function load
def test_load():
    a = 'abc'
    b = load(a, a)
    assert isinstance(b, dict)
    assert 'cookiecutter' in b


# Generated at 2022-06-25 15:40:25.071096
# Unit test for function load
def test_load():
    replay_dir = 'dir_0'
    template_name = 'test'
    try:
        dump(replay_dir, template_name, {'cookiecutter': {'s': 1}})
        dict_0 = {'cookiecutter': {'s': 1}}
        dict_1 = load(replay_dir, template_name)
        assert dict_0 == dict_1
    finally:
        os.remove('{}/{}'.format(replay_dir, template_name))


# Generated at 2022-06-25 15:40:32.800670
# Unit test for function dump
def test_dump():
    str_0 = 'C:\\Users\\Oscar\\Documents\\GitHub\\cookiecutter\\tests\\test-replay\\cc_test_user-replay'
    str_1 = 'cc_test_user'
    dict_0 = {'cookiecutter': {'full_name': 'Oscar Otero', 'email': 'om.otero.mallen@gmail.com', 'github_username': 'otero', 'project_short_description': 'Cookiecutter template for user', 'project_name': 'cookiecutter-user'}}
    dump(str_0, str_1, dict_0)

# Generated at 2022-06-25 15:40:34.053679
# Unit test for function dump
def test_dump():
    str_0 = 'asdf'
    var_0 = load(str_0, str_0)



# Generated at 2022-06-25 15:40:39.063603
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/test-replay/'
    template_name = 'test-replay'
    context = {'cookiecutter': {'project_slug': 'test-replay'}}
    dump(replay_dir, template_name, context)

    replay_file = get_file_name(replay_dir, template_name)
    with open(replay_file, 'r') as infile:
        context_from_file = json.load(infile)

    assert context_from_file == context


# Generated at 2022-06-25 15:40:47.576169
# Unit test for function dump
def test_dump():
    str_0 = 'tests/fixtures/replay/example.json'
    var_0 = {
        'cookiecutter': {
            'full_name': 'Your name',
            'email': 'Your email',
            'project_slug': 'project_name',
            'description': 'A short description of the project.',
            'project_name': "Example",
            'year': "{{ cookiecutter.year }}",
            'version': '0.1.0',
            'release': '0.1.0',
        }
    }
    dump(str_0, str_0, var_0)


# Generated at 2022-06-25 15:40:54.127846
# Unit test for function dump
def test_dump():
    print("Unit test for function dump")
    path_0 = os.path.abspath(os.path.join('.', 'replay', 'replay'))
    str_0 = 'replay'

    context = json.loads('{"cookiecutter": {}}')
    dump(path_0, str_0, context)
    var_0 = load(path_0, str_0)
    assert var_0 == {"cookiecutter": {}}


# Generated at 2022-06-25 15:40:56.431595
# Unit test for function load
def test_load():
    print("0: " + str(test_case_0()))
# End of test_load


# Generated at 2022-06-25 15:41:25.391444
# Unit test for function load
def test_load():
    # Load test cases with their known answers
    test_data = [['test_var_0', dict({})],
                 ['test_var_1', dict({'test_var_1': 'test_var_2'})]]

    # Test each test case
    for test_case in test_data:
        assert load(test_case[0], test_case[0]) == test_case[1]



# Generated at 2022-06-25 15:41:29.412327
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except TypeError as e:
        if str(e) == TYPE_ERROR_MESSAGE_0:
            print('[+] test_0 passed')
        else:
            print('[-] test_0 failed')
            print('\tExpected: {}'.format(TYPE_ERROR_MESSAGE_0))
            print('\tActual: {}'.format(str(e)))
    else:
        print('[-] test_0 failed')
        print('\tExpected: {}'.format(TYPE_ERROR_MESSAGE_0))
        print('\tActual: no exception')


# Generated at 2022-06-25 15:41:37.332600
# Unit test for function load
def test_load():
    import os
    import tempfile
    # delete test folder if exists
    try:
        os.rmdir('workspacetest/')
    except OSError:
        pass
    # new test folder generated
    with tempfile.TemporaryDirectory('workspacetest/') as dirpath:
        # get the path to temporary folder
        dirpath = os.getcwd()
        os.mkdir('workspacetest/')
    # create test file in test folder
    with open('workspacetest/testfile.txt', 'w+') as f:
        f.write('Hello world')
    # assert if file exists
    assert(os.path.isfile('/workspacetest/testfile.txt'))
    # delete temporary folder
    os.rmdir('workspacetest/')


# Unit

# Generated at 2022-06-25 15:41:39.643472
# Unit test for function load
def test_load():
    str_0 = '../tests/fixtures/fake-repo-tmpl'
    out_0 = load(str_0, str_0)
    assert isinstance(out_0, dict) is True


# Generated at 2022-06-25 15:41:49.428960
# Unit test for function load
def test_load():

    # Setup
    replay_dir = 'asdf'
    template_name = 'asdf'
    context = dict()

    context['cookiecutter'] = dict()
    context['cookiecutter']['full_name'] = 'asdf'
    context['cookiecutter']['email'] = 'asdf'
    context['cookiecutter']['project_name'] = 'asdf'
    context['cookiecutter']['project_slug'] = 'asdf'
    context['cookiecutter']['version'] = 'asdf'
    context['cookiecutter']['description'] = 'asdf'
    context['cookiecutter']['domain_name'] = 'asdf'
    context['cookiecutter']['repo_name'] = 'asdf'

# Generated at 2022-06-25 15:41:58.730590
# Unit test for function load
def test_load():
    # tests for:
    #   if not make_sure_path_exists(replay_dir):
    # test for when replay_dir does not exist
    replay_dir = 'tests/files/non_existent_dir'
    template_name = 'non_existent_dir'
    try:
        load(replay_dir, template_name)
    except IOError:
        pass
    else:
        assert False

    # test for when replay_dir does exist and dir permissions are fine
    replay_dir = 'tests/files/replay_dir_exists'
    template_name = 'replay_dir_exists'
    replay_file = get_file_name(replay_dir, template_name)
    try:
        load(replay_dir, template_name)
    except IOError:
        assert False

# Generated at 2022-06-25 15:42:06.335121
# Unit test for function load
def test_load():
    try:
        str_1 = 'asdf'
        assert load(str_1, str_1) is None
        str_1 = 'N'
        assert load('C:\\Users\\nguye\\AppData\\Local\\Temp\\tmp0qiz4_b\\cookiecutter', str_1) is None
        str_1 = 'test_0.json'
        str_1 = 'bad_replay'
        str_1 = 'cookiecutter.replay'
        str_1 = 'cookiecutter.json'
        str_1 = 'cookiecutter.replay'
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-25 15:42:07.784680
# Unit test for function load
def test_load():
    assert test_case_0() == N

# Generated at 2022-06-25 15:42:14.937944
# Unit test for function load
def test_load():
    # Test case 0
    str_0 = 'asdf'
    var_0 = load(str_0, str_0)
    
    # Test case 1
    str_0 = 'lol'
    var_0 = load(str_0, str_0)
    
    # Test case 2
    str_0 = 'lmao'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:42:17.458986
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except Exception as err:
        print('Test case 0 failed: ' + str(err))
        raise
