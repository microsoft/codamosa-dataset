

# Generated at 2022-06-25 15:32:55.507815
# Unit test for function dump
def test_dump():
    float_1 = -92.02253
    str_1 = 'test_file'
    str_2 = 'cookiecutter'
    var_1 = {str_2: str_1}
    dump(float_1, float_1, var_1)


# Generated at 2022-06-25 15:32:58.787629
# Unit test for function dump
def test_dump():
    float_0 = -1759.342405
    str_0 = 'cookiecutter'
    var_0 = dump(float_0, str_0, float_0)


# Generated at 2022-06-25 15:33:01.539079
# Unit test for function load
def test_load():
    float_0 = -1400.82905
    var_0 = load(float_0, float_0)
    var_1 = load(float_0, float_0)
    var_2 = load(float_0, float_0)


# Generated at 2022-06-25 15:33:08.262794
# Unit test for function dump
def test_dump():
    float_0 = -1400.82905

    # write json data to file
    dump(est_dir, float_0, float_0)

    # load the data from file
    data = load(est_dir, "est.json")

    # check the loaded data
    for i in range(5):
        assert(float_0[i] == data[i])



# Generated at 2022-06-25 15:33:10.649701
# Unit test for function dump
def test_dump():
    # Test if accurate
    assert True, 'Test is accurate'


# Generated at 2022-06-25 15:33:15.742795
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'tests_output/testing_replay_files'
    template_name = "test_template"

    expected_filename = os.path.join(replay_dir, 'test_template.json')
    filename = get_file_name(replay_dir, template_name)
    assert filename == expected_filename

# Generated at 2022-06-25 15:33:27.258320
# Unit test for function load
def test_load():
    float_0 = -1400.82905
    var_0 = load(float_0, float_0)
    assert var_0 is None

    float_0 = -1400.82905
    var_0 = load(float_0, float_0)
    assert var_0 is None

    float_0 = -1400.82905
    list_0 = []
    var_0 = load(float_0, list_0)
    assert var_0 is None

    float_0 = -1400.82905
    list_0 = []
    var_0 = load(float_0, list_0)
    assert var_0 is None

    float_0 = -1400.82905
    str_0 = 'Boolean'

# Generated at 2022-06-25 15:33:29.674941
# Unit test for function get_file_name
def test_get_file_name():
    var_0 = 'QIZhqcjsIY'
    assert get_file_name(var_0, var_0) == './QIZhqcjsIY/QIZhqcjsIY'


# Generated at 2022-06-25 15:33:32.958211
# Unit test for function load
def test_load():
    assert True


if __name__ == "__main__":
    test_case_0()
    test_load()

# Generated at 2022-06-25 15:33:34.438106
# Unit test for function load
def test_load():
    assert callable(load)
    # AssertionError: expected callable, got <class 'float'>


# Generated at 2022-06-25 15:33:39.178191
# Unit test for function load
def test_load():
    file_0 = 'tests/files/replay/QIZhqcjsIY.json'
    dict_0 = load('tests/files/replay/', 'QIZhqcjsIY')


# Generated at 2022-06-25 15:33:47.487040
# Unit test for function load
def test_load():
    # Test function where template name is set to None
    try:
        str_0 = 'jqATDqIOfF'
        str_1 = 'UBuYiYUvzI'
        load(str_0, str_1)
    except ValueError:
        pass


# Generated at 2022-06-25 15:33:48.818495
# Unit test for function load
def test_load():
    pass


# Generated at 2022-06-25 15:33:51.226609
# Unit test for function load
def test_load():
    replay_dir = 'replay'
    template_name = 'cookiecutter'
    context = load(replay_dir, template_name)
    print(context)

# Generated at 2022-06-25 15:33:53.805686
# Unit test for function load
def test_load():
    assert str(load('./cookiecutter.json', 'foo')).find('asd6') != -1



# Generated at 2022-06-25 15:33:58.306986
# Unit test for function load
def test_load():
    str_0 = 'Y5E5'
    str_1 = 'jhPx'
    str_0 = 'QIZhqcjsIY'

    var_0 = load(str_1, str_0)


# Generated at 2022-06-25 15:34:04.411997
# Unit test for function dump
def test_dump():
    replay_dir = 'replay'
    template_name = 'QIZhqcjsIY'
    context = {'cookiecutter': {'full_name': 'QIZhqcjsIY',
                                'email': 'QIZhqcjsIY',
                                'github_username': 'QIZhqcjsIY',
                                'project_name': 'QIZhqcjsIY'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:34:08.083278
# Unit test for function load
def test_load():
    # load
    replay_dir = 'C:'
    template_name = 'OvLSocckrO'
    context = load(replay_dir, template_name)
    assert context == {'foo': 'bar'} or context == {'{{cookiecutter.foo}}': 'bar'}

    # load
    replay_dir = '/tmp'
    template_name = 'YaYIkXBFJV'
    context = load(replay_dir, template_name)
    assert context == {'foo': 'bar'} or context == {'{{cookiecutter.foo}}': 'bar'}

    # load
    replay_dir = 'gScgrhrXGB'
    template_name = 'gScgrhrXGB'
    context = load(replay_dir, template_name)

# Generated at 2022-06-25 15:34:13.935813
# Unit test for function dump
def test_dump():
    with open('tests/files/cookiecutter.json', 'r') as infile:
        context = json.load(infile)

    dump('tests/replay', 'tests/files/cookiecutter.json', context)
    assert load('tests/replay', 'tests/files/cookiecutter.json') == context

# Generated at 2022-06-25 15:34:22.355750
# Unit test for function dump
def test_dump():
    test_data_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    replay_dir = os.path.join(test_data_dir, 'replay')
    template_name = 'audreyr/cookiecutter-pypackage'
    context = {'cookiecutter': {
        'full_name': 'Jeff Triplett',
        'github_username': 'webology',
        'project_name': 'cantusdata/cookiecutter-test',
        'repo_name': 'cookiecutter-test',
        'year': '2014'
    }}

    dump(replay_dir, template_name, context)
    assert 'cookiecutter' in load(replay_dir, template_name)



# Generated at 2022-06-25 15:34:26.074918
# Unit test for function load
def test_load():
    template_name = 'template_name'
    replay_dir = 'replay_dir'

# Generated at 2022-06-25 15:34:26.920758
# Unit test for function load
def test_load():
    assert True


# Generated at 2022-06-25 15:34:37.054325
# Unit test for function load
def test_load():
    f = get_file_name('QIZhqcjsIY','QIZhqcjsIY')
    try:
        os.remove(f)
    except:
        pass
    replay_dict = {'cookiecutter': {'project_license': 'EPL-1.0', 'full_name': 'Monty Python', 'project_name': 'LifeOfBrian', 'email': 'monty@python.com', 'replay_file': 'QIZhqcjsIY', 'date': '2013-12-15T21:13:44', 'replay_dir': 'QIZhqcjsIY', 'github_username': 'life-of-brian', 'timezone': 'US/Pacific'}}

# Generated at 2022-06-25 15:34:41.218672
# Unit test for function load
def test_load():
    replay_dir = './tests/test-replay/'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context
    assert isinstance(context['cookiecutter'], dict)


# Generated at 2022-06-25 15:34:46.913411
# Unit test for function dump
def test_dump():
    try:
        import os

        import json
    except ImportError:
        pass

    replay_dir = os.path.dirname(__file__)
    template_name = os.path.basename(__file__)
    context = {'cookiecutter': {'name': 'Joe'}}

    # Write json data to file.
    dump(replay_dir, template_name, context)

    # Read json data from file.
    result_context = load(replay_dir, template_name)
    assert result_context == context

    # Remove file
    os.remove(os.path.join(replay_dir, template_name))



# Generated at 2022-06-25 15:34:50.327003
# Unit test for function load
def test_load():
    str_0 = 'qIJFbDtvtf'
    str_1 = 'MnhJwKjOiW'
    str_2 = 'XeKAcSZQOc'
    dict_0 = load(str_0, str_1)
    dict_1 = load(str_2, str_0)


# Generated at 2022-06-25 15:34:56.738053
# Unit test for function load
def test_load():
    tmpl0 = 'dinsdale'
    replay_dir = 'tests/test-replay'
    if not os.path.exists(replay_dir):
        os.makedirs(replay_dir)
    context = load(replay_dir, tmpl0)
    assert context['_template'] == tmpl0


# Generated at 2022-06-25 15:35:04.094378
# Unit test for function load
def test_load():
    # TODO: more test cases
    str_0 = 'QIZhqcjsIY'
    dict_0 = {
        # TODO: more keys
        'cookiecutter': str_0
    }
    # TODO: more test cases
    str_0 = 'QIZhqcjsIY'
    dict_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:35:05.367703
# Unit test for function load
def test_load():
    assert callable(load)

# Generated at 2022-06-25 15:35:14.402544
# Unit test for function load
def test_load():
    assert context == {
        'cookiecutter': {
            u'full_name': u'A B',
            u'email': u'a@b.c',
            u'github_username': u'a',
            u'project_name': u'foo',
            u'project_slug': u'foo',
            u'pypi_username': u'a',
            u'year': u'2013',
            u'repo_name': u'cookiecutter-pypackage',
            u'use_pytest': u'y',
            u'command_line_interface': u'click',
            u'select_license': u'MIT license',
            u'open_source_license': u'MIT license'
        }
    }


# Generated at 2022-06-25 15:35:27.958501
# Unit test for function dump
def test_dump():
    template_name = 'cookiecutter-pypackage'
    replay_dir = 'tests/files/replay'
    context = {
        'cookiecutter': {
            'project_name': 'cookiecutter-pypackage',
            'pkg_name': 'cookiecutterpypackage',
            'repo_name': 'cookiecutter-pypackage',
            'project_short_description': 'A Python package project template',
            'release_date': '',
            'version': '0.1.0',
            'year': '2017',
            'full_name': 'Your Name',
            'email': 'you@example.com',
            'open_source_license': 'BSD license',
        },
    }
    dump(replay_dir, template_name, context)


# Unit

# Generated at 2022-06-25 15:35:30.539346
# Unit test for function load
def test_load():
    replay_dir = 'xnx4E4OYQX'
    template_name = 'hLkfS1UTzT'

    load(replay_dir, template_name)


# Generated at 2022-06-25 15:35:38.864596
# Unit test for function dump
def test_dump():
    # Template name is required to be of type str
    try:
        dump(False)
        assert False
    except TypeError as e:
        assert e

    # Context is required to be of type dict
    try:
        dump('foo', 'bar', [1, 2, 3])
        assert False
    except TypeError as e:
        assert e

    # Context is required to contain a cookiecutter key
    try:
        dump('foo', 'bar', {})
        assert False
    except ValueError as e:
        assert e

    # Returns None if successful
    assert dump('/tmp', 'test.json', {'cookiecutter': 'bar'})

# Generated at 2022-06-25 15:35:41.723234
# Unit test for function load
def test_load():
    assert load('QIZhqcjsIY', 'QIZhqcjsIY') == {'cookiecutter': {'full_name': 'n/a',
                                                                'email': 'n/a'}}


# Generated at 2022-06-25 15:35:46.249963
# Unit test for function load
def test_load():
    str_0 = 'QIZhqcjsIY'
    str_1 = 'QIZhqcjsIY'
    var_0 = load(str_0, str_1)


# Generated at 2022-06-25 15:35:53.139346
# Unit test for function load
def test_load():
    str_0 = 'nctZhBJUYi'
    str_1 = 'rzJgqAqPqo'
    str_2 = 'rzJgqAqPqo'
    var_0 = load(str_0, str_1)
    test_load_0(str_0, var_0)
    test_load_1(str_1, var_0)
    test_load_2(str_2, var_0)


# Generated at 2022-06-25 15:35:58.722099
# Unit test for function load
def test_load():
    str_0 = 'yvYpzWpSii'
    str_1 = 'FcqsLWJXlX'
    var_0 = os.path.join(str_0, str_1)
    var_1 = load(var_0, str_0)    
    

# Generated at 2022-06-25 15:36:09.470185
# Unit test for function load
def test_load():
    assert load('EqrUOkaLQG', 'YZFqJZqdCZ') == {
        "cookiecutter": {
            "project_name": "YZFqJZqdCZ",
            "project_slug": "YZFqJZqdCZ",
            "author_name": "YZFqJZqdCZ",
            "author_email": "YZFqJZqdCZ",
            "version": "0.1.0",
            "release": "0.1.0",
            "project_short_description": "YZFqJZqdCZ",
            "use_pycharm": "y",
            "open_source_license": "BSD license"
        }
    }


# Generated at 2022-06-25 15:36:17.013247
# Unit test for function load
def test_load():
    str_0 = '_xhmfP_oHm'
    str_1 = 'U6lHU0n0Ub'
    str_2 = '//|>BX9'
    var_0 = load(str_0, str_0)
    try:
        load(str_2, str_1)
    except TypeError:
        print('Except TypeError raised')
    try:
        load(str_0, str_1)
    except ValueError:
        print('Except ValueError raised')


# Generated at 2022-06-25 15:36:18.697871
# Unit test for function load
def test_load():
    assert not load("l3OqN1cZ1b", 'sL8a2WX9vR')


# Generated at 2022-06-25 15:36:31.182200
# Unit test for function load
def test_load():
    print(load('replay/test_replay'))
    assert load('replay/test_replay') == {
        'cookiecutter':
        {
            'author_email': 'biz@techarena51.com',
            'author_name': 'Biz',
            'company': 'TechArena51',
            'project_name': 'test_replay',
            'repo_name': 'test_replay',
            'year': '2016',
            'description': 'An awesome package',
            'version': '0.1.0'
        }
    }


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:36:32.749568
# Unit test for function load
def test_load():
    assert load('','cookiecutter.json') == 'cookiecutter.json'


# Generated at 2022-06-25 15:36:39.068667
# Unit test for function load
def test_load():
    replay_dir = 'UYMNhugYjg'
    template_name = 'JpNbOALCMi'
    var_0 = load(replay_dir, template_name)
    # Ensure var_0 is a dict
    assert isinstance(var_0, dict)
    # Ensure 'cookiecutter' in var_0
    assert 'cookiecutter' in var_0


# Generated at 2022-06-25 15:36:43.956364
# Unit test for function load
def test_load():
    print("\n\n\n\n\n")
    print("##################################################################################")
    print("Testing function load...")
    print("##################################################################################")
    test_case_1()
    test_case_2()
    test_case_3()
    print("\n")
    print("Finished testing function load!!!")


# Generated at 2022-06-25 15:36:51.431710
# Unit test for function load
def test_load():
    # simple case
    str_0 = './tests/files/replay'
    str_1 = 'fake'
    var_0 = load(str_0, str_1)
    assert isinstance(var_0, dict)
    # complex case
    # simple case
    str_0 = './tests/files/replay'
    str_1 = 'fake'
    try:
        load(str_0, str_1)
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:36:54.515811
# Unit test for function load
def test_load():
    with pytest.raises(TypeError):
        load('QIZhqcjsIY', 'QIZhqcjsIY', )


# Generated at 2022-06-25 15:36:58.522270
# Unit test for function load
def test_load():
    str_0 = 'C:\\Users\\Brennon\\Documents\\GitHub\\cookiecutter-tffpy'
    str_1 = 'D:\\Documents\\GitHub\\cookiecutter-tffpy'
    dic_0 = load(str_0, str_1)


test_load()

# Generated at 2022-06-25 15:37:04.756808
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    replay_dir = 'ovYIYgflpN'
    template_name = 'LWdJypvGFl'
    context = 'OaCCftWgQv'
    dump(replay_dir, template_name, context)
# Function load

# Generated at 2022-06-25 15:37:11.666264
# Unit test for function load
def test_load():
    assert load('', '', ) == ''
    assert load('', '', ) == ''
    assert load('', '', ) == ''
    assert load('', '', ) == ''
    assert load('', '', ) == ''


# Generated at 2022-06-25 15:37:16.204223
# Unit test for function load
def test_load():
    """Unit test for function load"""

    # test case 0
    print("test case 0")
    str_0 = 'TmDelnntbR'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:37:30.948638
# Unit test for function dump
def test_dump():
    str_0 = 'vnMqZqwEDf'
    str_1 = 'lGpRYrJSbC'
    dict_0 = dict()
    dict_0[str_0] = str_1
    dump(str_0, str_1, dict_0)
    bool_0 = os.path.exists(dict_0)
    dict_0 = dict()
    dict_0[str_0] = str_1
    dump(str_0, str_0, dict_0)
    bool_1 = os.path.exists(dict_0)
    dict_0 = dict()
    dict_0[str_0] = str_1
    dump(str_1, str_0, dict_0)
    bool_2 = os.path.exists(dict_0)
   

# Generated at 2022-06-25 15:37:32.203734
# Unit test for function load
def test_load():
    pass


# Generated at 2022-06-25 15:37:37.314240
# Unit test for function dump
def test_dump():
    json_1 = {"cookiecutter": {"project_name": "Test", "project_slug": "test", "author_name": "Test"}, "key": "value"}
    assert dump('D:\\dev\\myrepos\\cookie\\replay', 'test', json_1) == None


# Generated at 2022-06-25 15:37:39.546259
# Unit test for function load
def test_load():
    replay_dir = 'cookiecutter.replay'
    template_name = 'cookiecutter.replay'
    load(replay_dir, template_name)



# Generated at 2022-06-25 15:37:43.733586
# Unit test for function load
def test_load():
    # ...
    pass

if __name__ == '__main__':
    test_case_0()
    print('Unit test completed')

# Generated at 2022-06-25 15:37:46.572855
# Unit test for function load
def test_load():
    str_0 = 'QIZhqcjsIY'
    dict_0 = dict({'cookiecutter': dict({})})
    load(str_0, str_0)


# Generated at 2022-06-25 15:37:48.443274
# Unit test for function load
def test_load():
    assert load('jA93EoYr', 'JhfZm1Gafd') == {'cookiecutter': {'cookiecutter': 'c5S5S5NS'}}


# Generated at 2022-06-25 15:37:53.324561
# Unit test for function load
def test_load():
    assert load('YaYwFAYzIG', 'hxZszsZoGQ') != {'cookiecutter': {'full_name': 'John Doe', 'email': 'john@doe.com', 'project_name': 'example', 'replay_dir': None, 'no_input': False, 'extra_context': None, '_template': 'hxZszsZoGQ', 'output_dir': None}}


# Generated at 2022-06-25 15:37:54.950064
# Unit test for function load
def test_load():
    # Runs code and check for exception
    try:
        assert True == True
    except:
        print("test_load failed")

# Generated at 2022-06-25 15:38:00.456621
# Unit test for function load
def test_load():
    str_0 = dump(str_0, str_0, var_0)
    
    '''
    replay_dir = 'string'
    template_name = 'string'
    ret_0 = load(replay_dir, template_name)

    assert ret_0 == "QIZhqcjsIY"
    '''

# Generated at 2022-06-25 15:38:07.484771
# Unit test for function load
def test_load():
    replay_dir = 'qybJ'
    template_name = 'fRXTxRx'
    context = load(replay_dir, template_name)


# Generated at 2022-06-25 15:38:16.913813
# Unit test for function load
def test_load():
    # Test 1
    load('oexYqDFCIa', 'EwOslZKUjZ')
    # Test 2
    load('RJbwpYMufe','FOzKDdwWip')
    # Test 3
    load('dVxmhGoOSA','gYmBRPFWcj')
    # Test 4
    load('soZNhkvxHJ','gYmBRPFWcj')
    # Test 5
    load('soZNhkvxHJ','FOzKDdwWip')
    # Test 6
    load('oexYqDFCIa','EwOslZKUjZ')
    # Test 7
    load('dVxmhGoOSA','EwOslZKUjZ')
    # Test 8

# Generated at 2022-06-25 15:38:22.754443
# Unit test for function load
def test_load():
    # Hack for passing the coverage test
    d = {'cookiecutter': {'name': 'hello'}}
    file_name = 'testfilename.json'
    with open(file_name, 'w+') as outfile:
        json.dump(d, outfile, indent=2)
    assert load('.', file_name) == d
    os.remove(file_name)


# Generated at 2022-06-25 15:38:23.733061
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:38:32.303097
# Unit test for function dump
def test_dump():
    # Test if function raises exception
    with pytest.raises(IOError):
        dump('ZDUfytGjNO', 'AQBdKbztnP', 'RnyLzHkVpw')

    # Test if function raises exception
    with pytest.raises(TypeError):
        dump('tLnYWoznrt', 'KwxGcMsSls', 'eWbAJNXGAt')

    # Test if function raises exception
    with pytest.raises(TypeError):
        dump('hLIGbohyPF', 'QIZhqcjsIY', 'DMfPkbxFuR')

    # Test if function raises exception

# Generated at 2022-06-25 15:38:34.667201
# Unit test for function load
def test_load():
    str_1 = 'rXRBEHvRPp'
    str_2 = str_1
    load(str_1, str_1)


# Generated at 2022-06-25 15:38:40.382932
# Unit test for function dump
def test_dump():
    str_0 = 'gNcZRbPXzB'
    dict_0 = dict()
    dict_0['cookiecutter'] = dict()
    dict_0['cookiecutter']['full_name'] = 'John Smith'
    dict_0['cookiecutter']['email'] = 'john.smith@example.com'
    dict_0['cookiecutter']['github_username'] = 'johnsmith'
    dict_0['cookiecutter']['project_name'] = 'My Project'
    dict_0['cookiecutter']['repo_name'] = 'my_project'
    dict_0['cookiecutter']['project_slug'] = 'my_project'
    dict_0['cookiecutter']['release_date'] = '2017.04.06'
    dict_

# Generated at 2022-06-25 15:38:43.137096
# Unit test for function load
def test_load():
    str_1 = 'SmfIoRkCgf'
    dict_1 = load(str_1, str_1)


# Generated at 2022-06-25 15:38:52.272803
# Unit test for function dump
def test_dump():
    import os
    import os.path
    from cookiecutter.main import cookiecutter

    from cookiecutter.generate import generate_context

    from cookiecutter.utils import rmtree

    template = 'https://github.com/audreyr/cookiecutter-pypackage.git'

    replay_dir = '~/.cookiecutter_replay'

    context = generate_context(
        template,
        default_config={'cookiecutter': {'replay_dir': replay_dir}}
    )

    cookiecutter(template, replay_dir=replay_dir, no_input=True)

    os.mkdir('/test_replay_dir')

    replay_file = get_file_name(replay_dir, template)


# Generated at 2022-06-25 15:38:54.876463
# Unit test for function load
def test_load():
    str_0 = 'lJvEZwBzJF'
    var_0 = get_file_name(str_0, str_0)
    var_1 = load(var_0, str_0)


# Generated at 2022-06-25 15:39:05.820704
# Unit test for function load
def test_load():
    assert load('./replay', 'cookiecutter-pypackage')

# Generated at 2022-06-25 15:39:09.449043
# Unit test for function load
def test_load():
    assert callable(load)
    try:
        assert load('QIZhqcjsIY', 'QIZhqcjsIY')
    except ValueError:
        pass
    except Exception as e:
        print('Unexpected exception: {}'.format(e))
    try:
        assert load(10, 'QIZhqcjsIY')
    except TypeError:
        pass
    except Exception as e:
        print('Unexpected exception: {}'.format(e))


# Generated at 2022-06-25 15:39:14.053957
# Unit test for function load
def test_load():
    dict_0 = {'IWtdTKzOTJ': 'NEgVPgpCKF', 'XmvdYhBmYi': 'vMMOAByKbK'}
    str_0 = 'rboWpXzYgh'
    dict_1 = load(str_0, dict_0)


# Generated at 2022-06-25 15:39:21.478993
# Unit test for function dump
def test_dump():
    # Create context (dict)
    d = {
        'cookiecutter': {'slug': 'cookiecutter-dummy-project'}
    }

    # Create replay path
    replay_dir = os.path.join(os.getcwd(), 'replay')
    template_name = 'cookiecutter-dummy-project'

    # Test if exception is thrown
    try:
        dump('invalid_dir', 'template_name', d)
    except IOError:
        pass

    # Test if exception is thrown
    try:
        dump(replay_dir, 123, d)
    except TypeError:
        pass

    # Test if exception is thrown
    try:
        dump(replay_dir, template_name, ['a', 'b', 'c'])
    except TypeError:
        pass

   

# Generated at 2022-06-25 15:39:22.316150
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:39:28.414513
# Unit test for function load
def test_load():

    # Generate data for test (102, 103)
    str_0 = 'QIZhqcjsIY'

    # Generate expected results (104)
    expected_1 = {}

    # Set independent variables and run function (105)
    actual_1 = load(str_0, str_0)

    # Compare actual results against expected results (106)
    assert actual_1 == expected_1



# Generated at 2022-06-25 15:39:38.155856
# Unit test for function dump
def test_dump():
    replay_dir = './cookiecutter-pypackage'
    template_name = 'cookiecutter-pypackage'

# Generated at 2022-06-25 15:39:44.594174
# Unit test for function dump
def test_dump():
    # arrange
    replay_dir = 'C:/Users/Sajjad/Desktop/upwork/exercises/cookiecutter-exercise/cookiecutter-exercise/replay'
    template_name = 'gh-replay'
    context = {
        'cookiecutter': {
            'full_name': 'Sajjad',
            'email': 'sajjad@example.com',
            'github_username': 'Sajjad-Hussain',
            'github_repo_name': 'cookiecutter-exercise',
            'project_name': 'cookiecutter-exercise',
            'project_short_description': 'This is a test',
            'pypi_username': 'sajjad-hussain'
        }
    }

    # act

# Generated at 2022-06-25 15:39:53.077898
# Unit test for function dump
def test_dump(): 
    str_0 = 'oIxBquyWcS'
    test_0 = 'QIZhqcjsIY'
    test_1 = 'QcldtBDWVr'
    test_2 = 'XC8bDkV7vY'
    test_3 = 'NpNiWz7Bkk'
    test_4 = 'q3GgeYkvQD'

    # Call function
    #dump(test_0, test_1, test_2)

    # Call function
    #dump(test_3, test_4, test_0)


# Generated at 2022-06-25 15:39:59.144005
# Unit test for function load
def test_load():
    """Test for load"""
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()



# Generated at 2022-06-25 15:40:22.488415
# Unit test for function load
def test_load():
    replay_dir = 'Bwya6UxjKU'
    template_name = 'QIZhqcjsIY'
    share_context = load(replay_dir, template_name)


# Generated at 2022-06-25 15:40:26.080452
# Unit test for function dump
def test_dump():
    str_0 = 'QIZhqcjsIY'
    dict_0 = {'counter': 0, 'cookiecutter': {'project_slug': 'QIZhqcjsIY'}}
    dump(str_0, str_0, dict_0)


# Generated at 2022-06-25 15:40:28.271605
# Unit test for function load
def test_load():
    context = load('d:/github/django-js-reverse', 'django-js-reverse')
    assert 'cookiecutter' in context


# Generated at 2022-06-25 15:40:37.180583
# Unit test for function load
def test_load():
    var_0 = 'sRQQZuVJvw'
    var_1 = 'foQHgxUdMg'
    var_2 = load(var_0, var_1)
    assert var_2 == {}
    var_3 = 'XEmAjKiCZS'
    var_4 = load(var_0, var_3)
    assert var_4 == {}
    var_5 = 'mZswAZvpAv'
    var_6 = load(var_0, var_5)
    assert var_6 == {}
    var_7 = 'VhvCQzDQiR'
    var_8 = load(var_0, var_7)
    assert var_8 == {}
    var_9 = 'nFnXWXbjuL'
    var

# Generated at 2022-06-25 15:40:40.223758
# Unit test for function load
def test_load():
    replay_dir = '/etc/wqaaglfd/'
    template_name = 'QIZhqcjsIY/'
    load(replay_dir, template_name)


# Generated at 2022-06-25 15:40:42.662287
# Unit test for function load
def test_load():
    assert load('cookiecutter', 'cookiecutter') == dict(cookiecutter='cookiecutter')



# Generated at 2022-06-25 15:40:44.911707
# Unit test for function load
def test_load():
    str_0 = 'vsatYMVQGw'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:40:53.149693
# Unit test for function dump
def test_dump():
    # Test 1
    replay_dir = ''
    template_name = 'test_dump'
    context = {
        'test_dump': 'test_dump'
    }
    try:
        dump(replay_dir, template_name, context)
    except Exception as error:
        if str(error) == 'Unable to create replay dir at ' + replay_dir:
            print('Test 1: ' + str(error) + ' -> No such file or directory')
        else:
            print('Test 1: Error-> ', error)
    else:
        print('Test 1: No errors')
    # Test 2
    replay_dir = 'test_dir'
    template_name = ''
    context = {
        'test_dump': 'test_dump'
    }

# Generated at 2022-06-25 15:40:57.217211
# Unit test for function dump
def test_dump():
    arg_0 = str
    arg_1 = str
    arg_2 = dict
    try:
        dump(arg_0, arg_1, arg_2)
    except Exception as e:
        print(e)
        return False
    return True


# Generated at 2022-06-25 15:41:03.118615
# Unit test for function load
def test_load():
    assert callable(load)
    vars_0 = load('C:\\program files\\dummy', '3qO6QvE1O5')
    vars_1 = load('C:\\program files\\dummy\\dummy', 'F9Pbv4d4j4')
    vars_2 = load('C:\\program files\\dummy\\dummy\\dummy', 'ldd4dp4u4a')
    vars_3 = load('C:\\program files\\dummy\\dummy', 'ldd4dp4u4a')
    vars_4 = load('C:\\program files\\dummy', 'ldd4dp4u4a')
    vars_5 = load('C:\\program files\\dummy\\dummy', 'F9Pbv4d4j4')
    v

# Generated at 2022-06-25 15:42:05.371967
# Unit test for function load
def test_load():
    import cookiecutter.main
    cookiecutter.main.cookiecutter(
        'https://github.com/audreyr/cookiecutter-pypackage',
        replay_dir='./test_replay_dir',
        no_input=True
    )
    context = load('./test_replay_dir', 'cookiecutter-pypackage')
    assert context['cookiecutter']['author_email'] == 'audreyr@example.com'
    assert context['cookiecutter']['open_source_license'] == 'MIT license'



# Generated at 2022-06-25 15:42:12.164391
# Unit test for function load
def test_load():
    if not os.path.isfile(os.path.join('tests', 'files', 'dict_file.json')):
        raise Exception('file not found')
    var_0 = load('tests/files/dict_file.json', 'tests/files/dict_file.json')


# Generated at 2022-06-25 15:42:20.965308
# Unit test for function dump
def test_dump():
    str_0 = 'tokens/tokens.json'
    dict_0 = dict()

    dict_0['cookiecutter'] = dict()
    dict_0['cookiecutter']['repo_dir'] = 'QIZhqcjsIY'
    dict_0['cookiecutter']['repo_url'] = 'QIZhqcjsIY'
    dict_0['cookiecutter']['context_file'] = 'QIZhqcjsIY'
    dict_0['cookiecutter']['output_dir'] = 'QIZhqcjsIY'
    dict_0['cookiecutter']['abbreviations'] = dict()
    dict_0['cookiecutter']['abbreviations']['gh'] = 'https://github.com/'
   

# Generated at 2022-06-25 15:42:22.216041
# Unit test for function load
def test_load():
    assert load(get_file_name, 'decompile')


# Generated at 2022-06-25 15:42:28.652620
# Unit test for function load
def test_load():
    dict_1 = dict()
    dict_1['cookiecutter'] = dict()
    dict_1['cookiecutter']['full_name'] = 'Dennis'
    dict_1['cookiecutter']['email'] = 'dennismahler@gmail.com'
    dict_1['cookiecutter']['github_username'] = 'dennismahler'
    dict_1['cookiecutter']['date'] = '2018-07-05'
    dict_1['cookiecutter']['project_name'] = 'test'
    dict_1['cookiecutter']['project_slug'] = 'test'
    dict_1['cookiecutter']['release'] = '0.1.0'
    dict_1['cookiecutter']['repo_name'] = 'test'
   

# Generated at 2022-06-25 15:42:30.943293
# Unit test for function load
def test_load():
    str_0 = 'HqhFq4o4t'
    str_1 = 'ebXhTVDCLY'
    dict_0 = load(str_0, str_1)


# Generated at 2022-06-25 15:42:35.904854
# Unit test for function dump
def test_dump():

    str_0 = 'YLTlFvMboe'
    var_0 = dump(str_0, str_0, str_0)
    var_1 = dump(str_0, str_0, str_0)
    if var_0 or var_1:
        str_1 = 'aQyalGXyXt'
        var_2 = var_0
        var_3 = var_1
        int_0 = var_3 + var_1
        var_4 = var_2 + int_0



# Generated at 2022-06-25 15:42:37.533784
# Unit test for function load
def test_load():
    var_1 = load('replay_dir', 'template_name')
    return {'replay_dir': 'replay_dir', 'template_name': 'template_name'}

# Generated at 2022-06-25 15:42:40.613562
# Unit test for function load
def test_load():
    assert_test()


# Generated at 2022-06-25 15:42:48.424772
# Unit test for function dump
def test_dump():
    """unit test for dump"""
    str_0 = 'XbEZKx'
    str_1 = 'zbCJ'