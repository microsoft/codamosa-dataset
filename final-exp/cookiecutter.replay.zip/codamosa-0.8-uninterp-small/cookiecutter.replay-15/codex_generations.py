

# Generated at 2022-06-25 15:33:09.439639
# Unit test for function load
def test_load():
    replay_dir = 'wxV$Z>'
    context = "{'cookiecutter': {'full_name': 'David Fischer', 'email': 'dfischer@unit9.com', 'github_username': 'davidfischer-ch', 'project_name': '{{ cookiecutter.repo_name }}', 'project_short_description': 'A Python package template', 'pypi_username': 'davidfischer-ch', 'version': '0.1.0', 'release': '0.1.0', 'python_version': '2.7', 'use_pytest': 'n', 'command_line_interface': 'click', 'create_author_file': 'y', 'use_pypi_deployment_with_travis': 'y'}}"
    assert load(replay_dir, context)

# Unit test

# Generated at 2022-06-25 15:33:12.278394
# Unit test for function dump
def test_dump():
    assert(dump(replay_dir, template_name, context))


# Generated at 2022-06-25 15:33:16.998092
# Unit test for function dump
def test_dump():
    int_0 = -27
    str_0 = 'q'
    dict_0 = {'cookiecutter': {'cookiecutter': 'cookiecutter'}}

    try:
        dump(int_0, str_0, dict_0)
    except IOError:
        pass
    except TypeError:
        pass
    except ValueError:
        pass


# Generated at 2022-06-25 15:33:23.288735
# Unit test for function dump
def test_dump():
    var_0 = "Project name: "
    var_1 = json.load(var_0)
    var_2 = get_file_name(var_0, var_1)
    var_3 = os.path.exists(var_2)
    var_4 = "Unable to create replay dir at {}".format(var_2)
    if var_3:
        pass
    else:
        var_5 = IOError(var_4)
        var_5.__context__ = None
        var_5.__cause__ = None
        raise var_5
    var_6 = isinstance(var_0, str)
    if var_6:
        pass
    else:
        var_7 = TypeError("Template name is required to be of type str")
        var_7.__context__ = None
       

# Generated at 2022-06-25 15:33:28.363313
# Unit test for function dump
def test_dump():
    # Setup
    int_0 = -183
    int_1 = None
    dict_0 = {}
    dict_0['cookiecutter'] = dict_0
    dict_1 = dict_0
    dict_0 = dict_1
    dict_1 = dict_0

    try:
        # Exercise
        dump(int_0, int_1, dict_0)
    except Exception as e:
        assert isinstance(e, TypeError)



# Generated at 2022-06-25 15:33:32.005795
# Unit test for function dump
def test_dump():
    int_0 = -183
    int_1 = None
    var_0 = dump(int_0, int_1)


# Generated at 2022-06-25 15:33:37.548736
# Unit test for function dump
def test_dump():
    int_0 = -276
    str_1 = '%&{}{}{}'
    dict_2 = {'list_of_int': [-8, 8, -807], 'tuple_of_float': (0.50377, 0.91723, 0.3227), 'list_of_float': [0.63181, 0.0, 0.63422]}
    assert dump(int_0, str_1, dict_2) == None


# Generated at 2022-06-25 15:33:46.611403
# Unit test for function dump
def test_dump():
    dump_0 = 'test_cookiecutter_dir'
    dump_1 = 'test_cookiecutter_dir/tests/no_input.json'
    dump_2 = {'cookiecutter': {'full_name': 'First Last', 'email': 'user@example.com'}}
    dump(dump_0, dump_1, dump_2)

    dump_0 = 'test_cookiecutter_dir'
    dump_1 = 'test_cookiecutter_dir/tests/no_input.json'
    dump_2 = {'cookiecutter': {'full_name': 'First Last', 'email': 'user@example.com'}}
    dump(dump_0, dump_1, dump_2)

    dump_0 = 'test_cookiecutter_dir'

# Generated at 2022-06-25 15:33:50.696121
# Unit test for function dump
def test_dump():
    try:
        dump(None, 'test_value_0', None)
    except TypeError as error:
        print(error)
    try:
        dump(None, None, None)
    except TypeError as error:
        print(error)
    try:
        dump(None, 'test_value_0', None)
    except TypeError as error:
        print(error)
    try:
        dump(None, 'test_value_0', None)
    except TypeError as error:
        print(error)
    try:
        dump(None, 'test_value_0', None)
    except TypeError as error:
        print(error)



# Generated at 2022-06-25 15:33:51.637426
# Unit test for function dump
def test_dump():
    assert dump() == None


# Generated at 2022-06-25 15:33:56.325811
# Unit test for function load

# Generated at 2022-06-25 15:33:59.199431
# Unit test for function load
def test_load():
    try:
        assert dump()
    except:
        dump()
    try:
        assert load()
    except:
        load()


# Generated at 2022-06-25 15:34:01.305317
# Unit test for function load
def test_load():
    print ("test_load")
    context = load('~/loghub','loghub-project')



# Generated at 2022-06-25 15:34:02.177474
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:34:04.055002
# Unit test for function load
def test_load():
    # assert_equal(expected, load(replay_dir, template_name))
    assert False # TODO: implement your test here


# Generated at 2022-06-25 15:34:04.889400
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:34:08.581160
# Unit test for function load
def test_load():
    print ('Starting unit test for load')
    path = 'C:/Users/Himanshu/Desktop/cookiecutter-master/cookiecutter-master/tests/test_replay'
    replay_file = 'tests/test_replay/replay_json_example.json'
    context = load(path, replay_file)
    print (context)



# Generated at 2022-06-25 15:34:10.412264
# Unit test for function load
def test_load():
    var_0 = load()

# Generated at 2022-06-25 15:34:12.248457
# Unit test for function load
def test_load():
    """test load."""
    assert load() == '__main__'


# Generated at 2022-06-25 15:34:13.300717
# Unit test for function load
def test_load():
    assert True == True


# Generated at 2022-06-25 15:34:23.132306
# Unit test for function load
def test_load():
    import tempfile
    import shutil

    tdir0 = tempfile.mkdtemp()
    test_data0 = {'a': 'this is a test'}

    dump(tdir0, 'foo', test_data0)
    assert load(tdir0, 'foo') == test_data0

    shutil.rmtree(tdir0)

    tdir1 = tempfile.mkdtemp()
    test_data1 = {}

    with pytest.raises(ValueError):
        dump(tdir1, 'foo', test_data1)

    shutil.rmtree(tdir1)

    tdir2 = tempfile.mkdtemp()
    test_data2 = {'a': 'this is a test', 'cookiecutter': None}


# Generated at 2022-06-25 15:34:25.531008
# Unit test for function load
def test_load():
    str_0 = 'wxV$Z>'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:34:27.386204
# Unit test for function load
def test_load():
    str_0 = 'H{w5o'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:34:28.198707
# Unit test for function load
def test_load():
    test_case_0()

# Generated at 2022-06-25 15:34:33.570919
# Unit test for function load
def test_load():
    str_0 = 'kqA3#b'
    var_0 = load(str_0, str_0)
    assert var_0 == '{"cookiecutter": {"full_name": "First Last", "email": "First.Last@email.com", "project_name": "My Test Project", "repo_name": "my_test_project", "project_short_description": "A short description of the project."}}'


# Generated at 2022-06-25 15:34:43.483518
# Unit test for function dump
def test_dump():
    dict_0 = {}
    dict_0['0'] = '0'
    dict_0['1'] = '1'
    dict_0['2'] = '2'
    dict_0['3'] = '3'
    dict_0['4'] = '4'
    dict_0['5'] = '5'
    dict_0['6'] = '6'
    dict_0['7'] = '7'
    dict_0['8'] = '8'
    dict_0['9'] = '9'
    dict_0['10'] = '10'
    dict_0['11'] = '11'
    dict_0['12'] = '12'
    dict_0['13'] = '13'
    dict_0['14'] = '14'
    dict_0['15'] = '15'


# Generated at 2022-06-25 15:34:46.410469
# Unit test for function load
def test_load():
    # test 0
    assert dump('./replay', './replay', str('./replay')) == None

    # test 1
    assert dump(str(), str(), str()) == None




# Generated at 2022-06-25 15:34:48.917430
# Unit test for function load
def test_load():
    str_0 = 'wxV$Z>'
    var_0 = load(str_0, str_0)
    assert(var_0 == {'cookiecutter': {}})



# Generated at 2022-06-25 15:34:51.273839
# Unit test for function dump
def test_dump():
    template_name = 'Zc%h>R'
    context = {'cookiecutter': {'_template': 'Zc%h>R'}}
    dump(template_name, template_name, context)



# Generated at 2022-06-25 15:34:57.024967
# Unit test for function load
def test_load():
    # Test 1
    str_0 = 'wxV$Z>'
    var_0 = load(str_0, str_0)
    assert var_0 == {'cookiecutter': {'project_name': 'cookiecutter-pypackage', 'repo_name': 'cookiecutter-pypackage', 'package_name': 'cookiecutter_pypackage'}}
    # Test 2
    str_0 = 'Oea_'
    var_0 = load(str_0, str_0)
    assert var_0 == {'cookiecutter': {'project_name': 'cookiecutter-pypackage', 'repo_name': 'cookiecutter-pypackage', 'package_name': 'cookiecutter_pypackage'}}
    # Test 3

# Generated at 2022-06-25 15:35:06.490125
# Unit test for function load
def test_load():
    var_1 = get_file_name("<dir_path>", "template_name")
    var_2 = dump("<dir_path>", "template_name", "<json_context>")
    if var_1 == None:
    	print("var_1 is None")
    elif var_2 == None:
    	print("var_2 is None")
    print("var_1 : ", var_1)
    print("var_2 : ", var_2)

# Generated at 2022-06-25 15:35:08.984860
# Unit test for function load
def test_load():
    str_0 = 'd^kO#g'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:35:11.215075
# Unit test for function load
def test_load():
    str_0 = 'wxV$Z>'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:35:17.412930
# Unit test for function load
def test_load():
    # Test when first arg is not a str
    with pytest.raises(TypeError) as excinfo:
        load(1,'jz&b~C')
    assert str(excinfo.value) == 'Template name is required to be of type str'

    # Test when last arg is not a str
    with pytest.raises(TypeError) as excinfo:
        load('1','1')
    assert str(excinfo.value) == 'Template name is required to be of type str'

    # Test when context does not contain a cookiecutter value
    with pytest.raises(ValueError) as excinfo:
        load('jz&b~C','jz&b~C')
    assert str(excinfo.value) == 'Context is required to contain a cookiecutter key'


# Generated at 2022-06-25 15:35:18.973522
# Unit test for function dump
def test_dump():
    """
    Test cookiecutter.replay.dump
    """
    assert True


# Generated at 2022-06-25 15:35:29.051121
# Unit test for function load
def test_load():
    str_0 = 'wxV$Z>'
    print('replay_dir: ' + str_0)
    print('template_name: ' + str_0)
    var_0 = load(str_0, str_0)
    print('Context: ' + str(var_0))
    print('cookiecutter key: ' + str(var_0['cookiecutter']))
    print('Name: ' + str(var_0['cookiecutter']['full_name']))
    print('Email: ' + str(var_0['cookiecutter']['email']))
    print('Project_Name: ' + str(var_0['cookiecutter']['project_name']))
    print('Description: ' + str(var_0['cookiecutter']['description']))


# Generated at 2022-06-25 15:35:30.858817
# Unit test for function load
def test_load():
    replay_dir = 'Gc%[H'
    template_name = 'L^y/<'
    assert load(replay_dir, template_name) == 'p#+}B'



# Generated at 2022-06-25 15:35:36.052904
# Unit test for function load
def test_load():
    assert load(
        '/Users/hailiang/Documents/python_rep/cookiecutter/tests/files/fake-repo-pre/',
        'fake-repo-pre.zip'
    ) == {
        'cookiecutter': {
            'a': '1',
            'b': '2'
        }
    }


# Generated at 2022-06-25 15:35:38.994654
# Unit test for function dump
def test_dump():
    str_0 = 'wxV$Z>'
    str_1 = 'm?UKx'
    var_0 = dump(str_0, str_1, None)


# Generated at 2022-06-25 15:35:40.764016
# Unit test for function load
def test_load():
    str_0 = 'wxV$Z>'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:35:50.297194
# Unit test for function load
def test_load():
    assert callable(load)
    # Test with required paramaters
    try:
        test_case_0()
        print("Test case 0 passed.")
    except AssertionError:
        print("Test case 0 failed")
    except Exception:
        print("Test case 0 excepted")


# Generated at 2022-06-25 15:35:52.925032
# Unit test for function load
def test_load():

    str_0 = 'wxV$Z>'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:35:55.775408
# Unit test for function load
def test_load():
    assert callable(load)
    try:
        dump('', '', {})
        dump('', [], {})
        dump([], '', {})
        dump('', '', '')
        dump('', '', [])
    except (TypeError) as error:
        test_case_0()


# Generated at 2022-06-25 15:35:59.689108
# Unit test for function load
def test_load():
    str_0 = 'yU+h<f`|}b2&%Xj+Z:mz.n/'
    str_1 = 'yU+h<f`|}b2&%Xj+Z:mz.n/'
    var_0 = load(str_0, str_1)
    print(var_0)


# Generated at 2022-06-25 15:36:06.011102
# Unit test for function load
def test_load():
    str_0 = 'wxV$Z>'
    var_0 = load(str_0, str_0)

    str_1 = 'nq%+s(C'
    var_1 = load(str_0, str_1)

    str_2 = ''
    var_2 = load(str_0, str_2)



# Generated at 2022-06-25 15:36:07.255415
# Unit test for function load
def test_load():
    if __debug__:
        test_case_0()

# Generated at 2022-06-25 15:36:08.504906
# Unit test for function load
def test_load():
    # Runs before everything
    test_case_0()


# Generated at 2022-06-25 15:36:09.389517
# Unit test for function dump
def test_dump():
    test_case_0()


# Generated at 2022-06-25 15:36:19.301778
# Unit test for function load
def test_load():

    str_0 = 'hVu:6'
    assert (load(str_0, '<W[hz?}') == {})

    str_0 = '+n!}S'
    var_0 = load(str_0, str_0)
    assert (var_0 == {'cookiecutter': {}})

    str_0 = '0p0e'
    var_0 = load(str_0, 'P`oZ`')
    assert (var_0 == {'cookiecutter': {}})

    str_0 = 'DzZm'
    var_0 = load(str_0, '!X}e-')
    assert (var_0 == {'cookiecutter': {}})

    str_0 = '#tIy'

# Generated at 2022-06-25 15:36:31.229975
# Unit test for function load
def test_load():
    str_0 = '~wug|]@b3x-O5QF9y'
    assert get_file_name(str_0, str_0) == '~wug|]@b3x-O5QF9y/~wug|]@b3x-O5QF9y.json',\
        'Expected to return ~wug|]@b3x-O5QF9y/~wug|]@b3x-O5QF9y.json'

    var_0 = dump('O98@IbM+qTOJg9.f8~', 'C>(=+xz~rG^JtTUp', {'cookiecutter': {}})

# Generated at 2022-06-25 15:36:37.828921
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:36:44.038315
# Unit test for function load
def test_load():
    assert callable(load)
    try:
        if os.uname()[0] == 'Windows':
            test_case_0()
        # if os.uname()[0] == 'Linux':
        #     test_case_1()
        # if os.uname()[0] == 'Darwin':
        #     test_case_2()
    except:
        print('Your platform is not supported')


# Generated at 2022-06-25 15:36:49.087102
# Unit test for function load
def test_load():
    # parameters
    template_name = 'test'
    replay_dir = 'test'

    # expected result
    expected_result = 'test'

    # actual result
    actual_result = load(replay_dir, template_name)

    # assert result
    assert (expected_result == actual_result)


# Generated at 2022-06-25 15:36:59.464958
# Unit test for function load

# Generated at 2022-06-25 15:37:09.452425
# Unit test for function load
def test_load():
    replay_dir = 'replay_dir'
    str_0 = 'xyz'
    context = {}
    context['cookiecutter'] = {'abc': 'def'}

    dump(replay_dir, str_0, context)

    actual_val = load(replay_dir, str_0)
    assert actual_val == context

    # Should raise TypeError, template_name is required to be of type str
    try:
        load(replay_dir, 1)
    except TypeError:
        pass
    else:
        raise AssertionError('Should raise TypeError')

    # Should raise ValueError, context is required to contain a cookiecutter key
    try:
        load(replay_dir, str_0)
    except ValueError:
        pass

# Generated at 2022-06-25 15:37:19.168463
# Unit test for function dump
def test_dump():
    print('begin test_dump')
    str_0 = 'pxC_b1'
    dump(str_0, str_0, str_0)
    dump(str_0, str_0, str_0)
    dump(str_0, str_0, str_0)
    dump(str_0, str_0, str_0)
    dump(str_0, str_0, str_0)
    dump(str_0, str_0, str_0)
    dump(str_0, str_0, str_0)
    dump(str_0, str_0, str_0)
    dump(str_0, str_0, str_0)
    dump(str_0, str_0, str_0)
    dump(str_0, str_0, str_0)
   

# Generated at 2022-06-25 15:37:22.081694
# Unit test for function load
def test_load():
    str_0 = 'wxV$Z>'
    assert isinstance(load(str_0, str_0), dict)


# Generated at 2022-06-25 15:37:26.402064
# Unit test for function load
def test_load():
    with open('./load_fixture.json', 'r') as infile:
        load_fixture = json.load(infile)

    assert load("./replay_dir", "fixture") == load_fixture


# Generated at 2022-06-25 15:37:27.279075
# Unit test for function load
def test_load():
    # Test:
    assert callable(load)

# Generated at 2022-06-25 15:37:33.044283
# Unit test for function load
def test_load():
    print("----test_load")

    # setup testing for load
    str_0 = 'wxV$Z>'
    str_1 = "cookiecutters"

    test_case_0()
    # It's not very useful to do assert checks in the load function
    # other than making sure the function returns a usable value

    print("Unit test complete\n")


# Generated at 2022-06-25 15:37:44.028755
# Unit test for function load
def test_load():
    # Test with valid arguments
    file_name_0 = '/etc/init.d/setup.py'
    template_name_0 = '/var/log/pkg.cfg'
    context_0 = load(file_name_0, template_name_0)



# Generated at 2022-06-25 15:37:46.497911
# Unit test for function load
def test_load():
    str_0 = 'wxV$Z>'
    var_0 = load(str_0, str_0)
    assert(var_0 == str_0)


# Generated at 2022-06-25 15:37:47.280789
# Unit test for function load
def test_load():
    assert test_case_0() == None

# Generated at 2022-06-25 15:37:49.221946
# Unit test for function load
def test_load():
    assert callable(load)
    # Test for empty replay dir
    assert load('./', 'test_template') is None
    # Test for template name type
    try:
        load('.', 1)
    except TypeError:
        pass


# Generated at 2022-06-25 15:37:53.825201
# Unit test for function load
def test_load():
    str_0 = '>bJ8(t'
    #str_0 = 'wxV$Z>'
    str_1 = 'c:\\Users\\AEGEE\\Documents\\Profesional\\Projects\\python\\dev\\example-cookiecutter'
    str_2 = 'context.json'
    var_0 = load(str_0, str_2)
    var_1 = load(str_1, str_2)
    assert var_0 == var_1, 'Test 0 failed'


# Generated at 2022-06-25 15:37:55.674024
# Unit test for function dump
def test_dump():
    # Write your own test
    pass


# Generated at 2022-06-25 15:37:58.203585
# Unit test for function load
def test_load():
    pass
    
    # Test with assertion
    assert func_return == var_1


# Generated at 2022-06-25 15:38:00.843297
# Unit test for function load
def test_load():
    # Create a variable for the function call
    var_0 = '~i`mKzvD'
    # Call function load with arguments var_0 and var_0
    test_case_0()


# Generated at 2022-06-25 15:38:06.821200
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    # test_dir = '{{cookiecutter.project_slug}}'
    test_dir = 'project_slug'
    # test_dir = 'project_slug'
    os.makedirs(test_dir)
    try:
        context = cookiecutter(
            'example_repo',
            replay_dir=test_dir,
            overwrite_if_exists=True,
            skip_if_file_exists=False,
        )
        dump(test_dir, 'example_repo', context)
    finally:
        os.remove(os.path.join(test_dir, 'example_repo.json'))
        os.rmdir(test_dir)

# Generated at 2022-06-25 15:38:12.149231
# Unit test for function dump
def test_dump():
    replay_dir = 'wxV$Z>'
    template_name = 'wxV$Z>'
    context = 'wxV$Z>'
    # dump(replay_dir, template_name, context)



# Generated at 2022-06-25 15:38:21.417634
# Unit test for function load
def test_load():
    assert test_case_0() == {
        'cookiecutter': {'_copy_without_render': ['*'], '_replay_file': 'wxV$Z>'}
    }



# Generated at 2022-06-25 15:38:30.797454
# Unit test for function dump
def test_dump():
    # test_0
    try:
        str_0 = 'SL_=i:P'
        func_0 = load(str_0, str_0)
    except(Exception):
        func_0 = False
    assert func_0 == False

    # test_1
    try:
        str_0 = '$\nq'
        func_1 = load(str_0, str_0)
    except(Exception):
        func_1 = False
    assert func_1 == False

    # test_2
    try:
        str_0 = 'P)I6A'
        func_2 = load(str_0, str_0)
    except(Exception):
        func_2 = False
    assert func_2 == False

    # test_3

# Generated at 2022-06-25 15:38:34.788563
# Unit test for function dump
def test_dump():
    arg0 = b'\xa1'
    test_case_0.cookiecutter = {}
    dump(b'\x12\x02\x01', b'\x16\x06\x02\x04', test_case_0)


# Generated at 2022-06-25 15:38:36.570266
# Unit test for function load
def test_load():
    var_0 = str(vars())
    var_0 = '$E#xj'
    var_1 = test_case_0()
    return var_0 and var_1

# Generated at 2022-06-25 15:38:38.283147
# Unit test for function load
def test_load():
    try:
        test_case_0()
    # AssertionError, IOError, TypeError, ValueError
    except:
        raise


# Generated at 2022-06-25 15:38:40.896991
# Unit test for function load
def test_load():
    assert test_case_0() is None

# Generated at 2022-06-25 15:38:46.655460
# Unit test for function load
def test_load():
    print("Test 0: ")
    try:
        test_case_0()
    except TypeError as e:
        print("Error: Function load does not work for type: %s" % type(str))
    except ValueError as e:
        print("Error: Function load does not work for Value: %s" % str_0)
    else:
        print("Test 0: Pass")

# Generated at 2022-06-25 15:38:47.586740
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:38:55.189791
# Unit test for function load
def test_load():
    print('test_load')

    print('test_load: Test 1')
    json_str = '{"foo": "bar"}'
    template_name = 'template_name'
    replay_dir = 'replay_dir'
    exp_context = {'foo': 'bar'}
    mock_open = mock.mock_open(read_data=json_str)
    with mock.patch('builtins.open', mock_open):
        context = load(replay_dir, template_name)
    assert context == exp_context

    print('test_load: Test 2')
    json_str = '{"foo": "bar"}'
    template_name = 'template_name'
    replay_dir = 'replay_dir'
    exp_context = {'foo': 'bar'}

# Generated at 2022-06-25 15:38:56.083425
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:39:08.927934
# Unit test for function load
def test_load():
    str_0 = 'wxV$Z>'
    var_0 = load(str_0, str_0)

# Generated at 2022-06-25 15:39:11.911808
# Unit test for function load
def test_load():
    print('Test for load')
    print('Case 0: standard')
    test_case_0()
    print('Case 1: non-existing file')
    print('Case 2: non-json file')


if __name__ == '__main__':
    test_load()

# Generated at 2022-06-25 15:39:15.287629
# Unit test for function load
def test_load():
    replay_dir = "wxV$Z>"
    template_name = "wxV$Z>"
    # assert load(replay_dir, template_name)  == "value"


# Generated at 2022-06-25 15:39:17.949084
# Unit test for function load
def test_load():
    try:
        replay_dir = 'wxV$Z>'
        template_name = 'wxV$Z>'
        load(replay_dir, template_name)
    except TypeError:
        assert True
        return


# Generated at 2022-06-25 15:39:18.633179
# Unit test for function dump
def test_dump():
    assert callable(dump)


# Generated at 2022-06-25 15:39:20.065952
# Unit test for function load
def test_load():
    print('Start testing function load')
    # Test case 0
    print('Test case 0')
    test_case_0()
    print('End testing function load')



# Generated at 2022-06-25 15:39:22.506197
# Unit test for function load
def test_load():
    str_0 = 'user/repo'
    var_0 = load(str_0, str_0)
    print(var_0)
    print(type(var_0))


# Generated at 2022-06-25 15:39:24.264013
# Unit test for function dump
def test_dump():
    str_0 = 'Fh!IJ'
    var_0 = dump(str_0, str_0, str_0)


# Generated at 2022-06-25 15:39:31.512151
# Unit test for function load
def test_load():
    # case 0
    str_0 = 'wxV$Z>'
    var_0 = load(str_0, str_0)
    var_1 = load(str_0, str_0)
    assert var_0 == var_1
    var_2 = load(str_0, str_0)
    assert var_2 != var_1
    var_3 = load(str_0, str_0)
    assert var_2 == var_1


# Generated at 2022-06-25 15:39:36.147731
# Unit test for function load
def test_load():
    str_0 = 'XE3n+'
    dict_0 = {'cookiecutter': {'_template': 'fakeroot@fake.com/cookiecutter-pypackage'}}
    dict_1 = load(str_0, str_0)
    assert dict_1 == dict_0


# Generated at 2022-06-25 15:39:54.460562
# Unit test for function load
def test_load():
    var_0 = load('yh3jK', 'yh3jK')
    var_1 = load('yh3jK', 'yh3jK')


# Generated at 2022-06-25 15:40:04.435181
# Unit test for function load

# Generated at 2022-06-25 15:40:06.589623
# Unit test for function dump
def test_dump():
	assert True


# Generated at 2022-06-25 15:40:09.241882
# Unit test for function load
def test_load():
    str_0 = 'o`&-oN^$6YSoT6zy1'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:40:11.825459
# Unit test for function load
def test_load():
    # Test case0
    str_0 = 'wxV$Z>'
    try:
        load(str_0, str_0)
    except Exception:
        pass


# Generated at 2022-06-25 15:40:18.159885
# Unit test for function dump
def test_dump():
    import sys
    import flashflood.core.container
    from copy import deepcopy
    from flashflood.core.task import Task, TaskBase
    from flashflood.core.workflow import Workflow
    from flashflood.core.workflow import Query
    from flashflood.core.workflow import Interval
    ctx = deepcopy(ctx_0)
    ctx.update({"cookiecutter": {
        "repository_name": "test_repo_0",
        "workflow_folder": "test_repo_0"
    }})
    wf = Workflow(ctx["cookiecutter"]["workflow_folder"])
    wf.interval = Interval(days=2)

# Generated at 2022-06-25 15:40:22.534752
# Unit test for function dump
def test_dump():
    str_0 = 'test-replay-directory'
    str_1 = 'test-template'
    dict_0 = {'cookiecutter': {'test': 'dict'}}
    dump(str_0, str_1, dict_0)

    dict_1 = load(str_0, str_1)
    assert dict_1 == dict_0



# Generated at 2022-06-25 15:40:24.434127
# Unit test for function load
def test_load():
    assert(load('/var/tmp', 'test.json') == {"cookiecutter": {"replay": True}})


# Generated at 2022-06-25 15:40:32.380747
# Unit test for function load
def test_load():
    # Replay file "test_data/default_context.json" does not exist
    # test_data/default_context.json does not exist
    with pytest.raises(TypeError):
        load(True, 'test_data/default_context.json')

    # Replay file "test_data/default_context.json" does not exist
    # test_data/default_context.json does not exist
    # test_data does not exist
    with pytest.raises(TypeError):
        load('test_data', False)

    # Replay file "test_data/default_context.json" does not exist
    # test_data/default_context.json does not exist
    with pytest.raises(TypeError):
        load('test_data', True)

    # Replay file "test_data/default_context.json"

# Generated at 2022-06-25 15:40:38.008009
# Unit test for function load
def test_load():
    str_0 = 'my_template'
    str_1 = os.path.join(os.path.dirname(__file__), 'replay_dir')
    result = load(str_1, str_0)
    correct_result = {
        'cookiecutter': {
            'name': 'Audrey Roy',
            'email': 'audreyr@gmail.com',
            'github_username': 'audreyr'
        }
    }
    assert result == correct_result



# Generated at 2022-06-25 15:40:56.539220
# Unit test for function load
def test_load():
    replay_dir = 'test'
    template_name = 'test'
    context = load(replay_dir, template_name)
    assert context['cookiecutter'] == {'bacon': 'bacon_val', 'foo': 'foo_val',
                                       'greeting': 'hello world'}

test_case_0()

# Generated at 2022-06-25 15:40:58.435542
# Unit test for function load
def test_load():
    var_0 = 'h`Ne*'
    str_0 = 'l{@>B'
    var_1 = load(var_0, var_0)
    assert var_1
    # test_case_0()

# Generated at 2022-06-25 15:40:59.226332
# Unit test for function load
def test_load():
    # test_case_0()
    pass


# Generated at 2022-06-25 15:41:01.893453
# Unit test for function load
def test_load():
    replay_dir = '/Users/gundam0079/PycharmProjects/cookiecutter/examples/.cookiecutters/cookiecutter-pypackage'
    template_name = 'cookiecutter-pypackage'
    context = load(replay_dir, template_name)
    assert context['cookiecutter'] is not None


# Generated at 2022-06-25 15:41:03.237277
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except Exception:
        assert False # test failed

# Generated at 2022-06-25 15:41:05.087527
# Unit test for function dump
def test_dump():
    str_0 = 'wxV$Z>'
    dump(str_0, str_0, str_0)


# Generated at 2022-06-25 15:41:09.918471
# Unit test for function dump
def test_dump():
    try:
        dump()
        raise AssertionError('Expected Exception not thrown')
    except TypeError:
        pass
    try:
        dump(1, 2, 3, 4, 5)
        raise AssertionError('Expected Exception not thrown')
    except TypeError:
        pass



# Generated at 2022-06-25 15:41:11.581354
# Unit test for function load
def test_load():
    str_0 = 'wxV$Z>'
    var_0 = load(str_0, str_0)



# Generated at 2022-06-25 15:41:19.754512
# Unit test for function dump
def test_dump():
    replay_dir = 'out/replay'
    template_name = 'simple-python-package'
    context = {
        'cookiecutter': {
            'full_name': 'James T. Kirk',
            'email': 'jkirk@enterprise.com',
            'github_username': 'the-captain',
            'project_name': 'simple-python-package',
            'project_short_description': 'An example Python package',
        }
    }
    dump(replay_dir, template_name, context)
    new_context = load(replay_dir, template_name)


# Generated at 2022-06-25 15:41:22.100995
# Unit test for function load
def test_load():
    assert load(None, None) == None

if __name__ == '__main__':
    for i in range(0):
        test_case_0()

# Generated at 2022-06-25 15:41:47.028374
# Unit test for function dump
def test_dump():
    import tempfile
    dir_name = tempfile.mkdtemp()
    dump(dir_name, 'demo', {'cookiecutter': {'full_name': 'John Doe', 'project_name': 'foobar'}})
    path = os.path.join(dir_name, 'demo.json')
    assert os.path.exists(path)

    with open(path, 'r') as f:
        content = json.load(f)
        assert 'cookiecutter' in content
        assert 'full_name' in content['cookiecutter']
        assert 'project_name' in content['cookiecutter']

    try:
        os.remove(path)
    except:
        raise



# Generated at 2022-06-25 15:41:50.664358
# Unit test for function load
def test_load():
    expected_result = {u'cookiecutter': {u'project_name': u'A Bad Project'}}
    result = load('.', 'fake_repo')
    assert result == expected_result

# Generated at 2022-06-25 15:41:52.734696
# Unit test for function load
def test_load():
  # Test case
  assert load(None,None)

  # Test case
  assert load(None,None)


# Generated at 2022-06-25 15:41:57.324456
# Unit test for function load
def test_load():
    # Option 0
    str_0 = 'test_replay'
    str_1 = 'test_template'
    dict_0 = {'cookiecutter': {'cookiecutter': {'name': 'test_name'}}}
    test_load_0 = load(str_0, str_1)
    assert test_load_0 == dict_0

# Generated at 2022-06-25 15:42:00.746734
# Unit test for function dump
def test_dump():
    str_0 = '1YU-\r'
    dict_0 = dict(str_0=str_0)
    dump(str_0, str_0, dict_0)
    dict_1 = dict(str_0=str_0)
    dump(str_0, str_0, dict_1)


# Generated at 2022-06-25 15:42:02.120386
# Unit test for function load
def test_load():
    assert callable(load)



# Generated at 2022-06-25 15:42:03.938453
# Unit test for function load
def test_load():
    str_0 = 'None'
    str_1 = load(str_0, str_0)
    assert str_1 == None


# Generated at 2022-06-25 15:42:05.240919
# Unit test for function load
def test_load():
    assert callable(load), "Function 'load' not defined"


# Generated at 2022-06-25 15:42:17.659890
# Unit test for function load
def test_load():
    p_0 = 'P|'
    p_1 = 'hw}'
    p_2 = '<\x00'
    p_3 = '~7'
    p_4 = '3q'
    p_5 = 'p\x7f'
    p_6 = '<\x00'
    p_7 = '+h\x0b'
    p_8 = 'D:\x03\x0e\x02\x14\x18\x1c\x1a\x19\x0d\x1c\x03\x0b\x0b\x15\x19\x0d\x0f\x11\x02\x19\x17\x1b\x05\x0c\x14\x02'

# Generated at 2022-06-25 15:42:18.267222
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:42:56.400980
# Unit test for function load
def test_load():
    try:
        str_1 = 'i6!@8!@$!@$!@$@#'
        load(str_1, str_1)
        str_2 = 'i6!@8!@$!@$!@$@#'
        load(str_2, str_2)
    except Exception as e:
        print(str(e))


# Generated at 2022-06-25 15:43:01.167466
# Unit test for function load
def test_load():
    str_0 = 'bwK@M.'
    str_1 = '8W'
    list_0 = [str_1, '']
    dict_0 = {}
    for str_1 in list_0:
        dict_0[str_1] = str_1
    var_0 = dump(str_0, str_0, dict_0)
    var_1 = load(str_0, str_0)
    var_2 = True
    try:
        str_1 = '~A[dX'
        var_2 = load(str_0, str_1)
    except IOError:
        var_2 = False
    assert not var_0

