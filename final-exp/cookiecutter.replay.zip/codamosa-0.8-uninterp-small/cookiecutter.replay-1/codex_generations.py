

# Generated at 2022-06-25 15:33:00.053129
# Unit test for function load
def test_load():
    replay_dir = input('Please enter replay dir: ')
    set_0 = {replay_dir}
    template_name = input('Please enter template name: ')
    var_0 = load(set_0, template_name)
    print(var_0)


# Generated at 2022-06-25 15:33:08.103409
# Unit test for function load
def test_load():
    user_data = {
        'first_name': 'test',
        'last_name': 'test2',
        'email': 'test3@test.com',
        'company': 'test',
        'github_username': 'test',
        'cookiecutter': 'test'
    }
    dump('.', 'test', user_data)
    assert load('.', 'test') == user_data

# Generated at 2022-06-25 15:33:18.796937
# Unit test for function get_file_name
def test_get_file_name():
    str_1 = ''
    set_1 = {str_1}
    var_1 = get_file_name(set_1, set_1)
    assert var_1 == '{}', 'Returned name: {}'.format(var_1)
    str_2 = ''
    set_2 = {str_2}
    var_2 = get_file_name(set_2, set_2)
    assert var_2 == '{}', 'Returned name: {}'.format(var_2)
    str_3 = "foo.json"
    set_3 = {"foo.json"}
    var_3 = get_file_name(set_3, set_3)
    assert var_3 == 'foo.json', 'Returned name: {}'.format(var_3)

# Generated at 2022-06-25 15:33:23.179280
# Unit test for function load
def test_load():
    template_name = 'temp1'
    replay_dir = 'test_case1'
    dict_0 = {0:0,0:0,0:0}
    context = load(replay_dir, template_name)

    assert context == dict_0

# Generated at 2022-06-25 15:33:24.485618
# Unit test for function dump
def test_dump():
    assert dump('', '', {}) == None


# Generated at 2022-06-25 15:33:29.803883
# Unit test for function dump
def test_dump():
    '''
    Reasoning:
    Normal use case. All parameters exist. Make sure the directory can be
    created. Make sure the file name is correct. Make sure the file is
    opened correct. Make sure the json file is written correct.
    '''
    template_name = 'template'
    context = {'cookiecutter': {'directory_name': 'directory'}}
    replay_dir = '/tmp/cookiecutter'
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:33:40.269052
# Unit test for function load
def test_load():
    replay_0 = {'key_0': 'value_0'}
    replay_1 = {'key_0': 'value_1'}
    template_0 = {'dict_0': replay_0, 'dict_1': replay_1}
    context_0 = {'dict_0': {'key_0': 'value_0'}, 'dict_1': {'key_0': 'value_0'}}
    context_1 = {'dict_0': {'key_0': 'value_1'}, 'dict_1': {'key_0': 'value_1'}}
    set_0 = {context_0, context_1}
    set_1 = {context_1, context_0}
    replay_1 = get_file_name(set_0, template_0)

# Generated at 2022-06-25 15:33:46.725434
# Unit test for function dump
def test_dump():
    replay_dir = 'test'
    template_name = 'test'
    context = 'test'
    var_1 = dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:33:48.842258
# Unit test for function load
def test_load():
    set_0 = {1}
    set_1 = {1}
    str_0 = ''
    replay_dir = set_0
    template_name = str_0
    var_0 = load(replay_dir, template_name)


# Generated at 2022-06-25 15:33:50.942205
# Unit test for function dump
def test_dump():
    replay_dir = ''
    template_name = ''
    context = {}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:33:57.746328
# Unit test for function load
def test_load():
    replay_dir = 'replay'
    template_name = 'template_name'
    var_0 = load(replay_dir, template_name)
    print(var_0)

    assert var_0 == 'template_name'
    assert var_0 != replay_dir



# Generated at 2022-06-25 15:33:58.639377
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:34:07.456804
# Unit test for function load
def test_load():
    # Test when the template name is not of type str
    try:
        replay_dir = ''
        int_0 = 0
        load(replay_dir, int_0)
        print('AssertionError: Context is required to be of type dict')
    except AssertionError:
        print('AssertionError: Context is required to be of type dict')

    # Test when the context does not contain a cookiecutter key
    try:
        str_0 = ''
        str_1 = ''
        dict_0 = {}
        load(str_0, str_1, dict_0)
        print('AssertionError: Context is required to contain a cookiecutter key')
    except AssertionError:
        print('AssertionError: Context is required to contain a cookiecutter key')



# Generated at 2022-06-25 15:34:10.279483
# Unit test for function load
def test_load():
    assert load('dir', 'template') != ''


# Generated at 2022-06-25 15:34:11.356102
# Unit test for function dump
def test_dump():
    assert dump != None


# Generated at 2022-06-25 15:34:18.421754
# Unit test for function load
def test_load():
    file_name = 'test.json'
    file_content = '{"a": 5}'
    import tempfile
    temp_dir = tempfile.mkdtemp()
    file_path = os.path.join(temp_dir, file_name)
    with open(file_path, 'w') as content_file:
        content_file.write(file_content)
    try:
        assert load(temp_dir, file_name)['a'] == 5
    finally:
        import shutil
        shutil.rmtree(temp_dir)

# Generated at 2022-06-25 15:34:26.388405
# Unit test for function dump
def test_dump():
    var_0 = u''
    var_0 = dump(var_0, var_0, var_0)


# Generated at 2022-06-25 15:34:28.473547
# Unit test for function dump
def test_dump():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    var_0 = dump(str_0, str_1, str_2)


# Generated at 2022-06-25 15:34:30.979051
# Unit test for function get_file_name
def test_get_file_name():
    
    # Test with string as argument.
    str_0 = ''
    var_0 = get_file_name(str_0, str_0)

# Generated at 2022-06-25 15:34:33.404534
# Unit test for function load
def test_load():
    # basicUnitTest.py
    tmpl_name = "example"
    context = ""
    assert (load("/Users/liron/cookiecutter_replay", tmpl_name)) == (context)

# Generated at 2022-06-25 15:34:39.782490
# Unit test for function load
def test_load():
    try:
        load(0, 0)
        assert False
    except TypeError:
        assert True
    except:
        assert False

    try:
        load('', 0)
        assert False
    except TypeError:
        assert True
    except:
        assert False



# Generated at 2022-06-25 15:34:42.862108
# Unit test for function dump
def test_dump():
    str_0 = ''
    str_1 = ''
    str_2 = '{'
    var_0 = get_file_name(str_0, str_1)
    var_1 = dump(str_0, str_1, str_2)


# Generated at 2022-06-25 15:34:46.938648
# Unit test for function get_file_name
def test_get_file_name():
    # Test for case 0
    assert get_file_name('./replays', 'example') == './replays/example.json'
    # Test for case 1
    assert get_file_name('./replays', 'example.json') == './replays/example.json'



# Generated at 2022-06-25 15:34:53.789125
# Unit test for function load
def test_load():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = ''
    var_0 = load(str_0, str_0)
    var_1 = load(str_1, str_1)
    var_2 = load(str_2, str_2)
    var_3 = load(str_3, str_3)
    var_4 = load(str_4, str_4)
    var_5 = load(str_5, str_5)
    var_6 = load(str_6, str_6)
    var_7 = load(str_7, str_7)

# Generated at 2022-06-25 15:34:56.067606
# Unit test for function get_file_name
def test_get_file_name():
    # Setup
    replay_dir = 'replay'
    template_name = 'test'

    # Exercise
    file_name = get_file_name(replay_dir, template_name)

    # Verify
    expected = 'replay/test.json'
    assert file_name == expected



# Generated at 2022-06-25 15:35:07.784644
# Unit test for function load
def test_load():
    assert load('abc.json','abc.json') == {'cookiecutter': True}
    assert load('abc.json','abc.json') == {'cookiecutter': True}
    assert load('abc.json','abc.json') == {'cookiecutter': True}
    assert load('abc.json','abc.json') == {'cookiecutter': True}
    assert load('abc.json','abc.json') == {'cookiecutter': True}
    assert load('abc.json','abc.json') == {'cookiecutter': True}
    assert load('abc.json','abc.json') == {'cookiecutter': True}
    assert load('abc.json','abc.json') == {'cookiecutter': True}
    assert load('abc.json','abc.json') == {'cookiecutter': True}
   

# Generated at 2022-06-25 15:35:09.099387
# Unit test for function dump
def test_dump():
    dump()


# Generated at 2022-06-25 15:35:15.309943
# Unit test for function load
def test_load():
    try:
        replay_dir = 'test_directory'
        template_name = 'test_template_name'

        with pytest.raises(TypeError):
            load(None, None)

        with pytest.raises(TypeError):
            load(replay_dir, None)

        with pytest.raises(TypeError):
            load(None, template_name)

        with pytest.raises(ValueError):
            load(replay_dir, template_name)
    finally:
        if os.path.exists(replay_dir):
            os.rmdir(replay_dir)


# Generated at 2022-06-25 15:35:23.364986
# Unit test for function load
def test_load():
    replay_dir, template_name = '.cookiecutter', 'cookiecutter-python'
    context = {
        'cookiecutter': {
            '_copy_without_render': ['other_file']
        }
    }
    dump(replay_dir, template_name, context)

    replay_context = load(replay_dir, template_name)

    assert replay_context == context

    os.remove(get_file_name(replay_dir, template_name))



# Generated at 2022-06-25 15:35:24.242313
# Unit test for function get_file_name
def test_get_file_name():
    test_case_0()

# Generated at 2022-06-25 15:35:31.086001
# Unit test for function dump
def test_dump():
    from json import dumps as json_dumps
    from io import open as io_open

    # Replace 'open' with mock
    def as_open(file, *args, **kwargs):
        if file == "C:\\testdir\\/_test_cookiecutter-replay.json":
            return io_open("C:\\testdir\\/_test_cookiecutter-replay.json", "w")
        assert False

    # Replace 'json.dump' with mock
    def as_json_dump(content, file, *args, **kwargs):
        if file.name == "C:\\testdir\\/_test_cookiecutter-replay.json":
            file.write("{}")
            return
        assert False

    import sys
    original_open = open

# Generated at 2022-06-25 15:35:38.170488
# Unit test for function load
def test_load():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    var_0 = get_file_name(str_0, str_1)
    # UNKNOWN @ UndefinedVariable
    # @var_0.flush()
    str_3 = '.json'
    var_1 = str_2.endswith(str_1)
    var_2 = str_2.endswith(str_3)
    assert(var_0 == var_1 == var_2 == '.json')


# Generated at 2022-06-25 15:35:49.258681
# Unit test for function load
def test_load():

    str_0 = "C:\\Users\\cs8907\\ghbvnk-shrd\\"
    str_1 = "ghbvnk-shrd-"
    context = load(str_0, str_1)
    str_2 = context.get("cookiecutter")
    str_3 = "author_name"
    str_4 = str_2.get(str_3)
    str_5 = "author_email"
    str_6 = str_2.get(str_5)
    str_7 = "use_pytest"
    str_8 = str_2.get(str_7)
    str_9 = "project_name"
    str_10 = str_2.get(str_9)

# Generated at 2022-06-25 15:35:52.992004
# Unit test for function load
def test_load():
    replay_dir = 'tests/tests-data/json/'
    print('loading: ' + replay_dir)
    context = load(replay_dir, 'some-template')
    assert isinstance(context, dict)
    assert 'cookiecutter' in context



# Generated at 2022-06-25 15:36:00.387107
# Unit test for function dump
def test_dump():
    str_1 = '123'
    str_2 = '123'
    str_3 = '123'
    dict_0 = {}
    dict_1 = {}
    dict_1['cookiecutter'] = str_3
    var_0 = dump(str_1, str_2, dict_1)
    var_1 = load(str_1, str_2)
    assert var_1 == dict_1
    var_2 = dump(str_1, str_2, dict_0)


# Generated at 2022-06-25 15:36:04.180859
# Unit test for function load
def test_load():
    with pytest.raises(TypeError):
        load(1, 1)
    with pytest.raises(ValueError):
        load('temp', 'temp')


# Generated at 2022-06-25 15:36:06.528052
# Unit test for function dump
def test_dump():
    try:
        assert dump('/home/vagrant/cookiecutter', '', '') == None
    except Exception as e:
        print (e)
        assert False


# Generated at 2022-06-25 15:36:15.124386
# Unit test for function load
def test_load():
    replay_dir = '{{cookiecutter.replay_dir}}'
    # Replay directory should be created by default
    if not os.path.exists(replay_dir):
        os.makedirs(replay_dir)
    replay_file = os.path.join(replay_dir, '{{cookiecutter.replay_file}}')
    template_name = '{{cookiecutter.repo_name}}'
    # If a context file already exists, it is probably for a re-run
    # so we don't need to create/overwrite it again.

# Generated at 2022-06-25 15:36:17.952982
# Unit test for function dump
def test_dump():
    params_0 = {
        'replay_dir': 'C:\\Users\\marcel\\AppData\\Local\\Temp\\cookiecutter-test-replay',
        'template_name': 'cookiecutter-pypackage',
        'context': {
            'cookiecutter': {
                'full_name': 'Marcel Mongeon',
                'email': 'marcel.mongeon@gmail.com',
                'project_name': 'Paw'
            }
        }
    }
    dump(**params_0)


# Generated at 2022-06-25 15:36:24.293482
# Unit test for function load
def test_load():
    assert replay_dir is not None, 'replay_dir should have a value'
    assert template_name is not None, 'template_name should have a value'

    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context, 'cookiecutter key should be in context'



# Generated at 2022-06-25 15:36:29.502454
# Unit test for function load
def test_load():
    var_0 = load(str, str)


# Generated at 2022-06-25 15:36:31.525340
# Unit test for function dump
def test_dump():
    str_0 = ''
    str_1 = ''
    var_0 = dump(str_0, str_0, str_1)



# Generated at 2022-06-25 15:36:38.900499
# Unit test for function load
def test_load():
    str_0 = ''
    str_1 = '_default.json'
    var_0 = get_file_name(str_0, str_1)
    with open(var_0, "w") as var_1:
        var_1.write("{u'cookiecutter': {u'test': u'example'}}")
    var_2 = load(str_0, str_1)
    var_3 = 'example'
    var_4 = var_2['cookiecutter']['test']
    assert var_3 == var_4


# Generated at 2022-06-25 15:36:39.770447
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:36:42.992590
# Unit test for function dump
def test_dump():
    str_0 = ''
    str_1 = 'dump_str'
    dict_0 = {'cookiecutter': {}}
    dump(str_1, str_0, dict_0)


# Generated at 2022-06-25 15:36:53.954441
# Unit test for function dump
def test_dump():
    # mocking name.txt file
    file = open("name.txt", "w")
    file.write("test")
    file.close()
    
    # mocking context.txt file
    file = open("context.txt", "w")
    file.write("test")
    file.close()

    with open('name.txt') as f:
        template_name = f.read()
    with open('context.txt') as f:
        context = f.read()
    replay_dir = "test_dir"
    
    assert (os.path.isdir(replay_dir) == False)
    dump(replay_dir, template_name, context)
    assert (os.path.isdir(replay_dir) == True)

# Generated at 2022-06-25 15:36:56.526151
# Unit test for function load
def test_load():
    replay_dir = './'
    template_name = './tests/test-template'
    load(replay_dir, template_name)


# Generated at 2022-06-25 15:37:07.156425
# Unit test for function dump
def test_dump():
    replay_dir = 'test/functional/replay/'
    template_name = 'dummy'
    context = {'cookiecutter': {'full_name': 'Test User', 'email': 'test@example.com'}}

    dump(replay_dir, template_name, context)

    d_context = load(replay_dir, template_name)
    assert context == d_context


if __name__ == '__main__':
    test_case_0()
    test_dump()

# Generated at 2022-06-25 15:37:17.242327
# Unit test for function load
def test_load():
    assert load('../tests/replay', 'cookiecutter-pypackage') == {
        'cookiecutter': {
            'author_email': 'pydanny@gmail.com',
            'author_github_username': 'pydanny',
            'author_name': 'Daniel Roy Greenfeld',
            'description': 'A PyPA sample project',
            'license': 'MIT',
            'name': 'cookiecutter-pypackage',
            'open_source_license': 'MIT license',
            'use_pytest': 'y',
            'version': '0.1.0',
            'year': '2014'
        }
    }

# Generated at 2022-06-25 15:37:20.989885
# Unit test for function load
def test_load():
    args = []
    # Test function call with arguments: replay_dir='' (type: str), template_name='' (type: str)
    assert load(str, str)


# Generated at 2022-06-25 15:37:29.444583
# Unit test for function load
def test_load():
    template_name = 'bar'
    context = {"cookiecutter": {}}
    replay_dir = '../test'

    dump(replay_dir, template_name, context)
    context_loaded = load(replay_dir, template_name)

    assert context_loaded == context


# Generated at 2022-06-25 15:37:32.951006
# Unit test for function load
def test_load():
    str_1 = ''
    str_0 = ''
    func_0 = load(str_0, str_1)
    assert func_0 == {}


# Generated at 2022-06-25 15:37:37.023245
# Unit test for function load
def test_load():
    str_0 = ''
    dict_0 = {}
    var_0 = dump(str_0, str_0, dict_0)
    var_1 = load(str_0, str_0)


# Generated at 2022-06-25 15:37:39.265126
# Unit test for function dump
def test_dump():
    replay_dir, template_name, context = '', '', {}
    dump(replay_dir, template_name, context)
    return True


# Generated at 2022-06-25 15:37:41.530915
# Unit test for function load
def test_load():
    """
    Stub to test `load` function.
    """
    pass

# Generated at 2022-06-25 15:37:44.707077
# Unit test for function load
def test_load():
    r"""Write unit test for function load."""
    test_case_load()


# Generated at 2022-06-25 15:37:47.549184
# Unit test for function load
def test_load():
    replay_dir = 'test'
    template_name = 'template_name'
    context = load(replay_dir, template_name)
    assert isinstance(context, dict)
    assert 'cookiecutter' in context


# Generated at 2022-06-25 15:37:48.557466
# Unit test for function load
def test_load():
    assert isinstance(load(get_file_name('', ''), ''), dict)


# Generated at 2022-06-25 15:37:49.837429
# Unit test for function dump
def test_dump():
    dump(str_0, str_0, dict_0)


# Generated at 2022-06-25 15:37:54.456810
# Unit test for function load
def test_load():
    str_0 = ''
    str_1 = 'mY*@|#gV7#{S1iqS*1_z)w'
    str_2 = '/4uQP%U'
    var_0 = {str_1: '{{cookiecutter.foo}}'}
    func_0 = load(str_0, str_0)
    var_1 = load(str_0, str_1)
    var_2 = load(str_2, str_2)
    var_3 = load(str_2, str_1)


# Generated at 2022-06-25 15:38:00.301681
# Unit test for function load
def test_load():
    """Test load."""
    assert True


# Generated at 2022-06-25 15:38:02.209708
# Unit test for function load
def test_load():
    str_0 = ''
    str_1 = ''
    var_0 = load(str_1, str_0)


# Generated at 2022-06-25 15:38:04.097395
# Unit test for function load
def test_load():
    template_name = None
    replay_dir = None
    load(template_name, replay_dir)
    return


# Generated at 2022-06-25 15:38:12.762726
# Unit test for function load
def test_load():
    str_0 = '/root/Downloads/cookiecutter-pypackage-with-cli/{{cookiecutter.project_slug}}'
    str_1 = '{{cookiecutter.project_name}}'
    str_2 = '{{cookiecutter.project_slug}}'
    str_3 = '{{cookiecutter.project_version}}'
    str_4 = '{{cookiecutter.author_name}}'
    str_5 = '{{cookiecutter.email}}'
    str_6 = '{{cookiecutter.description}}'
    str_7 = '{{cookiecutter.domain_name}}'
    str_8 = '{{cookiecutter.use_pytest}}'
    str_9 = '{{cookiecutter.use_pypi_deployment_with_travis}}'
   

# Generated at 2022-06-25 15:38:16.282820
# Unit test for function dump
def test_dump():
    replay_dir = 'replay'
    template_name = 'replay/{{cookiecutter.project_name|lower}}_{{cookiecutter.project_slug}}'
    context = {
        'cookiecutter': {
                'project_name': 'ENERGYPLUS',
                'project_slug': 'energyplus'
        }
    }
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:38:24.326199
# Unit test for function dump
def test_dump():
    # Setup
    replay_dir = 'platforms/win/cache/cookiecutter/tests/files/test-cookiecutter-json-replay'
    template_name = 'test-cookiecutter-json-replay'
    context = {'cookiecutter': {'full_name': 'AUTHOR', 'email': 'author@example.com'}, 'platform': 'win', 'module': 'cookiecutter.replay'}

    # Exercise
    dump(replay_dir, template_name, context)

    # Verify
    pass



# Generated at 2022-06-25 15:38:31.505811
# Unit test for function load
def test_load():
    str_0 = ''
    dict_0 = {}
    dict_0['cookiecutter'] = dict_0
    str_1 = dump(str_0, str_0, dict_0)
    dict_1 = load(str_0, str_0)


# Generated at 2022-06-25 15:38:39.265317
# Unit test for function load
def test_load():
    template_name = 'test'
    # Test for valid file
    replay_dir = 'test'
    make_sure_path_exists(replay_dir)
    dump(replay_dir, template_name, {'cookiecutter': {'name': 'test_project'}})
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter': {'name': 'test_project'}}, "Incorrect result from load()"

    # Test for non-existing file
    replay_dir = 'test2'
    result = load(replay_dir, template_name)

    # Test for invalid type of replay_dir argument
    replay_dir = 1
    result = load(replay_dir, template_name)
    
    # Test for invalid type of template_name argument
   

# Generated at 2022-06-25 15:38:48.756807
# Unit test for function load
def test_load():
    assert callable(load)
    template_name = "cookiecutter-pytest"
    replay_dir = "tests/replay"
    context = load(replay_dir, template_name)
    assert context == {'cookiecutter': {'extra_context': {'namespace_package': 'tes', 'open_source_license': 'MIT', 'package_name': 'cookiecutter-pytest', 'package_short_description': 'A cookiecutter template to test Cookiecutter', 'python_classifier': 'Topic :: Software Development :: Testing', 'use_circleci': 'n', 'use_travis': 'y', 'year': '2015'}}}


# Generated at 2022-06-25 15:38:52.122840
# Unit test for function load
def test_load():
    var_0 = '/tmp/cookiecutter-bFmW8O/{{cookiecutter.repo_name}}/cookiecutter-{{cookiecutter.repo_name}}'
    var_1 = 'test_repo'

    var_2 = load(var_0, var_1)


# Generated at 2022-06-25 15:39:03.734974
# Unit test for function load
def test_load():
    assert load(str_0, str_0) == {'cookiecutter': {}}


# Generated at 2022-06-25 15:39:09.534912
# Unit test for function dump
def test_dump():
    replay_dir = os.path.abspath(os.curdir)
    template_name = 'template_name'
    context = {'cookiecutter': {'template_name': 'test_case_0'}}
    dump(replay_dir, template_name, context)
    new_context = load(replay_dir, template_name)
    assert new_context == context
    os.remove(template_name + '.json')


# Generated at 2022-06-25 15:39:11.276468
# Unit test for function load
def test_load():
    replay_dir = ''
    template_name = ''
    var_0 = load(replay_dir, template_name)


# Generated at 2022-06-25 15:39:20.131008
# Unit test for function dump
def test_dump():
    str_0 = '.'
    str_1 = ''
    dict_0 = dict()
    dict_0['cookiecutter'] = dict()
    dict_0['cookiecutter']['email'] = 'email@example.com'
    dict_0['cookiecutter']['full_name'] = 'First Last'
    dict_0['cookiecutter']['github_username'] = 'example'
    dict_0['cookiecutter']['project_name'] = 'example-project'
    dict_0['cookiecutter']['project_slug'] = 'example_project'
    dict_0['cookiecutter']['project_short_description'] = 'A really nice project'
    dict_0['cookiecutter']['release_date'] = 'YYYY-MM-DD'

# Generated at 2022-06-25 15:39:30.407842
# Unit test for function load
def test_load():
    # Test cases extracted from Cookiecutter-Pypackage's tests
    from cookiecutter.operations import dump, load
    from cookiecutter.main import cookiecutter
    from cookiecutter import utils

    # Restoring a replay doesn't recreate the directories

# Generated at 2022-06-25 15:39:32.518769
# Unit test for function dump
def test_dump():
    str_0 = ''
    dict_0 = {}
    var_0 = dump(str_0, str_0, dict_0)


# Generated at 2022-06-25 15:39:33.959868
# Unit test for function dump
def test_dump():

    # Test cases
    test_case_0()


# Generated at 2022-06-25 15:39:34.837874
# Unit test for function dump
def test_dump():
    test_case_0()


# Generated at 2022-06-25 15:39:39.946671
# Unit test for function load
def test_load():
    str_1 = ''
    var_1 = load(str_1, str_1)
    assert var_1 == None

    str_2 = ''
    var_2 = load(str_2, str_1)
    assert var_2 == None

    str_3 = ''
    str_4 = ''
    var_3 = load(str_3, str_4)
    assert var_3 == None


# Generated at 2022-06-25 15:39:40.727948
# Unit test for function load
def test_load():
	pass


# Generated at 2022-06-25 15:40:14.147704
# Unit test for function load
def test_load():
    # Test for function load
    replay_dir = 'test/files'
    template_name = 'template_name'
    context = load(replay_dir, template_name)
    assert context['cookiecutter'] == {'foo': '123'}
    # Test for function load
    replay_dir = ''
    template_name = ''
    context = load(replay_dir, template_name)
    assert context['cookiecutter'] == {'foo': '123'}
    # Test for function load
    replay_dir = ''
    template_name = 'template_name'
    context = load(replay_dir, template_name)
    assert context['cookiecutter'] == {'foo': '123'}
    # Test for function load
    replay_dir = ''
    template_name = 'template_name'


# Generated at 2022-06-25 15:40:19.316138
# Unit test for function dump
def test_dump():
    str_0 = 'template_name'
    str_1 = 'replay_dir'
    dic_0 = {'cookiecutter': str_0, 'foo': 'bar'}
    replay_0 = dump(str_0, str_1, dic_0)
    assert replay_0



# Generated at 2022-06-25 15:40:22.519147
# Unit test for function dump
def test_dump():
    str_0 = ''
    dict_0 = {}
    dict_0['cookiecutter'] = dict_0
    
    var_1 = dump(str_0, str_0, dict_0)
    print(var_1)


# Generated at 2022-06-25 15:40:30.945705
# Unit test for function load
def test_load():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = '404eec05ffa609e9c3ed3a3d62a8a69d'
    str_5 = '404eec05ffa609e9c3ed3a3d62a8a69d'
    str_6 = '404eec05ffa609e9c3ed3a3d62a8a69d'
    str_7 = 'dd18f2a2c8ef8db59b26f04a9d9b1df8'
    str_8 = 'dd18f2a2c8ef8db59b26f04a9d9b1df8'

# Generated at 2022-06-25 15:40:35.721215
# Unit test for function load
def test_load():
    template_name_0 = '~/replay-dir/'
    template_name_1 = '~/replay-dir/'
    context_0 = {{}}
    local_0_1 = load(template_name_0, template_name_1)
    assert local_0_1 == context_0


# Generated at 2022-06-25 15:40:40.460802
# Unit test for function dump

# Generated at 2022-06-25 15:40:43.266056
# Unit test for function load
def test_load():
    assert load('Path to replay_dir', 'Path to template_name') == None


# Generated at 2022-06-25 15:40:47.833886
# Unit test for function load
def test_load():
    path_0 = 'C:\\Users\\d1m9p1n\\Documents\\GitHub\\Cookiecutter\\tests\\files\\fake-repo-pre'
    name_0 = 'fake-repo-pre'
    var_0 = load(path_0, name_0)
    assert type(var_0) == dict
    assert 'cookiecutter' in var_0

# Generated at 2022-06-25 15:40:50.081573
# Unit test for function load
def test_load():
    replay_dir = 'test_file'
    template_name = 'test_file'
    load(replay_dir, template_name)


# Generated at 2022-06-25 15:40:56.050849
# Unit test for function load
def test_load():
    str_0 = 'tests/test-repo-pre/'
    str_1 = 'cookiecutter.json'
    var_0 = get_file_name(str_0, str_1)
    var_1 = load(str_0, str_1)
    assert var_0 == 'tests/test-repo-pre/cookiecutter.json'
    assert var_1 == {"cookiecutter":{"default_context": {"commit_message": "Initial commit from Cookiecutter", "full_name": "Audrey Roy", "project_name": "Test Project", "project_slug": "test_project", "release_date": "2013-06-09", "version": "0.1.0"}}}


# Generated at 2022-06-25 15:41:52.228441
# Unit test for function load
def test_load():
    try:
        load(str, str)
        assert False
    except TypeError:
        assert True

    try:
        load(str, 'cookiecutter-pypackage')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-25 15:41:57.249243
# Unit test for function load
def test_load():
    print('Testing load...')
    #from cookiecutter.main import cookiecutter
    #print(cookiecutter)
    replay_dir = os.getcwd()
    template_name = 'salty-dusk-8251'
    load(replay_dir, template_name)


if __name__ == '__main__':
    #test_case_0()
    test_load()

# Generated at 2022-06-25 15:42:01.819499
# Unit test for function load
def test_load():
    print('--- start of function load test ---')
    try:
        str_0 = 'cookiecutter-pypackage'
        str_1 = 'cookiecutter-pypackage/cookiecutter.json'
        _load = load(str_0, str_1)
        print(_load)
        #print('exception: {}'.format(e))
    except Exception as e:
        print('exception: {}'.format(e))
    print('--- end of function load test ---')


# Generated at 2022-06-25 15:42:03.459734
# Unit test for function load
def test_load():
    str_0 = ''
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:42:05.131603
# Unit test for function load
def test_load():
    context = load('/tmp', 'foo.json')
    print(context)


# Generated at 2022-06-25 15:42:14.082810
# Unit test for function dump
def test_dump():
    str_0 = ''
    dict_0 = dict()
    dict_1 = dict()
    dict_1['cookiecutter'] = dict_0
    dict_2 = dict()
    dict_2['halo'] = dict_1
    dict_3 = dict()
    dict_3['cookiecutter'] = dict_2
    dict_4 = dict()
    dict_4['cookiecutter'] = dict_3
    dump(str_0, str_0, dict_4)


# Generated at 2022-06-25 15:42:15.493434
# Unit test for function load
def test_load():
    assert load('test_dir', 'template_name') is not None


# Generated at 2022-06-25 15:42:19.025421
# Unit test for function dump
def test_dump():
    replay_dir = 'test_replay_dir'
    template_name = 'test_case_0'
    context = {'cookiecutter': {'project_slug': 'test_case_0'}}
    dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:42:23.494331
# Unit test for function load
def test_load():
    context = load('', '')
    assert isinstance(context, dict)



# Generated at 2022-06-25 15:42:24.710256
# Unit test for function load
def test_load():
    str_0 = ''
    str_1 = ''
    var_0 = load(str_0, str_1)
