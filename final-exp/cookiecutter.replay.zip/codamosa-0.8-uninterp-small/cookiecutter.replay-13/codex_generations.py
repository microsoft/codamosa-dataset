

# Generated at 2022-06-25 15:33:00.805552
# Unit test for function dump
def test_dump():
    assert dump('/tmp/cookiecutter-replay', 'test', {'cookiecutter': {}}) == None
    assert dump(None, 'test', {'cookiecutter': {}}) == None
    assert dump('/tmp/cookiecutter-replay', None, {'cookiecutter': {}}) == None
    assert dump('/tmp/cookiecutter-replay', 'test', None) == None

# Generated at 2022-06-25 15:33:12.081719
# Unit test for function dump
def test_dump():
    dict_0 = dict()
    dict_0['cookiecutter'] = dict()
    str_0 = 'E\x0c'
    str_1 = '~Xpz:cq3?f5_I'
    dict_0['cookiecutter']['_template'] = str_1
    dict_0['cookiecutter']['full_name'] = str_1
    dict_0['cookiecutter']['email'] = str_1
    dict_0['cookiecutter']['open_source_license'] = str_1
    dict_0['cookiecutter']['project_name'] = str_1
    dict_0['cookiecutter']['project_slug'] = str_1
    dict_0['cookiecutter']['project_short_description'] = str_1
    dict

# Generated at 2022-06-25 15:33:13.780513
# Unit test for function load
def test_load():
    replay_dir = 'tests/files/fake-replay-dir/'
    template_name = 'bad-file.json'
    load(replay_dir, template_name)



# Generated at 2022-06-25 15:33:15.744645
# Unit test for function load
def test_load():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 15:33:17.740165
# Unit test for function load
def test_load():
    test_case_0()



# Generated at 2022-06-25 15:33:27.916244
# Unit test for function dump
def test_dump():
    # Test 0
    str_0 = '<e/\x18\x0c\x1a\x1c'
    str_1 = ')oI)'
    str_2 = 'd6'
    str_3 = '.v}1+\x0cD\t'
    str_4 = 'H\x1b\x16\x18\x0cb!\x18cQ\r[\n\x10\x00\x1f\x1a\x0b\x18\x13\x1e'
    str_5 = '\r\x18'
    str_6 = '\\\x1c\x02\x1c\x18'
    str_7 = 'm\x18\x12\x1e\x1c'

# Generated at 2022-06-25 15:33:28.762915
# Unit test for function load
def test_load():
    test_case_0()

# Generated at 2022-06-25 15:33:35.493391
# Unit test for function dump
def test_dump():
    # inputs
    replay_dir = '.'
    template_name = __file__.split('.')[0]
    context = {'cookiecutter': {'test': 'test'}}
    # use function dump
    dump(replay_dir, template_name, context)
    # use function load
    assert load(replay_dir, template_name) == context



# Generated at 2022-06-25 15:33:43.827690
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    from collections import OrderedDict
    from cookiecutter.replay import load

    template_name = 'foobar'
    replay_dir = '.'
    replay_file = get_file_name(replay_dir, template_name)
    replay_data = {
        'cookiecutter': {
            'replay': True,
            'no_input': True,
            'default_context': True,
            'abbreviations': OrderedDict([('full', 'Foo Bar')]),
        }
    }

    # Setup

# Generated at 2022-06-25 15:33:45.903195
# Unit test for function load
def test_load():

    # Test case 0
    test_case_0()


# Generated at 2022-06-25 15:33:50.538056
# Unit test for function load
def test_load():
    var_0 = load(str_0, str_0)
    assert var_0 is not None, 'Unable to load.'


# Generated at 2022-06-25 15:33:58.515611
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-replay-dir/test1.json'
    var_0 = load(str_0, str_0)
    assert var_0 == {'cookiecutter': {'a': 'b'}}

    str_0 = 'tests/files/fake-replay-dir/test2.json'
    var_0 = load(str_0, str_0)
    assert var_0 == {'cookiecutter': {'a': 'b'}}



# Generated at 2022-06-25 15:33:59.683312
# Unit test for function load
def test_load():

    # Call function
    test_case_0()


# Generated at 2022-06-25 15:34:02.877193
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl_y-dir/'
    var_0 = load(str_0, str_0)
    assert type(var_0) == dict


# Generated at 2022-06-25 15:34:05.364048
# Unit test for function load
def test_load():
    print("Testing: load")

    try:
        test_case_0()
    except Exception as e:
        print("FAILED: load")
    else:
        print("SUCCESS: load")


# Generated at 2022-06-25 15:34:06.501406
# Unit test for function load
def test_load():
    print("\n\nRunning tests for load")
    test_case_0()


# Generated at 2022-06-25 15:34:18.332489
# Unit test for function dump
def test_dump():
    str_0 = 'tests/files/fake-replay-dir/'
    str_1 = 'tests/files/fake-replay-dir/test-replay'
    str_2 = 'tests/files/fake-replay-dir/test-replay.json'

# Generated at 2022-06-25 15:34:29.067953
# Unit test for function load
def test_load():
    str_1 = 'tests/files/fake-repl_y-dir/'
    var_1 = load(str_1, str_1)
    str_2 = 'tests/files/fake-repl_y-dir/'
    str_3 = ''
    str_4 = 'tests/files/fake-repl_y-dir/'
    var_2 = load(str_2, str_3)
    assert (var_1 == var_2)
    assert (var_2 == {})


# Generated at 2022-06-25 15:34:38.297884
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl_y-dir/'
    var_0 = load(str_0, str_0)
    str_1 = 'tests/files/fake-repl_y-dir/'
    str_2 = 'tests/files/fake-repl_y-dir/fake_project'
    var_1 = get_file_name(str_1, str_2)
    str_3 = '{"cookiecutter": {"_template": "tests/files/fake-repl_y-dir/"}}'
    var_2 = json.loads(str_3)
    var_3 = dump(str_1, str_2, var_2)
    var_4 = load(str_1, str_2)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 15:34:45.921455
# Unit test for function dump
def test_dump():
    str_0 = 'tests/files/fake-replay-dir/'
    dict_0 = {}
    dict_1 = {'example_key': 'example_value'}
    dict_0['example_key'] = dict_1
    dict_1 = {'example_key': 'example_value'}
    dict_0['example_key'] = dict_1
    dict_1 = {'example_key': 'example_value'}
    dict_0['example_key'] = dict_1
    dict_1 = {'example_key': 'example_value'}
    dict_0['example_key'] = dict_1
    dict_1 = {'example_key': 'example_value'}
    dict_0['example_key'] = dict_1
    dict_0['example_key'] = dict_1

# Generated at 2022-06-25 15:34:54.008400
# Unit test for function dump
def test_dump():
    str_0 = ''
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_

# Generated at 2022-06-25 15:34:56.732970
# Unit test for function dump
def test_dump():
    replay_dir = os.path.join('tests', 'files', 'fake-replay-dir')
    template_name = 'pytest'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy Greenfeld',
            'email': 'audreyr@example.com'
        }
    }
    dump(replay_dir, template_name, context)



# Generated at 2022-06-25 15:34:59.783017
# Unit test for function load
def test_load():
    # Call function load
    result = load(str, str)
    assert result == expected


# Generated at 2022-06-25 15:35:13.802122
# Unit test for function dump
def test_dump():
    str_0 = 'tests/files/fake-repl_y-dir/'

# Generated at 2022-06-25 15:35:17.449019
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl_y-dir/'
    var_0 = load(str_0, str_0)
    


# Generated at 2022-06-25 15:35:18.375725
# Unit test for function load
def test_load():
    pass


# Generated at 2022-06-25 15:35:24.074817
# Unit test for function load
def test_load():
    #default test
    str_1 = 'tests/files/fake-repl_y-dir/'
    var_1 = load(str_1, "")

    # custom test
    str_2 = 'tests/files/fake-repl_y-dir/'
    var_2 = load(str_2, str_2)


# Generated at 2022-06-25 15:35:30.844504
# Unit test for function load
def test_load():
    """Test for the function load."""
    str_0 = 'tests/files/fake-replay-dir/'
    var_0 = load(str_0, str_0)

# Generated at 2022-06-25 15:35:40.686183
# Unit test for function dump
def test_dump():
    str_0 = 'tests/files/fake-repl_y-dir/'
    str_1 = 'tests/files/fake-repl_y-dir/'
    str_2 = 'tests/files/fake-repl_y-dir/'
    str_3 = 'tests/files/fake-repl_y-dir/'
    str_4 = 'tests/files/fake-repl_y-dir/'
    str_5 = 'tests/files/fake-repl_y-dir/'
    str_6 = 'tests/files/fake-repl_y-dir/'
    var_0 = dump(str_0, str_1, {'cookiecutter': {'replay': True}})
    assert var_0 == None

# Generated at 2022-06-25 15:35:43.464602
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-replay-dir/'
    dict_0 = load(str_0, str_0)
    assert True


# Generated at 2022-06-25 15:35:55.292609
# Unit test for function dump
def test_dump():
    str_0 = 'tests/files/test-replay-dir/'
    str_1 = 'tests/files/fake-replay-dir/'
    str_2 = 'tests/files/test-replay-dir/'
    str_3 = 'tests/files/fake-replay-dir/'
    str_4 = 'tests/files/some-other-replay-dir/'
    str_5 = 'tests/files/some-other-replay-dir/'
    str_6 = 'tests/files/some-other-replay-dir/'
    str_7 = 'tests/files/fake-replay-dir/'
    str_8 = 'tests/files/some-other-replay-dir/'
    str_9 = 'tests/files/fake-replay-dir/'
   

# Generated at 2022-06-25 15:35:58.594832
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl_y-dir/'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:36:07.385475
# Unit test for function load
def test_load():
    str_0 = 'tests/replay-tests/fake-replay-dir/'
    str_1 = 'tests/replay-tests/fake-replay-dir/repo_name.json'
    str_2 = 'repo_name'
    dict_0 = load(str_0, str_2)
    dict_1 = load(str_0, str_0)
    dict_2 = load(str_1, str_0)
    dict_3 = load(str_2, str_0)
    dict_4 = load(str_1, str_1)


# Generated at 2022-06-25 15:36:15.886341
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl_y-dir/'
    bool_0 = str_0 in str_0
    if bool_0:
        bool_0 = str_0 in str_0
        if bool_0:
            bool_0 = str_0 in str_0
            if bool_0:
                bool_0 = str_0 in str_0
                if bool_0:
                    bool_0 = str_0 in str_0
                    if bool_0:
                        bool_0 = str_0 in str_0
                        if bool_0:
                            bool_0 = str_0 in str_0
                            if bool_0:
                                bool_0 = str_0 in str_0
                                if bool_0:
                                    bool_0 = str_0 in str_0
                

# Generated at 2022-06-25 15:36:16.767007
# Unit test for function load
def test_load():
    assert True


# Generated at 2022-06-25 15:36:17.592140
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:36:23.159399
# Unit test for function dump
def test_dump():
    def test_case_0():
        str_0 = 'tests/files/fake-replay-dir/'
        var_0 = dump(str_0, str_0, str_0)

    def test_case_1():
        obj_0 = {}
        str_0 = 'tests/files/fake-replay-dir/'
        var_0 = dump(str_0, str_0, obj_0)

    def test_case_2():
        str_0 = 'tests/files/fake-replay-dir/'
        var_0 = dump(str_0, str_0, str_0)

    def test_case_3():
        obj_0 = {}
        str_0 = 'tests/files/fake-replay-dir/'

# Generated at 2022-06-25 15:36:32.289445
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl_y-dir/'
    str_1 = 'tests/files/fake-context.json'
    dict_0 = {'cookiecutter': {'full_name': 'Simon Cross'}}
    with open(str_1, 'r') as var_1:
        var_0 = json.load(var_1)
        print(var_0)
    assert len(var_0) == 1
    assert len(var_0['cookiecutter']) == 1
    assert var_0 == dict_0
    assert load(str_0, str_0) == dict_0


# Generated at 2022-06-25 15:36:35.669163
# Unit test for function load
def test_load():
    str_0 = 'tests/f//iles/fake-repl_y-dir/'
    var_1 = load(str_0, str_0)


# Generated at 2022-06-25 15:36:37.406043
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-replay-dir/'
    assert load(str_0, str_0)



# Generated at 2022-06-25 15:36:50.708201
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl/'
    var_0 = load(str_0, 'just_a_test')

# Generated at 2022-06-25 15:36:54.136912
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl_y-dir/'
    var_0 = load(str_0, str_0)
    # Ensure that var_0 has the right value
    assert var_0 == 'tests/files/fake-repl_y-dir/tests/files/fake-repl_y-dir.json'



# Generated at 2022-06-25 15:37:01.513203
# Unit test for function load
def test_load():
    print("test_load")

    template_name = 'fake-template'
    replay_dir = 'tests/files/fake-replay-dir'
    context = {
        "cookiecutter": {
            "full_name": "Your Name",
            "email": "Your email goes here",
            "project_name": "Example Project",
            "project_slug": "example_project",
        },
    }
    dump(replay_dir, template_name, context)
    context2 = load(replay_dir, template_name)
    assert context == context2


if __name__ == "__main__":
    test_case_0()

    test_load()

# Generated at 2022-06-25 15:37:03.639788
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except Exception:
        import traceback
        traceback.print_exc()


# Generated at 2022-06-25 15:37:10.920844
# Unit test for function dump
def test_dump():
    """Test dump()."""
    # Dump context as a file
    replay_dir = 'tests/files/fake-replay-dir/'
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr'
        }
    }
    template = 'fake-project'
    dump(replay_dir, template, context)

    # Check that file exists
    replay_file = get_file_name(replay_dir, template)
    assert os.path.exists(replay_file)

    # Check that file content is correct
    with open(replay_file, 'r') as infile:
        written_context = json.load(infile)

    assert written_

# Generated at 2022-06-25 15:37:15.563240
# Unit test for function dump
def test_dump():
    str_0 = 'tests/files/test-replay-dir/'
    str_1 = str_0
    dict_0 = var_0
    dump(str_1, str_1, dict_0)


# Generated at 2022-06-25 15:37:23.399084
# Unit test for function dump
def test_dump():
    str_0 = 'tests/files/fake-replay-dir/'
    dict_0 = {'cookiecutter': {'full_name': 'Your Name', 'email': 'your@email.com', 'github_username': 'your-username', 'project_name': 'your-project-name', 'project_license': 'MIT', 'replay': "{{cookiecutter.replay}}", 'replay_dir': '{{cookiecutter.replay_dir}}'}}
    dump(str_0, dict_0, dict_0)


# Generated at 2022-06-25 15:37:28.995207
# Unit test for function load
def test_load():
    replay_dir = "tests/files/fake-replay-dir/"
    expected_output = {'cookiecutter':{'full_name': 'Firstname Lastname', 'email': 'me@mydomain.com', 'github_username': 'myusername'}}
    actual_output = load(replay_dir, 'fake-repo')

    assert expected_output == actual_output

# Generated at 2022-06-25 15:37:38.611867
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl_y-dir/'
    dict_0 = load(str_0, str_0)
    var_0 = dict_0.get('_workspace')
    assertNotIn('mjr',var_0)
    assertIn('cookiecutter',dict_0)
    assertNotIn('jb_t_s',dict_0)
    assertNotIn('doctest',dict_0)
    assertNotIn('<function context at 0xaa8f6c80>',dict_0)
    assertNotIn('asdfasdf',dict_0)

# Generated at 2022-06-25 15:37:47.042138
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-replay-dir/'
    str_1 = 'tests/files/fake-replay-dir/'
    dict_0 = {'hello': 'world'}
    dict_1 = {'hello': 'world'}
    dict_2 = {'hello': 'world'}
    var_0 = dump(str_0, str_1, dict_0)
    var_1 = load(str_0, str_1)
    assert dict_2 == var_1


# Generated at 2022-06-25 15:37:58.308460
# Unit test for function load
def test_load():
    # Arguments used in test case
    str_0 = 'tests/files/fake-repl_y-dir/'
    str_1 = 'tests/files/fake-repl_y-dir/fake-repl_y-file.json'
    # Return value used in test case
    dict_0 = dict()
    dict_0['cookiecutter'] = dict()
    dict_0['cookiecutter']['name'] = ''
    dict_0['cookiecutter']['version'] = ''
    # Pass line number used in test case
    passline = 17

    # Arrange the data
    os.makedirs(str_0)
    dict_1 = dict()
    dict_1['cookiecutter'] = dict()
    dict_1['cookiecutter']['name'] = ''

# Generated at 2022-06-25 15:37:59.764498
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl_y-dir/'
    var_0 = load(str_0, str_0)

    assert var_0 == {'cookiecutter': {'foo': 'ok', 'bar': 5}}

# Generated at 2022-06-25 15:38:07.983662
# Unit test for function load
def test_load():
    template_name = 'tests/files/fake-replay-dir/'
    replay_dir = 'tests/files/fake-replay-dir/'
    expected = {"cookiecutter": {"audit_version": "1.0.0", "project_name": "Some project", "project_slug": "some_project", "author_name": "Your Name", "email": "you@example.com", "description": "A short description of the project.", "domain_name": "example.com", "version": "0.1.0", "timezone": "UTC"}}
    actual = load(replay_dir, template_name)
    assert expected == actual


# Generated at 2022-06-25 15:38:13.290988
# Unit test for function load
def test_load():
    template_name = 'hi'
    assert get_file_name('.', template_name) == './hi.json'
    assert get_file_name('.', template_name + '.json') == './hi.json.json'

# Generated at 2022-06-25 15:38:19.166305
# Unit test for function dump
def test_dump():
    # Setup variables for test
    template_name = 'cookiecutter.json'
    context = {'cookiecutter': {'project_name': 'project name'}}
    replay_dir = '/Users/audreyr/cookiecutter'
    expected_result = os.path.join(replay_dir, template_name)

    # Call method under test
    result = dump(replay_dir, template_name, context)

    # Verify result
    assert result == expected_result



# Generated at 2022-06-25 15:38:25.701030
# Unit test for function dump
def test_dump():
    DIR_0 = 'tests/files/fake-replay-dir/'
    str_0 = 'tests/files/fake-replay-dir/'
    # replay_dir = '.'
    dict_0 = {'cookiecutter': '1' * 5}
    dump(DIR_0, str_0, dict_0)
    var_0 = load(DIR_0, str_0)
    assert var_0 == dict_0


# Generated at 2022-06-25 15:38:31.321526
# Unit test for function load
def test_load():
    # test with non existing directory

    str_0 = 'tests/files/fake-replay-dir/'
    try:
        load(str_0, str_0)
    except IOError:
        pass


# Generated at 2022-06-25 15:38:34.828947
# Unit test for function load
def test_load():
    # Call to load
    str_0 = os.path.join('tests', 'files', 'fake-replay-dir')
    context = load(str_0, str_0)
    assert isinstance(context, dict)



# Generated at 2022-06-25 15:38:40.861830
# Unit test for function load
def test_load():
    root_path = os.path.dirname(os.path.abspath(__file__))
    replay_dir = os.path.join(root_path, 'files', 'fake-replay-dir')
    template_name = 'fake-repo-tmpl'

    expected_context = {
        'cookiecutter': {
            'fake_key': 'fake-value',
            'repo_dir': '.',
            'username': 'audreyr',
            'github_username': 'audreyr'
        },
    }

    context = load(replay_dir, template_name)
    assert context == expected_context



# Generated at 2022-06-25 15:38:44.057726
# Unit test for function load
def test_load():
    with pytest.raises(TypeError):
        str_0 = 'tests/files/fake-repl_y-dir/'
        var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:38:59.963436
# Unit test for function dump
def test_dump():
    template_name = 'tests/files/fake-ori-dir/fake-repo/'
    context = {'cookiecutter': {'full_name': 'JanWerkhoven', 'email': 'janw@usv.com'}}
    dump('./tests/files/fake-repl_y-dir/', template_name, context)



# Generated at 2022-06-25 15:39:09.608475
# Unit test for function load
def test_load():
    print('test load')
    str_0 = 'tests/files/fake-repl_y-dir/'
    var_0 = load(str_0, str_0)
    var_1 = load(str_0, str_0)
    assert var_0 == var_1
    var_2 = load(str_0, str_0)
    assert var_0 == var_2
    var_3 = load(str_0, str_0)
    assert var_0 == var_3
    var_4 = load(str_0, str_0)
    assert var_0 == var_4
    var_5 = load(str_0, str_0)
    assert var_0 == var_5
    var_6 = load(str_0, str_0)
    assert var_0 == var_6


# Generated at 2022-06-25 15:39:11.650207
# Unit test for function load
def test_load():
    str_1 = 'tests/files/fake-repl_y-dir/'
    var_1 = load(str_1, str_1)

# Generated at 2022-06-25 15:39:20.456317
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl_y-dir/'
    str_1 = 'tests/files/fake-repl_y-dir/'
    str_2 = 'tests/files/fake-repl_y-dir/'
    str_3 = 'tests/files/fake-repl_y-dir/'
    str_4 = 'tests/files/fake-repl_y-dir/'
    str_5 = 'tests/files/fake-repl_y-dir/'
    str_6 = 'tests/files/fake-repl_y-dir/'
    str_7 = 'tests/files/fake-repl_y-dir/'
    str_8 = 'tests/files/fake-repl_y-dir/'
    str_9 = 'tests/files/fake-repl_y-dir/'

# Generated at 2022-06-25 15:39:30.705686
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-replay-dir/pyproject.toml.json'
    var_0 = load('tests/files/fake-replay-dir/', str_0)

# Generated at 2022-06-25 15:39:39.350126
# Unit test for function load
def test_load():
    # Test for raising IOError: replayfile does not exist
    str_0 = 'tests/files/fake-repl_y-dir/'
    var_0 = load(str_0, str_0)
    # Test for raising TypeError: template_name is required to be of type str
    str_1 = 'tests/files/fake-repl_y-dir/fake-replay-file'
    var_1 = load(str_0, str_1)
    # Test for raising ValueError: context is required to contain a cookiecutter key
    str_2 = 'tests/files/fake-replay-dir/fake-replay-file'
    var_2 = load(str_0, str_2)


# Generated at 2022-06-25 15:39:42.682529
# Unit test for function dump
def test_dump():
    str_0 = 'tests/files/fake-repl_y-dir/'
    dict_0 = {'cookiecutter': {'name': 'Learn cookiecutter'}}
    dump(str_0, str_0, dict_0)


# Generated at 2022-06-25 15:39:43.740843
# Unit test for function load
def test_load():
    assert load('same', 'same') == load('same', 'same')


# Generated at 2022-06-25 15:39:48.387381
# Unit test for function load
def test_load():
    var_0 = 'tests/files/fake-repl_y-dir/'
    var_1 = 'tests/files/fake-repl_y-dir/'
    var_2 = load(var_0, var_1)

# Generated at 2022-06-25 15:39:52.783513
# Unit test for function load
def test_load():
    assert load('tests/files/fake-replay-dir/', 'tests/files/fake-replay-dir/') == {'cookiecutter': {'full_name': 'Audrey Roy', 'email': 'audreyr@example.com', 'github_username': 'audreyr'}}


# Generated at 2022-06-25 15:40:25.110863
# Unit test for function dump
def test_dump():
    # Path where replay context files will be written to.
    replay_dir = 'tests/files/fake-replay-dir'

    # Name of template that was used to generate files.
    template_name = 'tests/fake-repo-pre/'

    # The context used while generating the files.

# Generated at 2022-06-25 15:40:25.996408
# Unit test for function load
def test_load():
    assert callable(load)

# Generated at 2022-06-25 15:40:29.173900
# Unit test for function dump
def test_dump():
    str_0 = 'tests/files/fake-repl_y-dir/'
    dict_0 = {str_0:str_0,str_0:str_0}
    dump(str_0, str_0, dict_0)


# Generated at 2022-06-25 15:40:31.952208
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl_y-dir/'
    var_0 = load(str_0, str_0)
    assert var_0['cookiecutter']['full_name'] == 'Gob Bluth'


# Generated at 2022-06-25 15:40:39.915875
# Unit test for function load
def test_load():
    try:
        str_0 = 'tests/files/fake-repl_y-dir/'
        var_0 = load(str_0, str_0)
        assert False
    except ValueError as e:
        assert True
    except Exception:
        assert False
    except TypeError as e:
        assert False
    try:
        str_0 = 'tests/files/fake-repl_y-dir/'
        str_1 = 'tests/files/fake-re$ply-dir/'
        var_0 = load(str_0, str_1)
        assert False
    except ValueError as e:
        assert True
    except Exception:
        assert False
    except TypeError as e:
        assert False

# Generated at 2022-06-25 15:40:44.868113
# Unit test for function load
def test_load():
    str_0 = 'tests/file_helper/fake-replay-dir'
    dict_0 = {'cookiecutter': {}}
    dump(str_0, str_0, dict_0)
    var_0 = load(str_0, str_0)
    assert dict_0 == var_0

# Generated at 2022-06-25 15:40:46.142056
# Unit test for function load
def test_load():
    # No error should occur during the execution of this test
    test_case_0()

# Generated at 2022-06-25 15:40:54.007622
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake_replay_dir/'
    dict_0 = load(str_0, str_0)

# Generated at 2022-06-25 15:41:00.473970
# Unit test for function load
def test_load():

    str_0 = 'tests/files/fake-replay-dir/'
    dict_0 = {'cookiecutter': {'full_name': 'Santa Claus', 'email': 'me@my.com', 'gh_username': 'me'}}
    dump(str_0, str_0, dict_0)
    bool_1 = os.path.exists(str_0)
    assert bool_1

    # Check to see if we can load what we dumped
    dict_1 = load(str_0, str_0)

    # Check to see if we can load the output of what was dumped
    dict_2 = load(str_0, str_0)
    bool_0 = dict_2 == dict_0
    assert bool_0

    # Check to see if we can load the output of what was dumped
    dict_3

# Generated at 2022-06-25 15:41:04.074170
# Unit test for function load
def test_load():
    assert callable(load), 'Failed to find function load'
    try:
        load('./tests/files/fake-replay-dir/', './tests/files/fake-replay-dir/')
        pass
    except:
        assert False, 'Failed when running function load'

# Generated at 2022-06-25 15:42:03.723154
# Unit test for function dump
def test_dump():
    str_0 = 'tests/files/test-template/'
    str_1 = 'fake-replay-dir'
    str_2 = 'fake-template-name'
    var_0 = {'cookiecutter': {'hello': 'world'}}
    var_1 = dump(str_0, str_1, str_2)


# Generated at 2022-06-25 15:42:11.854696
# Unit test for function load
def test_load():
    # 1
    str_0 = 'tests/files/fake-replay-dir/'
    var_0 = load(str_0, str_0)

    res_0 = {
        'cookiecutter': {
            'project_name': 'Baked Beans',
            'command_line_interface': 'Click',
            'open_source_license': 'BSD license'
        }
    }
    assert var_0 == res_0

# Generated at 2022-06-25 15:42:13.130593
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:42:21.500803
# Unit test for function load
def test_load():
    try:
        load(None, None)
    except TypeError as e:
        assert str(e) == 'Template name is required to be of type str' 
    else:
        raise Exception('Unreachable')
    try:
        load('tests/files/fake-replay-dir/', 'tests/files/fake-replay-dir/')
    except ValueError as e:
        assert str(e) == 'Context is required to contain a cookiecutter key' 
    else:
        raise Exception('Unreachable')
    try:
        str_0 = 'tests/files/fake-replay-dir/'
        load(str_0, str_0)
    except Exception as e:
        raise Exception('Unreachable')



# Generated at 2022-06-25 15:42:26.129049
# Unit test for function load
def test_load():
    dump_context = {'key': 'value'}
    dump_dir = 'tests/files/fake-replay-dir'
    dump_template = 'fake-replay-dir'
    replay_file = 'tests/files/fake-replay-dir/fake-replay-dir.json'

    try:
        dump(dump_dir, dump_template, dump_context)
        with open(replay_file, 'r') as infile:
            loaded_context = json.load(infile)
    finally:
        os.remove(replay_file)

    assert loaded_context == dump_context


# Generated at 2022-06-25 15:42:28.471576
# Unit test for function load
def test_load():
    str_0 = 'tests/files/fake-repl_y-dir/'
    var_0 = load(str_0, str_0)



# Generated at 2022-06-25 15:42:30.318468
# Unit test for function load
def test_load():
    assert callable(load)
    try:
        load('', '')
    except TypeError as e:
        assert True


# Generated at 2022-06-25 15:42:33.035433
# Unit test for function load
def test_load():
    dct_0 = {}
    str_0 = 'cookiecutter/tests/files/fake-replay-dir/'
    var_1 = load(str_0, str_0)
    assert var_1 is not dct_0


# Generated at 2022-06-25 15:42:36.538048
# Unit test for function load
def test_load():
    # unittest.expect(call(str, str), raises=ValueError)
    str_0 = get_file_name('tests/files/fake-repl_y-dir', 'tests/files/fake-repl_y-dir/')
    unittest.expect(
        call(str_0, str_0),
        raises=ValueError
    )


# Generated at 2022-06-25 15:42:42.934552
# Unit test for function load
def test_load():
    # Test function with simple input
    str_0 = 'tests/files/fake-repl_y-dir/'
    var_0 = load(str_0, str_0)
    # Test function with complex input
    str_0 = 'tests/files/fake-repl_y-dir/'
    var_0 = load(str_0, str_0)

