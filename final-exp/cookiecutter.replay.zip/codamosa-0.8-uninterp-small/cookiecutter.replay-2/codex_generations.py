

# Generated at 2022-06-25 15:33:03.672717
# Unit test for function load
def test_load():
    dict_0 = {
        '_replay_dir': '.',
        'template': 'foo/bar'
        }
    dict_1 = {
        'cookiecutter': {
            '_template': 'foo/bar',
            'name': 'Joe'
            }
        }
    filename = os.path.join(dict_0['_replay_dir'], '{}.json'.format(dict_0['template']))
    with open(filename, 'w') as f:
        json.dump(dict_1, f)

    dict_2 = load(dict_0['_replay_dir'], dict_0['template'])
    try:
        assert dict_1 == dict_2
    finally:
        os.unlink(filename)


# Generated at 2022-06-25 15:33:07.182067
# Unit test for function load
def test_load():
    input_0 = {}
    input_1 = {}
    output = load(input_0, input_1)
    assert output == {}


# Generated at 2022-06-25 15:33:18.408438
# Unit test for function load
def test_load():
    replay_dir = 'examples/test-cookiecutter/'
    template_name = 'test-cookiecutter'

# Generated at 2022-06-25 15:33:24.216578
# Unit test for function dump
def test_dump():
    replay_dir = 'replay'
    template_name = 'test'
    context = {'cookiecutter': {'key': 'value'}}
    var_1 = dump(replay_dir, template_name, context)
    print(var_1)
    var_2 = load(replay_dir, template_name)
    print(var_2)
    assert var_2 == context


# Generated at 2022-06-25 15:33:30.442181
# Unit test for function load
def test_load():
    # Setup
    replay_dir = 'tests/test-cases/test-case-0/replay'
    template_name = 'test-case-0'

    # Exercise
    data_from_load = load(replay_dir, template_name)

    # Verify
    assert data_from_load is not None
    assert isinstance(data_from_load, dict)
    assert 'cookiecutter' in data_from_load
    assert data_from_load['cookiecutter'] is not None
    assert isinstance(data_from_load['cookiecutter'], dict)



# Generated at 2022-06-25 15:33:36.186806
# Unit test for function load
def test_load():
    dict_0 = None
    dict_1 = dict_0
    dict_2 = dict_1
    dict_3 = dict_2
    dict_4 = dict_3
    dict_5 = dict_4
    dict_6 = dict_5
    dict_7 = dict_6
    dict_8 = dict_7
    dict_9 = dict_8
    dict_10 = dict_9
    dict_11 = dict_10
    dict_12 = dict_11
    dict_13 = dict_12
    dict_14 = dict_13
    dict_15 = dict_14
    dict_16 = dict_15
    dict_17 = dict_16
    dict_18 = dict_17
    dict_19 = dict_18
    dict_20 = dict_19
    dict_21 = dict_20
    dict_

# Generated at 2022-06-25 15:33:38.450537
# Unit test for function get_file_name
def test_get_file_name():
    file_name = get_file_name("replay", 'template_name')
    assert file_name == "replay/template_name.json"



# Generated at 2022-06-25 15:33:44.581959
# Unit test for function load
def test_load():
    # Variables
    replay_dir = 'tests/files/replay/'
    template_name = 'bacon'

    # Function call
    result = load(replay_dir, template_name)

    # Verify
    assert result == {'cookiecutter': {
        'full_name': 'Ian Cordasco', 'email': 'foo@example.com',
        'github_username': 'sigmavirus24', 'project_name': 'Bacon',
        'project_slug': 'bacon', 'project_short_description': 'Bacon bacon bacon'}
    }


# Generated at 2022-06-25 15:33:48.304299
# Unit test for function dump
def test_dump():
    template_name = 'template_name'
    replay_dir = 'replay_dir'
    context = {'cookiecutter': {}}
    try:
        dump(replay_dir, template_name, context)
    except Exception as e:
        print('Exception:', e)



# Generated at 2022-06-25 15:33:53.083606
# Unit test for function load
def test_load():
    dict_0 = {
        'cookiecutter': {
            '_template': '.',
            'full_name': 'Test User',
            'email': 'test@example.com',
            'project_name': 'projectname',
        }
    }
    assert load('.', '.') == dict_0


# Generated at 2022-06-25 15:33:58.053730
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except(TypeError, ValueError):
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:34:02.263618
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "test_dir"
    template_name = "test_file"
    
    file_name = get_file_name(replay_dir, template_name)
    assert(file_name == os.path.join(replay_dir, template_name + ".json"))


# Generated at 2022-06-25 15:34:03.130177
# Unit test for function load
def test_load():
    print('Testing function load')

# Generated at 2022-06-25 15:34:05.860526
# Unit test for function load
def test_load():
    error = None
    try:
        test_case_0()
    except Exception as _:
        error = str(_)
    assert error == 'Template name is required to be of type str'



# Generated at 2022-06-25 15:34:10.115322
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = "C:\\Users\\kraisorn\\Documents\\Cookiecutter\\cookiecutter-pypackage-minimal"
    template_name = "C:\\Users\\kraisorn\\Documents\\Cookiecutter\\cookiecutter-pypackage-minimal\\cookiecutter.json"
    var_0 = get_file_name(replay_dir, template_name)
    assert var_0 is not None


# Generated at 2022-06-25 15:34:16.977591
# Unit test for function get_file_name
def test_get_file_name():
    # Define some parameters for test
    replay_dir = 'C:\cookiecutter'
    template_name = 'cookiecutter-pypackage'
    # Call the function we are testing with the above parameters
    result_0 = get_file_name(replay_dir, template_name)
    # Test the result against the expected output
    assert not result_0 is None
    assert result_0 == 'C:\cookiecutter\\cookiecutter-pypackage.json'


# Generated at 2022-06-25 15:34:21.570344
# Unit test for function load
def test_load():
    replay_dir = "tests/files/test-replay-repo-tmpl/{{cookiecutter.repo_name}}"
    template_name = "tests/files/test-replay-repo-tmpl"
    context = {'cookiecutter': {'repo_name': 'test-repo'}}

    assert load(replay_dir, template_name) == context


# Generated at 2022-06-25 15:34:23.579174
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except:
        print("Testcase 0 failed.")


# Generated at 2022-06-25 15:34:26.691611
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name("./cookiecutter/tests/test-replay/", "test") == "./cookiecutter/tests/test-replay/test.json"


# Generated at 2022-06-25 15:34:27.501078
# Unit test for function load
def test_load():
    print(test_case_0())



# Generated at 2022-06-25 15:34:29.886933
# Unit test for function dump
def test_dump():
    res = dump()
    assert res == None, "Test Case 0 Failed"


# Generated at 2022-06-25 15:34:39.870967
# Unit test for function dump
def test_dump():
    var_0 = None
    var_1 = None
    var_2 = None
    var_0 = os.path.join('.cookiecutters', 'test_template')
    var_1 = 'test_template'
    var_2 = {
        'cookiecutter': {
            '_copy_without_render': [
                'test_dir',
            ],
            'test_dir': 'test_dir',
            'test_file_basename': 'test_file_basename',
            'test_file_extension': 'test_file_extension',
            'test_file_name': '{{ test_file_basename }}.{{ test_file_extension }}',
            'test_var': 'test_var',
        }
    }
    dump(var_0, var_1, var_2)

# Generated at 2022-06-25 15:34:41.682263
# Unit test for function load
def test_load():
    solutions_0 = None
    output_0 = load(var_0)
    assert output_0 == solutions_0


# Generated at 2022-06-25 15:34:42.489208
# Unit test for function load
def test_load():
    assert(load() != None)


# Generated at 2022-06-25 15:34:45.857831
# Unit test for function dump
def test_dump():
    input_0 = None
    input_1 = None
    input_2 = None
    expected_result = None
    result = dump(input_0, input_1, input_2)
    assert result == expected_result


# Generated at 2022-06-25 15:34:51.695517
# Unit test for function dump
def test_dump():
    replay_dir = 'replay_dir_arg'
    template_name = 'template_name_arg'
    context = 'context_arg'
    expected = "OK"
    actual = None
    try:
        dump(replay_dir, template_name, context)
        actual = "OK"
    except Exception as e:
        actual = repr(e)

    msg = "dump(replay_dir, template_name, context) expected {}, got {}".format(expected, actual)
    print(msg)
    assert expected == actual, msg



# Generated at 2022-06-25 15:34:54.711145
# Unit test for function load
def test_load():
    replay_dir = '.'
    template_name = '.'
    assert load(replay_dir, template_name) is not None


# Generated at 2022-06-25 15:34:58.028272
# Unit test for function load
def test_load():
    # Define arguments and results
    replay_dir = '.'
    template_name = '.'

    # Execute the tested function
    result = load(replay_dir, template_name)

    # Verify the results
    assert (result is None)


# Generated at 2022-06-25 15:35:00.783369
# Unit test for function load
def test_load():
    replay_dir = None
    template_name = None
    test_case_0()


# Generated at 2022-06-25 15:35:09.606233
# Unit test for function dump
def test_dump():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    replay_dir = os.path.join(dir_path, "test")
    template_name = "test"
    context = {"cookiecutter": {"test": None}}
    assert dump(replay_dir, template_name, context)


# Generated at 2022-06-25 15:35:13.600120
# Unit test for function load
def test_load():
    replay_dir = 'uV'
    template_name = 'ep'

    try:
        json = load(replay_dir, template_name)
    except:
        json = None
    return json


# Generated at 2022-06-25 15:35:17.190678
# Unit test for function dump
def test_dump():
    var_0 = dump({'test': 1}, {'test': 1}, {'test': 1})
    assert var_0 == None


# Generated at 2022-06-25 15:35:20.208413
# Unit test for function load
def test_load():
    template_name = None
    replay_dir = None
    try:
        load(replay_dir, template_name)
    except TypeError as e:
        print('Unable to run load. Exception: {}'.format(e))


# Generated at 2022-06-25 15:35:22.694970
# Unit test for function load
def test_load():
    assert True


# Generated at 2022-06-25 15:35:24.997169
# Unit test for function dump
def test_dump():
    assert dump('replay_dir', 'template_name', {'cookiecutter': 'repo_name'}) == None


# Generated at 2022-06-25 15:35:27.415877
# Unit test for function load
def test_load():
    template_name = 'a'
    replay_dir = '/home/yunhan/workspace/gitlab/demo/ccdemo/replay_dir'
    load(replay_dir, template_name)

# Generated at 2022-06-25 15:35:39.670931
# Unit test for function load
def test_load():
    assert callable(load)
    dump(replay_dir='replay', template_name='test_replay', context={'cookiecutter': {}})
    assert load(replay_dir='replay', template_name='test_replay') == {'cookiecutter': {}}
    assert load(replay_dir='replay', template_name='test_replay') != {'cookiecutter': {'b': 0}}
    assert load(replay_dir='replay', template_name='test_replay') != {'cookiecutter': {'b': 1}}
    assert load(replay_dir='replay', template_name='test_replay') == {'cookiecutter': {'a': 1}}

# Generated at 2022-06-25 15:35:49.339009
# Unit test for function dump
def test_dump():
    replay_dir = './tests/files/replay/'
    template_name = 'hello-world-{{cookiecutter.repo_name}}'
    context = {'cookiecutter': {'repo_name': 'HOLA'}}
    try :
        dump(replay_dir, template_name, context)
    except Exception as e:
        print('Arguments used are as follows:')
        print('replay_dir = {}'.format(replay_dir))
        print('template_name = {}'.format(template_name))
        print('context = {}'.format(context))
        print('exception raised is: ', e)
        assert False


# Generated at 2022-06-25 15:35:52.688826
# Unit test for function load
def test_load():
    assert True


# Generated at 2022-06-25 15:35:57.626613
# Unit test for function load
def test_load():
    var_0 = 'template_name'
    var_1 = 'replay_dir'
    try:
        return load(var_1, var_0)
    except ValueError as e:
        pass


# Generated at 2022-06-25 15:36:05.924769
# Unit test for function load
def test_load():
    str_0 = 'tets/files/replay/'
    var_0 = load(str_0, str_0)
    assert var_0['cookiecutter']['full_name'] == 'Audrey Roy'
    assert var_0['cookiecutter']['email'] == 'audreyr@gmail.com'
    assert var_0['cookiecutter']['github_username'] == 'audreyr'



# Generated at 2022-06-25 15:36:06.828788
# Unit test for function dump
def test_dump():
    assert '1' == '1'


# Generated at 2022-06-25 15:36:08.419354
# Unit test for function load
def test_load():
    x = load()
    print(x)
    assert x == 'test'


# Generated at 2022-06-25 15:36:12.051823
# Unit test for function dump
def test_dump():
    try:
        str_0 = 'tests/files/replay/'
        dict_0 = {}
        dict_0['cookiecutter'] = str_0
        dump(str_0, 'test_dump', dict_0)
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 15:36:14.853562
# Unit test for function load
def test_load():
    global v_arg_0
    global v_arg_1
    test_case_0()


# Generated at 2022-06-25 15:36:16.924119
# Unit test for function load
def test_load():
    str_0 = 'tets/files/replay/'
    var_0 = load(str_0, str_0)
    

# Generated at 2022-06-25 15:36:21.991120
# Unit test for function load
def test_load():
    # Test for case when replay_dir is not of type string
    str_0 = 'tets/files/replay/'
    str_1 = 'tets/files/replay/tets_0'
    dict_0 = {'cookiecutter': {'cookiecutter.tests': True, 'test_cookiecutter_config_file': True, 'test_variable_in_config': 'Test variable in config'}}
    dump(str_0, 'tets_0', dict_0)
    try:
        load(dict_0, str_1)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 15:36:28.194072
# Unit test for function dump
def test_dump():
    str_0 = 'dir_0'
    str_1 = 'dir_1'
    var_0 = get_file_name(str_0, str_1)

    dict_0 = {'cookiecutter': {'cake': 'lie'}}
    dump(str_0, str_1, dict_0)

    dict_1 = load(str_0, str_1)

    assert dict_0 == dict_1


# Generated at 2022-06-25 15:36:30.321283
# Unit test for function load
def test_load():
    assert load('replay_dir', 'template_name')



# Generated at 2022-06-25 15:36:31.037521
# Unit test for function dump
def test_dump():
    # TODO: need to find a way to unit test this
    pass



# Generated at 2022-06-25 15:36:36.203220
# Unit test for function load
def test_load():
    str_0 = 'tets/files/replay/'
    var_0 = load(str_0, str_0)

# Generated at 2022-06-25 15:36:38.672057
# Unit test for function load
def test_load():
    str_0 = 'tets/files/replay/'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:36:46.078905
# Unit test for function load
def test_load():
    str_0 = 'tests/files/replay/'
    str_1 = 'tests/files/replay/'
    dict_0 = {
        'cookiecutter': {
            'description': 'This is a test',
            'github_user': 'audreyr',
            'license': 'MIT',
            'name': 'Pytest',
            'project_name': 'pytest'
        }
    }
    dict_1 = load(str_0, str_1)
    assert dict_0 == dict_1


# Generated at 2022-06-25 15:36:54.889597
# Unit test for function load
def test_load():
    str_0 = 'tets/files/replay/'
    var_0 = load(str_0, str_0)
    str_1 = 'test/files/replay/'
    var_1 = load(str_1, str_1)
    if (( var_0 != None ) & ( var_1 == str_1 )):
        var_2 = test_case_0()
    return ((str_0, str_1, var_0, var_1, var_2))

# Test case for function test_load

# Generated at 2022-06-25 15:36:55.920007
# Unit test for function load
def test_load():
    test_case_0()

# Generated at 2022-06-25 15:37:03.103990
# Unit test for function dump
def test_dump():
    var_0 = {
        'cookiecutter': {
            'full_name': 'Henrique Bastos'
        }
    }

    assert dump('tests/files/replay/', 'test_dump', var_0) is None


# Generated at 2022-06-25 15:37:06.378381
# Unit test for function load
def test_load():
    str_1 = 'test/files/replay/'
    var_2 = load(str_1, str_1)


# Generated at 2022-06-25 15:37:09.503307
# Unit test for function dump
def test_dump():
    # TODO: Implement unit test
    assert True


# Generated at 2022-06-25 15:37:19.191199
# Unit test for function load
def test_load():
    replay_dir = os.path.join('tets/files/replay')
    template_name = 'replay'

# Generated at 2022-06-25 15:37:20.962100
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:37:32.586309
# Unit test for function load
def test_load():
    template_name = 'foobar'
    replay_dir = 'tests/files/replay/'
    assert not os.path.exists(get_file_name(replay_dir, template_name))

    # Write the replay file first
    context = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'github_username': 'audreyr',
            'project_name': 'cookiecutter-pypackage',
            'replay': template_name
        }
    }
    dump(replay_dir, template_name, context)
    assert os.path.exists(get_file_name(replay_dir, template_name))

    loaded_context = load(replay_dir, template_name)


# Generated at 2022-06-25 15:37:34.527605
# Unit test for function load
def test_load():
    print('test_load')
    test_case_0()


# Generated at 2022-06-25 15:37:41.002876
# Unit test for function load
def test_load():
    str_0 = 'test/files/replay_file_0.json'

    var_0 = load('test', str_0)
    assert(isinstance(var_0, dict))
    assert('cookiecutter' in var_0)
    assert(var_0 == {'cookiecutter': {'full_name': 'Audrey Roy Greenfeld', 'email': 'audreyr@example.com', 'github_username': 'audreyr', 'project_name': 'Cookiecutter Example Project'}})


# Generated at 2022-06-25 15:37:51.622054
# Unit test for function load
def test_load():
    # example from docs
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/replay/audreyr.json'


# Generated at 2022-06-25 15:37:52.749332
# Unit test for function load
def test_load():
    assert callable(load)
    test_case_0()



# Generated at 2022-06-25 15:37:58.679465
# Unit test for function load
def test_load():

    # Set up test values

    replay_dir = 'fixtures/test-replay/'
    template_name = 'simple-replay'
    context = {
        'cookiecutter': {
            'full_name': 'Test User',
            'email': 'test@example.com',
            'replay': True,
        }
    }

    # Run function

    dump(replay_dir, template_name, context)
    context_response = load(replay_dir, template_name)

    # Verify the results

    assert context.get('cookiecutter') == context_response.get('cookiecutter')

    # Tear down - remove replay file after function is run

    os.remove(get_file_name(replay_dir, template_name))

# Generated at 2022-06-25 15:38:08.278806
# Unit test for function load
def test_load():
    print('Testing load')

    # Setup
    from os import path
    from os import remove
    from cookiecutter.replay import dump

    replay_path = path.join(
        path.dirname(path.abspath(__file__)),
        'files', 'replay'
    )
    template_name = 'empty_repo'
    replay_file = get_file_name(replay_path, template_name)
    context = {'cookiecutter': {'test_key': 'test_val'}}
    dump(replay_path, template_name, context)

    # Test
    context_returned = load(replay_path, template_name)

    # Teardown
    remove(replay_file)

    # Test that context_returned is the same as the context we started with
   

# Generated at 2022-06-25 15:38:17.160803
# Unit test for function load
def test_load():
    str_0 = 'tets/files/replay/'
    dict_0 = load(str_0, str_0)

# Generated at 2022-06-25 15:38:18.836340
# Unit test for function load
def test_load():
    assert dump('test/files/replay/', 'test/files/replay/', {}) != None


# Generated at 2022-06-25 15:38:19.915676
# Unit test for function dump
def test_dump():
    pass


# Generated at 2022-06-25 15:38:39.025954
# Unit test for function load
def test_load():
    str_0 = 'tests/files/replay/foo/'
    str_1 = 'tests/files/replay/foo/bar.py'
    str_2 = 'tests/files/replay/foo/bar.yaml'
    dict_1 = {'cookiecutter': {'_template': 'foo/'}}
    dict_2 = {'cookiecutter': {'_template': 'foo/', 'baz': 'qux'}}
    dict_3 = {'cookiecutter': {'_template': 'foo/', 'baz': 'qux'}}
    test_0 = load(str_0, str_1)
    test_1 = load(str_0, str_2)
    test_2 = load(str_0, str_1)

# Generated at 2022-06-25 15:38:50.003550
# Unit test for function dump
def test_dump():
    # Test with a test directory that does not exist.
    try:
        replay_dir = 'tests/files/replay/'
        template_name = 'fake_template_name'
        context = {
            'cookiecutter': {
                'project_name': 'Cookiecutter Example',
                'repo_name': 'cookiecutter-example'
            }
        }
        dump(replay_dir, template_name, context)
    except IOError as e:
        assert e.args[0] == 'Unable to create replay dir at {}'.format(
            replay_dir)

    # Test with a template name that is a different type
    replay_dir = 'tests/files/'
    template_name = 'fake_template_name'

# Generated at 2022-06-25 15:38:53.150289
# Unit test for function load
def test_load():
    str_0 = 'tets/files/replay/'
    str_1 = dump(str_0, str_0, str_0)
    assert str_1 == {}
    str_1 = load(str_0, str_0)
    assert str_1 == {}


# Generated at 2022-06-25 15:38:56.594867
# Unit test for function dump
def test_dump():
    """Unit test for function dump."""
    # str_0 = 'tets/files/replay/'
    # var_0 = load(str_0, str_0)
    str_0 = 'tets/files/replay/'
    str_1 = '{}_test'.format(str_0)
    var_1 = dump(str_1, str_0, str_0)


# Generated at 2022-06-25 15:39:04.714527
# Unit test for function load
def test_load():
    template_name = 'cookiecutter.json'
    replay_dir = 'tests/files/replay/'
    expected = {
        'cookiecutter': {
            'full_name': 'Audrey Roy',
            'email': 'audreyr@example.com',
            'project_name': 'Cookiecutter Example Python Project'
        }
    }

    result = load(replay_dir, template_name)
    assert result == expected, "Expected: {}, got: {}".format(expected, result)



# Generated at 2022-06-25 15:39:10.775679
# Unit test for function load
def test_load():
    try:
        result = load()
        assert result == None
        assert False
    except TypeError as e:
        print(e)

    try:
        result = load('test/files/replay/')
        assert result == None
        assert False
    except TypeError as e:
        print(e)

    try:
        result = load('test/files/replay/', 'pizzapi')
        assert False
    except ValueError as e:
        print(e)


# Generated at 2022-06-25 15:39:19.766742
# Unit test for function load
def test_load():
    var_0 = get_file_name('./cookiecutter.json', 'cookiecutter')
    var_1 = get_file_name('./cookiecutter', 'cookiecutter')
    str_0 = 'test/files/replay/'
    str_1 = 'cookiecutter.json'
    str_2 = 'cookiecutter.json'
    str_3 = 'cookiecutter.json'
    str_4 = 'cookiecutter.json'
    str_5 = 'cookiecutter.json'
    str_6 = 'cookiecutter.json'
    str_7 = 'cookiecutter.json'
    str_8 = 'cookiecutter.json'
    str_9 = 'cookiecutter.json'
    str_10 = 'cookiecutter.json'

# Generated at 2022-06-25 15:39:21.281807
# Unit test for function load
def test_load():
    res = load(None, None)
    assert isinstance(res, dict)


# Generated at 2022-06-25 15:39:22.736773
# Unit test for function load
def test_load():
    try:
        test_case_0()
        return True
    except Exception:
        return False


# Generated at 2022-06-25 15:39:26.570561
# Unit test for function load
def test_load():
    txt = 'tets/files/replay/'
    assert isinstance(load(txt, txt), dict)

    txt = 'hoge'
    assert isinstance(load(txt, txt), dict) is False



# Generated at 2022-06-25 15:39:59.183562
# Unit test for function load
def test_load():
    from cookiecutter.main import cookiecutter
    import shutil
    import time

    # since our handle depends on the time the tests are run
    # we store the current time to use in the filename
    timestamp = time.strftime('%Y-%m-%dT%H:%M:%S')

    result = cookiecutter(
        'tests/test-repo-pre/',
        no_input=True,
        replay=True,
        replay_dir='tests/test-repo-post/'
    )
    assert result['project_slug'] == '{{cookiecutter.project_slug}}'
    assert result['project_name'] == '{{cookiecutter.project_name}}'
    assert result['project_slogan'] == "{{cookiecutter.project_slogan}}"
   

# Generated at 2022-06-25 15:40:00.195403
# Unit test for function load
def test_load():
    x = load()
    assert x != None

# Generated at 2022-06-25 15:40:08.579259
# Unit test for function dump
def test_dump():
    """test_dump
    """
    str_0 = 'tets/files/replay/'
    dict_0 = {'cookiecutter': {'fake': 'tester', 'full_name': 'tester'}}
    test_0 = dump(str_0, str_0, dict_0)
    dict_1 = {'cookiecutter': {'fake': 'tester'}}
    test_1 = dump(str_0, str_0, dict_1)
    dict_2 = {'cookiecutter': {'fake': 'tester', 'full_name': 'tester'}}
    test_2 = dump(str_0, 'not_imported', dict_2)
    dict_3 = {'fake': 'tester', 'full_name': 'tester'}

# Generated at 2022-06-25 15:40:13.763526
# Unit test for function load
def test_load():
    # Create user input
    replay_dir = '{{cookiecutter.replay_dir}}'
    template_name = '{{cookiecutter.template_name}}'

    # Manually add test data
    replay_dir = 'tests/files/replay/'
    template_name = 'example_repo'

    # Perform test
    try:
        load(replay_dir, template_name)
    except ValueError as e:
        print(e)
        raise Exception



# Generated at 2022-06-25 15:40:20.659341
# Unit test for function load
def test_load():
    # Test template name is not of type str
    with pytest.raises(TypeError):
        load('./test', 1)
    # Test replay file does not exist
    with pytest.raises(IOError):
        load('./test', 'test')
    # Test context does not contain key 'cookiecutter'
    with pytest.raises(ValueError):
        load('./test/replay', 'test')


# Generated at 2022-06-25 15:40:24.906988
# Unit test for function dump
def test_dump():
    replay_dir = 'tests/files/replay'
    template_name = 'tests/files/replay/test_template'
    context = {'cookiecutter': {'a': 'b'}}
    dump(replay_dir, template_name, context)
    assert os.path.isfile(get_file_name(replay_dir, template_name))



# Generated at 2022-06-25 15:40:26.121435
# Unit test for function load
def test_load():
    assert not True, "test_load not implemented"


# Generated at 2022-06-25 15:40:31.347844
# Unit test for function load
def test_load():
    try:
        # Test Case 0
        str_0 = 'tets/files/replay/'
        var_0 = load(str_0, str_0)
        assert True
    except:
        print('Test Case 0 failed')
    try:
        # Test Case 1
        str_0 = 'tets/files/replay/'
        var_0 = load(str_0, str_0)
        assert True
    except:
        print('Test Case 1 failed')


# Generated at 2022-06-25 15:40:34.965717
# Unit test for function load
def test_load():
    context = {"a": "1", "b": "2"}
    dump(str_0, str_0, context)
    assert load(str_0, str_0) == context


# Generated at 2022-06-25 15:40:38.339596
# Unit test for function load
def test_load():
    str_0 = 'test/files/replay/foo-project'
    str_1 = 'test/files/replay/'
    # Test with one argument
    var_0 = load(str_0)
    # Test with two arguments
    var_1 = load(str_1, str_0)


# Generated at 2022-06-25 15:41:30.383461
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:41:32.043955
# Unit test for function load
def test_load():
    assert isinstance(load('tets/files/replay/', 'tets/files/replay/'), dict)


# Generated at 2022-06-25 15:41:32.693883
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:41:34.249078
# Unit test for function load
def test_load():
    dump('tests/files/replay/', 'cc_test', {'cookiecutter': {'magic': 'abracadabra'}})
    test_case_0()

# Generated at 2022-06-25 15:41:36.220835
# Unit test for function load
def test_load():
    str_0 = 'tets/files/replay/'
    context = load(str_0, str_0)
    assert (isinstance(context, dict))
    assert ('cookiecutter' in context)


# Generated at 2022-06-25 15:41:38.337888
# Unit test for function load
def test_load():
    str_0 = 'tets/files/replay/'
    var_0 = load(str_0, str_0)
    assert isinstance(var_0, dict)
    assert var_0 == {'cookiecutter': {'_template': 'tests/files/replay/'}}


# Generated at 2022-06-25 15:41:39.957916
# Unit test for function dump
def test_dump():
    assert callable(dump)



# Generated at 2022-06-25 15:41:46.313925
# Unit test for function load
def test_load():
    from cookiecutter.replay import load
    from cookiecutter.main import cookiecutter
    
    context = {}
    replay_file = os.path.join(get_template_path(), 'replay/test_file.json')
    context = load(replay_file)
    
    assert context['name'] == 'test_cookiecutter_project'
    assert context['description'] == 'This is a fake cookiecutter project'
    assert context['author_name'] == 'Test Runner'
    
    

# Generated at 2022-06-25 15:41:52.783965
# Unit test for function dump
def test_dump():
    str_0 = 'test/files/replay/'
    str_1 = str_0
    
    def function_0():
        test_case_0()
    
    var_0 = dict()
    var_0['cookiecutter'] = dict()
    
    try:
        dump(str_0, str_1, var_0)
    except ValueError:
        function_0()
    else:
        function_0()
    finally:
        function_0()

# Generated at 2022-06-25 15:41:53.716162
# Unit test for function dump
def test_dump():
    assert callable(dump)
