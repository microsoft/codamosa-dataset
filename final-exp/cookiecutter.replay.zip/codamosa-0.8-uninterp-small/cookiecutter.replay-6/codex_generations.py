

# Generated at 2022-06-25 15:32:58.934730
# Unit test for function dump
def test_dump():
    assert callable(dump), 'Function "dump" is not callable'
    template_name = 'TODO: Replace with a valid value'
    context = {}
    try:
        dump(template_name, context)
    except TypeError as e:
        assert isinstance(e, TypeError), 'Exception raised should be of type TypeError'

# Generated at 2022-06-25 15:33:08.660006
# Unit test for function load
def test_load():
    var_0 = True
    var_1 = True
    var_2 = True
    var_3 = True
    var_4 = True
    var_5 = True
    var_6 = True
    var_7 = True
    var_8 = True
    var_9 = True
    var_10 = True
    var_11 = True
    var_12 = True
    var_13 = True
    var_14 = True
    var_15 = True
    var_16 = True
    var_17 = True
    var_18 = True
    var_19 = True
    var_20 = True
    var_21 = True
    var_22 = True
    var_23 = True
    var_24 = True
    var_25 = True
    var_26 = True
    var_27 = True
    var_

# Generated at 2022-06-25 15:33:10.649686
# Unit test for function dump
def test_dump():
    assert True == True


# Generated at 2022-06-25 15:33:14.673461
# Unit test for function get_file_name
def test_get_file_name():
    str_0 = "replay"
    str_1 = "context.json"
    str_2 = "context.json"
    assert get_file_name(str_0, str_1) == str_2


# Generated at 2022-06-25 15:33:17.643492
# Unit test for function get_file_name
def test_get_file_name():
    assert get_file_name(None, None)
    

# Generated at 2022-06-25 15:33:26.718034
# Unit test for function dump
def test_dump():
    with open("tests/test_dump.json", "r") as f:
        expected = json.loads(f.read())

    replay_dir = "cookiecutter"
    template_name = "tests/dump_test_template"
    context = {
        'cookiecutter': {
            '_template': 'tests/dump_test_template',
            'test': '123'
        }
    }
    dump(replay_dir, template_name, context)

    with open("cookiecutter/tests/dump_test_template.json", "r") as f:
        actual = json.loads(f.read())

    assert actual == expected


# Generated at 2022-06-25 15:33:28.875283
# Unit test for function load
def test_load():
    replay_dir = "./cqx_template"
    template_name = "cqx-template"
    context = load(replay_dir, template_name)
    print(context)



# Generated at 2022-06-25 15:33:31.474287
# Unit test for function dump
def test_dump():
    assert not dump()



# Generated at 2022-06-25 15:33:34.285409
# Unit test for function load
def test_load():
    print("test_load")

    # Source: RST_STUDIO/test_load.rst:4
    load('test_load_0', 'test_load_0')



# Generated at 2022-06-25 15:33:38.703136
# Unit test for function get_file_name
def test_get_file_name():
    replay_dir = 'abcdefghijklmnopqrstuvwzyz'
    template_name = 'abcdefghijklmnopqrstuvwzyz'
    assert get_file_name(replay_dir, template_name) == replay_dir + '/' + template_name + '.json'


# Generated at 2022-06-25 15:33:42.194067
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:33:43.838069
# Unit test for function load
def test_load():
    str_0 = 'potato'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:33:50.305303
# Unit test for function load
def test_load():
    file_yaml = "tests/load.yaml"
    file_json = "tests/load.json"
    with open(file_yaml, "r") as stream:
        try:
            data_loaded = yaml.load(stream)
            data_loaded = dict(data_loaded)
        except yaml.YAMLError as exc:
            print(exc)
    with open(file_json, "r") as json_file:
        data_loaded_json = json.load(json_file)
    assert data_loaded == data_loaded_json


# Generated at 2022-06-25 15:33:52.936137
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:34:00.743624
# Unit test for function load
def test_load():
    # Function Test: get_file_name - Function Test
    # Template: test_load_0
    var_0 = get_file_name('test_load_0', 'test_load_0')

    # Function Test: load - Unit Test
    # Template: test_load_0
    context = {'cookiecutter': {'full_name': 'test_load_0'}}
    var_0 = load('.', 'test_load_0')
    assert var_0 == context



# Generated at 2022-06-25 15:34:03.007798
# Unit test for function load
def test_load():
    # str_0 = 'test_load_0'
    # var_0 = load(str_0, str_0)
    test_case_0()


# Generated at 2022-06-25 15:34:10.349007
# Unit test for function load
def test_load():
    var_0 = dict()
    var_0['cookiecutter'] = dict()
    var_0['cookiecutter']['repo_dir'] = '{{ cookiecutter.repo_dir }}'
    var_0['cookiecutter']['full_name'] = '{{ cookiecutter.full_name }}'
    var_0['cookiecutter']['email'] = '{{ cookiecutter.email }}'
    var_0['cookiecutter']['project_name'] = '{{ cookiecutter.project_name }}'
    var_0['cookiecutter']['project_license'] = '{{ cookiecutter.project_license }}'
    var_0['cookiecutter']['project_short_description'] = '{{ cookiecutter.project_short_description }}'

# Generated at 2022-06-25 15:34:20.341304
# Unit test for function load
def test_load():
    print('Testing load ...')

    test_case_load_0()
    test_case_load_1()
    test_case_load_2()
    test_case_load_3()
    test_case_load_4()
    test_case_load_5()
    test_case_load_6()
    test_case_load_7()
    test_case_load_8()
    test_case_load_9()
    test_case_load_10()
    test_case_load_11()
    test_case_load_12()
    test_case_load_13()
    test_case_load_14()
    test_case_load_15()
    test_case_load_16()
    test_case_load_17()
    test_case_load_18()
   

# Generated at 2022-06-25 15:34:23.340129
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    arr_0 = [['clea', 'erly'], ['', '', ''], ['', 'y'], ['', '']]
    for element_1 in range(1, 2):
        for element_0 in arr_0[element_1]:
            try:
                var_0 = load(str_0, '')
            except ValueError as exception_0:
                print('ValueError: ', exception_0)


# Generated at 2022-06-25 15:34:25.823801
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:34:37.354842
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    str_1 = 'test_load_1'
    str_2 = 'test_load_2'
    str_3 = 'test_load_3'
    str_4 = 'test_load_4'
    str_5 = 'test_load_5'
    str_6 = 'test_load_6'
    str_7 = 'test_load_7'
    str_8 = 'test_load_8'
    str_9 = 'test_load_9'
    var_0 = load(str_0, str_1)
    str_10 = 'test_load_10'
    var_1 = load(str_2, str_3)
    str_11 = 'test_load_11'

# Generated at 2022-06-25 15:34:38.817328
# Unit test for function load
def test_load():
    test_case_0()

# Development logging for function load

# Generated at 2022-06-25 15:34:43.782101
# Unit test for function load
def test_load():
    dict_0 = {'cookiecutter': {'project_name': 'test_load_1', 'full_name': 'test_load_2'}}
    str_0 = 'test_load_0'
    dump(str_0, str_0, dict_0)
    var_0 = load(str_0, str_0)
    #Test the equality of two dictionaries
    assert dict_0 == var_0, "Not equal"


# Generated at 2022-06-25 15:34:45.261444
# Unit test for function load
def test_load():
    """Test load function."""
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 15:34:46.946359
# Unit test for function load
def test_load():
    test_case_0()



# Generated at 2022-06-25 15:34:47.962231
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:34:54.382872
# Unit test for function load
def test_load():
    # Input parameters
    replay_dir = 'hello'
    template_name = 'hello'

    # Expected results

# Generated at 2022-06-25 15:35:01.609516
# Unit test for function load
def test_load():
    dict_0 = dict()
    dict_0['cookiecutter'] = dict()
    dict_0['cookiecutter']['_template'] = 'cookiecutter-python-module'
    dict_0['cookiecutter']['cookiecutter_python_module_name'] = 'Python Cookiecutter Module'
    dict_0['cookiecutter']['cookiecutter_python_module_description'] = 'Generate a Python module with Cookiecutter'
    dict_0['cookiecutter']['cookiecutter_python_module_version'] = '0.1.0'
    dict_0['cookiecutter']['cookiecutter_python_module_license'] = 'MIT'
    dict_0['cookiecutter']['cookiecutter_python_module_author'] = 'Daniel Roy Greenfeld'
    dict_0

# Generated at 2022-06-25 15:35:13.862644
# Unit test for function dump
def test_dump():
    # Test Case #0
    template_name = 'test_dump_0'
    context = {'cookiecutter': {'full_name': 'FirstName LastName'}}
    os.makedirs('test_dump_0')
    dump('test_dump_0', template_name, context)

    # Test Case #1
    template_name = 'test_dump_1'
    context = {'cookiecutter': {'full_name': 'FirstName LastName'}}
    os.makedirs('test_dump_1')
    dump('test_dump_1', template_name, context)

    # Test Case #2
    template_name = 'test_dump_2'
    context = {'cookiecutter': {'full_name': 'FirstName LastName'}}

# Generated at 2022-06-25 15:35:16.590755
# Unit test for function load
def test_load():
    assert test_case_0() == None


# Generated at 2022-06-25 15:35:23.220295
# Unit test for function dump
def test_dump():
    str_0 = 'test_dump_0'
    var_0 = {str_0 : str_0}

    dump(str_0, str_0, var_0)
    var_1 = load(str_0, str_0)
    assert var_0 == var_1


# Generated at 2022-06-25 15:35:28.642049
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    dict_0 = dict()
    dict_0['cookiecutter'] = dict()
    dict_0['cookiecutter']['full_name'] = str_0
    dump(str_0, str_0, dict_0)
    dict_0 = load(str_0, str_0)
    print(dict_0)
    print(type(dict_0))
    # assert load(str_0, str_0) == dict_0


# Generated at 2022-06-25 15:35:34.921988
# Unit test for function load
def test_load():
    dict_0 = dict()
    dict_0['cookiecutter'] = dict()
    dict_0['cookiecutter']['full_name'] = 'Cat'
    dict_0['cookiecutter']['email'] = 'cat@me.com'
    dict_0['cookiecutter']['github_username'] = 'IamACat'
    dict_0['cookiecutter']['project_name'] = 'Cat Project'
    dict_0['cookiecutter']['project_slug'] = 'cat-project'
    dict_0['cookiecutter']['pypi_username'] = 'IamACat'
    dict_0['cookiecutter']['version'] = '0.1.0'
    dict_0['cookiecutter']['repo_name'] = 'cat-project'

# Generated at 2022-06-25 15:35:36.192842
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:35:39.391454
# Unit test for function load
def test_load():
    # Test Case 0
    try:
        test_case_0()
        print("test_load: Test Case 0: PASS")
    except ValueError:
        print("test_load: Test Case 0: FAIL")



# Generated at 2022-06-25 15:35:42.258877
# Unit test for function load
def test_load():
    str_0 = 'test_load_1'
    var_0 = load(str_0, str_0)
    if isinstance(var_0, str) is True:
        raise ValueError('expected ValueError')


# Generated at 2022-06-25 15:35:50.492750
# Unit test for function load
def test_load():
    var_0 = {
        'test_load_0':
        {
            'cookiecutter':
            {
                'project_name': 'my_project',
                'repo_name': 'my_repo'
            }
        },
        'test_load_1':
        {
            'cookiecutter':
            {
                'project_name': 'my_project',
                'repo_name': 'my_repo'
            }
        }
    }
    test_case_0()


# Generated at 2022-06-25 15:35:57.266559
# Unit test for function load
def test_load():
    test_case_0()

# Test case 1
str_0 = 'test_load_1'

# Generated at 2022-06-25 15:36:03.853771
# Unit test for function dump
def test_dump():
    var_0 = 'foo'
    var_1 = {'key': 'value'}
    # AssertionError: Context is required to contain a cookiecutter key
    var_2 = {'key': 'value', 'cookiecutter': 'val_0'}
    # IOError: Unable to create replay dir at dir_0
    var_3 = 'dir_0'
    dump(var_3, var_0, var_2)
    dump(var_0, var_0, var_2)
    dump(var_0, var_0, var_1)
    dump(var_0, var_0, var_1)

if __name__ == '__main__':
    test_case_0()
    test_dump()

# Generated at 2022-06-25 15:36:05.879414
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)
    assert not var_0

# Generated at 2022-06-25 15:36:11.968581
# Unit test for function load
def test_load():
    print("Function: load")
    print("Type: unit")

    # Case 0
    print("\tCase 0")
    try:
        test_case_0()
        print("\t\tload() works properly")
    except Exception as e:
        print("\t\tload() does not work properly")
        print("\t\tException: " + str(e))
    return

# Generated at 2022-06-25 15:36:15.392384
# Unit test for function load
def test_load():
    """Unit test for function load."""
    # Variable to hold value returned by function load
    var_2 = None

    # Test case 0
    if True:
        str_0 = 'test_load_0'
        var_0 = load(str_0, str_0)



# Generated at 2022-06-25 15:36:20.939960
# Unit test for function load
def test_load():

    # Load the context from an existing replay file
    replay_file = 'tests/files/replay/test_load_0.json'
    with open(replay_file, 'r') as infile:
        context = json.load(infile)

    # Dump the context to a replay file
    replay_dir = 'tests/files/replay'
    template_name = 'test_load_0'
    dump(replay_dir, template_name, context)

    # Load the context from the replay file and compare the results
    new_context = load(replay_dir, template_name)
    assert context == new_context



# Generated at 2022-06-25 15:36:22.931500
# Unit test for function load
def test_load():
    # Test with 'test_load_0' as parameter.
    test_case_0()



# Generated at 2022-06-25 15:36:26.000252
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except (IOError, OSError, TypeError, ValueError):
        pass
    else:
        raise AssertionError('load test case 0 failed')


# Generated at 2022-06-25 15:36:30.229211
# Unit test for function dump
def test_dump():
    a = {'cookiecutter': {'full_name': 'Elvin Yung', 'email': 'elvinyung@gmail.com'}}
    dump('.','answers',a)



# Generated at 2022-06-25 15:36:34.453261
# Unit test for function load
def test_load():
    cookiecutter = {'author': 'test'}
    dump('/tmp', 'dump.json', {'cookiecutter': cookiecutter})
    context = load('/tmp', 'dump.json')
    assert context['cookiecutter'] == cookiecutter
    os.remove(os.path.join('/tmp', 'dump.json'))



# Generated at 2022-06-25 15:36:35.519732
# Unit test for function load
def test_load():
    var_0 = load('', '')


# Generated at 2022-06-25 15:36:37.265586
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    str_1 = 'test_load_1'
    var_0 = load(str_0, str_1)


# Generated at 2022-06-25 15:36:38.949128
# Unit test for function load
def test_load():
    # test_case_0
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:36:47.032124
# Unit test for function load
def test_load():
    expect = {'cookiecutter': {'full_name': 'Audre Lorde'}}

    replay_dir = 'tests/files/test-replay'
    template_name = 'tests/files/test-template'

    result = load(replay_dir, template_name)
    assert result == expect, 'test_load failed: {} != {}'.format(result, expect)



# Generated at 2022-06-25 15:36:54.540019
# Unit test for function dump
def test_dump():
    str_0 = 'test_dump_0'
    str_1 = 'test_dump_1'
    # Create a dummy context
    var_1 = {str_0: str_0}
    context_0 = {str_1: var_1}
    # call dump with the dummy values
    dump(str_0, str_0, context_0)
    assert(load(str_0, str_0) == context_0)


# Generated at 2022-06-25 15:36:55.461958
# Unit test for function load
def test_load():

    test_case_0()



# Generated at 2022-06-25 15:36:57.641019
# Unit test for function load
def test_load():
    try:
        assert callable(load)
    except AssertionError as e:
        raise(e)


# Generated at 2022-06-25 15:37:01.633901
# Unit test for function load
def test_load():
    var_0 = load('test_load_0', 'test_load_1')

# Generated at 2022-06-25 15:37:02.665950
# Unit test for function load
def test_load():
    test_case_0()

# Generated at 2022-06-25 15:37:10.129534
# Unit test for function load
def test_load():
    str_0 = 'plop'
    str_1 = '{{cookiecutter}}'
    str_2 = 'test_load_0'

    print('test_load_0')
    try:
        var_0 = load(str_0, str_1)
    except ValueError as var_1:
        pass

    print('test_load_1')
    try:
        var_0 = load(str_2, str_2)
    except TypeError as var_1:
        pass

    print('test_load_2')
    try:
        var_0 = load(str_0, str_2)
    except IOError as var_1:
        pass


# Generated at 2022-06-25 15:37:10.870874
# Unit test for function load
def test_load():
    pass



# Generated at 2022-06-25 15:37:11.899917
# Unit test for function load
def test_load():
    assert True == False



# Generated at 2022-06-25 15:37:20.087733
# Unit test for function load
def test_load():
    
    # Test case 0
    str_0 = 'test_load_0'
    
    lst_0 = ['test_load_0']
    dict_0 = dict()
    dict_1 = dict()
    dict_0['default_context'] = dict_1
    dict_1['cookiecutter'] = dict()
    
    assert load(lst_0, str_0) == dict_0
    
    # Test case 1
    str_1 = 'test_load_1'
    
    dict_2 = dict()
    dict_3 = dict()
    dict_3['cookiecutter'] = dict()
    dict_3['test_load_1'] = str_1
    dict_2['default_context'] = dict_3
    
    assert load(lst_0, str_1) == dict

# Generated at 2022-06-25 15:37:32.509937
# Unit test for function load
def test_load():
    replay_dir = 'test_load'
    template_name = 'test_load'

    # Dump context data to file.

# Generated at 2022-06-25 15:37:42.014096
# Unit test for function dump
def test_dump():
    input_0 = 'test_dump_0'
    input_1 = 'test_dump_1'
    input_2 = 'test_dump_2'
    input_3 = 'test_dump_3'
    input_4 = 'test_dump_4'

# Generated at 2022-06-25 15:37:46.610562
# Unit test for function load
def test_load():
    try:
        test_case_0()
        print('Executed test cases successfully')
    except Exception as e:
        print(e)
        print('Executed test cases unsuccessfully')

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-25 15:37:49.640485
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    str_1 = 'test_load_1'
    str_2 = 'test_load_2'
    str_3 = 'test_load_3'
    str_4 = 'test_load_4'
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-25 15:37:52.414875
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)

    print(var_0)

if __name__ == "__main__":
    test_load()

# Generated at 2022-06-25 15:38:01.857494
# Unit test for function load
def test_load():
    var_1 = load(
        'path to Template 1',
        'Template 1'
    )
    # Expected 'Template 1', but got Template 1.
    var_2 = load(
        'path to Template 2',
        'Template 2'
    )
    # Expected 'Template 2', but got Template 2.
    # The path does not exist.
    var_3 = load(
        'path to Template 3',
        'Template 3'
    )
    # Expected 'Template 3', but got Template 3.
    var_4 = load(
        'path to Template 4',
        'Template 4'
    )
    # Expected 'Template 4', but got Template 4.


# Generated at 2022-06-25 15:38:11.062258
# Unit test for function load
def test_load():
    var_0 = {'foo': 'bar', 'cookiecutter': {}}
    str_0 = 'test_load_0'
    dump(str_0, str_0, var_0)
    var_1 = load(str_0, str_0)
    assert var_0 == var_1

    dict_0 = {'foo': 'bar', 'cookiecutter': {}}
    str_0 = 'test_load_1'
    dump(str_0, str_0, dict_0)
    dict_1 = load(str_0, str_0)
    assert dict_0 == dict_1

    dict_0 = {'foo': 'bar', 'cookiecutter': {}}
    str_0 = 'test_load_2'
    dump(str_0, str_0, dict_0)


# Generated at 2022-06-25 15:38:20.330768
# Unit test for function dump
def test_dump():
    """Test function dump.

    Tests the function dump by creating a file and directory and
    then checking to see if it exists.
    """
    template_name = 'test_dump_0'
    context = {'cookiecutter': {'replay_dir': '.'}}
    expected_file = get_file_name('.', template_name)

    # Check precondition
    assert not os.path.isfile(expected_file)

    dump('.', template_name, context)

    # Check postconditions
    assert os.path.isfile(expected_file), 'Created file does not exist'

    with open(expected_file, 'r') as infile:
        actual_context = json.load(infile)

    assert context == actual_context, 'Actual context does not match'

    # Cleanup
    os

# Generated at 2022-06-25 15:38:29.052390
# Unit test for function load
def test_load():
    d = {
        'content': load.__doc__,
        'function_name': load.__name__
    }
    # Function 'load' will have a docstring
    assert d['function_name'] == 'load'

    # Function 'load' will have a docstring
    assert d['content'].strip() == "Read json data from file."

    # Function 'load' will have a docstring
    assert load.__name__ == 'load'

    try:
        test_case_0()
    except Exception as e:
        assert 'Template name is required to be of type str'
        assert e.__class__.__name__ == 'TypeError'


# Generated at 2022-06-25 15:38:30.279432
# Unit test for function load
def test_load():
    # Test empty
    test_case_0()


# Generated at 2022-06-25 15:38:42.933809
# Unit test for function load
def test_load():
    test_case_0()

if __name__ == '__main__':
    test_load()

# Generated at 2022-06-25 15:38:53.014206
# Unit test for function load
def test_load():
    try:
        test_case_0()
    except IOError:
        print('IOError: test load case 0')

    try:
        assert(load(None, None) == False) 
    except TypeError:
        print('TypeError: test load case 1')

    try:
        assert(load('test_load_2', 'test_load_2') == True) 
    except ValueError:
        print('ValueError: test load case 2')



# Generated at 2022-06-25 15:38:59.561680
# Unit test for function dump
def test_dump():
    input_0 = {'cookiecutter': {'_copy_without_render': ['license', 'README.md']}}
    input_1 = {'replay_dir': '.', 'template_name': 'test_dump_1'}
    input_0.update(input_1)
    dump(**input_0)
    var_0 = load(**input_1)

    assert input_0 == var_0


# Generated at 2022-06-25 15:39:02.676988
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)
    assert var_0 == 'test_load_0'


# Generated at 2022-06-25 15:39:04.482910
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)



# Generated at 2022-06-25 15:39:10.660971
# Unit test for function load
def test_load():
    #assert(load("repo_name_0", "repo_name_0") == {"cookiecutter": {}})
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)
    str_1 = 'test_load_1'
    var_1 = load(str_1, str_1)
    str_2 = 'test_load_2'
    var_2 = load(str_2, str_2)
    str_3 = 'test_load_3'
    var_3 = load(str_3, str_3)
    str_4 = 'test_load_4'
    var_4 = load(str_4, str_4)
    str_5 = 'test_load_5'

# Generated at 2022-06-25 15:39:15.715049
# Unit test for function load
def test_load():
    context = {
        'cookiecutter': {'project_name': 'Cookiecutter'},
        'test': True
    }
    replay_dir = 'tests/test-replay'
    template_name = 'test-replay'
    context_loaded = load(replay_dir, template_name)
    assert context == context_loaded



# Generated at 2022-06-25 15:39:18.854336
# Unit test for function load
def test_load():
    assert len(test_load.__doc__) > 0, 'No docstring in %r.' % test_load
    assert test_load.__doc__.strip().startswith('test_load('), 'Missing or invalid docstring in %r.' % test_load
    test_case_0()


# Generated at 2022-06-25 15:39:23.359308
# Unit test for function load
def test_load():
    str_0 = 'test_load_1'
    dict_0 = {'cookiecutter': str_0}
    dump(str_0, str_0, dict_0)
    str_1 = load(str_0, str_0)
    assert(str_0 == str_1['cookiecutter'])
    os.remove(get_file_name(str_0, str_0))


# Generated at 2022-06-25 15:39:24.187493
# Unit test for function load
def test_load():
    test_case_0()


# Generated at 2022-06-25 15:39:49.338973
# Unit test for function dump
def test_dump():
    assert dump(2, 3, 4) == None


# Generated at 2022-06-25 15:39:54.460630
# Unit test for function load
def test_load():
    assert(callable(load))
    try:
        test_case_0()
    except:
        print('Function load does not work')


# Generated at 2022-06-25 15:40:04.437279
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)

    str_1 = 'test_load_1'
    var_1 = load(str_1, str_1)

    str_2 = 'test_load_2'
    var_2 = load(str_2, str_2)

    str_3 = 'test_load_3'
    var_3 = load(str_3, str_3)

    str_4 = 'test_load_4'
    var_4 = load(str_4, str_4)

    str_5 = 'test_load_5'
    var_5 = load(str_5, str_5)

    str_6 = 'test_load_6'

# Generated at 2022-06-25 15:40:07.111379
# Unit test for function load
def test_load():
    """Test for the module load."""
    test_case_0()


# Generated at 2022-06-25 15:40:14.931316
# Unit test for function load
def test_load():
    # Basic test cases
    assert load('tests/fixtures/replay', 'test_0') == {'cookiecutter': {'full_name': 'Chris Rossi', 'email': 'foobar@gmail.com', 'project_name': 'test_0', 'repo_name': 'test_0', 'year': 'This year', 'version': '0.1.0'}}
    assert load('tests/fixtures/replay', 'test_1') == {'cookiecutter': {'full_name': 'Chris Rossi', 'email': 'foobar@gmail.com', 'project_name': 'test_1', 'repo_name': 'test_1', 'year': 'This year', 'version': '0.1.0'}}

# Generated at 2022-06-25 15:40:23.058418
# Unit test for function dump
def test_dump():
    template_name = 'test_dump_context'
    replay_dir = template_name
    context = {
        'cookiecutter': {
            'full_name': 'Allister Sun',
        },
    }
    dump(replay_dir, template_name, context)
    # read it back
    context = load(replay_dir, template_name)
    assert 'cookiecutter' in context
    assert 'full_name' in context['cookiecutter']
    assert context['cookiecutter']['full_name'] == 'Allister Sun'


# Generated at 2022-06-25 15:40:24.946741
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)


# Generated at 2022-06-25 15:40:25.829799
# Unit test for function load
def test_load():
    test_case_0()



# Generated at 2022-06-25 15:40:29.647082
# Unit test for function load
def test_load():
    # Test case 0
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)
    var_1 = {'cookiecutter': {'description': 'My awesome new project'}}
    assert type(var_0) == type(var_1)
    assert var_0 == var_1


# Generated at 2022-06-25 15:40:38.532850
# Unit test for function dump
def test_dump():
    """Assert dump function is working."""
    dump_dir = os.path.join(os.path.dirname(__file__), 'fake-replay-dir')
    template_name = 'fake-template-name'

# Generated at 2022-06-25 15:41:11.308465
# Unit test for function dump
def test_dump():
    # no replay dir
    template_name = 'fake'
    context = {'cookiecutter': {'key_0': 'value_0'}}
    with pytest.raises(IOError):
        dump(template_name, template_name, context)

    # replay dir not a str
    replay_dir = {'replay_dir': 'fake_0'}
    with pytest.raises(TypeError):
        dump(replay_dir, template_name, context)

    # template name not a str
    replay_dir = 'fake_0'
    template_name = {'template_name': 'fake_1'}
    with pytest.raises(TypeError):
        dump(replay_dir, template_name, context)

    # context not a dict
    template_name = 'fake_2'


# Generated at 2022-06-25 15:41:14.068286
# Unit test for function load
def test_load():
    str_0 = 'test_load_0'
    var_0 = load(str_0, str_0)
    test_case_0()



# Generated at 2022-06-25 15:41:17.978096
# Unit test for function load
def test_load():
    try:
        test_case_0()
        print('Passed all')
    except ValueError as e:
        print('Failed test_case_0: {}'.format(e))

# Generated at 2022-06-25 15:41:21.806925
# Unit test for function load
def test_load():
    context_dict = {
        'a': 'b',
        'c': 'd',
    }
    template_name = 'test_load_1'

    dump('replay_dir', template_name, context_dict)
    context_dict2 = load('replay_dir', template_name)

    assert context_dict == context_dict2

# Generated at 2022-06-25 15:41:22.512735
# Unit test for function load
def test_load():
    print(test_case_0())


# Generated at 2022-06-25 15:41:23.184753
# Unit test for function load
def test_load():
    assert callable(load)


# Generated at 2022-06-25 15:41:24.053597
# Unit test for function dump
def test_dump():
    dump('test_dump', 'test_dump', {})


# Generated at 2022-06-25 15:41:30.865638
# Unit test for function dump
def test_dump():
    path = 'temp_replay'
    if not os.path.isdir(path):
        os.mkdir(path)
    context = {"cookiecutter": {"author_name": "Kevin", "package_name": "hello"}}
    dump(path, 'test_replay', context)
    new_context = load(path, 'test_replay')
    assert new_context['cookiecutter'] == context['cookiecutter']
    if os.path.isdir(path):
        os.rmdir(path)

if __name__ == '__main__':
    test_case_0()
    test_dump()

# Generated at 2022-06-25 15:41:32.741646
# Unit test for function load
def test_load():
    try:
        str_0 = 'test_load_0'
        test_case_0()
    except TypeError as err_0:
        print(str(err_0))


# Generated at 2022-06-25 15:41:33.347790
# Unit test for function load
def test_load():
    test_case_0()