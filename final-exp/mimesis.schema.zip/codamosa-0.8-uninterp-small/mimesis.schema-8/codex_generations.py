

# Generated at 2022-06-25 21:30:40.849209
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    schema = {'hello': 'Name.full_name',
              'age': 'Person.age'}

    # Generate a JSON object
    abstract_field_0 = AbstractField(locale='en')
    result = abstract_field_0('Person.age')
    assert isinstance(result, int)
    assert result in range(1, 100)

    # Generate a JSON object
    abstract_field_1 = AbstractField(locale='en')
    result = abstract_field_1('Person.age')
    assert isinstance(result, int)
    assert result in range(1, 100)

    # Generate a JSON object
    abstract_field_2 = AbstractField(locale='en')
    result = abstract_field_2('Person.age')
    assert isinstance(result, int)

# Generated at 2022-06-25 21:30:48.844833
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = Generic()
    abstract_field_0.avatar()
    abstract_field_0.datetime()
    abstract_field_0.datetime(datetime_format='DD:mm:YYYY')
    abstract_field_1 = Generic()
    abstract_field_1.avatar()
    abstract_field_1.datetime()
    abstract_field_1.datetime(datetime_format='DD:mm:YYYY')
    abstract_field_2 = Generic()
    abstract_field_2.avatar()
    abstract_field_2.datetime()
    abstract_field_2.datetime(datetime_format='DD:mm:YYYY')
    abstract_field_3 = Generic()
    abstract_field_3.avatar()
    abstract_field_3.datetime()
    abstract

# Generated at 2022-06-25 21:30:51.212593
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    id = abstract_field_0('id')
    assert len(id) > 0


# Generated at 2022-06-25 21:30:54.590925
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    assert type(abstract_field_0) == AbstractField()
    abstract_field_1 = AbstractField()


# Generated at 2022-06-25 21:30:56.035366
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        assert abstract_field_0 is not None
    except:
        print('Test "test_AbstractField" failed!')
        return
    print('Test "test_AbstractField" passed!')


# Generated at 2022-06-25 21:31:04.800691
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField()

    try:
        abstract_field()
    except UndefinedField as e:
        assert isinstance(e, UndefinedField)

    assert isinstance(abstract_field('email'), str)

    def first_char(x: str) -> str:
        return x[0]

    assert isinstance(abstract_field('email', first_char), str)

    try:
        abstract_field('fake_provider.fake_method')
    except UnsupportedField as e:
        assert isinstance(e, UnsupportedField)

    try:
        abstract_field('fake.fake_provider.fake_method')
    except UnacceptableField as e:
        assert isinstance(e, UnacceptableField)


# Generated at 2022-06-25 21:31:06.774761
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    abstract_field_0.__str__()
    assert isinstance(abstract_field_0, AbstractField)

# Generated at 2022-06-25 21:31:10.069884
# Unit test for constructor of class AbstractField
def test_AbstractField():

    from mimesis.schema import AbstractField

    abstract_field_0 = AbstractField()
    with raises(UndefinedField):
        abstract_field_0()

    abstract_field_1 = AbstractField()
    abstract_field_1('name')
    abstract_field_1('provider.name')



# Generated at 2022-06-25 21:31:17.877264
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.address import Address
    from mimesis.enums import Gender
    from mimesis.schema import Field

    field = Field()
    provider = Address('ru')
    method = 'name'
    kwargs = {'gender': Gender.MALE}

    # Provider method
    result_0 = field(method, **kwargs)
    assert isinstance(result_0, str)

    result_1 = field('{}.{}'.format(
        Address.Meta.provider_name, method), **kwargs)
    assert result_0 == result_1

    # Provider method with called key function
    result_2 = field(
        '{}.{}'.format(Address.Meta.provider_name, method),
        **kwargs,
        key=provider.person,
    )

# Generated at 2022-06-25 21:31:32.418457
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    assert isinstance(abstract_field_0, AbstractField)
    assert abstract_field_0.seed == None
    assert abstract_field_0.locale == 'en'

    abstract_field_1 = AbstractField(seed = 1)
    assert abstract_field_1.seed == 1
    abstract_field_1 = AbstractField(locale = 'fr')
    assert abstract_field_1.locale == 'fr'

    abstract_field_2 = AbstractField(locale = 'de',seed = 2)
    assert abstract_field_2.seed == 2
    assert abstract_field_2.locale == 'de'

    abstract_field_3 = AbstractField(locale = 'en',seed = None,providers = None)
    assert abstract_field_3.seed == None


# Generated at 2022-06-25 21:32:16.956501
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Case 1
    abstract_field_0 = AbstractField()
    result1 = abstract_field_0('person.name')
    assert type(result1) is str
    # Case 2
    result2 = abstract_field_0('integer_number', start=0, end=100)
    assert type(result2) is int
    # Case 3
    result3 = abstract_field_0('characters', length=10)
    assert type(result3) is str
    # Case 4
    result4 = abstract_field_0('float_number', start=1, end=10)
    assert type(result4) is float
    # Case 5
    abstract_field_0 = AbstractField()
    result5 = abstract_field_0('no.such.method')
    assert result5 is None
    # Case 6

# Generated at 2022-06-25 21:32:18.033895
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert 'AbstractField' in globals()



# Generated at 2022-06-25 21:32:19.702621
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert isinstance(abstract_field_0('__call__'), AbstractField)


# Generated at 2022-06-25 21:32:23.625531
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
  # Testing class AbstractField
  abstract_field = AbstractField()
  def test_case_1():
    # Non-existent method
    assert not abstract_field('non_existent')
  def test_case_2():
    # Some method
    assert abstract_field('text')


# Generated at 2022-06-25 21:32:24.716271
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField()
    abstract_field('foo')

# Generated at 2022-06-25 21:32:28.351185
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    data = AbstractField()
    data.__call__('CAPS', value='test')
    data.__call__('password', length=10)

    # Fix https://github.com/lk-geimfari/mimesis/issues/620
    data.__call__(name='CAPS', value='test')



# Generated at 2022-06-25 21:32:35.432272
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstractField_0 = AbstractField()
    name_0 = 'fnord'
    name_1 = 'fnord'
    name_2 = 'fnord'
    name_3 = 'fnord'
    name_4 = 'fnord'
    name_5 = 'fnord'
    name_6 = 'fnord'
    name_7 = 'fnord'
    name_8 = 'fnord'
    name_9 = 'fnord'
    name_10 = 'fnord'
    name_11 = 'fnord'
    name_12 = 'fnord'
    name_13 = 'fnord'
    name_14 = 'fnord'
    name_15 = 'fnord'
    name_16 = 'fnord'
    name_17 = 'fnord'
    name_18 = 'fnord'

# Generated at 2022-06-25 21:32:37.184026
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    abstract_field_0 = AbstractField()
    # print(abstract_field_0('__call__'))


# Generated at 2022-06-25 21:32:38.846511
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()


# Generated at 2022-06-25 21:32:41.976738
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    if '.' in test_AbstractField___call__.__module__:
        return
    abstract_field_0 = AbstractField()
    exception_raised_0 = False
    try:
        abstract_field_0.__call__()
    except UndefinedField:
        exception_raised_0 = True
    assert exception_raised_0
