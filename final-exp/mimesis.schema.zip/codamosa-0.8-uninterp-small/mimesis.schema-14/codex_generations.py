

# Generated at 2022-06-25 21:30:21.623507
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = Field()
    assert abstract_field_0('uuid') == 'ec72ddc5-c8d8-4e59-9b77-86b4c4e8da4d'



# Generated at 2022-06-25 21:30:31.510594
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_3 = AbstractField(
        providers=[
            'mimesis.builtins.Data',
        ]
    )
    __ = abstract_field_3('bool')  # type: ignore
    __ = abstract_field_3('bool', key=bool)  # type: ignore
    __ = abstract_field_3('bool', key=int)  # type: ignore
    value_1 = abstract_field_3('bool')  # type: ignore
    value_2 = abstract_field_3('bool', key=bool)  # type: ignore
    value_3 = abstract_field_3('bool', key=int)  # type: ignore
    assert value_1 == value_2
    assert value_1 != value_3
    abstract_field_4 = AbstractField()

# Generated at 2022-06-25 21:30:34.476195
# Unit test for method create of class Schema
def test_Schema_create():
    schema_0 = Schema(lambda : {'a': 'a'})
    result = schema_0.create()
    assert result[0]['a'] == 'a'

# Generated at 2022-06-25 21:30:44.484736
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.generic import Generic
    from mimesis.providers.internet import Internet 
    from mimesis.providers.address import Address 
    from mimesis.providers.person import Person 
    from mimesis.providers.phone import Phone 
    from mimesis.providers.datetime import Datetime 
    from mimesis.providers.file import File
    import random
    provider_list = [Generic('en'), Internet('en'), Address('en'), Person('en'), Phone('en'), Datetime('en'), File('en')]
    provider_list_1 = [Generic('ru'), Internet('ru'), Address('ru'), Person('ru'), Phone('ru'), Datetime('ru'), File('ru')]

# Generated at 2022-06-25 21:30:48.516512
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('credit_card.visa') == '4024007190868789'

# Generated at 2022-06-25 21:30:50.259746
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField()
    abstract_field.__call__('name')


# Generated at 2022-06-25 21:30:52.636733
# Unit test for method create of class Schema
def test_Schema_create():
    schema_0 = Schema(lambda : None)
    schema_0.create()



# Generated at 2022-06-25 21:30:56.341536
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Try to call method with name equal None
    try:
        abstract_field_0 = AbstractField()
        abstract_field_0(name = None)
        assert False
    except UndefinedField:
        assert True


# Generated at 2022-06-25 21:31:03.432885
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert AbstractField().__call__('name') == 'Isaac'
    assert AbstractField().__call__('name', key=str.capitalize) == 'Isaac'
    assert AbstractField().__call__('name.first_name') == 'Chris'
    assert AbstractField().__call__('name', last_name='Smith') == 'Isaac Smith'
    assert AbstractField().__call__('name.first_name', last_name='Smith') == 'Chris Smith'
    assert AbstractField().__call__('internet.username') == 'ci_smith'


# Generated at 2022-06-25 21:31:05.298195
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field = AbstractField()
    assert isinstance(abstract_field, AbstractField)
    assert abstract_field.locale == "en"
