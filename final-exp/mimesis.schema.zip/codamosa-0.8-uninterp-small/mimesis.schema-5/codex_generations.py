

# Generated at 2022-06-25 21:30:39.864540
# Unit test for method create of class Schema
def test_Schema_create():
    schema_0 = Schema({})
    schema_0.create()


# Generated at 2022-06-25 21:30:43.132585
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda: {'a': 1})
    assert schema.create(3), [{'a': 1}, {'a': 1}, {'a': 1}]


# Generated at 2022-06-25 21:30:48.887626
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema"""
    test_schema_obj = Schema({"test": 1})
    test_schema_obj.create(10)



# Generated at 2022-06-25 21:30:52.765723
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_2 = AbstractField()
    result = abstract_field_2('lorem', n=9, n_var=6)
    assert isinstance(result, str)
    assert len(result.split()) == 9


# Generated at 2022-06-25 21:30:56.145599
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema, Field
    from mimesis.schema.schemas import Address
    schema_0 = Schema(Address)
    schema_0.create()

# Generated at 2022-06-25 21:31:00.688204
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    locale = 'en'
    seed = None
    providers = None
    abstract_field_0 = AbstractField(locale, seed, providers)
    name = ''
    key = None
    kwargs = {}
    assert_exception(UndefinedField, abstract_field_0, name, key, **kwargs)
    assert_exception(UnacceptableField, abstract_field_0, 'too.many.tails', key, **kwargs)
    assert_exception(UnacceptableField, abstract_field_0, 'no.such.field', key, **kwargs)
    assert_exception(UnsupportedField, abstract_field_0, 'not.supported.field', key, **kwargs)
    assert isinstance(abstract_field_0('_', key, **kwargs), str)

# Generated at 2022-06-25 21:31:02.795624
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0('first_name', '__call__')


# Generated at 2022-06-25 21:31:11.007694
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    abstract_field_0 = AbstractField()
    abstract_field_0(arg0=2, arg1=2, arg2=3, arg3=1, arg4=1, arg5=1, arg6=1)
    abstract_field_0(arg0=False, arg1=False, arg2=False, arg3=False, arg4=False, arg5=False)
    abstract_field_0(arg0=False, arg1=False, arg2=False, arg3=False, arg4=False, arg5=False)
    abstract_field_0(arg0=False, arg1=False, arg2=False, arg3=False, arg4=False, arg5=False)

# Generated at 2022-06-25 21:31:13.681882
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()

    assert abstract_field_0('age') >= 0
    method_name = 'numerify'
    assert getattr(abstract_field_0(method_name), method_name)
    assert abstract_field_0('age', key=lambda x: x) >= 0


# Generated at 2022-06-25 21:31:14.694140
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert True is not False
