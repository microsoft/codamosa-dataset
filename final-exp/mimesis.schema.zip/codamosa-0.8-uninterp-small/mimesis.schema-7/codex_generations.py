

# Generated at 2022-06-25 21:30:42.800937
# Unit test for method create of class Schema
def test_Schema_create():
    # Define schema
    schema = Schema(lambda: {
        'name': Field('person.name'),
        'surname': Field('person.surname'),
        'age': Field('integer'),
        'sex': Field('person.sex'),
        'favorite_color': Field('color.color_name'),
        'birthday': Field('datetime.date', start=1940, end=2000),
    })

    # Generate 5 instances of schema
    data = schema.create(5)
    for item in data:
        print(item)

    # Output:
    # {'name': 'Dennis', 'surname': 'Moss', 'age': 88, 'sex': 'Male', 'favorite_color': 'Green', 'birthday': datetime.date(1959, 8, 27)}
    # {'name':

# Generated at 2022-06-25 21:30:51.773882
# Unit test for method create of class Schema
def test_Schema_create():
    expected_result = [{'id': 1, 'price': '1.6', 'quantity': 1}]
    schema_0 = {'id': 1, 'price': 1.6, 'quantity': 1}
    schema_1 = Schema(lambda: schema_0)
    result_1 = schema_1.create()
    assert result_1 == expected_result, result_1


# Generated at 2022-06-25 21:31:02.084164
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField()
    abstract_field_2 = AbstractField()
    abstract_field_3 = AbstractField()
    abstract_field_4 = AbstractField()
    abstract_field_5 = AbstractField()
    abstract_field_6 = AbstractField()
    abstract_field_7 = AbstractField()
    abstract_field_8 = AbstractField()
    abstract_field_9 = AbstractField()
    abstract_field_10 = AbstractField()
    abstract_field_11 = AbstractField()
    abstract_field_12 = AbstractField()
    abstract_field_13 = AbstractField()
    abstract_field_14 = AbstractField()
    abstract_field_15 = AbstractField()
    abstract_field_16 = AbstractField()
    abstract_field_17 = AbstractField()
   

# Generated at 2022-06-25 21:31:04.131282
# Unit test for method create of class Schema
def test_Schema_create():
    schema_0 = Schema(test_case_0)
    assert isinstance(schema_0.create(iterations=0), list)

# Generated at 2022-06-25 21:31:06.132040
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField()
    result = abstract_field('choice', [1, 2, 3])

    assert result in [1, 2, 3]

# Generated at 2022-06-25 21:31:06.648935
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert abstract_field_0



# Generated at 2022-06-25 21:31:08.115299
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField(locale='ru')
    assert abstract_field_0.locale == 'ru'

# Generated at 2022-06-25 21:31:11.187655
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    abstract_field_0 = AbstractField()

    try:
        result = (abstract_field_0())
    except Exception:
        print('Raise UndefinedField()')
    else:
        print('Unexpected behavior: {0}'.format(result))



# Generated at 2022-06-25 21:31:14.501045
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField(locale='fr', seed=561)

    expected_result_0 = abstract_field_0('word', unique=False)
    expected_result_1 = abstract_field_0('word', unique=True)

    assert expected_result_0 == 'mois'
    assert expected_result_1 == 'pays'



# Generated at 2022-06-25 21:31:15.239174
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()