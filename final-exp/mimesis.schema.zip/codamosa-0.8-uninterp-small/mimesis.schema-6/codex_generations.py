

# Generated at 2022-06-25 21:30:47.305944
# Unit test for method create of class Schema
def test_Schema_create():
    schema_0 = Schema(lambda: None)
    schema_1 = Schema(lambda: None)
    schema_2 = Schema(lambda: None)
    dict_0 = {'f': lambda: None}
    dict_1 = {'f': abstract_field_0}
    dict_2 = {'f': abstract_field_0}
    dict_3 = {'f': abstract_field_0}
    dict_4 = {}
    dict_5 = {'a': abstract_field_0,
              'b': abstract_field_0,
              'c': abstract_field_0,
              'd': abstract_field_0,
              'e': abstract_field_0}

# Generated at 2022-06-25 21:30:49.017761
# Unit test for constructor of class AbstractField
def test_AbstractField():
    print('Call constructor of class AbstractField')
    test_case_0()

# Generated at 2022-06-25 21:30:59.848915
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    abstract_field_2 = AbstractField()
    abstract_field_3 = AbstractField()
    abstract_field_4 = AbstractField()
    abstract_field_5 = AbstractField()
    abstract_field_6 = AbstractField()
    abstract_field_7 = AbstractField()
    abstract_field_8 = AbstractField()
    abstract_field_9 = AbstractField()
    abstract_field_10 = AbstractField()
    abstract_field_11 = AbstractField()
    abstract_field_12 = AbstractField()
    abstract_field_13 = AbstractField()
    abstract_field_14 = AbstractField()
    abstract_field_15 = AbstractField()
    abstract_field_16 = AbstractField()
    abstract_field_17 = AbstractField()
    abstract_field_18 = AbstractField()
   

# Generated at 2022-06-25 21:31:07.743639
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    argument_1_0 = abstract_field_0('name')
    argument_2_0 = abstract_field_0('name', key=str.capitalize)
    argument_3_0 = abstract_field_0('name', sex='male')
    argument_4_0 = abstract_field_0('name', sex='male', key=str.capitalize)
    argument_5_0 = abstract_field_0('name', sex='male', key=str.capitalize, weight=10)
    argument_6_0 = abstract_field_0('name', sex='male', key=str.capitalize, weight=10, key=str.upper)


# Generated at 2022-06-25 21:31:09.101929
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__()
    

# Generated at 2022-06-25 21:31:11.938622
# Unit test for method create of class Schema
def test_Schema_create():
    # Default argument
    obj0 = Schema(test_Schema_create)
    assert obj0.create() is not None
    # First argument
    obj1 = Schema(test_Schema_create)
    assert obj1.create(1) is not None

# Generated at 2022-06-25 21:31:12.991687
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0("name") == 'Santino'


# Generated at 2022-06-25 21:31:32.420887
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    assert str(abstract_field_0) == 'AbstractField <en>'
    abstract_field_0._table['name'].__name__
    abstract_field_0._gen.__getattribute__('random')
    abstract_field_0._gen.__getattribute__('address')
    abstract_field_0._gen.__getattribute__('datetime')
    abstract_field_0._gen.__getattribute__('internet')
    abstract_field_0._gen.__getattribute__('payload')
    abstract_field_0._gen.__getattribute__('text')
    abstract_field_0._gen.__getattribute__('person')
    abstract_field_0._gen.__getattribute__('user_agent')
    abstract_field_0._gen.__getattribute

# Generated at 2022-06-25 21:31:37.228885
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    def key(result):
        return result
    assert abstract_field_0("ctime","en",key=key) is not None

# Generated at 2022-06-25 21:31:38.322316
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert test_case_0() is None

# Generated at 2022-06-25 21:32:28.470914
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_6 = AbstractField()
    abstract_field_6(None) == None


# Generated at 2022-06-25 21:32:30.473407
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = Field()
    abstract_field_0('FullName', gender='female')
    abstract_field_0('Title', gender='male')
    abstract_field_0('City')



# Generated at 2022-06-25 21:32:35.738607
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField(locale='ru')
    abstract_field_2 = AbstractField(seed=123)
    abstract_field_3 = AbstractField(providers=[])
    abstract_field_4 = AbstractField(locale='en', seed=123)
    abstract_field_5 = AbstractField(locale='en', providers=[])
    abstract_field_6 = AbstractField(seed=123, providers=[])
    abstract_field_7 = AbstractField(locale='en', seed=123, providers=[])


# Generated at 2022-06-25 21:32:37.250348
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__()


# Generated at 2022-06-25 21:32:40.510228
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    assert abstract_field_0.locale == 'en'
    assert abstract_field_0.seed is None
    assert abstract_field_0._gen is not None
    assert abstract_field_0._table is not None


# Generated at 2022-06-25 21:32:41.811732
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0('valid_method_name')


# Generated at 2022-06-25 21:32:49.539175
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField(locale="en", seed="fb5c5e5d-e0e5-4dad-9ae9-18a1fbea7be3")
    # assert abstract_field_0('_') == <ValueError('Undefined field',) raised>

    abstract_field_0 = AbstractField(locale="en", seed="54f6a05d-aefc-4a00-b65e-a06a6f2cd8a4")
    # assert abstract_field_0('_', _=_) == <ValueError('Undefined field',) raised>

    abstract_field_0 = AbstractField(locale="en", seed="2130c6ad-96ad-46a6-8e8b-d1c19a6f162f")
    # assert abstract_

# Generated at 2022-06-25 21:32:50.968300
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__(name='name')


# Generated at 2022-06-25 21:32:52.090928
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # check that __init__ method of AbstractField is ok
    assert test_case_0() is None

# Generated at 2022-06-25 21:32:54.476162
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()  # noqa
    name = 'id'
    str_0 = abstract_field_0(name)
    assert isinstance(str_0, str)
    assert str_0 != ''


# Generated at 2022-06-25 21:33:11.878584
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Case 0:
    # Test when abstract_field_0.__call__()

    test_case_0()



# Generated at 2022-06-25 21:33:13.719619
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    try:
        abstract_field_0.__call__()
        assert False
    except UndefinedField:
        assert True
    else:
        assert False


# Generated at 2022-06-25 21:33:15.133309
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__('build_utc_date')



# Generated at 2022-06-25 21:33:22.578700
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField()
    abstract_field("personal.gender")
    abstract_field("personal.gender", format="short")
    abstract_field("personal.gender", format="full")
    abstract_field("personal.full_name")
    abstract_field("personal.full_name", gender="male")
    abstract_field("personal.full_name", gender="female")
    abstract_field("personal.full_name", with_middle_name=True)
    abstract_field("personal.full_name", with_last_name=False)
    abstract_field("personal.full_name", with_prefix=True)
    abstract_field("personal.full_name", with_suffix=True)
    abstract_field("personal.full_name", with_title=True)

# Generated at 2022-06-25 21:33:26.392558
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    method_name_0 = abstract_field_0.__call__()
    method_name_1 = abstract_field_0.__call__(name = 'name')
    method_name_2 = abstract_field_0.__call__(name = 'name', key = None)
    method_name_3 = abstract_field_0.__call__(name = 'name', key = None, **kwargs)

# Generated at 2022-06-25 21:33:28.692446
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    try:
        abstract_field_0.__call__('name', key=None)
    except Exception as e:
        print(str(e) == "UndefinedField('Field is undefined.')")


# Generated at 2022-06-25 21:33:34.940236
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    abstract_field_1('name')
    abstract_field_1(name='name')
    abstract_field_1('name', key=str)
    abstract_field_1('name', key=str.capitalize)
    abstract_field_1('name', key=str.capitalize)
    abstract_field_1('name', key=lambda x: str(x).capitalize())
    abstract_field_1('name', key=lambda x: str(x).capitalize())
    abstract_field_1('name', key=lambda x: str(x).capitalize())
    abstract_field_1('name', key=lambda x: str(x).capitalize())
    abstract_field_1('name', key=lambda x: str(x).capitalize())

# Generated at 2022-06-25 21:33:38.387108
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField()
    abstract_field_2 = AbstractField()
    abstract_field_3 = AbstractField()

    try:
        abstract_field_0.__call__()
    except Exception as e:
        assert type(e) == UndefinedField


# Generated at 2022-06-25 21:33:44.670149
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.person import Person
    from mimesis.providers.useragent import UserAgent

    # initialization of abstract field
    f1 = AbstractField()
    f2 = AbstractField(locale='en')
    f3 = AbstractField(locale='ru', seed=5)
    f4 = AbstractField()
    f5 = AbstractField()

    # add providers
    f4._gen.add_providers(Person, UserAgent)
    f5._gen.add_providers(Person, UserAgent)

    # get result
    result1 = f1('name')
    result2 = f2('name')
    result3 = f3('name')
    result4 = f4('person.username')
    result5 = f5('name')

    # set expected results
    expected1 = 'Joey'

# Generated at 2022-06-25 21:33:46.898064
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField()
    abstract_field.__call__('hello')


# Generated at 2022-06-25 21:34:07.388857
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__("name")
    abstract_field_0.__call__("name", "name")


# Generated at 2022-06-25 21:34:15.842551
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # see all assertions:
    # print(AbstractField.__call__.assertions__)
    # print(AbstractField.__call__.assertions__[1].source)
    # print(AbstractField.__call__.assertions__[2].source)
    assert AbstractField.__call__.assertions__[0].source == "assert key is None"
    assert AbstractField.__call__.assertions__[1].source == "assert name is None"
    assert AbstractField.__call__.assertions__[2].source == "assert name in self._table"


# Generated at 2022-06-25 21:34:25.170460
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField()
    abstract_field_2 = AbstractField()
    abstract_field_2 = AbstractField()
    abstract_field_3 = AbstractField()
    try:
        abstract_field_0.__call__({})
    except UndefinedField:
        pass
    try:
        abstract_field_1.__call__('', {'1': 8.797059045973984e-307})
    except UnsupportedField:
        pass
    try:
        abstract_field_2.__call__('1', {'key': float('2.0')})
    except UnsupportedField:
        pass

# Generated at 2022-06-25 21:34:29.336718
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field_0 = AbstractField()

    field_0.__call__(name='full_name')
    field_0.__call__(name='full_name', gender='male')
    field_0.__call__(name='full_name', gender='female')
    field_0.__call__(name='full_name', gender='male', key=str.lower)
    field_0.__call__(name='full_name', gender='female', key=str.lower)

# Generated at 2022-06-25 21:34:41.267739
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # the method __call__ should raise an error when name is None
    assert AbstractField().__call__() is None
    # the method __call__ should raise an error when name is None
    assert AbstractField().__call__('The name') is None
    # the method __call__ should raise an error when name is None
    assert AbstractField().__call__('The name', TheKey='') is None
    # the method __call__ should raise an error when name is None
    assert AbstractField().__call__(name='The name') is None
    # the method __call__ should raise an error when name is None
    assert AbstractField().__call__(name='The name', TheKey='') is None
    # the method __call__ should raise an error when name is None
    assert AbstractField().__call__(key='The Key') is None


# Generated at 2022-06-25 21:34:42.507343
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField(locale='en')
    str_0 = abstract_field_0(name='name', key=None, gender='male')


# Generated at 2022-06-25 21:34:48.655298
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    __call__ = AbstractField.__call__

    # Test if UnacceptableField is raised
    try:
        __call__('arbitrary_string', key='arbitrary_string')
    except UnacceptableField:
        pass
    else:
        pass

    # Test if UndefinedField is raised
    try:
        __call__(key='arbitrary_string')
    except UndefinedField:
        pass
    else:
        pass

    # Test if UnsupportedField is raised
    try:
        __call__('arbitrary_string', key='arbitrary_string')
    except UnsupportedField:
        pass
    else:
        pass

# Generated at 2022-06-25 21:34:56.204490
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Case 0
    abstract_field_0 = AbstractField(locale='ru')
    abstract_field_0.__call__(name='race.race')
    abstract_field_0.__call__(name='artist.artist', key=lambda e: e[0])

    # Case 1
    abstract_field_1 = AbstractField(locale='en')
    abstract_field_1.__call__(name='datetime.year', start=1900, end=2100)
    abstract_field_1.__call__(name='datetime.month')
    abstract_field_1.__call__(name='datetime.day', start=1, end=31)


# Generated at 2022-06-25 21:35:03.619702
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0('user_agent', key=lambda x: len(x))
    abstract_field_0('user_agent')
    abstract_field_0('user_agent', key=lambda x: len(x))
    abstract_field_0('user_agent', key=lambda x: len(x))
    abstract_field_0('user_agent')
    abstract_field_0('user_agent')
    abstract_field_0('user_agent')
    abstract_field_0('user_agent', key=lambda x: x[0])
    abstract_field_0('user_agent')
    abstract_field_0('user_agent', key=lambda x: x[0])
    abstract_field_0('user_agent', key=lambda x: len(x))
    abstract

# Generated at 2022-06-25 21:35:04.243662
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    test_case_0()



# Generated at 2022-06-25 21:35:31.725614
# Unit test for method __call__ of class AbstractField

# Generated at 2022-06-25 21:35:36.728041
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('person.name') == 'Adriana'
    assert abstract_field_0('person.full_name') == 'Deborah R. Carver'
    assert abstract_field_0('person.name', gender='female') == 'Jessica'
    assert abstract_field_0('person.full_name', gender='female') == 'Ruth N. Goldstein'
    assert abstract_field_0('person.name', gender='male') == 'Mark'
    assert abstract_field_0('person.full_name', gender='male') == 'Victor M. Payne'
    assert abstract_field_0('person.full_name',
            first_name_position='postfix') == 'D. Tyson Myers'

# Generated at 2022-06-25 21:35:38.252498
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    # In this case, the method __call__ with keyword arguments is called
    assert callable(abstract_field_1.__call__)


# Generated at 2022-06-25 21:35:39.149667
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0._gen is not None


# Generated at 2022-06-25 21:35:41.908982
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField()
    abstract_field_0.__call__()
    abstract_field_1.__call__()


# Generated at 2022-06-25 21:35:43.590413
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('date', '2019-04-15') == '2019-04-15'
    assert abstract_field_0('integer', minimum=10, maximum=20) == 15


# Generated at 2022-06-25 21:35:49.394788
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    string_0 = abstract_field_1.__call__('String')
    assert isinstance(string_0, str)

    abstract_field_2 = AbstractField()
    result_0 = abstract_field_2.__call__('String', 2)
    assert isinstance(result_0, str)
    assert len(result_0) == 2

    abstract_field_3 = AbstractField()
    result_1 = abstract_field_3.__call__('String', length=2)
    assert isinstance(result_1, str)
    assert len(result_1) == 2

    abstract_field_4 = AbstractField()
    with raises(UndefinedField):
        abstract_field_4.__call__()

    abstract_field_5 = AbstractField()

# Generated at 2022-06-25 21:35:55.858556
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert AbstractField().__call__('name', key=str.title) == 'Name'
    assert AbstractField().__call__('name') == 'name'
    assert AbstractField().__call__('choice', choices=['1', '2', '3']) == '2'
    assert AbstractField().__call__('name',
                                    key=lambda x: f'{x}-{x}') == 'name-name'
    assert AbstractField().__call__('email') == 'igornovikow@bk.ru'
    assert AbstractField().__call__(
        'ipv4',
        key=lambda x: '{}'.format(x)
    ) == '192.168.0.1'

# Generated at 2022-06-25 21:35:58.204180
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    res = field(name="random_int", a=1, b=100, key=int)
    assert isinstance(res, int)


# Generated at 2022-06-25 21:35:59.491347
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0('email')
    abstract_field_0('email', domain='ya.ru')


# Generated at 2022-06-25 21:36:50.780095
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__("")
    abstract_field_0.__call__("", key=lambda x: x)
    abstract_field_0.__call__("", key=lambda x: x)
    abstract_field_0.__call__("", key=lambda x: x)


# Generated at 2022-06-25 21:36:51.918198
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    a = AbstractField()

    assert a('camera_make', key=lambda s: s.replace('_', ' ')) is not None



# Generated at 2022-06-25 21:36:52.987596
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__(name='name')


# Generated at 2022-06-25 21:37:07.410635
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__('', key=int)
    abstract_field_0.__call__('', key=int, _seed=None)
    abstract_field_0.__call__('', key=int, _seed=None, digits=None)
    abstract_field_0.__call__('', key=int, _seed=None, digits=None, padding=None)
    abstract_field_0.__call__('', key=int, _seed=None, digits=None, padding=None, upper=None)
    abstract_field_0.__call__('', key=int, _seed=None, digits=None, padding=None, upper=None, safe=None)

# Generated at 2022-06-25 21:37:08.268772
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    obj = AbstractField()
    # assert obj.__call__('name') == 'Raleigh'


# Generated at 2022-06-25 21:37:12.905152
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField()
    abstract_field_0.locale = abstract_field_1.locale
    abstract_field_0.seed = abstract_field_1.seed
    abstract_field_0._gen = abstract_field_1._gen
    abstract_field_0._table = abstract_field_1._table

    # Test raises exception on AbstractField.__call__(abstract_field_1, None, None)
    try:
        AbstractField.__call__(abstract_field_1, None, None)
    except UndefinedField as raised_exception_0:
        assert type(raised_exception_0) is UndefinedField

    # Test raises exception on AbstractField.__call__(abstract_field_1, '', None)

# Generated at 2022-06-25 21:37:13.975326
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__(name="credit_card_number")  # real data


# Generated at 2022-06-25 21:37:18.250977
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('__call__', key=lambda x: type(x).__name__)
    assert abstract_field_0('__call__', key=lambda x: type(x).__name__) == 'instancemethod'
    assert abstract_field_0('__call__', key=lambda x: type(x).__name__) == 'instancemethod'

# Generated at 2022-06-25 21:37:21.122977
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField('en')
    abstract_field_1('py')
    abstract_field_1('username')
    abstract_field_1('username', minimum_size=10)
    abstract_field_1('username', key=lambda x: x)
    abstract_field_1('choice')

# Generated at 2022-06-25 21:37:26.882751
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()

    if "." in abstract_field_0(name='generic.password', length=8):
        pass
    else:
        print("AbstractField::__call__: Failed")
    if "." in abstract_field_0(name='generic.uuid4'):
        pass
    else:
        print("AbstractField::__call__: Failed")
    if "." in abstract_field_0(name='regex.'):
        pass
    else:
        print("AbstractField::__call__: Failed")
    if "." in abstract_field_0(name='regex.password', length=8):
        pass
    else:
        print("AbstractField::__call__: Failed")
    if "." in abstract_field_0(name='regex.uuid4'):
        pass

# Generated at 2022-06-25 21:38:55.021748
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    import unittest
    from mimesis.enums import Gender
    from mimesis.exceptions import UnsupportedField
    from mimesis.exceptions import UnacceptableField

    class TestAbstractField___call__(unittest.TestCase):
        def setUp(self):
            self.field_0 = AbstractField()
            self.field_1 = AbstractField()
            self.field_2 = AbstractField()
            self.field_3 = AbstractField()
            self.field_4 = AbstractField()
            self.field_5 = AbstractField()
            self.field_6 = AbstractField()

        def test_0(self):
            with self.assertRaises(UndefinedField):
                self.field_0()
            with self.assertRaises(UnsupportedField):
                self.field_0('abcd')


# Generated at 2022-06-25 21:38:59.013496
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Arrange
    abstract_field_0 = AbstractField()

    # Act
    assert abstract_field_0.__call__()

# Arrange
abstract_field_0 = AbstractField()

try:
    # Act
    abstract_field_0.__call__()
except Exception as exception_0:
    # Assert
    assert type(exception_0).__name__ == 'UndefinedField'

try:
    # Act
    abstract_field_0.__call__()
except Exception as exception_0:
    # Assert
    assert type(exception_0).__name__ == 'UndefinedField'

# Generated at 2022-06-25 21:38:59.543864
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert AbstractField()('name') != None


# Generated at 2022-06-25 21:39:00.650715
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('email') is not None
    assert abstract_field_0('random_email') is not None


# Generated at 2022-06-25 21:39:01.802617
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField(locale=str(), seed=1)
    assert abstract_field_0('strange method') is None


# Generated at 2022-06-25 21:39:03.111246
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert False, "Not implemented"

# Generated at 2022-06-25 21:39:04.607827
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    field('boo', key = lambda x: x.upper())
    assert field('boo', key = lambda x: x.upper())


# Generated at 2022-06-25 21:39:05.391621
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField()



# Generated at 2022-06-25 21:39:07.688971
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0('foo')
    abstract_field_1 = AbstractField(locale='ru', seed=0)
    abstract_field_1('foo')


# Generated at 2022-06-25 21:39:13.008363
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.generic import Generic
    from mimesis.providers.numbers import Numbers

    abstract_field_1 = AbstractField(providers=[Cryptographic,
    Numbers])
    result_1 = abstract_field_1('sha1_hash', length=1)
    assert isinstance(result_1, str)

    abstract_field_2 = AbstractField(providers=[Generic, Numbers])
    result_2 = abstract_field_2('choice', seq=['a'])
    assert isinstance(result_2, str)

    abstract_field_3 = AbstractField(providers=[Cryptographic,
    Numbers])
    result_3 = abstract_field_3('sha1_hash', length=1, key=str.upper)