

# Generated at 2022-06-25 21:30:21.624121
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField(locale='en', seed=None, providers=None)
    abstract_field_2 = AbstractField(locale='en', seed=None, providers=[])
    abstract_field_3 = AbstractField(locale='en', seed=None, providers=[str])
    abstract_field_4 = AbstractField(locale='en', seed=None, providers=[str,])
    assert abstract_field_0('identifier')
    assert abstract_field_1('identifier')
    assert abstract_field_2('identifier')
    assert abstract_field_3('identifier')
    assert abstract_field_4('identifier')

# Unit test class Schema

# Generated at 2022-06-25 21:30:23.072331
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__()



# Generated at 2022-06-25 21:30:32.018266
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    assert abstract_field_0.locale == 'en'
    assert abstract_field_0.seed is None

    abstract_field_1 = AbstractField(locale='ru')
    assert abstract_field_1.locale == 'ru'
    assert abstract_field_1.seed is None

    abstract_field_2 = AbstractField(locale='zh')
    assert abstract_field_2.locale == 'zh'
    assert abstract_field_2.seed is None

    abstract_field_3 = AbstractField(seed=23)
    assert abstract_field_3.locale == 'en'
    assert abstract_field_3.seed == 23


# Generated at 2022-06-25 21:30:37.450100
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema
    schema_0 = Schema(SchemaType)
    iterations_0 = 1
    # Call method with given arguments
    list_0 = schema_0.create(iterations_0)
    assert list_0 != None and len(list_0) == iterations_0


# Generated at 2022-06-25 21:30:40.066931
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    name_0 = 'method'
    try:
        abstract_field_0(name_0)
    except UndefinedField:
        pass


# Generated at 2022-06-25 21:30:44.445909
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    # noinspection PyUnresolvedReferences
    str(abstract_field_0)
    abstract_field_0.__str__()

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()



# Generated at 2022-06-25 21:30:47.417381
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert AbstractField('ru', '0.0')


# Generated at 2022-06-25 21:30:58.354355
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    field = AbstractField()

    def test_case_1():
        result = field('first_name')

    def test_case_2():
        result = field('first_name', gender='male')

    def test_case_3():
        result = field('__x', role='guest')  # UndefinedField error

    def test_case_4():
        result = field('__x.__y', age=18)  # UndefinedField error

    def test_case_5():
        result = field('timezones.__x', age=18)  # UnacceptableField error

    def test_case_6():
        result = field(name='internet.domain_name')

    def test_case_7():
        result = field(name='internet.__x')  # UnsupportedField error


# Generated at 2022-06-25 21:31:07.122744
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField(pr=None)
    abstract_field_2 = AbstractField('en')
    assert (abstract_field_0.locale == 'en')
    assert(abstract_field_1.locale == 'en')
    assert(abstract_field_2.locale == 'en')
    assert (abstract_field_0.seed is None)
    assert (abstract_field_1.seed is None)
    assert (abstract_field_2.seed is None)
    assert(not abstract_field_0.seed)
    assert(not abstract_field_1.seed)
    assert(not abstract_field_2.seed)



# Generated at 2022-06-25 21:31:08.525390
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field = AbstractField(locale="en")
    assert abstract_field is not None



# Generated at 2022-06-25 21:31:37.811494
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert AbstractField
    assert AbstractField.__init__
    assert AbstractField.__call__


# Generated at 2022-06-25 21:31:46.542008
# Unit test for method create of class Schema
def test_Schema_create():
    import pytest

    from mimesis.schema import Schema

    from mimesis.schema import Field

    from mimesis.enums import Gender

    def schema(field: Field) -> Any:
        return field(
            'full_name',
            gender=Gender.MALE,
        )

    test_schema_0 = Schema(schema)
    result_0 = test_schema_0.create(iterations=5)

    test_schema_1 = Schema(schema)
    result_1 = test_schema_1.create(iterations=5)

    assert (
        len(result_0) == 5
        and len(result_1) == 5
        and len(set(result_0)) == 5
        and len(set(result_1)) == 5
    )


# Generated at 2022-06-25 21:31:47.536926
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        test_case_0()
    except TypeError as e:
        assert str(e) == ''
    else:
        assert False

# Generated at 2022-06-25 21:31:48.987595
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    result = field('item')

    if type(result) is not str:
        raise AssertionError('Wrong type of result. It should be "str"')


# Generated at 2022-06-25 21:31:51.162417
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    assert abstract_field_0.locale == 'en'
    assert abstract_field_0.seed is None
    assert abstract_field_0._gen is not None
    assert abstract_field_0._table == {}


# Generated at 2022-06-25 21:31:52.788747
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    abstract_field = AbstractField('ru')

    abstract_field = AbstractField()



# Generated at 2022-06-25 21:31:54.216111
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    result_1 = abstract_field_1("field_name")
    assert result_1



# Generated at 2022-06-25 21:31:57.523420
# Unit test for method create of class Schema
def test_Schema_create():
    # Create instance of class Schema
    schema_0 = Schema(lambda: { 'test_key': 'test_value' })

    # Create list of a filled schemas with elements in an amount of 10
    schema_0.create(iterations = 10)


# Generated at 2022-06-25 21:31:58.832819
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    str_0 = abstract_field_0('')



# Generated at 2022-06-25 21:31:59.829835
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()


# Generated at 2022-06-25 21:32:18.103672
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert abstract_field_0 is not None

# Generated at 2022-06-25 21:32:19.772550
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__("a", key=lambda result: result)


# Generated at 2022-06-25 21:32:24.030925
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Constructor test"""
    locale = 'test'
    seed = 'test'
    providers = 'test'
    abstract_field_0 = AbstractField(locale, seed, providers)
    assert abstract_field_0.locale == 'test'
    assert abstract_field_0.seed == 'test'



# Generated at 2022-06-25 21:32:29.542257
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_1 = AbstractField()
    assert abstract_field_1.locale == 'en'
    assert abstract_field_1.seed is None

    abstract_field_2 = AbstractField(locale='ru')
    assert abstract_field_2.locale == 'ru'

    abstract_field_3 = AbstractField(seed=123)
    assert abstract_field_3.seed == 123

    providers = [1]
    abstract_field_4 = AbstractField(providers=providers)
    assert abstract_field_4._gen.providers == providers


# Generated at 2022-06-25 21:32:32.119593
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert test_case_0.__name__ == "test_case_0"
    assert hasattr(abstract_field_0,"__init__")
    assert isinstance(abstract_field_0,AbstractField)


# Generated at 2022-06-25 21:32:33.453352
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    str_result_0 = str(abstract_field_0)


# Generated at 2022-06-25 21:32:35.988923
# Unit test for constructor of class AbstractField
def test_AbstractField():
    with pytest.raises(UndefinedField) as e:
        abstract_field_0 = AbstractField()
        abstract_field_0.__call__()
    assert str(e.value) == 'Field not defined.'



# Generated at 2022-06-25 21:32:38.846833
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()

    assert abstract_field_0('cc_number') == '6277639159176401'


# Generated at 2022-06-25 21:32:41.713615
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.exceptions import UndefinedField
    from mimesis.schema import AbstractField
    abstract_field_0 = AbstractField()
    try:
        abstract_field_0()
    except UndefinedField:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-25 21:32:42.787438
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()


# Generated at 2022-06-25 21:33:13.249694
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert abstract_field_0.__call__('BadName').startswith('mimesis')

# Generated at 2022-06-25 21:33:14.451590
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('_str') is not None


# Generated at 2022-06-25 21:33:15.377812
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()


# Generated at 2022-06-25 21:33:17.885618
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    str_0 = abstract_field_0(name='lorem.word')


# Generated at 2022-06-25 21:33:19.131302
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field__call__ = AbstractField()
    assert(isinstance(field__call__('',), str))


# Generated at 2022-06-25 21:33:20.317659
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__('person')

# Generated at 2022-06-25 21:33:21.527588
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field = AbstractField()
    assert isinstance(abstract_field, AbstractField)


# Generated at 2022-06-25 21:33:26.503956
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # simple 'Field' instances
    abstract_field_0 = AbstractField()
    result = abstract_field_0.__call__('choice', data=['one', 'two'])
    assert result in ['one', 'two']
    result = abstract_field_0.__call__('choice', key=str.capitalize, data=['one', 'two'])
    assert result in ['One', 'Two']
    result = abstract_field_0.__call__('choice', key=str.lower, data=['one', 'two'])
    assert result in ['one', 'two']


# Generated at 2022-06-25 21:33:34.854530
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    def first_name():
        """Test first name."""
        abstract_field = AbstractField(locale='ru')
        f = abstract_field('first_name')
        # assert f in ['', '', '', '', '']
        assert f in ['Мартин', 'Ираида', 'Павел', 'Роман', 'Эмилий']

    # test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 21:33:36.699422
# Unit test for constructor of class AbstractField
def test_AbstractField():
    name = 'example.field'
    field = AbstractField()
    assert field.__call__(name) == 'example.field'


# Generated at 2022-06-25 21:34:39.483172
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    assert abstract_field_0._table == {}
    assert abstract_field_0.locale == 'en'
    assert abstract_field_0.seed == None



# Generated at 2022-06-25 21:34:42.439758
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field_0 = AbstractField()

    print(field_0('datetime.datetime'))
    print(field_0('timezone.zone'))
    print(field_0('timezone.zone', key=lambda x: x.split('/')[-1]))
    print(field_0('text.word'))
    print(field_0('text.slug'))

# Test case for callable object of class Schema

# Generated at 2022-06-25 21:34:43.250595
# Unit test for constructor of class AbstractField
def test_AbstractField():
    expected = AbstractField()
    assert expected is not None
test_AbstractField()


# Generated at 2022-06-25 21:34:51.855237
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField()
    abstract_field_2 = AbstractField()
    assert abstract_field_0.__call__('full_name') in ('Milton Nash', 'Yvonne Doyle', 'Bryan Sanders', 'Leroy Griffin', 'Patrick Morris', 'Gloria Young', 'Sue Barber', 'Herman Bishop', 'Florence Chapman', 'Rosie Jordan', 'Miguel Fuller', 'Terri Munoz', 'Dwight Warren', 'Adrian Quinn', 'Ruby Green', 'Stanley Patton', 'Teresa Spencer', 'Lester Arnold', 'David Pierce', 'Patsy Cunningham', 'Christine Warren')
    abstract_field_2.__call__('full_name')

# Generated at 2022-06-25 21:34:55.003317
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    # __call__() raises ValueError if field not defined
    try:
        abstract_field_0()
    except UndefinedField:
        pass



# Generated at 2022-06-25 21:35:01.579102
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():  # pylint: disable=redefined-outer-name
    test_cases = (
        ('1', "abstract_field_0.__call__('gps.latitude')"),
        ('2', "abstract_field_0.__call__('gps.latitude', angle=False)"),
        ('3', "abstract_field_0.__call__('gps.latitude', angle=True, dots=3)"),
        ('4', "abstract_field_0.__call__('gps.latitude', angle=True, dots=4, key=float)"),
    )
    for _, expr in test_cases:  # pylint: disable=unused-variable
        result = eval(expr)
        assert result is not None


# Generated at 2022-06-25 21:35:02.939118
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    assert abstract_field_1('address')


# Generated at 2022-06-25 21:35:06.112020
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    for _ in range(100):
        a_seed = Generic('en').seed
        a = AbstractField(seed=a_seed)
        b = AbstractField(seed=a_seed)
        actual = a('uuid4')
        expected = b('uuid4')
        assert expected == actual

        c = AbstractField('ru', seed=a_seed)
        assert a('uuid4') != c('uuid4')



# Generated at 2022-06-25 21:35:07.092427
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    assert abstract_field_1('safe_hex_color')


# Generated at 2022-06-25 21:35:19.779601
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('currency') == 'JOD'
    assert abstract_field_0('postal_code') == '4-624-723'
    assert abstract_field_0('postal_code', country_code='US') == '59339'
    assert abstract_field_0('address.country.code') == 'QA'
    assert abstract_field_0('datetime.datetime',
                            start='1970-01-01', end='2030-01-01') == '1993-03-18 11:19:40'
    assert abstract_field_0('bool') is True
    assert abstract_field_0('choice', items=['foo', 'bar', 'baz']) == 'baz'
    assert abstract_field_0('finance.iban')

# Generated at 2022-06-25 21:36:50.399925
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Case 0
    field0 = Generic.create_schema()
    assert callable(field0.address)
    assert field0.address('country') == 'France'

    # Case 1
    field1 = Generic.create_schema()
    assert field1.address('country') == 'California'

    # Case 2
    field2 = Generic.create_schema()
    assert field2.address('country') == 'United Kingdom'

    # Case 3
    field3 = Generic.create_schema()
    assert field3.address('country') == 'Montana'

    # Case 4
    field4 = Generic.create_schema()
    assert field4.address('country') == 'Florida'

    # Case 5
    field5 = AbstractField()
    assert callable(field5.address)


# Generated at 2022-06-25 21:36:51.627249
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        abstract_field_0 = AbstractField()
    except ValueError as e_0:
        print('Error in AbstractField constructor', e_0)


# Generated at 2022-06-25 21:36:52.693903
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    assert abs(abstract_field_0.__call__('int_')) <= 2147483647

# Generated at 2022-06-25 21:36:53.411680
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(AbstractField(), AbstractField)

# Generated at 2022-06-25 21:36:54.385092
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert isinstance(abstract_field_0.__call__('foo'), str) is True


# Generated at 2022-06-25 21:36:55.058249
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    filed = AbstractField()
    assert filed('is_bool') == True


# Generated at 2022-06-25 21:36:57.114425
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    name_0 = abstract_field_0.__call__()
    assert isinstance(name_0, str)
    name_0 = abstract_field_0.__call__(key=str.upper)
    assert isinstance(name_0, str)
