

# Generated at 2022-06-25 21:30:22.791837
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = Field()
    try:
        abstract_field()
    except UndefinedField:
        pass
    else:
        raise


# Generated at 2022-06-25 21:30:25.207425
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0('name')



# Generated at 2022-06-25 21:30:33.091328
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    names = ('en', 'ru', 'fr', 'ja', 'de', 'es')
    seeds = (0, 1, 2, 3, 4, 5, 6)
    assert isinstance(field, AbstractField)
    assert callable(field)
    for n, s in zip(names, seeds):
        f = AbstractField(locale=n, seed=s)
        assert f.locale == n, 'Fail {}'.format(n)
        assert f.seed == s, 'Fail {}'.format(s)
    assert field.locale == 'en'
    assert field.seed is None
    assert isinstance(field._gen, Generic)
    assert isinstance(field._table, dict)


# Generated at 2022-06-25 21:30:35.161111
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstractField0 = AbstractField()
    with raises(ValueError):
        abstractField0.__call__(None, key=None)


# Generated at 2022-06-25 21:30:38.969366
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Tests with AbstractField.__call__."""
    abstract_field_0 = AbstractField()
    try:
        assert abstract_field_0(None)
    except UndefinedField as error:
        assert error


# Generated at 2022-06-25 21:30:47.673559
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(test_case_0()._gen, Generic), \
        'Object is not an instance of Generic'
    assert isinstance(test_case_0()._gen._locale, str), \
        'Locale is not a string'
    assert hasattr(test_case_0()._gen, 'person'), \
        'Person provider is not exists'
    assert hasattr(test_case_0()._gen, 'datetime'), \
        'DataTime provider is not exists'
    assert hasattr(test_case_0()._gen, 'business'), \
        'Business provider is not exists'
    assert hasattr(test_case_0()._gen, 'code'), \
        'Code provider is not exists'

# Generated at 2022-06-25 21:30:58.596720
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor for class AbstractField"""
    field_0 = AbstractField()
    result = isinstance(field_0, AbstractField)
    assert result

    field_1 = AbstractField(locale='uk')
    assert field_1.locale == 'uk'

    field_2 = AbstractField(seed=4)
    assert field_2.seed == 4

    field_3 = AbstractField(locale='ru', seed=3)
    assert field_3.locale == 'ru'
    assert field_3.seed == 3

    field_4 = AbstractField(locale='fr', seed=1)
    assert field_4.locale == 'fr'
    assert field_4.seed == 1

    field_5 = AbstractField(locale='es', seed=94)
    assert field_5.locale == 'es'

# Generated at 2022-06-25 21:31:00.699149
# Unit test for constructor of class AbstractField
def test_AbstractField():
    expected = "AbstractField <en>"
    actual = str(AbstractField())
    assert expected == actual



# Generated at 2022-06-25 21:31:02.793770
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField(locale=str)
    assert abstract_field_0('choice', 'str')



# Generated at 2022-06-25 21:31:06.824098
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()

    abstract_field_0('name')
    abstract_field_0('name', k1='v1', k2='v2')
    abstract_field_0('name', key=lambda x: x)
    abstract_field_0('name', key=(lambda x: x))



# Generated at 2022-06-25 21:31:41.140475
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField(locale='en')
    abstract_field_2 = AbstractField(seed=12345)
    abstract_field_3 = AbstractField(locale='en', seed=12345)
    abstract_field_4 = AbstractField(providers=None)
    abstract_field_5 = AbstractField(providers=None, seed=12345)



# Generated at 2022-06-25 21:31:49.027727
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    assert str(abstract_field_0) == 'AbstractField <en>'
    assert abstract_field_0('personal.cpf', formatter='###.###.###-##') == '823.766.044-76'
    assert abstract_field_0('text.sentence') == 'Aperiam nostrum provident et voluptas tenetur.'
    with raises(UndefinedField): abstract_field_0()
    with raises(UndefinedField): abstract_field_0('')
    abstract_field_1 = AbstractField(locale='es')
    assert str(abstract_field_1) == 'AbstractField <es>'
    abstract_field_2 = AbstractField(seed='0')

# Generated at 2022-06-25 21:31:49.619770
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass


# Generated at 2022-06-25 21:31:51.656436
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField()  # type: AbstractField
    callable_0 = abstract_field_1()  # type: Callable
    str_0 = str(abstract_field_1)  # type: str

# Generated at 2022-06-25 21:31:52.105198
# Unit test for constructor of class AbstractField
def test_AbstractField():
    pass

# Generated at 2022-06-25 21:31:59.531177
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField(locale='en', seed=None)
    with raises(UndefinedField):
        abstract_field_0()

    abstract_field_1 = AbstractField(locale='en', seed=None)
    with raises(UnsupportedField):
        abstract_field_1(name='foo')

    abstract_field_2 = AbstractField(locale='en', seed=None)
    with raises(UnacceptableField):
        abstract_field_2(name='foo.bar.baz')

    abstract_field_3 = AbstractField(locale='en', seed=None)
    with raises(UnsupportedField):
        abstract_field_3(name='bad.name')

    abstract_field_4 = AbstractField(locale='en', seed=None)

# Generated at 2022-06-25 21:32:05.982660
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    af = AbstractField()
    v = af(name="postal_code")
    assert isinstance(v, str)
    assert len(v) == 5
    v = af(name="postal_code", key=lambda x: f"{x}-{x}")
    assert isinstance(v, str)
    assert len(v) == 11
    assert v[5] == "-"
    v = af(name="postal_code", key=lambda x: f"{x}")
    assert isinstance(v, str)
    assert len(v) == 5
    v = af(name="postal_code", key=lambda x: "postal_code")
    assert isinstance(v, str)
    assert v == "postal_code"

# Generated at 2022-06-25 21:32:11.970462
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField()

    abstract_field.__call__('uuid4')
    abstract_field.__call__('uuid4', hyphenate=True)

    abstract_field.__call__('uuid4', key=lambda x: x.upper())
    abstract_field.__call__('uuid4', key=str.upper)

    abstract_field.__call__('uuid4', key=lambda x: x.upper(), hyphenate=True)
    abstract_field.__call__('uuid4', key=str.upper, hyphenate=True)


# Generated at 2022-06-25 21:32:12.975458
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()


# Generated at 2022-06-25 21:32:20.641115
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    assert abstract_field_0.locale == 'en'  # type: ignore
    assert abstract_field_0.seed is None  # type: ignore
    assert abstract_field_0._gen.locale == 'en'  # type: ignore
    assert abstract_field_0._gen.seed is None   # type: ignore

    abstract_field_1 = AbstractField(locale='ru')
    assert abstract_field_1.locale == 'ru'  # type: ignore
    assert abstract_field_1.seed is None  # type: ignore
    assert abstract_field_1._gen.locale == 'ru'  # type: ignore
    assert abstract_field_1._gen.seed is None   # type: ignore

    abstract_field_2 = AbstractField(seed=42)
   

# Generated at 2022-06-25 21:32:49.269235
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.schema import AbstractField
    from mimesis.data import MUNICIPALITIES_RU
    from mimesis.enums import Gender
    from mimesis.providers import Address
    from mimesis.providers import Person
    from mimesis.providers import Business
    from mimesis.providers import Tools
    from mimesis.providers import Crypto
    from mimesis.providers import Internet
    from mimesis.providers import Code
    from mimesis.providers import Miscellaneous
    from mimesis.providers import Datetime
    from mimesis.providers import File
    from mimesis.providers import Science
    from mimesis.providers import Food
    from mimesis.providers import Payment
    from mimesis.providers import Sport

# Generated at 2022-06-25 21:32:55.715384
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # temp var to get the abstract_field_0
    abstract_field_0 = AbstractField()
    method_name = '__call__'
    args = ()
    kwargs = {}
    # this call will raise UndefinedField exception
    # because of the None name
    try:
        abstract_field_0.__call__()
    except UndefinedField as e:
        pass
    # this call will raise UndefinedField exception
    # because of the None name
    try:
        abstract_field_0.__call__(None)
    except UndefinedField as e:
        pass
    # this call will raise UndefinedField exception
    # because of the None name

# Generated at 2022-06-25 21:32:57.096410
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    try:
        abstract_field_0(None)
    except UndefinedField as e:
        pass

# Generated at 2022-06-25 21:32:59.631274
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('lowercase_hash') == '5e5c1f5e5c1f5e5c1f5e5c1f5e5c1f5e'


# Generated at 2022-06-25 21:33:01.012993
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField()


# Generated at 2022-06-25 21:33:02.555762
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    assert AbstractField()('person.full_name') == 'Katherine Mcdaniel'


# Generated at 2022-06-25 21:33:02.968429
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-25 21:33:05.416899
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    abstract_field_2 = AbstractField()
    abstract_field_2.__call__('__str__')


if __name__ == '__main__':
    test_case_0()
    test_AbstractField___call__()

# Generated at 2022-06-25 21:33:11.700210
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    try:
        abstract_field_0()
    except Exception as e:
        assert type(e) == UndefinedField
    try:
        abstract_field_0('__init__')
    except Exception as e:
        assert type(e) == UnsupportedField
    try:
        abstract_field_0('not_in_gen')
    except Exception as e:
        assert type(e) == UnsupportedField
    try:
        abstract_field_0('choice.choice')
    except Exception as e:
        assert type(e) == UnacceptableField
    try:
        import mimesis.providers.base as provider_0
    except Exception as e:
        assert type(e) == RuntimeError

# Generated at 2022-06-25 21:33:18.642778
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    result_0 = field('md5')
    result_1 = field(
        'faker.sex',
        formatter=lambda x: x.capitalize()
    )
    result_2 = field('currency.name')
    result_3 = field('faker.money')
    result_4 = field('faker.money', currency='rub')

    assert len(result_0) == 32
    assert result_0.isalnum() is True
    assert result_1 in ['Male', 'Female']
    assert isinstance(result_2, str) is True
    assert result_3.startswith('$') is True
    assert result_4.startswith('₽') is True


# Generated at 2022-06-25 21:34:01.596709
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    abstract_field_0 = AbstractField()

    try:
        assert abstract_field_0(None) is None
    except UndefinedField as e:
        print(e)
    except UnacceptableField as e:
        print(e)
    except UnsupportedField as e:
        print(e)
    except TypeError as e:
        print(e)
    except AttributeError as e:
        print(e)

    try:
        assert abstract_field_0('name', 1) is not None
    except UndefinedField as e:
        print(e)
    except UnacceptableField as e:
        print(e)
    except UnsupportedField as e:
        print(e)
    except TypeError as e:
        print(e)
    except AttributeError as e:
        print(e)


# Generated at 2022-06-25 21:34:02.614331
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0(name='pybool')


# Generated at 2022-06-25 21:34:04.646658
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    class Some(AbstractField):
        """This class used for test of AbstractField"""
        def __init__(self):
            super().__init__()

    # Create instance of Some
    inst = Some()
    # Call method
    inst(name='passport_series')

# Generated at 2022-06-25 21:34:06.472432
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    abstract_field_1("")
    abstract_field_1("", )
    abstract_field_1("", key = lambda x: x)
    abstract_field_1("", key = lambda x: x, )


# Generated at 2022-06-25 21:34:16.346558
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Create instance of class AbstractField
    abstract_field_1 = AbstractField()
    assert True, abstract_field_1.__call__('name')
    assert True, abstract_field_1.__call__('name', gender='male')
    assert True, abstract_field_1.__call__('random_element', data=('Hello', 'World'))
    assert True, abstract_field_1.__call__('random_element', data=('Hello', 'World'), key=str.upper)
    assert True, abstract_field_1.__call__('random_element', data=('Hello', 'World'), key=str.lower)
    assert True, abstract_field_1.__call__('random_element', data=('Hello', 'World'), key=str.title)

# Generated at 2022-06-25 21:34:19.582575
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # test for expected exception 1
    try:
        a = AbstractField()
        a()
        raise AssertionError()
    except UndefinedField:
        pass


# Generated at 2022-06-25 21:34:20.827710
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    with raises(UndefinedField):
        abstract_field_0()



# Generated at 2022-06-25 21:34:25.561273
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()

    assert abstract_field_0('__str__') == 'AbstractField <en>'
    assert abstract_field_0('uuid') == '97917fcd-c7c0-4bdd-b865-6f1bbbdf3aa6'
    assert abstract_field_0('test_field', min_value=0, max_value=10) == 10


# Generated at 2022-06-25 21:34:27.867752
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    method_name = field._gen.choice.Meta.name
    assert method_name in dir(field)
    assert field(method_name)


# Generated at 2022-06-25 21:34:39.518992
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('Name') is not None
    assert abstract_field_0('Sex') in ('male', 'female')
    assert abstract_field_0('Address') is not None
    assert abstract_field_0('Binary', length=5) is not None
    assert isinstance(abstract_field_0('Binary', length=5), str)
    assert abstract_field_0('HEX', length=5) is not None
    assert isinstance(abstract_field_0('HEX', length=5), str)
    assert abstract_field_0('Letter', lowercase=True) is not None
    assert isinstance(abstract_field_0('Letter', lowercase=True), str)
    assert abstract_field_0('RandomDigit') is not None

# Generated at 2022-06-25 21:35:35.781715
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.enums import Gender
    from mimesis.exceptions import TypeMismatch
    from datetime import datetime
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins.software import ApplicationName
    from mimesis.data import CURRENCY_CODES, FORMAT_CODES, TIMEZONE_CODES
    from mimesis.providers.base import BaseDataProvider
    # Setup
    abstract_field_0 = AbstractField(locale='ru')
    abstract_field_0._gen.add_provider(RussiaSpecProvider)
    abstract_field_0._gen.add_provider(ApplicationName)
    abstract_field_0._gen.add_providers(
        *BaseDataProvider.get_providers())

# Generated at 2022-06-25 21:35:42.509096
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__(name="user_agent")

    # Test the case that the provider is not supported
    abstract_field_0 = AbstractField()
    try:
        abstract_field_0.__call__(name="geo.num")
    except ValueError as exception_0:
        assert str(exception_0) == "Provider 'geo' is not supported."

    # Test the case that the field is not defined
    abstract_field_0 = AbstractField()
    try:
        abstract_field_0.__call__(name="foobar")
    except UndefinedField as exception_0:
        assert str(exception_0) == "Field name is not defined."

    # Test the case that the field is not acceptable
    abstract_field_0 = Abstract

# Generated at 2022-06-25 21:35:43.475153
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    def func_0(target: str):
        return target


# Generated at 2022-06-25 21:35:45.791958
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    name_0 = 'name'

    result = abstract_field_0(name=name_0)
    expected = abstract_field_0._gen.datetime.datetime_str(tzname='UTC',
                                                          timezone=90300)
    assert result == expected



# Generated at 2022-06-25 21:35:52.919729
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.internet import Internet
    from mimesis.providers.lorem import Lorem
    from mimesis.providers.system import System
    from mimesis.typing import Password, Seed
    field = AbstractField(locale='ru',
                          seed=Seed(1),
                          providers=[System, Lorem, Cryptographic, Internet, RussiaSpecProvider])
    password = field('password', key=Password.to_sha256)
    assert password == '49B2B7B680F536F9E9B74134D258C0410E03859B93E7B0B816C21555D9F03B9B'

# Generated at 2022-06-25 21:35:59.070612
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField('en', 0, 'Generic')
    str_0 = abstract_field_0('Username.username')
    assert str_0 == 'lillian'
    str_1 = abstract_field_0('Username.username', 'pear')
    assert str_1 == 'pear'
    str_2 = abstract_field_0('Username.username', 'pear')
    assert str_2 == 'pear'
    str_3 = abstract_field_0('Username.username', 'pear')
    assert str_3 == 'pear'
    str_4 = abstract_field_0('Username.username', 'pear')
    assert str_4 == 'pear'
    str_5 = abstract_field_0('Username.username', 'pear')
    assert str_

# Generated at 2022-06-25 21:36:00.196238
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    method = abstract_field_0('person.name')
    assert str(method()) == 'Andrew'


# Generated at 2022-06-25 21:36:03.764156
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField()
    abstract_field.__call__('datetime')
    abstract_field.__call__('person.full_name')
    abstract_field.__call__('person.full_name', key=len)
    abstract_field.__call__('person.full_name', gender='female')
    abstract_field.__call__('person.full_name',
                            gender='female', key=len)
    abstract_field.__call__('person.full_name',
                            gender='female', key=lambda x: x + 'x')


# Generated at 2022-06-25 21:36:06.129649
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    for name in ['datetime', 'file', 'file.extension', 'file.mime_type', 'network', 'text', 'text.text',
                 'text.paragraph', 'text.sentence', 'text.phrase', 'text.word', 'text.quote']:
        abstract_field_0(name)



# Generated at 2022-06-25 21:36:12.313813
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    try:
        abstract_field_0.__call__()
    except:
        assert True
    else:
        assert False
    try:
        abstract_field_0.__call__(name='test')
    except:
        assert True
    else:
        assert False
    def callable_func():
        return 'test'
    try:
        assert abstract_field_0.__call__(name='name.test', key=callable_func) == 'test'
    except:
        assert False
    else:
        assert True
    def callable_func():
        return 'test'
    try:
        abstract_field_0.__call__(name='test.name', key=callable_func)
    except:
        assert True

# Generated at 2022-06-25 21:37:24.693611
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.builders import FieldBuilder
    from mimesis.enums import Gender, Occupation
    from mimesis.schema import Field
    from mimesis.typing import JSON
    from mimesis.utils import make_schema
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.person import Person

    builder = FieldBuilder(Person, Address)
    field = Field(locale='en', providers=(builder,))
    schema = make_schema(
        {
            'gender': field('gender'), 'full_name': field('full_name'),
            'occupation': field('occupation', category=Occupation.SERVICE),
        }
    )  # type: JSON
    result = schema()
    assert result

# Generated at 2022-06-25 21:37:31.215976
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.exceptions import UnacceptableField, UndefinedField, UnsupportedField

    try:
        abstract_field_0 = AbstractField()
        result_0 = abstract_field_0()
    except UndefinedField:
        pass

    try:
        result_1 = AbstractField(locale='en', seed=201509).__call__(name='person.full_name')
    except UnacceptableField:
        pass

    try:
        result_2 = AbstractField(locale='en', seed=201509).__call__(name='region.address')
    except UnacceptableField:
        pass

    result_3 = AbstractField(locale='en', seed=201509).__call__(name='address', key=str)

# Generated at 2022-06-25 21:37:31.981405
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    obj = Field()
    obj('lorem_ipsum')


# Generated at 2022-06-25 21:37:32.865265
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('name')


# Generated at 2022-06-25 21:37:33.605427
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Test code
    abstract_field_0 = AbstractField()



# Generated at 2022-06-25 21:37:35.761148
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    result = abstract_field_1('name')
    assert isinstance(result, str) == True


# Generated at 2022-06-25 21:37:37.282111
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert (abstract_field_0('get_word')
            == 'Rerum sint assumenda.'), 'abstract_field_0.__call__'

# Generated at 2022-06-25 21:37:42.487246
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField()
    abstract_field_2 = AbstractField()
    abstract_field_3 = AbstractField()
    abstract_field_4 = AbstractField()

    def tail_parser(tails: str, obj: Any) -> Any:
        """Return method from end of tail.

        :param tails: Tail string
        :param obj: Object which search tail from
        :return last tailed method
        """
        provider_name, method_name = tails.split('.', 1)

        if '.' in method_name:
            raise ValueError()

        attr = getattr(obj, provider_name)
        if attr is not None:
            return getattr(attr, method_name)
    abstract_field_0._gen.add_providers('fish')


# Generated at 2022-06-25 21:37:43.769319
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    a = AbstractField()
    assert isinstance(a, AbstractField)


# Test for method __call__ of class AbstractField
# Callable object: None

# Generated at 2022-06-25 21:37:45.750965
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__

    Check that method __call__ is working as designed

    """

    abstract_field_0 = AbstractField()
    abstract_field_0('user_agent')

    abstract_field_1 = AbstractField(locale='zh-cn')
    abstract_field_1('user_agent')



# Generated at 2022-06-25 21:39:28.099249
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0('dog.breed')
    try:
        abstract_field_0('dog.breed.name')
        flag_0 = False
    except UnacceptableField:
        flag_0 = True
    assert flag_0
    abstract_field_0('food.fruit')
    abstract_field_0('food.vegetable')
    abstract_field_0('food.fruit', key=lambda x: x.title())
    abstract_field_0('food.vegetable', key=lambda x: x.title())


# Generated at 2022-06-25 21:39:30.706427
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    with raises(UndefinedField):
        abstract_field_0()  # __call__()
    with raises(UnsupportedField):
        abstract_field_0('foo')
    abstract_field_0('uuid')  # __call__()


# Generated at 2022-06-25 21:39:37.298765
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert callable(abstract_field_0)
    assert abstract_field_0() is None
    assert abstract_field_0('numbers.integer') is None
    assert abstract_field_0('numbers.integer', min_value=50, max_value=100) >= 50
    assert abstract_field_0('numbers.integer', min_value=50, max_value=100) <= 100
    assert abstract_field_0('numbers.integer',
                            min_value=50,
                            max_value=100,
                            key=lambda x: x * 2) >= 100
    assert abstract_field_0('numbers.integer',
                            min_value=50,
                            max_value=100,
                            key=lambda x: x * 2) <= 200


# Generated at 2022-06-25 21:39:39.968844
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    data_provider_1 = name='data_provider.name'
    method_name_1 = abstract_field_0(data_provider_1)
    method_name_1 = abstract_field_0(data_provider_1)
    method_name_1 = abstract_field_0(data_provider_1)



# Generated at 2022-06-25 21:39:41.554399
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0.__call__(
        "credit_card_number",
        key=lambda x: x.split('-')[0]
    ) == '3738'


# Generated at 2022-06-25 21:39:43.710406
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # This test will raise UndefinedField if it will be passed
    # as the parameter name
    abstract_field_1 = AbstractField()
    try:
        abstract_field_1()
    except UndefinedField:
        pass



# Generated at 2022-06-25 21:39:45.912726
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0.__call__('choice', items=['apple', 'banana'])
    abstract_field_0.__call__('choice', items=['apple', 'banana'])
    abstract_field_0.__call__('choice', items=['apple', 'banana'])


# Generated at 2022-06-25 21:39:47.133596
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Case 0 - call with None
    with raises(UndefinedField):
        abstract_field_0 = AbstractField()
        abstract_field_0(None)
        raise AssertionError()


# Generated at 2022-06-25 21:39:48.105030
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()


# Generated at 2022-06-25 21:39:49.227154
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    abstract_field_1('foo', bar='baz')
