

# Generated at 2022-06-25 21:30:26.762418
# Unit test for constructor of class AbstractField
def test_AbstractField():

    # Create an instance of a class AbstractField
    abstract_field_0 = AbstractField()
    assert str(abstract_field_0) == 'AbstractField <en>'



# Generated at 2022-06-25 21:30:34.321344
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    # Wrong parameter
    # AbstractField.__call__(abstract_field_0, 'i4.upper', key=None, **kwargs)
    # UndefinedField:
    # Field name was not specified
    # AbstractField.__call__(abstract_field_0, key=None, **kwargs)
    # KeyError:
    # Unsupported field: i4.upper
    # AbstractField.__call__(abstract_field_0, 'i4.upper', key=None)
    # ValueError:
    #  ['Upper'] is not in list
    # AbstractField.__call__(abstract_field_0, 'currency.code', key=None)
    # KeyError:
    # Unsupported field: currency.code
    # AbstractField.__call__

# Generated at 2022-06-25 21:30:40.790215
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    a = AbstractField()

    # Try to call undefined field
    try:
        result = a()
        assert False
    except UndefinedField:
        assert True

    # Try to call field from unsupported provider
    try:
        result = a('name')
        assert False
    except UnsupportedField:
        assert True

    # Try to call field with tail
    try:
        result = a('name.field')
        assert False
    except UnsupportedField:
        assert True



# Generated at 2022-06-25 21:30:43.096424
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0("test") is None


# Generated at 2022-06-25 21:30:47.310932
# Unit test for method create of class Schema
def test_Schema_create():
    assert Schema(lambda : 'test').create() == ['test']

# Generated at 2022-06-25 21:30:58.275100
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField('en', None, None)
    assert abstract_field_0._gen.providers.data_providers == abstract_field_1._gen.providers.data_providers, "Class AbstractField failed in getting correct instance of class Generic."

    abstract_field_2 = AbstractField('en', '123456789', None)
    abstract_field_3 = AbstractField('en', None, None)
    assert abstract_field_2._gen.seed != abstract_field_3._gen.seed, "Class AbstractField failed in creating instance of class AbstractField with seed."

    abstract_field_4 = AbstractField('en', None, ['currency', 'address'])

# Generated at 2022-06-25 21:31:03.924770
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Get the class
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField(locale='en')
    abstract_field_2 = AbstractField(locale='en', seed=None)
    abstract_field_3 = AbstractField(locale='en', seed=None, providers=None)
    abstract_field_4 = AbstractField(seed=None, providers=None, locale='en')


# Generated at 2022-06-25 21:31:11.668320
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from unittest.mock import patch

    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField(providers=[])

    class Temp:
        @staticmethod
        def __str__():
            return 'Temp'
    try:
        # Fix https://github.com/lk-geimfari/mimesis/issues/619
        with patch('mimesis.providers.generic.Generic.choice',
                   Temp()):
            abstract_field_1(iterations=1, name='choice')
    except UnacceptableField:
        pass

    try:
        abstract_field_0(iterations=1, name='integer')
    except UnacceptableField:
        assert True
    else:
        assert False



# Generated at 2022-06-25 21:31:12.248583
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert AbstractField() is not None


# Generated at 2022-06-25 21:31:12.626212
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-25 21:31:53.031672
# Unit test for method create of class Schema
def test_Schema_create():
    assert [{'dd': 'da'}] == Schema(SchemaType(lambda: {'dd': 'da'})).create()

# Generated at 2022-06-25 21:31:58.932631
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField(locale='en',
                                     seed=0)

    # Errors
    with pytest.raises(UndefinedField):
        abstract_field_0()
    with pytest.raises(UndefinedField):
        abstract_field_0(name='lorem_ipsum')
    with pytest.raises(UnsupportedField):
        abstract_field_0(name='lorem')

    assert(abstract_field_0(name='lorem_ipsum',
                            key=lambda x: len(x))
           == 10)


# Generated at 2022-06-25 21:32:02.334803
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    name = 'hello'
    key = None
    kwargs = None
    try:
        abstract_field_0.__call__(name, key, kwargs)
        assert False
    except UndefinedField as e:
        assert str(e) == 'Field is undefined.'

# Generated at 2022-06-25 21:32:08.849037
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    try:
        str = abstract_field_0()
    except UndefinedField:
        pass

    abstract_field_1 = AbstractField()
    func_obj = lambda x: x + 1
    try:
        int = abstract_field_1('expr', key=func_obj, expr='2')
    except UndefinedField:
        pass

    name_0 = 'datetime_datetime.date'
    abstract_field_2 = AbstractField()
    try:
        datetime_datetime = abstract_field_2(name_0)
    except UnsupportedField:
        pass

    name_1 = 'bad_name'
    abstract_field_3 = AbstractField()
    try:
        abstract_field_3(name_1)
    except UnsupportedField:
        pass

# Generated at 2022-06-25 21:32:09.951141
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()


# Generated at 2022-06-25 21:32:17.622813
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': Field(name='datetime.datetime', format='%H:%M:%S')
        }

    schema_0 = Schema(schema)
    assert isinstance(schema_0.create(), list)
    assert isinstance(schema_0.create(iterations=1), list)
    assert isinstance(schema_0.create(iterations=2), list)
    assert isinstance(schema_0.create(iterations=3), list)
    assert isinstance(schema_0.create(iterations=4), list)
    assert isinstance(schema_0.create(iterations=5), list)
    assert isinstance(schema_0.create(iterations=6), list)

# Generated at 2022-06-25 21:32:18.682640
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0('name')

# Generated at 2022-06-25 21:32:23.477804
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('name', parameter_0=abstract_field_0, parameter_1=0.8299157435409985) == 'Oliver Medina'
    assert abstract_field_0('name', parameter_0=abstract_field_0, parameter_1=0.8299157435409985) == 'Conner Knapp'


# Generated at 2022-06-25 21:32:24.036091
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-25 21:32:27.480991
# Unit test for method create of class Schema
def test_Schema_create():
    my_schema = Schema(
        lambda: {
            'name': Field()('name'),
            'email': Field()('email'),
            'link': Field()('link'),
        }
    )

    for i in my_schema.create(10):
        yield i