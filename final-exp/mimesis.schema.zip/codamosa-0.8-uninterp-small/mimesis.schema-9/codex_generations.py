

# Generated at 2022-06-25 21:30:37.736186
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    field('str', key=lambda x: x.lower())


# Generated at 2022-06-25 21:30:39.712789
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    abstract_field_0 = AbstractField(locale="it", seed=0.0)

# Generated at 2022-06-25 21:30:40.223161
# Unit test for constructor of class AbstractField
def test_AbstractField():
    AbstractField()

# Generated at 2022-06-25 21:30:41.672732
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0.__call__('abc')



# Generated at 2022-06-25 21:30:42.211224
# Unit test for constructor of class AbstractField
def test_AbstractField():
    test_case_0()

# Generated at 2022-06-25 21:30:48.107069
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0("full_name")
    assert abstract_field_0("full_name", gender="male")
    assert abstract_field_0("full_name", key=lambda x: x.upper())
    assert abstract_field_0("__subclasses__")
    assert abstract_field_0("__subclasses__", key=lambda x: len(x))


# Generated at 2022-06-25 21:30:49.647329
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field._gen is not None

# Generated at 2022-06-25 21:30:56.921123
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    try:
        result = abstract_field_0()
    except UndefinedField:
        assert True
    except:
        assert False

    try:
        result = abstract_field_0('fake')
    except UnsupportedField:
        assert True
    except:
        assert False

    result = abstract_field_0('address.address')
    assert result is not None

    result = abstract_field_0('address.fake')
    assert result is not None



# Generated at 2022-06-25 21:30:58.235398
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert AbstractField().__call__('name') is not None


# Generated at 2022-06-25 21:31:00.309661
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    result = abstract_field_0(name='____')
