

# Generated at 2022-06-25 21:30:37.817795
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field = AbstractField()
    abstract_field.__class__.__name__ == "AbstractField"


# Generated at 2022-06-25 21:30:40.437865
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        test_case_0()
        print('ok')
    except Exception as e:
        print('error')
        print(e)
    finally:
        print('')



# Generated at 2022-06-25 21:30:41.541802
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()


# Generated at 2022-06-25 21:30:45.849825
# Unit test for constructor of class AbstractField
def test_AbstractField():
    locale = 'en'
    seed = 123
    providers = ['foo', 'bar']
    abstract_field_0 = AbstractField(locale, seed, providers)
    assert abstract_field_0.locale == locale
    assert abstract_field_0.seed == seed
    assert abstract_field_0._gen.seed == seed
    assert abstract_field_0._table == {}


# Generated at 2022-06-25 21:30:52.811704
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()

    if (not (abstract_field_0.__call__() == UndefinedField)):
        print('Could not call method __call__ of class AbstractField')
        return

    try:
        abstract_field_0.__call__(name='person.full_name')
    except UndefinedField:
        print('Could not call method __call__ of class AbstractField')


# Generated at 2022-06-25 21:30:57.182489
# Unit test for method create of class Schema
def test_Schema_create():
    schema_0 = AbstractField()
    schema_1 = Schema(schema_0)
    assert isinstance(schema_1.create(1), list)
    assert len(schema_1.create(1)) == 1
    assert len(schema_1.create(10)) == 10


# Generated at 2022-06-25 21:30:58.158093
# Unit test for constructor of class AbstractField
def test_AbstractField():
    test_case_0()

# Generated at 2022-06-25 21:31:03.146750
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(lambda: str(0)).create()) == 1
    assert isinstance(Schema(lambda: str(0)).create()[0], str)
    assert len(Schema(lambda: str(0)).create(5)) == 5
    assert isinstance(Schema(lambda: str(0)).create(5)[0], str)


# Generated at 2022-06-25 21:31:04.671935
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field = AbstractField(locale='en', seed=None, providers=None)


# Generated at 2022-06-25 21:31:07.932030
# Unit test for constructor of class AbstractField
def test_AbstractField():
    val = AbstractField()
    assert isinstance(val, AbstractField)
    assert hasattr(val, '_table')
    assert hasattr(val, '_gen')
    assert hasattr(val, 'locale')
    assert hasattr(val, 'seed')