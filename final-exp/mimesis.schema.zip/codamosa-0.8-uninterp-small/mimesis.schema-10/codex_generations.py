

# Generated at 2022-06-25 21:30:31.672360
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    abstract_field_1('text.text')


# Generated at 2022-06-25 21:30:35.359783
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    abstract_field_1.__call__('name', 'first_name')
    try:
        abstract_field_1.__call__('name')
    except UndefinedField:
        pass


# Generated at 2022-06-25 21:30:36.972006
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()


# Generated at 2022-06-25 21:30:45.478846
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    print("\n- Field test:")

    # pylint: disable=no-value-for-parameter
    assert abstract_field_0() is None
    assert abstract_field_0(name='foo') is None
    assert abstract_field_0(key=lambda x: x.__class__.__name__) == 'Field'
    assert abstract_field_0(name='boolean', key=lambda x: x.__class__.__name__) == 'bool'
    assert abstract_field_0(name='random.boolean') is True
    assert abstract_field_0(name='date.time_unit') == 'unix_time'
    assert abstract_field_0(name='date.timestamp') > 0



# Generated at 2022-06-25 21:30:48.112053
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_01 = AbstractField('ru')

    assert abstract_field_01 is not None


# Generated at 2022-06-25 21:30:51.021053
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    try:
        abstract_field_0.__call__('name')
    except UndefinedField:
        pass


# Generated at 2022-06-25 21:30:53.085075
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('test_method')


# Generated at 2022-06-25 21:31:03.310380
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    try:
        abstract_field_0()
    except UndefinedField as e:
        assert (str(e) == "Field is not defined.")
    else:
        assert False

    try:
        abstract_field_0('asdflkjdsf')
    except UnsupportedField as e:
        assert (str(e) == "Method 'asdflkjdsf' is not supported.")
    else:
        assert False

    assert isinstance(abstract_field_0('as_string'), str)
    assert isinstance(abstract_field_0('null'), type(None))
    assert isinstance(abstract_field_0('boolean'), bool)
    assert isinstance(abstract_field_0('floating_number'), float)

# Generated at 2022-06-25 21:31:06.957760
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_1 = AbstractField()
    # test parameters args
    abstract_field_1('field', field='field', key='key')
    # test parameters kwargs
    abstract_field_1(name='random_full_name', gender='gender', key='key')



# Generated at 2022-06-25 21:31:07.635951
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(AbstractField(), AbstractField)
