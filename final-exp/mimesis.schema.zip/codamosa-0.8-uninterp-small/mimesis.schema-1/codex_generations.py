

# Generated at 2022-06-25 21:30:33.091024
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    test_data_provider = Generic('en')
    test_schema = ''
    test_key = None

    field = AbstractField()
    assert field('life.sex') == field._gen.life.sex()
    assert field('sex', key=test_key, provider=test_data_provider) == \
        test_data_provider.sex()
    assert field._table['sex'] == test_data_provider.sex
    with raises(UnsupportedField) as excinfo:
        field('sex', provider=Generic('en_GB'))
    assert 'sex' in str(excinfo.value)
    assert field('life.sex', provider=Generic('en')) == \
        test_data_provider.life.sex()

# Generated at 2022-06-25 21:30:33.685424
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field_0 = AbstractField()


# Generated at 2022-06-25 21:30:34.555536
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field('en').create_schema() == {}

# Generated at 2022-06-25 21:30:44.480271
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    schema = Schema(
        lambda: {
            'name': 'name.formats',
            'surname': 'name.last_name',
            'patronymic': 'name.middle_name',
            'gender': 'person.gender',
            'age': 'person.age',
            'birth_date': 'datetime.datetime',
            'country': 'address.country.name',
            'address': 'address.address',
            'city': 'address.city',
            'postcode': 'address.zip_code',
            'phone_number': 'person.phone_number',
            'email': 'person.email',
            'website': 'internet.url',
            'SSN': 'person.ssn',
            'password': 'person.password',
        }
    )


# Generated at 2022-06-25 21:30:55.973872
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f_0 = Field()
    # [FAILED]
    try:
        f_0(None)
    except UndefinedField:
        pass
    else:
        raise Exception("Failed assertion: UndefinedField")

    # [FAILED]
    try:
        f_0('text')
    except UnsupportedField:
        pass
    else:
        raise Exception("Failed assertion: UnsupportedField")

    provider_0 = Field()
    # [FAILED]
    try:
        provider_0('text.text')
    except UnacceptableField:
        pass
    else:
        raise Exception("Failed assertion: UnacceptableField")



# Generated at 2022-06-25 21:30:59.479102
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    inst_0 = AbstractField()
    inst_1 = AbstractField(locale='en', seed=None)

    def key(x: int) -> int:
        return x ** 3

    assert callable(inst_1)
    assert inst_0('integer', 100, 150) == inst_1('integer', 100, 150)
    assert inst_1(key=key, minimum=1, maximum=2) == 8
    assert inst_0('undefined')  # It raise UndefinedField()
    assert inst_0('choice.undefined')  # It raise UndefinedField()

# Generated at 2022-06-25 21:31:05.134200
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    schema_0 = Schema(test_case_0)
    str_0 = 'I-TADT'
    obj_0 = AbstractField(seed=str_0)
    int_0 = -69352865488898982
    int_1 = 83
    int_2 = -6
    obj_1 = obj_0(name='datetime', year=int_0, month=int_1, day=int_2)



# Generated at 2022-06-25 21:31:12.823334
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    str_0 = 'T!?:rD0~F>|E'
    field_0 = Field(str_0)
    boolean_0 = True

    # Call function __call__ with arguments
    # 'field_0.Foo'.
    # Expected result: 'foo'.
    field_0.Foo()

    str_1 = ''
    # Call function __call__ with arguments
    # 'field_0.__float__'.
    # Expected result: '-0.5534728095124431'.
    field_0.__float__(str_1)
    # Call function __call__ with arguments
    # 'field_0.__int__'.
    # Expected result: '-436'.
    field_0.__int__(boolean_0)

# Generated at 2022-06-25 21:31:32.418586
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    seed_0 = 0
    type_of_seed_0 = type(seed_0)
    locale_0 = 'en'
    key_0 = None
    type_of_key_0 = type(key_0)
    providers_0 = None
    type_of_providers_0 = type(providers_0)
    name_0 = '<seed_0>'
    type_of_name_0 = type(name_0)
    AbstractField.__init__(seed_0=seed_0,
                           key_0=key_0,
                           providers_0=providers_0,
                           locale_0=locale_0,
                           name_0=name_0)
    if type(name_0) != str:
        raise ValueError

# Generated at 2022-06-25 21:31:40.698729
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    str_0 = '6kc4!g94$(<e'
    str_1 = 'dkwN$x!L-@<'
    str_2 = '_'
    try:
        AbstractField(str_1, str_0).__call__(str_2)
        assert False
    except UndefinedField:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-25 21:32:55.797840
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    str_0 = 'en'
    field_0 = Field()

