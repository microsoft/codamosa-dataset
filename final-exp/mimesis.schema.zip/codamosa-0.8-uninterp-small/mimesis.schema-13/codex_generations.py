

# Generated at 2022-06-25 21:30:30.477778
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # TODO: test with all locales
    provider = AbstractField('en')


# Generated at 2022-06-25 21:30:33.801875
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField(providers=())
    assert abstract_field_0('example', key=lambda x: x) is None


# Generated at 2022-06-25 21:30:36.659323
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField(providers=[Person])
    result = field('full_name')
    assert isinstance(result, str)
    assert result


# Generated at 2022-06-25 21:30:40.790245
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    def i_am_key(data: str) -> str:
        return data.upper()

    abstract_field_0 = AbstractField()
    result = abstract_field_0('person.name', key=i_am_key)

    # Test with string as argument
    assert isinstance(result, str)
    # Test if result is not empty
    assert result

# Generated at 2022-06-25 21:30:48.795236
# Unit test for method create of class Schema
def test_Schema_create():
    """Test if create method of class Schema return sample."""
    provider = Generic('en', seed=123)
    sample = [{
        'first_name': 'Robert', 'last_name': 'Wright',
        'telephone': '123-513-8984', 'address': '4352 Little Street',
        'email': 'Robert.Wright@gmail.com', 'Birth_number': '1892/2',
        'postcode': '89302', 'city': 'North Joseph', 'username': 'Robert.Wright',
        'password': '2xghnJl49a'}]


# Generated at 2022-06-25 21:30:50.595684
# Unit test for constructor of class AbstractField
def test_AbstractField():
    AbstractField()
    AbstractField('en', None)
    AbstractField('en', None, None)

# Generated at 2022-06-25 21:30:54.282865
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField(locale='en', seed=None)
    assert abstract_field_0 is not None
    assert abstract_field_0(name='name') is not None


# Generated at 2022-06-25 21:30:56.398304
# Unit test for method create of class Schema
def test_Schema_create():
    s = Schema(lambda: {'name': 'Mimesis'})
    assert s.create(iterations=3) == [{'name': 'Mimesis'}, {'name': 'Mimesis'}, {'name': 'Mimesis'}]

# Generated at 2022-06-25 21:30:57.645366
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0.__call__('username') is not None


# Generated at 2022-06-25 21:31:07.201455
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Testing __call__ of class AbstractField
    abstract_field_0 = AbstractField()
    #  ValueError: if name of method == None
    try:
        abstract_field_0()
    except ValueError:
        pass
    except Exception as e:
        print("Should raise {}, but raised: {}".format(ValueError, e.__class__.__name__))

    # Testing __call__ of class AbstractField
    abstract_field_0 = AbstractField()
    #  ValueError: if method not supported
    try:
        abstract_field_0("not_method")
    #  except ValueError: is raised if method not supported
    except ValueError:
        pass
    except Exception as e:
        print("Should raise {}, but raised: {}".format(ValueError, e.__class__.__name__))

   

# Generated at 2022-06-25 21:31:47.797281
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()

# Generated at 2022-06-25 21:31:49.920193
# Unit test for method create of class Schema
def test_Schema_create():
    data_provider_0 = Generic(seed=64777)
    schema_0 = Schema(lambda: {})
    actual = schema_0.create()
    expect = [{}]
    assert actual == expect, actual



# Generated at 2022-06-25 21:31:53.175502
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_0('name')
    abstract_field_0('name', key=str)
    abstract_field_0('name', key=str, local_format=str)
    abstract_field_0('name', key=str, local_format=str, seed=str)
    abstract_field_0('name', key=str, local_format=str, seed=str, tail=str)
    abstract_field_0('name', key=str, local_format=str, seed=test_case_0, tail=test_case_0)

# Generated at 2022-06-25 21:31:54.164409
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert type(AbstractField()) == AbstractField


# Generated at 2022-06-25 21:32:01.210037
# Unit test for method create of class Schema
def test_Schema_create():
    schema_0 = Schema(None)
    schema_1 = Schema(lambda: {"integer": 999, "string": "example"})
    schema_2 = Schema(lambda: {"integer": 999, "string": "example"})
    schema_3 = Schema(lambda: {"integer": 999, "string": "example"})

    assert schema_1.create() == [{"integer": 999, "string": "example"}]
    assert schema_2.create(iterations=1) == [{"integer": 999, "string": "example"}]
    assert schema_3.create(iterations=2) == [{"integer": 999, "string": "example"}, {"integer": 999, "string": "example"}]

# Generated at 2022-06-25 21:32:01.885719
# Unit test for constructor of class AbstractField
def test_AbstractField():
    test_case_0()


# Generated at 2022-06-25 21:32:04.440382
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field
    from mimesis.schema.schemas import test_schema

    abstract_field_0 = Field()
    schema_0 = Schema(test_schema)
    schema_0.create()

# Generated at 2022-06-25 21:32:05.902222
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field_0 = AbstractField()
    abstract_field_0()



# Generated at 2022-06-25 21:32:07.075919
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField()
    assert abstract_field('address.address_line') is not None


# Generated at 2022-06-25 21:32:14.793535
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.schema import Field
    from mimesis.providers.date import DateProvider
    from mimesis.providers.person import PersonProvider
    from mimesis.providers.internet import InternetProvider
    from mimesis.providers.address import AddressProvider
    from mimesis.providers.phone import PhoneProvider
    from mimesis.providers.cryptographic import CryptographicProvider


    def schema():
        person = PersonProvider('en')
        address = AddressProvider('en')
        phone = PhoneProvider('en')

        return {
            'full_name': person.full_name(gender=Gender.FEMALE),
            'age': phone.age(),
            'address': address.address(),
        }


    schema = Schema(schema)
   

# Generated at 2022-06-25 21:33:22.409556
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    # assert abstract_field_0.__call__('word')
    # assert abstract_field_0('word')



# Generated at 2022-06-25 21:33:23.547557
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abs_field = AbstractField()
    assert abs_field is not None

# Generated at 2022-06-25 21:33:34.852362
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    abstract_field_1 = AbstractField()

    # Verify that abstract_field_0.__call__() raises UndefinedField
    try:
        assert abstract_field_0.__call__()
    except UndefinedField:
        assert True
    else:
        assert False

    # Verify that abstract_field_0.__call__(name=None) raises UndefinedField
    try:
        assert abstract_field_0.__call__(name=None)
    except UndefinedField:
        assert True
    else:
        assert False

    # Verify that abstract_field_0.__call__(name='') raises UndefinedField
    try:
        assert abstract_field_0.__call__(name='')
    except UndefinedField:
        assert True

# Generated at 2022-06-25 21:33:36.699677
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('name')
    assert abstract_field_0('name', True)

# Generated at 2022-06-25 21:33:43.185750
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    name_0 = 'Field'
    key_0 = 'key_0'
    kwargs_0 = {'kwarg_0': 'kwarg_0'}
    try:
        result = abstract_field_0(name_0, key_0, **kwargs_0)
    except UndefinedField:
        pass
    except Exception as err:
        print(err)
    abstract_field_1 = AbstractField('en')
    name_1 = 'Field'
    key_1 = Callable
    kwargs_1 = {'kwarg_1': 'kwarg_1'}
    try:
        result = abstract_field_1(name_1, key_1, **kwargs_1)
    except UndefinedField:
        pass

# Generated at 2022-06-25 21:33:47.949986
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text

    custom_field = AbstractField(locale='ru', seed=None,
                                 providers=[Person, Address, Datetime,
                                            Internet, Text])



# Generated at 2022-06-25 21:33:51.911517
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Case 1
    abstract_field_0 = AbstractField()
    try:
        abstract_field_0()
    except UndefinedField:
        pass

    # Case 2
    abstract_field_1 = AbstractField()
    try:
        abstract_field_1(
            name="fake-name",
            key=lambda x: x,
        )
    except UnsupportedField:
        pass


# Generated at 2022-06-25 21:33:52.832423
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field


# Generated at 2022-06-25 21:33:55.527819
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField()
    name = 'person.full_name'
    value = abstract_field(name)
    if isinstance(value, str):
        return
    raise AssertionError('Assertion error in AbstractField.__call__()')


# Generated at 2022-06-25 21:34:01.336099
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field_0 = AbstractField()
    assert abstract_field_0('full_name', gender='male') == 'John Mcdonald'
    assert abstract_field_0('full_name') == 'Arthur Silva'
    assert abstract_field_0('name') == 'Bruce'
    assert abstract_field_0('surname') == 'Patton'
    assert abstract_field_0('address.address') == '3203 Simpson Cir'
    assert abstract_field_0('address.street_address') == '884 Hegmann Orchard'
    assert abstract_field_0('address.street_name') == 'Giuseppe Camp'
    assert abstract_field_0('address.street_suffix') == 'Pines'
    assert abstract_field_0('address.city') == 'South Raynalaland'
    assert abstract_field