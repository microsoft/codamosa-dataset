

# Generated at 2022-06-17 23:19:38.069001
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None



# Generated at 2022-06-17 23:19:44.954839
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field
    from mimesis.enums import Gender

    field = Field()

    def schema():
        return {
            'name': field('person.full_name'),
            'age': field('age'),
            'gender': field('gender', key=lambda x: Gender(x).name),
        }

    schema = Schema(schema)
    assert schema.create(iterations=5)

# Generated at 2022-06-17 23:19:49.806622
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema() -> JSON:
        """Return filled schema."""
        return {
            'name': field('name'),
            'surname': field('surname'),
            'age': field('age'),
        }

    schema = Schema(schema)
    assert len(schema.create(10)) == 10

# Generated at 2022-06-17 23:19:57.783824
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema():
        """Schema."""
        return {
            'name': field('person.full_name'),
            'age': field('person.age'),
            'email': field('person.email'),
        }

    schema = Schema(schema)
    result = schema.create(iterations=5)
    assert isinstance(result, list)
    assert len(result) == 5

# Generated at 2022-06-17 23:20:03.465320
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    from mimesis.schema import Field
    from mimesis.enums import Gender

    field = Field()

    def schema():
        return {
            'name': field('person.full_name'),
            'age': field('age'),
            'gender': field('gender', key=lambda x: Gender(x).name),
        }

    schema = Schema(schema)
    result = schema.create(iterations=3)
    assert len(result) == 3

# Generated at 2022-06-17 23:20:11.198364
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None

    field = AbstractField(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42



# Generated at 2022-06-17 23:20:19.646615
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field

    def schema() -> JSON:
        """Return filled schema."""
        field = Field()
        return {
            'name': field('name'),
            'surname': field('surname'),
            'address': field('address.full_address'),
        }

    schema = Schema(schema)
    assert len(schema.create()) == 1
    assert len(schema.create(iterations=2)) == 2

# Generated at 2022-06-17 23:20:20.989549
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = Field()
    assert field is not None

# Generated at 2022-06-17 23:20:25.382711
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': Field('en').full_name(),
            'age': Field('en').age(),
        }

    s = Schema(schema)
    assert len(s.create(iterations=5)) == 5

# Generated at 2022-06-17 23:20:36.616881
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = AbstractField()
    assert field('full_name') == 'John Doe'
    assert field('full_name', gender='male') == 'John Doe'
    assert field('full_name', gender='female') == 'Jane Doe'
    assert field('full_name', gender='female', key=str.upper) == 'JANE DOE'
    assert field('full_name', gender='female', key=str.upper) == 'JANE DOE'
    assert field('full_name', gender='female', key=str.upper) == 'JANE DOE'
    assert field('full_name', gender='female', key=str.upper) == 'JANE DOE'
    assert field('full_name', gender='female', key=str.upper) == 'JANE DOE'

# Generated at 2022-06-17 23:21:10.040156
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())


# Generated at 2022-06-17 23:21:17.633988
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('uuid') is not None
    assert field('uuid', key=lambda x: x.split('-')) is not None
    assert field('uuid', key=lambda x: x.split('-'))[0] == '8'
    assert field('uuid', key=lambda x: x.split('-'))[1] == '0'
    assert field('uuid', key=lambda x: x.split('-'))[2] == '0'
    assert field('uuid', key=lambda x: x.split('-'))[3] == '0'
    assert field('uuid', key=lambda x: x.split('-'))[4] == '0'
    assert field('uuid', key=lambda x: x.split('-'))[5] == '0'

# Generated at 2022-06-17 23:21:24.035533
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'

# Generated at 2022-06-17 23:21:31.477659
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    field = AbstractField(providers=[Datetime, Internet, Person, Text])

    assert field('full_name')
    assert field('full_name', gender='female')
    assert field('full_name', gender='male')
    assert field('full_name', gender='male', key=lambda x: x.upper())
    assert field('full_name', gender='male', key=lambda x: x.lower())
    assert field('full_name', gender='male', key=lambda x: x.title())

# Generated at 2022-06-17 23:21:34.148848
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField constructor."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

# Generated at 2022-06-17 23:21:39.127100
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema():
        return {
            'name': field('full_name'),
            'age': field('age'),
            'gender': field('gender'),
            'address': field('address'),
            'phone': field('phone_number'),
            'email': field('email'),
        }

    schema = Schema(schema)
    assert len(schema.create(iterations=10)) == 10

# Generated at 2022-06-17 23:21:47.215903
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'

    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'

    assert field('person.name') == 'John'
    assert field('person.name', gender='male') == 'John'
    assert field('person.name', gender='female') == 'Jane'

    assert field('person.name', key=lambda x: x.upper()) == 'JOHN'
    assert field('person.name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('person.name', gender='female', key=lambda x: x.upper())

# Generated at 2022-06-17 23:21:56.919571
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', key=lambda x: x.replace('-', ''))
    assert field('uuid', key=lambda x: x.replace('-', ''), version=4)
    assert field('uuid', key=lambda x: x.replace('-', ''), version=5)
    assert field('uuid', key=lambda x: x.replace('-', ''), version=1)
    assert field('uuid', key=lambda x: x.replace('-', ''), version=2)
    assert field('uuid', key=lambda x: x.replace('-', ''), version=3)

# Generated at 2022-06-17 23:22:07.165330
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'

# Generated at 2022-06-17 23:22:08.675919
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')



# Generated at 2022-06-17 23:22:36.923742
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', 'en')
    assert field('name', 'en', gender='male')
    assert field('name', key=lambda x: x.upper())
    assert field('name', 'en', key=lambda x: x.upper())
    assert field('name', 'en', gender='male', key=lambda x: x.upper())
    assert field('person.full_name')
    assert field('person.full_name', gender='male')
    assert field('person.full_name', 'en')
    assert field('person.full_name', 'en', gender='male')
    assert field('person.full_name', key=lambda x: x.upper())

# Generated at 2022-06-17 23:22:44.244842
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema():
        """Schema."""
        return {
            'name': field('person.full_name'),
            'age': field('person.age'),
            'gender': field('person.gender'),
        }

    data = Schema(schema).create(iterations=10)
    assert len(data) == 10
    assert isinstance(data, list)
    assert isinstance(data[0], dict)

# Generated at 2022-06-17 23:22:51.747364
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', key=lambda x: x.upper(), gender='male') == 'JOHN'
    assert field('name', key=lambda x: x.upper(), gender='female') == 'JANE'
    assert field('name', 'generic.name') == 'John'
    assert field('name', 'generic.name', gender='male') == 'John'
    assert field('name', 'generic.name', gender='female') == 'Jane'

# Generated at 2022-06-17 23:23:01.600607
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': 'John',
            'surname': 'Doe',
            'age': 18,
        }

    s = Schema(schema)
    assert s.create(iterations=5) == [
        {'name': 'John', 'surname': 'Doe', 'age': 18},
        {'name': 'John', 'surname': 'Doe', 'age': 18},
        {'name': 'John', 'surname': 'Doe', 'age': 18},
        {'name': 'John', 'surname': 'Doe', 'age': 18},
        {'name': 'John', 'surname': 'Doe', 'age': 18},
    ]

# Generated at 2022-06-17 23:23:07.964233
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Schema
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    def schema() -> dict:
        """Return schema."""
        return {
            'name': Person('en').full_name(gender=Gender.MALE),
            'age': Person('en').age(),
        }

    s = Schema(schema)
    assert isinstance(s.create(iterations=3), list)
    assert len(s.create(iterations=3)) == 3

# Generated at 2022-06-17 23:23:10.830439
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:23:15.018854
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    def schema() -> JSON:
        """Return filled schema."""
        return {
            'name': Person('en').full_name(),
            'address': Address('en').address(),
        }

    s = Schema(schema)
    assert s.create() == [{
        'name': 'Mrs. Jessica M. Smith',
        'address': '9071 N. Lillian St.',
    }]

# Generated at 2022-06-17 23:23:15.811817
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-17 23:23:17.401866
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField()
    assert isinstance(field, AbstractField)



# Generated at 2022-06-17 23:23:21.295185
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field

    field = Field()
    schema = Schema(lambda: {
        'name': field('name'),
        'surname': field('surname'),
    })

    assert len(schema.create(iterations=5)) == 5



# Generated at 2022-06-17 23:24:51.004568
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid') is not None
    assert field('uuid') != field('uuid')
    assert field('uuid', key=lambda x: x.upper()) is not None
    assert field('uuid', key=lambda x: x.upper()) != field('uuid')
    assert field('uuid', key=lambda x: x.upper()) != field('uuid', key=lambda x: x.upper())
    assert field('uuid', key=lambda x: x.upper()) != field('uuid', key=lambda x: x.lower())
    assert field('uuid', key=lambda x: x.upper()) != field('uuid', key=lambda x: x.upper())

# Generated at 2022-06-17 23:24:56.618334
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('full_name')
    assert field('full_name', key=lambda x: x.split()[0])
    assert field('full_name', key=lambda x: x.split()[1])
    assert field('full_name', key=lambda x: x.split()[2])
    assert field('full_name', key=lambda x: x.split()[3])
    assert field('full_name', key=lambda x: x.split()[4])
    assert field('full_name', key=lambda x: x.split()[5])
    assert field('full_name', key=lambda x: x.split()[6])
    assert field('full_name', key=lambda x: x.split()[7])
   

# Generated at 2022-06-17 23:25:04.497676
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'name'
    assert field('name', gender='male') == 'name'
    assert field('name', gender='female') == 'name'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'NAME'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'NAME'
    assert field('name', gender='male', key=lambda x: x.lower()) == 'name'
    assert field('name', gender='female', key=lambda x: x.lower()) == 'name'
    assert field('name', gender='male', key=lambda x: x.capitalize()) == 'Name'