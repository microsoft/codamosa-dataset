

# Generated at 2022-06-17 23:20:06.657792
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', key=lambda x: x.lower()) == 'john'
    assert field('name', key=lambda x: x.capitalize()) == 'John'
    assert field('name', key=lambda x: x.title()) == 'John'
    assert field('name', key=lambda x: x.swapcase()) == 'jOHN'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', key=lambda x: x.lower()) == 'john'
    assert field('name', key=lambda x: x.capitalize()) == 'John'

# Generated at 2022-06-17 23:20:10.783003
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', gender='female')
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='female', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='female', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.lower())
    assert field('name', gender='female', key=lambda x: x.lower())
    assert field('name', gender='male', key=lambda x: x.capitalize())

# Generated at 2022-06-17 23:20:23.416511
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Mary'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'MARY'
    assert field('name', 'generic.name') == 'John'
    assert field('name', 'generic.name', gender='male') == 'John'
    assert field('name', 'generic.name', gender='female') == 'Mary'
    assert field('name', 'generic.name', gender='male',
                 key=lambda x: x.upper()) == 'JOHN'
   

# Generated at 2022-06-17 23:20:31.709397
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

    field = AbstractField('ru')
    assert field.locale == 'ru'

    field = AbstractField(seed=42)
    assert field.seed == 42

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42

    field = AbstractField(providers=[])
    assert field._gen is not None



# Generated at 2022-06-17 23:20:42.121328
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', 'male')
    assert field('name', 'male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', 'male', key=lambda x: x.title())
    assert field('name', 'male', key=lambda x: x.title())
    assert field('name', 'male', key=lambda x: x.title())
    assert field('name', 'male', key=lambda x: x.title())

# Generated at 2022-06-17 23:20:48.617205
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None



# Generated at 2022-06-17 23:20:59.003308
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', key=lambda x: x.upper())
    assert field('name', gender='male')
    assert field('name', 'male')
    assert field('name', 'male', key=lambda x: x.upper())
    assert field('name', 'male', key=lambda x: x.upper())
    assert field('name', 'male', key=lambda x: x.upper())
    assert field('name', 'male', key=lambda x: x.upper())
    assert field('name', 'male', key=lambda x: x.upper())
    assert field('name', 'male', key=lambda x: x.upper())
    assert field('name', 'male', key=lambda x: x.upper())


# Generated at 2022-06-17 23:21:09.254051
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('person.full_name') == 'John Doe'
    assert field('person.full_name', gender='male') == 'John Doe'
    assert field('person.full_name', gender='female') == 'Jane Doe'
    assert field('person.full_name', gender='male', key=str.upper) == 'JOHN DOE'
    assert field('person.full_name', gender='female', key=str.upper) == 'JANE DOE'
    assert field('person.full_name', gender='male', key=str.upper) == 'JOHN DOE'
    assert field('person.full_name', gender='female', key=str.upper) == 'JANE DOE'

# Generated at 2022-06-17 23:21:14.857648
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', key=lambda x: x.title())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('person.full_name')
    assert field('person.full_name', key=lambda x: x.title())
    assert field('person.full_name', gender='male')
    assert field('person.full_name', gender='male', key=lambda x: x.title())

# Generated at 2022-06-17 23:21:22.285886
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:21:47.913889
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:21:49.562857
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-17 23:21:52.352415
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:21:59.795198
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'

    assert field('person.name') == 'John'
    assert field('person.name', gender='male') == 'John'
    assert field('person.name', gender='female') == 'Jane'
    assert field('person.name', gender='male', key=str.upper) == 'JOHN'
    assert field('person.name', gender='female', key=str.upper) == 'JANE'



# Generated at 2022-06-17 23:22:08.456919
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('datetime')
    assert field('datetime', year=2000)
    assert field('datetime', year=2000, month=1)
    assert field('datetime', year=2000, month=1, day=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1,
                 second=1)

# Generated at 2022-06-17 23:22:11.941631
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:22:13.899381
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('full_name') is not None



# Generated at 2022-06-17 23:22:16.044980
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

# Generated at 2022-06-17 23:22:22.701677
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    field = AbstractField()
    assert field('datetime')
    assert field('datetime', key=lambda x: x.year)
    assert field('datetime', key=lambda x: x.year) == field('datetime', key=lambda x: x.year)
    assert field('datetime', key=lambda x: x.year) != field('datetime', key=lambda x: x.year)
    assert field('datetime', key=lambda x: x.year) != field('datetime', key=lambda x: x.year)
    assert field('datetime', key=lambda x: x.year) == field('datetime', key=lambda x: x.year)

# Generated at 2022-06-17 23:22:30.897160
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42, providers=['datetime'])

# Generated at 2022-06-17 23:22:49.550048
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field is not None