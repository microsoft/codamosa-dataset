

# Generated at 2022-06-17 23:19:49.806140
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('uuid') is not None
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')

# Generated at 2022-06-17 23:20:00.816153
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper(),
                 locale='ru') == 'ИВАН'

# Generated at 2022-06-17 23:20:05.892086
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema():
        """Schema."""
        return {
            'name': field('person.full_name'),
            'age': field('person.age'),
            'gender': field('person.gender'),
            'email': field('person.email'),
            'phone': field('person.telephone'),
            'address': field('address.address'),
        }

    schema = Schema(schema)
    assert len(schema.create(iterations=5)) == 5

# Generated at 2022-06-17 23:20:13.675551
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:20:24.917103
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    def schema() -> JSON:
        """Create a schema."""
        field = Field()
        return {
            'name': field('person.full_name'),
            'age': field('person.age'),
            'email': field('person.email'),
            'phone': field('person.telephone'),
            'address': field('address.address'),
            'city': field('address.city'),
            'country': field('address.country'),
            'postcode': field('address.postcode'),
            'latitude': field('address.latitude'),
            'longitude': field('address.longitude'),
        }

    schema = Schema(schema)
    result = schema.create(iterations=3)

# Generated at 2022-06-17 23:20:32.263595
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'

    assert field('person.name') == 'John'
    assert field('person.name', gender='male') == 'John'
    assert field('person.name', gender='female') == 'Jane'
    assert field('person.name', gender='male', key=str.upper) == 'JOHN'
    assert field('person.name', gender='female', key=str.upper) == 'JANE'


# Generated at 2022-06-17 23:20:35.512689
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-17 23:20:44.131483
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:20:45.999336
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:20:51.421332
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None



# Generated at 2022-06-17 23:21:23.966897
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:21:31.384309
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = Field()
    assert field('person.full_name')
    assert field('person.full_name', gender='male')
    assert field('person.full_name', gender='female')
    assert field('person.full_name', gender='male', key=lambda x: x.upper())
    assert field('person.full_name', gender='female', key=lambda x: x.upper())
    assert field('person.full_name', gender='male', key=lambda x: x.lower())
    assert field('person.full_name', gender='female', key=lambda x: x.lower())
    assert field('person.full_name', gender='male', key=lambda x: x.capitalize())

# Generated at 2022-06-17 23:21:32.505678
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-17 23:21:40.661893
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='female') == 'Mary'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:21:49.447572
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('full_name')
    assert field('full_name', key=lambda x: x.split(' ')[0])
    assert field('full_name', key=lambda x: x.split(' ')[1])
    assert field('full_name', key=lambda x: x.split(' ')[2])
    assert field('full_name', key=lambda x: x.split(' ')[3])
    assert field('full_name', key=lambda x: x.split(' ')[4])
    assert field('full_name', key=lambda x: x.split(' ')[5])
    assert field('full_name', key=lambda x: x.split(' ')[6])

# Generated at 2022-06-17 23:21:58.542142
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', 'generic.name') == 'John'
    assert field('name', 'generic.name', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', 'generic.name', gender='male') == 'John'

# Generated at 2022-06-17 23:22:01.108998
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

# Generated at 2022-06-17 23:22:09.564030
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid') is not None
    assert field('uuid', version=4) is not None
    assert field('uuid', version=4, key=lambda x: x.hex) is not None
    assert field('uuid', version=4, key=lambda x: x.hex) is not None
    assert field('uuid', version=4, key=lambda x: x.hex) is not None
    assert field('uuid', version=4, key=lambda x: x.hex) is not None
    assert field('uuid', version=4, key=lambda x: x.hex) is not None
    assert field('uuid', version=4, key=lambda x: x.hex) is not None

# Generated at 2022-06-17 23:22:19.488710
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    class PersonSchema:
        """Person schema."""

        def __init__(self):
            """Initialize person schema."""
            self.person = Person('en')

        def __call__(self):
            """Return filled schema."""
            return {
                'name': self.person.full_name(gender=Gender.MALE),
                'age': self.person.age(),
                'job': self.person.occupation(),
            }

    schema = Schema(PersonSchema)

# Generated at 2022-06-17 23:22:28.876824
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', key=lambda x: x.upper())
    assert field('uuid', key=lambda x: x.lower())
    assert field('uuid', key=lambda x: x.replace('-', ''))
    assert field('uuid', key=lambda x: x.replace('-', '').upper())
    assert field('uuid', key=lambda x: x.replace('-', '').lower())
    assert field('uuid', key=lambda x: x.replace('-', '').lower()[:10])
    assert field('uuid', key=lambda x: x.replace('-', '').lower()[:10].upper())

# Generated at 2022-06-17 23:23:27.232570
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema() -> dict:
        """Return schema."""
        return {
            'name': field('name'),
            'surname': field('surname'),
            'age': field('age'),
            'address': field('address'),
        }

    schema = Schema(schema)
    assert schema.create(1)[0]['name'] is not None
    assert schema.create(1)[0]['surname'] is not None
    assert schema.create(1)[0]['age'] is not None
    assert schema.create(1)[0]['address'] is not None

# Generated at 2022-06-17 23:23:37.506381
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', key=lambda x: x.upper())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())

# Generated at 2022-06-17 23:23:46.489684
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('username') == 'user'
    assert field('username', key=lambda x: x.upper()) == 'USER'
    assert field('username', key=lambda x: x.upper(),
                 with_symbols=False) == 'USER'
    assert field('username', key=lambda x: x.upper(),
                 with_symbols=False) == 'USER'
    assert field('username', key=lambda x: x.upper(),
                 with_symbols=False) == 'USER'
    assert field('username', key=lambda x: x.upper(),
                 with_symbols=False) == 'USER'

# Generated at 2022-06-17 23:23:56.630986
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()

    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'

    assert field('person.name') == 'John'
    assert field('person.name', gender='male') == 'John'

# Generated at 2022-06-17 23:24:06.755304
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = AbstractField()

    assert field('name') == 'John Doe'
    assert field('name', gender='female') == 'Jane Doe'
    assert field('name', gender='male') == 'John Doe'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN DOE'
    assert field('name', gender='male', key=lambda x: x.lower()) == 'john doe'
    assert field('name', gender='male', key=lambda x: x.title()) == 'John Doe'
    assert field('name', gender='male', key=lambda x: x.capitalize()) == 'John doe'
    assert field('name', gender='male', key=lambda x: x.swapcase()) == 'jOHN dOE'

# Generated at 2022-06-17 23:24:11.960853
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': 'John',
        'surname': 'Doe',
        'age': 18,
        'address': {
            'city': 'New York',
            'country': 'USA',
        },
    }

    def schema_func() -> JSON:
        return schema

    s = Schema(schema_func)
    assert s.create(1) == [schema]

# Generated at 2022-06-17 23:24:17.791734
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    def schema():
        """Generate schema."""
        return {
            'name': Field('name'),
            'surname': Field('surname'),
            'age': Field('age'),
        }

    s = Schema(schema)
    result = s.create(iterations=2)
    assert len(result) == 2
    assert isinstance(result, list)
    assert isinstance(result[0], dict)
    assert isinstance(result[1], dict)

# Generated at 2022-06-17 23:24:27.017862
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'

# Generated at 2022-06-17 23:24:35.884839
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.lower) == 'john'
    assert field('name', gender='female', key=str.lower) == 'jane'
    assert field('name', gender='male', key=str.title) == 'John'
    assert field('name', gender='female', key=str.title) == 'Jane'

# Generated at 2022-06-17 23:24:45.433093
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    f = Field()
    assert f('name')
    assert f('name', key=lambda x: x.capitalize())
    assert f('name', gender='male')
    assert f('name', gender='male', key=lambda x: x.capitalize())
    assert f('person.full_name')
    assert f('person.full_name', key=lambda x: x.capitalize())
    assert f('person.full_name', gender='male')
    assert f('person.full_name', gender='male', key=lambda x: x.capitalize())
    assert f('person.full_name', gender='male', key=lambda x: x.capitalize())
    assert f('person.full_name', gender='male', key=lambda x: x.capitalize())


# Generated at 2022-06-17 23:26:08.289089
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen.locale == 'en'
    assert field._gen.seed is None
    assert field._table == {}

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field._gen.locale == 'ru'

    field = AbstractField(seed=42)
    assert field.seed == 42
    assert field._gen.seed == 42

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen.locale == 'ru'
    assert field._gen.seed == 42



# Generated at 2022-06-17 23:26:10.671984
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f is not None

# Generated at 2022-06-17 23:26:18.197011
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', key=lambda x: x.upper())
    assert field('uuid', key=lambda x: x.lower())
    assert field('uuid', key=lambda x: x.replace('-', ''))
    assert field('uuid', key=lambda x: x.replace('-', '').upper())
    assert field('uuid', key=lambda x: x.replace('-', '').lower())
    assert field('uuid', key=lambda x: x.replace('-', '').upper())
    assert field('uuid', key=lambda x: x.replace('-', '').lower())
    assert field('uuid', key=lambda x: x.replace('-', '').upper())

# Generated at 2022-06-17 23:26:27.978320
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', gender='female')
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='female', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='female', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='female', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())

# Generated at 2022-06-17 23:26:34.576604
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', key=lambda x: x.split('-')[0])
    assert field('person.full_name')
    assert field('person.full_name', key=lambda x: x.split(' ')[0])
    assert field('person.full_name', key=lambda x: x.split(' ')[-1])
    assert field('person.full_name', key=lambda x: x.split(' ')[0])
    assert field('person.full_name', key=lambda x: x.split(' ')[-1])
    assert field('person.full_name', key=lambda x: x.split(' ')[0])

# Generated at 2022-06-17 23:26:41.100457
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    def schema():
        """Schema."""
        return {
            'name': Field('name'),
            'surname': Field('surname'),
            'age': Field('age'),
        }

    s = Schema(schema)
    assert len(s.create(2)) == 2

# Generated at 2022-06-17 23:26:50.747223
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John Doe'
    assert field('name', gender='male') == 'John Doe'
    assert field('name', gender='female') == 'Jane Doe'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN DOE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE DOE'

    assert field('person.name') == 'John Doe'
    assert field('person.name', gender='male') == 'John Doe'
    assert field('person.name', gender='female') == 'Jane Doe'
    assert field('person.name', gender='male', key=lambda x: x.upper()) == 'JOHN DOE'

# Generated at 2022-06-17 23:26:56.144207
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:26:58.482142
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-17 23:27:09.443812
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='male', key=lambda x: x.lower()) == 'john'
    assert field('name', gender='male', key=lambda x: x.capitalize()) == 'John'
    assert field('name', gender='male', key=lambda x: x.title()) == 'John'
    assert field('name', gender='male', key=lambda x: x.swapcase()) == 'jOHN'