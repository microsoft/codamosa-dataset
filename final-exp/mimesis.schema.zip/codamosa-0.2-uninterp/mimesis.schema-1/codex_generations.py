

# Generated at 2022-06-17 23:19:46.580827
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-17 23:19:47.428566
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-17 23:19:50.956531
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:20:01.446550
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', key=lambda x: x.split('-')[0])
    assert field('uuid', key=lambda x: x.split('-')[0]) == field('uuid')
    assert field('uuid', key=lambda x: x.split('-')[0]) != field('uuid')
    assert field('uuid', key=lambda x: x.split('-')[0]) != field('uuid')
    assert field('uuid', key=lambda x: x.split('-')[0]) != field('uuid')
    assert field('uuid', key=lambda x: x.split('-')[0]) != field('uuid')

# Generated at 2022-06-17 23:20:12.200011
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', key=lambda x: x.upper())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field

# Generated at 2022-06-17 23:20:15.731871
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-17 23:20:21.631545
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField('ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField('ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None



# Generated at 2022-06-17 23:20:22.540960
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    field = AbstractField()
    assert field._gen is not None
    assert field._table is not None

# Generated at 2022-06-17 23:20:31.927236
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None

# Generated at 2022-06-17 23:20:42.331551
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Mary'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'MARY'
    assert field('name', gender='male', key=str.upper, locale='ru') == 'ИВАН'
    assert field('name', gender='female', key=str.upper, locale='ru') == 'МАРИЯ'