

# Generated at 2022-06-17 23:19:40.914873
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    def schema() -> JSON:
        """Return filled schema."""
        field = Field()
        return {
            'name': field('person.full_name'),
            'age': field('person.age'),
            'email': field('person.email'),
            'address': field('address.address'),
            'phone': field('person.telephone'),
        }

    schema = Schema(schema)
    result = schema.create(iterations=5)
    assert isinstance(result, list)
    assert len(result) == 5

# Generated at 2022-06-17 23:19:43.731947
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-17 23:19:44.683138
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-17 23:19:54.149300
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.upper, locale='ru') == 'ИВАН'
    assert field('name', gender='female', key=str.upper, locale='ru') == 'МАРИЯ'

# Generated at 2022-06-17 23:20:03.912060
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('datetime')
    assert field('datetime', year=2000)
    assert field('datetime', year=2000, month=1)
    assert field('datetime', year=2000, month=1, day=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1,
                 second=1)

# Generated at 2022-06-17 23:20:13.135384
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', version=4)
    assert field('uuid', version=5)
    assert field('uuid', version=3)
    assert field('uuid', version=1)
    assert field('uuid', version=2)
    assert field('uuid', version=6)
    assert field('uuid', version=7)
    assert field('uuid', version=8)
    assert field('uuid', version=9)
    assert field('uuid', version=10)
    assert field('uuid', version=11)
    assert field('uuid', version=12)
    assert field('uuid', version=13)
    assert field('uuid', version=14)
   

# Generated at 2022-06-17 23:20:24.440691
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', version=4)
    assert field('uuid', version=5)
    assert field('uuid', version=3, namespace='dns')
    assert field('uuid', version=3, namespace='url')
    assert field('uuid', version=3, namespace='oid')
    assert field('uuid', version=3, namespace='x500')
    assert field('uuid', version=3, namespace='dns', name='mimesis')
    assert field('uuid', version=3, namespace='url', name='mimesis')
    assert field('uuid', version=3, namespace='oid', name='mimesis')

# Generated at 2022-06-17 23:20:35.809745
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    f = AbstractField()
    assert f('name') == 'John'
    assert f('name', key=lambda x: x.upper()) == 'JOHN'
    assert f('name', key=lambda x: x.lower()) == 'john'
    assert f('name', key=lambda x: x.title()) == 'John'
    assert f('name', key=lambda x: x.capitalize()) == 'John'
    assert f('name', key=lambda x: x.swapcase()) == 'jOHN'
    assert f('name', key=lambda x: x.upper()) == 'JOHN'
    assert f('name', key=lambda x: x.upper()) == 'JOHN'
    assert f('name', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:20:37.717035
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:20:44.488972
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=123)
    assert field.locale == 'en'
    assert field.seed == 123
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=123)
    assert field.locale == 'ru'
    assert field.seed == 123
    assert field._gen is not None



# Generated at 2022-06-17 23:21:54.682926
# Unit test for method create of class Schema
def test_Schema_create():
    """Test Schema.create."""
    from mimesis.schema import Field

    def schema():
        """Return schema."""
        field = Field()
        return {
            'name': field('name'),
            'surname': field('surname'),
            'age': field('age'),
            'address': {
                'country': field('country'),
                'city': field('city'),
                'street': field('street'),
            },
        }

    schema = Schema(schema)
    result = schema.create(iterations=10)
    assert len(result) == 10
    assert isinstance(result, list)

# Generated at 2022-06-17 23:21:56.687155
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-17 23:22:00.446996
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:22:09.023365
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper())

# Generated at 2022-06-17 23:22:17.204469
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None



# Generated at 2022-06-17 23:22:27.132328
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == field('name')
    assert field('name') != field('surname')
    assert field('name', gender='female') != field('name', gender='male')
    assert field('name', gender='female') == field('name', gender='female')
    assert field('name', gender='female') != field('name', gender='male')
    assert field('name', gender='female') == field('name', gender='female')
    assert field('name', gender='female') != field('name', gender='male')
    assert field('name', gender='female') == field('name', gender='female')
    assert field('name', gender='female') != field('name', gender='male')

# Generated at 2022-06-17 23:22:33.832917
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())

# Generated at 2022-06-17 23:22:35.784994
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    schema = Schema(lambda: {'a': 1, 'b': 2})
    assert schema.create(1) == [{'a': 1, 'b': 2}]

# Generated at 2022-06-17 23:22:39.832997
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

# Generated at 2022-06-17 23:22:49.730926
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.providers.address import Address

    def schema() -> JSON:
        """Return filled schema."""