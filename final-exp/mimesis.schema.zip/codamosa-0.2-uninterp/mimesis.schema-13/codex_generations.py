

# Generated at 2022-06-17 23:19:49.100556
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', gender='female')
    assert field('name', gender='male', key=str.upper)
    assert field('name', gender='female', key=str.upper)
    assert field('name', gender='male', key=str.lower)
    assert field('name', gender='female', key=str.lower)
    assert field('name', gender='male', key=str.title)
    assert field('name', gender='female', key=str.title)
    assert field('name', gender='male', key=str.capitalize)
    assert field('name', gender='female', key=str.capitalize)

# Generated at 2022-06-17 23:20:00.309761
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:20:06.632906
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.lower) == 'john'
    assert field('name', gender='female', key=str.lower) == 'jane'
    assert field('name', gender='male', key=str.title) == 'John'
    assert field('name', gender='female', key=str.title) == 'Jane'

# Generated at 2022-06-17 23:20:07.465136
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-17 23:20:09.791465
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:20:14.442602
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field
    from mimesis.enums import Gender

    field = Field()

    def schema() -> JSON:
        """Return filled schema."""
        return {
            'name': field('person.full_name'),
            'age': field('age', minimum=18, maximum=60),
            'gender': field('choice', args=[Gender]),
        }

    s = Schema(schema)
    result = s.create(iterations=10)
    assert isinstance(result, list)
    assert len(result) == 10

# Generated at 2022-06-17 23:20:15.959406
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-17 23:20:21.506862
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema():
        """Return schema."""
        return {
            'name': field('name'),
            'surname': field('surname'),
            'age': field('age'),
        }

    schema = Schema(schema)
    data = schema.create(iterations=10)
    assert len(data) == 10

# Generated at 2022-06-17 23:20:31.964109
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema():
        """Schema."""
        return {
            'name': field('person.full_name'),
            'age': field('person.age'),
            'sex': field('person.sex'),
            'address': field('address.address'),
            'phone': field('telecom.phone_number'),
            'email': field('internet.email'),
        }

    schema = Schema(schema)
    result = schema.create(iterations=10)
    assert len(result) == 10
    assert isinstance(result, list)
    assert isinstance(result[0], dict)

# Generated at 2022-06-17 23:20:40.069367
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema() -> JSON:
        """Return filled schema."""
        return {
            'name': field('name'),
            'surname': field('surname'),
            'age': field('age'),
            'email': field('email'),
        }

    schema = Schema(schema)
    result = schema.create(iterations=10)
    assert isinstance(result, list)
    assert len(result) == 10



# Generated at 2022-06-17 23:21:18.157157
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-17 23:21:22.843352
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    f = Field()

    def schema():
        return {
            'name': f('person.full_name'),
            'age': f('person.age'),
            'job': f('person.occupation'),
            'address': f('address.address'),
            'phone': f('person.telephone'),
            'email': f('person.email'),
        }

    s = Schema(schema)
    assert len(s.create(10)) == 10

# Generated at 2022-06-17 23:21:26.958401
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', 'person.name') == 'John'
    assert field('name', 'person.name', gender='male') == 'John'
    assert field('name', 'person.name', gender='female') == 'Jane'
    assert field('name', 'person.name', gender='female',
                 key=lambda x: x.upper()) == 'JANE'
    assert field('name', 'person.name', 'person.name') == 'John'
    assert field

# Generated at 2022-06-17 23:21:35.322428
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('datetime') is not None
    assert field('datetime', year=2000) is not None
    assert field('datetime', year=2000, month=1) is not None
    assert field('datetime', year=2000, month=1, day=1) is not None
    assert field('datetime', year=2000, month=1, day=1, hour=1) is not None
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1) \
        is not None
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1,
                 second=1) is not None

# Generated at 2022-06-17 23:21:43.378833
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Mary'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'MARY'
    assert field('name', gender='male', key=lambda x: x.lower()) == 'john'
    assert field('name', gender='female', key=lambda x: x.lower()) == 'mary'
    assert field('name', gender='male', key=lambda x: x.title()) == 'John'

# Generated at 2022-06-17 23:21:52.529280
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field
    from mimesis.enums import Gender

    f = Field()

    def schema() -> JSON:
        """Return schema."""

# Generated at 2022-06-17 23:21:54.647678
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = AbstractField()
    assert field._gen.__class__.__name__ == 'Generic'

# Generated at 2022-06-17 23:22:05.347727
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.lower) == 'john'
    assert field('name', gender='female', key=str.lower) == 'jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'

# Generated at 2022-06-17 23:22:06.440526
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-17 23:22:13.353735
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field
    from mimesis.providers.address import Address

    field = Field(providers=[Address])

    def schema():
        """Return filled schema."""
        return {
            'name': field('name'),
            'surname': field('surname'),
            'address': field('address.full_address'),
        }

    s = Schema(schema)
    assert len(s.create(iterations=10)) == 10