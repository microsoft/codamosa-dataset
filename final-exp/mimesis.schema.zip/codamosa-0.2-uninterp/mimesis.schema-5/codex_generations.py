

# Generated at 2022-06-17 23:19:57.644420
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field
    from mimesis.enums import Gender

    field = Field()

    def schema() -> dict:
        """Return filled schema."""
        return {
            'name': field('person.full_name'),
            'age': field('age', minimum=18, maximum=99),
            'gender': field('choice', args=[Gender]),
        }

    s = Schema(schema)
    assert len(s.create(iterations=10)) == 10

# Generated at 2022-06-17 23:20:04.429209
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=123)
    assert field.locale == 'en'
    assert field.seed == 123
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=123)
    assert field.locale == 'ru'
    assert field.seed == 123
    assert field._gen is not None



# Generated at 2022-06-17 23:20:09.641726
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=123)
    assert field.locale == 'ru'
    assert field.seed == 123
    assert field._gen is not None



# Generated at 2022-06-17 23:20:14.369332
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-17 23:20:17.896396
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:20:26.773422
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    field = Field(providers=[Address, Person])

    def schema() -> JSON:
        """Return schema."""
        return {
            'name': field('full_name'),
            'address': field('address'),
            'phone': field('phone_number'),
        }

    schema = Schema(schema)
    result = schema.create(iterations=10)
    assert len(result) == 10

# Generated at 2022-06-17 23:20:38.018973
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('datetime') is not None
    assert field('datetime', year=2018) is not None
    assert field('datetime', year=2018, key=lambda x: x.year) == 2018
    assert field('datetime', year=2018, key=lambda x: x.month) == 1
    assert field('datetime', year=2018, key=lambda x: x.day) == 1
    assert field('datetime', year=2018, key=lambda x: x.hour) == 0
    assert field('datetime', year=2018, key=lambda x: x.minute) == 0
    assert field('datetime', year=2018, key=lambda x: x.second) == 0

# Generated at 2022-06-17 23:20:44.844169
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema() -> JSON:
        """Return filled schema."""
        return {
            'name': field('name'),
            'surname': field('surname'),
            'age': field('age'),
        }

    schema = Schema(schema)
    assert len(schema.create(5)) == 5

# Generated at 2022-06-17 23:20:46.015621
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-17 23:20:53.402384
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    def schema():
        """Return schema."""
        field = Field()
        return {
            'name': field('name'),
            'surname': field('surname'),
            'age': field('age'),
            'sex': field('sex'),
        }

    schema = Schema(schema)
    data = schema.create(iterations=5)
    assert len(data) == 5
    assert isinstance(data, list)
    assert isinstance(data[0], dict)