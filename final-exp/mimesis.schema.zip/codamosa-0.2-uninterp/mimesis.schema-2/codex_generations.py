

# Generated at 2022-06-17 23:19:27.013883
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-17 23:19:36.547347
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f.locale == 'en'
    assert f.seed is None
    assert f._gen is not None

    f = AbstractField(locale='ru')
    assert f.locale == 'ru'
    assert f.seed is None
    assert f._gen is not None

    f = AbstractField(seed=42)
    assert f.locale == 'en'
    assert f.seed == 42
    assert f._gen is not None

    f = AbstractField(locale='ru', seed=42)
    assert f.locale == 'ru'
    assert f.seed == 42
    assert f._gen is not None



# Generated at 2022-06-17 23:19:43.648462
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'

    field = AbstractField(seed=42)
    assert field.seed == 42

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42



# Generated at 2022-06-17 23:19:44.781241
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-17 23:19:46.579439
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('uuid')



# Generated at 2022-06-17 23:19:57.644146
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:20:05.305703
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', key=lambda x: x.lower()) == 'john'
    assert field('name', key=lambda x: x.capitalize()) == 'John'
    assert field('name', key=lambda x: x.title()) == 'John'
    assert field('name', key=lambda x: x.swapcase()) == 'jOHN'
    assert field('name', key=lambda x: x.replace('J', 'K')) == 'Kohn'
    assert field('name', key=lambda x: x.replace('J', 'K', 1)) == 'Kohn'

# Generated at 2022-06-17 23:20:13.640768
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Mary'
    assert field('name', gender='male', key=lambda x: x.lower()) == 'john'
    assert field('name', gender='female', key=lambda x: x.lower()) == 'mary'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'MARY'

    assert field('person.name') == 'John'
    assert field('person.name', gender='male') == 'John'

# Generated at 2022-06-17 23:20:24.873819
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', key=str.upper) == 'JOHN'
    assert field('name', key=str.lower) == 'john'
    assert field('name', key=str.capitalize) == 'John'

    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'

    assert field('name', gender='male', key=str.lower) == 'john'
    assert field('name', gender='female', key=str.lower) == 'jane'

# Generated at 2022-06-17 23:20:31.925467
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field
    from mimesis.providers.address import Address

    field = Field(providers=[Address])

    def schema():
        """Return schema."""
        return {
            'name': field('name'),
            'surname': field('surname'),
            'address': field('address'),
        }

    s = Schema(schema)
    assert len(s.create(iterations=10)) == 10

# Generated at 2022-06-17 23:20:54.842901
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.lower()) == 'john'
    assert field('name', gender='female', key=lambda x: x.lower()) == 'jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.title()) == 'John'

# Generated at 2022-06-17 23:20:59.042361
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())

# Generated at 2022-06-17 23:21:09.285747
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', key=lambda x: x.upper(), gender='male') == 'JOHN'
    assert field('name', key=lambda x: x.upper(), gender='female') == 'JANE'
    assert field('name', key=lambda x: x.upper(), gender='female') == 'JANE'
    assert field('name', key=lambda x: x.upper(), gender='female') == 'JANE'

# Generated at 2022-06-17 23:21:10.145886
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

# Generated at 2022-06-17 23:21:17.704828
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('datetime')
    assert field('datetime', year=2000)
    assert field('datetime', year=2000, month=1)
    assert field('datetime', year=2000, month=1, day=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1,
                 second=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1,
                 second=1, microsecond=1)

# Generated at 2022-06-17 23:21:21.262042
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None

# Generated at 2022-06-17 23:21:26.055580
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen.locale == 'en'
    assert field._gen.seed is None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen.locale == 'ru'
    assert field._gen.seed is None

    field = AbstractField(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42
    assert field._gen.locale == 'en'
    assert field._gen.seed == 42

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'

# Generated at 2022-06-17 23:21:32.358105
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field
    from mimesis.enums import Gender

    field = Field()

    def schema() -> JSON:
        """Return filled schema."""
        return {
            'name': field('person.full_name'),
            'gender': field('person.gender', key=lambda x: Gender(x).name),
            'age': field('person.age'),
            'job': field('person.occupation'),
        }

    schema = Schema(schema)
    data = schema.create(iterations=10)
    assert len(data) == 10

# Generated at 2022-06-17 23:21:40.493887
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42, providers=['datetime'])

# Generated at 2022-06-17 23:21:41.770589
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)