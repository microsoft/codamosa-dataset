

# Generated at 2022-06-17 23:19:36.597409
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-17 23:19:47.105796
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', key=str)
    assert field('uuid', key=lambda x: x.hex)
    assert field('uuid', key=lambda x: x.hex)
    assert field('uuid', key=lambda x: x.hex)
    assert field('uuid', key=lambda x: x.hex)
    assert field('uuid', key=lambda x: x.hex)
    assert field('uuid', key=lambda x: x.hex)
    assert field('uuid', key=lambda x: x.hex)
    assert field('uuid', key=lambda x: x.hex)
    assert field('uuid', key=lambda x: x.hex)

# Generated at 2022-06-17 23:19:58.257298
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.lower) == 'john'
    assert field('name', gender='female', key=str.lower) == 'jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
   

# Generated at 2022-06-17 23:20:03.284660
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') != field('name')
    assert field('name', key=lambda x: x.capitalize()) != field('name')
    assert field('name', key=lambda x: x.capitalize()) == field('name', key=lambda x: x.capitalize())
    assert field('name', key=lambda x: x.capitalize()) != field('name', key=lambda x: x.lower())

# Generated at 2022-06-17 23:20:07.832477
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:20:14.363593
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('datetime')
    assert field('datetime', year=2000)
    assert field('datetime', year=2000, month=1)
    assert field('datetime', year=2000, month=1, day=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1,
                 second=1)

# Generated at 2022-06-17 23:20:25.431845
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', 'en')
    assert field('name', 'en', gender='male')
    assert field('name', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', 'en', key=lambda x: x.upper())
    assert field('name', 'en', gender='male', key=lambda x: x.upper())

    assert field('person.name')
    assert field('person.name', gender='male')
    assert field('person.name', 'en')
    assert field('person.name', 'en', gender='male')

# Generated at 2022-06-17 23:20:32.904351
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:20:34.302689
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-17 23:20:37.879582
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:21:02.788323
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('person.full_name') == 'John Smith'
    assert field('person.full_name', key=lambda x: x.split()[0]) == 'John'
    assert field('person.full_name', key=lambda x: x.split()[-1]) == 'Smith'
    assert field('person.full_name', key=lambda x: x.split()[-1],
                 gender='female') == 'Johnson'
    assert field('person.full_name', key=lambda x: x.split()[-1],
                 gender='male') == 'Smith'
    assert field('person.full_name', key=lambda x: x.split()[-1],
                 gender='male') == 'Smith'

# Generated at 2022-06-17 23:21:12.171352
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None

    field = AbstractField(seed=12345)
    assert field.locale == 'en'
    assert field.seed == 12345

    field = AbstractField(locale='ru', seed=12345)
    assert field.locale == 'ru'
    assert field.seed == 12345

    field = AbstractField(locale='ru', seed=12345,
                          providers=[])
    assert field.locale == 'ru'
    assert field.seed == 12345

# Generated at 2022-06-17 23:21:16.576832
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'

    field = AbstractField(seed=123)
    assert field.seed == 123

    field = AbstractField(locale='ru', seed=123)
    assert field.locale == 'ru'
    assert field.seed == 123



# Generated at 2022-06-17 23:21:23.546523
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') is not None
    assert field('name', gender='male') is not None
    assert field('name', gender='male', key=lambda x: x.upper()) is not None
    assert field('name', gender='male', key=lambda x: x.upper()) is not None
    assert field('name', gender='male', key=lambda x: x.upper()) is not None
    assert field('name', gender='male', key=lambda x: x.upper()) is not None
    assert field('name', gender='male', key=lambda x: x.upper()) is not None
    assert field('name', gender='male', key=lambda x: x.upper()) is not None

# Generated at 2022-06-17 23:21:24.502676
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-17 23:21:31.886210
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', key=lambda x: x.lower()) == 'john'
    assert field('name', key=lambda x: x.capitalize()) == 'John'
    assert field('name', key=lambda x: x.title()) == 'John'
    assert field('name', key=lambda x: x.swapcase()) == 'jOHN'
    assert field('name', key=lambda x: x.replace('J', 'K')) == 'Kohn'
    assert field('name', key=lambda x: x.replace('J', 'K', 1)) == 'Kohn'

# Generated at 2022-06-17 23:21:34.845824
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-17 23:21:42.769664
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:21:45.649982
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None

# Generated at 2022-06-17 23:21:55.117544
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') is not None
    assert field('name', gender='male') is not None
    assert field('name', gender='female') is not None
    assert field('name', gender='male', key=lambda x: x.capitalize()) is not None
    assert field('name', gender='female', key=lambda x: x.capitalize()) is not None
    assert field('name', gender='male', key=lambda x: x.upper()) is not None
    assert field('name', gender='female', key=lambda x: x.upper()) is not None
    assert field('name', gender='male', key=lambda x: x.lower()) is not None
    assert field('name', gender='female', key=lambda x: x.lower()) is not None


# Generated at 2022-06-17 23:22:29.975824
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('name') == 'John Doe'
    assert field('name', gender='male') == 'John Doe'
    assert field('name', gender='female') == 'Jane Doe'
    assert field('name', gender='male', key=str.upper) == 'JOHN DOE'
    assert field('name', gender='female', key=str.upper) == 'JANE DOE'
    assert field('name', gender='male', key=str.upper, locale='ru') == 'ДЖОН ДОУ'
    assert field('name', gender='female', key=str.upper, locale='ru') == 'ДЖЕЙН ДОУ'

# Generated at 2022-06-17 23:22:31.925396
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f.locale == 'en'
    assert f.seed is None
    assert f._gen is not None
    assert f._table == {}

# Generated at 2022-06-17 23:22:33.387490
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-17 23:22:38.564419
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('datetime') is not None
    assert field('datetime', year=2000) is not None
    assert field('datetime', year=2000, month=1) is not None
    assert field('datetime', year=2000, month=1, day=1) is not None
    assert field('datetime', year=2000, month=1, day=1, hour=1) is not None
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1) is not None
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1, second=1) is not None

# Generated at 2022-06-17 23:22:40.662200
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-17 23:22:44.322408
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=12345)
    assert field.locale == 'en'
    assert field.seed == 12345
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=12345)
    assert field.locale == 'ru'
    assert field.seed == 12345
    assert field._gen is not None



# Generated at 2022-06-17 23:22:51.803966
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', 'en')
    assert field('name', 'en', gender='male')
    assert field('name', key=lambda x: x.upper())
    assert field('name', 'en', key=lambda x: x.upper())
    assert field('name', 'en', gender='male', key=lambda x: x.upper())
    assert field('internet.email')
    assert field('internet.email', key=lambda x: x.upper())
    assert field('internet.email', 'en')
    assert field('internet.email', 'en', key=lambda x: x.upper())

# Generated at 2022-06-17 23:22:56.463011
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:23:05.135821
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:23:13.064870
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', key=lambda x: x.lower()) == 'john'
    assert field('name', key=lambda x: x.capitalize()) == 'John'
    assert field('name', key=lambda x: x.title()) == 'John'
    assert field('name', key=lambda x: x.swapcase()) == 'jOHN'
    assert field('name', key=lambda x: x.replace('o', 'a')) == 'Jan'
    assert field('name', key=lambda x: x.replace('o', 'a', 1)) == 'Jan'

# Generated at 2022-06-17 23:23:38.786004
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    from mimesis.providers.address import Address

    field = AbstractField()
    assert field('address.street_name')
    assert field('address.street_name', key=lambda x: x.upper())
    assert field('address.street_name', key=lambda x: x.lower())
    assert field('address.street_name', key=lambda x: x.capitalize())
    assert field('address.street_name', key=lambda x: x.title())
    assert field('address.street_name', key=lambda x: x.swapcase())

    field = AbstractField(providers=[Address])
    assert field('street_name')
    assert field('street_name', key=lambda x: x.upper())

# Generated at 2022-06-17 23:23:40.708467
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-17 23:23:51.412451
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.upper, locale='ru') == 'ДЖОН'
    assert field('name', gender='female', key=str.upper, locale='ru') == 'ДЖЕЙН'

# Generated at 2022-06-17 23:23:59.059299
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=123)
    assert field.locale == 'ru'
    assert field.seed == 123
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=123, providers=['datetime'])
    assert field.locale == 'ru'
    assert field.seed == 123
    assert field._gen is not None

# Generated at 2022-06-17 23:24:08.249127
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())


# Generated at 2022-06-17 23:24:17.630687
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:24:26.825706
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', key=lambda x: x.replace('-', ''))
    assert field('uuid', key=lambda x: x.replace('-', ''), version=4)
    assert field('uuid', version=4)
    assert field('uuid', version=4, key=lambda x: x.replace('-', ''))
    assert field('uuid', version=4, key=lambda x: x.replace('-', ''))
    assert field('uuid', version=4, key=lambda x: x.replace('-', ''))
    assert field('uuid', version=4, key=lambda x: x.replace('-', ''))

# Generated at 2022-06-17 23:24:35.757663
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = Field()
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', 'en')
    assert field('name', 'en', key=lambda x: x.capitalize())
    assert field('name', 'en', gender='male')
    assert field('name', 'en', gender='male', key=lambda x: x.capitalize())
    assert field('name', locale='en')
    assert field('name', locale='en', key=lambda x: x.capitalize())
    assert field('name', locale='en', gender='male')

# Generated at 2022-06-17 23:24:45.177859
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f.locale == 'en'
    assert f.seed is None
    assert f._gen is not None
    assert f._table == {}

    f = AbstractField(locale='ru')
    assert f.locale == 'ru'
    assert f.seed is None
    assert f._gen is not None
    assert f._table == {}

    f = AbstractField(seed=42)
    assert f.locale == 'en'
    assert f.seed == 42
    assert f._gen is not None
    assert f._table == {}

    f = AbstractField(locale='ru', seed=42)
    assert f.locale == 'ru'
    assert f.seed == 42
    assert f._gen is not None
    assert f._table == {}


# Generated at 2022-06-17 23:24:53.166902
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', key=lambda x: x.capitalize(), gender='male')
    assert field('name', key=lambda x: x.capitalize(), gender='female')
    assert field('name', key=lambda x: x.capitalize(), gender='male')
    assert field('name', key=lambda x: x.capitalize(), gender='female')
    assert field('name', key=lambda x: x.capitalize(), gender='male')
    assert field('name', key=lambda x: x.capitalize(), gender='female')

# Generated at 2022-06-17 23:25:17.124250
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == field('name')
    assert field('name') != field('surname')
    assert field('name', key=lambda x: x.upper()) == field(
        'name', key=lambda x: x.upper())
    assert field('name', key=lambda x: x.upper()) != field(
        'name', key=lambda x: x.lower())
    assert field('name', key=lambda x: x.upper()) != field(
        'surname', key=lambda x: x.upper())



# Generated at 2022-06-17 23:25:27.137370
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == field('name')
    assert field('name', key=lambda x: x.upper()) == field('name').upper()
    assert field('name', key=lambda x: x.upper()) == field('name').upper()
    assert field('name', key=lambda x: x.upper()) == field('name').upper()
    assert field('name', key=lambda x: x.upper()) == field('name').upper()
    assert field('name', key=lambda x: x.upper()) == field('name').upper()
    assert field('name', key=lambda x: x.upper()) == field('name').upper()
    assert field('name', key=lambda x: x.upper()) == field('name').upper()

# Generated at 2022-06-17 23:25:36.666292
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'

# Generated at 2022-06-17 23:25:47.177930
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    f = AbstractField()
    assert f('name') == f('name')
    assert f('name', gender='male') == f('name', gender='male')
    assert f('name', gender='male') != f('name', gender='female')
    assert f('name', gender='male') != f('name', gender='male', fullname=True)
    assert f('name', gender='male', fullname=True) != f('name', gender='male')
    assert f('name', gender='male', fullname=True) != f('name', gender='female')
    assert f('name', gender='male', fullname=True) != f('name', gender='male',
                                                        fullname=False)

# Generated at 2022-06-17 23:25:52.069610
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', gender='female')
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='female', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.lower())
    assert field('name', gender='female', key=lambda x: x.lower())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='female', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.capitalize())

# Generated at 2022-06-17 23:26:01.909720
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', gender='male')
    assert field('name', gender='female')
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='female', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='female', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='female', key=lambda x: x.capitalize())

# Generated at 2022-06-17 23:26:09.819158
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.lower()) == 'john'
    assert field('name', gender='female', key=lambda x: x.lower()) == 'jane'
    assert field('name', gender='male', key=lambda x: x.capitalize()) == 'John'
    assert field('name', gender='female', key=lambda x: x.capitalize()) == 'Jane'
    assert field

# Generated at 2022-06-17 23:26:17.681873
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('full_name') == 'John Doe'
    assert field('full_name', gender='male') == 'John Doe'
    assert field('full_name', gender='female') == 'Jane Doe'
    assert field('full_name', gender='male', key=str.upper) == 'JOHN DOE'
    assert field('full_name', gender='female', key=str.upper) == 'JANE DOE'
    assert field('full_name', gender='male', key=str.lower) == 'john doe'
    assert field('full_name', gender='female', key=str.lower) == 'jane doe'


# Generated at 2022-06-17 23:26:27.634364
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Mary'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'MARY'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'MARY'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:26:34.282842
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('name') == 'John Doe'
    assert field('name', gender='male') == 'John Doe'
    assert field('name', gender='female') == 'Jane Doe'
    assert field('name', gender='male', middle_name=True) == 'John Michael Doe'
    assert field('name', gender='female', middle_name=True) == 'Jane Marie Doe'
    assert field('name', gender='male', middle_name=True, last_name=True) == 'John Michael Doe'
    assert field('name', gender='female', middle_name=True, last_name=True) == 'Jane Marie Doe'
    assert field('name', gender='male', middle_name=True, last_name=True, suffix=True) == 'John Michael Doe Jr.'

# Generated at 2022-06-17 23:27:12.554517
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__ method."""
    field = AbstractField()

    assert field('name') == 'John Doe'
    assert field('name', gender='male') == 'John Doe'
    assert field('name', gender='female') == 'Jane Doe'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN DOE'

    assert field('person.name') == 'John Doe'
    assert field('person.name', gender='male') == 'John Doe'
    assert field('person.name', gender='female') == 'Jane Doe'
    assert field('person.name', gender='male',
                 key=lambda x: x.upper()) == 'JOHN DOE'

    assert field('person.name', gender='male') == 'John Doe'

# Generated at 2022-06-17 23:27:21.788801
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:27:32.049130
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.upper, locale='ru') == 'ДЖОН'
    assert field('name', gender='female', key=str.upper, locale='ru') == 'ДЖЕЙН'

# Generated at 2022-06-17 23:27:43.788087
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'

# Generated at 2022-06-17 23:27:52.882393
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', key=lambda x: x.title())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='female')
    assert field('name', gender='female', key=lambda x: x.title())
    assert field('name', gender='female', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='female', key=lambda x: x.title())

# Generated at 2022-06-17 23:28:03.337034
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('person.full_name') == 'John Doe'
    assert field('person.full_name', key=lambda x: x.split(' ')[0]) == 'John'
    assert field('person.full_name', key=lambda x: x.split(' ')[1]) == 'Doe'
    assert field('person.full_name', key=lambda x: x.split(' ')[0]) == 'John'
    assert field('person.full_name', key=lambda x: x.split(' ')[1]) == 'Doe'
    assert field('person.full_name', key=lambda x: x.split(' ')[0]) == 'John'
    assert field('person.full_name', key=lambda x: x.split(' ')[1]) == 'Doe'

# Generated at 2022-06-17 23:28:11.129528
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', key=lambda x: x.upper())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field

# Generated at 2022-06-17 23:28:21.373722
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'

# Generated at 2022-06-17 23:28:30.205624
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('uuid')
    assert field('uuid', version=4)
    assert field('uuid', version=5)
    assert field('uuid', version=1)
    assert field('uuid', version=3)
    assert field('uuid', version=1, key=lambda x: x.hex)
    assert field('uuid', version=3, key=lambda x: x.hex)
    assert field('uuid', version=4, key=lambda x: x.hex)
    assert field('uuid', version=5, key=lambda x: x.hex)
    assert field('uuid', version=1, key=lambda x: x.int)

# Generated at 2022-06-17 23:28:39.132889
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('datetime')
    assert field('datetime', format='%Y-%m-%d')
    assert field('datetime', format='%Y-%m-%d', date_format='%Y-%m-%d')
    assert field('datetime', format='%Y-%m-%d', date_format='%Y-%m-%d',
                 end_datetime='2019-01-01')
    assert field('datetime', format='%Y-%m-%d', date_format='%Y-%m-%d',
                 start_datetime='2019-01-01')