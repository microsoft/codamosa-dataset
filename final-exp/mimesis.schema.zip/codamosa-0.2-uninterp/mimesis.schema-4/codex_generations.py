

# Generated at 2022-06-17 23:20:04.304749
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = Field()
    assert field('full_name') == 'John Doe'
    assert field('full_name', gender='male') == 'John Doe'
    assert field('full_name', gender='female') == 'Jane Doe'
    assert field('full_name', gender='male', key=str.upper) == 'JOHN DOE'
    assert field('full_name', gender='female', key=str.upper) == 'JANE DOE'
    assert field('full_name', gender='male', key=str.lower) == 'john doe'
    assert field('full_name', gender='female', key=str.lower) == 'jane doe'
    assert field('full_name', gender='male', key=str.title) == 'John Doe'

# Generated at 2022-06-17 23:20:13.306655
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', key=str.upper) == 'JOHN'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.upper) == 'JOHN'

# Generated at 2022-06-17 23:20:24.617083
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__()."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', key=lambda x: x.split('-'))
    assert field('uuid', key=lambda x: x.split('-'))[0] == '8'
    assert field('uuid', key=lambda x: x.split('-'))[1] == '0'
    assert field('uuid', key=lambda x: x.split('-'))[2] == '0'
    assert field('uuid', key=lambda x: x.split('-'))[3] == '0'
    assert field('uuid', key=lambda x: x.split('-'))[4] == '0'

# Generated at 2022-06-17 23:20:35.968533
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis import Person
    from mimesis.schema import Field

    person = Person('en')
    field = Field(locale='en')

    def schema() -> dict:
        return {
            'name': field('person.full_name'),
            'age': field('person.age'),
            'gender': field('person.gender'),
            'occupation': field('person.occupation'),
        }

    schema = Schema(schema)
    data = schema.create(iterations=10)
    assert len(data) == 10

    for item in data:
        assert isinstance(item, dict)
        assert item['name'] == person.full_name()
        assert item['age'] == person.age()
        assert item['gender'] == person.gender

# Generated at 2022-06-17 23:20:42.396854
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    def schema() -> JSON:
        """Schema for test."""
        return {
            'name': Field('name'),
            'surname': Field('surname'),
            'age': Field('age'),
        }

    schema = Schema(schema)
    result = schema.create(iterations=10)
    assert len(result) == 10
    assert isinstance(result, list)
    assert isinstance(result[0], dict)

# Generated at 2022-06-17 23:20:53.237858
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('person.full_name')
    assert field('person.full_name', gender='male')
    assert field('person.full_name', key=lambda x: x.upper())
    assert field('person.full_name', gender='male', key=lambda x: x.upper())
    assert field('person.full_name', gender='male', key=lambda x: x.upper())
    assert field('person.full_name', key=lambda x: x.upper())
    assert field('person.full_name', gender='male', key=lambda x: x.upper())
    assert field('person.full_name', key=lambda x: x.upper())

# Generated at 2022-06-17 23:21:03.090290
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field

# Generated at 2022-06-17 23:21:10.442153
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    def schema():
        """Return schema."""
        return {
            'name': Person('en').full_name(),
            'address': Address('en').address(),
        }

    s = Schema(schema)
    assert isinstance(s.create(), list)
    assert isinstance(s.create(iterations=10), list)

# Generated at 2022-06-17 23:21:18.018215
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema() -> dict:
        """Return filled schema."""
        return {
            'name': field('name'),
            'surname': field('surname'),
            'age': field('age'),
            'address': field('address'),
            'email': field('email'),
            'phone': field('phone'),
            'username': field('username'),
            'password': field('password'),
        }

    s = Schema(schema)
    assert isinstance(s.create(), list)
    assert isinstance(s.create(iterations=2), list)
    assert isinstance(s.create(iterations=3), list)

# Generated at 2022-06-17 23:21:24.264773
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', key=lambda x: x.split('-'))
    assert field('uuid', key=lambda x: x.split('-'))
    assert field('uuid', key=lambda x: x.split('-'))
    assert field('uuid', key=lambda x: x.split('-'))
    assert field('uuid', key=lambda x: x.split('-'))
    assert field('uuid', key=lambda x: x.split('-'))
    assert field('uuid', key=lambda x: x.split('-'))
    assert field('uuid', key=lambda x: x.split('-'))