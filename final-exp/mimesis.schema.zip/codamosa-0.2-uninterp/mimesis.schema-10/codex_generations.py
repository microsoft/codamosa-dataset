

# Generated at 2022-06-17 23:20:10.582419
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:20:20.098860
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', 'en')
    assert field('name', 'en', gender='male')
    assert field('name', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', 'en', key=lambda x: x.upper())
    assert field('name', 'en', gender='male', key=lambda x: x.upper())

# Generated at 2022-06-17 23:20:31.593308
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', gender='male')
    assert field('name', gender='female')
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='female', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='female', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='female', key=lambda x: x.capitalize())

# Generated at 2022-06-17 23:20:42.049775
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = Field()
    assert field('full_name')
    assert field('full_name', key=lambda x: x.split(' ')[0])
    assert field('full_name', key=lambda x: x.split(' ')[-1])
    assert field('full_name', key=lambda x: x.split(' ')[0])
    assert field('full_name', key=lambda x: x.split(' ')[-1])
    assert field('full_name', key=lambda x: x.split(' ')[0])
    assert field('full_name', key=lambda x: x.split(' ')[-1])
    assert field('full_name', key=lambda x: x.split(' ')[0])

# Generated at 2022-06-17 23:20:53.173836
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('datetime')
    assert field('datetime', year=2000)
    assert field('datetime', year=2000, month=1)
    assert field('datetime', year=2000, month=1, day=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1,
                 second=1)