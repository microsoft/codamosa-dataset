

# Generated at 2022-06-17 23:19:41.824487
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42, providers=['datetime'])
    assert field.locale == 'ru'
    assert field.seed == 42

# Generated at 2022-06-17 23:19:52.141239
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:20:02.203198
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:20:12.528664
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:20:19.894266
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    def schema() -> JSON:
        """Return schema."""
        return {
            'name': Person('en').full_name(),
            'address': Address('en').address(),
        }

    s = Schema(schema)
    assert len(s.create()) == 1
    assert len(s.create(iterations=10)) == 10

# Generated at 2022-06-17 23:20:26.915073
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis import Person

    person = Person('ru')
    schema = {
        'name': person.full_name,
        'age': person.age,
        'gender': person.gender,
    }

    s = Schema(schema)
    result = s.create(iterations=10)
    assert isinstance(result, list)
    assert len(result) == 10

# Generated at 2022-06-17 23:20:34.080912
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema():
        """Schema."""
        return {
            'name': field('name'),
            'surname': field('surname'),
            'address': field('address'),
            'age': field('age'),
        }

    schema = Schema(schema)
    data = schema.create(iterations=10)
    assert len(data) == 10

# Generated at 2022-06-17 23:20:41.122933
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema() -> dict:
        """Return filled schema."""
        return {
            'name': field('name'),
            'surname': field('surname'),
            'age': field('age'),
        }

    schema = Schema(schema)
    assert isinstance(schema.create(), list)
    assert len(schema.create()) == 1
    assert len(schema.create(3)) == 3

# Generated at 2022-06-17 23:20:52.450171
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    f = Field()
    assert f('name') == 'John'
    assert f('name', gender='male') == 'John'
    assert f('name', gender='female') == 'Jane'
    assert f('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert f('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert f('person.name') == 'John'
    assert f('person.name', gender='male') == 'John'
    assert f('person.name', gender='female') == 'Jane'
    assert f('person.name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:20:59.110359
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'

    field = AbstractField(seed=42)
    assert field.seed == 42

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42



# Generated at 2022-06-17 23:21:39.689069
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None



# Generated at 2022-06-17 23:21:45.627134
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('person.name')
    assert field('person.name', gender='male')
    assert field('person.name', key=lambda x: x.upper())
    assert field('person.name', gender='male', key=lambda x: x.upper())

# Generated at 2022-06-17 23:21:55.119252
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:22:00.943252
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('full_name') == 'John Doe'
    assert field('full_name', gender='male') == 'John Doe'
    assert field('full_name', gender='female') == 'Jane Doe'
    assert field('full_name', gender='male', key=str.upper) == 'JOHN DOE'
    assert field('full_name', gender='female', key=str.upper) == 'JANE DOE'
    assert field('full_name', gender='male', key=str.lower) == 'john doe'
    assert field('full_name', gender='female', key=str.lower) == 'jane doe'
    assert field('full_name', gender='male', key=str.title) == 'John Doe'

# Generated at 2022-06-17 23:22:09.440804
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.lower()) == 'john'
    assert field('name', gender='female', key=lambda x: x.lower()) == 'jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.title()) == 'John'

# Generated at 2022-06-17 23:22:10.502666
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-17 23:22:17.956442
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None

    field = AbstractField(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42



# Generated at 2022-06-17 23:22:27.664792
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('person.name')
    assert field('person.name', key=lambda x: x.capitalize())
    assert field('person.name', gender='male')
    assert field('person.name', gender='male', key=lambda x: x.capitalize())
    assert field('person.name', gender='male', key=lambda x: x.capitalize())
    assert field('person.name', gender='male', key=lambda x: x.capitalize())

# Generated at 2022-06-17 23:22:29.842817
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:22:31.569828
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    field = AbstractField()
    assert field._gen is not None
    assert field._table is not None