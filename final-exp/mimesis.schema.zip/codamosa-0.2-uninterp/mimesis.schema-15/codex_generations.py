

# Generated at 2022-06-17 23:19:58.257674
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:20:10.437150
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('person.full_name') == 'John Doe'
    assert field('person.full_name', gender='male') == 'John Doe'
    assert field('person.full_name', gender='female') == 'Jane Doe'
    assert field('person.full_name', gender='female', key=str.upper) == 'JANE DOE'
    assert field('person.full_name', gender='female', key=str.upper) == 'JANE DOE'
    assert field('person.full_name', gender='female', key=str.upper) == 'JANE DOE'
    assert field('person.full_name', gender='female', key=str.upper) == 'JANE DOE'

# Generated at 2022-06-17 23:20:22.638158
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema() -> JSON:
        """Return filled schema."""
        return {
            'name': field('person.full_name'),
            'age': field('person.age'),
            'sex': field('person.sex'),
            'address': field('address.address'),
            'phone': field('telecom.phone_number'),
            'email': field('internet.email'),
            'company': field('business.company'),
            'job': field('business.job_title'),
        }

    schema = Schema(schema)
    result = schema.create(iterations=10)
    assert len(result) == 10
    assert isinstance(result, list)

# Generated at 2022-06-17 23:20:34.222307
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', 'en')
    assert field('name', 'en', key=lambda x: x.capitalize())
    assert field('name', 'en', gender='male')
    assert field('name', 'en', gender='male', key=lambda x: x.capitalize())
    assert field('name', locale='en')
    assert field('name', locale='en', key=lambda x: x.capitalize())
    assert field('name', locale='en', gender='male')

# Generated at 2022-06-17 23:20:37.796008
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    schema = Schema(lambda: {'foo': 'bar'})
    assert schema.create(iterations=3) == [{'foo': 'bar'}] * 3

# Generated at 2022-06-17 23:20:43.357273
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field._gen.__class__.__name__ == 'Generic'
    assert field.locale == 'en'
    assert field.seed is None
    assert field._table == {}

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'

    field = AbstractField(seed=42)
    assert field.seed == 42

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42



# Generated at 2022-06-17 23:20:51.936386
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=123)
    assert field.locale == 'en'
    assert field.seed == 123
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=123)
    assert field.locale == 'ru'
    assert field.seed == 123
    assert field._gen is not None

# Generated at 2022-06-17 23:20:55.142811
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

# Generated at 2022-06-17 23:21:05.535630
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=42, providers=['datetime'])
    assert field.locale == 'ru'

# Generated at 2022-06-17 23:21:13.960465
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') is not None
    assert field('name', gender='male') is not None
    assert field('name', gender='male', key=lambda x: x.capitalize()) is not None
    assert field('name', gender='male', key=lambda x: x.capitalize()) is not None
    assert field('name', gender='male', key=lambda x: x.capitalize()) is not None
    assert field('name', gender='male', key=lambda x: x.capitalize()) is not None
    assert field('name', gender='male', key=lambda x: x.capitalize()) is not None
    assert field('name', gender='male', key=lambda x: x.capitalize()) is not None

# Generated at 2022-06-17 23:21:37.498882
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', key=lambda x: x.upper())
    assert field('uuid', key=lambda x: x.upper())
    assert field('uuid', key=lambda x: x.upper())
    assert field('uuid', key=lambda x: x.upper())
    assert field('uuid', key=lambda x: x.upper())
    assert field('uuid', key=lambda x: x.upper())
    assert field('uuid', key=lambda x: x.upper())
    assert field('uuid', key=lambda x: x.upper())
    assert field('uuid', key=lambda x: x.upper())
    assert field('uuid', key=lambda x: x.upper())

# Generated at 2022-06-17 23:21:43.764803
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None

    field = AbstractField(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42

    field = AbstractField(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42



# Generated at 2022-06-17 23:21:52.874135
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('name') == field._gen.name()
    assert field('name', key=lambda x: x.upper()) == field._gen.name().upper()
    assert field('name', gender='male') == field._gen.name(gender='male')
    assert field('name', gender='male', key=lambda x: x.upper()) == \
        field._gen.name(gender='male').upper()
    assert field('person.name') == field._gen.person.name()
    assert field('person.name', key=lambda x: x.upper()) == \
        field._gen.person.name().upper()
    assert field('person.name', gender='male') == \
        field._gen.person.name(gender='male')

# Generated at 2022-06-17 23:21:54.126910
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-17 23:22:00.455047
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid') is not None
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')
    assert field('uuid') != field('uuid')

# Generated at 2022-06-17 23:22:09.023684
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Mary'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'MARY'
    assert field('name', gender='male', key=lambda x: x.lower()) == 'john'
    assert field('name', gender='female', key=lambda x: x.lower()) == 'mary'
    assert field('name', gender='male', key=lambda x: x.title()) == 'John'

# Generated at 2022-06-17 23:22:16.044975
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of AbstractField."""
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None

    field = Field(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None

    field = Field(seed=42)
    assert field.locale == 'en'
    assert field.seed == 42

    field = Field(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42



# Generated at 2022-06-17 23:22:22.691215
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'

# Generated at 2022-06-17 23:22:30.896932
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Mary'
    assert field('name', gender='male', key=lambda x: x.lower()) == 'john'
    assert field('name', gender='female', key=lambda x: x.lower()) == 'mary'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'MARY'
    assert field('name', gender='male', key=lambda x: x.title()) == 'John'

# Generated at 2022-06-17 23:22:36.778993
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field

    f = Field()

    def schema():
        return {
            'name': f('person.full_name'),
            'age': f('person.age'),
            'gender': f('person.gender'),
        }

    s = Schema(schema)

# Generated at 2022-06-17 23:23:09.264680
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}



# Generated at 2022-06-17 23:23:15.336040
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', gender='female')
    assert field('name', gender='male')
    assert field('name', gender='female', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='female', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='female', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())

# Generated at 2022-06-17 23:23:23.365376
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field
    from mimesis.enums import Gender

    field = Field()

    def schema() -> JSON:
        """Return filled schema."""

# Generated at 2022-06-17 23:23:32.584033
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')
    assert field('uuid', key=lambda x: x.split('-')[0])
    assert field('person.full_name')
    assert field('person.full_name', key=lambda x: x.split(' ')[0])
    assert field('person.full_name', key=lambda x: x.split(' ')[1])
    assert field('person.full_name', key=lambda x: x.split(' ')[2])
    assert field('person.full_name', key=lambda x: x.split(' ')[3])
    assert field('person.full_name', key=lambda x: x.split(' ')[4])

# Generated at 2022-06-17 23:23:39.539409
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:23:50.236040
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Mary'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'MARY'
    assert field('name', gender='male', key=str.lower) == 'john'
    assert field('name', gender='female', key=str.lower) == 'mary'
    assert field('name', gender='male', key=str.lower) == 'john'
    assert field('name', gender='female', key=str.lower) == 'mary'

# Generated at 2022-06-17 23:24:00.026506
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.lower()) == 'john'
    assert field('name', gender='female', key=lambda x: x.lower()) == 'jane'
    assert field('name', gender='male', key=lambda x: x.title()) == 'John'

# Generated at 2022-06-17 23:24:07.685879
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis import Person
    from mimesis.enums import Gender

    person = Person('en')

    def schema() -> JSON:
        """Return filled schema."""
        return {
            'name': person.full_name(gender=Gender.FEMALE),
            'age': person.age(),
            'job': person.occupation(),
        }

    data = Schema(schema).create(iterations=10)
    assert len(data) == 10
    assert isinstance(data, list)
    assert isinstance(data[0], dict)

# Generated at 2022-06-17 23:24:15.351119
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    field = Field(providers=[Address, Person])

    def schema() -> JSON:
        """Return filled schema."""
        return {
            'name': field('full_name'),
            'address': field('address'),
            'phone': field('phone_number'),
        }

    s = Schema(schema)
    assert len(s.create(iterations=5)) == 5

# Generated at 2022-06-17 23:24:21.033350
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field

    field = Field()

    def schema():
        return {
            'name': field('name'),
            'surname': field('surname'),
            'age': field('age'),
            'sex': field('sex'),
        }

    schema = Schema(schema)
    result = schema.create(iterations=5)
    assert len(result) == 5
    assert isinstance(result, list)
    assert isinstance(result[0], dict)