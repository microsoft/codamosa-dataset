

# Generated at 2022-06-17 23:19:36.151358
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('person.name')
    assert field('person.name', gender='male')
    assert field('person.name', gender='male', key=lambda x: x.capitalize())

# Generated at 2022-06-17 23:19:46.429047
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field
    from mimesis.enums import Gender

    field = Field()

    def schema() -> JSON:
        """Return schema."""
        return {
            'name': field('person.full_name', key=lambda x: x.split()[0]),
            'surname': field('person.full_name', key=lambda x: x.split()[1]),
            'age': field('datetime.age'),
            'gender': field('person.gender', key=lambda x: Gender(x).name),
        }

    schema = Schema(schema)
    data = schema.create(iterations=10)
    assert len(data) == 10

# Generated at 2022-06-17 23:19:57.464518
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=str.upper) == 'JOHN'
    assert field('name', gender='female', key=str.upper) == 'JANE'

    assert field('person.name') == 'John'
    assert field('person.name', gender='male') == 'John'
    assert field('person.name', gender='female') == 'Jane'
    assert field('person.name', gender='male', key=str.upper) == 'JOHN'
    assert field('person.name', gender='female', key=str.upper) == 'JANE'

# Generated at 2022-06-17 23:20:03.501361
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field

    def schema() -> JSON:
        """Return filled schema."""
        field = Field()
        return {
            'name': field('person.full_name'),
            'age': field('person.age'),
            'gender': field('person.gender'),
            'address': field('address.address'),
            'phone': field('person.telephone'),
        }

    schema = Schema(schema)
    assert len(schema.create(iterations=3)) == 3

# Generated at 2022-06-17 23:20:10.366953
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema import Field

    def schema() -> dict:
        """Return filled schema."""
        field = Field()
        return {
            'name': field('name'),
            'surname': field('surname'),
            'age': field('age', minimum=18, maximum=99),
        }

    schema = Schema(schema)
    assert len(schema.create(iterations=10)) == 10

# Generated at 2022-06-17 23:20:22.917526
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('datetime')
    assert field('datetime', year=2000)
    assert field('datetime', year=2000, month=1)
    assert field('datetime', year=2000, month=1, day=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1)
    assert field('datetime', year=2000, month=1, day=1, hour=1, minute=1,
                 second=1)

# Generated at 2022-06-17 23:20:34.424521
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    from mimesis.providers.text import Text
    from mimesis.providers.misc import Misc

    def schema() -> dict:
        """Create a schema."""
        return {
            'name': Person('en').full_name(),
            'address': Address('en').address(),
            'email': Internet('en').email(),
            'text': Text('en').text(),
            'number': Misc('en').number(),
        }

    s = Schema(schema)
    data = s.create(iterations=10)
    assert len(data) == 10
    assert isinstance(data, list)


# Generated at 2022-06-17 23:20:43.622141
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', gender='female')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', key=lambda x: x.capitalize(), gender='female')
    assert field('name', key=lambda x: x.capitalize(), gender='female')
    assert field('name', key=lambda x: x.capitalize(), gender='female')
    assert field('name', key=lambda x: x.capitalize(), gender='female')
    assert field('name', key=lambda x: x.capitalize(), gender='female')
    assert field('name', key=lambda x: x.capitalize(), gender='female')

# Generated at 2022-06-17 23:20:51.897589
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    def schema() -> JSON:
        """Return schema."""
        person = Person('en')
        return {
            'name': person.full_name(gender=Gender.FEMALE),
            'age': person.age(),
            'address': person.address(),
            'email': person.email(),
            'phone': person.telephone(),
        }

    s = Schema(schema)
    assert len(s.create(iterations=10)) == 10

# Generated at 2022-06-17 23:21:00.006188
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', key=lambda x: x.upper())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('person.name')
    assert field('person.name', key=lambda x: x.upper())
    assert field('person.name', gender='male')
    assert field('person.name', gender='male', key=lambda x: x.upper())

# Generated at 2022-06-17 23:21:41.176137
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-17 23:21:43.454696
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

# Generated at 2022-06-17 23:21:50.387571
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(seed=123)
    assert field.locale == 'en'
    assert field.seed == 123
    assert field._gen is not None

    field = AbstractField(locale='ru', seed=123)
    assert field.locale == 'ru'
    assert field.seed == 123
    assert field._gen is not None

# Generated at 2022-06-17 23:21:51.965719
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field is not None

# Generated at 2022-06-17 23:21:59.574419
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person

    field = AbstractField()
    field._gen.add_providers(Address, Datetime, Internet, Person)

    assert field('full_name')
    assert field('full_name', gender='male')
    assert field('full_name', gender='female')
    assert field('full_name', gender='male', key=lambda x: x.split(' ')[0])
    assert field('full_name', gender='female', key=lambda x: x.split(' ')[0])

# Generated at 2022-06-17 23:22:06.747535
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', key=lambda x: x.upper())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('person.full_name')
    assert field('person.full_name', key=lambda x: x.upper())
    assert field('person.full_name', gender='male')
    assert field('person.full_name', gender='male', key=lambda x: x.upper())

# Generated at 2022-06-17 23:22:08.606313
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-17 23:22:15.352754
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'

    field = AbstractField(seed=12345)
    assert field.seed == 12345

    field = AbstractField(locale='ru', seed=12345)
    assert field.locale == 'ru'
    assert field.seed == 12345



# Generated at 2022-06-17 23:22:25.378170
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:22:32.973327
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('uuid')
    assert field('uuid', key=lambda x: x.replace('-', ''))
    assert field('uuid', key=lambda x: x.replace('-', ''), version=4)
    assert field('uuid', version=4)
    assert field('uuid', version=4, key=lambda x: x.replace('-', ''))
    assert field('uuid', version=4, key=lambda x: x.replace('-', ''))
    assert field('uuid', key=lambda x: x.replace('-', ''), version=4)
    assert field('uuid', key=lambda x: x.replace('-', ''), version=4)

# Generated at 2022-06-17 23:23:40.110840
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', gender='female')
    assert field('name', gender='female', key=lambda x: x.capitalize())
    assert field('name', gender='female', key=lambda x: x.title())
    assert field('name', gender='female', key=lambda x: x.upper())
    assert field('name', gender='female', key=lambda x: x.lower())
    assert field('name', gender='female', key=lambda x: x.swapcase())
    assert field('name', gender='female', key=lambda x: x.title())
    assert field('name', gender='female', key=lambda x: x.title())

# Generated at 2022-06-17 23:23:50.873084
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:24:01.250893
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', key=lambda x: x.lower()) == 'john'
    assert field('name', key=lambda x: x.capitalize()) == 'John'
    assert field('name', key=lambda x: x.title()) == 'John'
    assert field('name', key=lambda x: x.swapcase()) == 'jOHN'
    assert field('name', key=lambda x: x.casefold()) == 'john'
    assert field('name', key=lambda x: x.replace('o', 'a')) == 'Jan'

# Generated at 2022-06-17 23:24:15.352434
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:24:16.902834
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid')

# Generated at 2022-06-17 23:24:25.935200
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', gender='female')
    assert field('name', gender='male', key=str.upper)
    assert field('name', gender='female', key=str.upper)
    assert field('name', gender='male', key=str.lower)
    assert field('name', gender='female', key=str.lower)
    assert field('name', gender='male', key=str.title)
    assert field('name', gender='female', key=str.title)
    assert field('name', gender='male', key=str.capitalize)
    assert field('name', gender='female', key=str.capitalize)

# Generated at 2022-06-17 23:24:34.928416
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', gender='male')
    assert field('name', gender='female')
    assert field('name', gender='male', key=lambda x: x.upper())
    assert field('name', gender='female', key=lambda x: x.upper())
    assert field('name', gender='male', key=lambda x: x.lower())
    assert field('name', gender='female', key=lambda x: x.lower())
    assert field('name', gender='male', key=lambda x: x.title())
    assert field('name', gender='female', key=lambda x: x.title())
    assert field('name', gender='male', key=lambda x: x.capitalize())

# Generated at 2022-06-17 23:24:44.182788
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='female')
    assert field('name', gender='female', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='female', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='female', key=lambda x: x.capitalize())

# Generated at 2022-06-17 23:24:52.106471
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('datetime') is not None
    assert field('datetime', year=2000) is not None
    assert field('datetime', year=2000, key=lambda x: x.year) == 2000
    assert field('datetime', year=2000, key=lambda x: x.month) == 1
    assert field('datetime', year=2000, key=lambda x: x.day) == 1
    assert field('datetime', year=2000, key=lambda x: x.hour) == 0
    assert field('datetime', year=2000, key=lambda x: x.minute) == 0
    assert field('datetime', year=2000, key=lambda x: x.second) == 0

# Generated at 2022-06-17 23:24:57.105244
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:26:01.875113
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', middle_name=True) == 'John Michael'
    assert field('name', gender='female', middle_name=True) == 'Jane Elizabeth'
    assert field('name', gender='male', middle_name=False) == 'John'
    assert field('name', gender='female', middle_name=False) == 'Jane'
    assert field('name', gender='male', middle_name=False, short_name=True) == 'John'

# Generated at 2022-06-17 23:26:09.802023
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John Doe'
    assert field('name', gender='male') == 'John Doe'
    assert field('name', gender='female') == 'Jane Doe'
    assert field('name', gender='male', middle_name=True) == 'John Michael Doe'
    assert field('name', gender='female', middle_name=True) == 'Jane Marie Doe'
    assert field('name', gender='male', middle_name=True, last_name=False) == 'John Michael'
    assert field('name', gender='female', middle_name=True, last_name=False) == 'Jane Marie'

# Generated at 2022-06-17 23:26:17.681891
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John Doe'
    assert field('name', key=lambda x: x.upper()) == 'JOHN DOE'
    assert field('name', gender='male') == 'John Doe'
    assert field('name', gender='female') == 'Jane Doe'
    assert field('person.name') == 'John Doe'
    assert field('person.name', gender='male') == 'John Doe'
    assert field('person.name', gender='female') == 'Jane Doe'
    assert field('person.name', key=lambda x: x.upper()) == 'JOHN DOE'
    assert field('person.name', gender='male', key=lambda x: x.upper()) == 'JOHN DOE'

# Generated at 2022-06-17 23:26:27.611979
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:26:34.233121
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', key=lambda x: x.lower())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.lower())
    assert field('name', gender='male', key=lambda x: x.lower())
    assert field('name', gender='male', key=lambda x: x.lower())
    assert field('name', gender='male', key=lambda x: x.lower())
    assert field('name', gender='male', key=lambda x: x.lower())
    assert field('name', gender='male', key=lambda x: x.lower())
    assert field('name', gender='male', key=lambda x: x.lower())
    assert field

# Generated at 2022-06-17 23:26:42.927060
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'
    assert field('name', gender='female', key=lambda x: x.upper()) == 'JANE'
    assert field('name', gender='male', key=lambda x: x.upper()) == 'JOHN'

# Generated at 2022-06-17 23:26:51.199221
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', gender='male') == 'John'
    assert field('name', gender='female') == 'Jane'
    assert field('name', gender='male', key=lambda x: x.lower()) == 'john'
    assert field('name', gender='female', key=lambda x: x.lower()) == 'jane'

    assert field('person.name') == 'John'
    assert field('person.name', gender='male') == 'John'
    assert field('person.name', gender='female') == 'Jane'
    assert field('person.name', gender='male', key=lambda x: x.lower()) == 'john'

# Generated at 2022-06-17 23:26:58.724294
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('person.full_name') == 'John Doe'
    assert field('person.full_name', key=lambda x: x.split()[0]) == 'John'
    assert field('person.full_name', key=lambda x: x.split()[1]) == 'Doe'
    assert field('person.full_name', key=lambda x: x.split()[-1]) == 'Doe'
    assert field('person.full_name', key=lambda x: x.split()[-2]) == 'John'
    assert field('person.full_name', key=lambda x: x.split()[-3]) == 'John'

# Generated at 2022-06-17 23:27:09.718995
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', 'en')
    assert field('name', 'en', key=lambda x: x.capitalize())
    assert field('name', 'en', gender='male')
    assert field('name', 'en', gender='male', key=lambda x: x.capitalize())
    assert field('person.name')
    assert field('person.name', key=lambda x: x.capitalize())
    assert field('person.name', gender='male')

# Generated at 2022-06-17 23:27:19.291830
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('name', gender='male')
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())
    assert field('name', gender='male', key=lambda x: x.capitalize())