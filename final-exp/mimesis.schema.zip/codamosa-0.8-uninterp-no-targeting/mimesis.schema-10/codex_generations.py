

# Generated at 2022-06-21 16:58:26.238666
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis import Person
    from mimesis.schema import Schema

    def create_person(field: Field) -> dict:
        return {
            'name': field.person.full_name(),
            'date_of_birth': field.datetime.date(),
        }

    provider = Person()
    schema = Schema(create_person)
    result = schema.create(iterations=2)

    assert result == [create_person(field=provider) for _ in range(2)]

# Generated at 2022-06-21 16:58:28.023969
# Unit test for constructor of class Schema
def test_Schema():
    schema = {'name': 'John', 'age': 26}

    s = Schema(lambda: schema)
    assert s.schema() == schema

# Generated at 2022-06-21 16:58:36.194306
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    assert field('uuid') is not None
    assert field('uuid', version=4) is not None

    assert field('person.full_name') is not None
    assert field('person.full_name', gender='female') is not None

    assert field('datetime.today') is not None
    assert field('datetime.today', year=2018) is not None

    assert field('datetime.datetime') is not None
    assert field('datetime.datetime', year=2018) is not None

    assert field('cryptographic.token_urlsafe') is not None
    assert field('cryptographic.token_urlsafe', nbytes=10) is not None

    assert field('internet.ip_address') is not None
    assert field('internet.ip_address', v=4) is not None


# Generated at 2022-06-21 16:58:43.905331
# Unit test for constructor of class AbstractField
def test_AbstractField():  # pragma: no cover
    from mimesis.builtins.datetime import Datetime, Datetime
    from mimesis.builtins.geography import Geography, Geography
    from mimesis.builtins.dummy import Dummy, Dummy
    from mimesis.builtins.internet import Internet, Internet
    from mimesis.builtins.numerical import Numerical, Numerical
    from mimesis.builtins.persons import Persons, Persons
    from mimesis.builtins.process import Process, Process
    from mimesis.builtins.text import Text, Text
    from mimesis.builtins.unit import Unit, Unit
    from mimesis.builtins.base import Base, Base

    field = AbstractField(locale='ru')

    assert field.locale == 'ru'

    en_

# Generated at 2022-06-21 16:58:46.458346
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    expect = 'AbstractField <en>'

    assert field.__str__() == expect

# Generated at 2022-06-21 16:58:49.241956
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert 'n.garikov@bolshoy.di' == field('email')

# Generated at 2022-06-21 16:58:50.936201
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>', 'Fail the unit test'

# Generated at 2022-06-21 16:58:53.839771
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field(locale='en')
    str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 16:59:04.064448
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create."""
    import random
    import string

    def test_schema() -> JSON:
        """Example of callable schema."""
        return {
            'name': ''.join(random.choices(string.ascii_letters, k=10)),
            'surname': ''.join(random.choices(string.ascii_letters, k=10)),
            'age': random.randint(1, 100),
            'gender': ''.join(random.choices(string.ascii_letters, k=1)),
        }

    sh = Schema(test_schema)
    assert isinstance(sh.create(iterations=2), list)
    assert len(sh.create(iterations=2)) == 2

# Generated at 2022-06-21 16:59:06.749776
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    instance = Field()
    assert str(instance) == 'Field <en>'

# Generated at 2022-06-21 16:59:32.486139
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    field = Field(seed=123)
    assert field('social_security_number') == '046-44-0880'
    assert field('full_name') == 'Isaac Salazar'

# Generated at 2022-06-21 16:59:34.932147
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 16:59:43.730385
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    # Create example schema
    example_schema = {
        'id': int,
        'title': str,
        'author': str,
        'price': float,
    }

    def schema_with_abstract_field():
        return {
            'id': Field('en', 'seed')('uuid'),
            'title': Field('en', 'seed')('title'),
            'author': Field('en', 'seed')('author'),
            'price': Field('en', 'seed')('price'),
        }

    schema = Schema(schema_with_abstract_field)
    filled_schema = schema.create(iterations=1)[0]
    assert filled_schema == example_schema

# Generated at 2022-06-21 16:59:50.283934
# Unit test for constructor of class Schema
def test_Schema():
    def _test_schema():
        pass

    assert isinstance(Schema(_test_schema), Schema), 'Not an instance'

    def _test_schema_with_args(*args, **kwargs):
        pass

    assert isinstance(Schema(_test_schema_with_args), Schema), \
        'Not an instance'

# Generated at 2022-06-21 16:59:58.189802
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField"""
    g = Generic()
    field = AbstractField(locale='ru', seed=324)
    assert field.locale == 'ru', 'Locale is not set.'
    assert field.seed == 324, 'Seed is not set.'
    assert field._gen == g, 'Generic is not set.'



# Generated at 2022-06-21 17:00:05.150542
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Cover method AbstractField.__call__()."""
    from mimesis.providers.person import Person
    from mimesis.providers import specialist as s
    from mimesis.schema import AbstractField, Field
    p = Person('ru')
    specialist = s.Specialist('ru')

    def test():
        f = AbstractField(locale='ru',
                          providers=(p, specialist,))
        assert f('full_name') == p.full_name()
        assert f('full_name', gender='female') == p.full_name(gender='female')
        assert (f('last_name', key=str.upper)
                == p.last_name().upper())
        assert (f('full_name', key=str.upper)
                == p.full_name().upper())

# Generated at 2022-06-21 17:00:10.835198
# Unit test for method create of class Schema
def test_Schema_create():
    expect_schema = {
        'key': '1',
        'key2': '2'
    }

    def schema():
        return {
            'key': '1',
            'key2': '2'
        }

    generated = Schema(schema).create(iterations=1)
    assert expect_schema == generated[0]

# Generated at 2022-06-21 17:00:17.978764
# Unit test for constructor of class Schema
def test_Schema():
    """Test abstract schema."""
    from .__init__ import UserSchema

    s = Schema(UserSchema)
    assert s.create(1) == [
        {
            'email': 'QlyOJdYGm5@mW5.com',
            'first_name': 'John',
            'last_name': 'Doe',
            'full_name': 'John Doe',
            'username': 'John.Doe',
            'password': 'rhhBnjKDfbp8s1',
            'country': 'Russia',
            'city': 'Cheboksary',
            'postal_code': '8WK',
            'address': 'Russia, Cheboksary, 8WK',
        },
    ]

# Generated at 2022-06-21 17:00:23.445459
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.person import Person, PersonInfo
    from mimesis.providers.transport import Vehicle

    # Generate fake data with only one provider
    provider = Person('ru')
    field = AbstractField(locale='ru')

    assert isinstance(field, AbstractField)

    value = field('full_name')
    assert isinstance(value, str)
    assert provider._validate_full_name(value)

    # Generate fake data with a few providers
    provider_2 = Vehicle('ru')

    field_2 = AbstractField(locale='ru')

# Generated at 2022-06-21 17:00:30.108857
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> JSON:
        """Return local schema.

        A schema for unit test :func:`~mimesis.schema.test_Schema_create`.
        """
        return {
            'name': 'Ivan',
            'age': 12,
            'email': 'example@mail.com',
        }

    schema = Schema(schema)
    data = schema.create(3)

    assert isinstance(data, list)
    assert len(data) == 3

# Generated at 2022-06-21 17:01:00.843976
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test the __str__ method of AbstractField class."""
    field = Field(locale='en')
    assert str(field) == 'Field <en>'

# Generated at 2022-06-21 17:01:01.673771
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 17:01:05.606498
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create."""
    full_name_schema = {
        'first_name': 'Person.first_name',
        'last_name': 'Person.last_name',
    }

    s = Schema(full_name_schema)
    result = s.create(2)
    assert len(result) == 2
    assert isinstance(result[0], dict)



# Generated at 2022-06-21 17:01:07.898905
# Unit test for constructor of class Schema
def test_Schema():
    """Testing constructor of class Schema."""
    assert not Schema(1)



# Generated at 2022-06-21 17:01:15.465788
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis import Person

    person = Person('en')
    schema = {
        'first_name': person.name,
        'second_name': person.surname,
        'age': 20
    }

    sch = Schema(lambda: schema)

    assert isinstance(sch.create(iterations=1), list)
    assert isinstance(sch.create(iterations=1)[0], dict)
    assert len(sch.create(iterations=100)) == 100



# Generated at 2022-06-21 17:01:17.131300
# Unit test for constructor of class AbstractField
def test_AbstractField():
    obj = AbstractField()
    assert isinstance(obj, AbstractField)



# Generated at 2022-06-21 17:01:28.038064
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.fun import FunSpecProvider
    obj = AbstractField(locale='ru', providers=[RussiaSpecProvider,
                                                FunSpecProvider])
    assert obj.__call__('full_name')

    result = obj.__call__('full_name', key=lambda x: x.lower())
    assert isinstance(result, str)
    assert result.islower()

    assert obj.__call__('currency_code')
    assert obj.__call__('russian.first_name')
    assert obj.__call__('russian.last_name')
    assert obj.__call__('russian.middle_name')

    assert obj.__call__('fun.lorem_ipsum')

# Generated at 2022-06-21 17:01:29.668840
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method AbstractField.__str__."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 17:01:31.498130
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.schema import AbstractField
    from mimesis.providers.internet import Internet

    f = AbstractField(providers=[Internet('en')])
    assert f



# Generated at 2022-06-21 17:01:36.335079
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test the method ``__call__`` of the class ``AbstractField``."""
    field = AbstractField()
    assert field('faker.name') == 'David Rodriguez'
    assert field('faker.text') == 'Dicta provident voluptatum eum. Fuga' \
                                  ' et inventore quisquam ut. Cupiditate' \
                                  ' beatae aperiam.'
    assert field('fake') == 'Klein'
    assert field('fake', True) == 'true'
    assert field('fake_email') == 'julia.romero@example.org'
    assert field('name') == 'Lydia Lang'

    assert field('datetime.datetime') == '1987-04-23 17:13:19'
    assert field('datetime.datetime',
                 tzinfo=True)

# Generated at 2022-06-21 17:01:58.505469
# Unit test for method create of class Schema
def test_Schema_create():
    # With unit test
    schema = {
        'person': {
            'full_name': 'person.full_name',
            'age': 'person.age',
            'email': 'person.email',
        }
    }
    gen = Schema(schema)
    assert gen.create(5) == [{
        'person': {
            'full_name': 'person.full_name',
            'age': 'person.age',
            'email': 'person.email',
        }
    } for _ in range(5)]

# Generated at 2022-06-21 17:01:59.444114
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Check instance."""
    assert isinstance(Field(seed=123), AbstractField)



# Generated at 2022-06-21 17:02:03.235219
# Unit test for method create of class Schema
def test_Schema_create():
    # TODO: Add unit test for class Schema
    # See <https://github.com/lk-geimfari/mimesis/issues/468>
    pass

# Generated at 2022-06-21 17:02:09.192480
# Unit test for method create of class Schema
def test_Schema_create():
    # sub_schema = Generic().create_schema('int', 'int', 'str')
    sub_schema = Generic().create_schema(int, int, str)
    schema = Generic().create_schema(sub_schema, sub_schema)
    # schema = Generic().create_schema('{int, int, str}', '{int, int, str}')
    data = Schema(schema).create()
    # print(data)
    assert type(data) is list
    assert type(data[0]) is tuple
    assert type(data[1]) is tuple
    assert type(data[0][0]) is tuple
    assert type(data[0][0][0]) is int
    assert type(data[0][0][1]) is int

# Generated at 2022-06-21 17:02:14.109162
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField."""
    assert (
        '{} <{}>'.format(
            AbstractField.__name__, 'en') ==
        str(AbstractField())
    )

# Generated at 2022-06-21 17:02:16.081540
# Unit test for method create of class Schema
def test_Schema_create():
    assert Schema(lambda: {'a': 0}).create(2) == [{'a': 0}, {'a': 0}]

# Generated at 2022-06-21 17:02:21.461933
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    gen = Generic('en')
    field = AbstractField()

    assert callable(field)

    # Test with method name which is not exist in any provider
    with pytest.raises(UndefinedField):
        field()

    # Test with method name which is exist in provider
    field_callable = field('internet')
    assert callable(field_callable)
    assert isinstance(field_callable(), str)

    # Test with method name which is exist in all providers
    field_callable = field('choice')
    assert callable(field_callable)
    assert isinstance(field_callable(), str)

    field_callable = field('finance.currency_code')
    assert callable(field_callable)
    assert isinstance(field_callable(), str)

    # Test with method name which is exist in

# Generated at 2022-06-21 17:02:31.579798
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.person import Person

    p = Person('ru')
    schema = Schema(schema=lambda: {
        'home': p.address(),
        'work': p.address(),
        'name': p.full_name(),
        'phone number': p.telephone(),
    })

# Generated at 2022-06-21 17:02:43.291928
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    # Create instance of AbstractField
    field = AbstractField(seed=0)
    # Get data from methods of provider Person via `__call__` method
    full_name = field('full_name')
    gender = field('gender')
    identity = field('identity')
    passport = field('passport')
    # Get data from methods of provider Address via `__call__` method
    address = field('address')
    city = field('city')
    address_line = field('address_line')
    street_name = field('street_name')
    # Get data from methods of provider DateTime via `__call__` method
    date = field('date')

    # Check for correct full name
    assert full_name == 'Lonnie V. Stephens'
    # Check for

# Generated at 2022-06-21 17:02:45.863296
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'



# Generated at 2022-06-21 17:03:12.685174
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field('name') is not None

# Generated at 2022-06-21 17:03:17.059371
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test the method __str__ of class AbstractField."""
    af = AbstractField()
    assert af.__str__() == 'AbstractField <en>'

# Generated at 2022-06-21 17:03:18.743886
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 17:03:27.949356
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.internet import Internet

    class SchemaClass:
        def __init__(self):
            self.internet = Internet('en')

        def schema(self):
            return {
                'url': self.internet.url(),
                'domain_name': self.internet.domain_name(),
                'ipv4': self.internet.ipv4(),
            }

    schema = Schema(SchemaClass().schema)
    schema.create(iterations=10)

# Generated at 2022-06-21 17:03:30.881025
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert repr(f) == 'AbstractField <en>'



# Generated at 2022-06-21 17:03:34.826864
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract = AbstractField()

    assert abstract('uuid4').startswith('4')
    # Check method with explicit provider name
    assert 'UUID' in abstract('provider.uuid4')


# Generated at 2022-06-21 17:03:41.339173
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    from mimesis.providers.currency import Currency
    provider = Currency('fr')

    field = AbstractField('fr', providers=[provider])
    assert field('code') == 'EUR'
    assert field('code') == 'EUR' # Repeat
    assert field('code') == 'EUR' # Repeat
    assert field('code') == 'EUR' # Repeat

    # Repeat but with explicit provider:
    assert field('currency.code') == 'EUR'
    assert field('currency.code') == 'EUR' # Repeat

    # Test key-function
    assert field('code', key=lambda x: x.lower()) == 'eur'

# Generated at 2022-06-21 17:03:47.633088
# Unit test for constructor of class Schema
def test_Schema():
    # type: () -> None
    """Test init of Schema class.

    :return: No return.
    """
    schema = {
        'name': 'Arseny',
        'age': 23
    }

    obj = Schema(schema)
    assert obj is not None



# Generated at 2022-06-21 17:03:51.015797
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField(locale='ru')) == 'AbstractField <ru>'

# Generated at 2022-06-21 17:04:00.067379
# Unit test for method create of class Schema
def test_Schema_create():
    """Test that :class:`~mimesis.schema.Schema.create` returns a list of
    filled schemas.
    """
    from mimesis.schema import Field
    from mimesis.providers.person import Person
    providers = Person('ru')
    field = Field('ru', providers=providers)

    def schema():
        return {
            'name': field('full_name'),
            'age': field('age', minimum=18, maximum=95),
        }

    s = Schema(schema)
    result = s.create(101)

    assert isinstance(result, list)
    assert len(result) == 101
    assert result[100] == schema()

# Generated at 2022-06-21 17:05:14.005504
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.data import EN

    f = Field()
    assert f.locale == 'en'
    assert f.seed is None
    assert f('boolean', chance_of_getting_true=0) is False

    f = Field('en')
    assert f.locale == 'en'

    f = Field('en', seed=123)
    assert f.seed == 123

    f = Field('en', seed=123, providers=[EN])
    assert f.locale == 'en'
    assert f.seed == 123

# Generated at 2022-06-21 17:05:18.850469
# Unit test for method create of class Schema
def test_Schema_create():
    def some_schema():
        return {
            'a': 'b'
        }
    s = Schema(some_schema)
    assert s.create(3) == [{'a': 'b'}, {'a': 'b'}, {'a': 'b'}]

# Generated at 2022-06-21 17:05:22.150429
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField."""
    #: Example of how it will work
    get_name = Field()
    print(get_name('full_name'))
    print(get_name('full_name', gender='male'))
    print(get_name('cryptographic.token_urlsafe'))

# Generated at 2022-06-21 17:05:26.300101
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    gen = Generic()
    field = AbstractField(providers=[gen])
    f = field('code')
    assert isinstance(f, str) and f



# Generated at 2022-06-21 17:05:31.593161
# Unit test for method create of class Schema
def test_Schema_create():
    """Test create method of class Schema."""
    def schema() -> JSON:
        return {'a': 1, 'b': 2, 'c': 3}

    data = Schema(schema).create(10)

    assert len(data) == 10 and all(item['a'] == 1 for item in data)

# Generated at 2022-06-21 17:05:40.542004
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda x: {'a': 1})
    assert schema.create(1) == [{'a': 1}]
    assert schema.create(2) == [{'a': 1}, {'a': 1}]
    assert schema.create(3) == [{'a': 1}, {'a': 1}, {'a': 1}]

# Generated at 2022-06-21 17:05:50.399118
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Testing __call__ method of class AbstractField."""
    import pytest
    from mimesis.providers import Person

    person = Person('en')
    custom = Person('en')
    custom.add_provider('me')

    # Test with custom providers
    field = Field(locale='en', providers=(custom,))

    result = field('name', gender='male', key=lambda x: x.title())
    assert person.name(gender='male').title() == result

    result = field('name', gender='female')
    assert person.name(gender='female') == result

    result = field('me.greeting')
    assert custom.me.greeting() == result

    # Test without custom providers
    field = Field(locale='en')

    result = field('full_name', gender='male')
   

# Generated at 2022-06-21 17:05:52.996687
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField."""
    field = AbstractField(seed=100)
    assert field('uuid') == '5f5b4d4b-4a52-4a6e-b91f-9b04d9bfe07a'



# Generated at 2022-06-21 17:05:56.280028
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor of class Schema."""
    assert isinstance(Schema, object) is True

# Generated at 2022-06-21 17:06:00.121811
# Unit test for method create of class Schema
def test_Schema_create():
    s = Schema(int)
    result = s.create(iterations=10)
    assert len(result) == 10
    assert isinstance(result[0], int)

# Generated at 2022-06-21 17:07:25.453224
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    # pylint: disable=unsubscriptable-object
    # pylint: disable=protected-access
    provider = AbstractField()
    methods = ['full_name', 'address.street_name']

    results = [provider(method) for method in methods]
    assert results[0] == provider._gen.full_name()
    assert results[1] == provider._gen.address.street_name()

# Generated at 2022-06-21 17:07:30.909320
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.builtins.schema import schema_person
    from mimesis.schema import Schema

    schema = Schema(schema_person)

    for _ in range(10):
        _ = schema.create(5)

# Generated at 2022-06-21 17:07:36.849158
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    f = Field(providers=[RussiaSpecProvider])
    provider = RussiaSpecProvider(f)

    assert f('address.state') == provider.address.state()
    assert f('choice') is not None
    assert f('choice', 'foo', 'bar') == 'foo'
    assert f('code.inn', gender=Gender.MALE) != provider.code.inn(
        gender=Gender.FEMALE)

# Generated at 2022-06-21 17:07:40.779016
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test AbstractField.__str__()."""
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-21 17:07:41.750525
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()

    assert hasattr(field, '_table')
    assert field._table is not None
    assert field._table == {}



# Generated at 2022-06-21 17:07:44.322196
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

