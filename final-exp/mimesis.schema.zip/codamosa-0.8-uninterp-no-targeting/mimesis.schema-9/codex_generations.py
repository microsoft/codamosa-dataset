

# Generated at 2022-06-21 16:58:26.538821
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test string representation of object."""
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 16:58:29.602480
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'name': 'John Doe', 'age': 35}

    def get_schema():
        return schema

    s = Schema(get_schema)
    assert s.create(3) == [{'name': 'John Doe', 'age': 35},
                           {'name': 'John Doe', 'age': 35},
                           {'name': 'John Doe', 'age': 35}]

# Generated at 2022-06-21 16:58:30.975923
# Unit test for method create of class Schema
def test_Schema_create():
    assert isinstance(Schema(list)(), Schema)

# Generated at 2022-06-21 16:58:40.682922
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None

    # Test by name and without kwargs
    data = field('name')
    assert data is not None

    # Test by supported field
    data1 = field('name', key=lambda x: x.capitalize())
    assert data1 is not None

    # Test with kwargs
    data2 = field('text', length=100)
    assert data2 is not None

    # Test with provider prefix and kwargs
    data3 = field('generic.special.hex')
    assert data3 is not None

# Generated at 2022-06-21 16:58:45.257435
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Testing AbstractField.

    __str__() should return the class name with the locale.
    """
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 16:58:53.638423
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()
    from mimesis.providers.internet import Internet

    # Test for case where field not defined
    with pytest.raises(UndefinedField):
        f()

    # Test for case where provider not supported (providers=None)
    with pytest.raises(UnsupportedField):
        f('email')

    # Test for case where provider not supported (providers=[])
    with pytest.raises(UnsupportedField):
        f('email', providers=[])

    # Test for case where provider not supported (providers=[SomeClass()])
    with pytest.raises(UnsupportedField):
        f('email', providers=[AbstractField()])

    # Test for case when provider is supported
    e = f('email', providers=Internet)
    assert '@' in e

    # Test for case when method

# Generated at 2022-06-21 16:58:55.274948
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field is not None

# Generated at 2022-06-21 16:58:59.157404
# Unit test for constructor of class AbstractField
def test_AbstractField():
    a = AbstractField()
    assert callable(a)

# Generated at 2022-06-21 16:59:03.478779
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__."""
    field = Field()

    assert field('datetime', format='%H:%M:%S %d.%m.%Y') is not None
    assert field('datetime', key=lambda x: x.isoformat()) is not None
    assert field(
        'datetime.isoformat',
        format='%H:%M:%S %d.%m.%Y',
    ) is not None

# Generated at 2022-06-21 16:59:07.314197
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField(locale='ru')) == 'AbstractField <ru>'