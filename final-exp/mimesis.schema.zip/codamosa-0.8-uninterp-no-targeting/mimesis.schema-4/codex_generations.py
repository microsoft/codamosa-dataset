

# Generated at 2022-06-21 16:58:13.345062
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field(locale='fr')
    assert str(f) == 'Field <fr>'

# Generated at 2022-06-21 16:58:16.420346
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: True)
    assert len(schema.create()) > 0, 'Empty list of filled schemas!'

# Generated at 2022-06-21 16:58:18.988428
# Unit test for constructor of class Schema
def test_Schema():
    import pytest

    f = lambda: {}

    schema = Schema(f)
    assert schema.schema == f

# Generated at 2022-06-21 16:58:22.169348
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-21 16:58:28.525789
# Unit test for method create of class Schema
def test_Schema_create():
    """Test create method of class Schema."""
    from mimesis import schema
    from mimesis.providers.web import Web

    web = Web('en')
    s = Schema(
        schema.create_schema({
            'name': web.name,
        }),
    )

    assert s.create()

# Generated at 2022-06-21 16:58:29.169648
# Unit test for method create of class Schema
def test_Schema_create():
    pass

# Generated at 2022-06-21 16:58:31.581842
# Unit test for constructor of class Schema
def test_Schema():
    assert isinstance(Schema({}), Schema)
    assert isinstance(Schema([]), Schema)

# Generated at 2022-06-21 16:58:36.873256
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    gen = Field()
    name = 'text'
    result = gen(name=name, key=str.upper)

    assert result is not None
    assert name in gen._table

# Generated at 2022-06-21 16:58:42.379415
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.builtins import Person
    from mimesis.providers.base import BaseDataProvider
    from mimesis.schema.fields import Field

    @Field(locale='ru', providers=[Person])
    def schema():
        return {
            'name': 'name',
            'surname': 'surname',
        }

    assert issubclass(schema, BaseDataProvider)
    assert schema.create().count('Иван') == schema.create().count('Иван')

    s = Schema(schema)
    assert isinstance(s.create(), list)

# Generated at 2022-06-21 16:58:45.399266
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field('ru')) == 'AbstractField <ru>', 'AbstractField.__str__'

# Generated at 2022-06-21 16:59:09.813708
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-21 16:59:12.367146
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

    f = AbstractField(locale='ru')
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-21 16:59:14.456929
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    expected = 'AbstractField <en>'
    assert str(f) == expected

# Generated at 2022-06-21 16:59:18.585289
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test of method __call__ of class AbstractField.

    .. note:: This test should be removed in the future.
    """
    try:
        f = AbstractField()
        f('')
    except UndefinedField:
        return True
    return False

# Generated at 2022-06-21 16:59:21.614567
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert callable(field)

# Generated at 2022-06-21 16:59:31.097236
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Tests for ``__call__`` method of class ``AbstractField``."""
    inst = AbstractField()
    assert inst('choice', ['1', '2', '3']) == '1'
    assert inst('choice', ['1', '2', '3'], key=None) == '1'
    assert inst('choice', ['1', '2', '3'], key=lambda x: x) == '1'

    inst = AbstractField()
    assert inst('choice', ['1', '2', '3'], key=lambda x: x) == '1'



# Generated at 2022-06-21 16:59:40.537761
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    from mimesis import Address, Person

    data = Schema(lambda: {
        'first_name': Person().name(),
        'address': Address().address(),
    }).create(2)

    assert len(data) == 2
    assert 'first_name' in data[0] and 'address' in data[0]
    assert 'first_name' in data[1] and 'address' in data[1]

# Generated at 2022-06-21 16:59:44.533697
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Create instance of class AbstractField.

    :return: Instance of class AbstractField
    """
    _ = AbstractField()
    return _

# Generated at 2022-06-21 16:59:50.585671
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__().

    It just checks if the function will find the data method by the name.
    Each method takes parameters by schema.
    """
    field = Field()
    name = 'full_name'
    assert hasattr(field._gen.person, name)
    assert ' ' in field(name)

# Generated at 2022-06-21 16:59:54.292212
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema

    schema = {
        'first_name': 'person.name',
        'last_name': 'person.surname',
        'gender': 'person.gender',
        'age': 'person.age',
        'address': 'person.address',
        'phone_number': 'person.telephone'
    }

    filled_schema = Schema(schema).create(5)

    assert len(filled_schema) == 5



# Generated at 2022-06-21 17:00:57.786405
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    f = Field()
    assert f('full_name') is not None
    assert f('address.street_name') is not None



# Generated at 2022-06-21 17:00:59.308813
# Unit test for constructor of class Schema
def test_Schema():
    schema = {'id': True, 'name': 'Yuri'}
    s = Schema(schema)
    assert s.schema == schema

# Generated at 2022-06-21 17:01:01.118028
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None
    assert callable(field)
    assert isinstance(field, AbstractField)


# Test for method __call__ of class AbstractField

# Generated at 2022-06-21 17:01:03.933701
# Unit test for method create of class Schema
def test_Schema_create():
    """Schema create method."""
    field = Field()

    def person():
        return {
            'name': field.name(),
            'surname': field.surname(),
            'gender': field.gender(),
        }

    data = Schema(person).create(3)
    assert data == [person() for _ in range(3)]



# Generated at 2022-06-21 17:01:05.351690
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    data = field('name')
    assert data is not None



# Generated at 2022-06-21 17:01:16.712458
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.generic import Generic
    from mimesis.providers.geography import Geography
    from mimesis.providers.datetime import Datetime

    field = Field()
    assert field('region') == 'New South Wales'
    assert field(name='region') == 'New South Wales'
    assert field('region', key=lambda x: 'Australia, ' + x) == \
        'Australia, New South Wales'

    # Use any provider
    field = Field(providers=Geography)
    assert field('delimiter') == '/'
    assert field('region') == 'New South Wales'

    # Use any method
    field = Field(providers=Geography)
    assert field('delimiter') == '/'
    assert field('region') == 'New South Wales'

    # Use other provider


# Generated at 2022-06-21 17:01:19.162882
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Method returns string representation of the class."""
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-21 17:01:20.607703
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-21 17:01:24.185137
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    try:
        AbstractField()
    except Exception:
        raise AssertionError('Constructor of class AbstractField failed.')

# Generated at 2022-06-21 17:01:27.009330
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    _field = AbstractField(locale='ru')
    assert _field('get_currency', code='USD') == 'доллар США'

