

# Generated at 2022-06-21 16:58:09.239417
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of AbstractField.

    :return: True if all tests have passed else False.
    """
    af = AbstractField(locale='ru', providers=[])
    assert af
    assert af.locale == 'ru'
    assert af.seed is None
    assert af._gen
    assert af._table == {}
    return True

# Generated at 2022-06-21 16:58:19.433519
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema
    from mimesis.providers.person import Person
    from mimesis.enums import Gender

    def schema():
        return {
            'full_name': Person('en').full_name(),
            'age': Person('en').age(),
            'gender': Person('en').gender(gender=Gender.MALE),
            'iban': Person('en').iban(),
        }

    schema = Schema(schema)
    result = schema.create(5)

    assert len(result) == 5

# Generated at 2022-06-21 16:58:25.066142
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert 'AbstractField' in repr(field)
    assert 'en' in repr(field)

    field_2 = AbstractField('ru')
    assert 'ru' in repr(field_2)

# Generated at 2022-06-21 16:58:32.594475
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        """Return sample schema."""
        return {
            'name': lambda: 'name',
            'surname': lambda: 'surname',
            'national_id': lambda: 'id',
            'email': lambda: 'email',
        }

    data_set = Schema(schema)
    created_data = data_set.create(iterations=5)
    assert len(created_data) == 5

    for data in created_data:
        assert data['name'] == 'name'
        assert data['surname'] == 'surname'
        assert data['national_id'] == 'id'
        assert data['email'] == 'email'

# Generated at 2022-06-21 16:58:33.550359
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(seed=42)
    assert field


# Generated at 2022-06-21 16:58:35.044268
# Unit test for constructor of class Schema
def test_Schema():
    _ = Schema(lambda: {})

# Generated at 2022-06-21 16:58:43.266686
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    import mimesis
    from mimesis.schema import Field

    field = Field()
    schema = Schema(
        lambda: {
            'first_name': field(key=lambda x: x.capitalize()),
            'second_name': field(key=lambda x: x.capitalize()),
            'age': field(key=lambda x: int(x)),
            'password': field(key=lambda x: int(x)),
            'salary': field(key=lambda x: float(x)),
            'address': field(),
            'phone': field(
                key=lambda x: mimesis.Personal(x).telephone()
            ),
            'bio': field(),
        },
    )
    data = schema.create()
    assert len(data)

# Generated at 2022-06-21 16:58:53.183053
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method ``__call__`` of class ``AbstractField``."""
    field = AbstractField()

    assert 'en' in field('full_name')

    assert 'en' in field('full_name', key=lambda s: s.lower())

    # Test for function __call__ with kwargs
    full_name = field('full_name')
    assert full_name in field('full_name', gender='female')

    # Test for function __call__ with tail
    assert 'en' in field('person.full_name')

    # Test for function __call__ with tail and kwargs
    assert full_name in field('person.full_name', gender='female')

    # Test for function __call__ with unexisted provider
    assert 'en' not in field('unexisted_provider.full_name')

    #

# Generated at 2022-06-21 16:58:55.417688
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(dict)
    assert schema



# Generated at 2022-06-21 16:59:04.933582
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema
    from mimesis.schema import Field
    from mimesis.schema import Field as FieldAlias

    field_ = Field(locale='en')

    @field_
    def personal():
        return {
            'full_name': '{first_name} {last_name}',
            'address': '{address.building_number} {address.street_name}'
        }

    @field_
    def tech():
        return {
            'job': '{job}',
            'language': '{programming_language}'
        }

    @field_
    def data():
        return {
            'personal': personal,
            'tech': tech,
            'language': '{programming_language}'
        }

    schema = Schema(data)


# Generated at 2022-06-21 16:59:26.827058
# Unit test for constructor of class AbstractField
def test_AbstractField():
    af = AbstractField()
    af.__init__()



# Generated at 2022-06-21 16:59:29.346712
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f._gen is not None
    assert f._table is not None

# Generated at 2022-06-21 16:59:32.223770
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    result = str(field)
    assert result == 'AbstractField <en>', 'Method __str__ of class AbstractField failed'


# Generated at 2022-06-21 16:59:33.444414
# Unit test for constructor of class Schema
def test_Schema():
    def get_schema():
        return {'id': 1, 'name': 'schema'}

    schema = Schema(get_schema)
    assert isinstance(schema, Schema)

# Generated at 2022-06-21 16:59:35.898855
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # assert isinstance(field, AbstractField)
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-21 16:59:37.739123
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema({'key': '<value>'})
    assert callable(schema.schema) is True

# Generated at 2022-06-21 16:59:38.536809
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert Field.__str__(Field())

# Generated at 2022-06-21 16:59:41.064312
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema.__doc__
    assert Schema.__init__.__doc__

    assert Schema({})



# Generated at 2022-06-21 16:59:44.803409
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = AbstractField()

    assert field.locale == 'en'
    assert field._gen is not None

# Generated at 2022-06-21 16:59:55.381562
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = AbstractField()
    assert field('username')
    assert field('email')
    assert field('password')
    assert field('full_name')
    assert field('full_name', key=lambda x: len(x))
    assert field('social_security_number', key=lambda x: len(x))
    assert field('local_id')
    assert field('local_id', key=lambda x: len(x))
    assert field('credit_card_number', key=lambda x: len(x))
    assert field('ipv4', key=lambda x: len(x))
    assert field('ipv6', key=lambda x: len(x))
    assert field('twitter_handle')
    assert field('instagram_username')
    assert field('tumblr_username')
   

# Generated at 2022-06-21 17:00:19.219261
# Unit test for method create of class Schema
def test_Schema_create():
    import datetime
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    schema = {
        'provider': Field(providers=[RussiaSpecProvider]),
        'birthday': datetime.date(2000, 1, 1),
        'gender': Gender.MALE,
        'count': int
    }

    schema = Schema(lambda: schema)
    assert len(schema.create(3)) == 3

# Generated at 2022-06-21 17:00:29.271494
# Unit test for method create of class Schema
def test_Schema_create():
    class MySchema:
        def __init__(self):
            self.field = Field()

        def __call__(self):
            return {
                "name": self.field('name'),
                "last_name": self.field('last_name'),
            }

    my = Schema(MySchema())
    assert isinstance(my.create(5), list)
    assert len(my.create()) == 1
    assert len(my.create(5)) == 5
    assert isinstance(my.create(5)[0], dict)



# Generated at 2022-06-21 17:00:36.261254
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> JSON:
        return {
            'title': 'title',
            'description': 'description',
        }
    s = Schema(schema)
    assert s.create() == [{'title': 'title', 'description': 'description'}]

# Generated at 2022-06-21 17:00:38.098496
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(None)
    assert schema.data == None

# Generated at 2022-06-21 17:00:41.903054
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        @staticmethod
        def schema(name: str = None, age: int = None) -> dict:
            return {'name': name, 'age': age}


    p = Person(schema=Person.schema)
    assert isinstance(p, Schema)

# Generated at 2022-06-21 17:00:43.869087
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Test initialization
    AbstractField(locale='en', seed=42)

# Generated at 2022-06-21 17:00:45.204185
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field(locale='ru')
    assert f._gen.providers['ru'] == f

# Generated at 2022-06-21 17:00:48.934330
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema():
        """Test schema."""
        return 'schema'

    s = Schema(test_schema)
    assert s.create(1) == ['schema']

# Generated at 2022-06-21 17:00:50.938667
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = AbstractField('de')
    assert field.locale == 'de'
    assert field.seed is None

# Generated at 2022-06-21 17:00:51.897579
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test a value of method __str__."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 17:01:16.610075
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field

# Generated at 2022-06-21 17:01:18.596671
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema({'f': '_'})
    assert isinstance(schema, Schema)


# Generated at 2022-06-21 17:01:21.754662
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test to test the constructor of class Schema."""
    schema = Schema(None)
    assert schema.schema is None

# Generated at 2022-06-21 17:01:24.169667
# Unit test for method create of class Schema
def test_Schema_create():
    def _schema():
        return {'name': 'foo', 'age': 42}

    s = Schema(_schema)
    assert s.create() == [_schema()]

# Generated at 2022-06-21 17:01:25.657892
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()

    expected_result = 'female'
    actual_result = f('gender')

    assert actual_result == expected_result, 'Result is not equal'

# Generated at 2022-06-21 17:01:27.905120
# Unit test for method create of class Schema
def test_Schema_create():
    assert Schema(lambda: 'test').create() == ['test']

# Generated at 2022-06-21 17:01:30.012421
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Return True if __call__ works."""
    provider = Generic('en')
    field = AbstractField(locale='en', providers=[provider])
    assert field('text', length=15)



# Generated at 2022-06-21 17:01:39.654881
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers import Address, Datetime, Person
    field = AbstractField()

    def upper_key(data: Any) -> str:
        return str(data).upper()

    # when name not defined
    try:
        field()
    except UndefinedField as e:
        assert str(e) == 'Field is undefined.'

    # when provider not supported
    try:
        field('not_exists')
    except UnsupportedField as e:
        assert str(e) == 'Provider is not supported.'

    # when provider not found
    try:
        field('not_exists.not_exists')
    except UnsupportedField as e:
        assert str(e) == 'Provider "not_exists" is not supported.'

    # when provider supported but method not exists

# Generated at 2022-06-21 17:01:42.102309
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor of class Schema."""
    assert Schema(object)



# Generated at 2022-06-21 17:01:47.494406
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(
        lambda: {'first_name': 'asd'})

    assert isinstance(schema, Schema)
    assert repr(schema) == '<Schema of <class \'dict\'>>'

# Generated at 2022-06-21 17:02:15.394621
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field.__call__('real.real') is not None

# Generated at 2022-06-21 17:02:21.211199
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import Person
    from schema import Field, Schema


# Generated at 2022-06-21 17:02:22.820827
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    pass

# Generated at 2022-06-21 17:02:30.286942
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.enums import Gender

    f = AbstractField()

    assert f('special_string') is not None
    assert f('email', domain='example.com') is not None
    assert f('username', gender=Gender.FEMALE) is not None
    assert f('person.username', gender=Gender.MALE) is not None
    assert f('person.username', gender=Gender.FEMALE) is not None
    assert f('person.email', gender=Gender.NEUTRAL) is not None

# Generated at 2022-06-21 17:02:40.083364
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    s = AbstractField()
    assert isinstance(s('datetime'), str)
    assert isinstance(s('cryptographic.md5'), str)
    assert isinstance(s('cryptographic.md5', length=8), str)

    import datetime as dt
    assert isinstance(s('datetime.datetime', seed=1,
                           date_format='%Y-%m-%d',
                           from_timestamp=dt.datetime(1990, 1, 1)), str)

    assert isinstance(s('string', key=len), int)
    assert isinstance(s('string', '', key=len), int)



# Generated at 2022-06-21 17:02:40.982340
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField)



# Generated at 2022-06-21 17:02:42.870207
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field is not None


# Generated at 2022-06-21 17:02:43.529313
# Unit test for constructor of class Schema
def test_Schema():
    pass

# Generated at 2022-06-21 17:02:46.816633
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test AbstractField.__str__."""
    field = AbstractField()
    result = field.__str__()
    assert result == 'AbstractField <en>'

# Generated at 2022-06-21 17:02:52.992275
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Testing method __str__ of class AbstractField."""
    assert str(Field(locale='de')) == 'AbstractField <de>'
    assert str(Field(locale='en')) == 'AbstractField <en>'

# Generated at 2022-06-21 17:03:17.137025
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None



# Generated at 2022-06-21 17:03:19.420318
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    obj = AbstractField()
    assert str(obj) == 'AbstractField <en>'

# Generated at 2022-06-21 17:03:23.150994
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    result = field('choice', ['a', 'b', 'c'])
    assert result in ['a', 'b', 'c']

# Generated at 2022-06-21 17:03:30.545553
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    import mimesis.providers.person as person
    from mimesis.enums import Gender

    # Check calling method of data provider
    field = Field(locale='en', seed=1,
                  providers=(person.Person(locale='en', seed=1), ))
    assert field('name') == 'Patricia'
    # Check calling method explicitly defined
    assert field('person.name', gender=Gender.FEMALE) == 'Patricia'
    # Check the error case when method not supported
    try:
        field('non-existent-method')
    except UndefinedField:
        assert True
    else:
        assert False



# Generated at 2022-06-21 17:03:36.084010
# Unit test for method create of class Schema
def test_Schema_create():
    """Test Schema.create."""
    assert len(Schema.create(lambda x: x, iterations=0)) == 0
    assert len(Schema.create(lambda x: x, iterations=1)) == 1
    assert len(Schema.create(lambda x: x, iterations=10)) == 10

# Generated at 2022-06-21 17:03:41.947536
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method AbstractField.__call__.

    For this test, the data provider ``name`` will be used.
    """
    field = AbstractField()
    name = 'name'
    assert field(name) == field._gen.name.__class__.__name__

    # Test tail parsing
    assert field('name.Meta') == field._gen.name.Meta
    assert field('name.Meta.name') == field._gen.name.Meta.name

    with pytest.raises(UnacceptableField):
        field('name.not_exist.Meta.name')

    with pytest.raises(UnacceptableField):
        field('name.Meta.name.not_exist')

# Generated at 2022-06-21 17:03:46.818690
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for the method create of class Schema."""
    schema_obj = Schema(lambda: 'Hello')
    data = schema_obj.create(iterations=10)

    assert len(data) == 10
    assert data[0] == 'Hello'

# Generated at 2022-06-21 17:03:50.402073
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema.base import BaseSchema

    class TestSchema(BaseSchema):
        pass

    s = Schema(TestSchema)

    assert isinstance(s, Schema)
    assert issubclass(s.schema, BaseSchema)

# Generated at 2022-06-21 17:03:57.063481
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor of class Schema."""
    def schema():
        return {}

    try:
        Schema('abc')
    except UndefinedSchema:
        pass
    else:
        raise AssertionError()
    assert Schema(schema)

# Generated at 2022-06-21 17:03:59.264832
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'Field <en>'



# Generated at 2022-06-21 17:04:36.494030
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # GIVEN
    field = AbstractField()

    # WHEN
    # THEN: it shouldn't raise any exceptions
    field('email')
    field('email.provider')

# Generated at 2022-06-21 17:04:38.048211
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    f = Field()

    assert f('foo', bar1='baz') is None
    assert f('foo', bar1='baz', name='text') == 'baz'

# Generated at 2022-06-21 17:04:39.125773
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField(locale='ru')) == (
        'AbstractField <ru>')



# Generated at 2022-06-21 17:04:40.927271
# Unit test for constructor of class Schema
def test_Schema():
    class A:
        def __call__(self, f: Any) -> 'A':
            return None

    a = A()
    a()(lambda: None)

# Generated at 2022-06-21 17:04:49.726580
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test calls to the AbstractField."""
    field = AbstractField()
    assert field('full_name') is not None
    assert field('full_name', value='id') is not None
    assert field('user_agent') is not None
    assert field('user_agent', value='chrome') is not None

    field = AbstractField(locale='ru')
    assert field('full_name') is not None
    assert field('full_name', value='id') is not None
    assert field('user_agent') is not None
    assert field('user_agent', value='chrome') is not None

# Generated at 2022-06-21 17:04:52.296386
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-21 17:04:54.534702
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    af = Field()
    assert str(af) == 'AbstractField <en>'

# Generated at 2022-06-21 17:04:56.783903
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 17:04:58.447121
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema(lambda: {}) is not None

# Generated at 2022-06-21 17:05:01.260661
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    _ = AbstractField()
    assert _.__str__() == 'AbstractField <en>'
    _ = AbstractField(locale='ru')
    assert _.__str__() == 'AbstractField <ru>'