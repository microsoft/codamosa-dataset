

# Generated at 2022-06-21 16:58:18.800352
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for schema of AbstractField."""
    field = Field(locale='en')
    assert field.locale == 'en'

# Generated at 2022-06-21 16:58:31.510633
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # If name is None, then raise an exception
    f = AbstractField()
    try:
        f()
    except UndefinedField:
        pass
    else:
        raise AssertionError('Method AbstractField._call__() has a bug')

    # If method with name not exists in any providers
    # then raise an exception
    f = AbstractField()
    name = 'haha'
    try:
        f(name)
    except UnsupportedField as e:
        assert str(e) == '\'{}\' not exists in providers'.format(name)
    else:
        raise AssertionError('Method AbstractField._call__() has a bug')

    # If we have a provider with a method name,
    # then call this method, return the result and
    # set this method as self._table key
    f = AbstractField

# Generated at 2022-06-21 16:58:39.821024
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema
    from mimesis.enums import Gender

    def schema():
        return {
            'age': Field('age', minimum=18, maximum=60),
            'gender': Field('gender', type_=Gender.MALE),
            'name': Field('full_name', gender=Gender.MALE),
        }

    s = Schema(schema)
    result = s.create()

    assert len(result) == 10



# Generated at 2022-06-21 16:58:42.934817
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert AbstractField.__str__(AbstractField('ru')) == 'AbstractField <ru>'

# Generated at 2022-06-21 16:58:50.246049
# Unit test for constructor of class AbstractField
def test_AbstractField():
    import pytest

    with pytest.raises(UndefinedField):
        AbstractField()()

    with pytest.raises(UnacceptableField):
        AbstractField(locale='en')('cryptographic.uuid.uuid1.uuid1')

    with pytest.raises(UnsupportedField):
        AbstractField(locale='en')('unsupported')

# Generated at 2022-06-21 16:58:59.159556
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    # 1. Init an object
    field = AbstractField()

    # 2. Call method __str__ of class AbstractField
    assert isinstance(field, AbstractField)

    # 3. Get the result
    result = str(field)
    expected = 'AbstractField <en>'

    # 4. Check result with the second object
    assert result == expected

# Generated at 2022-06-21 16:59:02.017791
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field(locale='ru')
    assert f._gen.locale == 'ru'

    f = Field(locale='ru', seed=None)
    assert f._gen.seed is None

# Generated at 2022-06-21 16:59:06.119672
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert issubclass(type(f), AbstractField)
    assert callable(f)



# Generated at 2022-06-21 16:59:16.122995
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Init field
    field = Field()

    # Check if name is None
    try:
        field(None)
    except UndefinedField:
        pass
    else:
        raise ValueError('Fail!')

    # Check if name is not supported
    try:
        field('not_supported')
    except UnsupportedField:
        pass
    else:
        raise ValueError('Fail!')

    # Check if name is not defined
    try:
        field('not_defined.field')
    except UnacceptableField:
        pass
    else:
        raise ValueError('Fail!')

    # Check if value returned by field
    # equals to value returned by method
    # of data provider
    field_result = field('uuid')
    gen = Generic()
    gen_result = gen.uuid()
    assert field_result

# Generated at 2022-06-21 16:59:18.963781
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor."""
    field = Field(locale='ru')

    assert field.locale == 'ru'
    assert field.seed is None
    assert isinstance(field._gen, Generic)
    assert hasattr(field, '__call__')