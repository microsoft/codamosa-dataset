

# Generated at 2022-06-21 16:58:29.320235
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor of class Schema."""
    schema = Schema(None)
    schema = Schema(lambda: None)

# Generated at 2022-06-21 16:58:36.944560
# Unit test for constructor of class Schema
def test_Schema():
    class SimpleSchema:
        def __call__(self):
            return {}

    schema = SimpleSchema()

    assert isinstance(Schema(schema), Schema)
    schema = lambda: {}
    assert isinstance(Schema(schema), Schema)

    try:
        Schema('test')
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-21 16:58:39.697042
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(lambda: 'test').create()) == 1
    assert Schema(lambda: 'test').create(0) == []
    assert len(Schema(lambda: 'test').create(2)) == 2

# Generated at 2022-06-21 16:58:42.864146
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field()
    assert Field(locale='ru', seed=12345)


# Generated at 2022-06-21 16:58:47.169256
# Unit test for constructor of class AbstractField
def test_AbstractField():

    f = AbstractField()

    assert f.locale == 'en'
    assert f.seed is None
    assert f._gen.locale == 'en'



# Generated at 2022-06-21 16:58:48.576636
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema is not None

# Generated at 2022-06-21 16:58:53.567984
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.base import BaseSpecProvider

    class Provider(BaseSpecProvider):
        """Test provider."""

        def foo(self):
            return 'bar'

    schema = {'key': 'value', 'foo': 'provider.foo'}

    def func():
        return Field(providers=[Provider])(**schema)

    sch = Schema(func)
    assert sch.create() == [{'key': 'value', 'foo': 'bar'}]
    assert sch.create(5) == [{'key': 'value', 'foo': 'bar'}] * 5

# Generated at 2022-06-21 16:59:04.390133
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert 'Nstz' == field(name='name')

    # Test method `choice`
    field = AbstractField()
    field.seed = 'mimesis'
    assert field(name='choice', args=['foo', 'bar', 'baz']) == 'bar'

    # Test method `uuid`
    field = AbstractField(locale='en')
    assert field(name='uuid', version=4) == '2e687b49-9ca1-4c68-bcb4-b3e4ad4c16a4'

    # Test method `randomize`
    field = AbstractField()
    field.seed = 'mimesis'
    assert field(name='randomize', token='Guido van Rossum') == 'gUiD0vAn R05Sum'

   

# Generated at 2022-06-21 16:59:15.472711
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class :class:`~mimesis.Schema.AbstractField`."""
    field = AbstractField(locale='en')
    assert field.locale == 'en'
    assert field._gen is not None
    assert field._gen.locale == 'en'
    assert field.seed is None

    field = AbstractField(locale='en', seed=42)
    assert field.locale == 'en'
    assert field._gen is not None
    assert field._gen.locale == 'en'
    assert field.seed == 42

    from mimesis.providers import Payment
    field = AbstractField(locale='en', providers=[Payment])
    assert field.locale == 'en'
    assert field._gen is not None
    assert field._gen.locale == 'en'

# Generated at 2022-06-21 16:59:18.562649
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    locale = 'en'
    instance = Field(locale=locale)
    actual = str(instance)
    expected = '{} <{}>'.format(instance.__class__.__name__, locale)
    assert actual == expected

# Generated at 2022-06-21 16:59:46.896126
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-21 16:59:50.883101
# Unit test for method create of class Schema
def test_Schema_create():
    # instance of class Schema
    schema_obj = Schema(lambda: {'name': 'Lorem Ipsum'})
    data = schema_obj.create(iterations=1)

    assert data[0].get('name') == 'Lorem Ipsum'



# Generated at 2022-06-21 16:59:51.789284
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField)



# Generated at 2022-06-21 16:59:52.647078
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()

    assert type(field) == AbstractField

# Generated at 2022-06-21 16:59:53.868597
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert callable(field)



# Generated at 2022-06-21 16:59:57.161850
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test __str__ method of AbstractField class."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 17:00:01.506449
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import Datetime

    data_provider = Datetime('ru')
    field = AbstractField(locale='ru')
    assert field('now') != data_provider.now()
    assert field('now', key=lambda x: x.year) == data_provider.now().year

    field._gen.add_provider(Datetime('ru'))
    assert field('now') == data_provider.now()
    assert field('now', key=lambda x: x.year) == data_provider.now().year
    assert field('datetime.now') == data_provider.now()
    assert field('datetime.now', key=lambda x: x.year) != '2018'



# Generated at 2022-06-21 17:00:09.309544
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for ``create`` method of class :class:`Schema'.
    """
    class SchemaTest:
        def __call__(self):
            return {'param': 'value'}

    count = 10

    s = Schema(SchemaTest())
    assert count == len(s.create(count))

    for element in s.create(count):
        assert 'param' in element
        assert 'value' == element['param']

# Generated at 2022-06-21 17:00:10.835095
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Demonstration of the unit test for class AbstractField."""
    field = AbstractField('ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-21 17:00:15.989501
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""

    def _schema():
        """Test schema."""
        return {'foo': 'bar'}

    filled_schema = Schema(_schema).create()
    assert filled_schema[0]['foo'] == 'bar'