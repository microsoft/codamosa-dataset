

# Generated at 2022-06-21 16:58:19.681819
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.exceptions import UnsupportedField
    try:
        Field()()
    except UnsupportedField:
        assert True



# Generated at 2022-06-21 16:58:24.856041
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField."""
    af = AbstractField()
    assert af.__str__() == 'AbstractField <en>'



# Generated at 2022-06-21 16:58:32.316040
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'id': '0b0edb2f-e5c3-4590-bdae-3255c5f5a539',
        'name': 'John Smith',
        'email': 'johnsmith@example.com',
        'created': '2019-10-07T08:17:43.816Z',
    }

    data = Schema(schema).create(1)
    assert isinstance(data, list)
    assert isinstance(data[0], dict)
    for k, v in schema.items():
        assert k in data[0]
        assert v != data[0].get(k)

# Generated at 2022-06-21 16:58:34.357752
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    pass

# Generated at 2022-06-21 16:58:43.074321
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field(locale='ru')
    assert field('datetime.datetime') is not None
    assert field('datetime.datetime', key=lambda x: x.year) is not None
    assert field('datetime.datetime', key=lambda x: x.year) == 2017
    assert field('text.word') is not None
    assert field('text.word', length=20) is not None
    assert field('text.word', length=20) == 'принципиальное'
    assert field('text.word', length=20, as_list=True) is not None
    assert field('text.word', length=20, as_list=True) == [
        'принципиальное'
    ]




# Generated at 2022-06-21 16:58:44.706791
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {})
    assert schema is not None
    assert callable(schema.create)

# Generated at 2022-06-21 16:58:47.154760
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = Field()

    data_1 = field('file_name')
    data_2 = field('file_name', extension='jpg')

    assert data_1 != data_2

# Generated at 2022-06-21 16:58:49.103308
# Unit test for constructor of class Schema
def test_Schema():
    with Schema(SchemaType):
        raise UndefinedSchema()

# Generated at 2022-06-21 16:58:49.910308
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field()

# Generated at 2022-06-21 16:58:53.980009
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field is not None
    assert field is not False
    assert field is not True

    assert field.locale == 'en'
