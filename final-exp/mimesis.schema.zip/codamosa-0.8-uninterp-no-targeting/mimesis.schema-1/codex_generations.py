

# Generated at 2022-06-21 16:58:23.864596
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import Address, Datetime, Person, Random

    provider_address = Address(locale='en')
    provider_datetime = Datetime(locale='en')
    provider_person = Person(locale='en')
    provider_random = Random(locale='en')


# Generated at 2022-06-21 16:58:29.810809
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    schema = Schema(lambda: dict(key='value'))
    assert isinstance(schema.create(), list)
    assert isinstance(schema.create(5), list)
    assert len(schema.create(5)) == 5
    assert schema.schema is schema.create()[0]



# Generated at 2022-06-21 16:58:32.779322
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert callable(field)

# Generated at 2022-06-21 16:58:39.629810
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.builtins import Person

    # Create a sample schema
    def my_schema() -> JSON:
        return {
            'name': Person('en').full_name(),
            'age': Person('en').age(),
        }

    # Init Schema class
    schema = Schema(my_schema)
    # Create three elements
    result = schema.create(3)
    # Check result
    assert len(result) == 3
    assert isinstance(result, list)
    assert isinstance(result[0], dict)

# Generated at 2022-06-21 16:58:47.522896
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    f = AbstractField()
    data = f('word')
    assert data is not None
    assert isinstance(data, str)

    data = f('timestamp', datetime=True)
    assert data is not None
    assert isinstance(data, float)



# Generated at 2022-06-21 16:58:49.978127
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField(locale='en')
    assert str(f) == "AbstractField <en>"

# Generated at 2022-06-21 16:58:55.417563
# Unit test for constructor of class AbstractField
def test_AbstractField():
    class Human:
        f = Field()

        def __init__(self):
            self.f = Field()

    assert Human().f.locale == 'en'
    assert Human.f.locale == 'en'



# Generated at 2022-06-21 16:58:59.157309
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check the method __str__."""
    assert str(AbstractField('ru')) == 'AbstractField <ru>'

# Generated at 2022-06-21 16:59:05.922399
# Unit test for method create of class Schema
def test_Schema_create():
    # from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.schema import PersonSchema
    from mimesis.typing import JSON

    provider = Person('ru')
    schema = PersonSchema(provider)


# Generated at 2022-06-21 16:59:07.145425
# Unit test for constructor of class AbstractField
def test_AbstractField():
    obj = AbstractField(locale='en')
    assert obj.locale == 'en'



# Generated at 2022-06-21 16:59:46.588094
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor."""
    assert str(Field()) == 'AbstractField <en>'



# Generated at 2022-06-21 16:59:51.295085
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema as S
    from mimesis.typing import Schema as SchemaT

    def schema() -> SchemaT:
        return {}

    try:
        S(schema)
    except UndefinedSchema:
        raise AssertionError


# Unit tests for create method of class Schema

# Generated at 2022-06-21 16:59:54.460296
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    field = AbstractField()
    result = type(field).__name__
    result = f'{result} <{field.locale}>'
    assert str(field) == result

# Generated at 2022-06-21 17:00:00.406538
# Unit test for method create of class Schema
def test_Schema_create():
    def func_schema():
        return {'name': 'user', 'age': 34}

    schema = Schema(func_schema)
    result = schema.create(3)
    assert len(result) == 3
    assert result == [{'name': 'user', 'age': 34}] * 3

# Generated at 2022-06-21 17:00:11.064315
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Do not remove. It's a unit test."""
    import re

    field = AbstractField()

    # Check if the method is supported (without `name` parameter)
    assert field.__call__() is not None
    assert not isinstance(field.__call__(), UndefinedField)

    # Check if the method is supported (with `name` parameter)
    assert field.__call__('uuid') is not None
    assert not isinstance(field.__call__('uuid'), UndefinedField)
    assert field.__call__('uuid') != field.__call__('uuid')
    assert field.__call__('uuid', version=4) != field.__call__('uuid', version=4)

    assert isinstance(field.__call__('uuid', version=4), str)
    assert field.__

# Generated at 2022-06-21 17:00:20.130132
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.schema import AbstractField
    from mimesis.providers.internet import Internet
    from mimesis.providers.geography import Geography

    field = AbstractField()
    assert field is not None
    assert field.locale == 'en'
    assert field.seed is None

    field = AbstractField('ru', 42)
    assert field.locale == 'ru'
    assert field.seed == 42

    providers = [Internet, Geography]
    field = AbstractField(providers=providers)
    assert field is not None
    assert 'internet' in field._gen.__dict__
    assert 'geography' in field._gen.__dict__



# Generated at 2022-06-21 17:00:23.316124
# Unit test for constructor of class AbstractField
def test_AbstractField():
    #: Should not raise any exceptions.
    AbstractField(locale='en')



# Generated at 2022-06-21 17:00:25.702031
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='ru')
    assert field.locale == 'ru'



# Generated at 2022-06-21 17:00:27.738339
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {
            'name': 'item',
            'price': 100,
        }

    field = Schema(schema)
    assert isinstance(field.create(), list)
    assert field.create() == [{
        'name': 'item',
        'price': 100,
    }]

# Generated at 2022-06-21 17:00:30.372678
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'name': 'Field', 'age': 18, 'height': "5'9\""}

    def sch() -> dict:
        return schema

    s = Schema(sch)
    assert s.create()[0] == schema



# Generated at 2022-06-21 17:00:56.208355
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field(
        'make_title') == 'Make Title'

# Generated at 2022-06-21 17:01:01.521133
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    def schema() -> JSON:
        return {
            'name': Person('en').full_name(),
            'birthday': Person('en').date_of_birth(minimum_age=18).isoformat(),
            'gender': Gender.FEMALE,
            'city': Address('en').city(),
            'country': Address('en').country(),
        }

    person = Schema(schema)
    assert len(person.create(3)) == 3

# Generated at 2022-06-21 17:01:03.933796
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import schemas

    try:
        result = Schema('test')
    except UndefinedSchema:
        result = None
    assert result is None

    result = Schema(schemas.Address)
    assert result is not None

# Generated at 2022-06-21 17:01:06.354966
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema.__init__."""
    assert Schema(lambda: {})

    try:
        Schema("{}")
    except UndefinedSchema:
        assert True

# Generated at 2022-06-21 17:01:09.469509
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """."""
    f = AbstractField()
    assert f.locale == 'en'
    assert f.seed is None


# Generated at 2022-06-21 17:01:13.404160
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Check if __call__ works correctly."""
    f = Field()
    assert isinstance(f('bitcoin_address'), str)
    assert f('dna_sequence', length=10)



# Generated at 2022-06-21 17:01:16.612693
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Just check that the method works as intended.
    # If the method raises an exception,
    # the test will be failed automatically.
    # This test is not covered by coverage.

    field = AbstractField()
    field('person.name')
    field('datetime.datetime', pattern='%Y %m %d')

# Generated at 2022-06-21 17:01:18.636547
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-21 17:01:21.159577
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(Field)
    assert schema is not None

# Generated at 2022-06-21 17:01:22.445377
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 17:01:46.133208
# Unit test for constructor of class Schema
def test_Schema():
    assert callable(Schema)
    assert isinstance(Schema, object)

# Generated at 2022-06-21 17:01:47.792587
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    obj = AbstractField()
    assert str(obj) == 'AbstractField <en>'

# Generated at 2022-06-21 17:01:53.638150
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test class AbstractField."""
    f = AbstractField()
    assert callable(f)
    assert isinstance(f, AbstractField)
    assert isinstance(f._gen, Generic)
    assert len(f._gen._providers) == 0

# Generated at 2022-06-21 17:01:55.689465
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-21 17:01:59.391239
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'
    field = Field(locale='ru')
    assert str(field) == 'AbstractField <ru>'
    field = Field(locale='en-GB')
    assert str(field) == 'AbstractField <en-GB>'

# Generated at 2022-06-21 17:02:08.117992
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import Person

    gen = Generic('en')
    gen.add_providers(Person)

    field = AbstractField(locale='en', providers=[Person])

    assert field.locale == gen.locale
    assert field.seed == gen.seed

    assert len(field._table) == 0
    assert field._table == {}

    # Test appending new providers
    assert len(gen._data_providers) == 1
    assert gen._data_providers == [Person]

    assert field._gen._data_providers == gen._data_providers

    assert len(field._gen._data_providers[0]._provider_data) == 16

    assert len(field(key=len)) == 16
    assert len(field(key=len)) == 16
    assert len(field(key=len)) == 16

# Generated at 2022-06-21 17:02:17.713126
# Unit test for method create of class Schema
def test_Schema_create():
    def _test_schema():
        schema = Schema(
            lambda: {
                'number': Field('number', start=40, end=100),
                'email': Field('email', domains=['mimesis.name']),
            }
        )
        items = schema.create(5)

        for item in items:
            print(item)
            assert type(item['number']) == int
            assert '@' in item['email']

    _test_schema()

# Generated at 2022-06-21 17:02:21.816717
# Unit test for constructor of class AbstractField
def test_AbstractField():
    func = Field().__call__

    # test for exceptions
    # empty name
    try:
        func()
    except UndefinedField:
        pass
    else:
        raise AssertionError('Field is not defined.')

    # Name like a Python keyword
    try:
        func(name='in')
    except UnacceptableField:
        pass
    else:
        raise AssertionError('Field has unacceptable name.')

    # Name which not supported
    try:
        func(name='unknown')
    except UnsupportedField:
        pass
    else:
        raise AssertionError('Field is not supported.')
    # return value
    assert func(name='hexadecimal')

    # return value from the first provider
    assert func(name='word')
    # return value from the second provider

# Generated at 2022-06-21 17:02:30.751504
# Unit test for constructor of class Schema
def test_Schema():
    import types
    import mimesis.builtins
    from mimesis.providers.address import Address

    schema = Schema(lambda: {'foo': 'bar'})

    try:
        schema = Schema(5)
    except UndefinedSchema:
        assert True
    else:
        assert False

    try:
        schema = Schema(list)
    except UndefinedSchema:
        assert True
    else:
        assert False

    schema = Schema(lambda: {'foo': 'bar'})

    # test Schema.create()
    assert schema.create(1) == [{'foo': 'bar'}]



# Generated at 2022-06-21 17:02:34.771978
# Unit test for constructor of class AbstractField
def test_AbstractField():
    expected_instance = '<Field <en>>'
    assert str(Field(locale='en')) == expected_instance
    assert str(Field(seed='123')) == expected_instance
    assert str(Field(locale='en', seed='123')) == expected_instance

# Generated at 2022-06-21 17:03:50.677244
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import Personal, Address, FIELDS

    # Create a new field
    field = AbstractField()
    # The result of calling
    res = field('full_name')
    assert isinstance(field, AbstractField)
    assert isinstance(res, str)
    assert res != ''

    # Check if provider supported
    with should_raise(UnsupportedField('uuid')):
        field('uuid')

    # Check if field is not defined
    with should_raise(UndefinedField):
        field()

    # Get the provider's method by name and apply to it
    res = field('full_name', key=Personal.is_male)
    assert isinstance(res, bool)

    # Get the provider's method by name with arguments
    res = field('iban', key=lambda x: x.replace(' ', ''))


# Generated at 2022-06-21 17:03:53.196983
# Unit test for method __str__ of class AbstractField

# Generated at 2022-06-21 17:03:56.743591
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """."""
    field = AbstractField(locale='en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 17:03:59.619549
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {'name': 'Test'}

    s = Schema(schema)
    assert s.create() == [{'name': 'Test'}]

# Generated at 2022-06-21 17:04:08.981103
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': Field('en').person.name(),
            'surname': Field('en').person.surname(),
            'email': Field('en').person.email(),
        }

    s = Schema(schema)
    assert s.create()[0] == schema()
    assert len(s.create(10)) == 10
    assert s.create()[0]['name'] == Field('en').person.name()

# Generated at 2022-06-21 17:04:12.155951
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    # This code should not raise an exception
    # Noqa: PyTypeChecker
    field('email')



# Generated at 2022-06-21 17:04:13.930445
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    field('datetime')



# Generated at 2022-06-21 17:04:15.886310
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'


# Unit tests for method __call__ of class AbstractField