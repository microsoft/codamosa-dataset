

# Generated at 2022-06-21 16:58:19.907639
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()
    assert 'BOB' in f('person.name')
    assert 6 in [
        len(f('person.password'))
        for _ in range(0, 6)
    ]
    assert 6 in [
        len(f('person.password', length=6))
        for _ in range(0, 6)
    ]
    assert 6 not in [
        len(f('person.password', length=5))
        for _ in range(0, 6)
    ]

# Generated at 2022-06-21 16:58:23.074670
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert AbstractField(locale='en')

# Generated at 2022-06-21 16:58:25.000700
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-21 16:58:27.360985
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis import _AbstractField
    assert isinstance(_AbstractField.__init__(object), str)

# Generated at 2022-06-21 16:58:35.838700
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField(locale='en')

    # Without 'name' parameter
    try:
        field()
    except UndefinedField:
        # Field not defined
        pass
    else:
        raise Exception('Name must be specified!')

    # Normal case
    field.__call__(name=field._gen.random.boolean.Meta.name)

    # With 'key' parameter
    field.__call__(
        name=field._gen.random.boolean.Meta.name,
        key=lambda x: '{0}'.format(x))

    # With 'key' parameter
    field.__call__(
        name=field._gen.random.boolean.Meta.name,
        key=lambda x: '{0}'.format(x),
        key_function='{0}')

    # With '

# Generated at 2022-06-21 16:58:42.004036
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field

    def schema():
        _field = Field()
        return _field(
            'user_agent.safari',
            key=lambda x: {
                'name': _field('name', gender='female'),
                'age': _field('age'),
                'user_agent': x,
            },
        )

    schema = Schema(schema)
    data = schema.create(2)
    assert isinstance(data, list)
    assert len(data) == 2



# Generated at 2022-06-21 16:58:47.349046
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor."""
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None
    assert repr(field) == "Field <en>"

    field = Field('ru')
    assert field.locale == 'ru'
    assert field.seed is None
    assert repr(field) == "Field <ru>"

    field = Field('ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42
    assert repr(field) == "Field <ru>"

# Generated at 2022-06-21 16:58:50.412889
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Tests that the returned string has the right value."""
    field = AbstractField()
    expected = 'AbstractField <en>'
    assert str(field) == expected

# Generated at 2022-06-21 16:58:52.738787
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    obj = Field()
    assert str(obj) == 'AbstractField <en>'

# Generated at 2022-06-21 16:59:00.883322
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'first_name': 'Anna',
        'age': 18,
    }
    expected = [
        {'first_name': 'Anna', 'age': 18},
        {'first_name': 'Anna', 'age': 18},
        {'first_name': 'Anna', 'age': 18},
    ]
    result = Schema(schema).create(3)

    assert expected == result