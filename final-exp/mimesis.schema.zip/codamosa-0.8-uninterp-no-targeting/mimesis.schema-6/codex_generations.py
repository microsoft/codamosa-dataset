

# Generated at 2022-06-21 16:58:37.155733
# Unit test for method create of class Schema
def test_Schema_create():
    from . import address

    schema = Schema(address.Address)

    schema.create(iterations=3)

# Generated at 2022-06-21 16:58:39.167793
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {'foo': 'bar'})
    result = schema.create()
    assert len(result) == 1

# Generated at 2022-06-21 16:58:49.665575
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    assert field('personal.full_name') != ''

    assert field('personal.full_name', key=str.strip) != ''

    test_dict = {
        'name': 'lk-geimfari',
    }

    assert field('personal.full_name', **test_dict) == 'lk-geimfari'

    assert field('personal.full_name', key=lambda x: x.split()[0]) != ''

# Generated at 2022-06-21 16:58:53.253150
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.providers import Address

    ad = Address('en')
    schema = {'address': ad.address, 'city': ad.city}

    def get_schema() -> JSON:
        return schema

    s = Schema(get_schema)
    result = s.create(iterations=3)

    assert len(result) == 3

# Generated at 2022-06-21 16:59:01.607190
# Unit test for constructor of class Schema
def test_Schema():
    # If schema is not a callable object we get UndefinedSchema error
    error = None
    try:
        Schema('')
    except UndefinedSchema as e:
        error = e

    assert isinstance(error, UndefinedSchema)
    assert error.args[0] == "Schema must be a callable object got <class 'str'>"
    # If schema is a callable object we get no error
    assert Schema(lambda: None)


# Generated at 2022-06-21 16:59:10.091261
# Unit test for method create of class Schema
def test_Schema_create():
    # Create schema
    def schema():
        return {'key': 'value'}

    result = Schema(schema).create()
    assert result == [{'key': 'value'}]
    result = Schema(schema).create(10)
    assert len(result) == 10
    result = Schema(schema).create(0)
    assert result == []