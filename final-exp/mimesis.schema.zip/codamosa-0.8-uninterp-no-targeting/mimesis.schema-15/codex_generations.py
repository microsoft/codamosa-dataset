

# Generated at 2022-06-21 16:58:08.846064
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    f = Field(locale='en')
    assert f('__repr__') == "<Field <en>>"
    assert f.__repr__() == "<Field <en>>"

    # Test for wrong name of method
    f('foo')

# Generated at 2022-06-21 16:58:13.696457
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import Schema

    def foo() -> JSON:
        return {}

    Schema(foo)

    assert True

# Generated at 2022-06-21 16:58:21.690230
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person


# Generated at 2022-06-21 16:58:23.266577
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    fn = AbstractField()
    assert fn('full_name')



# Generated at 2022-06-21 16:58:28.396974
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for the constructor of AbstractField."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

    field.add_providers(field.personal)
    assert field('first_name_male') == field.personal.first_name_male()

# Generated at 2022-06-21 16:58:30.481312
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    schema = ('name', 'first_name')
    field = Field()
    keys = [field(name) for name in schema]
    assert len(keys) == len(schema)

# Generated at 2022-06-21 16:58:35.856971
# Unit test for constructor of class Schema
def test_Schema():
    def _schema():
        """A schema for unit test."""
        return {
            'first_name': 'Ivan',
            'last_name': 'Ivanov',
        }

    assert isinstance(Schema(_schema), Schema)

# Generated at 2022-06-21 16:58:39.897001
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

    field = AbstractField(locale='fr')
    assert str(field) == 'AbstractField <fr>'

    field = AbstractField(locale='jp')
    assert str(field) == 'AbstractField <jp>'



# Generated at 2022-06-21 16:58:42.362060
# Unit test for constructor of class AbstractField
def test_AbstractField():
    a = AbstractField()
    assert isinstance(a, AbstractField)

# Generated at 2022-06-21 16:58:46.044871
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    def schema() -> dict:
        """Get filled schema."""
        return {'name': 'Levi'}

    actual = Schema(schema=schema).create(iterations=10)
    assert actual == [{'name': 'Levi'} for _ in range(10)]

# Generated at 2022-06-21 16:59:29.417182
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.schema import Field

    field = Field()

    def schema() -> JSON:
        return {
            'name': field('person.full_name', gender=Gender.FEMALE),
            'address': field('address.address'),
        }

    s = Schema(schema)
    filled = s.create()

    # print(filled)
    assert filled

# Generated at 2022-06-21 16:59:31.981157
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('last_name') is not None
    assert field('last_name', key=lambda x: x.upper()) is not None

# Generated at 2022-06-21 16:59:40.088712
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor."""
    from mimesis.schema import Field
    from mimesis.schema import Schema
    from mimesis.schema import _get_schema

    def _schema():
        return {
            'name': str(Field(name='text.word')),
            'surname': str(Field(name='person.surname')),
        }

    assert Schema(_schema)

    with Schema(_get_schema)('person'):
        assert Schema(_schema)
    assert Schema(_schema)

# Generated at 2022-06-21 16:59:47.669592
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    f = Field()
    assert f.__call__(name='full_name', gender='male')

    try:
        f.__call__()  # type: ignore
    except UndefinedField as e:
        assert str(e) == 'Undefined field.'

    try:
        f.__call__(name='full.name.without.dot')
    except UnacceptableField as e:
        assert str(e) == 'Unacceptable field.'

    try:
        f.__call__(name='random.method.which.is.not.exist.in.any.provider')
    except UnsupportedField as e:
        assert str(e) == 'Field is not supported.'



# Generated at 2022-06-21 16:59:48.442090
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field is AbstractField

# Generated at 2022-06-21 16:59:49.551700
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 16:59:52.540546
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method AbstractField.__call__."""
    result1 = AbstractField()('get_uuid')
    result2 = AbstractField(seed='kdfjh32jfkdfh32hj',
                            providers=[])('get_uuid')
    print(result1)
    print(result2)
    assert not result1 == result2

# Generated at 2022-06-21 17:00:03.395267
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    from mimesis.typing import JSON
    import pytest

    FIELDS = {
        'firstname': 'person.first_name',
        'lastname': 'person.last_name',
        'email': 'person.email',
        'address': 'address.address',
    }

    def schema() -> JSON:
        """Filled schema."""
        return {
            'firstname': str(Field()(FIELDS['firstname'])),
            'lastname': str(Field()(FIELDS['lastname'])),
            'email': str(Field()(FIELDS['email'])),
            'address': str(Field()(FIELDS['address'])),
        }

    sch = Schema(schema)
    res = sch

# Generated at 2022-06-21 17:00:07.347351
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema."""
    # test case N1
    with Schema(lambda: {'test': 1}) as schema:
        assert schema.create() == [{'test': 1}]

# Generated at 2022-06-21 17:00:09.509385
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField constructor."""
    f = AbstractField()
    assert isinstance(
        f, AbstractField
    )

# Generated at 2022-06-21 17:00:53.746841
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema.json import Person

    p = Person()

    assert callable(p)

# Generated at 2022-06-21 17:00:55.996603
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    def func():
        pass
    f = AbstractField()
    func = f.__str__
    assert func() == 'AbstractField <en>'

# Generated at 2022-06-21 17:00:59.549997
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {'a': 1, 'b': 2, 'c': 3}

    obj = Schema(schema)
    data = obj.create(2)

    assert data == [
        {'a': 1, 'b': 2, 'c': 3},
        {'a': 1, 'b': 2, 'c': 3},
    ]

# Generated at 2022-06-21 17:01:00.910249
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of AbstractField."""
    assert str(AbstractField('en')) == 'AbstractField <en>'

# Generated at 2022-06-21 17:01:03.517724
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = Field()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-21 17:01:05.285912
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    ab_field = AbstractField()
    assert (str(ab_field) == 'AbstractField <en>')

# Generated at 2022-06-21 17:01:16.133635
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    gen = Generic('en')
    f = Field()

    def _schema():
        """Create a schema."""
        return {'id': f('code', key=str), 'data': f('text')}

    s = Schema(_schema)
    result = s.create(5)
    assert isinstance(result, list) is True
    assert len(result) == 5
    assert isinstance(result[0], dict) is True
    assert 'id' in result[0] and 'data' in result[0]
    assert len(result[0]['id']) == gen.code().length()
    assert isinstance(result[0]['data'], str) is True

# Generated at 2022-06-21 17:01:18.128159
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.schema import Field

    f = Field()
    assert f('text')



# Generated at 2022-06-21 17:01:28.640206
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.enums import Gender

    # Test class for checking schemas
    class TestSchema:  # noqa
        def schema(self):
            return {
                'name.first': self.name.first_name(gender=Gender.FEMALE),
                'name.last': self.name.last_name(gender=Gender.FEMALE),
                'job.title': self.job.occupation(),
            }

    p = TestSchema()
    schema = Schema(p.schema)
    result = schema.create(iterations=1)
    # Assert that result must be a list of schemas
    assert type(result) is list

    schema = Schema([1, 2, 3])

# Generated at 2022-06-21 17:01:31.403457
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for AbstractField.__str__()."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'