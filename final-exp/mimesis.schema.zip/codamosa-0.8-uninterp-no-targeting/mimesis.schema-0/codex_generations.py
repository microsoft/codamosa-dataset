

# Generated at 2022-06-21 16:58:02.093225
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema"""
    assert isinstance(Schema, type)



# Generated at 2022-06-21 16:58:02.719704
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert callable(field)



# Generated at 2022-06-21 16:58:08.632268
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method ``__call__`` of class AbstractField."""
    from mimesis.providers.cryptographic import Cryptographic

    field = AbstractField(providers=[Cryptographic])
    assert isinstance(field, AbstractField)

    salt = field(field.Meta.name)
    assert len(salt) == 64
    assert isinstance(salt, str)

    salt = field('cryptographic.salt')
    assert len(salt) == 64
    assert isinstance(salt, str)

    password = field('cryptographic.password', length=128)
    assert len(password) == 128
    assert isinstance(password, str)



# Generated at 2022-06-21 16:58:14.291535
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for AbstractField.__str__."""
    f = Field()
    assert isinstance(f, Field)
    assert str(f) == 'Field <en>'

# Generated at 2022-06-21 16:58:16.349540
# Unit test for constructor of class Schema
def test_Schema():
    Schema(None)

# Generated at 2022-06-21 16:58:18.233526
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('int')
    assert field('int', maximum=10, minimum=1)

# Generated at 2022-06-21 16:58:20.445033
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test ``__str__`` method of class AbstractField."""
    schema = AbstractField()
    result = str(schema)
    assert result == 'AbstractField <en>'



# Generated at 2022-06-21 16:58:30.347674
# Unit test for method create of class Schema
def test_Schema_create():
    def get_sch():
        return {
            'name': Field(),
            'surname': Field(),
            'age': Field(name='person.age'),
            'uuid': Field('uuid4'),
        }
    sch = Schema(get_sch)
    data = sch.create()

    for i in data:
        assert i.get('name') is not None
        assert i.get('surname') is not None
        assert i.get('age') is not None
        assert i.get('uuid') is not None

    assert len(data) is 10

# Generated at 2022-06-21 16:58:38.946307
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Field

    field = Field()

    def schema() -> dict:
        return {
            'name': field.full_name(),
            'address': {
                'country': field.country(),
                'city': field.city(),
                'street': field.street_address(),
            },
        }

    sch = Schema(schema)

    assert sch is not None
    sch.create()

# Generated at 2022-06-21 16:58:51.211102
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test __call__ from AbstractField."""
    assert Field().__call__(name='name')
    assert Field().__call__(name='telephone')
    # assert Field(providers=[BaseUnit]).__call__(name='customary')
    assert Field().__call__(name='city', country_code='ru')
    assert Field().__call__(name='full_name')
    assert Field().__call__(name='email')
    assert Field().__call__(name='postcode')
    assert Field().__call__(
        name='name', key=lambda x: ' '.join(x.split(' ')[:2]))



# Generated at 2022-06-21 16:59:12.295480
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField."""
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-21 16:59:13.908427
# Unit test for constructor of class Schema
def test_Schema():
    schema = {'foo': 'bar'}

    def foo() -> JSON:
        return schema

    Schema(foo)

# Generated at 2022-06-21 16:59:17.059583
# Unit test for method create of class Schema
def test_Schema_create():
    """Working with class ``Schema``."""
    from mimesis.schema.schemas import User

    schema = Schema(User)
    user = schema.create(iterations=1)[0]

    assert set(user.keys()) == set([
        'name', 'gender', 'age', 'contact',
    ])

# Generated at 2022-06-21 16:59:22.637104
# Unit test for method create of class Schema
def test_Schema_create():
    def test_schema():
        return {
            'string': Field()('text.word'),
            'integer': Field()('numbers.between', start=1, end=999),
            'list': Field()('list.randoms', num=3, min=1, max=9999),
        }

    schema = Schema(test_schema)
    assert schema.create(2) == [{
        'string': 'dolor',
        'integer': 593,
        'list': [8203, 8255, 7063],
    }, {
        'string': 'dolor',
        'integer': 792,
        'list': [7196, 8256, 6655],
    }]

# Generated at 2022-06-21 16:59:24.900117
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-21 16:59:29.551511
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> JSON:
        return {'foo': 42}
    schm = Schema(schema)
    assert schm is not None
    assert schm.create() == [{'foo': 42}]

# Generated at 2022-06-21 16:59:32.255055
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test __str__ of class."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'  # noqa: WPS421

# Generated at 2022-06-21 16:59:37.779558
# Unit test for method create of class Schema
def test_Schema_create():
    from tests.utils import get_schema

    schema = get_schema()

    field = Schema(schema)
    result = field.create(iterations=3)

    assert result is not None
    assert len(result) == 3
    assert any(['name' in r for r in result])
    assert any(['email' in r for r in result])

# Generated at 2022-06-21 16:59:46.910100
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.data import MEDIA
    from mimesis.enums import Gender
    from mimesis.providers.media import Media
    from mimesis.providers.person import Person

    loc = 'en'
    seed = 'test'

# Generated at 2022-06-21 16:59:47.882820
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert field.__str__() == 'AbstractField <en>'