

# Generated at 2022-06-21 16:58:10.880549
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of class Schema."""
    from mimesis.schema import Schema as Schema_
    from mimesis.schema import SchemaType as SchemaType_

    def is_callable(x: Any) -> bool:
        """Return True if x is a callable object."""
        return callable(x)

    def get_callable() -> SchemaType_:
        """Return callable object."""
        return is_callable

    assert isinstance(Schema(get_callable()), Schema_)



# Generated at 2022-06-21 16:58:13.343445
# Unit test for constructor of class AbstractField
def test_AbstractField():
    a = AbstractField()
    assert isinstance(a, AbstractField)

# Generated at 2022-06-21 16:58:16.407032
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(lambda: {}).create()) == 1
    assert len(Schema(lambda: {}).create(5)) == 5

# Generated at 2022-06-21 16:58:22.591781
# Unit test for method create of class Schema
def test_Schema_create():
    def test_schema():
        return {
            'a': 1,
            'b': 2,
        }

    res = Schema(test_schema).create(10)  # type: ignore
    assert len(res) == 10
    assert [elem for elem in res if elem.get('a') == 1] == [{'a': 1, 'b': 2}] * 10
    assert [elem for elem in res if elem.get('a') == 2] == []
    assert [elem for elem in res if elem.get('b') == 1] == []

# Generated at 2022-06-21 16:58:24.589449
# Unit test for method create of class Schema
def test_Schema_create():
    assert isinstance(Schema(lambda: {}).create(), list)

# Generated at 2022-06-21 16:58:34.195091
# Unit test for method create of class Schema
def test_Schema_create():
    field = AbstractField()

# Generated at 2022-06-21 16:58:36.225477
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema
    assert schema is not None


# Generated at 2022-06-21 16:58:37.869376
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()

    assert field is not None



# Generated at 2022-06-21 16:58:40.350280
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema."""
    error = 'Argument schema of Schema must be a callable object'
    try:
        Schema('test')
    except UndefinedSchema as err:
        assert err.args[0] == error

# Generated at 2022-06-21 16:58:44.962911
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.builtins import RussiaSpecProvider

    f = Field(providers=[RussiaSpecProvider])
    f.__call__('full_name') == 'full_name'

# Generated at 2022-06-21 16:59:06.059876
# Unit test for constructor of class Schema
def test_Schema():
    schema = {'key': 'value'}
    assert Schema(schema).schema == schema

# Generated at 2022-06-21 16:59:16.085457
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.providers import \
        Address, Person, Business, Datetime, Payment

    from datetime import datetime

    def test_schema() -> JSON:  # noqa: E999
        person = Person('en')
        address = Address('en')
        business = Business('en')
        payment = Payment('en')
        dt = Datetime('en')


# Generated at 2022-06-21 16:59:20.625913
# Unit test for method create of class Schema
def test_Schema_create():
    """Tests for method create of class Schema."""
    from mimesis.schema import Field, JSONField
    from mimesis.typing import JSON

    field = Field('en')

    def schema() -> JSON:
        return JSONField({
            'first_name': field('first_name'),
            'last_name': field('last_name'),
        })

    sch = Schema(schema)
    assert isinstance(sch.create(), list)
    assert isinstance(sch.create()[0], dict)

# Generated at 2022-06-21 16:59:29.966129
# Unit test for method create of class Schema
def test_Schema_create():
    """Test Schema.create()."""
    field = AbstractField()
    schema = Schema(lambda: {'a': field('int', max_value=100)})

    result = schema.create()
    assert isinstance(result, list)
    assert len(result) == 1
    assert isinstance(result[0], dict)
    assert 'a' in result[0]

    result = schema.create(iterations=10)
    assert len(result) == 10

# Generated at 2022-06-21 16:59:42.155292
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test class AbstractField."""
    f = AbstractField()

    def test_seed(seed):
        """Test seed."""
        assert seed is f.seed

    def test_locale(locale):
        """Test locale."""
        assert locale == f.locale

    f(name='uuid', key=test_seed)
    f(name='uuid4', key=test_seed)
    f(name='uuid4', key=lambda x: len(x) == 36)
    f(name='uuid', key=lambda x: len(x) == 36)
    f(name='mock.uuid4', key=test_seed)
    f(name='mock.uuid4', key=lambda x: len(x) == 36)

# Generated at 2022-06-21 16:59:53.313155
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method call of AbstractField class."""
    field = Field()
    assert 'English' == field('name', title=True)
    assert field('name', title=True, seed=400) == 'German'
    assert field('number', minimum=1, maximum=10) == 4
    assert field('code', code_type='name') == 'IT'
    assert field('currency', code_type='iso') == 'USD'
    assert field('name', first_name=True) == 'Colin'
    assert field('name', first_name=True, seed=400) == 'John'

    # Fix https://github.com/lk-geimfari/mimesis/issues/619
    assert field('choice', collection=['A', 'B', 'C']) == 'B'

# Generated at 2022-06-21 16:59:54.701475
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = Field('ru', 1234)

    assert field.locale == 'ru'
    assert field.seed == 1234

# Generated at 2022-06-21 16:59:56.797378
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.locale == 'en'


# Generated at 2022-06-21 16:59:57.298056
# Unit test for constructor of class AbstractField
def test_AbstractField():
    AbstractField()

# Generated at 2022-06-21 17:00:09.406449
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    name = 'test'
    def test_method(x, y):
        return x + y
    class TestClass:
        def test_method(self, x, y):
            return x + y

    class TestProvider:
        def test_method(self, x, y):
            return x + y

    class MyField(AbstractField):
        def __init__(self, locale: str = 'en', seed: Optional[Seed] = None):
            super().__init__(locale, seed)
            self.add_provider(TestProvider())
        def test_method(self, x, y):
            return x + y

    def test_error(obj: Any, provider: Any, name: str) -> None:
        expected = UnsupportedField.__name__
        actual = UnsupportedField(name)

# Generated at 2022-06-21 17:00:39.245621
# Unit test for constructor of class Schema
def test_Schema():
    schema = dict(a=1, b=2, c=3)
    sc = Schema(schema)
    assert sc

# Generated at 2022-06-21 17:00:40.733321
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    expected = "AbstractField <en>"
    field = Field()
    assert str(field) == expected

# Generated at 2022-06-21 17:00:41.902050
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-21 17:00:46.093459
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Tests for AbstractField.__call__."""
    from mimesis.datetime import DateTime
    from mimesis.schema import Field

    field = Field('en')

    dt = DateTime('en')
    dt.bind_field(field)

    assert callable(field.__call__)

    assert isinstance(field('year'), int)
    assert isinstance(field('january'), str)
    assert isinstance(field('day_of_week'), int)

    assert field('day_of_week', formatter=str) == dt.day_of_week(formatter=str)

    assert field('__unsupported_field__') == \
        field('__unsupported_field__', is_fake=True)



# Generated at 2022-06-21 17:00:49.863377
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.datasets import GENDERS as GEN
    def schema():
        return {
            'name': 'Adam',
            'age': 5,
            'gender': GEN,
        }
    Schema(schema)

# Generated at 2022-06-21 17:00:53.557688
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema

    def _schema() -> JSON:
        return {
            'foo': 'bar',
        }

    s = Schema(_schema)
    assert s.schema == _schema, 'ERROR: wrong schema.'

# Generated at 2022-06-21 17:00:55.157035
# Unit test for constructor of class Schema
def test_Schema():
    Schema(int)
    try:
        Schema('Hello')
    except UndefinedSchema:
        pass

# Generated at 2022-06-21 17:01:00.524799
# Unit test for constructor of class Schema
def test_Schema():
    """Test the constructor of Schema class."""
    # pylint: disable=protected-access
    sch = Schema(lambda: {})
    assert sch._Schema__schema() == {}

    sch = Schema([1, 2])
    try:
        sch._Schema__schema()
    except UndefinedSchema:
        assert True
    else:
        assert False

    sch = Schema(None)
    try:
        sch._Schema__schema()
    except UndefinedSchema:
        assert True
    else:
        assert False



# Generated at 2022-06-21 17:01:05.684700
# Unit test for method create of class Schema
def test_Schema_create():
    import mimesis
    p = mimesis.Person()
    schema = {
        'name': p.full_name,
        'age': p.age
    }
    sample_data = Schema(schema).create(10)
    assert len(sample_data) == 10
    assert isinstance(sample_data, list)
    for d in sample_data:
        assert 'name' in d
        assert 'age' in d



# Generated at 2022-06-21 17:01:16.992650
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    provider = Generic('en')
    field = Field('en')
    method = provider.datetime.timestamp()
    result = field('datetime.timestamp')
    assert (method == result) is True

    field = Field('en', 'zzz')
    method = provider.datetime.timestamp()
    result = field('datetime.timestamp')
    assert (method == result) is False

    field = Field('ru')
    method = provider.datetime.timestamp()
    result = field('datetime.timestamp')
    assert (method == result) is False

    # Check UnacceptableField
    try:
        field = Field('en')
        field('hello.world.zzz')
        assert False
    except UnacceptableField:
        assert True



# Generated at 2022-06-21 17:01:33.480962
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 17:01:34.466924
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert callable(field) is True

# Generated at 2022-06-21 17:01:35.861754
# Unit test for constructor of class Schema
def test_Schema():
    import pytest

    with pytest.raises(UndefinedSchema):
        Schema(1)

# Generated at 2022-06-21 17:01:40.506289
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema({
        "foo": "bar",
    })

    assert schema.create() == [{
        "foo": "bar",
    }]

# Generated at 2022-06-21 17:01:47.628893
# Unit test for method create of class Schema
def test_Schema_create():
    """Test that method create return list of filled schema."""
    schema = {'foo': 'bar', 'baz': 42}

    class TestSchema:
        def __call__(self):
            return schema

    assert Schema(TestSchema()).create(iterations=3) == [schema] * 3

# Generated at 2022-06-21 17:01:53.339586
# Unit test for constructor of class Schema
def test_Schema():
    import json

    # Create a filled schema
    schema = {
        'id': 'email',
        'properties': {
            'url': {'type': 'string'},
            'tags': {
                'items': {'type': 'string'},
                'type': 'array'
            },
            'email': {'type': 'string'},
            'name': {'type': 'string'},
            'description': {'type': 'string'},
            'phone': {'type': 'string'},
            'address': {'type': 'string'},
        },
        'type': 'object'
    }

    # Create a custom AbstractField which overrides
    # __call__ to return only methods from 'datetime' provider

# Generated at 2022-06-21 17:01:54.723507
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    provider = AbstractField()
    assert isinstance(str(provider), str)

# Generated at 2022-06-21 17:01:56.913781
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field(locale='en')
    assert 'Field <en>' in str(f)

# Generated at 2022-06-21 17:02:00.705666
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f._gen.providers == ('address', 'code', 'commerce', 'datetime', 'food',
                                'internet', 'location', 'lorem', 'misc', 'network',
                                'numbers', 'person', 'text', 'transport')

# Generated at 2022-06-21 17:02:03.039181
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    value = str(AbstractField(locale='en'))
    assert value == 'AbstractField <en>'

# Generated at 2022-06-21 17:02:47.655033
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema constructor."""
    # Test with a callable object
    Schema(lambda: {'foo': 'bar'})

    # Test with a not callable object
    try:
        Schema({'foo': 'bar'})
    except UndefinedSchema:
        pass

# Generated at 2022-06-21 17:02:49.444635
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('random.number')

# Generated at 2022-06-21 17:02:56.807901
# Unit test for method create of class Schema
def test_Schema_create():
    def test_schema():
        """Test schema."""
        return {'a': 1, 'b': "2", 'c': 3, 'd': 4}

    schema = Schema(schema=test_schema)
    assert len(schema.create(iterations=5)) == 5
    assert isinstance(schema.create(iterations=5), list)

# Generated at 2022-06-21 17:03:09.318714
# Unit test for method create of class Schema
def test_Schema_create():
    import pytest

    from helper import seed

    data = {
        'name': 'Drax',
        'health': 5000,
        'address': {
            'country': 'USA',
            'city': 'New York',
            'street': 'Manhattan',
        },
        'weapons': ['dagger', 'hammer'],
        'phrase': 'die!',
        'born': '1980',
    }


# Generated at 2022-06-21 17:03:11.607328
# Unit test for constructor of class Schema
def test_Schema():
    sch = Schema(lambda: 'test')
    sch.create()

# Generated at 2022-06-21 17:03:14.787874
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test generator of AbstractField."""
    f = Field()
    assert isinstance(f, AbstractField)

# Generated at 2022-06-21 17:03:18.287276
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField(locale='en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 17:03:29.808391
# Unit test for method create of class Schema
def test_Schema_create():
    import mimesis.enums
    from mimesis.providers.address import Address
    from mimesis.providers.generic import Generic

    def schema() -> dict:
        return {
            'name': Field().name(),
            'age': Field().age(minimum=0, maximum=100),
            'city': Field().city(),
            'currency': Field().currency_code(),
            'date': Field().date(),
            'time': Field().time(),
            'datetime': Field().datetime(),
            'uuid': Field().uuid4(),
            'url': Field().url(),
            'email': Field().email(),
        }

    # Test for correct values
    assert Schema(schema).create(iterations=10)

    # Test for custom class Schema

# Generated at 2022-06-21 17:03:37.599773
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.data import OCCUPATIONS

    def schema():
        field = Field()
        return dict(
            id=field('uuid'),
            job=field('occupation', data=OCCUPATIONS),
            name=field('full_name'),
        )

    for item in Schema(schema).create(50):
        assert isinstance(item['id'], str)
        assert isinstance(item['job'], str)
        assert isinstance(item['name'], str)

# Generated at 2022-06-21 17:03:49.582111
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    _field = Field()
    assert _field('word')

    _field = Field(seed=12345)
    assert _field('word') == 'praesentium'

    def key_function(x: str) -> str:
        return x.upper()

    _field = Field(seed=12345)
    assert _field('word', key=key_function) == 'PRAESENTIUM'

    _field = Field(locale='de')
    assert ' ' in _field('word')

    _field = Field(locale='ru')
    assert ' ' not in _field('word')

    _field = Field(locale='ru')

# Generated at 2022-06-21 17:05:00.356802
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': '{first_name} {last_name}',
        'job': '{occupation}'
    }

    mock = Schema(schema)

    result = mock.create()

    assert len(result) == 1

# Generated at 2022-06-21 17:05:02.525356
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.enums import Gender
    from mimesis.providers import Person
    from mimesis.schema import Field

    schema_field = Field()

    schema = {
        'first_name': schema_field('first_name'),
        'last_name': schema_field('last_name'),
        'gender': Person.Gender.MALE
    }

    _ = Schema(schema)

# Generated at 2022-06-21 17:05:09.840763
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            "name": Field('en').full_name(),
            "age": Field('en').age(),
            "birthday": Field('en').date(),
        }

    s = Schema(schema)
    assert s.create() == [schema()]
    assert isinstance(s.create(), list)

# Generated at 2022-06-21 17:05:12.129879
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(AbstractField())
    assert isinstance(schema.create(iterations=3), list)

# Generated at 2022-06-21 17:05:16.244477
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('person.full_name') == 'John Smith'
    assert field('person.full_name', key=lambda x: x.upper()) == 'JOHN SMITH'

# Generated at 2022-06-21 17:05:19.858807
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> JSON:
        return {}

    s = Schema(schema)
    assert callable(s.schema)
    assert isinstance(s, Schema)



# Generated at 2022-06-21 17:05:32.833143
# Unit test for method create of class Schema
def test_Schema_create():
    """Test the method create of the class Schema."""
    schema = Schema({
        'a': lambda: 'a',
        'b': lambda: 'b',
    })
    assert schema.create(1) == [{'a': 'a', 'b': 'b'}]

    schema = Schema({
        'a': lambda: 'a',
        'b': lambda: 'b',
    })
    assert schema.create(5) == [
        {'a': 'a', 'b': 'b'},
        {'a': 'a', 'b': 'b'},
        {'a': 'a', 'b': 'b'},
        {'a': 'a', 'b': 'b'},
        {'a': 'a', 'b': 'b'},
    ]

# Generated at 2022-06-21 17:05:33.949111
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    return AbstractField()

# Generated at 2022-06-21 17:05:46.256693
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.datetime import Datetime

    field = AbstractField()
    field._gen.add_providers(Datetime)

    # Test method from added provider
    assert field('datetime_delta') >= 0
    assert field('datetime_delta') <= 99999999

    # Test method from default provider
    assert field('random_int') >= 0
    assert field('random_int') <= 99999999

    # Test method with key
    assert field('random_int', key=str)

    # Test method from parent
    assert field('choice', args=['A', 'b', 'C']) in ['A', 'b', 'C']

    # Test method from provider
    assert field('datetime.datetime_delta') >= 0
    assert field('datetime.datetime_delta') <= 99999

# Generated at 2022-06-21 17:05:51.749676
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'string': '<string>',
        'integer': '<integer()>',
        'number': '<number()>',
    }

    s = Schema(schema)
    assert isinstance(s.create(), list)
    assert len(s.create(iterations=5)) == 5