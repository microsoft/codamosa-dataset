

# Generated at 2022-06-21 16:58:26.336933
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()  # noqa: F841
    assert AbstractField(locale='fo') is not None

# Generated at 2022-06-21 16:58:27.407409
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor."""
    try:
        Schema({})
    except UndefinedSchema:
        assert True

# Generated at 2022-06-21 16:58:29.327492
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema
    from mimesis.schema import Field

    assert issubclass(Field, AbstractField)
    assert issubclass(Schema, Field)

# Generated at 2022-06-21 16:58:30.080804
# Unit test for constructor of class Schema
def test_Schema():
    Schema({})

# Generated at 2022-06-21 16:58:40.563169
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Create an object of class AbstractField
    field = Field()
    # These tests are calling methods from mimesis.providers.generic module
    assert field('word')
    assert field('text')
    assert field('word.en')
    assert field('text.en')
    assert field('word.en', capitalize=True)
    assert field('text.en', capitalize=True)
    assert field('word', capitalize=True)
    assert field('text', capitalize=True)

    # More tests with a key function
    assert len(field('word', key=lambda w: w)) == 6


# Test for method __call__ with an UnacceptableField exception

# Generated at 2022-06-21 16:58:50.681877
# Unit test for method create of class Schema
def test_Schema_create():
    class Person:
        def __init__(self):
            self.name = Field()
            self.age = Field()
            self.id = Field()

        def __call__(self):
            return {
                'name': self.name('name', case='upper'),
                'age': self.age('age', minimum=18),
                'id': self.id('uuid4', cast=str),
            }

    person = Person()
    data = Schema(person).create(2)

    from pprint import pprint
    pprint(data)

# Generated at 2022-06-21 16:58:55.568916
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    af = AbstractField()
    assert af.__str__() == 'AbstractField <en>'

    af = AbstractField('ru')
    assert af.__str__() == 'AbstractField <ru>'

# Generated at 2022-06-21 16:58:59.157512
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField(locale='en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 16:59:05.920889
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import schema
    from mimesis.builtins import Person, Address

    class PersonSchema(schema.Field):
        """Schema for testing."""

        def __init__(self, *args, **kwargs):
            """Initialize schema."""
            super().__init__(*args, **kwargs)
            self.person = Person(*args, **kwargs)
            self.address = Address(*args, **kwargs)

        def name(self) -> str:
            """Return full name.

            :return: Full name.
            """
            return self.person.full_name()

        def address(self, **kwargs) -> str:
            """Retur full address with kwargs.

            :return: Full address.
            """
            return self.address.address(**kwargs)

    schema

# Generated at 2022-06-21 16:59:10.362494
# Unit test for method create of class Schema
def test_Schema_create():
    assert all([
        isinstance(Schema.create(lambda: 'mimesis'), list),
        len(Schema.create(lambda: 'mimesis', iterations=3)) == 3,
    ])

# Generated at 2022-06-21 16:59:46.063738
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    result = field('uuid')
    assert isinstance(result, str)



# Generated at 2022-06-21 16:59:55.628945
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('person.full_name')
    assert isinstance(field('person.full_name'), str)

    assert field('person.full_name',
                 capitalization='lower') == 'abigail scheinberg'
    assert field('person.full_name',
                 capitalization='upper') == 'ABIGAIL SCHEINBERG'
    assert field('person.full_name',
                 capitalization='title') == 'Abigail Scheinberg'
    assert field('person.full_name',
                 capitalize=True) == 'Abigail scheinberg'
    assert field('person.full_name',
                 capitalize=False) == 'abigail scheinberg'
    assert field('person.full_name',
                 capitalized=True) == 'Abigail scheinberg'

# Generated at 2022-06-21 16:59:58.657572
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-21 17:00:01.812329
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema

    schema = Schema(lambda: {'name': 'Tom'})
    assert schema.create(iterations=10) == [{'name': 'Tom'}] * 10

# Generated at 2022-06-21 17:00:05.913796
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import Random

    random = Random()
    schema = random.create_schema(3)

    s = Schema(schema)
    assert isinstance(s, Schema)

# Generated at 2022-06-21 17:00:06.872001
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-21 17:00:07.701396
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-21 17:00:11.126208
# Unit test for constructor of class Schema
def test_Schema():
    class SchemaMock:
        """Unit test for constructor of class Schema."""

        @staticmethod
        def schema():
            """Unit test for constructor of class Schema."""
            return {'test': True}
    s = Schema(SchemaMock.schema)
    assert s.create() is not None

# Generated at 2022-06-21 17:00:13.956091
# Unit test for method create of class Schema
def test_Schema_create():
    """Verify that schemas create only valid JSON."""
    import json

    schema = Schema(lambda: {'field': 'value', 'another': 'field'})
    results = schema.create()
    for result in results:
        json.dumps(result)

# Generated at 2022-06-21 17:00:17.350299
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    field = AbstractField('en')
    assert 'AbstractField <en>' == str(field)