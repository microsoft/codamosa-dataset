

# Generated at 2022-06-21 16:58:36.151150
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField('it', 'qwerty')) == 'AbstractField <it>'
    assert str(AbstractField('it', 'qwerty', ['provider'])) == 'AbstractField <it>'  # noqa: E501

# Generated at 2022-06-21 16:58:39.890844
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Method for testing constructor of class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed
    assert callable(field.__call__)
    assert isinstance(field, AbstractField)



# Generated at 2022-06-21 16:58:43.769005
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field(seed=1)
    assert f.__str__() == 'AbstractField <en>', f.__str__()

# Generated at 2022-06-21 16:58:47.604728
# Unit test for method create of class Schema
def test_Schema_create():
    s = Schema(lambda: {'example': 'string'})
    assert isinstance(s.create(), list)
    assert isinstance(s.create(1), list)
    assert s.create(1)[0].get('example') == 'string'
    assert len(s.create(2)) == 2
    assert len(s.create(5)) == 5
    assert len(s.create(10)) == 10

# Generated at 2022-06-21 16:58:50.542972
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    _field = Field()
    assert _field.__str__() == 'AbstractField <en>'
    assert isinstance(_field, AbstractField)



# Generated at 2022-06-21 16:58:53.510242
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__ method for failure."""
    field = Field()
    assert field()



# Generated at 2022-06-21 16:58:59.351155
# Unit test for constructor of class AbstractField
def test_AbstractField():  # noqa: D103
    field = AbstractField()
    assert isinstance(field, AbstractField)
    assert field.locale == 'en'
    assert field.seed is None
    assert field._table == {}
    assert isinstance(field._gen, Generic)


# Generated at 2022-06-21 16:59:01.955939
# Unit test for constructor of class Schema
def test_Schema():
    def my_schema():
        """Empty schema."""
        pass


    schema = Schema(my_schema)

    assert schema.create() == [None]

# Generated at 2022-06-21 16:59:03.737025
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField)



# Generated at 2022-06-21 16:59:12.024999
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field('ru', seed=4)
    assert field.locale == 'ru'
    assert field.seed == 4

    field = Field('en', seed=None)
    assert field.locale == 'en'
    assert field.seed is None

    field = Field('zh', seed=3)
    assert field.locale == 'zh'
    assert field.seed == 3