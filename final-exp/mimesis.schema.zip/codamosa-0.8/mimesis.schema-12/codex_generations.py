

# Generated at 2022-06-12 02:52:50.976062
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test function __call__ of class AbstractField."""
    # Each instance of AbstractField should be a callable object
    # with defined field.
    field = Field()
    assert callable(field)
    assert not callable(field('lang'))

    # Check if field is supported
    assert field('lang') == 'en'

    # Test that method is from first supported data provider
    assert field('first_name', gender='male') == 'David'
    assert field('first_name', gender='female') == 'Jane'

    # Test type of returned data
    assert type(field('uuid4')) is str
    assert type(field('latitude')) is float
    assert type(field('latitude', signed=False)) is int
    assert type(field('latitude', as_string=True)) is str

    # Test key