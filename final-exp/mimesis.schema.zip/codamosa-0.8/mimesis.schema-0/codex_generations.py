

# Generated at 2022-06-12 02:52:04.355615
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.schema import AbstractField
    from mimesis.enums import Gender
    from mimesis.exceptions import UnacceptableField

    gen = AbstractField(providers=[RussiaSpecProvider, ])

    name = gen('full_name')
    assert name

    email = gen('email', key=lambda x: x.split('@')[0])
    assert email

    city = gen('city', region=gen('region', country_code='RU'))
    assert city

    region = gen('region', country_code='RU')
    assert region

    birth_date = gen('birth_date', minimum_age=21, maximum_age=30)
    assert birth_date


# Generated at 2022-06-12 02:52:06.278744
# Unit test for constructor of class AbstractField
def test_AbstractField():
    af = AbstractField()
    assert af.locale == 'en'

# Generated at 2022-06-12 02:52:09.998949
# Unit test for constructor of class AbstractField
def test_AbstractField():
    _ = AbstractField(locale='en', seed='foo')
    _ = AbstractField(locale='en', seed='foo', providers='foo')

# Generated at 2022-06-12 02:52:16.332297
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda: {'name': Field(), 'gender': Field(name='name')})
    filled_schemas = schema.create(iterations=1)
    assert len(filled_schemas) == 1
    assert filled_schemas == [{'name': 'Cook', 'gender': 'Cook'}]



# Generated at 2022-06-12 02:52:22.388856
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    result = field('name.first')
    assert isinstance(result, str)
    assert result == 'Anthony'

# Generated at 2022-06-12 02:52:26.668083
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema
    from mimesis.providers.generic import Generic

    def some_schema(data: Generic) -> dict:
        return {'foo': data.word()}

    schema = Schema(some_schema)
    result = schema.create()

    assert result == [{'foo': result[0]['foo']}]

# Generated at 2022-06-12 02:52:27.559578
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f._gen is not None


# Generated at 2022-06-12 02:52:30.235483
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create for class Schema."""
    schema = Schema(lambda: {
        'foo': 'bar',
    })

    assert schema.create(3) == [
        {'foo': 'bar'}, {'foo': 'bar'}, {'foo': 'bar'}
    ]

# Generated at 2022-06-12 02:52:41.104477
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.address import Address
    from mimesis.providers.identifiers import Identifiers

    a = Address('ru')
    i = Identifiers('ru')

    gen = Generic(seed=17388)
    gen.add_providers(a, i)

    field = AbstractField(locale='ru', providers=(a, i), seed=17388)

    assert field('sha1') == 'f2b463de5b5c5b45dd76b5fc5e5a9ba3a686b8e3'
    assert field('ssn') == '901907030200'
    assert field('region') == 'Ленинградская область'
    assert field('region_code') == '78'
    assert field

# Generated at 2022-06-12 02:52:49.978075
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    locale = 'en'
    seed = 'test_AbstractField___call__'
    gen = Generic(locale, seed=seed)
    x = Field(seed=seed, providers=(gen.datetime, gen.person))

    assert x(name='full_name') == 'Otto H. Pfeiffer'
    assert x('full_name') == 'Otto H. Pfeiffer'
    assert x(name='datetime') == '1993-11-24'
    assert x('datetime') == '1993-11-24'
    assert x('datetime.date') == '1993-11-24'
    assert x('full_name', key=str.capitalize) == 'Otto h. pfeiffer'