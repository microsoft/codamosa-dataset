

# Generated at 2022-06-12 02:52:39.289596
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.builtins import datetime

    field = Field()

    def foo() -> List[int]:
        """Return list of ints."""
        return [field.integer(start=1, end=20) for _ in range(10)]

    schema = Schema(foo)
    result = schema.create(iterations=2)
    assert len(result) == 2
    assert len(result[0]) == 10
    assert result[0] != result[1]

# Generated at 2022-06-12 02:52:43.858100
# Unit test for method create of class Schema
def test_Schema_create():
    def a():
        return {'a': 1, 'b': 2, 'c': 'test'}

    s = Schema(a)
    assert isinstance(s.create(), list)
    assert isinstance(s.create(1)[0], dict)
    assert len(s.create(1)[0]) == 3

# Generated at 2022-06-12 02:52:46.921110
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'Name': Field('ru')(),
            'Address': Field('ru')(),
            'City': Field('ru')()
        }
    assert len(Schema(schema).create(5)) == 5

# Generated at 2022-06-12 02:52:50.801773
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    # class Field
    # is equivalent
    # class Field(object)
    assert issubclass(AbstractField, object)

    field = Field()
    result = field('datetime.datetime')
    assert isinstance(result, str) is True

# Generated at 2022-06-12 02:53:01.176900
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # GIVEN
    gen = Schema(lambda: {
        'name': '',
        'surname': '{personal.name}',
        'email': '{personal.email}',
        'occupation': '{personal.occupation}',
        'gender': '{personal.gender}',
    })
    expected = {
        'name': '',
        'email': 'Nicole_Gibbs@yahoo.com',
        'occupation': 'watercraft operator',
        'gender': 'Male',
    }
    field = Field()

    # WHEN
    schema = gen.create(iterations=1)[0]
    for key in schema:
        if '.' in key:
            schema[key] = field(key)

    # THEN
    for key in expected:
        assert schema.get(key)

# Generated at 2022-06-12 02:53:07.165641
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert str(f('urls.url')) == 'http://www.jfvtoaxe.org/'
    assert str(f('random_seed', seed=42)) == '3.6540712697328444e+18'
    assert str(f('internet.email', key=lambda x: x.split('@')[0])) == 'neha.mendez'

    with pytest.raises(UndefinedField):
        f()

# Generated at 2022-06-12 02:53:12.899304
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema

    def schema():
        from mimesis.schema import Field

        field = Field()
        return {
            "name": field('person.full_name'),
            "job_title": field('occupation.job'),
            "email": field('internet.email'),
            "address": field('address.address')
        }


    schema = Schema(schema)
    assert len(schema.create(iterations=10)) == 10

# Generated at 2022-06-12 02:53:15.385429
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert callable(field.__call__)

    schema = Schema(field)
    assert schema.create(1) != []

# Generated at 2022-06-12 02:53:22.209182
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Test for error if name is not mentioned
    field = AbstractField()
    try:
        field()
    except UndefinedField:
        pass
    else:
        raise RuntimeError()

    # Test for error if field is not supported
    try:
        field('some_field')
    except UnsupportedField:
        pass
    else:
        raise RuntimeError()

    # Test for error if field is not acceptable
    try:
        field('provider.name.some_field')
    except UnacceptableField:
        pass
    else:
        raise RuntimeError()

# Generated at 2022-06-12 02:53:29.103768
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert field.__call__('full_name')

    fullname = field.__call__('full_name', key=lambda x: x.title())
    assert fullname == fullname.title()

    assert field.__call__('data', 'full_name')

    assert field.__call__('data', 'full_name', key=lambda x: x.title())

    assert field.__call__('person.full_name')

    assert not field.__call__('person.undefined_name')