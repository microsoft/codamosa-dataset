

# Generated at 2022-06-12 02:52:28.263219
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert isinstance(field('country'), str)
    assert isinstance(field('region'), str)
    assert isinstance(field('postcode'), str)
    assert isinstance(field('city'), str)
    assert isinstance(field('address'), str)
    assert isinstance(field('street_name'), str)
    assert isinstance(field('building_number'), str)
    assert isinstance(field('latitude'), float)
    assert isinstance(field('longitude'), float)
    assert isinstance(field('language_code'), str)
    assert isinstance(field('internet'), str)
    # test issue #132
    assert isinstance(field('internet', key=lambda x: x[0]), str)
    assert isinstance(field('password'), str)

# Generated at 2022-06-12 02:52:34.047999
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # test_create_instance_of_AbstractField
    assert AbstractField(seed=123)

    # test_create_instance_of_AbstractField
    assert AbstractField(locale='en').locale == 'en'

    # test_create_instance_of_AbstractField
    assert AbstractField(seed=123).seed == 123



# Generated at 2022-06-12 02:52:37.100117
# Unit test for method create of class Schema
def test_Schema_create():
    assert Schema(
        lambda: {
            "number": 1,
            "text": "text"
        }
    ).create() == [
        {
            "number": 1,
            "text": "text"
        }
    ]



# Generated at 2022-06-12 02:52:40.078244
# Unit test for constructor of class AbstractField
def test_AbstractField():
    class Test(AbstractField):
        pass

    obj = Test()
    assert obj.locale == 'en'
    assert obj.seed is None
    assert obj.__class__.__name__ == 'Test'



# Generated at 2022-06-12 02:52:41.384469
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert isinstance(f, AbstractField)

# Generated at 2022-06-12 02:52:42.367258
# Unit test for method create of class Schema
def test_Schema_create():
    # TODO
    pass

# Generated at 2022-06-12 02:52:51.949481
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor."""
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.filesystem import Filesystem

    fs = Filesystem('en', seed=42)
    crypto = Cryptographic('en', seed=42)

    f = AbstractField(locale='en', seed=42, providers=[fs, crypto])
    assert isinstance(f, AbstractField)
    assert len(f._gen.providers) == 3
    assert fs.get_seed() == 42
    assert crypto.get_seed() == 42

    f = AbstractField(locale='en', seed=42)
    assert f.locale == 'en'
    assert f.seed == 42
    assert f._gen.locale == 'en'
    assert f._gen.seed == 42

# Generated at 2022-06-12 02:53:02.184846
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema
    from mimesis.providers.generic import Generic

    gen = Generic('en')

    @gen.schema
    def person() -> dict:
        return {
            'name': gen.person.first_name(),
            'last_name': gen.person.last_name(),
            'age': gen.person.age(min=18, max=50),
            'birth_date': gen.datetime.date(start=1950),
            'profession': gen.person.occupation(),
            'skills': [gen.person.speciality() for _ in range(3)],
        }

    for person in Schema(person).create(iterations=5):
        # Check if all data are correct
        assert person['age'] <= 50 and person['age'] >= 18

# Generated at 2022-06-12 02:53:12.165270
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    # Check default value
    assert (field(name=None, test=None) == None)

    # Raise exception if field name not defined
    try:
        field(name=None)
    except UndefinedField:
        pass
    else:
        raise AssertionError('Should raise UndefinedField')

    # Raise exception if field not supported
    try:
        field(name='example')
    except UnsupportedField:
        pass
    else:
        raise AssertionError('Should raise UnsupportedField')

    # Raise exception if provider not supported
    try:
        field(name='test.example')
    except UnsupportedField:
        pass
    else:
        raise AssertionError('Should raise UnsupportedField')

    # Raise exception if field method not found

# Generated at 2022-06-12 02:53:22.209179
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('Code.isbn')
    assert field('Code.isbn') != field('Code.isbn')
    assert field('Floor.floor')
    assert field('Floor.floor') != field('Floor.floor')
    assert field('Person.full_name')
    assert field('Person.full_name') != field('Person.full_name')
    assert field('Person.full_name', key=lambda x: x.split()[0])
    assert field('Person.full_name', key=lambda x: x.split()[0]) \
        != field('Person.full_name', key=lambda x: x.split()[0])
    assert field('Cryptographic.md5hash')
    assert field('Cryptographic.md5hash') != field('Cryptographic.md5hash')
   