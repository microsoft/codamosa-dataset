

# Generated at 2022-06-12 02:52:22.833566
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    result = field(name='full_name')
    assert result


# Unit tests for methods of class Field

# Generated at 2022-06-12 02:52:23.496130
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField('en')
    assert field.locale == 'en'

# Generated at 2022-06-12 02:52:26.886594
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> JSON:
        return {'test': 'data'}

    s = Schema(schema)

    assert s.create(1) == [{'test': 'data'}]
    assert s.create(2) == [{'test': 'data'}, {'test': 'data'}]



# Generated at 2022-06-12 02:52:36.213460
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.builtins.enums import Gender
    from mimesis.providers.address import Address as Addr

    from mimesis import Field

    field = Field()

    # Providers must be supported
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None

    # Unsupported provider
    field = Field(providers=[1, 2])

    # Empty method name
    field('', key=lambda x: len(x))

    # Undefined field
    field('')

    # Undefined field
    field('address.undefined')

    # Unacceptable field
    field('person.name.get_full_name')

    # Other provider
    assert field('address.__class__') == Addr
    assert field('address.__class__.__name__') == Addr

# Generated at 2022-06-12 02:52:46.921204
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'phone': Field('en').phone_number(),
            'email': Field('en').email(),
            'password': Field('en').password(),
            'ipv4': Field('en').ipv4(),
            'ipv6': Field('en').ipv6(),
        }

    data = Schema(schema).create()

    assert len(data) == 1
    assert isinstance(data[0]['phone'], str)
    assert isinstance(data[0]['email'], str)
    assert isinstance(data[0]['password'], str)
    assert isinstance(data[0]['ipv4'], str)
    assert isinstance(data[0]['ipv6'], str)

# Generated at 2022-06-12 02:52:49.696456
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for Schema.create method."""
    assert len(Schema(None).create(2)) == 2



# Generated at 2022-06-12 02:52:51.023370
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert callable(f)



# Generated at 2022-06-12 02:52:52.530346
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Just for PEP8
    AbstractField()



# Generated at 2022-06-12 02:53:02.760619
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    from mimesis.builtins import RussiaSpecProvider

    f = AbstractField()
    assert f('address.city') is not None
    assert f('address.city', region=True, key=lambda x: x['city']) is not None
    assert f('address.city', region=True,
             key=lambda x: x['city'].replace(' ', '')) is not None
    assert f('address.city', region=True,
             key=lambda x: x['city'].replace(' ', '')).isdigit() is False

    f.add_providers(RussiaSpecProvider)
    assert (f('russia_spec.federal_subject',
              key=lambda x: x['name']) is not None)

# Generated at 2022-06-12 02:53:04.241015
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        AbstractField()
        assert True
    except TypeError:
        assert False
