

# Generated at 2022-06-12 02:52:18.238999
# Unit test for method create of class Schema
def test_Schema_create():
    """Test creating filled schemas."""
    from mimesis.schema import Field

    field = Field()
    schema = {
        'id': field('uuid'),
        'name': field('word'),
        'phone': field('phone_number'),
        'email': field('email'),
        'website': field('url'),
        'social': {
            'github': field('url'),
            'stackoverflow': field('url'),
            'twitter': field('url'),
        },
        'projects': [{
            'name': field('text'),
            'description': field('paragraph'),
            'url': field('url'),
            'language': field('programming_language'),
        }],
    }

    create_schema = Schema(lambda: schema)

    filled_schemas = create_schema.create

# Generated at 2022-06-12 02:52:25.723714
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():  # noqa: D103
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.web import Web
    from mimesis.schema import AbstractField
    from mimesis.typing import JSON

    address = Address('ru')
    person = Person('ru')
    web = Web('ru')
    internet = Internet('ru')
    text = Text('ru')

    gen = AbstractField(locale='ru', providers=[address, person, web,
                                                internet, text])
    # First check working only with one generic
    field = gen('username')
    assert isinstance(field, str)
    assert len(field) > 0

# Generated at 2022-06-12 02:52:34.405028
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField's method __call__.
    """
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person

    class MySchema(Field):
        def __init__(self) -> None:
            super().__init__()

        def get_name(self) -> str:
            return self('person.full_name', last_name_position=False)

        def get_age(self) -> str:
            return self('person.age')

        def get_address(self) -> str:
            return self('address.city')

    s = MySchema()  # type: ignore
    assert isinstance(s, AbstractField)
    assert isinstance(s, Field)

# Generated at 2022-06-12 02:52:40.417616
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert field('datetime.date')
    assert field('datetime.time')
    assert field('datetime.datetime')

    assert field('code.uuid')
    assert field('code.isbn', mask='###-X-#')
    assert field('code.isbn10')

    assert field('finance.iban')
    assert field('finance.credit_card_number')
    assert field('finance.currency_code')

    assert field('internet.email', trailing='yahoo')
    assert field('internet.domain_name', suffix='com')

    assert field('meta.uuid')
    assert field('meta.password')

# Generated at 2022-06-12 02:52:47.986310
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    import string

    def schema():
        return string.ascii_letters

    schema = Schema(schema)
    assert schema.create(3) == ['abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
                                'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
                                'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ']

# Generated at 2022-06-12 02:52:55.100780
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.builtins.en import EnProvider

    en = EnProvider(seed=42)
    schema_field = Field(seed=42, providers=[en])
    assert schema_field('random_int', min=1, max=10) == 3
    assert schema_field('users.random_element_from_json') == 'Eleonore'
    assert schema_field('random_int', min=1, max=10) == 6, \
        'Should be 3 and 6'

# Generated at 2022-06-12 02:52:55.712255
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-12 02:52:57.877369
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    value = field('choice', [1, 2, 3])
    assert value in [1, 2, 3]



# Generated at 2022-06-12 02:53:02.754514
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field

    def schema1(): return dict(a=Field('floor', minimum=1, maximum=2))

    schema = Schema(schema1)
    assert len(schema.create()) == 1
    assert isinstance(schema.create(), list)
    assert len(schema.create(5)) == 5
    assert isinstance(schema.create(5)[0], dict)

# Generated at 2022-06-12 02:53:03.618674
# Unit test for method create of class Schema
def test_Schema_create():
    assert isinstance(Schema.create(Field), list)

# Generated at 2022-06-12 02:54:06.983023
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    # Undefined field
    field('')

    # Undefined field
    field(None)

    # Undefined field
    field('unsupported')

    # Provider is not exist
    field('unsupported.provider')

# Generated at 2022-06-12 02:54:08.396624
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField(locale='en')
    assert isinstance(f._gen, Generic)

# Generated at 2022-06-12 02:54:12.610653
# Unit test for constructor of class AbstractField
def test_AbstractField():
    a = AbstractField()

    assert isinstance(a, AbstractField)
    assert isinstance(a, Callable)
    assert a.locale == 'en'
    assert not a.seed
    assert isinstance(a._gen, Generic)



# Generated at 2022-06-12 02:54:13.892686
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-12 02:54:16.832079
# Unit test for constructor of class AbstractField
def test_AbstractField():
    gen = Generic()
    A = AbstractField(providers=gen)

    assert isinstance(A, AbstractField)

    A(name='name')



# Generated at 2022-06-12 02:54:20.926044
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    field = AbstractField()
    method = field('random_int')
    assert callable(method) and isinstance(method, int)

    with field.seed(619):
        assert field('random_int') == 0



# Generated at 2022-06-12 02:54:27.643694
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Tests for method ``__call__`` in class ``AbstractField``."""
    f = Field()
    assert f('first_name')
    assert f('last_name')  # nosec
    assert f('gender')
    assert f('uuid')  # nosec
    assert f('unsupported')  # nosec
    assert f('password')  # nosec
    assert f('full_name')

    assert not f('person.first_name')
    assert not f('person.last_name')  # nosec
    assert not f('person.gender')
    assert not f('person.uuid')  # nosec



# Generated at 2022-06-12 02:54:35.706091
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f
    assert f.locale == 'en'
    assert isinstance(f._gen, Generic)
    assert isinstance(f._table, dict)
    f = AbstractField(locale='ru', seed=42)
    assert f.locale == 'ru'
    assert f.seed == 42
    f = AbstractField(providers=[Generic])
    assert f
    assert isinstance(f._gen, Generic)



# Generated at 2022-06-12 02:54:41.009853
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.address import Address, AddressProvider

    name = 'address.address'
    key = lambda s: s

    # try:
    #     Field(providers=(Address, AddressProvider))()
    # except UndefinedField:
    #     pass

    try:
        Field(providers=(Address, AddressProvider))(name)
    except UnsupportedField:
        raise

    # try:
    #     Field(providers=(Address, AddressProvider))(name, key=key)
    # except UndefinedField:
    #     pass

    try:
        Field(providers=(Address, AddressProvider))(name, key=key)
    except UnsupportedField:
        raise

    # try:
    #     Field(providers=(Address, AddressProvider))(name, key=key,
    #                                                 length

# Generated at 2022-06-12 02:54:42.567367
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None

# Generated at 2022-06-12 02:55:35.769330
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test __call__ method of class AbstractField."""
    field = AbstractField()

    result = field('choice', ['1', 2, 3, 4, 5])
    assert result in ['1', 2, 3, 4, 5]

    result = field('choice', ['1', 2, 3, 4, 5], key=lambda s: int(s))
    assert result in [1, 2, 3, 4, 5]

    result = field('integer', key=lambda s: int(s) + 2)
    assert isinstance(result, int)

    result = field('user_agent', browser='chrome')
    assert 'chrome' in result.lower()

    result = field('gender')
    assert result in ['male', 'female']

    result = field('gender', data=['man', 'woman'])

# Generated at 2022-06-12 02:55:38.840743
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method AbstractField.__call__."""
    field = Field()
    assert field.__call__('name', 'male')
    assert field.__call__('name', 'male', key=lambda x: x[0]) == 'A'

# Generated at 2022-06-12 02:55:40.717019
# Unit test for constructor of class AbstractField
def test_AbstractField():
    AbstractField('en')
    AbstractField('en', seed=10)
    AbstractField('en', providers=['system', 'science'])



# Generated at 2022-06-12 02:55:48.886760
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__."""
    def test_UndefinedField():
        try:
            field = AbstractField()
            field()
        except UndefinedField:
            return True
        return False

    def test_UnsupporteField():
        try:
            field = AbstractField()
            field('invalid_name')
        except UnsupportedField:
            return True
        return False

    def test_UnacceptableField():
        try:
            field = AbstractField()
            field('provider.invalid_name.invalid_name')
        except (UnacceptableField, UnsupportedField):
            return True
        return False

    def test_Field():
        field = AbstractField()
        field('choice', [1, 2])

    def test_key_function_with_Field():
        field = AbstractField()
       