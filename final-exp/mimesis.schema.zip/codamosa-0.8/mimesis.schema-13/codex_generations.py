

# Generated at 2022-06-12 02:52:41.637524
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for correct work of method __call__.

    - Create instance of AbstractField.
    - Check different values ​​in the call of AbstractField.
    """
    field = AbstractField()

    # Call with invalid provider, so KeyError must be raised
    with raises(KeyError):
        field('invalid-provider')

    # Call with methods with the same names from different providers.
    assert field('email') == field('person.email')
    assert field('text') != field('person.text')

# Generated at 2022-06-12 02:52:46.921099
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField('en')
    assert isinstance(f, AbstractField)

    f = AbstractField('en', seed=42)
    assert isinstance(f, AbstractField)



# Generated at 2022-06-12 02:52:48.497046
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None



# Generated at 2022-06-12 02:52:50.978025
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert hasattr(f, '_gen') is True
    assert hasattr(f, '_table') is True

# Generated at 2022-06-12 02:52:55.402127
# Unit test for constructor of class AbstractField
def test_AbstractField():
    data = [
        'Method',
        'Field',
    ]
    field = AbstractField()
    generated_data = [field(data[0]), field(data[1])]

    assert all(isinstance(g, str) for g in generated_data)

# Generated at 2022-06-12 02:52:58.254646
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField(seed=1337)
    assert field is not None
    assert callable(field)
    assert len(field._table) == 0


# Generated at 2022-06-12 02:53:04.126892
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()

    f.create = lambda: 'test'
    f.create2 = lambda: 'test2'

    assert f('create') != f('create')

    assert f('create') != f('create', upper=True)
    assert f('create', upper=True) != f('create')

    assert f('create2') == f('create2')
    assert f('create2') == f('create2', upper=True)
    assert f('create2', upper=True) == f('create2')

# Generated at 2022-06-12 02:53:09.470606
# Unit test for method create of class Schema
def test_Schema_create():
    """Check creating a list of willed schemas.

    :return: Testing result.
    """
    _schema = {
        'name': 't1',
        'value': 1,
    }
    s = Schema(_schema)
    assert s.create(iterations=2) == [_schema, _schema]