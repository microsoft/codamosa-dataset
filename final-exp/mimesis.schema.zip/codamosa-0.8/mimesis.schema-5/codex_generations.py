

# Generated at 2022-06-12 02:52:04.526317
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    """ Unit test for method __call__ of class AbstractField.
    """

    field = AbstractField()

    # Test for UnsupportedField
    with pytest.raises(UnsupportedField):
        field('__unsupported_field__')

    # Test for UnacceptableField
    with pytest.raises(UnacceptableField):
        field('unsupported_provider.unsupported_method')

    # Test for UndefinedField
    with pytest.raises(UndefinedField):
        field()

    # Test for default call
    assert field('boolean', upper=True) is True
    assert field('gender') in ('Male', 'Female')
    assert field('full_name')

    # Test for call with key function
    assert field('full_name', key=lambda x: ' '.join(x))

    # Test for call with __.

# Generated at 2022-06-12 02:52:13.500336
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.person import Person

    class TestSchema(Person):

        def schema(self):
            return {
                'name': self.name(),
                'surname': self.surname(),
                'full_name': self.full_name(),
                'username': self.username(),
                'password': self.password()
            }

    s = Schema(TestSchema().schema)
    print(s.create(5))



# Generated at 2022-06-12 02:52:20.910006
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    person = AbstractField()
    assert person('full_name') is not None, 'Failed on calling full name'
    assert ' ' in person('full_name'), 'Failed on calling full name'

    assert person('token_hex') is not None, 'Failed on calling token hex'
    assert len(person('token_hex')) == 16, 'Failed on calling token hex'

    assert person('token_hex', nbytes=24) is not None, \
        'Failed on calling token hex'
    assert len(person('token_hex', nbytes=24)) == 32, \
        'Failed on calling token hex'

    assert person('country', key=lambda x: x.lower()) == \
        person('country', key=lambda x: x.lower()), \
        'Failed on calling country'

    assert isinstance

# Generated at 2022-06-12 02:52:28.308926
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of the class Schema."""
    from mimesis.enums import Gender

    def schema() -> JSON:
        """Schema."""
        return {
            'name': Field().person.full_name(),
            'age': Field().datetime.age(),
            'gender': Field().random.choice(list(Gender)),
            'address': {
                'country': Field().address.country(),
                'city': Field().address.city(),
                'street': Field().address.street_name(),
                'postcode': Field().address.postcode(),
            }
        }

    s = Schema(schema)
    assert isinstance(s.create(1), list)
    assert isinstance(s.create(3)[0], dict)

# Generated at 2022-06-12 02:52:38.589982
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert field() is None
    assert field('random_int') >= 0
    assert isinstance(field('timestamp'), int)
    assert field('random_int', minimum=10) == 10
    assert field('truncate', 'Hello test!', 10) == 'Hello test!'
    assert field('truncate', 'Привет, мир!', 10) == 'Привет, мир!'
    assert callable(field('choice', [0, 1]))
    assert field('choice', [0, 1]) in [0, 1]
    assert field('choice', [0, 1], key=len) == 1
    assert field('choice', [0, 1], key=len) == 1

    # Test explicit call of method


# Generated at 2022-06-12 02:52:46.921326
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None
    assert field.locale == 'en'
    assert field.seed is None
    field = AbstractField(locale='ru')
    assert field is not None
    assert field.locale == 'ru'
    assert field.seed is None
    field = AbstractField(seed=42)
    assert field is not None
    assert field.locale == 'en'
    assert field.seed == 42
    field = AbstractField(locale='ru', seed=42)
    assert field is not None
    assert field.locale == 'ru'
    assert field.seed == 42

# Generated at 2022-06-12 02:52:50.430320
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method call of class AbstractField."""
    field = AbstractField()
    field('sum', 8, 10)

    field = AbstractField(seed=123)
    field('random_int', 0, 100)

# Generated at 2022-06-12 02:52:52.282061
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Field() -> new object of class AbstractField."""
    field = Field()
    assert field._gen.choice is not None

# Generated at 2022-06-12 02:52:59.202612
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import Field

    schema = Field()
    sch = Schema(lambda: {
        'name': schema('full_name'),
        'email': schema('email'),
        'age': schema('between', start=18, end=35),
    })

    items = sch.create(iterations=5)
    assert isinstance(items, list)
    assert all(isinstance(item, dict) for item in items)

# Generated at 2022-06-12 02:53:06.274228
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method ``__call__`` of the class AbstractField."""
    f = AbstractField()
    assert isinstance(f.locale, str)
    assert isinstance(f.seed, int)
    assert isinstance(f._table, dict)

    for i in range(1, 10):
        assert f('integer', **{'minimum': 0, 'maximum': 100}) in range(0, 100)

    assert f('not_existing_method') is None

    assert callable(f('choice', key=str))

    assert isinstance(f('__str__'), str)

# Generated at 2022-06-12 02:53:27.059081
# Unit test for constructor of class AbstractField

# Generated at 2022-06-12 02:53:37.999011
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # :rtype: AbstractField
    field = Field()

    # :rtype: object
    p = field.generic.provider

    assert p == field.generic.provider  # type: ignore
    assert p != field.datetime.provider  # type: ignore

    assert callable(field('datetime'))
    assert isinstance(field('datetime'), type)

    assert callable(field('datetime.time'))
    assert callable(field('time', format='%H-%M'))

    assert callable(field('dynamic.value'))
    assert callable(field('dynamic_value'))

    assert isinstance(field('datetime.date'), type)
    assert isinstance(field('datetime.datetime'), type)
    assert isinstance(field('datetime.time'), type)
   

# Generated at 2022-06-12 02:53:44.074232
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.internet import Internet
    from mimesis.providers.geo import Geo

    providers = (Geo, Internet)
    field = Field(locale='ru', providers=providers)
    result = field('email')
    assert result is not None

    result = field('city', key=lambda x: x.title())
    assert result is not None


# Generated at 2022-06-12 02:53:46.469028
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('address.house_number')

    field = AbstractField()
    assert field('choice')

    field = AbstractField()
    assert field('address.choice')

# Generated at 2022-06-12 02:53:49.311007
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    from mimesis.providers.aviation import Aviation

    field = AbstractField(providers=[Aviation])
    assert field('aircraft_manufacturer') is not None

# Generated at 2022-06-12 02:53:50.046644
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert callable(field)

# Generated at 2022-06-12 02:54:00.218255
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None

    field = Field(locale='ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42

    assert callable(field)
    assert field('currency.code') in field._gen.currency.codes
    assert field('credit_card_number') in field._gen.credit_card.numbers
    assert field('credit_card_number', key=len) == 16
    assert field('credit_card_number', key=str) == '4929800273084502'
    assert field('credit_card_number', card_type='American Express') == '345678901234564'  # noqa

# Generated at 2022-06-12 02:54:04.209387
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test __call__ method."""
    f = Field(locale='en')

    result = f(name='first_name')
    assert isinstance(result, str)

    result = f(name='first_name', gender='male')
    assert isinstance(result, str)

    result = f(name='name')
    assert isinstance(result, str)

    assert f(name='undefined provider')

# Generated at 2022-06-12 02:54:13.641382
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema
    from mimesis.schemas import Address, Person

    schema = Schema(Person)
    person_json = schema.create(iterations=10)

# Generated at 2022-06-12 02:54:16.134460
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None



# Generated at 2022-06-12 02:54:34.960941
# Unit test for method create of class Schema
def test_Schema_create():
    """Test create method."""
    def test_schema() -> dict:
        """Test schema."""
        return {'number': 1}

    assert len(Schema(test_schema).create()) == 1
    assert len(Schema(test_schema).create(iterations=10)) == 10



# Generated at 2022-06-12 02:54:40.973558
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person

    field = AbstractField(providers=(Person, Address, Internet))

    assert field('full_name') is not None
    assert field('name_first') is not None
    assert field('street_name') is not None
    assert field('hostname') is not None

    assert field('person.full_name') is not None
    assert field('address.street_name') is not None
    assert field('internet.hostname') is not None
    assert field('person.name_first') is not None

    assert callable(lambda: field('random_int', min=1, max=10))
    assert callable(lambda: field('address.postcode'))
    assert callable

# Generated at 2022-06-12 02:54:41.679449
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('something')

# Generated at 2022-06-12 02:54:44.919364
# Unit test for method create of class Schema
def test_Schema_create():
    """Test if create method of Schema class returns right data."""
    s = Schema(
        lambda: {
            'a': lambda: 1,
            'b': lambda: 2
        }
    )
    data = s.create(10)
    for item in data:
        assert item.get('a') == 1
        assert item.get('b') == 2

# Generated at 2022-06-12 02:54:48.397127
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field(name='text', val='lorem') == 'lorem'

# Generated at 2022-06-12 02:54:56.113283
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    persons = Person('en')
    addresses = Address('en')

    field = AbstractField(locale='en', providers=(persons, addresses))
    assert field('full_name')
    assert field('email')
    assert field('country')
    assert field('address')
    assert field('person.full_name')
    assert field('address.country')
    assert field('address.region')
    assert field('address.city')
    assert field('address.address')

# Generated at 2022-06-12 02:54:58.978087
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of base class AbstractField."""
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-12 02:55:03.159872
# Unit test for method create of class Schema
def test_Schema_create():
    """Testing method :meth:`~mimesis.schema.Schema.create`."""
    schema = {
        'foo': lambda: 'bar',
    }

    assert Schema(schema).create() == [{'foo': 'bar'}]

    sch = Schema(lambda: 'some text')
    assert sch.create() == ['some text']
    assert sch.create(5) == ['some text'] * 5



# Generated at 2022-06-12 02:55:11.972750
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.builtins import Generic

    def test_schema(gen: Generic) -> JSON:
        """Return standard schema."""
        return {
            'name': gen.person.full_name(),
            'age': gen.code.age(),
            'job': gen.person.occupation(),
        }

    created = Schema(test_schema).create(2)
    assert len(created) == 2

    for _ in created:
        assert 'name' in _
        assert 'age' in _
        assert 'job' in _



# Generated at 2022-06-12 02:55:16.745466
# Unit test for method create of class Schema
def test_Schema_create():
    # test if schema has method __call__
    class Schema:
        def __call__(self):
            return {}

    s = Schema()

    assert Schema().create(2)[0] == s.create(2)[0]



# Generated at 2022-06-12 02:55:44.329618
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(AbstractField('ru', seed=123), AbstractField)

# Generated at 2022-06-12 02:55:46.163271
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field is not None
    assert field._table is not None
    assert field._gen is not None
    assert field.locale == 'en'
    assert field.seed is None



# Generated at 2022-06-12 02:55:48.570231
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.network import Network

    field = AbstractField()

    provider = field._gen.choice
    method = field.__call__('Meta.name')
    assert method == provider.Meta.name



# Generated at 2022-06-12 02:55:57.391705
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    def key_fun(s: str) -> str:
        """Return a string in lower case."""
        return s.lower()

    field = Field()
    assert field('other.title') == 'Mr.'
    assert field('metadata.other') == {
        'title': 'Mr.',
        'name': 'Miss Jadyn',
        'surname': 'Kertzmann',
        'phone_number': '+38097-734-06-83',
    }
    assert field('metadata.other', key=key_fun) == {
        'title': 'mr.',
        'name': 'miss jadyn',
        'surname': 'kertzmann',
        'phone_number': '+38097-734-06-83',
    }

# Generated at 2022-06-12 02:55:59.298661
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'example': Field('name')
        }

    s = Schema(schema)
    assert s.create() == [{'example': 'Daniel'}]

# Generated at 2022-06-12 02:56:07.601464
# Unit test for constructor of class AbstractField
def test_AbstractField():
    class DummyObject:
        _locale = 'en'
        _seed = '01'

    dummy_instance = DummyObject()
    dummy_field = AbstractField(locale=dummy_instance._locale,
                                seed=dummy_instance._seed)
    assert dummy_field.locale == dummy_instance._locale
    assert dummy_field.seed == dummy_instance._seed



# Generated at 2022-06-12 02:56:12.743817
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__ case.

    Test method by any combination of the name of method and the
    combination of their arguments. Basically, we do not need to test
    this method because it only delegates calls to the appropriate
    method of data provider.
    """
    f = Field('en')

    assert f('person.full_name') == 'Adrian A. Leonard'
    assert f('person.full_name', gender='Male') == 'Guillermo M. Cousins'
    assert f('person.username') == 'wilson_sherman'

    assert f('datetime.date') == '1981-04-15'
    assert f('datetime.date', pattern='%d/%m/%Y') == '07/05/2012'

    assert f('datetime.time') == '08:59:16'


# Generated at 2022-06-12 02:56:17.976355
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='en')
    assert field.locale == 'en'
    assert field.seed is None

    field = AbstractField(seed=1234)
    assert field.locale == 'en'
    assert field.seed == 1234



# Generated at 2022-06-12 02:56:19.476629
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Implementation of assertion for method __call__ in class AbstractField.
    """
    field = Field()
    assert field("username", key=lambda x: x.lower())

# Generated at 2022-06-12 02:56:24.294164
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda: {
        'name': 'Foo',
        'age': 'Bar',
    })

    assert schema.create() == [{'name': 'Foo', 'age': 'Bar'}]
    assert len(schema.create(10)) == 10

# Generated at 2022-06-12 02:57:04.119594
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field
    assert field.locale == 'en'
    assert field.seed is None

# Generated at 2022-06-12 02:57:06.270064
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    instance = AbstractField()
    data = instance("person.full_name", key=lambda x: x.title())
    assert isinstance(data, str)

# Generated at 2022-06-12 02:57:07.335607
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # This class is an abstract class and you need to create instance
    # of the Field class to test the function of this class.
    assert AbstractField is Field

# Generated at 2022-06-12 02:57:08.826201
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField)

# Generated at 2022-06-12 02:57:09.286186
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-12 02:57:15.019412
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    import json

    key = lambda x: json.dumps(x)
    f = AbstractField()
    # case - 1
    result = f('address.address')
    assert isinstance(result, str)
    # case - 2
    result = f('address.address', 'KZ')
    assert isinstance(result, str)
    # case - 3
    result = f('address.address', key=key)
    assert isinstance(result, str)
    # case - 4
    result = f('address.address', key=key, country_code='KZ')
    assert isinstance(result, str)



# Generated at 2022-06-12 02:57:17.760407
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    obj = Field()
    assert isinstance(obj, AbstractField)

    obj2 = Field(seed=123)
    assert isinstance(obj2, AbstractField)
    assert obj2.seed == 123



# Generated at 2022-06-12 02:57:19.494692
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field
    assert isinstance(field, AbstractField)



# Generated at 2022-06-12 02:57:25.399781
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()

    assert f('name') == 'Aaron'
    assert f('person') == 'Aaron,35,white'
    assert f('person', height=190) == 'Aaron,35,white,190'

# Generated at 2022-06-12 02:57:26.197068
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-12 02:58:23.152140
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField."""
    field = AbstractField()

    assert field('full_name') is not None
    assert field('username') is not None

# Generated at 2022-06-12 02:58:25.071052
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    af = AbstractField(locale='en')
    value = af('choice', ['a', 'b', 'c'])
    assert value in ['a', 'b', 'c']



# Generated at 2022-06-12 02:58:30.529604
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert isinstance(field, AbstractField)

    assert field('telephone', key=str.isdigit)
    assert field('random_id')
    assert field('uuid4')
    assert field('random_lorem')
    assert field('random_alphanumeric')

    assert field('person.full_name')
    assert field('person.age')
    assert field('person.sex')
    assert field('person.username')
    assert field('person.first_name')
    assert field('person.last_name')
    assert field('person.patronymic')
    assert field('person.initials')
    assert field('person.full_name')

    assert field('address.city')
    assert field('address.street')
   

# Generated at 2022-06-12 02:58:35.125952
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('age') > 0
    assert f('age', key=int) > 0
    assert f('full_name', gender='M') is not None
    assert f('full_name', 'gender', 'm', key=str) is not None
    assert f('random_element', [1, 2, 3]) in [1, 2, 3]

# Generated at 2022-06-12 02:58:37.975712
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field.__call__('person.name') == field._gen.person.name()
    assert field.__call__('person.surname') == field._gen.person.surname()
    assert field.__call__('person.patronymic') == field._gen.person.patronymic()

# Generated at 2022-06-12 02:58:39.306309
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test ``__call__`` method of AbstractField."""
    field = Field(locale='en')
    assert field('person.name') == 'Steven'

# Generated at 2022-06-12 02:58:44.666628
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method AbstractField.__call__."""
    field = AbstractField()

    provider = 'datetime'
    method = 'timestamp'
    name = '{}.{}'.format(provider, method)
    assert field(name) == field._gen.datetime.timestamp()

    provider = 'datetime'
    method = 'date'
    name = '{}.{}'.format(provider, method)
    assert field(name) == field._gen.datetime.date()

# Generated at 2022-06-12 02:58:47.300258
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('full_disp_name') is not None
    assert field('full_disp_name', key=lambda x: len(x) > 1) is True
    assert field('full_disp_name') != field('full_disp_name')

# Generated at 2022-06-12 02:58:48.755729
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Fix https://github.com/lk-geimfari/mimesis/issues/619
    field = Field(seed=123)
    assert field('choice') == 'choice'

# Generated at 2022-06-12 02:58:51.921760
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    expected_value = 1

    f = Field(seed=42)
    result = f('code', to=expected_value)

    assert result == expected_value