

# Generated at 2022-06-12 02:52:18.708670
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # class Foo:
    #    bar = 12

    s = AbstractField()
    # assert s('bar', Foo) == 12
    # assert s('bar', key=str, Foo=Foo) == '12'
    assert s('name').__class__.__name__ == 'str'



# Generated at 2022-06-12 02:52:25.721192
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    name_method = field._gen.choice.Meta.name

    # Execute method
    assert type(field(name_method)) == str

    # Try to get data from non existed provider
    try:
        field('non.existed.provider')
    except ValueError as err:
        assert err.args[0] == 'Provider (non) not supported'
    else:
        raise AssertionError('Should be ValueError')

    # Try to get data from non existed method of existed provider
    try:
        field('person.non_existed_method')
    except ValueError as err:
        assert err.args[0] == 'Field (person.non_existed_method) is not defined'
    else:
        raise AssertionError('Should be ValueError')

    # Try to get data

# Generated at 2022-06-12 02:52:34.417388
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    from mimesis.tools import test_data
    from mimesis.schema import AbstractField
    from mimesis.providers.clinic import Clinic

    field = AbstractField(seed=1337)
    provider = Clinic('en', 1337)

    assert field is not None
    assert field.locale == 'en'
    assert field.seed == 1337
    assert field._gen.seed == 1337

    assert field.choice is not None
    assert field.choice == field._gen.choice

    assert field.clinic is not None
    assert field.clinic == field._gen.clinic

    assert field.clinic.random_drug is not None
    assert field.clinic.random_drug() == provider.random_drug()

    assert field.clinic.random_

# Generated at 2022-06-12 02:52:35.161714
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract = AbstractField()
    assert abstract('uuid')



# Generated at 2022-06-12 02:52:46.921200
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    result = field('email')
    assert '@' in result
    assert isinstance(result, str)

    field = AbstractField('es')
    result = field('email')
    assert '@' in result
    assert isinstance(result, str)
    assert result.lower() == result

    field = AbstractField('ru')
    result = field('email')
    assert '@' in result
    assert isinstance(result, str)

    def key(value): return value.upper()

    result = field('email', key=key)
    assert '@' in result
    assert isinstance(result, str)
    assert result == result.upper()

    class A:
        @staticmethod
        def foo():
            return 'FOO'

    field = AbstractField('en', providers=(A,))


# Generated at 2022-06-12 02:52:51.145680
# Unit test for constructor of class AbstractField
def test_AbstractField():
    args = ('en', None)
    attrs = ('locale', 'seed')
    field = AbstractField(*args)
    assert all([getattr(field, attr) == attr_value for
                attr, attr_value in zip(attrs, args)])

# Generated at 2022-06-12 02:53:01.591694
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = AbstractField()

    assert isinstance(field.__call__('uuid'), str)  # string
    assert isinstance(field.__call__('money'), float)  # float
    assert isinstance(field.__call__('email'), str)  # string
    assert isinstance(field.__call__('password'), str)  # string
    assert isinstance(field.__call__('full_name'), str)  # string
    assert isinstance(field.__call__('first_name'), str)  # string
    assert isinstance(field.__call__('full_name', with_middle_name=True), str)
    assert isinstance(field.__call__('full_name_female'), str)  # string

# Generated at 2022-06-12 02:53:03.855689
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField."""
    field = Field()
    result = field('name')

    # Assert that result is a string
    assert isinstance(result, str)

# Generated at 2022-06-12 02:53:06.719205
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = Field()
    data = field('username')
    assert data
    assert isinstance(data, str)

# Generated at 2022-06-12 02:53:07.248049
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-12 02:53:55.389136
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    _test_names = {
        'name': 'foo',
        'name.name': 'foo.foo',
        'private_name': '__private_name',
        'name.private_name': 'foo.__private_name',
    }
    _test_kwargs = {
        'key': str,
        'exact_value': 'str',
        'exact_values': ('str',),
        'between': (10, 100),
        'min_value': 50,
        'max_value': 100,
        'quantity': 5,
        'length': 5,
        'ext': 'txt',
    }


# Generated at 2022-06-12 02:54:03.787185
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField(locale='en')
    result = field('username')
    assert result is not None
    assert isinstance(result, str)

    result = field('person.full_name')
    assert result is not None
    assert isinstance(result, str)

    result = field(name='person.full_name', key=lambda x: x.split(' '))
    assert isinstance(result, list)

    assert field(name="person.full_name", key=len) is not None

    result = field(name='person.full_name', key=lambda x: x[0])
    assert isinstance(result, str)

    result = field(name='person.full_name', key=lambda x: x[0].upper())
    assert isinstance(result, str)


# Generated at 2022-06-12 02:54:05.051018
# Unit test for constructor of class AbstractField
def test_AbstractField():
    foo = Field(locale='ru')
    assert foo.locale == 'ru'


# Generated at 2022-06-12 02:54:06.115287
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField)

# Generated at 2022-06-12 02:54:08.900828
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    result = field('credit_card.provider')
    assert result in ('Visa', 'Mastercard', 'American Express', 'Discover')

    field = AbstractField(providers=[])
    assert field('credit_card.provider') == ''

# Generated at 2022-06-12 02:54:12.570175
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(seed=1337)
    assert field.locale == 'en'
    assert field.seed == 1337
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-12 02:54:14.117673
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field.__call__('integer', minimum=0, maximum=10) in range(11)

# Generated at 2022-06-12 02:54:16.750575
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test class AbstractField."""
    field = AbstractField()
    assert field._gen
    assert isinstance(field._table, dict)

# Generated at 2022-06-12 02:54:18.642283
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('full_name')



# Generated at 2022-06-12 02:54:19.639698
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert f

# Generated at 2022-06-12 02:54:53.070374
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    assert field('custom_code', 4, length=4) == '8205'

# Generated at 2022-06-12 02:55:02.821154
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.finance import Finance
    from mimesis.providers.internet import Internet

    assert (
        Field(locale='ru',
              providers=[Datetime(seed=4), Finance(seed=4), Internet(seed=4)])
        ('datetime.timestamp_till',
         data=Datetime().datetime(), seed=4, key=lambda x: int(x))
    ) == 1521107200

    assert (
        Field(locale='ru',
              providers=[Datetime(seed=4), Finance(seed=4), Internet(seed=4)])
        ('some_field')
    ) == 'some_field'

# Generated at 2022-06-12 02:55:09.394015
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()("data_provider1.method_name",
                key=lambda x: x.upper(),
                param="param")
    print(f)
    assert f == "NORMAL"
    f = Field()("choice", [1, 2, 3])
    print(f)
    assert f in [1, 2, 3]

# Generated at 2022-06-12 02:55:18.779183
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    with pytest.raises(UndefinedField) as e:
        field()

    with pytest.raises(UnacceptableField) as e:
        field('method.method.method')

    with pytest.raises(UnsupportedField) as e:
        field('foo.bar')

    assert field('seed') == 13

    assert field('seed', key=lambda x: x**2) == 13**2

    with pytest.raises(TypeError) as e:
        field('choice', items=['bar'], default='foo')

    assert field('choice', items=['bar'], default='foo', key=str.upper) == 'BAR'


# Generated at 2022-06-12 02:55:25.143697
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.

    Unit test for method __call__ of class AbstractField.
    """
    f = Field(locale='ru')
    result = f('integer', minimum=0, maximum=10)

    assert isinstance(result, int)
    assert result < 10

# Generated at 2022-06-12 02:55:33.347746
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Tests if method __call__ raises UndefinedField when its called with
    # name=None
    field = Field()
    try:
        field(name=None)
    except UndefinedField:
        pass
    else:
        raise AssertionError(
            'Method __call__ does not raise UndefinedField when'
            ' its called with name=None')

    # Tests if method __call__ raises UnsupportedField when its called with
    # name=fake_name
    field = Field()
    try:
        field(name='fake_name')
    except UnsupportedField:
        pass
    else:
        raise AssertionError(
            'Method __call__ does not raise UnsupportedField when'
            ' its called with name=fake_name')

    # Tests if method __call__ raises UnacceptableField when its called with


# Generated at 2022-06-12 02:55:39.889723
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """It will run unit test for method __call__."""
    field = AbstractField()
    res = field('text.word')
    assert isinstance(res, str)



# Generated at 2022-06-12 02:55:46.443768
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    class Schema:
        def __init__(self, field):
            self.field = field

        def __call__(self):
            name = self.field.generic.choice(
                ['person', 'lorem', 'address'])
            first_name = self.field(name + '.first_name')
            last_name = self.field(name + '.last_name')
            return {'name': first_name + ' ' + last_name}

    f = Field()

    s = Schema(f)

    for _ in range(10):
        print(s())

# Generated at 2022-06-12 02:55:55.640786
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    for i in range(10):
        assert field('IPv4') in ['192.168.0.1', '10.0.0.1']
        assert field('IPv6') in ['fe80::99c9:3a3a:508c:6126',
                                 'fe80::3bb6:57c6:d8bf:9dd6']
        assert field('UUID') in ['6d89a6a7-2368-4514-b8c5-5f465f5be5e5',
                                 '9d292c11-e07e-42d8-8a3d-1c6cd3b6f1fa']

# Generated at 2022-06-12 02:56:01.002095
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    locale = 'en'
    seed = 42
    provider = 'food'
    name = 'item'

    generic = Generic(locale=locale, seed=seed)
    food = getattr(generic, provider)
    assert generic
    assert food

    kwargs = {'max_length': 10, 'categories': ['dessert']}

    food_item = getattr(food, name)
    assert callable(food_item)
    assert food_item(**kwargs) == 'chicken'

    field = AbstractField(locale=locale, seed=seed)
    assert field(name) == 'chicken'
    assert field(name=name) == 'chicken'
    assert field(name=name, **kwargs) == 'chicken'
    assert field(name='food.item') == 'chicken'

# Generated at 2022-06-12 02:57:02.302966
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Verify that AbstractField is working correctly."""
    gen = Generic('kk')
    field = Field(locale='kk', providers=[gen])
    assert field('choice', a=[1, 2, 3]) in [1, 2, 3]
    assert field('choice', a=(1, 2, 3)) in [1, 2, 3]
    assert field('choice', a={1, 2, 3}) in [1, 2, 3]

# Generated at 2022-06-12 02:57:11.829799
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    def key(value: str) -> str:
        return value.upper()


    field = Field()
    assert field.locale == 'en'

    # Call with kwargs
    result = field('relaxed_word')
    assert result is not None

    # Call with key
    result = field('relaxed_word', key=key)
    assert result is not None

    # Method from provider using '.'
    result = field('datetime.timestamp')
    assert result is not None

    # With kwargs and key
    result = field('datetime.timestamp', key=key)
    assert result is not None

    # Expected error

# Generated at 2022-06-12 02:57:18.084928
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert str(Field(locale='ru')) == 'AbstractField <ru>'

    obj = Field(locale='ru')
    assert obj.__call__(name='word') != obj.__call__(name='word')
    assert obj.__call__(name='word', key=lambda x: x[0]) == obj.__call__(name='word')[0]

# Generated at 2022-06-12 02:57:21.840961
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = AbstractField()
    result = field('uuid')
    assert isinstance(result, str)
    result = field('age.with_range', min_age=18, max_age=75)
    assert isinstance(result, int)
    result = field('address.building_number')
    assert isinstance(result, str)

# Generated at 2022-06-12 02:57:31.232707
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Schema.Field()
    assert type(field('hash')) == str
    assert type(field('hash', key=lambda x: x[0])) == str
    assert type(field('code')) == str
    assert type(field('code', key=str.upper)) == str
    assert type(field(
        'person_name',
        gender=schema.Gender('female'))) == str
    assert type(field('person_name', gender='female')) == str
    assert type(field(
        'person_name.full_name',
        gender=schema.Gender('female'))) == str
    assert type(field('person_name.full_name', gender='female')) == str

# Generated at 2022-06-12 02:57:34.142311
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method.

    Test method AbstractField.__call__()
    """
    pass

# Generated at 2022-06-12 02:57:39.649363
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.person import Person

    cryp = Cryptographic()
    per = Person()

    field = AbstractField(providers=[cryp, per])

    # This will return method from provider Person
    assert field('full_name') == per.full_name()

    # This will return method from provider Cryptographic
    assert field('token') == cryp.token()

    # This will return method from provider Person
    assert field('person.full_name') == per.full_name()

    # This will return method from provider Cryptographic
    assert field('cryp.token') == cryp.token()

# Generated at 2022-06-12 02:57:40.799834
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    data = field('codename')
    assert data != ''



# Generated at 2022-06-12 02:57:43.336443
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field(locale='ru')
    assert f('name') != f('name')

    f = Field('ru', seed=12345)
    assert f('name') == f('name')

# Generated at 2022-06-12 02:57:51.958730
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('email')
    assert callable(f('email', key=str.upper))
    assert f('email', key=str.upper)
    assert f('email', domain='gmail.com')
    assert f('address.country')
    assert f('address.country', key=str.upper)
    assert f('address.country', key=str.upper)
    assert f('address.country', key=str.upper, form='one_word')
    assert f('address.country', form='one_word')
    assert f('address.country', form='one_word', key=str.upper)
    assert f('address.country', key=str.upper, form='one_word')

# Generated at 2022-06-12 02:59:27.865793
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    # Field doesn't exist in any provider.
    assert field('get.some') is None
    # Provider doesn't support such method.
    assert field('get.some.value') is None



# Generated at 2022-06-12 02:59:33.367906
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    a = AbstractField()
    assert a('datetime') == a.datetime()

    # Fix https://github.com/lk-geimfari/mimesis/issues/619
    b = AbstractField()
    assert b('choice') == b.choice()

# Generated at 2022-06-12 02:59:42.412824
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('person.full_name') != ''
    assert f('name', category='last') != ''

    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    data_providers = [Person, Address]

    field = Field(providers=data_providers)
    assert field('person.full_name') != ''
    assert field('name', category='last') != ''
    assert field('address.country', key=str.upper) != ''

    try:
        assert field('blabla') != ''
    except UnsupportedField as err:
        assert err.name == 'blabla'
        assert isinstance(err.message, str)


# Generated at 2022-06-12 02:59:46.029627
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    # noinspection PyTypeChecker
    field = AbstractField()
    assert '0x9cabaf' == field(
        'hex_color',
        key_func=lambda x: x.replace('#', '0x'),
    )



# Generated at 2022-06-12 02:59:49.011452
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    class Field(AbstractField):
        pass

    field = Field()
    assert field('String.ascii_letters')
    assert field('String.ascii_letters', key=lambda x: x[0]) == 'a'
    assert field('String.ascii_letters', key=lambda x: x[-1]) == 'z'



# Generated at 2022-06-12 02:59:52.843497
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Tests for calling AbstractField."""
    field = AbstractField()
    assert field(
        'username',
        pattern='???') == 'a_b'

# Generated at 2022-06-12 02:59:57.577393
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    data = (
        ('identifier', False),
        ('random_boolean', True),
        ('random_int', 42),
        ('random_digit', 0),
        ('random_special_digit', 'x'),
    )
    field = Field()

    for datum in data:
        result = field(datum[0])

        if isinstance(datum[1], bool):
            assert isinstance(result, bool)
        elif isinstance(datum[1], int):
            assert isinstance(result, int)
        elif isinstance(datum[1], str):
            assert isinstance(result, str)
        else:
            assert isinstance(result, type(datum[1]))

# Generated at 2022-06-12 03:00:01.031605
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for class AbstractField."""
    pass

# Generated at 2022-06-12 03:00:08.222883
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Check that __call__ method works fine."""
    af = AbstractField(seed=42)
    assert af('name') == 'Edwin N.'
    assert af('name') == 'Edwin N.'
    assert af('name', male=False) == 'Frances '
    assert af('name', key=lambda x: x, male=False) == 'Frances '
    assert af('address.city') == 'Patsybury'
    assert af('address.city') == 'Patsybury'
    assert af('address.city', key=lambda x: x.lower()) == 'patsybury'
    assert af('address.city', key=lambda x: x.upper()) == 'PATSYBURY'
    assert af('address.city') == 'Patsybury'

# Generated at 2022-06-12 03:00:17.526702
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Тестируем вызов метода с поддержкой провайдера
    provider = Generic()
    field = AbstractField(providers=[provider])
    assert field('choice', ls=['a']) == 'a'

    assert 'choice' in field._table.keys()

    # Тестируем вызов провайдера по *полному имени*
    assert field('datetime.timestamp')

    # Тестируем вызов несуществующ