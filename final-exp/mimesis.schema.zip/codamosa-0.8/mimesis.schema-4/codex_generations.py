

# Generated at 2022-06-12 02:52:13.976881
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField)

# Generated at 2022-06-12 02:52:21.203830
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.exceptions import UnacceptableField, UndefinedField
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.security import Security

    class MyProvider(BaseProvider):
        class Meta:
            name = 'provider'

        def foo(self):
            return 42

    provider = MyProvider()

    provider.register(provider)
    provider.register(Address)
    provider.register(Security)
    provider.register('random')

    field = Field(providers=[provider, 'text'])
    assert not field._gen.has_provider('my-provider')
    assert field._gen.has_provider(provider.Meta.name)

# Generated at 2022-06-12 02:52:28.682863
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__ method."""
    import unittest
    from unittest import mock

    from mimesis.schema import AbstractField

    class AField(AbstractField):

        def __init__(self, locale, seed):
            super().__init__(locale, seed)

    class TestAbstractField(unittest.TestCase):

        def setUp(self):
            self.field = AField('en', None)

        def test_call_method_with_wrong_name(self):
            """Test method call with wrong name."""
            with self.assertRaises(UndefinedField):
                self.field()

        def test_call_method_with_wrong_provider(self):
            """Test method call with wrong provider."""

# Generated at 2022-06-12 02:52:29.118250
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert True

# Generated at 2022-06-12 02:52:36.285404
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test of AbstractField.__call__ method."""
    f = AbstractField()
    assert callable(f)
    assert isinstance(f.__call__('enumeration', length=1), list)
    assert f.__call__('enumeration', length=1, key=lambda x: x[0]) == 'a'
    assert f.__call__('uuid', version=4)
    assert f.__call__('uuid', version=4)



# Generated at 2022-06-12 02:52:37.823287
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    _ = AbstractField()



# Generated at 2022-06-12 02:52:47.022243
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.data import AUTOMOBILE
    from mimesis.enums import Gender
    from mimesis.schema import Schema
    from mimesis.builtins import Person
    from mimesis.generic import Generic
    import mimesis.builtins.person

    def schema() -> dict:
        """Example of a schema."""

# Generated at 2022-06-12 02:52:51.541550
# Unit test for method create of class Schema
def test_Schema_create():
    @Schema
    def schema():
        """Create schema."""
        return {
            'value': Field(name='math.randint', start=10, end=100, key=int),
        }

    assert all([isinstance(i, dict) for i in schema.create(2)])

# Generated at 2022-06-12 02:52:57.384303
# Unit test for method create of class Schema
def test_Schema_create():
    """Test Schema class method."""
    def schema(field: Any) -> JSON:
        """Test schema."""
        return {
            'name': field('full_name'),
            'age': field('age'),
        }

    s = Schema(schema)
    result = s.create(iterations=10)
    assert len(result) == 10



# Generated at 2022-06-12 02:52:59.562057
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField instantiation."""
    f = Field('en')
    assert f.locale == 'en'
    assert f.seed is None



# Generated at 2022-06-12 02:53:16.670012
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)


# Generated at 2022-06-12 02:53:22.900412
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.numerics import Numerics
    from mimesis.providers.misc import Misc

    f = AbstractField()

    assert callable(f)
    assert isinstance(f('choice', options='abcd'), str)
    assert isinstance(
        f('choice', 'numerics', options=range(10)),
        int)
    assert isinstance(f('random'), float)
    assert isinstance(f('random_int'), int)
    assert isinstance(f('pick_item', 'mimesis'), str)
    assert f('pick_item', 'mimesis', key=lambda s: s.title())



# Generated at 2022-06-12 02:53:24.825850
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField."""
    field = Field()
    assert field(name='name') is not None

# Generated at 2022-06-12 02:53:35.476790
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of AbstractField."""

    f = Field()
    assert callable(f)

    assert f(name=None) is None
    assert f(name='email') != f(name='email')
    assert f(name='person.full_name') != f(name='person.full_name')

    with open('./tests/forbidden_words.txt') as words:
        content = words.read()
        words_list = [word for word in content.split(' ')]

    key_func = lambda x: x.split(' ')[0]
    # This is a key-function which is applied to result
    # returned by method `full_name` of `Person` provider.
    assert f(name='person.full_name', key=key_func) not in words_list

# Generated at 2022-06-12 02:53:36.339710
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field is not None

# Generated at 2022-06-12 02:53:37.857217
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    field = AbstractField('ru')

# Generated at 2022-06-12 02:53:47.937491
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for class AbstractField."""
    schema = AbstractField()
    assert schema('fmt') == '{} {}'.format(
        schema('first_name', seed=1), schema('last_name', seed=1))
    assert schema('age', seed=1) == 89

    # Testing if name belongs to provider
    assert schema('first_name') == 'Alice'
    assert schema('personal.first_name') == 'Alice'

    # Testing undefined fields
    try:
        schema()
    except UndefinedField:
        pass

    # Testing unsupported fields
    try:
        schema('non-existent-method')
    except UnsupportedField:
        pass

    # Testing unacceptable fields
    try:
        schema('non-existent-provider.xxx')
    except UnacceptableField:
        pass



# Generated at 2022-06-12 02:53:49.168745
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert f
    assert isinstance(f, AbstractField)

# Generated at 2022-06-12 02:53:50.674912
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()   # noqa: F841
    assert field.locale == 'en'
    assert field.seed is None



# Generated at 2022-06-12 02:53:55.668466
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Test __init__
    try:
        assert Field()
    except:
        assert False

    assert Field.locale == 'en'
    # Test __str__ method
    assert isinstance(str(Field()), str)
    assert str(Field()) == 'AbstractField <en>'



# Generated at 2022-06-12 02:54:21.558559
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field() is not None

# Generated at 2022-06-12 02:54:30.988961
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Create instance of AbstractField
    field = AbstractField()

    # Test that passing None as *name* raises an exception
    try:
        field()
    except UndefinedField as e:
        print(e)

    # Test that passing 'this_is_not_a_method_name' as *name* raises an exception
    try:
        field('this_is_not_a_method_name')
    except UnsupportedField as e:
        print(e)

    # Test that passing 'choice' as *name* returns string
    print(field('choice',
                ['one', 'two', 'three']))  # 'three' if seed = 42

    # Test that passing 'provider.choice' as *name* returns
    # string from provider (in this case 'Computer' provider)

# Generated at 2022-06-12 02:54:40.052825
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    f2 = field(name='binary', bits=8)
    assert isinstance(f2, str)

    f3 = field('binary', bits=8)
    assert f3 == f2

    assert field('json', key=str).startswith('{')

    f4 = field(name='json', key=str)
    assert f4 == f3

    assert field('get_provider_name') == 'generic'

    f5 = field('json', key=str)
    assert field(name='json', key=str) == f5

    assert field('choices', collection=1) == 1

    f6 = field('choices', collection=1)
    assert f6 == f5

# Generated at 2022-06-12 02:54:45.105996
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    result = field('uuid')

    assert len(result) == 36

# Generated at 2022-06-12 02:54:54.034046
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    # 1 method
    assert Field(seed=0)('sha1') == 'b1bd7b1e91b68d7e84817c3a9f9a9b70ed722e1e'
    # 1 method with args
    assert Field(seed=0)(
        'quantity',
        minimum=2,
        maximum=10,
    ) == 5
    # 1 method with args, but with key
    assert Field(seed=0)(
        'uuid4',
        key=str,
    ) == '02b5f1d9-f9af-4a99-8b3c-f5983d0d03c5'
    # 1 method with invalid name
    assert Field(seed=0)('bad_method') is None

# Generated at 2022-06-12 02:54:57.933334
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field._gen is not None

# Generated at 2022-06-12 02:55:04.556727
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()

    assert field('file.extension') in ['pdf', 'jpg']
    assert field('file.extension', key=lambda ext: ext.upper()) == 'PDF'

    try:
        field('unsupported')
    except ValueError as e:
        assert str(e) == 'Provider is not supported'

    try:
        field('unsupported.method')
    except ValueError as e:
        assert str(e) == 'Provider is not supported'

    try:
        field('file.unsupported')
    except AttributeError as e:
        assert str(e) == "'FileProvider' object has no attribute 'unsupported'"

    try:
        field('file.unsupported.method')
    except UnacceptableField:
        assert True

# Generated at 2022-06-12 02:55:12.248575
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method AbstractField.__call__."""
    field = AbstractField()

    # Test without name
    with pytest.raises(UndefinedField):
        field.__call__()

    # Test with unsupported method #1
    with pytest.raises(UnsupportedField):
        field.__call__(name='unsupported')

    # Test with unsupported method #2
    with pytest.raises(UnsupportedField):
        field.__call__(name='system.unsupported')

    # Test for unsupported provider
    with pytest.raises(UnsupportedField):
        field.__call__(name='system.os_name')

# Generated at 2022-06-12 02:55:13.572555
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    result = field('person.full_name')
    assert result



# Generated at 2022-06-12 02:55:15.777273
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    def key_function(value):
        return value + 'foo'

    field = Field()
    assert isinstance(field('uuid'), str)
    assert isinstance(field('uuid', version=4), str)
    assert isinstance(field('uuid', key=key_function), str)

# Generated at 2022-06-12 02:55:57.202205
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Create object of AbstractField class."""
    _ = AbstractField()

# Generated at 2022-06-12 02:55:59.655661
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import Datetime

    dt = Datetime()
    field = AbstractField('en', dt.seed, [dt])
    assert (field('datetime', '%Y-%m-%d',
                  day=1, month=1, year=2020) == '2020-01-01')

# Generated at 2022-06-12 02:56:10.477192
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    from mimesis.providers.base import BaseDataProvider

    class SomeProvider(BaseDataProvider):

        class Meta:
            name = 'some_provider'

        def some_method(self) -> str:
            return 'some_method'

        def another_method(self) -> str:
            return 'another_method'

    locale = 'en'
    seed = 'seed'

    generic = Generic(locale, seed)

    provider = SomeProvider(locale, seed)
    gen = generic.add_providers(provider)

    field = AbstractField(locale, seed, providers=gen)

    assert field('some_method') == 'some_method'
    assert field('another_method') == 'another_method'

# Generated at 2022-06-12 02:56:19.921462
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    # Return the same result when first call
    # and second call when number of elements is the same
    data = field('token', n=10)
    assert data == field('token', n=10)

    # Return different results when first call
    # and second call when number of elements is different
    data = field('token', n=10)
    assert data != field('token', n=11)

    # Return the same result when first call
    # and second call when number of symbols of the same
    data = field('password', symbols=20)
    assert data == field('password', symbols=20)

    # Return different results when first call
    # and second call when number of symbols is different
    data = field('password', symbols=20)
    assert data != field('password', symbols=21)

    # Return the

# Generated at 2022-06-12 02:56:23.168146
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None
    field = AbstractField('en')
    assert field is not None

# Generated at 2022-06-12 02:56:28.910350
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test __call__ method."""
    field = AbstractField()
    assert field('location.city', region='US')

# Generated at 2022-06-12 02:56:35.094432
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    expected = 57
    provider = 'en'
    generated = AbstractField(provider, seed=123)(
        'age',
        minimum=18,
        maximum=100,
    )
    assert expected == generated

# Generated at 2022-06-12 02:56:37.079987
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(providers=[])
    assert field is not None
    assert field._gen is not None
    assert field._table is not None
    assert field._gen.providers == []
    assert field._gen.locale == 'en'

# Generated at 2022-06-12 02:56:41.613896
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    def test_with__key_function() -> None:
        field = AbstractField()

        assert isinstance(field('uuid'), str)
        assert isinstance(field('uuid', key=lambda x: x.split('-')[0]), str)

    def test_with__no_key_function() -> None:
        field = AbstractField()
        assert isinstance(field('gender'), str)

    def test_with__not_supported_provider() -> None:
        field = AbstractField()
        with pytest.raises(UnsupportedField):
            field('mimesis')

    def test_with__not_defined_field() -> None:
        field = AbstractField()
        with pytest.raises(UndefinedField):
            field()

    test_with__key_function()
    test_with__no_key

# Generated at 2022-06-12 02:56:46.059490
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """AbstractField.__call__ is a method which returns value of field.

    :return: AbstractField with 'mimesis.Generic' provider
    """
    # :type field: AbstractField
    field = AbstractField()

    assert field('full_name') == 'Anthony Reyes'

    assert callable(field.choice)

    assert field('choice', list(range(5))) in list(range(5))



# Generated at 2022-06-12 02:58:07.494372
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(AbstractField(), AbstractField) is True

# Generated at 2022-06-12 02:58:08.732648
# Unit test for constructor of class AbstractField
def test_AbstractField():  # noqa: D103
    field = AbstractField(locale='ru')
    assert field.locale == 'ru'



# Generated at 2022-06-12 02:58:14.298790
# Unit test for constructor of class AbstractField

# Generated at 2022-06-12 02:58:14.932539
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field._table == {}

# Generated at 2022-06-12 02:58:25.561119
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import Person, Profile
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet
    from mimesis.typing import KeyFunction

    def gender(_: Any) -> str:
        return _

    def address(_: Any) -> str:
        return _['address']

    locale = 'en'
    seed = 42
    f = Field(locale=locale, seed=seed)
    p = Person(locale=locale, seed=seed)

    assert f('name', gender=Gender.FEMALE) == \
        p.full_name(gender=Gender.FEMALE)

    assert f('full_name', key=gender, gender=Gender.FEMALE) == \
        p.full_name(gender=Gender.FEMALE)


# Generated at 2022-06-12 02:58:30.052814
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor."""
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-12 02:58:33.896209
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f('name')
    assert isinstance(f('geo.coordinates'), float)
    assert isinstance(f('geo.coordinates', precision=2), float)

# Generated at 2022-06-12 02:58:40.293048
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField('ru')

    try:
        f()
    except UndefinedField:
        pass
    else:
        raise AssertionError('Should be raised UndefinedField.')



# Generated at 2022-06-12 02:58:40.765525
# Unit test for constructor of class AbstractField
def test_AbstractField():
    pass

# Generated at 2022-06-12 02:58:45.784759
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method ``__call__`` of ``AbstractField``."""
    obj = Field()
    result = obj('get_value')
    assert isinstance(result, str)