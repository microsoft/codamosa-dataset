

# Generated at 2022-06-12 02:52:17.647326
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__.

    **Description:**

        Some data-providers have methods with the same names.
        For example, Person class has method `full_name` for
        getting full name of a person. But a method `full_name`
        is in other data-providers.

        In this case, you can explicitly define that the method
        belongs to data-provider ``name = 'provider.name'``
        otherwise it will return the data from the first
        provider which has a method ``name``.
    """
    name = 'full_name'

    # It will return the data from the first provider which has a method
    # name. In this case it will be from a data-provider Person
    # because the last one.
    assert ' ' in Field()(name)

    # To return from the data-

# Generated at 2022-06-12 02:52:25.038571
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for Schema.create."""
    def schema():
        """Simple schema."""
        return {'key': 'value'}

    schema = Schema(schema)
    assert schema.create(3) == [{'key': 'value'}, {'key': 'value'}, {'key': 'value'}]

# Generated at 2022-06-12 02:52:29.881754
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='en')
    assert field.locale == 'en'

    field = AbstractField(locale='ru', seed=123)
    assert field.seed == 123

# Generated at 2022-06-12 02:52:38.157633
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Preparation
    field = Field('en')

    # Get value with field
    assert field('token') is not None

    # Get value with field and key
    assert field('uuid4',
                 key=lambda x: x.split('-')[0]) is not None

    # Get value from method which belongs to data-provider
    assert field('person.full_name') is not None

    # Get value from method which belongs to data-provider with key
    assert field('person.age', key=lambda a: a % 100) is not None



# Generated at 2022-06-12 02:52:46.921363
# Unit test for method create of class Schema
def test_Schema_create():
    class DummySchema:
        def __init__(self, callable_obj: Callable) -> None:
            self.schema = callable_obj

        def create(self, iterations: int = 1) -> List[JSON]:
            return [self.schema() for _ in range(iterations)]

    field = Field()
    schema = DummySchema(field("full_name"))
    result = schema.create(5)
    assert isinstance(result, list)
    assert len(result) == 5

# Generated at 2022-06-12 02:52:58.061620
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for :class:`~mimesis.schema.Schema`."""
    from mimesis import Person

    person = Person('zh')

    def person_schema() -> JSON:
        """Return person data."""
        return {
            'name': person.full_name(),
            'age': person.age(),
            'height': person.height(),
            'weight': person.weight(),
        }

    schema = Schema(person_schema)
    data = schema.create(100)

    assert isinstance(data, list)
    assert len(data) == 100

    assert isinstance(data[0], dict)
    assert isinstance(data[0]['name'], str)
    assert isinstance(data[0]['age'], int)

# Generated at 2022-06-12 02:53:07.634481
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    # with open('field_list.txt', 'w') as f:
    #     for i in dir(field._gen):
    #         if i.islower() and not i.startswith('_'):
    #             f.write('- {}.{}\n'.format(i, field._gen.choice.Meta.name))
    #             f.write('- {}.{}\n'.format(i, field._gen.boolean.Meta.name))
    #             f.write('- {}.{}\n'.format(i, field._gen.date_time.Meta.name))
    #             f.write('- {}.{}\n'.format(i, field._gen.python.Meta.name))
    #             f.write('- {}.{}\n'.format(i, field._gen

# Generated at 2022-06-12 02:53:10.804271
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method `__call__` of class AbstractField."""
    field = AbstractField(locale='ru')
    assert field('provider.data.word')



# Generated at 2022-06-12 02:53:19.235282
# Unit test for method create of class Schema
def test_Schema_create():
    """..."""
    from mimesis.schema import Schema
    from mimesis.schema import Field


    def schema():
        """..."""
        field = Field()
        return {
            'a': field('price'),
            'b': field('credit_card_number'),
            'c': field('person.full_name'),
        }


    expected = [
        {'a': 1, 'b': '4012881888818888', 'c': 'John McManus'},
    ]

    result = Schema(schema).create()

    assert result is not None
    assert result == expected

# Generated at 2022-06-12 02:53:20.750357
# Unit test for method create of class Schema
def test_Schema_create():
    """Test class Schema.

    Run method create
    """
    pass



# Generated at 2022-06-12 02:54:17.247897
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    f = AbstractField()
    assert f('full_name')
    assert f('full_name', token='-')
    assert f('science.element')
    assert f('science.element', symbol=True)
    assert f('datetime.datetime', year=2000, month=1, day=1)
    assert f('datetime.datetime', year=2000, month=1, day=1, key=lambda x: x.year)

    assert f('choice', ['a', 'b', 'c'])
    assert f('choice', ['a', 'b', 'c'], key=list)

    assert f('personal.full_name')
    assert f('personal.full_name', gender='male')

    assert f('code.iban')

# Generated at 2022-06-12 02:54:21.804113
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    case1 = AbstractField()
    assert case1('name')
    assert case1('name', gender='m')
    assert case1('name', key=str.title)
    assert case1('currency_symbol')
    assert case1('currency', key=str.title)
    assert case1('currency.symbol')
    assert case1('currency.symbol', key=str.title)

# Generated at 2022-06-12 02:54:31.070733
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = Field(locale='en')
    assert field('full_name') == 'Christopher Hansen'
    assert field('full_name', key=lambda x: "I'm {}".format(x)) == "I'm Christopher Hansen"
    assert field('datetime.date', key=lambda x: '{0:%Y-%m-%d}'.format(x)) == '2020-11-15'
    assert field('datetime.time') == '12:59:52'
    assert field('datetime.datetime') == '2020-01-09 17:19:20'
    assert field('datetime.datetime', '2020-01-09 17:19:20') == '2020-01-09 17:19:20'

# Generated at 2022-06-12 02:54:36.680365
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # noinspection PyTypeChecker
    # assert type(AbstractField()()) == str
    assert AbstractField()() is not None



# Generated at 2022-06-12 02:54:41.461979
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('uuid') == field('uuid')
    assert isinstance(field('token'), str)
    assert isinstance(field('uuid'), str)
    assert isinstance(field('identifier'), str)
    assert isinstance(field('integer'), int)
    assert isinstance(field('float_number'), float)
    assert isinstance(field('boolean'), bool)
    assert isinstance(field('datetime'), str)
    assert isinstance(field('datetime_tz'), str)
    assert field('choice', choices=[1, 2, 3]) in [1, 2, 3]
    assert field('choice_int', choices=[1, 2, 3]) in [1, 2, 3]

# Generated at 2022-06-12 02:54:50.571351
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.providers.generic import Person as Person

    obj = AbstractField()
    assert isinstance(obj._gen, Generic)
    assert obj.locale == 'en'
    assert obj.seed is None
    assert not obj._table

    obj = AbstractField('ru')
    assert obj.locale == 'ru'

    obj = AbstractField(locale='ru', seed=10)
    assert obj.locale == 'ru'
    assert obj.seed == 10

    obj = AbstractField('ru', seed='Some seed')
    assert obj.locale == 'ru'
    assert obj.seed == 'Some seed'

    obj = AbstractField(locale='ru', seed=10, providers=[Person])
    assert isinstance(obj._gen.person, Person)


# Generated at 2022-06-12 02:54:56.925354
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Positive tests
    _field = Field()
    assert _field('code.npi')
    assert _field('code.ssn')
    assert _field('address.address_line')
    assert _field('address.street_name')
    assert _field('address.postal_code')
    assert _field('address.street_address')
    assert _field('address.country')
    assert _field('cryptographic.md5')
    assert _field('text.text')
    assert _field('internet.domain_name')
    assert _field('internet.user_agent')
    assert _field('geo.latitude')
    assert _field('geo.longitude')
    assert _field('datetime.datetime')
    assert _field('datetime.month')
    assert _field('datetime.year')

# Generated at 2022-06-12 02:55:02.755138
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert isinstance(field('Code'), str)
    assert isinstance(field('Code', length=10), str)
    assert isinstance(field('Code', 'alpha', length=10), str)
    assert isinstance(field('Code', 'lower', length=10), str)
    assert isinstance(field('Code', 'upper', length=10), str)

    assert isinstance(field('Code', Code='alpha', length=10), str)
    assert isinstance(field('Code', Code='lower', length=10), str)
    assert isinstance(field('Code', Code='upper', length=10), str)
    assert isinstance(field('Code', Code='alpha_numeric', length=10), str)


# Generated at 2022-06-12 02:55:13.001109
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Create field object
    f = Field()

    # Create random person
    person = f('person')
    assert isinstance(person, str)

    # Create first name of person
    first_name = f('first_name')
    assert isinstance(first_name, str)

    # Create last name of person
    last_name = f('last_name')
    assert isinstance(last_name, str)

    # Create random person by address
    person = f('person', address=f('address'))
    assert isinstance(person, str)

    # Apply key function to result
    person = f('person', key=lambda x: f'{x.capitalize()}.')
    assert person.capitalize().endswith('.')
    assert isinstance(person, str)

# Generated at 2022-06-12 02:55:13.946409
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert isinstance(f, AbstractField)



# Generated at 2022-06-12 02:55:38.232072
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()  # type: ignore
    assert field.locale == 'en'
    assert field.seed == None  # type: ignore
    assert field._gen != None  # type: ignore

# Generated at 2022-06-12 02:55:45.553356
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Tests for ``__call__`` method."""
    from mimesis.schema.data import address, person
    field = AbstractField()

    assert field('us_address')
    assert field('name')

    assert field('person.name') == field('name')
    assert field('address.us_address') == field('us_address')

    assert field(key=person.title, name='person')
    assert field(key=address.title, name='address')

    def upper(text: str) -> str:
        """Return text in uppercase."""
        return text.upper()

    assert field('name', key=upper)

# Generated at 2022-06-12 02:55:47.132850
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    _field = Field(locale='en')
    assert _field('string') is not None



# Generated at 2022-06-12 02:55:48.598000
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for unit test for constructor of class AbstractField."""
    ab_field = AbstractField()
    assert ab_field

# Generated at 2022-06-12 02:55:49.769935
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert AbstractField('en')  # noqa: S101

# Generated at 2022-06-12 02:55:53.208104
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    field = Field(seed=42)
    assert isinstance(field, AbstractField)
    assert field.locale == 'en'
    assert field.seed == 42

# Generated at 2022-06-12 02:55:57.725532
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert str(Field()) == 'AbstractField <en>'
    assert Field('ru')
    assert Field(seed=232)
    Field('es', 111111, ['datetime'])

# Generated at 2022-06-12 02:56:04.354270
# Unit test for constructor of class AbstractField
def test_AbstractField():
    class TestClass(AbstractField):
        pass

    af = TestClass()

    name = 'test'
    kwargs = {
        'key': 'item_1',
        'amount': 1,
    }

    assert af(name, **kwargs) == 'item_1'

# Generated at 2022-06-12 02:56:06.872589
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(locale='en')
    assert field.locale == 'en'

# Generated at 2022-06-12 02:56:11.165521
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field
    assert field.locale == 'en'
    assert field._gen
    assert field._gen.locale == 'en'