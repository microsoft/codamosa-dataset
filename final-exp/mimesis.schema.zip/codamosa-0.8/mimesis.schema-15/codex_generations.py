

# Generated at 2022-06-12 02:52:00.321325
# Unit test for method create of class Schema
def test_Schema_create():
    s = Schema(lambda: {
        'name': lambda: 'test',
        'last_name': lambda: 'test',
    })
    assert isinstance(s.create(), list)
    assert isinstance(s.create(0), list)

# Generated at 2022-06-12 02:52:07.859612
# Unit test for method create of class Schema
def test_Schema_create():
    # Arrange
    schema = {
        'age': lambda: 18,
        'name': lambda: 'Jon Snow',
        'address': {
            'street': lambda: 'Winterfell',
            'number': lambda: 100,
        }
    }

    # Act
    num_iterations = 3
    data = Schema(schema).create(num_iterations)

    # Assert
    assert len(data) == num_iterations

# Generated at 2022-06-12 02:52:16.532345
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test that AbstractField is a class for generating data."""
    f = AbstractField()
    assert f('text.word')
    assert f('cryptographic.hash', key=print)
    assert f('cryptographic.salt', length=32) == '7cc8f'
    assert f('user_agent.chrome')
    assert f('internet.mac_address')
    assert f('system.cpu_family')
    assert f('system.host_name')
    assert f('system.platform')
    assert f('system.architecture')

# Generated at 2022-06-12 02:52:21.589415
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert issubclass(field.__class__, AbstractField)

# Generated at 2022-06-12 02:52:25.110044
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    field = AbstractField()
    assert callable(field)
    assert isinstance(field, AbstractField)
    assert field._gen is not None
    assert field._table is not None



# Generated at 2022-06-12 02:52:30.909532
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': 'Tomas',
            'surname': 'Anderson',
            'age': 22,
            'skills': ['Python', 'JS']
        }

    results = Schema(schema=schema).create(iterations=3)
    assert len(results) == 3

# Generated at 2022-06-12 02:52:35.691470
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()

    assert callable(f)
    assert isinstance(f('random.int'), int)
    assert isinstance(f('random.int', max_value=100), int)

# Generated at 2022-06-12 02:52:37.175485
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert hasattr(field, '__call__')



# Generated at 2022-06-12 02:52:38.658374
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    result = field('text.word', provider='en')
    assert result

# Generated at 2022-06-12 02:52:42.606002
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    reference = 'Rick'
    locale = 'en'
    seed = 42

    f = Field(locale, seed)

    assert f('person.name') == reference
    assert f('person.name', title=True) != reference
    assert f('person.name', middle_name=True) is not None

# Generated at 2022-06-12 02:53:02.462141
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():  # noqa: D103
    f = Field()
    assert isinstance(f('uuid'), str)
    assert f('uuid', key=len) == 32
    assert isinstance(f('datetime'), str)
    assert isinstance(f('datetime', formatter='%H:%M:%S'), str)
    assert isinstance(f('file_extension'), str)
    assert isinstance(f('status_code'), int)


# Generated at 2022-06-12 02:53:04.278438
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert isinstance(field('datetime.timestamp'), int)
    assert field('datetime.timestamp') > 1e10

# Generated at 2022-06-12 02:53:09.642270
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField(locale='ru')
    assert f('text.words')(4, join=False) == ['автопередача', 'автоподбор', 'автопротокол', 'автопрокладка']

# Generated at 2022-06-12 02:53:13.073551
# Unit test for method create of class Schema
def test_Schema_create():
    """Test class Schema."""
    from mimesis import Address

    addr = Address('ru')

    schema = Schema(addr.address)

    values = schema.create(iterations=5)
    print(values)

    for address in values:
        assert isinstance(address, str)
        assert len(address) > 0



# Generated at 2022-06-12 02:53:17.191261
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Testing `__init__` method
    f = Field(locale='ru')
    assert f.locale == 'ru'

    # Testing `__str__` method
    assert str(f) == 'Field <ru>'



# Generated at 2022-06-12 02:53:23.894738
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    import pytest
    from mimesis.schema import Field

    schema = {
        'full_name': Field('person.full_name'),
        'age': Field('datetime.age', minimum=18),
        'phone': Field('personal.phone'),
        'email': Field('internet.email'),
        'password': Field('personal.password'),
        'gender': Field('personal.gender', gender=Gender.FEMALE),
    }

    def _schema(obj):
        return {
            key: val() for key, val in obj.items() if key != 'gender'
        }

    schema_instance = Schema(_schema)

    result = schema_instance.create(schema, iterations=10)
    assert isinstance(result, list)

# Generated at 2022-06-12 02:53:24.692418
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field is not None

# Generated at 2022-06-12 02:53:26.607972
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    f = AbstractField()
    assert f('word')



# Generated at 2022-06-12 02:53:32.621858
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __del__ of class AbstractField."""
    field = AbstractField()  # type: ignore

    # Test for UndefinedField
    assert field() is None

    # Test for UnsupportedField and KeyError
    assert field('abc') is None

    # Test for UnacceptableField
    assert field('abc.xyz.123') is None

    # Test for success case
    assert field('name') is not None

# Generated at 2022-06-12 02:53:35.028721
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test object creation."""
    f = AbstractField()
    assert f
    assert isinstance(f, AbstractField)



# Generated at 2022-06-12 02:53:57.187614
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Init AbstractField class."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert isinstance(field._table, dict)

# Generated at 2022-06-12 02:54:05.523898
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    provider = Generic()

    # Default name
    field = AbstractField()
    assert field('none') is None

    # Define a field by name without a data provider
    field = AbstractField()
    assert field('username') == provider.person.username()[0]

    # Define a field by name without a data provider
    field = AbstractField()
    method = field('username')
    assert method == provider.person.username()[0]

    # Define a field by name with a data provider
    field = AbstractField()
    assert field('person.username') == provider.person.username()[0]

    # Define a field by name with a data provider,
    # but the method is from another provider
    field = AbstractField()
    assert field('person.telephone') is None

    # Define a field by name for a non

# Generated at 2022-06-12 02:54:09.949040
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for safe call to unknown method."""
    from mimesis.enums import Gender

    field = Field()

    assert field('random_element', data=[1, 2, 3]) == 2

    # test key function
    assert field(
        'gender', key=lambda x: Gender.FEMALE if x == 'f' else Gender.MALE,
    ) == Gender.MALE

# Generated at 2022-06-12 02:54:14.053675
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('abbreviation')
    assert field('full_name', with_suffix=False)
    assert field('random_element', elements=['foo', 'bar'])
    assert field('random_string', length=100)



# Generated at 2022-06-12 02:54:17.334587
# Unit test for constructor of class AbstractField
def test_AbstractField():
    seed = 'test_seed'
    locale = 'ru'
    field = AbstractField(locale, seed=seed)
    assert field.seed == seed
    assert field.locale == locale
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-12 02:54:24.002697
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.builtins import RussiaSpecProvider

    fields = Field(providers=[RussiaSpecProvider])
    schema = type('DummySchema', (object,), {
        'name': fields('full_name'),
        'age': fields('age', min_value=30, max_value=60),
        'job': fields('occupation'),
    })
    s = Schema(schema)

    result = s.create(iterations=10)
    assert len(result) == 10
    assert isinstance(result, list)
    assert isinstance(result[0], schema)

# Generated at 2022-06-12 02:54:27.485535
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert isinstance(field('full_name'), str)
    assert isinstance(field('password'), str)
    assert isinstance(field('seed'), str)
    assert isinstance(field('person.full_name'), str)
    assert isinstance(field('custom_provider.data'), str)

# Generated at 2022-06-12 02:54:30.344737
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    obj = AbstractField()
    assert obj('name') is not None

# Generated at 2022-06-12 02:54:31.519484
# Unit test for method create of class Schema
def test_Schema_create():

    assert len(Schema(dict).create(3)) == 3
    assert len(Schema(dict).create()) == 1

# Generated at 2022-06-12 02:54:35.008556
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.

    Unit test for method __call__ of class AbstractField
    """
    field = AbstractField()
    result = field('uuid')
    assert isinstance(result, str)



# Generated at 2022-06-12 02:55:24.842460
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for AbstractField's __call__ method."""
    provider = Generic('en')
    field = AbstractField('en', providers=provider)
    assert field('random_long') is not None
    assert field('random_long') is not None
    assert field('random_long', minimum=-10, maximum=10) is not None

# Generated at 2022-06-12 02:55:29.091556
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    #  check exceptions
    assert field('', raise_exceptions=True)
    assert field(None, raise_exceptions=True)

    assert field('randstr', length=5)

# Generated at 2022-06-12 02:55:35.953039
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    gen = AbstractField()
    assert callable(gen)
    assert isinstance(gen('datetime'), str)
    assert isinstance(gen('number.between', 1, 100), int)
    assert isinstance(gen('number.between', 1, 100), int)
    assert isinstance(gen('person.full_name'), str)
    assert callable(gen('permalink'))
    assert isinstance(gen('permalink')(), str)
    assert gen('permalink') == gen('permalink')
    assert gen('permalink') != gen('permalink')
    assert gen('datetime') == gen('datetime')
    assert gen('datetime') != gen('datetime')
    assert isinstance(gen('person.full_name', key=str.casefold), str)

# Generated at 2022-06-12 02:55:45.166942
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method ``__call__`` of class ``AbstractField``."""
    field = Field()
    assert callable(field)

    random_string = field('random.string')
    assert isinstance(random_string, str)

    random_string = field('random.string', min_size=1, max_size=10)
    assert isinstance(random_string, str)

    random_integer = field('random.integer', min_value=1, max_value=10)
    assert isinstance(random_integer, int)

    random_float = field('random.float', places=2)
    assert isinstance(random_float, float)

    random_float = field('random.float', min_value=1.1, max_value=12.5)
    assert isinstance(random_float, float)

    random

# Generated at 2022-06-12 02:55:53.814308
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    def key(data: str) -> str:
        return data.upper()

    assert field('sha512', key=key, length=16) == 'SHA512'
    assert field('credit_card_number', key=key) == 'CREDIT_CARD_NUMBER'
    assert field('cellphone_number', key=key) == 'CELLPHONE_NUMBER'
    assert field('telephone_number', key=key) == 'TELEPHONE_NUMBER'
    assert field('password') != field('password')
    assert field('name.full_name') != field('full_name')
    assert field('name.full_name') == field('name.full_name')

# Generated at 2022-06-12 02:56:00.091626
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    result = field('datetime.datetime', year=2004)
    assert result.year == 2004
    result = field('datetime.datetime', full=True)
    assert len(result.split()) == 6
    result = field('datetime.datetime', full=True, key=lambda x: x.split()[0])
    assert len(result.split()) == 1

# Generated at 2022-06-12 02:56:10.527405
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('datetime')

    field = Field(locale='ru')
    assert field('datetime')

    with field.seed(12345):
        assert field('person.full_name') == 'Дарья Александровна Карпова'

    field = Field()
    assert field('person.full_name') == 'John H. Johnson'
    field = Field(locale='ru')
    assert field('person.full_name') == 'Александр Васильевич Жуков'


# Generated at 2022-06-12 02:56:19.921358
# Unit test for method __call__ of class AbstractField

# Generated at 2022-06-12 02:56:28.686627
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.person import Person
    from mimesis.providers.person.ru import RussianPerson

    field = AbstractField(locale='ru', providers=[Person, RussianPerson])
    result = field('address.postal_code')
    assert isinstance(result, str)

    result = field('address.postal_code', length=6)
    assert isinstance(result, str)
    assert len(result) == 6

    result = field('address.postal_code', name='person.postal_code')
    assert isinstance(result, str)

    result = field('name', key=lambda x: x.title())
    assert isinstance(result, str)
    assert result.istitle()

    field = AbstractField()
    assert isinstance(field('name'), str)


# Generated at 2022-06-12 02:56:38.826550
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    f = AbstractField()
    assert f.locale == 'en'

    data = f('datetime')
    assert isinstance(data, str)

    data = f('datetime', datetime_format='%d %m %Y %H:%M:%S')
    assert '-' not in data

    p = Person(locale='ru')
    f._gen.add_provider(p)

    g = f('gender')
    assert g in Gender.ALL
    assert p.gender() == g

    g = f('person.gender')
    assert g in Gender.ALL
    assert p.gender() == g


# Generated at 2022-06-12 02:57:38.038185
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    # Check if result is Callable
    assert callable(field('binary'))

    # Check if there is a KeyError
    try:
        field('not_exists')
    except KeyError:
        pass

    # Check if there is a ValueError
    try:
        field('math.unsupported')
    except ValueError:
        pass

    # Check if there is a UnacceptableField
    try:
        field('math.unsupported.field.name')
    except UnacceptableField:
        pass

# Generated at 2022-06-12 02:57:42.375266
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test __call__ method of AbstractField."""
    field = AbstractField()
    # Test with the provider
    assert field('uuid')
    assert field('uuid').__name__ == 'uuid'
    assert field('uuid', version=4)
    assert field('uuid4')
    assert field('uuid4').__name__ == 'uuid4'

    assert field('color')
    assert field('Color')
    assert field('color').__name__ == 'hex_color'

    assert callable(field('currency'))
    assert field('currency', 'JPY').__name__ == 'JPY'

    assert field('seed') == field('seed')
    assert field('code') == field('code')

    assert field('code', key=lambda x: ''.join(x)) == field('code')