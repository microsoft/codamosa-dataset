

# Generated at 2022-06-12 02:52:16.259263
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()
    assert f('text.word')



# Generated at 2022-06-12 02:52:23.612201
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    result = f('name')
    assert isinstance(result, str)

    result = f('name', gender='female')
    assert isinstance(result, str)

    result = f('name', title='female')
    assert isinstance(result, str)

    result = f('name', title='female', gender='female')
    assert isinstance(result, str)



# Generated at 2022-06-12 02:52:26.226465
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('uuid') is not None
    assert f('uuid') == f('uuid')
    assert f('uuid') != f('uuid')
    assert f('uuid', with_hyphens=True) is not None

# Generated at 2022-06-12 02:52:30.966491
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""

    field = Field()
    assert field('name') is not None
    assert field('datetime', datetime_format='YYYY-MM-DD') is not None
    assert field('file.generator', suffix='.sql') is not None

# Generated at 2022-06-12 02:52:34.495832
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('timestamp') > 0



# Generated at 2022-06-12 02:52:43.343154
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField(seed=42)
    assert isinstance(field('address.full_address'), str)
    assert isinstance(field('person.full_name'), str)
    assert isinstance(field('address.postcode'), str)
    assert isinstance(field('address.state'), str)

    assert field('address.city') == 'South Kaitlynnhaven'
    assert field('address.state') == 'Arkansas'

    assert field('payment.card_number') == '5518551284869378'

    assert field('code.code', min_size=8, max_size=16) == '5p5Chd3xP4'

    assert field('datetime.year') == 2018

    assert field('bool.bool') is True

    def upper(s: str) -> str:
        """Upper string"""


# Generated at 2022-06-12 02:52:49.492280
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()
    assert f('random_int', 10, 100) in range(10, 100)
    assert f('Integer.between', min_value=10, max_value=100) in range(10, 100)
    assert f('integer.between', min_value=10, max_value=100) in range(10, 100)
    assert f(key=lambda x: x.upper(), word=3) == 'FOO'.upper()



# Generated at 2022-06-12 02:52:56.158609
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    import random
    seed = random.randint(0, 100)
    field = AbstractField(seed=seed)

    # First call for the same seed
    first = field('en.identifier')
    assert first == field('en.identifier')

    # Change seed
    field = AbstractField(seed=seed+1)

    # Second call for another seed
    second = field('en.identifier')
    assert first != second
    assert first == field('en.identifier')

# Generated at 2022-06-12 02:53:05.434029
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    g_field = field.__call__

    # With random provider
    assert g_field('uuid') != g_field('uuid')
    assert g_field('email') != g_field('email')

    # With crypto provider
    assert g_field('hash.sha1') != g_field('hash.sha1')

    # With dates provider
    assert g_field('datetime') != g_field('datetime')

    # With numeric provider
    assert g_field('integer') != g_field('integer')

    # With system provider
    assert g_field('cpu_info') != g_field('cpu_info')
    assert g_field('hdd_info') != g_field('hdd_info')

    # With web provider

# Generated at 2022-06-12 02:53:14.273532
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """AbstractField: __call__."""
    f = Field()

    assert f('btc') is not None
    assert f('pers_name') is not None
    assert f('org_name') is not None
    assert f('first_name') is not None
    assert f('full_name') is not None
    assert f('number_ext') is not None
    assert f('number_int') is not None
    assert f('number') is not None
    assert f('latitude') is not None
    assert f('longitude') is not None
    assert f('coordinate') is not None
    assert f('email') is not None
    assert f('country_code') is not None
    assert f('country_tld') is not None
    assert f('postcode') is not None
    assert f('city') is not None
