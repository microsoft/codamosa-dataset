

# Generated at 2022-06-12 02:52:07.092215
# Unit test for constructor of class AbstractField
def test_AbstractField():
    def test_empty_constructor():
        field = Field()
        assert isinstance(field, AbstractField)

    def test_constructor_with_locale():
        field = Field(locale='ru')
        assert field.locale == 'ru'

    def test_constructor_with_seed():
        field = Field(seed=10)
        assert field.seed == 10



# Generated at 2022-06-12 02:52:13.494102
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    g = Generic()
    a = AbstractField(seed=42, providers=[g.personal.Meta])
    a._gen.random = 42
    assert g.random() == a.random()



# Generated at 2022-06-12 02:52:15.207869
# Unit test for constructor of class AbstractField
def test_AbstractField():  # noqa: D103
    field = AbstractField()
    assert isinstance(field, AbstractField)



# Generated at 2022-06-12 02:52:17.642545
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    f = Field()
    r = f('name')
    assert isinstance(r, str)

# Generated at 2022-06-12 02:52:25.684697
# Unit test for method create of class Schema
def test_Schema_create():
    """Test if class Schema works as intended."""
    from mimesis.schema import Field

    field = Field()

    def schema():
        """Fake schema."""
        return {
            'name': field('person.full_name'),
            'age': field('integer', minimum=18, maximum=65),
            'address': field('address.address')
        }

    schema = Schema(schema)
    filled_schema_list = schema.create(2)
    assert isinstance(filled_schema_list, list)
    assert len(filled_schema_list) == 2
    assert isinstance(filled_schema_list[0], dict)
    assert isinstance(filled_schema_list[1], dict)

    # __str__ and __repr__

# Generated at 2022-06-12 02:52:32.341549
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create.

    Method create of class Schema return list of filled schemas.
    """

    class Foo:
        def __init__(self, bar: str = '', baz: str = ''):
            self.bar = bar
            self.baz = baz

    schema = Schema(Foo)
    assert isinstance(schema.create(iterations=5), list)

# Generated at 2022-06-12 02:52:37.195686
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert isinstance(f, AbstractField)

# Generated at 2022-06-12 02:52:40.613834
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.providers.internet import Internet

    field = AbstractField(locale='ru',
                          seed='1',
                          providers=[Internet, ])

    value = field('fqdn')
    assert value == 'соседка.рф'

# Generated at 2022-06-12 02:52:42.293374
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f is not None, 'Bad initialization of AbstractField class instance.'



# Generated at 2022-06-12 02:52:43.774531
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field(name='username')



# Generated at 2022-06-12 02:53:15.385388
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    expected = 'Василий'
    result = field('person.full_name')
    assert result == expected

# Generated at 2022-06-12 02:53:23.367813
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Create instance of the class
    f = AbstractField()
    # Create list of providers and add providers to instance of the class
    # generic
    providers = [Gender, Person, Address]

    for provider in providers:
        f._gen.add_providers(provider)

    # Check equality of the value of parameter
    assert f.locale == 'en'

    # Call a method of the class with params
    result = f('name', male=False, key=lambda x: x.title())
    # Check the type of result
    assert isinstance(result, str)
    # Check the result
    assert 'name' in result

    # Call a method of the class with params
    result = f('name', male=False, female=True)
    # Check the type of result
    assert isinstance(result, str)

    # Call

# Generated at 2022-06-12 02:53:24.584495
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f is not None

# Generated at 2022-06-12 02:53:25.843590
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    f = AbstractField()


# Generated at 2022-06-12 02:53:27.983515
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    f = AbstractField()
    assert f('Text.word') == f('word')

# Generated at 2022-06-12 02:53:38.472227
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method ``__call__`` of class AbstractField."""
    provider = Generic()

    field = Field(locale='ru')
    field._gen.add_providers(provider)
    result = field('lorem.text')
    assert (len(result) <= int(provider.lorem.text._maximum_paragraphs))

    field = Field(locale='ru')
    field._gen.add_providers(provider)
    result = field('choice', data=['A', 'B', 'C', 'D'])
    assert result in ['A', 'B', 'C', 'D']

    field = Field(locale='ru')
    field._gen.add_providers(provider)

# Generated at 2022-06-12 02:53:48.061473
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender, HashAlgorithm
    from mimesis.providers import Person, Text, Crypto

    crypto = Crypto(seed=4)
    text = Text(seed=5)
    person = Person(seed=6)

    field = AbstractField(seed=7)


# Generated at 2022-06-12 02:53:53.791284
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    content_type = field('content_type')
    assert content_type

    from mimesis.providers.media import Media
    with open(Media.get_file_path('content_types.json'), 'r') as f:
        types = set(json.loads(f.read()))
        assert content_type in types

    field = AbstractField()
    name = field('user.full_name')
    assert name
    assert len(name) > 0

# Generated at 2022-06-12 02:54:00.311440
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    # test for UnsupportedField
    with pytest.raises(UnsupportedField):
        field('foo')

    # test for UndefinedField
    with pytest.raises(UndefinedField):
        field()

    # test for UndefinedProvider
    with pytest.raises(UndefinedProvider):
        field('foo.bar.baz')

    # test for method which not exist
    with pytest.raises(KeyError):
        field('foo.bar')



# Generated at 2022-06-12 02:54:08.195597
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert callable(field)

    assert field('name') == 'Michael'
    assert field('name', gender='male') == 'Richard'
    assert field('full_name', gender='female') == 'Annabella'

    assert field('datetime', end='2010-01-01') != \
        field('datetime', end='2011-01-01')

    assert field('name', key=lambda x: x.capitalize()) == 'Michael'
    assert field('full_name', key=lambda x: x.capitalize()) == 'Annabella'

    assert field('name', p_provider='foods') == 'bagel'

    assert field('integer', minimum=-10, maximum=0) < 0
    assert field('integer', minimum=-10, maximum=0) >= -10


# Generated at 2022-06-12 02:55:03.102666
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Simple unit test for AbstractField.__call__()

    Test will pass if **field()** return string (if **name** is **text**)
    or integer (if **name** is **integer**).
    """
    field = AbstractField()

    # Test case 1 - text
    assert isinstance(field('text'), str)

    # Test case 2 - integer
    assert isinstance(field('integer'), int)