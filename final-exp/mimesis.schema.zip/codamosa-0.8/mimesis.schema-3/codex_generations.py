

# Generated at 2022-06-12 02:52:07.011729
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    f = Field()
    assert f('code.source') == '1234567890'

# Generated at 2022-06-12 02:52:09.597952
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-12 02:52:14.791764
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test __call__ method."""
    field = Field()

    try:
        field()
    except UndefinedField:
        return field(name='word')



# Generated at 2022-06-12 02:52:18.368827
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for class `AbstractField`.

    It's weird but I didn't find any better way to test
    constructor of class AbstractField.

    :return: None
    """
    obj = AbstractField()
    assert isinstance(obj, AbstractField)



# Generated at 2022-06-12 02:52:25.927825
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('integer', minimum=0, maximum=10) < 11
    assert field('person.full_name')
    assert field('person.full_name', first_name='John', last_name='Smith') == \
        'John Smith'
    assert 'John' in field('person.full_name', full_name='John Doe')
    assert len(field('person.full_name', full_name='John Doe')) > 0

# Generated at 2022-06-12 02:52:33.851016
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    handle = AbstractField()
    assert handle('food') == 'Food'
    assert handle('text') != ''
    assert len(handle('text')) == 10
    assert handle('food') == 'Food'
    assert len(handle('food')) == 4
    assert handle('text', length=20) != ''
    assert len(handle('text', length=20)) == 20
    assert handle('food', key=lambda x: len(x)) == 4
    assert handle('choice', [1, 2, 3]) in [1, 2, 3]
    assert len(handle('data.full_name')) > 7
    assert len(handle('data.full_name')) < 20



# Generated at 2022-06-12 02:52:37.093735
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('uuid')

# Generated at 2022-06-12 02:52:38.586016
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for class AbstractField."""
    f = AbstractField()
    assert isinstance(f, AbstractField)

# Generated at 2022-06-12 02:52:39.484906
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert AbstractField


# Generated at 2022-06-12 02:52:41.593239
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of abstract field."""
    field = AbstractField()
    assert isinstance(field, AbstractField)



# Generated at 2022-06-12 02:53:02.719406
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-12 02:53:04.505015
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field('fr')
    assert field.locale == 'fr'
    assert isinstance(field._gen, Generic)



# Generated at 2022-06-12 02:53:12.199459
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    assert field('str.ascii.word') == 'fPysqm'
    assert field('str.ascii.word', 3) == 'ZwN'

    assert field('str.word', 3) == 'qEw'

    assert field('str.roman.numeral', key='str.word') == 'you'

    data = field('datetime.datetime', 'ed', 'in', end='2016-12-12')
    assert type(data) == str
    assert len(data) == 10



# Generated at 2022-06-12 02:53:13.991917
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field is not None

# Generated at 2022-06-12 02:53:14.535689
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()

# Generated at 2022-06-12 02:53:16.900224
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField(locale='en')
    print(abstract_field('my_name'))

# Generated at 2022-06-12 02:53:19.355035
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test SimpleField."""
    schema = Field()
    result = schema('code.isbn', length=13)
    assert len(result) == 13

# Generated at 2022-06-12 02:53:20.822452
# Unit test for constructor of class AbstractField
def test_AbstractField():
    gen = Generic()
    f = AbstractField(Generic, gen)
    assert isinstance(f, AbstractField)

# Generated at 2022-06-12 02:53:21.862069
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert isinstance(field('token', length=10), str)

# Generated at 2022-06-12 02:53:33.070237
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for __call__ method.

    AbstractField._AbstractField__call__(
        name: str, key: Optional[Callable] = None, **kwargs
    )
    """
    field = Field()
    assert field('__doc__') == Generic.__doc__
    assert field('uuid') != field('uuid')

    assert not callable(field('uuid'))
    assert callable(field('uuid'))
    assert callable(field('uuid', 'uuid4'))

    # Test for providers with equal functions
    assert field('user_agent') != field('user_agent', 'safari')
    assert field('user_agent', 'safari') == field(
        'user_agent', 'safari', provider='system')