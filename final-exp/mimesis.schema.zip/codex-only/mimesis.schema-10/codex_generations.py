

# Generated at 2022-06-23 22:04:38.140384
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:04:39.630313
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {}
    assert len(Schema(schema).create(10)) == 10



# Generated at 2022-06-23 22:04:47.711824
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    test = Field()
    assert test('choice', [1, 2, 3]) in (1, 2, 3)
    assert test('name')
    assert test('address')
    assert test('name.first_name')
    assert test('datetime.datetime')
    assert test('datetime.date')
    assert test('datetime.time')
    assert test('datetime.timestamp')
    assert test('random.integer') == test('random__integer') == test('random.seed') == test('random__seed')
    assert test('random.boolean') is False or test('random.boolean') is True
    assert test('random.hexadecimal')
    assert test('random.alpha')
    assert test('random.float')
    assert test('random.decimal')
    assert test('random.uuid4')
   

# Generated at 2022-06-23 22:04:49.584760
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    test_field = AbstractField(locale='en')
    assert str(test_field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:04:53.979818
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of class Schema."""
    schema = Schema(lambda: {"name": "John", "age": 18})
    assert schema.create(3) == [{'name': 'John', 'age': 18},
                                {'name': 'John', 'age': 18},
                                {'name': 'John', 'age': 18}]

# Generated at 2022-06-23 22:04:54.697102
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-23 22:04:56.353282
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {}

    s = Schema(schema)
    assert s.schema == schema

# Generated at 2022-06-23 22:04:57.356420
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()  # noqa

# Generated at 2022-06-23 22:05:04.207441
# Unit test for method create of class Schema
def test_Schema_create():
    """Test class Schema."""
    schema = Schema(lambda: {
        'first_name': Field('person.full_name'),
        'age': Field('datetime.age'),
        'birth_date': Field('datetime.datetime'),
        'salary': Field('economic.money'),
    })

    result = schema.create(5)
    assert len(result) == 5
    assert isinstance(result[0], dict)



# Generated at 2022-06-23 22:05:06.573315
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField(locale='en')
    result = str(f)
    assert result == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:12.710547
# Unit test for method create of class Schema
def test_Schema_create():
    """Schema.create()."""
    from mimesis import Address, Datetime

    def schema():
        return {
            'number': Address('en').street_number(),
            'name': Address('en').street_name(),
            'updated_at': Datetime('en').timestamp(),
        }

    data = Schema(schema).create(10)
    assert len(data) == 10

# Generated at 2022-06-23 22:05:21.101486
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()

    result = field('title')
    assert result is not None

    # Test for method with unsupported provider
    try:
        field('unsupported.method')
    except UnsupportedField:
        assert True
    else:
        assert False

    # Test for method with unsupported provider (without provider name)
    try:
        field('unsupported_method')
    except UnsupportedField:
        assert True
    else:
        assert False

    # Test for method in method dot symbol
    try:
        field('code.zip.code')
    except UnacceptableField as e:
        assert True
    else:
        assert False

    # Test for method with key function

# Generated at 2022-06-23 22:05:22.598318
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:24.112813
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('uuid') == field.uuid()



# Generated at 2022-06-23 22:05:26.469244
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert isinstance(field, AbstractField)
    assert field.locale == 'en'


# Generated at 2022-06-23 22:05:30.253104
# Unit test for constructor of class Schema
def test_Schema():
    import mimesis.enums
    from mimesis.schema import Schema

    schema = lambda: {
        'a': mimesis.enums.Gender.MALE,
        'b': mimesis.enums.Gender.FEMALE,
    }

    g = Schema(schema)
    assert g.create(3) == [
        {'a': 'male', 'b': 'female'},
        {'a': 'male', 'b': 'female'},
        {'a': 'male', 'b': 'female'},
    ]


if __name__ == '__main__':
    test_Schema()
    print('OK')

# Generated at 2022-06-23 22:05:35.702843
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    schema = {}
    provider = 'internet'
    method = 'password'
    keyword = 'size'
    value = 16
    schema[method] = {keyword: value}
    field = AbstractField()
    assert field(provider + '.' + method, **schema[method])



# Generated at 2022-06-23 22:05:37.847313
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    text = Field()
    assert text('sentence', amount=5) == 'Labore quisquam.'

# Generated at 2022-06-23 22:05:43.551768
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method Schema.create."""
    def schema():
        return {
            'title': str(field('words', quantity=2)),
            'text': str(field('text')),
        }

    schema = Schema(schema)
    assert isinstance(schema.create(iterations=2), list)
    assert len(schema.create(iterations=2)) == 2
    assert isinstance(schema.schema(), dict)

# Generated at 2022-06-23 22:05:51.926832
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    # test with undefined field
    assert field('not_exists') == UndefinedField()

    # test with unsupported field
    assert field('hexadecimal') == UnsupportedField('hexadecimal')

    # test with field from first provider
    assert field('word') != UndefinedField()
    assert field('word') != UnsupportedField('word')
    assert field('word')

    # test with field from specific provider
    assert field('choice') != UndefinedField()
    assert field('choice') != UnsupportedField('choice')
    assert field('choice')

    # test with method from specific provider
    assert field('person.full_name') != UnsupportedField('person.full_name')
    assert field('person.full_name')

    # test with method from specific provider which has the same name
    # as

# Generated at 2022-06-23 22:05:58.369023
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field
    from mimesis.providers.address import Address

    address = Address('en')

    class AddressSchema:

        @staticmethod
        def city(field: Field) -> str:
            return field('city')

        @staticmethod
        def street(field: Field) -> str:
            return field('street_address')

        @staticmethod
        def full_address(field: Field) -> str:
            return field('full_address')

    schema = Schema(AddressSchema)
    addresses = schema.create(iterations=5)

    assert len(addresses) == 5

# Generated at 2022-06-23 22:06:09.639069
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    with open('tests/data/schema/test_schema.json', 'r') as f:
        test_schema = f.read()

    # Testing with locale
    locale_field = AbstractField(locale='ru')
    assert locale_field('address.address') == 'Ул. Красная, дом 36'

    # Testing without locale
    no_locale_field = AbstractField()
    assert no_locale_field('address.address') == '12th St.'

    # Testing with seed
    seed_field = AbstractField(seed=1234567890)
    assert seed_field('address.address') == '12th St.'

    # Testing with locale and seed

# Generated at 2022-06-23 22:06:11.403577
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    locale = 'ru'
    seed = 'seed'
    providers = None
    field = Field(locale, seed, providers)
    assert field.locale == locale
    assert field.seed == seed

# Generated at 2022-06-23 22:06:12.671329
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    result = field('timezone')
    assert result

    result = field('vehicle.model')
    assert result

# Generated at 2022-06-23 22:06:13.705577
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field(locale='en')
    assert str(f) == 'AbstractField <en>'



# Generated at 2022-06-23 22:06:15.239584
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema
    Schema([])

# Generated at 2022-06-23 22:06:16.458479
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(dict).create()) != 0

# Generated at 2022-06-23 22:06:18.061435
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    instance = Field()
    assert isinstance(instance, AbstractField)
    assert isinstance(instance, Field)


# Generated at 2022-06-23 22:06:25.496623
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    def schema_0() -> JSON:
        """Create a simple schema."""
        return {
            'name': '{name}',
            'last_name': '{last_name}',
            'address': '{address}'
        }

    def schema_1() -> JSON:
        """Create a schema with interactions."""
        return {
            'name': '{name}',
            'last_name': '{last_name}',
            'address': '{address}',
            'full_name': lambda x: f'{x["name"]} {x["last_name"]}',
        }

    person = Person('ru')

# Generated at 2022-06-23 22:06:29.710333
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema
    from mimesis.exceptions import UndefinedSchema

    def schema():
        return {'name': 'John Doe'}

    assert isinstance(Schema(schema), Schema)
    assert True is UndefinedSchema, UndefinedSchema



# Generated at 2022-06-23 22:06:32.410322
# Unit test for method create of class Schema
def test_Schema_create():
    assert Schema(
        lambda: {'name': 'Jane', 'surname': 'Doe'}
    ).create() == [{'name': 'Jane', 'surname': 'Doe'}]

# Generated at 2022-06-23 22:06:34.325880
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = Field()
    assert field


# Generated at 2022-06-23 22:06:35.933203
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(providers=['person'])
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:37.080062
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        Field()
    except Exception:
        assert False



# Generated at 2022-06-23 22:06:38.039001
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert AbstractField()('json.boolean') is False
    assert callable(AbstractField.__call__) is True

# Generated at 2022-06-23 22:06:39.329990
# Unit test for constructor of class Schema
def test_Schema():
    pass

if __name__ == '__main__':
    test_Schema()

# Generated at 2022-06-23 22:06:42.087237
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>', 'Should be en'
    field = Field('ru')
    assert str(field) == 'AbstractField <ru>', 'Should be ru'

# Generated at 2022-06-23 22:06:45.166722
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    af = AbstractField()
    result = af.__str__()
    assert result == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:46.833235
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('personal.full_name') is not None

# Generated at 2022-06-23 22:06:48.810537
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'



# Generated at 2022-06-23 22:06:57.005761
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    # Test for correct value
    assert field('datetime.datetime') is not None
    assert field('datetime.datetime', year=2019) is not None

    # Test for correct value with provider name
    assert field('datetime.datetime', provider='time') is not None
    assert field('datetime.datetime',
                 provider='time', year=2019) is not None

    # Test for wrong value
    assert field('wrong.value') is None

    # Test for wrong value with provider name
    assert field('wrong.value', provider='time') is None

    # Test for wrong value without provider name but with dot
    assert field('datetime.datetime.wrong') is None

    # Test for wrong value with provider name but with dot

# Generated at 2022-06-23 22:07:05.021690
# Unit test for method create of class Schema
def test_Schema_create():
    # Note: in this test we are not going to test data
    # generators, just their usage here
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('ru')
    schema = {'name': 'person.full_name',
              'phone': 'person.telephone',
              'gender': lambda: person.gender(gender=Gender.MALE)}
    s = Schema(schema)
    result = s.create(5)
    assert isinstance(result, list)
    assert len(result) == 5
    assert isinstance(result[0], dict)


# Generated at 2022-06-23 22:07:10.707083
# Unit test for method create of class Schema
def test_Schema_create():
    """Test Schema.create method."""
    import mimesis.generic

    schema = Schema(mimesis.generic.JSONSchema({}))
    result = schema.create()
    assert isinstance(result, list)

    result = schema.create(2)
    assert len(result) == 2
    assert isinstance(result, list)

# Generated at 2022-06-23 22:07:16.608561
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender

    def schema() -> JSON:
        from mimesis.schema import Field

        return {
            'name': Field('name', gender=Gender.MALE),
            'surname': Field('surname'),
        }

    # Create a Schema instance
    s = Schema(schema)
    # Create 10 filled schemas
    r = s.create(10)

    assert len(r) == 10

# Generated at 2022-06-23 22:07:26.004042
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field(providers=[0, 1])
    assert field('choice', [0, 1]) == 1

    field = Field(providers=[0, 1])
    assert field('choice', [0, 1], key=str) == '1'

    field = Field(providers=[0, 1])
    assert field('choice', [0, 1], seed=3) == 0

    field = Field(providers=[0, 1])
    assert field('choice', [0, 1], seed=3, key=str) == '0'

    field = Field(providers=[0, 1])
    assert field('choice', [0, 1], key=str, seed=None) == '1'

    field = Field(providers=[0, 1])

# Generated at 2022-06-23 22:07:29.532805
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField."""
    f = Field()
    assert f('person.full_name')  # noqa: F841
    try:
        f('person')
        assert False
    except UndefinedField:
        assert True
    except Exception:  # noqa: B001
        assert False

# Generated at 2022-06-23 22:07:36.300325
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    obj = AbstractField()

# Generated at 2022-06-23 22:07:39.770293
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test of __str__ method of AbstractField."""
    a = AbstractField()
    expected_result = "AbstractField <{}>".format('en')
    assert str(a) == expected_result

# Generated at 2022-06-23 22:07:44.523779
# Unit test for constructor of class Schema
def test_Schema():
    def schema_func():
        return {'my': 'schema'}
    schema = Schema(schema_func)
    assert schema.create() == [{'my': 'schema'}]
    assert schema.create(3) == [
        {'my': 'schema'},
        {'my': 'schema'},
        {'my': 'schema'},
    ]

# Generated at 2022-06-23 22:07:45.288326
# Unit test for constructor of class Schema
def test_Schema():
    pass


# Generated at 2022-06-23 22:07:47.281824
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    s = 'Field <en>'
    result = f.__str__()
    assert result == s

# Generated at 2022-06-23 22:07:50.752438
# Unit test for constructor of class Schema
def test_Schema():
    def my_schema():
        return {'name': 'John'}

    s = Schema(my_schema)
    assert s.schema() == my_schema()



# Generated at 2022-06-23 22:07:55.723765
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'uuid': Field()('uuid'),
            'person.full_name': Field()('person.full_name'),
            'person.email': Field()('person.email'),
            'datetime.datetime_now': Field()('datetime.datetime_now'),
        }

    schema = Schema(schema)
    assert isinstance(schema.create(iterations=5), list)

# Generated at 2022-06-23 22:08:05.340070
# Unit test for constructor of class Schema
def test_Schema():
    # pylint: disable=protected-access
    from mimesis.builtins import DataSpecProvider
    from mimesis.providers import Internet

    schema = Schema(lambda: {'age': 42, 'name': 'John'})
    data = schema.create(1)
    assert data == [{"age": 42, "name": "John"}]

    schema = Schema(lambda: {'age': 42, 'name': 'John'})
    data = schema.create()
    assert data == [{'age': 42, 'name': 'John'}]

    schema = Schema(lambda: {'age': 42, 'name': 'John'})
    data = schema.create(2)

# Generated at 2022-06-23 22:08:07.460415
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField(_locale='en')
    assert f._gen.locale == 'en'



# Generated at 2022-06-23 22:08:11.051549
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen.locale == 'en'
    assert field._gen.seed is None
    assert field._table == {}

# Generated at 2022-06-23 22:08:13.342866
# Unit test for constructor of class Schema
def test_Schema():
    data = {'a': 1}

    def schema():
        return data

    s = Schema(schema)
    assert s.create() == [data]

# Generated at 2022-06-23 22:08:22.327907
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field
    from mimesis.providers.address import Address

    sch = Schema(lambda: {
        'name': Field('personal.full_name'),
        'address': Field('address.full_address')
    })

    result = sch.create(iterations=3)

    assert 'name' in result[0]
    assert 'address' in result[0]

    assert isinstance(result[0]['name'], str)
    assert isinstance(result[0]['address'], str)

    sch = Schema(lambda: {
        'name': Field('personal.full_name'),
        'address': Field('address.full_address', key=lambda x: Address(locale='en').full_address())
    })


# Generated at 2022-06-23 22:08:29.636931
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema.factory import Factory as SchemaFactory
    Field = AbstractField
    Schema = SchemaFactory(Field)

    def person_schema():
        return """
        {{
            "name": {name},
            "surname": {surname},
            "age": {age}
        }}
        """
    person = Schema(person_schema)
    people = person.create(iterations=5)
    assert isinstance(people, list)
    assert len(people) == 5



# Generated at 2022-06-23 22:08:31.492812
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    result = str(AbstractField())
    assert result == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:32.558265
# Unit test for constructor of class Schema
def test_Schema():
    pass

# Generated at 2022-06-23 22:08:41.137259
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for :func:`~mimesis.schema.Schema.create`."""
    from mimesis.providers.web import Web
    from mimesis.schema import Field

    def my_schema() -> JSON:
        _ = Field('en')
        return {
            'foo': _('random_int', a=1, b=10),
            'bar': _('url'),
            'baz': _('word'),
        }

    s = Schema(my_schema)
    assert len(s.create(iterations=10)) == 10

    s = Schema(my_schema)
    s._gen.add_providers(Web)
    assert len(s.create(iterations=10)) == 10

# Generated at 2022-06-23 22:08:52.156519
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.address import Address
    t = AbstractField()
    assert callable(t)

    with seed(seed=42):
        t = AbstractField(seed=42)
        f = t('full_name')
        assert f.split()[0] == 'Marquise'

        f = t('full_name')
        assert f.split()[0] == 'Marquise'

    with seed(seed=42):
        t = AbstractField(seed=42)
        f = t('full_name')
        assert f.split()[0] == 'Marquise'

    with seed(seed=42):
        t = AbstractField(seed=42)
        f = t('address.city')
        assert f.split()[0] == 'Gulberg'


# Generated at 2022-06-23 22:08:59.318501
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create."""
    md = Field(locale='it')  # type: ignore

    schema = {
        'person': {
            'name': md('name.full_name'),
            'generic': {
                'example': md('text.word'),
            },
        },
    }

    result = Schema(schema).create(iterations=1)
    assert result == [{'person': {
        'name': 'Antonio Guarini', 'generic': {'example': 'velit'}}}]

# Generated at 2022-06-23 22:09:02.244857
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    _ = AbstractField()
    assert _ == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:06.147183
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = Field()
    # This method actually exists
    assert abstract_field('choice', [1, 2, 3]) in [1, 2, 3]

    # This method doesn't exist
    try:
        abstract_field('_')
        assert False
    except UnsupportedField:
        assert True

# Generated at 2022-06-23 22:09:15.522346
# Unit test for method create of class Schema
def test_Schema_create():
    data = {'freelance': {'email': 'freelance@gmail.com', 'phone': '75218471464'},
            'name': {'first': 'Максим', 'last': 'Тимощук'}}
    schema = Field(locale='ru')
    sch = Schema(lambda: {
        'freelance': {
            'email': schema('email', domain='gmail.com'),
            'phone': schema('phone', mask='+7### ## ## ###'),
        },
        'name': {
            'first': schema('first_name'),
            'last': schema('last_name'),
        }
    })
    result = sch.create(iterations=1)[0]

    assert data == result

# Generated at 2022-06-23 22:09:18.331683
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField.

    Test method __str__ of class AbstractField.
    """
    field = Field('ru')
    assert "Field <ru>" == field.__str__()

# Generated at 2022-06-23 22:09:20.506235
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert isinstance(str(field), str) is True
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:27.261432
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet

    def schema():
        return {
            'firstname': Address.get_first_name(gender='female'),
            'lastname': Address.get_last_name(),
            'age': Internet.get_age(),
        }

    data = Schema(schema).create()
    assert len(data) == 1

# Generated at 2022-06-23 22:09:29.716893
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for AbstractField.__str__()."""
    assert str(AbstractField(locale='ru')) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:09:31.725299
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema constructor."""
    s = Schema(dict)
    assert s.schema == dict

# Generated at 2022-06-23 22:09:40.194421
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    from mimesis.providers.datetime import Datetime

    locale = 'en'
    seed = 12345
    dt = Datetime()
    field = AbstractField(locale, seed, [dt])

    # We can get the same value by calling the method directly with
    # the same seed
    assert field('datetime.datetime', seed=seed) == dt.datetime(seed=seed)

    # We have not parameter *name* so it should raise error
    raised = False
    try:
        field()
    except UndefinedField:
        raised = True

    assert raised

    # If we have two methods with the same name,
    # which belong to different data providers
    # then we get the data from the first data provider
    raised = False

# Generated at 2022-06-23 22:09:49.892198
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': str,
        'age': int,
    }

    test_schema = Schema(schema)


# Generated at 2022-06-23 22:09:52.421673
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check that `__str__` method works correctly."""
    f = Field()
    result = str(f)
    assert result == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:58.828728
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.address import Address

    address = Address('ru')
    f = Field(providers=[address])

    def schema() -> dict:
        """Example schema."""
        return {
            'country_code': f('country_code'),
            'region': f('region'),
            'city': f('city'),
            'zip_code': f('zip_code'),
            'address': f('address'),
        }

    s = Schema(schema)
    data = s.create(3)
    assert len(data) == 3



# Generated at 2022-06-23 22:10:09.695194
# Unit test for method create of class Schema
def test_Schema_create():
    import json
    # Test with default value for iterations
    schema = Schema(lambda: {'person': {'name': 'Albert Einstein'}})
    result = schema.create()
    assert isinstance(result, list)
    assert len(result) == 1
    assert isinstance(result[0], dict)
    assert result[0] == {'person': {'name': 'Albert Einstein'}}

    # Test with iterations = 2
    schema = Schema(lambda: {'first_name': 'Albert', 'last_name': 'Einstein'})
    result = schema.create(iterations=2)
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], dict)
    assert isinstance(result[1], dict)

# Generated at 2022-06-23 22:10:18.829364
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.internet import Internet
    from mimesis.providers.address import Address

    class DerivedSchema(Schema):
        name = Field()
        password = Field()

        def __call__(self) -> JSON:
            return {
                'name': self.name,
                'password': self.password,
            }

    class DerivedField(AbstractField):
        def __init__(self, *args, **kwargs):
            providers = [
                Internet(),
                Address('en'),
            ]
            super().__init__(*args, providers=providers, **kwargs)

    class DerivedUser(DerivedSchema):
        name = DerivedField()
        password = DerivedField()

    user = DerivedUser()
    result = user.create(1)

# Generated at 2022-06-23 22:10:29.529805
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Create object and check the input of this object
    field = Field()

    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen.locale == 'en'
    assert field._gen.seed is None
    assert field._table == {}

    # Create object with locale and seed
    locale = 'ru'
    seed = '123456789'

    field = Field(locale=locale, seed=seed)

    assert field.locale == locale
    assert field.seed == seed
    assert field._gen.locale == locale
    assert field._gen.seed == seed
    assert field._table == {}

    field.__call__('last_name')
    field.__call__('last_name')

    # Create object with providers

# Generated at 2022-06-23 22:10:31.664604
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f is not None

# Generated at 2022-06-23 22:10:42.126307
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema, Field
    from mimesis.enums import Gender
    from mimesis.providers.address import Address

    f = Field(locale='en',
              providers=[Address])

    def user_schema():
        """Test schema."""
        return {
            'name': '{} {}'.format(f.human.name(gender=Gender.MALE),
                                   f.human.surname()),
            'address': f.address.street_address(),
            'phone': f.address.phone_number(),
            'email': '{}@{}.com'.format(
                f.personal.username(), f.internet.domain_name()),
            'age': f.person.age(),
            'sex': Gender.MALE,
        }


# Generated at 2022-06-23 22:10:52.938158
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    from mimesis import Person
    from mimesis.enums import Gender

    f = Field(locale='ru', seed=123)
    assert f.locale == 'ru'
    assert f.seed == 123

    assert f('name') == 'Василий'
    assert f('name', key=str.lower) == 'василий'
    assert f('name', gender=Gender.MALE) == 'Василий'
    assert f('name', gender=Gender.FEMALE) == 'Анна'

    p = Person('ru')
    assert f('person.full_name') == p.full_name()

    # With providers

# Generated at 2022-06-23 22:10:56.164920
# Unit test for constructor of class Schema
def test_Schema():  # noqa: WPS437
    from mimesis.types import JSON

    def schema() -> JSON:
        return {'key': 'value'}

    test_object = Schema(schema)

    assert test_object.schema() == {'key': 'value'}

# Generated at 2022-06-23 22:11:04.108812
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    assert field('foo') == 'foo'
    assert field('datetime.datetime_now') != ''
    assert field(key=str, name='foo').isalpha()
    assert field('datetime.datetime_now', key=str) != ''
    assert field(
        'datetime.datetime_now',
        key=str, format_='%Y-%m-%d',
    ).isdigit()

# Generated at 2022-06-23 22:11:06.828852
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField('en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:08.991016
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField) is True
    assert isinstance(Field('en'), AbstractField) is True
    assert isinstance(Field('en', seed=111), AbstractField) is True

# Generated at 2022-06-23 22:11:10.499591
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check type of __str__ of class AbstractField."""
    assert isinstance(str(AbstractField()), str)

# Generated at 2022-06-23 22:11:18.517605
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for AbstractField.__call__."""
    f = AbstractField()
    assert callable(f)

    assert f('timestamp') >= 0
    assert f('timestamp') < f('timestamp')

    assert isinstance(f('choice'), str)
    assert f('quantifier', min_value=10) >= 10
    assert f('quantifier', max_value=10) <= 10

    assert f('choice', list_of_items=['a', 'b', 'c']) in ['a', 'b', 'c']

    assert f('quantifier', key=lambda x: x**2, min_value=1, max_value=5) >= 1 ** 2
    assert f('quantifier', key=lambda x: x**2, min_value=1, max_value=5) <= 5 ** 2

# Generated at 2022-06-23 22:11:26.391176
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> JSON:
        def _schema() -> JSON:
            return {
                'first_name': Field().person.full_name(),
                'age': Field().person.age(start=18, end=65),
                'address': Field().address.address(),
            }
        return _schema()

    for item in Schema(schema).create(2):
        assert isinstance(item, dict)
        assert isinstance(item['first_name'], str)
        assert isinstance(item['age'], int)
        assert isinstance(item['address'], str)

# Generated at 2022-06-23 22:11:32.878183
# Unit test for constructor of class Schema
def test_Schema():
    test_schema = {
        'name': 'John Doe',
        'phone': '123-456-789',
        'address': {
            'street': 'Main Street',
            'house': '10'
        }
    }

    def my_schema() -> JSON:
        return test_schema

    s = Schema(my_schema)
    assert s.create()[0] == test_schema

# Generated at 2022-06-23 22:11:35.230061
# Unit test for method create of class Schema
def test_Schema_create():
    field = AbstractField()
    schema = Schema(lambda: {'id': field.random.uuid4()})

    for item in schema.create(5):
        assert len(item) == 1
        assert 'id' in item

# Generated at 2022-06-23 22:11:37.321432
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()

    from mimesis.builtins import RussiaSpecProvider

    f = Field(seed='test', providers=(RussiaSpecProvider(), ))
    assert f._table == {}



# Generated at 2022-06-23 22:11:47.886254
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test __call__ of class AbstractField."""
    obj = Field()
    assert obj('ascii_letters')
    assert obj('ascii_set', set_len=2)
    assert obj('md5', digits=10)
    assert obj('sha1', digits=12)
    assert obj('sha256', digits=16)
    assert obj('sha512', digits=32)
    assert obj('ascii_letters', range_=10)
    assert obj('ascii_letters', start=1, stop=100)
    assert obj('ascii_letters', range_=(20, 30))
    assert obj('random_letter', pool='asdfg')
    assert obj('random_number', pool='1234567890')

# Generated at 2022-06-23 22:11:48.575892
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        pass

    assert Schema(schema)

# Generated at 2022-06-23 22:11:52.136198
# Unit test for constructor of class Schema
def test_Schema():
    assert callable(Schema)
    assert len(Schema.__code__.co_varnames) == 1
    assert Schema.__code__.co_varnames[0] == 'schema'



# Generated at 2022-06-23 22:11:58.689861
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.typing import AnySchema

    def my_schema() -> AnySchema:
        return {
            'foo': 'bar',
            'baz': 1239,
            'buzz': 'fuz',
        }

    schema = Schema(my_schema)
    result = schema.create(iterations=5)

    assert isinstance(result, list)
    assert len(result) == 5

# Generated at 2022-06-23 22:12:03.332403
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    from mimesis.builtins import RussiaSpecProvider

    f = Field(providers=[RussiaSpecProvider])
    assert f('name') in RussiaSpecProvider.Meta.name
    assert f('name.fullname') == RussiaSpecProvider.Meta.fullname

# Generated at 2022-06-23 22:12:05.103150
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField __call__ method."""
    field = Field()
    assert field('username') == field('username')

# Generated at 2022-06-23 22:12:09.785602
# Unit test for constructor of class Schema
def test_Schema():
    # __init__()
    schema = Schema(JSON)
    schema = Schema(lambda: {})
    schema = Schema(lambda: [])
    try:
        Schema({})  # type: ignore
    except UndefinedSchema:
        pass

# Generated at 2022-06-23 22:12:11.112501
# Unit test for constructor of class AbstractField
def test_AbstractField():
    obj = AbstractField()
    assert str(obj) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:15.792904
# Unit test for method create of class Schema
def test_Schema_create():
    schema = lambda: {
        'string': 'Hello world',
        'integer': 2,
        'float': 1.3,
        'list': [1, 2, 3]
    }
    data = Schema(schema).create(2)
    assert len(data) == 2
    assert data[0]['string'] == 'Hello world'

# Generated at 2022-06-23 22:12:17.299781
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    obj = Field(locale='ru', seed=42)
    assert str(obj) == 'Field <ru>'

# Generated at 2022-06-23 22:12:28.249949
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test call method."""
    f = Field()
    assert f('personal.full_name') == 'James Chapman'

    f = Field(locale='ru')
    assert f('personal.full_name') == 'Михаил Николаев'

    assert f('something_bad') == 'Something bad data provider.'
    assert f('something_bad', 'key', **{'base': '0123456789'}) == 'Something bad data provider.'

    assert f('something_bad', 'key', **{'base': '0123456789'}) == 'Something bad data provider.'
    assert f('something_bad', 'key', **{'base': '0123456789'}) == 'Something bad data provider.'


# Generated at 2022-06-23 22:12:39.102121
# Unit test for constructor of class AbstractField
def test_AbstractField():
    import pytest
    from mimesis.typing import DataProvider
    from mimesis.providers.code import Code
    from mimesis.providers.geography import Geography

    class MyProviders(DataProvider):
        """Test class for adding custom providers."""

        def __init__(self, locale: str = 'en') -> None:
            """Initialize attributes."""
            super().__init__(locale)

    def test_gen_object():
        field = AbstractField()
        assert isinstance(field._gen, Generic)

    field = AbstractField()


# Generated at 2022-06-23 22:12:44.459488
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    def func(text):
        return 'test {}'.format(text)

    af = AbstractField()
    af.create_provider('test', 'mimesis.providers.generic.generic')
    assert af('test_field') == 'test'
    assert af('test.test_field') == 'test'
    assert af('test.test_field', key=func) == 'test test'
    assert af('test_field', key=func) == 'test test'

# Generated at 2022-06-23 22:12:50.352258
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers import Person

    class PetSchema:
        def __init__(self):
            self.person = Person('en')

        def __call__(self):
            return {
                'name': 'Dog',
                'owner': self.person.full_name()
            }

    schema = Schema(PetSchema)
    result = schema.create(iterations=2)

    assert result, 'Result must be not empty'

# Generated at 2022-06-23 22:12:53.542973
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()  # type: ignore
    result = field('uuid4', upper=False)
    assert isinstance(result, str) and len(result) == 36

# Generated at 2022-06-23 22:13:00.086360
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test class AbstractField."""
    from mimesis.exceptions import UnsupportedField

    field = Field('hu')
    assert field.locale == 'hu'
    assert callable(field)

    # Unsupported provider
    field = Field('hu', providers=[])
    with UnsupportedField.raised(field, 'person'):
        field('person.full_name')

# Generated at 2022-06-23 22:13:08.803767
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.enums import Gender
    from mimesis.schema import Field
    from mimesis.providers.person import Person

    f = Field(locale='en', seed=42, providers=[Person])

    schema = Schema(lambda: {
        'name': f('person.full_name'),
        'age': f('person.age', minimum=10),
        'gender': f('person.gender', ratio=[3, 1]),
    })

    assert schema.schema() == {
        'name': 'Jasmine Blevins',
        'age': 19,
        'gender': Gender.FEMALE,
    }

# Generated at 2022-06-23 22:13:12.279214
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    field = AbstractField()

    # This is a fake method
    def fake_method() -> str:
        return 'fake'

    field._gen.fake = fake_method

    assert field('fake') == 'fake'

# Generated at 2022-06-23 22:13:13.919255
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()

    assert str(field) == 'AbstractField <en>'


# Generated at 2022-06-23 22:13:16.822440
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        field = AbstractField()
    except Exception:
        assert False
    else:
        assert field

# Generated at 2022-06-23 22:13:18.380668
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test the method __str__ of AbstractField."""
    field = Field()
    assert isinstance(str(field), str)



# Generated at 2022-06-23 22:13:21.868260
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field_object = AbstractField()

    assert isinstance(field_object, AbstractField)
    assert isinstance(field_object, Generic)
    assert isinstance(field_object, object)
    assert hasattr(field_object, '__call__')
    assert hasattr(field_object, '__str__')


# Generated at 2022-06-23 22:13:22.874197
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(dict).create(100)) == 100

# Generated at 2022-06-23 22:13:29.958116
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Test for unsupported provider
    field = Field()
    try:
        field('fake.method')
    except UnsupportedField as error:
        assert error.args[0] == 'fake.method'

    # Test for unacceptable field
    field = Field()
    try:
        field('datetime.datetime.time')
    except UnacceptableField as error:
        assert str(error) == 'Attempt to get a method \'time\' ' \
                             'from \'datetime.datetime\' provider.'

    # Test for undefined field
    try:
        field()
    except UndefinedField:
        pass



# Generated at 2022-06-23 22:13:31.150728
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test class AbstractField."""
    field = Field()

    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:13:33.711612
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import SchemaType

    def schema() -> SchemaType:
        return {
            'string': str,
            'number': int,
        }

    fields = Schema(schema)

    assert fields is not None



# Generated at 2022-06-23 22:13:36.595004
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:41.088719
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema() -> JSON:
        """Test schema."""
        return {
            'name': 'John',
            'age': 10,
        }

    schema = Schema(test_schema)
    assert schema.create() == [{'name': 'John', 'age': 10}]

    schema = Schema(test_schema, )

# Generated at 2022-06-23 22:13:42.096176
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for abstract field constructor."""
    result = Field()
    assert result is not None



# Generated at 2022-06-23 22:13:43.712020
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""



# Generated at 2022-06-23 22:13:46.838703
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    field = AbstractField(locale='ru')
    result = field('full_name')
    assert result is not None



# Generated at 2022-06-23 22:13:52.949651
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.file import FileSystem

    fs = FileSystem('en')
    schema = {
        'name': fs.file_name('*.py'),
        'size': fs.size(size_from=10, size_to=20),
    }

    manager = Schema(schema)
    data = manager.create(iterations=10)

    assert isinstance(data, list)
    assert len(data) == 10

# Generated at 2022-06-23 22:13:58.260490
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema():
        return {
            'id': 1,
            'name': 'Test',
            'country': 'Ukraine'
        }

    s = Schema(test_schema)
    assert list == type(s.create())
    assert dict == type(s.create()[0])



# Generated at 2022-06-23 22:14:08.603179
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method `create` of class `Schema`."""
    schema = [
        ('name', str),
        ('surname', str),
        ('age', int),
        ('height', float),
        ('sex', bool),
    ]
    s = Schema(lambda: {key: value() for key, value in schema})
    result = s.create()
    assert isinstance(result, list)
    assert len(result) == 1
    assert isinstance(result[0], dict)
    assert len(result[0]) == 5
    assert result[0]['name'] is not None  # nosec
    assert result[0]['surname'] is not None  # nosec
    assert isinstance(result[0]['age'], int)
    assert result[0]['height'] is not None  #

# Generated at 2022-06-23 22:14:11.164248
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    field = AbstractField(locale='en', seed=None)
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:14.089290
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    a = AbstractField()
    assert str(a) == 'AbstractField <en>'
    a = AbstractField(locale='ru')
    assert str(a) == 'AbstractField <ru>'


# Generated at 2022-06-23 22:14:16.256817
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('enumerate', ['foo', 'bar'], start=1) == [1, 2]



# Generated at 2022-06-23 22:14:17.208135
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema(field=Field())

# Generated at 2022-06-23 22:14:22.146912
# Unit test for constructor of class Schema
def test_Schema():
    class Schema:
        def __call__(self):
            return {
                'string': 'https://github.com/lk-geimfari/mimesis',
            }

    filled = mimesis_schema.Schema(Schema()).create()
    assert filled[0]['string'] == 'https://github.com/lk-geimfari/mimesis'

# Generated at 2022-06-23 22:14:26.317293
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema

    schema = {
        'name': 'Antony',
        'age': 12,
        'is_married': False,
        'likes': ['red', 'blue']
    }

    sch = Schema(schema)
    assert sch.create() == [schema]

# Generated at 2022-06-23 22:14:28.652789
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Ensure that AbstractField.__str__ works correctly."""
    f = Field()
    assert str(f) == 'AbstractField <en>'



# Generated at 2022-06-23 22:14:32.658523
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

    field = Field(locale='uk')
    assert str(field) == 'AbstractField <uk>'

    field = Field(locale='ru')
    assert str(field) == 'AbstractField <ru>'



# Generated at 2022-06-23 22:14:35.436481
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {'a': 1, 'b': 2, 'c': 3}

    assert(len(Schema(schema).create()) == 1)
    assert(len(Schema(schema).create(2)) == 2)

# Generated at 2022-06-23 22:14:36.479780
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert callable(f) is True

# Generated at 2022-06-23 22:14:38.983052
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor of class ``Schema``."""
    schema = Schema
    assert schema is not None