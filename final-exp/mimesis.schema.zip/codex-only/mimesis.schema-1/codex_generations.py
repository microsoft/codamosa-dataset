

# Generated at 2022-06-23 22:04:32.491119
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        f = AbstractField()
        assert f
    except AttributeError:
        raise AssertionError('AbstractField() not instantiate')

# Generated at 2022-06-23 22:04:33.799788
# Unit test for constructor of class Schema
def test_Schema():
    try:
        Schema(list())
    except UndefinedSchema:
        pass

# Generated at 2022-06-23 22:04:35.162869
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert field.__str__() == 'Field <en>'

# Generated at 2022-06-23 22:04:36.782734
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='ru')
    assert field._gen.ru
    assert field.locale == 'ru'

# Generated at 2022-06-23 22:04:37.645963
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField)

# Generated at 2022-06-23 22:04:41.960615
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {
            'id': id,
            'name': name,
            'email': 'email',
            'address': 'address'
        }

    obj = Schema(schema)
    assert obj is not None
    assert callable(obj.schema)

    with pytest.raises(UndefinedSchema):
        Schema(1)



# Generated at 2022-06-23 22:04:46.652125
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert field('uuid')
    assert field('uuid', key=lambda x: x.lower())

    # Test for explicit definition of the provider
    for k in range(10):
        assert field('datetime.datetime', year=1990, month=12, day=12)

    # Test for ambiguous field names
    assert field('date', year=1990, month=12, day=12)
    assert field('address.city')
    assert field('personal.full_name', gender='male')

# Generated at 2022-06-23 22:04:50.110552
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()

    # Test for correct generation
    assert field(name='uuid4')
    assert field(name='uuid4')



# Generated at 2022-06-23 22:04:54.118443
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    field = Field()
    result = field('person.full_name')

    assert isinstance(result, str)

    result = field('uuid4', key=lambda x: len(x))
    assert isinstance(result, int)



# Generated at 2022-06-23 22:04:55.429632
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:04:57.918206
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor."""
    field = AbstractField()
    assert isinstance(field, AbstractField)
    assert isinstance(field, Generic)



# Generated at 2022-06-23 22:05:00.226131
# Unit test for constructor of class Schema
def test_Schema():
    """Test for Schema constructor."""
    s = Schema(lambda: None)
    assert s.schema is not None



# Generated at 2022-06-23 22:05:11.874691
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider

    class Person(RussiaSpecProvider):
        """An example of a class which returns filled schema."""

        @staticmethod
        def first_name(gender: Gender = None) -> str:
            """Return a first name by gender.

            :return: First name.
            """
            return Person(
                'ru',
                gender=gender,  # type: ignore
            ).person.first_name()

        @classmethod
        def filled_schema(cls) -> dict:
            """Return filled schema."""

# Generated at 2022-06-23 22:05:14.484347
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Successful call."""
    f = AbstractField()
    result = f('currency_code', key=str.upper)
    assert type(result) is str and result.isalpha()

# Generated at 2022-06-23 22:05:15.468988
# Unit test for constructor of class Schema
def test_Schema():
    schema = {}
    Schema(schema)

# Generated at 2022-06-23 22:05:17.566147
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>',\
        'Method __str__ of class AbstractField isn\'t work'

# Generated at 2022-06-23 22:05:19.142992
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:28.669141
# Unit test for method create of class Schema
def test_Schema_create():
    """Tests Schema's method create."""
    from mimesis.schema import Schema
    from mimesis.data import FAKE
    from mimesis.enums import Gender
    from mimesis.schema import Field

    def schema():
        return {
            'fio': Field('full_name').create(gender=Gender.FEMALE),
            'email': Field('email'),
            'phone': Field('telephone'),
            'address': Field('address').create(full=True),
        }

    s = Schema(schema)
    for item in s.create(iterations=5):
        assert isinstance(item, dict)



# Generated at 2022-06-23 22:05:40.532499
# Unit test for constructor of class Schema
def test_Schema():
    def get_schema() -> SchemaType:
        # A schema for testing.
        return {
            'name': 'Patricia Lebsack',
            'balance': '2500',
            'phone': '1-463-123-4447',
            'age': 44,
            'gender': 'F',
            'company': 'Johns Group',
            'email': 'Sherwood@rosamond.me',
            'address': 'Skiles Walks',
        }

    try:
        Schema(get_schema)
    except UndefinedSchema:
        # Schema is valid and it should raise an exception
        assert False

    # test: exception case
    def get_schema() -> SchemaType:
        return [{'name': 'Sherwood@rosamond.me'}]

# Generated at 2022-06-23 22:05:50.244003
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()
    assert f.locale == 'en'
    assert f.seed is None

    f = AbstractField(locale='ru', seed=42)
    assert f.locale == 'ru'
    assert f.seed == 42

    f = AbstractField(providers=(locales.en.Address,))
    assert 'full_address' in dir(f)
    assert f.full_address() != f.full_address()

    f._gen.add_providers(locales.en.Address)
    assert 'full_address' in dir(f)
    assert f.full_address() != f.full_address()

    def test_kwargs(**kwargs) -> str:
        return kwargs.get('prefix')

    assert f('test_kwargs', prefix='abc') == 'abc'


# Generated at 2022-06-23 22:05:58.414048
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Test that it raises an exception if `name` is not provided
    field = Field()
    assert isinstance(field, Field)

    # Test that it raises an exception if name is not supported
    field = Field()
    try:
        field('NotSupportedField')
    except UnsupportedField as e:
        assert str(e) == 'Field `NotSupportedField` not found.'

    # Test that it raises an exception if name is not supported
    field = Field()
    try:
        field('choice')
    except UnsupportedField as e:
        assert str(e) == 'Field `choice` not found.'

    # Test that it works if name is supported from an instance
    field = Field()
    field('random_int')
    field('random_int')
    field('random_int')

    # Test that it works if name is

# Generated at 2022-06-23 22:06:03.135076
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'test': 'web.url',
    }

    def my_schema(field: AbstractField):
        return field(**schema)

    s = Schema(my_schema)

    assert len(s.create()) == 1
    assert len(s.create(5)) == 5

# Generated at 2022-06-23 22:06:05.351257
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__."""
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:07.654281
# Unit test for method create of class Schema
def test_Schema_create():
    try:
        Schema(1).create()
    except UndefinedSchema as e:
        assert str(e) == 'Undefined Schema.'

# Generated at 2022-06-23 22:06:08.573341
# Unit test for constructor of class AbstractField
def test_AbstractField():
    data = Field()
    assert isinstance(data, AbstractField)
    assert isinstance(data, Field)

# Generated at 2022-06-23 22:06:15.921099
# Unit test for method create of class Schema
def test_Schema_create():
    def example_schema():
        return {
            'name': 'John Doe',
            'age': 22,
            'sex': 'male',
            'email': 'john_doe@gmail.com'
        }

    data = Schema(example_schema).create(2)
    assert len(data) == 2
    assert data == [
        {
            'name': 'John Doe',
            'age': 22,
            'sex': 'male',
            'email': 'john_doe@gmail.com'
        },
        {
            'name': 'John Doe',
            'age': 22,
            'sex': 'male',
            'email': 'john_doe@gmail.com'
        },
    ]

# Generated at 2022-06-23 22:06:23.359689
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    type(field('url')).__name__ == 'URL'
    type(field('random.number')).__name__ == 'int'
    type(field('random.number', min=0, max=10)).__name__ == 'int'
    field('random.number', min=0, max=10) <= 10
    field('random.number', min=0, max=10) >= 0
    field('random.number', min=1, max=10) == field(
        'random.number', min=1, max=10)
    field('random.number', min=2, max=10) != field(
        'random.number', min=1, max=10)



# Generated at 2022-06-23 22:06:32.399888
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    def schema() -> JSON:
        """Dummy schema.

        :return: Dummy schema.
        """
        from pprint import pprint
        from mimesis import Person

        person = Person(seed=42)
        field = Field(seed=42)

        dummy_data = {
            'id': field('uuid'),
            'title': field('sentence'),
            'completed': field('boolean'),
            'author': person('full_name'),
            'metadata': [
                field('uuid'),
                field('uuid'),
                field('uuid'),
                field('uuid'),
                field('uuid'),
            ]
        }
        pprint(dummy_data)
        return dummy_data


# Generated at 2022-06-23 22:06:34.995333
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert f.locale == 'en'
    assert f.seed is None
    assert isinstance(f, AbstractField)



# Generated at 2022-06-23 22:06:40.758033
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    a = AbstractField(seed=12345)

    # UndefinedField
    try:
        a()
        raise AssertionError('a should not pass')
    except UndefinedField:
        pass

    # UnacceptableField
    try:
        a('lorem.ipsum.ipsum')
        raise AssertionError('a should not pass')
    except UnacceptableField:
        pass

    # UnsupportedField
    try:
        a('lorem')
        raise AssertionError('a should not pass')
    except UnsupportedField:
        pass

# Generated at 2022-06-23 22:06:46.297579
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    i = field('currency')
    assert isinstance(i, str)
    assert len(i) == 3

    # Method with same name
    result = field('full_name')
    assert isinstance(result, str)

    en_result = field('full_name', locale='en')
    ru_result = field('full_name', locale='ru')
    assert en_result != ru_result

    result = field(
        'full_name',
        key=lambda x: x.split(' ')[0]
    )
    assert isinstance(result, str)

    result = field('person.full_name', locale='en')
    assert isinstance(result, str)

    from mimesis.builtins import Address
    from mimesis.builtins import Person

# Generated at 2022-06-23 22:06:50.759394
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import Person, Address

    person = Person('ru')
    address = Address('ru')

    s = {
        'full_name': person.full_name(),
        'address': address.address(),
    }

    schema = Schema(s)

    assert isinstance(schema, Schema)

# Generated at 2022-06-23 22:06:52.032740
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    f = Field()
    assert callable(f)

# Generated at 2022-06-23 22:06:54.865784
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    result = field('choice', ['1', '2'])
    assert result in ['1', '2']

# Generated at 2022-06-23 22:06:57.041419
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test if __str__ return expected result."""
    f = Field()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:58.120435
# Unit test for constructor of class Schema
def test_Schema(): 
    sh = Schema(None)

# Generated at 2022-06-23 22:07:06.173402
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    schema = {
        'name': '<method_name>',
        'key': '<key_function>'
    }
    correct = [
        {
            'name': 'method_name',
            'key': None,
        },
        {
            'name': 'method_name',
            'key': 'key_function',
        },
    ]
    for param in correct:
        result = ''
        try:
            import mimesis
            field = mimesis.Field(providers=['mimesis.providers.text'])
            result = field(**param)
        except:
            result = result
        assert result == 'method_name'

# Generated at 2022-06-23 22:07:08.168641
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {})
    assert schema is not None



# Generated at 2022-06-23 22:07:10.366350
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for methdo create of class Schema."""
    def schema():
        """Function as a schema."""
        return {}

    schema = Schema(schema)
    result = schema.create(iterations=0)
    assert result == []

# Generated at 2022-06-23 22:07:12.302037
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:07:19.373348
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    assert field('integer') > 0

    assert field('integer', min=100, max=1000) > 100
    assert field('integer', min=100, max=1000) < 1000

    assert field('name')
    assert field('name', gender='male')

    name = field('name', key=lambda x: x.split(' ')[0])
    assert name

    assert field('gender') in ['male', 'female']
    field = Field(locale='ru')
    assert field('gender') in ['male', 'female']



# Generated at 2022-06-23 22:07:28.305633
# Unit test for method __call__ of class AbstractField

# Generated at 2022-06-23 22:07:31.845087
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        # It's a very simple schema
        return {
            'foo': 'bar'
        }

    s = Schema(schema)
    assert s.create(1) == [{'foo': 'bar'}]

# Generated at 2022-06-23 22:07:36.311874
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {'foo': 'bar'}

    s = Schema(schema=schema)
    assert isinstance(s, Schema)

    with pytest.raises(UndefinedSchema):
        Schema(schema='schema')



# Generated at 2022-06-23 22:07:38.121062
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    # Test constructor
    f = AbstractField()
    assert isinstance(f, AbstractField)



# Generated at 2022-06-23 22:07:47.786498
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__.

    Test for correct work of method __call__
    of class AbstractField.
    """
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    field = AbstractField(providers=[RussiaSpecProvider])

    assert field('full_name') in field._table  # pylint: disable=protected-access
    assert (callable(field._table['full_name']))  # pylint: disable=protected-access
    assert callable(field._table['person.full_name'])  # pylint: disable=protected-access

    name = field('person.full_name', gender=Gender.MALE)
    assert name in field._gen.person._data['full_name']['male']  # pylint: disable=protected-access



# Generated at 2022-06-23 22:07:50.758111
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    class AbstractFieldAlias(AbstractField):
        pass

    field = AbstractFieldAlias(locale='en')
    assert str(field) == 'AbstractFieldAlias <en>'

# Generated at 2022-06-23 22:07:52.863753
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    t = AbstractField()
    assert t.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:56.802103
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField.

    :return: None.
    :raises: assertion error if failed.
    """
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:59.966451
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field(locale='ru').locale == 'ru'
    assert Field(locale='ja').locale == 'ja'

# Generated at 2022-06-23 22:08:03.037058
# Unit test for constructor of class Schema
def test_Schema():
    schema = {'a': 1, 'b': 2}
    results = Schema(lambda: schema)(1)
    assert results == [schema]



# Generated at 2022-06-23 22:08:07.820843
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor of class Schema."""
    schema = Schema(SchemaType())
    assert isinstance(schema, Schema)

    # Test with not callable
    try:
        Schema(object())
    except UndefinedSchema:
        assert True
    else:
        assert False

# Generated at 2022-06-23 22:08:12.503127
# Unit test for constructor of class Schema
def test_Schema():
    def my_schema():
        return {'foo': 'bar'}

    s = Schema(my_schema)
    assert isinstance(s, Schema)
    assert isinstance(s.create(), list)
    # default value
    assert s.create(1) == Schema(my_schema).create(1)

# Generated at 2022-06-23 22:08:15.117021
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()
    result = f.__call__('country')
    assert result is not None

# Generated at 2022-06-23 22:08:18.577299
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField('ru')) == 'AbstractField <ru>'
    assert str(AbstractField('ru', seed=123)) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:08:23.542238
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'string': 'foo',
            'integer': 5,
            'float': 5.0,
        }

    assert Schema(schema).create(10) == [{
        'string': 'foo',
        'integer': 5,
        'float': 5.0,
    }] * 10

# Generated at 2022-06-23 22:08:32.995315
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()

    # Test for the UnsupportedField exception
    try:
        f('test')
    except UnsupportedField as e:
        assert str(e) == 'Field "test" is not supported'

    # Test for the UndefinedField exception
    try:
        f()
    except UndefinedField as e:
        assert str(e) == 'Method name was not passed'

    # Test for the UnacceptableField exception
    try:
        f('test.test.test')
    except UnacceptableField as e:
        assert str(e) == 'Method "test" is not acceptable'

    # Test if it's equal to words.word()
    assert isinstance(f('word'), str)
    assert f('word') == f('words.word')

    # Test if it's equal to datetime.time()

# Generated at 2022-06-23 22:08:34.272861
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert f is not None  # noqa: S101

# Generated at 2022-06-23 22:08:42.349090
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test field call."""
    import pytest  # noqa

    gen = Generic()
    f = AbstractField(locale='en', providers=[gen])

    assert f('seed') == gen.seed
    assert f('gender') == gen.gender()
    assert f('uuid4') == gen.uuid4()
    assert f('seed') == gen.seed

    with pytest.raises(UndefinedField):
        f()

    with pytest.raises(UndefinedField):
        f(None)

    with pytest.raises(UnsupportedField):
        f('dadada')

    with pytest.raises(UnacceptableField):
        f('random.random.random')

    assert f('random.randint', min=1, max=10) == gen.random.randint(1, 10)

   

# Generated at 2022-06-23 22:08:49.058407
# Unit test for method create of class Schema
def test_Schema_create():
    def first_schema():
        return {
            'name': 'John',
            'last_name': 'Smith',
            'age': 42,
            'gender': 'male',
            'is_adult': True,
            'is_child': False
        }

    s = Schema(first_schema)
    assert s.create(2) == [
        first_schema(),
        first_schema(),
    ]

# Generated at 2022-06-23 22:08:50.015010
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:52.740608
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field = Field()
    assert abstract_field
    assert abstract_field.locale == 'en'
    assert abstract_field.seed is None



# Generated at 2022-06-23 22:08:55.319944
# Unit test for constructor of class AbstractField
def test_AbstractField():
    _field = AbstractField()
    _field.create_provider = lambda: None
    assert isinstance(_field, AbstractField)



# Generated at 2022-06-23 22:08:57.938989
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema():
        pass

    schema = Schema(schema=test_schema)
    assert isinstance(schema, Schema)



# Generated at 2022-06-23 22:09:05.330443
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.generic import Generic
    from mimesis.providers.text import Text

    class PersonSchema:
        """Basic person schema.

        https://json-schema.org/learn/getting-started-step-by-step.html
        """

        def __init__(self) -> None:
            """Initialize schema."""
            self.gen = Generic()
            self.txt = Text()

        def __call__(self) -> dict:
            """Return filled schema.

            :return: Schema.
            """

# Generated at 2022-06-23 22:09:06.779016
# Unit test for method create of class Schema
def test_Schema_create():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 22:09:15.683051
# Unit test for constructor of class Schema

# Generated at 2022-06-23 22:09:24.098749
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('fake', fake='one') == 'one'
    assert field('slug', key=lambda x: x.title()) == 'Slug'
    assert field('slug') == 'slug'
    field = Field(locale='ru')
    assert field('address.city') == 'Москва'
    assert field('fake', fake='one') == 'one'
    assert field('address.city', region='77') == 'Москва'
    assert field('faker.address.city') == 'Moscow'
    assert field('fake.address.city') == 'Moscow'
    assert field('fake.address.city', region='77') == 'Москва'

# Generated at 2022-06-23 22:09:25.553509
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    a = AbstractField()
    assert str(a) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:29.806650
# Unit test for constructor of class Schema
def test_Schema():
    class A:
        def __init__(self):
            self.a = 0
            self.b = 'test'
            self.c = ''

    try:
        Schema(A())
    except UndefinedSchema:
        Schema(A)

# Generated at 2022-06-23 22:09:37.642013
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.geography import Geography

    field = Field()

    assert field.locale == 'en'
    assert field.seed is None

    field.seed = 10
    assert field.seed == 10

    field = Field(locale='ru')
    assert field.locale == 'ru'

    field = Field(seed=5)
    assert field.seed == 5

    field2 = Field(providers=[Geography, Address])
    assert field2.Person.gender() == Gender.MALE

# Generated at 2022-06-23 22:09:44.834253
# Unit test for constructor of class Schema
def test_Schema():  # noqa: D102
    from mimesis.schema import build_schema  # NOQA

    def test_schema() -> Schema:  # NOQA
        return build_schema({
            'name': str,
            'age': int,
            'favorite_color': ['red', 'blue', 'green', 'yellow', 'orange']
        })

    schm = Schema(test_schema)
    schm.create()


# Generated at 2022-06-23 22:09:47.052900
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Assert AbstractField.__str__."""
    f = Field(locale='ru')
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:09:50.407431
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

if __name__ == '__main__':
    test_AbstractField___str__()

# Generated at 2022-06-23 22:09:54.358714
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda: {'name': 'foo', 'age': 18})
    assert schema.create() == [{'name': 'foo', 'age': 18}]
    assert schema.create(5) == [
        {'name': 'foo', 'age': 18} for _ in range(5)]

# Generated at 2022-06-23 22:09:58.942175
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(locale='en', seed=1)
    assert field.locale == 'en'
    assert field.seed == 1
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None
    field = Field(locale='en', seed=1,
                  providers=[])
    assert field.locale == 'en'
    assert field.seed == 1

# Generated at 2022-06-23 22:10:00.550632
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Alias for AbstractField
    Field = AbstractField

    # Constructor of class AbstractField.
    assert Field().locale == 'en'

# Generated at 2022-06-23 22:10:03.398936
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__."""
    f = Field('en')
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:05.114369
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test AbstractField.__str__()."""
    assert isinstance(AbstractField().__str__(), str)

# Generated at 2022-06-23 22:10:11.830679
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import schema
    from mimesis.schema import Schema

    _ = schema.Schema({"_id": "<uuid4()>",
                       "name": "<person.full_name()>",
                       "avatar": "<person.avatar_url()>"})
    print(_)

    def test() -> dict:
        return {"_id": "<uuid4()>",
                "name": "<person.full_name()>",
                "avatar": "<person.avatar_url()>"}

    s = Schema(test)
    print(s)

# Generated at 2022-06-23 22:10:17.503847
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> JSON:
        return {
            'name': Field().word(),
            'surname': Field().word(),
            'status': Field().word(),
            'gender': Field().gender(),
        }

    data = Schema(schema).create(iterations=10)
    assert isinstance(data, list) and all(isinstance(i, dict) for i in data)
    assert len(data) == 10



# Generated at 2022-06-23 22:10:19.490652
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test generating strings."""
    field = AbstractField(locale='es')
    assert field.__str__() == 'AbstractField <es>'

# Generated at 2022-06-23 22:10:26.117337
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__() method."""
    f = Field(seed=1234)
    assert f('full_name') == 'Mrs. Anastasia O'
    assert f('datetime', start='2018-01-01', end='2018-01-02') == '2018-01-01'
    assert f('datetime', start='2018-01-01', end='2018-01-02', key=lambda x: x.strftime('%m')) == '01'

# Generated at 2022-06-23 22:10:27.580757
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema(lambda: 1)
    assert s is not None
    assert callable(s)

# Generated at 2022-06-23 22:10:28.972375
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert isinstance(field.__str__(), str)

# Generated at 2022-06-23 22:10:37.026858
# Unit test for method create of class Schema
def test_Schema_create():
    sample_schema = {
        'first_name': str,
        'last_name': str,
        'gender': str,
    }

    if field is not None:
        sample_schema['full_name'] = lambda: field('full_name')
    else:
        def full_name():
            return '{0} {1}'.format(field('first_name'), field('last_name'))
        sample_schema['full_name'] = full_name

    def schema_example():
        return sample_schema
    schema_example.create = Schema.create  # type: ignore # noqa

    schema_example.create()  # type: ignore

# Generated at 2022-06-23 22:10:39.612505
# Unit test for constructor of class Schema
def test_Schema():
    """Check Schema constructor."""
    schema = Schema(lambda: {})
    assert len(schema.create(iterations=5)) == 5

# Generated at 2022-06-23 22:10:40.370514
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f is not None, 'Object must be not None.'

# Generated at 2022-06-23 22:10:42.632986
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(lambda x: {}).create(1)) == 1
    assert len(Schema(lambda x: {}).create(2)) == 2

# Generated at 2022-06-23 22:10:45.785543
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()

    assert f('datetime') is not None
    assert f('datetime', year=1990) is not None
    assert f('datetime', 'year', year=1990) is not None



# Generated at 2022-06-23 22:10:49.773017
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f).startswith('AbstractField <')
    assert str(f).endswith('>')
    assert str(f).__len__() > 'AbstractField <en>'.__len__()

# Generated at 2022-06-23 22:10:51.703521
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__.

    """
    field = AbstractField()
    assert callable(field)



# Generated at 2022-06-23 22:10:52.274684
# Unit test for constructor of class AbstractField
def test_AbstractField():
    _ = AbstractField()

# Generated at 2022-06-23 22:10:53.501228
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field._gen is not None

# Generated at 2022-06-23 22:10:55.426295
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField."""
    field = Field()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:57.820288
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

    f = AbstractField(locale='ru')
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:10:59.280398
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('title') == 'Mr'

# Generated at 2022-06-23 22:11:06.201274
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis import Person
    from mimesis.schema import Field

    p = Person('en')
    f = Field('en')

    s = Schema(lambda: {
        'name': p.full_name,
        'age': f('age', start=18, end=60, key=int),
    })

    result = s.create(10)
    assert len(result) == 10
    assert isinstance(result, list)
    assert isinstance(result[0], dict)

# Generated at 2022-06-23 22:11:08.350607
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    f = AbstractField()
    assert f('person.full_name')



# Generated at 2022-06-23 22:11:10.228783
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField(locale='ru')) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:11:18.517213
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test a method __call__ of class AbstractField."""
    f = Field()
    assert isinstance(f('username'), str)
    assert isinstance(f('uuid'), str)
    assert f('uuid') != f('uuid')
    assert f('uuid') != f('uuid')
    assert f('uuid', uuid_format='base64') != f('uuid', uuid_format='base64')
    assert f('uuid', uuid_format='base64') != \
        f('uuid', uuid_format='base64')
    assert isinstance(f('uuid'), str)
    assert len(f('uuid')) == 36
    assert isinstance(f('uuid', uuid_format='hex'), str)

# Generated at 2022-06-23 22:11:19.941200
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:22.256582
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test case that represents a field."""
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:24.213907
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()  # noqa: F841
    assert field


# Generated at 2022-06-23 22:11:31.371409
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    import pytest

    class Foo:
        def bar(self, **kwargs):
            return self

    field = AbstractField()

    with pytest.raises(UndefinedField):
        field()

    with pytest.raises(UnsupportedField):
        field('foo')

    with pytest.raises(UnacceptableField):
        field('foo.bar.baz')

    field._gen.add_providers(Foo())
    assert isinstance(field('foo'), Foo)

# Generated at 2022-06-23 22:11:38.207134
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField.
    :return: None.
    :raises ValueError: if provider not
        supported or if field not defined.
    :raises UnacceptableField: if field is unacceptable.
    """
    f = AbstractField()  # noqa

    # tests without search provider
    f(name='full_name')

    # tests with search by provider without tail
    f(name='en.full_name')

    # tests with search by provider with tail
    with pytest.raises(UnacceptableField):
        f(name='en.name.full_name')

    # test if provider not supported
    with pytest.raises(UnsupportedField):
        f(name='en.full_name.example')

    # test if field not defined

# Generated at 2022-06-23 22:11:48.832687
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    try:
        field = Field()
        field('')
    except UndefinedField:
        assert True
    else:
        assert False

    try:
        field = Field()
        field('provider.method')
    except UndefinedField:
        assert True
    else:
        assert False

    try:
        field = Field()
        field('provider..method')
    except UnacceptableField:
        assert True
    else:
        assert False

    try:
        field = Field()
        field('provider.method.method')
    except UnacceptableField:
        assert True
    else:
        assert False

    try:
        field = Field()
        field('method')
    except UnsupportedField:
        assert True
    else:
        assert False



# Generated at 2022-06-23 22:11:57.917112
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person

    field = Field(providers=[Person, Address, Internet, Datetime])
    result = field('name', gender='male')
    assert result in Person(field.locale).name().values()  # type: ignore

    result = field('zip_code')
    assert len(result) == 7  # type: ignore

    result = field('email')
    assert '@' in result  # type: ignore

    result = field('datetime.datetime')
    assert isinstance(result, datetime)  # type: ignore



# Generated at 2022-06-23 22:12:08.368164
# Unit test for method create of class Schema
def test_Schema_create():
    """Test :func:`mimesis.schema.Schema.create`."""
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.schema import Schema

    def schema() -> dict:
        address = Address('it')
        person = Person('it')

        schema = {
            'gender': person.gender(Gender.MALE),
            'name': person.full_name(gender=Gender.MALE),
            'address': address.address(),
            'age': person.age(),
            'city': address.city(),
            'country': address.country(),
            'timezone': address.timezone(),
        }
        return schema

    s = Schema(schema)

# Generated at 2022-06-23 22:12:10.394277
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:12.338899
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import schema as s
    s.Schema(s.Field)



# Generated at 2022-06-23 22:12:17.534808
# Unit test for method create of class Schema
def test_Schema_create():
    field = Field()
    schema = dict(name=field.name(), age=field.age())

    data = Schema(schema).create(iterations=3)
    expected = [{'name': field.name(), 'age': field.age()},
                {'name': field.name(), 'age': field.age()},
                {'name': field.name(), 'age': field.age()}]

    assert data == expected

# Generated at 2022-06-23 22:12:21.099379
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = Field()

    assert field(name='url', protocol='http')



# Generated at 2022-06-23 22:12:22.845028
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    _field = AbstractField(locale='en')
    assert str(_field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:27.786513
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    schema = Schema({
        'foo': Field().name(),
    })
    result = schema.create(1)
    assert isinstance(result, list)
    assert result == [{'foo': Field().name()}]

# Generated at 2022-06-23 22:12:28.852497
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()

    assert field is not None

# Generated at 2022-06-23 22:12:33.417246
# Unit test for method create of class Schema
def test_Schema_create():
    json_schema = {
        'name': 'John',
        'surname': 'Doe',
        'address': {
            'city': 'New York',
            'zip': '12345',
        },
    }

    def schema():
        return json_schema

    result = Schema(schema).create(iterations=2)
    assert result == [json_schema, json_schema]

# Generated at 2022-06-23 22:12:43.808222
# Unit test for method create of class Schema
def test_Schema_create():
    import pytest
    from mimesis.schema import Schema
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    def create_person_schema() -> JSON:
        """Create a schema for Person."""
        return {
            'name': Person('en', seed=1).full_name(),
            'gender': Person('en', seed=2).gender(),
            'city': Person('en', seed=3).city(),
        }

    schema = Schema(create_person_schema)
    result = schema.create(iterations=2)
    assert len(result) == 2
    assert result[0]['name'] == 'Michael Rath'
    assert result[0]['gender'] == Gender.MALE.value

# Generated at 2022-06-23 22:12:49.135517
# Unit test for method create of class Schema
def test_Schema_create():
    @Field.json
    def schema():
        return {
            'name': Field('person.full_name'),
            'username': Field('person.username'),
            'email': Field('person.email'),
            'password': Field('person.password'),
        }

    assert isinstance(Schema(schema).create(iterations=2), list)

# Generated at 2022-06-23 22:12:52.381793
# Unit test for method create of class Schema
def test_Schema_create():
    def schema_1(field: Field = Field()) -> JSON:
        return {
            'name': field('person.name'),
            'surname': field('person.surname'),
        }

    s = Schema(schema_1)

    assert isinstance(s.create(iterations=5), list)

# Generated at 2022-06-23 22:12:55.248773
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()

    expected = 'AbstractField <en>'
    result = field.__str__()

    assert result == expected

# Generated at 2022-06-23 22:13:01.238674
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from . import point_schema

    field = Field()
    value = field(name='point', key=tuple)
    assert isinstance(value, tuple)
    assert len(value) == 2

    assert isinstance(field(name='numeric.geometric_mean',
                            x=point_schema.first,
                            y=point_schema.second),
                      float)



# Generated at 2022-06-23 22:13:04.053394
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'
    assert str(Field(locale='ru')) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:13:08.459595
# Unit test for constructor of class Schema
def test_Schema():
    def schema(x: JSON) -> JSON:
        return {
            'title': x.lorem.text(),
        }

    obj = Schema(schema)  # type: ignore
    assert obj.create(iterations=10)



# Generated at 2022-06-23 22:13:11.798578
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>', \
        '__str__ function is broken'

# Generated at 2022-06-23 22:13:12.780116
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema(object)

# Generated at 2022-06-23 22:13:14.925964
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert callable(field)
    result = field('__str__', name='generic')
    assert isinstance(result, str)
    assert result.endswith('<en>')



# Generated at 2022-06-23 22:13:19.587505
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>', \
        'Method must return AbstractField <en>'

    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>', \
        'Method must return AbstractField <ru>'



# Generated at 2022-06-23 22:13:23.962937
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field

    schema = Field(locale='ru')

    def _schema():
        return {
            'name': schema.person.full_name(),
            'age': schema.person.age(),
        }

    s = Schema(_schema)
    assert (len(s.create()) == 1)
    assert (len(s.create(iterations=5)) == 5)

# Generated at 2022-06-23 22:13:26.771934
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = AbstractField()
    data = abstract_field('person.full_name')
    assert isinstance(data, str)

# Generated at 2022-06-23 22:13:31.139435
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    name = 'uuid4'
    expected = 'd30a3f28-dc6f-45e2-9c50-2ab0929253c0'
    result = field(name)

    assert result == expected, (
        'Failed to call AbstractField.__call__() method'
    )

# Generated at 2022-06-23 22:13:33.306217
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    field = AbstractField('ru')
    assert str(field) == 'AbstractField <ru>'



# Generated at 2022-06-23 22:13:37.365091
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check the str representation of AbstractField."""
    assert str(Field(locale='ru', seed=42)) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:13:38.256743
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:13:40.375772
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        """Fill schema."""
        return {}

    s = Schema(schema)
    assert len(s.create(10)) == 10

# Generated at 2022-06-23 22:13:47.780443
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('choice', drug=['meth', 'heroin', 'cocaine', 'ecstasy']) in [
        'meth', 'heroin', 'cocaine', 'ecstasy']
    assert field('choice', key=lambda x: x.upper(),
                 drug=['meth', 'heroin', 'cocaine', 'ecstasy']) in [
        'METH', 'HEROIN', 'COCAINE', 'ECSTASY']

# Generated at 2022-06-23 22:13:50.495675
# Unit test for constructor of class Schema
def test_Schema():
    provider = Generic('ru')

    def foo() -> str:
        return provider.full_name()

    Schema(foo)



# Generated at 2022-06-23 22:13:59.661708
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    def test_UnsupportedField(name: Optional[str] = None):
        """Test method __call__ with wrong arguments."""
        # 'name' must be None
        if name is None:
            return 'name' in str(excinfo.value)

        # 'name' must be a string
        if not isinstance(name, str):
            return 'must be a string' in str(excinfo.value)

        # 'name' must be part of table
        if name not in {
                'name', 'name.name', 'provider.name', 'provider'}:
            return 'Unsupported field' in str(excinfo.value)

        # 'name' must NOT contain tail

# Generated at 2022-06-23 22:14:00.489826
# Unit test for constructor of class Schema
def test_Schema():
    assert callable(Schema)

# Generated at 2022-06-23 22:14:02.595557
# Unit test for method create of class Schema
def test_Schema_create():
    assert type(Field().create(10)) == list
    assert len(Field().create(10)) == 10

# Generated at 2022-06-23 22:14:05.948720
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = Field()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:14:10.357015
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field(seed=None, locale='en')
    assert issubclass(field.__class__, AbstractField)
    assert field.__class__.__name__ == 'AbstractField'
    assert field.__class__ == AbstractField
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:13.281140
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

    field = AbstractField('ru')
    assert str(field) == 'AbstractField <ru>'



# Generated at 2022-06-23 22:14:14.774858
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:22.824452
# Unit test for method create of class Schema
def test_Schema_create():
    # Define a schema
    def data_schema():
        return {
            'name': 'John',
            'surname': 'Smith',
            'age': Field('age'),
            'country': {
                'name': 'USA'
            }
        }

    # Create a new instance of class Schema with defined schema
    s = Schema(schema=data_schema)
    # Get a list of filled schemas
    filled_schemas = s.create(iterations=2)
    # Assertions
    assert len(filled_schemas) == 2



# Generated at 2022-06-23 22:14:32.530508
# Unit test for method create of class Schema
def test_Schema_create():
    class Test:
        def schema(self):
            return [self.name(), self.last_name(), self.phone_number()]

        def name(self):
            return 'Bob'

        def last_name(self):
            return 'Ross'

        def phone_number(self):
            return '+1 (234) 567-89-01'

    test = Schema(Test().schema)