

# Generated at 2022-06-23 22:04:52.159708
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert f.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:04:53.010498
# Unit test for constructor of class Schema
def test_Schema():
    pass

# Generated at 2022-06-23 22:04:59.879734
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    def test_key_function(result):
        return '{} world'.format(result)


    field = AbstractField()

    # For methods without arguments
    assert field('title') == 'Mr.'
    assert field('title', key=test_key_function) == 'Mr. world'

    # For methods with arguments
    assert field('name', first_name=True, gender='male') == 'Michael'
    assert field('name', first_name=True, gender='female') == 'Linda'

    # In a cases when it's necessary to define a provider explicitly
    assert field('datetime.today') == field('datetime').today()

    # Raise appropriate errors
    try:
        field('$')
    except Exception as ex:
        assert isinstance(ex, UnsupportedField)

# Generated at 2022-06-23 22:05:04.626909
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()

    assert field.locale == 'en'
    assert field.seed is None

    field = Field(locale='ru', seed=987654321)

    assert field.locale == 'ru'
    assert field.seed == 987654321

# Generated at 2022-06-23 22:05:07.773718
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method ``__str__`` of class AbstractField."""
    field = Field(locale='ru')
    result = str(field)
    expected = 'AbstractField <ru>'
    assert result == expected

# Generated at 2022-06-23 22:05:14.357015
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    # test if it's really works
    assert field('name')
    assert field('name', key=lambda x: x.capitalize())
    assert field('person.full_name')
    # test by a random string
    assert field('a' * 10) is None
    # test if it's raise an exception
    try:
        field()  # type: ignore
    except UndefinedField:
        assert True
    else:
        assert False

# Generated at 2022-06-23 22:05:16.834410
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert f.locale == 'en', 'Wrong locale'
    assert f.seed is None, 'Wrong seed'


# Unit tests for class AbstractField

# Generated at 2022-06-23 22:05:25.704308
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Field
    from mimesis.enums import Gender

    def _schema(field: Field) -> JSON:
        return {
            'first_name': field('person.name', gender=Gender.FEMALE),
            'last_name': field('person.surname'),
            'email': field('person.email'),
            'ssn': field('person.ssn'),
            'password': field('internet.password',
                              length=10, hashed=False),
            'phone': field('person.telephone'),
        }

    schema = Schema(_schema)
    lst = schema.create(iterations=5)
    print('\n'.join(str(elem) for elem in lst))



# Generated at 2022-06-23 22:05:26.481834
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field

# Generated at 2022-06-23 22:05:30.865650
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Smoke test for the AbstractField.__call__ method."""
    field = Field()
    assert field.__call__('name') is not None
    assert field.__call__('first_name') is not None
    assert field.__call__('uuid4') is not None
    assert field.__call__('uuid4') is not None
    assert field.__call__('hex_color') is not None


# Generated at 2022-06-23 22:05:42.087988
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.localization import Localization

    from mimesis.typing import Provider

    field = Field(locale='ru', seed=10)  # type: ignore

    # Should be able to invoke not existing method
    assert field('not_exist')

    # Should be able to invoke method from not existing provider
    assert field('not_exist.data')

    # Should be able to invoke method from existing provider
    assert field('datetime.timestamp')

    # Should able to invoke method with key
    assert field('cryptographic.sha1', key=lambda x: x[0:3:]) == 'b6e'

    # Should be able to invoke method with kwargs
    assert isinstance(field('http.url', length=2), str)

    # Should raise UnsupportedField

# Generated at 2022-06-23 22:05:44.386688
# Unit test for constructor of class Schema
def test_Schema():
    # invalid schema
    s = Schema('invalid')
    assert not s


# Generated at 2022-06-23 22:05:45.408285
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field() is not None



# Generated at 2022-06-23 22:05:48.957460
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField constructor."""
    # Test should be passed (no exception)
    field = AbstractField('ru')
    field = AbstractField('ru', 1234)
    field = AbstractField('ru', 1234, [])



# Generated at 2022-06-23 22:05:55.153365
# Unit test for constructor of class Schema
def test_Schema():
    """The name of the method."""
    class SchemaTest:
        """The name of the method."""

        @staticmethod
        def schema() -> dict:
            """The name of the method."""
            return {
                'name': 'John User',
                'age': 16,
                'email': 'john@example.com',
            }

    result = Schema(SchemaTest.schema)

    assert result is not None

    bad_schema = Schema(123456)  # type: ignore

    assert bad_schema is not None

# Generated at 2022-06-23 22:06:02.628263
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.schema import Field


# Generated at 2022-06-23 22:06:05.713753
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()
    assert f('faker.name.first_name') == f['faker.name.first_name']
    assert f('name.first_name') != f['name.first_name']

# Generated at 2022-06-23 22:06:08.716398
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(locale='ru', seed=123456)
    assert field.locale == 'ru'
    assert field.seed == 123456



# Generated at 2022-06-23 22:06:10.324553
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema."""
    class TestSchema:

        def schema(self):
            """Dummy schema."""
            return {1: 2}
    t_schema = TestSchema()

    assert Schema(t_schema.schema)

# Generated at 2022-06-23 22:06:14.567430
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField constructor."""
    test_field = AbstractField()
    assert test_field.locale == 'en'
    assert test_field.seed is None

    test_field = AbstractField(locale='ru')
    assert test_field.locale == 'ru'

    test_field = AbstractField(seed=999)
    assert test_field.seed == 999



# Generated at 2022-06-23 22:06:15.740025
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('datetime') is not None
    assert field('datetime.utcnow') is not None



# Generated at 2022-06-23 22:06:21.450560
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema() -> Any:
        return 'Test'
    sch = Schema(schema=test_schema)
    assert sch.schema() == 'Test'

    with open('tests/files/schemas/test.json') as json_file:
        json_data = json_file.read()

    def json_schema() -> Any:
        return json_data

    sch = Schema(schema=json_schema)
    assert sch.schema() == json_data



# Generated at 2022-06-23 22:06:24.509657
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField's __call__ method."""
    field = Field()
    value = field('person.full_name')
    assert isinstance(value, str)

# Generated at 2022-06-23 22:06:31.520591
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'item': ['a', 'b', 'c', 'd', 'e']}

    def __schema():
        return {
            'item': 'c',
            'item2': True,
            'item3': ['d' 'e']
        }

    schema_object = Schema(__schema)
    assert (len(schema_object.create(iterations=10)) == 10)
    assert (type(schema_object.create()) == list)



# Generated at 2022-06-23 22:06:36.567345
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    def schema() -> dict:
        """Test schema."""
        return {
            'id': f.uuid4(),
            'name': f.name(),
            'age': f.age(),
            'gender': f.gender(),
        }

    s = Schema(schema)
    assert isinstance(s.create()[0], dict)

# Generated at 2022-06-23 22:06:39.075525
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> List[JSON]:
        return [{'name': 'John'}]

    sch = Schema(schema)
    assert sch.create(4) == [{'name': 'John'} for _ in range(4)]

# Generated at 2022-06-23 22:06:40.173474
# Unit test for method create of class Schema
def test_Schema_create():
    """Remove stub."""
    schema = Schema({
        "name": "address"
    })
    assert len(schema.create(1)) > 0

# Generated at 2022-06-23 22:06:44.169011
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__()."""
    field = AbstractField()
    assert field('choice') in ['male', 'female']
    assert field('choice', choices=['foo', 'bar']) in ['foo', 'bar']

    with raises(UndefinedField):
        field()

    with raises(UnsupportedField):
        field('not_supported')

    assert field('person.full_name')

    assert field('person.full_name', key=len)



# Generated at 2022-06-23 22:06:54.090774
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(locale='en', seed=1), AbstractField)
    assert isinstance(Field(locale='en', seed=2), AbstractField)
    assert isinstance(Field(locale='en', seed=3), AbstractField)
    assert isinstance(Field(locale='en', seed=4), AbstractField)
    assert isinstance(Field(locale='en', seed=5), AbstractField)
    assert isinstance(Field(locale='en', seed=6), AbstractField)
    assert isinstance(Field(locale='en', seed=7), AbstractField)
    assert isinstance(Field(locale='en', seed=8), AbstractField)
    assert isinstance(Field(locale='en', seed=9), AbstractField)
    assert isinstance(Field(locale='en', seed=10), AbstractField)

# Generated at 2022-06-23 22:06:54.796639
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    result = AbstractField().__str__()
    assert result == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:56.195408
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # This method is unit-tested inside the method Schema.create
    pass

# Generated at 2022-06-23 22:07:01.151613
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.providers.base import BaseSpecProvider

    field = Field()
    spec_provider = BaseSpecProvider(
        locale='en',
        seed=None,
    )
    assert field._gen.random.__class__.__name__ == 'Random'

    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:03.342443
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField('ru')) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:07:11.488731
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField"""
    field = AbstractField(locale='en')
    field2 = AbstractField(locale='en', seed=1)
    field3 = AbstractField(locale='en', seed=1, providers=[])

    assert field._gen.Meta.name == 'generic'
    assert field2._gen.Meta.name == 'generic'
    assert field3._gen.Meta.name == 'generic'

    expected_table = {}
    assert field._table == expected_table
    assert field2._table == expected_table
    assert field3._table == expected_table

    expected_locale = 'en'
    assert field.locale == expected_locale
    assert field2.locale == expected_locale
    assert field3.locale == expected_locale

    assert field2.seed is not None

# Generated at 2022-06-23 22:07:14.332340
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'



# Generated at 2022-06-23 22:07:15.648298
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:16.994688
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(lambda: None).create(iterations=0)) == 0

# Generated at 2022-06-23 22:07:18.753943
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field: AbstractField = AbstractField(locale='en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:28.721839
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import AbstractField
    from mimesis.enums import Gender

    field = AbstractField()

    def random_schema() -> dict:
        return {
            'first_name': field('first_name', gender=Gender.MALE),
            'last_name': field('last_name', gender=Gender.MALE),
            'username': field('username', category=Gender.MALE),
            'address': field('address'),
            'email': field('email'),
            'password': field('password', key=str.capitalize)
        }

    schema = Schema(random_schema)
    generated_data = schema.create()

    assert len(generated_data) == 1
    assert isinstance(generated_data, list)
    assert isinstance(generated_data[0], dict)

    generated

# Generated at 2022-06-23 22:07:34.986470
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.schema import (
        Field,
        JSONSchema,
    )

    field = Field()
    schema = JSONSchema({'foo': field.uuid, 'bar': field.uuid}, 'foo')

    s = Schema(schema)
    schema = s.create(3)
    assert isinstance(schema, list)
    assert len(schema) == 3
    assert isinstance(schema[0], dict)
    assert len(schema[0]) == 1
    assert schema[0]['foo'] != schema[0]['bar']

# Generated at 2022-06-23 22:07:37.524383
# Unit test for method create of class Schema
def test_Schema_create():
    def schem1():
        return {
            "color": Field("color_name")
        }

    schema = Schema(schem1)
    schema.create()
    schema.create(iterations=3)

# Generated at 2022-06-23 22:07:43.949728
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis import Person, Address, Internet
    from mimesis.schema import Field

    field = Field(locale='en')
    person = Person('en')
    address = Address('en')
    internet = Internet('en')

    schema = dict(
        name=person.full_name,
        gender=person.gender,
        age=person.age,
        email=internet.email,
        country=address.country,
    )

    s = Schema(schema)

    assert isinstance(s.create(), list)
    assert isinstance(s.create(iterations=2), list)

# Generated at 2022-06-23 22:07:45.726549
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField."""
    assert str(AbstractField()) == 'AbstractField <en>'



# Generated at 2022-06-23 22:07:47.439163
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert isinstance(field('title'), str)



# Generated at 2022-06-23 22:07:50.252340
# Unit test for constructor of class Schema
def test_Schema():
    from .schema import test_schema

    instance = Schema(schema=test_schema)

    assert isinstance(instance, Schema)

# Generated at 2022-06-23 22:07:57.825236
# Unit test for constructor of class Schema
def test_Schema():  # noqa: D202
    from mimesis.providers import Person

    p = Person('en', seed=42)
    schema = Schema(lambda: {
        'name': p.full_name(),
        'birthday': p.birthday(),
        'address': p.address(),
        'email': p.email(),
        'telephone': p.telephone(),
    })
    result = schema.create(2)

# Generated at 2022-06-23 22:08:04.020405
# Unit test for method create of class Schema
def test_Schema_create():
    def _schema():
        return {
            'name': Field('person.name'),
            'age': Field('person.age'),
        }

    schema = Schema(_schema)
    data = schema.create()

    assert isinstance(data, list)
    assert isinstance(data[0], dict)
    assert isinstance(data[0]['name'], str)
    assert isinstance(data[0]['age'], int)

# Generated at 2022-06-23 22:08:08.884601
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert isinstance(field('datetime'), str)
    assert isinstance(field('datetime', iso8601=True), str)

    assert field('bool', key=bool)
    assert not field('bool', key=bool)

    assert ' ' not in field('password')

# Generated at 2022-06-23 22:08:11.633799
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert field('__init__')

    # Test for explicit call of method
    assert field('persian.personal.name') == 'Amin'



# Generated at 2022-06-23 22:08:13.936147
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field() # type: ignore
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:17.938322
# Unit test for method create of class Schema
def test_Schema_create():
    s = Schema(lambda: {
        'name': 'Ryan',
        'surname': 'Reynolds',
    })
    assert s.create(1) == [{'name': 'Ryan', 'surname': 'Reynolds'}]

# Generated at 2022-06-23 22:08:18.533794
# Unit test for constructor of class Schema
def test_Schema():
    Schema(lambda: {'key': 'value'})

# Generated at 2022-06-23 22:08:21.859672
# Unit test for constructor of class Schema
def test_Schema():
    """Test schema class."""
    err = 'Wrong type of schema'
    sch = Schema(Callable)
    assert (str(sch) == 'Schema <{}>'.format(Callable))

# Generated at 2022-06-23 22:08:23.037702
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert (str(AbstractField()) == 'AbstractField <en>')

# Generated at 2022-06-23 22:08:26.716953
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor of class Schema."""
    def schema():  # pragma: no cover
        return None

    s = Schema(schema)
    assert callable(s.schema) is True



# Generated at 2022-06-23 22:08:27.989183
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f  # type: ignore

# Generated at 2022-06-23 22:08:35.634333
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    obj = Field()
    assert obj(name='safe_email')
    assert obj(name='address.street_address')
    assert obj(name='address.city')
    assert obj(name='address.state')
    assert obj(name='address.country')
    assert obj(name='address.postal_code')
    assert obj(name='address.coordinate')
    assert obj(name='address.location')
    assert obj(name='datetime.datetime')
    assert obj(name='datetime.time')
    assert obj(name='datetime.date')
    assert obj(name='datetime.timestamp')
    assert obj(name='datetime.delorean')
    assert obj(name='network.ipv4')

# Generated at 2022-06-23 22:08:37.648188
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # pyre-ignore[11]
    field = Field(locale='en')
    # pyre-ignore[11]
    assert callable(field)

    field('gender')
    field('business.company_name')
    field('gender', key=lambda x: x.upper())

# Generated at 2022-06-23 22:08:42.895486
# Unit test for constructor of class Schema
def test_Schema():
    class Foo:
        @property
        def schema(self):
            pass

    try:
        Schema(Foo())
    except UndefinedSchema as e:
        e.args[0]
    else:
        raise AssertionError('Invalid schema')


# Unit tests for __call__ method of class AbstractField

# Generated at 2022-06-23 22:08:54.263980
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test function for AbstractField.__call__."""
    a = AbstractField()
    r = a('uuid')
    assert r is not None

    r = a('uuid', sep='-', key=lambda x: x.upper())
    assert r is not None

    r = a('datetime.datetime')
    assert r is not None

    r = a('datetime.datetime', year=2018)
    assert r is not None

    r = a('datetime.datetime', year=2018, tzinfo=None)
    assert r is not None

    r = a('datetime.datetime', key=lambda x: str(x))
    assert r is not None

    r = a('datetime.datetime', key=lambda x: x.month)
    assert r is not None


# Generated at 2022-06-23 22:08:56.108476
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of abstract field."""
    data = str(AbstractField())
    assert data == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:58.633806
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import schema as s
    from mimesis.schema import Schema

    assert isinstance(Schema(s.Address()), Schema)



# Generated at 2022-06-23 22:09:01.207001
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert AbstractField('en', 5)

# Generated at 2022-06-23 22:09:07.770218
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema.factory import create_schema

    # Create a schema
    schema = {
        'key1': 'value1',
        'key2': 'value2',
    }
    filled_schema = {
        'key1': 'value1',
        'key2': 'value2',
    }
    final_schema = create_schema(schema)
    assert Schema(final_schema).create(1)[0] == filled_schema


# Generated at 2022-06-23 22:09:10.208455
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for Schema."""
    schema = Schema(schema=lambda: {'foo': 'bar'})
    assert isinstance(schema, Schema)



# Generated at 2022-06-23 22:09:15.061788
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.schema import SchemaProvider
    s = SchemaProvider('en')

    class User:
        name = str
        age = int

    assert isinstance(s.schema(), str)
    assert isinstance(s.schema([1, 2, 3]), List)
    assert isinstance(s.schema({'name': str, 'age': int}), dict)
    assert isinstance(s.schema(User), dict)

# Generated at 2022-06-23 22:09:18.037751
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(lambda: {}).create()) == Schema(
        lambda: {}).create(iterations=10) == 10

# Generated at 2022-06-23 22:09:20.867897
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    field = Field()
    assert str(field) == 'AbstractField <en>'
    assert field('name') is not None


# Generated at 2022-06-23 22:09:22.828178
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Call __str__ method."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:32.252019
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit-test for AbstractField.
    """
    # Case 1:
    f = Field()
    assert f.locale == 'en'
    assert f._gen is not None
    # Case 2:
    f = Field(locale='ru')
    assert f.locale == 'ru'
    assert f._gen is not None
    # Case 3:
    f = Field('en', 1)
    assert f.locale == 'en'
    assert f.seed == 1
    assert f._gen is not None
    # Case 4:
    f = Field(seed=2)
    assert f.seed == 2
    assert f._gen is not None



# Generated at 2022-06-23 22:09:35.805257
# Unit test for constructor of class AbstractField
def test_AbstractField():
    result = AbstractField(locale='ru', seed=12345)
    assert result.locale == 'ru'
    assert isinstance(result._gen, Generic)
    assert isinstance(result._gen.seed, Seed)
    assert result._gen.seed == 12345

# Generated at 2022-06-23 22:09:38.056877
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field(locale='en', seed=42)
    assert f.locale == 'en'
    assert f.seed == 42



# Generated at 2022-06-23 22:09:48.877547
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.builtins import RussiaSpecProvider

    def func_schema_1() -> JSON:
        """Test schema 1."""
        return {
            'name': 'Test 1',
            'surname': 'Test 2',
            'id': 100,
            'age': 18,
        }

    def func_schema_2() -> JSON:
        """Test schema 2."""
        return {
            'name': 'Test 3',
            'surname': 'Test 4',
            'id': 200,
            'age': 25,
        }

    data_1 = Schema(func_schema_1).create(iterations=1)
    data_2 = Schema(func_schema_2).create(iterations=1)
    data_3 = Schema(func_schema_1).create

# Generated at 2022-06-23 22:09:54.673823
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {'name': 'Konstantin'}

    s = Schema(schema)

    # Check default value
    assert s.create() == [{'name': 'Konstantin'}]
    assert s.create(iterations=2) == [
        {'name': 'Konstantin'},
        {'name': 'Konstantin'},
    ]

# Generated at 2022-06-23 22:09:56.933847
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'Field <en>'

    field = Field(locale='ru')
    assert str(field) == 'Field <ru>'

# Generated at 2022-06-23 22:09:57.732206
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert 'AbstractField <en>' == str(f)

# Generated at 2022-06-23 22:10:04.594444
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field
    from mimesis.schema.json import JSONSchema

    field = Field()

    x1 = field('rt')
    x2 = field('rt')
    x3 = field('rt')

    assert bool(x1) != bool(x2) == bool(x3)


# Generated at 2022-06-23 22:10:08.751048
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.address import Address

    def schema() -> dict:
        """Simple schema."""
        return {
            'address': f'{Address().address()}',
        }
    schema_ = Schema(schema)
    data = schema_.create(iterations=5)
    assert len(data) == 5



# Generated at 2022-06-23 22:10:17.897847
# Unit test for method create of class Schema
def test_Schema_create():
    pass

# Generated at 2022-06-23 22:10:19.100950
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert AbstractField(locale='en').__call__('full_name') is not None

# Generated at 2022-06-23 22:10:20.802877
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('word') is not None



# Generated at 2022-06-23 22:10:24.002253
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():  # noqa: WPS213
    """Test __call__ method."""
    field = Field(providers=[{'foo': 1, 'bar': 2}])

    assert field('foo') == 1



# Generated at 2022-06-23 22:10:27.315404
# Unit test for constructor of class AbstractField
def test_AbstractField():
    schema = Field(locale='es', seed=123)
    data = schema('full_name_male')

    assert data is not None
    assert isinstance(data, str)

# Generated at 2022-06-23 22:10:37.023014
# Unit test for method create of class Schema

# Generated at 2022-06-23 22:10:38.786761
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema([])
    assert schema.schema == []

# Generated at 2022-06-23 22:10:47.562575
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    field = f('__getattr__')

    if not isinstance(field, AbstractField):
        raise TypeError('Returned value must be an instance of AbstractField')

    # Case 1
    try:
        f()
    except UndefinedField:
        pass
    else:
        raise UndefinedField()

    # Case 2
    try:
        f('__getattr__')
    except UnacceptableField:
        pass
    else:
        raise UnacceptableField()

    # Case 3
    try:
        f('__getattr__', kw='test')
    except UnsupportedField:
        pass
    else:
        raise UnsupportedField()



# Generated at 2022-06-23 22:10:51.973688
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    schema = Schema(lambda str: {'name': str('name')})
    schemas = schema.create(iterations=10)

    assert isinstance(schemas, list)
    assert len(schemas) == 10

# Generated at 2022-06-23 22:10:54.892734
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    def schema():
        """Example schema."""
        return dict(
            name=Field()(name='full_name'),
            age=Field()(min=18, max=90),
            email=Field()(name='email', key=str.lower),
        )

    schema = Schema(schema)
    result = schema.create(5)
    assert isinstance(result, list)
    assert len(result) == 5

# Generated at 2022-06-23 22:10:56.576692
# Unit test for method create of class Schema
def test_Schema_create():
    def test_schema():
        return {'name': 'Alex', 'age': '20'}

    assert Schema(test_schema).create() == [{
        'name': 'Alex', 'age': '20'}]

# Generated at 2022-06-23 22:10:59.231590
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Test __init__ of class AbstractField
    field = AbstractField()  # noqa
    assert True

# Generated at 2022-06-23 22:11:09.419581
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for Schema.create method."""
    import pytest

    from mimesis.exceptions import UndefinedSchema

    fake = Generic('en')

    def schema_1() -> JSON:
        """Generate a schema 1."""
        return {
            'name': fake.person.full_name(),
            'address': fake.address.address(),
        }

    def schema_2() -> JSON:
        """Generate a schema 2."""
        return {
            'todo': fake.lorem.word(),
            'done': fake.datetime.datetime(),
        }

    for schema in [schema_1, schema_2]:
        s = Schema(schema)
        data = s.create()
        assert len(data) == 1

        data = s.create(5)

# Generated at 2022-06-23 22:11:14.868017
# Unit test for method create of class Schema
def test_Schema_create():
    """Check that method create work correctly."""
    import mimesis.builtins.person

    provider = mimesis.builtins.person.Person(locale='pt-br')

    class PersonSchema:
        """Person schema."""

        def __call__(self):
            """Fill schema."""
            return {
                'name': provider.full_name(),
            }

    person = Schema(PersonSchema())
    people = person.create(iterations=7)

    assert isinstance(people, list) and len(people) == 7

# Generated at 2022-06-23 22:11:16.330668
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert f.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:17.187258
# Unit test for method create of class Schema
def test_Schema_create():
    assert isinstance(Schema.create, AbstractMethod)

# Generated at 2022-06-23 22:11:20.096716
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f is not None
    assert f.locale == 'en'
    assert f.seed is None
    assert f._gen is not None
    assert f._table == {}  # type: ignore

# Generated at 2022-06-23 22:11:22.409665
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    assert field.locale == 'en'

# Generated at 2022-06-23 22:11:23.994475
# Unit test for constructor of class AbstractField
def test_AbstractField():
    instance = AbstractField()
    assert isinstance(instance, AbstractField)

# Generated at 2022-06-23 22:11:33.088793
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Check that all required attributes are exists."""
    # Check that all required attributes are exists.
    assert hasattr(AbstractField, 'locale')
    assert hasattr(AbstractField, 'seed')
    assert hasattr(AbstractField, '_gen')
    assert hasattr(AbstractField, '_table')

    # Check that attributes are correct type.
    assert isinstance(AbstractField().locale, str)
    assert isinstance(AbstractField().seed, (int, type(None)))
    assert isinstance(AbstractField()._gen, Generic)
    assert isinstance(AbstractField()._table, dict)

# Generated at 2022-06-23 22:11:34.810102
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert callable(field)
    assert isinstance(field, Field)

# Generated at 2022-06-23 22:11:35.611896
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:41.787507
# Unit test for method create of class Schema
def test_Schema_create():
    """Test create method."""
    from mimesis import Person, Address
    from mimesis.schema import Field

    person = Person('en')
    address = Address('en')
    person.add_provider(address)

    def create_persons_schema() -> dict:
        """Return a persons schema."""

# Generated at 2022-06-23 22:11:52.252412
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Should return a list of seven elements
    assert len(Field().__call__('get_items', length=7)) == 7
    assert len(Field().__call__('list.get_items', length=7)) == 7

    # Should return a string with a length of 12
    assert len(Field().__call__('password', length=12)) == 12

    # Should return a float between 1 and 10
    assert Field().__call__(
        'float', lte=10, gte=1, precision=1) >= 1

    # Should return a string with a length of 10
    assert len(Field().__call__('uuid', length=10)) == 10

    # Should return a string with a length of 10 and all elements uppercase
    assert Field().__call__('uuid', length=10, key=str.upper) == Field

# Generated at 2022-06-23 22:11:56.549114
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema constructor."""
    s = Schema(lambda: {'name': 'John', 'surname': 'Wick'})
    assert s

    s = Schema(lambda: {'name': 'Rambo', 'surname': 'Stallone'})
    s.create(iterations=3)

# Generated at 2022-06-23 22:12:00.370295
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    f = Field()
    f('email')
    f('full_name', gender='m')
    f('password', length=10)

# Generated at 2022-06-23 22:12:07.270406
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__()."""
    field = Field()

    assert field.__call__('name')
    assert field.__call__('name', key=lambda x: x.capitalize())
    assert field.__call__('number.integer') is not None
    assert callable(field.__call__('number.integer', between=0, end=10))
    assert field.__call__('choice', args=(10, 20)) in (10, 20)

# Generated at 2022-06-23 22:12:10.057872
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    # TODO: fix this test
    # assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:12.057244
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test special method __str__."""
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:14.449692
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField(locale="uk")) == 'AbstractField <uk>'

# Generated at 2022-06-23 22:12:16.018043
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField."""
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:17.824257
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert isinstance(field, AbstractField)
    assert field('address.region') == 'Kentucky'



# Generated at 2022-06-23 22:12:20.381042
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('word')



# Generated at 2022-06-23 22:12:29.228619
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    import json
    import os
    import pytest
    from mimesis.schema import Field

    field = Field()

    def schema() -> json:
        """Return filled schema.

        :return: JSON (dict).
        """
        return {
            'username': field('person.username'),
            'password': field('password'),
            'email': field('email'),
        }

    data = json.dumps(Schema(schema).create(), indent=4)
    with open(os.path.dirname(__file__) + '/data/schema.json') as f:
        schema_data = json.dumps(json.load(f), indent=4)
        assert data == schema_data

# Generated at 2022-06-23 22:12:31.511270
# Unit test for constructor of class Schema
def test_Schema():
    schema_obj = Schema(lambda: {})
    assert isinstance(schema_obj, Schema)



# Generated at 2022-06-23 22:12:34.380196
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method `create` of class `Schema`."""
    schema = Schema(Field)
    assert isinstance(schema.create(iterations=5), list)
    assert isinstance(schema.create(iterations=5), list)
    assert len(schema.create(iterations=5)) == 5
    assert len(schema.create(iterations=10)) == 10

# Generated at 2022-06-23 22:12:41.977854
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # None
    assert Field().__call__(None) == None

    # Acceptable
    assert Field().__call__('country', 'IS') == 'Iceland'

    # Unacceptable
    try:
        Field().__call__('country.en')
    except UnacceptableField:
        assert True

    # Unsupported
    try:
        Field().__call__('unsupported')
    except UnsupportedField:
        assert True

    # Undefined
    try:
        Field().__call__(None)
    except UndefinedField:
        assert True

# Generated at 2022-06-23 22:12:43.338378
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:49.403011
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    from mimesis.enums import Gender

    f = AbstractField()

    assert isinstance(f, Field)


# Generated at 2022-06-23 22:12:52.749794
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis import Person
    from mimesis.schema import Schema, Field

    p = Person('ru')
    f = Field('ru')
    schema = Schema(lambda: {
        'name': p.full_name(),
        'age': f('datetime.datetime_between',
                 key=lambda d: (p.datetime.now() - d).days // 365),
        'phone': p.telephone(),
    })
    data = schema.create(iterations=2)
    assert len(data) == 2

# Generated at 2022-06-23 22:12:53.373026
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-23 22:12:55.791853
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis import Field
    assert Field().__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:04.789415
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import Address, Lorem, Person, ProvidersRegistry

    field = AbstractField()

    name = Person.__name__
    last_name = Person.__dict__['Meta'].last_name

    provider = ProvidersRegistry.get('en', Person)
    assert field('{}.{}'.format(name, last_name)) is provider.last_name()

    words_count = Lorem.__dict__['Meta'].words_count
    provider = ProvidersRegistry.get('en', Lorem)
    assert field('{}.{}'.format(Lorem.__name__, words_count), 3) == \
        provider.words(3)

    address_field = Address.__dict__['Meta'].address_field
    provider = ProvidersRegistry.get('en', Address)

# Generated at 2022-06-23 22:13:12.758994
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('gender') in ('male', 'female')

    assert field('currency') in ('USD', 'EUR', 'CAD', 'AUD')

    assert field('number') in range(1, 10)

    assert 0 <= field('float') <= 9
    assert 0 <= field('float', minimum=1) <= 9
    assert 1 <= field('float', minimum=1) <= 10

    assert field('float', maximum=1) <= 1
    assert field('float', minimum=1, maximum=1) == 1

    assert field('byte') in range(0, 255)

    assert len(field('md5')) == 32

    assert len(field('email')) != 0


# Generated at 2022-06-23 22:13:19.371223
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.date import Date
    from mimesis.providers.address import Address
    from mimesis.providers.contact import Contact
    from mimesis.providers import Person
    import mimesis.schema


# Generated at 2022-06-23 22:13:21.379989
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    # Act
     obj = AbstractField()
     # Assert
     assert str(obj).startswith('AbstractField')



# Generated at 2022-06-23 22:13:22.672025
# Unit test for constructor of class AbstractField
def test_AbstractField():
    instance = Field()
    assert instance._gen.__class__.__name__ == 'Generic'

# Generated at 2022-06-23 22:13:25.543138
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert (
        str(AbstractField(locale='en', seed=None))
        == 'AbstractField <en>'
    )

# Generated at 2022-06-23 22:13:31.759957
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField without providers."""
    a = AbstractField(providers=None) # Providers should be init in __init__

    assert a.locale == 'en'
    assert not a.seed
    assert a.__str__() == 'AbstractField <en>'

    a = AbstractField(seed=42)
    assert a.locale == 'en'
    assert a.seed == 42
    assert a.__str__() == 'AbstractField <en>'

    b = AbstractField(locale='ru', seed=42)
    assert b.locale == 'ru'
    assert b.seed == 42
    assert b.__str__() == 'AbstractField <ru>'



# Generated at 2022-06-23 22:13:32.363793
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('word')

# Generated at 2022-06-23 22:13:38.690092
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    locale = 'en'
    field = Field(locale)

    # Test __call__
    assert field('uuid') == '1c683df3-f5b5-5d40-b1df-b475a4baca2f'
    assert field('uuid', key=lambda x: str(x.__class__)) == str(str)
    assert field('uuid', dashes=False) == 'ffa09685813843d9b48a33c84e0f1c8a'
    assert field('uuid', dashes=False, key=lambda x: str(x.__class__)) == str(str)
    assert field('language_code', field='alpha2') == 'en'
    assert field('language_code', field='alpha3') == 'eng'

# Generated at 2022-06-23 22:13:40.029172
# Unit test for constructor of class Schema
def test_Schema():
    """Test for class Schema."""
    s = Schema({'a': 1})
    assert isinstance(s, Schema)



# Generated at 2022-06-23 22:13:44.112276
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    f = AbstractField()
    assert f.locale == 'en'
    assert callable(f)
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:47.542602
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.providers import Address

    address = Address(seed=0)

    af = AbstractField(providers=[address])

    assert str(af) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:49.882240
# Unit test for constructor of class AbstractField
def test_AbstractField():
    name = 'en'
    seed = 'test_AbstractField'
    field = AbstractField(name, seed)
    assert field.locale == name
    assert field.seed == seed

# Generated at 2022-06-23 22:13:51.819076
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:58.944147
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema.utils import Field, Schema

    def test_schema() -> List[dict]:
        fields = Field()
        return [
            {
                'name': fields('person.full_name'),
                'age': fields('person.age')
            }
        ]

    schema = Schema(test_schema)
    data = schema.create(iterations=100)
    assert isinstance(data, list)
    assert len(data) == 100

# Generated at 2022-06-23 22:14:01.797726
# Unit test for constructor of class AbstractField
def test_AbstractField():
    alpha = AbstractField('en', providers=('Person',))
    assert alpha is not None
    assert alpha._gen is not None
    assert alpha._gen.person is not None

# Generated at 2022-06-23 22:14:13.208576
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.lorem import Lorem

    providers = {
        'person': Person,
        'internet': Internet,
        'lorem': Lorem,
    }

    af = AbstractField(locale='en', seed=42, providers=providers)
    assert af('gender') == Gender.MALE.value
    assert af('username') == 'doedorothy932'
    assert af('lorem.word') == 'consectetur'
    assert af('person.full_name') == 'Ashley Smith'

# Generated at 2022-06-23 22:14:17.742997
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.enums import Gender

    def gender_schema() -> dict:
        """Gender schema."""
        gender = Gender.MALE.value if Field().boolean() else Gender.FEMALE.value
        return {'gender': gender}

    assert gender_schema is not None
    Schema(gender_schema)

# Generated at 2022-06-23 22:14:19.503705
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field is not None
    assert field('uuid')

# Generated at 2022-06-23 22:14:29.136896
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Test 1
    try:
        AbstractField()()
        assert False
    except UndefinedField:
        assert True

    # Test 2
    try:
        AbstractField()('foo')
        assert False
    except UnsupportedField:
        assert True

    # Test 3
    try:
        AbstractField()('foo.bar')
        assert False
    except UnsupportedField:
        assert True

    # Test 4
    try:
        AbstractField()(
            'foo.bar',
            provider='generic',
        )
        assert False
    except UnsupportedField:
        assert True

    # Test 5
    try:
        AbstractField()(
            'foo.bar.baz',
            provider='generic',
        )
        assert False
    except UnacceptableField:
        assert True

    # Test 6

# Generated at 2022-06-23 22:14:29.836875
# Unit test for constructor of class AbstractField
def test_AbstractField():
    AbstractField()

# Generated at 2022-06-23 22:14:32.701407
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    field = AbstractField(locale='es')
    assert str(field) == 'AbstractField <es>'

# Generated at 2022-06-23 22:14:39.146274
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Tests method __call__ of class AbstractField."""
    af = AbstractField()
    result = af('uuid')

    assert isinstance(result, str)
    assert len(result) == 36

    result = af('uuid', dash=False)

    assert isinstance(result, str)
    assert len(result) == 32

    result = af('uuid', dash=False, prefix='test.')
    assert result.startswith('test.')

    result = af('uuid', prefix='test.', dash=False)
    assert result.startswith('test.')

    # Test for tail parser
    result = af('food.fruit_name')
    assert isinstance(result, str)

    # Test for non-existent field

# Generated at 2022-06-23 22:14:45.232158
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for .create()."""

    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet

    field = Field(providers=[Internet, Address])

    @field.schema
    def user_schema() -> JSON:
        """Return JSON."""

# Generated at 2022-06-23 22:14:54.510880
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert Field().__call__('gender') in ['Male', 'Female']
    assert Field().__call__('name') != ''
    assert Field().__call__('postcode') != ''
    assert Field().__call__('postcode') != ''

    assert Field().__call__('uuid4') == Field().uuid4()
    assert Field().__call__('uuid4') != ''
    assert len(Field().__call__('uuid4')) == 36

    uuid4 = Field().__call__('uuid4')
    assert Field().__call__('uuid4', key=lambda x: uuid4 in x)

