

# Generated at 2022-06-23 22:04:51.547586
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.animals import Animals, Pets
    from mimesis.providers.vehicles import Vehicles

    _providers = [BaseProvider, Animals, Pets, Vehicles]
    field = Field(providers=_providers)

    assert field
    assert field._gen
    assert all(provider in dir(field._gen) for provider in _providers)

# Generated at 2022-06-23 22:04:53.946764
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test the behaviour of method __str__ of class AbstractField."""
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:04:54.537383
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field()

# Generated at 2022-06-23 22:05:04.206409
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test initializing of the AbstractField class."""
    provider_name = 'person'
    method_name = 'full_name'
    provider_full_name = '{}.{}'.format(provider_name, method_name)
    field = AbstractField()
    # Let's check that class find the first provider which has needed method
    assert field(method_name) == getattr(getattr(field._gen, provider_name), method_name)()
    # Let's be more accurate. We want to choose a method from the Person provider.
    assert field(provider_full_name) == getattr(getattr(field._gen, provider_name), method_name)()

# Generated at 2022-06-23 22:05:06.197327
# Unit test for method create of class Schema
def test_Schema_create():
    s = Schema(lambda: {'test': 1})
    assert isinstance(s.create(1), list)

# Generated at 2022-06-23 22:05:11.757979
# Unit test for method create of class Schema
def test_Schema_create():
    def _test_schema() -> JSON:
        """Create a simple schema."""
        return {'a': 1, 'b': 2}

    schema = Schema(_test_schema)
    result = schema.create(iterations=10)

    assert len(result) == 10
    assert 1 in result
    assert 2 in result

# Generated at 2022-06-23 22:05:14.719583
# Unit test for constructor of class Schema
def test_Schema():
    Schema(lambda: {'foo': 1})

    try:
        Schema({})
    except UndefinedSchema:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-23 22:05:17.276514
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert AbstractField()(
        'full_name',
        key=lambda x: ' '.join(x.split(' ')[:2])
    ) is not None

# Generated at 2022-06-23 22:05:22.229963
# Unit test for constructor of class Schema
def test_Schema():
    from unittest.mock import MagicMock
    from mimesis.schema import Schema

    def provide_schema():
        return 'Just a test'

    schema = Schema(provide_schema)
    assert isinstance(schema, Schema)

    # Raise the exception
    mock = MagicMock()
    mock.__call__ = MagicMock(side_effect=AssertionError)
    with pytest.raises(AssertionError):
        Schema(mock)


# Generated at 2022-06-23 22:05:24.527144
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check AbstractField.__str__."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:33.677193
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    a = Field()
    # Assert of method call with invalid provider name
    try:
        a('invalid-provider.invalid')
        assert False
    except UndefinedField as e:
        assert True

    # Assert of method call with invalid field name
    try:
        a('invalid-field')
        assert False
    except UnsupportedField as e:
        assert True

    # Assert of method call with valid field name
    try:
        a('personal.md5')
        assert True
    except UnsupportedField as e:
        assert False

    # Assert of method call with valid field name
    try:
        a('invalid-provider.md5')
        assert False
    except UnacceptableField as e:
        assert True

# Generated at 2022-06-23 22:05:39.149361
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.enums import Gender

    def schema():
        return {
            'person': {
                'sex': 'sex',
                'full_name': 'full_name',
                'age': 22,
                'address': {
                    'address': 'address',
                    'country': 'country'
                }
            }
        }

    sch = Schema(schema)
    assert sch.create(iterations=10)[0]['person']['sex'] in Gender.ALL
    assert len(sch.create(iterations=10)[0]['person']['full_name']) > 0
    assert isinstance(
        sch.create(iterations=10)[0]['person']['age'], int)

# Generated at 2022-06-23 22:05:40.944684
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()

    assert field.locale == 'en'
    assert field.seed is None

# Generated at 2022-06-23 22:05:44.190947
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    field = AbstractField('en')
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:05:46.350999
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    name = 'person.name'
    assert field(name) == field(name, with_middle=False)

# Generated at 2022-06-23 22:05:55.730443
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    def test_call_1():
        field = Field(seed=42)

        assert field('person.name') == 'Nathan Bailey'
        assert field('person.full_name', key=lambda x: x.split()[0]) == 'Nathan'

    def test_call_2():
        field = Field(seed=42)

        assert field('full_name', key=lambda x: x.split()[0]) == 'Nathan'

    def test_call_3():
        field = Field(seed=42)

        try:
            field('person.full_name', key=lambda x: x.split()[0])  # type: ignore
        except UndefinedField as err:
            assert str(err) == '`name` parameter is not defined'


# Generated at 2022-06-23 22:05:59.191367
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__.

    Try to call the method ``__call__`` of the class
    :class:`~mimesis.schema.AbstractField` and return value of that call.
    """
    field = Field()
    assert callable(field)
    return field('__call__')



# Generated at 2022-06-23 22:06:09.818155
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method AbstractField.__call__."""
    from mimesis.providers.address import Address
    from mimesis.providers.text import Text

    class MyAddress(Address):
        """Custom class for test."""

        def foo(self):
            """Sample method."""
            return self.seed + 1

        def bar(self):
            """Another sample method."""
            return self.seed + 2

        def baz(self):
            """Another sample method."""
            return self.seed + 3

    a = Field(seed=50)

    assert a('city') == 'New York'
    assert a('city', seed=50) == 'New York'

    assert a('city', country_code='EN') == 'London'

# Generated at 2022-06-23 22:06:12.018925
# Unit test for method create of class Schema
def test_Schema_create():
    schema = [{'name': 'jane', 'age': 18}]

    expected = [{'name': 'jane', 'age': 18}, {'name': 'jane', 'age': 18}]
    result = Schema(schema).create(2)
    assert result == expected



# Generated at 2022-06-23 22:06:15.680004
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = Field()
    assert field('full_name') is not None



# Generated at 2022-06-23 22:06:16.217063
# Unit test for constructor of class AbstractField
def test_AbstractField():
    pass

# Generated at 2022-06-23 22:06:18.903908
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field(locale='ru', seed=12345)
    assert f.locale == 'ru'
    assert f.seed == 12345
    assert isinstance(f, AbstractField)



# Generated at 2022-06-23 22:06:23.718636
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__ method."""
    field = AbstractField()
    assert isinstance(
        field('full_name'),
        str,
    )
    assert isinstance(
        field('enums.color'),
        str,
    )
    assert isinstance(
        field('internet.url'),
        str,
    )

# Generated at 2022-06-23 22:06:28.011334
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': Field().name(),
            'age': Field().age(),
            'email': Field().email(),
        }

    Schema(schema).create(iterations=5)
    Schema(schema).create(iterations=5)

# Generated at 2022-06-23 22:06:35.280284
# Unit test for method create of class Schema
def test_Schema_create():
    #  Count of iterations
    iterations = 3

    # Example of a schema
    d = {
        "name": "sasha",
        "age": "18",
        "gender": "female",
        "address": "New York, 17",
        "email": "sasha@mail.com",
    }

    class Example:
        def __init__(self, *args, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    results = Schema(Example).create(iterations)

    assert len(results) == iterations
    assert results[0].name == d['name']
    assert results[0].age == d['age']
    assert results[0].gender == d['gender']
    assert results[0].address == d['address']
    assert results

# Generated at 2022-06-23 22:06:36.861186
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    t = AbstractField()
    assert 'AbstractField <en>' == str(t)



# Generated at 2022-06-23 22:06:38.890781
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema():
        """Return a test schema.
        """
        return {
            'country': 'field.country'
        }

    schema = Schema(test_schema)
    result = schema.create(1)
    assert result[0]['country']
    assert len(result) == 1

# Generated at 2022-06-23 22:06:44.240709
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import Person

    def schema():
        return {
            'name': Person().name(),
            'age': Person().age(),
            'birthday': Person().birthday(),
        }

    s = Schema(schema)
    assert isinstance(s, Schema)
    assert isinstance(s.create(), list)
    assert len(s.create()) == 1
    assert len(s.create(3)) == 3
    assert len(s.create(iterations=10)) == 10

    # Undefined schema
    # incorrect schema
    # with pytest.raises(UndefinedSchema):
    #     Schema({})

# Generated at 2022-06-23 22:06:45.864408
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:55.354463
# Unit test for method create of class Schema
def test_Schema_create():  # pragma: no cover
    from mimesis.enums import Gender
    from mimesis.providers import Person

    def schema() -> JSON:
        return {
            'first_name':
                Field('person.first_name', gender=Gender.MALE),
            'last_name':
                Field('person.last_name'),
            'age':
                Field('person.age', minimum=18, maximum=90),
            'is_funny':
                Field('boolean.boolean', key=lambda x: 'Yes' if x else 'No'),
        }

    s = Schema(schema)

    assert isinstance(s.create(3), list)
    assert len(s.create(3)) == 3
    assert isinstance(s.create(3)[0], dict)

# Generated at 2022-06-23 22:06:56.882762
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('World') == 'World'
    assert isinstance(f('World', is_capitalized=True), str)
    assert isinstance(f('World', is_capitalized=False, key=str.upper), str)

# Generated at 2022-06-23 22:06:59.864358
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = Field()
    assert isinstance(field('text'), str)
    assert isinstance(field('integer'), int)
    assert isinstance(field('telephone'), str)
    assert isinstance(field('uuid', version=4), str)
    assert isinstance(field('uuid', version=3), str)
    assert isinstance(field('uuid', version=5), str)
    assert isinstance(field('uuid', version=1), str)



# Generated at 2022-06-23 22:07:02.085479
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema."""
    s = Schema(lambda: {})
    assert s.schema() == {}



# Generated at 2022-06-23 22:07:10.578049
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert field('full_name', gender='male')
    assert field('full_name', gender='female')
    assert field('full_name', gender='non-binary')
    assert field('full_name', gender='non-binary', capitalize=True)
    assert field('full_name', gender='male', capitalize=True)
    assert field('full_name', gender='female', capitalize=True)

    assert field('full_name', gender='male', position=1)
    assert field('full_name', gender='male', position=2)

    assert field('internet.user_agent', os='linux')
    assert field('internet.user_agent', os='windows')
    assert field('internet.user_agent', os='macos')
    assert field('internet.user_agent', os='ios')
    assert field

# Generated at 2022-06-23 22:07:12.085429
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:18.699009
# Unit test for method create of class Schema
def test_Schema_create():
    sample_data = [{
        "key_1": "val_1",
        "key_2": "val_2",
    }]

    def key_2_factory():
        return Field(providers=['datetime'])()

    schema = {
        'key_1': 'val_1',
        'key_2': key_2_factory,
    }

    assert (Schema(lambda: schema).create(iterations=3)
            == sample_data * 3)

# Generated at 2022-06-23 22:07:26.498854
# Unit test for method create of class Schema
def test_Schema_create():
    """Test case for function create."""
    import pytest
    from mimesis.schema import Field, Schema

    field = Field()

    def schema() -> dict:
        """Schema of dictionary."""
        return {
            'param': field('metadata.description', length=10),
            'param2': field('fake.text', length=10),
        }

    schema_instance = Schema(schema)
    result = schema_instance.create(2)

    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], dict)

    with pytest.raises(UndefinedSchema):
        Schema('schema')

# Generated at 2022-06-23 22:07:27.660872
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    assert(isinstance(Field(), AbstractField))

# Generated at 2022-06-23 22:07:28.745059
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.locale == 'en'



# Generated at 2022-06-23 22:07:35.405748
# Unit test for method create of class Schema
def test_Schema_create():  # pylint: disable=invalid-name
    """Test Schema.create method."""
    import pytest
    from mimesis.typing import JSON

    _Schema = Schema

    with pytest.raises(UndefinedSchema):
        _Schema(None)

    with pytest.raises(TypeError):
        _Schema(lambda: None)

    iterations = 10
    s = _Schema(lambda: {'data': 'generated'})
    schema = s.create(iterations)

    assert isinstance(schema, list)
    assert len(schema) == iterations
    assert isinstance(schema[0], JSON)
    assert schema[0] == {'data': 'generated'}

# Generated at 2022-06-23 22:07:43.278736
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert AbstractField().__call__('name', full_name=True)
    assert AbstractField().__call__('address', full_address=True)
    assert AbstractField().__call__('internet', protocol='ipv4')
    assert AbstractField().__call__('currency', code='USD')
    assert AbstractField().__call__('person', gender='M')
    assert AbstractField().__call__('code', length=6)

    try:
        AbstractField().__call__('currency', foo='USD')
    except TypeError:
        pass
    else:
        assert False

    try:
        AbstractField().__call__('foo')
    except UnsupportedField:
        pass
    else:
        assert False

    assert AbstractField().__call__('code', length=6)

# Generated at 2022-06-23 22:07:45.561776
# Unit test for method create of class Schema
def test_Schema_create():
    s = Schema(lambda: {'id': 1, 'name': 'foo'})
    data = s.create(2)
    print(data)


if __name__ == "__main__":
    test_Schema_create()

# Generated at 2022-06-23 22:07:47.038229
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField."""
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:51.207500
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda: {'id': lambda: 1, 'data': lambda: 'test'})
    result = schema.create(5)
    assert result == [{'id': 1, 'data': 'test'} for _ in range(5)]

# Generated at 2022-06-23 22:07:56.958541
# Unit test for constructor of class Schema
def test_Schema():
    from .faker import Fake
    from .build import Build
    from .structures import Address

    assert isinstance(Address.address(), dict)

    assert isinstance(Address.latitude(), float)
    assert isinstance(Address.longitude(), float)

    assert isinstance(Fake.username(), str)

    build = Build()
    assert isinstance(build.first_name(), str)
    assert isinstance(build.last_name(), str)
    assert isinstance(build.name(), str)
    assert isinstance(build.address(), str)
    assert isinstance(build.email(), str)

# Generated at 2022-06-23 22:08:05.186003
# Unit test for constructor of class Schema
def test_Schema():
    """Test class constructor of Schema."""
    schema_one = {
        'name': 'Ivan',
        'surname': 'Petrov',
        'age': 22,
    }

    def schema_two():
        return {
            'name': 'Ivan',
            'surname': 'Petrov',
            'age': 22,
        }

    s_one = Schema(schema_one)
    assert s_one.schema == schema_one

    s_two = Schema(schema_two)
    assert s_two.schema == schema_two

# Generated at 2022-06-23 22:08:06.998956
# Unit test for constructor of class Schema
def test_Schema():
    schema = {"a": 1, "b": 2}
    s = Schema(schema)

    assert s.schema == schema

# Generated at 2022-06-23 22:08:09.764188
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    # Arrange
    field = Field()
    # Act
    result = str(field)
    # Assert
    assert result == 'AbstractField <en>'


# Generated at 2022-06-23 22:08:16.550250
# Unit test for method create of class Schema
def test_Schema_create():
    field = Field()
    data = dict(id=field('uuid4'),
                name=field('full_name'),
                email=field('email'))

    schema = Schema(data)

    data = schema.create(2)
    assert len(data) == 2
    assert isinstance(data, list)


if __name__ == '__main__':
    test_Schema_create()

# Generated at 2022-06-23 22:08:23.495867
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema, Field

    def schema():
        return {
            'name': Field('full_name'),
            'age': Field('age')
        }

    s = Schema(schema)
    result = s.create(10)

    assert len(result) == 10
    assert 'name' in result[0]
    assert 'age' in result[0]

    def schema_with_key():
        return {
            'name': Field('full_name', key=lambda x: x.upper()),
            'age': Field('age')
        }

    s = Schema(schema_with_key)
    result = s.create(10)

    assert len(result) == 10
    assert 'name' in result[0]
    assert 'age' in result[0]
   

# Generated at 2022-06-23 22:08:29.508274
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None

    assert field.locale == field('locale')

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'

    field = AbstractField(locale='ru', seed='value')
    assert field.locale == 'ru'
    assert field.seed == 'value'
    assert field('locale') == 'ru'

# Generated at 2022-06-23 22:08:31.092150
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # This will raise UndefinedField exception
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:08:40.537646
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    from mimesis.providers.internet import Internet
    from mimesis.providers.identifiers import (
        UniversalProductCode,
        Passport,
        InternationalStandardBookNumber,
    )

    providers = (Internet, UniversalProductCode, Passport,
                 InternationalStandardBookNumber)
    f = Field(locale='ru', providers=providers)
    # Some methods have the same names in different providers
    # Explicitly define the provider name
    assert 'http' in f('internet.http', scheme='https')
    assert 'http' in f('http', scheme='https')
    assert 'http' in f('internet.http', scheme='https')
    assert 'http' in f('http', scheme='https')

# Generated at 2022-06-23 22:08:47.889724
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.address import Address
    from mimesis.providers.build import Build

    def schema():
        return {'address': Address(locale='en').full_address()}

    field = Field(locale='en', providers=[Build])
    s = Schema(schema)
    assert isinstance(s, Schema)

    record = s.create(iterations=1)[0]
    assert record['address'] == field('full_address')

# Generated at 2022-06-23 22:08:50.423050
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> JSON:
        return {'name': 'Ivan'}

    s = Schema(schema)
    assert isinstance(s, Schema)



# Generated at 2022-06-23 22:08:53.479537
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Checks if method __str__ return correct value."""
    field = Field(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:08:56.896873
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Person
    from mimesis.schema import Field

    schema = Schema(Person(Field('en')))

    assert hasattr(schema, 'schema')
    assert schema.schema is not None

# Generated at 2022-06-23 22:08:57.889359
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField)

# Generated at 2022-06-23 22:09:04.930259
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Test with an accepted name of method
    # (which belongs to any supported data provider)
    assert Field().__call__('uuid4')

    # Test with a name of method which
    # doesn't belong to any supported data provider
    assert Field().__call__('not_exists') is None

    # Test with a name of method from a specific data provider
    assert Field().__call__('datetime.timestamp')

    # Test with a name of method from a specific data provider
    # which doesn't have this method
    assert Field().__call__('foo.bar') is None

    # Test with a name of method which accepts more than 1 argument
    assert Field().__call__('times_x', multiplier=2, x=3) is not None

# Generated at 2022-06-23 22:09:13.963848
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test if AbstractField.__call__() works well."""
    sim = Schema(lambda: {
        'name': Field(name='username'),
        'email': Field(name='internet.email'),
        'password': Field(name='password'),
        'address': Field(name='address.address')
    })

    data = sim.create(10)
    assert isinstance(data, list)
    assert len(data) == 10

    assert isinstance(data[0], dict)
    assert len(data[0]) == 4

    assert data[0]['name']
    assert data[0]['email']
    assert data[0]['password']
    assert data[0]['address']

# Generated at 2022-06-23 22:09:25.003980
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""

    field = Field(locale='ru', seed=12345)

    assert field('email.safe_email', provider='internet') == 'c.burtsev@mail.ru'
    assert field('email.safe_email', provider='fake') == 'zubkov@mail.ru'
    assert field('full_name', gender='M') == 'Константин Васильевич Демидов'
    assert field('full_name', gender='F') == 'Екатерина Ивановна Труханова'

# Generated at 2022-06-23 22:09:29.716215
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test AbstractField.__str__()."""
    field = AbstractField()
    assert field.__str__() == 'AbstractField <en>'
    field.locale = 'ru'
    field.seed = 10
    assert field.__str__() == 'AbstractField <ru>'

# Generated at 2022-06-23 22:09:39.164769
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField."""
    from mimesis.providers.internet import Internet

    internet_provider = Internet('ru')
    field = AbstractField(locale='ru', providers=[internet_provider])

    assert field.locale == 'ru'
    assert field.seed is None

    assert field('email') is not None

    assert field('email', key=lambda x: '@' in x) is True

    assert field('email', domain='yandex.ru') is not None

    assert field('email',
                 key=lambda x: x.split('@')[1] == 'yandex.ru') is True

    assert field('internet.email') is not None

    assert field('internet.email', key=lambda x:
                 '@' in x) is True


# Generated at 2022-06-23 22:09:49.375530
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for ``__call__`` method of class ``AbstractField``."""
    f = AbstractField()

    assert f('field', key=lambda x: None) is None
    assert f('field.field', key=lambda x: None) is None
    assert f('field.field.field') is None
    assert f('field', field=10) is None
    assert f('field', 10) is None
    assert f('field.field', 10) is None
    assert f('field.field.field', 10) is None

    assert f('first_name')
    assert f('first_name.first')
    assert f('first_name.first.first') is None

    assert f('datetime')
    assert f('datetime.datetime')
    assert f('datetime.datetime.datetime') is None

    assert f

# Generated at 2022-06-23 22:09:55.480486
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.builtins import RussiaSpecProvider

    def key(val: int) -> int:
        """Key function."""
        return val + 10

    field = AbstractField(providers=[RussiaSpecProvider])
    assert field('person.full_name')
    assert field('person.full_name') == field('full_name')
    assert field('postcode')
    assert field('postcode', key=key) == field('postcode') + 10
    field('not_valid')

# Generated at 2022-06-23 22:09:56.465991
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('active') is False

# Generated at 2022-06-23 22:09:58.015563
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)
    assert isinstance(field._gen, Generic)

# Generated at 2022-06-23 22:10:04.140263
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    class Callable(object):
        def __call__(self):
            return 1

        def __str__(self):
            return 'Callable objects'

    schema = {
        'name': 'Ivan',
        'surname': 'Ivanov',
        'age': 18,
        'phone_number': '+7 (999) 999-99-99',
        'phone_number_1': '+1 (999) 999-99-99',
        'phone_number_2': '+7 (999) 999-99-99',
        'address': 'The address',
        'email': 'example@email.com',
        'field_with_key': lambda: 'Field with key',
        'callable_field': Callable(),
    }

    field

# Generated at 2022-06-23 22:10:09.018834
# Unit test for constructor of class Schema
def test_Schema():
    class Schema:
        def __call__(self):
            return True

    s = Schema()

    result = Schema(s).create(iterations=5)
    assert len(result) == 5
    assert result == [True, True, True, True, True]


if __name__ == '__main__':
    test_Schema()

# Generated at 2022-06-23 22:10:11.016723
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema
    from mimesis.schema import Field
    
    schema = Schema(Field)
    assert schema.schema is not None
    assert isinstance(schema.schema, Field)



# Generated at 2022-06-23 22:10:17.448996
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import Provider
    from mimesis.providers.internet import Internet

    field = AbstractField()
    internet = Internet()

    assert isinstance(field('mac_address'), str)
    assert isinstance(field('mac_address', delimiter='-'), str)
    assert isinstance(field('mac_address',
                            key=lambda x: x.count('-')), int)
    assert isinstance(field('mac_address', provider=internet), str)
    assert isinstance(field('mac_address',
                            provider=internet,
                            key=lambda x: x.count('-'),
                            delimiter='-'), int)

    assert isinstance(field('ipv4', ip_version=4, prefix=False), str)

# Generated at 2022-06-23 22:10:20.891784
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    field = AbstractField()

    assert isinstance(field, AbstractField)
    assert isinstance(field, object)
    assert field.locale == 'en'
    assert field.seed is None

# Generated at 2022-06-23 22:10:31.367987
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    fld = AbstractField()

    def test_func(x: int) -> int:
        """Test function."""
        return x + 1

    assert fld('datetime', format='%d.%m.%Y')
    assert fld('person.full_name')

    assert fld('person.full_name', fmt='lF') == fld('person.full_name', fmt='lF')
    assert fld('person.full_name', fmt='lF') != fld('person.full_name', fmt='l')
    assert fld('person.full_name', fmt='F') != fld('person.full_name', fmt='f')


# Generated at 2022-06-23 22:10:33.519195
# Unit test for constructor of class AbstractField
def test_AbstractField():  # noqa: D103
    assert issubclass(AbstractField, object)
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:10:36.575383
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field(locale='ru')
    field(name='code.numeric_code')
    field(name='code.postal_code', mask='#####')

# Generated at 2022-06-23 22:10:38.287010
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:10:41.693385
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': 'Eve',
        'age': 12,
    }
    field = Schema(schema)
    assert isinstance(field.create(), list)  # pylint: disable=no-member

# Generated at 2022-06-23 22:10:45.056798
# Unit test for constructor of class AbstractField
def test_AbstractField():
    _field = AbstractField()
    _is_instance = isinstance(_field, AbstractField)
    assert _is_instance is True, \
        'Should be instance of AbstractField, got {}' \
        .format(type(_field))

# Generated at 2022-06-23 22:10:45.836510
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema

# Generated at 2022-06-23 22:10:47.273612
# Unit test for constructor of class AbstractField
def test_AbstractField():  # pragma: no cover
    _ = AbstractField()



# Generated at 2022-06-23 22:10:51.372422
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert 'en' == f.locale
    assert f.seed is None

    f = AbstractField('it', 1234)
    assert 'it' == f.locale
    assert 1234 == f.seed

# Generated at 2022-06-23 22:10:54.742359
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField class."""
    field = Field()
    result = field('uuid4', hex=False)
    assert isinstance(result, list)
    result = field('uuid4', seed=42, hex=False)
    assert isinstance(result, list)
    result = field('currency', code=True)



# Generated at 2022-06-23 22:10:59.187810
# Unit test for constructor of class Schema
def test_Schema():
    """Test and show the usage of class Schema."""
    import mimesis.data

    def schema():
        """Schema."""
        return {
            'name': '{{ person.full_name() }}',
            'email': '{{ person.email() }}',
        }

    data = mimesis.data.Data()
    SCHEMA = Schema(schema)
    print(SCHEMA.create(100))



# Generated at 2022-06-23 22:11:00.214095
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # TODO: Implement tests for class AbstractField
    pass

# Generated at 2022-06-23 22:11:10.190926
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Check AbstractField.__call__."""
    field = AbstractField()

    expected = '<class \'mimesis.data.LoremIpsum\'>'
    result = str(type(field.lorem()))
    assert result == expected, \
        '{} != {}'.format(result, expected)

    expected = '<class \'mimesis.data.LoremIpsum\'>'
    result = str(type(field('lorem')))
    assert result == expected, \
        '{} != {}'.format(result, expected)

    expected = '<class \'mimesis.data.LoremIpsum\'>'
    result = str(type(field('lorem_ipsum')))
    assert result == expected, \
        '{} != {}'.format(result, expected)

# Generated at 2022-06-23 22:11:15.451260
# Unit test for method create of class Schema
def test_Schema_create():
    """Test that create method of class Schema working correctly."""

    from mimesis import Person, Address, Food

    schema = Schema(lambda: {
        'Name': Person('en').full_name(),
        'Address': Address('en').address(),
        'Food': Food('en').vegetable(),
    })

    result = schema.create()
    assert len(result) == 1



# Generated at 2022-06-23 22:11:17.212484
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    actual = str(field)
    expected = 'AbstractField <en>'
    assert actual == expected

# Generated at 2022-06-23 22:11:19.236618
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():  # noqa: D103
    field = Field()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:11:21.988695
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test class AbstractField."""
    f = Field()
    assert f('random.token')
    assert f('en.first_name')
    assert f('first_name')

# Generated at 2022-06-23 22:11:32.880349
# Unit test for method create of class Schema
def test_Schema_create():
    import json

    from mimesis.schema import Field, Schema
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    field = Field(locale='en')

    class SuperPerson(Person):

        def name(self, gender: Gender = None) -> str:
            return self.first_name(gender)

    schema = Schema(field.test)
    schema._schema = SuperPerson(seed=1).test

    assert json.dumps(schema.create(iterations=10)) == \
        '["Test123", "Test123", "Test123", "Test123", "Test123", ' \
        '"Test123", "Test123", "Test123", "Test123", "Test123"]'

# Generated at 2022-06-23 22:11:37.352553
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {
            'id': 'id',
            'first_name': 'first_name',
            'last_name': 'last_name',
        }

    sche = Schema(schema)
    assert isinstance(sche, Schema)

    with sche.create(1)[0] as s:
        assert s['id'] == 'id'
        assert s['first_name'] == 'first_name'
        assert s['last_name'] == 'last_name'

# Generated at 2022-06-23 22:11:47.886274
# Unit test for method create of class Schema
def test_Schema_create():
    import mimesis
    import mimesis.enums
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.schema import Schema

    class CustomSchema(RussiaSpecProvider):

        @classmethod
        def custom(cls):
            return {
                'first_name': cls.person.name(),
                'last_name': cls.person.surname(),
                'age': cls.datetime.age(),
                'department': cls.org.department(),
                'skills': [
                    cls.science.discipline()
                    for _ in cls.datetime.age(
                        minimum=10, maximum=20, distribution=50
                    ).split(',')
                ]
            }

    data = Schema(CustomSchema.custom)
    assert data.create

# Generated at 2022-06-23 22:11:49.408751
# Unit test for constructor of class Schema
def test_Schema():
    from . import Person
    s = Schema(Person)

# Generated at 2022-06-23 22:11:59.142590
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='en', seed=123456789)
    assert field.locale == 'en'
    assert field.seed == 123456789
    assert str(field) == 'AbstractField <en>'

    assert field()
    assert field(name='codepoint')
    assert field(name='codepoint')
    assert field(name='codepoint')
    assert field(name='codepoint')
    assert field(name='codepoint')
    assert field(name='codepoint')
    assert field(name='codepoint')
    assert field(name='codepoint')
    assert field(name='codepoint')
    assert field(name='codepoint')
    assert field(name='codepoint')
    assert field(name='codepoint')

# Generated at 2022-06-23 22:12:05.675860
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': 'Text',
        'surname': 'Text',
        'age': 'Integer',
        'address': {
            'country': 'Text',
            'city': 'Text',
        }
    }

    def generator():
        return schema

    schema = Schema(generator)
    s = schema.create(iterations=10)
    print(s)

# Generated at 2022-06-23 22:12:07.272606
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:12.592699
# Unit test for constructor of class Schema
def test_Schema():
    # Define schema
    schema = Schema(lambda: {
        'name': {},
        'age': {},
        'id': {},
    })

    # Return list of filled schemas
    result = schema.create(iterations=10)
    assert isinstance(result, list)
    assert len(result) == 10



# Generated at 2022-06-23 22:12:17.220061
# Unit test for method create of class Schema
def test_Schema_create():
    test_schema = {
        'a': 1,
        'b': []
    }

    schema = Schema(lambda: test_schema)
    assert schema.create(3) == [
        test_schema,
        test_schema,
        test_schema,
    ]

# Generated at 2022-06-23 22:12:20.774574
# Unit test for constructor of class Schema
def test_Schema():
    import mimesis.schema.schemas as ss
    assert isinstance(Schema(ss.AddressSchema), Schema)

# Generated at 2022-06-23 22:12:22.125439
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:23.487249
# Unit test for constructor of class Schema
def test_Schema():
    def test():
        return {}

    test()


# Generated at 2022-06-23 22:12:28.076604
# Unit test for method create of class Schema
def test_Schema_create():
    """Test class Schema."""
    _field = Field()
    _schema = Schema(
        _field('person.full_name'),  # pylint: disable=no-value-for-parameter
    )
    assert _schema.create(3) == [{'full_name': _field('person.full_name')}
                                 for _ in range(3)]

# Generated at 2022-06-23 22:12:29.120687
# Unit test for constructor of class Schema
def test_Schema():
    assert callable(Schema(lambda: []))

# Generated at 2022-06-23 22:12:30.600057
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.locale == 'en'

# Generated at 2022-06-23 22:12:32.001397
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:33.405153
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field1 = Field()
    assert isinstance(field1.__str__(), str)

# Generated at 2022-06-23 22:12:35.271305
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    af = AbstractField()
    assert af.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:41.014310
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='en', seed=12345)
    assert field.locale == 'en'
    assert field.seed == 12345
    assert field._gen  # noqa

    field = AbstractField(locale='uk', seed=12345)
    assert field.locale == 'uk'
    assert field.seed == 12345
    assert field._gen  # noqa


# Generated at 2022-06-23 22:12:45.164267
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> SchemaType:
        return {
            'name': 'name',
            'age': 18,
            'email': 'email',
        }

    schema = Schema(schema)
    result = schema.create()

    assert len(result) == 1
    assert result[0]['name'] == 'name'
    assert result[0]['age'] == 18
    assert result[0]['email'] == 'email'

# Generated at 2022-06-23 22:12:46.336328
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test __str__ method."""
    f = Field()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:48.445014
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'


# Generated at 2022-06-23 22:12:50.502191
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test the method __str__ of class AbstractField."""
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:02.257649
# Unit test for method create of class Schema
def test_Schema_create():
    import pytest
    from mimesis.schema import Field

    # Test if the method returns a list of a filled schema
    schema = lambda: {
        'str': str,
        'int': int,
    }

    new_schema = Schema(schema)
    assert isinstance(new_schema.create(), list)
    assert len(new_schema.create(3)) == 3

    # Test if the method return correct filled schema
    schema = lambda: {
        'str': str,
        'int': int,
    }

    new_schema = Schema(schema)
    for data in new_schema.create(3):
        assert isinstance(data['str'], str)
        assert isinstance(data['int'], int)

    # Test if the method return correct filled schema
    #

# Generated at 2022-06-23 22:13:03.728331
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema is not None

# Generated at 2022-06-23 22:13:05.764614
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f is not None

# Generated at 2022-06-23 22:13:13.517546
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field.__class__.__name__ == 'AbstractField'

    result = field('sha1')
    assert 'sha1' == result.__class__.__name__
    result = field('sha1', seed=123)
    assert 'sha1' == result.__class__.__name__
    assert result != field('sha1', seed=123)



# Generated at 2022-06-23 22:13:14.899370
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Check constructor of class AbstractField."""
    f = AbstractField()
    assert f.locale == 'en'
    assert f.seed is None

# Generated at 2022-06-23 22:13:17.438090
# Unit test for constructor of class AbstractField
def test_AbstractField():
    af = AbstractField(locale='de')
    assert isinstance(af, AbstractField)



# Generated at 2022-06-23 22:13:19.245050
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:13:22.077366
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test __str__ method of AbstractField class."""
    obj = Field()
    assert obj.__str__() == 'Field <en>'
    obj = Field(locale='ru')
    assert obj.__str__() == 'Field <ru>'

# Generated at 2022-06-23 22:13:28.954379
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test callable object."""
    field = AbstractField('en', seed=1234)
    assert field('Code') == '938-914-072'
    assert field('Code') == '837-237-732'
    assert field('code', length=8) == '73074300'
    assert field('Code', length=4) == '4241'
    assert field('BIC', key=lambda x: x.split(' ')[0]) == 'ZQFRNQKM'
    assert field('first_name') == 'Edward'
    assert field('first_name') == 'Patrick'
    assert field('last_name', gender='m') == 'Brady'
    assert field('last_name', gender='m') == 'Maxwell'

# Generated at 2022-06-23 22:13:35.079487
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender, Person
    from mimesis.schema import Field
    import json

    f = Field(locale='ru')

    schema = {
        'name': f('name.full_name',
                  gender=lambda: Gender.FEMALE),
        'first_name': f('person',
                        providers=Person).get_name('ru', Gender.MALE),
    }

    assert isinstance(Schema(schema).create(), list)
    assert json.dumps(Schema(schema).create()) == '[]'
    assert isinstance(Schema(schema).create(5), list)

# Generated at 2022-06-23 22:13:41.089543
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None

    field = Field(seed=10)
    assert field.seed == 10
    assert field.locale == 'en'

    field = Field(locale='lt', seed=1)
    assert field.locale == 'lt'
    assert field.seed == 1



# Generated at 2022-06-23 22:13:47.497478
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field(locale='en')

    # undefined provider
    try:
        f('lorem_ipsum')
    except UndefinedField:
        pass

    # unsupported provider
    try:
        f('provider.generate')
    except UnsupportedField:
        pass

    # UndefinedField
    try:
        f()
    except UndefinedField:
        pass



# Generated at 2022-06-23 22:13:48.761366
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:54.992847
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('username')
    assert f('last_name')
    assert f('username', length=42)
    assert f('last_name', upper_case=True)
    assert f('username', length=42, upper_case=True)
    assert f('username', key=str.upper)
    assert f('last_name', upper_case=True, key=str.upper)
    assert f('username', length=42, key=str.upper)



# Generated at 2022-06-23 22:13:57.089270
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method AbstractField.__str__."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:07.678899
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.providers.generic import Generic

    class F(BaseSpecProvider):

        def ff(self, a=3, b=4) -> int:
            return a + b
        def fff(self, a=3, b=4) -> int:
            return a * b

    class MySchema(Generic):

        def __init__(self):
            super().__init__()
            self.F = F


# Generated at 2022-06-23 22:14:10.828002
# Unit test for constructor of class AbstractField
def test_AbstractField():
    self = AbstractField()
    self = AbstractField('ru')
    self = AbstractField('en', seed=8)
    self = AbstractField('en', seed=8, providers=('address.Address',))

# Generated at 2022-06-23 22:14:13.060725
# Unit test for constructor of class Schema
def test_Schema():
    def f():
        return {'a': 1}
    schema = Schema(f)
    assert schema.schema == f

# Generated at 2022-06-23 22:14:17.248060
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()  # type: ignore
    # Test for custom provider
    assert f('custom.mimesis') == 'mimesis'

    # Test for generic provider
    assert f('timestamp') > 0

    # Test for python provider
    result = f('choice', ['foo', 'bar', 'baz'])
    assert result in ['foo', 'bar', 'baz']

    # Test for case when provider and method
    # is not defined (expectation: raise ValueError)
    try:
        f('not_supported')
    except UnsupportedField:
        pass



# Generated at 2022-06-23 22:14:22.912068
# Unit test for method create of class Schema
def test_Schema_create():
    """Test Schema.create."""
    from mimesis.schema import Pattern
    import pprint

    schema = Schema(Pattern('{name} - {surname}').create())
    pprint.pprint(schema.create(iterations=2))
    # [{'name': 'Blanca', 'surname': 'Izzo'},
    #  {'name': 'Celestina', 'surname': 'Criscione'}]

# Generated at 2022-06-23 22:14:26.001791
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of AbstractField."""
    f = AbstractField()
    s = '{} <{}>'.format('AbstractField', 'en')
    assert str(f) == s

# Generated at 2022-06-23 22:14:27.280899
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {'some': True})
    assert schema is not None

# Generated at 2022-06-23 22:14:32.356992
# Unit test for constructor of class Schema
def test_Schema():
    obj = Schema(lambda: 'test')
    assert callable(obj.schema)
    assert isinstance(obj.schema, type(lambda: 1))
    assert obj.schema() == 'test'
    assert obj.create() == ['test']
    assert obj.create(2) == ['test', 'test']
    assert obj.create(3) == ['test', 'test', 'test']

# Generated at 2022-06-23 22:14:33.916948
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:40.065920
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    string = field('uid')
    assert isinstance(string, str)
    assert len(string) == 36

    field = AbstractField()
    lorem_ipsum = field('text')
    assert isinstance(lorem_ipsum, str)

    field = AbstractField()
    hash_id = field('hashid')
    assert isinstance(hash_id, str)
    assert len(hash_id) == 19

    field = AbstractField()
    hash_id = field('generic.hashid')
    assert isinstance(hash_id, str)
    assert len(hash_id) == 19

    field = AbstractField()
    hash_id = field('hashid', salt='test')
    assert isinstance(hash_id, str)
    assert len(hash_id) == 19


# Generated at 2022-06-23 22:14:41.922383
# Unit test for method create of class Schema
def test_Schema_create():
    s = Schema(lambda: {})
    assert isinstance(s.create(1), list)



# Generated at 2022-06-23 22:14:43.521064
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f
    f = AbstractField(providers=['datetime'])
    assert f

# Generated at 2022-06-23 22:14:46.489415
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    f = Field()
    assert str(f) == 'Field <en>'