

# Generated at 2022-06-23 22:04:39.512458
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    inst = AbstractField()
    assert str(inst) == 'AbstractField <en>'

# Generated at 2022-06-23 22:04:43.407378
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField constructor."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None

    field = AbstractField('ru')
    assert field.locale == 'ru'
    assert field.seed is None

    field = AbstractField('en', 123)
    assert field.locale == 'en'
    assert field.seed == 123



# Generated at 2022-06-23 22:04:45.539414
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:04:48.688923
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('datetime.datetime') is not None
    assert f('uuid4') is not None
    assert f('uuid4') is not None

# Generated at 2022-06-23 22:04:50.445570
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    result = str(field)

    assert result.startswith('AbstractField')

# Generated at 2022-06-23 22:04:56.985598
# Unit test for method create of class Schema
def test_Schema_create():
    assert Schema(lambda: {}).create(0) == []
    assert Schema(lambda: {}).create(iterations=0) == []
    assert Schema(lambda: {}).create(1) == [{}]
    assert Schema(lambda: {}).create(iterations=1) == [{}]
    assert len(Schema(lambda: {}).create(2)) == 2
    assert len(Schema(lambda: {}).create(iterations=2)) == 2

# Generated at 2022-06-23 22:05:08.645514
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField's method __call__().

    :raises: UndefinedField, UnsupportedField, UnacceptableField
    """
    field = AbstractField()

    # Try to call some method with undefined name
    try:
        field()
    except UndefinedField:
        pass
    else:
        raise AssertionError('Method not raise exception')

    # Try to call some undefined method
    try:
        field('undefined_method')
    except UnsupportedField:
        pass
    else:
        raise AssertionError('Method not raise exception')

    # Try to set not callable object as key
    try:
        field(name='person.full_name', key=not_callable_object)
    except UnacceptableField:
        pass
    else:
        raise AssertionError('Method not raise exception')



# Generated at 2022-06-23 22:05:13.058385
# Unit test for method create of class Schema
def test_Schema_create():
    """Test schema.create method."""
    schema = Schema(lambda: {'a': 1, 'b': 2})
    assert isinstance(schema.create(), list)
    assert len(schema.create()) == 1
    assert len(schema.create(3)) == 3



# Generated at 2022-06-23 22:05:14.403366
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Check abstract field constructor."""
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:05:17.247305
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    # type: () -> None
    """Unit test for method __str__ of class AbstractField."""
    fld = AbstractField()
    assert str(fld) == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:25.982658
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.providers.datetime import Datetime as DT
    from mimesis.providers.internet import Internet as IT

    provider = DT(locale='en')
    internet = IT(locale='en')

    provider.add_provider(internet)

    field = Field(locale='en', providers=provider)

    assert field._table == {}

    field('timezone')

    expected_results = {
        'timezone': DT.timezone,
        'username': IT.username,
        'email': IT.email,
    }

    assert field._table == expected_results



# Generated at 2022-06-23 22:05:27.895168
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:05:31.775301
# Unit test for constructor of class Schema
def test_Schema():
    def func_factory():
        return {'data': 'ok'}

    schema = Schema(func_factory)
    assert schema.create(1) == [
        {'data': 'ok'}]

# Generated at 2022-06-23 22:05:43.128082
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert callable(field) is True

    result = field.__call__(
        'timestamp')

    assert isinstance(result, int)

    provider_name = 'address'
    method_name = 'country'
    assert field.__call__(
        '{}.{}'.format(provider_name, method_name),
        key=lambda x: x.upper()) == 'UNITED STATES'

    assert field.__call__(
        '{}.{}'.format('text', 'word'),
        count=3) == 'I am'

    assert field.__call__(
        'choice',
        items=['foo', 'bar', 'baz'],
        key=lambda x: x.upper()) == 'FOO'


# Generated at 2022-06-23 22:05:48.882159
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': 'Bulbasaur',
        'type': ['grass', 'poison'],
    }

    expected = [{
        'name': 'Bulbasaur',
        'type': ['grass', 'poison'],
    }]

    class PokemonSchema:
        def __call__(self, **kwargs):  # noqa: WPS110
            return schema

    result = Schema(PokemonSchema()).create()
    assert result == expected

# Generated at 2022-06-23 22:05:55.118851
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.utils import FileProvider

    file_provider = FileProvider()
    from mimesis.schema import Field

    field = Field(locale='ru', providers=(file_provider,))

    schema = {
        'name': field('full_name'),
        'last_name': field('surname'),
        'photo': field('image'),
        'description': field('comment'),
        'location': field('place'),
    }

    def create():
        return schema

    s = Schema(create)
    assert len(s.create(10)) == 10

# Generated at 2022-06-23 22:05:56.880607
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'
    assert str(Field(locale='ru')) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:05:59.344567
# Unit test for constructor of class Schema
def test_Schema():
    @Field.order((
        'test',
    ))
    def schema():
        return {'test': 'value'}

    s = Schema(schema)
    assert s is not None
    s.create()

# Generated at 2022-06-23 22:06:04.299254
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f.locale == 'en'

    f = AbstractField(locale='ru')
    assert f.locale == 'ru'

    f = AbstractField(seed=42)
    assert f.seed == 42

    g = Generic('en')
    f = AbstractField(providers=g)
    assert f._gen.providers == g.providers

# Generated at 2022-06-23 22:06:09.818146
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender

    def schema() -> dict:
        return {
            'name': 'Robert',
            'age': 18,
            'gender': Gender.MALE,
            'occupation': 'Fisher',
        }

    schema = Schema(schema)
    data = schema.create(2)
    assert len(data) == 2

# Generated at 2022-06-23 22:06:10.150826
# Unit test for constructor of class AbstractField
def test_AbstractField():
    pass

# Generated at 2022-06-23 22:06:10.923358
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert isinstance(field, AbstractField)


# Generated at 2022-06-23 22:06:12.180185
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField"""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:22.528507
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    import unittest
    from mimesis.providers.address import Address

    class TestAbstractField(unittest.TestCase):
        def setUp(self):
            self.field = AbstractField()

        def test_if_callable(self):
            self.assertTrue(callable(self.field))

        def test_if_provider_not_supported(self):
            with self.assertRaises(UnsupportedField):
                self.field('some_provider.method_name')

        def test_if_field_not_defined(self):
            with self.assertRaises(UndefinedField):
                self.field()

        def test_if_provider_is_supported(self):
            self.field = AbstractField(providers=[Address])
            self.assertTrue(self.field('country_code'))

# Generated at 2022-06-23 22:06:24.630360
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()

    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:06:29.191155
# Unit test for constructor of class Schema
def test_Schema():
    """Test for Schema constructor."""
    class Scm(Schema):
        def __init__(self, schema):
            super().__init__(schema)

    try:
        Scm()
    except UndefinedSchema:
        pass
    else:
        raise Exception

# Generated at 2022-06-23 22:06:38.332287
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.enum import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.code import Code

    field = AbstractField()

    assert isinstance(field, AbstractField)

    person = Person('en', '123')
    field = AbstractField(providers=[person])

    assert person.__class__.__name__ in str(field)

    person = Person('en', '123')
    field = AbstractField(providers=[person, Text('en', '123')])

    assert person.__class__.__name__ in str(field)

    assert field(name='full_name') == 'Sara Smith'

    assert field(name='full_name', gender=Gender.FEMALE) == 'Sara Smith'



# Generated at 2022-06-23 22:06:43.761942
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    from mimesis.providers.person import Person

    def schema() -> dict:
        """Return filled schema."""
        f = Field(locale='en')

        data = dict(
            name=f('personal.full_name'),
            age=f('person.age'),
            phone_number=f('person.phone_number'),
        )
        return data

    s = Schema(schema)
    assert s.create(iterations=10) == [
        schema() for _ in range(10)
    ]

# Generated at 2022-06-23 22:06:45.863459
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    stringified = __str__(AbstractField())
    expected = 'AbstractField <en>'
    assert stringified == expected

# Generated at 2022-06-23 22:06:48.808259
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    name = field._gen.choice.Meta.name
    value = field(name)
    assert field(name=name) == value



# Generated at 2022-06-23 22:06:55.757504
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method ``create`` of class ``Schema``."""

    def schema_function():
        """Create schema.

        :return: Schema
        """
        return {
            'name': 'Jon',
            'age': 21,
            'cars': [
                {
                    'model': 'Bmw',
                    'year': 2018
                },
                {
                    'model': 'Lada',
                    'year': 1990
                }
            ]
        }

    schema = Schema(schema_function)
    result = schema.create(iterations=2)
    assert result == [schema_function(), schema_function()]

# Generated at 2022-06-23 22:06:59.805875
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField."""
    field = AbstractField()
    name = field.__class__.__name__
    locale = field.locale

    assert str(field) == '{} <{}>'.format(name, locale)

# Generated at 2022-06-23 22:07:04.965497
# Unit test for method create of class Schema
def test_Schema_create():
    # Create a schema
    schema = Schema(lambda: {'name': 'John', 'age': '25'})
    # Create a list of filled schemas with length 10
    res = schema.create(10)
    assert len(res) == 10
    # Test result
    # [{'name': 'John', 'age': '25'}, {'name': 'John', 'age': '25'}, ...]

# Generated at 2022-06-23 22:07:14.943622
# Unit test for constructor of class Schema
def test_Schema():
    def get_schema() -> JSON:  # noqa
        """Return schema."""
        return {
            'first_name': 'John',
            'last_name': 'Doe',
            'age': 25,
        }

    data = [
        {'first_name': 'John', 'last_name': 'Doe', 'age': 25},
        {'first_name': 'John', 'last_name': 'Doe', 'age': 25},
        {'first_name': 'John', 'last_name': 'Doe', 'age': 25},
    ]

    assert data == Schema(get_schema).create(iterations=3)

# Generated at 2022-06-23 22:07:15.913069
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema([])


# Generated at 2022-06-23 22:07:17.273362
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor."""
    with Schema(lambda: None):
        pass

# Generated at 2022-06-23 22:07:21.587087
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    data = Field()

    assert data('address.city') == 'North Rivaside'
    assert data('address.city', full=False) == 'Mintyville'
    assert data(
        'address.city',
        key=lambda x: x.lower()
    ) == 'passton'

# Generated at 2022-06-23 22:07:25.420914
# Unit test for constructor of class Schema
def test_Schema():
    fn = int()
    schema = Schema(fn)
    assert schema.schema() == fn()
    assert callable(schema)
    Schema(Schema(fn))
    try:
        Schema(1)
        assert False
    except UndefinedSchema:
        assert True



# Generated at 2022-06-23 22:07:27.700881
# Unit test for constructor of class AbstractField
def test_AbstractField():
    gen = Generic()
    field = AbstractField(locale=gen.locale, seed=gen.seed)
    print(field)
    assert field is not None

# Generated at 2022-06-23 22:07:36.516112
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.schema import Field, Schema

    def flat_schema() -> dict:
        """Create a flat schema."""
        address = Address('en')
        return {
            'address': {
                'street': address.street_name(),
                'house': address.house_number(1),
            },
            'gender': str(Gender(Gender.FEMALE)),
        }

    def nested_schema() -> dict:
        """Create a nested schema."""
        flat_schema()
        return {
            'people': [
                flat_schema() for _ in range(2)
            ]
        }

    assert isinstance(Field(), Schema)

# Generated at 2022-06-23 22:07:38.001109
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()

    assert f.locale == 'en'
    assert callable(f)

# Generated at 2022-06-23 22:07:40.856553
# Unit test for constructor of class Schema
def test_Schema():
    schema = lambda: None
    assert isinstance(Schema(schema), Schema)



# Generated at 2022-06-23 22:07:41.621554
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:07:42.332965
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    obj = AbstractField()

# Generated at 2022-06-23 22:07:44.999298
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField."""
    field = Field('en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:48.662188
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField(locale='en')

    assert field('datetime')
    assert field('datetime.date', year=2000, month=1, day=1)
    assert field('datetime.date', year=2000, month=1, day=1)



# Generated at 2022-06-23 22:07:49.948331
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:52.736190
# Unit test for method create of class Schema
def test_Schema_create():
    """Test that method create return list of filled schemas."""
    schema = Schema(lambda: {'field': 0})
    assert type(schema.create(2)) == list

# Generated at 2022-06-23 22:07:55.021592
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert callable(field)
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:07:58.846367
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert isinstance(field('password', length=10), str)
    assert isinstance(field('lorem.sentence', count=3), str)
    assert isinstance(field('lorem.sentence', count=3, key=str.capitalize), str)

# Generated at 2022-06-23 22:08:01.306327
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check correct string representation of AbstractField."""
    field = Field(locale='en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:03.700345
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test AbstractField#__str__ method."""
    before = AbstractField().__class__.__name__
    after = AbstractField().__str__()

    assert before in after

# Generated at 2022-06-23 22:08:06.194735
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(locale='ru', seed=1)
    assert field.locale == 'ru'
    assert field.seed == 1

# Generated at 2022-06-23 22:08:07.970212
# Unit test for constructor of class Schema
def test_Schema():
    def empty() -> JSON:
        return {}

    Schema(empty)

# Generated at 2022-06-23 22:08:15.490955
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():  # noqa
    """Check AbstractField.__call__."""
    import datetime as dt

    field = AbstractField()

    assert isinstance(field('uuid'), str)
    assert isinstance(field('uuid'), str)
    assert isinstance(field('uuid.uuid4'), str)
    assert isinstance(field('uuid.uuid4'), str)
    assert isinstance(field('uuid.uuid4', dash=False), str)
    assert isinstance(field('uuid.uuid4', dash=False), str)

    assert isinstance(field('timestamp'), int)
    assert isinstance(field('timestamp', fmt='%Y-%m-%d %H:%M:%S'), str)

# Generated at 2022-06-23 22:08:17.040468
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert isinstance(f, AbstractField)



# Generated at 2022-06-23 22:08:20.670844
# Unit test for method create of class Schema
def test_Schema_create():
    """."""
    def schema() -> JSON:
        """."""
        return {
            'name': Field()('name'),
            'year': Field()('year'),
        }

    from pprint import pformat
    schema = Schema(schema)
    data = schema.create(iterations=2)
    print(pformat(data))

# Generated at 2022-06-23 22:08:22.784591
# Unit test for constructor of class Schema
def test_Schema():
    try:
        Schema(Field())
    except Exception as err:
        assert str(err) == 'Schema should be a callable object.'



# Generated at 2022-06-23 22:08:25.726860
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField."""
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:31.917536
# Unit test for method create of class Schema
def test_Schema_create():
    """Example of how to create filled schemas."""
    from pprint import pprint
    from mimesis import Person

    person = Person('en')

    def schema(person=person):
        """Example of schema."""
        return {
            'name': person.full_name(),
            'address': person.address(),
            'job': person.occupation(),
        }

    s = Schema(schema)
    pprint(s.create(2))
    # names = (s.create(2))
    # print(names)

# Generated at 2022-06-23 22:08:36.046848
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    data = {
        'locale': 'en',
        'seed': None,
        'providers': None,
    }

    field = AbstractField(**data)
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:39.187630
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    expected_result = 'lorem ipsum'

    assert callable(field)
    assert field.__call__(name='words', quantity=1) == expected_result

# Generated at 2022-06-23 22:08:49.296025
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Constructor of class AbstractField."""
    from mimesis.providers.base import BaseProvider, BaseDataProvider

    class Provider(BaseProvider):
        """..."""
        class Meta:
            """..."""

            name = 'provider'

    class DataProvider(BaseDataProvider):
        """..."""
        class Meta:
            """..."""

            name = 'dataprovider'

    provider = Provider(seed='test')
    dataprovider = DataProvider(seed='test')

    field = AbstractField(seed='test', providers=[provider, dataprovider])
    assert callable(field)



# Generated at 2022-06-23 22:08:50.238415
# Unit test for constructor of class AbstractField
def test_AbstractField():
    return AbstractField(seed=0, locale='en')

# Generated at 2022-06-23 22:08:51.100321
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-23 22:08:57.184309
# Unit test for constructor of class Schema
def test_Schema():
    def fake_schema(a):
        return a

    schema = Schema(fake_schema)
    assert schema.schema(1) == fake_schema(1)
    assert str(schema) == '{} <{}>'.format(
        'Schema', '',
    )
    assert repr(schema) == f'<Schema schema={fake_schema}>'
    assert isinstance(schema, Schema)

# Generated at 2022-06-23 22:09:03.430175
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for creating list of filled schemas."""
    from mimesis.schema import Field, Schema

    field = Field()

    def schema() -> dict:
        """Return filled schema."""
        return {
            'first_name': field('person.first_name'),
            'last_name': field('person.last_name'),
            'age': field('random_int', min=10, max=80),
        }

    sc = Schema(schema)
    actual = sc.create(iterations=5)
    assert len(actual) == 5

# Generated at 2022-06-23 22:09:13.632236
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field, Schema
    from mimesis.enums import Gender

    field = Field(locale='ru')

    def test_schema():
        return {
            'name': field('full_name', gender=Gender.MALE),
            'favourite_subject': field('subject'),
            'age': field('age', minimum=15, maximum=18),
            'some_key': field('number', maximum=10),
            'nested': {
                'any_address': field('address'),
                'any_phone': field('phone_number'),
            }
        }

    schema = Schema(test_schema)
    result = schema.create(2)
    assert isinstance(result, list)
    assert len(result) == 2

# Generated at 2022-06-23 22:09:16.836636
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema([1, 2])
    assert Schema(SchemaType.DATABASE)
    assert not Schema(None)

# Generated at 2022-06-23 22:09:19.106068
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:20.654226
# Unit test for constructor of class Schema
def test_Schema():
    def _schema():
        ...

    assert Schema(_schema)

# Generated at 2022-06-23 22:09:23.105860
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    a = Field()
    assert str(a) == "AbstractField <en>"



# Generated at 2022-06-23 22:09:24.391601
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:26.590035
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert AbstractField().__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:28.728715
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor."""
    schema = Schema(None)
    assert isinstance(schema, Schema)



# Generated at 2022-06-23 22:09:30.890232
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:09:34.858671
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for Schema.create."""
    from mimesis.query import Query

    query = Query()
    schema = {
        'name': '{{ person.name() }}',
        'address': '{{person.address.building_number()}}',
    }
    result = Schema(lambda: query.get(schema)).create(3)

    assert len(result) == 3
    assert isinstance(result[0], dict)
    assert len(result[0]) == 2

# Generated at 2022-06-23 22:09:39.553364
# Unit test for method create of class Schema
def test_Schema_create():
    def _generator():
        yield 1
        yield 2
        yield 3

    def _schema(_):
        return {
            'title': 'First schema',
            'counts': {
                'one': 1,
                'two': 2,
                'three': 3,
            },
            'gen': _generator()
        }

    schema = Schema(_schema)
    for _ in range(10):
        assert schema.create() == [_schema(None)]  # type: ignore

# Generated at 2022-06-23 22:09:49.444110
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Instance of AbstractField and initial assignment
    # of a locale and seed
    f = AbstractField('en')
    assert f.locale == 'en'
    assert isinstance(f.seed, int)

    # Let's call the method of a provider
    for x in range(5):
        assert f('currency_code') in f._gen.currency.currency_codes

    # Let's to call the method with the same name,
    # but from a different provider
    for x in range(5):
        assert f('uuid') in f._gen.uuid.uuids

    # Let's test the method of a provider with a key
    for i in range(5):
        assert f('username', key=lambda x: x.replace('-', ''))

    def test(x):
        """Return upper."""
        return x

# Generated at 2022-06-23 22:09:55.510145
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # TODO: check providers with deprecated API (like RussianAddress)
    field = Field()
    assert field.locale == 'en'
    assert field('datetime') == '2019-01-06T03:52:28.274809'
    assert field('datetime', year=2012) == '2012-12-01T23:01:20.710302'
    assert field('phone_number') == '+1 (677) 824-9819'
    assert field('phone_operator') == 'Straight Talk'
    assert field('address', country_code='us') == '61946 Pineda Village, CA'
    assert field('person', gender='Male') == 'Victor Pete'
    assert field('person', gender='Male', key=lambda x: str(x).lower()) \
        == 'victor pete'


# Generated at 2022-06-23 22:09:56.089930
# Unit test for method create of class Schema
def test_Schema_create():
    pass

# Generated at 2022-06-23 22:09:57.311946
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {})
    assert isinstance(schema, Schema)

# Generated at 2022-06-23 22:10:01.331564
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': 'John',
            'surname': 'Doe',
        }
    s = Schema(schema)
    assert len(s.create(3)) == 3

# Generated at 2022-06-23 22:10:11.907346
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.dynamic import DynamicProvider
    from mimesis.schema import Field

    class CustomSchema(DynamicProvider):
        """Example of custom schema."""

        def __init__(self, *args, **kwargs):
            """Initialize schema."""
            super().__init__(*args, **kwargs)
            self.field = Field(providers=[self])

        class Meta:
            """Metaclass for the CustomSchema."""

            name = 'custom_schema'

        @property
        def language(self) -> str:
            """
            Get language code.

            :return: Language code.
            """
            return 'en'

        def simple_field(self):
            """Return example of a simple field."""
            return self.field('text')


# Generated at 2022-06-23 22:10:20.213266
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # check the standard behaviour without arguments
    field = Field()
    assert(callable(field))

    # check the explicit definition of the method
    assert(isinstance(field('datetime.datetime'), datetime.datetime))

    # check the standard behaviour with key function
    assert(isinstance(field(
        name='datetime.datetime',
        key=datetime.datetime.strftime,
    ), str))

    # check the standard behaviour with parameters
    assert(isinstance(field(
        name='datetime.datetime',
        today=True,
    ), datetime.datetime))

    # check the standard behaviour with parameters
    assert(isinstance(field(
        name='personal.name',
        gender='female',
    ), str))

# Generated at 2022-06-23 22:10:22.620908
# Unit test for method create of class Schema
def test_Schema_create():
    schema = lambda: {'id': 1, 'name': 'John'}
    s = Schema(schema)
    assert isinstance(s.create(10), list)

# Generated at 2022-06-23 22:10:23.901063
# Unit test for constructor of class Schema
def test_Schema():
    assert callable(Schema)

# Generated at 2022-06-23 22:10:29.427133
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.schema import AbstractField, Field
    from mimesis.providers.person import Person

    f1 = Field(providers=(Person,))
    assert f1('name')

    f2 = AbstractField(providers=(Person,))
    f2._table['name'] = getattr(f2._gen.person, 'name')
    assert f2('name')



# Generated at 2022-06-23 22:10:31.179922
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(lambda: {'a': 'b'}).create(3)) == 3

# Generated at 2022-06-23 22:10:39.868150
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    try:
        field()
        raise AssertionError('Expected ValueError')
    except Exception as error:
        assert error.__class__ == UndefinedField

    result1 = field('random_number', minimum=10, maximum=100, digits=3)
    result2 = field('random_number', maximum=100, minimum=10, digits=3)

    assert result1 == result2

    try:
        field('random_number', maximum=100, minimum=10, digits=3, wrong=True)
        raise AssertionError('Expected TypeError')
    except Exception as error:
        assert error.__class__ == TypeError


# Generated at 2022-06-23 22:10:41.788262
# Unit test for method create of class Schema
def test_Schema_create():
    _field = Field(locale='en')
    assert len(_field.create(3)) == 3

# Generated at 2022-06-23 22:10:42.365512
# Unit test for method create of class Schema
def test_Schema_create():
    pass

# Generated at 2022-06-23 22:10:42.959672
# Unit test for constructor of class Schema
def test_Schema():
    assert True

# Generated at 2022-06-23 22:10:46.483090
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test a text representation of the object."""
    field = AbstractField()
    assert field.__str__() == 'AbstractField <en>'

    field = AbstractField('ru')
    assert field.__str__() == 'AbstractField <ru>'



# Generated at 2022-06-23 22:10:51.371587
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Must return data from the first provider which
    # has a method name
    assert Field()('uuid') != ''

    # Explicitly define that the method belongs
    # to data-provider must return data from
    # the first provider which has a method name
    assert Field()('code.uuid') != ''

# Generated at 2022-06-23 22:10:53.311793
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        AbstractField()
    except Exception:
        assert False, 'Should not fail if an empty constructor is used.'
        pass



# Generated at 2022-06-23 22:10:55.215809
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert isinstance(field, AbstractField)
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:57.030012
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Type check for the __str__ method of AbstractField."""
    field = Field()

    assert isinstance(field.__str__(), str)

# Generated at 2022-06-23 22:10:58.174089
# Unit test for constructor of class Schema
def test_Schema():
    pass

# Generated at 2022-06-23 22:11:01.327694
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema, Field

    schema = Schema(Field('person.full_name'))
    result = schema.create(5)
    assert len(result) == 5

# Generated at 2022-06-23 22:11:08.647415
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Testing method __call__ of class AbstractField."""
    gen = Generic()
    num = gen.random.Random().seed(42).randint(1, 10)
    field = AbstractField(seed=42)
    assert num == field('randint', 1, 10)
    assert num == field('randint', min_value=1, max_value=10)
    assert num == field('random.Random', seed=42).randint(1, 10)
    assert num == field('random.Random', seed=42).randint(
        min_value=1, max_value=10)

# Generated at 2022-06-23 22:11:16.367817
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers import Person
    from mimesis.schema import AbstractField
    from mimesis.enums import Gender

    def my_schema() -> dict:
        """Return filled dict."""
        return {
            'Name': str(field('name')),
            'Gender': str(field('gender')),
        }

    field = AbstractField(providers=[Person()])
    schema = Schema(my_schema)
    people = schema.create(iterations=5)
    p = people[0]
    assert all([
        isinstance(p, dict),
        p['Name'] in field._gen.person.names_list(Gender.MALE),
        p['Gender'] == 'Male',
    ])



# Generated at 2022-06-23 22:11:17.995005
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test abstract field."""
    f = Field()
    assert f('date').today()



# Generated at 2022-06-23 22:11:23.473302
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema.

    The purpose of this unit test is to check that an exception is
    raised when schema is not a callable object.
    """
    from mimesis.exceptions import UndefinedSchema

    # Create an object of class Schema and pass the list.
    # It doesn't raise an exception.
    with pytest.raises(UndefinedSchema):
        Schema([])

# Generated at 2022-06-23 22:11:30.769045
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    def get_schema() -> dict:
        return {
            'first_name': 'Anna',
            'last_name': 'Smith',
            'age': 23,
            'full_name': 'Anna Smith',
        }

    s = Schema(get_schema)
    data = s.create(iterations=10)
    assert data == [get_schema() for _ in range(10)]

# Generated at 2022-06-23 22:11:36.893314
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()

    result = field('datetime')
    assert isinstance(result, datetime)

    result = field('datetime', year=2018)
    assert isinstance(result, datetime)
    assert result.year == 2018

    result = field('string', key=lambda x: 'WTF?')
    assert result == 'WTF?'

    result = field('string')
    assert isinstance(result, str)

    result = field('system.device_type')
    assert isinstance(result, str)

    result = field('system.os_type')
    assert isinstance(result, str)



# Generated at 2022-06-23 22:11:41.154733
# Unit test for method create of class Schema
def test_Schema_create():
    assert isinstance(Schema((lambda: {})).create()[0], dict)

    assert len(Schema((lambda: [])).create()[0]) == 0

    assert Schema((lambda: [1])).create()[0][0] == 1



# Generated at 2022-06-23 22:11:45.765004
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {'name': 'Vasya'}

    s = Schema(schema)
    assert s.schema() == {'name': 'Vasya'}
    assert s.create() == [schema()]
    assert s.create(5) == [schema() for _ in range(5)]

# Generated at 2022-06-23 22:11:47.257844
# Unit test for constructor of class Schema
def test_Schema():
    def sch():
        return {}
    s = Schema(sch)
    assert isinstance(s, Schema)
    assert isinstance(s.schema, Callable)
    assert s.schema() == {}

# Generated at 2022-06-23 22:11:51.566383
# Unit test for constructor of class Schema
def test_Schema():
    """Test class Schema."""
    s = Schema(lambda: '1')
    result = s.create(3)
    assert result == ['1', '1', '1']

    try:
        Schema('1')
    except UndefinedSchema:
        pass



# Generated at 2022-06-23 22:12:00.646964
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():  # type: ignore
    # Invalid cases
    f = Field()
    try:
        f()  # type: ignore
    except UndefinedField:
        pass
    else:
        raise ValueError('Should fail with UndefinedField exception here')

    try:
        f(name='local.')  # type: ignore
    except UnacceptableField:
        pass
    else:
        raise ValueError('Should fail with UnacceptableField exception here')

    try:
        f(name='local.None')  # type: ignore
    except UndefinedField:
        pass
    else:
        raise ValueError(
            'Should fail with UndefinedField exception here')

    try:
        f(name='local.None.method')  # type: ignore
    except UnacceptableField:
        pass

# Generated at 2022-06-23 22:12:08.707764
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for Schema create."""
    from mimesis.builtins import RussiaSpecProvider

    def test_schema() -> dict:
        """Return test JSON schema."""
        field = Field(locale='ru')
        field.add_providers(RussiaSpecProvider)

        return {
            'name': field('full_name'),
            'phone': field('phone_number'),
            'address': {
                'city': field('city'),
                'street': field('street_address'),
            },
        }

    persons = Schema(test_schema).create(iterations=3)
    assert len(persons) == 3

# Generated at 2022-06-23 22:12:12.382100
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema constructor."""
    assert Schema
    with pytest.raises(UndefinedSchema):
        Schema('foo')

    def schema(field):
        return field('random')

    assert Schema(schema)



# Generated at 2022-06-23 22:12:16.201798
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema.schemas import SimpleSchema1

    schema = Schema(SimpleSchema1())

    assert schema is not None, 'Should not be None'



# Generated at 2022-06-23 22:12:18.577293
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    from mimesis.builtins.structures import AbstractStructure

    AbstractField(locale='en', seed=1,
                  providers=AbstractStructure)

# Generated at 2022-06-23 22:12:21.966172
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__()."""
    schema = Schema
    schema_one = Schema(lambda : {'name': Field()})
    schema_two = Schema(lambda : {'name': Field(name='person.full_name')})

    for _ in range(5):
        assert schema_one.create()
        assert schema_two.create()

# Generated at 2022-06-23 22:12:24.810089
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'foo': 'bar'}

    result = Schema(lambda: schema).create()

    assert result is not None
    assert result[0] == schema

# Unit tests for method create of class Field

# Generated at 2022-06-23 22:12:26.724903
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    af = AbstractField()
    assert isinstance(af.__str__(), str)

# Generated at 2022-06-23 22:12:29.483637
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> JSON:
        """Dummy schema."""
        return {}

    s = Schema(schema)
    assert s.schema == schema



# Generated at 2022-06-23 22:12:31.932115
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    result = field(name='person.full_name')
    assert isinstance(result, str)



# Generated at 2022-06-23 22:12:33.177104
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(seed=1)
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:35.774288
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField."""
    obj = AbstractField()
    assert str(obj).startswith('AbstractField')

# Generated at 2022-06-23 22:12:41.116615
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Check constructor of the AbstractField class."""
    result = '{} <{}>'.format(AbstractField.__name__, 'en')
    assert result in str(AbstractField())
    result = '{} <{}>'.format(AbstractField.__name__, 'ru')
    assert result in str(AbstractField(locale='ru'))



# Generated at 2022-06-23 22:12:45.066002
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    test_schema = {
        'a': 'Person.name'
    }
    test_schema2 = {
        'a': 'Dummy.dummy'
    }

    Field().__call__(**test_schema)
    Field().__call__(**test_schema2)

    g = Generic()
    Field(providers=[g]).__call__(**test_schema)
    Field(providers=[g]).__call__(**test_schema2)

# Generated at 2022-06-23 22:12:51.766066
# Unit test for method create of class Schema
def test_Schema_create():
    '''Unit test for method create of class Schema.'''

    def _create_schema():
        return {
            'name': 'name of a fictional character',
            'gender': 'gender',
            'height': 'height',
            'weight': 'weight',
            'age': 'age',
        }

    schema = Schema(_create_schema)
    data = schema.create(2)
    assert len(data) == 2
    assert isinstance(data, list)
    assert isinstance(data[0], dict)

# Generated at 2022-06-23 22:12:53.757302
# Unit test for method create of class Schema
def test_Schema_create():
    s = Schema(lambda: {})
    assert len(s.create(5)) == 5

# Generated at 2022-06-23 22:12:54.822336
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {})
    assert schema.schema() == {}



# Generated at 2022-06-23 22:12:56.254288
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:58.639730
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field._gen.data.en == field._gen.data.en

# Generated at 2022-06-23 22:13:01.475245
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Create instance of the AbstractField class
    field = AbstractField(locale='ru', seed='mimesis')
    assert field.locale == 'ru'
    assert field.seed == 'mimesis'

# Generated at 2022-06-23 22:13:04.663706
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField."""
    field = AbstractField()
    assert '<' in str(field)
    assert 'AbstractField' in str(field)

# Generated at 2022-06-23 22:13:07.537975
# Unit test for method create of class Schema
def test_Schema_create():
    """Schema.create: return list."""
    data = Schema(lambda: {'foo': 'bar'}).create(iterations=10)

    assert isinstance(data, list)

# Generated at 2022-06-23 22:13:09.368784
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    obj = AbstractField()
    pattern = 'AbstractField <en>'
    assert str(obj) == pattern

# Generated at 2022-06-23 22:13:11.482719
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    # Just run it
    AbstractField().__call__('random')  # noqa: F841

# Generated at 2022-06-23 22:13:14.681563
# Unit test for constructor of class Schema
def test_Schema():
    class SchemaTeen:
        def schema(self):
            return self._gen.person.age(min_age=15, max_age=19)


    obj = SchemaTeen()
    assert obj.schema() <= 19



# Generated at 2022-06-23 22:13:18.573498
# Unit test for constructor of class AbstractField
def test_AbstractField():
    provider = Field()
    assert provider.locale == 'en'

    provider = Field('de')
    assert provider.locale == 'de'

    provider = Field('ru')
    assert provider.locale == 'ru'

# Generated at 2022-06-23 22:13:24.984683
# Unit test for constructor of class Schema
def test_Schema():
    # check it will raise exception if schema is not callable
    from mimesis.schema import Schema
    from mimesis.exceptions import UndefinedSchema
    try:
        Schema(schema='some_schema')
        assert False
    except UndefinedSchema:
        assert True
    try:
        Schema(schema=None)
        assert False
    except UndefinedSchema:
        assert True

    # check it will not raise exception if schema is callable
    from mimesis.schema import Schema
    def schema():
        return 'some_schema'
    try:
        Schema(schema=schema)
        assert True
    except UndefinedSchema:
        assert False

# Generated at 2022-06-23 22:13:27.833878
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert hasattr(field, '_gen')
    assert hasattr(field, '_table')
    assert hasattr(field, 'locale')
    assert hasattr(field, 'seed')

# Generated at 2022-06-23 22:13:34.049821
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    # Case 1: create a field object
    f = AbstractField()
    # Case 1.1: check a field with not defined data provider
    try:
        assert f('not_supported')
    except UnsupportedField:
        pass
    # Case 1.2: check a field with not defined method
    try:
        assert f('text')
    except UnacceptableField:
        pass
    # Case 2: check a field with not defined method
    try:
        f('text.foo.bar')
    except UnacceptableField:
        pass

# Generated at 2022-06-23 22:13:37.087091
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert (
        'AbstractField <en>' ==
        str(AbstractField('en'))
    )

# Generated at 2022-06-23 22:13:41.126088
# Unit test for method create of class Schema
def test_Schema_create():
    def _schema():
        return {
            'test': 123,
        }

    s = Schema(_schema)
    assert s.create() == [{'test': 123}]
    assert s.create(iterations=10) == [{'test': 123}] * 10



# Generated at 2022-06-23 22:13:41.938645
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:45.317941
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    #
    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:13:47.030477
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:13:49.756846
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        """Schema."""
        return {}

    result = Schema(schema).create(5)
    assert len(result) == 5
    assert result == [{}] * 5

# Generated at 2022-06-23 22:13:55.241331
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema constructor."""
    from mimesis.enums import Gender
    from mimesis.schema import Field
    from mimesis.providers.person import Person

    obj = Field(providers=[Person(locale='ru'),
                           Person(locale='en')])

    def schema():

        return {
            'fullname': obj('full_name'),
            'fullname2': obj('full_name', gender=Gender.FEMALE),
        }

    Schema(schema)

# Generated at 2022-06-23 22:13:58.260952
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test ``AbstractField``."""
    field = AbstractField()

    assert isinstance(field, AbstractField)
    assert field._gen is not None



# Generated at 2022-06-23 22:14:08.601543
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    generator = Generic('en')
    field = AbstractField(providers=generator)

    assert field('full_name') in [generator.personal.full_name(),
                                  generator.person.full_name()]

    assert field('full_name',
                 gender=generator.person.GENDER.FEMALE) in [
                     generator.personal.full_name(gender=generator.person.GENDER.FEMALE),
                     generator.person.full_name(gender=generator.person.GENDER.FEMALE)
                 ]

    assert field('person.full_name') == \
        generator.person.full_name()


# Generated at 2022-06-23 22:14:16.404649
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field('en')
    name = field.datetime().Meta.name

    assert field(name)

    text = field(name)
    assert isinstance(text, str)

    def get_errors():
        field(name='IncrediblyNotSoSupportedProvider')  # noqa: F841

    def get_errors_2():
        field(name='en.not_so_supported_method')  # noqa: F841

    def get_errors_3():
        field(name='en.bad_method.bad_method')  # noqa: F841

    get_errors.expect_exception = UnsupportedField
    get_errors_2.expect_exception = UnsupportedField
    get_errors_3.expect_exception = UnacceptableField

# Generated at 2022-06-23 22:14:21.701728
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Method for testing class AbstractField.

    This method fills the schema which
    is a callable object with the help of
    class AbstractField.
    """

    def schema():
        """Example schema."""
        return {
            'name': Field().name(),
            'address': Field().address(),
            'quantity': Field('ru').quantity(),
        }

    s = Schema(schema)
    assert s.create(5)

# Generated at 2022-06-23 22:14:31.397337
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> JSON:
        return {
            'Name': Field()('person.full_name'),
            'Email': Field()('person.email')
        }

    s = Schema(schema=schema)

# Generated at 2022-06-23 22:14:34.671627
# Unit test for constructor of class Schema
def test_Schema():
    schema = {
        "name": "John",
        "age": "18",
    }

    s = Schema(schema)
    assert isinstance(s, Schema) is True
    assert isinstance(s.schema, dict) is True
    assert hasattr(s.schema, '__call__') is False



# Generated at 2022-06-23 22:14:36.996862
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

    assert str(AbstractField('ru')) == 'AbstractField <ru>'

    assert str(AbstractField(seed=1234)) == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:41.385930
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('uuid')
    assert field('uuid')
    assert field('uuid', length=4)
    assert field('person.full_name')
    assert field('I.like.to.move.it.move.it')