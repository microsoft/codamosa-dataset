

# Generated at 2022-06-23 22:04:38.869677
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test class AbstractField."""
    from mimesis.providers.base.enums import Gender

    locale = 'en'

    # Test for tail method
    test1 = AbstractField(locale=locale)
    assert test1('datetime.datetime')

    # Test for default
    test2 = AbstractField(locale=locale)
    assert test2('full_name')  # pylint: disable=no-value-for-parameter

    # Test for date
    test3 = AbstractField(locale=locale)
    assert test3('date', gender=Gender.MALE)

    # Test for a key function
    test4 = AbstractField(locale=locale)

    def key_func(birthday: str) -> int:
        """Return age."""
        from datetime import datetime
       

# Generated at 2022-06-23 22:04:40.247598
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check AbstractField.__str__()."""
    assert str(AbstractField(locale='en')) == 'AbstractField <en>'

# Generated at 2022-06-23 22:04:42.950096
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abf = AbstractField(locale='en', seed=1)
    assert isinstance(abf, AbstractField)



# Generated at 2022-06-23 22:04:46.366846
# Unit test for constructor of class Schema
def test_Schema():
    import mimesis

    # Valid argument
    s = Schema(lambda: mimesis.Text().word())
    assert callable(s.schema)

    # Invalid argument
    try:
        Schema(None)
        assert False
    except UndefinedSchema as e:
        assert str(e) == 'Schema must be a callable object'



# Generated at 2022-06-23 22:04:49.255946
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return dict(a=1, b=2)

    assert Schema(schema).create(2) == [schema(), schema()]


# Unit tests for method __call__ of class AbstractField

# Generated at 2022-06-23 22:04:58.868948
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.schema import Field

    def user_schema(field: Field) -> JSON:
        return {
            'name': field('person.full_name'),
            'age': field('person.age', key=int),
            'gender': field('person.gender', args=[Gender.FEMALE]),
            'job': field('business.job', key=str.lower),
            'company': field('business.company'),
            'email': field('internet.email'),
        }

    schema = Schema(user_schema)

    for i in range(1, 5):
        data = schema.create(iterations=i)
        assert isinstance(data, list)
        assert len(data) == i

   

# Generated at 2022-06-23 22:05:09.393828
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method Schema.create."""
    from mimesis import Person, Address

    person = Person('ru')
    address = Address('ru')

    def user() -> JSON:
        """Generate user schema."""
        return {
            'first_name': person.full_name(),
            'last_name': person.last_name(),
            'age': person.age(),
            'email': person.email(),
            'password': person.password(),
            'home_address': {
                'country': address.country(),
                'city': address.city(),
            },
        }

    s = Schema(user)
    assert isinstance(s.create(iterations=2), list)

# Generated at 2022-06-23 22:05:17.229029
# Unit test for constructor of class Schema
def test_Schema():
    """Test function."""
    # pylint: disable=too-few-public-methods
    class Schema:
        """Class Schema."""

        def __init__(self, data):
            """Initialize Schema."""
            self._data = data

        def __call__(self):
            """Return data."""
            return self._data

    schema = Schema('test')
    s = Schema(schema)
    assert s.create() == ['test']

    s = Schema('test')
    assert s.create() == [None]



# Generated at 2022-06-23 22:05:28.053162
# Unit test for constructor of class Schema
def test_Schema():
    """First unit test."""
    from mimesis.enums import Gender
    from mimesis.builtins import Person
    from mimesis.schema import Field
    from mimesis.schema import Schema
    from mimesis.types import JSON
    from mimesis.providers.person.en import Person as PersonEN

    schema = Schema(lambda: {
        'id': Field(Gender.MALE),
        'name': Field(PersonEN.full_name, gender=Gender.MALE),
        'age': Field(Person.age, minimum=18, maximum=80),
    })
    schema.create(5)  # [{'id': 'Male', 'name': 'Steven Barfield', 'age': 66}, ...] # noqa



# Generated at 2022-06-23 22:05:33.769125
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method `create()` of class `Schema`."""

    def schema():
        return {'a': 'b'}

    s = Schema(schema)
    assert len(s.create()) == 1
    assert len(s.create(4)) == 4
    assert len(s.create(0)) == 0



# Generated at 2022-06-23 22:05:37.736702
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check that Field object has expected string representation.

    Args:
        field (mimesis.schema.Field): Field instance.
    """
    field = Field(locale='nl')
    assert str(field) == 'Field <nl>'

# Generated at 2022-06-23 22:05:39.539710
# Unit test for constructor of class Schema
def test_Schema():
    assert callable(Schema)

# Generated at 2022-06-23 22:05:42.169646
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    # GIVEN
    field = AbstractField()
    # WHEN
    result = str(field)
    # THEN
    assert result == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:51.239120
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema
    from mimesis.schema import Field
    from mimesis.schema import UndefinedSchema
    import pytest

    # Alias for UndefinedSchema
    UndefinedSchema = UndefinedSchema

    # Alias for Schema
    Schema = Schema

    def dummy_schema():
        """A dummy schema."""
        return {'name': 'Kek Cheburek'}

    f = Field()

    schema1 = Schema(dummy_schema)
    schema2 = Schema(lambda schema: schema.create())
    schema3 = Schema(lambda schema: dummy_schema())

    data = {
        'name': 'Kek Cheburek',
    }

    # Create a schema

# Generated at 2022-06-23 22:05:59.530945
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.schema import AbstractField
    from mimesis.enums import Gender

    class Schema(AbstractField):
        pass

    field = Schema()
    assert field.__class__.__name__ == 'Schema'

    assert field.locale == 'en'
    assert field.seed is None

    field = Schema(locale='ru', seed='foo')
    assert field.locale == 'ru'
    assert field.seed == 'foo'

    assert field.person() != field.person()
    assert field.person(gender=Gender.FEMALE) != field.person()
    assert field.person(gender=Gender.FEMALE, seed='bar') != field.person(gender=Gender.MALE)

    # This is for fix flake8 inspection

# Generated at 2022-06-23 22:06:01.648403
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    try:
        AbstractField()
    except TypeError:
        raise TypeError('Constructor of class AbstractField does not work.')

# Generated at 2022-06-23 22:06:03.929672
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema:
        def __init__(self) -> None:
            pass
    TestSchema()

# Generated at 2022-06-23 22:06:06.231585
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test to check if __str__ method works correctly."""
    af = AbstractField()
    af.__str__()



# Generated at 2022-06-23 22:06:07.649042
# Unit test for constructor of class Schema
def test_Schema():
    assert isinstance(Schema(lambda: {}), Schema)



# Generated at 2022-06-23 22:06:10.488516
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda: {'': ''})
    assert len(schema.create()) == 1
    assert len(schema.create(iterations=5)) == 5

# Generated at 2022-06-23 22:06:13.610700
# Unit test for constructor of class Schema
def test_Schema():
    """Test the constructor of class Schema."""
    with open('tests/unit/files/schema.json') as src:
        json_schema = src.read()
    schema = Schema(json_schema)
    assert schema.schema == json_schema

# Generated at 2022-06-23 22:06:19.031535
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # With explicit locale
    gen = Field(locale='en-GB')
    assert gen.locale == 'en-GB'

    # With explicit seed
    gen = Field(seed=42)
    assert gen.seed == 42

    # With explicit seed and locale
    gen = Field(locale='en-GB', seed=42)
    assert gen.locale == 'en-GB'
    assert gen.seed == 42



# Generated at 2022-06-23 22:06:20.921276
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: 'data')
    assert schema.create(5) == ['data', 'data', 'data', 'data', 'data']

# Generated at 2022-06-23 22:06:25.080768
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import Person
    from mimesis.schema import Schema

    schema = {'name': Person('en').full_name, 'age': Person('en').age}
    generated_schema = Schema(lambda: schema)
    assert generated_schema is not None

# Generated at 2022-06-23 22:06:30.009294
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda x: 'schema')
    assert schema.schema() == 'schema'
    assert Schema(lambda: 'schema').schema() == 'schema'

    try:
        Schema({})
    except Exception:
        assert True

    try:
        Schema('')
    except Exception:
        assert True



# Generated at 2022-06-23 22:06:31.401244
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema({'name': 'name'})
    assert callable(schema) is True

# Generated at 2022-06-23 22:06:32.677954
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:35.642997
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> str:
        return 'test'

    field = Schema(schema)
    assert field.create(iterations=10) == ['test' for _ in range(10)]



# Generated at 2022-06-23 22:06:37.845867
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> JSON:
        return {
            'name': 'Anna',
            'age': 42
        }

    assert len(Schema(schema).create(100)) == 100

# Generated at 2022-06-23 22:06:38.995868
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:40.442494
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:43.427569
# Unit test for method create of class Schema
def test_Schema_create():
    field = Field()

    @field.schema(iterations=2)
    def schema():
        return {
            'name': field('name'),
            'age': field('age', min=18, max=80),
            'birthday': field('date'),
            'country': field('country'),
        }

    assert len(schema) == 2

# Generated at 2022-06-23 22:06:53.777098
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Tests for method ``__call__`` of class ``AbstractField``."""
    field = AbstractField()
    result = field('name')
    assert result is not None

    # Check working with providers.
    result = field('usd')
    assert result is not None

    # Check error raising.
    try:
        field('nothing')
    except UndefinedField:
        assert True
    else:
        raise AssertionError('Test failed')

    # Check error raising.
    try:
        field('nothing.nothing')
    except UnacceptableField:
        assert True
    else:
        raise AssertionError('Test failed')

    try:
        field('en.nothing')
    except UnsupportedField:
        assert True
    else:
        raise AssertionError('Test failed')

    # Check working with key.

# Generated at 2022-06-23 22:06:54.630083
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:00.283972
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': 'Foo',
        'x': 0,
        'y': 0,
    }

    def get_schema():
        return schema

    s = Schema(schema=get_schema)
    assert s.create() == [schema]

    s = Schema(schema=get_schema)
    assert s.create(iterations=2) == [schema, schema]

# Generated at 2022-06-23 22:07:04.029176
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    locale = 'en'
    seed = 77777
    f = AbstractField(locale, seed)
    name = 'person.full_name'
    result = f(name)
    assert result

    name = 'person.full_name'
    result = f(name)
    assert result

# Generated at 2022-06-23 22:07:12.004999
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.typing import JSON
    from mimesis.schema import Schema
    from mimesis.providers.generic import Generic

    gen = Generic()

    def schema():
        return {
            'name': gen.text.word(),
            'surname': gen.text.word(),
            'age': gen.numbers.between(1, 100),
            'profession': gen.occupation.occupation(),
        }

    s = Schema(schema)
    result = s.create(10)

    assert isinstance(result, list)
    assert len(result) == 10
    for item in result:
        assert isinstance(item, JSON)
        assert isinstance(item['name'], str)
        assert isinstance(item['surname'], str)

# Generated at 2022-06-23 22:07:16.687798
# Unit test for method create of class Schema
def test_Schema_create():
    """Test Schema create method."""
    schema = {
        'key': 'value',
        'key1': 'value1',
        'obj': {
            'key2': 'value2',
        },
    }

    assert all(schema == Schema(lambda: schema).create(10))

# Generated at 2022-06-23 22:07:26.085670
# Unit test for method create of class Schema
def test_Schema_create():
    import mimesis.builtins
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.person.en import Provider as ENProvider
    from mimesis.providers.person.ru import Provider as RUProvider

    en = ENProvider()
    ru = RUProvider()
    artifacts = ru.artifacts()

    class MyProvider(Person):
        def get_first_name(self, gender: str = None) -> str:
            """Return first name."""
            return 'MyFirstName'
        first_name = get_first_name

        def get_last_name(self, gender: str = None) -> str:
            """Return last name."""
            return 'MyLastName'
        last_name = get_last_name


# Generated at 2022-06-23 22:07:28.982372
# Unit test for constructor of class Schema
def test_Schema():
    # TODO: Mocking the `SchemaType` here is a hack. We should
    # refactor the Schema class in a way that the schema isn't
    # required upon initialization.
    assert Schema(None).create() == []

# Generated at 2022-06-23 22:07:31.174115
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    result = '{} <{}>'.format(Field.__name__, 'en')
    assert result == str(field)

# Generated at 2022-06-23 22:07:33.000096
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field(locale='en-GB')
    assert isinstance(field, Field)
    assert str(field) == 'AbstractField <en-GB>'

# Generated at 2022-06-23 22:07:34.710474
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method `__str__` of class `AbstractField`."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:36.471344
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert '<{}>'.format(f.locale) in str(f)

# Generated at 2022-06-23 22:07:43.066169
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema

    class Person:
        def __init__(self, first_name, second_name, age):
            self.first_name = first_name
            self.second_name = second_name
            self.age = age

    def person_schema(field):
        def fn():
            return Person(
                field('first_name'),
                field('last_name'),
                field('age.elderly'),
            )
        return fn

    p_schema = Schema(person_schema(Field))
    assert len(p_schema.create(1)) == 1
    assert len(p_schema.create(10)) == 10

# Generated at 2022-06-23 22:07:45.145767
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:07:46.905937
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__."""
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:50.092394
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert 'AbstractField <en>' == str(f)

    assert 'AbstractField <ru>' == str(AbstractField(locale='ru'))

# Generated at 2022-06-23 22:07:54.951410
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field.__call__('person.full_name')
    assert field.__call__('person.full_name', gender='male')
    assert field.__call__('person.full_name', 'upper')
    assert field.__call__('person.full_name', 'upper', gender='male')

# Generated at 2022-06-23 22:08:02.156116
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema.

    The method must return list of filled schemas.
    """

    def schema() -> dict:
        """Schema for testing.*/

        This schema returns a dictionary with the key
        ``_pk`` (primary key) which contains a random value.

        :return: Filled schema.
        """
        pk = Field(name='random_int')
        return dict(_pk=pk(min=1, max=10))

    assert len(Schema(schema).create(iterations=3)) == 3

# Generated at 2022-06-23 22:08:07.910462
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    def schema() -> dict:
        """Return dict with a random data."""
        return {
            'name': Field()('name'),
            'age': Field()('age'),
            'sex': Field()('sex'),
        }
    data = Schema(schema).create(5)
    assert data
    assert isinstance(data, list)
    assert len(data) == 5
    for d in data:
        assert isinstance(d, dict)
        assert len(d.keys()) == 3
        assert 'name' in d
        assert 'age' in d
        assert 'sex' in d
    data = Schema(schema).create()
    assert data
    assert isinstance(data, list)
    assert len(data) == 1



# Generated at 2022-06-23 22:08:12.264794
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.address import Address
    from mimesis.schema import AbstractField

    a = Address(seed=1)

    assert Schema(a.city)

    f = AbstractField()

    assert Schema.__init__(
        Schema, f(a.city, key=list))

# Generated at 2022-06-23 22:08:21.871676
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.schema import Field as F

    field = F()
    # Test for case if method has a name of data-provider itself
    assert field('person') in Person.Meta.provides
    assert field('person', gender=Gender.MALE) in Person.Meta.provides
    assert isinstance(field('name'), str)
    assert isinstance(field('text'), str)

    # Test for case if method has a name of other data-provider
    # method which has the same name as method of this data-provider
    assert field('name', min_length=10, max_length=20) in range(10, 21)

# Generated at 2022-06-23 22:08:23.861902
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test class AbstractField."""
    obj = AbstractField()
    assert str(obj) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:26.055720
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        """Dummy schema."""
        return {}

    return Schema(schema)

# Generated at 2022-06-23 22:08:34.437360
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField."""
    def test_maker():
        """Make test."""
        def key_func(result: Any) -> bool:
            """Return true if result is int."""
            return isinstance(result, int)

        field1 = Field()
        field2 = Field(locale='ru')
        field3 = Field(locale='ru', seed=42)
        assert field1('uuid4') is not None
        assert field2('uuid4') is not None
        assert field1('uuid4', seed=42) is not None
        assert field1('uuid4', seed=42) == field3('uuid4')
        assert field1('uuid5') is not None
        assert field1('uuid5') != field2('uuid5')

# Generated at 2022-06-23 22:08:36.047578
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f


# Generated at 2022-06-23 22:08:38.957578
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test abstract field.

    Test for method __call__.
    """
    field = AbstractField()

    # `name` param is None
    with pytest.raises(UndefinedField):
        field(None)

    # Key function
    pwd = field('password', key=lambda x: field('sha256', x))
    assert len(pwd) == 64

    # Unsupported field
    with pytest.raises(UnsupportedField):
        field('unsupported_field')

# Generated at 2022-06-23 22:08:41.473109
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field('ru')
    assert field.locale == 'ru'

# Generated at 2022-06-23 22:08:52.537757
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema, Field
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    schema = Schema(lambda: {
        'first_name': Field('person.first_name', gender=Gender.MALE),
        'last_name': Field('person.last_name', gender=Gender.MALE),
        'gender': Field('choice', items=Gender),
        'age': Field('datetime.age', start=Person.calculate_age(18)),
    })

    assert len(schema.create(iterations=100)) == 100

    data = schema.create()
    assert len(data) == 1
    assert data[0]['first_name']
    assert data[0]['last_name']
    assert data[0]['age']

# Generated at 2022-06-23 22:08:54.309288
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:56.555273
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schemas.base import GenericSchema

    schema = Schema(GenericSchema)
    assert len(schema.create()) == 1

# Generated at 2022-06-23 22:08:58.310053
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField('ru')
    assert field.locale == 'ru'
    assert field.seed is None

# Generated at 2022-06-23 22:09:00.651106
# Unit test for constructor of class Schema
def test_Schema():
    def func() -> JSON:
        return {'foo': 'bar'}

    schema = Schema(func)
    assert schema.schema() == {'foo': 'bar'}

# Generated at 2022-06-23 22:09:03.067872
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.schema import AbstractField
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:08.800945
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('full_name')
    # Ensure that the methods are cached
    assert field("something_new") is None
    # Check that the function returns an error if
    # the method name is not defined
    try:
        field("something_new", key=None)
    except UndefinedField:
        pass

    assert field("seed", key=int) == field._gen.seed


# Generated at 2022-06-23 22:09:14.979825
# Unit test for constructor of class Schema
def test_Schema():
    def random_schema():
        return {
            'name': Field('en').full_name(),
            'age': Field().age(),
        }

    schema = Schema(random_schema)
    assert schema.create(iterations=5) == [
        {'name': 'Jennifer Reed', 'age': 77},
        {'name': 'Ruth Clark', 'age': 84},
        {'name': 'Ruth Phillips', 'age': 84},
        {'name': 'Steve Meyer', 'age': 65},
        {'name': 'Christopher Richards', 'age': 99},
    ]


# Generated at 2022-06-23 22:09:16.191935
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField class with __call__ method."""
    pass

# Generated at 2022-06-23 22:09:17.944806
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField."""
    field = Field()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:09:18.964250
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema is not None

# Generated at 2022-06-23 22:09:23.942086
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()

    # Test __str__()
    assert str(field) == 'AbstractField <en>'

    # Test __call__()
    assert field("word")
    assert field("word", key=lambda x: x.upper())
    assert field("cryptographic.hash", algorithm="sha1")
    assert field("random.pybool")

    # Test exceptions
    try:
        field()
    except UndefinedField:
        pass

# Generated at 2022-06-23 22:09:28.125607
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    obj = AbstractField()
    assert obj('codename')

    # Test for UnacceptableField
    try:
        obj('address.codename')
    except UnacceptableField:
        pass
    else:
        assert False

    # Test for UnsupportedField
    try:
        obj('foo')
    except UnsupportedField:
        pass
    else:
        assert False



# Generated at 2022-06-23 22:09:31.681291
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis import Person

    def schema() -> JSON:
        """Return filled JSON."""
        return Person().full_name()

    sc = Schema(schema)
    assert isinstance(sc.create(), list)

# Generated at 2022-06-23 22:09:33.162777
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert type(AbstractField('ru')) == AbstractField
    assert type(AbstractField('de', seed=42)) == AbstractField



# Generated at 2022-06-23 22:09:40.995505
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.providers.person import Person

    class SomeProvider(BaseSpecProvider):
        def __init__(self, seed: Seed = None, **kwargs):
            super().__init__(seed=seed)

        def hello(self):
            return 'hello'

    class SomeOtherProvider(BaseSpecProvider):
        def __init__(self, seed: Seed = None, **kwargs):
            super().__init__(seed=seed)

        def hello(self):
            return 'Hello'

    providers = (SomeProvider, SomeOtherProvider)

    for cl in (Field, AbstractField):
        f = cl(locale='en', seed=42, providers=providers)
        assert f('hello') == 'hello'


# Generated at 2022-06-23 22:09:43.709350
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.builder import Builder
    bldr = Builder()
    assert '{}'.format(bldr.field(['en'])) == 'Field <en>'

# Generated at 2022-06-23 22:09:45.371015
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(locale='en')
    field('name')

# Generated at 2022-06-23 22:09:48.841045
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.typing import SchemaDict

    schema = SchemaDict({
        'name': 'John',
        'age': 18,
        'city': 'Seattle',
    })

    data = Schema(schema).create(10)

    assert isinstance(data, list)
    assert len(data) == 10
    for item in data:
        assert isinstance(item, dict)



# Generated at 2022-06-23 22:09:54.270709
# Unit test for method create of class Schema
def test_Schema_create():
    def _schema():
        return {
            'name': {'first_name': 'first_name', 'last_name': 'last_name'},
            'age': 'age',
            'birthday': 'date_time',
        }

    result = Schema(_schema).create(1)
    assert isinstance(result, list)
    assert len(result) == 1

# Generated at 2022-06-23 22:09:55.524202
# Unit test for method create of class Schema
def test_Schema_create():
    d = Schema.create(2)
    assert len(d) == 2

# Generated at 2022-06-23 22:09:56.180220
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField)

# Generated at 2022-06-23 22:09:59.839627
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> JSON:
        """Schema."""
        return {
            '__field': 'person.full_name',
        }

    generator = Schema(schema)
    assert generator.create(iterations=1)[0] == 'Maurice Schultz'

# Generated at 2022-06-23 22:10:06.423816
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Without arguments
    assert Field().locale == 'en'
    assert Field().seed is None

    assert Field('ru').locale == 'ru'
    assert Field('ru').seed is None

    assert Field(seed=42).locale == 'en'
    assert Field(seed=42).seed == 42

    assert Field('ru', seed=42).locale == 'ru'
    assert Field('ru', seed=42).seed == 42

# Generated at 2022-06-23 22:10:15.668525
# Unit test for method create of class Schema
def test_Schema_create():
    """Test function."""
    from mimesis.data import (
        GENDER,
        SOCIAL_NETWORKS,
        COUNTRIES,
        REGIONS,
        CITIES,
    )
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.geography import Geography

    def schema() -> JSON:
        """Return schema."""
        from mimesis import Person

        p = Person('ru')

        return {
            'first_name': p.first_name(),
            'last_name': p.last_name(),
            'username': p.username(),
            'email': p.email(),
        }

    def provider_schema() -> JSON:
        """Return schema."""

# Generated at 2022-06-23 22:10:18.709570
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda: {'test': 5})
    result = schema.create(iterations=5)
    assert len(result) == 5
    assert result == [{'test': 5} for _ in range(5)]

# Generated at 2022-06-23 22:10:20.708979
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:22.859229
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'
    assert str(Field(locale='ru')) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:10:26.903124
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField constructor."""
    _field = AbstractField()
    assert _field.locale == 'en'
    assert _field.seed is None
    assert hasattr(_field._gen, 'random')
    assert hasattr(_field._gen, 'datetime')



# Generated at 2022-06-23 22:10:33.122324
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():  # pragma: no cover
        return {
            'key1': Field().uuid(),
            'key2': Field().uuid(),
        }

    schema = Schema(schema)
    result = schema.create(iterations=1)

    assert isinstance(result, list)
    assert len(result) == 1

    for item in result:
        assert isinstance(item, dict)
        assert len(item) == 2
        assert item['key1'] != item['key2']



# Generated at 2022-06-23 22:10:44.015056
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""

# Generated at 2022-06-23 22:10:48.851233
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(dict)
    assert isinstance(schema, Schema)
    assert isinstance(schema.schema, dict)
    assert isinstance(schema.create(), list)

    schema = Schema(list)
    assert isinstance(schema, Schema)
    assert isinstance(schema.schema, list)
    assert isinstance(schema.create(), list)
    pass



# Generated at 2022-06-23 22:10:50.372922
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.locale == 'en'

# Generated at 2022-06-23 22:10:54.172735
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> JSON:
        """Create schema."""
        return {
            'first_name': '{{ person.first_name() }}',
            'last_name': '{{ person.last_name() }}',
        }

    s = Schema(schema)
    assert isinstance(s.create(), list)

# Generated at 2022-06-23 22:10:57.637657
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    # Test correct class name
    field = AbstractField(locale='en')
    assert field.__str__() == 'AbstractField <en>'

    # Test correct locale
    field = AbstractField(locale='ru')
    assert field.__str__() == 'AbstractField <ru>'



# Generated at 2022-06-23 22:11:00.264881
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == '{} <{}>'.format(
        AbstractField.__name__, f.locale)



# Generated at 2022-06-23 22:11:06.001621
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # https://github.com/lk-geimfari/mimesis/issues/919
    field = AbstractField(locale='en')
    result = field('choice', choices=['a', 'b'])
    assert result in ['a', 'b']

    field = AbstractField(locale='uk', providers=[])
    result = field('uuid')
    assert len(result) > 0

# Generated at 2022-06-23 22:11:09.613710
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        @staticmethod
        def test_schema():
            return {'success': True}

    schema = TestSchema(TestSchema.test_schema)
    assert schema.schema() == {'success': True}


# Generated at 2022-06-23 22:11:11.150986
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for class ``Schema``."""
    assert callable(Schema)

# Generated at 2022-06-23 22:11:12.931312
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:15.517880
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test of method __call__ of class AbstractField."""
    f = Field()
    try:
        f()
        assert False
    except UndefinedField:
        assert True



# Generated at 2022-06-23 22:11:17.456122
# Unit test for constructor of class Schema
def test_Schema():
    try:
        Schema('schema')
    except UndefinedSchema:
        pass
    else:
        assert False



# Generated at 2022-06-23 22:11:23.721877
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {"name": "Tom"}

    sch = Schema(schema)
    assert isinstance(sch.create(), list) is True
    assert isinstance(sch.create(1), list) is True
    assert isinstance(sch.create(1)[0], dict) is True
    assert isinstance(sch.create(5), list) is True
    assert isinstance(sch.create(5)[0], dict) is True
    assert len(sch.create(5)) == 5

# Generated at 2022-06-23 22:11:25.755331
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__."""

    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:35.721688
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.schema import Field

    def schema() -> dict:
        return {
            'name': Field('person.full_name', gender=Gender.MALE),
            'age': Field('datetime.age'),
            'job': Field('employment.position'),
        }

    assert isinstance(schema(), dict)
    schema_obj = Schema(schema)
    iterations = 10
    data = schema_obj.create(iterations)

    assert len(data) == iterations

    for item in data:
        assert len(item.keys()) == 3
        assert 'name' in item.keys()
        assert 'age' in item.keys()
        assert 'job' in item.keys()

# Generated at 2022-06-23 22:11:36.758439
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()

    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:43.608286
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(
        lambda: {
            'name': 'Jack',
            'surname': 'Daniels',
            'age': 20
        }
    )
    assert schema.create(2) == [{
        'name': 'Jack',
        'surname': 'Daniels',
        'age': 20
    }, {
        'name': 'Jack',
        'surname': 'Daniels',
        'age': 20
    }]

# Generated at 2022-06-23 22:11:46.278884
# Unit test for constructor of class Schema
def test_Schema():
    class Foo:
        def __init__(self):
            self.foo = True

    schema = Schema(Foo)
    assert isinstance(schema, Schema)

# Generated at 2022-06-23 22:11:53.502787
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField class."""
    obj = AbstractField()

    assert isinstance(obj._gen, Generic)
    assert obj._table == {}  # type: ignore
    assert obj.locale == 'en'
    assert obj.seed is None

    obj = AbstractField(locale='ru', seed=42)
    assert obj.locale == 'ru'
    assert obj.seed == 42

    obj = AbstractField(locale='tt', seed='test')
    assert obj.locale == 'tt'
    assert obj.seed == 'test'

# Generated at 2022-06-23 22:11:54.529684
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert AbstractField().__class__ is AbstractField



# Generated at 2022-06-23 22:12:02.446270
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Method name is None
    f = Field()
    try:
        f()
    except UndefinedField:
        pass
    else:
        raise ValueError('Method name is None.')

    # Method name is empty string
    f = Field()
    try:
        f('')
    except UndefinedField:
        pass
    else:
        raise ValueError('Method name is empty string.')

    # Check call without kwargs
    f = Field()
    assert f('uuid')

    # Check call with kwargs
    f = Field()
    assert f('uuid', only_hex=True)

    # Check tail
    f = Field()

    try:
        f('lorem.ipsum')
    except UnacceptableField:
        pass

# Generated at 2022-06-23 22:12:07.909384
# Unit test for method create of class Schema
def test_Schema_create():
    def schema(context):
        context['foo'] = 'bar'
        context['bar'] = [1, 2, 3]
        return context

    data = Schema(schema).create(10)
    assert len(data) == 10
    assert data[0]['foo'] == 'bar'
    assert data[0]['bar'] == [1, 2, 3]

# Generated at 2022-06-23 22:12:08.942755
# Unit test for constructor of class AbstractField
def test_AbstractField():
    return Field()

# Generated at 2022-06-23 22:12:18.111615
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis import Person, Address, Datetime
    from mimesis.enums import Gender

    person = Person('en')
    address = Address('en')
    datetime = Datetime('en')

    current_year = datetime.now().year
    date_from = datetime.date(current_year - 4, 1, 1)
    date_to = datetime.date(current_year - 18, 1, 1)


# Generated at 2022-06-23 22:12:28.483723
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from random import randint
    from mimesis import datetime
    from mimesis.enums import Gender
    from mimesis.schema import Schema, Field

    def schema_1():
        """Create schema (1)."""

# Generated at 2022-06-23 22:12:30.808352
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test str method of AbstractField."""
    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:12:36.549131
# Unit test for constructor of class AbstractField
def test_AbstractField():
    class MyField(AbstractField):
        def __init__(self):
            super().__init__(locale='ru', seed=1, providers=None)

    f = MyField()
    assert f.__class__.__name__ == '_MyField'
    assert f.locale == 'ru'
    assert f.seed == 1
    assert f._gen.__class__.__name__ == 'Generic'

# Generated at 2022-06-23 22:12:40.962789
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'date': Field('datetime').date(start=2017, end=2019),
            'time': Field('datetime').time(),
        }

    _ = Schema(schema).create(iterations=5)

    assert type(_) is list

# Generated at 2022-06-23 22:12:44.166900
# Unit test for constructor of class Schema
def test_Schema():
    @Field()
    def schema() -> Any:
        return 'Hello, world!'

    s = Schema(schema)

    assert isinstance(s.__dict__.get('schema'), Field)

# Generated at 2022-06-23 22:12:46.017896
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        pass
    sc = Schema(schema)
    assert schema == sc.schema

# Generated at 2022-06-23 22:12:48.270092
# Unit test for method create of class Schema
def test_Schema_create():
    assert Schema(lambda: {}).create(iterations=10) == [{}] * 10

# Generated at 2022-06-23 22:12:50.828930
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema as _Schema
    from mimesis.schema import Field as _Field

    assert isinstance(_Schema, type)


# Unit test function create of class Schema.

# Generated at 2022-06-23 22:12:53.759317
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField.

    Create instance of AbstractField and check if it is a callable object.
    """
    gen = Field()
    assert callable(gen)

# Generated at 2022-06-23 22:13:00.130080
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """
    Test for method ``__call__`` of the class AbstractField,
    with default value of arguments.
    """
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field('postal_code') == '28305'
    assert field('custom_code', code='42') == '42'

# Generated at 2022-06-23 22:13:03.138933
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of class Schema."""
    try:
        Schema('str')
    except UndefinedSchema:
        Schema(lambda: None)

# Generated at 2022-06-23 22:13:08.735818
# Unit test for method create of class Schema
def test_Schema_create():
    def simple_schema():
        return {
            'int, 10': 1,
            'bool': True,
        }

    gen = Schema(simple_schema)
    simple_data = gen.create(2)
    assert len(simple_data) == 2
    assert simple_data[0]['int, 10'] == 1
    assert type(simple_data[1]['int, 10']) is int

# Generated at 2022-06-23 22:13:11.165112
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for :class:`~mimesis.schema.Schema`."""
    s = Schema(None)
    assert s.schema is None



# Generated at 2022-06-23 22:13:12.769614
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == "AbstractField <en>"

# Generated at 2022-06-23 22:13:14.398161
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert f.__str__() == "AbstractField <en>"

# Generated at 2022-06-23 22:13:16.867991
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:18.162019
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for AbstractField."""
    a = AbstractField()
    assert isinstance(a, AbstractField)

# Generated at 2022-06-23 22:13:20.032373
# Unit test for constructor of class AbstractField
def test_AbstractField():
    data = AbstractField(seed=420)

    assert data.locale == 'en'
    assert data.seed == 420



# Generated at 2022-06-23 22:13:24.857307
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert hasattr(field, '_gen')
    assert isinstance(field._gen, Generic)
    assert hasattr(field, '_table')
    assert isinstance(field._table, dict)
    assert field.locale == 'en'
    assert field.seed is None

    field = Field('ru')
    assert field.locale == 'ru'

    seed = 'mimesis'
    field = Field(seed=seed)
    assert field.seed == seed



# Generated at 2022-06-23 22:13:27.097785
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__ method."""
    x = Field()
    assert callable(x)



# Generated at 2022-06-23 22:13:33.011964
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test function __str__ of class AbstractField."""
    from mimesis.enums import Gender
    from mimesis.schema import Field as _Field

    s = _Field()
    assert isinstance(s, AbstractField)

    assert isinstance(s, Generic)
    assert isinstance(s.choice, Generic.choice)

    assert s.gender.MALE == Gender.MALE

    assert s.__str__() == 'AbstractField <en>'

    s = _Field(locale='ru')
    assert s.__str__() == 'AbstractField <ru>'

# Generated at 2022-06-23 22:13:41.023981
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Field

    def schema() -> JSON:
        return {
            'name': Field('name').create(),
            'age': Field('age').create(),
        }

    schema = Schema(schema)

    assert schema is not None
    assert hasattr(schema, 'schema')
    assert isinstance(schema.schema, Callable)
    assert isinstance(schema.create(), List)
    assert schema.create(5)

# Generated at 2022-06-23 22:13:45.133907
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    def key(x: List[str]) -> str:
        return ','.join(x)

    assert key(field('choice', key=key, values=['a', 'b', 'c'])) == 'a,b,c'

# Generated at 2022-06-23 22:13:48.431966
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema():
        return {
            'name': 'test',
            'age': 18
        }

    s = Schema(test_schema)
    assert isinstance(s, Schema)



# Generated at 2022-06-23 22:13:56.215148
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method that creates a filled schema."""
    from mimesis.builtins import Basic

    field = Field()
    data = {
        'name': str(field),
        'age': int(field),
        'email': field('email'),
        'username': field('username'),
        'password': field('password',
                          length=10,
                          special_chars=True),
        'address': field('address'),
        'company': field('company'),
        'full_name': field('full_name'),
    }

    schema = Schema(data)
    filled_schema = schema.create(iterations=20)
    assert len(filled_schema) == 20
    assert isinstance(filled_schema, list)


# Generated at 2022-06-23 22:13:59.261547
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()  # pass
    assert isinstance(f, AbstractField)

    result = f(name = 'uuid')
    assert isinstance(result, str)

# Generated at 2022-06-23 22:14:08.349640
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__ method."""
    f = Field()

    assert f.__call__('name') is not None
    assert f.__call__('name', full_name=True) is not None
    assert f.__call__('user_agent', browser=True) is not None
    assert f.__call__('title', gender='female') is not None
    assert f.__call__('currency', code=True) is not None

    assert f.__call__('choice', items=('a', 'b', 'c')) is not None
    assert f.__call__('choice', items=('a', 'b', 'c'), key=str.upper) is not None

# Generated at 2022-06-23 22:14:14.238041
# Unit test for method create of class Schema
def test_Schema_create():
    """Testing create method of class Schema."""
    @Field
    def field(**kwargs):
        return kwargs

    # Short schemas for testing
    s = Schema(lambda: {'a': field('choice', choices=['1', '2', '3'],
                                    key=lambda x: int(x))})
    assert isinstance(s.create(), list)
    assert isinstance(s.create()[0], dict)

# Generated at 2022-06-23 22:14:17.337637
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'Field <en>'



# Generated at 2022-06-23 22:14:22.807376
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': 'StructuredText',
        'field': 'generic.text',
        'max_length': 200,
        'min_length': 50,
    }

    s = Schema(schema)
    schemas = s.create(iterations=5)
    assert isinstance(schemas, list)
    assert len(schemas) == 5

# Generated at 2022-06-23 22:14:26.272141
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'field': '{{ person.get_full_name() }}'}

    filled = Schema(Field).create(schema)

    assert filled
    assert len(filled) == 3
    assert len(filled[0]) == 1

# Generated at 2022-06-23 22:14:27.881386
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field._gen.locale == 'en'
    assert field._gen.seed is None

# Generated at 2022-06-23 22:14:29.180672
# Unit test for constructor of class Schema
def test_Schema():
    if Schema:
        return True
    else:
        return False