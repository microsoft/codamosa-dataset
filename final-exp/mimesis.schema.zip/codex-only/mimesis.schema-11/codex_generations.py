

# Generated at 2022-06-23 22:04:41.294285
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert callable(field)
    assert field('user.full_name') is not None
    assert field('user.full_name') is not None
    assert field('user.full_name') is not None

    assert field('user.full_name', with_middle_name=False) is not None
    assert field('user.full_name', with_middle_name=False) is not None

    assert field('user.full_name', with_middle_name=False,
                 to_upper=True) is not None

# Generated at 2022-06-23 22:04:42.992613
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None
    assert field._table is not None

# Generated at 2022-06-23 22:04:46.455540
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='ru', seed=0)
    assert field.locale == 'ru'
    assert field.seed == 0

    assert field(name='last_name') == 'Арсентьев'
    assert field(name='full_name', key=lambda x: x.split()[0]) == 'Семён'

# Generated at 2022-06-23 22:04:49.728749
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert isinstance(field, AbstractField)

    field = Field(locale='sk')
    assert field._gen.sk

    field = Field(seed='seed')
    assert field._gen.seed == 'seed'

# Generated at 2022-06-23 22:04:54.846264
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert Field(seed=42)('text') == 'Dolor nesciunt distinctio quos.'
    assert Field(seed=42)('text', key=str.upper) == \
        'DOLOR NESCIUNT DISTINCTIO QUOS.'
    assert Field(seed=42)('lorem_ipsum') == \
        'Dolor quia autem repellendus pariatur qui quod.'

# Generated at 2022-06-23 22:04:58.107798
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for the string representation of AbstractField."""
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'
    assert repr(f) == '<AbstractField: en>'

# Generated at 2022-06-23 22:04:59.552546
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:03.119418
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert Field().__call__('foo') == Field().foo()
    assert Field().__call__('foo', key=lambda x: str(x)) == Field().foo()



# Generated at 2022-06-23 22:05:04.997675
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    fake = AbstractField()
    assert fake

# Generated at 2022-06-23 22:05:12.648623
# Unit test for constructor of class Schema
def test_Schema():
    from schema import Schema as MagicSchema

    def create_schema() -> dict:  # pragma: no cover
        return {
            'login': '{username}_{seed}',
            'username': '{person.last_name}_{person.first_name}',
            'person': {
                'first_name': '{person.first_name}',
                'last_name': '{person.last_name}',
            }
        }

    s = Schema(create_schema)
    assert s.schema == MagicSchema

# Generated at 2022-06-23 22:05:21.072940
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import Person

    dictionary = {
        'string': (str, ),
        'integer': (int, ),
        'float': (float, ),
        'boolean': (bool, ),
        'person':  {
            'fullname': (Person.full_name, ),
            'address': (Person.address, ),
        },
    }

    def schema() -> JSON:
        return Field(providers=(Person, )).create(dictionary)

    data = Schema(schema).create(5)
    assert isinstance(data, list)

# Generated at 2022-06-23 22:05:31.705253
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.internet import Internet

    f = Field(seed=12345)
    f._gen.add_providers(Internet)

    resp1 = f('get_email')
    assert resp1 == 'smithjoe@gmail.com'

    resp2 = f('internet.get_email')
    assert resp2 == 'smithjoe@gmail.com'

    resp3 = f('get_email', domain='gmail.com')
    assert resp3 == 'smithjoe@gmail.com'

    resp4 = f('internet.get_email', domain='yandex.ru')
    assert resp4 == 'smithjoe@yandex.ru'

    resp5 = f('get_email', domain='yandex.ru', key=lambda x: x.split('@')[0])

# Generated at 2022-06-23 22:05:35.086820
# Unit test for constructor of class Schema
def test_Schema(): 
    """Assert that class Schema is initialized."""
    schema = Schema(None)
    assert schema

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 22:05:39.823366
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for correct work of method ``__call__``."""
    f = Field()
    f.__call__(name='email', name_prefix=False)
    f.__call__(name='foo.email', name_prefix=False)

# Generated at 2022-06-23 22:05:44.613719
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Field
    from mimesis.enums import Gender

    def schema():
        return {
            'name': Field('full_name', gender=Gender.MALE),
            'age': Field('age', minimum=18, maximum=60),
        }

    assert Schema(schema)

# Generated at 2022-06-23 22:05:46.811563
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField(locale="en", seed=123)
    assert f.locale == "en"
    assert f.seed == 123

# Generated at 2022-06-23 22:05:48.876884
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema(lambda: {})
    assert isinstance(s, Schema)



# Generated at 2022-06-23 22:05:55.026597
# Unit test for constructor of class Schema
def test_Schema():
    R = Schema

    class DummySchema:
        @staticmethod
        def schema() -> JSON:
            return {'foo': 'bar'}

    schema = DummySchema()

    assert isinstance(R(DummySchema.schema), R)

    # Passing not callable object
    try:
        R({})
        assert False
    except UndefinedSchema:
        assert True

    # Passing schema object
    try:
        R(schema)
        assert False
    except UndefinedSchema:
        assert True

# Generated at 2022-06-23 22:05:58.999466
# Unit test for method create of class Schema
def test_Schema_create():
    test_schema = {'a': 1, 'b': '2'}

    s = Schema(lambda: test_schema)
    res = s.create()
    assert isinstance(res, list)
    assert len(res) == 1

    res = s.create(2)
    assert len(res) == 2
    assert res[0] == res[1] == test_schema

# Generated at 2022-06-23 22:06:06.905249
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema
    from mimesis.schema import Field
    from mimesis.enums import Gender

    field = Field(locale='en')
    schema = Schema(
        lambda: {
            'first_name': field('first_name', gender=Gender.FEMALE),
            'last_name': field('last_name', gender=Gender.FEMALE),
            'age': field('random_int', min_value=18, max_value=99),
        }
    )
    assert len(schema.create(iterations=5)) == 5

# Generated at 2022-06-23 22:06:10.312869
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:06:11.962827
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:06:17.815663
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import JSON, Schema

    schema = {'name': 'John', 'age': lambda: 15}  # type: SchemaType

    s = Schema(schema)  # type: Schema
    assert isinstance(s.create(), list)
    assert all(isinstance(i, JSON) for i in s.create())

# Generated at 2022-06-23 22:06:24.319534
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from pprint import pprint

    class Provider:
        def method(self, *args, **kwargs):
            return self.__class__.__name__ + '::' + self.method.__name__

    class Provider1(Provider):
        pass

    class Provider2(Provider):
        pass

    field = AbstractField(providers=(Provider1(), Provider2()))
    pprint(field('method', size=10))

# Generated at 2022-06-23 22:06:27.878066
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField constructor."""
    data = {'locale': 'en', 'seed': None}
    abstract_field = AbstractField(**data)
    assert abstract_field.locale == 'en'
    assert abstract_field.seed == None

# Generated at 2022-06-23 22:06:32.327485
# Unit test for constructor of class Schema
def test_Schema():
    """Scenario: Constructor of the Schema generates new class."""
    schema = {'a': 10}

    def func() -> SchemaType:
        return schema

    sch = Schema(func)
    assert sch.schema() == schema
    assert sch.create() == [schema]

# Generated at 2022-06-23 22:06:34.243936
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        AbstractField()
    except:
        return False
    else:
        return True

# Generated at 2022-06-23 22:06:38.172613
# Unit test for constructor of class Schema
def test_Schema():
    def s():
        return {
            'name': Field('en').name(),
            'surname': Field('en').surname(),
        }

    s = Schema(s)
    assert isinstance(s, Schema)
    assert isinstance(s.schema, Callable)
    assert s.create(10)

# Generated at 2022-06-23 22:06:39.791375
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test init of AbstractField."""
    field = AbstractField()
    assert isinstance(field, Field)

# Generated at 2022-06-23 22:06:42.792234
# Unit test for method create of class Schema
def test_Schema_create():
    """Test that schema is correct."""
    schema = Schema(lambda: {
        'name': 'Test',
        'address': 'Earth',
    })
    assert schema.create() == [
        {'name': 'Test', 'address': 'Earth'},
    ]



# Generated at 2022-06-23 22:06:53.513696
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # name: the name of the method which called
    # empty: if keyword is empty or not
    # should_be: result of call if name of method or **kwargs is correct
    for name, key, should_be in [
        (
                'full_name',
                None,
                'Alice Beauregard',
        ),
        (
                'full_name',
                lambda x: x.split(' ')[0],
                'Alice',
        ),
        (
            'currency_code',
            lambda x: x.upper(),
            'USD',
        ),
        (
            'html.element',
            lambda x: x.upper(),
            'DIV',
        ),
    ]:
        field = AbstractField()
        assert field(name, key=key) == should_be

# Generated at 2022-06-23 22:07:04.074651
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.providers.generic import Generic
    from mimesis.schema import Schema

    g = Generic()
    r = g.random

    def schema() -> JSON:
        """Generate a sample JSON schema."""
        return {
            "name": g.full_name(),
            "age": r.randint(min_value=21, max_value=70),
            "gender": g.gender(),
            "email": g.email(),
            "phone": g.telephone(),
            "address": {
                "street": g.address.street_name(),
                "city": g.address.city(),
                "zip": g.address.zip_code(),
                "country": g.address.country(),
            }
        }

    s = Sche

# Generated at 2022-06-23 22:07:05.613555
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        """A simple schema."""
        return {
            'name': 'Pepe',
            'email': 'pepe@gmail.com',
            'age': 10
        }

    sc = Schema(schema)
    assert sc.create(3) == [schema(), schema(), schema()]

# Generated at 2022-06-23 22:07:07.104195
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField('en')
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:07:08.838097
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert hasattr(f, '__call__')
    assert callable(f.__call__)

# Generated at 2022-06-23 22:07:15.133004
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None

    field = AbstractField(seed=1234)
    assert field.seed == 1234

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'

    field = AbstractField(seed=1234, locale='ru')
    assert field.seed == 1234
    assert field.locale == 'ru'


# Generated at 2022-06-23 22:07:17.275217
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema

    with Schema(None) as s:
        assert s is None



# Generated at 2022-06-23 22:07:27.429932
# Unit test for method create of class Schema
def test_Schema_create():
    """Test that the ``create`` method of class ``Schema`` works properly."""
    from mimesis.enums import Gender
    from mimesis.providers.geo import Geo
    from mimesis.providers.person import Person

    geo = Geo('ru')
    person = Person('ru')

    def schema() -> dict:
        """Return filled schema."""
        data = {}

        data['street'] = geo.address.street_suffix()
        data['name'] = person.full_name(gender=Gender.MALE)
        data['age'] = person.age()

        return data

    _ = Schema(schema)
    with person.seed(42):
        result = _.create()

    assert len(result) == 1

# Generated at 2022-06-23 22:07:29.097814
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test class AbstractField."""
    provider = AbstractField()
    assert provider
    assert isinstance(provider, AbstractField)

# Generated at 2022-06-23 22:07:32.674377
# Unit test for method create of class Schema
def test_Schema_create():
    def a() -> dict:
        return {'a': 'foo'}

    gen = Field()
    schema = Schema(a)
    result = schema.create(1)
    assert isinstance(result, list)
    assert len(result) == 1
    assert {'a': 'foo'} in result

# Generated at 2022-06-23 22:07:34.741136
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema(lambda: {'test': lambda: 'test'})



# Generated at 2022-06-23 22:07:36.472957
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='en')
    assert field.locale == 'en'



# Generated at 2022-06-23 22:07:41.951417
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema():
        return {
            'username': 'John Doe',
            'lucky_number': 49,
            'credit_card': '420000111122223333',
            'expires_in': 365,
            'is_active': False,
        }

    schema = Schema(test_schema)
    data = schema.create(2)
    assert len(data) == 2

# Generated at 2022-06-23 22:07:47.368688
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers import Address, Person
    from mimesis.schema import AbstractField
    from mimesis.typing import JSON

    def schema() -> JSON:
        return {
            'name': str(Person('en', 'avatar').full_name()),
            'address': Address('en').address(),
        }

    abstract = AbstractField('en', 'key', [Person, Address])
    schema = Schema(abstract)
    result = schema.create(iterations=3)
    assert len(result) == 3



# Generated at 2022-06-23 22:07:50.834168
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    schema = Schema(lambda x: x)
    data = schema.create(10)
    assert isinstance(data, list) is True
    assert len(data) == 10

# Generated at 2022-06-23 22:07:56.930927
# Unit test for constructor of class Schema
def test_Schema():
    schema1 = {'name': 'John Snow', 'age': 25, 'gender': 'male'}
    schema2 = {'name': 'Jane Doe', 'age': 32, 'gender': 'female'}

    def names() -> JSON:
        if Field().coin_flip():
            return schema1
        return schema2

    schema = Schema(names)

    res = schema.create()
    assert isinstance(res, list)
    assert len(res) == 1

    res = schema.create(iterations=3)
    assert isinstance(res, list)
    assert len(res) == 3

# Generated at 2022-06-23 22:08:00.371006
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test initialization of the class AbstractField."""
    assert callable(AbstractField())


# Run tests for AbstractField
if __name__ == '__main__':
    test_AbstractField()

# Generated at 2022-06-23 22:08:01.345159
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:05.625669
# Unit test for method create of class Schema
def test_Schema_create():
    def _schema() -> JSON:
        return {'name': 'Siddharth Sharma'}

    s = Schema(_schema)
    assert isinstance(s.create(1), list)
    assert isinstance(s.create(3), list)
    assert len(s.create(3)) == 3
    assert isinstance(s.create(3)[0], dict)



# Generated at 2022-06-23 22:08:06.949583
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(Field())



# Generated at 2022-06-23 22:08:14.282336
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__.

    This method is tested by schema test.
    """
    # Implementation details
    # Assert all exceptions which can be raised by this method,
    # and check if results is not None.
    f = Field()
    assert f('gender', key=lambda x: x) is not None
    assert f('gender', 'hello') is not None
    assert f(key=lambda x: 'hello') is None
    assert f(name='non.existent', key=lambda x: x) is None
    assert f('non.existent', key=lambda x: x) is None
    assert f('name') is not None

# Generated at 2022-06-23 22:08:17.832266
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    def schema_mock() -> JSON:
        """Test schema mock."""
        return {
            'foo': 'bar',
            'baz': 42,
        }

    filled_schemas = Schema(schema=schema_mock).create(5)

    assert len(filled_schemas) == 5
    assert schema_mock() in filled_schemas

# Generated at 2022-06-23 22:08:20.587255
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Testing __str__ of AbstractField."""
    f = Field(locale='en', seed=123)
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:22.332858
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """
    :type AbstractField: object
    """
    field = AbstractField('en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:25.173731
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test the __str__ method of `AbstractField` class."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:33.821905
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from typing import cast

    from mimesis.enums import Gender

    f = Field(seed=42)
    f._gen.add_providers('person')
    assert f('gender') == Gender.FEMALE
    assert f('gender') == Gender.FEMALE
    assert f('gender') != Gender.MALE
    assert f('age', minimum=18, maximum=100) == cast(int, f('age', minimum=18, maximum=100))
    assert f('full_name') == 'Chloe Lin'

    f_ru = Field(locale='ru')
    f_ru._gen.add_providers('person')
    assert f_ru('gender') == Gender.MALE
    assert f_ru('gender') == Gender.MALE
    assert f_ru('gender') != Gender.FEMALE
    assert f

# Generated at 2022-06-23 22:08:35.384535
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert f.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:39.298565
# Unit test for constructor of class Schema
def test_Schema():
    def invalid_schema2():
        pass
    assert not callable(invalid_schema2)
    s = Schema(invalid_schema2)
    assert s.schema == invalid_schema2
    assert not callable(s.schema)



# Generated at 2022-06-23 22:08:43.042692
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import Person
    p = Person('ru')
    field = AbstractField(providers=[p])
    assert field('full_name') == p.full_name()

# Generated at 2022-06-23 22:08:52.106738
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()

    assert 'en' == f.locale
    assert f.seed is None
    assert f._gen is not None

    result = f(name='name', key=str.upper)
    assert isinstance(result, str)

    result = f(name='name.first_name', key=str.title)
    assert isinstance(result, str)

    result = f(name='name.full_name', key=str.capitalize)
    assert isinstance(result, str)

    result = f(name='full_name', key=str.lower)
    assert isinstance(result, str)



# Generated at 2022-06-23 22:09:01.950253
# Unit test for method create of class Schema
def test_Schema_create():
    from decimal import Decimal

    field = Field()

    def schema() -> dict:
        return {
            'name': field('person.full_name', capitalize=True),
            'age': field('age', minimum=18, maximum=30),
            'random': field('random_number', minimum=1, maximum=10),
        }

    s = Schema(schema)
    data = s.create(10)

    assert len(data) == 10

    for item in data:
        assert isinstance(item['random'], int)
        assert isinstance(item['age'], int)
        assert isinstance(item['name'], str)

    # Ensure that decimal is supported

# Generated at 2022-06-23 22:09:08.719890
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for AbstractField."""
    field = Field()

    provider = '...'
    method = '...'

    assert field(provider + '.' + method) is not None
    assert field(provider + '.' + method, 0) is not None
    assert field(provider + '.' + method, 1) is not None
    assert field(provider + '.' + method, value=1) is not None

    assert field('...', 0, 1) is not None

    assert field.__str__() is not None

# Generated at 2022-06-23 22:09:10.296585
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:09:18.155517
# Unit test for constructor of class Schema
def test_Schema():
    import pytest
    from mimesis.providers import Address, Person

    # Custom schema.
    def schema():
        return {
            'name': str(Field()),
            'address': str(Field()),
        }

    # Invalid schema.
    def invalid_schema():
        return {
            'second_name': Field(),
            'address': str(Field()),
        }

    s = Schema(schema)
    assert len(s.create()) == 1

    # Test for custom schema.
    assert s.create(10)[0]['name'] == Person.name()
    assert s.create(10)[0]['address'] == Address.address()

    # Test for invalid schema.
    with pytest.raises(UndefinedSchema):
        Schema(invalid_schema)

# Generated at 2022-06-23 22:09:26.664274
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # test with invalid parameter
    field = Field()
    try:
        field()
    except UndefinedField as err:
        assert str(err) == 'Undefined field name.'

    # test with bad syntax
    try:
        field(name='bad.syntax')
    except UnacceptableField as err:
        assert str(err) == (
            "Can't use tail parser on this syntax (bad.syntax)."
        )

    # test with not existing method
    try:
        field(name='not.exists')
    except UnsupportedField as err:
        assert str(err) == "Field not.exists not supported."

    # test with existing method
    assert field(name='code.ean')

    # test with existing method and with key function

# Generated at 2022-06-23 22:09:36.903495
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema
    from mimesis.providers.network import Address
    from mimesis.enums import Gender

    # Declare a custom schema
    def pokedex() -> dict:
        """Custom schema."""
        _ = Address('en')
        gender = Gender.MALE
        return {
            'name': _.username(),
            'gender': gender.value,
            'age': _.age(),
            'address': {
                'city': _.city(),
                'country': _.country(),
            }
        }

    # Create a new schema object
    schema = Schema(pokedex)

    # Generate 3 filled schemas
    result = schema.create(3)

    assert len(result) == 3



# Generated at 2022-06-23 22:09:38.224646
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda: 'test')
    assert schema.create(iterations=10) == ['test'] * 10

# Generated at 2022-06-23 22:09:39.519916
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Show that AbstractField works correctly."""
    field = AbstractField(locale='ru')
    assert callable(field)

# Generated at 2022-06-23 22:09:42.618425
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    from mimesis.providers.address import Address

    f = Field()
    assert f('city') == Address(f.locale, f.seed).city()
    assert f('city', key=str.upper) == Address(f.locale, f.seed).city().upper()

# Generated at 2022-06-23 22:09:44.567078
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis import Field
    assert Field('ru')



# Generated at 2022-06-23 22:09:48.840416
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import Generic

    _generic = Generic()

    def _schema() -> str:
        """Create a schema."""
        return _generic.text.word()

    _schema = Schema(_schema)
    data = _schema.create()
    assert len(data) == 1
    assert isinstance(data, list)

# Generated at 2022-06-23 22:09:58.667623
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of class Schema."""
    from mimesis.schema import Schema
    from mimesis.enums import Gender
    from mimesis.typing import JSON

    def user_schema() -> JSON:
        """User schema."""
        from mimesis.providers.person import Person

        person = Person()

        return {
            'name': person.name(Gender.MALE),
            'surname': person.surname(),
            'full_name': person.full_name(Gender.MALE),
            'email': person.email(),
            'username': person.username(),
            'password': person.password(),
            'birthdate': person.birthday(),
            'age': person.age(),
            'gender': person.gender(),
        }


# Generated at 2022-06-23 22:10:03.186473
# Unit test for constructor of class Schema
def test_Schema():
    t = Schema(lambda: {
        'name': 'first_name',
    })
    a = t.create()
    assert len(a) == 1
    assert 'name' in a[0].keys()

# Generated at 2022-06-23 22:10:10.206748
# Unit test for method create of class Schema
def test_Schema_create():
    """Test create method of class Schema."""
    def test_schema() -> dict:
        """Test schema."""
        return {
            'field_1': 1,
            'field_2': 2,
        }

    schema = Schema(schema=test_schema)
    result = schema.create(iterations=2)
    # Assert that `iterations` is always greater than 0
    assert isinstance(result, list)
    # Assert that each item in the list is a dictionary
    assert isinstance(result[0], dict)
    # Assert that the length of the list is `iterations`
    assert len(result) == 2

# Generated at 2022-06-23 22:10:11.867998
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # assert isinstance(AbstractField, object)
    assert issubclass(AbstractField, object)

# Generated at 2022-06-23 22:10:18.244205
# Unit test for constructor of class Schema
def test_Schema():
    schema = {'a': 'test'}

    s = Schema(lambda: schema)

    assert s.schema() == {'a': 'test'}
    assert s.create() == [{'a': 'test'}]
    assert s.create(2) == [{'a': 'test'}, {'a': 'test'}]
    assert s.create(0) == []

    try:
        Schema({})
    except UndefinedSchema:
        pass



# Generated at 2022-06-23 22:10:19.101431
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test schemas."""
    pass

# Generated at 2022-06-23 22:10:29.832210
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Just a unit test for AbstractField.__call__."""
    import pytest  # type: ignore

    with pytest.raises(UndefinedField):
        field = AbstractField()
        field()

    with pytest.raises(UnacceptableField):
        field = AbstractField()
        field('foo.bar.baz')

    with pytest.raises(UnsupportedField):
        field = AbstractField()
        field('unsupported_provider_or_method')

    field = AbstractField()
    assert isinstance(field('uuid'), str)
    assert isinstance(field('lorem.text'), str)
    assert isinstance(field('lorem.text', words=2), str)
    assert isinstance(field('code.isbn', is_with_hyphen=True), str)

# Generated at 2022-06-23 22:10:32.461557
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of class Schema."""
    schema = Schema({
        'test': 1,
    })
    assert schema.schema() == {'test': 1}

# Generated at 2022-06-23 22:10:33.950887
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'



# Generated at 2022-06-23 22:10:36.362961
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema(None)
    assert s is not None
    assert s.create(1)[0] is None

# Generated at 2022-06-23 22:10:40.323331
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema
    from mimesis.schema import SchemaType
    
    schema: SchemaType = Schema({
        'name': ':name'
    })

    assert (schema()['name'], str) == (':name', str)

# Generated at 2022-06-23 22:10:42.351635
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert isinstance(f, AbstractField)
    assert f.locale == 'en'
    assert f.seed == None
    f = AbstractField('ru')
    assert f.locale == 'ru'
    f = AbstractField(seed=0)
    assert f.seed == 0

# Generated at 2022-06-23 22:10:43.972787
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert field.__str__() == "AbstractField <en>"

# Generated at 2022-06-23 22:10:46.869318
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'
    f = Field(locale='ru')
    assert str(f) == 'AbstractField <ru>'
    f = Field(locale='ru', seed=5)
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:10:50.512154
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {
            "foo": "bar",
            "bar": "foo",
        }

    sch = Schema(schema=schema)

    assert sch is not None

# Generated at 2022-06-23 22:10:58.103835
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'a': lambda: 3, 'b': lambda: 2, 'c': lambda: 1}
    test_schema = Schema(schema)
    res = test_schema.create()
    assert res == [{'a': 3, 'b': 2, 'c': 1}]
    res = test_schema.create(2)
    assert res == [{'a': 3, 'b': 2, 'c': 1}, {'a': 3, 'b': 2, 'c': 1}]
    assert isinstance(test_schema, Schema)
    try:
        Schema({})
    except Exception as e:
        assert isinstance(e, UndefinedSchema)



# Generated at 2022-06-23 22:11:08.382438
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field, Schema
    import mimesis.providers.address

    class _SimpleSchema():
        name = Field()
        address = Field('address.house')

        def __call__(self):
            return {
                'name': self.name,
                'address': self.address,
            }

    s = Schema(_SimpleSchema)
    assert len(s.create(5)) == 5

    from mimesis import Text

    class _SimpleSchema():
        name = Field()

        def __call__(self):
            return {
                'name': self.name,
                'address': Text().word(),
            }

    s = Schema(_SimpleSchema)
    assert len(s.create(5)) == 5

    from mimesis import Datetime

# Generated at 2022-06-23 22:11:13.303498
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.enums import FieldName
    field_name = FieldName.AGE.value
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField('ru')) == 'AbstractField <ru>'
    assert str(AbstractField(field_name, 123)) == 'AbstractField <{}>'.format(field_name)

# Generated at 2022-06-23 22:11:14.712087
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {})
    assert schema is not None

# Generated at 2022-06-23 22:11:15.227020
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()

# Generated at 2022-06-23 22:11:22.430350
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method AbstractField.__call__."""
    from mimesis.providers.person import Person

    class CustomField(AbstractField):
        pass

    person = Person('ru')
    person.add_provider(person)

    field = CustomField('ru')
    field.add_provider(person)

    assert field.__call__('full_name') == 'Мария Михайлова'
    assert field.__call__('full_name', gender='female') == 'Любовь Иванова'
    assert field.__call__('full_name', gender='male') == 'Сергей Семёнов'


# Generated at 2022-06-23 22:11:25.388816
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    # Should return str
    a = AbstractField()
    b = str(a)
    assert isinstance(b, str)
    assert b == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:26.731560
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField('ru')
    result = field('cryptographic_random_url_safe', size=10)
    assert isinstance(result, str)

# Generated at 2022-06-23 22:11:29.105816
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema('not a callable schema')
    assert schema.schema is None



# Generated at 2022-06-23 22:11:30.710924
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    expected = 'AbstractField <en>'
    actual = str(AbstractField())
    assert expected == actual, (
        "# Methods __str__ in class AbstractField() returns value "
        "which isn't the same that {0}".format(expected)
    )

# Generated at 2022-06-23 22:11:32.348765
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:38.398171
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field

    def _get_person_data() -> dict:
        f = Field()
        return {
            'name': f('name'),
            'surname': f('surname'),
            'email': f('email'),
            'username': f('username'),
            'birthday': f('date_time'),
            'gender': f('gender'),
            'document': f('ssn'),
        }

    schema = Schema(_get_person_data)
    data = schema.create(10)
    assert isinstance(data, list)
    assert len(data) == 10
    assert isinstance(data[0], dict)

# Generated at 2022-06-23 22:11:48.993121
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__.

    It tests the following cases::

        - UndefinedField if name is None
        - UnsupportedField if provider is not supported
        - UnacceptableField if method name is not available
    """
    field = AbstractField()

    try:
        # name = None
        field(name=None)
    except UndefinedField as e:
        assert str(e) == 'Undefined field'

    try:
        # Unsupported
        field(name='not.supported.provider')
    except UnsupportedField as e:
        assert str(e) == 'Field (not.supported.provider) is not supported'


# Generated at 2022-06-23 22:11:50.896945
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    schema = AbstractField()
    assert str(schema) == 'AbstractField <en>'



# Generated at 2022-06-23 22:11:59.935428
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.builtins import Python

    # Create a field
    f = Field()

    # Create a list of names
    names = f.datetime()

    # Create a schema
    def s() -> JSON:
        return {
            'name': names,
            'age': f.age(),
            'salary': f.money.value(),
        }

    # Apply the schema to objects
    schema = Schema(s)

    # Create 20 records
    records = schema.create(20)
    assert len(records) == 20
    assert isinstance(records, list)
    assert isinstance(records[0], dict)

# Generated at 2022-06-23 22:12:09.356535
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.code import Code
    from mimesis.random import Random
    from mimesis.schema import AbstractField
    from mimesis.typing import JSON

    random = Random('ab_')
    provider = Code(random)
    field = AbstractField(seed=random.seed, providers=(provider, ))

    assert field(
        'token', key=lambda x: len(x) == 10)
    assert field(
        'token', key=lambda x: len(x) == 100)
    assert field(
        'code', key=lambda x: len(x) == 100)
    assert field(
        'code', key=lambda x: len(x) == 300)

    assert field('token')
    assert field('code')
    assert field('token')
    assert field('code')

   

# Generated at 2022-06-23 22:12:12.592226
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class Field."""
    field = Field()
    assert isinstance(field, AbstractField)
    assert field.locale == 'en'
    assert field.seed is None


# Generated at 2022-06-23 22:12:13.995027
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert isinstance(f, AbstractField)

# Generated at 2022-06-23 22:12:16.559881
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    abstract_field = Field(locale='en')

    expected = 'AbstractField <en>'
    result = str(abstract_field)
    assert result == expected

# Generated at 2022-06-23 22:12:19.363730
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Create an instance of the class AbstractField."""
    Field(locale='en')



# Generated at 2022-06-23 22:12:21.571061
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import AbstractField

    data = Schema(AbstractField)
    assert callable(data.create)

# Generated at 2022-06-23 22:12:23.304043
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda : {})
    assert schema.schema == {}



# Generated at 2022-06-23 22:12:26.841752
# Unit test for method create of class Schema
def test_Schema_create():
    _field = Field()
    _schema = Schema(lambda: _field.uuid4())

    # Create and check filled schemas
    for _ in range(1000):
        data = _schema.create(iterations=5)
        assert len(data) == 5

# Generated at 2022-06-23 22:12:32.784204
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    random_field = AbstractField()
    random_field('int', maximum=100, minimum=1)
    random_field('datetime.datetime', maximum='now', minimum='now')
    random_field(name='datetime.datetime', maximum='now', minimum='now')
    random_field('person.full_name')
    random_field('en.person.full_name')
    random_field('en.person.full_name', sex='male')

# Generated at 2022-06-23 22:12:41.567004
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema, Field

    field = Field()

    schema = {
        'name': field('name'),
        'surname': field('surname'),
        'password': field('password'),
        'username': field('username'),
        'email': field('email'),
        'address': {
            'city': field('city'),
            'country': field('country'),
            'region': field('region'),
        }
    }

    S = Schema(lambda: schema)

    iterations = 4

    data = S.create(iterations)

    assert len(data) == iterations



# Generated at 2022-06-23 22:12:48.525555
# Unit test for method create of class Schema

# Generated at 2022-06-23 22:12:49.181845
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-23 22:12:50.095249
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField(locale='ru')
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:12:52.620136
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis import Field

    assert callable(Field)  # it is callable



# Generated at 2022-06-23 22:12:54.670228
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(dict)
    assert schema.schema is dict

# Generated at 2022-06-23 22:12:57.008913
# Unit test for constructor of class AbstractField
def test_AbstractField():
    _ = AbstractField()
    assert isinstance(_, AbstractField)  # noqa WPS421



# Generated at 2022-06-23 22:12:58.980543
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField.__init__."""
    af = AbstractField()
    assert af._gen is not None

# Generated at 2022-06-23 22:13:01.116796
# Unit test for constructor of class Schema
def test_Schema():
    schema = {
        'name': 'Anna',
        'age': 12,
    }

    assert Schema(schema)

# Generated at 2022-06-23 22:13:02.750847
# Unit test for constructor of class Schema
def test_Schema():  # noqa: D102
    assert Schema is SchemaType

# Generated at 2022-06-23 22:13:07.624203
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        pass

    try:
        s = Schema(schema)
    except UndefinedSchema as e:
        pass
    else:
        assert s.schema == schema

    s = Schema(lambda x: x)
    assert s.schema(1) == 1

# Generated at 2022-06-23 22:13:17.214268
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.schema import Schema as S
    def _schema():
        s = S('en')
        return {
            'name': s.name(),
            'surname': s.surname(),
            'age': s.age(),
        }

    schema = Schema(_schema)
    assert schema.create(5) is not None

# Generated at 2022-06-23 22:13:22.883723
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field, Schema
    from tests.utils import check_iteration
    from mimesis.providers.person import Person


    def test_schema() -> dict:
        return {
            'name': Field().name(),
            'title': Field().title(),
            'job': Field().job_title(),
            'username': Field('ru', Person).username(),
        }


    s = Schema(test_schema)
    result = s.create(iterations=10)
    check_iteration(result, [test_schema])

# Generated at 2022-06-23 22:13:24.819688
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    value = field('password')
    assert len(value) > 0



# Generated at 2022-06-23 22:13:28.974546
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    f = AbstractField(locale='en', seed=1)
    assert f('name') == 'Dennis'
    assert f(key=lambda x: 'Mr. {}'.format(x),
             first_name='Alex', last_name='Green') == 'Mr. Alex Green'



# Generated at 2022-06-23 22:13:31.724824
# Unit test for method create of class Schema
def test_Schema_create():
    a = Schema({'name': 'Ivan'})
    b = Schema({'name': 'Петя'})
    items = a.create(10)
    items += b.create(10)

test_Schema_create()

# Generated at 2022-06-23 22:13:34.890180
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    locale = 'en'
    _ = AbstractField(locale)
    assert str(_) == 'AbstractField <{}>'.format(locale)

# Generated at 2022-06-23 22:13:40.297146
# Unit test for constructor of class Schema
def test_Schema():
    def my_func_schema() -> JSON:
        return {
            'name': 'John',
        }

    schema = Schema(schema=my_func_schema)
    assert schema.create() == [{'name': 'John'}]
    assert isinstance(schema, Schema)



# Generated at 2022-06-23 22:13:42.660679
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:48.009263
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    def schema():
        """Schema for testing."""
        return {
            'a': 1,
            'b': 2,
        }

    #: Create schema
    schema = Schema(schema)
    assert schema.create() == [{'a': 1, 'b': 2}]

# Generated at 2022-06-23 22:13:49.291674
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert isinstance(f, Field)

# Generated at 2022-06-23 22:13:56.428002
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():  # noqa: N802
    fi = Field()
    assert fi('full_name')
    assert fi('full_name',
              key=lambda x: x.split(' ')[0])
    assert fi('internet.domain_name',
              _level2_=True)
    assert isinstance(fi('internet.ipv6'), str)
    assert fi('person.full_name',
              gender='female')
    assert fi('business.credit_card_security_code')
    assert fi('business.credit_card_number')
    assert fi('person.age',
              _age=10)
    assert fi('person.age',
              _age=100)
    assert fi('person.age',
              _age=30)

# Generated at 2022-06-23 22:14:04.242550
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field(seed=1)
    assert field('username') == field('username')

    with pytest.raises(UndefinedField):
        field()

    with pytest.raises(UnsupportedField):
        field('not_exists_method')

    assert field('not_exists_method', default=None) is None

    assert field('not_exists_method', field('username')) == field('username')

    with pytest.raises(UnacceptableField):
        field('person.not_exists_method.other_method')

# Generated at 2022-06-23 22:14:12.960988
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create."""
    class SampleSchema:
        """Example of schema."""

        def __call__(self) -> JSON:
            """Overriding method."""
            field = Field()
            return {
                'name': field('token'),
                'age': field('age'),
                'weight': field('weight'),
                'height': field('height'),
                'address': {
                    'country': field('country'),
                    'city': field('city'),
                    'region': field('region'),
                },
            }

    schema = Schema(SampleSchema())
    assert schema.create(iterations=5)

# Generated at 2022-06-23 22:14:16.302464
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = AbstractField()
    #  Generate name
    assert not field.__call__('sex') == ''
    assert not field.__call__('address.country') == ''



# Generated at 2022-06-23 22:14:19.013981
# Unit test for constructor of class Schema
def test_Schema():
    # Create unit test for constructor of class Schema
    def test_schema_with_invalid_params():
        assert Schema('name')

    test_schema_with_invalid_params()

# Generated at 2022-06-23 22:14:21.127885
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test AbstractField's __str__ method."""
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:23.140474
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()

    assert f('is_snake_case') == True
    assert callable(f.__call__)



# Generated at 2022-06-23 22:14:24.079986
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:14:26.096501
# Unit test for constructor of class Schema
def test_Schema():
    # AssertionError
    s = Schema(1)
    assert s.schema == 1

# Generated at 2022-06-23 22:14:29.136356
# Unit test for method create of class Schema
def test_Schema_create():
    import mimesis.builtins.schema

    schema = Schema(mimesis.builtins.schema.Schema.person)
    for i in range(10):
        assert len(schema.create(iterations=i)) == i

# Generated at 2022-06-23 22:14:36.951013
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert field('name') == 'James'
    assert (isinstance(field('romanized', key=str.upper), str))
    assert field('byte', max_size=0).decode() == ''
    assert (isinstance(field('first_name'), str))
    assert field('method', key=str) == 'method'

    field = AbstractField()
    with pytest.raises(UndefinedField):
        field('method')

    with pytest.raises(UndefinedField):
        AbstractField()()

    with pytest.raises(UnsupportedField):
        field('not_supported')

    with pytest.raises(UnacceptableField):
        field('provider.name.method')
