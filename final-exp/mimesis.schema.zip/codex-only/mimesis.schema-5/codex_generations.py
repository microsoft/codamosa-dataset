

# Generated at 2022-06-23 22:04:52.782102
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField)

# Generated at 2022-06-23 22:04:55.860399
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField(seed = 'mimesis')
    assert isinstance(f, AbstractField)

    f = AbstractField(seed = 'mimesis')
    assert isinstance(f, AbstractField)

# Generated at 2022-06-23 22:04:57.599595
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    class C(AbstractField):
        pass

    assert str(C()) == 'C <en>'


# Generated at 2022-06-23 22:04:58.463572
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:06.624803
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Unsupported field
    f = Field()
    try:
        f()
    except UndefinedField:
        assert True
    else:
        assert False

    # Unsupported field
    try:
        f(name='unsupported_field')
    except UnsupportedField:
        assert True
    else:
        assert False

    # Unaccepted field (field name with dot)
    try:
        f(name='unsupported.provider.field')
    except UnacceptableField:
        assert True
    else:
        assert False

# Generated at 2022-06-23 22:05:09.769311
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method ``__call__`` of class AbstractField."""
    field = Field()
    assert 'First letter of the alphabet.' in field('letter')

    assert 'First letter of the alphabet.' in field('letter')

# Generated at 2022-06-23 22:05:12.116744
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field()
    assert Field('en')
    assert Field('ru')
    assert Field('en', seed=123456)

# Generated at 2022-06-23 22:05:13.808064
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:05:22.642516
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    from mimesis.builtins import Datetime

    field = Field(locale='en', providers=[Datetime])
    assert field.__call__('today') == field.today()
    assert field.__call__('today', format='%d %m %Y', as_str=True) == field.today(format='%d %m %Y', as_str=True)
    assert field.__call__('weekday') == field.weekday()
    assert field.__call__('weekday', week_start=0) == field.weekday(week_start=0)



# Generated at 2022-06-23 22:05:33.143208
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet

    class PersonSchema(Field):
        """A schema for Person data."""

        def __init__(self, address: Address, internet: Internet) -> None:
            super().__init__()
            self.address = address
            self.internet = internet

        def schema(self) -> JSON:
            """Return filled schema."""

# Generated at 2022-06-23 22:05:44.578113
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    gen = Generic('en')
    field = gen.field
    assert field('first_name') in gen.person._first_names

    field = gen.field
    assert field('first_name', gender='male') in gen.person._male_names

    field = gen.field
    assert field('first_name', gender='female') in gen.person._female_names

    field = gen.field
    assert field('full_name') in gen.person._first_names

    field = gen.field
    assert field('full_name', gender='male') in gen.person._male_names

    field = gen.field
    assert field('full_name', gender='female') in gen.person._female_names

    field = gen.field
    assert field('one_weekend_day') in ['Sunday', 'Saturday']


# Generated at 2022-06-23 22:05:46.395072
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None

# Generated at 2022-06-23 22:05:48.826757
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test str representation of a class."""
    f = Field(locale='ru')
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:05:51.473555
# Unit test for constructor of class Schema
def test_Schema():
    schema = {'key': 'value'}

    for _ in range(10):
        run = Schema(schema)
        assert run.create() == [schema]



# Generated at 2022-06-23 22:05:55.195437
# Unit test for method create of class Schema
def test_Schema_create():
    def my_schema():
        return dict(zeros=0, ones=1)

    sch = Schema(my_schema)
    assert sch.create(0) == []
    assert sch.create(1) == [{'zeros': 0, 'ones': 1}]



# Generated at 2022-06-23 22:05:56.351703
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert Field().__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:57.708542
# Unit test for constructor of class Schema
def test_Schema():
    from . import Person
    from mimesis.schema import Schema

    schema = Schema(Person)
    assert schema

# Generated at 2022-06-23 22:05:59.230159
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {})
    assert schema is not None, 'Must be defined schema'


# Generated at 2022-06-23 22:06:00.718350
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for class AbstractField."""
    field = AbstractField()
    assert field is not None



# Generated at 2022-06-23 22:06:11.486176
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field
    from mimesis.enums import Gender

    field = Field()

    def schema():
        return {
            'name': field.person.full_name(),
            'age': field.person.age(),
            'gender': field.person.gender(Gender.MALE),
        }

    response = Schema(schema).create(3)
    my_tuple_schema = [{
        'name': 'Ramiro Oliver',
        'age': 55,
        'gender': 'Male'
    }, {
        'name': 'Eddie Mckinney',
        'age': 43,
        'gender': 'Male'
    }, {
        'name': 'Eli Shaffer',
        'age': 21,
        'gender': 'Male'
    }]


# Generated at 2022-06-23 22:06:12.511470
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='en')
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:06:20.921400
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('ru')
    f = Field('ru')
    f.add_provider(p)

    assert isinstance(f('full_name', gender=Gender.MALE), str) is True
    assert f('full_name', gender=Gender.MALE) == p.full_name(gender=Gender.MALE)
    assert f('full_name', 'male') == p.full_name(gender='male')
    assert f('full_name', 'male') == p.full_name(gender=Gender.MALE)

# Generated at 2022-06-23 22:06:23.913186
# Unit test for constructor of class Schema
def test_Schema():
    # pylint: disable=missing-docstring
    class Foo:
        @classmethod
        def schema(cls):
            pass

    _ = Schema(Foo.schema)



# Generated at 2022-06-23 22:06:25.930630
# Unit test for method create of class Schema
def test_Schema_create():
    s = Schema({'str': 'str'})
    assert type(s.create(iterations=2)) is list

# Generated at 2022-06-23 22:06:31.090539
# Unit test for method create of class Schema
def test_Schema_create():
    def schema_factory() -> dict:
        """Return schema."""
        field = Field()
        return {
            'url': field('url'),
            'email': field('email'),
            'address': field('address')
        }

    schema = Schema(schema_factory)
    assert len(schema.create()) == 1
    assert len(schema.create(iterations=10)) == 10

# Generated at 2022-06-23 22:06:33.677745
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema class.

    Unit test for constructor of class Schema.
    """
    def schem() -> SchemaType:
        return {'foo': 'bar'}

    Schema(schem)

# Generated at 2022-06-23 22:06:35.642931
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.tests.schema import TEST_SCHEMA
    assert Schema(TEST_SCHEMA)



# Generated at 2022-06-23 22:06:36.836778
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert isinstance(field.__str__(), str)

# Generated at 2022-06-23 22:06:42.742448
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema
    from mimesis.schema import Field

    @Field.to_schema
    class _Schema:
        def __init__(self, field: Field) -> None:
            self.field = field

        def get_data(self) -> JSON:
            return {
                'name': self.field('name'),
                'surname': self.field('surname'),
            }

    schema = _Schema(Field())
    assert isinstance(schema, Schema)

    data = schema.create()
    assert len(data) == 1

# Generated at 2022-06-23 22:06:49.311576
# Unit test for constructor of class Schema
def test_Schema():
    # test for the constructor of class Schema
    # the **schema** parameter of the constructor **MUST**
    # be a callable object
    def _test_not_callable():
        Schema(1)
    def _test_not_callable_2():
        Schema(Schema)
    _test_not_callable()
    _test_not_callable_2()

# Generated at 2022-06-23 22:06:53.077593
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'id': 0, 'title': 'string'}

    def m():
        return schema

    s = Schema(m)
    assert isinstance(s, Schema)
    assert isinstance(s.create(2), list)
    assert len(s.create(2)) == 2



# Generated at 2022-06-23 22:07:03.721234
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert field('random.int') is not None
    assert field('user_agent.desktop_os') is not None
    assert field('rules.field') is not None
    assert field('person.gender') is not None

    # Explicitly use `random_item`.
    assert field('random.random_item') is not None

    # Explicitly use `random_item` for `random` provider.
    assert field('random.random_item') is not None

    # Through `random` goes to `random_item` method.
    assert field('random_item') is not None

    # Choice is not `random` method and it's own provider.
    assert field('choice') is not None

    # Explicitly use `choice` for `random` provider.
    assert field('random.choice') is not None

    # Name

# Generated at 2022-06-23 22:07:05.348594
# Unit test for constructor of class AbstractField
def test_AbstractField():
    class TestField(AbstractField):
        pass

    field = TestField()
    assert field is not None

# Generated at 2022-06-23 22:07:10.974628
# Unit test for method create of class Schema
def test_Schema_create():
    import json

    schema = {
        'id': 'uuid4',
        'name': 'full_name',
        'email': 'email',
    }

    def _():
        return schema

    _ = Schema(_).create()

    assert isinstance(_, list) is True
    assert isinstance(json.dumps(_), str) is True

# Generated at 2022-06-23 22:07:21.188353
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.person import Person
    from mimesis.providers.date_time import DateTime
    from mimesis.providers.person import Gender

    field = AbstractField()
    # provider.method
    assert isinstance(field('person.full_name'), str)
    assert isinstance(
        field('datetime.datetime', start='1970-01-01 00:00:01',
              end='2019-01-01 00:00:00'),
        str,
    )

    field = AbstractField(providers=(Person, DateTime))
    # method
    assert isinstance(field('full_name'), str)

# Generated at 2022-06-23 22:07:22.888199
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:25.960972
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    # Test method __str__ of class AbstractField
    # with default parameters and return value

    # Return: 'AbstractField <en>'

    field = AbstractField()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:07:27.460853
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    field = AbstractField()
    assert field


# Generated at 2022-06-23 22:07:30.164730
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    s = Schema(lambda: {'test': '123'})
    assert isinstance(s, Schema)
    assert s.create() == [{'test': '123'}]

# Generated at 2022-06-23 22:07:31.153041
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {})


# Generated at 2022-06-23 22:07:32.739005
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of AbstractField class."""
    f = Field()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:34.613965
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema('hello')
    assert schema.schema == 'hello'

    try:
        Schema(1)
        assert False
    except UndefinedSchema:
        assert True



# Generated at 2022-06-23 22:07:36.679031
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Ensure AbstractField.__str__ return correct str."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:46.335665
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method AbstractField.__call__."""
    field = Field()

    # test for exception UndefinedField
    assert field() is None

    # test for exception UnsupportedField
    assert field(name='baz') is None

    # test for exception UndefinedField when name of method is empty
    assert field(name='', foo='bar') is None

    # test for exception UndefinedField when name of method is too short
    assert field(name='.') is None

    # test for exception UndefinedField when name of method is too long
    assert field(name='fizz.buzz.bizz') is None

    # test for exception UnacceptableField when name of method is correct
    # but not supported
    assert field(name='foo.bar.baz') is None

    # test for exception UndefinedField when name of method is correct
   

# Generated at 2022-06-23 22:07:51.676935
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.enums import Gender
    assert str(Generic()) == 'Generic <en>'
    assert str(Generic(locale='ru')) == 'Generic <ru>'
    assert str(Generic(locale='en').personal.Gender(gender=Gender.NEUTRAL)) == 'Gender <en>'
    assert str(Generic(locale='en').personal.Gender(gender=Gender.MALE)) == 'Gender <en>'
    assert str(Generic(locale='en').personal.Gender(gender=Gender.FEMALE)) == 'Gender <en>'

# Generated at 2022-06-23 22:07:53.968796
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Create Field instance."""
    field = Field()

    assert str(field)  == 'Field <en>'


# Generated at 2022-06-23 22:07:56.754977
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert 'AbstractField <en>' == str(field)

    field.locale = 'ru'
    assert 'AbstractField <ru>' == str(field)

# Generated at 2022-06-23 22:08:00.338063
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema({'foo': 'bar', 'baz': 'spam'})
    assert isinstance(schema, Schema)
    assert isinstance(schema.create(), list)

# Generated at 2022-06-23 22:08:05.299932
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.weather import Weather

    def schema() -> dict:
        """Test schema."""
        return {
            'region': Field('en', providers=(Weather,)),
        }

    schema = Schema(schema)
    data = schema.create(10)
    assert len(data) == 10
    assert isinstance(data, list)

# Generated at 2022-06-23 22:08:12.083898
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema
    from mimesis.data import PERSON

    schema = Schema(lambda: {
        'name': PERSON.full_name(),
        'age': PERSON.age(),
        'gender': PERSON.gender()
    })
    filled_schema = schema.create()[0]

    assert len(filled_schema) == 3
    assert 'name' in filled_schema
    assert filled_schema['name']



# Generated at 2022-06-23 22:08:15.552048
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'
    f.locale = 'ru'
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:08:20.291090
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    def schema():
        """Create a schema."""
        return {
            'first_name': '{{ person.name() }}',
            'surname': '{{ person.surname() }}'
        }

    data = Schema(schema=schema).create()

    assert len(data) == 1
    assert isinstance(data[0], dict)

# Generated at 2022-06-23 22:08:21.438261
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:23.592785
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField(locale='en')
    s = 'AbstractField <en>'
    result = str(field)
    assert result == s

# Generated at 2022-06-23 22:08:26.841149
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.enums import Gender
    from mimesis.providers.personal import Personal

    p = Personal('ru')  # type: ignore
    assert p.full_name(gender=Gender.MALE) == 'Федор Данилов'

# Generated at 2022-06-23 22:08:30.970389
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema."""
    foo = Field()

    def bar():
        """Some schema."""
        return {
            'string': foo('string')
        }

    schema = Schema(bar)
    result = schema.create(4)
    print(result)
    assert isinstance(result, list)

# Generated at 2022-06-23 22:08:32.109478
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert(str(Generic.create_field('en')) == 'AbstractField <en>')

# Generated at 2022-06-23 22:08:33.990369
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of AbstractField"""
    res = AbstractField()
    assert isinstance(res, str)
    assert res == 'AbstractField <en>'


# Generated at 2022-06-23 22:08:35.169908
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField constructor with no arguments."""
    assert hasattr(AbstractField(), '_gen')



# Generated at 2022-06-23 22:08:41.441927
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers import Person
    f = Field()
    p = Person(f.locale, f.seed)
    assert isinstance(p, Person)
    assert isinstance(Schema(f.random.boolean), Schema)
    assert isinstance(Schema(f.random.hexadecimal), Schema)
    assert isinstance(f, AbstractField)
    assert isinstance(f, Field)
    assert isinstance(p.full_name(), str)
    assert callable(f.random.hexadecimal)



# Generated at 2022-06-23 22:08:43.243407
# Unit test for constructor of class Schema
def test_Schema():
    try:
        Schema('not callable')
    except UndefinedSchema:
        pass

# Generated at 2022-06-23 22:08:50.512861
# Unit test for constructor of class Schema
def test_Schema():
    class SchemaTest:  # noqa: N801
        def __init__(self, schema):  # noqa: N807
            self.schema = schema
            self.result = [schema() for _ in range(10)]

    __schema = {
        'name': 'Alex',
        'last_name': 'Smith',
        'age': 23,
    }

    s = SchemaTest(Schema(lambda: __schema))
    assert s.result == [__schema for _ in range(10)]

# Generated at 2022-06-23 22:08:52.524920
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    result = field.__str__()
    assert result == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:54.308781
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:54.932966
# Unit test for constructor of class Schema
def test_Schema():
    assert True

# Generated at 2022-06-23 22:08:55.593546
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()

# Generated at 2022-06-23 22:09:03.110032
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    # First try
    try:
        field()  # UndefinedField exception
    except UndefinedField:
        pass
    else:
        raise AssertionError

    # Second try
    value = field('word')
    assert value
    assert isinstance(value, str)

    # Third try
    try:
        field('undefined')  # UnsupportedField exception
    except UnsupportedField:
        pass
    else:
        raise AssertionError

    # Fourth try
    try:
        field('code.code')  # UnacceptableField exception
    except UnacceptableField:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-23 22:09:04.696199
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.schema import AbstractField

    assert 'AbstractField' in str(AbstractField())


# Generated at 2022-06-23 22:09:06.426426
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    provider = AbstractField()
    assert str(provider) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:14.340320
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    gen = AbstractField('en')

    assert gen.__call__('uuid4') is not None
    assert gen.__call__('uuid4') != gen.__call__('uuid4')
    assert gen.__call__('user_agent.android') is not None
    assert gen.__call__('user_agent.android') != gen.__call__('user_agent.android')

    # Fix: https://github.com/lk-geimfari/mimesis/issues/619
    assert gen.__call__('choices') is not None
    assert gen.__call__('choices') != gen.__call__('choices')



# Generated at 2022-06-23 22:09:20.230332
# Unit test for method create of class Schema
def test_Schema_create():
    class Person:
        def __init__(self, name: str, age: int) -> None:
            self.name = name
            self.age = age

        def __str__(self) -> str:
            return f'{self.name} - {self.age}'

    def person_schema() -> Person:
        return Person(
            name=Field('full_name'),
            age=Field('age'),
        )

    schema = Schema(person_schema)
    assert len(schema.create()) == 1
    assert len(schema.create(3)) == 3


test_Schema_create()

# Generated at 2022-06-23 22:09:26.730710
# Unit test for constructor of class Schema
def test_Schema():
    class User:
        def __init__(self, username: str, password: str) -> None:
            self.username = username
            self.password = password

    schema = Schema(
        lambda: User(
            username=Field()('username'),
            password=Field()('password'),
        )
    )

    data = schema.create(10)
    assert len(data) == 10

# Generated at 2022-06-23 22:09:30.718497
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Check AbstractField constructor.

    Also it tests that AbstractField.__call__() not raises an
    exception when ``name`` is ``None``.
    """
    AbstractField(locale='en')
    AbstractField(locale='ru')



# Generated at 2022-06-23 22:09:39.767995
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField call.

    Test the call method of the AbstractField class.
    """
    field = Field()

    func = field('name')  # type: ignore
    result = func()
    assert isinstance(result, str)

    func = field('address')  # type: ignore
    result = func()
    assert isinstance(result, str)

    func = field('uuid4')  # type: ignore
    result = func()
    assert isinstance(result, str)

    func = field('uuid4')  # type: ignore
    result = func()
    assert isinstance(result, str)

    func = field('currency_code')  # type: ignore
    result = func()
    assert isinstance(result, str)

    func = field('timestamp')  # type: ignore
    result = func()

# Generated at 2022-06-23 22:09:41.168470
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    af = AbstractField()
    assert 'AbstractField' in str(af)

# Generated at 2022-06-23 22:09:50.561304
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Positive tests
    # Simple example
    field = AbstractField()

    result = field('name', gender='male')
    assert result in {'John', 'Tom', 'Mark', 'Mike', 'James', 'William',
                      'Matthew', 'Joseph'}

    # Positive tests
    # With key function
    field = AbstractField()

    result = field('name', key=lambda x: x.upper(), gender='male')
    assert result in {'JOHN', 'TOM', 'MARK', 'MIKE', 'JAMES', 'WILLIAM',
                      'MATTHEW', 'JOSEPH'}

    # Positive tests
    # Without 'key' field
    field = AbstractField()
    result = field('name', gender='male')

# Generated at 2022-06-23 22:09:54.134702
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {"name": "John", "age": 24}
    gen = Field()
    pschema = gen.create_schema(schema)
    s = Schema(pschema)
    assert isinstance(s.create(iterations=1), list)

# Generated at 2022-06-23 22:09:57.142800
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Tests Abstract field.

    The test class will be initialized by method ``__call__``
    which allows to call the method of any data provider.
    """
    field = AbstractField()
    assert field('uuid') is not None

# Generated at 2022-06-23 22:10:01.653462
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'id': '',
        'name': '',
        'parent': '',
        'children': []
    }

    def full_schema():
        return {
            'id': Field('uuid'),
            'name': Field('word'),
            'parent': '',
            'children': []
        }

    s = Schema(full_schema)
    assert len(s.create()) == 1
    assert len(s.create(5)) == 5

# Generated at 2022-06-23 22:10:04.488202
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    instance = AbstractField()
    assert str(instance) == 'AbstractField <en>'
    instance = AbstractField(locale='ru')
    assert str(instance) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:10:06.423392
# Unit test for constructor of class AbstractField
def test_AbstractField():
    obj = AbstractField()
    assert obj.locale == 'en'
    assert obj.seed is None
    assert obj._gen



# Generated at 2022-06-23 22:10:08.668969
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'
    assert str(Field(locale='ru')) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:10:10.721033
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert isinstance(f('num', maximum=1000), int)

    assert f('num', maximum=1000, key=lambda x: str(x)) == '999'

# Generated at 2022-06-23 22:10:11.907553
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:16.043061
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test method to init field."""
    field = AbstractField(
        locale='en',
        seed=None,
        providers=None,
    )
    assert field.locale == 'en'
    assert field.seed is None
    assert isinstance(field._gen, Generic)
    assert not field._table


# Generated at 2022-06-23 22:10:20.719816
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    address = Address()
    person = Person()

    data = ['Bob', 'Smith', 'bob.smith@example.com']

    def _schema() -> dict:
        return {
            'first': data[0],
            'last': data[1],
            'email': data[2],
            'phone': person._phone(),
            'city': address._city(),
            'state': address._state(),
            'country': address._country(),
            'address': address.address(),
            'street': address.street_name(),
            'zip_code': address.zip_code(),
        }

    users = Schema(_schema).create(iterations=5)
    assert users[0] == _schema()

# Generated at 2022-06-23 22:10:22.332313
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test that `Field` can be called."""
    field = Field()
    assert field('email')
    assert field('person.full_name')

# Generated at 2022-06-23 22:10:24.894992
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field() is None
    field = Field()
    assert field('code.numeric')



# Generated at 2022-06-23 22:10:26.220081
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    pass

# Generated at 2022-06-23 22:10:28.182472
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """AbstractField.__call__ should work properly."""
    field = AbstractField()
    assert callable(field)

# Generated at 2022-06-23 22:10:35.306027
# Unit test for constructor of class Schema
def test_Schema():
    """Testing Schema constructor."""
    from mimesis.schema import SchemaType

    def test_schema(field: AbstractField) -> SchemaType:
        """Funkcja dekorująca schemat.

        :param field: Instancja fielda.
        :return: Schemat.
        """
        return {
            'name': field('full_name'),
            'address': field('address.address'),
        }

    with Schema(test_schema) as schema:
        assert len(schema.create()) == 0



# Generated at 2022-06-23 22:10:40.072108
# Unit test for method create of class Schema
def test_Schema_create():
    schema_1 = lambda: {'first_name': 'John'}
    schema_2 = lambda: {'first_name': 'John', 'last_name': 'Doe'}

    assert isinstance(Schema(schema_1).create(), list)
    assert isinstance(Schema(schema_2).create(3), list)

# Generated at 2022-06-23 22:10:41.984794
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field(locale='en')
    assert f.__str__() == "AbstractField <en>"

# Generated at 2022-06-23 22:10:43.603529
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema(SchemaType).schema is not None



# Generated at 2022-06-23 22:10:48.974898
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema.__doc__ is not None

    def test_schema():
        pass

    def test_schema_not_callable():
        return 1

    assert Schema(test_schema).schema == test_schema

    try:
        Schema(test_schema_not_callable)
    except UndefinedSchema:
        pass
    else:
        raise AssertionError(
            'UndefinedSchema is not raised.')

# Generated at 2022-06-23 22:10:57.929336
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.providers import Person
    field = AbstractField()

    assert field._gen.locale == 'en'
    assert field._gen.seed is None

    data = field('full_name')
    assert isinstance(data, str)

    field = AbstractField(locale='ru')
    assert field._gen.locale == 'ru'
    assert field._gen.seed is None

    field = AbstractField(seed=None)
    assert field._gen.locale == 'en'
    assert field._gen.seed is not None

    field = AbstractField(providers=(Person,))
    assert field._gen.locale == 'en'
    assert len(field._gen.providers) == 2

    def return_int(data: str) -> int:
        return int(data)


# Generated at 2022-06-23 22:11:08.295284
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.geography import Geography
    from mimesis.providers.cryptographic import Cryptographic

    class TestField(AbstractField):
        """Test class for AbstractField."""

        def __init__(self, locale='en', seed=None, geog=None, crypt=None):
            """Initialize field."""
            super().__init__(locale=locale, seed=seed)

            if geog is None:
                geog = Geography(seed)
            self._gen.add_provider(geog)

            if crypt is None:
                crypt = Cryptographic(seed)
            self._gen.add_provider(crypt)

    f = TestField()
    assert f.geography.postal_code() == f('postal_code')

# Generated at 2022-06-23 22:11:09.490193
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:10.946109
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check the string representation of the class."""
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:12.592523
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert isinstance(f, Field)


# Generated at 2022-06-23 22:11:14.517208
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == field.__class__.__name__ + ' <en>'



# Generated at 2022-06-23 22:11:17.458674
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__."""
    schema = AbstractField()
    assert schema('cryptographic.key') is not None
    assert schema('token', digits=4) is not None
    assert schema('token', key=lambda x: x.upper()) is not None

# Generated at 2022-06-23 22:11:22.414780
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of class Schema."""
    # pylint: disable=invalid-name
    from mimesis.schema import Schema

    def schema() -> dict:
        """Return shemas."""
        return {'age': 1}

    assert isinstance(Schema(schema), Schema)


# Unit tests for method __call__ of class AbstractField

# Generated at 2022-06-23 22:11:24.376831
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(SchemaType({"x": 1})).create()) == 1

# Generated at 2022-06-23 22:11:28.066722
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.providers.internet import Internet  # noqa

    field = Field()
    assert isinstance(field._gen, Generic)
    assert isinstance(field._table, dict)

    field = Field(providers=[Internet])
    assert hasattr(field._gen, 'internet')

# Generated at 2022-06-23 22:11:37.398266
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import Address, Person

    def test_1():
        """."""
        person = Person('ru', seed=12345)
        address = Address('ru')

        field = AbstractField()
        field._gen.add_providers(person, address)
        assert (
            field('full_name', gender='female', title=True) ==
            'Лариса Семеновна Григорьева'
        )
        assert field('street_name') == 'Хотьковский проезд'

# Generated at 2022-06-23 22:11:46.647234
# Unit test for method create of class Schema
def test_Schema_create():
    """Test create method."""
    if __debug__:
        from mimesis.enums import Gender
        from mimesis.providers.person import Person

        def schema() -> JSON:
            """Return the filled schema."""
            person = Person('en')
            return {
                'name': person.full_name(gender=Gender.MALE),
                'email': person.email(),
            }

        expected_schema = {
            'name': 'Mr. Paul Zita',
            'email': 'paul.zita@hotmail.com',
        }
        ds = Schema(schema)
        data = ds.create(1)
        assert data[0] == expected_schema

# Generated at 2022-06-23 22:11:47.759166
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:53.239963
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField.

    :return: None
    """
    f = Field()
    assert all([f('test_method') is not None,
                f('test_method', key=lambda x: x.upper()) is not None,
                f('test_method', key=lambda x: x.upper()) == f('test_method').upper()])



# Generated at 2022-06-23 22:12:00.617285
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Create an instance of Field
    field = Field()

    # Check method without name
    try:
        field()
    except UndefinedField:
        assert True
    else:
        assert False

    # Check method with unsupported field
    try:
        field('unsupported_field')
    except UnsupportedField:
        assert True
    else:
        assert False

    # Check method with tail provider
    try:
        field('test.test')
    except UnacceptableField:
        assert True
    else:
        assert False

    # Check method by name
    assert field('password')
    assert field('uuid4') is not None



# Generated at 2022-06-23 22:12:01.756010
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:12:09.674764
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for Schema.create method."""
    def test() -> JSON:
        """This is a test."""
        return {
            'name': Field('en').name(),
            'age': Field('en').age(),
            'gender': Field('en').sex(),
            'id': Field('en').uuid4(),
        }

    schema = Schema(test)
    created_schema = schema.create()
    assert isinstance(created_schema, list)
    assert len(created_schema) == 1

# Generated at 2022-06-23 22:12:15.279932
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test call of AbstractField.

    :raises UnacceptableField: if tail string is not valid
    :raises UnsupportedField: if field not supported
    """
    cls = AbstractField()
    cls('foo')
    cls('foo', key=lambda x: x)
    cls.seed = None
    cls('foo.bar')
    cls('foo.bar.baz')

# Generated at 2022-06-23 22:12:18.077716
# Unit test for constructor of class Schema
def test_Schema():
    def user_schema():
        return {'name': 'Ivan'}

    assert isinstance(Schema(user_schema), Schema)
    assert isinstance(Schema(user_schema).schema, type(user_schema))

# Generated at 2022-06-23 22:12:22.081544
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('human.name') is not None
    assert field(name='human.name') is not None
    assert field('datetime.datetime.now') is not None
    assert field(name='datetime.datetime.now') is not None
    assert field('foo.bar') is None
    assert field(name='foo.bar') is None



# Generated at 2022-06-23 22:12:23.441187
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert(isinstance(Field(), AbstractField))



# Generated at 2022-06-23 22:12:26.426912
# Unit test for constructor of class Schema
def test_Schema():
    data = {
        'user': 'string',
    }

    schema = Schema(data)
    assert schema.create() == [data]

# Generated at 2022-06-23 22:12:28.705613
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method ``__str__`` of class AbstractField."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:31.456502
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

    field = Field(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:12:34.674425
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema():
        return {'test': 'schema'}

    s = Schema(test_schema)
    assert s.create() == [{'test': 'schema'}]



# Generated at 2022-06-23 22:12:44.107374
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method AbstractField.__call__."""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    field = Field()
    assert field.__call__('text') is not None
    assert field.__call__('address.address') == field.__call__('address')
    assert field.__call__('address', level=0) is not None

    field._gen.add_provider(RussiaSpecProvider)
    assert field.__call__('rus.fio', gender=Gender.FEMALE) is not None

    field.__call__('rus.fio', gender=Gender.MALE) is not None

# Generated at 2022-06-23 22:12:51.329137
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema, Field
    from mimesis.enums import Gender

    men = Field('gender', gender=Gender.MALE)
    lion = Field('person.name', gender=Gender.MALE)
    user = Schema(lambda: {
        'name': lion(),
        'sex': men(),
    })

    # Create 2 men
    persons = user.create(2)
    assert len(persons) == 2

    # Create 1 person
    person = user.create(1)[0]
    assert person['sex'] == 'Male'

# Generated at 2022-06-23 22:12:53.369076
# Unit test for constructor of class Schema
def test_Schema():
    """Check Schema constructor."""
    schema = Schema(None)
    assert schema.schema is None

# Generated at 2022-06-23 22:12:59.518777
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()

    assert field
    assert hasattr(field, 'locale')
    assert hasattr(field, 'seed')
    assert hasattr(field, '_gen')
    assert hasattr(field, '_table')

    field = Field('ru')

    assert field.locale == 'ru'



# Generated at 2022-06-23 22:13:02.008877
# Unit test for constructor of class AbstractField
def test_AbstractField():
    obj = AbstractField()
    assert 'AbstractField' == obj.__class__.__name__
    assert obj.locale == 'en'
    assert obj.seed is None


# Generated at 2022-06-23 22:13:11.407959
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert Field()('md5')
    assert Field()('md5', length=3)
    assert Field()('ssn', code='ru')
    assert Field()('ssn', code='ru', dash=True)
    assert Field()('tech.mac_address')
    assert Field()('tech.mac_address', length=6, separator='-')
    assert Field()('tech.mac_address', length=3, separator=':')
    assert Field()('tech.mac_address', length=10)
    assert Field()('tech.mac_address', length=10, separator='::')
    assert Field()('tech.mac_address', length=10, separator=True)
    assert Field()('uuid')
    assert Field()('uuid', code='uuid1')

# Generated at 2022-06-23 22:13:15.270017
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema class."""
    def schema():
        """Example schema."""
        return {'foo': 'bar'}

    obj = Schema(schema)
    assert obj.schema() == {'foo': 'bar'}
    assert obj.create() == [{'foo': 'bar'}]



# Generated at 2022-06-23 22:13:17.849912
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for the method AbstractField.__str__."""
    field = AbstractField()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:19.811276
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        AbstractField(locale='en')
    except:
        raise AssertionError('AbstractField not initialized')


# Generated at 2022-06-23 22:13:21.607711
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    af = AbstractField()
    assert af.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:25.051373
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit-test for method create of class Schema."""
    def schema():
        """Create test-schema."""
        return {
            'name': 'John',
            'surname': 'Doe',
        }

    s = Schema(schema)
    assert len(s.create()) == 1
    assert len(s.create(5)) == 5

# Generated at 2022-06-23 22:13:27.834274
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for AbstractField.__call__."""
    f = AbstractField()
    assert f('password') == f('password')
    assert f('password.for_humans') == f('password.for_humans')

# Generated at 2022-06-23 22:13:31.906307
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    class User(Schema):
        def __init__(self):
            def create_user():
                return {
                    'name': Person('en').full_name(gender=Gender.FEMALE),
                    'password': Person().password(),
                }

            super().__init__(schema=create_user)

    users = User().create(iterations=5)

    assert len(users) == 5

# Generated at 2022-06-23 22:13:33.268259
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    a = Field()
    assert callable(a)

    data = a('uuid')
    assert isinstance(data, str)

# Generated at 2022-06-23 22:13:39.558807
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import Person
    _f = Field(locale='ru')
    p = Person(locale='ru')
    assert _f('full_name') == p.full_name()
    assert _f('full_name', gender='male') == p.full_name(gender='male')

# Generated at 2022-06-23 22:13:45.039700
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person

    gen = Generic()
    gen.add_providers(Person, Internet)
    field = AbstractField(providers=gen.providers)
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:46.849229
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema(None)
    print(s.create())

# Generated at 2022-06-23 22:13:47.832815
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema



# Generated at 2022-06-23 22:13:51.989201
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> SchemaType:
        return {
            'foo': 'bar',
            'baz': 'blabla',
        }

    # test with callable object
    s = Schema(schema)
    assert len(s.create()) == 1

    # test with non callable object
    with pytest.raises(UndefinedSchema):
        Schema('This is a string')


# Generated at 2022-06-23 22:13:54.510968
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:13:55.999494
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert type(field) is AbstractField

# Generated at 2022-06-23 22:13:59.420440
# Unit test for constructor of class Schema
def test_Schema():
    sch = {'foo': 'bar'}

    try:
        s = Schema(sch)
    except UndefinedSchema:
        assert True
        return

    assert s.create() == [sch]

# Generated at 2022-06-23 22:14:09.410885
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema.base import Schema
    from mimesis.enums import Gender

    # Full data

# Generated at 2022-06-23 22:14:19.831264
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.enums import Gender

    # Assert that it raises a value exception when called wrong
    field = AbstractField()
    try:
        field()
    except UndefinedField:
        assert True  # Pass
    else:
        assert False  # Fail

    # Assert that it raises a value exception when called wrong
    try:
        field('__str__')
    except UnsupportedField:
        assert True  # Pass
    else:
        assert False  # Fail

    # Assert that it raises a value exception when called wrong
    def wrong_callable(gender: str) -> str:
        if gender == 'male':
            return 'Мужчина'

        return 'Женщина'


# Generated at 2022-06-23 22:14:20.907084
# Unit test for method create of class Schema
def test_Schema_create():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 22:14:28.610387
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test function to check the creation of filled schemas."""
    from mimesis import Person
    from mimesis.schema import Schema as _Schema
    from mimesis.typing import SchemaType as _SchemaType

    def schema() -> JSON:
        """Create a schema."""
        person = Person('en')
        return {
            'name': person.full_name(),
            'email': person.email(),
            'age': person.age(),
            'sex': person.sex(),
        }

    schema_ = _Schema(schema)
    assert isinstance(schema_.create(1), list)

# Generated at 2022-06-23 22:14:29.975698
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField('en')
    assert isinstance(f, AbstractField)

# Generated at 2022-06-23 22:14:35.400674
# Unit test for method create of class Schema
def test_Schema_create():
    # Define schema
    def schema() -> dict:
        """An example of schema."""
        return {
            'name': '[person:name]',
            'age': '[meta:age]',
        }

    # Create instance of class Schema
    schema = Schema(schema)
    # Set iterations
    iterations = 3

    assert isinstance(schema.create(iterations), list) is True
    assert len(schema.create(iterations)) == iterations



# Generated at 2022-06-23 22:14:41.656754
# Unit test for constructor of class Schema
def test_Schema():
    """Test field for example."""
    def test_schema():
        """Test schema."""
        return {
            'name': 'Kevin',
            'surname': 'Malone',
        }
    field = Schema(test_schema)
    assert field.create(iterations=5) == [
        {'name': 'Kevin', 'surname': 'Malone'},
        {'name': 'Kevin', 'surname': 'Malone'},
        {'name': 'Kevin', 'surname': 'Malone'},
        {'name': 'Kevin', 'surname': 'Malone'},
        {'name': 'Kevin', 'surname': 'Malone'},
    ]

# Generated at 2022-06-23 22:14:43.162933
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test ``__str__`` of AbstractField."""
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:45.037902
# Unit test for constructor of class Schema
def test_Schema():
    try:
        Schema('foo')
    except Exception:
        pass

# Generated at 2022-06-23 22:14:55.503370
# Unit test for method create of class Schema
def test_Schema_create():
    # Set value for iterations
    iterations = 10

    # We want to test a function
    f = Schema(lambda: {'a': 'b'})

    # The result of this function must be a list filled
    # with dictionaries which has only one key equal to 'a'
    # and value equal to 'b'
    result = f.create(iterations)

    # The filled list must be equal to the number iterations
    assert len(result) == iterations

    # Each element of list must be a dictionary
    assert all(isinstance(i, dict) for i in result)

    # Each dictionary must contain only one key 'a' and
    # value 'b'
    assert all(i == {'a': 'b'} for i in result)