

# Generated at 2022-06-23 22:04:59.363056
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    def my_schema() -> JSON:
        return {
            'first_name': Field()('first_name', gender=Gender.MALE),
            'last_name': Field()('last_name', gender=Gender.MALE),
            'full_name': Field()('full_name', gender=Gender.MALE),
            'full_address': Field()('address'),
            'email': Field()('email'),
        }

    person_data = Schema(my_schema).create(5)
    person = Person('en')

    for i in person_data:
        assert i['first_name'] == person.first_name(gender=Gender.MALE)
        assert i['last_name'] == person.last_name

# Generated at 2022-06-23 22:05:03.735828
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {'a': 1, 'b': 'string'}

    schema_ = Schema(schema=schema)
    assert schema_.create(iterations=1) == [{'a': 1, 'b': 'string'}]

# Generated at 2022-06-23 22:05:04.798355
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(dict)
    assert schema.schema == dict
    assert schema.create() == [{}]

# Generated at 2022-06-23 22:05:13.898906
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    locale = 'en'
    provider = 'geo'
    name = 'coordinate.latitude'
    key = lambda x: str(x)

    field = AbstractField(locale)

    assert 'mimesis.generic.Generic' in repr(field._gen)
    assert field._gen.locale == locale
    assert field._gen.seed is None

    result = field(name, key=key)
    assert isinstance(result, str)

    result = field('geo.provincia')
    assert isinstance(result, str)

    result = field(provider)
    assert result is not None

# Generated at 2022-06-23 22:05:18.560816
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field

    field = Field()

    @field.schema
    def my_fake_schema():
        return {
            'name': field('person.full_name'),
            'email': field('internet.email'),
            'password': field('person.password'),
        }

    assert isinstance(my_fake_schema.create(2), list)

# Generated at 2022-06-23 22:05:22.280445
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = Field(seed=1)
    expected = '<AbstractField <en>>'
    result = str(field)
    assert result == expected, 'Invalid response.'

# Generated at 2022-06-23 22:05:32.832457
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for create method."""
    from mimesis import Person
    from mimesis.schema import Field

    p = Person('ru')
    f = Field('ru')

    schema = {
        'full_name': f('full_name'),
        'username': f('username'),
        'phone_number': f('phone_number'),
        'email': f('email'),
        'password': f('password'),
    }

    s = Schema(schema)
    result = s.create(5)


# Generated at 2022-06-23 22:05:34.922410
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert Field(locale='ru').__call__(name='person.full_name').split()[0]

# Generated at 2022-06-23 22:05:35.598744
# Unit test for constructor of class Schema
def test_Schema():
    pass

# Generated at 2022-06-23 22:05:45.308552
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of class Schema."""
    _Field = AbstractField()

    def user_schema() -> dict:
        """Return user schema."""
        return {
            'name': _Field('person.full_name'),
            'email': _Field('internet.user_agent'),
            'phone': _Field('telephone'),
        }

    sc = Schema(user_schema)

    assert isinstance(sc, Schema)
    assert isinstance(sc.create(), list)

    assert len(sc.create()) == 1
    assert len(sc.create(iterations=3)) == 3
    assert isinstance(sc.create(iterations=3)[0], dict)

# Generated at 2022-06-23 22:05:50.315984
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    from mimesis.enums import Gender, Localization

    assert Field(locale=Localization.EN).locale == Localization.EN
    assert Field(seed='12345').seed == '12345'
    provider = Gender.MALE
    assert Field(providers=[provider])._gen.gender.Meta.name == provider.name

# Generated at 2022-06-23 22:05:50.960669
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField)

# Generated at 2022-06-23 22:05:58.767603
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.typing import Field, SchemaType

    schema: SchemaType = {
        'id': Field('uuid'),
        'name': Field('person.full_name'),
        'age': Field('age'),
        'gender': Field('person.gender', choices=[Gender.MALE, Gender.FEMALE])
    }

    schema_instance = Schema(schema)

    assert schema_instance.create() == [{
        'id': '6dfd111c-e8e6-4d52-bf12-eb9f67c8aff1',
        'name': 'Timothy Douglas',
        'age': 46,
        'gender': 'Male',
    }]

# Generated at 2022-06-23 22:06:04.394099
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method AbstractField.__call__."""
    field = Field()
    assert field('datetime') > '2020'

    def is_odd(number):
        return number % 2 != 0

    assert field('random_int', key=is_odd)

    def is_even(number):
        return number % 2 == 0

    assert field('random_int', key=is_even)

# Generated at 2022-06-23 22:06:11.618969
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field, Schema

    schema = Schema(lambda: {
        'name': Field(name='person.first_name'),
        'age': Field(name='random_int', minimum=0, maximum=150),
        'height': Field(name='datetime',
                        key=lambda obj: obj.timestamp()),
    })

    assert len(schema.create()) == 1

    assert len(schema.create(0)) == 0

    assert len(schema.create(5)) == 5


# Generated at 2022-06-23 22:06:13.258656
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    gen = Generic()
    field = AbstractField()
    field(name='en')
    field(name='en.word')
    field(name='en.word', key=str.upper)



# Generated at 2022-06-23 22:06:22.603761
# Unit test for method create of class Schema
def test_Schema_create():
    import inspect

    def simple_schema():
        return {
            'name': 'John',
            'age': '25',
            'address': 'London',
            'friends': '5',
        }

    def complex_schema():
        return {
            'name': Field('name'),
            'age': Field('age'),
            'address': Field('address'),
            'friends': Field('name'),
        }

    schema = Schema(complex_schema)
    assert schema.create(5) == [
        {'name': 'John', 'age': 42, 'address': 'London', 'friends': 'John'}
        for _ in range(5)
    ]

    schema = Schema(simple_schema)
    #: Because ``Schema(simple_schema)`` is not a *callable* object


# Generated at 2022-06-23 22:06:33.867008
# Unit test for method create of class Schema
def test_Schema_create():
    import random
    import string
    import uuid

    class SchemaProvider(Generic):
        def __init__(self, locale: str = 'en',
                     seed: Optional[Seed] = None):
            super().__init__(locale, seed=seed)
            self.uuid = uuid.uuid4()

        def text(self, **kwargs):
            return self.uuid

    def schema():
        generator = SchemaProvider(seed='test')
        return {
            'name': generator.text,
            'surname': generator.text,
        }

    field = Schema(schema)

    iterations = 10
    data = field.create(iterations)

    for d in data:
        assert isinstance(d['name'], str)

# Generated at 2022-06-23 22:06:37.112978
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField(seed=12345)
    result = f('titular')
    assert result == 'Mr. Leonardo'

    f = AbstractField(seed=12345)
    result = f('personal.full_name', key=lambda x: x.upper())
    assert result == 'VIRGIL ENGLAND'


# Generated at 2022-06-23 22:06:38.932540
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField constructor."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen.locale == 'en'
    assert field._gen.seed is None



# Generated at 2022-06-23 22:06:41.046232
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.schema import AbstractField
    obj = AbstractField()
    assert str(obj) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:42.023884
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('phone', code='+7') == '+79364528310'

# Generated at 2022-06-23 22:06:45.657767
# Unit test for method create of class Schema
def test_Schema_create():
    # Test
    iterations = 5
    res = Schema(lambda: {}).create(iterations)
    assert len(res) == iterations

# Generated at 2022-06-23 22:06:54.125055
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.network import MACAddress
    from mimesis.providers.person import Person
    from mimesis.providers.file import File

    def custom_schema() -> JSON:
        """Here you can define your valid schema."""
        person = Person()
        file_provider = File()

        return {
            'name': person.full_name(),
            'age': person.age(),
            'mac': MACAddress().mac_address(),
            'file': file_provider.file_name(),
            'path': file_provider.file_path(),
        }

    schema = Schema(custom_schema)
    assert isinstance(schema.create(), list)

# Generated at 2022-06-23 22:06:57.452693
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert (
        str(AbstractField())
        == '{} <{}>'.format(AbstractField.__name__, 'en'))
    assert (
        str(AbstractField(locale='ru'))
        == '{} <{}>'.format(AbstractField.__name__, 'ru'))



# Generated at 2022-06-23 22:07:07.004772
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    locale = 'en'
    f = Field(locale=locale)
    d = {'full_name': 'Person.full_name',
         'integer_number': 'Data.integer_number',
         'email': 'Internet.email',
         'date': 'Datetime.date',
         'datetime': 'Datetime.datetime',
         'verdict': 'Science.verdict',
         'bool_true': 'Data.bool',
         'bool_false': 'Data.bool',
         }
    for i, (key, value) in enumerate(d.items()):
        f(value, start=i)

    assert f(d['full_name']) == 'Wayne C. Freeman'

# Generated at 2022-06-23 22:07:13.542243
# Unit test for constructor of class Schema
def test_Schema():
    """Test class for Schema()."""
    def schema_func():
        """Schema function."""
        return {}

    sc1 = Schema(schema_func)
    assert isinstance(sc1, Schema)

    data = sc1.create()
    assert len(data) == 1
    assert isinstance(data[0], dict)


# Unit tests for AbstractField

# Generated at 2022-06-23 22:07:17.232054
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method AbstractField.__str__."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'



# Generated at 2022-06-23 22:07:19.720612
# Unit test for constructor of class Schema
def test_Schema():
    """Test for Schema."""
    schema = Schema(dict)
    assert isinstance(schema, Schema)
    assert callable(schema.schema)

# Generated at 2022-06-23 22:07:22.475924
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None

# Generated at 2022-06-23 22:07:23.825540
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert isinstance(f, AbstractField)



# Generated at 2022-06-23 22:07:25.828642
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method Field.__str__."""
    field = Field()
    assert 'AbstractField <en>' == str(field)

# Generated at 2022-06-23 22:07:34.312902
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Public interface of class AbstractField
    assert hasattr(AbstractField, '__call__')

    # Check UndefinedField exception
    field = Field()
    try:
        field()
    except UndefinedField:
        assert True
    else:
        assert False

    # Check UndefiniedField exception
    try:
        field(foo='bar')
    except UndefinedField:
        assert True
    else:
        assert False

    # Check UnacceptableField exception
    try:
        field(name='foo.bar.baz')
    except UnacceptableField:
        assert True
    else:
        assert False

    # Check UnsupportedField exception
    try:
        field(name='foo')
    except UnsupportedField:
        assert True
    else:
        assert False

    # Check UnsupportedField exception

# Generated at 2022-06-23 22:07:35.748376
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert issubclass(Field, AbstractField)
    assert Field()

# Generated at 2022-06-23 22:07:37.249124
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema():
        return {}

    assert Schema(test_schema)



# Generated at 2022-06-23 22:07:44.693827
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = Field()
    try:
        assert abstract_field() is None
    except UndefinedField:
        pass
    assert 'test' == abstract_field('first_name')
    assert 'test' == abstract_field('first_name',
                                    gender=abstract_field('gender'))
    assert 'test' == abstract_field('first_name',
                                    gender=abstract_field(
                                        'gender', locale='ru'))
    assert '3050' == abstract_field('postcode')
    assert '3050' == abstract_field('postcode', locale='ru')
    assert '3050' == abstract_field('ru.postcode')
    assert 'EK' == abstract_field('ru.region_code')
    assert 'Дата' == abstract_field('label')

# Generated at 2022-06-23 22:07:45.727394
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:52.753777
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': 'John Doe',
        'age': '{{ 29 }}',
        'address': {
            'city': '{{ city }}',
            'state': '{{ state }}',
            'zip_code': '{{ zip_code }}'
        },
        'phone': '{{ phone }}'
    }    
    result = Schema(schema).create(iterations=2)        
    assert len(result) == 2
    assert result[0].get('name') == 'John Doe'
    assert result[0].get('age') == '29'
    assert result[0].get('phone')
    assert result[0].get('address').get('city')
    assert result[0].get('address').get('state')
    assert result[0].get('address').get('zip_code')

# Generated at 2022-06-23 22:07:54.205626
# Unit test for method create of class Schema
def test_Schema_create():
    # TODO: Create this unit test
    pass

# Generated at 2022-06-23 22:07:55.540498
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor."""
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:08:05.184571
# Unit test for constructor of class Schema
def test_Schema():
    def schema_example():
        field = Field(locale='en')
        return {
            'name': field('text', length=10),
            'surname': field('surname'),
            'sex': field('sex'),
            'patronymic': field('patronymic'),
            'email': field('email'),
            'phone': field('phone_number'),
            'address': {
                'country': field('country'),
                'city': field('city'),
                'street': field('street_name'),
                'building': field('building_number'),
                'zip_code': field('zip_code'),
            },
        }

    schema = Schema(schema_example)
    data = schema.create(1)

    assert isinstance(data, list)

# Generated at 2022-06-23 22:08:11.053069
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': Field('en').text(),
            'status': Field('en').boolean(),
            'age': Field('en').integer(10, 20),
        }

    schema = Schema(schema)

    schemas_amount = 5
    generated_schemas = schema.create(schemas_amount)

    assert len(generated_schemas) == schemas_amount

# Generated at 2022-06-23 22:08:13.172009
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField(locale='ru', seed=42)) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:08:15.116925
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:19.135035
# Unit test for method create of class Schema
def test_Schema_create():
    def schema_func():
        """A schema function."""
        return {
            'name': Field(name='name'),
            'last_name': Field(name='last_name'),
        }

    s = Schema(schema_func)
    assert len(s.create(iterations=2)) == 2

# Generated at 2022-06-23 22:08:22.012561
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    locale = 'fr'
    f = Field(locale=locale)
    assert repr(f) == 'Field <{}>'.format(locale)



# Generated at 2022-06-23 22:08:31.918426
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.enums import Gender
    from mimesis.schema import Field
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person

    locales = ('en', 'ru')
    field = Field(locales[1])

    person_provider = Person(locales[1])
    address_provider = Address(locales[1])
    internet_provider = Internet(locales[1])

    # Add a custom provider to the existing pool of providers
    field._gen.add_provider(person_provider)
    field._gen.add_provider(address_provider)
    field._gen.add_provider(internet_provider)


# Generated at 2022-06-23 22:08:37.868720
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()

# Generated at 2022-06-23 22:08:41.650969
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.data import PYTHON_VERSION
    assert AbstractField()
    assert AbstractField(locale='en', seed=1)
    assert AbstractField(PYTHON_VERSION, seed=1)

# Generated at 2022-06-23 22:08:44.262183
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test AbstractField.__str__ method."""
    obj = AbstractField()
    print(obj)
    assert str(obj) == "AbstractField <en>"

# Generated at 2022-06-23 22:08:47.250747
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert 'AbstractField <en>' == str(AbstractField())
    assert 'AbstractField <ru>' == str(AbstractField('ru'))

# Generated at 2022-06-23 22:08:55.867444
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field
    from mimesis.enums import Gender

    _field = Field()
    schema = [
        _field('full_name', gender=Gender.MALE.value),
        _field('email'),
        _field('telephone')
    ]

    _schema = Schema(lambda: [x() for x in schema])
    assert _schema.create(1) == [[p() for p in schema]]
    assert _schema.create(2) == [[p() for p in schema]] * 2
    assert _schema.create(3) == [[p() for p in schema]] * 3

# Generated at 2022-06-23 22:08:58.033741
# Unit test for method create of class Schema
def test_Schema_create():
    assert isinstance(Schema('test').create(), list)
    assert isinstance(Schema(lambda: 'test').create(1)[0], str)

# Generated at 2022-06-23 22:08:59.363689
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:04.234818
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis import Localization

    schema = Localization('ru').datetime.datetime_obj(year=1980)
    s = Schema(schema)

    for obj in s.create(3):
        assert isinstance(obj, dict)



# Generated at 2022-06-23 22:09:05.572855
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    fl = Field()
    assert str(fl) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:11.056156
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField.

    :return: None
    """
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'
    field = AbstractField(locale='en', seed=42)
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:18.611917
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    a = field('personal.name')
    b = field('personal.surname')
    c = field('python.identifier')
    d = field('python.module')
    e = field('python.source')
    
    a_type = 'str'  # result value type
    b_type = 'str'  # result value type
    c_type = 'str'  # result value type
    d_type = 'str'  # result value type
    e_type = 'str'  # result value type
    

    if type(a).__name__ != a_type or type(b).__name__ != b_type or type(c).__name__ != c_type or type(d).__name__ != d_type or type(e).__name__ != e_type:
        print

# Generated at 2022-06-23 22:09:22.999175
# Unit test for method create of class Schema
def test_Schema_create():
    """Test create method of class Schema."""
    def test_schema():
        """Test schema."""
        return {'user': 'Kirill'}

    schema = Schema(test_schema)
    result = schema.create(3)

    assert len(result) == 3
    assert isinstance(result, list)

# Generated at 2022-06-23 22:09:27.041473
# Unit test for method create of class Schema
def test_Schema_create():
    @Field.provide('datetime')
    def schema():
        return {
            'dt': Field('datetime.datetime'),
            'tz': Field('timezone'),
        }

    assert len(Schema(schema).create()) == 1

# Generated at 2022-06-23 22:09:34.233146
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import AbstractField
    from mimesis.schema import Schema as Sch
    from mimesis.typing import JSON

    def test_schema() -> JSON:
        return {
            'name': 'John Doe',
            'age': AbstractField().random.int(min=0, max=100),
        }
    test = Sch(test_schema)
    assert test.create()[0]['age'] in range(100)
    assert test.create()[0]['name'] == 'John Doe'

# Generated at 2022-06-23 22:09:35.556206
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:36.971822
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema(lambda : [])
    assert isinstance(s, Schema)



# Generated at 2022-06-23 22:09:42.430956
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test strings representation of AbstractField.

    Test the string representation of an instance of the class
    AbstractField. We always want to see something like
    ``AbstractField <locale>``
    """
    field = Field()
    assert str(field) == 'AbstractField <en>'

    field.locale = 'ru'
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:09:44.369648
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'  # noqa: S101

# Generated at 2022-06-23 22:09:47.089889
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    # GIVEN
    f = Field(locale='fa', seed=43)

    # THEN
    assert str(f) == f'{Field.__name__} <fa>'

# Generated at 2022-06-23 22:09:51.235694
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'a': 1, 'b': 2}

    def func() -> JSON:
        return schema

    f = Schema(func)

    data = [{'a': 1, 'b': 2}]
    assert f.create() == data

# Generated at 2022-06-23 22:09:56.934977
# Unit test for constructor of class Schema
def test_Schema():
    import time
    import datetime

    def _schema() -> JSON:
        return {
            'name': Field(name='person.name'),
            'timestamp': time.time(),
        }

    def _schema2() -> JSON:
        return {
            'name': Field(name='person.full_name'),
            'age': Field(name='datetime.age'),
            'datetime': datetime.datetime.now(),
        }

    s = Schema(_schema)
    s2 = Schema(_schema2)

    res = s.create(iterations=10)
    res2 = s2.create(iterations=3)
    print(res)
    print(res2)
    assert len(res) == 10
    assert len(res2) == 3

# Generated at 2022-06-23 22:10:07.587032
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Testing method of class AbstractField."""
    from mimesis.builtins import JapanSpecProvider
    field = Field(locale='ja', providers=[JapanSpecProvider()])

    japanese = field('japanese')
    assert japanese is not None

    with field.seed(10):
        data = field('color.name', key=lambda x: x.capitalize())
    assert data == 'Yellow'

    with field.seed(10):
        data = field('color.name', key=lambda x: x.capitalize()).capitalize()
    assert data == 'Yellow'

    # Test explicit order
    assert field('datetime.datetime') is not None
    assert field('datetime.datetime', year=2011, month=9, day=13) is not None

# Generated at 2022-06-23 22:10:12.064962
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.providers.person import Person

    person = Person('ru')
    person.name(gender=person.GENDER.MASCULINE)
    person.surname(gender=person.GENDER.MASCULINE)

    field = AbstractField('ru')
    field._gen.add_providers(person)
    field('name')
    field('surname')

# Generated at 2022-06-23 22:10:13.171710
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:15.821206
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check output of AbstractField.__str__."""
    f = AbstractField(locale='ru')
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:10:19.937743
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    field = AbstractField()
    sample_name = 'Person.last_name'
    result = field(
        name=sample_name
    )
    assert isinstance(result, str)
    assert field(
        name=sample_name
    ) != field(
        name=sample_name
    )

# Generated at 2022-06-23 22:10:21.627226
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    obj = AbstractField()
    assert repr(obj) != ''

# Generated at 2022-06-23 22:10:22.794079
# Unit test for constructor of class AbstractField
def test_AbstractField():
    i = Field(seed=123)
    assert i.seed == 123
    assert i.locale == 'en'

# Generated at 2022-06-23 22:10:23.411841
# Unit test for constructor of class Schema
def test_Schema():
    Schema(object)

# Generated at 2022-06-23 22:10:25.865108
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:10:28.281593
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field is not None



# Generated at 2022-06-23 22:10:30.124809
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {})
    assert schema.create(1) == [{}]

# Generated at 2022-06-23 22:10:32.600580
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test interface of the class AbstractField."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field() is None



# Generated at 2022-06-23 22:10:33.483996
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert not isinstance(AbstractField(), AbstractField)

# Generated at 2022-06-23 22:10:37.857382
# Unit test for constructor of class Schema
def test_Schema():
    import mimesis.exceptions as exc

    class SomeSchema:
        def foo(self):
            return 'bar'

    schema = Schema(SomeSchema)

    assert isinstance(schema, Schema)

    s = schema.schema()
    assert s.foo() == 'bar'

    with exc.UndefinedSchema:
        schema = Schema(1)

# Generated at 2022-06-23 22:10:39.699821
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert f.__str__() == 'AbstractField <en>'



# Generated at 2022-06-23 22:10:42.310456
# Unit test for constructor of class Schema
def test_Schema():
    schema = {'a': 1, 'b': 2}

    def func() -> dict:
        return schema

    sch = Schema(func)
    assert sch.schema() == schema

# Generated at 2022-06-23 22:10:53.100481
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    import pytest

    field = Field(providers=[{'Translations': {'en': {'foo': 'bar'}}}])

    with pytest.raises(UndefinedField):
        field()

    assert field('number.between', min_value=1, max_value=5) >= 1
    assert field('number.between', min_value=1, max_value=5) <= 5

    assert field('translations.foo', name='Translations') == 'bar'

    assert field('datetime.datetime.now') is not None
    assert field('datetime') is not None
    with pytest.raises(UnacceptableField):
        field('datetime.datetime.now.now')

    assert field('choice.from_list') is not None

# Generated at 2022-06-23 22:10:55.340068
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.providers.base import BaseSpecProvider
    f = Field()
    assert f._gen
    assert isinstance(f._gen, BaseSpecProvider)

# Generated at 2022-06-23 22:11:02.007460
# Unit test for method create of class Schema
def test_Schema_create():
    import json
    import pytest
    def test_schema():
        return {
            'key': 'value'
        }
    schema = Schema(schema=test_schema)
    test_results = schema.create(iterations=7)
    expected_results = [{'key': 'value'}, {'key': 'value'},
                        {'key': 'value'}, {'key': 'value'},
                        {'key': 'value'}, {'key': 'value'},
                        {'key': 'value'}]
    for i in range(7):
        assert test_results[i] == expected_results[i]
        assert type(test_results[i]) == dict
    with pytest.raises(UndefinedSchema):
        schema = Schema(schema=json)

# Generated at 2022-06-23 22:11:03.199953
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField(seed=0)
    assert f('email') == 'jacob.green@example.com'

# Generated at 2022-06-23 22:11:08.743338
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Check if method __call__ raises the appropriate
    exception when passing a wrong provider name.

    :return: None
    :raises: AssertionError
    """
    f = AbstractField()
    try:
        f('invalid_provider_name')
    except UndefinedField:
        return True
    else:
        raise AssertionError('AbstractField.__call__() '
                             'failed to raise UndefinedField')



# Generated at 2022-06-23 22:11:10.269403
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
  import time

  with AbstractField(seed=time.time()) as gen:
    assert gen('sha1')

# Generated at 2022-06-23 22:11:13.301738
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of AbstractField."""
    field = Field(locale='en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:14.988974
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:11:17.903392
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method AbstractField.__call__."""
    f = AbstractField()
    res = f('text')
    assert isinstance(res, str)

    res = f('datetime', format='%H:%M')
    assert isinstance(res, str)

# Generated at 2022-06-23 22:11:19.616164
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    assert isinstance(AbstractField(), AbstractField)

# Generated at 2022-06-23 22:11:21.037009
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert isinstance(field(), str)


# Generated at 2022-06-23 22:11:24.747147
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for AbstractField."""
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None
    assert isinstance(field._gen, Generic)
    assert field._table == {}



# Generated at 2022-06-23 22:11:26.390382
# Unit test for constructor of class AbstractField
def test_AbstractField():
    instance = AbstractField()
    assert isinstance(instance, AbstractField)

# Generated at 2022-06-23 22:11:28.613677
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test __call__ method of AbstractField."""
    field = Field()
    assert field('username') is not None

# Generated at 2022-06-23 22:11:29.837193
# Unit test for constructor of class Schema
def test_Schema():
    _ = Schema
    # _ = Schema()

# Generated at 2022-06-23 22:11:32.642491
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field(locale='en-GB')
    assert (str(field) == 'AbstractField <en-GB>')
    assert (field.__str__() == 'AbstractField <en-GB>')

# Generated at 2022-06-23 22:11:34.099123
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    gen = AbstractField()
    assert isinstance(str(gen), str)

# Generated at 2022-06-23 22:11:38.060024
# Unit test for method create of class Schema
def test_Schema_create():
    """Test Schema.create method."""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.schema import Field

    def _schema() -> JSON:
        """Example schema."""
        return {
            'name': Field('full_name', key=str.split()[1]),
            'phone': Field('phone', mask='8-777-777-77-77'),
            'address': Field('address', post_index='100057'),
            'email': Field('email'),
            'passport': Field('passport'),
        }

    s = Schema(_schema)
    result = s.create(iterations=3)
    assert isinstance(result, list)
    assert len(result) == 3

    # Check Russian locale
    r = Schema(_schema)
    r.schema

# Generated at 2022-06-23 22:11:42.086572
# Unit test for constructor of class AbstractField
def test_AbstractField():
    class CustomField(AbstractField):
        """Test class for AbstractField."""

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    field = CustomField()

    assert isinstance(field, CustomField)
    assert field._gen.choice.Meta.name == 'choice'

# Generated at 2022-06-23 22:11:43.511210
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:45.321916
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    af = AbstractField()
    assert af.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:52.251755
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Field
    from mimesis.enums import Gender

    field = Field()
    schema = {
        'name': field.name(gender=Gender.MALE),
        'surname': field.surname(gender=Gender.MALE),
        'age': field.age(minimum=5),
        'patronymic': field.patronymic(gender=Gender.MALE),
    }

    s = Schema(schema)
    print(s.create(3))

# Generated at 2022-06-23 22:11:53.124835
# Unit test for constructor of class Schema
def test_Schema():
    Schema('Not callable')

# Generated at 2022-06-23 22:11:55.440527
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()

    assert field is not None


# Unit test function: AbstractField.__call__()

# Generated at 2022-06-23 22:11:56.988882
# Unit test for constructor of class Schema
def test_Schema():
    instance = Schema('')
    assert isinstance(instance, Schema)



# Generated at 2022-06-23 22:11:58.790491
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    t = Field()
    assert str(t) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:02.376517
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Create instance of AbstractField and check output of __str__."""
    f = AbstractField()
    assert f.__str__() == 'AbstractField <en>'


if __name__ == '__main__':
    test_AbstractField___str__()

# Generated at 2022-06-23 22:12:06.530684
# Unit test for constructor of class Schema
def test_Schema():
    def func():
        pass

    # 1. Good one
    schema = Schema(func)
    assert schema._field == func

    # 2. Bad one
    try:
        Schema('string')
    except UndefinedSchema:
        pass



# Generated at 2022-06-23 22:12:16.340898
# Unit test for method create of class Schema
def test_Schema_create():
    class MySchema:
        def __init__(self, field: Field) -> None:
            self.field = field

        def __call__(self, *args, **kwargs) -> dict:
            return {
                'uuid': self.field('uuid'),
                'number': self.field('number', 0, 100),
            }

    field = Field()
    schema = Schema(MySchema(field))
    answer = [
        {'uuid': field('uuid'), 'number': field('number', 0, 100)},
        {'uuid': field('uuid'), 'number': field('number', 0, 100)},
    ]
    assert schema.create(2) == answer

# Generated at 2022-06-23 22:12:19.869476
# Unit test for constructor of class Schema
def test_Schema():
    assert ('Schema' in globals())
    schema = Schema(lambda: "1")
    assert (isinstance(schema, Schema))


# Generated at 2022-06-23 22:12:21.287306
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert isinstance(Field()('URL', protocol='https'), str)

# Generated at 2022-06-23 22:12:22.549993
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None
    assert field.locale == 'en'



# Generated at 2022-06-23 22:12:24.844953
# Unit test for constructor of class Schema
def test_Schema():
    assert isinstance(Schema({}), Schema)



# Generated at 2022-06-23 22:12:27.585498
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField."""
    field = AbstractField()
    assert (
        str(field) == 'AbstractField <en>'
    )

# Generated at 2022-06-23 22:12:35.568924
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('email')
    assert field('email', key=lambda x: x.split('@')[1]) == 'gmail.com'
    assert field('datetime.datetime')
    assert field('datetime.datetime', year=2000)
    assert field('datetime.datetime', key=lambda x: x.year) == 2000
    assert field('datetime.datetime', year=2000, key=lambda x: x.year) == 2000
    assert field('us.zipcode')
    assert field('software.mimesis', key=lambda x: x.title()) == 'Mimesis'

# Generated at 2022-06-23 22:12:40.497381
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.data import RUSSIAN_SCHEMA

    s = Schema(schema=RUSSIAN_SCHEMA)
    assert s.schema == RUSSIAN_SCHEMA

    # TypeError
    with pytest.raises(UndefinedSchema):
        Schema(schema={})



# Generated at 2022-06-23 22:12:41.566811
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field()



# Generated at 2022-06-23 22:12:45.370284
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': 'Bitcoin',
        'symbol': 'BTC',
        'decimal': 8
    }

    data = Schema(lambda: schema).create(2)
    assert data[0] == data[1] == schema

# Generated at 2022-06-23 22:12:46.284677
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField"""
    f = AbstractField()
    assert f('full_name')

# Generated at 2022-06-23 22:12:49.487777
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert callable(f)

    name = 'hello'
    assert f(name=name) is not None

    name = 'something'
    assert f(name=name) is not None

# Generated at 2022-06-23 22:12:57.351253
# Unit test for constructor of class Schema
def test_Schema():
    schema = {
        'name': 'Ivan Ivanov',
        'email': 'username@example.com'
    }

    class User(Schema):
        def __init__(self):
            super().__init__(schema)

    user = User()
    assert isinstance(user.schema, dict)
    assert user.create()[0]['name'] == 'Ivan Ivanov'



# Generated at 2022-06-23 22:13:00.042398
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField constructor.

    test_AbstractField()
    """
    field = AbstractField()
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:13:00.743634
# Unit test for constructor of class Schema
def test_Schema():
    func = lambda: {}
    assert Schema(func)

# Generated at 2022-06-23 22:13:10.430109
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet

    def test_schema() -> dict:
        """Test schema."""
        _field = AbstractField(providers=[Person(seed=2), Internet()])
        return {
            'name': _field('name', gender=Gender.MALE),
            'surname': _field('surname', gender=Gender.MALE),
            'address': _field('address'),
            'email': _field('email', address='@example.com'),
        }

    schema = Schema(test_schema)
    result = schema.create(5)
    assert len(result) == 5

# Generated at 2022-06-23 22:13:15.039163
# Unit test for method create of class Schema
def test_Schema_create():
    """Test create method."""
    def _get_schema() -> JSON:
        return {'a': 1, 'b': 2}

    s = Schema(_get_schema)
    cases = s.create(3)
    assert len(cases) == 3
    assert cases[0] == {'a': 1, 'b': 2}

# Generated at 2022-06-23 22:13:18.054607
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    s = SchemaType({
        'name': 'name',
        'age': 'random.randint',
        'gender': 'random.choice.gender',
    })

    def schema() -> dict:
        return Field()(**s)

    result = Schema(schema).create()
    assert isinstance(result, list)

# Generated at 2022-06-23 22:13:24.696353
# Unit test for method create of class Schema
def test_Schema_create():
    """Test the method create of class Schema."""
    import mimesis.data

    class Person:
        last_name = mimesis.data.LAST_NAMES
        first_name = mimesis.data.FIRST_NAMES
        address = mimesis.data.STREETS

    class PersonSchema:
        def __call__(self):
            return Person()

    schema = Schema(PersonSchema())
    result = schema.create(2)
    assert isinstance(result, list)
    assert isinstance(result[0], dict)
    assert isinstance(result[1], dict)
    assert set(result[0].keys()) == {'last_name', 'first_name', 'address'}

# Generated at 2022-06-23 22:13:27.097730
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()
    assert 'Alice' in f('person.name')
    assert f('person.name') == f('name')

# Generated at 2022-06-23 22:13:30.818246
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    f = Field()
    assert f.locale == 'en'
    assert f.seed is None
    f('hello')
    f('provider1.hello')
    f('hello', tail=True)
    try:
        f()
    except UndefinedField as e:
        assert isinstance(str(e), str)

# Generated at 2022-06-23 22:13:32.968332
# Unit test for constructor of class Schema
def test_Schema():
    def empty_schema():
        return []
    Schema(empty_schema)
    Schema.empty_schema = empty_schema
    Schema.create = Schema.create
    Schema.create()

# Generated at 2022-06-23 22:13:34.080166
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(lambda: {}).create(10)) == 10

# Generated at 2022-06-23 22:13:37.086234
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = Field()

    assert field._gen.choice.Meta.name == 'choice'

# Generated at 2022-06-23 22:13:42.198514
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import schema

    def schema_person():
        person = schema.Field()
        return {
            'first_name': person('person.name'),
            'last_name': person('person.surname'),
            'age': person('person.age'),
        }

    people = schema.Schema(schema_person).create(iterations=10)

    assert len(people) == 10
    assert isinstance(people, list)

# Generated at 2022-06-23 22:13:46.411534
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('address.city') == 'Marshall'
    assert field('person.last_name') == 'Tyson'
    assert field('person.last_name', upper_case=True) == 'TYSON'

# Generated at 2022-06-23 22:13:47.825913
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert 'en' == f.locale

# Generated at 2022-06-23 22:13:56.482314
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    f = Field()

    # Test for split of name
    for name in ('name', 'provider.name', 'provider.provider.name', 'provider.'):
        if name == 'provider.':
            try:
                f(name)
            except UnacceptableField:
                pass

        node, _, tail = name.partition('.')
        assert getattr(getattr(f._gen, node), tail)

    # Test for UndefinedField exception
    try:
        f()
    except UndefinedField:
        pass

    # Test for UnsupportedField exception
    # Unknown provider name
    try:
        f('provider.name')
    except UnsupportedField:
        pass

    # Unknown method name

# Generated at 2022-06-23 22:13:57.788630
# Unit test for method create of class Schema
def test_Schema_create():
    # TODO
    pass

# Generated at 2022-06-23 22:14:00.157210
# Unit test for constructor of class Schema
def test_Schema():
    def _schema() -> JSON: return {}
    schema = Schema(_schema)

    assert schema
    assert schema.schema



# Generated at 2022-06-23 22:14:01.688914
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abf = AbstractField()
    assert abf.locale == 'en'

# Generated at 2022-06-23 22:14:05.216583
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field(locale='en', seed=0)
    assert f.locale == 'en'
    assert f.seed == 0, 'Seed should be equal zero.'
    assert str(f) == 'Field <en>'

# Generated at 2022-06-23 22:14:06.699955
# Unit test for constructor of class Schema
def test_Schema():
    global Field
    assert issubclass(Field, AbstractField)

# Generated at 2022-06-23 22:14:12.769888
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField's constructor.

    If we will get an error like ``AssertionError`` that means that
    call of constructor of class AbstractField is not correct.
    """
    abstract_field = AbstractField()

    assert isinstance(abstract_field._gen, Generic)
    assert abstract_field._table == {}
    assert abstract_field.locale == 'en'
    assert abstract_field.seed is None



# Generated at 2022-06-23 22:14:16.802817
# Unit test for method create of class Schema
def test_Schema_create():
    # Create a new field
    f = Field()

    # Create a new schema by field
    s = Schema(lambda: {'foo': f('text')})

    # Create a list of a filled schemas
    result = s.create(10)
    assert (len(result) == 10)

# Generated at 2022-06-23 22:14:19.077526
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    abstract_field = AbstractField()
    assert str(abstract_field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:22.338926
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """
    Test AbstractField's __str__ method.

    Expected result:
        AbstractField <en>
    """
    field = AbstractField()
    result = str(field)
    assert result == 'AbstractField <en>'



# Generated at 2022-06-23 22:14:24.394679
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {'name': 'John'})
    assert schema
    assert isinstance(schema.create(), list)

# Generated at 2022-06-23 22:14:26.724263
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field: Callable = AbstractField()

    assert field('__call__') == field
    assert field('__call__', key=lambda x: True)

# Generated at 2022-06-23 22:14:28.695112
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for string representation of AbstractField."""
    af = AbstractField()
    assert af.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:33.706868
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.builtins.schema import (
        Address,
        Person,
    )

    schema = Schema(Person)
    filled_schemas = schema.create(iterations=3)
    assert len(filled_schemas) == 3

    schema = Schema(Address)
    filled_schemas = schema.create(iterations=5)
    assert len(filled_schemas) == 5

# Generated at 2022-06-23 22:14:34.253896
# Unit test for method create of class Schema
def test_Schema_create():
    pass

# Generated at 2022-06-23 22:14:36.191092
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    _field = Field()
    assert _field.__str__() == 'Field <en>'

# Generated at 2022-06-23 22:14:39.133027
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """AbstractField.__str__()."""
    provider = AbstractField()
    assert str(provider) == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:43.240391
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for Schema."""
    s = Schema(lambda: {
        'one': 1,
        'two': 2,
    })
    assert s.create(3) == [{
        'one': 1,
        'two': 2,
    }] * 3

# Generated at 2022-06-23 22:14:49.372691
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field

    def simple_schema() -> list:
        field = Field()
        return [
            field('uuid4'),
            field('uuid4'),
            field('uuid4'),
        ]

    schema = Schema(simple_schema)
    result = schema.create(iterations=10)
    assert len(result) == 10

# Generated at 2022-06-23 22:14:54.757810
# Unit test for constructor of class Schema
def test_Schema():
    # Tests for positive cases
    positive_values = [dict, lambda: dict(a=1)]

    for value in positive_values:
        Schema(value)

    # Tests for negative cases
    negative_values = [1, [], '1', object()]

    for value in negative_values:
        try:
            Schema(value)
        except UndefinedSchema:
            continue