

# Generated at 2022-06-23 22:04:48.788417
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    schema = Schema({'a': 1})
    assert len(schema.create()) == 1



# Generated at 2022-06-23 22:04:52.815046
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f.locale == 'en'
    assert f.seed is None
    assert f._gen is not None
    assert isinstance(f._gen.datetime, f._gen._dt.Datetime)
    assert isinstance(f._gen.text, f._gen._txt.Text)

# Generated at 2022-06-23 22:04:56.438396
# Unit test for constructor of class Schema
def test_Schema():
    def _get_schema() -> JSON:
        return {
            'foo': 'bar',
            'num': 123,
            'float': 3.14,
            'arr': [1, 'b', 3],
        }

    return Schema(_get_schema)

# Generated at 2022-06-23 22:04:58.259458
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test of class AbstractField."""
    tester = Field()
    assert callable(tester)

# Generated at 2022-06-23 22:05:02.601949
# Unit test for method create of class Schema
def test_Schema_create():  # pragma: no cover
    schema = Schema(lambda: {})
    assert schema.create(iterations=5) == [{}] * 5
    assert schema.create(iterations=1) == [{}]



# Generated at 2022-06-23 22:05:04.890938
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for AbstractField.__str__."""
    provider = AbstractField()
    assert isinstance(str(provider), str)

# Generated at 2022-06-23 22:05:06.413903
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert callable(field)



# Generated at 2022-06-23 22:05:17.277083
# Unit test for constructor of class Schema
def test_Schema():
    """Test case for constructor of class Schema"""
    # Test when schema is not a callable object
    try:
        Schema('str')
    except UndefinedSchema:
        pass
    else:
        raise AssertionError('WTF?')

    # Create an empty class with no attributes
    class EmptyClass:
        pass

    # Test when EmptyClass is callable
    try:
        Schema(EmptyClass)
    except UndefinedSchema:
        pass
    else:
        raise AssertionError('WTF?')

    # Create callable class
    class CallableClass:
        def __init__(self):
            self.attr = 'attr'


# Generated at 2022-06-23 22:05:26.469772
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.enums import Gender

    def schema():
        return {
            'name': Field().person.full_name(),
            'gender': Field().person.gender(gender=Gender.MALE),
            'age': Field().person.age(minimum=20, maximum=30),
            'id': Field().code.isbn(),
        }
    s = Schema(schema)
    assert s.create(1) == [{
        'name': 'Bobby Barts',
        'gender': Gender.MALE,
        'age': '20',
        'id': '0-7112-3767-2',
    }]

# Generated at 2022-06-23 22:05:31.211010
# Unit test for method create of class Schema
def test_Schema_create():
    """Test class Schema and its method create."""
    schema = Schema(lambda:
                    {'name': 'Bob',
                     'age': 20})
    result = schema.create(3)
    result_expected = [{
        'name': 'Bob',
        'age': 20,
    }] * 3

    assert result == result_expected

# Generated at 2022-06-23 22:05:32.681670
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:41.841682
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import Person
    from mimesis.builtins import RussiaSpecProvider

    person = Person('ru')
    person.add_provider(RussiaSpecProvider)

    schema = person.create_schema(
        name=None,
        surname=None,
        gender='male',
        occupation='programmer',
        address=None,
    )

    assert callable(schema)

    # Assert thar schema is a Schema object
    assert isinstance(Schema(schema), Schema)

    # Assert thar schema is a Schema object
    assert not isinstance(Schema(person.create_fake_value), Schema)

# Generated at 2022-06-23 22:05:50.960989
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    result = callable_field(field)
    assert result == 'Python'

    result = callable_field(field, name='python.choice')
    assert result == 'Python'

    assert callable(field.python)
    assert callable(field.python.choice)

    result = callable_field(field, name='programming.language')
    assert result.startswith('Java')

    assert callable(field.programming)
    assert callable(field.programming.language)

    # Fix https://github.com/lk-geimfari/mimesis/issues/619
    #  and https://github.com/lk-geimfari/mimesis/issues/639
    result = callable_field(field, name='choice')

# Generated at 2022-06-23 22:05:55.825122
# Unit test for method create of class Schema
def test_Schema_create():
    test_schema = {
        'name': 'Olga',
        'age': 20,
        'gender': 'female',
        'job': 'Manager',
        'address': 'Moscow'
    }

    s = Schema(test_schema)
    res = s.create(10)
    assert isinstance(res, list)
    assert len(res) == 10
    assert res[0].get('name') == 'Olga'

# Generated at 2022-06-23 22:05:57.038439
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert AbstractField().__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:02.232622
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.types import SchemaType
    from mimesis.providers.base import BaseDataProvider

    class Fake(BaseDataProvider):

        class Meta:
            name = __name__

        def foo(self):
            return 'bar'

    provider = Fake('en')
    field = Field(locale='en', providers=provider)
    schema: SchemaType[Fake] = lambda: {'foo': field.foo}
    data: List[dict] = Schema(schema).create(iterations=5)
    assert isinstance(data, list)
    assert isinstance(data[0], dict)
    assert data[0] == {'foo': 'bar'}

# Generated at 2022-06-23 22:06:05.576307
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'
    field.locale = 'ru'
    assert str(field) == 'AbstractField <ru>'



# Generated at 2022-06-23 22:06:11.315273
# Unit test for constructor of class AbstractField
def test_AbstractField():  # noqa: D103
    from mimesis import schema, providers

    field = schema.AbstractField(providers=[providers.Internet()])
    result = field('email')
    assert '@' in result

    result = field('web.email')
    assert '@' in result

    result = field('web.email', domains=['test.com'])
    assert 'test.com' in result

# Generated at 2022-06-23 22:06:12.531004
# Unit test for constructor of class Schema
def test_Schema():
    def func():
        return {}

    return Schema(func)

# Generated at 2022-06-23 22:06:17.892194
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.enums import Gender
    from mimesis.providers import Person
    from mimesis.schema import Field

    person = Person('en')
    f = Field(locale='en', providers=[person])

    assert (
        f('name', gender=Gender.MALE) ==
        person.name('male')
    )

# Generated at 2022-06-23 22:06:21.617344
# Unit test for method create of class Schema
def test_Schema_create():
    """Testing json."""
    import mimesis

    generator = mimesis.Generic()
    data = {'name': generator.name(),
            'surname': generator.surname(),
            'patronymic': generator.patronymic(),
            'address': generator.address(),
            }

    def person() -> Schema:
        """Return person data."""
        return data

    schema = Schema(person)
    assert isinstance(schema.create(3), list)

    schema = Schema(generator)
    assert isinstance(schema.create(3), list)



# Generated at 2022-06-23 22:06:23.104640
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field(locale='ru')) == 'Field <ru>'

# Generated at 2022-06-23 22:06:33.826678
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for AbstractField.__call__.

    This method is a magic method which overrides standard call.
    It takes any string which represents the name of any method
    of any supported data provider and the ``**kwargs`` of this method.
    """
    g = Generic('en')
    f = Field()
    assert f('person.full_name') == g.person.full_name()
    assert f('person.full_name') != g.person.uuid()
    assert f('file_extension') == g.file.extension()
    assert f('file_extension') != g.file.extension()
    assert f('file_extension') not in g.file.extension()
    assert f('file_extension') not in g.person.full_name()

# Generated at 2022-06-23 22:06:40.914127
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.schema import AbstractField, Schema
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet
    from mimesis.typing import JSON

    def schema() -> JSON:
        """Create schema."""
        return {
            'name': AbstractField().name(gender=Gender.FEMALE),
            'surname': AbstractField().surname(gender=Gender.FEMALE),
            'email': AbstractField().email(
                domains=Internet.get_top_level_domains()),
        }

    assert len(Schema(schema).create(10)) == 10



# Generated at 2022-06-23 22:06:44.913158
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Test with kwargs
    field = Field()
    field('json', indent=2)

    # Test with no kwargs
    assert field('uuid4')

    # Test with key function
    field = Field()
    assert field('uuid4', key=lambda x: x.upper())

    # Test with bad provider name
    field = Field()
    field('BadProvider.json')

    # Test with bad field name
    field = Field()
    field('BadField')

    # Test with bad tail name
    field = Field()
    field('user_agent.bad_provider')

    # Test with bad tail name
    field = Field()
    field('user_agent.bad.provider')

# Generated at 2022-06-23 22:06:47.043386
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert isinstance(f, AbstractField)
    assert callable(f)



# Generated at 2022-06-23 22:06:48.760178
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'
    f = AbstractField(locale='ru')
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:06:52.297319
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    class SimpleProvider:

        @classmethod
        def simple(cls, a: str):
            return a

    field = AbstractField(locale='en', providers=[SimpleProvider])
    method = field('simple', a='mimesis')

    assert method == 'mimesis'

# Generated at 2022-06-23 22:07:01.029857
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.schema import Field, Schema

    field = Field(locale='en')

    def schema() -> dict:
        return {
            'name': field('person.name', gender=Gender.MALE),
            'surname': field('person.surname', gender=Gender.MALE),
        }

    s = Schema(schema)
    created = s.create(2)

    assert isinstance(created, list)
    assert len(created) == 2
    assert created[0]['name'] != created[1]['name']



# Generated at 2022-06-23 22:07:08.931104
# Unit test for constructor of class Schema
def test_Schema():
    """Test for instance initialization of class Schema.

    :return:
    """
    # Test 1. The schema must be a callable object
    # otherwise an exception UndefinedSchema should be raised
    try:
        # noinspection PyTypeChecker
        Schema(1)
    except UndefinedSchema:
        pass

    # Test 2. Class accepts only callable objects
    # otherwise UndefinedSchema should be raised
    try:
        Schema('test')
    except UndefinedSchema:
        pass

    # Test 3. If everything is fine, the new instance of class should be created.
    schema = Schema(lambda: 'test')
    assert schema.schema() == 'test'

# Generated at 2022-06-23 22:07:19.727140
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Check that the method works correctly with a method without arguments
    instance = AbstractField()
    assert isinstance(instance('full_name'), str)

    # Check that the method works correctly with a method with arguments
    instance = AbstractField()
    assert isinstance(instance('token_hex', length=5), str)

    # Check that the method works correctly with a method of a certain provider
    instance = AbstractField()
    assert instance('choice', ['a', 'p', 'f', 'l']) in ['a', 'p', 'f', 'l']

    # Check that the method works correctly with a method of a certain provider
    instance = AbstractField()
    with pytest.raises(UndefinedField):
        assert isinstance(instance(None), str)

    # Check that the method works correctly with a method of a certain provider
    instance = AbstractField

# Generated at 2022-06-23 22:07:21.809764
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test AbstractField.__str__."""
    field = AbstractField()
    assert str(field) == "AbstractField <en>"

# Generated at 2022-06-23 22:07:23.519424
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    field = Field()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:07:25.044706
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:28.547393
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field
    from mimesis.schema import Schema

    def schema():
        return {
            'field': Field(),
        }

    schema = Schema(schema)
    assert isinstance(schema.create(), list)

# Generated at 2022-06-23 22:07:31.952890
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__() method."""
    field = AbstractField()
    assert isinstance(field, AbstractField)

    try:
        field()
    except UndefinedField:
        assert True
    else:
        assert False

# Generated at 2022-06-23 22:07:36.513880
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Test basic initialization
    AbstractField()
    # Test initialization with seed
    AbstractField(seed=1)
    # Test initialization with locale
    AbstractField(locale='ru')
    # Test initialization with provider
    AbstractField(providers=['datetime'])

# Generated at 2022-06-23 22:07:40.895231
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test class AbstractField method __call__."""
    _seed = None
    _locale = 'en'
    _field = Field(_locale, _seed)
    _data = _field('name')
    assert _data  # nosec



# Generated at 2022-06-23 22:07:43.313878
# Unit test for constructor of class AbstractField
def test_AbstractField():
    locale = 'en'
    seed = '1'
    field = AbstractField(locale, seed)
    assert field.locale == locale
    assert field.seed == str(seed)
    assert field._gen is not None



# Generated at 2022-06-23 22:07:44.408980
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert AbstractField()

# Generated at 2022-06-23 22:07:54.112851
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test magic __call__ method of any fields."""
    field = AbstractField()

    # Check that method return the right value
    assert field('text.word') == 'Vivamus'

    # Check that method return the right value if method has an alias
    assert field('network.mac_address') == 'b4:e4:6d:f6:8b:c1'

    # Check that method supports random function (choices)
    assert field('network.mac_address', choices=True) == 'e4:1f:ff:a4:53:4b'

    # Check that method returns the right value from two different providers
    assert field('codename.word') == 'Onyx'

    # And the second
    assert field('codename.word') == 'Opus'

    # Check that method returns the right value with a

# Generated at 2022-06-23 22:08:04.099808
# Unit test for method create of class Schema
def test_Schema_create():
    def get_schema() -> dict:
        """Get schema."""
        return {
            'name': 'John',
            'surname': 'Smith',
            'email': 'johnsmith@example.com',
            'age': 22,
            'address': {
                'street': 'Main Street',
                'number': 12,
                'city': 'Springfield'
            }
        }


# Generated at 2022-06-23 22:08:10.503680
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': 'name',
            'surname': 'surname',
        }

    s = Schema(schema)
    result = s.create(2)
    expected = [
        {'name': 'name', 'surname': 'surname'},
        {'name': 'name', 'surname': 'surname'},
    ]
    assert result == expected

# Generated at 2022-06-23 22:08:12.588911
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    class F(AbstractField):
        pass

    assert str(F('en')) == 'F <en>'

# Generated at 2022-06-23 22:08:14.735605
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()

    assert f('uuid') is not None



# Generated at 2022-06-23 22:08:21.404363
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.generic import Generic
    from mimesis.schema import Schema
    from mimesis.schema import Field

    gen = Generic()
    assert isinstance(gen, Generic)
    assert isinstance(Field(locale=gen.locale), AbstractField)
    assert isinstance(Schema(Field(locale=gen.locale)), Schema)
    data = gen.create_schema(iterations=1, schema=Field)
    # ignore mypy error: Unexpected keyword argument "iterations"
    assert isinstance(data, list)  # type: ignore



# Generated at 2022-06-23 22:08:24.046792
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for AbstractField class."""
    import pytest

    with pytest.raises(UndefinedSchema):
        Schema('Schema')('create', iterations=3)

# Generated at 2022-06-23 22:08:26.937725
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'
    f = Field('de')
    assert str(f) == 'AbstractField <de>'

# Generated at 2022-06-23 22:08:35.013005
# Unit test for method create of class Schema
def test_Schema_create():
    """Test Schema."""
    from mimesis import Generic, Schema

    import pytest

    class MySchema:
        """MySchema."""

        def __init__(self, gender: str = None, **kwargs) -> None:
            """Initialize schema."""
            self.seed = 'mimesis'
            self.locale = 'ru'
            self._gen = Generic(seed=self.seed, locale=self.locale)
            self.gender = gender

        def __call__(self) -> JSON:
            """Make schema callable."""

# Generated at 2022-06-23 22:08:38.649904
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis import Person
    from mimesis.schema import AbstractField

    provider = Person('en')
    field = AbstractField(provider=provider)
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:41.850932
# Unit test for constructor of class AbstractField
def test_AbstractField():
    gen = Generic()
    field = Field(providers=[gen])
    assert issubclass(field.__class__, AbstractField)

# Generated at 2022-06-23 22:08:44.843088
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField constructor."""
    field = AbstractField()
    field = AbstractField(locale='fr')
    field = AbstractField(seed=42)
    field = AbstractField(providers='foo')

# Generated at 2022-06-23 22:08:51.968876
# Unit test for method create of class Schema
def test_Schema_create():
    schema = lambda: {'foo': 'bar'}
    sch = Schema(schema)
    assert sch.create() == [{'foo': 'bar'}]
    assert sch.create(0) == []
    assert sch.create(5) == [{'foo': 'bar'}, {'foo': 'bar'}, {'foo': 'bar'},
                             {'foo': 'bar'}, {'foo': 'bar'}]



# Generated at 2022-06-23 22:08:55.720979
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {}

    assert callable(schema()) is True
    a = Schema(schema)
    assert callable(a.schema) is True
    assert a.create() == [{}]


# Generated at 2022-06-23 22:09:04.165932
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers import Person
    from mimesis.schema import Field

    # Define the schema of our business objects
    def _person_schema() -> JSON:
        return {
            'first_name': Field('first_name'),
            'last_name': Field('last_name'),
            'email': Field('email'),
            'age': Field('age', minimum=18, maximum=55),
        }

    # Instantiate Schema class
    schema = Schema(_person_schema)

    # Create 10 participants in the conference
    participants = schema.create(10)
    assert len(participants) == 10

    # Add additional participants with different data
    # (just for demonstration)
    p = Person('en', seed=42)

# Generated at 2022-06-23 22:09:10.826289
# Unit test for method create of class Schema
def test_Schema_create():
    NUM = 100
    schema = Schema(lambda: {'a': 1, 'b': 2})
    schemas = schema.create(NUM)
    assert len(schemas) == NUM, 'Invalid length of schemas'
    assert all(['a' in s and 'b' in s for s in schemas]), (
        'Invalid schema data')
    assert all([s['a'] == 1 and s['b'] == 2 for s in schemas]), (
        'Invalid schema data')

# Generated at 2022-06-23 22:09:14.754574
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check that __str__ method works properly."""
    from mimesis.schema import AbstractField
    abc = AbstractField()
    ab = AbstractField()

    assert str(abc) == 'AbstractField <en>'
    assert str(ab) == 'AbstractField <en>'
    assert str(ab) is not str(abc)



# Generated at 2022-06-23 22:09:18.250333
# Unit test for method create of class Schema
def test_Schema_create():
    data = [{'a': 1, 'b': 'str'}]
    schema = Schema(data)
    assert schema.create(2) == [{'a': 1, 'b': 'str'}, {'a': 1, 'b': 'str'}]

# Generated at 2022-06-23 22:09:19.701190
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    obj = AbstractField()
    assert str(obj) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:21.301534
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    f = AbstractField()
    assert f



# Generated at 2022-06-23 22:09:26.802634
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers import Address

    addr = Address('ru')

    def schema():
        return {
            'full_name': [addr.name() for x in range(addr.random.randint(1, 10))],
            'age': addr.random.randint(0, 100),
            'house': {
                'room': addr.room(),
                'apartment': addr.apartment()
            }
        }

    s = Schema(schema)
    assert len(s.create(10)) == 10



# Generated at 2022-06-23 22:09:27.741519
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:09:36.013079
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Person

    class PersonSchema(Person):
        """Test PersonSchema."""

        @staticmethod
        def schema() -> JSON:
            """Return schema."""
            return {
                'first_name': PersonSchema().full_name(),
                'age': PersonSchema().age(),
            }

    # Testing

    s = Schema(schema=PersonSchema.schema)
    assert len(s.create()) == 1
    assert len(s.create(iterations=10)) == 10
    assert s.create(iterations=2)[0] == s.create(iterations=2)[1]

# Generated at 2022-06-23 22:09:38.406404
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit-test for constructor of class AbstractField."""
    assert Field('ru').locale == 'ru'
    assert Field(seed=123).seed == 123
    assert Field()._gen.locale == 'en'

# Generated at 2022-06-23 22:09:39.366730
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert (
        str(AbstractField()) == 'AbstractField <en>'
    )

# Generated at 2022-06-23 22:09:41.331569
# Unit test for constructor of class Schema
def test_Schema():
    """Check schema callable."""
    s = Schema(lambda: True)
    assert callable(s.schema)

# Generated at 2022-06-23 22:09:44.271609
# Unit test for constructor of class AbstractField
def test_AbstractField():
    data = Field(locale='en', providers=[])
    assert data.locale == 'en'


# Unit-test for AbstractField.__call__

# Generated at 2022-06-23 22:09:47.346633
# Unit test for constructor of class Schema
def test_Schema():
    class MySchema:
        def __call__(self):
            return {}

    obj = Schema(MySchema)

    assert obj is not None
    assert obj.schema() == {}



# Generated at 2022-06-23 22:09:49.443874
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {'field': Field()('datetime')}

    assert len(Schema(schema).create(10)) == 10



# Generated at 2022-06-23 22:09:50.969023
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema  # type: ignore
    assert isinstance(schema(lambda: {'name': 'name'}), Schema)



# Generated at 2022-06-23 22:09:52.696783
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of class Schema."""
    _ = Schema(None)



# Generated at 2022-06-23 22:09:54.762272
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor of class Schema."""
    s = Schema(lambda: {'name': 'Johnny'})
    assert s is not None

# Generated at 2022-06-23 22:09:56.040484
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:00.618944
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    result = field(name='random_int')
    assert isinstance(result, int)

    result = field(name='random_int', key=str)
    assert isinstance(result, str)

    result = field(name='address.address', neighborhood='London')
    assert 'London' in result

    result = field(name='address.zip_code', country_code='GB')
    assert 'GB' in result

# Generated at 2022-06-23 22:10:02.012681
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert isinstance(field, AbstractField)
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:03.187047
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert f.__str__() == "{} <en>".format(f.__class__.__name__)

# Generated at 2022-06-23 22:10:10.296983
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field

    f = Field()

    def schema() -> JSON:
        return {
            'name': f('person.full_name'),
            'age': f('datetime.year')
        }

    s = Schema(schema)
    assert s.create(iterations=3) == [
        {'name': 'Olivia Griffin', 'age': 1993},
        {'name': 'Carlos Brown', 'age': 2008},
        {'name': 'John Anderson', 'age': 2018}
    ]


# Generated at 2022-06-23 22:10:14.921644
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schemas import USER

    schema = Schema(USER())
    assert schema.create() == [{'name': 'Irene',
                                'surname': 'Gonzalez',
                                'email': 'Molina.Martin@yahoo.com',
                                'age': 13,
                                'gender': 'm',
                                'username': 'jfmenezes',
                                'password': '123456',
                                'telephone': '523-619-1171'}]



# Generated at 2022-06-23 22:10:18.005739
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'num': 10,
        'str': 'mimesis',
    }

    s = Schema(lambda: schema)
    assert s.create() == [schema]

# Generated at 2022-06-23 22:10:20.661665
# Unit test for method create of class Schema
def test_Schema_create():
    assert Schema(dict).create(2) == [{}, {}]
    assert Schema(lambda: 'Foo').create(2) == ['Foo', 'Foo']

# Generated at 2022-06-23 22:10:21.961623
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:25.291181
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of AbstractField."""
    from mimesis.providers.cryptographic import Cryptographic

    test = AbstractField(providers=[Cryptographic])
    assert callable(test.sha3) is True

# Generated at 2022-06-23 22:10:28.266009
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """."""
    AbstractField(locale='ru', seed=None)
    AbstractField(locale='ru', seed=42, providers=[])
    AbstractField(locale='en', seed=42)
    AbstractField(locale='en', seed=None)



# Generated at 2022-06-23 22:10:31.507850
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of class Schema."""
    s = Schema(lambda: {})
    assert s
    assert callable(s.schema)

# Generated at 2022-06-23 22:10:35.076791
# Unit test for constructor of class Schema
def test_Schema():
    def test():
        return 1

    schema = Schema(schema=test)
    assert isinstance(schema, Schema)

    assert schema.create(1)

    schema = Schema(schema=2)
    assert isinstance(schema, Schema)

# Generated at 2022-06-23 22:10:38.091496
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'foo': 'bar'}
    s = Schema(schema)
    assert s.create(2) == [schema] * 2



# Generated at 2022-06-23 22:10:39.526317
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:45.842891
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    data = field('postcode')
    assert len(data) == 6
    data = field('postcode', tail='random_int',
                 limit_min=6, limit_max=6)
    assert len(data) == 6
    field = Field(locale='ru')
    data = field('phone_number')
    assert len(data) == 14
    data = field('url')
    assert len(data) > 10
    data = field('email', _key=lambda x: '@' in x)
    assert data
    data = field('email', _key=lambda x: '@' not in x)
    assert not data
    field = Field(locale='ru')
    data = field('ruble', tail='random_int',
                 limit_min=1, limit_max=2)


# Generated at 2022-06-23 22:10:47.660158
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Check method call."""
    schema = Field()
    assert isinstance(schema('uuid'), str)

# Generated at 2022-06-23 22:10:55.755586
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of Schema class."""
    from mimesis.typing import Schema

    class TestSchema(Schema):
        """Test schema class."""

        def __init__(self, field: Field) -> None:
            self.field = field
            super().__init__(self.__class__.resume)

        def resume(self) -> dict:
            """Create dict."""
            return {
                'fullname': self.field('full_name'),
                'age': self.field('age'),
            }

    s = TestSchema(Field())
    assert isinstance(s.field, Field)

# Generated at 2022-06-23 22:10:59.903740
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of AbstractField class."""
    gen = Field()

    assert callable(gen.__call__)
    assert gen.__call__('person.full_name') is not None
    assert gen.__call__('full_name') is not None

    for _ in range(5):
        assert gen.__call__('person.age', None, minimum=18, maximum=65)
        assert gen.__call__('person.age', None, minimum=18, maximum=65) \
            is not None

    assert gen.__call__('person.full_name', None) is not None

    assert gen.__call__('person.full_name', None) is not None
    assert gen.__call__('person.full_name', len) == 0



# Generated at 2022-06-23 22:11:00.986652
# Unit test for constructor of class Schema
def test_Schema():
    assert callable(Schema)



# Generated at 2022-06-23 22:11:01.806384
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:12.139331
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import Address
    from mimesis.providers import Business, Person
    from mimesis.providers.address import Address as AddressProvider

    for provider in [Person(), Business(), AddressProvider()]:
        assert provider.__class__.__name__ in dir(Address())

    f = AbstractField()
    # Case 1. Data provider and method doesn't contain a dot (.)
    name = 'ssn'
    assert callable(getattr(Person(), name))
    assert f(name) == getattr(Person(), name)()

    # Case 2. Data provider contains a dot, but the method doesn't
    name = 'person.ssn'
    assert callable(getattr(Person(), 'ssn'))
    assert f(name) == getattr(Person(), 'ssn')()

    # Case 3. Both data provider and

# Generated at 2022-06-23 22:11:14.068048
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert field.__class__.__name__ in str(field)
    assert field.locale in str(field)

# Generated at 2022-06-23 22:11:21.759469
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test test_Schema_create"""

    element = {
        'name': '{{ person.full_name }}',
        'age': '{{ person.age }}',
        'address': '{{ person.address }}',
    }

    class Address:
        """Override class for testing."""

        def __init__(self, **kwargs):
            """Initialize Address."""
            self.country = kwargs.get('country', None)

    class Person:
        """Override class for testing."""

        def __init__(self, **kwargs) -> None:
            """Initialize Person."""
            self.full_name = kwargs.get('full_name', None)
            self.address = Address(**kwargs)
            self.age = kwargs.get('age', None)


# Generated at 2022-06-23 22:11:23.259707
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field = AbstractField(seed=42)
    assert abstract_field is not None

# Generated at 2022-06-23 22:11:24.798763
# Unit test for constructor of class Schema
def test_Schema():
    assert callable(Schema)
    assert not callable(Schema('test'))

# Generated at 2022-06-23 22:11:28.988321
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    try:
        field = AbstractField('en')
    except Exception as e:
        assert str(e) == 'Schema do not supported by provider.'
    else:
        assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:30.485943
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    schema = Schema(lambda: {'data': 'test'})
    assert schema.create() == [{'data': 'test'}]

# Generated at 2022-06-23 22:11:34.729846
# Unit test for method create of class Schema
def test_Schema_create():
    field = Field()
    schema = Schema(lambda: {
        'name': field('name'),
        'surname': field('surname'),
        'address': field('address'),
    })

    result = schema.create(iterations=3)
    assert isinstance(result, list)
    assert len(result) == 3

# Generated at 2022-06-23 22:11:36.062421
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    class C(AbstractField):
        pass

    assert str(C()) == 'C <en>'

# Generated at 2022-06-23 22:11:38.130626
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test AbstractField.__str__."""
    field = Field()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:40.791292
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'
    f.locale = 'ru'
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:11:42.443730
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert AbstractField


# Generated at 2022-06-23 22:11:44.651033
# Unit test for method create of class Schema
def test_Schema_create():

    @Schema
    def schema() -> Field:
        return Field()

    assert len(schema.create(10)) == 10

# Generated at 2022-06-23 22:11:50.326078
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    provider = Generic('en')
    field = AbstractField('en', providers=provider)

    assert field('uuid') == provider.uuid()
    assert field('provider.uuid') == provider.provider.uuid()
    assert field('uuid', times=2, separator='-') == provider.uuid(2, '-')

# Generated at 2022-06-23 22:12:01.446837
# Unit test for method create of class Schema
def test_Schema_create():
    """Test creating schemas by Schema."""
    from mimesis.builtins import RussiaSpecProvider

    address = RussiaSpecProvider.Address(seed=12345678)
    address_schema = address.create_schema()
    schema = Schema(address_schema)
    result = schema.create(iterations=2)

# Generated at 2022-06-23 22:12:05.786874
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    field = Field(seed=12345)

    assert field('uuid') is not None
    assert field('uuid', key=str) is not None



# Generated at 2022-06-23 22:12:11.609883
# Unit test for method create of class Schema
def test_Schema_create():
    """Check return value from method create of class Schema."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person()

    def schema() -> JSON:
        """Simple schema."""
        return {
            'name': person.full_name(gender=Gender.FEMALE),
            'location': person.address.city(),
        }

    s = Schema(schema)
    result = s.create(iterations=5)
    assert result is not None
    assert result != []
    assert isinstance(result, list)
    assert len(result) == 5
    assert isinstance(result[0], dict)
    assert isinstance(result[0]['name'], str)
    assert isinstance(result[0]['location'], str)

# Generated at 2022-06-23 22:12:13.118339
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert 'AbstractField' in str(f)

# Generated at 2022-06-23 22:12:14.982516
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:16.858685
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    field_name = 'person.full_name'
    result = field(field_name)
    assert result

# Generated at 2022-06-23 22:12:26.614264
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """To check AbstractField.__call__."""
    import inspect

    field = Field()
    print(field('time.time'))
    print(field('time.time', sep='-'))

    import pytest
    with pytest.raises(UnsupportedField):
        print(field('undefined'))

    with pytest.raises(UnacceptableField):
        print(field('time.time.sep'))

    time_spec = inspect.getfullargspec(
        field('time.time')).args + inspect.getfullargspec(
            field('time.time')).kwonlyargs

    for arg in time_spec:
        print(field('time.time', **{arg: arg}))



# Generated at 2022-06-23 22:12:30.964261
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Create an instance of Field
    gen = Field()

    # Declare some variables
    field = 'first_name'
    kwargs = {}

    # Call method __call__ of gen
    result = gen(field, **kwargs)
    assert isinstance(result, str)



# Generated at 2022-06-23 22:12:33.123338
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for repr of Abstract Field."""
    field = AbstractField()
    assert isinstance(field.__str__(), str)

# Generated at 2022-06-23 22:12:44.249426
# Unit test for method create of class Schema
def test_Schema_create():
    """
    Test create method of Schema class.
    Check the create method of the Schema class,
    which must return a list of JSON objects,
    the element of which corresponds to the schema.

    """
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.finance import Finance
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.schema import Field

    class User:
        """Class for testing."""

        @staticmethod
        def schema() -> JSON:
            """Test method."""
            provider = Field(
                providers=[Person, Text, Finance, RussiaSpecProvider])


# Generated at 2022-06-23 22:12:47.615607
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': 'ADmin'
    }

    def test_schema():
        return schema

    sch = Schema(test_schema)
    sch.create(iterations=10)

# Generated at 2022-06-23 22:12:49.097069
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f(name='full_name')

# Generated at 2022-06-23 22:12:54.171824
# Unit test for method create of class Schema
def test_Schema_create():
    counter = 0

    def s() -> JSON:
        nonlocal counter
        counter += 1
        return {
            'name': 'name{}'.format(counter),
            'age': counter,
        }

    schema = Schema(s)
    result = schema.create(iterations=5)

    assert isinstance(result, list)
    assert len(result) == 5
    for item in result:
        assert item['name'] == 'name{}'.format(result.index(item) + 1)
        assert item['age'] == result.index(item) + 1

# Generated at 2022-06-23 22:12:55.009533
# Unit test for constructor of class Schema
def test_Schema():
    assert isinstance(Schema(lambda: dict()), Schema)


# Generated at 2022-06-23 22:12:56.821815
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema():
        return {
            'name': 'test',
            'description': 'test',
            'price': 0.1,
        }

    Schema(schema=test_schema)

# Generated at 2022-06-23 22:12:58.876844
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    #  check case when provider not supported
    field = Field()
    assert field('test') is None

# Generated at 2022-06-23 22:13:00.385002
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    a = Field()
    assert str(a) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:02.131250
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert callable(field)



# Generated at 2022-06-23 22:13:11.525158
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test Field.__call__().

    :param field: AbstractField object
    :return: None
    :raises AssertionError: If test failed.
    """
    field = Field(locale='en', seed=None)

    # Test with normal field
    res = field('random_int', min_value=1, max_value=100)
    assert isinstance(res, int)
    assert res >= 1
    assert res <= 100

    # Test with key function
    def custom_key(value: int) -> str:
        return str(value)

    res = field('random_int', min_value=1, max_value=100, key=custom_key)
    assert isinstance(res, str)

    # Test with specific field
    res = field('payload.fullname')

# Generated at 2022-06-23 22:13:12.869859
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'Field <en>'

# Generated at 2022-06-23 22:13:14.280944
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for class AbstractField."""
    f = Field()
    assert f is not None
    assert callable(f)

# Generated at 2022-06-23 22:13:17.897474
# Unit test for method create of class Schema
def test_Schema_create():
    """Test create method of class Schema."""
    schema = Schema(lambda: {})
    assert schema.create(iterations=2) == [{}, {}]

# Generated at 2022-06-23 22:13:24.620376
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.text import Text
    from mimesis.schema import Schema
    from mimesis.providers.person.names import MaleName, FemaleName
    from mimesis.schema import Field

    class NameSchema(Schema):
        def schema(self) -> JSON:
            return {
                'name': Field(self).name(gender='male'),
                'age': Field(self).age(minimum=18, maximum=99),
            }

    schemas = NameSchema(NameSchema.schema)

    assert isinstance(schemas.create(2), list)
    assert isinstance(schemas.create(2)[0], dict)
    assert len(schemas.create(10)) == 10

    # Add provider
    Text.add_provider(MaleName)
   

# Generated at 2022-06-23 22:13:26.740353
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of class Schema."""
    assert isinstance(Schema({}), Schema)



# Generated at 2022-06-23 22:13:31.056562
# Unit test for constructor of class Schema
def test_Schema():
    """Test class Schema."""
    try:
        # Test defined schema
        Schema(lambda: {'foo': 'bar'})
    except Exception as e:
        print(e)
    else:
        assert True

    # Test undefined schema
    try:
        Schema('foo')
    except Exception as e:
        assert str(e) == 'Schema must be callable object'

# Generated at 2022-06-23 22:13:32.818216
# Unit test for method create of class Schema
def test_Schema_create():
    assert not Schema.create()


if __name__ == '__main__':  # pragma: no cover
    test_Schema_create()

# Generated at 2022-06-23 22:13:35.939593
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    schema = Schema(lambda: {'key': 'value'})
    assert len(schema.create(iterations=1)) == 1

    assert len(schema.create(iterations=2)) == 2
    assert len(schema.create(iterations=3)) == 3

# Generated at 2022-06-23 22:13:37.482703
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:13:40.214749
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'id': lambda: 2, 'pet': lambda: 'horse'}

    s = Schema(schema)
    assert s.create(2) == [schema, schema]

# Generated at 2022-06-23 22:13:43.011450
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        data = {
            'name': Field()
        }
        return data

    assert Schema(schema) is not None


# Generated at 2022-06-23 22:13:44.768582
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    _ = str(field)
    _ = repr(field)

# Generated at 2022-06-23 22:13:48.095337
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field(locale='en')
    assert str(field) == 'AbstractField <en>'

    field = Field(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:13:48.640866
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field()

# Generated at 2022-06-23 22:13:50.501176
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {'name': 'Vasya'})
    assert len(schema.create()) == 1



# Generated at 2022-06-23 22:13:54.480936
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field('first_name')
    assert field('first_name', male=False)
    assert field('get_color')
    assert field('get_color', key=lambda x: x.upper())
    assert field('Person.first_name')
    assert field('Person.get_color')



# Generated at 2022-06-23 22:13:55.529449
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert Field().__call__('email') is not None

# Generated at 2022-06-23 22:14:03.269340
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField(locale='en')
    assert field('uuid')

    # More examples of how AbstractField will work
    assert bool(field('bool'))
    assert 'Yes' in field('bool_str')
    assert 'No' in field('bool_str')
    assert len(field('bytes', size=1024)) == 1024
    assert field('language_code', locale=True).upper() in field('language')

    assert field('string', length=10)
    assert field('py_string', length=10)
    assert field('timestamp')
    assert field('email')
    assert field('domain')
    assert field('url')
    assert field('ipv4')
    assert field('ipv6')
    assert field('mac_address')

    # More examples of how AbstractField will work

# Generated at 2022-06-23 22:14:06.844695
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField constructor.

    :return: None.
    """
    f = AbstractField(locale='de')
    assert f.locale == 'de'

# Generated at 2022-06-23 22:14:07.998098
# Unit test for method create of class Schema
def test_Schema_create():
    # TODO: Need test
    pass

# Generated at 2022-06-23 22:14:13.109441
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': AbstractField(),
            'age': AbstractField(key=lambda v: v * 2),
        }

    s = Schema(schema)
    data = s.create(iterations=2)
    assert len(data) == 2
    assert data[0]['name'] is not None
    assert data[0]['age'] is not None

# Generated at 2022-06-23 22:14:21.127871
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    field2 = AbstractField(locale='fr')
    field3 = AbstractField(providers=['datetime'])
    field4 = AbstractField(seed=42)
    field5 = AbstractField(locale='fr', seed=42)
    assert field._gen.locale == 'en'
    assert field2._gen.locale == 'fr'
    assert 'datetime' in [i.__name__ for i in field3._gen.providers]
    assert field4._gen.seed == 42
    assert field5._gen.locale == 'fr'
    assert field5._gen.seed == 42



# Generated at 2022-06-23 22:14:22.414587
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert isinstance(str(field), str)

# Generated at 2022-06-23 22:14:23.722752
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(Field)
    assert isinstance(schema, Schema)

# Generated at 2022-06-23 22:14:28.610861
# Unit test for constructor of class AbstractField
def test_AbstractField():
    provider = Generic('ru', lambda: 'test')
    field = Field(locale='ru', providers=[provider])
    assert field._gen.provider.locale == 'ru'
    assert field._gen.provider.seed() == 'test'
    assert field.locale == 'ru'

# Generated at 2022-06-23 22:14:33.624886
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Check if method works correctly."""
    from mimesis.providers.weather import Weather
    from mimesis.enums import WeatherConditions

    field = Field(providers=[Weather()])

    assert isinstance(field('WEATHER'), str)
    assert isinstance(field('WEATHER',
                            key=lambda x: x.get(WeatherConditions.TEMPERATURE)),
                      dict)

# Generated at 2022-06-23 22:14:35.088823
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()

    assert f.locale == 'en'
    assert f.seed is None
    assert f('person.full_name')

# Generated at 2022-06-23 22:14:36.886365
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField(locale='ru')) == 'AbstractField <ru>'


# Generated at 2022-06-23 22:14:41.286985
# Unit test for method create of class Schema
def test_Schema_create():
    f = Field()
    schema = Schema(f.name)
    assert schema.create()
    assert len(schema.create()) == 1
    assert len(schema.create(10)) == 10
    assert len(schema.create(100)) == 100


# Generated at 2022-06-23 22:14:42.291309
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass


# Generated at 2022-06-23 22:14:43.896965
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""


# Tests for class Schema

# Generated at 2022-06-23 22:14:46.439884
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema([
        {'a': 'b'}
    ])

