

# Generated at 2022-06-23 22:04:32.138593
# Unit test for constructor of class Schema
def test_Schema():
    schema = [{'name': 'foo', 'age': 'bar'}]
    obj = Schema(schema)
    assert obj.create() == schema

# Generated at 2022-06-23 22:04:33.485515
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:04:37.972274
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract = AbstractField(providers=['datetime'])
    field_key = abstract('get_time', key=lambda x: x.strftime('%A, %d. %B %Y %I:%M%p'))
    print(field_key)


# Run test
if __name__ == '__main__':
    test_AbstractField___call__()

# Generated at 2022-06-23 22:04:41.341092
# Unit test for constructor of class Schema
def test_Schema():
    schema = {
        'name': Field('en', 'a seed'),
        'age': Field('en', 'seed', providers=['provider'])
    }

    s = Schema(schema)

    assert isinstance(s, Schema)
    assert isinstance(s.schema, type(schema))

# Generated at 2022-06-23 22:04:48.367985
# Unit test for method create of class Schema
def test_Schema_create():
    _schema = {
        "name": "John Doe",
        "age": 30,
        "birthday": "1999-03-03",
        "username": "jdoe123",
        "uuid": "6fa459ea-ee8a-3ca4-894e-db77e160355e",
        "address": "20 W 34th St, New York, NY 10001",
    }

    def schema() -> JSON:
        """Return filled schema."""
        return {
            "name": Field().name(),
            "age": Field().age(),
            "birthday": Field().datetime(start=1970, end=2000),
            "username": Field().username(),
            "uuid": Field().uuid(version=3),
            "address": Field().address(),
        }

    _schema_test

# Generated at 2022-06-23 22:04:51.067497
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: 'test')

    for i in range(3):
        assert schema.create(iterations=i) == ['test'] * i



# Generated at 2022-06-23 22:04:52.435182
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert type(Field('en')('word', key=str)) is str

# Generated at 2022-06-23 22:04:59.686332
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of AbstractField."""
    field = Field()
    assert callable(field)

    value = field('name')
    assert isinstance(value, str)

    value = field('name.first_name')
    assert isinstance(value, str)

    value = field('choice', choices=['a', 'b'])
    assert isinstance(value, str)
    assert value in ['a', 'b']

    value = field('choice', choices={'a', 'b'})
    assert isinstance(value, str)
    assert value in ['a', 'b']

    value = field('choice', choices=False)
    assert isinstance(value, bool)
    assert value in [True, False]

    value = field('unique', limit=10)
    assert isinstance(value, int)

# Generated at 2022-06-23 22:05:07.774290
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for class Schema and method create."""
    from mimesis.schema import Field

    schemas = [
        {'key': Field('text')},
        {'key': Field('text')},
        {'key': Field('text')},
        {'key': Field('text')},
        {'key': Field('text')},
    ]

    data = Schema(lambda: schemas).create(5)
    assert isinstance(data, list)
    assert len(data) == 5
    assert isinstance(data[0], dict)

# Generated at 2022-06-23 22:05:08.544184
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()

    assert isinstance(f, AbstractField)



# Generated at 2022-06-23 22:05:09.490158
# Unit test for method create of class Schema
def test_Schema_create():
    """."""
    pass

# Generated at 2022-06-23 22:05:13.460649
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema

    def schema():
        return {'name': 'Vasya', 'age': 28}

    s = Schema(schema=schema)
    assert isinstance(s, Schema)



# Generated at 2022-06-23 22:05:15.639019
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for class AbstractField."""
    f = Field('ru')
    assert str(f).startswith('AbstractField')

# Generated at 2022-06-23 22:05:17.372622
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:05:24.421444
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    from mimesis.providers.programming import Programming

    class TestClass(AbstractField):
        """Test class with the same constructor."""

    assert len(TestClass()._gen.providers) == 32  # 32 is default count

    custom_gen = Generic(locale='en')
    custom_gen.add_providers(Programming)

    assert len(TestClass(providers=custom_gen)._gen.providers) == 33

# Generated at 2022-06-23 22:05:27.260240
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test AbstractField.__str__."""
    assert str(AbstractField(locale='ru',
                             seed=123)) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:05:30.821544
# Unit test for constructor of class AbstractField
def test_AbstractField():
    def key(value):
        return value

    f = AbstractField()
    expected = key(f('email', key=key, domain='example.org'))
    generated = 'random.example.org'

    assert expected == generated

# Generated at 2022-06-23 22:05:42.037982
# Unit test for method __call__ of class AbstractField

# Generated at 2022-06-23 22:05:51.039410
# Unit test for method create of class Schema
def test_Schema_create():
    from tests.data.schemas import SimpleFieldsSchema, ScalarSchema

    f = Field()

    s = Schema(SimpleFieldsSchema)
    data = s.create(10)

    for row in data:
        assert row['name'] == f.person.name()
        assert row['date'] == f.datetime.date()
        assert row['date_full'] == f.datetime.date(full=True)

    # Test scalar schema
    s = Schema(ScalarSchema)
    assert isinstance(s.create(), dict)
    assert s.create()['name'] == f.person.name()
    assert s.create(1) == [{'name': f.person.name()}]

# Generated at 2022-06-23 22:05:52.641846
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField(locale='ru', seed=42)
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:05:55.364961
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert field.__str__() == 'AbstractField <en>'

    field = AbstractField(locale='ru')
    assert field.__str__() == 'AbstractField <ru>'

# Generated at 2022-06-23 22:05:57.517571
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'
    f = Field('ru')
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:06:00.219848
# Unit test for method create of class Schema
def test_Schema_create():
    """Test that create() returns a list of filled schemas."""
    schema = {'constant': 1}
    s = Schema(lambda: schema)
    assert isinstance(s.create(3), list)



# Generated at 2022-06-23 22:06:04.665271
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema
    from mimesis.schema import Field
    from mimesis.schema import UnacceptableField
    from mimesis.schema import UndefinedSchema

    provider = Field()
    schema = Schema(provider)
    schema.create()

# Generated at 2022-06-23 22:06:14.269256
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis import Person, Address

    schema = Schema(
        Person(seed=1).schema(
            {
                'name': 'full_name',
                'age': 'age',
                'gender': 'gender',
                'address': {
                    'city': 'city',
                    'country': 'country',
                },
            }
        )
    )
    result = schema.create()
    assert result == [{'name': 'Alice Mullen', 'age': 18,
                       'gender': 'female',
                       'address': {'city': 'Lindsay', 'country': 'Turkey'}}]


# Generated at 2022-06-23 22:06:17.891849
# Unit test for method create of class Schema
def test_Schema_create():
    import mimesis.schema

    def schema():
        """Generate schema."""
        return {
            'field': mimesis.schema.Field(),
        }

    assert len(Schema(schema).create(1)) == 1
    assert len(Schema(schema).create(2)) == 2

# Generated at 2022-06-23 22:06:20.458348
# Unit test for constructor of class Schema
def test_Schema():
    class _Schema:
        def __call__(self):
            return 1

    try:
        Schema(_Schema())
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-23 22:06:21.392861
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema(1) == UndefinedSchema()

# Generated at 2022-06-23 22:06:23.623669
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Ensure __str__ result."""
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:25.418046
# Unit test for constructor of class Schema
def test_Schema():
    foo = {'key': 'value'}

    Schema(foo)

# Generated at 2022-06-23 22:06:27.131680
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: "schema")
    assert schema.create() == ['schema']

# Generated at 2022-06-23 22:06:34.711128
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'username': '<username()>',
        'password': '<password()>',
        'email': '<email()>',
    }

    user_schema = Schema(schema)
    entries = user_schema.create(10)
    assert len(entries) == 10
    assert type(entries) == list
    assert type(entries[0]) == dict
    assert entries[0]['username'] is not None
    assert entries[0]['password'] is not None
    assert entries[0]['email'] is not None

# Generated at 2022-06-23 22:06:42.672996
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis import Person
    from mimesis.enums import Gender
    from mimesis.typing import JSON


    class TSchema:
        @staticmethod
        def generate_schema() -> JSON:
            return {
                'first_name': Person('en').full_name(),
                'last_name': Person('en').full_name(),
                'gender': Person('en').gender(),
                'age': Person('en').age(),
                'address': Person('en').address(),
            }

    ts = TSchema()
    schema = Schema(ts.generate_schema)

    assert schema.create(0) == []
    assert isinstance(schema.create(1), list)

    result = schema.create(10)
    assert len(result) == 10

# Generated at 2022-06-23 22:06:45.215008
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    provider = AbstractField('ru')
    assert str(provider) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:06:54.974062
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person

    def schema_factory() -> dict:
        """Return schema filled by arguments."""
        datetime = Datetime(locale='ru')
        person = Person('ru')
        return {
            'title': person.full_name(),
            'date': datetime.date(),
            'time': datetime.time(),
        }

    schema = Schema(schema_factory)

# Generated at 2022-06-23 22:07:00.233976
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> SchemaType:
        field = Field()
        return {
            'name': field('full_name'),
            'email': field('email'),
            'gender': field('gender'),
            'age': field('age'),
            'status': field('marital_status'),
        }
    p = Schema(schema)
    assert len(p.create(iterations=5)) == 5

# Generated at 2022-06-23 22:07:01.656337
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('name') == 'unknown'



# Generated at 2022-06-23 22:07:04.210999
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField constructor."""
    f = Field()
    assert isinstance(f.locale, str)
    assert isinstance(f.seed, int)
    assert isinstance(f._gen, Generic)
    assert not f._table

# Generated at 2022-06-23 22:07:09.546163
# Unit test for constructor of class Schema
def test_Schema():
    class TextMessage:
        def __init__(self, text: str, time: float) -> None:
            self.text = text
            self.time = time

    @Schema
    def message() -> TextMessage:
        text = Field('text.word')
        time = Field('datetime.timestamp')
        return TextMessage(text, time)

    msgs = message.create(iterations=10)

    assert len(msgs) == 10
    assert len(msgs[0].text) > 0
    assert msgs[0].time > 0

# Generated at 2022-06-23 22:07:13.285730
# Unit test for method create of class Schema
def test_Schema_create():
    def tschema() -> JSON:
        return {
            'name': 'Kirill',
            'age': 17,
        }

    schema = Schema(tschema)
    assert isinstance(schema.create(), list)

# Generated at 2022-06-23 22:07:16.299395
# Unit test for constructor of class Schema
def test_Schema():
    test_schema = lambda: [
        'a', 'b', 'c',
    ]
    schema = Schema(test_schema)
    assert schema.schema == test_schema


# Generated at 2022-06-23 22:07:18.099173
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    s = f.__str__()
    assert isinstance(s, str)

# Generated at 2022-06-23 22:07:19.727918
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:20.953083
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:22.640721
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda: {'key': 'value'})
    assert type(schema.create()) is list

# Generated at 2022-06-23 22:07:30.681107
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.base import BaseDataProvider

    class Provider(BaseDataProvider):

        class Meta:
            name = 'provider'

        def one(self):
            return 'one'

        def two(self):
            return 'two'

    # Create a field class with one provider
    class MyField(Field):

        def __init__(self, seed=None) -> None:
            super().__init__(seed=seed, providers=[Provider])

    # Create a schema
    def schema():
        return {
            'field1': MyField(seed=42).one(),
            'field2': MyField(seed=42).two(),
        }

    S = Schema(schema)
    res = S.create(iterations=5)

# Generated at 2022-06-23 22:07:32.442221
# Unit test for method create of class Schema
def test_Schema_create():
    def schema_1():
        return {'foo': 'bar'}

    assert Schema(schema_1).create(1) == [{'foo': 'bar'}]

# Generated at 2022-06-23 22:07:41.805566
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import Personal

    def key(value):
        return '{}'.format(value)

    field = AbstractField()
    assert field('name') == 'John'
    assert field('name', key=key) == 'John'
    assert field('name_male') == 'James'

    field = AbstractField('ru')
    assert field('name_male') == 'Иван'

    field = AbstractField('ru', providers=[Personal])
    assert field('name') == 'Борис'
    assert field('name_male') == 'Борис'
    assert field('name_male', kwargs={'gender': 'male'}) == 'Борис'

# Generated at 2022-06-23 22:07:47.512847
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    def sample_schema() -> JSON:
        return {
            'gender': Gender.MALE,
            'title': Person('en').title,
            'full_name': Person('en').full_name,
            'age': Person('en').age,
            'occupation': Person('en').occupation,
        }

    sc = Schema(sample_schema)
    assert len(sc.create(5)) == 5
    assert sc.create(3)[0]['gender'] == Gender.MALE

# Generated at 2022-06-23 22:07:48.562094
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert isinstance(f, AbstractField)

# Generated at 2022-06-23 22:07:49.573093
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField(locale='ru')
    assert f.locale == 'ru'

# Generated at 2022-06-23 22:07:52.693651
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""

    field = AbstractField()
    assert (field.locale == 'en')
    field = AbstractField('ru')
    assert (field.locale == 'ru')

# Generated at 2022-06-23 22:07:55.977262
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__."""
    field = Field()

    # Correct method
    assert field('name') is not None

    # Incorrect method
    assert field('incorrect') is None


# Generated at 2022-06-23 22:07:58.808143
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema.schema_factory import SchemaFactory
    assert isinstance(Schema(SchemaFactory()), Schema)


# Generated at 2022-06-23 22:07:59.360056
# Unit test for constructor of class Schema
def test_Schema():
    assert False

# Generated at 2022-06-23 22:08:01.885728
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:04.090009
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor of class Schema."""
    # Schema init
    s = Schema(lambda: None)
    assert isinstance(s, Schema), "Should be a Schema"

# Generated at 2022-06-23 22:08:06.045277
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)
    return field


# Generated at 2022-06-23 22:08:14.911456
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method Schema.create,
    check if it's generate json schema.
    """
    from mimesis.schema import Field
    from mimesis.providers import Person

    field = Field(locale='en', providers=[Person()])

    json_schema = {
        "name": field('formatter', pattern='{L} {N.initials}'),
        "surname": field('surname'),
        "age": field('age'),
        "is_adult": field('bool'),
        "address": {
            "country": field('country'),
            "region": field('region'),
            "city": field('city'),
            "street": field('street_name'),
        },
    }

    schema = Schema(json_schema)
    list_of_schemas = schema.create

# Generated at 2022-06-23 22:08:18.099162
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    def _test(name, kwargs, result):
        f = Field()
        assert f(name, **kwargs) == result

    _test('ipv4', {}, '192.168.0.1')

# Generated at 2022-06-23 22:08:21.052347
# Unit test for method create of class Schema
def test_Schema_create():
    import mimesis.builtins.schema

    s = Schema(mimesis.builtins.schema.USAddressSchema)
    assert len(s.create(10)) == 10

# Generated at 2022-06-23 22:08:22.168193
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema(lambda: dict(x='x'))



# Generated at 2022-06-23 22:08:27.240467
# Unit test for method create of class Schema
def test_Schema_create():
    def scheme():
        return {
            'first_name': Field('person').name(),
            'last_name': Field('person').surname(),
        }

    schema_obj = Schema(scheme)
    assert len(schema_obj.create()) == 1
    assert len(schema_obj.create(5)) == 5


# Generated at 2022-06-23 22:08:29.680171
# Unit test for method create of class Schema
def test_Schema_create():
    data = [{'id': 1}, {'id': 2}]
    schema = Schema(lambda: data)
    assert schema.create(1) == [data]

# Generated at 2022-06-23 22:08:38.808237
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    a = AbstractField()
    first_name = a('first_name')
    assert first_name is not None
    last_name = a('last_name')
    assert last_name is not None
    full_name = a('full_name', ln=last_name)
    assert full_name is not None
    title = a('title')
    assert title is not None
    assert title in title.upper()
    text = a('text', max_symbols=100)
    assert text is not None
    assert len(text) <= 100

# Generated at 2022-06-23 22:08:39.659484
# Unit test for constructor of class AbstractField
def test_AbstractField():
    af = AbstractField()
    assert af is not None

# Generated at 2022-06-23 22:08:42.102771
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field



# Generated at 2022-06-23 22:08:43.597938
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:51.561588
# Unit test for method create of class Schema
def test_Schema_create():  # noqa: D202
    from mimesis.schema import AnyString, Boolean, Integer, Schema

    @Schema
    class AnyData:
        i = Integer()
        b = Boolean()
        s = AnyString()

    schema = AnyData().create(5)
    assert len(schema) == 5

    for item in schema:
        assert isinstance(item, dict)
        assert set(['i', 'b', 's']) == set(item.keys())
    # End of unit test for method create of class Schema

# Generated at 2022-06-23 22:08:52.308279
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(Field(), AbstractField)



# Generated at 2022-06-23 22:08:54.075741
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert field('datetime') is not None

# Generated at 2022-06-23 22:08:55.918513
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField."""
    field = AbstractField()
    assert str(field)

# Generated at 2022-06-23 22:08:56.948484
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema is not None


# Generated at 2022-06-23 22:09:00.650429
# Unit test for method create of class Schema
def test_Schema_create():
    from decimal import Decimal

    from mimesis.providers import DateTime

    class CustomDateTime(DateTime):
        @DateTime.timestamp.overload(raw=True)
        def timestamp(self) -> int:
            """Return timestamp."""
            return 1525152000

        def num(self) -> Decimal:
            """Return number.

            :return: Decimal('3.14')
            """
            return Decimal('3.14')

    def schema():
        """Return custom schema."""

# Generated at 2022-06-23 22:09:11.095713
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    class FilledSchema:

        def __init__(self, field: AbstractField = Field()) -> None:
            """Initialize filled schema.

            :param field: Field of data.
            """
            self.field = field

        def __call__(self) -> JSON:
            """Override standard call.

            :return: Dict of filled data.
            """
            return {
                'name': self.field('person.full_name'),
                'age': self.field('datetime.year'),
                'address': self.field('address.address'),
            }

    test_schema = Schema(FilledSchema)

# Generated at 2022-06-23 22:09:16.262773
# Unit test for constructor of class Schema
def test_Schema():
    from random import randint

    from mimesis.enums import Gender

    def schema() -> JSON:
        return {
            'full_name': Field('en').full_name(gender=Gender.FEMALE),
            'amount': Field().amount(min_value=10, max_value=100)
        }

    sch = Schema(schema)
    result = sch.create(iterations=randint(1, 10))
    assert isinstance(result, list), True

# Generated at 2022-06-23 22:09:25.176613
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Create instance of AbstractField class and check that everything works."""
    gen = AbstractField()
    assert gen('money.amount')

    assert gen('fake.email', locale='ru') == gen.create(locale='ru',
                                                        name='fake.email')
    assert gen('fake.email', locale='ru') != gen.create(locale='en',
                                                        name='fake.email')

    assert gen('fake.email', locale='ru', seed=1) == gen.create(locale='ru',
                                                                name='fake.email',
                                                                seed=1)
    assert gen('fake.email', locale='ru', seed=1) != gen.create(locale='ru',
                                                                name='fake.email',
                                                                seed=2)


# Generated at 2022-06-23 22:09:26.496030
# Unit test for constructor of class Schema
def test_Schema():
    pass

# Generated at 2022-06-23 22:09:32.251824
# Unit test for method create of class Schema
def test_Schema_create():
    """Test :meth:`.Schema.create`."""
    from mimesis.builtins import RussiaSpecProvider

    schema = Schema(lambda: Field(
        'ru',
        providers=[RussiaSpecProvider],
    ).inn)

    schemas = schema.create(iterations=10)

    assert all(map(lambda row: len(row) == 12, schemas))
    assert all(schemas)

# Generated at 2022-06-23 22:09:37.889285
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit for method __call__ of class AbstractField."""
    provider = AbstractField()

    # name = None
    try:
        provider()
    except UndefinedField:
        pass

    # if field not in data provider
    try:
        provider('foo')
    except UnsupportedField:
        pass

    # if field not in any data provider
    try:
        provider('foo.bar')
    except UnacceptableField:
        pass

# Generated at 2022-06-23 22:09:40.370729
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test of AbstractField constructor."""
    field = AbstractField('en')
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:09:46.226258
# Unit test for constructor of class Schema
def test_Schema():  # noqa: D102
    def create_schema() -> JSON:
        return {
            'first_name': Field().personal.full_name(),
            'last_name': Field().personal.last_name(),
            'age': Field().numerical.uint8(),
            'city': Field().address.city(),
        }

    schema = Schema(create_schema)
    assert schema is not None

# Generated at 2022-06-23 22:09:48.159089
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method of AbstractField __str__."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:51.235767
# Unit test for constructor of class Schema
def test_Schema():
    def test_field() -> str:
        return 'Test'

    field = test_field() # noqa

    assert Schema(field) is not None

# Generated at 2022-06-23 22:09:52.559410
# Unit test for constructor of class Schema
def test_Schema():
    assert isinstance(Schema({}), Schema)



# Generated at 2022-06-23 22:10:00.897718
# Unit test for method create of class Schema
def test_Schema_create():
    # unit tests for class Schema
    from datetime import date, time
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.date import Date
    from mimesis.providers.sanitize import Sanitize
    from mimesis.providers.geo import Geo
    from mimesis.providers.payment import Payment
    from mimesis.providers.network import Network

    person = Person('en', seed=123)
    date_provider = Date('zh', seed=123)
    sanitize = Sanitize('th', seed=123)
    geo = Geo('kk', seed=123)
    payment = Payment('hi', seed=123)
    networking = Network('sr', seed=123)


# Generated at 2022-06-23 22:10:07.543786
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> JSON:  # noqa: F741
        return {'name': 'John', 'age': 25, 'city': 'New York'}

    my_schema = Schema(schema)
    assert isinstance(my_schema, Schema)
    assert isinstance(my_schema.schema, JSON)
    assert isinstance(my_schema.create(), list)
    assert isinstance(my_schema.create(3)[1], JSON)



# Generated at 2022-06-23 22:10:09.287837
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('__str__') # noqa: WPS441


# Generated at 2022-06-23 22:10:15.495002
# Unit test for constructor of class Schema
def test_Schema():
    class BasicSchema:

        def schema(self) -> JSON:
            return {
                'name': self.field.first_name(),
                'surname': self.field.last_name(),
                'age': self.field.age(),
                'sex': self.field.sex(),
            }

    schema_object = BasicSchema()
    generator = Schema(schema_object.schema)
    result = generator.create()
    print(result)

    assert isinstance(result, list)
    assert len(result) == 1

# Generated at 2022-06-23 22:10:16.985087
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema(lambda: {})
    assert isinstance(s, Schema)

# Generated at 2022-06-23 22:10:18.319863
# Unit test for method create of class Schema
def test_Schema_create():
    assert isinstance(Schema(lambda: {}).create(iterations=3), list)

# Generated at 2022-06-23 22:10:19.888858
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'


# Generated at 2022-06-23 22:10:26.109265
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis import Person
    from mimesis.schema import Schema
    from mimesis.schema.serializers import Serializer

    p = Person('en')
    s = Serializer('en')

    schema = Schema(p.get_schema().create)

# Generated at 2022-06-23 22:10:33.883909
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema."""
    from mimesis.enums import Gender

    def person() -> JSON:
        """Generate a dictionary with personal data."""
        field = Field()
        return dict(
            name=field('full_name', gender=Gender.FEMALE),
            age=field('age', minimum=20, maximum=60),
            phone=field('phone_number'),
        )

    people = Schema(person)
    results = people.create(5)
    assert isinstance(results, list)
    assert len(results) == 5



# Generated at 2022-06-23 22:10:35.933749
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'a': 1, 'b': 2}
    assert isinstance(Schema(lambda: schema).create(2), list)

# Generated at 2022-06-23 22:10:44.435587
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('en_US') == 'en_US'
    assert field('en') == 'en'
    assert field('en_GB') == 'en_GB'
    assert field('ru') == 'ru'
    assert field('es') == 'es'
    assert field('de') == 'de'
    assert field('uk') == 'uk'
    assert field('fr') == 'fr'
    assert field('zh') == 'zh'
    assert field('it') == 'it'
    assert field('vi') == 'vi'
    assert field('pt') == 'pt'



# Generated at 2022-06-23 22:10:54.880892
# Unit test for method create of class Schema
def test_Schema_create():
    from pydantic import BaseModel

    from mimesis.providers.person import Person

    def schema_creator() -> BaseModel:
        """Create schema."""
        return BaseModel(
            title=Field(
                'person.honorific_prefix',
                key=lambda x: x.title()
            ),
            full_name=Field(
                'person',
                key=lambda x: x.capitalize()
            )
        )

    s = Schema(schema_creator)
    result = s.create(iterations=1)
    print(result)
    assert isinstance(result[0], BaseModel)
    assert isinstance(result[0].full_name, str)
    assert isinstance(result[0].title, str)


# Generated at 2022-06-23 22:10:57.929394
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """
    Create an object of class AbstractField
    and get string representation of it.

    Check that the result is the same as expected.
    """
    field = Field()
    observed = str(field)
    expected = 'AbstractField <en>'

    assert observed == expected

# Generated at 2022-06-23 22:11:08.294054
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():  # noqa
    """Test for AbstractField.__call__.

    It passes all methods of the data provider
    and kwargs of the current method if it has.

    For example, method ``uuid4`` of ``system`` data provider
    has no kwargs, so it returns uuid4 of the current system.

    .. code-block:: python

        from mimesis.schema import AbstractField
        field = AbstractField()
        field('uuid4')  # returns uuid4

    And the method ``personal.email`` has kwargs ``mask``,
    so it returns email with the current mask.

    .. code-block:: python

        field('personal.email', mask='*')  # returns email with '*'

    """
    field = AbstractField()
    assert '\n' not in field('public_suffix')

# Generated at 2022-06-23 22:11:12.291459
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') is not None
    assert field('timestamp') is not None
    assert field('name', phase=2) is not None
    assert field('name', gender='female') is not None

# Generated at 2022-06-23 22:11:13.606155
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None



# Generated at 2022-06-23 22:11:16.812347
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schemas import Schema
    from mimesis.providers.address import Address

    schema = Schema('address')

    result = schema.create()
    assert isinstance(result, list)
    for item in result:
        assert isinstance(item, Address)

# Generated at 2022-06-23 22:11:18.123725
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test abstract field."""
    obj = AbstractField()
    assert obj is not None

# Generated at 2022-06-23 22:11:19.100836
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:21.389030
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import AbstractField

    schema = Schema(AbstractField)

    assert schema is not None



# Generated at 2022-06-23 22:11:31.587462
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test the method __call__ from class AbstractField.

    It checks the method. The parameters must be only strings.
    If there is no such method, it will raise the exception.
    """
    f = AbstractField()

    with assert_raises(UndefinedField):
        f()

    # Check that the method is called
    f('datetime.datetime')
    # f('datetime.datetime', 1234, 5678)

    with assert_raises(UnsupportedField):
        f('undefined_method')

    # Acceptable method
    f('user_agent.chrome')

    # Unacceptable method
    with assert_raises(UnacceptableField):
        f('user_agent.chrome.stable')

# Generated at 2022-06-23 22:11:34.275793
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for AbstractField.__str__ method."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

    field = AbstractField('ru')
    assert str(field) == 'AbstractField <ru>'



# Generated at 2022-06-23 22:11:45.496937
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()

    assert f.locale == 'en'
    assert f('datetime.timestamp')
    assert f('datetime.timestamp', min_year=2010)
    assert f('person.full_name')
    assert f('person.full_name', key=str.title)
    assert f('json.loads', key=lambda x: x,
             data={'test': 'test'})

    try:
        f('test')
    except UndefinedField:
        pass

    try:
        f('test', key=lambda x: x)
    except UnsupportedField:
        pass

    try:
        f('test.test')
    except UnsupportedField:
        pass

    try:
        f('test.test.test', key=lambda x: x)
    except UnacceptableField:
        pass

# Generated at 2022-06-23 22:11:46.356907
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    provider = AbstractField()
    assert str(provider) is not None

# Generated at 2022-06-23 22:11:48.251440
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert repr(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:11:49.765191
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():  # noqa
    f = Field()
    assert 'Field' in str(f)

# Generated at 2022-06-23 22:11:51.160260
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()

    assert isinstance(field, AbstractField)


# Generated at 2022-06-23 22:11:58.229409
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method ``create`` of class Schema."""
    schema = {
        'id': 0,
        'name': 'John Doe',
        'email': 'john.doe@example.net',
    }

    field = Field()

    def func() -> JSON:
        return {
            'id': field('uuid'),
            'name': field('name'),
            'email': field('email'),
        }

    instance = Schema(func)
    generated = instance.create()
    sample = generated[0]

    assert sample == schema
    assert generated[1] != schema

# Generated at 2022-06-23 22:12:00.487558
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField('ru')) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:12:05.825045
# Unit test for constructor of class Schema
def test_Schema():
    class Foo:
        """docstring"""
        def __call__(self):
            return {}

    noncallable_schema = {}
    callable_schema = Foo()

    try:
        Schema(noncallable_schema)
    except TypeError:
        Schema(callable_schema)

# Generated at 2022-06-23 22:12:08.615310
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for AbstractField.__str__()."""
    assert (str(AbstractField()).startswith('AbstractField'))

# Generated at 2022-06-23 22:12:11.074153
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField."""
    field = AbstractField()

    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:16.490852
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    methods = [f.datetime.datetime, f.datetime.time, f.datetime.date]
    for method in methods:
        assert method() == [f('datetime.datetime')(),
                            f('datetime.time')(),
                            f('datetime.date')()]

# Generated at 2022-06-23 22:12:21.287229
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.providers.vi import VI

    data = {
        'locale': 'ru',
        'seed': 42,
        'providers': [VI]
    }
    field = Schema(AbstractField(**data))
    print(field)

# Generated at 2022-06-23 22:12:23.027479
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(lambda: {'name': 'John'})
               .create(3)) == 3

# Generated at 2022-06-23 22:12:27.185148
# Unit test for constructor of class Schema
def test_Schema():
    """Create an instance of class Schema."""
    def st() -> Any:
        """Return schema."""
        return {}

    schema = Schema(schema=st)
    assert schema is not None



# Generated at 2022-06-23 22:12:29.910363
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert callable(f)
    assert str(f) == 'AbstractField <en>'
    assert type(f._gen) is Generic



# Generated at 2022-06-23 22:12:36.848611
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import schedule
    from mimesis.schema import AbstractField

    field = AbstractField(providers=[schedule])
    assert field('datetime').year != 0

    # Fix https://github.com/lk-geimfari/mimesis/issues/619
    assert field('choice', ['a', 'b', 'c']) in ['a', 'b', 'c']
    assert field('choice', objs=['a', 'b', 'c']) in ['a', 'b', 'c']

# Generated at 2022-06-23 22:12:44.975092
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis import Person
    from mimesis.enums import Gender

    def schema_example():
        """Example of filled schema."""
        user = Person(locale='en')
        return dict(
            first_name=user.first_name(gender=Gender.FEMALE),
            last_name=user.last_name(),
        )

    s = Schema(schema_example)
    result = s.create(5)
    assert isinstance(result, list)
    assert isinstance(result[0], dict)
    assert len(result) == 5

# Generated at 2022-06-23 22:12:49.488301
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {'id': Field().uuid4(), 'name': Field().name()}

    data = Schema(schema).create(iterations=100)
    assert len(data) == 100
    assert isinstance(data, list)
    assert isinstance(data[0], dict)

# Generated at 2022-06-23 22:12:53.810552
# Unit test for constructor of class AbstractField
def test_AbstractField():

    def test_init():
        """Test basic constructor."""
        a = Field()
        assert a

    def test_init_with_params():
        """Test constructor with parameters."""
        a = Field(locale='ru')
        assert a

    def test_init_with_invalid_locale():
        """Test constructor with incorrect locale."""
        a = Field(locale='zz')
        assert a

    def test_init_with_seed():
        """Test constructor with seed."""
        a = Field(seed=42)
        assert a

    def test_init_with_providers():
        """Test constructor with provider."""
        from mimesis import Address

        a = Field(providers=[Address()])
        assert a

# Generated at 2022-06-23 22:12:57.673485
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis.schema.schemas import SCHEMA_PERSON
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis import Generic

    providers = (Address, Person)
    generator = Generic('en', seed=123)
    generator.add_providers(*providers)
    schema = Schema(SCHEMA_PERSON(generator))
    data = schema.create(5)
    assert len(data) == 5

# Generated at 2022-06-23 22:12:59.062173
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    p = Field()
    data = p('person')
    assert data is not None

# Generated at 2022-06-23 22:12:59.724194
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    s = AbstractField()
    assert isinstance(s('word'), str)

# Generated at 2022-06-23 22:13:06.812942
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field

    def schema():
        return {
            'name': Field('full_name'),
            'second_name': Field('full_name'),
        }

    result = Schema(schema).create(iterations=2)
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], dict)
    assert len(result[0].keys()) == 2
    assert len(result[1].keys()) == 2

# Generated at 2022-06-23 22:13:16.790362
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    misc = Misc()

    class NewProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def method_1(self) -> str:
            return 'method_1'

        def method_2(self, x: str) -> str:
            return 'method_2'

    internet = Field('en')
    assert internet.__str__() == 'AbstractField <en>'

    custom_provider = Field('en', providers=[NewProvider])
    assert custom_provider('method_1') == 'method_1'

# Generated at 2022-06-23 22:13:17.819575
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:19.775488
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField('ru')) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:13:26.763237
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField()"""
    field1 = Field()
    assert len(field1('codepoint')) == 1
    assert sum(field1('ipv6', parts=6)) > 0

    class MyField(AbstractField):
        """A class for test AbstractField."""

        def __init__(self):
            super().__init__()
            self._gen.add_provider(self)

        def my_method(self, **kwargs):
            """Test method."""
            return kwargs

    field2 = MyField()
    assert field2('my_method', **{'foo': 'bar'}) == {'foo': 'bar'}

# Generated at 2022-06-23 22:13:33.281138
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis import Person, Address
    person = Person('ru')
    address = Address('ru')

    def factory_schema() -> JSON:
        """Return a filled schema."""
        return {
            'name': person.full_name(),
            'city': address.city(),
            'address': address.address(),
            'age': person.age(),
        }

    schema = Schema(factory_schema)
    result = schema.create(iterations=10)
    assert len(result) == 10
    assert isinstance(result, list)
    assert all(isinstance(schema, dict) for schema in result)

# Generated at 2022-06-23 22:13:40.255684
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema(lambda: 'It is schema')
    assert str(s) == '<Schema <lambda>>'

    s = Schema(lambda a: 'It is schema')
    assert str(s) == '<Schema <lambda>>'

    s = Schema(field=lambda a: 'It is schema')
    assert str(s) == '<Schema <lambda>>'

# Generated at 2022-06-23 22:13:47.780567
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.generic import Generic
    data = Generic('en')
    schema_data = {
        'field1': data.text.word(),
        'field2': data.datetime.datetime(),
    }
    schema = Schema(schema_data)
    assert schema.create() == [
        {
            'field1': 'test',
            'field2': '2019-01-29T18:03:03.593845'
        }
    ]

# Generated at 2022-06-23 22:13:49.756936
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {'name': Field('en').name()}

    result = Schema(schema).create(100)
    assert result

# Generated at 2022-06-23 22:13:56.933720
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema
    from mimesis.schema import Field
    import json

    field = Field()
    faker = Schema(field)
    result = faker.create(1)
    assert json.dumps(result) == json.dumps([{
        "name": "Kirk",
        "surname": "Pena",
        "age": "3",
        "email": "bclements@hotmail.com",
        "username": "john.young",
        "phone": "833-665-9085",
        "address": {
            "street": "Cox Place",
            "city": "West Larry",
            "state": "Kansas",
            "country": "Virgin Islands"
        }
    }])

# Generated at 2022-06-23 22:14:03.321213
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = Field()
    # No exceptions
    field(name='codepoint')
    field(name='datetime.datetime', format='%d.%m.%Y')
    field(name='internet.email')
    field(name='file.extension', key=lambda x: '.' + x)
    field(name='lorem.word')
    field(name='random.uuidv1')

# Generated at 2022-06-23 22:14:08.562902
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test the constructor of the class AbstractField."""
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field = Field(seed='foo')
    assert field.seed == 'foo'

    field = Field(locale='ru')
    assert field.locale == 'ru'



# Generated at 2022-06-23 22:14:11.690849
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {
            'key': 'value'
        }

    s = Schema(schema=schema)
    assert s.create(2) == [{'key': 'value'}] * 2

# Generated at 2022-06-23 22:14:14.225095
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field._gen is not None
    assert callable(field) is True
    assert field('gender') in ('Male', 'Female')



# Generated at 2022-06-23 22:14:17.300411
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'


# Generated at 2022-06-23 22:14:19.264738
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    def _test() -> None:
        field = Field()
        assert isinstance(str(field), str)

    _test()



# Generated at 2022-06-23 22:14:24.661679
# Unit test for method create of class Schema
def test_Schema_create():
    class CustomSchema:
        def __init__(self):
            self._field = Field()

        def data(self):
            return {
                'name': self._field('full_name'),
                'email': self._field('email'),
            }

    data = Schema(CustomSchema().data)
    test_list = data.create(10)

    assert isinstance(test_list, list)
    assert len(test_list) == 10

# Generated at 2022-06-23 22:14:25.911266
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert AbstractField() == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:28.502889
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test of AbstractField.__str__."""
    from mimesis.schema import AbstractField
    af = AbstractField()
    assert str(af) == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:35.437479
# Unit test for method create of class Schema
def test_Schema_create():
    def sample_schema() -> JSON:
        """Test schema."""
        from mimesis.enums import Gender
        from mimesis.providers.person import Person

        person = Person('en')
        return dict(
            name=person.full_name(gender=Gender.FEMALE),
            age=person.age(),
            phone=person.telephone(),
            job=person.occupation(),
            salary=person.money().amount(),
        )

    schema = Schema(sample_schema)
    result = schema.create(iterations=20)
    assert isinstance(result, list)