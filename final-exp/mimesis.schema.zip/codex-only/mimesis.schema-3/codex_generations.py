

# Generated at 2022-06-23 22:04:57.569946
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('key') is not None

    # Test with tail
    field('financial.iban', True) is not None
    field('personal.name.full_name', True) is not None

    # Test with tail and wrong tail
    with pytest.raises(UnacceptableField):
        field('personal.name.first_name.full_name', True) is not None

    # Test with tail and wrong tail - where is not provider
    with pytest.raises(UnsupportedField):
        field('name.first_name', True) is not None

    # Test with provider which is not supported
    with pytest.raises(UnsupportedField):
        field('error.full_name', True) is not None


# Generated at 2022-06-23 22:05:02.775674
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    # TODO: (2019-08-09)
    #  Some tests on assert, it's better without them.
    assert str(AbstractField(locale='en')) == 'AbstractField <en>'
    assert str(AbstractField(locale='en')) == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:07.239908
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    field = AbstractField()
    first = field('name', gender='male', with_middle=True)
    second = field('name', gender='male', with_middle=True)
    assert (first, second) == ('John Smith', 'John Smith')

# Generated at 2022-06-23 22:05:17.977589
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # When calling the method __call__
    # without passing any parameter,
    # then it should raise the exception UndefinedField
    field = AbstractField()
    try:
        field(name=None)
    except UndefinedField:
        pass
    else:
        assert False

    # When calling the method with name of the method as a parameter,
    # and without key parameter, then it should return a value,
    # which represented by method name
    field = AbstractField()
    assert field.__call__(name='uuid4').__class__.__name__ == 'UUID'

    # When calling the method with name of the method as a parameter,
    # key parameter and some additional arguments for a method,
    # then it should return a value, which represented by method name
    # and, in this case, should be equal to the one of

# Generated at 2022-06-23 22:05:21.762686
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    fld = AbstractField()
    assert fld('uuid') is not None
    assert fld('datetime.datetime') is not None
    assert fld('person.full_name') is not None

# Generated at 2022-06-23 22:05:27.536123
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Test without parameters
    f = Field()
    # Test with one parameter
    g = Field(locale='ru')
    # Test with two parameters
    h = Field(locale='ru', seed=123)
    assert str(f) == 'AbstractField <en>'
    assert str(g) == 'AbstractField <ru>'
    assert str(h) == 'AbstractField <ru>'


# Generated at 2022-06-23 22:05:32.912917
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.schema import SchemaProvider

    schema = {
        'id': SchemaProvider.id_(pattern='#####'),
        'username': SchemaProvider.username_(pattern='s******?'),
    }

    s = Schema(lambda: schema)
    assert isinstance(s.create(iterations=3), list)
    assert isinstance(s.create(iterations=3)[0], dict)
    assert len(s.create(iterations=3)) == 3
    assert len(s.create(iterations=3)[0]) == 2



# Generated at 2022-06-23 22:05:35.864932
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return 'test'

    expected = ['test'] * 5
    result = Schema(schema).create(5)
    assert result == expected



# Generated at 2022-06-23 22:05:38.439485
# Unit test for method create of class Schema
def test_Schema_create():
    """Test create of Schema."""
    schema = Schema(dict)
    assert isinstance(schema.create(), list)

# Generated at 2022-06-23 22:05:39.936406
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema(None)
    assert s.schema is None

# Generated at 2022-06-23 22:05:43.017371
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    field = Field(locale='ru', seed=42)
    assert field('geo.latitude', format='dd.dd') == '77.86'



# Generated at 2022-06-23 22:05:45.188038
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()

    assert 'Field' in field.__str__()
    assert '<en>' in field.__str__()

# Generated at 2022-06-23 22:05:48.738786
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of Schema"""
    for schema1 in (lambda : {}):
        s = Schema(schema1)
        assert callable(s.schema) and s.schema is schema1



# Generated at 2022-06-23 22:05:56.198078
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Tests for AbstractField.__call__."""
    # Test UndefinedField
    f = Field(providers=['faker'])
    assert f() == UndefinedField

    # Test UnsupportedField
    assert f('dfsdfsdf') == UnsupportedField

    # Test Tail
    assert f('faker.name') == UnacceptableField

    # Test Data
    assert f('name')
    assert f('address')
    assert f('full_name')

    # Test Key
    full_name = f('full_name', key=lambda x: x.split()[0])
    assert full_name in ['Foo Bar', 'John Doe']



# Generated at 2022-06-23 22:06:02.252028
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema.

    :return:
    """
    from mimesis import Person, Address

    def create_schema():
        """Create schema."""
        _person = Person('uk')
        _address = Address('uk')

        return {
            'full_name': _person.full_name(),
            'address': _address.address(),
            'number': _address.house_number(),
        }

    schema = Schema(create_schema)
    assert isinstance(schema.create(10), list)
    assert isinstance(schema.create(10)[0], dict)



# Generated at 2022-06-23 22:06:12.809570
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test of magic method __call__."""
    f = Field()
    assert f.locale == 'en'

    result = f('timestamp')
    assert type(result) == int

    result = f('gender')
    assert result in ['Male', 'Female']

    result = f('random_digit_not_null', min_=0, max_=255)
    assert result in list(range(0, 255))

    result = f('random_digit_not_null', max_=255)
    assert result in list(range(1, 255))

    result = f('random_digit', max_=255)
    assert result in list(range(0, 255))

    result = f('random_digit', min_=0, max_=255)
    assert result in list(range(0, 255))


# Generated at 2022-06-23 22:06:17.637238
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.typing import JSON
    from mimesis.providers.generic import lorem

    schema1 = JSON({'text': lorem.text()})
    assert Schema(schema1).create() == [{'text': Lorem.text()}]

    schema2 = JSON({'text': lorem.word()})
    assert Schema(schema2).create() == [{'text': Lorem.word()}]

    schema3 = JSON({'text': lorem.sentence()})
    assert Schema(schema3).create() == [{'text': Lorem.sentence()}]

    schema4 = JSON({'text': lorem.paragraph()})
    assert Schema(schema4).create() == [{'text': Lorem.paragraph()}]


# Generated at 2022-06-23 22:06:20.456923
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()

    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:06:22.609336
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema.template import SCHEMA

    x = Schema(SCHEMA)
    assert callable(x.schema)



# Generated at 2022-06-23 22:06:24.620826
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:29.192119
# Unit test for constructor of class Schema
def test_Schema():
    def schema_function():
        return {
            'name': 'John',
            'surname': 'Doe',
        }
    schema = Schema(schema_function)
    assert schema.schema == schema_function


# Unit tests for method create of class Schema

# Generated at 2022-06-23 22:06:30.958985
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    f.locale = 'ru'
    assert str(f) == 'AbstractField <ru>'



# Generated at 2022-06-23 22:06:32.287446
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert isinstance(f, AbstractField)



# Generated at 2022-06-23 22:06:35.202878
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'name': 'name'}

    s = Schema(lambda: schema)
    assert s.create() == [schema]
    assert s.create(3) == [schema] * 3

# Generated at 2022-06-23 22:06:37.482611
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field(locale='ru')
    # noinspection PyTypeChecker
    assert str(f) == 'AbstractField <ru>'



# Generated at 2022-06-23 22:06:39.270591
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField(locale='ru')) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:06:40.508829
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    target = 'AbstractField <en>'
    assert AbstractField().__str__() == target

# Generated at 2022-06-23 22:06:46.235596
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__.

    :return: Test result.
    """
    field = Field()

    assert callable(field)
    assert callable(field(name='text'))
    assert callable(field(name='full_name'))
    assert callable(field(name='full_name', gender='male'))
    assert callable(field(name='full_name', gender='male', key=lambda x: x.title()))
    assert callable(field(name='datetime.now'))

    assert isinstance(field(name='uuid4'), str)
    assert isinstance(field(name='uuid4', key=str.upper), str)

    assert field(name='uuid4') != field(name='uuid4')

# Generated at 2022-06-23 22:06:48.748741
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField."""
    f = Field('ru')
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:06:54.392817
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    # Undefined field
    try:
        field()
    except UndefinedField:
        pass

    # Unsupported field
    try:
        field('hello world')
    except UnsupportedField:
        pass

    # Unacceptable
    try:
        field('en.en.en')
    except UnacceptableField:
        pass

    # Supported field
    field('full_name')
    field('name')
    field('true')
    field('yes')

# Generated at 2022-06-23 22:06:56.194973
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field(locale='ru')

    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:06:59.100134
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__."""
    af = AbstractField()
    assert af('username') == af._gen.username()
    assert af('name.username') == af._gen.name.username()



# Generated at 2022-06-23 22:07:07.731493
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(locale='ru', seed='mimesis')
    assert isinstance(field, AbstractField)
    assert isinstance(field._gen, Generic)
    assert field._gen.locale == 'ru'
    assert str(field) == 'AbstractField <ru>'
    assert field._gen.seed == 'mimesis'
    assert field._gen.seed

    field = Field(locale='en')
    assert isinstance(field, AbstractField)
    assert isinstance(field._gen, Generic)
    assert field._gen.locale == 'en'
    assert str(field) == 'AbstractField <en>'
    assert field._gen.seed is None

    assert field() is None
    assert field(name='fake.name') is None

# Generated at 2022-06-23 22:07:10.448480
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    actual = str(AbstractField())
    expected = 'AbstractField <en>'

    assert actual == expected

# Generated at 2022-06-23 22:07:12.819076
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor of class Schema."""
    schema = Schema(lambda: {})
    assert isinstance(schema, Schema)



# Generated at 2022-06-23 22:07:15.819938
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Check AbstractField construction.

    :param field: Instance of the AbstractField
    :return: True or False
    """
    field = AbstractField()
    assert field is not None
    assert field._gen is not None

# Generated at 2022-06-23 22:07:19.502143
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.person import Person

    p = Person('pt')
    field = AbstractField(providers=[Person, p])  # type: ignore
    assert field('username')
    assert field('full_name')
    assert field('username', with_dots=False)

# Generated at 2022-06-23 22:07:22.370502
# Unit test for constructor of class Schema
def test_Schema():
    pass
#     try:
#         Schema({})
#     except Exception as e:
#         assert str(e) == 'Schema must be a callable object'
#     else:
#         raise AssertionError('Should be raised Schema exception')

# Generated at 2022-06-23 22:07:30.552262
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.schema import Field

    field = Field()
    schema = Schema(lambda: {
        'name': field('person.full_name', gender=Gender.MALE),
        'surname': field('person.surname'),
        'age': field('person.age', minimum=18, maximum=60),
    })

    result = schema.create(2)
    assert isinstance(result, list)
    assert isinstance(result[0], dict)
    assert isinstance(result[1], dict)
    assert result[0]['name'] != result[1]['name']

    assert isinstance(result[0]['age'], int)
    assert isinstance(result[0]['surname'], str)

# Generated at 2022-06-23 22:07:36.841186
# Unit test for method create of class Schema
def test_Schema_create():
    assert Schema(lambda: []).create() == []
    assert Schema(lambda: [1]).create() == [1]
    assert Schema(lambda: [1]).create(iterations=2) == [1, 1]
    assert Schema(lambda: [1]).create(iterations=0) == []

    assert Schema(lambda: ["1"]).create(iterations=2) == ["1", "1"]
    assert Schema(lambda: ["1"]).create(iterations=0) == []

    assert Schema(lambda: ["1", "2"]).create(iterations=1) == ["1", "2"]
    assert Schema(lambda: ["1", "2"]).create(iterations=2) == [
        "1", "2", "1", "2",
    ]

# Generated at 2022-06-23 22:07:38.000962
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field('en')) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:39.120947
# Unit test for constructor of class AbstractField
def test_AbstractField():
    fd = Field()
    assert fd.locale == 'en'



# Generated at 2022-06-23 22:07:48.463477
# Unit test for constructor of class Schema
def test_Schema():
    """Test for Schema."""
    from mimesis.data import USER_AGENTS

    def ua_schema() -> dict:
        """Dummy schema."""
        return {
            'user_agent': Field('ua.user_agent')
        }

    schema = Schema(ua_schema)
    assert len(schema.create()) > 0
    assert isinstance(schema.create(5), list)
    assert isinstance(schema.create(5)[1], dict)

    def ua_schema_mocked() -> dict:
        """Dummy schema."""
        return {
            'user_agent': Field('ua.user_agent',
                                key=lambda x: USER_AGENTS[0])
        }

    schema_mocked = Schema(ua_schema_mocked)

# Generated at 2022-06-23 22:07:53.107174
# Unit test for method create of class Schema
def test_Schema_create():
    """Method create of class Schema."""
    def schema() -> dict:
        """Return schema."""
        return dict(a=1, b=2)

    schema_ = Schema(schema)
    result = schema_.create(1)
    assert result == [{'a': 1, 'b': 2}]



# Generated at 2022-06-23 22:07:54.639255
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:58.847727
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field(locale='ru', seed=666)
    assert field('datetime') == '13 мая 2012'
    assert field('datetime.date', '%A, %d. %B %Y') == 'пятница, 11. мая 2012'



# Generated at 2022-06-23 22:08:06.929345
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField('en')
    result = field('full_name')
    assert len(result) > 0
    result = field('en.full_name')
    assert len(result) > 0
    result = field('en.full_name', gender='f')
    assert len(result) > 0
    def key(data: Any) -> str:
        """Test key."""
        return data.capitalize()
    result = field('full_name', key=key)
    assert len(result.split(' ')[0]) > 0
    assert result[0].isupper()
    result = field('full_name', capitalized=True)
    assert len(result.split(' ')[0]) > 0
    assert result[0].isupper()
    result = field

# Generated at 2022-06-23 22:08:15.129284
# Unit test for method create of class Schema
def test_Schema_create():
    # GIVEN
    from mimesis import Address, Food
    from mimesis.schema import Field

    f = Field()
    schema = {'name': f('person.full_name'),
              'address': f('address.full_address'),
              'email': f('person.email')}

    address = Address(schema['address'])
    full_name = f('person.full_name')
    email = f('person.email')
    food = Food()
    schema_list = [{'name': full_name, 'address': address.full_address,
                    'email': email, 'food': food.dish()}]
    # WHEN
    s = Schema(schema)
    result = s.create(1)[0]
    # THEN
    assert result in schema_list

# Generated at 2022-06-23 22:08:15.858577
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test case for AbstractField class."""
    field = AbstractField()

# Generated at 2022-06-23 22:08:18.137937
# Unit test for constructor of class Schema
def test_Schema():
    blueprint = {'a': 1}
    s = Schema(blueprint)
    assert s.schema == blueprint



# Generated at 2022-06-23 22:08:25.769662
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema
    from mimesis.providers.internet import Internet

    schema = {'email': 'internet.email'}

    instance = Schema(lambda: schema)
    assert isinstance(instance, Schema)

    instance = Schema(lambda: {'em': 'internet.email'})
    assert isinstance(instance, Schema)

    field = Field('en', providers=[Internet])
    instance = Schema(lambda: field('internet.email'))
    assert isinstance(instance, Schema)


# Generated at 2022-06-23 22:08:32.865985
# Unit test for method create of class Schema
def test_Schema_create():
    # The simplest case of creating a filled scheme
    def my_schema() -> dict:
        return {'name': 'John'}

    s = Schema(my_schema)
    assert s.create() == [{'name': 'John'}]

    # The case when filled scheme returns a list of dicts
    def my_schema_2() -> dict:
        return [{'name': 'John'}, {'name': 'Mike'}]

    s = Schema(my_schema_2)
    assert s.create() == [{'name': 'John'}, {'name': 'Mike'}]



# Generated at 2022-06-23 22:08:41.619345
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    # without raise error
    result = field('person.full_name')
    result = field('person.full_name', key=str)

    # without raise error
    result = field('person.name')
    result = field('person.surname')
    result = field('person.last_name')
    result = field('person.last_name', key=str)
    result = field('person.last_name', key=int)
    result = field('person.last_name', key=float)

    # without raise error
    result = field('name')
    result = field('surname')
    result = field('last_name')
    result = field('last_name', key=str)
    result = field('last_name', key=int)

# Generated at 2022-06-23 22:08:52.610825
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField __call__ method."""
    obj = Field()

    # Normally
    assert(
        obj('full_name') == 'Thomas Hernandez'
    )

    # With explicit naming
    assert(
        obj('person.full_name') == 'Thomas Hernandez'
    )

    # With key function
    assert(
        obj('full_name', key=lambda x: x.upper())
        == 'THOMAS HERNANDEZ'
    )

    # With key function and explicit naming
    assert(
        obj('person.full_name', key=lambda x: x.upper())
        == 'THOMAS HERNANDEZ'
    )

    # With method argument

# Generated at 2022-06-23 22:08:57.562270
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='ru', seed=123)
    assert field.locale == 'ru'
    assert field.seed == 123
    assert field._gen.seed == 123

    field = AbstractField(providers=[1, 2, 3])
    assert field._gen._providers == [1, 2, 3]



# Generated at 2022-06-23 22:08:58.174966
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field is not None

# Generated at 2022-06-23 22:09:00.522715
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'
    assert str(Field(locale='ru')) == 'AbstractField <ru>'
    assert Field() == Field()

# Generated at 2022-06-23 22:09:11.097020
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime

    def test_call_without_args():
        """Test call without any args."""
        f = AbstractField()
        assert callable(f)

        with pytest.raises(UndefinedField):
            f()

    def test_call_with_name():
        """Test call with name."""
        f = AbstractField()
        assert callable(f)

        f()

    def test_call_with_name_and_without_args():
        """Test call with name and without args."""
        f = AbstractField()
        assert callable(f)

        result = f('full_name')
        assert isinstance(result, str)


# Generated at 2022-06-23 22:09:18.629238
# Unit test for constructor of class Schema
def test_Schema():
    # Correct initialization
    t = Schema(lambda: {})
    assert isinstance(t, Schema)
    assert callable(t.schema)
    assert t.create(iterations=1) == [{}]
    assert t.create(iterations=2) == [{}, {}]

    # Incorrect initialization
    # with string
    try:
        Schema('qwerty')
    except UndefinedSchema:
        pass
    else:
        raise Exception('Must be raise UndefinedSchema')

    # with number
    try:
        Schema(123)
    except UndefinedSchema:
        pass
    else:
        raise Exception('Must be raise UndefinedSchema')

# Generated at 2022-06-23 22:09:23.730930
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Check if exception is raised
    provider_name = 'datetime.datetime'
    method_name = 'second'
    field = Field()
    try:
        field(method_name)
    except UndefinedField:
        pass
    assert field(provider_name + '.' + method_name) is not None

# Generated at 2022-06-23 22:09:26.540668
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert isinstance(f, AbstractField)
    assert f.locale == 'en'
    assert f.seed is None

# Generated at 2022-06-23 22:09:28.684386
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {
            'foo': 'bar',
        }

    Schema(schema)



# Generated at 2022-06-23 22:09:33.871332
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis import DataProvider
    from mimesis.builtins import RussiaSpecProvider

    class Object(DataProvider):
        class Meta:
            name = 'object'

        @classmethod
        def object_method(cls):
            return 'object'

    class Provider(RussiaSpecProvider):
        class Meta:
            name = 'russia'

        @classmethod
        def first_name(cls):
            return 'anonymous'

    abstract = AbstractField(providers=(Object, Provider))

    assert abstract('object') == 'object'
    assert abstract('russia.first_name') == 'anonymous'

# Generated at 2022-06-23 22:09:35.603078
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    f = AbstractField()
    assert isinstance(f, AbstractField)
    assert isinstance(f, Generic)



# Generated at 2022-06-23 22:09:38.123505
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'key': 'value'}
    expected = [schema]
    result = Schema(lambda: schema).create()
    assert result == expected, 'Schema.create() test fails.'
    print('Schema.create() test success.')

# Generated at 2022-06-23 22:09:41.417476
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {'name': 'Roger'})
    assert isinstance(schema, Schema)
    assert schema.create() == [{'name': 'Roger'}]

# Generated at 2022-06-23 22:09:43.753633
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    field = Field()
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:09:46.592632
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: None)
    assert schema.schema is not None

    try:
        Schema(1)
    except UndefinedSchema:
        assert True

# Generated at 2022-06-23 22:09:52.422850
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__.

    See :class:`~mimesis.schema.AbstractField`.
    """
    gen = AbstractField()
    assert gen.__call__('email', domain='email.com')
    assert gen.__call__('person.name') == gen.person.name()

    with raises(UnacceptableField):
        assert gen.__call__('person.person.name')

# Generated at 2022-06-23 22:10:00.812494
# Unit test for constructor of class Schema
def test_Schema():  # noqa
    from mimesis.schema import Schema
    from mimesis.schema import Field

    def _schema(field: Field) -> JSON:
        from datetime import datetime, timedelta

        # This is a good example of using a Field object
        # in this way we can generate data related to any part of the
        # schema in the same way, without repeating yourself.
        age = field.datetime.date_delta()
        return {
            'name': field.person.full_name(),
            'age': age,
            'birthday': field.datetime.date(
                start=datetime.now() - timedelta(days=age),
                end=datetime.now().date() - timedelta(days=age),
            ),
            'email': field.person.email(),
        }

   

# Generated at 2022-06-23 22:10:03.440781
# Unit test for constructor of class Schema
def test_Schema():
    """Test for the Schema class."""
    from mimesis.schema.schemas import user

    assert Schema(user)



# Generated at 2022-06-23 22:10:05.487669
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField(seed=None)
    assert 'en' == f.locale
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:06.985548
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    name = AbstractField().__str__()
    assert name == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:09.679795
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    providers = {'foo': 'bar'}
    af = AbstractField(providers=providers)
    try:
        af(name=None, key=None)
    except UndefinedField:
        pass

# Generated at 2022-06-23 22:10:10.576852
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:12.271456
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:21.697447
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """
    Test AbstractField.__call__()

    This method takes any string which represents the name of
    any method of any supported data provider.

    Some data providers have methods with the same names
    and in such cases, you can explicitly define that the method
    belongs to data-provider _name='provider.name'_ otherwise
    it will return the data from the first provider which
    has a method _name_.
    """
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers import Address
    from mimesis.providers.person import Person

    af = AbstractField('ru', None, [RussiaSpecProvider, Address, Person])

    for _ in range(10):
        assert af('full_name') is not None


# Generated at 2022-06-23 22:10:24.199341
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test magic method __str__."""
    field = Field()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:10:29.730507
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.personal import Personal

    field = Field(seed=42, providers=[Personal])
    name, surname = field('full_name', split=True), field('full_name',
                                                          split=True)
    assert name == 'Елена Георгиева'
    assert surname == 'Ирина Иванова'

# Generated at 2022-06-23 22:10:32.510648
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:35.988356
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method AbstractField.__call__."""
    g = Generic('en')
    s = AbstractField(providers=g)
    func = s('token', n=10)
    assert isinstance(func, str)

# Generated at 2022-06-23 22:10:38.786827
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f.locale == 'en'
    assert f.seed is None
    assert f._gen is not None



# Generated at 2022-06-23 22:10:40.939857
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {'field': 'value'})
    assert isinstance(schema, Schema)



# Generated at 2022-06-23 22:10:47.418868
# Unit test for method create of class Schema
def test_Schema_create():
    def test_schema() -> dict:
        return {'name': 'John', 'age': 18}

    schema = Schema(test_schema)
    result = schema.create()
    assert len(result) == 1
    assert result == [test_schema()]

    result = schema.create(5)
    assert len(result) == 5
    assert len(set(result)) == 1
    assert result == [test_schema() for _ in range(5)]

# Generated at 2022-06-23 22:10:49.018432
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f

# Generated at 2022-06-23 22:10:53.789541
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'foo': 1,
        'bar': 'string',
    }

    class Test:
        def __init__(self):
            self.schema_ = Schema(schema)

        def test_iterations(self, iterations: int = 1000):
            self.schema_.create(iterations)

    t = Test()
    t.test_iterations()

# Generated at 2022-06-23 22:10:57.259049
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField(locale='es', seed=123)

    assert f.locale == 'es'
    assert f.seed == 123

    f = AbstractField(locale='en', seed=1234)

    assert f.locale == 'en'
    assert f.seed == 1234



# Generated at 2022-06-23 22:11:03.542689
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.base import BaseProvider

    schema = {'number': 'number', 'text': 'text'}

    def fill_schema() -> dict:
        field = Field(providers=[BaseProvider])
        return {
            'number': field('integer'),
            'text': field('text'),
        }

    s = Schema(fill_schema).create(iterations=5)
    assert s == [schema] * 5

# Generated at 2022-06-23 22:11:03.986068
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    AbstractField()

# Generated at 2022-06-23 22:11:07.232859
# Unit test for constructor of class AbstractField
def test_AbstractField():
    af = AbstractField()
    assert af.locale == 'en'
    assert isinstance(af._gen, Generic)
    assert af.seed is None

# Generated at 2022-06-23 22:11:10.109321
# Unit test for constructor of class Schema
def test_Schema():
    def schema_test() -> SchemaType:
        """Return a test schema."""
        return dict(key1=1, key2=2)

    schema = Schema(schema_test)
    assert schema.schema() == schema_test()

# Generated at 2022-06-23 22:11:13.905059
# Unit test for method create of class Schema
def test_Schema_create():
    def simple_schema():
        return {
            'a': 1,
            'b': '2',
            'c': 3.0
        }

    return Schema(simple_schema).create(4)



# Generated at 2022-06-23 22:11:14.906497
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema(SchemaType(int))

# Generated at 2022-06-23 22:11:17.799705
# Unit test for method create of class Schema
def test_Schema_create():
    # test for invalid schema
    schema = Schema(None)
    schema.create()

    # test for valid schema
    from mimesis.schema import Address
    for i in range(100):
        schema = Schema(Address)
        schema.create(iterations=i)

# Generated at 2022-06-23 22:11:28.779523
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Method must return right value."""
    field = Field()
    assert field('name') == 'Kelvin'
    assert field('title') == 'Mr.'
    assert field('title', gender='female') == 'Mrs.'
    assert field('name', gender='male') == 'Abraham'
    assert field('first_name', gender='female') == 'Bonnie'
    assert field('name', key=lambda s: s.capitalize()) == 'Kelvin'
    assert field('first_name',
                 gender='male',
                 key=lambda s: s[0].capitalize() + s[1:]) == 'Abraham'
    assert field('first_name',
                 gender='female',
                 key=lambda s: s[0].capitalize() + s[1:]) == 'Bonnie'


# Generated at 2022-06-23 22:11:30.088285
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    f = Field(seed=123)
    assert f.locale == 'en'
    assert not f.seed is None

# Generated at 2022-06-23 22:11:37.671258
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    from mimesis import Person, Address, Datetime

    def schema_() -> dict:
        """Return schema (dict) of filled fields."""
        return {
            'name': Person('en').full_name(),
            'address': Address('en').address(),
            'postal_code': Address('en').postal_code(),
            'birthday': Datetime('en').date(),
        }

    schema = Schema(schema_)
    iterations = 3

    result = schema.create(iterations=iterations)
    assert len(result) == iterations
    assert isinstance(result, list)
    assert isinstance(result[0], dict)

# Generated at 2022-06-23 22:11:40.692070
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert field.__str__() == 'AbstractField <en>'

    field = AbstractField('ru')
    assert field.__str__() == 'AbstractField <ru>'



# Generated at 2022-06-23 22:11:44.700069
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> dict:
        return {'a': 1, 'b': 2}

    assert Schema(schema).create(2) == [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]


# Generated at 2022-06-23 22:11:45.517115
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:11:47.116801
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field(name='sha256')



# Generated at 2022-06-23 22:11:58.124781
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()  # type: ignore
    assert callable(field)

    assert field('choice', pool=['foo', 'bar', 'baz'],
                 key=lambda x: x.upper()) == 'FOO'

    assert field('choice', ['foo', 'bar', 'baz'],
                 key=lambda x: x.upper()) == 'FOO'

    assert field('choice', ['foo', 'bar', 'baz']) in ['foo', 'bar', 'baz']

    assert field('choice', ['foo', 'bar', 'baz'],
                 key=lambda x: x.lower()) in ['foo', 'bar', 'baz']

    assert field('choice', 'foo', 'bar', 'baz',
                 key=lambda x: x.upper()) in ['foo', 'bar', 'baz']

   

# Generated at 2022-06-23 22:11:59.715960
# Unit test for constructor of class AbstractField
def test_AbstractField():
    fld = Field()
    assert str(fld) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:01.639593
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """By default should be created by the system locale."""
    field = Field()
    assert field.locale == 'en'

# Generated at 2022-06-23 22:12:04.856312
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    field = Field()
    result = field('enumerate', start=10)
    assert isinstance(result, int)
    assert result == 10



# Generated at 2022-06-23 22:12:08.553664
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor of Schema class."""
    try:
        Schema(None)
        assert False, "Must to raise `UndefinedSchema`"
    except UndefinedSchema:
        assert True

# Generated at 2022-06-23 22:12:11.394119
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    locale = 'zz'
    seed = '1'
    field = AbstractField(locale, seed)
    assert str(field) == 'AbstractField <zz>'

# Generated at 2022-06-23 22:12:18.370270
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    # Works with another providers with the same method name
    field('age', minimum=7, maximum=90)

    # Works with full path for method
    field('datetime.datetime', year=2000, month=1, day=1)

    # Not work because of unsupport field
    try:
        field('blah')
    except UnacceptableField:
        pass

    # Not work because of unacceptable field
    try:
        field('datetime.blah.blah')
    except UnacceptableField:
        pass

    # Not work because of undefined field
    try:
        field()
    except UndefinedField:
        pass



# Generated at 2022-06-23 22:12:21.239133
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    field = AbstractField(locale='en')
    field = AbstractField(locale='en', seed=None)

# Generated at 2022-06-23 22:12:22.806039
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(seed=4242)
    assert field.locale == 'en'
    assert field.seed == 4242

# Generated at 2022-06-23 22:12:25.709442
# Unit test for constructor of class Schema
def test_Schema():
    # Undefined schema
    def bad_schema():
        return {}
    print(Schema(bad_schema))

# Generated at 2022-06-23 22:12:28.745631
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()
    assert f.__call__('name') == 'Sarah'
    assert f.__call__('random_int', key=lambda x: x > 0)



# Generated at 2022-06-23 22:12:30.330995
# Unit test for constructor of class AbstractField
def test_AbstractField():
    a = AbstractField(None)
    assert isinstance(a, AbstractField)

# Generated at 2022-06-23 22:12:33.312476
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema():
        return {'__provider__': 'person'}

    schema = Schema(schema=test_schema)
    assert schema.create() == [test_schema()]

# Generated at 2022-06-23 22:12:34.057823
# Unit test for constructor of class AbstractField
def test_AbstractField():
    pass

# Generated at 2022-06-23 22:12:44.880901
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.providers.internet import Internet
    from mimesis.providers.finance import Finance
    field = AbstractField(
        locale='en',
        seed=None,
        providers=[Internet, Finance],
    )
    # If a provider has a method with the same name,
    # then the method becomes a data-provider name
    assert 'ipv4' in field('ipv4')
    # If a provider has a method with the same name,
    # then the method becomes a data-provider name
    assert 'md5' in field('md5')
    assert 'money' in field('money')
    # The result of calling the method will be equal to the result of
    # calling the same method of the provider
    assert field._gen.money() == field('money')
    # Test attribute locale
    assert field

# Generated at 2022-06-23 22:12:49.412641
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.data import LANGUAGES
    from mimesis.providers.datetime import Datetime

    for lang in LANGUAGES:
        f = Field(locale=lang, providers=[Datetime(lang)])
        assert str(f) == 'Field <{}>'.format(lang)

# Generated at 2022-06-23 22:12:51.213625
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test __str__ of class Field."""
    field = AbstractField()

    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:02.394603
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person

    _field = Field()
    # Wrong provider
    assert not _field('some.provider.method', foo='bar')

    # Provider Person
    provider = Person('ru')
    assert _field('name', gender='male') == provider.name(gender='male')

    # Provider Address
    provider = Address('ru')
    assert _field('region') == provider.region()

    # Provider Numbers
    provider = Numbers('ru')
    assert _field('float_number', minimum=0, maximum=10) == \
        provider.float_number(minimum=0, maximum=10)

    # Explicit provider
    provider

# Generated at 2022-06-23 22:13:03.852138
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema is not None

# Generated at 2022-06-23 22:13:14.276835
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__ method."""
    field = AbstractField()
    assert field('full_name') is not None
    assert callable(field('full_name'))
    assert field('full_name', 'en') is not None
    assert callable(field('full_name', 'en'))
    assert field('fake_field', 'en') is None
    assert field('custom_method', 'en', 'Hello') is not None
    assert field('custom_method', 'en', 'Hello') == 'Hello'
    assert field(  # pylint: disable=W0108
        'full_name', 'en',
        formatter='{middle_name} {name} {surname}') is not None

# Generated at 2022-06-23 22:13:23.385029
# Unit test for method create of class Schema

# Generated at 2022-06-23 22:13:26.557264
# Unit test for constructor of class AbstractField
def test_AbstractField(): # pragma: no cover
    provider = Generic()
    field = AbstractField(providers=[provider])
    value = field('full_name')
    print(value)



# Generated at 2022-06-23 22:13:28.587578
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method AbstractField.__str__."""
    field = Field(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:13:30.422058
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField('ru')
    assert field.__str__() == 'AbstractField <ru>'

# Generated at 2022-06-23 22:13:34.831840
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create.

    Expected result: the type of the returned
    value is list and its length is equal to the specified iteration.
    """
    from mimesis import Person

    def schema():
        """Generate schema."""
        return {'name': Person('en').full_name()}
    generator = Schema(schema)
    result = generator.create(5)
    assert isinstance(result, list)
    assert len(result) == 5

# Generated at 2022-06-23 22:13:36.947287
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()

    assert isinstance(field, AbstractField)


# Generated at 2022-06-23 22:13:38.526326
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:13:39.880424
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:47.688710
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    from mimesis.providers.address import Address

    def schema():
        return {
            'street': Address().street_name(),
            'zip': Address().postal_code(),
        }

    s = Schema(schema)
    result = s.create(iterations=2)
    assert len(result) == 2
    assert isinstance(result, list)
    assert isinstance(result[0], dict)

# Generated at 2022-06-23 22:13:50.845013
# Unit test for constructor of class Schema
def test_Schema():
    # Test with a correct schema
    def my_schema():
        return {}

    _ = Schema(my_schema)

    # Test with a False schema
    with pytest.raises(UndefinedSchema):
        _ = Schema('test')



# Generated at 2022-06-23 22:13:54.771944
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Constructor of AbstractField should work correctly."""
    from mimesis.providers.datetime import Datetime
    field = Field('ru', providers=Datetime)

    assert field.seed is None
    assert isinstance(field._gen, Generic)
    assert isinstance(field._gen.dt, Datetime)
    assert field._gen.dt.locale == 'ru'

# Generated at 2022-06-23 22:13:57.737320
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test :meth:`~mimesis.schema.AbstractField.__str__`."""
    field = AbstractField()
    assert isinstance(field.__str__(), str)

# Generated at 2022-06-23 22:14:01.034227
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema

    class Test:
        def __call__(self):
            return 'Its test'

    schema = Schema(Test())

    assert schema.create() == ['Its test']

# Generated at 2022-06-23 22:14:02.642379
# Unit test for constructor of class AbstractField
def test_AbstractField():
    af = AbstractField()
    assert af.locale == 'en'

# Generated at 2022-06-23 22:14:07.143216
# Unit test for constructor of class Schema
def test_Schema():
    class Test:
        @staticmethod
        def test():
            return {}

    test = Schema(Test.test)
    assert isinstance(test, Schema)
    assert test.schema() == {}

# Generated at 2022-06-23 22:14:15.062701
# Unit test for method create of class Schema
def test_Schema_create():
    """Check the correctness of the create method of the Schema class."""
    from mimesis.enums import Gender
    from mimesis.schema import Field

    schema = {
        'gender': Field('gender'),
        'name': Field('full_name', gender=Gender.FEMALE),
        'age': Field('age'),
    }

    def test_schema():
        return schema

    schema = Schema(test_schema)

    assert isinstance(schema.create(5), list)
    assert len(schema.create(5)) == 5

# Generated at 2022-06-23 22:14:17.077367
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field is not None



# Generated at 2022-06-23 22:14:19.430629
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'
    field = Field('ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:14:20.865371
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        Field()
    except UndefinedField:
        pass

# Generated at 2022-06-23 22:14:23.590927
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {
            'name': 'James Bond'
        }

    s = Schema(schema)
    assert s.schema() == {
        'name': 'James Bond'
    }

# Generated at 2022-06-23 22:14:24.178574
# Unit test for constructor of class Schema
def test_Schema():
    from .basic import Person

# Generated at 2022-06-23 22:14:33.087693
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('name')
    assert field('uuid4')
    assert field('uuid4', key=lambda x: x.split('-'))
    assert len(field('uuid4', key=lambda x: x.split('-'))) == 5
    assert len(field('uuid4', key=lambda x: x.split('-'))[3]) == 4
    assert field('name', key=lambda x: x.split(' '))
    assert len(field('name', key=lambda x: x.split(' '))) == 2
    assert all((len(x) > 3 for x in field('name', key=lambda x: x.split(' '))))

# Generated at 2022-06-23 22:14:36.480249
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': 'Ivan',
            'age': 19,
            'country': 'Russia',
        }

    data = Schema(schema).create(iterations=2)
    assert len(data) == 2

    for item in data:
        assert 'name' in item
        assert 'age' in item
        assert 'country' in item

# Generated at 2022-06-23 22:14:39.377681
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda x: x)
    assert schema.create(3) == ([G.uuid4() for i in range(3)] * 3)

# Generated at 2022-06-23 22:14:44.565327
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField.

    This test is necessary because at the moment the class is a simple
    object, and we need to make sure that the constructor
    works correctly.
    """
    data = {'data': '1'}
    field = AbstractField()
    assert field._table == {}
    assert type(field._gen) is Generic
    assert field(**data) == '1'

# Generated at 2022-06-23 22:14:55.923994
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""

    # A field object, which represents any method of any supported data
    # provider. For example, data.user.name() which returns name of any user.
    data = Field()

    schema = {
        'name': data('name'),
        'last_name': data('last_name'),
        'age': data('age', minimum=20, maximum=30),
        'full_name': data('full_name', key=lambda x: '{} {}'.format(
            x['last_name'], x['name'])),
    }

    filled_schema = Schema(schema)

    created = filled_schema.create(3)
    for one in created:
        assert isinstance(one, dict)
        assert isinstance(one['name'], str)