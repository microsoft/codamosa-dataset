

# Generated at 2022-06-23 22:04:54.778964
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    f = AbstractField()
    assert callable(f)

    data = f('items_quantity', max=8)
    assert isinstance(data, int)

    data = f('address.address')
    assert isinstance(data, str)



# Generated at 2022-06-23 22:04:55.748183
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()

# Generated at 2022-06-23 22:04:57.925542
# Unit test for constructor of class AbstractField
def test_AbstractField():
    provider = AbstractField()
    assert callable(provider)
    assert isinstance(provider, AbstractField)



# Generated at 2022-06-23 22:05:04.322166
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': 'Eric Idle',
        'email': 'eric.idle@gmail.com',
        'age': 74,
        'birth_date': '1943-03-29',
    }

    def custom_schema():
        return schema

    schema = Schema(custom_schema)
    data = schema.create()
    assert data == [schema] * 1


# Generated at 2022-06-23 22:05:07.917034
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema constructor."""
    from mimesis.schema.json import schema
    s = Schema(schema)
    assert s.schema == schema
    assert len(s.create(10)) == 10



# Generated at 2022-06-23 22:05:15.687364
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor of class Schema."""
    # pylint: disable=R0201,C0115

    class DummySchema:
        """Dummy schema."""

        def __init__(self) -> None:
            """Initialize dummy schema."""
            pass

        def __call__(self) -> object:
            """Return an object."""
            return object

    schema = DummySchema()
    assert isinstance(Schema(schema), Schema)

    with pytest.raises(UndefinedSchema):
        Schema('Wrong schema')



# Generated at 2022-06-23 22:05:17.023281
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        pass

    assert Schema(schema)

# Generated at 2022-06-23 22:05:21.511259
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert isinstance(field._table, dict)
    assert len(field._table) == 0



# Generated at 2022-06-23 22:05:24.683638
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> Any:
        return 'test'
    s = Schema(schema).create()
    assert isinstance(s, list)
    assert s[0] == 'test'


# Generated at 2022-06-23 22:05:31.195761
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.schema import AbstractField
    from mimesis.providers import Coin, Datetime, Internet, Person, Python

    # Standard usage
    field = AbstractField()
    assert isinstance(field, AbstractField)

    # Instance with providers
    field = AbstractField(
        providers=[Coin, Datetime(lazy=False),
                   Internet, Person, Python])
    assert isinstance(field, AbstractField)

    # Instance with locale
    field = AbstractField(locale='ru')
    assert isinstance(field, AbstractField)

    # Instance with seed
    field = AbstractField(seed=1)
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:05:34.044775
# Unit test for method create of class Schema
def test_Schema_create():
    assert Schema(lambda: {'test': 1}).create(iterations=3) == [
        {'test': 1}, {'test': 1}, {'test': 1}
    ]

# Generated at 2022-06-23 22:05:38.445362
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema.

    :return:
    """
    def my_schema(field):
        return {'test': field.datetime.date()}

    schema = Schema(my_schema)
    assert schema.create(5)


# Generated at 2022-06-23 22:05:41.641999
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> JSON:
        return {'foo': 'bar'}

    s = Schema(schema)
    assert s.schema == schema
    assert len(s.create()) == 1

# Generated at 2022-06-23 22:05:43.622694
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    af = Field()
    assert str(af) == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:47.663822
# Unit test for constructor of class AbstractField
def test_AbstractField():
    with_providers = AbstractField(providers='datetime')
    without_providers = AbstractField()
    assert hasattr(with_providers, 'datetime')
    assert not hasattr(without_providers, 'datetime')

# Unit for constructor of the Schema class

# Generated at 2022-06-23 22:05:49.970033
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert repr(field) == "<{} <en>>".format(
        field.__class__.__name__)

# Generated at 2022-06-23 22:05:57.528296
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field(locale='en')
    result = field('__str__')
    assert field != result
    # Fix https://github.com/lk-geimfari/mimesis/issues/519#issuecomment-482653879
    assert isinstance(result, str)
    assert '<Generic' in result
    result = field('provider.name')
    assert isinstance(result, str)
    assert result == 'Generic'
    result = field('__str__', key=lambda x: len(x))
    assert result in range(0, field.__str__())  # noqa: WPS609
    assert field('unsupported_field') == UnsupportedField()



# Generated at 2022-06-23 22:06:00.401991
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: True)
    assert schema.create(2) == [True, True]

# Generated at 2022-06-23 22:06:04.882187
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema.simple import Simple
    from mimesis.schema import Field

    f = Field()
    s = Simple(f)

    data = s.create()
    assert len(data) == 1

    data = s.create(2)
    assert len(data) == 2

# Generated at 2022-06-23 22:06:08.669134
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'name': 'dummy',
        'kind': 'Persons.full_name',
    }

    field = Field()
    result = Schema(schema).create(iterations=1)[0]
    assert result == schema

# Generated at 2022-06-23 22:06:10.576659
# Unit test for constructor of class Schema
def test_Schema():
    Schema()
    # TODO: uncomment after adding code
    #Schema(schema='test')

# Generated at 2022-06-23 22:06:17.294903
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField.

    :return: True
    :rtype: bool
    """
    from mimesis.builtins import Person
    from mimesis.enums import Gender
    from mimesis.providers.address import Address

    field = Field()
    assert isinstance(field('person.full_name'), str)
    assert isinstance(field('person.full_name', gender=Gender.MALE), str)
    assert isinstance(field('person.full_name', gender=Gender.FEMALE), str)

    assert isinstance(field('address.country'), str)
    assert isinstance(field('address.street_address'), str)

    # Test with key function
    assert isinstance(field('address.country', key=str.upper), str)

# Generated at 2022-06-23 22:06:25.027883
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: '')
    assert callable(schema)

    from mimesis.schema import AbstractField
    field = AbstractField()

    assert field.locale == 'en'
    assert field.__str__() == 'AbstractField <en>'


# Generated at 2022-06-23 22:06:28.910830
# Unit test for method create of class Schema
def test_Schema_create():
    fill = lambda: {'test', 'test'}

    schema = Schema(fill)
    result = schema.create(iterations=2)

    assert result == [{'test', 'test'}, {'test', 'test'}]



# Generated at 2022-06-23 22:06:30.837840
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Create instance of AbstractField."""
    field = Field()
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:06:35.936617
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> JSON:
        return {
            'first_name': Field('name.get_first_name'),
            'last_name': Field('name.get_last_name'),
            'full_name': Field('name.get_full_name'),
            'age': Field('person.age'),
        }

    assert isinstance(Schema(schema), Schema)



# Generated at 2022-06-23 22:06:38.617687
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField.

    This method must return value of 'AbstractField <locale>',
    where <locale> is locale, which you set before.
    """
    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'

    field = AbstractField(locale='en')
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:06:41.332306
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abstract_field = AbstractField()
    # Bug https://github.com/lk-geimfari/mimesis/issues/535
    assert isinstance(abstract_field, AbstractField)

# Generated at 2022-06-23 22:06:46.408632
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis import Person
    from mimesis.schema import Field
    from mimesis.exceptions import UndefinedField
    from mimesis.providers.person import Person as PersonProvider

    f = Field(locale='ru', seed=12345)
    assert isinstance(f, AbstractField)
    p = Person('ru')

    # Tests for using provider methods
    assert p.full_name() == f.full_name()
    assert p.full_name() == f(name='full_name')
    assert p.full_name() == f(name='person.full_name')
    assert p.full_name() == f(name='person.full_name')

    # Tests which return a random value
    assert p.age() == f.age()
    assert p.age() == f(name='age')

# Generated at 2022-06-23 22:06:48.021732
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:49.460346
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:49.991212
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    pass

# Generated at 2022-06-23 22:06:50.720260
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField __call__."""
    pass

# Generated at 2022-06-23 22:07:01.176257
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    abstract_field = Field(locale='en', seed=123)

    result = abstract_field('choice')
    assert result == 'Zealand'

    result = abstract_field('choice', 'Джозефина', 'Уильям', 'Марта')
    assert result == 'Уильям'

    result = abstract_field('choice', 12, 89, 100)
    assert result == 12

    result = abstract_field('personal.name', gender='female')
    assert result == 'Сабина'

    result = abstract_field('personal.name', key=lambda x: x.capitalize(),
                            gender='female')
    assert result == 'Сабина'


# Generated at 2022-06-23 22:07:07.914853
# Unit test for constructor of class Schema
def test_Schema():
    """."""
    from mimesis.schema.builder import CFSchema, CSchema

    # Define an empty schema
    empty_schema = CSchema()
    assert Schema(empty_schema).schema == empty_schema
    assert Schema(empty_schema()).schema == empty_schema

    # Define a schema with fields
    schema = CSchema(
        field1=None,
        field2=None,
        field3=None,
        field4=None,
        field5=None,
        field6=None,
    )
    assert Schema(schema).schema == schema



# Generated at 2022-06-23 22:07:09.629419
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema

    schema = Schema('123')

    assert schema

__all__.append('test_Schema')

# Generated at 2022-06-23 22:07:12.139378
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test AbstractField.__str__() is str."""
    field = AbstractField(locale='ru')
    assert isinstance(str(field), str)

# Generated at 2022-06-23 22:07:14.369709
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field
    field = AbstractField(seed=12345)
    assert field

# Generated at 2022-06-23 22:07:15.691704
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f.locale == 'en'

# Generated at 2022-06-23 22:07:17.045037
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:18.799199
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(providers=[])
    assert hasattr(field, '_gen')



# Generated at 2022-06-23 22:07:24.827097
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    field = AbstractField()

    data = field(name='email')
    data_ = field(name='datetime.datetime')
    data_with_key = field(name='payment_card.card_number', key=lambda x: x.lower())

    try:
        _ = field(name='not_supported_method')
    except UnsupportedField:
        assert True
    else:
        assert False

    assert data is not None
    assert data_ is not None
    assert data_with_key is not None

# Generated at 2022-06-23 22:07:25.995085
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:07:27.163577
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:29.069410
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.data import SCHEMAS
    s = Schema(SCHEMAS['json'])

    assert s is not None

# Generated at 2022-06-23 22:07:31.552413
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    title = Field()
    description = Field()
    assert str(title) == 'Field <en>'
    assert str(description) == 'Field <en>'

# Generated at 2022-06-23 22:07:35.588602
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create."""
    def create_schema():
        """Create simple schema."""
        return {"key": True}

    iterable = Schema(create_schema).create()

    assert iterable[0]['key']



# Generated at 2022-06-23 22:07:43.410957
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema."""
    # pylint: disable=C0115
    from mimesis.enums import Gender, PersonTitle
    from mimesis.providers import Person

    class Human:

        def __init__(self):
            self.data = {
                'first_name': self.first_name,
                'last_name': self.last_name,
                'full_name': self.full_name,
                'title': self.title,
                'birthday': self.birthday,
            }

        first_name = Person('en').first_name
        last_name = Person('en').last_name
        full_name = Person('en').full_name
        title = Person('en').title
        birthday = Person('en').birthday

    schema = Human()

    schema

# Generated at 2022-06-23 22:07:44.243307
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:07:45.888892
# Unit test for constructor of class Schema
def test_Schema():
    def simple_schema():
        return {
            'field': 'value',
        }

    assert Schema(simple_schema)

# Generated at 2022-06-23 22:07:47.832295
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test that ``str`` returning class name and locale."""
    f = Field()
    assert isinstance(str(f), str)

# Generated at 2022-06-23 22:07:53.342208
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    field = AbstractField()

    results = [
        field('name'),
        field('name', gender='male'),
        field('name', gender='male', key=lambda x: x.upper()),
        field('person.name', gender='male'),
        field('person.name', gender='male', key=lambda x: x.upper()),
        field('name', gender='male', key=lambda x: x.upper()),
        field('person.name', gender='male', key=lambda x: x.upper()),
    ]

    for res in results:
        assert isinstance(res, str)
        assert res.istitle()

# Generated at 2022-06-23 22:08:02.107903
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis import Schema
    from mimesis.builtins import RussiaSpecProvider

    f = Field(locale='ru')
    name = (
        Schema('ru')
        .field('full_name')
        .field('username')
        .field('password', length=8)
        .field(
            'birthday',
            start=2012,
            end=2018,
            fmt='%Y.%m.%d')
        .field('email')
        .field('phone')
    )()

    assert isinstance(name, dict)
    f.add_providers(RussiaSpecProvider)
    assert f.__str__() == 'AbstractField <ru>'

# Generated at 2022-06-23 22:08:07.577930
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    a = AbstractField()
    call_result = a('self.__repr__')
    assert call_result in repr(a)

    call_result = a('self.__repr__', key=str)
    assert call_result == repr(a)

    call_result = a('random.uuid4')
    assert call_result

    call_result = a('random.uuid4', key=str)
    assert call_result

    # def test_method() -> str:
    #     return 'something'
    #
    # call_result = a('random.uuid4', key=test_method)
    # assert call_result == 'something'


# Generated at 2022-06-23 22:08:09.142073
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'



# Generated at 2022-06-23 22:08:12.804797
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()

    assert isinstance(field, AbstractField)
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None

    field.__call__('username')  # noqa: WPS609



# Generated at 2022-06-23 22:08:22.195114
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Magic method __call__ returns by name of the method."""
    field = AbstractField(seed=42)

    assert field('personal.full_name') == 'William Shaw'
    assert field('full_name', gender='male') == 'Benjamin Holmes'
    assert field('full_name') == 'Jonathan Wade'
    assert field('personal.full_name') == 'Yvonne Osborne'
    assert field('personal.name') == 'Joseph'
    assert field('name') == 'Harold'

    assert field('uuid4') == 'f8d442ad-85b1-4bed-b26a-6fbf13a52f9c'
    assert field('uuid4') == '77a2e64d-ae0a-4458-9f79-0c9e3ca3c3d8'
   

# Generated at 2022-06-23 22:08:24.444253
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'


# Generated at 2022-06-23 22:08:30.299880
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    import pytest
    from mimesis.exceptions import UndefinedField, UnsupportedField

    field = AbstractField(providers=['datetime'])

    with pytest.raises(UndefinedField):
        field(name=None)

    with pytest.raises(UnsupportedField):
        field('foo')

    assert field('strftime') is not None
    assert field('strftime', format='%Y') >= '1970'
    assert callable(field('strftime', format='%Y', key=callable))
    assert field('strftime', format='%Y',
                 key=lambda x: int(x) >= 1970) is True
    assert field('datetime.strftime', format='%Y') >= '1970'
    assert callable(field('datetime.strftime', format='%Y', key=callable))



# Generated at 2022-06-23 22:08:35.477219
# Unit test for constructor of class Schema
def test_Schema():
    def my_schema(field: Field) -> JSON:
        return {
            'user_id': field('uuid'),
        }

    sch = Schema(my_schema)
    assert isinstance(sch, Schema)
    assert isinstance(sch.schema, Callable)



# Generated at 2022-06-23 22:08:40.437116
# Unit test for method create of class Schema
def test_Schema_create():
    """Need to test method create."""
    iterations = 3

    def create_schema() -> JSON:
        """Create schema for testing."""
        return {
            'name': 'Eggs',
            'amount': Field('integer_number')
        }

    eggs = Schema(create_schema).create(3)

    assert isinstance(eggs, list)
    assert len(eggs) == iterations

# Generated at 2022-06-23 22:08:51.969568
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():

    f = AbstractField(seed=10)

    def key(result):
        return 'key'

    assert f('uuid4') == '79a5b0da-f9a0-41d8-a90f-1a62a1bc6788'
    assert f('uuid4', key=key) == 'key'
    assert f('uuid4', version='v1') == '8dce11af-5a84-30fe-b938-8a1b2ebc2646'

    assert f('person.name') == 'Catherine Walker'
    assert f('Person.name') == 'Catherine Walker'
    assert f('person.surname') == 'Hopkins'
    assert f('Person.surname') == 'Hopkins'


# Generated at 2022-06-23 22:08:54.125478
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for class Schema."""
    schema = Schema(1)
    assert schema is not None

# Generated at 2022-06-23 22:09:03.220833
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method of filled schema."""
    from mimesis.enums import Gender
    from mimesis.schema.attrs import Attrs
    from mimesis.schema.datetime import Datetime
    from mimesis.schema.numbers import Numbers
    from mimesis.schema.structures import Structures
    from mimesis.schema.text import Text

    field = Field(seed=1337)

    attrs = Attrs(field=field)
    num = Numbers(field=field)
    text = Text(field=field)
    date = Datetime(field=field)
    struct = Structures(field=field)


# Generated at 2022-06-23 22:09:04.105678
# Unit test for constructor of class AbstractField
def test_AbstractField():
    AbstractField()


# Generated at 2022-06-23 22:09:06.050249
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(seed=42)

    assert field.locale == 'en'
    assert field.seed == 42

# Generated at 2022-06-23 22:09:09.700327
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {
            'ssn': field('ssn'),
            'name': field('name'),
        }

    field = AbstractField()
    sch = Schema(schema)
    print(sch.create())

# Generated at 2022-06-23 22:09:10.888865
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:13.070718
# Unit test for constructor of class AbstractField
def test_AbstractField():
    _field = AbstractField(locale='en', seed=1)
    assert isinstance(_field, AbstractField)

# Generated at 2022-06-23 22:09:22.425527
# Unit test for method create of class Schema
def test_Schema_create():
    """Create a list of filled schemas as a unit test."""
    from mimesis.typing import JSON
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.date import Date

    def schema() -> JSON:
        return {
            'name': Person('en').full_name(),
            'address': Address('en').address_line(),
            'birthday': Date('en').date(),
        }

    sch = Schema(schema)
    assert isinstance(sch, Schema) and isinstance(sch.create(3), list)



# Generated at 2022-06-23 22:09:25.132195
# Unit test for constructor of class Schema
def test_Schema():
    class SchemaInstance:
        def __call__(self):
            return {'foo': 'bar'}

    schema = Schema(SchemaInstance())
    assert schema.schema() == {'foo': 'bar'}

# Generated at 2022-06-23 22:09:36.011315
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.datetime import Datetime
    # Test 1
    field = Field(seed=42)
    # Test 1.1
    field.seed = 42

    # Test 1.2
    field.locale = 'en'

    # Test 1.3
    assert field.locale == 'en'

    # Test 1.4
    assert field.seed == 42

    # Test 2
    assert field('full_name') == 'Dr. Ruby Harvey'

    # Test 3
    assert field('person.full_name') == 'Dr. Ruby Harvey'

    # Test 4
    assert field('full_name', key=lambda x: x.split(' ')[0]) == 'Dr.'

    # Test 5
    assert field('code.iban') == 'EE73284212404266565'

    # Test 6

# Generated at 2022-06-23 22:09:37.082632
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test AbstractField __str__ method."""
    a = AbstractField()
    assert str(a) == "AbstractField <en>"

# Generated at 2022-06-23 22:09:39.113551
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:40.764318
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:44.468662
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Create the default field
    field = AbstractField()

    assert field.locale is not None
    assert field.locale == field._gen.locale

    assert field.seed is not None
    assert field.seed == field._gen.seed

# Generated at 2022-06-23 22:09:52.306943
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """
    This method tests the method ``__call__``.

    Assertion: Returns value which represented by method.
    """
    field = Field()

    # Test with a string parameter which not supported
    with pytest.raises(UnsupportedField):
        field('foo')

    # Test with a string parameter which have not tail
    with pytest.raises(ValueError):
        field('Guid', version='v4')

    # Test with a string parameter which have tail and not exist
    with pytest.raises(UnsupportedField):
        field('foo.bar')

    # Test with a string parameter which have tail and exist
    field('json.dumps')

    # Test with a string parameter which have tail but the method
    # is unacceptable for tail

# Generated at 2022-06-23 22:09:55.028540
# Unit test for method create of class Schema
def test_Schema_create():
    import mimesis

    schema = mimesis.schema.Field()

    data = schema.create(10)
    assert len(data) == 10
    assert isinstance(data, list)

# Generated at 2022-06-23 22:10:02.450454
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method Schema.create."""
    from mimesis import Person
    from mimesis.schema import Field, BaseSchema
    import uuid

    field = Field()

    class TestSchema(BaseSchema):
        """Test case for the class Schema."""

        first_name = field('first_name')
        second_name = field('last_name')
        age = field('age')
        uuid_field = field('uuid')

    person = Person('ru')
    person.seed(str(uuid.uuid4()))
    test_schema = TestSchema()

    data = test_schema.create(iterations=10)

    assert len(data) == 10


# Generated at 2022-06-23 22:10:10.793635
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test the method __call__ from AbstractField class."""
    from mimesis.providers.date import Date, Datetime
    from mimesis.providers.number import Number

    field = AbstractField(locale='en', seed=0, providers=(Date, Datetime))
    assert field('Date.date', '2019-03-28') == '2019-03-28'
    assert field('Datetime.date', '2019-03-28') == '2019-03-28'
    assert field('date', '2019-03-28') == '2019-03-28'
    assert field('Datetime.datetime', '2019-01-01T01:00:01') == '2019-01-01T01:00:01'

# Generated at 2022-06-23 22:10:13.710362
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('randterms', n=3, separator='-') == 'field-sort-value'
    assert f('randterms', n=1) == 'email'
    assert f('randterms', n=1, key=lambda x: x[0]) == 'e'

# Generated at 2022-06-23 22:10:14.262436
# Unit test for constructor of class Schema
def test_Schema():
    pass

# Generated at 2022-06-23 22:10:21.828489
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Tests for methods which provide unsupported data providers
    for method_name in ('abstract_provider', 'method', 'provider.method'):
        assert AbstractField()(method_name) is None
    # Tests for methods which provide undefined data providers
    for method_name in ('undefined_provider', 'method', 'provider.method'):
        assert AbstractField()(method_name) is None
    # Tests for methods which provide defined data providers
    for method_name in ('datetime', 'date', 'time', 'datetime.now'):
        assert AbstractField()(method_name) is not None


# Unit tests for Schema class

# Generated at 2022-06-23 22:10:23.950987
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:10:34.117610
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for AbstractField.__call__.

    This test checks behavior of AbstractField.__call__ method
    with different values of parameters.
    """
    from mimesis.providers.code import Code
    from mimesis.providers.cryptographic import Cryptographic
    field = AbstractField(providers=[Code, Cryptographic])

    # 1. Select data by method name
    assert field('sha256') is not None
    assert field('xor', key=lambda x: x.hexdigest(),
                 data='a', key2='b') is not None
    assert field('text', key=lambda x: x.upper(),
                 alphabet='abc', amount=5) is not None
    assert field('xor', key=lambda x: x.hexdigest(),
                 data=b'a', key2='b') is not None


# Generated at 2022-06-23 22:10:38.741197
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of AbstractField class."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'



# Generated at 2022-06-23 22:10:40.491323
# Unit test for constructor of class Schema
def test_Schema():
    @Schema
    def f():
        return {}

    assert isinstance(f, Schema)



# Generated at 2022-06-23 22:10:43.790817
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField."""
    assert str(AbstractField()) == 'AbstractField <en>'
    assert str(AbstractField(locale='ru')) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:10:45.445815
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check method AbstractField.__str__."""
    f = Field()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:55.755465
# Unit test for method __call__ of class AbstractField

# Generated at 2022-06-23 22:10:56.718283
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert field.__str__() == 'AbstractField <en>'


# Generated at 2022-06-23 22:11:06.301558
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # If a method not supported raise exception
    field = AbstractField()

    try:
        field('get_foo')
    except UnsupportedField:
        pass

    # If a method not defined raise exception
    try:
        field()
    except UndefinedField:
        pass

    # If a provider not supported raise exception
    try:
        field('foo.bar')
    except UnsupportedField:
        pass

    # If tail not found raise exception
    try:
        field('foo.bar.baz')
    except UnacceptableField:
        pass

    # If tail incorrect raise exception
    try:
        field('foo..bar')
    except UnacceptableField:
        pass

# Generated at 2022-06-23 22:11:11.200049
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender

    def schema() -> JSON:
        person = Field()
        return {
            'fullname': person('full_name', gender=Gender.MALE),
            'gender': person('gender', abbr=True),
        }

    result = Schema(schema).create(iterations=10)
    for elem in result:
        assert 'name' in elem
        assert 'gender' in elem

# Generated at 2022-06-23 22:11:16.106238
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__.

    Override standard call so it takes any string which
    represents the name of any method of any supported
    data provider.
    """
    f = Field()

    result = f('file_extension')
    assert result in Generic().file.extensions

    result = f('file.extension')
    assert result in Generic().file.extensions

    result = f('text.word', length=10)
    assert len(result) == 11



# Generated at 2022-06-23 22:11:21.057732
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Create a new instance of class AbstractField
    field = Field()
    field._gen.add_provider(
        'test', {'name': lambda x: 'test'})

    # Create a new instance of class Field
    # Set up an __call__ method of class AbstractField
    # And return the result of function
    field.__call__ = lambda name, **kwargs: getattr(field._gen, name)()
    assert field.__call__('test') == 'test'



# Generated at 2022-06-23 22:11:22.567386
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert field.__str__() == "AbstractField <en>"

# Generated at 2022-06-23 22:11:24.592111
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field(locale='ru')
    assert f.__str__() == 'AbstractField <ru>'

# Generated at 2022-06-23 22:11:32.878042
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField.

    For more information see documentation of the
    :class:`~mimesis.schema.AbstractField` class.

    :return: None.
    :raises: None.
    """
    from mimesis.enums import Gender

    assert str(Field()) == 'AbstractField <en>'
    assert str(Field('ru')) == 'AbstractField <ru>'
    assert str(Field('ru', Gender.FEMALE)) == 'AbstractField <ru>'



# Generated at 2022-06-23 22:11:34.587126
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field('ru')
    assert field.__str__() == 'AbstractField <ru>'



# Generated at 2022-06-23 22:11:35.648178
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert 'AbstractField <en>' == str(f)

# Generated at 2022-06-23 22:11:39.621629
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    assert field('email') == 'jmullen@gmail.com'
    assert field('email') == 'jmullen@gmail.com'
    assert field('email') == 'jmullen@gmail.com'
    assert field('email') == 'jmullen@gmail.com'
    assert field('email') == 'jmullen@gmail.com'



# Generated at 2022-06-23 22:11:50.326283
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.enums import Gender
    from mimesis.providers.other import Crypto
    from mimesis.providers.misc import Misc
    from mimesis.providers.network import Network
    from mimesis.providers.internet import Internet
    from mimesis.providers.datetime import Datetime

    field = AbstractField()

    # Positive tests
    field('seed')
    field(Datetime.seed.__name__)
    field(Datetime.seed.__name__, datetime='2019-04-23 12:15:00')
    field('seed')
    field('datetime.seed')
    field('datetime.seed', datetime='2019-04-23 12:15:00')

    field('security.token_hex')
    field('security.token_hex', length=128)
   

# Generated at 2022-06-23 22:11:52.634279
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField constructor."""
    af = Field()
    assert af.locale == 'en'
    assert af.seed is None

# Generated at 2022-06-23 22:11:54.941456
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema constructor."""
    data = Schema(None)
    assert isinstance(data, Schema)

# Generated at 2022-06-23 22:11:55.920610
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:58.574504
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('foo').isdigit()
    assert field('foo', bar='baz') == 'baz'
    assert field('foo', key=int) == 0



# Generated at 2022-06-23 22:12:00.042864
# Unit test for constructor of class Schema
def test_Schema():
    from ..contrib.schemas import person
    Schema(person)

# Generated at 2022-06-23 22:12:02.737739
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    field = AbstractField('ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:12:14.045008
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create."""
    from operator import itemgetter

    from mimesis.data import JAPANESE_FIRST_NAMES, US_FIRST_NAMES

    schema = Schema(lambda: {
        'name': Field(locale='jp').full_name(),
        'age': Field().age(),
    })

    names = schema.create(iterations=100)

    assert len(names) == 100
    assert sorted(names, key=itemgetter('name'))[0]['name'] in \
        JAPANESE_FIRST_NAMES
    assert sorted(names, key=itemgetter('name'))[1]['name'] in \
        JAPANESE_FIRST_NAMES


# Generated at 2022-06-23 22:12:16.247813
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema."""
    s = Schema('test')
    assert s.schema == 'test'



# Generated at 2022-06-23 22:12:19.373817
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method ``__str__`` of class ``AbstractField``."""
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:28.815304
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    from mimesis.providers.person import Person

    def calc_schema() -> dict:
        """Calculation."""
        return {
            'first': 1,
            'second': 2,
            'operation':
                lambda: '+',
            'result':
                lambda x: x['first'] + x['second']
        }

    s = Schema(calc_schema)
    assert len(s.create()) == 1

    def _person(self) -> dict:
        """Person."""

# Generated at 2022-06-23 22:12:30.052464
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema({'name': 'name'})
    assert schema.schema() == {'name': 'name'}

# Generated at 2022-06-23 22:12:31.903679
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    class Field(AbstractField):
        pass

    assert str(Field('en')) == 'Field <en>'

# Generated at 2022-06-23 22:12:33.985578
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for __str__ method."""
    field = AbstractField(locale='en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:38.166388
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None
    assert field.locale == 'en'
    assert field.seed is None

    field = AbstractField('ru', seed=42)
    assert field.locale == 'ru'
    assert field.seed == 42



# Generated at 2022-06-23 22:12:45.944548
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.typing import DataFields

    from mimesis.providers import Address, Person, Text
    from mimesis.schema import Field, Schema

    _address = Address('ru')
    _person = Person('ru')
    _text = Text('ru')

    def schema_generator() -> DataFields:
        """Generate random data."""

# Generated at 2022-06-23 22:12:48.183371
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    f.locale = 'en'
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:49.781437
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:12:55.149637
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema."""
    schema = Schema(lambda: 1)
    assert schema.schema() == 1
    assert schema.create() == [1]
    assert schema.create(iterations=3) == [1, 1, 1]



# Generated at 2022-06-23 22:12:58.103375
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method AbstractField.__str__()"""
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:00.346378
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None



# Generated at 2022-06-23 22:13:04.977743
# Unit test for method create of class Schema
def test_Schema_create():
    """Test the class `Schema`."""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.types import Gender

    s = Schema(Field)
    assert isinstance(s.create(), list)
    assert len(s.create(5)) == 5

# Generated at 2022-06-23 22:13:10.028525
# Unit test for constructor of class AbstractField
def test_AbstractField():
    class Mock:
        def __init__(self, locale: str, seed: Optional[Seed]) -> None:
            pass

    cases = (
        (None, Mock),
        ('foo', Mock),
        ('bar', Mock),
    )

    for case, provider in cases:
        field = AbstractField(provider=provider(locale='en', seed=None))
        assert field._gen.__class__ is Mock

# Generated at 2022-06-23 22:13:13.787244
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field
    assert field.locale == 'en'
    assert field.seed is None

    locale = 'ru'
    seed = 12
    field = Field(locale, seed)

    assert field.locale == locale
    assert field.seed == seed



# Generated at 2022-06-23 22:13:16.729766
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {'a': 1, 'b': 2})
    assert schema



# Generated at 2022-06-23 22:13:18.021276
# Unit test for constructor of class Schema
def test_Schema():
    """Test class Schema."""
    try:
        Schema(list)
    except UndefinedSchema:
        pass

# Generated at 2022-06-23 22:13:22.672080
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> dict:
        """Return dict with schema."""
        return {
            'name': 'John Doe',
            'email': 'john-doe@example.com',
            'job': 'Software Engineer',
            'year': 1996
        }

    s = Schema(schema)
    assert s

    field = Field(seed=0)
    schema = field('schema.person')
    s = Schema(schema)
    assert s

# Generated at 2022-06-23 22:13:26.260002
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

    g = AbstractField(locale='ru')
    assert str(g) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:13:33.665123
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    schema = {
        'name': 'John Doe',
        'age': 23,
        'address': {
            'country': 'en',
            'region': 'en',
            'city': 'en',
        },
    }

    def schema_generator():
        """Generator of a schema."""
        return Field()(schema)

    data = Schema(schema_generator).create()
    assert data is not None, 'data is None'
    assert isinstance(data, list), 'data is not a list'
    assert len(data) == 1, 'data does not contain 1 element'
    assert type(data[0]) is dict, 'data[0] is not a dict'

# Generated at 2022-06-23 22:13:43.626830
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers import Address
    from mimesis.providers.address import AddressProvider
    from mimesis.providers.base import BaseDataProvider

    schema_field = Field()

    # noinspection PyUnresolvedReferences
    @schema_field.schema()
    def create_order() -> JSON:
        """Create test order."""
        return {
            'order_id': schema_field('order_id'),
            'customer_address': schema_field('address.street_address'),
            'quantity': schema_field('quantity'),
            'name': schema_field('person.name'),
            'address': schema_field('address.province'),
        }

    schema_field.register_provider(Address)

    actual = Schema(create_order).create(iterations=3)


# Generated at 2022-06-23 22:13:52.646709
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.builtins import RussiaSpecProvider

    def func() -> JSON:
        from mimesis.schema import Field
        from mimesis.schema import Schema

        return {
            "fio": Field('person.full_name'),
            "activity": Field('company.activity'),
            "name": Field('company.business_name'),
            "job": Field('russia.job'),
            "address": Field('russia.address'),
        }

    schema = Schema(func)
    jsons = schema.create(3)
    assert len(jsons) == 3
    assert isinstance(jsons, list)
    assert 'fio' in jsons[0]
    assert 'name' in jsons[0]
    assert 'activity' in jsons[0]
    assert 'address' in jsons

# Generated at 2022-06-23 22:13:57.943155
# Unit test for constructor of class Schema
def test_Schema():
    f = Field()
    assert isinstance(f, AbstractField)
    assert isinstance(f, Field)

    s = Schema(f.datetime.datetime_uuid)
    assert isinstance(s, Schema)

    d = s.create(3)
    assert isinstance(d, list)
    assert len(d) == 3

# Generated at 2022-06-23 22:13:59.846535
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field('ru')
    assert field.locale == 'ru'


# Generated at 2022-06-23 22:14:09.712556
# Unit test for method create of class Schema
def test_Schema_create():
    """Test a method create of class Schema."""
    from mimesis import Generic
    from mimesis.enums import Gender
    from mimesis.providers.address import Address

    person_schema = Generic('en')
    address_schema = Address('en')

    def person() -> JSON:
        """Return person."""
        name = person_schema.person.full_name()
        gender = person_schema.person.gender()
        age = person_schema.person.age(
            minimum=18, maximum=99)
        address = address_schema.address.full_address()
        return {
            'name': name,
            'age': age,
            'gender': gender,
            'address': address,
        }

    schema = Schema(person)

# Generated at 2022-06-23 22:14:13.233135
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field(locale='uk', providers=['text'])
    assert field('sentence').split()[0] == 'Ця'
    assert field('sentence', words=10).split()[0] == 'Ця'

# Generated at 2022-06-23 22:14:15.790695
# Unit test for method create of class Schema
def test_Schema_create():
    s = Schema(lambda: [{'name': 'foo'}])
    result = s.create()

    assert result == [{'name': 'foo'}]

# Generated at 2022-06-23 22:14:19.690775
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema."""
    import mimesis.builtins
    import mimesis.schema
    assert not Schema(mimesis.builtins.Boolean)
    assert not Schema(mimesis.schema.Field)
    assert Schema(Schema)

# Generated at 2022-06-23 22:14:27.152803
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """If everything goes well, the test will pass."""
    from mimesis.providers.datetime import Datetime

    field = AbstractField()

    assert field('datetime.datetime')

    field._gen.add_providers(Datetime)

    assert field('datetime')

    assert field('datetime.datetime')

    try:
        field('datetime.now.year')
    except AttributeError:
        pass
    else:
        raise Exception('Test failed.')

    assert field('datetime.now', year=1990)

    assert field('datetime', year=1990)

# Generated at 2022-06-23 22:14:30.365355
# Unit test for constructor of class Schema
def test_Schema():
    def schema_() -> dict:
        from mimesis import Person

        person = Person()
        return {'name': person.full_name(), 'age': person.age()}

    assert Schema(schema_).create() == [schema_()]

# Generated at 2022-06-23 22:14:37.842528
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor and method AbstractField.__call__."""
    g = AbstractField()
    assert g.locale == 'en'

    g = AbstractField(locale='ru')
    assert g.locale == 'ru'

    g.locale = 'de'
    assert g.locale == 'de'

    g = AbstractField(seed=541)
    assert g.seed == 541
    assert g('uuid') == 'c02bbea8-f9cd-4d7f-a218-ce0ca8e1cb18'

    g.seed = 367
    assert g.seed == 367
    assert g('uuid') == 'f817e55d-e605-4d60-9c4c-3d213a79b754'

# Generated at 2022-06-23 22:14:44.413445
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Check the correctness of generating data for a given schema."""

# Generated at 2022-06-23 22:14:45.968783
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abc = AbstractField()
    assert callable(abc)



# Generated at 2022-06-23 22:14:48.294996
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test __str__ method."""
    res = str(AbstractField())

    assert '<en>' in res

# Generated at 2022-06-23 22:14:51.013424
# Unit test for constructor of class Schema
def test_Schema():
    schema = {"foo": "bar"}
    s = Schema(lambda: schema())  # type: ignore
    assert s is not None