

# Generated at 2022-06-23 22:04:51.670119
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit-test for ``AbstractField``."""
    field = Field()
    assert field is not None

    field = Field(seed=123)
    assert field is not None

# Generated at 2022-06-23 22:04:56.044217
# Unit test for constructor of class Schema
def test_Schema():
    def _t(a: JSON) -> JSON:
        return a
    _t_str = '{}'

    try:
        Schema(1)
    except UndefinedSchema:
        pass

    assert str(Schema(_t)) == 'Schema <{}>'.format(_t_str)

# Generated at 2022-06-23 22:05:03.582737
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        'key_1': 'value_1',
        '__many__': [{
            'key_2': 'value_2',
            '__many__': [{
                'key_3': 'value_3'
            }]
        }]
    }

    class TestSchema:
        def __call__(self) -> JSON:
            return schema

    schema = TestSchema()
    generated_data = Schema(schema).create()

    assert generated_data is not None

# Generated at 2022-06-23 22:05:06.359177
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    # Raise UndefinedField
    with pytest.raises(UndefinedField):
        field()

    assert field('uuid')



# Generated at 2022-06-23 22:05:08.896834
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test __str__ method."""
    field = Field(locale='en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:11.210083
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f.locale == 'en'
    assert f.seed is None



# Generated at 2022-06-23 22:05:22.021488
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__ method."""
    field = Field()
    value1 = field('person.full_name')
    value2 = field('person.full_name')
    value3 = field('person.full_name', key=lambda x: x.lower())
    value4 = field('person.full_name', key=str.lower)
    assert value1 != value2
    assert value3 == value4
    assert value1 == value2.title()
    assert len(value3.split(' ')) == 2

    try:
        field('invalid_provider.invalid_method')
    except ValueError:
        assert True
    else:
        assert False  # pragma: no cover

    try:
        field('invalid_method')
    except ValueError:
        assert True

# Generated at 2022-06-23 22:05:23.476558
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField(locale='en')) == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:25.628827
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    a = str(f)
    assert a == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:29.078930
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    _ = AbstractField()
    _ = AbstractField(locale='en')
    _ = AbstractField(seed=1)
    _ = AbstractField(locale='en',
                      seed=1)
    _ = AbstractField(providers=[])



# Generated at 2022-06-23 22:05:33.053072
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda: {'foo': 'bar'})
    assert schema.create(iterations=3) == [{'foo': 'bar'}, {'foo': 'bar'}, {'foo': 'bar'}]



# Generated at 2022-06-23 22:05:34.610135
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:37.579334
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, object)
    assert field.locale == 'en'



# Generated at 2022-06-23 22:05:39.825669
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:41.472247
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema


# Unit test create method of class Schema

# Generated at 2022-06-23 22:05:48.008884
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.providers import Person as PersonProvider
    from mimesis.schema import Field

    def schema(gen: Field) -> dict:
        return {
            'name': gen('person.full_name',
                        gender=Gender.MALE),
            'age': gen(PersonProvider.age,
                       minimum=0, maximum=99)
        }
    s = Schema(schema)
    assert isinstance(s.create(3), list)

# Generated at 2022-06-23 22:05:49.114358
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {})
    assert schema.schema() == {}



# Generated at 2022-06-23 22:05:57.672909
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('datetime')
    assert field('datetime.date')
    assert field('datetime.date', '%d-%m-%Y')
    assert field('datetime.time')
    assert field('datetime.time', '%d-%m-%Y')
    assert field('person.gender')
    assert field('person.gender', key=lambda x: x[0])
    assert field('person', gender=True)
    assert field('person.gender', True)
    assert field('text.lorem_ipsum')
    assert field('text.lorem_ipsum', key=lambda x: len(x))
    assert field('text.lorem_ipsum', words=100)

# Generated at 2022-06-23 22:06:00.383020
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    def s_func(field: Field) -> JSON:
        return {'user': field('username')}

    s = Schema(s_func)
    s.create(2)

    ss = Schema(dict)
    ss.create(2)

# Generated at 2022-06-23 22:06:05.261036
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField."""
    # Locale
    _locale = 'en'
    # Seed
    seed = 'mimesis'

    field = AbstractField(_locale, seed)
    assert str(field) == '{} <{}>'.format(
        field.__class__.__name__, _locale)

# Generated at 2022-06-23 22:06:14.404502
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Test without any args
    field = Field()
    assert field.locale == 'en'

    # Test with locale
    field = Field('ru')
    assert field.locale == 'ru'

    # Test with kwarg locale
    field = Field(locale='ja')
    assert field.locale == 'ja'

    # Test with kwarg seed
    field = Field(seed=123)
    assert field.seed == 123

    # Test with seed
    field = Field('en', seed=1)
    assert field.seed == 1

    # Test with kwarg providers
    from mimesis.providers.geography import Geography
    geog = Geography('en')
    field = Field(providers=[geog])
    assert field._gen.geography == geog

# Generated at 2022-06-23 22:06:19.367921
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert 'Visa' in field('credit_card')
    assert 'Uzbek' in field('country')
    assert len(field('password')) == 8
    assert field('password', length=10)
    assert 'Tajik' in field('nationalities.ethnicity')
    assert 'Tajik' in field('nationalities.ethnicity', length=10)
    assert len(field('password', length=12)) == 12

# Generated at 2022-06-23 22:06:26.310928
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()


# Generated at 2022-06-23 22:06:29.703877
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Create field with method integer
    field = Field()

    # Call the method
    result = field('integer')

    assert isinstance(result, int)



# Generated at 2022-06-23 22:06:31.254667
# Unit test for constructor of class Schema
def test_Schema():
    class SimpleSchema:
        pass

    assert isinstance(Schema(SimpleSchema), Schema)

# Generated at 2022-06-23 22:06:34.822782
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    import pytest

    with pytest.raises(UndefinedField):
        field()

    with pytest.raises(UnsupportedField):
        field('some_provider')

    with pytest.raises(UnacceptableField):
        field('provider.method.method')

    field('data')
    field('food.sweet')

# Generated at 2022-06-23 22:06:42.762091
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField.__call__."""
    field = AbstractField()

    # Try to call method, which is not inside of Generic
    # Catch an exception UndefinedField
    try:
        _ = field()  # noqa
    except UndefinedField:
        pass
    else:
        assert False

    # Call method, which is inside of Generic
    assert callable(field.internet)

    assert field('internet.url') is not None
    assert field('internet.ipv4') is not None
    assert field('internet.ipv6') is not None
    assert field('internet.domain_name') is not None
    assert field('internet.user_name') is not None
    assert field('internet.email') is not None

    # Try to call method, which is not inside of Generic
    # Catch an exception UnsupportedField


# Generated at 2022-06-23 22:06:44.866644
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.locale == 'en'

# Generated at 2022-06-23 22:06:46.019540
# Unit test for constructor of class Schema
def test_Schema():
    assert isinstance(Schema, object)

# Generated at 2022-06-23 22:06:47.153590
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:50.294404
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Smoke unit test."""
    field = AbstractField()
    uuid = field('uuid')
    assert isinstance(uuid, str)
    assert uuid != ''
    assert len(uuid) == 36

# Generated at 2022-06-23 22:06:56.002712
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""

    class TestField(Field):
        """TestField is a class for testing AbstractField."""

        def __init__(self):
            """Initialize test field."""
            super().__init__()

    field = TestField()
    result = field('boolean', true_chance=1)
    assert result is True  # type: ignore

# Generated at 2022-06-23 22:06:56.942856
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:59.720634
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema('a')
    assert s is not None
    assert s.schema == 'a'

# Generated at 2022-06-23 22:07:04.924481
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # pylint: disable=W0612
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.math import Math

    f = Field()
    f._gen.add_providers(Cryptographic, Math)

    assert f.locale == 'en'
    assert isinstance(f._gen, Generic)
    assert isinstance(f, AbstractField)



# Generated at 2022-06-23 22:07:12.357246
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    result = Schema(lambda: {
        'name': 'Tomas',
        'surname': 'Naugt'
    }).create(2)
    assert isinstance(result, list)
    assert result == [{
        'name': 'Tomas',
        'surname': 'Naugt'
    }, {
        'name': 'Tomas',
        'surname': 'Naugt'
    }]

# Generated at 2022-06-23 22:07:14.457689
# Unit test for constructor of class Schema
def test_Schema():
    assert isinstance(Schema(SchemaType()), Schema)

# Generated at 2022-06-23 22:07:15.782029
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert 'AbstractField' in str(field)

# Generated at 2022-06-23 22:07:18.012647
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {})
    assert isinstance(schema, Schema)
    assert isinstance(schema.schema, Callable)

# Generated at 2022-06-23 22:07:20.381048
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:23.912753
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(locale='ru')
    assert field.locale == 'ru'
    assert field.seed is None

    field = Field(locale='en', seed=42)
    assert field.locale == 'en'
    assert field.seed == 42

# Generated at 2022-06-23 22:07:24.528023
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-23 22:07:29.603905
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    from mimesis.utils import gen_seed

    lang = 'en'
    seed = gen_seed()
    f = AbstractField(lang, seed)

    assert f.locale == lang
    assert f.seed == seed

    seed = gen_seed()
    f = AbstractField(seed=seed)

    assert f.locale == 'en'
    assert f.seed == seed



# Generated at 2022-06-23 22:07:31.101920
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:32.935577
# Unit test for constructor of class Schema
def test_Schema():
    def callable_schema() -> JSON:
        return {'foo': 'bar'}

    schema = Schema(callable_schema)
    assert schema.create(100)

# Generated at 2022-06-23 22:07:37.902697
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.generic import Generic
    from mimesis.providers import Address, Datetime

    f = Field()
    assert isinstance(f._gen, Generic), \
        'Not isinstance of Generic'

    assert 'address' in dir(f._gen), \
        'Address provider not loaded.'

    assert 'datetime' in dir(f._gen), \
        'Datetime provider not loaded.'

    f = Field(locale='ru', seed=123456789)
    assert f._gen.locale == 'ru', 'Locale not set.'
    assert f._gen.seed == 123456789, 'Seed not set.'

    # Add another two providers and check that they are loaded.
    f = Field(locale='ru', seed=123456789,
              providers=(Address, Datetime))


# Generated at 2022-06-23 22:07:39.349076
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:07:41.587095
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for AbstractField.__str__."""
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'


# Unit test

# Generated at 2022-06-23 22:07:47.587113
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test of method __call__ of class AbstractField."""
    import pytest

    def keyfunc(word: str) -> str:
        """Key function."""
        word = word.capitalize()
        return word

    f = Field()
    assert f('key', key=keyfunc) == 'Key'

    with pytest.raises(UndefinedField):
        f()

    with pytest.raises(UndefinedField):
        f('')

    with pytest.raises(UnsupportedField):
        f('foo')

    with pytest.raises(UnacceptableField):
        f('foo.bar.baz')

# Generated at 2022-06-23 22:07:51.039020
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {'a': Field()('name')}
    assert all(elem in {'a': 'James Cook'} for elem in Schema(schema).create())



# Generated at 2022-06-23 22:07:53.453346
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField."""
    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:08:03.590684
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    ab = AbstractField()

    # Raise value error if provider not supported
    try:
        ab('fake')
    except UnsupportedField:
        pass
    else:
        raise ValueError('Must be raise unsupported provider error')

    # Raise value error if field not defined
    try:
        ab('choice')
    except UndefinedField:
        pass
    else:
        raise ValueError('Must be raise field not found error')

    # If method not exists but used explicitly
    try:
        ab('fake.method')
    except UnsupportedField:
        pass
    else:
        raise ValueError('Must be raise unsupported provider error')

    # Check that return error if Argument provider exists but method not
    try:
        ab('personal.fake')
    except AttributeError:
        pass

# Generated at 2022-06-23 22:08:06.741254
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        field = AbstractField('ru')
    except Exception as exc:
        assert isinstance(exc, ValueError)
    else:
        assert field is not None

# Generated at 2022-06-23 22:08:11.102815
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> dict:
        return {
            'name': 'Mimesis',
            'version': '0.8.4',
        }

    result = Schema(schema).create(iterations=10)
    assert isinstance(result, list)
    assert len(result) == 10



# Generated at 2022-06-23 22:08:17.647904
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for AbstractField."""
    field = Field()
    result = field('uuid')
    assert type(result) is str

    result = field('uuid', key=lambda x: x[:8])
    assert type(result) is str

    data = field('bitcoin_blockchain_address')
    assert type(data) is str
    assert len(data) == 34



# Generated at 2022-06-23 22:08:18.709259
# Unit test for constructor of class AbstractField
def test_AbstractField():
    schema = AbstractField('ru', None)
    assert schema.locale == 'ru'
    assert schema.seed is None

# Generated at 2022-06-23 22:08:21.170027
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema(lambda: {'a': 1})
    assert isinstance(s, Schema)

# Generated at 2022-06-23 22:08:23.597396
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """AbstractField.__str__.

    Check that method returns string representation.
    """
    f = Field()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:29.866909
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Create a Field instance
    field = Field()

    # get a value from the method
    assert field('datetime')

    # get a value from the method of the specified provider
    assert field('personal.full_name')

    # get a list of values
    assert field('choice', ['foo', 'bar', 'baz']) is not None

    # get a value with a key
    assert field('age', key=int)

    # get a value with **kwargs
    assert field('choice', ['foo', 'bar', 'baz'], k=1) is not None

    # get a value from the method of the specified provider
    assert field('personal.full_name')

    # get a value from the method of the specified provider
    # with **kwargs
    assert field('personal.full_name', gender='male') is not None

# Generated at 2022-06-23 22:08:34.312907
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.schema import Schema
    from mimesis.providers import Person

    person = Person('ru')
    data = Schema(lambda: {
        'name': person.full_name(gender=Gender.MALE),
        'city': person.city(),
        'address': person.address(),
    }).create(iterations=5)
    assert len(data) == 5

# Generated at 2022-06-23 22:08:37.288538
# Unit test for constructor of class Schema
def test_Schema():
    assert callable(Schema)
    assert callable(Schema({}))
    assert callable(Schema({'test': 'Hello World'}))



# Generated at 2022-06-23 22:08:39.707563
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': Field().full_name(),
            'email': Field().email(),
            'phone': Field().telephone(),
        }

    Schema(schema).create()

# Generated at 2022-06-23 22:08:43.296082
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {
        'name': Field('name')
    })
    assert schema.schema() == {
        'name': 'Tiffany Curtis'
    }

# Generated at 2022-06-23 22:08:45.895809
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert callable(field)
    assert field.locale == 'en'

# Generated at 2022-06-23 22:08:47.145882
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:50.870481
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__()."""
    field = AbstractField()
    assert callable(field)

    # Test error handling
    name = None
    assert field(name) is None

    # Test field from common provider
    name = 'author'
    assert len(field(name)) > 0

    # Test field from common provider with kwargs
    name = 'code_point'
    assert len(field(name, symbol=False)) > 1

    # Test field from common provider with key
    name = 'just_int'
    key = len
    assert field(name, key=key) == 1

    # Test field from specific provider
    name = 'datetime.date'
    value = field(name)
    assert type(value) == str

    # Test field from specific provider with kwargs

# Generated at 2022-06-23 22:08:54.542183
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test case for ``__str__`` method."""
    af = AbstractField()
    actual = str(af)
    expected = 'AbstractField <en>'
    assert actual == expected, 'Got: {}'.format(actual)

# Generated at 2022-06-23 22:08:56.015708
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    assert Field().__call__('age') == Field()._gen.personal.age()

# Generated at 2022-06-23 22:08:57.418848
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(seed=123)
    assert field is not None


# Generated at 2022-06-23 22:09:01.827887
# Unit test for method create of class Schema
def test_Schema_create():
    """Run unit test for Schema.create method."""
    field = Field(locale='en')
    schema = {
        'uuid': field('uuid'),
        'int': field('integer_number'),
    }

    s = Schema(lambda: schema)

    assert len(s.create(1)) == 1
    assert len(s.create()) == 10

# Generated at 2022-06-23 22:09:03.217127
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:07.462296
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for Schema."""
    import pytest

    schema = Schema(lambda: {'name': 'vasya'})
    assert isinstance(schema, Schema)

    with pytest.raises(UndefinedSchema):
        Schema('bla')



# Generated at 2022-06-23 22:09:11.006744
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)
    assert isinstance(field._gen, Generic)
    assert field.locale == 'en'
    assert field.seed is None
    assert 'age' in field._table



# Generated at 2022-06-23 22:09:12.497286
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:09:17.551418
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method AbstractField.__call__.

    GIVEN:
        The value 'person' which represents the method name.

    WHEN:
        The method __call__ is called.

    THEN:
        The method __call__ should return not empty string.

    """
    f = Field()
    assert f('person')

# Generated at 2022-06-23 22:09:19.285209
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField.

    Test class AbstractField
    """
    af = AbstractField()
    af('person.name')

# Generated at 2022-06-23 22:09:22.209045
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {
            'name': faker.name(),
            'email': faker.internet.email(),
            'address': faker.address(),
        }

    _ = Schema(schema)

# Generated at 2022-06-23 22:09:25.117090
# Unit test for method create of class Schema
def test_Schema_create():
    from .decorators import with_field
    @with_field()
    def phone_numbers(field):
        return field('phone_number')

    schema = Schema(phone_numbers)
    schema.create(iterations=3)

# Generated at 2022-06-23 22:09:27.610142
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    gen = AbstractField()
    assert gen.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:35.886947
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method AbstractField.__call__."""
    field = AbstractField()
    assert callable(field)

    person = field(name='choice', items=['Ivan', 'Vladimir'])
    assert isinstance(person, str)

    price = field(name='money', currency='USD', cents=True,
                  symbol=False, positive=True)
    assert isinstance(price, float)

    assert field.__call__('choice', items=['Ivan', 'Vladimir']) == person
    assert field.__call__('money', currency='USD', cents=True,
                          symbol=False, positive=True) == price

# Generated at 2022-06-23 22:09:38.908850
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    for i in range(10):
        item = field('random.number')
        # Make sure that every number is unique.
        assert item not in {field('random.number') for _ in range(100)}


# Generated at 2022-06-23 22:09:42.300537
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    a = Field(locale='ru')
    assert 'Анна' in a('person.full_name')
    assert len(a('person.iban')) == 18
    assert '.' in a('person.email')
    assert a('internet.url') == ''  # https://github.com/lk-geimfari/mimesis/issues/586

# Generated at 2022-06-23 22:09:45.401645
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Simple usage
    assert callable(Field)

    # Local
    field = Field(locale='uk')
    assert field.locale == 'uk'

    # Seed
    field = Field(seed=42)
    assert field.seed == 42

    # Empty argument
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None



# Generated at 2022-06-23 22:09:48.469912
# Unit test for constructor of class Schema
def test_Schema():
    class Schema1(Schema):
        def __call__(self):
            return dict(
                color=Field('color'),
                name=Field('name'),
                any=Field('any'),
            )

    Schema1()
    assert True

# Generated at 2022-06-23 22:09:53.556665
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Create a new instance of AbstractField
    field = AbstractField()

    # Call a method of fake provider
    assert field('text')

    # Call a method of fake provider with fake
    # param and let's try to use unicode.
    assert field('text', opt=u'\u000A')

# Generated at 2022-06-23 22:10:00.619258
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test ``__call__`` method.

    To represent an end point is available as follows:
    1. ```name='provider.method'``` (recommended way).
    2. ```name='method'``` (without provider.method)
    """
    field = AbstractField()

    # 1. Way
    assert field('address.address')
    assert field('business.company')
    assert field('datetime.datetime')
    assert field('internet.email')
    assert field('lorem.sentence')
    assert field('person.full_name')
    assert field('programming.programming_language')

    # TODO: Add more tests


# Generated at 2022-06-23 22:10:04.629490
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for str method in AbstractField."""
    assert str(Field()) == 'AbstractField <en>'
    assert str(Field(locale='ru')) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:10:11.480845
# Unit test for constructor of class Schema
def test_Schema():
    def schema_func():
        return {
            'id': '84e7d4ab-b49e-4e4a-9666-0a0aac1c813e',
            'name': 'Pomme de terre',
            'description': 'Ceci est une description.',
            'quantity': '18',
            'unit_price': '2.25',
            'token': 'aac0ac813e-b49e-0a0a-9666-e7d4ab84',
        }

    schema = Schema(schema_func)
    assert schema_func is schema.schema
    assert [schema_func()] == schema.create(1)



# Generated at 2022-06-23 22:10:19.838572
# Unit test for method create of class Schema
def test_Schema_create():
    """Test creating a list of schemas."""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers import Internet

    @Schema
    def test(field: Field) -> JSON:
        """This is sample schema."""
        return {
            'name': field('full_name', gender='female'),
            'sex': field('sex'),
            'email': field('email'),
            'year': field('century'),
            'time': field('timestamp'),
        }

    field = Field(providers=[RussiaSpecProvider, Internet()])
    data = test.create(10, field=field)
    assert data is not None
    assert isinstance(data, list)
    assert len(data) == 10

# Generated at 2022-06-23 22:10:22.050167
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> str:
        """Fake schema."""
        return 'foo'

    Schema(schema)



# Generated at 2022-06-23 22:10:26.606103
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {
            'id': Field('uuid', version=4),
        }

    s = Schema(schema)
    assert isinstance(s, Schema)

    sch = s.create(iterations=3)
    for _s in sch:
        assert _s['id'] is not None

# Generated at 2022-06-23 22:10:30.559813
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema."""
    try:
        Schema('str')
        assert False, 'Should raise an error'
    except UndefinedSchema:
        pass

    assert Schema(lambda: {})
    assert Schema(object)



# Generated at 2022-06-23 22:10:31.939881
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:34.533902
# Unit test for method create of class Schema
def test_Schema_create():
    def test_schema() -> JSON:
        return {
            'name': 'Person',
            'age': 32,
        }

    assert len(Schema(test_schema).create()) == 1

# Generated at 2022-06-23 22:10:36.875879
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit-test for method __call__ of class AbstractField."""
    # assert True
    pass

# Generated at 2022-06-23 22:10:38.237866
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema({})

# Generated at 2022-06-23 22:10:41.112598
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test call by name."""
    field = AbstractField()
    assert field('SHA1') is not None
    field.__call__()  # pylint: disable=no-value-for-parameter



# Generated at 2022-06-23 22:10:43.001609
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.builtins.schema import schema as sch

    assert isinstance(Schema(sch), Schema)

# Generated at 2022-06-23 22:10:47.465582
# Unit test for constructor of class Schema
def test_Schema():
    # If callable object is passed
    schema = Schema(lambda: {})
    assert schema.schema == {}

    # If not callable object is passed
    try:
        Schema({'foo': 'bar'})
    except UndefinedSchema:
        pass
    else:
        assert False



# Generated at 2022-06-23 22:10:49.453111
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:53.830398
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    # test for exception UnsupportedField
    assert field('some_provider_name') is None
    # test for exception UnacceptableField
    assert field('text.text.text') is None
    # test for exception UndefinedField
    assert field() is None
    # test for exception UndefinedSchema
    assert Schema() is None

# Generated at 2022-06-23 22:10:55.050522
# Unit test for constructor of class Schema
def test_Schema():
    test_schema = 'str'

    assert Schema(test_schema)

# Generated at 2022-06-23 22:10:56.874278
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field('faker.name') == 'Amber Abbott'
    assert field('name') == 'Aubree Conner'

# Generated at 2022-06-23 22:11:02.246630
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    schema = Schema(lambda: {
        'name': {
            'first': 'name',
            'last': 'surname',
            'full_name': 'person.full_name',
            'gender': Gender.MALE,
        }
    })
    schema.create(iterations=10)

# Generated at 2022-06-23 22:11:04.066723
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('uuid4')
    assert field('uuid4')
    assert field('uuid4')
    assert field('uuid4')
    assert field('uuid4')

# Generated at 2022-06-23 22:11:08.703959
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Field

    f = Field()
    users = Schema(lambda: {
        'name': f('person.name'),
        'email': f('person.email'),
        'id': f('integer', minimum=1),
    })

    assert len(users.create(5)) == 5

# Generated at 2022-06-23 22:11:12.794334
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.builtins import RussiaSpecProvider

    gen = Generic(locale='ru', seed=1)
    gen.add_provider(RussiaSpecProvider)
    field = AbstractField(providers=gen)

    assert field('politics.president') == 'Борис Ельцин'
    assert field('rus.business.company_suffix') == 'ия'

# Generated at 2022-06-23 22:11:17.213725
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    import os
    import json
    import mimesis

    with open(os.path.realpath('tests/schemas/faker_schema.json'), 'r') as f:
        schema = json.loads(f.read())

    s = Schema(mimesis.schema.create_schema(schema))
    assert len(s.create()) == 1

# Generated at 2022-06-23 22:11:21.690935
# Unit test for constructor of class Schema
def test_Schema():
    def schema_() -> SchemaType:
        """Schema."""
        return {
            'name': 'Name',
            'surname': 'Surname',
            'age': 'Age',
        }

    schema = Schema(schema_)
    assert isinstance(schema, Schema) is True



# Generated at 2022-06-23 22:11:25.496025
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField."""
    field = Field()
    assert field is not None
    assert field.locale == 'en'
    assert field.seed is None
    assert field._gen is not None
    assert field._table == {}

# Generated at 2022-06-23 22:11:29.388508
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'name': '', 'age': 0, 'height': 160.5}

    def callback(field: 'AbstractField') -> SchemaType:
        new_schema = {
            'name': field('person.full_name'),
            'age': field('random_int', start=1, end=100),
            'height': field('random_float', a=155, b=190),
        }
        return new_schema

    data = Schema(callback).create(iterations=5)
    assert len(data) == 5
    assert isinstance(data, list)
    assert schema in data

# Generated at 2022-06-23 22:11:29.785060
# Unit test for constructor of class Schema
def test_Schema():
    pass

# Generated at 2022-06-23 22:11:33.643046
# Unit test for method create of class Schema
def test_Schema_create():
    schema_ = lambda: {
        'name': Field('en').full_name,
        'profile': {
            'email': Field('en').email,
            'mobile': Field('en').telephone,
        }
    }

    schema = Schema(schema_)
    schema.create()



# Generated at 2022-06-23 22:11:40.026200
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField through Schema class."""
    # Schema of person name
    @Schema
    def get_name(field: Field) -> JSON:
        """Return schema of person name."""
        return {
            'first_name': field('first_name'),
            'last_name': field('last_name'),
        }

    names = get_name.create(5)
    assert isinstance(names, list)
    assert len(names) == 5

    for item in names:
        assert 'first_name' in item
        assert 'last_name' in item
        assert isinstance(item['first_name'], str)
        assert isinstance(item['last_name'], str)



# Generated at 2022-06-23 22:11:46.063522
# Unit test for method create of class Schema
def test_Schema_create():
    """Testing for method Schema.create."""
    from mimesis.schema import Schema

    def schema():
        """Fake schema object."""
        return {
            'field1': 'foo',
            'field2': 'bar',
        }

    s = Schema(schema)
    assert len(s.create()) == 1
    assert len(s.create(iterations=10)) == 10



# Generated at 2022-06-23 22:11:50.142655
# Unit test for method create of class Schema
def test_Schema_create():
    """Test create method of class Schema."""
    from mimesis.schema import Address, Person

    person = Person('ru')
    address = Address('ru')

    schema = lambda: {
        'name': person.full_name(gender='male'),
        'email': person.email(),
        'address': address.address(),
        'city': address.city(),
    }

    result = Schema(schema).create(5)
    assert len(result) == 5

    err = False
    try:
        Schema(1)
    except UndefinedSchema:
        err = True
    assert err

    err = False
    try:
        Schema(schema).create(-5)
    except TypeError:
        err = True
    assert err

# Generated at 2022-06-23 22:11:51.618508
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Schema
    assert Schema is not None

# Generated at 2022-06-23 22:11:52.597516
# Unit test for constructor of class AbstractField
def test_AbstractField():
    a = AbstractField()



# Generated at 2022-06-23 22:11:54.530487
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    sf = AbstractField()
    assert isinstance(str(sf), str)

# Generated at 2022-06-23 22:11:59.222183
# Unit test for method create of class Schema
def test_Schema_create():
    def _func() -> dict:
        return {
            'a': 'b',
        }

    schema = Schema(_func)
    result = schema.create(2)

    assert type(result) == list
    assert len(result) == 2
    assert result[0] == result[1]
    assert type(result[0]) == dict
    assert result[0]['a'] == 'b'

# Generated at 2022-06-23 22:12:01.220107
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for AbstractField constructor."""
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:12:04.463023
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(abc=1)
    assert schema.create(iterations=3) == [{'abc': 1}] * 3

# Generated at 2022-06-23 22:12:07.324936
# Unit test for constructor of class Schema
def test_Schema():
    schema = {'name': "Name", 'age': "Age"}
    try:
        Schema(schema)
    except UndefinedSchema:
        assert True

# Generated at 2022-06-23 22:12:10.552774
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda: {'x': 'y'})
    filled = schema.create(100)
    assert len(filled) == 100



# Generated at 2022-06-23 22:12:16.064248
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of Schema.

    Passing None to Schema constructor must
    raise UndefinedSchema exception.
    """
    try:
        Schema(None)
    except UndefinedSchema as err:
        assert isinstance(err, UndefinedSchema)
    except BaseException as err:
        assert isinstance(err, UndefinedSchema)
    else:
        print('UndefinedSchema exception not raised.')

# Generated at 2022-06-23 22:12:17.259736
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field('en')
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:23.440835
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema() -> JSON:
        return {
            'a': 'a',
            'b': 'b',
        }

    schema = Schema(test_schema)
    assert callable(schema)
    assert isinstance(schema.create(), list)

    for data in schema.create(10):
        assert isinstance(data, dict)



# Generated at 2022-06-23 22:12:25.547494
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()
    from mimesis.providers.internet import Internet
    f('gen.choice', providers=[Internet])



# Generated at 2022-06-23 22:12:35.936629
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.builtins import Field, Schema
    from mimesis.providers.geography import Geography, usa
    from mimesis.providers.person import Person
    from mimesis.schema import SchemaObject, as_list

    person = Person()
    geography = Geography(locale='en')

    @SchemaObject()
    def some_schema():
        return {
            'id': Field('uuid'),
            'name': Field('full_name'),
            'email': Field('email'),
            'address': {
                'city': Field('city'),
                'country': Field('country'),
            },
            'comment': Field('comment', key=as_list),
        }

    assert len(some_schema) == 6


# Generated at 2022-06-23 22:12:37.955164
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {'test': 100}
    assert isinstance(Schema(schema), Schema)

# Generated at 2022-06-23 22:12:42.257202
# Unit test for constructor of class Schema
def test_Schema():
    def a_schema():
        return {
            'a': 1,
            'b': 2,
            'c': 3,
        }

    schema = Schema(a_schema)
    data = schema.create(iterations=5)
    assert len(data) == 5



# Generated at 2022-06-23 22:12:43.580366
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('person.full_name').startswith('Dr')

# Generated at 2022-06-23 22:12:45.222756
# Unit test for constructor of class AbstractField
def test_AbstractField():
    FA = AbstractField()
    assert FA is not None



# Generated at 2022-06-23 22:12:48.315073
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert len(field('uuid')) == 36
    assert field('uuid', key=lambda x: len(x)) == 36



# Generated at 2022-06-23 22:12:55.791765
# Unit test for method create of class Schema
def test_Schema_create():
    # test_Schema_create_1
    field = AbstractField()

    def schema():
        return {
            'name': field('person.full_name'),
            'address': field('address.address'),
        }

    s = Schema(schema)
    assert isinstance(s.create(), list)
    assert len(s.create()) == 1
    assert isinstance(s.create(3), list)
    assert len(s.create(3)) == 3

# Generated at 2022-06-23 22:13:03.917111
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method AbstractField.__call__.

    It must execute field's method with kwargs and must return expected
    result.
    """
    provider = Field('en')
    assert provider('uid') is not None
    assert provider('uid', length=15) is not None
    assert provider('person.full_name') is not None
    assert provider('person.full_name', gender='female') is not None
    assert provider(name='uid') is not None
    assert provider(name='uid', length=15) is not None
    assert provider(name='person.full_name') is not None
    assert provider(name='person.full_name', gender='female') is not None

# Generated at 2022-06-23 22:13:11.874974
# Unit test for method create of class Schema
def test_Schema_create():
    """Check for the method ``create`` of :class:`~mimesis.schema.Schema`.

    :return:
    """
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person

    schema = Schema(
        Field(locale='en',
              providers=(
                  Address,
                  Internet,
                  Person,
              ))
    )

    for user in schema.create(1):
        pass

    for user in schema.create(10):
        pass



# Generated at 2022-06-23 22:13:15.301829
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field()
    assert Field()
    assert Field(locale='ru')
    assert Field(seed=0)
    assert Field(locale='ru', seed=0)
    assert Field(providers=['datetime'])
    assert Field(providers=['datetime', 'personal'])



# Generated at 2022-06-23 22:13:18.088748
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    _ = AbstractField()
    assert _('data_provider') != _('data_provider')

    field = AbstractField(seed=42)
    assert field('data_provider') == field('data_provider')

    _ = AbstractField(locale='ru', seed=42)
    _('data_provider')

# Generated at 2022-06-23 22:13:24.701524
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test __call__ method."""
    field = Field()
    # Undefined provider and method
    assert field('some_undefined_provider.some_undefined_method') is None

    # Undefined method
    assert field('some_undefined_method') is None

    # Undefined method for defined data provider
    assert field('generic.some_undefined_method') is None

    # Method from a data provider
    assert field('uuid4') is not None

    # Method from a data provider with key function
    assert field('uuid4', key=lambda x: x.replace('-', '')) is not None

    # Undefined data provider and method
    with pytest.raises(UndefinedField):
        field()

    # Method from a data provider with another method

# Generated at 2022-06-23 22:13:27.793829
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    for name in ('name', 'full_name', 'address.address', 'phone'):
        assert field(name)

# Generated at 2022-06-23 22:13:30.571911
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    assert f('email') == f('email')
    assert f('random_element',container=['a','b']) == 'a'
    assert f('random_element',container=['a','b']) in ['a','b']

# Generated at 2022-06-23 22:13:31.419145
# Unit test for constructor of class Schema
def test_Schema():
    schema = None
    schema = Schema(schema)

# Generated at 2022-06-23 22:13:32.174777
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:34.092789
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test that AbstractField was initialized."""
    sample = Field()
    assert isinstance(sample, AbstractField)

# Generated at 2022-06-23 22:13:37.481997
# Unit test for constructor of class AbstractField
def test_AbstractField():
    required = ['_gen', 'locale', 'seed', '_table']
    for elem in required:
        assert hasattr(AbstractField(), elem)

# Generated at 2022-06-23 22:13:40.256992
# Unit test for constructor of class AbstractField
def test_AbstractField():
    a = AbstractField(seed=1234, locale='ru')
    assert a.locale == 'ru'
    assert a.seed == 1234
    assert a._gen is not None

# Generated at 2022-06-23 22:13:42.245601
# Unit test for constructor of class Schema
def test_Schema():
    try:
        Schema(schema=None)
    except:
        pass

# Generated at 2022-06-23 22:13:46.050157
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    assert 'ComplexField' in str(AbstractField())
    assert 'ComplexField' not in str(AbstractField(locale='ru'))

# Generated at 2022-06-23 22:13:49.959707
# Unit test for constructor of class Schema
def test_Schema():
    """Test object."""
    schema = Schema(lambda: {'x': 'y'})
    assert schema.create(1) == [{'x': 'y'}]
    assert schema.create(2) == [{'x': 'y'}, {'x': 'y'}]

# Generated at 2022-06-23 22:13:52.175560
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()

    assert field.locale == 'en'
    assert field.seed == None



# Generated at 2022-06-23 22:13:54.043217
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert isinstance(field('datetime', year=2050), str)

# Generated at 2022-06-23 22:13:56.158797
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'



# Generated at 2022-06-23 22:13:58.785895
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert type(field.__call__('string')) == str
    assert type(field.__call__('integer')) == int

# Generated at 2022-06-23 22:14:01.688986
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {'a': 1})
    assert schema.schema() == {'a': 1}
    assert isinstance(schema.create(), list)

# Generated at 2022-06-23 22:14:03.218257
# Unit test for constructor of class Schema
def test_Schema():
    """Test Schema constructor."""
    assert Schema(list) is not None

# Generated at 2022-06-23 22:14:06.049541
# Unit test for constructor of class Schema
def test_Schema():
    schema = {'name': 'Tom'}

    s = Schema(schema)

    assert s

# Generated at 2022-06-23 22:14:08.561136
# Unit test for constructor of class Schema
def test_Schema():
    """Test for Schema class constructor."""
    s = Schema(iter)
    assert isinstance(s, Schema)



# Generated at 2022-06-23 22:14:11.116113
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema should be failed."""
    try:
        Schema("")
    except UndefinedSchema:
        pass

    Schema(lambda: None)

# Generated at 2022-06-23 22:14:16.024504
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    _gen = field._gen

    field = AbstractField('ru', 'seed')
    assert field.locale == 'ru'
    assert field.seed == 'seed'
    assert field._gen != _gen

    assert field('full_name') != field('full_name')

# Generated at 2022-06-23 22:14:17.520793
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field('en')) == 'AbstractField <en>'



# Generated at 2022-06-23 22:14:26.898404
# Unit test for method __call__ of class AbstractField

# Generated at 2022-06-23 22:14:33.002907
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='en')
    assert field.locale == 'en'

    field = AbstractField(locale='ru')
    assert field.locale == 'ru'

    field = AbstractField(seed=123)
    assert field.seed == 123

    from mimesis.builtins.base import BaseSpecProvider

    class MyProvider(BaseSpecProvider):
        pass

    field = AbstractField(providers=[MyProvider()])
    assert hasattr(field._gen, 'my_provider')

# Generated at 2022-06-23 22:14:33.537154
# Unit test for constructor of class AbstractField
def test_AbstractField():
    Field()

# Generated at 2022-06-23 22:14:37.815016
# Unit test for method create of class Schema
def test_Schema_create():
    #: :type:JSON
    schema = {'a': str, 'b': int, 'c': float}
    obj = Schema(schema)
    data = obj.create()

    assert data is not None
    assert isinstance(data, list)
    assert len(data) == 1
    assert isinstance(data[0], dict)
    assert data[0] == {'a': '', 'b': 0, 'c': 0.0}



# Generated at 2022-06-23 22:14:39.987745
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test __str__ method of class ``AbstractField``."""
    field = Field()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:14:41.041241
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema('hi')
    assert schema

# Generated at 2022-06-23 22:14:42.815329
# Unit test for constructor of class Schema
def test_Schema():
    def func() -> JSON:
        return {'foo': 'bar'}

    Schema(func)

# Generated at 2022-06-23 22:14:46.914452
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    import pytest

    with pytest.raises(UndefinedField):
        f = Field()
        f()

    with pytest.raises(UnsupportedField):
        f('undefined')

    assert f('credit_card_number')

# Generated at 2022-06-23 22:14:53.787969
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # Test for method AbstractField.__call__
    # more than one provider has method 'name'
    # and return name from first provider
    f = AbstractField()
    assert f('name')  # should be as successful
    assert f('datetime.datetime.now')

    # Unsupported field
    try:
        f('doge')
    except UnsupportedField:
        # AssertionError
        assert 'doge' in f._table
        assert f('doge')