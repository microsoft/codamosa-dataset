

# Generated at 2022-06-23 22:04:41.828938
# Unit test for constructor of class Schema
def test_Schema():
    """Test for creating instance of class Schema."""
    from dataclasses import dataclass
    from mimesis import Person

    @dataclass
    class User:
        email: str = ''
        login: str = ''

    def schema() -> User:
        """Return dataclass User."""
        person = Person('en')
        return User(
            email=person.email(),
            login=person.username(),
        )

    data = Schema(schema).create()
    assert isinstance(data, list)

# Generated at 2022-06-23 22:04:47.838477
# Unit test for constructor of class AbstractField
def test_AbstractField():
    af = AbstractField()
    assert af
    assert af._gen.data('en')
    assert af._gen.data('de')
    assert af._gen.data('ru')
    assert af._gen.data('it')
    assert af._gen.data('fr')
    assert af._gen.data('hi')
    assert af._gen.data('ja')
    assert af._gen.data('ko')
    assert af._gen.data('ms')
    assert af._gen.data('pl')
    assert af._gen.data('sv')
    assert af._gen.data('vi')
    assert af._gen.data('zh-cn')
    assert af._gen.data('zh-tw')

# Generated at 2022-06-23 22:04:48.717126
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:04:52.250448
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return dict(
            a="b",
            c="d",
        )

    Schema(schema)



# Generated at 2022-06-23 22:04:53.832806
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(AbstractField(locale='en'), AbstractField)



# Generated at 2022-06-23 22:04:56.621582
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.geography import Geography

    field = Field(providers=[Geography])

    assert field('street_suffix')
    assert field('currency_code')

# Generated at 2022-06-23 22:05:05.933379
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.providers import BaseProvider
    class JunkProvider(BaseProvider):
        """Junk provider."""
        class Meta:
            name = 'junk'

    class CustomField(AbstractField):
        pass

    field = CustomField()
    custom_provider = JunkProvider(field._gen)
    field._gen.add_providers(custom_provider)
    assert field._table == {}
    assert str(field) == 'CustomField <en>'
    assert len(field._table) == 0

    field("junk")
    assert len(field._table) == 1
    assert str(field) == 'CustomField <en>'

# Generated at 2022-06-23 22:05:09.537328
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    ab = AbstractField(locale='en')
    assert 'AbstractField <en>' in str(ab)
    ab = AbstractField(locale='fi')
    assert 'AbstractField <fi>' in str(ab)

# Generated at 2022-06-23 22:05:13.892864
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='en', seed=10)

    assert field.locale == 'en'
    assert field.seed == 10

    field = AbstractField(locale='ru')

    assert field.locale == 'ru'
    assert field.seed is None



# Generated at 2022-06-23 22:05:17.472549
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    def check_method():
        class Test:
            def __str__(self):
                return 'Test class'

        return Test()

    t = Generic()
    a = AbstractField(providers=t)
    assert a.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:05:20.362213
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)
    assert field.locale == 'en'
    assert field.seed == None

# Generated at 2022-06-23 22:05:21.817954
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField class."""
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:05:23.736244
# Unit test for constructor of class AbstractField
def test_AbstractField():
    try:
        field = AbstractField()
    except UnacceptableField:
        pass

    assert field is not None

# Generated at 2022-06-23 22:05:31.958101
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    assert callable(field)

    assert field('choice') in ['a', 'b', 'c']
    assert field('choice', choices=['1', '2', '3']) in ['1', '2', '3']
    assert field('choice', choices=['1', '2', '3'],
                 key=lambda x: int(x)) in [1, 2, 3]
    assert field('identifier.uuid')
    assert field('business.company')
    assert field(
        'timeline.date', start='2019-01-01', end='2020-01-01').year == 2019

    with pytest.raises(UndefinedField):
        field()

    with pytest.raises(UnsupportedField):
        field('foo')


# Generated at 2022-06-23 22:05:33.600984
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    field('datetime')  # noqa



# Generated at 2022-06-23 22:05:44.869711
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.address import Address
    from mimesis.providers.date import Date
    from mimesis.providers.geo import Geo
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person

    def test_data(providers: List[Any]) -> None:
        """Test data.

        :param providers: List of providers.
        :return:
        """
        f = Field(providers=providers)

        data = f('person.name')
        assert isinstance(data, str)
        assert len(data) > 0

        data = f('person.full_name')
        assert isinstance(data, str)
        assert len(data) > 0


# Generated at 2022-06-23 22:05:49.181157
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.builders import SchemaFactory
    from mimesis.schema import Schema

    schema_ = SchemaFactory(schema_file='schemas/user.schema.json')
    schema = Schema(schema_)

    assert isinstance(schema, Schema)



# Generated at 2022-06-23 22:05:57.755137
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis import Person

    person = Person()

    def personal_schema() -> dict:
        return {
            'name': person.full_name(),
            'age': person.age(),
            'address': person.address(),
            'occupation': person.occupation(),
            'school': person.school(),
            'university': person.university(),
            'job': person.job(),
            'language': person.language(),
            'blood_group': person.blood_group(),
        }

    person_schema = Schema(personal_schema)
    person_data = person_schema.create()

    assert isinstance(person_data, list)
    assert isinstance(person_data[0], dict)



# Generated at 2022-06-23 22:06:03.722726
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Schema, Field
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.web import Web

    schema = Schema(Field(
        providers=[Address, Person, Datetime, Numbers, Web],
        locale='ru'))

    data = schema.create(iterations=3)
    assert isinstance(data, list)
    assert len(data) == 3
    assert isinstance(data[0], dict)
    assert len(data[0]) > 0

# Generated at 2022-06-23 22:06:09.633240
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'first': '#random.randint(1, 100)',
              'second': '#person.birthday'}

    js = Schema(schema)
    data = js.create(iterations=10)

    assert isinstance(data, list)
    assert len(data) == 10

    for d in data:
        for k, v in d.items():
            assert isinstance(k, str)

# Generated at 2022-06-23 22:06:16.795550
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.schema import Field

    f = Field()


# Generated at 2022-06-23 22:06:21.271744
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> JSON:
        return {
            'a': 'b',
            'c': 'd'
        }

    items = Schema(schema).create(1)
    assert isinstance(items, list)
    assert isinstance(items[0], dict)



# Generated at 2022-06-23 22:06:28.118969
# Unit test for method create of class Schema
def test_Schema_create():
    dummyschema = {
        'name': 'John',
        'surname': 'Doe',
        'age': 128,
        'address': {
            'country': 'USA',
            'city': 'New York'
        }
    }

    create = Schema(dummyschema).create(iterations=10)
    assert type(create) is list

    for item in create:
        assert type(item) is dict
        assert item['name'] == 'John'
        assert item['surname'] == 'Doe'

# Generated at 2022-06-23 22:06:31.133827
# Unit test for constructor of class Schema
def test_Schema():
    # GIVEN a class Schema
    s = Schema({})
    # WHEN running create()
    data = s.create(3)
    # THEN assert that create() returns a list of filled schemas
    assert isinstance(data, list)

# Generated at 2022-06-23 22:06:35.847152
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    f = Field()

    # Test for method __call__ with keyword argument key
    assert f(name='person.full_name', key=lambda s: s.split(' ')[0]) != ''

    # Test for method __call__ without keyword argument key
    assert f(name='person.full_name') != ''

# Generated at 2022-06-23 22:06:37.398774
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = Field()
    assert field('hello') == 'Hello!'

# Generated at 2022-06-23 22:06:44.287185
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__ method."""
    f = Field(seed=12345)

    # Check that all attributes are empty by default
    assert f.locale is None
    assert f.seed is None
    assert f._gen is None
    assert f._table == {}

    # Check that all attributes are set
    f = Field('en', seed=12345)
    assert f.locale == 'en'
    assert f.seed == 12345
    assert isinstance(f._gen, Generic)

    # Check that all attributes are set
    f = Field(seed=12345, locale='en')
    assert f.locale == 'en'
    assert f.seed == 12345
    assert isinstance(f._gen, Generic)

    # Check that _table is filled
    f = Field('en', seed=12345)

# Generated at 2022-06-23 22:06:54.126144
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test __call__ method of AbstractField class."""
    field = Field()
    assert callable(field)
    assert field.__call__('email') is not None
    assert field.__call__('email', address='org') is not None
    assert field.__call__('bank_card_number') is not None
    assert field.__call__('bank_card_number', card_class='american-express') is not None
    assert field.__call__('telephone') is not None
    assert field.__call__('telephone', country_code='PRC') is not None

    assert field.__call__('text.word', word=True) is not None
    assert field.__call__('text.word', word=False) is not None

# Generated at 2022-06-23 22:06:55.133450
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema



# Generated at 2022-06-23 22:06:56.000504
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'


# Generated at 2022-06-23 22:06:56.942526
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    schema = AbstractField()
    assert str(schema) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:00.682341
# Unit test for method create of class Schema
def test_Schema_create():
    # Create some schema
    def schema():
        return dict(
            one='One',
            two='Two',
            tree='Tree',
        )

    # Check if create method return list
    assert isinstance(Schema(schema).create(1), list)

# Generated at 2022-06-23 22:07:02.845164
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method AbstractField.__str__."""
    f = AbstractField(locale='ru')
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:07:04.252302
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    assert field('password', length=10)
    assert field('personal.passport_id')

# Generated at 2022-06-23 22:07:08.690290
# Unit test for method create of class Schema
def test_Schema_create():
    # First schema
    def simple_schema():
        for _ in ['M', 'F']:
            yield {
                'name': 'name',
                'gender': 'gender',
                'age': 'age',
            }

    schema1 = Schema(simple_schema)
    assert len(schema1.create()) == 1
    assert len(schema1.create(3)) == 3



# Generated at 2022-06-23 22:07:11.661742
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.locale == 'en'
    assert callable(field)
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:07:16.994968
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test work of method __call__."""
    field = AbstractField()
    result = field('uuid4')
    assert result

    result = field('uuid4')
    assert result

    def name_parser(name: str) -> str:
        return name.split(' ')[0]

    result = field('full_name', key=name_parser)
    assert result

# Generated at 2022-06-23 22:07:19.400972
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField constructor."""
    f = AbstractField(locale='ru', seed=123)
    assert isinstance(f, AbstractField)

# Generated at 2022-06-23 22:07:21.210465
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    fn = AbstractField()
    result = fn.__str__()
    assert result == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:23.297302
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': Field('ru-RU')()
        }

    Schema(schema).create()

# Generated at 2022-06-23 22:07:25.634484
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor."""
    from mimesis.schema import Schema

    schema = lambda: {}
    Schema(schema)



# Generated at 2022-06-23 22:07:29.312923
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.locale is not None
    assert field.seed is not None
    assert field._gen is not None

    field = Field(locale='ru', seed=12345)
    assert field.locale == 'ru'
    assert field.seed == 12345
    field.seed = None

# Generated at 2022-06-23 22:07:34.106294
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField.

    This test is not a unit test in the full sense of the word.
     It is intended to ensure that a new instance of
     class ``AbstractField`` will have all the attributes
     that are needed for the class to work.
    """
    f = AbstractField()
    assert hasattr(f, 'locale')
    assert hasattr(f, 'seed')
    assert hasattr(f, '_gen')
    assert hasattr(f, '_table')



# Generated at 2022-06-23 22:07:36.892009
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()

    class Key:
        def __call__(self, value: int) -> str:
            return str(value)

    field('randint', 1, 200, key=Key())



# Generated at 2022-06-23 22:07:42.272059
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Docstring for field."""
    assert Field().locale == 'en'
    assert Field().seed is None
    assert Field(locale='fr').locale == 'fr'
    assert Field(seed=42).seed == 42
    assert Field('ru', 42).locale == 'ru'
    assert Field('ru', 42).seed == 42


# Generated at 2022-06-23 22:07:43.313440
# Unit test for constructor of class Schema
def test_Schema():
    # :raises UndefinedSchema
    Schema(object)

# Generated at 2022-06-23 22:07:45.558134
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    # Given
    f = Field()

    # When
    actual = str(f)

    # Then
    assert actual == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:52.632879
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method ``__call__`` of class ``AbstractField``."""
    field = Field()  # Here is a bug in pylint: it is wrong
    # in mark as undefined attribute '_gen'.

    # Test for key function
    def func(text: str) -> str:
        """Func for testing."""
        return text.upper()
    result = field('text.word', key=func)
    assert len(result) > 3 and all(c.isupper() for c in result)

    # Test for undefined key
    result = field('text.word', key='undefined')
    assert len(result) > 3 and not all(c.isupper() for c in result)

    # Test for acception a name of field
    result = field('text.word')

# Generated at 2022-06-23 22:07:55.191404
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema."""
    import pytest

    with pytest.raises(UndefinedSchema):
        Schema('string')

    with pytest.raises(UndefinedSchema):
        Schema(0)

# Generated at 2022-06-23 22:07:58.690657
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test __call__() method of AbstractField class."""
    field = AbstractField()
    assert isinstance(field.__call__('code.isbn'), str)
    assert len(field.__call__('code.isbn', length=3)) == 3

# Generated at 2022-06-23 22:08:02.374160
# Unit test for constructor of class AbstractField
def test_AbstractField():
    abs_field = Field()
    assert abs_field is not None

    # With providers
    providers = ['mimesis.Person', 'mimesis.Code']
    abs_field = Field(providers=providers)
    assert abs_field is not None

# Generated at 2022-06-23 22:08:05.184085
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        field = Field()
        return {
            'fullname': field('full_name'),
            'country': field('country'),
            'age': field('age'),
        }

    s = Schema(schema)
    assert isinstance(s, Schema)

    assert isinstance(s.schema, Callable)



# Generated at 2022-06-23 22:08:11.930279
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('date')
    assert field('date')
    assert field('date')
    assert field('date_time')
    assert field('date_time')
    assert field('uuid')
    assert field('uuid')
    assert field('uuid')
    assert field('uuid')
    assert field('uuid')
    assert field('currency.code')
    assert field('currency.code')
    assert field('currency.code')

# Generated at 2022-06-23 22:08:20.872882
# Unit test for constructor of class Schema
def test_Schema():
    # Set the seed for get random values.
    seed = '1'

    from mimesis.providers import Person, MetaProviders
    from mimesis.schema import Field

    # Create a new Field instance
    f = Field(seed=seed, providers=(Person, MetaProviders))

    names = ('gender', 'name', 'surname', 'number')
    # Create a will return filled schema
    schema = lambda: dict((i, getattr(f, i)()) for i in names)

    # Create a new Schema instance
    s = Schema(schema)
    # Get the filled schema
    data = s.create(iterations=10)
    assert len(data) == 10



# Generated at 2022-06-23 22:08:26.103193
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider

    a = Address('en', providers=BaseProvider)

    def s() -> dict:
        r = {
            'first_name': a.first_name(),
            'last_name': a.last_name(),
        }
        return r

    Schema(s)

# Generated at 2022-06-23 22:08:26.945032
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:31.993389
# Unit test for method create of class Schema
def test_Schema_create():
    """Test generating data by simple schema."""
    schema = {
        'name': '@first_name',
        'age': '@integer(min=0, max=100)',
    }
    data = Schema(lambda: schema).create()
    assert isinstance(data, list)
    assert isinstance(data[0], dict)
    assert 'age' in data[0]
    assert 'name' in data[0]

# Generated at 2022-06-23 22:08:36.613627
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__ for correctness."""
    field = AbstractField()
    assert field('full_name') == 'John Doe'

    # Assert raise for undefined field
    try:
        field('qwerty')
    except UndefinedField:
        assert True

    # Assert raise for unacceptable field
    try:
        field('person.full_name.qwerty')
    except UnacceptableField:
        assert True

    # Assert raise for unsupported field
    try:
        field('undefined.field')
    except UnsupportedField:
        assert True

# Generated at 2022-06-23 22:08:37.919598
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert isinstance(field, AbstractField)

# Generated at 2022-06-23 22:08:42.449645
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()
    assert field('name') == 'John'
    assert field('name', gender='female') == 'Mary'
    assert field('sentence', key=str.upper) == field('sentence').upper()

# Generated at 2022-06-23 22:08:44.364189
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method create of class Schema."""
    assert len(Schema( {} ).create(1)) == 1

# Generated at 2022-06-23 22:08:46.540976
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:08:47.641589
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()
    f('ipv4')

# Generated at 2022-06-23 22:08:48.676281
# Unit test for method create of class Schema
def test_Schema_create():
    assert type(Schema.create()) == list

# Generated at 2022-06-23 22:08:51.461523
# Unit test for constructor of class AbstractField
def test_AbstractField():
    class Foo:
        pass

    assert Field().__str__() == 'AbstractField <en>'
    assert isinstance(Field(providers=[Foo()]), AbstractField)

# Generated at 2022-06-23 22:08:59.003057
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    def schema() -> JSON:
        """Return array of dicts."""
        p = Person('ru')
        return {
            'name': p.full_name(gender=Gender.FEMALE),
            'age': p.age(),
            'birthdate': p.birthday(),
            'passport_id': p.passport_id(),
        }

    sch = Schema(schema)
    assert sch.create(1) == [schema()]

# Generated at 2022-06-23 22:09:01.259934
# Unit test for constructor of class AbstractField
def test_AbstractField():
    provider = Field(seed=123)
    assert provider.locale == 'en'
    assert provider.seed == 123
    assert provider._gen is not None


# Generated at 2022-06-23 22:09:07.059605
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import schema

    def schema():
        s = schema.Schema(locale='ru')
        s.add_field('a', str)
        s.add_field('b', int)
        return s

    res = [
        {'a': 'str', 'b': 4},
        {'a': 'str', 'b': 4},
    ]
    assert Schema(schema).create(2) == res

# Generated at 2022-06-23 22:09:15.869586
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.address import Address
    from mimesis.typing import JSON
    from mimesis.enums import AddressType
    from mimesis.enums import Gender

    def schema_func() -> JSON:
        _ = Field(providers=[Address])


# Generated at 2022-06-23 22:09:19.601017
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor."""
    def test_schema() -> JSON:
        """Test schema."""
        return {'test': 'passed'}

    schema = Schema(test_schema)
    assert isinstance(schema, Schema)



# Generated at 2022-06-23 22:09:27.616175
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.base import NoneType

    class PersonSchema:
        """Person schema."""

        def __init__(self, data: JSON = None) -> None:
            self.data = data or {}

        @property
        def name(self) -> str:
            """Return name of person."""
            return self.data.get('name', '')

        @property
        def age(self) -> int:
            """Return age of person."""
            return self.data.get('age', 0)

        @property
        def not_field(self) -> NoneType:
            """Return a field that doesn't exist."""
            return self.data.get('not_field', None)

    schema = Schema(PersonSchema)
    result = schema.create()
    assert isinstance(result, list)

# Generated at 2022-06-23 22:09:32.952540
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check method __str__."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

    field = AbstractField(locale='en')
    assert str(field) == 'AbstractField <en>'

    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'



# Generated at 2022-06-23 22:09:34.811770
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField(locale='en')
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:37.326108
# Unit test for constructor of class AbstractField
def test_AbstractField():
    obj = AbstractField()

    assert isinstance(obj, AbstractField)
    assert isinstance(obj._gen, Generic)
    assert isinstance(obj._table, dict)


# Unit tests for AbstractField.__call__ method

# Generated at 2022-06-23 22:09:43.991138
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Field

    def schema_1():
        return [Field('code') for _ in range(10)]

    def schema_2():
        return [Field('code') for _ in range(10)]

    schema = Schema(schema_1)

    assert schema.create() == [
        ['P6JF', '8QI6', 'P6JF', 'X9O6', 'IJ0M', 'TJTJ', 'TJTJ', 'TJTJ', 'TJTJ', 'TJTJ'],
    ]

    schema = Schema(schema_2)

# Generated at 2022-06-23 22:09:45.127193
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:09:47.346034
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test class ``AbstractField``."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:51.487279
# Unit test for constructor of class Schema
def test_Schema():
    assert issubclass(Schema, object)
    try:
        _ = Schema('foo')
    except UndefinedSchema:
        pass
    else:
        raise AssertionError('If schema is not callable, it must be raised')

# Generated at 2022-06-23 22:09:54.277258
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Return class name and the locale."""
    locale = 'es'
    obj = Field(locale=locale)
    assert str(obj) == 'Field <{}>'.format(locale)

# Generated at 2022-06-23 22:09:55.291171
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField('en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:59.762553
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    _schema = {
        'name': lambda: field.name(),
        'age': lambda: field.age(),
        'birthday': lambda: field.datetime.date(),
    }

    expected_list = [_schema for _ in range(2)]

    s = Schema(_schema)
    assert expected_list == s.create(iterations=2)

# Generated at 2022-06-23 22:10:04.399880
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()

    assert isinstance(field, AbstractField)
    assert isinstance(field._gen, Generic)
    assert field.seed is None
    assert field.locale == 'en'
    assert callable(field)

# Generated at 2022-06-23 22:10:09.593057
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert f is not None
    assert callable(f)
    assert f.locale == 'en'
    f = Field('ru')
    assert f.locale == 'ru'
    f = Field(locale='uk')
    assert f.locale == 'uk'
    f = Field(seed=42)
    assert f.seed == 42
    f = Field(providers=[str])
    assert f.seed is None

# Generated at 2022-06-23 22:10:14.127179
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Tests for the AbstractField class."""
    def test_case(**kwargs):
        """Create instance of AbstractField and return result of __call__."""
        # Create an instance of AbstractField
        fld = Field(**kwargs)

        methods = ['full_name']
        return [fld(method) for method in methods]

    result = test_case()
    assert isinstance(result[0], str)

# Generated at 2022-06-23 22:10:16.085523
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():

    field = AbstractField()
    string = field.__str__()
    assert string == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:23.067729
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    from mimesis.enums import Gender
    from mimesis.providers.orem import Orem

    locale = 'ru'
    gender = Gender.MALE

    schema = {
        'name': 'person.full_name',
        'address': {
            'city': 'address.city',
            'street': 'address.street_name',
            'house': 'address.house_number',
        },
        'email': 'person.email',
    }

    orem = Orem(locale)

    providers = [orem]

    f = Field(locale, providers=providers)

    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:10:27.217272
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method __str__ of class AbstractField."""
    field = Field('en', seed=42)
    assert str(field) == 'AbstractField <en>'

    field = Field('ru', seed=42)
    assert str(field) == 'AbstractField <ru>'



# Generated at 2022-06-23 22:10:29.479583
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    field = AbstractField()
    assert hasattr(field._gen, 'datetime')



# Generated at 2022-06-23 22:10:35.395951
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor AbstractField."""
    field = Field()

    assert field.seed is not None
    assert field.locale == 'en'
    assert field.__str__() == 'AbstractField <en>'

    field2 = Field(locale='ru', seed=123)

    assert field2.seed == 123
    assert field2.locale == 'ru'
    assert field2.__str__() == 'AbstractField <ru>'



# Generated at 2022-06-23 22:10:36.446339
# Unit test for method create of class Schema
def test_Schema_create():
    pass


# Generated at 2022-06-23 22:10:39.702865
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method `AbstractField.__call__`."""
    field = AbstractField()
    result = field('full_name')
    assert result is not None
    assert callable(result)



# Generated at 2022-06-23 22:10:50.748283
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    with pytest.raises(UndefinedField):
        field()

    field('not_exist')
    # Python 2.7: UnsupportedField('not_exist')

    field('en')
    # Python 2.7: UnsupportedField('en')

    field('datetime')
    field('datetime.now')
    field('datetime.now', year=2018)
    field('datetime', now=True)
    field('datetime', now=True, year=2018)

    field('person')
    field('person.full_name')
    field('person.full_name', gender='male')

    field('person.occupation')
    field('person.occupation', gender='male')

    field('person.occupation', gender='male', key=lambda x: x.upper())


# Generated at 2022-06-23 22:10:52.815190
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    service = field('service')
    assert service in Generic.instance().services.list()
    assert callable(field)

# Generated at 2022-06-23 22:10:54.758675
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check method `__str__` of class AbstractField."""
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:59.224519
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for AbstractField."""
    from mimesis.enums import Gender

    def _field(name):
        """Helper func to get Field based on name."""
        return getattr(gen, name)

    gen = Field()
    gen_en = Field('en')
    gen_ru = Field('ru')
    gen_es = Field('es')

    assert gen_en.person.gender(male_only=True) == Gender.MALE
    assert gen_es.person.gender() == Gender.MALE

    assert _field('person.gender')(male_only=True) == Gender.MALE
    assert _field('person.gender')(female_only=True) == Gender.FEMALE
    assert _field('person.gender')() == Gender.MALE

# Generated at 2022-06-23 22:11:02.814660
# Unit test for constructor of class Schema
def test_Schema():
    def test_schema():
        return {
            'title': 'Lorem Ipsum',
            'author': 'Dolor',
            'published': '2015-01-01',
        }
    assert Schema(test_schema)



# Generated at 2022-06-23 22:11:04.672187
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()  # type: ignore
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:06.151560
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test for constructor of class AbstractField."""
    assert Field()

# Generated at 2022-06-23 22:11:09.613693
# Unit test for constructor of class Schema
def test_Schema():
    import pytest
    from mimesis.schema import Schema
    from mimesis.exceptions import UndefinedSchema

    def schema():
        return 1

    with pytest.raises(UndefinedSchema):
        Schema('value')

    Schema(schema)

# Generated at 2022-06-23 22:11:15.666329
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field

    def schema():
        field = Field()
        return {
            'id': field('id_48'),
            'value': field('uuid4')
        }

    sch = Schema(schema)
    data = sch.create(2)

    assert isinstance(data, list)
    assert len(data) == 2
    assert 'id' in data[0]
    assert 'value' in data[0]
    assert data[0]['id'] != data[1]['id']
    assert data[0]['value'] != data[1]['value']

# Generated at 2022-06-23 22:11:18.158262
# Unit test for method create of class Schema
def test_Schema_create():
    """Test Schema.create()"""
    def schema():
        return {'name': 'Petrov'}

    result = Schema(schema).create(iterations=5)

    assert result == [{'name': 'Petrov'}] * 5

# Generated at 2022-06-23 22:11:28.988891
# Unit test for method create of class Schema
def test_Schema_create():
    import mimesis.builtins.datetime
    from mimesis.data import BASE_SCHEMAS
    
    field = Field()
    person_schema = Schema(BASE_SCHEMAS['Person'].schema)

    person_list = person_schema.create(10)
    assert len(person_list) == 10

    for person in person_list:
        assert person['first_name']
        assert person['second_name']
        assert person['address']['city']
        assert person['address']['country']
        assert person['address']['street']
        assert person['address']['address']

        birthday = field.datetime.from_timestamp(
            person['birth_date'])
        assert birthday.year == 1970



# Generated at 2022-06-23 22:11:30.604125
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    result = str(Field('en'))
    assert result == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:34.293351
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {
            'name': Field('person.name'),
            'surname': Field('person.last_name'),
        }

    assert isinstance(Schema(schema()).create(1), list)

# Generated at 2022-06-23 22:11:35.124550
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField __init__."""
    f = AbstractField()
    assert f.locale == 'en'

# Generated at 2022-06-23 22:11:36.816575
# Unit test for constructor of class Schema
def test_Schema():
    with pytest.raises(UndefinedSchema):
        assert Schema('abc')



# Generated at 2022-06-23 22:11:39.757928
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    #: :type: AbstractField
    obj = AbstractField()
    assert isinstance(obj, AbstractField)

# Generated at 2022-06-23 22:11:42.679107
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test method AbstractField.__str__."""
    field = Field('en')
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:46.118431
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test of AbstractField.__call__ method."""
    assert Field().__call__(name='person').full_name()
    assert Field().__call__(
        name='person.name.full_name').startswith('Mr')

# Generated at 2022-06-23 22:11:51.594098
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.address import Address

    class MyField(AbstractField):
        pass

    field = MyField(locale='ru')
    address = Address('ru')
    assert address.country() == field('country')
    assert address.city() == field('city')
    assert address.address() == field('address')
    assert address.street_name() == field('street_name')
    assert address.postal_code() == field('postal_code')
    assert address.region() == field('region')

    field = MyField(locale='ru', providers=['address'])
    address = Address('ru')
    assert address.country() == field('country')
    assert address.city() == field('city')
    assert address.address() == field('address')
    assert address.street_name() == field

# Generated at 2022-06-23 22:12:00.448301
# Unit test for method create of class Schema
def test_Schema_create():
    """Test generate filled schemas."""
    from mimesis.schema import Field

    field = Field()

    def schema() -> JSON:
        """Generate schema."""
        return {
            'id': field('uuid'),
            'name': {
                'firstName': field('person.name'),
                'lastName': field('person.surname'),
            },
            'email': field('email'),
            'age': field('age', minimum=18, maximum=60),
            'gender': field('gender'),
            'address': field('address'),
        }

    filled_schemas = Schema(schema).create(10)
    assert len(filled_schemas) == 10

    # Unit test for method create of class Schema
    test_Schema_create()

# Generated at 2022-06-23 22:12:04.296684
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        pass

    s = Schema(schema)
    assert str(s) == 'Schema <{}>'.format(schema.__name__)

# Generated at 2022-06-23 22:12:12.223783
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    from mimesis.builtins import RussiaSpecProvider

    schema = Schema(Field(locale='ru', providers=[RussiaSpecProvider()]))
    person = schema.create(3)

    assert len(person) == 3

    for p in person:
        assert isinstance(p, dict)
        assert 'name' in p.keys()
        assert len(p.keys()) == 5

    for p in person:
        assert 'name' in p.keys()
        assert len(p.keys()) == 5

# Generated at 2022-06-23 22:12:18.368965
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    class TestField(AbstractField):
        """Class TestField."""

    field = TestField()

    try:
        field()
    except UndefinedField:
        assert True
    else:
        assert False

    try:
        field(name='name')
    except UnsupportedField:
        assert True
    else:
        assert False

    try:
        field(name='name.name')
    except UnacceptableField:
        assert True
    else:
        assert False

    assert field(name='name.name', key=callable) is callable

# Generated at 2022-06-23 22:12:22.750772
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> JSON:
        """Implement a schema."""
        return {
            'name': 'John',
            'surname': 'Smith',
            'age': '42',
        }

    assert len(Schema(schema).create()) == 1

# Generated at 2022-06-23 22:12:24.479551
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    stream = 'AbstractField <en>'
    assert str(AbstractField()) == stream

# Generated at 2022-06-23 22:12:26.475831
# Unit test for constructor of class Schema
def test_Schema():
    """Create new object of class Schema."""
    Schema(lambda: {'key': lambda x: x()})

# Generated at 2022-06-23 22:12:37.371058
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    callable_field = AbstractField()

    # `name == 'string'`
    expect = 'String()'
    result = field('string')
    assert result == expect

    # `name == 'provider.name'`
    expect = 'Name()'
    result = field('datetime.name')
    assert result == expect

    # `key`
    callable_field = AbstractField()
    expect = 'String(length=5)'
    result = callable_field(
        name='string',
        key=lambda x: 'String(length={})'.format(x),
        length=5,
    )
    assert result == expect

    # `error`
    try:
        callable_field(name='provider.name.method')
    except UnacceptableField:
        assert True


# Generated at 2022-06-23 22:12:43.940592
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for class Schema.

    Test method create with iterations > 1.
    """
    field = Field()

    def schema() -> dict:
        return {
            'id': field('uuid'),
            'name': field('person.first_name'),
            'surname': field('person.last_name'),
            'weight': field.weight.random_weight,
        }

    s = Schema(schema)
    data = s.create(2)
    assert isinstance(data, list) and len(data) == 2

# Generated at 2022-06-23 22:12:48.878975
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    result = field('en_GB.company.name')
    assert isinstance(result, str)

    # More detailed tests
    assert isinstance(field(), UndefinedField)
    assert isinstance(field('Data Science'), UndefinedField)
    assert isinstance(field('na.na.name'), UnsupportedField)

# Generated at 2022-06-23 22:12:51.165977
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    af = AbstractField()
    assert af.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:53.584387
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {'foo': 'bar'}

    obj = Schema(schema)
    assert len(obj.create(1)) == 1

# Generated at 2022-06-23 22:12:55.657935
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(AbstractField()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:01.897685
# Unit test for method create of class Schema
def test_Schema_create():
    """Test for method create of class Schema."""
    schema = {
        'name': 'Ivan',
        'age': 20,
        'books': [{
            'title': 'The NeverEnding Story'
        }, {
            'title': 'Harry Potter and the Chamber of Secrets'
        }],
        'gender': 'male'
    }

    assert Schema(schema).create(iterations=10) == [schema] * 10

# Generated at 2022-06-23 22:13:06.396572
# Unit test for constructor of class Schema
def test_Schema():
    """Unit-test for constructor of class Schema."""
    def func() -> JSON:
        """Func to test."""
        return {'hello': 'world'}

    s = Schema(func)
    assert isinstance(s.schema, Callable)

# Generated at 2022-06-23 22:13:11.395956
# Unit test for constructor of class AbstractField
def test_AbstractField():
    src = 'FOOBAR'
    # Check string (locale)
    assert AbstractField(locale=src).locale == src

    src = 'FOOBAR'
    # Check seed
    assert AbstractField(seed=src).seed == src

# Generated at 2022-06-23 22:13:21.332496
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__ method."""
    field = AbstractField(locale='ru')
    assert callable(field) is True

    # With wrong name
    with raises(UnsupportedField):
        field('nam')

    # This is wrong tail
    with raises(UnacceptableField):
        field('people.name.surname')

    # Call with tail of the data provider
    assert field('people.name')

    # Unit tests for Schema
    def schema():
        """Schema for Test."""
        return dict(
            locale=field('ru.locale'),
            name=field('ru.name'),
            surname=field('ru.surname'),
        )

    assert Schema(schema=schema).create()

    # Unit tests for schema
    schema = Schema(schema=schema)

# Generated at 2022-06-23 22:13:25.811935
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    locale = 'uk'
    seed = '123'
    #: List of providers
    providers = ['datetime', 'person']
    field = Field(locale, seed, providers)

    assert field('full_name') == 'Олександр Саєнко'
    assert field('timestamp_ms') == 1572016947486
    assert field('timestamp_ms', key=int) == 1572016947486

# Generated at 2022-06-23 22:13:26.262296
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    pass

# Generated at 2022-06-23 22:13:29.848097
# Unit test for method create of class Schema
def test_Schema_create():
    schema = Schema(lambda: {'foo': 'bar'})
    assert len(schema.create(5)) == 5

    schema = Schema(lambda: [1, 2])
    assert len(schema.create(7)) == 7

    schema = Schema(lambda: 1)
    assert len(schema.create(11)) == 11



# Generated at 2022-06-23 22:13:32.459581
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import AbstractField
    f = AbstractField()
    schema = f.Person.name

    schema = Schema(schema)
    assert isinstance(schema, Schema)

if __name__ == '__main__':
    print(test_Schema())

# Generated at 2022-06-23 22:13:36.353553
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert isinstance(field, AbstractField)
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:13:40.613537
# Unit test for constructor of class AbstractField
def test_AbstractField():
    '''
    Test :func:`AbstractField()`
    '''
    ab = AbstractField('ru')
    testMethod = ab('title')
    assert testMethod == 'Нет'

    testMethod = ab('username')
    assert type(testMethod) is str
    assert len(testMethod) > 0

# Generated at 2022-06-23 22:13:44.049598
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    field = AbstractField()
    assert field.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:47.080114
# Unit test for constructor of class Schema
def test_Schema():
    """Test constructor.

    :raises UndefinedSchema: if schema not callable
    """
    # noinspection PyTypeChecker
    Schema(1)



# Generated at 2022-06-23 22:13:48.721312
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = AbstractField()

# Generated at 2022-06-23 22:13:56.471436
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Demonstration of using __call__ method."""
    from pprint import pprint

    schema = {
        'name': 'Roman.full_name',  # Full name from Person provider
        'age': 33,  # integer
        'email': '@Email.safe_email',  # Safe e-mail from Email provider
        'password': lambda: ''.join(  # Secure password
            Field()('Word.words(quantity=2, joiner=" ")', key=str.capitalize)
        ),
    }
    print('Schema:\n')
    pprint(schema, indent=4)
    print('\n')
    print('Result:\n')
    field = AbstractField()

# Generated at 2022-06-23 22:13:59.104340
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test case for check constuctor."""
    field = Field()
    assert field is not None
    assert field._gen is not None



# Generated at 2022-06-23 22:14:06.008919
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField.

    Checks that method returns expected string:
    ``'<Class name> <locale>'``

    :return: True if all is ok
    """
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'
    field = AbstractField(locale='ru')
    assert str(field) == 'AbstractField <ru>'
    assert str(AbstractField(providers=['NFA'])).__contains__('NFA')

# Generated at 2022-06-23 22:14:14.482321
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {'id': 12345,
              'attributes': {
                  'name': 'Oleh',
                  'age': 33
              }
              }

    def _schema() -> JSON:
        return schema

    obj1 = Schema(_schema)
    iterations = 10
    data = obj1.create(iterations)
    assert len(data) == iterations

    def _schema2() -> JSON:
        return {'name': 'Oleh'}

    obj2 = Schema(_schema2)
    iterations = 15
    data = obj2.create(iterations)
    assert len(data) == iterations

# Generated at 2022-06-23 22:14:16.625070
# Unit test for constructor of class Schema
def test_Schema():
    assert callable(Schema)



# Generated at 2022-06-23 22:14:18.970474
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():  # noqa
    """Tests Field.__str__()."""
    field = Field()
    assert str(field) == 'AbstractField <en>'



# Generated at 2022-06-23 22:14:19.921551
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema(SchemaType)



# Generated at 2022-06-23 22:14:25.753088
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert field.__call__('foo') is None
    assert field.__call__('foo', 'bar') is None
    assert field.__call__('foo', 'bar', 'baz') is None
    assert field.__call__('foo', 'bar', 'baz', 'foobar') is None
    try:
        field.__call__('foo.bar')
    except UnacceptableField:
        assert True
    except:
        assert False



# Generated at 2022-06-23 22:14:26.724008
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField()
    assert f is not None

# Generated at 2022-06-23 22:14:30.616295
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {"name": Field("name.name", format='full_name'),
                "age": Field("person.age")}

    s = Schema(schema)
    assert len(s.create(5)) == 5
    assert isinstance(s.create(5), list)

# Generated at 2022-06-23 22:14:37.130809
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> JSON:
        """Create users."""
        return {
            'user_id': Field('uuid', hyphens=False),
            'name': Field('full_name', gender='female'),
            'login': Field('username', prefix='user_'),
            'avatar': Field('image_url', width=400, height=250),
            'email': Field('email', domain='yandex.ru'),
            'password': Field('password', length=16),
            'is_active': Field('boolean', probability=0.55),
            'created_at': Field('timestamp'),
        }

    _ = Schema(schema)