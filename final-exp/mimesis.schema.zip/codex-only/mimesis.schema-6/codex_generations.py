

# Generated at 2022-06-23 22:04:51.720980
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test the method ``__str__`` of class AbstractField.

    :return: Nothing
    """
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:04:53.367798
# Unit test for constructor of class Schema
def test_Schema():
    schema = {}

    schema = Schema(schema)
    assert schema.create()

# Generated at 2022-06-23 22:04:57.535079
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field(locale='ru', providers=['datetime'])
    assert field.locale == 'ru'
    assert field._gen.datetime.get_current_locale_name() == 'ru'

    field = Field(locale='en', seed='test')
    assert field.locale == 'en'
    assert field.seed == 'test'



# Generated at 2022-06-23 22:05:00.699957
# Unit test for constructor of class Schema
def test_Schema():
    schema = {
        'string': '{{ text.word() }}',
        'number': '{{ numeric.integer() }}'
    }
    assert callable(Schema(schema))



# Generated at 2022-06-23 22:05:03.323595
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema(dict)
    assert str(s) == '<Schema>'



# Generated at 2022-06-23 22:05:07.725862
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test that magic method __call__ of clas AbstractField."""
    field = Field()

    result = field('datetime')

    assert result is not None and isinstance(result, str)

    # Mocking tail function
    field._gen.user_agent.chrome.tail_parser = lambda x, y: x

# Generated at 2022-06-23 22:05:14.864252
# Unit test for method create of class Schema
def test_Schema_create():
    """Test method `create` of class `Schema`."""
    import uuid

    def _test_schema():
        return {
            "id": str(uuid.uuid4()),
            "name": "John Doe",
            "email": "john@doe.com",
        }

    schema = Schema(_test_schema)
    assert isinstance(schema.create(iterations=5), list)
    assert len(schema.create(iterations=5)) == 5



# Generated at 2022-06-23 22:05:17.332689
# Unit test for constructor of class Schema
def test_Schema():
    schema = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    s = Schema(schema)
    assert s.create() == schema

# Generated at 2022-06-23 22:05:20.156284
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Create an instance of class AbstractField."""
    field = AbstractField()
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:05:30.858185
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.data import ADDRESSES
    from mimesis.schema import Field, Schema, build_schema

    def schema_func():
        """Schema."""
        field = Field()
        return {
            'city': field('city'),
            'street': field('street'),
            'address': field('address'),
        }

    assert (
        Schema(schema_func).create() ==
        [{
            'city': 'Aberdeen',
            'street': 'Kilpatrick Street',
            'address': '4820 Kilpatrick Street, Mcfarland, New Hampshire 67752',
        }, ]
    )

    schema = build_schema(ADDRESSES)


# Generated at 2022-06-23 22:05:39.161732
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__.

    **Description:** Check that AbstractField.__call__ returns correct value.

    **Expected behavior:** AbstractField.__call__
        raises UnsupportedField exception when a user
        tries to call a method not supported by the Generic class.
    """
    provider = Generic(seed=1)
    field = Field(providers=provider)

    assert field('timezone') == 'Europe/Zagreb'

    with Field(seed=1) as field:
        assert field('timezone') == 'Europe/Zagreb'


# Generated at 2022-06-23 22:05:41.472280
# Unit test for constructor of class Schema
def test_Schema():
    def schema_gen():
        return Field()

    s = Schema(schema_gen)
    assert callable(s.schema)

# Generated at 2022-06-23 22:05:47.394697
# Unit test for constructor of class Schema
def test_Schema():
    schema = {
        'name': 'Иван',
        'surname': 'Иванов',
        'patronymic': 'Иванович',
        'age': 18,
        'email': 'ivan.ivanov@example.com',
        'phone': '+79991112233',
    }

    def person() -> JSON:
        return {
            'name': Field().person.name(),
            'surname': Field().person.surname(),
            'patronymic': Field().text.patronymic(gender='M'),
            'age': Field().datetime.age(),
            'email': Field().internet.email(),
            'phone': Field().telephone.phone_number(),
        }

    persons = Schema(person).create

# Generated at 2022-06-23 22:05:51.088381
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    import json

    schema_parser = Schema(field=Field())

    generated = schema_parser.create(iterations=10)

    assert len(generated) == 10
    assert json.dumps(generated) is not None

# Generated at 2022-06-23 22:05:59.185504
# Unit test for method create of class Schema
def test_Schema_create():
    """Method create.

    Create a list of a filled schemas with elements in an amount of **iterations**.

    :param iterations: Amount of iterations.
    :return: List of willed schemas.
    """
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    class FakeSchema:

        def __call__(self):
            person = RussiaSpecProvider()

            return {
                'name': person.person.full_name(gender=Gender.MALE),
            }

    assert Schema(FakeSchema()).create() == [{'name': 'Александр Леонидович Смирнов'}]

# Generated at 2022-06-23 22:06:05.357961
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.exceptions import UnacceptableField
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    class Foo:

        def __init__(self):
            self.person = Person('ru')
            self.address = Address('ru')

    class Bar(Person):
        pass

    class Baz:

        def __init__(self, locale: str = 'en'):
            self.locale = locale
            self.parent = Generic(locale)

        def __getattr__(self, item):
            return getattr(self.parent, item)

    class Qux:

        def __init__(self, parent):
            self.parent = parent

        def __getattr__(self, item):
            return getattr(self.parent, item)


# Generated at 2022-06-23 22:06:09.352372
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__."""
    from mimesis.providers.cryptographic import Cryptographic

    field = AbstractField()

    # Test for the correct call
    assert callable(field.person.name)
    assert isinstance(field('person.name'), str)
    assert isinstance(field(name='person.name'), str)

    # Test for the exception
    try:
        field(name='person.not_existing_method')
    except UnsupportedField:
        pass

    # Test for explicit provider name
    field._gen.add_provider(Cryptographic)
    assert field('person.name') != field('crypto.uuid4')



# Generated at 2022-06-23 22:06:10.789369
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for AbstractField.

    See also:
        :class:`~mimesis.schema.AbstractField`
    """
    field = AbstractField()
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:06:15.989960
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    f = Field()

    assert f('date.date')
    f = Field(locale='uk')
    assert f('date.date') == f('date.date')
    assert f('date.date') != f('date.date', seed=10000)

    users = [
        f('person.username', seed=i) for i in range(100)
    ]
    assert len(users) == len(set(users))

    assert f('localized_data.currency')
    assert f('localized_data.currency', locale='ru')
    assert f('localized_data.currency', locale='es')
    assert f('localized_data.currency', locale='it')
    assert f('localized_data.currency', locale='nl')
    assert f('localized_data.currency', locale='fr')



# Generated at 2022-06-23 22:06:18.030470
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField(locale='en')
    assert (field.locale == 'en')
    assert (field.seed is None)

# Generated at 2022-06-23 22:06:19.578966
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Check abstract field representation."""
    assert AbstractField().__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:23.732396
# Unit test for method create of class Schema
def test_Schema_create():
    schema = {
        "name": "Mimesis",
        "age": 1,
        "gender": "male",
        "id": 1
    }

    def inner_schema():
        return schema

    schema_obj = Schema(inner_schema)
    filled_schemas = schema_obj.create(1)

    assert filled_schemas == [schema]



# Generated at 2022-06-23 22:06:30.783039
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert isinstance(field, AbstractField)

    field = Field(locale='ru')
    assert isinstance(field, AbstractField)
    assert field.locale == 'ru'

    field = Field(seed=12345)
    assert isinstance(field, AbstractField)
    assert field.seed == 12345

    field = Field(providers=[Generic()])
    assert isinstance(field, AbstractField)
    assert field._gen.generic



# Generated at 2022-06-23 22:06:32.596424
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test cases for constructor of class ``AbstractField``."""
    field = Field()

    assert field._gen is not None
    assert field._table is not None



# Generated at 2022-06-23 22:06:34.494491
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test magic method __str__ of class AbstractField."""
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:06:39.027533
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = Field()

    # Check if method exists
    assert hasattr(field, '__call__')

    # Check if method returns string
    assert isinstance(field('password'), str)

    # Check if method raises error
    try:
        field('unexpected.method')
    except ValueError:
        assert True



# Generated at 2022-06-23 22:06:41.647450
# Unit test for constructor of class AbstractField
def test_AbstractField():
    with pytest.raises(TypeError):
        AbstractField(123, 456)

    field = AbstractField()
    assert isinstance(field, AbstractField)
    assert field.locale == 'en'



# Generated at 2022-06-23 22:06:46.938059
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    kwargs = {'min_value': 100, 'max_value': 200}

    assert field('integer', key=lambda x: x, **kwargs) != 0
    assert field('integer', **kwargs) != 0

# Generated at 2022-06-23 22:06:55.908704
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():  # noqa: D103
    from mimesis.providers.address import Address
    from mimesis.providers.base import Base
    from mimesis.providers.cryptographic import Cryptographic

    field = AbstractField()

    class NewProvider(Base):
        __qualname__ = 'NewProvider'

        @property
        def test_1(self):
            return 'test_1'

        @property
        def test_2(self):
            return 'test_2'

        def test_3(self):
            return 'test_3'

    providers = [NewProvider(seed=5), Address, Cryptographic]

    field.add_providers(*providers)

    assert field('test_1') == 'test_1'
    assert field('test_2') == 'test_2'

# Generated at 2022-06-23 22:06:59.678767
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method ``__call__`` of class ``AbstractField``."""
    f = Field(locale='en')
    assert f('random.intr') == 'intr'
    assert f('security.key') == 'key'



# Generated at 2022-06-23 22:07:01.511190
# Unit test for constructor of class Schema
def test_Schema():
    from .schema import NameSchema

    field = NameSchema()
    result = field()

    assert result is not None

# Generated at 2022-06-23 22:07:05.053476
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema({'name': 'Kevin'})
    assert schema.create()[0] == {'name': 'Kevin'}

    schema = Schema({'name': lambda: 'Kevin'})
    assert schema.create()[0] == {'name': 'Kevin'}

# Generated at 2022-06-23 22:07:06.266518
# Unit test for constructor of class AbstractField
def test_AbstractField():
    gen = Field()  # noqa: F841
    assert gen is not None

# Generated at 2022-06-23 22:07:09.100577
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test that the function returns str."""
    field = Field()
    assert isinstance(field.__str__(), str)

# Generated at 2022-06-23 22:07:18.108073
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field, Schema
    from mimesis.exceptions import UndefinedSchema

    field = Field()

    def schema() -> JSON:
        return {
            'data': field('random_int', minimum=0, maximum=17),
            'user': {
                'username': field('user_name'),
                'address': field('address'),
                'e-mail': field('email'),
            },
            'departments': ['engineering', 'design', 'development']
        }

    schema = Schema(schema)
    assert isinstance(schema.create(), list)

    with UndefinedSchema:
        Schema('schema')

# Generated at 2022-06-23 22:07:20.845015
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.providers.base import BaseDataProvider

    class Provider(BaseDataProvider):
        pass

    Field(locale='en', seed='42',
          providers=[Provider()]
          )

# Generated at 2022-06-23 22:07:23.249835
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    field = AbstractField()
    assert field('username')
    assert field('email')
    assert field('binary')

# Generated at 2022-06-23 22:07:24.172861
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    # this method can't be tested
    pass

# Generated at 2022-06-23 22:07:26.499108
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__.

    :return: None.
    """
    af = AbstractField()
    assert af.__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:35.258853
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.schema import Field, Schema
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    import pytest

    person = Person('ru')
    street = Address('ru')

    def schema() -> JSON:
        return {
            'name': Field('full_name'),
            'age': Field('age'),
            'address': {
                'number': Field('house_number'),
                'street': Field('street_name'),
                'city': Field('city'),
                'country': Field('country'),
                'full': Field('full_address'),
            },
        }

    sc = Schema(schema)
    for person in sc.create(iterations=10):
        assert person['name'] == person_full_name()

# Generated at 2022-06-23 22:07:43.140810
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    def test_raise_exceptions():
        field = AbstractField()
        field('t')

    def test_call_correct_method():
        field = AbstractField()
        assert isinstance(field('datetime'), str)

    def test_call_method_from_provider():
        field = AbstractField()
        provider = 'datetime'
        field(provider + '.now')

    def test_call_undefined_field():
        field = AbstractField()
        field('code')

    def test_call_undefined_provider():
        field = AbstractField()
        field('t.now')

    def test_call_methods_with_the_same_names():
        field = AbstractField()
        field('internet.url')

    test_raise_exceptions()
    test_call_correct_method()
   

# Generated at 2022-06-23 22:07:45.217855
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field()
    result = str(field)
    assert result == 'Field <en>'

# Generated at 2022-06-23 22:07:46.978997
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for __str__ method."""
    field = Field()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:07:52.397649
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test AbstractField class for constructor."""
    field = AbstractField()
    assert field.locale == 'en'
    assert field.seed is None
    field = AbstractField('ru', 666)
    assert field.locale == 'ru'
    assert field.seed == 666
    assert field._gen is not None



# Generated at 2022-06-23 22:07:55.557692
# Unit test for constructor of class Schema
def test_Schema():
    """Test class which return list of filled schemas."""
    import mimesis.enums

    f = Field()
    schema = Schema(f.gender)
    schema.create(42)
    assert mimesis.enums.Genders.MALE.value in schema.create(42)

# Generated at 2022-06-23 22:07:58.770000
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.__class__.__name__ == 'Field'
    assert field.locale == 'en'
    assert field.seed is None


# Unit tests for Field().__call__

# Generated at 2022-06-23 22:08:03.038496
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test of implemantation of __str__."""
    f = AbstractField()
    assert str(f) == 'AbstractField <en>'
    f = AbstractField(locale='ru')
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:08:07.460999
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for method __call__ of class AbstractField."""
    gen = Generic('en')
    field = AbstractField(providers=gen)
    assert field('uuid') == gen.uuid()
    assert field('uuid', version=4) == gen.uuid(version=4)

# Generated at 2022-06-23 22:08:08.989026
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'



# Generated at 2022-06-23 22:08:10.066716
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema({}) is not None


# Generated at 2022-06-23 22:08:13.829759
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of AbstractField class.

    :return: None
    """
    strategy = AbstractField()

    assert strategy
    assert not strategy.locale
    assert not strategy.seed
    assert strategy._table

# Generated at 2022-06-23 22:08:20.289436
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.__call__."""
    # Try to call AbstractField with no params
    try:
        Field()
    except UndefinedField:
        assert True

    # Try to call AbstractField with non supported field
    try:
        Field('example')
    except UnsupportedField:
        assert True

    # Call AbstractField with supported field
    assert Field('uuid')

    assert Field('datetime.datetime_formatted')

    assert Field('datetime.datetime_formatted', key=lambda x: x)

# Generated at 2022-06-23 22:08:22.051372
# Unit test for constructor of class Schema
def test_Schema():
    """Test for constructor of Schema."""
    field = Schema(lambda: {})
    assert isinstance(field, Schema)



# Generated at 2022-06-23 22:08:23.542077
# Unit test for constructor of class AbstractField
def test_AbstractField():
    schema = AbstractField()
    assert schema



# Generated at 2022-06-23 22:08:27.878523
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()

    test_cases = [
        'date',
        'time',
        'datetime',
        'timestamp',
        'uuid4',
        'uuid1',
        'md5',
        'hexadecimal',
        'token_hex',
        'sha1',
        'sha256',
    ]

    for case in test_cases:
        value = getattr(field, case)()
        assert callable(value)

# Generated at 2022-06-23 22:08:29.997640
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.generic import Generic
    from mimesis.providers.datetime import Datetime

    def schema():
        return {
            'foo': Generic('ru').uuid(),
            'bar': Datetime('ru').timestamp()
        }

    Schema(schema)

# Generated at 2022-06-23 22:08:36.756087
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from string import ascii_lowercase
    from mimesis.builtins.cryptographic import Cryptographic

    leaves = [
        'en.datetime.time',
        'en.datetime.datetime',
        'en.datetime.timedelta',
        'en.datetime.time_delta',
        'en.datetime.date',
        'en.datetime.today',
        'en.datetime.now',
        (
            'en.cryptographic.hash',
            {'data': 'mimesis', 'algorithm': 'md5'},
        ),
    ]
    leaf_providers = [
        'datetime',
    ]
    node_providers = [
        'cryptographic',
    ]
    field = Field('en')

    # Test leafs

# Generated at 2022-06-23 22:08:38.689926
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers.address import Address
    s = Schema(Address('en').get_address)

    assert isinstance(s, Schema)

# Generated at 2022-06-23 22:08:50.150036
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    assert isinstance(field('datetime'), datetime.datetime)
    assert isinstance(field('datetime'), datetime.datetime)
    assert isinstance(field('datetime'), datetime.datetime)
    assert isinstance(field('datetime'), datetime.datetime)
    assert isinstance(field('datetime', seed=42), datetime.datetime)
    assert isinstance(field('datetime', seed=42), datetime.datetime)
    assert isinstance(field('datetime', seed=42), datetime.datetime)
    assert isinstance(field('datetime', seed=42), datetime.datetime)
    assert isinstance(field('seed'), int)
    assert isinstance(field('seed', seed=10), int)

# Generated at 2022-06-23 22:09:00.482387
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.enums import Gender
    from mimesis.schema import Field
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet

    def my_schema():
        """Schema example."""
        p = Person('en')
        a = Address('en')
        i = Internet('en')

        field = Field(providers=[p, a, i])


# Generated at 2022-06-23 22:09:04.696557
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert isinstance(AbstractField(), AbstractField)
    assert isinstance(AbstractField(locale='ru'), AbstractField)
    assert isinstance(AbstractField(seed=1), AbstractField)
    assert isinstance(AbstractField(providers=(1, 2)), AbstractField)



# Generated at 2022-06-23 22:09:06.823214
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field('en')
    assert 'Field <en>' in field.__str__()

# Generated at 2022-06-23 22:09:10.047810
# Unit test for method create of class Schema
def test_Schema_create():
    def schema() -> dict:
        return {}

    s = Schema(schema=schema)
    assert len(s.create(1)) == 1
    assert len(s.create(10)) == 10

# Generated at 2022-06-23 22:09:11.203304
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:09:13.227618
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    instance = AbstractField()
    result = str(instance)
    assert isinstance(result, str)

# Generated at 2022-06-23 22:09:16.848781
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Testing AbstractField __call__ method."""
    field = Field()
    assert field('choice', ['1', '2', '3']) in ['1', '2', '3']
    assert field('choice', ['1', '2', '3'], key=int) in [1, 2, 3]

# Generated at 2022-06-23 22:09:23.917718
# Unit test for method create of class Schema
def test_Schema_create():
    """Test of Schema.create."""
    field = Field()
    schema = Schema(lambda: {
        'a': field('a'),
        'b': field('b'),
        'c': field('c'),
        'd': field('d'),
        'e': {
            'f': field('f'),
            'g': field('g'),
            'h': field('h'),
        }

    })
    assert isinstance(schema.create(), list)
    assert len(schema.create(3)) == 3



# Generated at 2022-06-23 22:09:25.369094
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = Field()
    assert field.locale == 'en'
    assert field.seed is None

# Generated at 2022-06-23 22:09:27.831437
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = Field(locale='ru', providers=[])
    assert field.__str__() == 'Field <ru>'

# Generated at 2022-06-23 22:09:34.713540
# Unit test for method create of class Schema
def test_Schema_create():
    """Unit test for method create of class Schema."""
    from mimesis.schema import Schema
    from mimesis.typing import JSON

    schm = Schema(lambda: {'id': '1', 'name': 'Bob'})
    actual = schm.create(2)
    expected = [
        {'id': '1', 'name': 'Bob'},
        {'id': '1', 'name': 'Bob'}
    ]  # type: List[JSON]

    assert actual == expected

# Generated at 2022-06-23 22:09:36.060152
# Unit test for constructor of class Schema
def test_Schema():
    try:
        Schema('schema')
    except UndefinedSchema:
        assert True



# Generated at 2022-06-23 22:09:46.275538
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Unit test for method __call__ of class AbstractField."""
    # pylint: disable=invalid-name
    a = AbstractField()
    b = AbstractField(locale='ru')
    c = AbstractField(seed=42)

    assert a('datetime') != b('datetime')
    assert a('datetime') != c('datetime')
    assert a('datetime') == a('datetime')

    assert a('datetime') != a('datetime', year=-1)

    # Fixed https://github.com/lk-geimfari/mimesis/issues/619
    assert a('choice', choices=['a', 'b']) != b('choice', choices=['b', 'a'])

# Generated at 2022-06-23 22:09:47.992255
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field(locale='ru')
    assert str(f) == 'AbstractField <ru>'

# Generated at 2022-06-23 22:09:55.652923
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for __call__ method."""
    field = Field()

    assert field('seed') == field('seed')

    assert field('not_exists') is None

    assert field('seed', max_length=3) != field('seed', max_length=3)

    assert field('seed') != field('seed', max_length=3)

    # If a field has an alias, it must be the same
    assert field('i') == field('integer')

    # This should work too
    assert field('i', min=10) == field('integer', min=10)

# Generated at 2022-06-23 22:10:06.277721
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('person.full_name')
    assert field('person.occupation')
    assert field('address.address')

    assert field('person.full_name', key=lambda x: x) == \
        field('person.full_name')

    def test_key(x: str) -> str:
        return x.upper()

    assert field('person.full_name', key=test_key).isupper() is True

    assert field('name') is not None

    try:
        field('')
    except UndefinedField:
        assert True

    try:
        field(None)
    except UndefinedField:
        assert True

    try:
        field('full_name.person')
    except UnacceptableField:
        assert True


# Generated at 2022-06-23 22:10:10.061684
# Unit test for method create of class Schema
def test_Schema_create():
    field = Field()
    schema = {
        "id": field("uuid"),
        "name": field("name")
    }
    schema = Schema(schema).create(10)
    assert len(schema) == 10
    assert all(['id' in item and 'name' in item for item in schema])

# Generated at 2022-06-23 22:10:16.043686
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.builtins import Geo

    f = AbstractField()
    assert f.locale == 'en'
    assert isinstance(f._gen, Generic)
    assert callable(f)

    f = Field(locale='ru', seed=10, providers=(Geo,))
    assert f.locale == 'ru'
    assert isinstance(f._gen, Generic)
    assert 'Geo' in dir(f._gen)
    assert callable(f)



# Generated at 2022-06-23 22:10:17.971600
# Unit test for method create of class Schema
def test_Schema_create():
    def schema():
        return {'test': 'test'}

    assert len(Schema(schema).create()) == 1
    assert len(Schema(schema).create(5)) == 5

# Generated at 2022-06-23 22:10:22.055775
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.schema import Field

    def schema():
        field = Field()
        return {
            'name': field('person.full_name'),
            'age': field('person.age'),
        }

    s = Schema(schema)
    assert len(s.create(10)) == 10

# Generated at 2022-06-23 22:10:24.199736
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test method."""
    output = AbstractField()()
    assert isinstance(output, str)



# Generated at 2022-06-23 22:10:27.334768
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('currency.code') in field('currency.codes')


if __name__ == '__main__':  # pragma: no cover
    test_AbstractField___call__()

# Generated at 2022-06-23 22:10:29.304147
# Unit test for constructor of class Schema
def test_Schema():
    def func():
        return {'a': 'b'}

    schema = Schema(func)
    assert callable(schema.schema)

# Generated at 2022-06-23 22:10:30.500990
# Unit test for constructor of class Schema
def test_Schema():
    pass

# Generated at 2022-06-23 22:10:31.930203
# Unit test for constructor of class Schema
def test_Schema():
    import mimesis.schema
    schema = mimesis.schema.Field()

# Generated at 2022-06-23 22:10:33.521623
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:34.381727
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:37.389612
# Unit test for constructor of class AbstractField
def test_AbstractField():
    # Initialization should be working without parameters
    field = Field()
    assert field.locale
    assert field.seed is None
    assert field._gen
    assert field._table

# Generated at 2022-06-23 22:10:39.948089
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for constructor of class AbstractField."""
    field = AbstractField()
    field('name')
    field('person.name')

# Generated at 2022-06-23 22:10:51.039952
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    gen = AbstractField()
    assert gen.__call__('identifier')
    assert gen.__call__('identifier', length=5)
    assert gen.__call__('identifier', length=5, alphabet=0)
    assert gen.__call__('identifier', length=5, alphabet=1)
    assert gen.__call__('identifier', length=5, alphabet=2)
    assert gen.__call__('identifier', length=5, alphabet=3)
    assert gen.__call__('identifier', length=5, alphabet=4)
    assert gen.__call__('identifier', length=5, alphabet=5)
    assert gen.__call__('identifier', length=5, alphabet=6)
    assert gen.__call__('identifier', length=5, alphabet=7)

# Generated at 2022-06-23 22:10:54.417818
# Unit test for constructor of class Schema
def test_Schema():
    def schema() -> JSON:
        """Return filled schema as a dictionary."""
        return {
            "number": Field(),
            "name": Field(name='person.name'),
        }

    s = Schema(schema)
    assert isinstance(s.create(iterations=10), list)

# Generated at 2022-06-23 22:10:55.632388
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert str(f) == 'AbstractField <en>'

# Generated at 2022-06-23 22:10:58.549597
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.builtins import Person
    from mimesis.enums import Gender

    person = Person('en')
    person.gender = Gender.FEMALE

    test_schema = Schema(person)
    assert isinstance(test_schema, Schema)

# Generated at 2022-06-23 22:11:08.781676
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    provider = Field()

    # Testing for correct exception
    # when name is None
    try:
        provider()
    except UndefinedField:
        pass

    # Testing for correct exception
    # when field unsupported
    try:
        provider('unsupported')
    except UnsupportedField:
        pass

    # Testing for correct exception
    # when field unacceptable
    try:
        provider('provider.unacceptable')
    except UnacceptableField:
        pass

    # Testing for correct work
    # if field acceptable, supported and defined
    assert provider('python.module') != ''
    assert provider('unix.file_extension') != ''
    assert provider('python.global_variable') != ''

    # Testing for correct work
    # if key function is not callable
    assert provider('python.module', key='') != ''

    #

# Generated at 2022-06-23 22:11:10.308941
# Unit test for constructor of class Schema
def test_Schema():
    # returns an instance of Schema
    assert isinstance(Schema(lambda: {}), Schema)

# Generated at 2022-06-23 22:11:12.024292
# Unit test for constructor of class Schema
def test_Schema():
    assert bool(Schema())

# Generated at 2022-06-23 22:11:13.486375
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for AbstractField.__str__()."""
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:11:15.830699
# Unit test for constructor of class AbstractField
def test_AbstractField():
    from mimesis.schema import Field
    f = Field()
    assert isinstance(f, AbstractField)
    assert f is not None
    assert f.locale == 'en'

# Generated at 2022-06-23 22:11:24.268319
# Unit test for method create of class Schema
def test_Schema_create():
    from mimesis.providers.address import Address
    from mimesis.schema import Field

    schema = {
        'name': Field('address.full_address'),
        'age': Field('random_int', min=1, max=100)
    }

    def user_schema():
        return schema

    s = Schema(user_schema)
    assert len(s.create(iterations=1000)) == 1000

    field = Field(locale='en')
    address = Address(locale='en')

    assert [field('address.full_address') for _ in range(1000)] == [
        address.full_address() for _ in range(1000)]

# Generated at 2022-06-23 22:11:25.407903
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    f = Field()
    assert f.__str__() == 'Field <en>'

# Generated at 2022-06-23 22:11:28.034705
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method AbstractField.__str__."""
    field = Field()
    actual = str(field)
    assert isinstance(actual, str)

# Generated at 2022-06-23 22:11:29.501176
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema(dict)
    assert callable(s.schema)

# Generated at 2022-06-23 22:11:32.266868
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    field('choice', choices=[3, 5, 1])
    field('fake.boolean')
    field('fake', provider='gp')
    field('fake')



# Generated at 2022-06-23 22:11:36.138063
# Unit test for method create of class Schema
def test_Schema_create():
    result = Schema(lambda: {'name': str}).create(2)
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], dict)
    assert result[0]['name'] == str(result[0]['name'])

# Generated at 2022-06-23 22:11:38.175049
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema({}).create(iterations=10)) == 10

# Generated at 2022-06-23 22:11:41.310644
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {"a": "b"}

    s = Schema(schema)
    assert isinstance(s, Schema)
    assert s.create() == [{'a': 'b'}]

# Generated at 2022-06-23 22:11:45.233581
# Unit test for constructor of class Schema
def test_Schema():
    def schema_func(seed):
        field = Field(seed=seed)
        data = field("person.full_name")
        return {
            "name": data
        }
    sc = Schema(schema_func)
    assert sc.create(100)



# Generated at 2022-06-23 22:11:46.109308
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    assert f is not None



# Generated at 2022-06-23 22:11:56.403851
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    from mimesis.providers.bitcoin import Bitcoin
    from mimesis.providers.date import Date
    from mimesis.providers.generic import Generic
    from mimesis.providers.internet import Internet

    # __init__
    f = AbstractField()
    f.locale = 'en'
    f.seed = '1234'

    # __call__ (try to call method of Generic class)
    assert f('nullvalue') is None
    assert f('nullvalue', value=100) == 100
    assert f('binary', length=100)
    assert f('binary', value=100) is None

    # __call__ (try to call method of Internet class)
    assert f('useragent')
    assert f('useragent', os='linux')
    assert f('useragent', browser='chrome', os='linux')



# Generated at 2022-06-23 22:12:07.825543
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    gen = Generic('en')
    f = AbstractField(locale='en')

    result = f('person.full_name')
    assert isinstance(result, str)
    assert len(result) > 0

    result = f('person.gender')
    assert isinstance(result, str)
    assert result == gen.person.gender()

    result = f('person.full_name', gender='male')
    assert isinstance(result, str)
    assert len(result) > 0

    result = f('person.full_name', gender='female')
    assert isinstance(result, str)
    assert len(result) > 0

    result = f('person.full_name', gender='unknown')
    assert isinstance(result, str)
    assert len(result) > 0


# Generated at 2022-06-23 22:12:17.812959
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for calling of method __call__.

    Case with:
        1. Correct name of method and wrong name of provider.
        2. Correct name of provider and method.
        3. Correct name of provider with underscore.
        4. Correct name of provider with period.
        5. Correct name of provider with key function.
    """
    field = Field('ru')

    assert field(name='full_name') == 'Дана Миронов'

    assert field(
        name='person.full_name',
        key=lambda x: x.split(' ')[0]) == 'Андрей'

    assert field(name='person_misc.territory.country') == 'Украина'

    res = field('person_misc.territory.country')


# Generated at 2022-06-23 22:12:21.147866
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Unit test for method __str__ of class AbstractField."""
    assert Field().__str__() == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:22.511120
# Unit test for constructor of class Schema
def test_Schema():
    f = Schema(lambda: {'k': 1})
    assert f is not None

# Generated at 2022-06-23 22:12:24.395072
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema is not None

# Generated at 2022-06-23 22:12:28.214998
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Tests for method __call__ of class AbstractField.

    """
    field = Field()

    method = 'name'
    provider = 'person'
    attr = '{}.{}'.format(provider, method)

    result = field(attr)
    assert isinstance(result, str)



# Generated at 2022-06-23 22:12:29.273369
# Unit test for constructor of class Schema
def test_Schema():
    assert isinstance(Schema({}), Schema)

# Generated at 2022-06-23 22:12:33.123332
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema()."""
    with open('tests/schemas/house.json') as json_file:
        schema = Schema(json_file)
        assert isinstance(schema, Schema)


# Unit tests for constructor of class AbstractField

# Generated at 2022-06-23 22:12:34.686415
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field(locale='en')) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:36.040022
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(lambda: {'a': 1})

# Generated at 2022-06-23 22:12:38.057551
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Test constructor of class AbstractField."""
    f = Field()
    assert bool(f)
    assert f is not None

# Generated at 2022-06-23 22:12:39.941458
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = AbstractField(locale='ru')
    assert f.locale == 'ru'
    assert f.seed is None

# Generated at 2022-06-23 22:12:42.587189
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert Field().locale == 'en'
    assert Field(locale='es').locale == 'es'
    assert Field(seed=123).seed == 123



# Generated at 2022-06-23 22:12:44.073512
# Unit test for method create of class Schema
def test_Schema_create():
    assert len(Schema(lambda: {'f1': 'a'}).create(3)) == 3

# Generated at 2022-06-23 22:12:45.877905
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__ of class AbstractField."""
    assert str(Field()) == 'AbstractField <en>'

# Generated at 2022-06-23 22:12:47.572646
# Unit test for constructor of class Schema
def test_Schema():
    def schema():
        return {}

    Schema(schema)

# Generated at 2022-06-23 22:12:48.364462
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field(locale='ru')
    assert f.locale == 'ru'

# Generated at 2022-06-23 22:12:50.907334
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert str(field) == 'AbstractField <en>'

    field.locale = 'ru'
    assert str(field) == 'AbstractField <ru>'


# Generated at 2022-06-23 22:12:53.416063
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField()
    result = field('maybe.boolean')

    assert not result
    assert isinstance(result, bool)

# Generated at 2022-06-23 22:12:55.489104
# Unit test for method create of class Schema
def test_Schema_create():
    assert Schema(lambda: {}).create(1) == [{}]

# Generated at 2022-06-23 22:13:00.468086
# Unit test for method create of class Schema
def test_Schema_create():
    _schema_ = {'str': 'str', 'int': 1, 'float': 1.0}

    def _schema_callable_():
        return _schema_

    _schema_ = Schema(_schema_callable_)

    assert isinstance(_schema_.create(), list)

# Generated at 2022-06-23 22:13:10.689601
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """
    Tests for the
    :meth:`~mimesis.schema.AbstractField.__call__` method.
    """
    abf = AbstractField()
    assert isinstance(abf('first_name'), str)
    assert abf('datetime.date')
    assert abf('datetime.time')
    assert abf('user_agent.safari')
    assert abf('numbers.between', 0, 1)
    assert abf('first_name', key=lambda x: x.lower())
    assert abf('choice', ['a', 'b', 'c', 'd'])
    assert abf('choice', [1, 2, 3, 4], key=lambda x: x * x)
    assert abf('datetime.datetime_object')
    assert abf('datetime.date')


# Generated at 2022-06-23 22:13:12.726662
# Unit test for constructor of class AbstractField
def test_AbstractField():
    f = Field()
    f.create(iterations=1)

# Generated at 2022-06-23 22:13:14.969743
# Unit test for constructor of class Schema
def test_Schema():
    """Unit test for constructor of class Schema."""
    # assert_raises(UndefinedSchema, Schema, 1)
    s = Schema(callable)
    assert callable(s.schema)



# Generated at 2022-06-23 22:13:17.815579
# Unit test for constructor of class AbstractField
def test_AbstractField():
    """Unit test for AbstractField.

    TODO: fix this test.
    """
    Field('pt-BR')  # Should passed without errors

# Generated at 2022-06-23 22:13:20.637154
# Unit test for constructor of class AbstractField
def test_AbstractField():
    assert not isinstance(AbstractField(seed=123), int)
    assert isinstance(AbstractField(seed=123), AbstractField)
    assert isinstance(AbstractField(seed=123), object)
    assert not isinstance(AbstractField(seed=123), type)

# Generated at 2022-06-23 22:13:21.683985
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    at = AbstractField()
    assert str(at) is not None


# Generated at 2022-06-23 22:13:22.714190
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    field = AbstractField()
    assert repr(field) == 'AbstractField <en>'

# Generated at 2022-06-23 22:13:28.556263
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = AbstractField(seed=0)
    assert field('first_name') == 'Benjamin'
    assert field('first_name', gender='female') == 'Emily'
    assert field('datetime.date') == '1938-09-22'
    assert field('datetime.date', from_now=True) == '2019-09-22'
    assert field('true') is True
    assert field(None)



# Generated at 2022-06-23 22:13:36.117000
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for .__call__()."""
    from mimesis.schema import AbstractField
    from mimesis.parser import Parser

    f = AbstractField()


# Generated at 2022-06-23 22:13:37.182706
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert field is not None

# Generated at 2022-06-23 22:13:41.199693
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    field = Field()
    assert field('token')
    assert field('integer', minimum=1, maximum=5) == [1, 2, 3, 4, 5]
    assert field('internet.ip_address')
    assert field('internet.ip_address', key=lambda x: x.split('.'))

# Generated at 2022-06-23 22:13:51.371826
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test method __call__ of class AbstractField."""
    field = AbstractField()

    # 'data' is method of class Generic
    assert field('data') is not None

    # 'location' is module of class Generic
    assert field('location.address') == field('address')

    # 'result' is method of class Provider
    assert field('result') is not None

    # 'address' is method of class Address
    assert field('address') is not None

    # 'create_address' is method of class Address
    assert field('location.create_address') == field('create_address')

    try:
        field('provider_name.method_name.method')
    except UnacceptableField:
        pass


# Generated at 2022-06-23 22:14:02.858012
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test for the AbstractField class.

    This test is designed to check the correct
    operation of :meth:`~mimesis.schema.AbstractField.__call__`
    method.
    """

    field = AbstractField()

    assert field('name') == field('name')

    def key(x):
        return x[0]

    assert field('name', key=key) == field('name', key=key)

    assert field('name', gender='male') == field('name', gender='male')

    result = field('person.name', gender='male')
    assert result

    result = field('person.name', key=key, gender='male')
    assert result

    result = field('person.name', key=lambda x: x[0], gender='male')
    assert result

# Generated at 2022-06-23 22:14:10.199738
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(JSON):
        def __init__(self):
            self.value = 'test'

        def __repr__(self):
            return self.value

        def __eq__(self, other):
            if isinstance(other, Schema):
                return self.value == other.value
            return False

    schema = Schema(TestSchema)
    assert schema.create() == [TestSchema()]

# Generated at 2022-06-23 22:14:18.993304
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    """Test AbstractField.#__call__()."""
    field = AbstractField()
    value = field(name='sha256', data='Mimesis')
    assert value == '5d5c5df5d5db44df5bf5b5e54ccb731e5d5c5df5d5db44d' \
                    'f5bf5b5e54ccb731e5d5c5df5d5db44df5bf5b5e54ccb' \
                    '731e5d5c5df5d5db44df5bf5b5e54ccb731e5d5c5df5'



# Generated at 2022-06-23 22:14:21.560422
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    """Test for method __str__."""
    fake = AbstractField()
    expected = 'AbstractField <en>'
    assert fake.__str__() == expected

# Generated at 2022-06-23 22:14:23.590892
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    assert str(Field()) == 'Field <en>'
    assert str(Field(locale='ru')) == 'Field <ru>'

# Generated at 2022-06-23 22:14:24.930636
# Unit test for method __str__ of class AbstractField
def test_AbstractField___str__():
    x = AbstractField()
    assert str(x) == '<AbstractField <en>>'

# Generated at 2022-06-23 22:14:34.408310
# Unit test for method __call__ of class AbstractField
def test_AbstractField___call__():
    locale = 'ru'
    seed = 'test_AbstractField___call__'

    a = AbstractField(locale, seed)
    assert a.__class__.__name__ == 'AbstractField'
    assert a.locale == locale
    assert a.seed == seed

    # >>> a('datetime')
    # datetime.datetime(2039, 3, 12, 23, 16, 48, 716579)
    assert a('datetime').__class__.__name__ == 'datetime'
    assert a('datetime', year=2039).year == 2039

    # >>> a('email')
    # 'wvu@gmail.com'
    assert a('email').__class__.__name__ == 'str'

    # >>> a('uuid')
    # 'f4825c53-8f31-4e

# Generated at 2022-06-23 22:14:35.760777
# Unit test for constructor of class AbstractField
def test_AbstractField():
    field = AbstractField()
    assert callable(field)
    assert isinstance(field, AbstractField)



# Generated at 2022-06-23 22:14:41.320982
# Unit test for constructor of class Schema
def test_Schema():
    from mimesis.providers import Datetime
    from mimesis.schema import Field

    provider = Field()

    test_schema = {
        'year': provider.year(),
        'month': provider.month(),
        'day': provider.day(),
    }

    schema = Schema(test_schema)  # type: ignore

    dt = Datetime(provider.locale, provider.seed)
    year = dt.year()
    month = dt.month()
    day = dt.day()

    filled_schema = schema.create(1)[0]

    assert test_schema == filled_schema
    assert year == filled_schema['year']
    assert month == filled_schema['month']
    assert day == filled_schema['day']



# Generated at 2022-06-23 22:14:48.641011
# Unit test for method create of class Schema
def test_Schema_create():
    def iterable_schema_v1():
        for i in range(5):
            yield i

    schema_v1 = Schema(iterable_schema_v1)
    assert schema_v1.create() == [0, 1, 2, 3, 4]

    def iterable_schema_v2():
        for i in range(5):
            assert False
            yield i

    schema_v2 = Schema(iterable_schema_v2)
    assert schema_v2.create() == []