

# Generated at 2022-06-21 16:20:34.913851
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert len(Payment().cid()) == 4


# Generated at 2022-06-21 16:20:38.448939
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    testPayment = Payment('en')
    print(testPayment.credit_card_number())
    print(testPayment.credit_card_number(CardType.MASTER_CARD))
    print(testPayment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-21 16:20:40.537017
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert isinstance(payment.ethereum_address(), str)
    assert (len(payment.ethereum_address()) == 42)


# Generated at 2022-06-21 16:20:43.532959
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    result = payment.cvv()
    assert len(str(result)) == 3


# Generated at 2022-06-21 16:20:45.949554
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    res = p.cid()
    assert (type(res) == int)
    assert (len(str(res)) == 4)


# Generated at 2022-06-21 16:20:46.785115
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.random is not None

# Generated at 2022-06-21 16:20:47.581917
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    print(payment.cvv())

# Generated at 2022-06-21 16:20:49.291972
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    print(p.credit_card_number())

# Generated at 2022-06-21 16:20:51.446426
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment('ru')
    credit_card_owner = p.credit_card_owner()
    assert credit_card_owner is not None

# Generated at 2022-06-21 16:20:53.745712
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print(Payment().credit_card_number())


# Generated at 2022-06-21 16:21:14.342215
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    result = payment.bitcoin_address()
    print(result)
    check = re.match('[13][a-km-zA-HJ-NP-Z0-9]{33}', result)
    assert check is not None


# Generated at 2022-06-21 16:21:15.374580
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    x=Payment()
    print(x.credit_card_network())

# Generated at 2022-06-21 16:21:16.889834
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Arrange
    # Act
    c = Payment()
    # Assert
    assert c.paypal().find('@') > 0


# Generated at 2022-06-21 16:21:19.258741
# Unit test for method cid of class Payment
def test_Payment_cid():
    from mimesis.enums import CardType

    payment = Payment('en')

    assert payment.cid() in range(0, 9999)


# Generated at 2022-06-21 16:21:20.452636
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    pay = Payment(seed=42)
    print(pay.bitcoin_address())


# Generated at 2022-06-21 16:21:23.271078
# Unit test for method cid of class Payment
def test_Payment_cid():
    obj_Payment = Payment()
    assert obj_Payment.cid()
    # return obj_Payment.cid()


# Generated at 2022-06-21 16:21:30.451024
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Arrange
    payment = Payment('en', seed=12345)

    # Act
    credit_card_owner = payment.credit_card_owner(Gender.MALE)

    # Assert
    assert credit_card_owner is not None
    assert credit_card_owner['credit_card'] == '5223 8274 6818 5243'
    assert credit_card_owner['expiration_date'] == '07/17'
    assert credit_card_owner['owner'] == 'THOMAS WATSON'

# Generated at 2022-06-21 16:21:34.010089
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    assert Payment().ethereum_address() == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'

# Generated at 2022-06-21 16:21:35.553818
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment != None

#  Unit test for method cid of class Payment

# Generated at 2022-06-21 16:21:37.184603
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    assert re.match(r"^[13][a-km-zA-HJ-NP-Z1-9]{33}$", payment.bitcoin_address())


# Generated at 2022-06-21 16:22:22.584223
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    import itertools
    import random
    import string

    pay = Payment('en')

    for year in range(16, 25):
        for month in range(1, 12):
            p = Payment('en')
            p.seed(year)
            p.seed(month)
            payment = p.credit_card_expiration_date(minimum=year, maximum=year)
            print('{0} => {1}'.format((year, month), payment))

    # Test cases: years: [16..25], months: [01..12]
    # The seed is passed like parameter of Payment method
    # The seed is passed like parameter of CreditCardExpirationDate method
    years = [16, 17, 18, 19, 20, 21, 22, 23, 24, 25]

# Generated at 2022-06-21 16:22:26.155725
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment_cid = Payment()
    assert re.match(r"^[0-9]{4}$", payment_cid.cid())
    assert payment_cid.cid().__len__() == 4


# Generated at 2022-06-21 16:22:29.406921
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """ Unit test for method bitcoin_address of class Payment """
    payment = Payment()
    assert re.match('[13][a-zA-Z0-9]{32}', payment.bitcoin_address())
    for _ in range(10):
        assert len(payment.bitcoin_address()) == 34


# Generated at 2022-06-21 16:22:30.208107
# Unit test for method cid of class Payment
def test_Payment_cid():
    Payment().cid()


# Generated at 2022-06-21 16:22:31.579963
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.__class__.__name__ == 'Payment'


# Generated at 2022-06-21 16:22:35.451201
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    data = []
    for i in range(100):
        test = Payment().credit_card_expiration_date()
        assert test not in data
        data.append(test)
        assert len(test) == 5
        assert '/' in test



# Generated at 2022-06-21 16:22:36.454126
# Unit test for constructor of class Payment
def test_Payment():
    Payment()



# Generated at 2022-06-21 16:22:39.929452
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    piece = Payment(seed=1234)

    result = piece.credit_card_network()
    assert result == 'Visa'


# Generated at 2022-06-21 16:22:42.181832
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    print("test_Payment_cvv")
    p = Payment(64)
    for i in range(10):
        print(p.cvv())



# Generated at 2022-06-21 16:22:45.807425
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    object = Payment('en')
    dic = object.credit_card_owner()
    if isinstance(dic, dict):
        assert dic['credit_card'].__class__ == str
        assert dic['expiration_date'].__class__ == str
        assert dic['owner'].__class__ == str
    else:
        raise TypeError
