

# Generated at 2022-06-21 16:20:34.919788
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print('Visa card: ' + payment.credit_card_number())
    print('Master Card: ' + payment.credit_card_number(CardType.MASTER_CARD))
    print('American Express: ' + payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-21 16:20:47.133891
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment(seed=1)

    # Case 1: 01/18
    assert payment.credit_card_expiration_date() == '01/18'

    # Case 2: credit_card_expiration_date('1', '2')
    assert payment.credit_card_expiration_date(minimum=1, maximum=2) == '06/1'

    # Case 3: credit_card_expiration_date('1', '5')
    assert payment.credit_card_expiration_date(minimum=1, maximum=5) == '08/2'

    # Case 4: credit_card_expiration_date('2', '2')
    assert payment.credit_card_expiration_date(minimum=2, maximum=2) == '01/2'

# Generated at 2022-06-21 16:20:49.209303
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert payment.ethereum_address()

# Generated at 2022-06-21 16:20:53.489360
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    t = p.ethereum_address()
    assert isinstance(t, str)
    assert t.startswith('0x')
    assert len(t) == 42
    print(t)


# Generated at 2022-06-21 16:20:54.822021
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    b = Payment()
    assert b.paypal() == "wolf235@gmail.com"

# Generated at 2022-06-21 16:20:56.552487
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Initialize
    pay = Payment('en')

    # Perform
    pay.paypal()


# Generated at 2022-06-21 16:20:59.147804
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment('en',seed=23)
    paypal_account = payment.paypal()
    assert re.match(r'\w+@\w+\.\w+', paypal_account)


# Generated at 2022-06-21 16:21:00.459892
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # execute
    result = Payment().bitcoin_address()
    # assert
    assert (result is not None)

# Generated at 2022-06-21 16:21:02.581383
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis.enums import CardType
    card_type = CardType.VISA
    payment = Payment('en')
    payment.credit_card_network(card_type)


# Generated at 2022-06-21 16:21:03.566643
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert isinstance(p, Payment)

# Generated at 2022-06-21 16:21:17.916451
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    cc_owner = p.credit_card_owner()

    # Test if credit_card is a string
    assert isinstance(cc_owner['credit_card'], str)

    # Test if expiration_date is a string
    assert isinstance(cc_owner['expiration_date'], str)

    # Test if owner is a string
    assert isinstance(cc_owner['owner'], str)

# Generated at 2022-06-21 16:21:19.700655
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment('en')
    assert 2 == len(re.findall(r"\d\d/\d\d", p.credit_card_expiration_date()))


# Generated at 2022-06-21 16:21:21.619068
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    test = Payment()
    assert test.cvv() >= 100 and test.cvv() <= 999


# Generated at 2022-06-21 16:21:22.731814
# Unit test for method cid of class Payment
def test_Payment_cid():
    a = Payment()
    for i in range(0, 10):
        assert isinstance(a.cid(), int)


# Generated at 2022-06-21 16:21:24.923326
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()

    for i in range(1000):
        expiration_date = payment.credit_card_expiration_date()
        assert len(expiration_date) == 7
        month = expiration_date[0:2]
        year = expiration_date[3:7]
        assert year >= '16'
        assert month >= '01'


# Generated at 2022-06-21 16:21:28.935009
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    test = Payment()
    assert '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX' == test.bitcoin_address()


# Generated at 2022-06-21 16:21:31.924143
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    numbers = []
    for i in range(0, 1000):
        numbers.append(Payment().credit_card_number())

    assert isinstance(numbers, list)
    print(numbers)


# Generated at 2022-06-21 16:21:36.871375
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    from mimesis.builtins import GermanySpecProvider
    import mimesis.enums as enums
    import re
    p = Payment(enums.Language.GERMAN, GermanySpecProvider())
    assert re.match(r'[\w.-]+@[\w.-]+', p.paypal())



# Generated at 2022-06-21 16:21:38.190949
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cid = payment.cid()
    assert cid >= 1000 and cid <= 9999
    print(cid)


# Generated at 2022-06-21 16:21:40.708484
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Unit test for method credit_card_network of class Payment."""
    payment = Payment()
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS

# Generated at 2022-06-21 16:22:07.508634
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()

    for card_type in CardType:
        assert re.match(payment.credit_card_number(card_type), r'\d{16}') is not None

    assert re.match(payment.credit_card_number(), r'\d{16}') is not None

    # Test "American Express" card type
    amex_card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(re.match(r'\d{15}', amex_card_number).group()) == 15

# Generated at 2022-06-21 16:22:10.249787
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment('en')
    assert len(payment.bitcoin_address()) == 34


# Generated at 2022-06-21 16:22:13.302003
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment(seed=12345)
    assert p.cid() == 8255


# Generated at 2022-06-21 16:22:15.792632
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    assert Payment().ethereum_address() == '0x2bed5436d46d1a6b1e7b8094d62aa8'

# Generated at 2022-06-21 16:22:17.426866
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    test = Payment.credit_card_expiration_date()
    assert type(test) == str



# Generated at 2022-06-21 16:22:21.681849
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    result = payment.ethereum_address()
    print(result)
    assert result == "0x9b70f7e1e530b2e8fabd5d5a7ca30bc8078a5a9d"
    assert result != "0x9b70f7e1e530b2e8fabd5d5a7ca30bc8078a5a92"

# Generated at 2022-06-21 16:22:24.660349
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment('en')
    assert len(payment.credit_card_network()) == 2


# Generated at 2022-06-21 16:22:27.440168
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import unittest
    from mimesis.enums import CardType

    credit_card_number = Payment().credit_card_number(card_type = CardType.VISA)
    assert isinstance(credit_card_number, str)


# Generated at 2022-06-21 16:22:37.090793
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
        # Testing method credit_card_number
        payment = Payment()
        credit_card_number_result = payment.credit_card_number()
        assert credit_card_number_result != None
        # Testing method credit_card_expiration_date
        expiration_date_result = payment.credit_card_expiration_date()
        assert expiration_date_result != None
        # Testing method full_name
        person = Person('en')
        full_name_result = person.full_name()
        assert full_name_result != None
        # Testing method credit_card_owner
        credit_card_owner_result = payment.credit_card_owner()
        assert credit_card_owner_result != None
        assert credit_card_owner_result['credit_card'] == credit_card_number_result
        assert credit_card_owner_

# Generated at 2022-06-21 16:22:45.332952
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    print(payment.paypal())
    print(payment.bitcoin_address())
    print(payment.ethereum_address())
    print(payment.credit_card_network())
    print(payment.credit_card_number(CardType.VISA))
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))
    print(payment.credit_card_expiration_date(16, 25))
    print(payment.cvv())
    print(payment.credit_card_owner(Gender.FEMALE))

# Generated at 2022-06-21 16:23:34.465637
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cvv = payment.cvv()
    assert isinstance(cvv, int)


# Generated at 2022-06-21 16:23:35.639545
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    print(p.credit_card_network())


# Generated at 2022-06-21 16:23:37.677171
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(card_type='visa')
    assert payment.credit_card_checker(card_number), card_number


# Generated at 2022-06-21 16:23:46.564311
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    print("\n{}".format(p.credit_card_owner()))
    """
    {
        'credit_card': '5360 0632 0266 5791',
        'expiration_date': '07/20',
        'owner': 'FARRELL NOBLE'
    }
    """
    print("\n{}".format(p.credit_card_owner(gender=Gender.MALE)))
    """
    {
        'credit_card': '5397 6868 5694 4293',
        'expiration_date': '03/18',
        'owner': 'LONNIE COOPER'
    }
    """
    print("\n{}".format(p.credit_card_owner(gender=Gender.FEMALE)))

# Generated at 2022-06-21 16:23:48.123361
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
	gender = Gender.MALE
	cc_owner = Payment().credit_card_owner(gender)
	print(cc_owner)

# Generated at 2022-06-21 16:23:49.343614
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    f = Payment()
    result = f.credit_card_expiration_date()
    assert result is not None

# Generated at 2022-06-21 16:23:51.840829
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    try:
        bitcoin_address = Payment()
        bitcoin_address.bitcoin_address()
        print('Unit test for bitcoin_address passed')
        return True
    except Exception as e:
        print('Failed to execute unit test for bitcoin_address: ', e)
        return False


# Generated at 2022-06-21 16:23:54.093552
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment(seed = '1')
    assert provider.credit_card_network() == 'American Express'


# Generated at 2022-06-21 16:23:56.591227
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Calls function cid of class Payment
    result = Payment().cid()
    # Check if result is an int
    res = isinstance(result, int)
    # Compare with expected result
    assert res == True


# Generated at 2022-06-21 16:24:01.653227
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    obj = Payment()
    card_type = obj.credit_card_number()
    expiration_date = obj.credit_card_expiration_date()
    owner = obj.credit_card_owner()
    assert (isinstance(owner, dict) and owner['credit_card'] == card_type and owner['expiration_date'] == expiration_date)
