

# Generated at 2022-06-21 16:20:40.565303
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Test class Payment method credit_card_expiration_date

    :return: None
    """
    assert Payment().credit_card_expiration_date()



# Generated at 2022-06-21 16:20:49.520277
# Unit test for method credit_card_expiration_date of class Payment

# Generated at 2022-06-21 16:20:58.163142
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # Создаем экземпляр класса
    payment = Payment()
    # Проверяем соответсвие результата регулярному выражению
    pattern = re.compile(r'([0-1][1-9])/[1-9][0-9]{1,2}')
    assert re.match(pattern, payment.credit_card_expiration_date()) != None

# Generated at 2022-06-21 16:20:59.598800
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    # Test for credit_card_network method of class Payment
    res = payment.credit_card_network()
    assert res in CREDIT_CARD_NETWORKS

# Generated at 2022-06-21 16:21:01.525318
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Unit test for method cid of class Payment."""
    number = Payment().cid()
    assert 1000 < number <= 9999
    assert type(number) is int


# Generated at 2022-06-21 16:21:05.424106
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payload = Payment()
    credit_card_number = payload.credit_card_number(CardType.VISA)
    # Check the credit_card_number is valid
    # The first number in the credit_card_number is between 4 and 5
    assert credit_card_number[0] >= "4" and credit_card_number[0] <= "5"
    # Check the length of credit_card_number
    assert len(credit_card_number) == 16


# Generated at 2022-06-21 16:21:09.349328
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment(seed=1)
    assert payment.credit_card_owner() == {
                'credit_card': '4866 5132 9012 3311',
                'expiration_date': '09/17',
                'owner': 'ANTHONY STEWART'
            }

# Generated at 2022-06-21 16:21:11.916881
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis.enums import CardType
    payment = Payment()

    a = payment.credit_card_network()
    assert a in CREDIT_CARD_NETWORKS



# Generated at 2022-06-21 16:21:13.463200
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    pay = Payment()
    print('credit_card_network:', pay.credit_card_network())


# Generated at 2022-06-21 16:21:17.149922
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Expecting four-digit number
    cid = Payment('en').cid()
    assert(cid).isnumeric()
    assert(len(str(cid)) == 4)

    # Expecting five-digit number
    cid = Payment('en').cid(5)
    assert(cid).isnumeric()
    assert(len(str(cid)) == 5)


# Generated at 2022-06-21 16:21:27.387868
# Unit test for method cid of class Payment
def test_Payment_cid():
    test=Payment()
    assert test.cid() in range(1000, 10000)


# Generated at 2022-06-21 16:21:33.128158
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    c = Payment()
    for _ in range(10):
        number = c.credit_card_number(CardType.VISA)
        #assert re.fullmatch(r'\d{16}', number)
        assert re.fullmatch(r'[\d ]{19}', number)

# Generated at 2022-06-21 16:21:36.458835
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # cvv test
    from random import seed
    from mimesis.providers.payment import Payment
    seed(1)
    p = Payment()
    for i in range(100):
        assert p.cvv() == 696


# Generated at 2022-06-21 16:21:37.582934
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    print(p.ethereum_address())

# Generated at 2022-06-21 16:21:41.610827
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Unit test for method bitcoin_address of class Payment."""

    temp = Payment(seed=12345)
    assert temp.bitcoin_address() == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'


# Generated at 2022-06-21 16:21:44.248430
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment(random_state=1)
    data = payment.credit_card_expiration_date()
    expected = '05/20'
    assert data == expected


# Generated at 2022-06-21 16:21:50.090335
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Test data
    payment = Payment()
    output = payment.ethereum_address()

    # Test
    assert output is not None
    assert len(output) == len('0xe8ece9e6ff7dba52d4c07d37418036a89af9698d')


# Generated at 2022-06-21 16:21:55.078242
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment('en', seed=42)
    actual = payment.credit_card_expiration_date()
    expected = '04/21'
    if actual != expected:
        raise ValueError(f'{actual} != {expected}')

if __name__ == '__main__':
    test_Payment_credit_card_expiration_date()

# Generated at 2022-06-21 16:21:58.177158
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    paypal = p.paypal()
    print (paypal)
    assert "com" in paypal


# Generated at 2022-06-21 16:22:03.143423
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment.credit_card_number(CardType.VISA)
    payment.credit_card_number(CardType.MASTER_CARD)
    payment.credit_card_number(CardType.AMERICAN_EXPRESS)


# Generated at 2022-06-21 16:22:20.064613
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment('en')
    result = payment.ethereum_address()
    assert result != None
    assert len(result) == 42
    assert re.findall('[0-9a-fA-F]{40}', result) != None


# Generated at 2022-06-21 16:22:21.856906
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()

    assert re.match(r'0x[0-9a-fA-F]{40}', payment.ethereum_address())


# Generated at 2022-06-21 16:22:26.878485
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    def test_Payment_credit_card_network():
        seed = 1  # type: int
        Payment_object = Payment(seed=seed)  # type: Payment
        res = Payment_object.credit_card_network()  # type: str
        assert res == 'Visa'  # type: ignore



# Generated at 2022-06-21 16:22:31.080331
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # note: random.seed(1) is set in method Payment.__init__()
    p = Payment()
    print('Bitcoin Address: {}'.format(p.bitcoin_address()))
    print('Bitcoin Address: {}'.format(p.bitcoin_address()))


# Generated at 2022-06-21 16:22:32.899714
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    result = payment.cvv()
    assert type(result) == int


# Generated at 2022-06-21 16:22:35.217301
# Unit test for method cid of class Payment
def test_Payment_cid():
    result = Payment().cid()
    assert result >= 1000 and result <= 9999
    assert len(str(result)) == 4


# Generated at 2022-06-21 16:22:37.053540
# Unit test for constructor of class Payment
def test_Payment():
    print("\nUnit test for constructor of class Payment")
    payment = Payment()
    print("payment: ", payment)


# Generated at 2022-06-21 16:22:44.816171
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    testObj = Payment()
    minYear = int(input("Введите минимальный возраст на момент окончания срока действия карты: "))
    maxYear = int(input("Введите максимальный возраст на момент окончания срока действия карты: "))

# Generated at 2022-06-21 16:22:45.625775
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert Payment().cid()


# Generated at 2022-06-21 16:22:50.197188
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Test method cid() of class Payment"""
    
    import random
    import pickle

    random.seed(12345)
    
    pay = Payment(seed=12345)
    r = pay.cid()
    r2 = 8157

    with open('samples/payment_testsamples.pkl', 'rb') as f:
        data = pickle.load(f)
    assert r == r2
    assert r in data


# Generated at 2022-06-21 16:23:30.441683
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment1 = Payment(seed=0)
    assert payment1.credit_card_expiration_date() == '10/19'

    payment2 = Payment(seed=0)
    assert payment2.credit_card_expiration_date(minimum=16, maximum=25) == '10/19'

    payment3 = Payment(seed=0)
    assert payment3.credit_card_expiration_date(minimum=14, maximum=20) == '09/18'

# Generated at 2022-06-21 16:23:34.629902
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    test_obj = Payment()
    for _ in range(100):
        res = test_obj.ethereum_address()
        assert re.match(r'0x[0-9a-fA-F]{40}', res)

# Generated at 2022-06-21 16:23:35.486319
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    assert Payment('ru').ethereum_address()

# Generated at 2022-06-21 16:23:37.288178
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    d=Payment()
    if d.credit_card_network()== "Mastercard":
        assert 1
    else:
        assert 0


# Generated at 2022-06-21 16:23:38.448300
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    output = Payment().credit_card_network()
    assert output in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:23:40.147569
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    expected="1GSrGgfcAvdmzZwHm1AJzgEAAk1t9XVJe"
    myPayment = Payment(seed=42)
    actual = myPayment.bitcoin_address()
    assert expected == actual


# Generated at 2022-06-21 16:23:44.617637
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    f = Payment()
    res = f.credit_card_expiration_date()
    exp = re.match(r"(\d{2})/(\d{2})", res)
    assert (exp is not None and exp.group(1) <= "12"
            and exp.group(2) >= "16" and exp.group(2) <= "25")
    
    

# Generated at 2022-06-21 16:23:47.448721
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_expiration_date())
    print(payment.cvv())
    print(payment.credit_card_owner(Gender.MALE))
    
    

# Generated at 2022-06-21 16:23:50.270821
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis.random import Random
    rnd = Random()
    p = Payment('en', seed=rnd.random_int())
    eth = p.ethereum_address()
    assert isinstance(eth, str)
    assert eth.startswith('0x')
    assert len(eth) == 42


# Generated at 2022-06-21 16:23:52.001863
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    print("test_Payment_cvv")
    pp = Payment(random_state=1)
    res = pp.cvv()
    assert isinstance(res, int)
    assert res == 324


# Generated at 2022-06-21 16:25:12.507356
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment('en')
    month = payment.random.randint(1, 12)
    year = payment.random.randint(0, 25)
    if month == 12:
        expected_result = 'January, 1, {}'.format(year + 1)
    else:
        expected_result = '{0:02d}/{1}'.format(month + 1, year)

    assert payment.credit_card_expiration_date() == expected_result

# Generated at 2022-06-21 16:25:13.488864
# Unit test for constructor of class Payment
def test_Payment():
    temp = Payment()
    assert (temp is not None)


# Generated at 2022-06-21 16:25:17.446842
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment(seed=0)
    result = p.ethereum_address()
    assert result == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'



# Generated at 2022-06-21 16:25:20.407556
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    print(payment.bitcoin_address())
    # Example output: 1PMycacnJaSqwwJqjawXBErnLsZ7RkXUAs


# Generated at 2022-06-21 16:25:22.900625
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.credit_card_number() is not None
    assert payment.credit_card_expiration_date() is not None
    assert payment.cid() is not None
    assert payment.paypal() is not None
    assert payment.bitcoin_address() is not None
    assert payment.cvv() is not None
    assert payment.credit_card_network() is not None
    assert payment.credit_card_owner() is not None

# Generated at 2022-06-21 16:25:25.406426
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(random_state=1, locale='en')
    credit_card_number = payment.credit_card_number(CardType.MASTER_CARD)
    assert credit_card_number == '5274 9211 7643 2195'

# Generated at 2022-06-21 16:25:28.277142
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment"""
    assert len(Payment().ethereum_address()) == 42
    assert Payment().ethereum_address()[2:2+64].isalnum()

# Generated at 2022-06-21 16:25:32.500810
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    address = Payment().bitcoin_address()
    if address[0] != '1' and address[0] != '3':
        raise Exception('Address {} dont starts with 1 or 3.'.format(address))

    if len(address) != 34:
        raise Exception('Length of address {} not is 34.'.format(address))

    for char in address[1:]:
        if char not in string.ascii_letters and char not in string.digits:
            raise Exception('Address {} not valid.'.format(address))


# Generated at 2022-06-21 16:25:33.804269
# Unit test for method cid of class Payment
def test_Payment_cid():
    from mimesis.providers.payment import Payment

    payment = Payment()
    print(payment.cid())


# Generated at 2022-06-21 16:25:37.847309
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    p.paypal()
    p.cvv()
    p.credit_card_expiration_date()
    p.credit_card_number()
    p.credit_card_network()
    p.ethereum_address()
    p.bitcoin_address()
