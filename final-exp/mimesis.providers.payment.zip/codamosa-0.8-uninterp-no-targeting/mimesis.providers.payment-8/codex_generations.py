

# Generated at 2022-06-21 16:20:40.009459
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    for _ in range(100):
        p = Payment("en")
        result = p.cvv()
        assert (len(str(result)) == 3)


# Generated at 2022-06-21 16:20:43.041173
# Unit test for constructor of class Payment
def test_Payment():
    Payment = Payment()
    assert Payment.credit_card_owner().owner == 'WOLF BARRON'

# Generated at 2022-06-21 16:20:46.143814
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    assert len(p.bitcoin_address()) == 35
    assert p.bitcoin_address()[0] in ['1', '3']
    assert len(p.bitcoin_address()) == 35



# Generated at 2022-06-21 16:20:57.166010
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Unit test for method credit_card_expiration_date of class Payment."""
    import unittest
    import datetime
    from mimesis.providers.payment import Payment

    class PaymentTestCase(unittest.TestCase):

        def setUp(self):
            self.pay = Payment()

        def test_credit_card_expiration_date(self):
            expiration_date = self.pay.credit_card_expiration_date()
            cur_date = datetime.datetime.now()
            cur_year = cur_date.year
            cur_month = cur_date.month
            my_date = datetime.datetime.strptime(expiration_date + '/' + str(cur_year), '%m/%d/%Y')

# Generated at 2022-06-21 16:20:59.378659
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    result = payment.paypal()
    assert '@' in result and result.replace('@', '').isalnum()


# Generated at 2022-06-21 16:21:00.605286
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card_number = p.credit_card_number()
    print(card_number)

# Generated at 2022-06-21 16:21:03.229381
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
#   set seed for reproducibility
    p = Payment(seed=0)
    result = p.ethereum_address()
    assert result == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'


# Generated at 2022-06-21 16:21:10.200154
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test method credit_card_number of class Payment."""
    p = Payment()
    assert p.credit_card_number(CardType.VISA)
    assert p.credit_card_number(CardType.MASTER_CARD)
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert p.credit_card_number()
    assert p.credit_card_number()
    assert p.credit_card_number()
    assert p.credit_card_number()
    assert p.credit_card_number()
    assert type(p.credit_card_number()) == str

# Generated at 2022-06-21 16:21:14.449996
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert len(str(p.credit_card_number())) == 16
    assert len(str(p.credit_card_number(CardType.AMERICAN_EXPRESS))) == 15
    assert len(str(p.credit_card_number(CardType.MASTER_CARD))) == 16
    assert len(str(p.credit_card_number(CardType.VISA))) == 16

# Generated at 2022-06-21 16:21:17.441244
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment('en')
    count = 0
    for i in range(1, 100):
        assert len(payment.ethereum_address()) == 42
        count += 1
    print(count)


# Generated at 2022-06-21 16:21:37.617787
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis import Payment
    from mimesis.enums import CardType
    from mimesis.enums import Gender
    
    p = Payment('en',seed=50)
    
    print('Testing credit_card_expiration_date')
    print('    Output: {0}'.format(p.credit_card_expiration_date()))
    print('    Expected: 11/22')
    

# Generated at 2022-06-21 16:21:46.512869
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()

    # Check that the format is correct.
    card_owner = p.credit_card_owner()
    assert isinstance(card_owner['credit_card'], str)
    assert isinstance(card_owner['expiration_date'], str)
    assert isinstance(card_owner['owner'], str)

    # Check that the keys exist.
    assert 'credit_card' in card_owner
    assert 'expiration_date' in card_owner
    assert 'owner' in card_owner

    # Check the value of expiration_date
    assert isinstance(card_owner['expiration_date'].split('/')[0], str)
    assert isinstance(card_owner['expiration_date'].split('/')[1], str)

# Generated at 2022-06-21 16:21:49.610847
# Unit test for constructor of class Payment
def test_Payment():
    test = Payment(seed = 0)
    return 


# Generated at 2022-06-21 16:21:53.633838
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert isinstance(p, Payment)
    assert isinstance(p.random, BaseProvider)
    assert isinstance(p.datetime, BaseProvider)
    assert isinstance(p.__person, Person)

# Generated at 2022-06-21 16:21:55.957303
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))


# Generated at 2022-06-21 16:21:59.147371
# Unit test for constructor of class Payment
def test_Payment():
    # create instance of class Payment
    payment = Payment()
    assert payment != None


# Generated at 2022-06-21 16:22:05.060254
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    import pytest
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment

    test_paypal = Payment()
    assert '@' in test_paypal.paypal()
    assert test_paypal.paypal(gender=Gender.MALE) == test_paypal.paypal(gender=Gender.FEMALE)

# Generated at 2022-06-21 16:22:10.670004
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    #assert re.match(r"^(([^<>()\[\]\\.,;:\s@']+(\.[^<>()\[\]\\.,;:\s@']+)*)|('.+'))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$", payment.paypal()) is not None
    print(payment.paypal())
    assert True

# Generated at 2022-06-21 16:22:13.773540
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    from mimesis.builtins import Payment

    p = Payment()
    assert p.type(p.paypal(),"paypal") == True

# Generated at 2022-06-21 16:22:16.205308
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    from mimesis.enums import CardType
    p = Payment()
    test_var = p.cvv()
    assert type(test_var) == int


# Generated at 2022-06-21 16:22:50.088697
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    print(p.credit_card_expiration_date())


# Generated at 2022-06-21 16:22:55.072739
# Unit test for constructor of class Payment
def test_Payment():
    # payment = Payment('en', seed=4)
    payment = Payment()
    # print(payment.provider.seed)
    print(payment.cid())
    print(payment.paypal())
    print(payment.bitcoin_address())
    print(payment.ethereum_address())
    print(payment.credit_card_network())
    print(payment.credit_card_number())
    print(payment.credit_card_expiration_date())
    print(payment.cvv())
    print(payment.credit_card_owner(gender=Gender.MALE))


# Generated at 2022-06-21 16:22:59.687303
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.VISA))
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-21 16:23:00.588460
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    return True


# Generated at 2022-06-21 16:23:10.954134
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    from mimesis.enums import Gender
    from mimesis.enums import CardType
    from mimesis.enums import Gender
    
    from mimesis.providers.payment import Payment
    
    payment = Payment(seed=42)
    
    assert payment.cvv() == 717
    assert payment.credit_card_network() == 'Visa'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5408 0516 1517 6176'
    assert payment.credit_card_expiration_date(13, 18) == '02/13'

# Generated at 2022-06-21 16:23:14.070383
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert payment.cvv() > 0 and payment.cvv() < 1000


# Generated at 2022-06-21 16:23:23.144370
# Unit test for constructor of class Payment
def test_Payment():
    _payment = Payment(seed=1)  # payment is the name of class
    # this is the attribute of class Person
    # We will use the function called Person.full_name
    # that is defined in the class Person
    # This is the attribute of class Payment
    # We will use the function called Payment.credit_card_number
    # that is defined in the class Payment
    _person = Person(seed=1)  # person is the name of class
    print(_payment.credit_card_number())
    print(_person.full_name())
    # The functions that are defined in the class Payment
    # will be used


# Generated at 2022-06-21 16:23:24.560661
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert len(Payment.cid()) == 4


# Generated at 2022-06-21 16:23:27.082451
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Test for method credit_card_network of class Payment."""
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    
    p = Payment()
    assert p.credit_card_network() in CardType.__members__.values()
    assert isinstance(p.credit_card_network(), str)



# Generated at 2022-06-21 16:23:28.316914
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date()

# Generated at 2022-06-21 16:24:43.458635
# Unit test for method cid of class Payment
def test_Payment_cid():
    provider = Payment()
    cid = provider.cid()
    assert isinstance(cid, int)
    assert 1000 <= cid <= 9999, "cid must be in range [1000, 9999] inclusive"


# Generated at 2022-06-21 16:24:45.103268
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:24:45.789146
# Unit test for method cid of class Payment
def test_Payment_cid():
	pass


# Generated at 2022-06-21 16:24:47.651620
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert payment.ethereum_address() == "0x86a9e837f03794d6b0de27b080026d8c7814fdbc"



# Generated at 2022-06-21 16:24:49.366195
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    expiration_date = payment.credit_card_expiration_date(2020)
    if expiration_date[3:] != '20':
        raise Exception('expiration_date[3:] != 20')

# Generated at 2022-06-21 16:24:53.337210
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment.credit_card_number(card_type=CardType.MASTER_CARD)
    payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    payment.credit_card_number(card_type=CardType.VISA)

# Generated at 2022-06-21 16:24:55.392315
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    assert (payment.bitcoin_address()[0]=="1" or payment.bitcoin_address()[0]=="3")


# Generated at 2022-06-21 16:24:58.169304
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import Gender
    payment = Payment('en')
    print(payment.credit_card_expiration_date())
    print(payment.credit_card_expiration_date(16, 25))


# Generated at 2022-06-21 16:25:00.980708
# Unit test for constructor of class Payment
def test_Payment():
    """
    Here is a unit test for the constructor of the class Payment.
    """
    # Arrange
    # Act
    test_class = Payment()
    # Assert
    assert test_class is not None


# Generated at 2022-06-21 16:25:02.987407
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment()
    assert isinstance(provider.credit_card_network(), str)
    assert provider.credit_card_network() in CREDIT_CARD_NETWORKS
