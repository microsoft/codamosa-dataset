

# Generated at 2022-06-21 16:20:37.262901
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    for i in range(10):
        cid = payment.cid()
        assert(isinstance(cid, int))
        assert(cid > 1000 and cid < 9999)


# Generated at 2022-06-21 16:20:39.495980
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    result = Payment().cvv()
    assert len(str(result)) == 3


# Generated at 2022-06-21 16:20:42.165564
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    p.credit_card_number(CardType.MASTER_CARD)



# Generated at 2022-06-21 16:20:43.945599
# Unit test for method cid of class Payment
def test_Payment_cid():
    x = Payment(seed=1)
    test_result = x.cid()
    expected_result = 7452
    assert test_result == expected_result


# Generated at 2022-06-21 16:20:45.989787
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment('en')
    print(payment.paypal())
    assert(payment.paypal() != None)



# Generated at 2022-06-21 16:20:48.612276
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Create test providers
    rnd = Random()
    pr1 = Payment(rnd)
    # Create random credit card owner
    card_owner = pr1.credit_card_owner()
    print("Owner of credit card is {0}".format(card_owner))

# Generated at 2022-06-21 16:20:51.994013
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment(seed=4357)
    assert payment.paypal() == "georgehatcher@hotmail.com"
    assert payment.paypal() == "robertbaldwin@yahoo.com"


# Generated at 2022-06-21 16:20:52.949597
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    cc = payment.credit_card_number()
    assert len(cc) == 19 and cc[0] == '4'

# Generated at 2022-06-21 16:20:55.530831
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    cc = payment.credit_card_owner()
    print("cc: {}".format(cc))
    assert isinstance(cc, dict)

# Generated at 2022-06-21 16:20:58.501510
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    a = Payment('en')

    # Test the type of a is str
    assert type(a.bitcoin_address()) == str

    # Test length of a is 34
    assert len(a.bitcoin_address()) == 34


# Generated at 2022-06-21 16:21:07.325180
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    c = Payment()
    print(c.paypal())

# Generated at 2022-06-21 16:21:09.975930
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment()
    Visa = provider.credit_card_network()
    assert provider.credit_card_network() in ['Visa','MasterCard','American Express','Discover','Cartes Bancaires','Diners Club','JCB','CartaSi']
    assert Visa == 'Visa'


# Generated at 2022-06-21 16:21:13.722014
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    print ("test_Payment_bitcoin_address method started")
    # Create object of class Payment
    pay = Payment(seed=0)

    # Generate bitcoin address
    result = pay.bitcoin_address()
    # Check if bitcoin address is None
    assert result is not None
    print ("test_Payment_bitcoin_address method completed")



# Generated at 2022-06-21 16:21:15.860094
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cvv = payment.cvv()
    assert isinstance(cvv, int)
    assert re.match(r'[\d]{3}', str(cvv)) is not None


# Generated at 2022-06-21 16:21:16.816818
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert payment.paypal()


# Generated at 2022-06-21 16:21:19.945559
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment('en')
    payment.set_seed(123)
    assert payment.credit_card_network() == 'Visa'
    assert payment.credit_card_network() == 'Visa'
    assert payment.credit_card_network() == 'Visa'
    assert payment.credit_card_network() == 'Visa'
    assert payment.credit_card_network() == 'Visa'


# Generated at 2022-06-21 16:21:23.339481
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    print(payment.ethereum_address())
    # 0xe8ece9e6ff7dba52d4c07d37418036a89af9698d


# Generated at 2022-06-21 16:21:29.866624
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    Payment._reseed = b'This is a random seed'
    p = Payment()
    minm = 16
    maxm = 25
    res = p.credit_card_expiration_date(minimum=minm, maximum=maxm)

    year = int(res.split('/')[1])
    # print('year = ', year)
    assert year >= minm and year <= maxm
    # print('res = ', res)


# Generated at 2022-06-21 16:21:34.139139
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    a1 = Payment()
    print(a1.credit_card_owner())
    print(a1.credit_card_owner(Gender.MALE))

if __name__ == '__main__':
    test_Payment_credit_card_owner()

# Generated at 2022-06-21 16:21:35.403610
# Unit test for constructor of class Payment
def test_Payment():
    my_payment = Payment()
    my_payment = Payment('en')
    my_payment = Payment(seed=1)
    my_payment = Payment('en', seed=1)


# Generated at 2022-06-21 16:21:54.315073
# Unit test for constructor of class Payment
def test_Payment():
  payment = Payment()

  print(payment.credit_card_number())

# Generated at 2022-06-21 16:21:55.888632
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis.providers.payment import Payment
    p = Payment()
    print(p.ethereum_address())

# Generated at 2022-06-21 16:21:58.284677
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert payment.cvv() in range(100, 1000)

# Generated at 2022-06-21 16:22:08.381605
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment('en')
    assert payment.cid() != payment.cid()
    assert payment.paypal() == 'lmorgan@hotmail.com'
    assert payment.bitcoin_address() == '1L9tLfztPcLNLnQ2vH5ifFEn8DphjCx5Qh'
    assert payment.ethereum_address() == '0x6cfc2054e1dc6b62c6b10fdf3e3cc0bd8d123b0c'

    # 12/24 is not a valid expiration date
    assert payment.credit_card_expiration_date(12, 24) != '12/24'

    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card

# Generated at 2022-06-21 16:22:15.635303
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    pay = Payment(seed=['test'])
    assert re.match(r'1[A-Za-z\d]{33}', pay.bitcoin_address())
    assert re.match(r'3[A-Za-z\d]{33}', pay.bitcoin_address())


# Generated at 2022-06-21 16:22:17.669721
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date(minimum=16, maximum=25) == '11/18'

# Generated at 2022-06-21 16:22:20.519836
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """
    Test method credit_card_network of class Payment
    """

    seed = 0
    pr = Payment(seed=seed)

    result = pr.credit_card_network()
    assert result == 'MasterCard'



# Generated at 2022-06-21 16:22:23.795609
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    from mimesis.providers.payment import Payment
    provider = Payment()
    result = provider.paypal()
    assert type(result) == str
    pattern = re.compile(r'^[A-Za-z0-9_.+-]+@[A-Za-z0-9-]+\.[A-Za-z0-9-.]+$')
    assert pattern.search(result)


# Generated at 2022-06-21 16:22:27.406130
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Unit test for method credit_card_network of class Payment."""
    card_network = Payment()
    # print("Test for method credit_card_network of class Payment:")
    assert isinstance(card_network.credit_card_network(), str)
    # print("Pass")


# Generated at 2022-06-21 16:22:30.281419
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    assert Payment().paypal() == 'gonzalezoscar@hotmail.com'
    assert Payment().paypal() == 'vsmith8@about.com'


# Generated at 2022-06-21 16:23:17.269800
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment"""
    payment = Payment()
    re_ethereum_address = re.compile(r'0x[0-9a-f]{40}')
    assert re_ethereum_address.match(payment.ethereum_address()) is not None


# Generated at 2022-06-21 16:23:23.144084
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """
    Unit test for method "ethereum_address" of class "Payment"
    """
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment
    payment = Payment()

    assert payment.ethereum_address() is not None
    assert payment.ethereum_address() is not ""
    assert payment.ethereum_address() is not 0


# Generated at 2022-06-21 16:23:25.297117
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card = p.credit_card_number(card_type=CardType.VISA)
    assert len(card.replace(" ","")) == 16
    

# Generated at 2022-06-21 16:23:27.369971
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    cvv = Payment().cvv()
    assert len(str(cvv)) == 3
    assert 0 < cvv < 1000

# Generated at 2022-06-21 16:23:32.596560
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Test the method bitcoin_address of the class Payment."""
    # Init
    import pytest
    from mimesis.providers.payment import Payment
    from mimesis.enums import CardType
    x = Payment()
    # Run test
    for _ in range(10):
        assert re.search(r'^(1|3)[a-zA-Z0-9]{33}$', x.bitcoin_address())

# Generated at 2022-06-21 16:23:35.059712
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()  # Create an object
    assert payment.cid() <= 9999 and payment.cid() >= 1000
    

# Generated at 2022-06-21 16:23:36.468015
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    assert isinstance(payment.credit_card_owner(), dict)


# Generated at 2022-06-21 16:23:41.843864
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Test 1
    if Payment('en', seed=12345).paypal() == 'faculdadeconcordia@gmail.com':
        print('Test 1. Teste realizado com sucesso.')

    # Test 2
    if Payment('en', seed=1).paypal() == 'generaldispatcher@hotmail.com':
        print('Test 2. Teste realizado com sucesso.')



# Generated at 2022-06-21 16:23:43.843984
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    for _ in range(100):
        cid = payment.cid()
        assert (len(str(cid)) == 4)


# Generated at 2022-06-21 16:23:45.387173
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    print("address: %s" % payment.bitcoin_address() )


# Generated at 2022-06-21 16:25:23.029618
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """ Unit test for method credit_card_number of class Payment.

    :return: None
    """
    from typing import List
    from random import choice

    results = list()  # type: List[str]

    for i in range(10000):
        pp = Payment()
        results.append(pp.credit_card_number().replace(" ", ""))
    for result in set(results):
        assert len(result) == 16
        assert choice(CardType) in CardType.__members__
    print("Test of method credit_card_number() of class Payment: Passed")

# Generated at 2022-06-21 16:25:25.172356
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment(seed=42)
    assert repr(payment) == '<Payment>'



# Generated at 2022-06-21 16:25:28.595418
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    seed = 42
    payment = Payment(seed=seed)
    address = '0x6c755f14026eaf8c31d24b12d7bfdc4e9699c4e4'
    assert payment.ethereum_address() == address


# Generated at 2022-06-21 16:25:30.930891
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    with open("Payment.txt", "w") as my_file:
        p = Payment()
        for i in range(10000):
            cvv = p.cvv()
            print(cvv, file = my_file)
            print(cvv)


# Generated at 2022-06-21 16:25:32.501186
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    assert re.match(r'\d{2}/\d{2}', p.credit_card_expiration_date())

# Generated at 2022-06-21 16:25:34.491590
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    ethereum_address = Payment.ethereum_address()
    assert type(ethereum_address) is str
    assert len(ethereum_address) is 42
    assert ethereum_address[:2] == '0x'


# Generated at 2022-06-21 16:25:35.638184
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert Payment().cvv() > 100 and Payment().cvv() < 999


# Generated at 2022-06-21 16:25:40.023798
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    print(p.credit_card_number())
    print(p.credit_card_number(CardType.MASTER_CARD))
    print(p.credit_card_number(CardType.AMERICAN_EXPRESS))

if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-21 16:25:43.402992
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert Payment('en').bitcoin_address() == '3GEDfHkRZW8M53niKMnAgtbcvxHxq3tXzz'

# Generated at 2022-06-21 16:25:46.436146
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    In this test function, we test credit_card_number function of Payment class
    """
    payment = Payment()
    credit_card_nums = payment.credit_card_number(card_type="VISA")
    assert credit_card_nums
    assert credit_card_nums.find(" ") != -1

# Generated at 2022-06-21 16:28:41.517154
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    a = Payment('en', seed=12345)
    for _ in range(10):
        print(a.credit_card_network())



# Generated at 2022-06-21 16:28:44.823095
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment('en')
    data = payment.credit_card_owner()
    print(data)
    assert data['owner'] != ''
    assert data['expiration_date'] != ''
    assert data['credit_card'] != ''

test_Payment()

# Generated at 2022-06-21 16:28:46.352513
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    from mimesis.typing import Seed

    payment = Payment(seed=Seed(1))
    assert payment.paypal() == 'wolf235@gmail.com'



# Generated at 2022-06-21 16:28:49.754938
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    print('Done')
    print(payment.credit_card_network())


# Generated at 2022-06-21 16:28:52.135835
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    results = []
    iterations = 10
    for _ in range(iterations):
        r = payment.credit_card_owner(Gender.MALE)
        results.append(r)
    print("result: {}".format(results))


# Generated at 2022-06-21 16:28:55.139355
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p.credit_card_network() in CREDIT_CARD_NETWORKS
test_Payment()

# Generated at 2022-06-21 16:29:02.958492
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment(seed=123)

    # check for cid, paypal, credit_card_network, credit_card_number,
    # credit_card_expiration_date, cvv
    assert p.cid() == 8538
    assert p.paypal() == 'florencejamest@hotmail.com'
    assert p.credit_card_network() == 'Visa'
    assert p.credit_card_number() == '4946 4632 9378 9098'
    assert p.credit_card_expiration_date() == '04/20'
    assert p.cvv() == 414

# Generated at 2022-06-21 16:29:03.885736
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())

# Generated at 2022-06-21 16:29:05.183176
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    a = Payment()
    print(a.bitcoin_address())
#test_Payment_bitcoin_address()


# Generated at 2022-06-21 16:29:06.262688
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    owner = p.credit_card_owner()
    print(owner)