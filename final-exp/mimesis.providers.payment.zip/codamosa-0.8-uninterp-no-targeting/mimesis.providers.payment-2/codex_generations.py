

# Generated at 2022-06-21 16:20:39.213478
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    assert (type(p.cid()) == int)


# Generated at 2022-06-21 16:20:42.274804
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.credit_card_owner()['credit_card'] == '5217 2825 4993 4972'

# Generated at 2022-06-21 16:20:45.709766
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment_test = Payment()
    print("Test method credit_card_number of class Payment")
    print("The value of random credit card number is:")
    print(Payment_test.credit_card_number())


# Generated at 2022-06-21 16:20:52.979564
# Unit test for method cid of class Payment
def test_Payment_cid():
    f = Payment()
    print(f.cid())
    # print(f.paypal())
    # print(f.bitcoin_address())
    # print(f.ethereum_address())
    # print(f.credit_card_network())
    # print(f.credit_card_number())
    # print(f.credit_card_expiration_date())
    # print(f.cvv())
    # print(f.credit_card_owner())


test_Payment_cid()

# Generated at 2022-06-21 16:20:54.417014
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    (card_number, card_type) = payment.credit_card_number(CardType.VISA)
    assert(re.match("^4\d{3} \d{4} \d{4} \d{4}$", card_number) != None)

# Generated at 2022-06-21 16:20:56.434664
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """
    test for method cvv of class Payment
    """
    payment = Payment()
    assert 100 <= payment.cvv() <= 999

# Generated at 2022-06-21 16:20:58.714288
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment(seed=123456789)
    paypal = payment.paypal()
    assert paypal == 'jane547@yahoo.com'


# Generated at 2022-06-21 16:21:04.865241
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.providers.payment import Payment
    p = Payment()
    print(p.credit_card_expiration_date())
    print(p.credit_card_expiration_date(1, 2))
    print(p.credit_card_expiration_date(1, 5))
    print(p.credit_card_expiration_date(1, 10))
    print(p.credit_card_expiration_date(1, 15))
    print(p.credit_card_expiration_date(1, 20))
    print(p.credit_card_expiration_date(1, 30))
    print(p.credit_card_expiration_date(1, 40))



# Generated at 2022-06-21 16:21:11.111876
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from datetime import datetime
    from mimesis.enums import CardType, Gender
    from payment import Payment
    payment = Payment()
    card_type: CardType = payment.random.choice(CardType.__members__.values())
    gender: Gender = payment.random.choice(Gender.__members__.values())
    if (card_type == CardType.VISA or
            card_type == CardType.MASTER_CARD or
            card_type == CardType.AMERICAN_EXPRESS):
        exp_date = payment.credit_card_expiration_date()
        exp_date_ = '{0:02d}/{1:02d}'.format(payment.random.randint(1, 12),
                                             payment.random.randint(16, 25))
        assert exp_date == exp_date

# Generated at 2022-06-21 16:21:13.219473
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment('en')
    for i in range(10):
        assert re.match(r"[\w\.-]+@[\w\.-]+", payment.paypal())

# Generated at 2022-06-21 16:21:31.965134
# Unit test for constructor of class Payment
def test_Payment():
    a=Payment()
    assert isinstance(a,Payment)
    assert isinstance(a.cid(), int)
    assert isinstance(a.paypal(), str)
    assert isinstance(a.bitcoin_address(), str)
    assert isinstance(a.ethereum_address(), str)
    assert isinstance(a.credit_card_network(), str)
    assert isinstance(a.credit_card_number(), str)
    assert isinstance(a.credit_card_expiration_date(), str)
    assert isinstance(a.cvv(), int)
    assert isinstance(a.credit_card_owner(), dict)

# Generated at 2022-06-21 16:21:36.871292
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    credit_card_owner = Payment().credit_card_owner()
    assert isinstance(credit_card_owner['credit_card'], str)
    assert isinstance(credit_card_owner['expiration_date'], str)
    assert isinstance(credit_card_owner['owner'], str)

# Generated at 2022-06-21 16:21:41.068248
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis.enums import CardType
    payment = Payment()
    items = [
        CardType.VISA,
        CardType.MASTER_CARD,
        CardType.AMERICAN_EXPRESS,
    ]
    for _ in range(100):
        assert payment.credit_card_network() in items

# Generated at 2022-06-21 16:21:46.513029
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    payment.seed(1)
    assert payment.cid() == 3895
    assert payment.cid() == 7923
    assert payment.cid() == 7449
    assert payment.cid() == 5320
    assert payment.cid() == 8244
    assert payment.cid() == 1659
    assert payment.cid() == 1253
    assert payment.cid() == 4952
    assert payment.cid() == 5801
    assert payment.cid() == 2535


# Generated at 2022-06-21 16:21:51.082100
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Test for method cid of class Payment"""
    payment_object = Payment()
    assert len(str(payment_object.cid())) == 4


# Generated at 2022-06-21 16:21:53.230635
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    x = Payment()
    #assert x.credit_card_network() == 'Visa'


# Generated at 2022-06-21 16:21:59.462201
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    provider = Payment('en')
    ethereum_address = provider.ethereum_address()
    # assert re.match(r'^(0x)[0-9a-f]{40}$', ethereum_address)
    #assert re.match(r'0x[a-fA-F0-9]{40}', ethereum_address)
    #assert re.match(r'0x[a-fA-F0-9]{40}', ethereum_address)
    #assert re.match(r'0x[a-fA-F0-9]{40}', ethereum_address)
    assert re.match(r'0x[a-fA-F0-9]{40}', ethereum_address)



# Generated at 2022-06-21 16:22:03.544558
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pay = Payment()
    res = pay.paypal()
    assert re.match(pattern=r'.{1,300}\@.{1,300}\.[a-zA-Z]{2,4}', string=res)

# Generated at 2022-06-21 16:22:05.687209
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment(seed=123456)
    assert payment.paypal() == 'louiseleclerc@hotmail.com'

# Generated at 2022-06-21 16:22:07.141862
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment: Payment = Payment()
    assert payment.ethereum_address().startswith('0x')  # type: ignore

# Generated at 2022-06-21 16:22:34.798066
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment('en')
    assert isinstance(payment.ethereum_address(), str)


# Generated at 2022-06-21 16:22:42.775889
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment(seed=42)
    assert payment.cid() == 7452
    assert payment.paypal() == "jonathanholt@gmail.com"
    assert payment.bitcoin_address() == "1GKj9BPFzGWnUSVg1twwRjYwT1TpCchE8v"
    assert payment.ethereum_address() == "0x00b2779eaa43ac6b72db8044bcd09a19d077b9c4"
    assert payment.credit_card_network() == "MasterCard"
    assert payment.credit_card_number() == "4873 2428 7951 3457"
    assert payment.credit_card_expiration_date() == "02/17"
    assert payment.cvv() == 384
    assert payment.credit_card_

# Generated at 2022-06-21 16:22:50.226088
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    import re
    import pytest

    payment = Payment()
    assert (isinstance(payment.credit_card_owner(Gender.MALE), dict)
            is True)
    cc_number = payment.credit_card_number()
    cc_number_length = len(cc_number)
    cc_number_regex = re.compile(r'\d{4}-\d{4}-\d{4}-\d{4}')
    cc_expiration = payment.credit_card_expiration_date()
    cc_expiration_length = len(cc_expiration)
    cc_owner = payment.credit_card_owner(Gender.MALE)
    cc_owner_cc = cc_owner['credit_card']
    cc_owner_exp = cc_

# Generated at 2022-06-21 16:22:51.652858
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    a = p.credit_card_network()
    assert isinstance(a, str)


# Generated at 2022-06-21 16:22:53.273173
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    a=Payment(seed=0)
    assert a.paypal()=="mletz8@example.com"


# Generated at 2022-06-21 16:22:55.774687
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Test credit_card_owner method."""
    import mimesis
    import datetime
    payment = mimesis.Payment()
    payment.random.seed(43)
    owner = payment.credit_card_owner(gender='male')
    assert owner == {
        'credit_card': '4757 0366 6118 1701',
        'expiration_date': '09/19',
        'owner': 'BENJAMIN WINTERS',
    }

# Generated at 2022-06-21 16:22:56.944778
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Test DocString."""
    cvv = Payment().cvv()
    print('cvv = {0}'.format(cvv))
    assert type(cvv) is int



# Generated at 2022-06-21 16:22:59.497606
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    m = Payment()
    CVV = m.cvv()
    assert type(CVV) == int
# End of unit test

# Generated at 2022-06-21 16:23:01.482998
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    pay = Payment()
    assert isinstance(pay.cvv(), int)
    assert 99 < pay.cvv() < 1000


# Generated at 2022-06-21 16:23:04.504722
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    cc = p.cvv()
    assert len(str(cc)) == 3
    assert str(cc).isdigit()


# Generated at 2022-06-21 16:24:04.373041
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pay = Payment()
    result = pay.paypal()
    assert isinstance(result, str)


# Generated at 2022-06-21 16:24:05.777230
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment ('ru')
    assert payment.cvv() == payment.cvv()

# Generated at 2022-06-21 16:24:09.176694
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    assert len(Payment().credit_card_owner()['owner']) > 0
    assert len(Payment().credit_card_owner()['credit_card']) == 19
    assert len(Payment().credit_card_owner()['expiration_date']) == 5


# Generated at 2022-06-21 16:24:14.255296
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    c = Payment()
    owner = c.credit_card_owner(Gender.MALE)
    assert len(owner) == 3
    assert re.fullmatch(r'[\d|\s]{12,20}', owner['credit_card'])
    assert re.fullmatch(r'^\d\d/\d{2}$', owner['expiration_date'])
    assert re.fullmatch(r'^[A-Z|\s]+$', owner['owner'])

# Generated at 2022-06-21 16:24:17.414100
# Unit test for method cid of class Payment
def test_Payment_cid():
    a = [Payment('en').cid() for i in range(10)]
    assert all ([len(str(k)) == 4 for k in a])
    assert all ([k in range(1000, 10000) for k in a])


# Generated at 2022-06-21 16:24:18.187153
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    tmp = Payment()
    tmp.bitcoin_address()

# Generated at 2022-06-21 16:24:20.107228
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """ Test for method paypal of class Payment
    """
    payment = Payment(seed=123)
    assert( payment.paypal() == 'huntershaffer@yahoo.com')


# Generated at 2022-06-21 16:24:23.575124
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    length_of_test = 100
    for i in range(length_of_test):
        assert Payment().cvv() <= 999
        assert Payment().cvv() >= 100

# Generated at 2022-06-21 16:24:24.409831
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert isinstance(payment, Payment)


# Generated at 2022-06-21 16:24:26.837838
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    p.credit_card_number("visa");

# Generated at 2022-06-21 16:26:23.751808
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    x = Payment(seed=0).credit_card_owner()
    assert x == {'credit_card': '4455 5299 1152 2450', 
                 'expiration_date': '12/18', 
                 'owner': 'William Dickson'}


# Generated at 2022-06-21 16:26:25.420193
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import Gender
    payment = Payment('ru')
    b = payment.credit_card_expiration_date(2020)
    print(b)

# Generated at 2022-06-21 16:26:26.526131
# Unit test for method cid of class Payment
def test_Payment_cid():
    a = Payment()
    print(a.cid())


# Generated at 2022-06-21 16:26:27.787300
# Unit test for method cid of class Payment
def test_Payment_cid():

    temp = Payment()
    for i in range(0, 100):
        temp.cid()


# Generated at 2022-06-21 16:26:29.567113
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    a = Payment(seed=1)
    print("test_Payment_paypal:")
    print(a.paypal())


# Generated at 2022-06-21 16:26:31.950366
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    print("Payment.ethereum_address()")
    print(Payment.ethereum_address())
    print(Payment.ethereum_address())

# Generated at 2022-06-21 16:26:33.604529
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    print(p.cvv())
    assert (p.cvv() is not None)


# Generated at 2022-06-21 16:26:35.271695
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Initialization
    payment = Payment()
    # Test
    paypal = payment.paypal()
    # Assertions
    assert "@" in paypal


# Generated at 2022-06-21 16:26:36.181551
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert len(Payment().bitcoin_address()) == 35


# Generated at 2022-06-21 16:26:41.196644
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    pc = Payment()
    data = pc.credit_card_owner(gender=Gender.FEMALE)
    # Here only check the first and last of credit card owner's full name:
    first_name = data.get('owner').split()[0]
    last_name = data.get('owner').split()[1]
    assert first_name.isalpha()
    assert last_name.isalpha()
    assert isinstance(data.get('credit_card'), str)
    assert isinstance(data.get('expiration_date'), str)
    assert isinstance(data.get('owner'), str)



# Generated at 2022-06-21 16:30:08.953029
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card = Payment().credit_card_number()
    assert card[-1:] == str(Payment().luhn_checksum(card[:-1]))

# Generated at 2022-06-21 16:30:12.726220
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """
    Test the Payment class method ethereum_address to validate it returns
    a string of the correct format.
    """

    print('Running test_Payment_ethereum_address.')

    # Instantiate a Payment object
    pa = Payment()

    # Generate a random Ethereum address string
    eth_address = pa.ethereum_address()

    assert(isinstance(eth_address, str))
    assert(len(eth_address) == 42)

# Generated at 2022-06-21 16:30:18.399948
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    for i in range(0, 10):
        # For some reason it does not work with random gender, but it works with random gender enum object
        credit_card_owner = payment.credit_card_owner(gender=Gender.from_(payment.random.randint(0, 1)))
        print(credit_card_owner)

# Generated at 2022-06-21 16:30:21.963132
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p_1=Payment()
    p_1.name
    print(p_1.paypal())
    
    
    
    
    
    
    
    
  
print(test_Payment_paypal())



# Generated at 2022-06-21 16:30:24.710521
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cid = payment.cid()
    assert 1000 <= cid <= 9999 and isinstance(cid, int), 'Wrong type'


# Generated at 2022-06-21 16:30:25.471605
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pay = Payment()
    print(pay.paypal())

# Generated at 2022-06-21 16:30:27.451364
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    Pay = Payment(random=True)
    assert re.match(r"0x[a-fA-F0-9]{40}", Pay.ethereum_address())

# Generated at 2022-06-21 16:30:30.317488
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    my_payment_gen = Payment()
    assert my_payment_gen.cvv() in range(100, 1000)
    

# Generated at 2022-06-21 16:30:35.225327
# Unit test for method cid of class Payment
def test_Payment_cid():
    # create a instance of class Payment
    payment = Payment()
    # get the cid
    cid = payment.cid()
    # a cid must be an integer, it has 4 digits
    assert isinstance(cid, int) and len(str(cid)) == 4

# unit test for method paypal of class Payment