

# Generated at 2022-06-21 16:20:36.578314
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    result = payment.bitcoin_address()
    assert len(result) == 35


# Generated at 2022-06-21 16:20:47.619372
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    import random
    import string
    random.seed(1)

    def get_random_string(length):
        letters = string.ascii_letters + string.digits
        return ''.join(random.choice(letters) for i in range(length))

    def get_random_address():
        bits = random.getrandbits(160)
        address = bits.to_bytes(20, byteorder='big')
        return '0x' + address.hex()

    py_address = get_random_address()
    cpp_address = get_random_string(42)
    print(py_address, cpp_address)

    payment = Payment(seed=1)
    assert payment.ethereum_address() == cpp_address



# Generated at 2022-06-21 16:20:58.374503
# Unit test for method credit_card_owner of class Payment

# Generated at 2022-06-21 16:20:59.764009
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cid = payment.cid()
    assert cid >= 1000 and cid <= 9999


# Generated at 2022-06-21 16:21:02.576482
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    payment = Payment()
    payment.credit_card_owner(gender=Gender.MALE)


# Generated at 2022-06-21 16:21:05.865586
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    provider = Payment()
    result = list()
    for x in range (100):
        result.append(provider.ethereum_address())
    print(result)


if __name__ == '__main__':
    test_Payment_ethereum_address()

# Generated at 2022-06-21 16:21:09.438795
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    result = payment.bitcoin_address()
    assert result != "3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX"


# Generated at 2022-06-21 16:21:12.955867
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    import pytest
    p = Payment(seed=12345)
    sample = "1xSyNwPPMoZnEyHucz5GADP5oK2EDCt5r5"
    assert p.bitcoin_address() == sample, "test_Payment_bitcoin_address: bitcoin_address()"

# Generated at 2022-06-21 16:21:15.509805
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    flag = True
    p = Payment()
    if type(p.cvv()) != int:
        flag = False
    if len(str(p.cvv())) != 3:
        flag = False
    return flag


# Generated at 2022-06-21 16:21:16.751474
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    print(payment.credit_card_expiration_date())



# Generated at 2022-06-21 16:21:39.718234
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment('en')
    result = provider.credit_card_network()
    assert result in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:21:42.928210
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    import mimesis
    a = mimesis.Payment()
    b = a.credit_card_network()
    assert b in mimesis.data.CREDIT_CARD_NETWORKS
    

# Generated at 2022-06-21 16:21:44.389077
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS

# Generated at 2022-06-21 16:21:46.573122
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    my = p.cvv()
    assert (len(my) == 3) and (my.isdigit())


# Generated at 2022-06-21 16:21:51.118742
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment('en')
    ccn = payment.credit_card_network()
    assert ccn in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:21:53.279306
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment(seed=123)
    assert p.cvv() == '985'


# Generated at 2022-06-21 16:21:55.679946
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    for i in range(10):
        assert re.match(r"[\w.]+@[\w.]+", p.paypal())

# Generated at 2022-06-21 16:21:57.597692
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    Payment().credit_card_network()

# Generated at 2022-06-21 16:22:08.007059
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    Test the method credit_card_number of class Payment
    """
    obj = Payment()
    
    assert isinstance(obj.credit_card_number(),str), "Test 1.0: test failed" 
    assert isinstance(obj.credit_card_number(CardType.AMERICAN_EXPRESS),str), "Test 2.0: test failed" 
    assert isinstance(obj.credit_card_number(CardType.MASTER_CARD),str), "Test 3.0: test failed" 
    assert isinstance(obj.credit_card_number(CardType.VISA),str), "Test 4.0: test failed" 
    assert isinstance(obj.credit_card_number(CardType.VISA),str), "Test 5.0: test failed" 
    

# Generated at 2022-06-21 16:22:10.195429
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert payment.cid() is not None


# Generated at 2022-06-21 16:22:59.957488
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Execution of method under test
    result = Payment().cid()
    assert isinstance(result, int)
    assert result < 9999
    assert result >= 1000


# Generated at 2022-06-21 16:23:09.963596
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment('en', seed=42)
    result = payment.credit_card_number(card_type=CardType.VISA)
    # The result should be a string
    assert isinstance(result, str)
    data = result.split(' ')
    # The data should be a list
    assert isinstance(data, list)
    # The length of data should be 4
    assert len(data) == 4

    # The luhn_checksum should be True
    assert luhn_checksum(data[0] + data[1] + data[2] + data[3]) is True

    # All elements of data should be string
    for element in data:
        assert isinstance(element, str)

    # All elements of data should be only 4

# Generated at 2022-06-21 16:23:11.614275
# Unit test for method paypal of class Payment
def test_Payment_paypal():
  # Set up
  provider = Payment()

  # Test
  result = provider.paypal()

  # Verify
  assert isinstance(result, str)


# Generated at 2022-06-21 16:23:15.302800
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    for _ in range(100):
        try:
            p.credit_card_number()
        except Exception as e:
            print(e)
            assert False



# Generated at 2022-06-21 16:23:18.449152
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    a = p.paypal()
    assert isinstance(a, str)
    assert a.find('@')
    assert a.find('.')