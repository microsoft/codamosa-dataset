

# Generated at 2022-06-21 16:20:39.679318
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert (payment.cid() >= 1000 and payment.cid() <= 9999)


# Generated at 2022-06-21 16:20:48.064653
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment(locale = 'en')
    print('Test method Credit Card Network: ', payment.credit_card_network())
    print('Test method Credit Card Number: ', payment.credit_card_number())
    print('Test method Credit Card Expiration Date: ', payment.credit_card_expiration_date())
    print('Test method Credit Card Owner: ', payment.credit_card_owner())
    print('Test method CVV: ', payment.cvv())
    print('Test method Paypal: ', payment.paypal())
    print('Test method CID: ', payment.cid())


if __name__ == '__main__':
    test_Payment()

# Generated at 2022-06-21 16:20:51.868695
# Unit test for method cid of class Payment
def test_Payment_cid():
    print("Testing cid of class Payment")
    print("-"*50)
    print("Test case 1: return type of function cid() is int")
    is_int = isinstance(Payment.cid(), int)
    assert is_int == True


# Generated at 2022-06-21 16:20:57.676972
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # create an instance of class Payment
    payment = Payment()
    # call method ethereum_address of class Payment
    a = payment.ethereum_address()
    # check if the string a start with 0xe
    result = a.startswith('0xe')
    # check if the length of a is 42
    result = result & (len(a) == 42)
    return result


# Generated at 2022-06-21 16:21:00.764442
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment(seed=4)
    assert payment.ethereum_address() == '0x5f5ce5c48779c9a0a67a8b0f102dc21eab1bd308'


# Lab 3

# Testing the method cid of class Payment

# Generated at 2022-06-21 16:21:09.034750
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p.cid()
    assert p.paypal()
    assert p.bitcoin_address()
    assert p.ethereum_address()
    credit_card_network = 'VISA'
    assert credit_card_network in CREDIT_CARD_NETWORKS
    assert p.credit_card_network() in CREDIT_CARD_NETWORKS
    assert p.credit_card_number()
    assert p.credit_card_expiration_date()
    assert p.cvv()
    assert isinstance(p.credit_card_owner(), dict)

# Generated at 2022-06-21 16:21:11.538470
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    cc_network = Payment()
    cc_network.seed(0)
    card_network = cc_network.credit_card_network()

    assert card_network == 'American Express'
    

# Generated at 2022-06-21 16:21:19.753964
# Unit test for constructor of class Payment
def test_Payment():
    # Instance object of class Payment
    payment = Payment(seed=123456)

    # Test output
    assert payment.cid() == 2275
    assert payment.paypal() == "bradley58@outlook.com"
    assert payment.bitcoin_address() == "3D7VZjiQ8zgRVvjtHppmctVrFE2gWdkRDA"
    assert payment.ethereum_address() == "0x49bd92f88b77c34b6977a6d0c6d9e1e9a6ab70dc"
    assert payment.credit_card_network() == "American Express"
    assert payment.credit_card_number() == "3190 1366 7834 238"

# Generated at 2022-06-21 16:21:26.988054
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Test method credit_card_owner of class Payment."""
    payment = Payment()
    owner = payment.credit_card_owner()
    assert len(owner) == 3
    assert type(owner) == dict
    assert type(owner['credit_card']) == str
    assert len(owner['credit_card'].split(' ')) == 4
    assert type(owner['expiration_date']) == str
    assert type(owner['owner']) == str
    assert len(owner['owner'].split(' ')) == 2


# Generated at 2022-06-21 16:21:30.609663
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    bitcoin_address = payment.bitcoin_address()
    assert len(bitcoin_address) == 34 and bitcoin_address[0] in ('1', '3') and bitcoin_address[1:]



# Generated at 2022-06-21 16:21:40.256436
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment
    assert ' ' in p.credit_card_owner()

# Generated at 2022-06-21 16:21:42.051096
# Unit test for method paypal of class Payment
def test_Payment_paypal():

    payment = Payment()
    paypal = payment.paypal()
    assert "@" in paypal


# Generated at 2022-06-21 16:21:44.489340
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    pay = Payment()
    ethereum_address = pay.ethereum_address()
    assert len(ethereum_address) == 42
    assert (ethereum_address[0:2] == '0x')

# Generated at 2022-06-21 16:21:50.143201
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis.providers.payment import Payment
    p = Payment()
    address = p.ethereum_address()
    assert isinstance(address, str)
    assert address[0:2] == '0x'
    assert len(address) == 42



# Generated at 2022-06-21 16:21:53.054647
# Unit test for method cid of class Payment
def test_Payment_cid():
    pay = Payment()
    cid = pay.cid()
    assert re.search('\d{1,4}', str(cid)) is not None


# Generated at 2022-06-21 16:21:54.366269
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    assert len(payment.credit_card_owner()) == 3

# Generated at 2022-06-21 16:22:01.852914
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p.cid() != None
    assert p.paypal() != None
    assert p.bitcoin_address() != None
    assert p.ethereum_address() != None
    assert p.credit_card_network() != None
    assert p.credit_card_number() != None
    assert p.credit_card_expiration_date() != None
    assert p.cvv() != None
    assert p.credit_card_owner() != None

# Generated at 2022-06-21 16:22:05.059942
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment"""
    payment = Payment(random.Random(), 'en')
    target = payment.ethereum_address()
    return target


# Generated at 2022-06-21 16:22:05.694698
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    paypal = Payment()
    print(paypal.paypal())


# Generated at 2022-06-21 16:22:07.440603
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    result = payment.credit_card_network()
    assert result in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:22:29.285942
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    expected_result = '4455 5299 1152 2450'
    actual_result = Payment().credit_card_number()
    assert actual_result == expected_result

# Generated at 2022-06-21 16:22:31.579787
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    print("running test_Payment_ethereum_address()")
    payment = Payment()
    for _ in range(5):
        print(payment.ethereum_address())


# Generated at 2022-06-21 16:22:34.574300
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    ether = payment.ethereum_address()
    assert isinstance(ether, str)
    assert len(ether) == 42


# Generated at 2022-06-21 16:22:37.941606
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment('en', seed=0)
    owner = p.credit_card_owner()
    assert owner['credit_card'] == '4334 4290 0043 0693'
    owner = p.credit_card_owner(gender=Gender.MALE)
    assert owner['owner'] == 'BRIAN ROWE'

# Generated at 2022-06-21 16:22:40.604532
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    test = Payment(seed=11)
    print(test.bitcoin_address())


# Generated at 2022-06-21 16:22:42.253211
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    py = Payment()
    value = py.credit_card_network()
    assert value in CREDIT_CARD_NETWORKS

# Generated at 2022-06-21 16:22:45.302718
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Unit test for method credit_card_expiration_date of class Payment."""
    obj = Payment()
    result = obj.credit_card_expiration_date()
    assert result is not None
    assert re.match(r"^\d+\/\d+$", result) is not None


# Generated at 2022-06-21 16:22:51.661894
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    payment = Payment()
    # we are testing three times to test the code with different credit card
    # types
    for card_test_num in range(3):
        credit_card_number = payment.credit_card_number(CardType(card_test_num))
        # Check that the credit card number is of 16 digits
        assert len(credit_card_number.replace(' ', '')) == 16
        # Check the credit card number is valid with luhn.
        numbers = ''
        for num in credit_card_number.split():
            numbers += num

        assert luhn_checksum(numbers) == ''

# Generated at 2022-06-21 16:22:52.269518
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    p.credit_card_owner()

# Generated at 2022-06-21 16:22:54.193417
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cvv = payment.cvv()
    assert isinstance(cvv, int)
    assert len(str(cvv)) == 3


# Generated at 2022-06-21 16:23:43.790461
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    paypal = payment.paypal()
    assert Regex(r'(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)').match(paypal)

# Generated at 2022-06-21 16:23:45.317192
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment(seed=123)
    assert p.cvv() == 526


# Generated at 2022-06-21 16:23:46.372149
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    print(payment.credit_card_network())


# Generated at 2022-06-21 16:23:47.276338
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    r = Payment()
    print(r.credit_card_network())


# Generated at 2022-06-21 16:23:52.767057
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Initialize the Payment class instance for test_Payment_ethereum_address
    payment = Payment()
    #Initialize flag for the test_Payment_ethereum_address
    flag = False
    #
    ethereum_address = payment.ethereum_address()
    # The length of ethereum_address should be 42
    if len(ethereum_address) != 42:
        flag = False
    # If the ethereum_address not start with '0x' then the flag should be False
    if ethereum_address[0:2] != '0x':
        flag = False
    # If the flag is always True after the above test,
    # then the test_Payment_ethereum_address is passed
    if not flag:
        raise ValueError

# Generated at 2022-06-21 16:23:55.078087
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    r = p.credit_card_expiration_date()
    assert isinstance(r, str)


# Generated at 2022-06-21 16:23:57.473447
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    s = set()
    for i in range(1000000):
        s.add(p.credit_card_number())
    assert len(s) == 1000000

# Generated at 2022-06-21 16:24:01.330778
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test_pattern = re.compile('[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}')
    assert test_pattern.match(Payment().credit_card_number()) is not None


# Generated at 2022-06-21 16:24:03.828897
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner(Gender.MALE)
    # print(owner)
    assert owner["owner"] == 'JAMES MURPHY'

# Generated at 2022-06-21 16:24:06.277477
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment(seed=123)
    result = payment.bitcoin_address()
    assert  result == '1HZwkjkeaoZfTSaJxDw6aKkxp45agDiEzN'



# Generated at 2022-06-21 16:25:41.225937
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cls = Payment()
    assert len(cls.credit_card_number()) == 16
    assert len(cls.credit_card_number(CardType.AMERICAN_EXPRESS)) == 15

# Generated at 2022-06-21 16:25:43.149035
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    print(Payment().cvv())



# Generated at 2022-06-21 16:25:44.518850
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    _payment = Payment()
    length = 34
    assert len(_payment.bitcoin_address()) == length


# Generated at 2022-06-21 16:25:46.708991
# Unit test for method cid of class Payment
def test_Payment_cid():
    _cid = Payment()
    _a = _cid.cid()
    assert isinstance(_a, int)
    assert len(str(_a)) == 4
    assert _a >= 1000
    assert _a <= 9999


# Generated at 2022-06-21 16:25:49.918418
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert len(card_number.split(" ")) == 4
    pattern = re.compile("^[0-9 ]+$")
    assert pattern.match(card_number) is not None
    assert luhn_checksum(card_number.replace(" ", ""))

# Generated at 2022-06-21 16:25:51.098673
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    res = p.credit_card_network()
    assert res in CREDIT_CARD_NETWORKS

# Generated at 2022-06-21 16:25:53.631338
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    assert isinstance(p.cid(), int)


# Generated at 2022-06-21 16:25:55.510052
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment('en', seed=6) # seed = 6, cvv = 324
    assert p.cvv() == 324

# Generated at 2022-06-21 16:25:59.444070
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    res = payment.paypal()
    x = re.match("\w+@\w+\.\w+", res)
    assert x is not None


# Generated at 2022-06-21 16:26:00.633560
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment(seed=0)
    assert p.credit_card_network() == "JCB"
