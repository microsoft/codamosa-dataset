

# Generated at 2022-06-21 16:20:48.036972
# Unit test for constructor of class Payment
def test_Payment():
    # Test Payment constructor
    payment = Payment(seed=0)

    # Test cid()
    result = payment.cid()
    assert result == '2291'

    # Test paypal()
    result = payment.paypal()
    assert result == 'josephbarnett@hotmail.com'

    # Test bitcoin_address()
    result = payment.bitcoin_address()
    assert result == '12VaknhSjMMWT2X9cGzA7VzhEB4ZpvP7Vq'

    # Test ethereum_address()
    result = payment.ethereum_address()
    assert result == '0xb7b231e00dceafba7f8fae1b9dd2b4cae4e7d4c4'

    # Test credit_card_network()
    result

# Generated at 2022-06-21 16:20:50.877528
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = get_random_item(CardType)
    print(card_type.value)

if __name__ == "__main__":
    test_Payment_credit_card_number()

# Generated at 2022-06-21 16:20:53.641760
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert payment.paypal() == 'wolf235@gmail.com'


# Generated at 2022-06-21 16:20:58.790411
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.builtins import Payment
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    p = Payment(BaseProvider(Person(Gender.FEMALE)))

    # Unit-test: credit_card_expiration_date
    assert len(p.credit_card_expiration_date()) == 5, "Credit card expire date is wrong"

# Generated at 2022-06-21 16:21:01.147611
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():

    from mimesis.enums import Gender
    p = Person('en')
    bitcoin_address = p.bitcoin_address()
    assert type(bitcoin_address) == str
    assert len(bitcoin_address) == 34

# Generated at 2022-06-21 16:21:02.175203
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    print(Payment().credit_card_network())



# Generated at 2022-06-21 16:21:02.913555
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    Payment().credit_card_owner()

# Generated at 2022-06-21 16:21:04.784981
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Create instance of class Payment
    payment = Payment()

    # Generate credit card owner
    owner = payment.credit_card_owner()

    # Asserts
    assert len(owner) == 3



# Generated at 2022-06-21 16:21:06.981486
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    '''
    Test class Payment
    '''
    payment = Payment()
    assert payment.ethereum_address() != None


if __name__ == '__main__':
    print(Payment().ethereum_address())
    print(Payment().bitcoin_address())

# Generated at 2022-06-21 16:21:10.649334
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # Create an instance of class Payment
    credit_card = Payment()
    # Invoke method credit_card_expiration_date
    expirationdate = credit_card.credit_card_expiration_date()
    # Check the format
    match = re.search(r'([\d]{2})/([\d]{2})', expirationdate)

    assert(match != None)
    assert(0 < int(match.group(1)) <= 12)

# Generated at 2022-06-21 16:21:25.613972
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Test for method credit_card_owner of class Payment"""
    payment = Payment()
    owner = payment.credit_card_owner()
    print("credit_card:", owner['credit_card'])
    print("expiration_date:", owner['expiration_date'])
    print("Owner:", owner['owner'])

# Generated at 2022-06-21 16:21:29.034972
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    credit_card_owner = payment.credit_card_owner(gender=Gender.FEMALE)
    assert credit_card_owner != None

# Generated at 2022-06-21 16:21:40.171272
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert isinstance(payment.paypal(), str)
    assert len(payment.bitcoin_address()) > 5
    assert isinstance(payment.credit_card_number(), str)
    assert isinstance(payment.credit_card_network(), str)
    assert isinstance(payment.cid(), int)
    assert isinstance(payment.cvv(), int)
    assert isinstance(payment.credit_card_owner(), dict)
    assert isinstance(payment.credit_card_expiration_date(), str)

#===============================================================================#
#     A unit test for class Payment                                             #
#===============================================================================#
if __name__ == '__main__':
    payment = Payment()
    print(payment.paypal())
    print(payment.bitcoin_address())
    print(payment.credit_card_number())


# Generated at 2022-06-21 16:21:42.011903
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert len(payment.ethereum_address()) == 42


# Generated at 2022-06-21 16:21:43.604935
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    print(payment.cid())



# Generated at 2022-06-21 16:21:45.159153
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    pm = Payment()
    cvv = pm.cvv()
    print("cvv = " + str(cvv))

# Generated at 2022-06-21 16:21:52.410693
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    for _ in range(10):
       addr = Payment().ethereum_address()
       assert 0 == int(addr[:2], base=16)
       assert 255 == int(addr[-2:], base=16)
       assert (len(addr) - 2) * 4 == int(addr[2:-2], base=2).bit_length()


# Generated at 2022-06-21 16:21:55.387804
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cc_cvv = payment.cvv()
    assert cc_cvv >= 100 and cc_cvv <= 999
    assert isinstance(cc_cvv, int)


# Generated at 2022-06-21 16:21:58.642980
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p1 = Payment(seed=1234)
    assert p1.credit_card_network() == 'Diners Club'


# Generated at 2022-06-21 16:22:02.267292
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Unit test for method credit_card_network of class Payment."""
    payment = Payment()
    p = payment.credit_card_network()


# Generated at 2022-06-21 16:22:28.658041
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cvv = payment.cvv()
    assert(cvv > 99 and cvv <= 999)


# Generated at 2022-06-21 16:22:30.431195
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    for _ in range(10):
        assert(payment.cid() in range(1000, 9999))


# Generated at 2022-06-21 16:22:31.221520
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    print(payment.cvv())

# Generated at 2022-06-21 16:22:35.141232
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """
    It is a testing method
    :return: True if test passed, False otherwise
    """
    payment_ = Payment()
    bitcoin = payment_.bitcoin_address()[0]
    return bitcoin == '1' or bitcoin == '3'


# Generated at 2022-06-21 16:22:43.150140
# Unit test for constructor of class Payment
def test_Payment():
    from mimesis.enums import CardType, Gender
    a = Payment()

    # test cid()
    for _ in range(4):
        assert a.cid() >= 1000
        assert a.cid() <= 9999

    # test paypal()
    assert re.match(r'^[a-z0-9]+([\._-][a-z0-9]+)*@[a-z0-9]+([._-][a-z0-9]+)+$',
                    a.paypal())

    # test bitcoin_address()
    assert re.match(r'^[13][a-km-zA-HJ-NP-Z0-9]{33}$',
                    a.bitcoin_address())

    # test ethereum_address()

# Generated at 2022-06-21 16:22:44.870023
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert (p)


# Generated at 2022-06-21 16:22:52.011376
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Create object of class Payment
    Payment_1 = Payment()
    # Get credit card owner
    owner = Payment_1.credit_card_owner()
    # Check the correctness of returned result
    if owner.get('credit_card') is not None and type(owner.get('credit_card')) is str and len(owner.get('credit_card')) > 0 and owner.get('expiration_date') is not None and type(owner.get('expiration_date')) is str and len(owner.get('expiration_date')) > 0 and owner.get('owner') is not None and type(owner.get('owner')) is str and len(owner.get('owner')) > 0:
        print("Test for method credit_card_owner of class Payment - OK")

# Generated at 2022-06-21 16:22:52.478685
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()

# Generated at 2022-06-21 16:22:53.821020
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert isinstance(payment.credit_card_expiration_date(), str)

# Generated at 2022-06-21 16:22:54.496279
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())

# Generated at 2022-06-21 16:23:55.596262
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    s = p.credit_card_expiration_date()
    assert isinstance(s, str) and len(re.findall('/',s)) == 1 and len(re.findall('/',s)) >= 3


# Generated at 2022-06-21 16:23:58.716462
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    cid = p.cid()
    assert isinstance(cid, int)
    assert len(str(cid)) == 4
    return cid


# Generated at 2022-06-21 16:24:01.102088
# Unit test for constructor of class Payment
def test_Payment():
    instance = Payment()
    assert isinstance(instance, Payment)
    assert isinstance(instance.__person, Person)
