

# Generated at 2022-06-21 16:20:37.653633
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner()
    assert type(owner) == dict
    assert isinstance(owner.get('credit_card'), str)
    assert isinstance(owner.get('expiration_date'), str)
    assert isinstance(owner.get('owner'), str)



# Generated at 2022-06-21 16:20:39.723589
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert isinstance(payment.ethereum_address(), str)


# Generated at 2022-06-21 16:20:40.855638
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()

    assert len(str(payment.cid())) == 4


# Generated at 2022-06-21 16:20:44.229814
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # t = Payment()
    # assert len(t.bitcoin_address()) == 35
    assert 1 == 1


# Generated at 2022-06-21 16:20:45.950176
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    print(payment.credit_card_expiration_date())


# Generated at 2022-06-21 16:20:53.930300
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()

    assert p.cid() is not None 
    assert p.paypal() is not None 
    assert p.bitcoin_address() is not None 
    assert p.credit_card_network() is not None 
    assert p.credit_card_number(CardType.VISA)  is not None 
    assert p.credit_card_expiration_date()  is not None 
    assert p.cvv() is not None 
    assert p.credit_card_owner(Gender.FEMALE) is not None

# Generated at 2022-06-21 16:21:02.275899
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment(seed=0)
    # Visa
    assert payment.credit_card_number(CardType.VISA) == "4442 8464 5578 1355"
    # MasterCard
    assert payment.credit_card_number(CardType.MASTER_CARD) == "5322 2330 9279 5186"
    # American Express
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == "3731 829995 17755"
    # UnionPay
    assert payment.credit_card_number(CardType.UNIONPAY) == "6215 3123 8254 2205"
    # Discover
    assert payment.credit_card_number(CardType.DISCOVER) == "6011 1816 0971 8472"


# Generated at 2022-06-21 16:21:03.537780
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert (Payment().cid() >= 1000) and (Payment().cid() <= 9999)


# Generated at 2022-06-21 16:21:05.558385
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.VISA
    payment = Payment()
    credit_card_number = payment.credit_card_number(card_type)
    print(credit_card_number)
    #must return first number = 4

# Generated at 2022-06-21 16:21:09.224199
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    for loop in range(0,10):
        x = Payment().ethereum_address()
        if len(x) != 42:
            print("ERROR! \n")
            break
        else:
            print(x)


# Generated at 2022-06-21 16:21:24.528818
# Unit test for method cid of class Payment
def test_Payment_cid():
    seed = 7
    test_CID = Payment(seed=seed)
    assert test_CID.cid() == 7283  # Test case


# Generated at 2022-06-21 16:21:28.058774
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    x = Payment()
    for _ in range(10):
        paypal = x.paypal()
        assert re.match(r'\w+@\w+\.\w{2,3}$', paypal)

# Generated at 2022-06-21 16:21:35.410932
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # 0xe8ece9e6ff7dba52d4c07d37418036a89af9698d
    assert Payment().ethereum_address() == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'
    return "Unit test for method ethereum_address of class Payment is completed successfully"

if __name__ == '__main__':
    print(test_Payment_ethereum_address())

# Generated at 2022-06-21 16:21:36.909773
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    test = Payment()
    print(test.credit_card_network())


# Generated at 2022-06-21 16:21:39.801160
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    print("\n", "Test method cid of class Payment", "\n")
    print("CID: ", p.cid())



# Generated at 2022-06-21 16:21:41.925334
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    p.credit_card_expiration_date(minimum = 12, maximum = 15)


# Generated at 2022-06-21 16:21:44.106179
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert Payment().credit_card_expiration_date() != None
    assert Payment().credit_card_expiration_date() != ""

# Generated at 2022-06-21 16:21:45.126131
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    print(payment.cvv())

# Generated at 2022-06-21 16:21:56.731942
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    from mimesis.enums import Gender
    from mimesis.enums import CardType

    payment = Payment('en')
    cvv = payment.cvv()
    owner = payment.credit_card_owner()
    number = payment.credit_card_number()
    expiration_date = payment.credit_card_expiration_date(minimum=17, maximum=24)
    credit_card_expiration_date = payment.credit_card_expiration_date()
    credit_card_network = payment.credit_card_network()
    bitcoin_address = payment.bitcoin_address()
    ethereum_address = payment.ethereum_address()
    paypal = payment.paypal()
    cid = payment.cid()

    assert cvv != None
    assert owner != None
    assert number != None
    assert expiration_date

# Generated at 2022-06-21 16:22:03.438338
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    print("#############")
    print("card = p.credit_card_network()")
    print("#############")
    card = p.credit_card_network()
    print("card : ", card)
    assert card in ['China UnionPay', 'AmericanExpress', 'MasterCard', 'Visa']
    print("\n")


# Generated at 2022-06-21 16:22:34.833797
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment_unit = Payment()
    print(payment_unit.bitcoin_address())


# Generated at 2022-06-21 16:22:37.912148
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    from mimesis.providers.payment import Payment
    from mimesis.exceptions import NonEnumerableError

    testObj = Payment(seed=4321)
    assert re.match(r".+@.+\..+", testObj.paypal()) is not None

# Generated at 2022-06-21 16:22:38.404511
# Unit test for constructor of class Payment
def test_Payment():
    print(Payment())

# Generated at 2022-06-21 16:22:41.636630
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit-test for method credit_card_number of class Payment"""
    p1 = Payment(seed=23423)
    # check if output is the same for the same seed
    assert(p1.credit_card_number() == '4455 5299 1152 2450')

# Generated at 2022-06-21 16:22:49.101129
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pay = Payment('en')
    c = pay.credit_card_number()
    type_of_card = c[0]
    if type_of_card == '4':
        # Visa
        assert c[1:5] == '4000'
        assert c[5:9] == '4999'
    elif type_of_card == '5':
        # Master Card
        assert c[1:5] == '2221' or c[1:5] == '5100'
        assert c[5:9] == '2720' or c[5:9] == '5599'
    elif type_of_card == '3':
        # American Express
        assert c[1:3] == '34' or c[1:3] == '37'
    assert len(c) == 16

# Generated at 2022-06-21 16:22:50.869425
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    i = 0
    while i < 10:
        payment = Payment()
        assert payment.paypal() == payment.paypal()
        i = i + 1


# Generated at 2022-06-21 16:22:53.078152
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    # Below is the values verified by another program
    assert payment.credit_card_network() in [
        "Visa", "Visa Electron", "MasterCard",
        "American Express", "Discover", "Diners Club",
        "JCB", "Maestro"
    ]


# Generated at 2022-06-21 16:22:54.127030
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    print(p.cid())


# Generated at 2022-06-21 16:23:03.675926
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    test=True
    payment = Payment()
    while(test):
        address = payment.bitcoin_address()
        if(address[0]=='1' or address[0]=='3'):
            for i in range(1,33):
                if(address[i]!=' '):
                    if(ord(address[i])<97 and ord(address[i])>57):
                        test=False
                    if(ord(address[i])<65 and ord(address[i])>57):
                        test=False
                    if(ord(address[i])<48 and ord(address[i])>=0):
                        test=False
                    if(ord(address[i])>122 and ord(address[i])<=127):
                        test=False
        else:
            test=False
        if(test):
            break

# Generated at 2022-06-21 16:23:06.575565
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    ether1 = Payment('en').ethereum_address()
    ether2 = Payment('en').ethereum_address()
    assert ether1 != ether2
