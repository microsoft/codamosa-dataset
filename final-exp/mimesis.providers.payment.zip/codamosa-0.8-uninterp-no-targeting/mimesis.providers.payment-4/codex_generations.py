

# Generated at 2022-06-21 16:20:39.396303
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    provider = Payment()
    print(provider.cvv())


# Generated at 2022-06-21 16:20:42.611712
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert (payment.cid() < 10000)
    assert (payment.cid() > 999)


# Generated at 2022-06-21 16:20:44.397350
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Create an instance of Payment
    payment = Payment()
    print(payment.paypal())


# Generated at 2022-06-21 16:20:45.793365
# Unit test for method cid of class Payment
def test_Payment_cid():
	payment = Payment()
	assert type(payment.cid()) == int


# Generated at 2022-06-21 16:20:47.546229
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment('en')
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:20:50.337012
# Unit test for method cid of class Payment
def test_Payment_cid():
    output = Payment().cid()
    assert type(output) == int
    assert 0 <= output <= 9999 # Check that output is between 0 and 9999


# Generated at 2022-06-21 16:20:55.440015
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    bitcoin = payment.bitcoin_address()
    # print(bitcoin)
    if len(bitcoin) == 34 and bitcoin[0] == '1' or bitcoin[0] == '3':
        print("success")
    else:
        print("fail")
test_Payment_bitcoin_address()

# Generated at 2022-06-21 16:20:59.069301
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    check = Payment(seed=1234)
    owner = check.credit_card_owner()
    assert owner['credit_card'] == '4072 8227 0075 5046'
    assert owner['expiration_date'] == '07/25'
    assert owner['owner'] == 'KELLEY TAYLOR'

# Generated at 2022-06-21 16:21:01.077295
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    credit_card_expiration_date = payment.credit_card_expiration_date()
    print(credit_card_expiration_date)


# Generated at 2022-06-21 16:21:02.380545
# Unit test for method cid of class Payment
def test_Payment_cid():
	cid = Payment().cid()
	assert len(str(cid)) == 4


# Generated at 2022-06-21 16:21:20.052811
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    test_payment = Payment('en')
    email = test_payment.paypal()
    assert re.match('(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)', email) is not None



# Generated at 2022-06-21 16:21:24.999603
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment(seed=0)
    credit_card_owner = payment.credit_card_owner()
    assert credit_card_owner['owner'] == "JULIA STEVENSON"
    assert credit_card_owner['credit_card'] == "4936 7786 4544 0654"
    assert credit_card_owner['expiration_date'] == "11/24"

# Generated at 2022-06-21 16:21:29.034368
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    global paypal
    paypal = Payment()
    print("The email of PayPal is: " + paypal.paypal())
    assert type(paypal.paypal()) == str


# Generated at 2022-06-21 16:21:40.173394
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    card = payment.credit_card_owner()
    assert payment.credit_card_number() != None
    assert payment.credit_card_expiration_date() != None
    assert payment.credit_card_owner() != None
    assert payment.credit_card_network() != None
    assert payment.credit_card_number() != None
    assert payment.bitcoin_address() != None
    assert payment.ethereum_address() != None
    assert isinstance(payment.cid(), int)
    assert isinstance(payment.cvv(), int)
    assert isinstance(payment.paypal(), str)
    assert isinstance(payment.credit_card_number(), str)
    assert isinstance(payment.credit_card_expiration_date(), str)
    assert isinstance(payment.credit_card_network(), str)

# Generated at 2022-06-21 16:21:43.339053
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Test method 'cid' of class Payment
    Check if the length is 4 digits
    """
    p=Payment()
    assert len(str(p.cid()))==4


# Generated at 2022-06-21 16:21:54.918148
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment(seed = 1)
    cid = payment.cid()
    assert cid == 5947
    paypal = payment.paypal()
    assert paypal == 'jerry_doe@hotmail.com'
    bitcoin_address = payment.bitcoin_address()
    assert bitcoin_address == '1BmPTzdV6UwGQgtZT6fLq6jPV7JfYXePV7'
    ethereum_address = payment.ethereum_address()
    assert ethereum_address == '0xf914ba5b5d5d8cadf5c4bed5e4ad4d4e'
    credit_card_network = payment.credit_card_network()
    assert credit_card_network == 'MasterCard'
    card_type = CardType.MAS

# Generated at 2022-06-21 16:21:57.837341
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    Payment = Payment(seed=12345)
    Payment.credit_card_owner(gender='MALE')
    assert(Payment.credit_card_owner(gender='MALE') == {'credit_card': '4446 2649 9838 9866',
        'expiration_date': '07/20', 'owner': 'JOHN SMITH'})

# Generated at 2022-06-21 16:22:02.886127
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment('en')
    bitcoin_address = payment.bitcoin_address()
    assert all(c in string.ascii_letters + string.digits for c in bitcoin_address)
    assert bitcoin_address[0] in '13'
    assert len(bitcoin_address) == 34

# Generated at 2022-06-21 16:22:04.460225
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment("en")
    print(p.credit_card_network())

# Generated at 2022-06-21 16:22:08.182356
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(100):
        payment = Payment(seed = i)
        payment.random.choice = lambda a:0
        card = payment.credit_card_number()
        if int(card[:8]) / 1000 % 10 >= 5 or card[-3:-1] in {'34', '37'}:
            break
    assert card == '4455 5299 1152 2450'

# Generated at 2022-06-21 16:22:38.767267
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment(seed=1)
    assert p.cid() == 2999


# Generated at 2022-06-21 16:22:42.516194
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    #Arrange
    seed = 1
    expected = "0x0f891afb1ce0abdf9a94493a70557d86accf4a40"
    #Act
    payment1 = Payment(seed=seed)
    actual = payment1.ethereum_address()
    #Assert
    assert(actual == expected)

# Generated at 2022-06-21 16:22:49.991178
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()

# Generated at 2022-06-21 16:22:51.210043
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    Payment.cvv()
    for i in range(10):
        assert type(Payment.cvv()) == int

# Generated at 2022-06-21 16:22:51.896456
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    P = Payment()
    print(P.cvv())

# Generated at 2022-06-21 16:22:56.824620
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    from mimesis.builtins import payment
    assert len(payment.Payment().bitcoin_address()) == 34
    assert len(payment.Payment().bitcoin_address().split('1')[1]) == 31
    assert len(payment.Payment().bitcoin_address().split('3')[1]) == 31
    assert payment.Payment().bitcoin_address().split('1')[0] == '1'
    assert payment.Payment().bitcoin_address().split('3')[0] == '3'



# Generated at 2022-06-21 16:23:05.508911
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test method credit_card_number of class Payment."""
    th = Payment(seed=1)

    # Test with None
    cc_number = th.credit_card_number(card_type=None)

    # Test with Visa
    cc_number = th.credit_card_number(card_type=CardType.VISA)

    # Test with MasterCard
    cc_number = th.credit_card_number(card_type=CardType.MASTER_CARD)

    # Test with AmericanExpress
    cc_number = th.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-21 16:23:06.397818
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment(seed=47)
    assert payment.cvv() == 592


# Generated at 2022-06-21 16:23:09.037950
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment(seed=seed)
    assert p.bitcoin_address() == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'


# Generated at 2022-06-21 16:23:10.953585
# Unit test for constructor of class Payment
def test_Payment():
    obj = Payment()
    print(obj.credit_card_expiration_date())