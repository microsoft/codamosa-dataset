

# Generated at 2022-06-21 16:20:34.868956
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert type(payment.cvv()) is int
    print(payment.cvv())


# Generated at 2022-06-21 16:20:40.778694
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    result = Payment().credit_card_owner()
    assert result == {
        'credit_card': '4455 5299 1152 2450',
        'expiration_date': '03/19',
        'owner': 'CURTIS DOUGLAS'
    }

    result = Payment().credit_card_owner(gender=Gender.MALE)
    assert result == {
        'credit_card': '4455 5299 1152 2450',
        'expiration_date': '03/20',
        'owner': 'DAVID CHAMBERS'
    }

# Generated at 2022-06-21 16:20:43.804273
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """Unit test for method paypal of class Payment"""
    assert Payment().paypal() != None


# Generated at 2022-06-21 16:20:45.543803
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert re.match(r'^\d{34}$', Payment().bitcoin_address()) is not None


# Generated at 2022-06-21 16:20:48.755465
# Unit test for method paypal of class Payment
def test_Payment_paypal():
  payObj = Payment()
  payObj.seed(1)
  assert payObj.paypal() == "jeannineblankenship@gmail.com"
  assert type(payObj.paypal()) == type("")


# Generated at 2022-06-21 16:20:53.747045
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Generated 10 random addresses
    for x in range(10):
        address = Payment().ethereum_address()
        # Check if there is an address that starts with 0x
        assert '0x' in address
        # Check if there is an address that has 40 characters
        assert len(address) == 42

# Generated at 2022-06-21 16:20:54.636350
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    b = Payment()
    result = b.bitcoin_address()
    print(result)
    assert len(result[1:]) == 33


# Generated at 2022-06-21 16:20:59.071147
# Unit test for constructor of class Payment
def test_Payment():
    pm = Payment()
    pm.cid()
    pm.paypal()
    pm.bitcoin_address()
    pm.ethereum_address()
    pm.credit_card_network()
    pm.credit_card_number()
    pm.credit_card_expiration_date()
    pm.cvv()
    pm.credit_card_owner()

# Generated at 2022-06-21 16:21:00.907230
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    owner = Payment().credit_card_owner()
    assert 'credit_card' in owner
    assert 'expiration_date' in owner
    assert 'owner' in owner

# Generated at 2022-06-21 16:21:03.259543
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for Payment.ethereum_address"""
    payment = Payment()
    assert payment.ethereum_address() == '0x1e29e026b01c31fca9ed194f7c1cb93a607c7b16'

# Generated at 2022-06-21 16:21:20.423093
# Unit test for constructor of class Payment
def test_Payment():
    # Class object
    payment = Payment()
    # Check value data
    assert isinstance(payment.cid(), int)
    assert isinstance(payment.paypal(), str)
    assert isinstance(payment.bitcoin_address(), str)
    assert isinstance(payment.ethereum_address(), str)
    assert isinstance(payment.credit_card_network(), str)
    assert isinstance(payment.credit_card_number(), str)
    assert isinstance(payment.credit_card_expiration_date(), str)
    assert isinstance(payment.cvv(), int)
    assert isinstance(payment.credit_card_owner(), dict)

# Generated at 2022-06-21 16:21:23.542193
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    print("test_Payment_credit_card_network")
    assert Payment().credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:21:25.659242
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cid = payment.cid()
    assert isinstance(cid, int)


# Generated at 2022-06-21 16:21:37.265601
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner(): #TODO Change name
    from mimesis.data import CREDIT_CARD_NETWORKS
    from mimesis.providers.payment import Payment
    from mimesis.enums import CardType
    from mimesis.enums import Gender

    payment = Payment()
    payment.random.shuffle(CREDIT_CARD_NETWORKS)
    network = payment.credit_card_network()
    card_type = CardType.get_inverse_value(network)
    owner = payment.credit_card_owner()

    # Asserts card type and expiration date
    assert owner['credit_card'].startswith(str(card_type))
    assert len(owner['expiration_date'].split('/')) == 2

    # Asserts credit card number

# Generated at 2022-06-21 16:21:46.267469
# Unit test for constructor of class Payment
def test_Payment():
    obj = Payment()
    # check if the version is defined and is a string
    assert obj.__version__ is not None and isinstance(obj.__version__, str)
    # check if __name__ is defined and is a string
    assert obj.__name__ is not None and isinstance(obj.__name__, str)
    # check if __author__ is defined and is a string
    assert obj.__author__ is not None and isinstance(obj.__author__, str)
    # check if __license__ is defined and is a string
    assert obj.__license__ is not None and isinstance(obj.__license__, str)
    # check if __copyright__ is defined and is a string
    assert obj.__copyright__ is not None and isinstance(obj.__copyright__, str)
    # check if __email

# Generated at 2022-06-21 16:21:50.440082
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    credit_card_number = Payment().credit_card_number()
    assert len(credit_card_number) == 19


# Generated at 2022-06-21 16:21:55.237427
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from pprint import pprint
    from mimesis.enums import CardType

    p = Payment()
    pprint(p.ethereum_address())

    for i in range(10):
        print(p.ethereum_address())


if __name__ == '__main__':
    test_Payment_ethereum_address()

# Generated at 2022-06-21 16:22:05.098413
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    ccn = Payment()
    types = [CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]
    for i in range(0, 10):
        for type_ in types:
            ccn_ = ccn.credit_card_number(type_)
            print(type_)
            print(ccn_)
            assert(len(ccn_) == 19 or len(ccn_) == 17)
            assert(ccn_[0] == ccn.credit_card_network()[0])

test_Payment_credit_card_number()

# Generated at 2022-06-21 16:22:06.836804
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    a = Payment(random=False)  # Init Payment
    assert a.credit_card_network() == 'Visa' #Test value


# Generated at 2022-06-21 16:22:11.231906
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Unit test for method cid of class Payment."""
    payment = Payment()
    assert 1000 <= payment.cid() <= 9999


# Generated at 2022-06-21 16:22:37.273427
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment('en')
    address = payment.bitcoin_address()
    assert len(address) == 34
    assert address[0] == '1' or address[0] == '3'



# Generated at 2022-06-21 16:22:41.064190
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment(seed=1234)
    assert payment.paypal() == 'hebert.felicia@vk.com'
    assert payment.paypal() == 'jovan.cruickshank@microsoft.com'
    assert payment.paypal() == 'winter.leuschke@paypal.com'


# Generated at 2022-06-21 16:22:44.028283
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_test = Payment()
    result = payment_test.credit_card_number()
    assert (len(result) == 19)
    assert (int(result[0]) == 4)
    assert (int(result[1]) > 3)

# Unittest for method credit_card_owner of class Payment

# Generated at 2022-06-21 16:22:46.027365
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()

    card_network = payment.credit_card_network()
    assert (card_network in CREDIT_CARD_NETWORKS)


# Generated at 2022-06-21 16:22:47.364615
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    cvv = p.cvv()
    len(str(cvv)) == 3
    print(cvv)

# Generated at 2022-06-21 16:22:50.619875
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()

    bitcoin_address = payment.bitcoin_address()

    assert re.match(r"^(?:[13][a-km-zA-HJ-NP-Z1-9]{25,34}|bc1[a-zA-HJ-NP-Z0-9]{11,71})$",bitcoin_address)


# Generated at 2022-06-21 16:22:53.080957
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    x=Payment(seed=10)
    s=x.credit_card_number()
    print(s)
    if (s=="5354 9446 8406 5202"):
        print('test for credit_card_number is passed!')
    else:
        print('test for credit_card_number is failed!')

# Generated at 2022-06-21 16:22:54.555266
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Unit test for method bitcoin_address of class Payment."""
    payment = Payment()
    assert re.match(r'^(1|3)[a-zA-Z0-9]{33}$', payment.bitcoin_address())


# Generated at 2022-06-21 16:22:55.490684
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment(seed = 0)
    payment.cid()

    assert payment.cid() == 4331


# Generated at 2022-06-21 16:22:56.252469
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    method = Payment().bitcoin_address()
    print(method)
    print('\n')


# Generated at 2022-06-21 16:23:51.188686
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    seed = 1
    ans = '0x9081f5fdfc60be1a0ce56c70f8d5c5ef758f5c5d'
    assert Payment(seed).ethereum_address() == ans


# Generated at 2022-06-21 16:23:55.780171
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():

    from mimesis.enums import Gender

    seed = 0
    p = Payment(seed=seed)

    gender = Gender.MALE

    owner = p.credit_card_owner(gender=gender)

    assert owner['credit_card'] == '4077 9753 5382 8529'
    assert owner['expiration_date'] == '04/21'
    assert owner['owner'] == 'JONATHAN WOOD'

# Generated at 2022-06-21 16:23:57.337124
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    _p = Payment()
    _p.credit_card_number()

# Generated at 2022-06-21 16:24:00.588531
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    bitcoin = payment.bitcoin_address()
    regex = re.compile(r'^[13][A-Za-z0-9]{33}$')
    assert regex.search(bitcoin) is not None

# Generated at 2022-06-21 16:24:04.372666
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # GIVEN a Payment instance
    subject = Payment()

    # WHEN paypal is called on the instance
    result = subject.paypal()

    # THEN it should return a email format string.
    assert isinstance(result, str) and result.count('@') == 1 and result.count('.') >= 1


# Generated at 2022-06-21 16:24:07.886850
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    h = Payment(seed=123)
    print (h.credit_card_number(CardType.MASTER_CARD))
    print (h.credit_card_number(CardType.VISA))
    print (h.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-21 16:24:09.739491
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    my_payment = Payment()
    assert (100 <= my_payment.cvv() <= 999) or my_payment.cvv() in [100, 999]


# Generated at 2022-06-21 16:24:18.390009
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.providers import Payment
    import re
    payment = Payment()
    for _ in range(100):
        card_number = payment.credit_card_number(CardType.VISA)
        if not re.match(r'^\d{4} \d{4} \d{4} \d{4}$', card_number):
            print('Visa:', card_number)
        card_number = payment.credit_card_number(CardType.MASTER_CARD)
        if not re.match(r'^\d{4} \d{4} \d{4} \d{4}$', card_number):
            print('MasterCard:', card_number)

# Generated at 2022-06-21 16:24:21.061450
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    print('Testing method credit_card_network of class Payment')
    payment = Payment()
    for _ in range(0, 50):
        print('Testing output of method credit_card_network')
        credit_card_network = payment.credit_card_network()
        print(credit_card_network)
        print()


# Generated at 2022-06-21 16:24:25.541061
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment(seed=2019)
    print("Payment.credit_card_expiration_date() is " + payment.credit_card_expiration_date())

if __name__ == '__main__':
    test_Payment_credit_card_expiration_date()

# Generated at 2022-06-21 16:26:09.135753
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert 4 > len(str(Payment().cid())) >= 3


# Generated at 2022-06-21 16:26:13.534333
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    is_valid_email = re.compile(r'(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)')
    assert is_valid_email.match(Payment().paypal()) is not None


# Generated at 2022-06-21 16:26:15.463582
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Test method credit_card_network of class Payment."""
    payment = Payment()
    network = payment.credit_card_network()
    assert isinstance(network, str)
    assert network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:26:18.509733
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    month = payment.random.randint(1, 12)
    year = payment.random.randint(16, 25)
    assert payment.credit_card_expiration_date() == '{0:02d}/{1}'.format(month, year)


# Generated at 2022-06-21 16:26:20.264783
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    assert p.credit_card_expiration_date(0, 0) == "01/00"


# Generated at 2022-06-21 16:26:21.082534
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    x = payment.cvv()
    assert x > 99 and x < 1000


# Generated at 2022-06-21 16:26:24.156598
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner()
    assert isinstance(owner, dict)
    assert set(['credit_card', 'expiration_date', 'owner']).issubset(set(owner))
    assert isinstance(owner['credit_card'], str)
    assert isinstance(owner['expiration_date'], str)
    assert isinstance(owner['owner'], str)

# Generated at 2022-06-21 16:26:25.967552
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    random_num = Payment().cvv()
    assert isinstance(random_num, int)
    assert random_num in range(101, 1000)


# Generated at 2022-06-21 16:26:32.715311
# Unit test for constructor of class Payment
def test_Payment():
    # Create an instance of Payment class
    c = Payment()
    # Check whether the value is equal to "en_en"
    assert c.credit_card_network() == 'Visa'
    # Check whether the value is equal to "#Payment"
    assert c.Meta.name == 'payment'
    # Check whether the value is equal to 4455 5299 1152 2450
    assert c.credit_card_number() == '4455 5299 1152 2450'
    # Check whether the value is equal to 03/19
    assert c.credit_card_expiration_date() == '03/19'
    # Check whether the value is equal to 324
    assert c.cvv() == 324


# Generated at 2022-06-21 16:26:37.617521
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    print(Payment.ethereum_address(Payment)) 
    print(Payment.ethereum_address(Payment)) 
    print(Payment.ethereum_address(Payment)) 
    print(Payment.ethereum_address(Payment)) 
    print(Payment.ethereum_address(Payment)) 
    print(Payment.ethereum_address(Payment)) 
    print(Payment.ethereum_address(Payment)) 


test_Payment_ethereum_address()

# Generated at 2022-06-21 16:29:51.364217
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # test for provider Payment
    p1 = Payment()
    for i in range(100):
        assert p1.paypal() is not None

    # test for provider Payment with custom seed
    p2 = Payment(seed=45)
    for i in range(100):
        assert p2.paypal() is not None


# Generated at 2022-06-21 16:29:53.057172
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pp = Payment()
    print(pp.paypal())
    # Output: wkim23@pusc.edu.sg


# Generated at 2022-06-21 16:29:54.814296
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
	# Arrange
	payment = Payment(random=Random())

	# Act
	result = payment.ethereum_address()

	# Assert
	assert len(result) == 42



# Generated at 2022-06-21 16:29:57.034279
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Test method credit_card_network of class Payment"""
    payment = Payment()
    assert type(payment.credit_card_network()) is str


# Generated at 2022-06-21 16:29:58.735975
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment('en')
    credit_card_network = payment.credit_card_network()
    assert credit_card_network in CREDIT_CARD_NETWORKS



# Generated at 2022-06-21 16:30:01.356670
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    pay = Payment('en')
    r = pay.ethereum_address()
    print(r)



# Generated at 2022-06-21 16:30:03.126661
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    for i in range(5):
        payment = Payment()
        assert payment.credit_card_network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:30:07.347471
# Unit test for constructor of class Payment
def test_Payment():
    allData = Payment(seed=0).credit_card_owner()
    assert allData == {
        'credit_card': '4455 5299 1152 2450',
        'expiration_date': '04/21',
        'owner': 'DOROTHY WASHINGTON',
    }

# Generated at 2022-06-21 16:30:08.321599
# Unit test for constructor of class Payment
def test_Payment():
  payment = Payment()
  assert payment is not None


# Generated at 2022-06-21 16:30:09.925033
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    x = payment.credit_card_expiration_date()
    print(x)