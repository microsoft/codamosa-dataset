

# Generated at 2022-06-21 16:20:42.605766
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    array1 = p.bitcoin_address()
    array2 = p.bitcoin_address()
    print(array1)
    print(array2)
    assert array1 != array2


# Generated at 2022-06-21 16:20:44.187809
# Unit test for method cid of class Payment
def test_Payment_cid():
    ins_Payment = Payment()
    result = ins_Payment.cid()
    print(result)



# Generated at 2022-06-21 16:20:45.911564
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    for i in range(10):
        print(payment.ethereum_address())

# Generated at 2022-06-21 16:20:47.916519
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment('en')
    assert payment.credit_card_expiration_date(minimum = 16, maximum = 25) == '03/19'


# Generated at 2022-06-21 16:20:49.613272
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():

    payment = Payment()
    address = payment.ethereum_address()
    assert isinstance(address, str)

# Generated at 2022-06-21 16:20:51.942448
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    obj = Payment()
    result = obj.credit_card_network()
    assert isinstance(result, str) == True


# Generated at 2022-06-21 16:20:55.674623
# Unit test for constructor of class Payment
def test_Payment():
    __test_Payment = Payment()
    assert __test_Payment.__class__.__name__ == 'Payment'
    assert type(__test_Payment.__doc__) == str


# Generated at 2022-06-21 16:20:57.586123
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:21:01.799878
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    test_data = [
        (16, 25, '03/19'),
        (16, 25, '05/21'),
        (16, 25, '10/20'),
        (16, 25, '09/18'),
    ]

    payment = Payment()
    for minimum, maximum, result in test_data:
        assert payment.credit_card_expiration_date(minimum, maximum) == result

# Generated at 2022-06-21 16:21:04.296563
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment("ru")
    payment.seed(1)
    assert payment.bitcoin_address() == "12oFDkN5b5RQ2zAjbV7eU6C9U6JYhYfbV7"


# Generated at 2022-06-21 16:21:21.689355
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # prepare dataset
    payment = Payment()
    # execute the code we are testing
    result = payment.credit_card_owner()
    # verify the result
    assert result == {'credit_card': '4048 7221 2379 8718',
                      'expiration_date': '09/21',
                      'owner': 'CECILIA BOWMAN'}

# Generated at 2022-06-21 16:21:23.139576
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert 0 <= payment.cid() < 10000


# Generated at 2022-06-21 16:21:24.211424
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert Payment().cvv() <= 999
    assert Payment().cvv() >= 100

# Generated at 2022-06-21 16:21:36.185225
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Instantiate a Payment object
    payment = Payment()

    # Generate credit card owner
    result = payment.credit_card_owner(gender=Gender.MALE)

    # Get owner as a string from result
    owner = result['owner']

    # Retrieve first name from owner
    first_name = owner.split(' ')[0]

    # Retrieve last name from owner
    last_name = owner.split(' ')[1]

    # Check if first name starts with a capital letter
    assert first_name[0].isupper()

    # Check if last name starts with a capital letter
    assert last_name[0].isupper()

    # Get credit card number as a string from result
    credit_card_number = result['credit_card']

    # Retrieve last number from credit card number
    last_number = credit_card_

# Generated at 2022-06-21 16:21:43.339282
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    # Check that the first 2 characters are 1 or 3
    assert payment.bitcoin_address()[0] in ['1', '3']
    # Check the length of 36
    assert len(payment.bitcoin_address()) == 36
    payment = Payment(seed=12345)
    # Check that the first 2 characters are 1 or 3
    assert payment.bitcoin_address()[0] in ['1', '3']
    # Check the length of 36
    assert len(payment.bitcoin_address()) == 36


# Generated at 2022-06-21 16:21:44.901155
# Unit test for method cid of class Payment
def test_Payment_cid():
    test = Payment()
    for i in range(0, 10):
        assert test.cid() <= 9999 and test.cid() >= 1000


# Generated at 2022-06-21 16:21:50.734393
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    a = Payment()
    print(a.credit_card_expiration_date())
    assert len(a.credit_card_expiration_date()) == 7

if __name__ == "__main__":
    test_Payment_credit_card_expiration_date()

# Generated at 2022-06-21 16:21:55.197093
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    random = Random()
    random.seed(1)
    payment = Payment(random)
    assert payment.ethereum_address() == '0x1e70f3f2b9d7c8e30a31f7e7a0d901f744cdb59b'


# Generated at 2022-06-21 16:21:59.922195
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_number = Payment().credit_card_number()

    assert re.match(r'^\d{4}\s\d{4}\s\d{4}\s\d{4}$', card_number)



# Generated at 2022-06-21 16:22:04.940315
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    from mimesis.random import Seed
    seed = Seed.create_seed(1234567890)
    payment = Payment('en', seed=seed)
    assert payment.bitcoin_address() == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'

# Generated at 2022-06-21 16:22:23.030850
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3728 423627 52325'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2277 9878 3796 5195'
    assert payment.credit_card_number(CardType.VISA) == '4013 3890 0665 4253'

# Generated at 2022-06-21 16:22:24.873226
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    pay = Payment()
    assert len(str(pay.cvv())) == 3



# Generated at 2022-06-21 16:22:26.566163
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert Payment().credit_card_expiration_date(16, 20) == '05/20'


# Generated at 2022-06-21 16:22:29.305102
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    result = payment.credit_card_owner()
    # print(result)
    assert result != ''

# Generated at 2022-06-21 16:22:30.619903
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis import Payment
    payment = Payment()
    assert payment.credit_card_network() != None


# Generated at 2022-06-21 16:22:37.943015
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Unit test for method credit_card_expiration_date of class Payment."""
    import datetime
    ccd = Payment(seed=0)
    assert ccd.credit_card_expiration_date() == '08/17'
    assert ccd.credit_card_expiration_date(minimum=10, maximum=20) == '05/12'
    now = datetime.datetime.now()
    month = str(now.month)
    year = str(now.year)[2:]
    assert ccd.credit_card_expiration_date(minimum=now.year, maximum=now.year) == month + '/' + year

# Generated at 2022-06-21 16:22:46.529724
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    for _ in range(10):
        card_type = get_random_item(CardType, rnd=payment.random)
        cc_number = payment.credit_card_number(card_type)
        assert len(cc_number) == 19
        if card_type == CardType.VISA:
            assert cc_number[:1] == '4'
        elif card_type == CardType.MASTER_CARD:
            assert cc_number[:2] == '22' or cc_number[:2] == '51'
        elif card_type == CardType.AMERICAN_EXPRESS:
            assert cc_number[:2] == '34' or cc_number[:2] == '37'

# Generated at 2022-06-21 16:22:48.562593
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    payment.cid()
    # 7452
    payment.cid()
    # 1759
    payment.cid()
    # 7351
    payment.cid()
    # 4579



# Generated at 2022-06-21 16:22:51.210963
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
  p = Payment()
  ethereum_address = p.ethereum_address()
  assert len(ethereum_address) == 42
  assert ethereum_address[0:2] == '0x'
  assert ethereum_address[2:].isalnum()


# Generated at 2022-06-21 16:22:52.181781
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    payment.credit_card_network()

# Generated at 2022-06-21 16:23:25.238926
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert len(Payment().bitcoin_address()) == 35


# Generated at 2022-06-21 16:23:30.135584
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    print(payment.credit_card_network())
    print(payment.credit_card_number(CardType.VISA))
    print(payment.credit_card_expiration_date())
    print(payment.cvv())
    print(payment.credit_card_owner(Gender.MALE))
    print(payment.bitcoin_address())
    print(payment.ethereum_address())


# Generated at 2022-06-21 16:23:39.301228
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()

    # Unit test for method paypal()
    def test_paypal():
        expected = 'daniel.ramirez@gmail.com'
        actual = payment.paypal()
        assert expected == actual

    # Unit test for method bitcoin_address()
    def test_bitcoin_address():
        expected = '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'
        actual = payment.bitcoin_address()
        assert expected == actual

    # Unit test for method ethereum_address()
    def test_ethereum_address():
        expected = '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'
        actual = payment.ethereum_address()
        assert expected == actual

   

# Generated at 2022-06-21 16:23:41.872072
# Unit test for method cid of class Payment
def test_Payment_cid():
    obj = Payment("en")
    assert 7452 == obj.cid() # True



# Generated at 2022-06-21 16:23:43.621502
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """test_Payment_cvv function"""
    pr = Payment()
    assert isinstance(pr.cvv(), int)



# Generated at 2022-06-21 16:23:46.463679
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment(seed=int.from_bytes(b'\x14\x00\x00\x00\x00\x00\x00\x00', byteorder='little'))
    assert provider.credit_card_number() == '3846 9793 5188 8241'

# Generated at 2022-06-21 16:23:48.597077
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # Test that bitcoin_address method generates a string that starts with 1 or 3
    obj1 = Payment()
    assert(obj1.bitcoin_address().startswith('1') or obj1.bitcoin_address().startswith('3'))


# Generated at 2022-06-21 16:23:49.517280
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    obj = Payment()
    print(obj.credit_card_network())

# Generated at 2022-06-21 16:23:51.189267
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    result = payment.paypal()
    assert isinstance(result, str)
    assert not result.isspace()
    print(result)



# Generated at 2022-06-21 16:23:53.886303
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    CardNetwork = Payment()
    cnn = CardNetwork.credit_card_network()
    assert cnn in ["Visa", "MasterCard", "American Express"]
