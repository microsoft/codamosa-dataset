

# Generated at 2022-06-21 16:20:39.441681
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    seed = 1
    payment = Payment(seed=seed)
    generator = payment.cvv()
    assert(generator == 324)


# Generated at 2022-06-21 16:20:41.885924
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    assert len(str(p.cvv())) == 3


# Generated at 2022-06-21 16:20:49.727447
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p.cid() >= 1000 and p.cid() <= 9999 and type(p.cid()) == int
    assert bool(re.match(r'^[A-Za-z0-9_]+@[A-Za-z0-9_]+.[A-Za-z0-9_]+$',
                         p.paypal())) == True and type(p.paypal()) == str
    assert bool(re.match(r'^[13][A-Za-z0-9_]{33}$',
                         p.bitcoin_address())) == True and type(p.bitcoin_address()) == str

# Generated at 2022-06-21 16:20:53.745981
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment('en')
    t = p.credit_card_owner()
    assert t['owner'] != '' and t['credit_card'] != '' and t['expiration_date'] != ''

# Generated at 2022-06-21 16:20:56.862930
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """This unit test is for ethereum_address method."""
    payment = Payment()
    assert re.match(
        r'0x[0-9a-f]{40}', payment.ethereum_address()
    )


# Generated at 2022-06-21 16:21:00.376814
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from collections import Counter
    from mimesis.enums import CardType

    payment = Payment()

    networks = [payment.credit_card_network() for _ in range(100)]
    counter = Counter(networks)

    for card_type in CardType:
        assert card_type.value in counter


# Generated at 2022-06-21 16:21:10.279099
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p.credit_card_expiration_date() == "03/23"
    assert p.credit_card_network() == "Visa"
    assert p.credit_card_owner().get("owner") == "MARCY PARKER"
    assert p.credit_card_number(CardType.MASTER_CARD) == "5100 7163 6684 2397"
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == "3400 873435 13800"
    assert p.credit_card_number(CardType.VISA) == "4556 1461 4193 5226"
    assert p.credit_card_number() == "4020 2614 6477 3690"
    assert p.paypal() == "cristiankennedy@hotmail.com"


# Generated at 2022-06-21 16:21:12.735857
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Unit test for Payment.credit_card_network."""
    payment_obj = Payment()
    assert payment_obj.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:21:15.544010
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Unit test for method credit_card_network of class Payment."""
    payment = Payment()
    assert 'Visa' in CREDIT_CARD_NETWORKS
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:21:16.290468
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    print(Payment().ethereum_address())

# Generated at 2022-06-21 16:21:36.611596
# Unit test for constructor of class Payment
def test_Payment():
    Payment()


# Generated at 2022-06-21 16:21:38.777371
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    assert Payment().credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:21:41.973283
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method Payment_ethereum_address."""
    p = Payment()
    address = p.ethereum_address()
    assert address[:2] == '0x'
    assert len(address) == 42

# Generated at 2022-06-21 16:21:45.663115
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment(seed=42)
    actual = payment.credit_card_owner()
    expected = {'credit_card': '4444 1725 2970 7587', 'expiration_date': '03/21', 'owner': 'JENNINGS ZACHARY'}
    print(actual)
    assert actual == expected, "Credit card owner is not working"

# Generated at 2022-06-21 16:21:49.958572
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment(seed=123)
    payment.random.choice = lambda x: x[0]
    assert payment.credit_card_network() == 'Visa'


# Generated at 2022-06-21 16:21:58.404960
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import CardType
    from mimesis.enums import Gender

    p = Payment(seed=14)

    # test_credit_card_network
    assert p.credit_card_network() == 'MasterCard'
    assert p.credit_card_network() == 'Visa'
    assert p.credit_card_network() == 'Visa'

    # test_credit_card_number
    assert p.credit_card_number() == '4455 5299 1152 2450'
    assert p.credit_card_number(CardType.MASTER_CARD) == '5274 8236 5156 7875'

    # test_credit_card_owner
    assert p.credit_card_owner(Gender.MALE).get('credit_card') == '4455 5299 1152 2450'

# Generated at 2022-06-21 16:22:07.401178
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis import Payment
    p = Payment()
    for i in range(4):
        card_type = CardType.VISA
        print (p.credit_card_number(card_type))
    for i in range(4):
        card_type = CardType.MASTER_CARD
        print (p.credit_card_number(card_type))
    for i in range(4):
        card_type = CardType.AMERICAN_EXPRESS
        print (p.credit_card_number(card_type))

if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-21 16:22:14.065450
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    p.credit_card_expiration_date()
    string_list = []
    for i in range(5):
        string_list.append(p.credit_card_expiration_date())
        assert isinstance(string_list[i], str)


# Generated at 2022-06-21 16:22:15.354932
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    print(payment.paypal())


# Generated at 2022-06-21 16:22:22.189778
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test method credit_card_number() of class Payment."""
    payment = Payment(seed=42)
    assert payment.credit_card_number(card_type="VISA") == "4908 0803 2177 6345"
    assert payment.credit_card_number(card_type="MASTER_CARD") == "5499 0357 3307 5145"
    assert payment.credit_card_number(card_type="AMERICAN_EXPRESS") == "3494 392051 54215"
    try:
        payment.credit_card_number(card_type="UNSUPPORTED")
        assert_unreachable()
    except NonEnumerableError:
        pass

# Generated at 2022-06-21 16:22:48.712139
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    # Return CID code
    payment.cid()
    # Return Email of PapPal user
    payment.paypal()
    # Return Bitcoin address
    payment.bitcoin_address()
    # Return Ethereum address
    payment.ethereum_address()
    # Return Credit card network
    payment.credit_card_network()
    # Return Credit card number
    payment.credit_card_number()
    # Return Expiration date of credit card
    payment.credit_card_expiration_date()
    # Return CVV code
    payment.cvv()
    # Return credit card owner
    payment.credit_card_owner()

# Generated at 2022-06-21 16:22:54.181312
# Unit test for constructor of class Payment

# Generated at 2022-06-21 16:22:55.162886
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # print(Payment().cvv())
    pass


# Generated at 2022-06-21 16:22:57.499050
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment('en')
    d = payment.credit_card_expiration_date(minimum=2, maximum=16)
    assert(len(d.split('/')) == 2)

# Generated at 2022-06-21 16:23:00.663168
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Unit test for credit card expiration date"""
    payment = Payment()
    card_expiration_date = payment.credit_card_expiration_date()
    assert card_expiration_date == "03/16"

# Generated at 2022-06-21 16:23:02.491166
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    for i in range(0,10):
        assert payment.credit_card_network() in CREDIT_CARD_NETWORKS

# Generated at 2022-06-21 16:23:07.411163
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment.__new__(Payment)
    payment.random.getrandbits = lambda _x: int('1'*78+'0'*82, 2)
    address = payment.ethereum_address()
    assert address == '0x' + '1'*40


# Generated at 2022-06-21 16:23:11.314098
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    payment.cid()
    payment.credit_card_expiration_date()
    payment.credit_card_network()
    payment.credit_card_number()
    payment.credit_card_owner()
    payment.cvv()
    payment.bitcoin_address()
    payment.ethereum_address()
    payment.paypal()

# Generated at 2022-06-21 16:23:12.824782
# Unit test for method cid of class Payment
def test_Payment_cid():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 16:23:17.832799
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Unit test for method cid of class Payment."""
    # init the object
    obj = Payment()
    # get a random value
    value = obj.cid()
    # check if the value is 10000 or more and 9999 or less
    assert value >= 1000 and value <= 9999


# Generated at 2022-06-21 16:24:13.730282
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment("en")
    assert payment.__class__.__name__ == 'Payment'
    assert payment.__class__.Meta.name == 'payment'
    assert payment.cid() >= 1000 and payment.cid() <= 9999
    assert payment.paypal() != None
    assert payment.bitcoin_address() != None
    assert payment.ethereum_address() != None
    assert payment.credit_card_network() != None
    assert payment.credit_card_number() != None
    assert payment.credit_card_expiration_date(16, 25) != None
    assert payment.cvv() >= 100 and payment.cvv() <= 999
    assert payment.credit_card_owner() != None


# Generated at 2022-06-21 16:24:14.893040
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    Payment().paypal()


# Generated at 2022-06-21 16:24:16.108133
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    for i in range(100):
        print(p.cvv())


# Generated at 2022-06-21 16:24:18.423892
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    obj = Payment()
    obj.random.seed(4)
    for i in range(0, 20):
        print(obj.credit_card_network())


# Generated at 2022-06-21 16:24:20.083457
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    paypal = Payment(seed=123)
    result = paypal.paypal()
    assert result == 'drew0@hotmail.com'


# Generated at 2022-06-21 16:24:24.499218
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert hasattr(payment, 'random')
    assert hasattr(payment, '__person')
    assert isinstance(payment.random, Random)
    assert isinstance(payment.__person, Person)


# Generated at 2022-06-21 16:24:30.923032
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import CardType
    payment = Payment()
    # Exp: Minimum: 16 and Maximum: 25
    for _ in range(100000):
        print(payment.credit_card_expiration_date(16, 25))

    # Exp: Minimum: 7 and Maximum: 8
    for _ in range(100000):
        print(payment.credit_card_expiration_date(7, 8))


# Generated at 2022-06-21 16:24:32.968108
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    assert (Payment.Meta.name) == "payment"


# Generated at 2022-06-21 16:24:39.663369
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print('credit_card_number(CardType.AMERICAN_EXPRESS):')
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))
    print('credit_card_number(CardType.MASTER_CARD):')
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print('credit_card_number(CardType.VISA):')
    print(payment.credit_card_number(CardType.VISA))


# Generated at 2022-06-21 16:24:42.515551
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    print(p.credit_card_expiration_date())
    p.seed(0)
    print(p.credit_card_expiration_date())
