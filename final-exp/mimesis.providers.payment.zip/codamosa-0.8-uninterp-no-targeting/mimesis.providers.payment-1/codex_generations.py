

# Generated at 2022-06-21 16:20:34.956840
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert len(Payment().cvv()) == 3

# Generated at 2022-06-21 16:20:38.370693
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    print(p.cvv())

# Generated at 2022-06-21 16:20:44.483163
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Initialize object Payment
    payment = Payment('en')
    for _ in range(10):
        assert payment.paypal() == "doug_67@example.com"
    # Change seed of Payment
    payment.seed(1)
    for _ in range(10):
        assert payment.paypal() == "oshaughnessy_cody@example.com"

# Generated at 2022-06-21 16:20:45.869866
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert isinstance(payment, Payment)

# Generated at 2022-06-21 16:20:47.884448
# Unit test for constructor of class Payment
def test_Payment():
    cid = Payment().credit_card_number()
    # print(cid)
    assert re.match(r'\d{16}', cid)



# Generated at 2022-06-21 16:20:52.457090
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """This function tests the credit_card_expiration_date() method of the Payment class.""" 
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    payment = Payment()
    assert len(payment.credit_card_expiration_date()) == 5


# Generated at 2022-06-21 16:20:53.843290
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pass


# Generated at 2022-06-21 16:20:55.213073
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment=Payment("en",seed=0)
    assert payment.cvv()==602

# Generated at 2022-06-21 16:21:03.168089
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import CardType
    from mimesis.enums.payment import CreditCardNetwork
    from mimesis.random import Random

    random = Random(seed=42)
    payment = Payment(seed=42)

    assert payment.credit_card_number() == '4455 5299 1152 2450'

    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'

    assert payment.credit_card_number(CardType.MASTER_CARD) == '5121 9087 6954 3496'

    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3764 87837 88568'

    assert payment.credit_card_network() == CreditCardNetwork.VISA
    assert payment.credit_card_network()

# Generated at 2022-06-21 16:21:06.072522
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    data = Payment().credit_card_expiration_date()[:2]
    if data[0] == '0' and (data[1] == '1' or data[1] == '0'):
        data = Payment().credit_card_expiration_date()[:2]
    assert data[0] != '0' or data[1] != '1'

# Generated at 2022-06-21 16:21:14.831504
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    assert len(p.bitcoin_address()) == 34
    assert "0x" not in (p.bitcoin_address())
    assert p.bitcoin_address()[0] == '1' or p.bitcoin_address()[0] == '3'


# Generated at 2022-06-21 16:21:15.722858
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    assert isinstance(payment.credit_card_network(), str)

# Generated at 2022-06-21 16:21:18.499790
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Test for method cvv of class Payment."""
    payment = Payment()
    assert len(str(payment.cvv())) == 3


# Generated at 2022-06-21 16:21:20.024273
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert re.match(r'^\w+[\w\.]*@\w+\.\w+$', payment.paypal())


# Generated at 2022-06-21 16:21:22.578604
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    x = Payment().bitcoin_address()
    assert len(x) == 34


# Generated at 2022-06-21 16:21:23.973881
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment(seed=0)
    assert payment.cid() == 2583


# Generated at 2022-06-21 16:21:25.180960
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment(seed=0)
    assert payment.cvv() == 364

# Generated at 2022-06-21 16:21:26.258069
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert Payment().cid()


# Generated at 2022-06-21 16:21:34.139116
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print('Test method credit_card_number of class Payment')

    p = Payment()

    print('Generate a random credit card number: ')
    print(p.credit_card_number())
    print(p.credit_card_number())
    print(p.credit_card_number())
    print(p.credit_card_number())
    print(p.credit_card_number())
    print(p.credit_card_number())


# Generated at 2022-06-21 16:21:36.458915
# Unit test for method cid of class Payment
def test_Payment_cid():
    x = 0
    for i in range(100000):
        x += get_random_payment().cid()
    print(x)


# Generated at 2022-06-21 16:21:52.679182
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert re.match(r'^(?:\d{2})/(?:1[6-9]|[2-9][0-9])$', payment.credit_card_expiration_date())

# Generated at 2022-06-21 16:21:55.314417
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Generate a random credit card network"""
    payment = Payment()
    result = payment.credit_card_network()
    assert result in CREDIT_CARD_NETWORKS

# Generated at 2022-06-21 16:21:58.387127
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    instance = Payment()
    cvv = instance.cvv()
    assert(cvv >= 100 and cvv <= 999)


# Generated at 2022-06-21 16:22:04.092082
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment('en')
    owner = p.credit_card_owner(Gender.FEMALE)
    assert isinstance(owner, dict)
    assert isinstance(owner['credit_card'], str)
    assert isinstance(owner['expiration_date'], str)
    assert isinstance(owner['owner'], str)

# Generated at 2022-06-21 16:22:05.110965
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())

if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-21 16:22:07.974838
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis.enums import CardType
    provider = Payment()
    assert provider.credit_card_network() in CREDIT_CARD_NETWORKS
    assert provider.credit_card_network(CardType.VISA) == 'Visa'


# Generated at 2022-06-21 16:22:19.617248
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    # Visa
    assert len(payment.credit_card_number(CardType.VISA)) == 19
    assert re.match(r'^4[0-9]{12}(?:[0-9]{3})?$', payment.credit_card_number(CardType.VISA)) is not None

    # MasterCard
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert re.match(r'^5[1-5][0-9]{14}$', payment.credit_card_number(CardType.MASTER_CARD)) is not None

    # AmericanExpress
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 18

# Generated at 2022-06-21 16:22:21.069433
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert payment.cid() == payment.cid()


# Generated at 2022-06-21 16:22:22.190780
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    assert isinstance(p.credit_card_network(), str)


# Generated at 2022-06-21 16:22:25.131992
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    print("\n# Unit test for method paypal of class Payment")
    pay = Payment()
    print(pay.paypal())


# Generated at 2022-06-21 16:22:55.040698
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    print("Payment.bitcoin_address: ", payment.bitcoin_address())
    print("Payment.bitcoin_address: ", payment.bitcoin_address())
    print("Payment.bitcoin_address: ", payment.bitcoin_address())
    print("Payment.bitcoin_address: ", payment.bitcoin_address())
    print("Payment.bitcoin_address: ", payment.bitcoin_address())


# Generated at 2022-06-21 16:23:05.466862
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    paypal = payment.paypal()
    assert bool(re.search(r'[\w\.-]+@[\w\.-]+', paypal))
    assert bool(re.search(r'([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})', paypal))
    assert bool(re.search(r'([a-zA-Z0-9_\-\.]+)@[a-zA-Z0-9_\-\.]+\.[a-zA-Z]+', paypal))
    assert bool(re.search(r'[\w\.-]+@[\w\.-]+\.[a-zA-Z]+', paypal))

# Generated at 2022-06-21 16:23:07.567318
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment(seed=1)
    assert p.paypal() == 'jakubekm@hotmail.com'


# Generated at 2022-06-21 16:23:17.013225
# Unit test for method cvv of class Payment
def test_Payment_cvv():
	print("=================================================")
	print("Test for method cvv of class Payment")
	print("=================================================")
	#Test 1
	cvv = Payment().cvv()
	print(cvv)
	
	#Test 2
	cvv = Payment().cvv()
	print(cvv)
	
	#Test 3
	cvv = Payment().cvv()
	print(cvv)
	
	#Test 4
	cvv = Payment().cvv()
	print(cvv)
	
	#Test 5
	cvv = Payment().cvv()
	print(cvv)
	
	#Test 6
	cvv = Payment().cvv()
	print(cvv)
	
	#Test 7
	cvv = Payment().cvv()
	print(cvv)
	
	#

# Generated at 2022-06-21 16:23:26.007957
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    import unittest
    import datetime

    class TestPayment(unittest.TestCase):
        def setUp(self):
            self.payment = Payment()

        def test_credit_card_expiration_date(self):
            now = datetime.datetime.now()
            month = now.strftime("%m")
            year = now.strftime("%Y")

            expiration_date_test = self.payment.credit_card_expiration_date(
                int(year[2:]),
                int(year[2:]) + 5)

            # truncate string
            expiration_date_test = ".".join(
                expiration_date_test.split("/")[:2])

            expiration_date = "." + month + "." + year[2:]


# Generated at 2022-06-21 16:23:27.546384
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment(random_state=0)
    assert payment.cid() == 2595


# Generated at 2022-06-21 16:23:30.035548
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    print(p.credit_card_owner())
    print(p.credit_card_owner(gender=Gender.MALE))
    print(p.credit_card_owner(gender=Gender.FEMALE))


# Generated at 2022-06-21 16:23:32.716009
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date(minimum = 16, maximum = 25) == "03/19"

# Generated at 2022-06-21 16:23:41.377145
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    from mimesis.providers.utils import seed

    p1 = Payment()
    c1 = p1.credit_card_number()
    print(c1)
    e1 = p1.credit_card_expiration_date(minimum=16, maximum=25)
    print(e1)
    print(p1.credit_card_number(CardType.MASTER_CARD))

    seed('mimesis')
    c2 = p1.credit_card_number()
    print(c2)
    e2 = p1.credit_card_expiration_date(minimum=16, maximum=25)
    print(e2)

# Generated at 2022-06-21 16:23:44.248534
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    eth_addr = payment.ethereum_address()
    assert re.match(r'0x[0-9a-f]{40}', eth_addr) is not None
    assert len(eth_addr) == 42


# Generated at 2022-06-21 16:24:57.661850
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    card = Payment()

    # test if card_type is empty
    credit_card_number = card.credit_card_number()
    if not (len(credit_card_number) == 19):
        raise Exception('Credit card number has not the right length !')

    # test if card_type is Visa
    credit_card_number = card.credit_card_number(CardType.VISA)
    if not (len(credit_card_number) == 19):
        raise Exception('Credit card number has not the right length !')

    # test if card_type is MasterCard
    credit_card_number = card.credit_card_number(CardType.MASTER_CARD)
    if not (len(credit_card_number) == 19):
        raise Exception('Credit card number has not the right length !')

    # test if card_

# Generated at 2022-06-21 16:24:58.440064
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()


# Generated at 2022-06-21 16:25:01.918291
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    data = payment.credit_card_owner()
    # Test value of dictionary "data"
    assert data['credit_card'] == '4548 1645 2657 7226'
    assert data['expiration_date'] == '06/17'
    assert data['owner'] == 'JACOBO PERALTA'

# Generated at 2022-06-21 16:25:11.311687
# Unit test for constructor of class Payment
def test_Payment():
    provider = Payment()
    result1 = provider.cid()
    result2 = provider.paypal()
    result3 = provider.bitcoin_address()
    result4 = provider.ethereum_address()
    result5 = provider.credit_card_network()
    result6 = provider.credit_card_number()
    result7 = provider.credit_card_expiration_date()
    result8 = provider.cvv()
    result9 = provider.credit_card_owner()

    assert isinstance(result1, int)
    assert isinstance(result2, str)
    assert isinstance(result3, str)
    assert isinstance(result4, str)
    assert isinstance(result5, str)
    assert isinstance(result6, str)
    assert isinstance(result7, str)

# Generated at 2022-06-21 16:25:22.308027
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    bitcoin_address_list = []
    instance = Payment(seed=12345)
    for i in range(100):
        bitcoin_address_list.append(instance.bitcoin_address())    

# Generated at 2022-06-21 16:25:23.596278
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    b_address = payment.bitcoin_address()
    return b_address


# Generated at 2022-06-21 16:25:25.172320
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    provider = Payment()
    result = provider.cvv()
    assert len(str(result)) == 3

# Generated at 2022-06-21 16:25:27.912539
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Test unit for method credit_card_owner of class Payment."""
    payment = Payment()
    credit_card_owner = payment.credit_card_owner()
    assert type(credit_card_owner) == dict
    assert 'credit_card' in credit_card_owner
    assert 'expiration_date' in credit_card_owner
    assert 'owner' in credit_card_owner

# Generated at 2022-06-21 16:25:29.618733
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    owner = p.credit_card_owner()
    assert isinstance(owner, dict)
    assert len(owner['credit_card']) == 19


# Generated at 2022-06-21 16:25:32.947138
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """Test paypal method"""
    payment_paypal = Payment()
    assert isinstance(payment_paypal.paypal(), str)
    assert re.match(r"^([a-zA-Z0-9_\-\.]+)@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,6})$", payment_paypal.paypal())


# Generated at 2022-06-21 16:27:17.566145
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert isinstance(payment.cvv(), int)
    assert len(str(payment.cvv())) == 3


# Generated at 2022-06-21 16:27:18.683213
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment is not None

if __name__ == '__main__':
    test_Payment()

# Generated at 2022-06-21 16:27:20.982490
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment
    
    payment = Payment()
    payment.credit_card_owner(gender=Gender.MALE)
    assert payment.credit_card_owner(gender=Gender.MALE)['owner'] == 'Mr. William Davis'

# Generated at 2022-06-21 16:27:23.954317
# Unit test for method paypal of class Payment
def test_Payment_paypal():
  x = Payment()
  for _ in range(10):
    print(x.paypal())

# Generated at 2022-06-21 16:27:24.886569
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    Payment.credit_card_owner()

# Generated at 2022-06-21 16:27:26.019221
# Unit test for constructor of class Payment
def test_Payment():
    provider = Payment()
    print(provider.credit_card_owner(Gender.MALE))

# Generated at 2022-06-21 16:27:28.778710
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
  payment = payment(seed=0)
  owner = payment.credit_card_owner()
  assert owner == {'credit_card': '4975 0770 2239 8952', 'expiration_date': '08/20', 'owner': 'FLORA RATLIFF'}


# Generated at 2022-06-21 16:27:31.573833
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    test_obj = Payment('en', seed=1234)
    test_gender = Gender.FEMALE
    test_result = {'credit_card': '4455 5299 1152 2450', 'expiration_date': '03/16',
        'owner': 'CAMILLE MYERS'}
    assert test_obj.credit_card_owner(test_gender) == test_result

# Generated at 2022-06-21 16:27:34.372156
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert len(str(payment.cid())) > 0


# Generated at 2022-06-21 16:27:37.060704
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment('en')
    for _ in range(10):
        x = payment.cid()
        assert (type(x) == int)
