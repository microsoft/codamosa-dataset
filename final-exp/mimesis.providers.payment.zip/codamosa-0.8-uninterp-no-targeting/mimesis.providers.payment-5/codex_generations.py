

# Generated at 2022-06-21 16:20:39.308127
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    d = Payment()
    for _ in range(10):
        assert(d.cvv() in range(100, 999))

# Generated at 2022-06-21 16:20:42.504581
# Unit test for constructor of class Payment
def test_Payment():
    assert Payment.__bases__[0] == BaseProvider
    assert Payment.Meta.name == 'payment'

# Unit tests for method cid

# Generated at 2022-06-21 16:20:45.830539
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment_1 = Payment()
    print(payment_1.credit_card_network())
    assert payment_1.credit_card_network() in CREDIT_CARD_NETWORKS

#Unit test for method credit_card_number of class Payment

# Generated at 2022-06-21 16:20:46.668260
# Unit test for method cvv of class Payment
def test_Payment_cvv():
  assert 99 < Payment().cvv() <= 999

# Generated at 2022-06-21 16:20:48.434946
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    bitcoin_address = Payment('en').bitcoin_address()
    #print('bitcoin_address =', bitcoin_address)
    assert bitcoin_address is not None


# Generated at 2022-06-21 16:20:51.792056
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pa = Payment()
    assert type(pa.credit_card_number()) == str
    assert len(pa.credit_card_number()) == 19
    print("test_Payment_credit_card_number passed")


# Generated at 2022-06-21 16:20:54.392447
# Unit test for method cid of class Payment
def test_Payment_cid():
    Payment = Payment(seed=1234)
    assert Payment.cid() == 4572



# Generated at 2022-06-21 16:20:57.801345
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date() == "11/22"
    assert payment.credit_card_expiration_date() > "01/10"
    assert payment.credit_card_expiration_date() < "00/25"

# Generated at 2022-06-21 16:20:59.031410
# Unit test for method cvv of class Payment
def test_Payment_cvv(): # type: ignore
    payment = Payment()
    payment.cvv()

# Generated at 2022-06-21 16:21:00.205449
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert (len(Payment().cid()) == 4)


# Generated at 2022-06-21 16:21:16.257680
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():

    payment = Payment()
    credit_card_network = payment.credit_card_network()

    assert (credit_card_network in [
        'MasterCard',
        'Visa',
        'American Express',
        'Discover',
        'Diners Club',
        'JCB',
    ])


# Generated at 2022-06-21 16:21:18.772540
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    # Init object Payment
    paymentObj = Payment('en')
    # Call method credit_card_network
    temp = paymentObj.credit_card_network()
    # Check result
    assert temp in ['MasterCard', 'Visa', 'Discover', 'JCB', 'Diners Club']


# Generated at 2022-06-21 16:21:22.110518
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # test data
    data = [
        ('williamknight@outlook.com', 'PayPal', '0.04$'),
        ('connorlewis@outlook.com', 'PayPal', '0.08$'),
    ]
    # testing process
    for rec in data:
        assert rec[0] == rec[0]
        assert rec[1] == rec[1]
        assert rec[2] == rec[2]


# Generated at 2022-06-21 16:21:23.727747
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    cvv = Payment().cvv()
    assert type(cvv) == int
    assert 100 <= cvv <= 999


# Generated at 2022-06-21 16:21:25.900711
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    provider = Payment()
    bitcoin_address = provider.bitcoin_address()
    print("bitcoin_address: ", bitcoin_address)


# Generated at 2022-06-21 16:21:27.970945
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert Payment().credit_card_expiration_date() == "04/21"


# Generated at 2022-06-21 16:21:31.923959
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    number = Payment()
    card_number = number.credit_card_number(CardType.VISA)
    print(card_number)
    print(type(card_number))
    assert type(card_number) == str


# Generated at 2022-06-21 16:21:37.757912
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    payment.credit_card_expiration_date()
    payment.credit_card_number()
    payment.credit_card_owner()
    payment.credit_card_network()
    payment.cid()
    payment.bitcoin_address()
    payment.credit_card_network()
    payment.paypal()

if __name__ == '__main__':
    test_Payment()

# Generated at 2022-06-21 16:21:46.539125
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    pay = Payment()
    month = [1,2,3,4,5,6,7,8,9,10,11,12]
    year = [16,17,18,19,20,21,22,23,24,25]
    for i in range(1000):
        text_date = pay.credit_card_expiration_date()
        month_date = int(text_date[:2])
        month.remove(month_date)
        year_date = int(text_date[-2:])
        year.remove(year_date)
    if(month != [] or year != []):
        sys.stderr.write("Test for method credit_card_expiration_date of class Payment")
        sys.stderr.write("has failed\n")

# Generated at 2022-06-21 16:21:55.888685
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment(seed=1234)

    assert p.ethereum_address() == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'
    assert p.ethereum_address() == '0x1e8ece9e6ff7dba52d4c07d37418036a89af9698d'
    assert p.ethereum_address() == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'


# Generated at 2022-06-21 16:22:28.020234
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment
    p = Payment()
    print(p.credit_card_owner(Gender.MALE))
    print(p.credit_card_owner(Gender.FEMALE))


# Generated at 2022-06-21 16:22:33.276763
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card = p.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(card.replace(' ', '')) == 15
    card = p.credit_card_number(CardType.VISA)
    assert len(card.replace(' ', '')) == 16
    card = p.credit_card_number(CardType.MASTER_CARD)
    assert len(card.replace(' ', '')) == 16

# Generated at 2022-06-21 16:22:35.489986
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # ethereum_address should return a string of length 42
    assert len(Payment('en').ethereum_address()) == 42


# Generated at 2022-06-21 16:22:37.308753
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment('en')

    assert p.credit_card_network() in ["American Express", "MasterCard", "Visa"]


# Generated at 2022-06-21 16:22:40.215439
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    result = payment.cid()
    print(result)


# Generated at 2022-06-21 16:22:41.791683
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-21 16:22:49.231546
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # case 1:
    assert Payment.credit_card_number(Payment()) == "4040 4188 7490 4826"

    # case 2:
    assert Payment.credit_card_number(Payment()) == "4040 4188 7490 4826"

    # case 3:
    assert Payment.credit_card_number(Payment()) == "2221 9328 0950 1591"

    # case 4:
    assert Payment.credit_card_number(Payment()) == "2221 9328 0950 1591"

    # case 5:
    assert Payment.credit_card_number(Payment()) == "2221 9328 0950 1591"

    # case 6:
    assert Payment.credit_card_number(Payment()) == "2221 9328 0950 1591"




# Generated at 2022-06-21 16:22:51.633955
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    a = Payment()
    b = Payment(seed=1234)
    print('a =', a.seed)
    print('b =', b.seed)
    assert a.cvv() != b.cvv()

# Generated at 2022-06-21 16:22:52.626739
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    p.bitcoin_address()
    print("Class Payment method bitcoin_address() OK")


# Generated at 2022-06-21 16:22:54.539787
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    for i in range(10):
        result = p.cid()
        assert result >= 1000 and result <= 9999
