

# Generated at 2022-06-12 02:21:39.837469
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    obj = Payment('en')
    assert obj.credit_card_number() == '4929 7844 8193 2947'

# Generated at 2022-06-12 02:21:43.052755
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number(CardType.MASTER_CARD))


# Generated at 2022-06-12 02:21:46.095788
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc_number = '4455 5299 1152 2450'
    p = Payment()
    assert p.credit_card_number(CardType.VISA) == cc_number

# Generated at 2022-06-12 02:21:53.509213
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    tmp_Payment = Payment()
    tmp_Payment.credit_card_number()

    tmp_Payment.credit_card_number(CardType.VISA)
    tmp_Payment.credit_card_number(CardType.MASTER_CARD)
    tmp_Payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    print('test_Payment_credit_card_number success')
    return
test_Payment_credit_card_number()

# Generated at 2022-06-12 02:21:57.644016
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print("card_number: {}".format(payment.credit_card_number()))
    print("card_number: {}".format(payment.credit_card_number()))
    print("card_number: {}".format(payment.credit_card_number()))


# Generated at 2022-06-12 02:22:01.838062
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    mimesis = Payment()
    print(mimesis.credit_card_number())
    print(mimesis.credit_card_number(CardType.AMERICAN_EXPRESS))
    print(mimesis.credit_card_number(CardType.MASTER_CARD))
    print(mimesis.credit_card_number(CardType.VISA))


# Generated at 2022-06-12 02:22:08.205796
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method Payment_credit_card_number"""
    # assert re.search(r'\d{4}\s\d{4}\s\d{4}\s\d{4}',
    # Payment().credit_card_number(),
    # re.IGNORECASE) is not None
    assert Payment().credit_card_number()

test_Payment_credit_card_number()

# Generated at 2022-06-12 02:22:17.160950
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    seed = 9
    provider = Payment('en', seed)
    assert provider.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert provider.credit_card_number(CardType.MASTER_CARD) == '2264 6034 7191 1586'
    assert provider.credit_card_number(CardType.AMERICAN_EXPRESS) == '3747 360256 75744'
    assert provider.credit_card_number() in ['4455 5299 1152 2450', '2264 6034 7191 1586', '3747 360256 75744']



# Generated at 2022-06-12 02:22:29.323261
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_en = Payment(locale='en', seed=100)
    payment_ru = Payment(locale='ru', seed=100)

    card_type = [
        CardType.MASTER_CARD,
        CardType.VISA,
        CardType.AMERICAN_EXPRESS
    ]

    assert payment_en.credit_card_number(CardType.VISA) == '4883 8231 0046 1503'
    assert payment_en.credit_card_number(CardType.MASTER_CARD) == '5484 8343 9441 2064'
    assert payment_en.credit_card_number(CardType.AMERICAN_EXPRESS) == '3423 977492 05912'
    assert payment_ru.credit_card_number(None) == '5483 0580 5698 9083'

# Generated at 2022-06-12 02:22:37.483757
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.MASTER_CARD
    random = BaseProvider("en")
    payment = Payment("en", random=random)
    for i in range(100):
        number = payment.credit_card_number(card_type)
        assert re.match(r"^.{2} .{4} .{4} .{4}", number)
    card_type = CardType.VISA
    for i in range(100):
        number = payment.credit_card_number(card_type)
        assert re.match(r"^.{4} .{4} .{4} .{4}", number)
    card_type = CardType.AMERICAN_EXPRESS
    for i in range(100):
        number = payment.credit_card_number(card_type)
        assert re.match

# Generated at 2022-06-12 02:22:49.598480
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment(seed=12345)
    assert payment.credit_card_number() == '4089 4834 3362 6918'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5454 0888 6500 9520'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3767 8793 78846 92'


# Generated at 2022-06-12 02:22:57.954860
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pp = Payment(seed=123)

    VISA = pp.credit_card_number(CardType.VISA)
    print(VISA)
    master_card = pp.credit_card_number(CardType.MASTER_CARD)
    print(master_card)
    american_express = pp.credit_card_number(CardType.AMERICAN_EXPRESS)
    print(american_express)

    assert VISA == '4455 5299 1152 2451'
    assert master_card == '5266 0172 1646 2366'
    assert american_express == '3767 806136 60486'

# Generated at 2022-06-12 02:23:01.378980
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc_num = Payment().credit_card_number()
    assert re.match(r"^\d{4} \d{4} \d{4} \d{4}$", cc_num)

# Generated at 2022-06-12 02:23:11.387575
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    '''
    测试Payment中的 credit_card_number()方法
    :return:
    '''
    p = Payment()
    print(p.credit_card_number())
    print(p.credit_card_number(CardType.AMERICAN_EXPRESS))
    print(p.credit_card_number(CardType.MASTER_CARD))
    print(p.credit_card_number(CardType.VISA))
    print(p.credit_card_number(CardType.VISA))

if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:23:19.969505
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test method Payment.credit_card_number()."""

    # Verbose flag
    verbose = False

    # Generate an object Payment
    obj = Payment()

    # Generate a random credit card number
    credit_card_number = obj.credit_card_number()

    # Print the result
    if verbose:
        print('credit_card_number = {}'.format(credit_card_number))

    # Check if the generated string is valid
    if not isinstance(credit_card_number, str):
        raise TypeError

    # Check if the generated string is not empty
    if not credit_card_number:
        raise ValueError

    # Check if the generated string is not empty
    if len(credit_card_number) < 16:
        raise ValueError

# Generated at 2022-06-12 02:23:24.401549
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    #assert payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    #assert payment.credit_card_number(CardType.MASTER_CARD)
    #assert payment.credit_card_number(CardType.VISA)

# Generated at 2022-06-12 02:23:34.827708
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import mimesis.enums
    enum = mimesis.enums

    # Test for default card type
    card_type = None
    payment = Payment()
    card_number = payment.credit_card_number(card_type)
    assert len(card_number) == 19
    pattern = re.compile(r'([4][0-9]{3})([0-9]{4})([0-9]{4})([0-9]{4})')
    assert pattern.match(card_number)

    # Test for all card type
    card_types = enum.ListEnum(enum.CardType)
    for card_type_enum in card_types:
        card_type = card_type_enum.value
        payment = Payment()

# Generated at 2022-06-12 02:23:41.506333
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test = Payment()
    # expected value = 4556737586899855
    test.random.seed(0)
    assert(test.credit_card_number() == "4556 7375 8689 9855")
    # expected value = 6011000990139424
    test.random.seed(1)
    assert(test.credit_card_number() == "6011 0009 9013 9424")
    # expected value = 3528000000000007
    test.random.seed(2)
    assert(test.credit_card_number() == "3528 00000000 0007")
    # expected value = 371449635398431
    test.random.seed(3)
    assert(test.credit_card_number() == "3714 496353 98431")

# Generated at 2022-06-12 02:23:47.016562
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # card_type = CardType.VISA
    card_type = None
    pp = Payment()
    # credit_card_number = pp.credit_card_number()
    credit_card_number = pp.credit_card_number(card_type)
    print(credit_card_number)


# Generated at 2022-06-12 02:23:48.236596
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    p = Payment()
    for i in range(10):
        print(p.credit_card_number())



# Generated at 2022-06-12 02:24:03.584743
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test_payment = Payment()
    test_credit_card_number = test_payment.credit_card_number(CardType.VISA)
    assert test_credit_card_number is not None


# Generated at 2022-06-12 02:24:12.933586
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print("\n\nPrint a randomly generated Credit Card Number:")
    print(Payment().credit_card_number())
    # Verify that method gets proper parameters
    print("\n\nPrint a randomly generated Credit Card Number:")
    print(Payment().credit_card_number(CardType.MASTER_CARD))
    # Verify that method gets improper parameters
    print("\n\nPrint a randomly generated Credit Card Number:")
    print(Payment().credit_card_number(CardType.DISCOVER))


# Generated at 2022-06-12 02:24:16.447126
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_number = Payment().credit_card_number(CardType.MASTER_CARD)
    assert card_number[:2] == '52'
    assert card_number[:3] != '521'


# Generated at 2022-06-12 02:24:20.787501
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.VISA
    card_number = Payment(seed=1234).credit_card_number(card_type=card_type)
    assert card_number == '4455 5299 1152 2450'


# Generated at 2022-06-12 02:24:23.900400
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    ps = Payment()
    card_type = CardType.VISA
    # print(ps.credit_card_number(card_type))
    assert ps.credit_card_number(card_type)

# Generated at 2022-06-12 02:24:33.658059
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_number_expected=['4885 8252 8412 8073','5595 7600 1383 8841','4502 1462 6599 6055','4357 3292 6283 0813','4221 7847 5987 9293','5511 0903 8799 7135','4920 5304 5949 0653','4490 9539 7601 3515','4495 3485 4628 6593','4807 7452 6870 8701']
    actual_card_number=[]
    card_num = Payment(seed=47)
    for i in range(10):
        actual_card_number.append(card_num.credit_card_number())
    assert(card_number_expected==actual_card_number)



# Generated at 2022-06-12 02:24:36.098585
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test_string = '4545 5212 3099 3643'
    assert test_string == Payment.credit_card_number(CardType.VISA)

# Generated at 2022-06-12 02:24:37.578977
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())

# Generated at 2022-06-12 02:24:49.440235
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for i in range(0, 50):
        payment.reset_seed()
        card_type = get_random_item(CardType, rnd=payment.random)
        card = payment.credit_card_number(card_type)
        assert isinstance(card, str)
        assert len(card.replace(" ", "")) == 16

    for i in range(0, 50):
        payment.reset_seed()
        card = payment.credit_card_number(CardType.MASTER_CARD)
        assert isinstance(card, str)
        assert len(card.replace(" ", "")) == 16

# Generated at 2022-06-12 02:24:56.545872
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    from mimesis.enums import CardType
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.payment import Payment
    payment = Payment()
    payment.random = payment.random.set_state("Test")
    print("Run the test for method credit_card_number of class Payment")
    assert payment.credit_card_number() == '4538 7432 7252 4221'
    payment.credit_card_number(CardType.VISA)
    # Test exception
    try:
        payment.credit_card_number("MasterCard")
    except Exception as error:
        assert isinstance(error, NonEnumerableError)


# Generated at 2022-06-12 02:25:35.472369
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pmt = Payment()
    assert re.match(r'\d{4}\s?\d{4}\s?\d{4}\s?\d{4}', pmt.credit_card_number(CardType.VISA))
    assert re.match(r'\d{4}\s?\d{6}\s?\d{5}', pmt.credit_card_number(CardType.AMERICAN_EXPRESS))
    assert re.match(r'\d{4}\s?\d{4}\s?\d{4}\s?\d{4}', pmt.credit_card_number(CardType.MASTER_CARD))

# Generated at 2022-06-12 02:25:40.520795
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # test case
    card_type = 'VISA'
    # execute
    payment = Payment(seed=2000)
    result = payment.credit_card_number(card_type)
    # assert
    assert result == '4455 5299 1152 2450'
    return None


# Generated at 2022-06-12 02:25:43.611458
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment

    payment = Payment()
    print(payment.credit_card_number(CardType.VISA))

# Generated at 2022-06-12 02:25:45.216009
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(0, 100):
        #print(Payment().credit_card_number())
        pass

# Generated at 2022-06-12 02:25:47.349914
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pay = Payment()
    credit = pay.credit_card_number()
    assert isinstance(credit, str)
    assert credit in [item.value for item in CardType]

# Generated at 2022-06-12 02:25:52.860743
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # CardType.VISA
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}',
                    Payment().credit_card_number(card_type=CardType.VISA))
    # CardType.MASTER_CARD
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}',
                    Payment().credit_card_number(
                        card_type=CardType.MASTER_CARD))
    # CardType.AMERICAN_EXPRESS
    assert re.match(r'\d{4} \d{6} \d{5}',
                    Payment().credit_card_number(
                        card_type=CardType.AMERICAN_EXPRESS))
# test_Payment_credit_card_number()

# Generated at 2022-06-12 02:25:57.094807
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test = Payment()
    assert len(test.credit_card_number(CardType.VISA)) == 19
    assert len(test.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(test.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17

# Generated at 2022-06-12 02:26:06.564856
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print("\nUnit test for method credit_card_number of class Payment")
    payment = Payment()
    card_networks = [CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]
    print("Unit testing:")
    # ===Unit test for method credit_card_number of class Payment===
    for i in range(100):
        card_type = payment.random.choice(card_networks)
        card_number = payment.credit_card_number(card_type)
        print("Card type: ", card_type)
        print("Card number: ", card_number)
        print("***********************************")


# Generated at 2022-06-12 02:26:10.438920
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert(number[:2] == '34') or (number[:2] == '37')


# Generated at 2022-06-12 02:26:13.873707
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    payment.credit_card_number(CardType.MASTER_CARD)
    payment.credit_card_number(CardType.VISA)
    payment.credit_card_number(CardType.AMERICAN_EXPRESS)