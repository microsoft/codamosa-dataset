

# Generated at 2022-06-12 02:21:35.494332
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    payment = Payment()
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))
    print(len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)))

# Generated at 2022-06-12 02:21:37.724456
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for _ in range(10):
        print(Payment().credit_card_number()) 
# End of unit test for method credit_card_number of class Payment


# Generated at 2022-06-12 02:21:45.937856
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    c = CardType
    card = p.credit_card_number(c.VISA)
    print('VISA: ' + card)
    card = p.credit_card_number(c.MASTER_CARD)
    print('MC: ' + card)
    card = p.credit_card_number(c.AMERICAN_EXPRESS)
    print('AE: ' + card)
    print()
    for i in range(0, 10):
        card = p.credit_card_number()
        print(card)

# Generated at 2022-06-12 02:21:57.319597
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment."""
    py = Payment()
    for i in range(100):
        number = py.credit_card_number()
        assert number[0] == '4'
    for i in range(100):
        number = py.credit_card_number(CardType.MASTER_CARD)
        assert number[0] in ['2', '5']
    for i in range(100):
        number = py.credit_card_number(CardType.AMERICAN_EXPRESS)
        assert number[0:2] in ['34', '37']
        assert len(number) == 17
        assert number[0] != '-'
        assert number[1] != ' '

# Generated at 2022-06-12 02:22:02.398796
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    card_type_list = [CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]
    card_number_list = []
    for i in range(0, 100):
        card_number = Payment().credit_card_number(card_type_list[i%3])
        if card_number not in card_number_list:
            card_number_list.append(card_number)
            print(card_number)

# Generated at 2022-06-12 02:22:14.370005
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import math
    import random
    import statistics
    import unittest

    # Class to count the number of digits
    class DigitsCounter:
        def __init__(self):
            self.count = 0

        def count_digits(self, num):
            self.count += math.floor(math.log10(num)) + 1

    # Test 1
    test_card_type = 'VISA'
    rnd = random.Random()
    rnd.seed(1)
    counter = DigitsCounter()
    payment = Payment(seed = rnd)
    for i in range(1, 15):
        counter.count_digits(int(payment.credit_card_number()[4:8]))
    assert(counter.count == 14)

    # Test 2

# Generated at 2022-06-12 02:22:18.517423
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # case 1: card_type is not None
    card_type = CardType.VISA
    payment = Payment()
    payment.random.choice = lambda x: card_type
    result = payment.credit_card_number(card_type)


# Generated at 2022-06-12 02:22:30.124367
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Unit test for method credit_card_number of class Payment
    payment = Payment('en', seed=1)
    card_number = payment.credit_card_number(CardType.VISA)
    assert card_number == "4051 4931 0201 9708"
    card_number = payment.credit_card_number(CardType.MASTER_CARD)
    assert card_number == "5486 6133 4478 0837"
    card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert card_number == "3716 028368 09029"
    # Test for non-enumerable within card type
    with pytest.raises(NonImplementedError):
        payment.credit_card_number(CardType.DISCOVER)

# Generated at 2022-06-12 02:22:36.802769
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    from mimesis.enums import CardType

    print("------------ Testing credit_card_number ------------")
    payment = Payment()
    card_num = payment.credit_card_number(CardType.VISA)
    print("Visa credit card number: ", card_num)
    card_num = payment.credit_card_number(CardType.MASTER_CARD)
    print("MasterCard credit card number: ", card_num)
    card_num = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    print("American Express credit card number: ", card_num)
    print("-----------------------------------------------------")


# Generated at 2022-06-12 02:22:48.447010
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    rng = random.Random(2)
    # Test credit card number for master card
    for _ in range(100):
        # Check that the number is valid
        number = rng.choice(CREDIT_CARD_NETWORKS[:2])
        card = Payment.credit_card_number(card_type=CardType.MASTER_CARD)
        card_type = CardType.MASTER_CARD
        assert card.startswith(number)
        assert len(card) == 19
        assert Payment.luhn_checksum(card) == 0
    # Test credit card number for visa
    for _ in range(100):
        # Check that the number is valid
        number = "4"

# Generated at 2022-06-12 02:23:01.723615
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert (p.credit_card_number() == "4455 5299 1152 2450")
    # Test for VISA card format.
    assert (len(p.credit_card_number()) == 19)
    assert (p.credit_card_number()[:4] == "4455")
    assert (p.credit_card_number()[5] == " ")
    assert (p.credit_card_number()[9] == " ")
    assert (p.credit_card_number()[13] == " ")

    assert (p.credit_card_number(CardType.MASTER_CARD) == "5021 4168 3107 8299")
    # Test for MasterCard
    assert (len(p.credit_card_number(CardType.MASTER_CARD)) == 19)


# Generated at 2022-06-12 02:23:04.273007
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()

# Generated at 2022-06-12 02:23:08.498920
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType

    payment = Payment()
    credit_card_number = payment.credit_card_number(card_type = CardType.VISA)
    assert (len(credit_card_number) == 19)

# Generated at 2022-06-12 02:23:18.330488
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test for 4444 4444 4444 4444
    obj = Payment()
    if obj.credit_card_number() == '4444 4444 4444 4444':
        print('Test PASSED')
    else:
        print('Test FAILED')
        print(obj.credit_card_number())

    # Test for 5555 5555 5555 4444
    obj = Payment()
    if obj.credit_card_number() == '5555 5555 5555 4444':
        print('Test PASSED')
    else:
        print('Test FAILED')
        print(obj.credit_card_number())

    # Test for 6666 6666 6666 4444
    obj = Payment()
    if obj.credit_card_number() == '6666 6666 6666 4444':
        print('Test PASSED')

# Generated at 2022-06-12 02:23:23.399261
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.MASTER_CARD
    credit_card_num = payment.credit_card_number(card_type=card_type)
    # print(credit_card_num)
    assert credit_card_num[0:2] == '51' or credit_card_num[0:2] == '55'

# Generated at 2022-06-12 02:23:26.076003
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pp = Payment()
    v = pp.credit_card_number(CardType.MASTER_CARD)
    print(v)
    assert v

# Generated at 2022-06-12 02:23:31.448872
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis import Payment
    p = Payment()
    from random import seed
    seed(0)
    assert(p.credit_card_number(CardType.VISA) == '4455 5299 1152 2450')


# Generated at 2022-06-12 02:23:38.613021
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()

    r = p.credit_card_number()
    assert re.match(r'\d{16}', r)

    r = p.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert re.match(r'\d{15}', r)

    r = p.credit_card_number(CardType.MASTER_CARD)
    assert re.match(r'\d{16}', r)

    r = p.credit_card_number(CardType.VISA)
    assert re.match(r'\d{16}', r)

# Generated at 2022-06-12 02:23:49.872091
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.enums import Gender
    p = Payment()
    for _ in range(25):
        print(p.credit_card_owner(gender=Gender.FEMALE))
    # Test for method credit_card_number
    p = Payment()
    for _ in range(25):
        print(p.credit_card_number(card_type=CardType.MASTER_CARD))
        print(p.credit_card_number(card_type=CardType.VISA))
        print(p.credit_card_number(card_type=CardType.AMERICAN_EXPRESS))
    # Test Visa:
    p = Payment()
    for _ in range(25):
        print(p.credit_card_number(card_type=CardType.VISA))

# Generated at 2022-06-12 02:23:59.887487
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test_cases = {
        #  card_type: expected_output
        CardType.VISA: re.compile("^4[0-9]{3}[ ]?[0-9]{4}[ ]?[0-9]{4}[ ]?[0-9]{4}$"),
        CardType.MASTER_CARD: re.compile("^5[1-5][0-9]{2}[ ]?[0-9]{4}[ ]?[0-9]{4}[ ]?[0-9]{4}$"),
        CardType.AMERICAN_EXPRESS: re.compile("^3[47][0-9]{2}[ ]?[0-9]{6}[ ]?[0-9]{5}$"),
    }

# Generated at 2022-06-12 02:24:13.902374
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test if the function returns a string."""
    result = Payment(seed=1).credit_card_number()
    assert isinstance(result, str)


# Generated at 2022-06-12 02:24:16.693965
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card = p.credit_card_number()
    print(card)
    # print(len(card))
    # print(card)


# Generated at 2022-06-12 02:24:23.656394
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number()) == 19

    for i in range(100):
        number = payment.credit_card_number()
        assert True == luhn_checksum(number[:-1])


# Generated at 2022-06-12 02:24:32.183487
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    rnd_seed = 485
    rnd_seed2 = 576
    card_number = Payment(seed=rnd_seed)
    card_number2 = Payment(seed=rnd_seed)
    card_number3 = Payment(seed=rnd_seed2)
    assert card_number.credit_card_number() == '4455 5299 1152 2450'
    assert card_number.credit_card_number() == card_number2.credit_card_number()
    assert card_number2.credit_card_number() != card_number3.credit_card_number()

# Generated at 2022-06-12 02:24:33.611835
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    print(p.credit_card_number())



# Generated at 2022-06-12 02:24:37.367141
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import random
    import mimesis
    random.seed(0)
    payment = mimesis.Payment('en')
    assert payment.credit_card_number() == '4789 5199 9800 2476'


# Generated at 2022-06-12 02:24:38.851522
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert len(Payment().credit_card_number()) == 19

# Generated at 2022-06-12 02:24:46.124189
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=1)
    assert payment.credit_card_number(card_type=CardType.VISA) == '4556 7090 0773 8480'
    assert payment.credit_card_number(card_type=CardType.MASTER_CARD) == '5341 6522 8046 9889'
    assert payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == '3714 870273 62311'


# Generated at 2022-06-12 02:24:51.301991
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    r = Payment(seed=42)
    r.credit_card_number()
    r.credit_card_number(CardType.VISA)
    r.credit_card_number(CardType.MASTER_CARD)
    r.credit_card_number(CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-12 02:24:53.919767
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=42)
    card_number = payment.credit_card_number(CardType.VISA)
    assert card_number == '4083 7951 6195 1040'

# Generated at 2022-06-12 02:25:29.212215
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    x = Payment()
    assert (re.match(r"^([0-9]){16}$", x.credit_card_number())) is not None
    assert (re.match(r"^([0-9]){16}$", x.credit_card_number(CardType.MASTER_CARD))) is not None
    assert (re.match(r"^([0-9]){16}$", x.credit_card_number(CardType.AMERICAN_EXPRESS))) is not None
    assert (re.match(r"^([0-9]){16}$", x.credit_card_number(CardType.VISA))) is not None

# Generated at 2022-06-12 02:25:38.122899
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Create a Payment object
    p = Payment()
    # Test the method credit_card_number of class Payment
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', str(p.credit_card_number(CardType.VISA)))
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', str(p.credit_card_number(CardType.MASTER_CARD)))
    assert re.match(r'\d{4} \d{6} \d{5}', str(p.credit_card_number(CardType.AMERICAN_EXPRESS)))
    assert isinstance(p.credit_card_number(), str)

# Generated at 2022-06-12 02:25:42.826986
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for the credit_card_expiration_date method."""
    # pylint: disable=no-member
    payment = Payment()
    card = payment.credit_card_number()
    assert len(card) == 20
    assert len(card.split()) == 4


# Generated at 2022-06-12 02:25:44.401269
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    for i in range(100):
        print(payment.credit_card_number())

# Generated at 2022-06-12 02:25:48.473939
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card_type = CardType.VISA
    number = p.credit_card_number(card_type)
    # print(number)

    assert (number[0:1] == str(4) and len(number) == 19), "The method credit_card_number of class Payment is fail!"
    print("The method credit_card_number of class Payment is pass!")

# Generated at 2022-06-12 02:25:55.959924
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number() == '4556 8993 8510 1352'
    assert p.credit_card_number(CardType.VISA) == '4654 1117 1633 0898'
    assert p.credit_card_number(CardType.MASTER_CARD) == '5351 4135 6214 9784'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3402 895770 73847'


# Generated at 2022-06-12 02:26:03.955495
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    g1 = Payment()
    x = g1.credit_card_number(CardType.VISA)
    print('VISA Card Number:\t', x)
    x = g1.credit_card_number(CardType.MASTER_CARD)
    print('Master Card Number:\t', x)
    x = g1.credit_card_number(CardType.AMERICAN_EXPRESS)
    print('American Express Card Number:\t', x)

test_Payment_credit_card_number()

# Generated at 2022-06-12 02:26:09.241943
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    gen = Payment()
    for i in range(5):
        card_type = gen.random.choice(list(CardType))
        print("payment.credit_card_number(card_type=CardType." + card_type.name + ")")
        print(" -> ", gen.credit_card_number(card_type=CardType[card_type.name]))


# Generated at 2022-06-12 02:26:10.602164
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print(Payment.credit_card_number('Visa'))

# Generated at 2022-06-12 02:26:17.315608
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import pytest
    from mimesis.enums import CardType
    # Test for CardType VISA
    p = Payment()
    result = p.credit_card_number(CardType.VISA)
    assert result.startswith('4')
    assert result.split()[0][0] == '4'
    result = p.credit_card_number(CardType.VISA)
    assert result.startswith('4')
    assert result.split()[0][0] == '4'
    result = p.credit_card_number(CardType.VISA)
    assert result.startswith('4')
    assert result.split()[0][0] == '4'
    # Test for CardType MasterCard
    p = Payment()