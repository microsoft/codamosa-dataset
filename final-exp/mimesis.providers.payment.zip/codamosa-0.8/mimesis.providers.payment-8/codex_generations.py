

# Generated at 2022-06-12 02:21:43.207925
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for credit_card_number method of class Payment."""
    inst = Payment()
    assert inst.credit_card_number()
    assert inst.credit_card_number(CardType.VISA)

    # Test for card type MasterCard
    assert inst.credit_card_number(CardType.MASTER_CARD)

    # Test for card type AmericanExpress
    assert inst.credit_card_number(CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-12 02:21:49.600790
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    c=Payment(seed=777)
    print(c.credit_card_number(CardType.VISA))
    print(c.credit_card_number(CardType.MASTER_CARD))
    print(c.credit_card_number(CardType.AMERICAN_EXPRESS))


if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:21:56.600055
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Example of Visa credit card number
    print(Payment().credit_card_number(CardType.VISA))
    # Example of Master Card credit card number
    print(Payment().credit_card_number(CardType.MASTER_CARD))
    # Example of American Express credit card number
    print(Payment().credit_card_number(CardType.AMERICAN_EXPRESS))

if __name__ == "__main__":
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:22:01.688380
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    obj = Payment()
    result = {CardType.AMERICAN_EXPRESS: 0, CardType.MASTER_CARD: 0, CardType.VISA: 0}
    tries = 100000
    for _ in range(tries):
        result[obj.credit_card_number()[0]] += 1
    print(result)


if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:22:08.903901
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=0)
    assert payment.credit_card_number(card_type=CardType.VISA) == "4555 5299 1152 2450"
    assert payment.credit_card_number(card_type=CardType.MASTER_CARD) == "5452 9351 5421 8023"
    assert payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == "3782 822463 91304"


# Generated at 2022-06-12 02:22:12.600446
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=1)
    credit_card_number = payment.credit_card_number()
    assert (credit_card_number == "4444 4445 1423 7648")

# Generated at 2022-06-12 02:22:20.273972
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4539 0437 4034 9058'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5570 6077 1550 7796'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3718 598813 96819'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3440 017359 58591'


# Generated at 2022-06-12 02:22:26.211223
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import re
    import random
    import string
    # Test when card_type = None
    # Create object Payment
    payment = Payment()
    # Test 10 times
    for i in range(10):
        c = payment.credit_card_number()
        # Check credit card number has 16 digits
        assert len(c) - c.count(' ') == 16


# Generated at 2022-06-12 02:22:32.446760
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=123)
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5406 5196 5306 3995'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3431 528985 30048'



# Generated at 2022-06-12 02:22:38.570911
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    c=Payment()
    assert c.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert c.credit_card_number(CardType.AMERICAN_EXPRESS) == '3759 771142 77987'
    assert c.credit_card_number().isdigit()
    assert len(c.credit_card_number()) == 16
    assert c.credit_card_number(CardType.VISA) != c.credit_card_number(CardType.VISA)

# Generated at 2022-06-12 02:22:46.187854
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    _payment = Payment()
    _credit_card_number = _payment.credit_card_number(CardType.MASTER_CARD)
    print(_credit_card_number)

# Generated at 2022-06-12 02:22:51.072139
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    print("------------------------- UNIT TESTING -------------------------")

    base = Payment()

    print("\nCredit card number (Visa)")
    print(base.credit_card_number())
    print("\nCredit card number (MasterCard)")
    print(base.credit_card_number(card_type=CardType.MASTER_CARD))

# Generated at 2022-06-12 02:23:00.736647
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""

    from mimesis.enums import CardType

    _payment = Payment()
    _card_number1 = _payment.credit_card_number()
    _card_number2 = _payment.credit_card_number(CardType.VISA)
    _card_number3 = _payment.credit_card_number(CardType.MASTER_CARD)
    _card_number4 = _payment.credit_card_number(CardType.AMERICAN_EXPRESS)

    assert _card_number1 in [_card_number2, _card_number3, _card_number4]
    assert len(_card_number1) == 19
    assert len(_card_number2) == 19
    assert len(_card_number3) == 19

# Generated at 2022-06-12 02:23:07.687198
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    PaymentTest = Payment()
    PaymentTest.credit_card_number('visa')
    PaymentTest.credit_card_number('master_card')
    PaymentTest.credit_card_number('american_express')
    try:
        PaymentTest.credit_card_number('bad_type')
    except NonEnumerableError:
        assert 1
    print('Test Passed')


# Generated at 2022-06-12 02:23:13.780602
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(seed = 0)
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == "3781 502713 08731"
    p = Payment(seed = 1)
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == "3491 607137 80968"
    p = Payment(seed = 0)
    assert p.credit_card_number(CardType.VISA) == "4834 952408 84192"
    p = Payment(seed = 1)
    assert p.credit_card_number(CardType.VISA) == "4986 267574 88639"
    p = Payment(seed = 0)
    assert p.credit_card_number(CardType.MASTER_CARD) == "5109 218868 61847"

# Generated at 2022-06-12 02:23:15.505965
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    mcc = p.credit_card_number(CardType.MASTER_CARD)
    print(mcc)


# Generated at 2022-06-12 02:23:18.292338
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    random.seed(0)
    assert luhn_checksum("4455 5299 1152 2450") == "4"
    assert luhn_checksum("4455 5299 1152 2454") == "8"


# Generated at 2022-06-12 02:23:25.142909
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    data = {}
    for card_type in CardType:
        count = 0
        while True:
            card_number = Payment().credit_card_number(card_type)
            if card_number in data and card_number.startswith(card_type.value):
                raise Exception('Credit card number {} is exist!'.format(card_number))
            else:
                data[card_number] = True
            count += 1
            if count >= 1000:
                break

# Generated at 2022-06-12 02:23:35.123726
# Unit test for method credit_card_number of class Payment

# Generated at 2022-06-12 02:23:40.282750
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pay = Payment()
    result1 = pay.credit_card_number(card_type=CardType.VISA)
    result2 = pay.credit_card_number(card_type=CardType.MASTER_CARD)
    result3 = pay.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    print(result1)
    print(result2)
    print(result3)

if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:24:00.004081
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import mimesis
    import mimesis.enums
    payment = mimesis.Payment("en")
    # unit test for "CardType.VISA"
    payment.random.seed(0)
    assert payment.credit_card_number(card_type=mimesis.enums.CardType.VISA) == '4455 5299 1152 2450'
    # unit test for "CardType.MASTER_CARD"
    payment.random.seed(1)
    assert payment.credit_card_number(card_type=mimesis.enums.CardType.MASTER_CARD) == '5491 1949 9502 0473'
    # unit test for "CardType.AMERICAN_EXPRESS"
    payment.random.seed(2)

# Generated at 2022-06-12 02:24:06.445958
# Unit test for method credit_card_number of class Payment

# Generated at 2022-06-12 02:24:11.164830
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    args = (None, )
    p = Payment()
    # print(p.credit_card_number(*args))
    assert isinstance(
        p.credit_card_number(), str
    )
    assert p.credit_card_number().count(' ') == 3


# Generated at 2022-06-12 02:24:15.142654
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Tests for credit card number"""

    # Positive test for VISA
    assert Payment().credit_card_number(card_type=CardType.VISA) == '4455 5299 1152 2450'

    # Positive test for Master Card

# Generated at 2022-06-12 02:24:18.617892
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert re.match(r'^\d{4} \d{4} \d{4} \d{4}$', Payment().credit_card_number()) is not None


# Generated at 2022-06-12 02:24:23.752423
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment('en')
    print(payment.credit_card_number())
    print(payment.credit_card_number())
    print(payment.credit_card_number())
    print(payment.credit_card_number())
    print(payment.credit_card_number())
    print(payment.credit_card_number())
    print(payment.credit_card_number())

# Generated at 2022-06-12 02:24:26.041335
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    credit_card_number = p.credit_card_number()

    print(credit_card_number)


# Generated at 2022-06-12 02:24:29.971964
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print("\nTest method credit_card_number of class Payment:")
    p1 = Payment(seed_provider=None)
    for i in range(10):
        print("Card number:", p1.credit_card_number())


# Generated at 2022-06-12 02:24:32.286506
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(re.findall(r'\d{4}', payment.credit_card_number())) == 4

# Generated at 2022-06-12 02:24:40.273669
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pt = Payment(seed=123)
    assert pt.credit_card_number(card_type=CardType.MASTER_CARD) == '5174 4984 7226 5662'
    assert pt.credit_card_number(card_type=CardType.VISA) == '4555 5299 1152 2450'
    assert pt.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == '3700 0044 9023 114'
    assert pt.credit_card_number(card_type=CardType.DISCOVER) is None

# Generated at 2022-06-12 02:25:06.008289
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    P = Payment()
    assert P.credit_card_number() in [CardType.MASTER_CARD, CardType.VISA]

# Generated at 2022-06-12 02:25:10.743541
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    credit_card_number = Payment().CreditCard_number(card_type = CardType.VISA)
    assert payment.re.match(r'\d{4} \d{4} \d{4} \d{4}', credit_card_number) is not None, "credit card number. format is not correct!"

# Generated at 2022-06-12 02:25:16.058451
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment('en')
    assert len(p.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(p.credit_card_number(CardType.VISA)) == 19
    assert len(p.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert type(p.credit_card_number()) is str
    try:
        p.credit_card_number(CardType.DINERS_CLUB)
    except NonEnumerableError:
        pass

# Generated at 2022-06-12 02:25:25.869739
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import pandas as pd
    import numpy as np
    from mimesis.data import CREDIT_CARD_NETWORKS
    import re
    p = Payment()
    df = pd.DataFrame()
    df['type'] = p.random.choices(CREDIT_CARD_NETWORKS,
                               weights=[0.5, 0.25, 0.25],
                               k=5000)
    df['ccn'] = df.type.apply(lambda x: p.credit_card_number(x))
    df['length'] = df.ccn.apply(lambda x: len(x))
    regex = re.compile(r'(\d{4})(\d{4})(\d{4})(\d{4})')

# Generated at 2022-06-12 02:25:28.578733
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match(r'\d+ \d+ \d+ \d+', p.credit_card_number())


# Generated at 2022-06-12 02:25:38.240549
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    a = Payment(seed=1234567890)
    a.credit_card_number(CardType.AMERICAN_EXPRESS)
    a.credit_card_number(CardType.MASTER_CARD)
    a.credit_card_number(CardType.VISA)
    a.credit_card_number()
    print(a.cvv())
    print(a.credit_card_expiration_date())
    print(a.eth_address_validator())

    a.credit_card_owner(Gender.MALE)
    a.credit_card_owner(Gender.FEMALE)
    a.credit_card_owner(Gender.MALE)
    a.credit_card_owner(Gender.FEMALE)
    a.credit_card_owner(Gender.MALE)
    a.credit_card_

# Generated at 2022-06-12 02:25:43.368528
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card_number = p.credit_card_number(CardType.VISA)
    pattern = re.compile(r'\b\d{4}\s?\d{4}\s?\d{4}\s?\d{4}\b')
    assert pattern.match(card_number)



# Generated at 2022-06-12 02:25:46.639963
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number(CardType.VISA))
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-12 02:25:48.366188
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    number = payment.credit_card_number()

    assert isinstance(number, str)
    assert len(number) == 19

# Generated at 2022-06-12 02:25:49.780137
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment('en')
    number = p.credit_card_number()
    print(number)
