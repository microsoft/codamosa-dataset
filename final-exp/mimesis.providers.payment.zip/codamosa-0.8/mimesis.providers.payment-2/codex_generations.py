

# Generated at 2022-06-12 02:21:38.696355
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    _p = Payment()
    print('First Run :')
    print(_p.credit_card_number())
    print('Second Run :')
    print(_p.credit_card_number())


# Generated at 2022-06-12 02:21:45.948496
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment(seed=0)
    assert provider.credit_card_number(CardType.VISA) == '4497 0913 7398 2084'
    assert provider.credit_card_number(CardType.MASTER_CARD) == '5281 2913 5145 9442'
    assert provider.credit_card_number(CardType.AMERICAN_EXPRESS) == '3409 176837 74932'


# Generated at 2022-06-12 02:21:56.555344
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test the method credit_card_number for a card type supported by
    # this method.
    p = Payment()
    # Visa card
    card_type = "Visa"
    card_number = p.credit_card_number(card_type=card_type)
    assert(card_type in card_number)
    # MasterCard card
    card_type = "MasterCard"
    card_number = p.credit_card_number(card_type=card_type)
    assert(card_type in card_number)
    # American Express card
    card_type = "American Express"
    card_number = p.credit_card_number(card_type=card_type)
    assert(card_type in card_number)

# Generated at 2022-06-12 02:22:03.661172
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print("Testing Payment.credit_card_number")

    payment = Payment(seed=1)
    cardVisa = payment.credit_card_number(CardType.VISA)
    cardMasterCard = payment.credit_card_number(CardType.MASTER_CARD)
    cardAmericanExpress = payment.credit_card_number(CardType.AMERICAN_EXPRESS)

    assert cardVisa == '4539 3374 4594 7115'
    assert cardMasterCard == '2224 3531 6243 8153'
    assert cardAmericanExpress == '3775 568691 17187'

    print("Done")

# Generated at 2022-06-12 02:22:11.381039
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_num = Payment('en').credit_card_number(CardType.MASTER_CARD)
    print(card_num)
    pattern_obj = re.compile(r'^(5[1-5][0-9]{14}|222100[0-9]{12}|2221[1-9][0-9]{12}|2720[0-9]{12})$')
    assert pattern_obj.match(card_num.replace(' ', ''))

# Generated at 2022-06-12 02:22:13.053623
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment.credit_card_number()
    return 0

# Generated at 2022-06-12 02:22:16.445501
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(card_type=CardType.MASTER_CARD))


# Generated at 2022-06-12 02:22:19.690029
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test random number of credit card."""
    payment = Payment()
    c_card = payment.credit_card_number(CardType.VISA)
    assert len(c_card.split()) == 4

# Generated at 2022-06-12 02:22:25.224341
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    a = Payment('en')
    test_dict = {}
    for _ in range(50):
        temp_str = a.credit_card_number()
        test_dict[temp_str] = test_dict.get(temp_str, 0) + 1
    for _ in test_dict.values():
        assert(_ == 1)

# Generated at 2022-06-12 02:22:32.709897
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    obj = Payment()
    card_type = CardType.VISA
    credit_card_number = obj.credit_card_number(card_type)
    regex = re.compile(r'(\d{4})(\d{4})(\d{4})(\d{4})')
    str_num = ''.join(regex.search(credit_card_number).groups())
    assert str_num[0] == '4'
    assert luhn_checksum(str_num) == '0'


# Generated at 2022-06-12 02:22:41.614140
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Does this function work?
    Payment().credit_card_number()

# Generated at 2022-06-12 02:22:44.053507
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    assert re.match('[0-9]{16}', Payment().credit_card_number())



# Generated at 2022-06-12 02:22:52.983418
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Tests for method credit_card_number of class Payment
    # List of card_types
    card_type = [CardType.VISA,
                 CardType.MASTER_CARD,
                 CardType.AMERICAN_EXPRESS,
                 ]
    # Testing method
    for card_type_i in card_type:
        p = Payment(seed=1)
        assert p.credit_card_number(card_type_i) == '4555 5299 1152 2450'
        assert p.credit_card_number(card_type_i) != '4555 5299 1152 2451'
        
        for i in range(100):
            assert len(p.credit_card_number(card_type_i)) == 19

# Generated at 2022-06-12 02:22:56.003258
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Invalid gender
    card_type = 'invalid'
    assert Payment().credit_card_number(card_type) is None

# Generated at 2022-06-12 02:23:02.078047
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Set up the Payment object
    provider = Payment()
    # Testing
    result = provider.credit_card_number()
    # Verification
    assert isinstance(result, str)
    assert len(result) == 19
    result_split = result.split(' ')
    assert len(result_split) == 4

#Unit test for method credit_card_owner of class Payment

# Generated at 2022-06-12 02:23:10.278712
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Create a Payment object
    payment = Payment(random=0)

    # Test the function credit_card_number
    assert payment.credit_card_number() == '4090 1279 1010 6651'
    assert payment.credit_card_number(card_type=CardType.MASTER_CARD) == '5333 0842 6425 7457'
    assert payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == '3433 722111 54960'


# Generated at 2022-06-12 02:23:17.105304
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    int_to_card_type = {
        0: CardType.VISA,
        1: CardType.MASTER_CARD,
        2: CardType.AMERICAN_EXPRESS,
    }
    payment = Payment()
    for i in range(3):
        card_type = int_to_card_type[i]
        credit_card_number = payment.credit_card_number(card_type)
        print(credit_card_number)
        assert isinstance(credit_card_number, str) == True

# Generated at 2022-06-12 02:23:18.850841
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment_test = Payment()
    assert Payment_test.credit_card_number() == "4552 5244 8324 2435"


# Generated at 2022-06-12 02:23:23.552231
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for credit_card_number method."""
    payment = Payment()
    card_number = payment.credit_card_number(card_type='visa')
    number = card_number.replace(' ', '')
    assert payment.validate_card_number(number) is True



# Generated at 2022-06-12 02:23:34.384042
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    for _ in range(100):
        card_type = payment.random.choice(CardType)
        card_number = payment.credit_card_number(card_type)
        card_number = card_number.replace(' ', '')

        if card_type is CardType.VISA:
            assert card_number[0] == '4'
            assert len(card_number) == 16

        elif card_type is CardType.MASTER_CARD:
            assert card_number[:2] in ['22', '51']
            assert len(card_number) == 16

        elif card_type is CardType.AMERICAN_EXPRESS:
            assert card_number[:2] in ['34', '37']
            assert len(card_number) == 15


# Generated at 2022-06-12 02:23:58.370493
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment

    def test_card_num(target, card_type: CardType):
        payload = Payment()
        result = payload.credit_card_number(card_type)
        assert target == result

    test_card_num('4455 5299 1152 2450', CardType.VISA)
    test_card_num('4455 5299 1152 2450', None)
    test_card_num('5100 0799 7101 5046', CardType.MASTER_CARD)
    test_card_num('2256 7097 5090 4282', CardType.MASTER_CARD)
    test_card_num('3450 8259 3134 597', CardType.AMERICAN_EXPRESS)
    test_card_num

# Generated at 2022-06-12 02:24:05.964859
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import types
    import unittest

    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment


    class PaymentTestCase(unittest.TestCase):

        def setUp(self) -> None:
            self.payment = Payment(seed=0)

        def test_credit_card_number(self) -> None:
            self.assertTrue(
                isinstance(self.payment.credit_card_number(), str))
            self.assertTrue(
                isinstance(self.payment.credit_card_number(None), str))
            self.assertTrue(isinstance(
                self.payment.credit_card_number(CardType.VISA), str))

# Generated at 2022-06-12 02:24:13.928026
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    s = Payment(seed=2)
    assert (s.credit_card_number() == "4455 5299 1152 2450")
    assert (s.credit_card_number(CardType.Master_Card) == "5183 8765 0489 1374")
    assert (s.credit_card_number(CardType.American_Express) == "3748 162831 02699")
    try:
        assert (s.credit_card_number(CardType.Maestro))
    except NonEnumerableError:
        assert True


# Generated at 2022-06-12 02:24:17.510715
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert (card_number.startswith('4'))
    assert (len(card_number) == 16)

# Generated at 2022-06-12 02:24:25.538369
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    # Get instance of class Payment
    payment = Payment()
    # Compare the length of the credit card number
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number(CardType.VISA)) == 19
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.DISCOVER)) == 19
    # To check that the credit card number is valid. (We pass the validator only the first 14 digits of the credit card)
    assert luhn_checksum(payment.credit_card_number(CardType.AMERICAN_EXPRESS)[0:16]) == payment.credit_card

# Generated at 2022-06-12 02:24:36.413981
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert luhn_checksum(card_number.replace(" ", "")) == 0
    assert card_number == payment.credit_card_number(CardType.VISA)
    card_number = payment.credit_card_number(CardType.MASTER_CARD)
    assert card_number[0] != '3'
    assert len(card_number) == 16
    card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(card_number) == 15
    assert card_number[:2] == '34'
    assert payment.credit_card_number(CardType.UNIONPAY) is None


# Generated at 2022-06-12 02:24:44.149237
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # test_Payment = Payment()
    # temp_string = test_Payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    # assert temp_string[0:2] == '34' or temp_string[0:2] == '37'
    # assert temp_string.find(' ') != -1
    # assert len(temp_string) == 16
    # assert temp_string.count(' ') == 3
    # print(f'temp_string : {temp_string}')
    pass



# Generated at 2022-06-12 02:24:53.245604
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    # Test for method credit_card_number
    for _ in range(10):
        card_type = p.random.choice(['MasterCard', 'VISA', 'AmericanExpress'])
        result = p.credit_card_number(card_type)
        if card_type == 'VISA':
            assert result[0:1] == '4'
        if card_type == 'MasterCard':
            assert (5500 >= int(result[0:2]) >= 2221) or (2221 >= int(result[0:2]) >= 5100)
        if card_type == 'AmericanExpress':
            assert (37 >= int(result[0:2]) >= 34)

# Generated at 2022-06-12 02:25:04.943899
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    from mimesis.enums import CardType
    from mimesis.exceptions import NonEnumerableError
    payment = Payment()
    payment.seed(1)
    card_numbers = [payment.credit_card_number(), payment.credit_card_number(
        card_type=CardType.VISA), payment.credit_card_number(
        card_type=CardType.AMERICAN_EXPRESS), payment.credit_card_number(
            card_type=CardType.MASTER_CARD)]

    assert card_numbers == [
        '4824 8294 3548 5462',
        '4416 1591 6369 1315',
        '3717 0652 9778 516',
        '5378 5365 3451 8985',
    ]

# Generated at 2022-06-12 02:25:08.668626
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    assert len(Payment().credit_card_number()) == 19, 'The length of credit_card_number is not 19'


# Generated at 2022-06-12 02:25:43.772427
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    ccn = payment.credit_card_number()
    assert len(ccn) == 19
    assert ccn[0] == '4'
    assert ccn[1] == ' '

# Generated at 2022-06-12 02:25:45.703742
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    fake = Payment()
    print("Testing method credit_card_number:")
    print("\t", "Result:", fake.credit_card_number())

# Generated at 2022-06-12 02:25:48.925911
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    v = Payment()
    credit_card_master_card = v.credit_card_number(CardType.MASTER_CARD)
    print(credit_card_master_card)


# Generated at 2022-06-12 02:25:58.911885
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Create a instance of class Payment
    p = Payment('en')

    # Generate a random credit card number
    c_visa = p.credit_card_number(CardType.VISA)
    c_master_card = p.credit_card_number(CardType.MASTER_CARD)
    c_american_express = p.credit_card_number(CardType.AMERICAN_EXPRESS)

    list_visa = [str(c)[:1] for c in c_visa.split(' ')]
    list_master_card = [str(c)[:2] for c in c_master_card.split(' ')]
    list_american_express = [str(c)[:2] for c in c_american_express.split(' ')]


# Generated at 2022-06-12 02:26:06.400857
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=1)
    # 4455 5299 1152 2450
    assert payment.credit_card_number(CardType.VISA) == "4455 5299 1152 2450"
    # 5492 8101 7335 8596
    assert payment.credit_card_number(CardType.MASTER_CARD) == "5492 8101 7335 8596"
    # 3402 391186 43049
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == "3402 391186 43049"



# Generated at 2022-06-12 02:26:09.774355
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    result = Payment().credit_card_number(CardType.MASTER_CARD)
    print('Result for method credit_card_number is: ', result)
    assert result is not None


# Generated at 2022-06-12 02:26:16.966649
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test_Payment = Payment()
    # Visa
    test_string = test_Payment.credit_card_number(CardType.VISA)
    assert test_string[:1] == '4'
    assert len(test_string) == 19
    # Master
    test_string = test_Payment.credit_card_number(CardType.MASTER_CARD)
    assert test_string[:2] == '51' or test_string[:2] == '22'
    assert len(test_string) == 18
    # Amex
    test_string = test_Payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert test_string[:2] == '34' or test_string[:2] == '37'
    assert len(test_string) == 17
    #

# Generated at 2022-06-12 02:26:20.855542
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment(seed=1234)
    card_type = CardType.MASTER_CARD
    card_number = provider.credit_card_number(card_type)
    assert card_number == '5407 9380 7092 8932'


# Generated at 2022-06-12 02:26:26.257080
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number(card_type=CardType.VISA) == "4455 5299 1152 2450"
    assert Payment().credit_card_number(card_type=CardType.MASTER_CARD) == "5100 0582 6174 5134"
    assert Payment().credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == "3713 1764 9163 042"


# Generated at 2022-06-12 02:26:28.870027
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment("en")
    res = p.credit_card_number()
    assert(res != p.credit_card_number())

# Generated at 2022-06-12 02:27:36.322207
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = payment.random.choice(list(CardType))
    num = payment.credit_card_number(card_type)
    # print(num)
    if(card_type == CardType.VISA):
        assert num[0]=='4'
    elif(card_type == CardType.MASTER_CARD):
        assert num[0]=='5'
    elif(card_type == CardType.AMERICAN_EXPRESS):
        assert num[0:2]=='37'


# Generated at 2022-06-12 02:27:38.821869
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number())

# Generated at 2022-06-12 02:27:41.576978
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-12 02:27:44.453548
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p=Payment()
    a = p.credit_card_number()
    print(a)
test_Payment_credit_card_number()

# Generated at 2022-06-12 02:27:53.155563
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment1 = Payment('en')
    # MasterCard
    assert payment1.credit_card_number(CardType.MASTER_CARD) == "5271 0067 0622 5264"
    # MasterCard
    assert payment1.credit_card_number(CardType.MASTER_CARD) == "5482 2946 0442 0920"
    # MasterCard
    assert payment1.credit_card_number(CardType.MASTER_CARD) == "5399 7735 5241 3163"
    # MasterCard
    assert payment1.credit_card_number(CardType.MASTER_CARD) == "5188 6863 9987 8168"
    # American Express
    assert payment1.credit_card_number(CardType.AMERICAN_EXPRESS) == "3419 162394 90235"
    # American Express

# Generated at 2022-06-12 02:27:55.174165
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=456)
    assert payment.credit_card_number() == '4477 2187 6194 8200'

# Generated at 2022-06-12 02:27:58.991919
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for _ in range(1000):
        assert re.search(r'^(4\d{3}|5[1-5]\d{2})(\d{4})', Payment().credit_card_number())


# Generated at 2022-06-12 02:28:04.228617
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number(): #convert this to a unit test
    payment: Payment = Payment()
    print(payment.credit_card_number(CardType.VISA))
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))

if __name__ == "__main__":
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:28:07.678850
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    print(p.credit_card_number())


# Generated at 2022-06-12 02:28:10.605074
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()

    assert len(credit_card_number) == 19
    assert credit_card_number[0] in ['4', '5']
    assert credit_card_number[5] == ' '