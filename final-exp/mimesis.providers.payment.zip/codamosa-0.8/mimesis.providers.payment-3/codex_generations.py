

# Generated at 2022-06-12 02:21:38.543916
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for _ in range(10):
        assert re.match(r'\d{4}\s{1}\d{4}\s{1}\d{4}\s{1}\d{4}', Payment().credit_card_number())

# Generated at 2022-06-12 02:21:50.742388
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed = 777)
    payment.random.seed(777)

    # Test random
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    payment.random.seed(777)
    assert payment.credit_card_number() == '4455 5299 1152 2450'

    # Test custom card type
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0955 2269 5161'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3417 3737 7261 532'



# Generated at 2022-06-12 02:22:00.734310
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    card_number = Payment().credit_card_number(CardType.VISA)
    assert re.match(r'4\d{3}\s\d{4}\s\d{4}\s\d{4}', card_number) is not None

    card_number = Payment().credit_card_number(CardType.MASTER_CARD)
    assert re.match(r'5[1-5]\d{2}\s\d{4}\s\d{4}\s\d{4}',
                    card_number) is not None

# Generated at 2022-06-12 02:22:04.971529
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=42)
    cardVisa = payment.credit_card_number(CardType.VISA)
    assert cardVisa == '4594 4976 5795 2533'
    cardMastercard = payment.credit_card_number(CardType.MASTER_CARD)
    assert cardMastercard == '5288 9473 3238 4950'
    cardAmericanExpress = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert cardAmericanExpress == '3427 552502 47935'

# Generated at 2022-06-12 02:22:06.930602
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.random import Random

    random = Random()

    i = 0
    for card_type in CardType:
        for _ in range(10):
            Payment(random=random, seed=i).credit_card_number(card_type)
            i += 1

# Generated at 2022-06-12 02:22:09.680487
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import re
    credit_card_number = Payment.credit_card_number(CardType.VISA)
    assert re.match(r'\d{16}', credit_card_number)

# Generated at 2022-06-12 02:22:21.573365
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import string
    import re

    p = Payment()

    for _ in range(1000):
        card_type = get_random_item(CardType, rnd=p.random)
        if card_type == CardType.VISA:
            number = p.random.randint(4000, 4999)
        elif card_type == CardType.MASTER_CARD:
            number = p.random.choice([
                p.random.randint(2221, 2720),
                p.random.randint(5100, 5599),
            ])
        elif card_type == CardType.AMERICAN_EXPRESS:
            number = p.random.choice([34, 37])
        str_num = str(number)


# Generated at 2022-06-12 02:22:23.882698
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print("Test Payment.credit_card_number")
    card_number = Payment().credit_card_number()
    assert isinstance(card_number, str)

# Generated at 2022-06-12 02:22:32.677120
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    number_of_tests = 100
    for _ in range(number_of_tests):
        payment = Payment()
        card_number = payment.credit_card_number()
        assert len(card_number) == 19

        total = 0
        for i in range(len(card_number) - 1, -1, -1):
            if card_number[i] != ' ':
                total += int(card_number[i])

                if (len(card_number) - i) % 2 == 0:
                    total += int(card_number[i])

        assert total % 10 == 0


# Generated at 2022-06-12 02:22:41.869550
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    assert re.search(
        r'^4\d{15}$',
        payment.credit_card_number(card_type=CardType.VISA)
    ) is not None

    assert re.search(
        r'^5[1-5]\d{14}$',
        payment.credit_card_number(card_type=CardType.MASTER_CARD)
    ) is not None

    assert re.search(
        r'^3[4,7]\d{13}$',
        payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    ) is not None

# Generated at 2022-06-12 02:22:54.721928
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    counter_1 = 0
    counter_2 = 0
    counter_3 = 0
    count = 10000
    for i in range(count):
        credit_card_number = payment.credit_card_number()
        # Credit card number should start with valid 4 first digits
        if credit_card_number.startswith("4"):
            counter_1 += 1
        if credit_card_number.startswith("2221") or credit_card_number.startswith("2720") \
                or credit_card_number.startswith("5100") or credit_card_number.startswith("5599"):
            # Credit card number should start with valid 4 first digits
            counter_2 += 1

# Generated at 2022-06-12 02:23:00.206818
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.random import Seed
    seed = Seed.create_seed()
    p = Payment(seed)
    card_number = p.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(card_number) == 18
    assert card_number[:2] in ('34', '37')
    assert card_number[0] != card_number[1]


# Generated at 2022-06-12 02:23:10.191072
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(card_type=CardType.VISA) in \
    ['4002 0086 2633 5806', '4596 1945 5458 4956']
    assert payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) in \
    ['3713 8176 34378', '3761 2583 43541']
    assert payment.credit_card_number(card_type=CardType.MASTER_CARD) in \
    ['2221 0069 2493 487', '2221 6912 9801 644']


# Generated at 2022-06-12 02:23:14.650622
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 16
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert payment.credit_card_number(CardType.VISA)
    assert payment.credit_card_number(CardType.MASTER_CARD)

# Generated at 2022-06-12 02:23:19.612040
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    # Test Visa
    assert payment.credit_card_number(CardType.VISA) == '4086 6442 3034 5478'
    # Test MasterCard
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5575 3042 9222 3869'
    # Test AmericanExpress
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 78563'


# Generated at 2022-06-12 02:23:24.044639
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment."""
    payment = Payment()

    credit_card_number = payment.credit_card_number(CardType.VISA)

    assert credit_card_number.startswith('4')


# Generated at 2022-06-12 02:23:27.763911
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number(CardType.VISA) == "4581 1137 9494 9550"
        

# Generated at 2022-06-12 02:23:28.916788
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment().credit_card_number()

# Generated at 2022-06-12 02:23:33.127508
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print("********************** Unit test for method credit_card_number of class Payment **********************")
    card_type = CardType.AMERICAN_EXPRESS
    payment = Payment()
    print("The credit card number: ", payment.credit_card_number(card_type))
    return "Done!"


# Generated at 2022-06-12 02:23:36.289216
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    number = payment.credit_card_number(card_type)
    assert card_type.value in number
    assert len(number) == 16


# Generated at 2022-06-12 02:23:49.490310
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    for card_type in CardType:  # type: ignore
        for _ in range(100):
            credit_card = p.credit_card_number(card_type)
            assert credit_card.isdigit(), "credit_card_number should be a number. Got: {}".format(credit_card)

# Generated at 2022-06-12 02:23:57.545383
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(20):
        card_number = Payment().credit_card_number(CardType.VISA)
        print(card_number)
        assert card_number != None
    for i in range(20):
        card_number = Payment().credit_card_number(CardType.MASTER_CARD)
        print(card_number)
        assert card_number != None
    for i in range(20):
        card_number = Payment().credit_card_number(CardType.AMERICAN_EXPRESS)
        print(card_number)
        assert card_number != None



# Generated at 2022-06-12 02:23:59.926465
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment()
    assert len(str(provider.credit_card_number())) == 19
    

# Generated at 2022-06-12 02:24:01.748325
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    for i in range(100):
        print(p.credit_card_number())


# Generated at 2022-06-12 02:24:06.388963
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    i = 0
    while i < 100:
        print(i, p.credit_card_number())
        i += 1
    print("i = ", i)


# Generated at 2022-06-12 02:24:14.949718
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    doc = """
    >>> payment = Payment('en')
    >>> payment.random.seed(9)
    >>> payment.credit_card_number()
    '4455 5299 1152 2450'
    >>> payment.credit_card_number(CardType.MASTER_CARD)
    '5135 6856 9674 5263'
    >>> payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    '3415 00693 50892'
    """
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)


# Generated at 2022-06-12 02:24:22.429839
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card = [
        Payment().credit_card_number(CardType.VISA),
        Payment().credit_card_number(CardType.MASTER_CARD),
        Payment().credit_card_number(CardType.AMERICAN_EXPRESS),
    ]
    assert card[0][0] == '4'
    assert card[0][-1] != '4'
    assert card[1][0] == '5'
    assert card[1][-1] != '4'
    assert card[2][0] == '3'

# Generated at 2022-06-12 02:24:24.195605
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():  
    result = Payment().credit_card_number()
    assert result.count(" ") == 3

# Generated at 2022-06-12 02:24:32.831265
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment().credit_card_number(CardType.VISA)
    Payment().credit_card_number(CardType.MASTER_CARD)
    Payment().credit_card_number(CardType.AMERICAN_EXPRESS)

    try:
        Payment().credit_card_number(CardType.JCB)
        assert False, "Should be raised"
    except NonEnumerableError as ex:
        assert isinstance(ex, NonEnumerableError)
        assert isinstance(ex, Exception)
        assert issubclass(ex.__class__, NonEnumerableError)
        assert issubclass(ex.__class__, Exception)

# Generated at 2022-06-12 02:24:36.098391
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
        payment = Payment('en', seed=0)
        card_number = payment.credit_card_number(card_type=CardType.VISA)
        assert card_number == '4455 5299 1152 2450'

# Generated at 2022-06-12 02:25:05.842732
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test method credit_card_number of class Payment."""
    # Test with default parameter.
    card = Payment().credit_card_number()
    assert re.match(r'^[0-9]{4}\s[0-9]{4}\s[0-9]{4}\s[0-9]{4}$', card) is not None

    # Test with CardType.AMERICAN_EXPRESS
    card = Payment().credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    assert re.match(r'^[0-9]{4}\s[0-9]{6}\s[0-9]{5}$', card) is not None

    # Test with CardType.VISA

# Generated at 2022-06-12 02:25:12.355284
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(card_type=CardType.VISA) == '4463 9372 7944 5135'
    assert payment.credit_card_number(card_type=CardType.MASTER_CARD) == '2255 3297 7381 1864'
    assert payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == '3309 131923 87415'

# Generated at 2022-06-12 02:25:16.252652
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS))
    print(payment.credit_card_number(card_type=CardType.MASTER_CARD))
    print(payment.credit_card_number(card_type=CardType.VISA))



# Generated at 2022-06-12 02:25:18.269325
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_number = Payment().credit_card_number()
    print(card_number)
    assert len(card_number) == 19


# Generated at 2022-06-12 02:25:25.993182
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    payment.seed(0)
    visa = payment.credit_card_number(CardType.VISA)
    assert visa == "4455 5299 1152 2450"

    amex = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert amex == "3411 07066 63359"

    mastercard = payment.credit_card_number(CardType.MASTER_CARD)
    assert mastercard == "5299 0720 9267 2450"


# Generated at 2022-06-12 02:25:32.709471
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Verify if method returns the correct value
    for any determined card type."""
    test_cardTypes = [CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]
    payment = Payment()
    for item in test_cardTypes:
        card = payment.credit_card_number(item)
        card_ = card.replace(" ", "")
        luhn_value = luhn_checksum(card_)
        assert card_[-1] == luhn_value

# Generated at 2022-06-12 02:25:43.333293
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import unittest
    from mimesis.enums import CardType
    from unittest import TestCase
    class PaymentTestCase(TestCase):
        def setUp(self):
            self.payment1 = Payment()
            self.payment2 = Payment('en')
            self.card_type = CardType.VISA
        def test_Payment_credit_card_number_1(self):
            credit_card_number = self.payment1.credit_card_number(self.card_type)
            if self.card_type == CardType.VISA:
                self.assertRegex(credit_card_number, r"^4\d{3}( |-)?\d{4}( |-)?\d{4}( |-)?\d{4}$")

# Generated at 2022-06-12 02:25:46.930035
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    result = payment.credit_card_number()
    test = re.search(r'(\d{4}\s\d{4}\s\d{4}\s\d{4})', result)
    assert (test.group() == result)



# Generated at 2022-06-12 02:25:56.141199
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment('en', seed=1)
    print(p.credit_card_number())
    print(p.credit_card_number(CardType.MASTER_CARD))
    print(p.credit_card_number(CardType.AMERICAN_EXPRESS))
    # print(p.credit_card_number(CardType.DINERS_CLUB))
    print(p.credit_card_number(CardType.DISCOVER))
    # print(p.credit_card_number(CardType.JCB))
    print(p.credit_card_number(CardType.VISA))


# Generated at 2022-06-12 02:26:02.199122
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    number = payment.credit_card_number(card_type=card_type)
    assert number[:len(card_type.value)] == card_type.value


if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:26:47.359493
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    card_type = CardType.VISA
    assert Payment().credit_card_number(card_type=card_type) == '4455 5299 1152 2450'
    print('Test completed!')


# Generated at 2022-06-12 02:26:57.333637
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    is_valid = [0, 0, 0]
    for _ in range(1000):
        number = Payment().credit_card_number()
        if Payment().credit_card_network() == 'Visa':
            is_valid[0] += 1
            assert re.match("^4[0-9]{3} ?[0-9]{4} ?[0-9]{4} ?[0-9]{4}$", number)
        elif Payment().credit_card_network() == 'MasterCard':
            is_valid[1] += 1
            assert re.match("^5[1-5][0-9]{2} ?[0-9]{4} ?[0-9]{4} ?[0-9]{4}$", number)

# Generated at 2022-06-12 02:27:05.217396
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Random provider with same seed
    provider = Payment(seed=1)
    assert provider.credit_card_number(CardType.VISA) == '4987 5640 5492 9347'
    assert provider.credit_card_number(CardType.MASTER_CARD) == '2233 9438 0246 1521'
    assert provider.credit_card_number(CardType.AMERICAN_EXPRESS) == '3778 778194 62414'

    provider.seed(1)
    assert provider.credit_card_number() == '4987 5640 5492 9347'
    assert provider.credit_card_number(CardType.MASTER_CARD) == '2233 9438 0246 1521'

# Generated at 2022-06-12 02:27:08.963411
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment()
    card_type = CardType.VISA
    result = provider.credit_card_number(card_type=card_type)
    assert isinstance(result, str)
    assert len(result) == 19
    assert card_type.value.lower() in result.lower()



# Generated at 2022-06-12 02:27:11.833459
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_number = "4556 0293 6279 1587"
    payment = Payment(seed=0)
    assert payment.credit_card_number(CardType.VISA) == card_number

# Generated at 2022-06-12 02:27:19.029377
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    this is a unit test for testing  method credit_card_number() of class Payment
    :return: return True if test is successful, return False if test is unsuccessful
    """
    provider = Payment()
    # it will generate random credit card number
    expected_result = provider.credit_card_number()

    # it will generate credit card number of specific type
    actual_result = provider.credit_card_number(CardType.VISA)
    # all credit card numbers have the same format ,the only difference is the provider
    check_result = re.match(expected_result, actual_result)
    if check_result:
        return True
    else:
        return False

# Generated at 2022-06-12 02:27:27.225260
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=796)
    assert (payment.credit_card_number() == '5693 0670 8722 2624')
    assert (payment.credit_card_number(CardType.VISA) == '4098 2373 2770 6619')
    assert (payment.credit_card_number(CardType.MASTER_CARD) == '5182 0507 0694 1812')
    assert(payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3469 586997 08972')

# Generated at 2022-06-12 02:27:33.387959
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    lists = []
    num = 100
    while num:
        lists.append(Payment().credit_card_number())
        num -= 1
    for items in lists:
        nums = items.replace(" ", "")
        assert len(nums) == 16 or len(nums) == 15
        assert int(nums[0]) == 4 or int(nums[0]) == 3 or int(nums[0]) == 5 or int(nums[0]) == 2


# Generated at 2022-06-12 02:27:35.244369
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test = Payment()
    for _ in range(5):
        print(test.credit_card_number())


# Generated at 2022-06-12 02:27:43.238582
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.typing import Enum
    from mimesis.exceptions import NonEnumerableError
    from mimesis.utils import is_valid_enum
    import pytest

    card_type = CardType.VISA
    payment = Payment()

    # First test: The credit card number is a string
    assert(isinstance(payment.credit_card_number(), str))
    # Second test: the credit card number has 16 digits and 4 groups of 4 digits
    # separated by spaces
    regex = re.compile(r'(\d{4})(\d{4})(\d{4})(\d{4})')
    assert(regex.search(payment.credit_card_number()))
    # Third test: when a CardType is passed, the number belongs to the