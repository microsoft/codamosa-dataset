

# Generated at 2022-06-12 02:21:44.033158
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(seed=100)
    p.random.choice = lambda seq: seq[1]
    p.random.randint = lambda num1, num2: 4444
    print(p.credit_card_number())
    # Output: 4444 4444 4444 4446
    p.random.choice = lambda seq: seq[2]
    print(p.credit_card_number())
    # Output: 2223 5167 5530 6815
    p.random.choice = lambda seq: seq[3]
    print(p.credit_card_number())
    # Output: 3741 5102 6834 605


# Generated at 2022-06-12 02:21:46.807294
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
	print("This is the test for method credit_card_number of class Payment")
	payment = Payment()
	print(payment.credit_card_number())


# Generated at 2022-06-12 02:21:50.848017
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    assert payment.credit_card_number(card_type=CardType.MASTER_CARD) == '5556 0241 0176 3669'


# Generated at 2022-06-12 02:21:54.193818
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number(card_type=None)
    # 5887623773817798
    print(credit_card_number)


# Generated at 2022-06-12 02:21:59.357861
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test function."""
    p = Payment(seed=12345)

    enum_test = [CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]

    for item in enum_test:
        print (p.credit_card_number(item))
        print (p.credit_card_number(item))
        print (p.credit_card_number(item))


# Generated at 2022-06-12 02:22:01.635633
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    for _ in range(0, 100):
        assert p.credit_card_number() != p.credit_card_number()


# Generated at 2022-06-12 02:22:08.797565
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    country_payment = Payment('en')
    master_card = country_payment.credit_card_number(CardType.MASTER_CARD)
    visa = country_payment.credit_card_number(CardType.VISA)
    american_express = country_payment.credit_card_number(
        CardType.AMERICAN_EXPRESS)
    assert len(master_card) == 19
    assert len(visa) == 19
    assert len(american_express) == 17

# Generated at 2022-06-12 02:22:20.700225
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    # Test default behavior
    # Default is VISA
    testPayment = Payment()
    creditCardNumber = testPayment.credit_card_number()
    assert type(creditCardNumber) == str
    assert re.match("\d{4} \d{4} \d{4} \d{4}", creditCardNumber) != None

    # Test VISA
    creditCardNumber = testPayment.credit_card_number(CardType.VISA)
    assert type(creditCardNumber) == str
    assert re.match("\d{4} \d{4} \d{4} \d{4}", creditCardNumber) != None

    # Test Master Card
    creditCardNumber = testPayment.credit_card_number(CardType.MASTER_CARD)
    assert type(creditCardNumber) == str

# Generated at 2022-06-12 02:22:23.005920
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    assert re.match(r'\d{16}', payment.credit_card_number())
    

# Generated at 2022-06-12 02:22:33.927937
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type_list = CardType.__members__.values()
    payment_provider = Payment(random_data=False)
    # test without card type
    credit_card_number_without_type = payment_provider.credit_card_number()
    assert len(credit_card_number_without_type) == 19
    for card_type in card_type_list:
        payment_provider.random_data = False
        credit_card_number = payment_provider.credit_card_number(card_type=card_type)
        if card_type.name == 'VISA':
            assert len(credit_card_number) == 19
            assert credit_card_number[0:4] == '4'

# Generated at 2022-06-12 02:22:52.955884
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test: Verify if credit card is valid."""
    dni = Payment()
    # VISA = 'VISA'
    # MASTER_CARD = 'MASTERCARD'
    # AMERICAN_EXPRESS = 'AMERICANEXPRESS'
    card_type = CardType.VISA
    credit_card_number = dni.credit_card_number(card_type)

    # Credit card number: 5449 0732 9623 2128
    if card_type == CardType.VISA:
        assert re.search(r"^4[0-9]{3}(\s?[0-9]{4}){3}$", credit_card_number) is not None

# Generated at 2022-06-12 02:23:01.649875
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """ Unit test for method credit_card_number of class Payment. """
    from mimesis.enums import CardType
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import Seed

    # Initialize a Payment provider with a seed
    seed = Seed(1)
    payment = Payment(seed=seed)

    # Test an exception
    try:
        # If card_type is not supported,it will raise an exception
        payment.credit_card_number(CardType.DISCOVER)
    except NonEnumerableError:
        assert True
        pass

    # Test with card_type is VISA, MASTER_CARD, and AMERICAN_EXPRESS
    # If the result is correct, the credit_card_number is valid and the
    # result is correct.
    assert payment.credit_card_

# Generated at 2022-06-12 02:23:05.085684
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card = Payment()
    num = card.credit_card_number(CardType.VISA)
    assert num[:1] == '4'


# Generated at 2022-06-12 02:23:06.694062
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    print(payment.credit_card_number())

# Generated at 2022-06-12 02:23:17.308772
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test generating random credit card number:
    # * card type is not specified
    # * card type is specified
    payment = Payment()
    # card type is not specified
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}',
                    payment.credit_card_number())
    # card type is specified
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}',
                    payment.credit_card_number(CardType.VISA))
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}',
                    payment.credit_card_number(CardType.MASTER_CARD))

# Generated at 2022-06-12 02:23:23.450748
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Initialize the Payment object
    Payment_obj = Payment()

    # Get a random credit card number with length of 16 digits
    credit_card_number = Payment_obj.credit_card_number()

    print(credit_card_number)

    # Get a specific credit card number with length of 16 digits
    credit_card_number = Payment_obj.credit_card_number(CardType.VISA)

    print(credit_card_number)


# Generated at 2022-06-12 02:23:29.835897
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment1 = Payment(seed=42)
    payment2 = Payment(seed=42)
    assert(payment1.credit_card_number() == "4218 4970 5598 8319")
    assert(payment2.credit_card_number() == "4218 4970 5598 8319")

if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:23:36.270076
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for i in range(10):
        list_ = []
        list_ = payment.credit_card_number(CardType.VISA)
        assert ' ' not in list_
        assert re.match(r'\d{16}$', list_)

        list_ = payment.credit_card_number(CardType.MASTER_CARD)
        assert ' ' not in list_
        assert re.match(r'\d{16}$', list_)

        list_ = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
        assert ' ' not in list_
        assert re.match(r'\d{15}$', list_)


# Generated at 2022-06-12 02:23:39.515564
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(seed=4)
    for i in range(10):
        assert p.credit_card_number() == '4455 5299 1152 2450'

# Generated at 2022-06-12 02:23:42.214020
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment().credit_card_number(CardType.VISA)
    Payment().credit_card_number(CardType.MASTER_CARD)
    Payment().credit_card_number(CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-12 02:24:06.902529
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    scenario_1 = {'CardType': CardType.VISA, 'length': 16, 'start_with': 4000}
    scenario_2 = {'CardType': CardType.MASTER_CARD, 'length': 16, 'start_with': 2221}
    scenario_3 = {'CardType': CardType.AMERICAN_EXPRESS, 'length': 15, 'start_with': 34}

    for scenario in [scenario_1, scenario_2, scenario_3]:
        payment = Payment()
        credit_card_number = payment.credit_card_number(scenario['CardType'])
        assert len(credit_card_number) == scenario['length']
        assert credit_card_number[0:scenario['length']-3].startswith(str(scenario['start_with']))

# Generated at 2022-06-12 02:24:13.902390
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(language='en')

    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(card_type=CardType.VISA)) == 19
    assert len(payment.credit_card_number(card_type=CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)) == 17

# Generated at 2022-06-12 02:24:18.460091
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print("MasterCard:" + payment.credit_card_number())
    print("Visa:" + payment.credit_card_number(CardType.VISA))
    print("American Express:" + payment.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-12 02:24:20.996315
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=42)
    assert payment.credit_card_number(CardType.VISA) == '4556 3129 2226 8368'

# Generated at 2022-06-12 02:24:31.735174
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """In unitary test we check the validity of the credit_card_number method
    of the Payment class.

    Test description:

    1. Tested method: credit_card_number()

    2. Preconditions:
    2.1. The number of expected results is: 5 000
    2.2. The card type is: VISA

    3. Test target:
    3.1. We check the correctness of the results.

    4. Expected result:
    4.1. The results are correct.
    """
    payment = Payment('en')
    count = 0
    while count < 5000:
        number = payment.credit_card_number(card_type=CardType.VISA)
        number = number.replace(" ", "")
        if (number[0] in ['4'] and len(number) == 16):
            count

# Generated at 2022-06-12 02:24:38.437299
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    for i in range(100):
        print(p.credit_card_number())
        print(p.credit_card_number(CardType.MASTER_CARD))
        print(p.credit_card_number(CardType.AMERICAN_EXPRESS))
        print(p.credit_card_number(CardType.VISA))


if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:24:42.094567
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card_type = CardType.MASTER_CARD
    number = p.credit_card_number(card_type)
    assert card_type.value in number

# Generated at 2022-06-12 02:24:50.657949
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment.

    :return:
    """
    payment = Payment()
    for _ in range(1000):
        card_type = get_random_item(CardType, rnd=payment.random)
        num = payment.credit_card_number(card_type=card_type)
        if card_type == CardType.AMERICAN_EXPRESS:
            assert len(num.replace(' ', '')) == 15
        else:
            assert len(num.replace(' ', '')) == 16

# Generated at 2022-06-12 02:24:52.552104
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(0,10):
        print(Payment().credit_card_number())

# Generated at 2022-06-12 02:25:00.930539
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for card_type in CardType:
        obj = Payment()
        credit_card_number = obj.credit_card_number(card_type)
        if card_type == CardType.AMERICAN_EXPRESS:
            assert len(credit_card_number) == 17
            assert credit_card_number[:2] in ['34', '37']
        else:
            assert len(credit_card_number) == 19
            assert credit_card_number[0] == str(int(card_type))[-1]