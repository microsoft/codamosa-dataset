

# Generated at 2022-06-12 02:21:34.674656
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc = Payment().credit_card_number(CardType.AMERICAN_EXPRESS)
    assert re.search(r'^\d{4} \d{6} \d{5}$', cc) is not None

# Generated at 2022-06-12 02:21:43.054621
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment()
    card = provider.credit_card_number()
    print(card)
    digits = card.replace(' ', '')

    # Test that string consists of 16 digits
    assert len(digits) == 16, 'Length should be 16, but is {}'.format(len(digits))

    # Test that all characters are digits
    for digit in digits:
        assert digit.isdigit(), 'All characters should be digits, but got {}'.format(digit)

    # Test that card number passes the Luhn algorithm
    assert int(digits[15]) == luhn_checksum(digits[:-1]), 'Card number fails Luhn algorithm'

# Generated at 2022-06-12 02:21:49.104127
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    f = Payment(seed=1)
    print(f.credit_card_number(CardType.MASTER_CARD))
    print(f.credit_card_number(CardType.VISA))
    print(f.credit_card_number(CardType.AMERICAN_EXPRESS))

# call to the unit test
# test_Payment_credit_card_number()

# Generated at 2022-06-12 02:21:54.203849
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=1234567)
    assert payment.credit_card_number(CardType.VISA) == '4421 5155 3132 1014'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5199 5177 0396 4510'


# Generated at 2022-06-12 02:21:58.807308
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number(CardType.VISA) == '4554 3627 0443 5029'
    assert Payment().credit_card_number(CardType.MASTER_CARD) == '5412 8527 0589 1015'
    assert Payment().credit_card_number(CardType.AMERICAN_EXPRESS) == '3717 148431 05844'

# Generated at 2022-06-12 02:22:02.199857
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    from mimesis.enums import CardType

    payment = Payment(seed=12345)
    assert payment.credit_card_number(
        card_type=CardType.VISA) == '4955 1469 6271 8674'

# Generated at 2022-06-12 02:22:04.655711
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert isinstance(card_number, str)

# Generated at 2022-06-12 02:22:09.627898
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(seed = 78)
    # if we need to get the credit card number of specific card
    print(p.credit_card_number(CardType.MASTER_CARD))
    # if we need to get random credit card number
    print(p.credit_card_number())
    assert True

# Generated at 2022-06-12 02:22:14.479545
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    '''
    Unit test for method credit_card_number of class Payment
    '''
    _payment = Payment(random=True)
    # test VISA
    assert _payment.credit_card_number(card_type=CardType.VISA) == '4012 8051 7954 6390'
    # test MasterCard
    assert _payment.credit_card_number(card_type=CardType.MASTER_CARD) == '5587 6519 9185 3599'
    # test AmericanExpress
    assert _payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == '3700 6289787 87'
    # test CardType.DinersClub

# Generated at 2022-06-12 02:22:20.275067
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    print(p.credit_card_number(CardType.VISA))   # 4455 5299 1152 2450
    print(p.credit_card_number(CardType.MASTER_CARD))   # 5461 6122 8805 8251
    print(p.credit_card_number(CardType.AMERICAN_EXPRESS))   # 3729 509757 51457

# Generated at 2022-06-12 02:22:33.229369
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    x = Payment("en")
    for i in range(10):
        print(x.credit_card_number())
# >>> 4455 5299 1152 2450
# >>> 4579 0567 2432 4555
# >>> 4579 0567 2432 4555
# >>> 4579 0567 2432 4555
# >>> 4579 0567 2432 4555
# >>> 4579 0567 2432 4555
# >>> 4579 0567 2432 4555
# >>> 4579 0567 2432 4555
# >>> 4579 0567 2432 4555
# >>> 4579 0567 2432 4555


# Generated at 2022-06-12 02:22:42.598876
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    # Create a random card type
    card_type = get_random_item(CardType)
    # Get the first digit of the card type
    card_type_str = card_type.name
    # Generate a random 16-digit credit card number based on card type 
    credit_card_number = payment.credit_card_number(card_type)
    # Get the first digit of the credit card number
    first_digit = int(credit_card_number[0])
    # Compare the first digit of the card type with that of the credit card number to see if they match 
    assert int(card_type_str[0]) == first_digit
    

# Generated at 2022-06-12 02:22:47.461140
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pc = Payment()

    print(pc.credit_card_number())
    print(pc.credit_card_number(CardType.VISA))
    print(pc.credit_card_number(CardType.MASTER_CARD))
    print(pc.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-12 02:22:53.763109
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test function credit_card_number of class Payment."""
    assert Payment().credit_card_number(CardType.VISA) == '4000 8585 5361 9245'
    assert Payment().credit_card_number(CardType.MASTER_CARD) == '5256 8169 4173 0365'
    assert Payment().credit_card_number(CardType.AMERICAN_EXPRESS) == '3785 995931 54382'

# Generated at 2022-06-12 02:22:55.194717
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())


# Generated at 2022-06-12 02:23:02.291948
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    for i in range(3):
        card_number = p.credit_card_number(CardType.VISA)
        assert p.luhn_check(card_number)
        
        card_number = p.credit_card_number(CardType.MASTER_CARD)
        assert p.luhn_check(card_number)
        
        card_number = p.credit_card_number(CardType.AMERICAN_EXPRESS)
        assert p.luhn_check(card_number)

if __name__ == '__main__':
    p = Payment()
    p.seed(12345)
    card_number = p.credit_card_number(CardType.AMERICAN_EXPRESS)
    print(card_number)

# Generated at 2022-06-12 02:23:13.627573
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    # Visa
    _visa = payment.credit_card_number(CardType.VISA)
    assert _visa[:1] == '4'
    assert len(_visa) == 19
    # MasterCard
    _mastercard = payment.credit_card_number(CardType.MASTER_CARD)
    assert int(_mastercard[:2]) in [22, 23, 24, 25, 51, 52, 53, 54, 55]
    assert len(_mastercard) == 19
    # AmericanExpress
    _americanexpress = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert _americanexpress[:2] in ['34', '37']
    assert len(_americanexpress) == 17

# Generated at 2022-06-12 02:23:22.543895
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
	payment = Payment()
	result = payment.credit_card_number()
	# Check if result is a string
	if not isinstance(result, str):
		raise Exception("result is not a string")
	
	# Check if result have 16 characters
	if not len(result) == 16:
		raise Exception("result does not contain 16 characters")

	# Check if the first two characters are numbers
	if not result[0:2].isdigit():
		raise Exception("result first two characters are not numbers")

	# Check if the first character is a number from 4 to 6
	if not result[0].isdigit():
		raise Exception("result first character is not a number from 4 to 6")

	if int(result[0]) > 6:
		raise Exception("result first character is not a number from 4 to 6")



# Generated at 2022-06-12 02:23:30.436524
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_info = Payment()
    for i in range(1000):
        credit_card_number = payment_info.credit_card_number()
        print(credit_card_number)
        if not credit_card_number.startswith('4'):
            print(credit_card_number)
            print('Method Payment_credit_card_number() is wrong!')
            return False
    print('Method Payment_credit_card_number() is correct!')
    return True


# Generated at 2022-06-12 02:23:37.368906
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    seed = "Не вказано"
    p = Payment(seed=seed)
    assert len(p.credit_card_number()) == 16
    assert len(p.credit_card_number(CardType.MASTER_CARD)) == 16
    assert len(p.credit_card_number(CardType.VISA)) == 16
    assert len(p.credit_card_number(CardType.AMERICAN_EXPRESS)) == 15

# Generated at 2022-06-12 02:23:46.787965
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=12345)
    for _ in range(10):
        assert payment.credit_card_number(CardType.VISA).startswith('4')


# Generated at 2022-06-12 02:23:56.965540
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    PAYMENT = Payment()
    num = PAYMENT.credit_card_number()
    digit = num.replace(" ", "")

    if int(num[0]) == 4:
        assert len(digit) == 16
        assert int(digit) >= 4000000000 and int(digit) < 5000000000
    elif int(num[0]) == 3:
        assert len(digit) == 15
        assert int(digit) >= 3400000000 and int(digit) < 3500000000
    elif int(num[0:2]) >= 22 and int(num[0:2]) <= 27:
        assert len(digit) == 16
        assert int(digit) >= 2200000000 and int(digit) < 2800000000

# Generated at 2022-06-12 02:24:00.701031
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    seed = 0
    prng = Payment(seed=seed)
    # print(prng.credit_card_number())
    assert(prng.credit_card_number() == '4813 4759 3950 8125')


# Generated at 2022-06-12 02:24:04.726881
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    # print(payment.credit_card_number(CardType.VISA))
    # ["Visa", "MasterCard", "American Express"]
    # card_type = random.choice(["Visa", "MasterCard", "American Express"])
    # print(payment.credit_card_number(card_type))
    print(payment.credit_card_number())


# Generated at 2022-06-12 02:24:12.657323
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    result = payment.credit_card_number(card_type=CardType.MASTER_CARD)
    
    assert isinstance(result, str)
    assert len(result) == 19
    assert result[4] == " "
    assert result[9]  == " "
    assert result[14] == " "
    assert result[18] != " "

if __name__ == '__main__':
    
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:24:21.636345
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Expectation: The function will return a card number for the
    credit card type.
    """
    payment = Payment('en')

    actual = payment.credit_card_number(card_type=CardType.MASTER_CARD);
    expected = '5100 0000 0000 0000'
    assert actual == expected

    actual = payment.credit_card_number(card_type=CardType.VISA);
    expected = '4000 0000 0000 0000'
    assert actual == expected

    actual = payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS);
    expected = '3700 0000 0000 000'
    assert actual == expected

# Generated at 2022-06-12 02:24:27.086851
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert len(p.credit_card_number()) == len("4444444444444444")
    assert len(p.credit_card_number(CardType.MASTER_CARD)) == len("4444444444444444")
    assert len(p.credit_card_number(CardType.AMERICAN_EXPRESS)) == len("4444444444444")

# Generated at 2022-06-12 02:24:38.328402
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert(payment.credit_card_number() == "4455 5299 1152 2450")
    assert(payment.credit_card_number(card_type = CardType.VISA) == "4455 5299 1152 2450")
    assert(payment.credit_card_number(card_type = CardType.MASTER_CARD) == "5226 6776 3646 3817")
    assert(payment.credit_card_number(card_type = CardType.AMERICAN_EXPRESS) == "3788 8098 497 1732")
    try:
        payment.credit_card_number(card_type = "")
        assert (1 == 0)
    except NonEnumerableError as e:
        x = 1
        assert(x == 1)


# Generated at 2022-06-12 02:24:44.329956
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    card_number = payment.credit_card_number(CardType.MASTER_CARD)
    assert len(card_number) == 19
    card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(card_number) == 17


# Generated at 2022-06-12 02:24:48.077672
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    num = p.credit_card_number()

    assert len(num) == 19
    assert num[0] in '45'


# Generated at 2022-06-12 02:25:04.157370
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # ==> test_Payment_credit_card_number:1:
    payment = Payment()
    card_type = CardType.AMERICAN_EXPRESS
    credit_card_number = payment.credit_card_number(card_type)
    assert credit_card_number == "3733 2234 51183 7"


# Generated at 2022-06-12 02:25:12.603283
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test the credit_card_number method of the Payment class
    """
    nb_of_card_created_for_each_card_type = 10
    for card_type in CardType:
        for _ in range(nb_of_card_created_for_each_card_type):
            index_card_number = Payment().credit_card_number(card_type)
            card_number_regex = re.compile(r'(\d{4}\s\d{4}\s\d{4}\s\d{4})')
            assert card_number_regex.search(
                index_card_number
            ) is not None

# Generated at 2022-06-12 02:25:16.039176
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print(Payment.credit_card_number(CardType.AMERICAN_EXPRESS))
    print(Payment.credit_card_number(CardType.MASTER_CARD))
    print(Payment.credit_card_number(CardType.VISA))


# Generated at 2022-06-12 02:25:22.107454
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment()
    mydict = {"len" : 0}
    for x in range(100):
        result = provider.credit_card_number()
        if(mydict.get(len(result))):
            mydict[len(result)] += 1
        else:
            mydict[len(result)] = 1
        if(len(result) != 16 and len(result) != 17):
            print("KO")
    print(mydict)


# Generated at 2022-06-12 02:25:25.747959
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Generate random number
    number = Payment().credit_card_number()

    # Use luhn_checksum function to check this number
    assert luhn_checksum(number) == 0

    # Check the type of generated number
    assert isinstance(number, str)

# Generated at 2022-06-12 02:25:35.185437
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    
    # Enum.VISA
    provider = Payment()
    result = []
    for i in range(99):
        result.append(provider.credit_card_number(CardType.VISA))
    assert '4455 5299 1152 2450' in result

    # Enum.MASTER_CARD
    provider = Payment()
    result = []
    for i in range(99):
        result.append(provider.credit_card_number(CardType.MASTER_CARD))
    assert '5100 0302 8053 5452' in result   

    # Enum.AMERICAN_EXPRESS
    provider = Payment()
    result = []
    for i in range(99):
        result.append(provider.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-12 02:25:43.040035
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(random_state=0)
    assert payment.credit_card_number() == '4716 2549 1030 4223'
    assert payment.credit_card_number(  # type: ignore
        card_type=CardType.AMERICAN_EXPRESS,
    ) == '3401 438452 52228'
    assert payment.credit_card_number(  # type: ignore
        card_type=CardType.MASTER_CARD,
    ) == '5271 9173 3784 1843'


# Generated at 2022-06-12 02:25:45.663001
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    Test credit_card_number method of class Payment.
    """
    p = Payment('en')
    for _ in range(10):
        print(p.credit_card_number())

# Generated at 2022-06-12 02:25:51.086713
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(feature='en', seed=123)
    assert payment.credit_card_number(card_type=CardType.VISA) == '4914 4320 7744 6778'
    assert payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == '3710 8561 6414 755'
    assert payment.credit_card_number(card_type=CardType.MASTER_CARD) == '5180 8893 3329 8094'
    assert payment.credit_card_number(card_type=CardType.VISA) == '4632 3775 0455 6807'



# Generated at 2022-06-12 02:26:00.228693
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Тестируем генератор номеров кредитных карт для правильных карт
    for card in {CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS}:
        obj = Payment()
        # Проверяем формат возвращаемого значения: строка
        assert type(obj.credit_card_number(card)) is str, "Некорректный тип"
       

# Generated at 2022-06-12 02:26:30.854914
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment with parameters that are not valid."""
    p = Payment()
    try:
        p.credit_card_number(card_type=-1)
    except NonEnumerableError as error:
        assert "Item must be one of CardType enum" in str(error)
    try:
        p.credit_card_number(card_type=4)
    except NonEnumerableError as error:
        assert "Item must be one of CardType enum" in str(error)

# Generated at 2022-06-12 02:26:39.809670
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    #  test for CardType Visa
    assert re.search('^4\d{3} \d{4} \d{4} \d{4}$', Payment().credit_card_number(CardType.VISA))
    assert re.search('^4\d{3} \d{4} \d{4} \d{4}$', Payment().credit_card_number())

    # test for CardType AmericanExpress
    assert re.search('^3[47]\d{2} \d{6} \d{5}$', Payment().credit_card_number(CardType.AMERICAN_EXPRESS))

    # test for CardType MasterCard
    result = Payment().credit_card_number(CardType.MASTER_CARD)

# Generated at 2022-06-12 02:26:49.536645
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    #VISA
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    assert len(credit_card_number) == 19
    assert credit_card_number[0] == "4"
    #MASTER_CARD
    payment = Payment()
    credit_card_number = payment.credit_card_number(CardType.MASTER_CARD)
    assert len(credit_card_number) == 19
    assert credit_card_number[0] == "2" or credit_card_number[0] == "5"
    #American Express
    payment = Payment()
    credit_card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(credit_card_number) == 17
    assert credit_card_number[0] == "3"

# Generated at 2022-06-12 02:26:51.708656
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    a=Payment()
    print(a.credit_card_number())


# Generated at 2022-06-12 02:27:02.147696
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Обьявление переменной payment, которая относиться к классу Payment
    payment = Payment()
    # Обьявление переменной для записи результата класса Payment
    a = payment.credit_card_number()
    # Проверка результата класса Payment на вхождение в него регулярного

# Generated at 2022-06-12 02:27:03.154881
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment.create('en')
    print(p.credit_card_number())

# Generated at 2022-06-12 02:27:05.090425
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment().credit_card_number()

# Generated at 2022-06-12 02:27:07.532347
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card_type = CardType.AMERICAN_EXPRESS
    assert len(p.credit_card_number(card_type)) == 19

# Generated at 2022-06-12 02:27:10.476762
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment(seed=1)
    card = payment.credit_card_number()
    assert card == '4455 5299 1152 2450'

# Generated at 2022-06-12 02:27:19.193729
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    import random
    import pytest
    assert re.match(r"^(\d{4})(\d{4})(\d{4})(\d{4})$",
                    Payment().credit_card_number(CardType.VISA))
    assert re.match(r"^(\d{4})(\d{4})(\d{4})(\d{4})$",
                    Payment().credit_card_number(CardType.MASTER_CARD))
    assert re.match(r"^(\d{4})(\d{6})(\d{5})$",
                    Payment().credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-12 02:28:07.122917
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    payment = Payment()
    ctype = CardType.VISA
    for _ in range(5):
        card_number = payment.credit_card_number(card_type=ctype)
        # Check that the card number has the right length
        if ctype == CardType.VISA or ctype == CardType.MASTER_CARD:
            assert len(card_number) == 19
        elif ctype == CardType.AMERICAN_EXPRESS:
            assert len(card_number) == 17
        else:
            assert False

        # Check that the card number is valid
        card_number = card_number.replace(' ', '')
        if int(card_number) > 0:
            assert luhn_checksum(card_number) == 0

# Generated at 2022-06-12 02:28:09.539878
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert isinstance(payment.credit_card_number(), str)
    assert len(payment.credit_card_number()) == 19


# Generated at 2022-06-12 02:28:12.686879
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from .providers.payment import Payment
    from .enums import CardType
    p = Payment()
    assert re.match('\d+', p.credit_card_number(card_type=CardType.VISA))
    assert re.match('\d+', p.credit_card_number(card_type=CardType.MASTER_CARD))
    assert re.match('\d+', p.credit_card_number(card_type=CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-12 02:28:19.970328
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Setup
    provider = Payment()
    credit_card_numbers = [provider.credit_card_number(card_type=CardType.VISA) for _ in range(10000)]
    # Execution
    # Checking the property of credit_card_number
    for credit_card_number in credit_card_numbers:
        # Checking the prefix of each credit_card_number
        prefix_values = []
        for i in range(len(credit_card_number) - 1):
            prefix_values.append(int(credit_card_number[:i]) in range(4000, 5000))
        # Checking the length of each credit_card_number
        length_values = [len(credit_card_number) == 19]
        # Unit test
        assert all(prefix_values) and all(length_values)


# Generated at 2022-06-12 02:28:23.806658
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    p = Payment()
    assert p.credit_card_number(CardType.VISA)


# Generated at 2022-06-12 02:28:32.945452
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment()
    for _ in range(100):
        card_type = provider.random.choice(list(CardType)).name
        card_number = provider.credit_card_number(CardType[card_type])
        if card_type == 'VISA':
            assert int(card_number[0:2]) in range(40, 50)
        elif card_type == 'MASTER_CARD':
            assert int(card_number[0:2]) in range(22, 28), card_number
        elif card_type == 'AMERICAN_EXPRESS':
            assert int(card_number[0:2]) in [34, 37], card_number
        else:
            raise NonEnumerableError(CardType)

# Generated at 2022-06-12 02:28:38.970490
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print("Test credit_card_number( )")
    pmt = Payment()
    v1 = pmt.credit_card_number(CardType.VISA)
    v2 = pmt.credit_card_number(CardType.VISA)
    assert (v1 != v2)
    print("VISA 1 =", v1)
    ma = pmt.credit_card_number(CardType.MASTER_CARD)
    print("MASTER CARD =", ma)
    am = pmt.credit_card_number(CardType.AMERICAN_EXPRESS)
    print("AMERICAN EXPRESS =", am)
    # bad_type = pmt.credit_card_number("AAAA")


# Generated at 2022-06-12 02:28:42.510645
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    number = p.credit_card_number()
    print(number)
    assert re.match(r'\d{16}', number) is not None


# Generated at 2022-06-12 02:28:52.212835
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    cc = Payment()
    # Ensure that the first digit of the generated CC number
    # is equal to 4 if it is a VISA card
    assert cc.credit_card_number(CardType.VISA).startswith('4') == True
    # Ensure that the first digit of the generated CC number
    # is equal to 5 if it is a MasterCard card
    assert cc.credit_card_number(CardType.MASTER_CARD).startswith('5') == True
    # Ensure that the first digit of the generated CC number
    # is equal to 3 if it is an AmericanExpress card
    assert cc.credit_card_number(CardType.AMERICAN_EXPRESS).startswith('3') == True
    # Ensure that the length is equal to 16 if it is an AmericanExpress card


# Generated at 2022-06-12 02:28:56.287840
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    '''test_Payment_credit_card_number'''
    p = Payment()
    card_number = p.credit_card_number()
    assert len(card_number) == 19
    assert card_number[0] in ['3', '4', '5']
