

# Generated at 2022-06-12 02:21:38.419378
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    random_prov = Payment()
    print(random_prov.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-12 02:21:45.534257
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(locale='ru')
    try:
        payment.credit_card_number(card_type='Visa')
    except Exception as e:
        print(e)
    print(payment.credit_card_number(card_type='Visa'))
    print(payment.credit_card_number(card_type='MasterCard'))
    print(payment.credit_card_number(card_type='AmericanExpress'))


# Generated at 2022-06-12 02:21:46.937863
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment = Payment()
    print(Payment.credit_card_number())

# Generated at 2022-06-12 02:21:52.759302
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cls_main = Payment()
    assert cls_main.credit_card_number() in ["4415 1095 8612 8384","4635 0199 6676 3437","4532 4128 6137 9042","4620 5679 9820 9857","4427 6129 3687 3346","4532 6499 4973 1184"]


# Generated at 2022-06-12 02:21:56.319365
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment = Payment()
    card_type = get_random_item(CardType, rnd=Payment.random)
    card_number = Payment.credit_card_number(card_type)
    print(card_number)


# Generated at 2022-06-12 02:21:57.524387
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())

# Generated at 2022-06-12 02:22:00.533353
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc = Payment()
    for i in range(10000):
        credit_card_number = cc.credit_card_number()
        print(credit_card_number)
        assert len(credit_card_number) == 19
        print("pass")

# Generated at 2022-06-12 02:22:05.754325
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    cType = CardType.MASTER_CARD

    card_number = payment.credit_card_number(cType)
    assert cType == CardType.MASTER_CARD
    assert len(card_number) == 19

    cType = CardType.VISA
    card_number = payment.credit_card_number(cType)
    assert cType == CardType.VISA
    assert len(card_number) == 16

    cType = CardType.AMERICAN_EXPRESS
    card_number = payment.credit_card_number(cType)
    assert cType == CardType.AMERICAN_EXPRESS
    assert len(card_number) == 17



# Generated at 2022-06-12 02:22:17.530279
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment."""
    from mimesis.enums import CardType
    payment = Payment(seed=42)

    # Test for VISA
    card_type_objects = [CardType.VISA]
    for card_type in card_type_objects:
        card_number = payment.credit_card_number(card_type=card_type)
        assert str(card_type)[9:] in card_number
        # The number of spaces is correct
        assert card_number.count(' ') == 3
        # The length of the number is correct
        assert len(card_number.replace(' ', '')) == 16

    # Test for MASTER_CARD
    card_number = payment.credit_card_number(card_type=CardType.MASTER_CARD)

# Generated at 2022-06-12 02:22:29.667246
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    # Test Visa
    number = p.credit_card_number(CardType.VISA)
    assert re.match('^4[0-9]{3} [0-9]{4} [0-9]{4} [0-9]{4}$', number)
    # Test MasterCard
    number = p.credit_card_number(CardType.MASTER_CARD)
    assert re.match('^[2-5][0-9]{3} [0-9]{4} [0-9]{4} [0-9]{4}$', number)
    # Test AmEx
    number = p.credit_card_number(CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-12 02:22:37.065306
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Check that there is no error
    tmp = Payment()
    tmp.credit_card_number()
    tmp.credit_card_number(CardType.MASTER_CARD)
    tmp.credit_card_number(CardType.AMERICAN_EXPRESS)


# Generated at 2022-06-12 02:22:48.685792
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import collections
    import random
    import statistics

    class CreditCardGenerator:

        _credit_card_network_to_type = {
            'Visa': 'VISA',
            'MasterCard': 'MASTER_CARD',
            'American Express': 'AMERICAN_EXPRESS',
        }

        def __init__(self):
            self._payment = Payment(random.Random())

        def get_credit_card_number(self, card_type):
            return self._payment.credit_card_number(card_type)

        def generate_credit_card_numbers(self, num_cards, card_type):
            card_type = self._credit_card_network_to_type[card_type]

# Generated at 2022-06-12 02:22:56.106599
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number(card_type=CardType.VISA) == '4455 5299 1152 2450'
    assert p.credit_card_number(card_type=CardType.MASTER_CARD) == '5100 0257 7095 8888'
    assert p.credit_card_number(
        card_type=CardType.AMERICAN_EXPRESS) == '3782 8224 6310 005'

# Generated at 2022-06-12 02:23:00.941104
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'(\d{4}\s){3}\d{4}', payment.credit_card_number())
    assert re.match(r'(\d{4}\s){3}\d{4}', payment.credit_card_number(CardType.VISA))


# Generated at 2022-06-12 02:23:05.136928
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    seed = 101010101
    p = Payment(seed=seed)
    assert p.credit_card_number(CardType.MASTER_CARD) == '5292 8526 8566 9605'

# Generated at 2022-06-12 02:23:08.913888
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=42)
    credit_card_number = payment.credit_card_number()
    assert credit_card_number == "4455 5299 1152 2450"


# Generated at 2022-06-12 02:23:10.409539
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())


# Generated at 2022-06-12 02:23:19.580185
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en', random_state=42)
    cc_num_test_values = [
        ['visa', '4929 3271 3300 4048'],
        ['mastercard', '5454 2340 1499 9019'],
        ['american express', '3785 873236 81592'],
        ['diners club', '3649 722509 53729'],
        ['discover', '6011 933812 69510'],
        ['jcb', '3566 002021 97397'],
        ['maestro', '6759 641673 05014'],
        ['union pay', '6250 060142 26172'],
    ]


# Generated at 2022-06-12 02:23:28.453702
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test method credit_card_number of class Payment."""
    assert Payment().credit_card_number() == '4455 5299 1152 2450'
    assert Payment('en').credit_card_number() == '4455 5299 1152 2450'
    assert Payment().credit_card_number(CardType.MASTER_CARD) == '5155 7452 3210 4262'
    assert Payment().credit_card_number(CardType.AMERICAN_EXPRESS) == '3761 7183 8117 035'


# Generated at 2022-06-12 02:23:36.235192
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    # Default card type: CardType.VISA
    data = Payment().credit_card_number()
    # Check if the first number is 4 (Visa card type)
    assert data[0] == '4'

    # Card type: CardType.VISA
    data = Payment().credit_card_number(CardType.VISA)
    # Check if the first number is 4 (Visa card type)
    assert data[0] == '4'

    # Card type: CardType.MASTER_CARD
    master_card_data = Payment().credit_card_number(CardType.MASTER_CARD)
    # Check if the first number is 2,5 (Master card type)
    assert master_card_data[0] in ['2', '5']

    # Card type: CardType.AMERICAN_EXPRESS
    american

# Generated at 2022-06-12 02:23:48.110040
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    obj = Payment()
    assert len(obj.credit_card_number()) == 19

# Generated at 2022-06-12 02:23:58.326635
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    a = Payment()
    b = Payment()
    c = Payment()
    d = Payment()
    assert a.credit_card_number() != b.credit_card_number()
    assert a.credit_card_number() != c.credit_card_number()
    assert b.credit_card_number() != c.credit_card_number()
    assert d.credit_card_number(CardType.AMERICAN_EXPRESS) != a.credit_card_number(CardType.VISA)
    assert d.credit_card_number(CardType.VISA) != d.credit_card_number(CardType.MASTER_CARD)
    assert d.credit_card_number(CardType.AMERICAN_EXPRESS) != d.credit_card_number(CardType.VISA)
    assert d.credit_card_

# Generated at 2022-06-12 02:24:02.222353
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test."""
    import mimesis
    payment = mimesis.Generic('en')
    assert re.match('\d{4}\s\d{4}\s\d{4}\s\d{4}', payment.credit_card_number())

# Generated at 2022-06-12 02:24:09.852542
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Initialize Payment class
    payment = Payment(seed=12345)
    # Get credit_card_number
    cc = payment.credit_card_owner()
    # If credit_card_number is correct, then return True, else return False
    if cc['credit_card'][0] == '4' and cc['credit_card'][1] == '5':
        return True
    return False

print(test_Payment_credit_card_number())

# Generated at 2022-06-12 02:24:16.070826
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import random

    payment = Payment(random.seed())
    print('Visa: ' + payment.credit_card_number(CardType.VISA))
    print('MasterCard: ' + payment.credit_card_number(CardType.MASTER_CARD))
    print('American Express: ' + payment.credit_card_number(CardType.AMERICAN_EXPRESS))
    print('American Express: ' + payment.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-12 02:24:24.674989
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    print("Payment().credit_card_number()=",Payment().credit_card_number())
    print("Payment().credit_card_number(CardType.VISA)=",Payment().credit_card_number(CardType.VISA))
    print("Payment().credit_card_number(CardType.AMERICAN_EXPRESS)=",Payment().credit_card_number(CardType.AMERICAN_EXPRESS))
    print("Payment().credit_card_number(CardType.MASTER_CARD)=",Payment().credit_card_number(CardType.MASTER_CARD))

if __name__ == "__main__":
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:24:26.683824
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_info = Payment().credit_card_number()
    assert isinstance(card_info, str)

# Generated at 2022-06-12 02:24:30.532717
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test for method credit_card_number
    for _ in range(0, 100):
        cc = Payment()
        assert cc.credit_card_number() is not None
        assert len(cc.credit_card_number()) == 19


# Generated at 2022-06-12 02:24:41.993579
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    visa = Payment().credit_card_number(CardType.VISA)
    master_card = Payment().credit_card_number(CardType.MASTER_CARD)
    american_express = Payment().credit_card_number(CardType.AMERICAN_EXPRESS)

    assert re.search(r'4[0-9]{3} [0-9]{4} [0-9]{4} [0-9]{4}', visa)
    assert re.search(r'[2-5][0-9]{3} [0-9]{4} [0-9]{4} [0-9]{4}', master_card)
    assert re.search(r'[3][4,7] [0-9]{6} [0-9]{5}', american_express)

# Generated at 2022-06-12 02:24:44.191180
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    p = Payment()
    assert len(p.credit_card_number()) == 19

# Generated at 2022-06-12 02:25:13.904409
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(seed=42)
    print('credit_card_number of class Payment',p.credit_card_number(card_type=CardType.MASTER_CARD))
    assert p.credit_card_number(card_type=CardType.MASTER_CARD) == '5418 0168 3137 8252'




# Generated at 2022-06-12 02:25:15.238343
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    for i in range(100):
        p.credit_card_number()

# Generated at 2022-06-12 02:25:21.662239
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en', seed=123456)
    number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert number == '3789 021464 64449'

    number = payment.credit_card_number(CardType.MASTER_CARD)
    assert number == '5485 6297 7781 2395'

    number = payment.credit_card_number(CardType.VISA)
    assert number == '4029 8061 4631 2988'

# Generated at 2022-06-12 02:25:30.843111
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """ Unit test for method credit_card_number of class Payment"""
    payment = Payment()
    pattern = re.compile(r'^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|'
                         r'6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|'
                         r'3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|'
                         r'35\d{3})\d{11})$')
    assert pattern.match(payment.credit_card_number())

# Generated at 2022-06-12 02:25:40.918658
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

# Generated at 2022-06-12 02:25:45.424651
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    assert payment.credit_card_number(card_type=CardType.VISA)
    assert payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    assert payment.credit_card_number(card_type=CardType.MASTER_CARD)


# Generated at 2022-06-12 02:25:46.929564
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment('en')
    for i in range(1, 100):
        provider.credit_card_number()

# Generated at 2022-06-12 02:25:50.142593
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    Unit test for method credit_card_number of class Payment
    """
    payment = Payment()
    assert payment.credit_card_number().__len__() == 19


# Generated at 2022-06-12 02:25:53.781334
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment=Payment()
    print(payment.credit_card_number())
#Unit test for method credit_card_owner of class Payment

# Generated at 2022-06-12 02:25:57.094804
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    number = p.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert number[0] == '3'
    assert number[1] == '4' or number[1] == '7'


# Generated at 2022-06-12 02:26:56.238112
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test use default CardType
    obj = Payment()
    assert re.match('\d{4} \d{4} \d{4} \d{4}', obj.credit_card_number()) is not None
    # Test use CardType.MASTER_CARD
    assert re.match('5[1-5]\d{2} \d{4} \d{4} \d{4}',
                    obj.credit_card_number(CardType.MASTER_CARD)) is not None
    # Test use CardType.AMERICAN_EXPRESS
    assert re.match('3[4-7]\d{2} \d{6} \d{5}',
                    obj.credit_card_number(CardType.AMERICAN_EXPRESS)) is not None
    # Test use CardType.VISA
   

# Generated at 2022-06-12 02:27:03.505424
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    assert len(payment.credit_card_number(CardType.VISA)) == 16
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 16
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 15
    card_number = payment.credit_card_number(CardType.VISA)

    # Test if credit card number is valid
    # See https://en.wikipedia.org/wiki/Luhn_algorithm
    assert card_number[-1] == str(luhn_checksum(card_number[:-1]))



# Generated at 2022-06-12 02:27:05.448620
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    result = Payment().credit_card_number()
    assert len(result) == 19

# Generated at 2022-06-12 02:27:08.286514
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    pattern = re.compile(r'^[\d]{16}$')
    assert pattern.match(payment.credit_card_number(CardType.VISA)) != None

# Generated at 2022-06-12 02:27:11.833673
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(10):
        card_type = get_random_item(CardType, rnd=random)
        payment = Payment()
        number = payment.credit_card_number(card_type=card_type)
        print(number)

# Generated at 2022-06-12 02:27:13.234133
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for _ in range(100):
        print(payment.credit_card_number())

# Generated at 2022-06-12 02:27:18.150635
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[:4] == '4455'
    assert card_number[5:9] == '5299'
    assert card_number[10:14] == '1152'
    assert card_number[15:] == '2450'


# Generated at 2022-06-12 02:27:22.590255
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""

    payment = Payment('en')
    card_type = CardType.MASTER_CARD
    card = payment.credit_card_number(card_type)
    assert card_type.value in card

# Generated at 2022-06-12 02:27:33.227326
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    card_type = CardType.AMERICAN_EXPRESS
    assert len(payment.credit_card_number(card_type)) == 17
    # test card type
    assert payment.credit_card_number(CardType.VISA)[0] == '4'
    assert payment.credit_card_number(CardType.MASTER_CARD)[0] == '2' or payment.credit_card_number(CardType.MASTER_CARD)[1] == '5'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS)[0] == '3'
    # test card number

# Generated at 2022-06-12 02:27:35.089017
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment.credit_card_number()
    payment.credit_card_number(CardType.AMERICAN_EXPRESS)