

# Generated at 2022-06-12 02:21:39.066147
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en', seed=1234)
    assert payment.credit_card_number() == "5332 3854 7678 8118"
    for _ in range(100):
        assert luhn_checksum(payment.credit_card_number()) == 0

# Generated at 2022-06-12 02:21:46.673604
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import random
    random.seed(123456)
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5279 0842 6979 7152'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3442 0018 843 752'


# Generated at 2022-06-12 02:21:58.032686
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test all possible card type."""
    # For each test we generate 100 credit card number and each number
    # should respect the regex of the card type.
    for card_type in CardType:
        regex = r'^'
        if card_type == CardType.VISA:
            regex += r'4[0-9]{3}\s[0-9]{4}\s[0-9]{4}\s[0-9]{4}$'
        elif card_type == CardType.MASTER_CARD:
            regex += r'(2221|2720)[0-9]{2}\s[0-9]{4}\s[0-9]{4}\s[0-9]{4}$|'

# Generated at 2022-06-12 02:22:00.977455
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card_type = CardType.VISA
    card_number = p.credit_card_number(card_type)
    print(card_number)
    assert card_number[0] == "4"



# Generated at 2022-06-12 02:22:02.587481
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    long_str = payment.credit_card_number()
    assert(len(long_str) == 16)
    

# Generated at 2022-06-12 02:22:14.826207
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    n = 100000

    payment = Payment()

    # VISA
    length = 0
    for _ in range(n):
        assert len(payment.credit_card_number()) == 16
        length += len(payment.credit_card_number())
    print(length / n)

    # Master Card
    length = 0
    for _ in range(n):
        assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 16
        length += len(payment.credit_card_number(CardType.MASTER_CARD))
    print(length / n)

    # American Express
    length = 0
    for _ in range(n):
        assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 15

# Generated at 2022-06-12 02:22:16.020507
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for x in range(0, 20):
        assert (len(Payment().credit_card_number(CardType.VISA)) == 19)



# Generated at 2022-06-12 02:22:20.845616
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pr1 = Payment()
    card1 = pr1.credit_card_number()
    card_obj1 = CardType.MASTER_CARD
    card2 = pr1.credit_card_number(card_obj1)
    print(card1)
    print(card2)


# Generated at 2022-06-12 02:22:29.606955
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    method = Payment()
    assert len(method.credit_card_number()) == 19
    assert method.credit_card_number("Visa").startswith("4")
    assert method.credit_card_number("MasterCard").startswith("51", "52", "53", "54", "55")
    assert method.credit_card_number("AmericanExpress").startswith("34", "37")

if __name__ == "__main__":
    test_Payment_credit_card_number()
    test_Payment_credit_card_expiration_date()

# Generated at 2022-06-12 02:22:35.887236
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    result = Payment('en').credit_card_number(CardType.VISA)
    assert len(result) == 19
    assert result.startswith('4')

    result = Payment('en').credit_card_number(CardType.MASTER_CARD)
    assert len(result) == 19
    assert result.startswith('2') or result.startswith('5')

    result = Payment('en').credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(result) == 17
    assert result.startswith('3')


# Generated at 2022-06-12 02:22:43.150316
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(card_type=CardType.VISA)
    assert (len(card_number.split()) == 4)

# Generated at 2022-06-12 02:22:45.717904
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(seed=123)
    output = p.credit_card_number()
    assert output == '4444 4444 4444 4441'

# Generated at 2022-06-12 02:22:55.371086
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # create object instance:
    payment = Payment()
    # invoke method:
    result = payment.credit_card_number()
    # check that method call was successful:
    assert result is not None
    # check that result is not empty:
    assert result != ''
    # check that result is a string of length 16:
    assert type(result) is str
    assert len(result) == 16
    # check that result is a string of numbers separated by spaces:
    assert re.search(r'^([0-9]+(\s)){3}[0-9]+$', result) is not None


# Generated at 2022-06-12 02:22:59.034442
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    seed = 0
    test_pay = Payment(seed=seed)
    assert test_pay.credit_card_number(CardType.AMERICAN_EXPRESS) == "3719 136984 66444"



# Generated at 2022-06-12 02:23:09.018075
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    import json
    import logging
    logging.basicConfig(level=logging.DEBUG)
    p = Payment()
    f = open('Payment_credit_card_number.json', 'w+')
    for i in range(10000):
        c_type = p.random.choice(list(CardType))
        f.write(json.dumps((i, c_type, p.credit_card_number(card_type=c_type)), indent=4, separators=(',', ': ')) + '\n')
    f.close()


# Generated at 2022-06-12 02:23:18.705034
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = 'VISA'
    provider = Payment()
    number = provider.credit_card_number(card_type)
    assert re.match('[0-9]{16}', number)
    assert number[:1] == '4'
    assert len(number) == 16
    card_type = 'MASTERCARD'
    number = provider.credit_card_number(card_type)
    assert re.match('[2][2-7][0-9]{14}', number)
    assert len(number) == 16
    card_type = 'AMERICAN EXPRESS'
    number = provider.credit_card_number(card_type)
    assert re.match('[34|37][0-9]{14}', number)
    assert len(number) == 15

# Generated at 2022-06-12 02:23:22.980887
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    payment = Payment()
    result = payment.credit_card_number()
    assert len(result) == 19
    assert isinstance(result, str)
    assert result.count(" ") == 3

# Generated at 2022-06-12 02:23:33.581879
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """test for method: credit_card_number of class Payment"""
    payment = Payment(seed=12345)

    assert payment.credit_card_number() == '4084 8722 8191 8165'
    assert payment.credit_card_number(CardType.VISA) == '4452 0537 5546 5136'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5391 8281 6793 7391'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3415883184242'
    try:
        payment.credit_card_number(CardType.DISCOVERY)
        assert False
    except NonEnumerableError:
        assert True


# Generated at 2022-06-12 02:23:34.907718
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment.credit_card_number(CardType.VISA)

# Generated at 2022-06-12 02:23:41.701088
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(seed=1234)
    assert p.credit_card_number() == "4455 5299 1152 2450"
    assert p.credit_card_number() == "5553 2198 1560 7794"
    assert p.credit_card_number() == "4315 8731 6373 5012"
    assert p.credit_card_number() == "4807 6794 7052 5376"
    assert p.credit_card_number() == "4040 0045 8660 7269"
    assert p.credit_card_number() == "4848 5596 5218 9436"
    assert p.credit_card_number() == "4108 1774 7560 3104"
    assert p.credit_card_number() == "4465 7020 0219 8094"

# Generated at 2022-06-12 02:23:57.590572
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import time
    import random

    cur_time_second = int(time.time())
    random.seed(cur_time_second)

    test_times = 1000
    for i in range(test_times):
        card_type = None
        if (i % 2 == 0):
            card_type = CardType.VISA
        elif (i % 3 == 0):
            card_type = CardType.MASTER_CARD
        else:
            card_type = CardType.AMERICAN_EXPRESS
        payment = Payment(seed=cur_time_second)
        card_number = payment.credit_card_number(card_type)

        if (card_type == CardType.VISA):
            assert (card_number[0] == '4')
            assert (len(card_number) == 19)
            print

# Generated at 2022-06-12 02:23:59.886177
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment.credit_card_number(CardType.MASTER_CARD)
    # payment.credit_card_number(CardType.DISCOVER)  # Exception

# Generated at 2022-06-12 02:24:05.036549
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for i in range(50):
        card_number = payment.credit_card_number()
        if card_number[0] == '4':
            assert len(card_number) == 19
        if card_number[0] == '2':
            assert len(card_number) == 19
        if card_number[0] == '5':
            assert len(card_number) == 19
        if card_number[0] == '3':
            assert len(card_number) == 18


# Generated at 2022-06-12 02:24:15.548206
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment.
    """
    payment = Payment()
    # Test for parameters: card_type
    # Parameter card_type with value CardType.VISA
    assert payment.credit_card_number(card_type=CardType.VISA) == "4842 5884 6269 7839"
    # Parameter card_type with value CardType.MASTER_CARD
    assert payment.credit_card_number(card_type=CardType.MASTER_CARD) == "2267 5091 7382 6991"
    # Parameter card_type with value CardType.AMERICAN_EXPRESS
    assert payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == "3370 0554 2088 04"

# Generated at 2022-06-12 02:24:21.036553
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number('Visa'))
    print(payment.credit_card_number('MasterCard'))
    # print(payment.credit_card_number('AmericanExpress'))

if __name__ == "__main__":
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:24:22.434292
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())

# Generated at 2022-06-12 02:24:24.999041
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    num = p.credit_card_number()
    print(num)

    assert (int(num[0]) == 4)
    

# Generated at 2022-06-12 02:24:36.261521
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    py_obj = Payment(1)
    print ("Credit card type: " + str(py_obj.credit_card_network()))
    print ("Credit Card Number: " + str(py_obj.credit_card_number()))
    print ("Exp. Date: " + str(py_obj.credit_card_expiration_date()))
    print ("CID: " + str(py_obj.cid()))
    print ("CVV: " + str(py_obj.cvv()))
    print ("Bitcoin address: " + str(py_obj.bitcoin_address()))
    print ("Ethereum address: " + str(py_obj.ethereum_address()))
    print ("PayPal account: " + str(py_obj.paypal()))

# Generated at 2022-06-12 02:24:38.591030
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert  len(card_number) == 16


# Generated at 2022-06-12 02:24:41.489700
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
  data = Payment.credit_card_number(CardType.MASTER_CARD)
  assert isinstance(data, str) == True
