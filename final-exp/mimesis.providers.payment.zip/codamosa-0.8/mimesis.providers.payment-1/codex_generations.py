

# Generated at 2022-06-12 02:21:43.159633
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number() == '4455 5299 1152 2450'
    assert p.credit_card_number(CardType.MASTER_CARD) == '5177 5756 9193 4583'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3703 567837 78722'
    assert p.credit_card_number(CardType.DISCOVER) == '6011 4299 6315 7363'
    assert p.credit_card_number(CardType.CHINA_UNIONPAY) == '6221 5372 5306 9808'
    assert p.credit_card_number(CardType.DINERS_CLUB) == '5280 5998 1901 4946'

# Generated at 2022-06-12 02:21:51.794729
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    print('card_number of Credit Card = ', card_number)
    card_number = payment.credit_card_number(CardType.MASTER_CARD)
    print('card_number of Credit Card = ', card_number)
    card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    print('card_number of Credit Card = ', card_number)
    card_number = payment.credit_card_number(CardType.VISA)
    print('card_number of Credit Card = ', card_number)



# Generated at 2022-06-12 02:21:55.047342
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match('\d{4} \d{4} \d{4} \d{4}', p.credit_card_number()) is not None


# Generated at 2022-06-12 02:22:02.922312
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(seed=12345)
    c = p.credit_card_number()
    c1 = p.credit_card_number(card_type=CardType.VISA)
    c2 = p.credit_card_number(card_type=CardType.MASTER_CARD)
    c3 = p.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    assert c=='4009 4510 3112 5774'
    assert c1=='4009 4510 3112 5774'
    assert c2=='5536 3126 2941 6973'
    assert c3=='3493 63512940'


# Generated at 2022-06-12 02:22:11.429641
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment_ = Payment()
    assert(Payment_.credit_card_number(CardType.VISA)[0:2] == '45')
    assert(Payment_.credit_card_number(CardType.AMERICAN_EXPRESS)[0:2] in ['34', '37'])
    assert(Payment_.credit_card_number(CardType.MASTER_CARD)[0:2] in ['51', '52', '53', '54', '55', '22', '23', '24', '25', '26', '27'])

# Generated at 2022-06-12 02:22:16.546938
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    number = payment.credit_card_number(card_type)
    # 1. The length of number is 16
    assert len(number) == 16
    # 2. The first 5 digits is the card type
    assert number[:5] == str(card_type)


# Generated at 2022-06-12 02:22:23.470479
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    length = 16
    regex = re.compile(r'(\d{4})(\d{4})(\d{4})(\d{4})')
    card_type = CardType.VISA
    card_number = payment.credit_card_number()
    assert len(card_number) == length
    assert regex.match(card_number)
    assert payment.credit_card_number(card_type)


# Generated at 2022-06-12 02:22:34.004604
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    a = Payment()
    is_visa = lambda number: str(number)[0] == '4' and len(str(number)) == 16
    assert is_visa(a.credit_card_number(card_type=CardType.VISA))

    is_mastercard = lambda number: str(number)[0] in ['5', '2'] and len(str(number)) == 16
    assert is_mastercard(a.credit_card_number(card_type=CardType.MASTER_CARD))

    is_americanexpress = lambda number: str(number)[0] in ['3', '7'] and len(str(number)) == 15
    assert is_americanexpress(a.credit_card_number(card_type=CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-12 02:22:37.581652
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
  # Credit card number with correct length
  assert len(Payment().credit_card_number())==19
  # Credit card number without card type
  assert isinstance(Payment().credit_card_number(), str)
  # Credit card number with card type Visa
  assert isinstance(Payment().credit_card_number(CardType.VISA), str)



# Generated at 2022-06-12 02:22:43.956262
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card = payment.credit_card_number(CardType.VISA)
    assert len(credit_card) == 19
    assert credit_card[:1]=='4'
    assert credit_card[4]==' '
    assert credit_card[9]==' '
    assert credit_card[14]==' '


# Generated at 2022-06-12 02:23:00.481205
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number(CardType.MASTER_CARD) == '5212 8758 1151 1192'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3701 7291 47415'
    assert p.credit_card_number(CardType.VISA) == '4094 9765 5572 9227'
    assert p.credit_card_number() in ['4094 9765 5572 9227',
                                      '3701 7291 47415',
                                      '5212 8758 1151 1192']

# Generated at 2022-06-12 02:23:13.114453
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()

    # Punto 1
    assert p.credit_card_number(CardType.VISA).startswith('4')

    # Punto 2
    assert p.credit_card_number(CardType.MASTER_CARD).startswith('51') \
        or p.credit_card_number(CardType.MASTER_CARD).startswith('22')

    # Punto 3
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS).startswith('34') \
           or p.credit_card_number(CardType.AMERICAN_EXPRESS).startswith('37')

    # Punto 4
    assert len(p.credit_card_number(CardType.VISA).replace(' ', '')) == 16

    # Punto 5

# Generated at 2022-06-12 02:23:15.215249
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test method credit_card_number of class Payment
    
    """
    assert Payment().credit_card_number()

# Generated at 2022-06-12 02:23:19.246272
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    #test with card_type is None
    p1=Payment(seed=seed)
    card_type=p1.credit_card_number()
    #test with card_type is not None
    p2=Payment(seed=seed)
    card_type=p2.credit_card_number(card_type=CardType.VISA)
    print(card_type)

# Generated at 2022-06-12 02:23:28.057316
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert card_number.startswith('4')
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[-1].isdigit()
    assert luhn_checksum(card_number[:-1]) == card_number[-1]


# Generated at 2022-06-12 02:23:33.711031
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis import Payment
    payment = Payment(seed=18)
    assert payment.credit_card_number(CardType.VISA) == '4005 5704 3282 0841'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2666 1385 0150 3959'
    assert payment.credit_card_number(CardType.DISCOVER) == '6593 9388 5362 6461'

# Generated at 2022-06-12 02:23:35.801663
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number(CardType.VISA) == '4455 5299 1152 2450'



# Generated at 2022-06-12 02:23:47.379777
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    
    # Test 1
    test = Payment(seed = 1)
    # Test that for 10 times, the result has the following format:
    # xxxx xxxx xxxx xxxx
    for i in range(10):
        assert(re.match(r'^\d{4}\s\d{4}\s\d{4}\s\d{4}$', test.credit_card_number()) is not None)
    # Test that the last digit is a valid luhn checksum
    # of the previous 15 digits
    # For 100 times, we test that the last digit is valid
    for i in range(100):
        card_number = re.sub(r' ', '', test.credit_card_number())

# Generated at 2022-06-12 02:23:52.989063
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment('en')
    assert p.credit_card_number(CardType.VISA) == '4065 0301 0951 1801'
    assert p.credit_card_number(CardType.MASTER_CARD) == '5561 7811 0489 2351'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3783 0102 4950135'


# Generated at 2022-06-12 02:23:54.916467
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_provider = Payment()
    print(payment_provider.credit_card_number())


# Generated at 2022-06-12 02:24:18.191280
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import mimesis
    A = mimesis.Payment()
    print(A.credit_card_number())


# Generated at 2022-06-12 02:24:19.664984
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment.credit_card_number()

# Generated at 2022-06-12 02:24:30.480960
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    for _ in range(10):
        credit_card_number = p.credit_card_number()
        assert len(credit_card_number) == 19
        assert credit_card_number.endswith(str(luhn_checksum(credit_card_number.replace(' ',''))))
        assert all([c in string.digits or c == ' ' for c in credit_card_number])
        credit_card_number = p.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
        assert len(credit_card_number) == 17
        assert credit_card_number.endswith(str(luhn_checksum(credit_card_number.replace(' ',''))))

# Generated at 2022-06-12 02:24:38.486857
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Create the instance of class Payment
    payment = Payment()
    # Generate the credit card number
    credit_card_number = payment.credit_card_number()
    print('Credit card number is: ' + credit_card_number)
    # Split the credit card number into 4 groups
    groups = re.findall('\d{4}', credit_card_number)
    print('4 groups of credit card number:')
    for group in groups:
        print('\t' + group)

if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-12 02:24:42.972093
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test method credit_card_number of class Payment.

    Args:
        None

    Returns:
        None

    """
    obj = Payment()
    result = obj.credit_card_number()
    print(result)
    assert(result is not None)



# Generated at 2022-06-12 02:24:45.078971
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for _ in range(32):
        print(payment.credit_card_number())

# Generated at 2022-06-12 02:24:50.614081
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    p.credit_card_number(CardType.VISA)
    p.credit_card_number(CardType.MASTER_CARD)
    p.credit_card_number(CardType.AMERICAN_EXPRESS)



# Generated at 2022-06-12 02:24:53.320797
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number() == '4860 0755 8267 8028'
    assert len(Payment().credit_card_number()) == 19


# Generated at 2022-06-12 02:24:56.622567
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Generate credit card number
    print("Generate credit card number")
    x = Payment()
    print(x.credit_card_number())

# Generated at 2022-06-12 02:25:02.576318
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment1 = Payment(seed=1)
    Payment2 = Payment(seed=1)

    assert Payment1.credit_card_number() == \
        Payment2.credit_card_number()

    Payment1 = Payment(seed=1)
    Payment2 = Payment(seed=2)
    assert Payment1.credit_card_number() != \
        Payment2.credit_card_number()




