

# Generated at 2022-06-25 20:55:25.472775
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = CardType.VISA
    str_0 = payment_0.credit_card_number(
        card_type=card_type_0)


# Generated at 2022-06-25 20:55:28.698268
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number(card_type='Visa')
    assert payment_0.credit_card_number(card_type='MasterCard')
    assert payment_0.credit_card_number(card_type='AmericanExpress')


# Generated at 2022-06-25 20:55:31.232130
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    card_number_0 = payment_1.credit_card_number()


# Generated at 2022-06-25 20:55:37.610634
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """ Test for method credit_card_number of class Payment"""
    payment_2 = Payment()
    credit_card_number_0 = payment_2.credit_card_number(CardType.VISA)
    cc_regex = re.compile(r'^(\d{4})\s(\d{4})\s(\d{4})\s(\d{4})$')
    assert cc_regex.match(credit_card_number_0) is not None



# Generated at 2022-06-25 20:55:39.659102
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    payment_obj = Payment()
    card_number = payment_obj.credit_card_number()
    assert isinstance(card_number, str)
    return "success"



# Generated at 2022-06-25 20:55:42.340742
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(100):
        payment_0 = Payment()
        string_0 = payment_0.credit_card_number(None)
        assert len(string_0) == 19
        assert string_0[0] == '4'

# Unit test credit_card_expiration_date of class Payment

# Generated at 2022-06-25 20:55:48.153116
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    res = payment.credit_card_number()
    assert len(res) == 19
    assert res == '4556 6424 1443 0236' or res == '4912 3046 1731 9377' or res == '4028 6894 8224 8755' or res == '4916 2196 6382 2264' or res == '4929 9465 4322 9074'

if __name__ == "__main__":
    test_case_0()
    test_Payment_credit_card_number()

# Generated at 2022-06-25 20:55:53.827558
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    global int_0
    str_0 = CardType.VISA
    payment_0 = Payment()
    if payment_0.credit_card_number(str_0) != '4546 6690 8562 5253':
        raise AssertionError()
    str_0 = CardType.MASTER_CARD
    if payment_0.credit_card_number(str_0) != '5595 6661 2404 9173':
        raise AssertionError()
    str_0 = CardType.AMERICAN_EXPRESS
    if payment_0.credit_card_number(str_0) != '3782 678463 44988':
        raise AssertionError()
    

# Generated at 2022-06-25 20:55:59.594379
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_number = payment_0.credit_card_number()
    assert len(card_number) == 19
    assert card_number.count('-') == 0
    assert card_number.count(' ') == 3
    assert card_number.count('/') == 0
    print(card_number)


# Generated at 2022-06-25 20:56:02.431574
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment(LOCALE)
    CardType_0 = get_random_item(CardType, rnd=payment_0.random)
    str_0 = payment_0.credit_card_number(CardType_0)
    assert str_0 is not None


# Generated at 2022-06-25 20:56:22.637097
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    int_1 = payment_1.credit_card_number(card_type=CardType.VISA)
    assert re.match(re.compile(r'\d{4} \d{4} \d{4} \d{4}'), str(int_1))
    int_2 = payment_1.credit_card_number(card_type=CardType.MASTER_CARD)
    assert re.match(re.compile(r'\d{4} \d{4} \d{4} \d{4}'), str(int_2))
    int_3 = payment_1.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-25 20:56:32.643733
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    # Test with default value of argument card_type
    str_0 = payment.credit_card_number()
    assert(isinstance(str_0, str))
    assert(len(str_0) == 19)

    # Test with value Visa for argument card_type
    str_1 = payment.credit_card_number(card_type=CardType.VISA)
    assert(isinstance(str_1, str))
    assert(len(str_1) == 19)

    # Test with value MasterCard for argument card_type
    str_2 = payment.credit_card_number(card_type=CardType.MASTER_CARD)
    assert(isinstance(str_2, str))
    assert(len(str_2) == 19)

    # Test with value AmericanExpress for argument card_type


# Generated at 2022-06-25 20:56:36.341117
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    card_type_1 = CardType.AMERICAN_EXPRESS
    exp_1 = payment_1.credit_card_number(card_type_1=card_type_1)
    assert exp_1 == payment_1.credit_card_number(card_type_1=card_type_1)


# Generated at 2022-06-25 20:56:37.798708
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_0.credit_card_number(CardType.VISA)


# Generated at 2022-06-25 20:56:40.054617
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    credit_card_number_0 = payment_0.credit_card_number()
    assert credit_card_number_0 is not None


# Generated at 2022-06-25 20:56:48.594003
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    # Create the object to be test
    payment_0 = Payment()

    # Testing the method when card_type is None
    str_0 = payment_0.credit_card_number()

    assert re.match(r'^[\d\s]{19}$', str_0) == None

    # Testing the method when card_type is CardType.VISA
    str_0 = payment_0.credit_card_number(card_type=CardType.VISA)

    assert re.match(r'^[\d\s]{19}$', str_0) == None

    # Testing the method when card_type is CardType.MASTER_CARD
    str_0 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)


# Generated at 2022-06-25 20:56:49.948675
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    assert type(payment_1.credit_card_number()) == str


# Generated at 2022-06-25 20:56:50.867162
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    int_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:56:53.947111
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    int_0 = payment_0.cvv()
    value_0 = payment_0.credit_card_number()

    assert re.match(r'(\d{4})(\s)(\d{4})(\s)(\d{4})(\s)(\d{4})', value_0) is not None
    

# Generated at 2022-06-25 20:56:55.406866
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    int_1 = payment_1.credit_card_number()
    int_2 = payment_1.credit_card_number()


# Generated at 2022-06-25 20:57:21.983197
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    int_0 = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert (len(int_0) > 0)


# Generated at 2022-06-25 20:57:26.446928
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    MasterCard = payment_1.credit_card_number(CardType.MASTER_CARD)
    mc2 = re.compile(r'^(?:(?:\d{4}-){3}\d{4}|\d{4} \d{4} \d{4} \d{4})$')
    assert mc2.match(MasterCard)



# Generated at 2022-06-25 20:57:34.029592
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    credit_card_network_0 = payment_0.credit_card_network()
    credit_card_number_0 = payment_0.credit_card_number()
    assert credit_card_number_0 == '4556 7233 1118 8419'
    credit_card_number_1 = payment_0.credit_card_number(CardType.VISA)
    assert credit_card_number_1 == '4455 5299 1152 2450'
    credit_card_number_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert credit_card_number_2 == '3782 822463 10001'


# Generated at 2022-06-25 20:57:37.163839
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    char_str_0 = payment.credit_card_number(CardType.MASTER_CARD)
    check_char_str_0 = 'MASTER_CARD' in char_str_0
    assert check_char_str_0


# Generated at 2022-06-25 20:57:39.048522
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert isinstance(payment.credit_card_number(), str)


# Generated at 2022-06-25 20:57:41.734733
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment(seed=5)

    str_0 = payment_0.credit_card_number()
    assert str_0 == '2221 7816 4668 0852'



# Generated at 2022-06-25 20:57:44.309571
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    credit_card_number_0 = Payment().credit_card_number()
    # Test if the credit_card_number is a str using the isinstance function
    assert isinstance(credit_card_number_0, str)


# Generated at 2022-06-25 20:57:47.181466
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_number_0 = payment_0.credit_card_number()
    assert len(card_number_0) == 19


# Generated at 2022-06-25 20:57:53.079682
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert str_0 == '4444 5344 5163 1778'
    str_0 = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert str_0 == '5560 4722 6792 7149'
    str_0 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert str_0 == '3412 448976 27440'


# Generated at 2022-06-25 20:57:56.139513
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    credit_card = payment.credit_card_number(card_type)

    assert card_type.name in credit_card
    assert len(credit_card) == 19

# Generated at 2022-06-25 20:58:41.646692
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    int_0 = str(str_0)

