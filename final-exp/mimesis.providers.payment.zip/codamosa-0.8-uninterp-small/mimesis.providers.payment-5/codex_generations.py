

# Generated at 2022-06-25 20:55:30.961285
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    global CreditCardType, card_type
    CreditCardType = CardType
    CreditCardType.VISA = 1
    CreditCardType.MASTER = 2
    CreditCardType.AMEX = 3
    list_0 = [CreditCardType.VISA, CreditCardType.MASTER, CreditCardType.VISA]
    list_1 = [CreditCardType.MASTER, CreditCardType.AMEX, CreditCardType.VISA]
    list_2 = [CreditCardType.AMEX, CreditCardType.MASTER, CreditCardType.VISA]
    list_3 = [CreditCardType.VISA, CreditCardType.VISA, CreditCardType.AMEX]
    list_4 = [CreditCardType.MASTER, CreditCardType.MASTER, CreditCardType.MASTER]

# Generated at 2022-06-25 20:55:35.683362
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type = CardType.AMERICAN_EXPRESS
    int_0 = payment_0.credit_card_number(card_type)
    assert int_0 is not None
    assert payment_0.credit_card_number(card_type) == int_0


# Generated at 2022-06-25 20:55:38.781543
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pr = Payment()
    actual = re.compile('([\d]{4} [\d]{4} [\d]{4} [\d]{4})')
    result = pr.credit_card_number()
    assert re.match(actual, result)

# Generated at 2022-06-25 20:55:40.820965
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card = p.credit_card_number(CardType.MASTER_CARD)
    assert card == "5288 9404 0368 0081"


# Generated at 2022-06-25 20:55:44.092100
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert re.match('\d{4} \d{4} \d{4} \d{4}', str_0)


# Generated at 2022-06-25 20:55:46.684111
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)
    assert str_0 == ""


# Generated at 2022-06-25 20:55:48.190703
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:55:52.401709
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.search(r'^[4][0-9]{15}$', payment.credit_card_number(CardType.VISA)) \
        is not None
    assert re.search(r'^[5][1-5][0-9]{14}$', payment.credit_card_number(CardType.MASTER_CARD)) \
        is not None
    assert re.search(r'^[3][4|7][0-9]{13}$', payment.credit_card_number(CardType.AMERICAN_EXPRESS)) \
        is not None

# Generated at 2022-06-25 20:55:56.630802
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    string_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:56:01.526537
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_2 = Payment()
    payment_2.credit_card_number()
    payment_1 = Payment()
    payment_1.credit_card_number(CardType.VISA)
    payment_3 = Payment()
    payment_3.credit_card_number(CardType.MASTER_CARD)
    payment_4 = Payment()
    payment_4.credit_card_number(CardType.AMERICAN_EXPRESS)


# Generated at 2022-06-25 20:56:13.747066
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    print(payment.credit_card_number() == credit_card_number)


# Generated at 2022-06-25 20:56:19.103062
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    number_0 = Payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert number_0 == '3743 844017 90623'
    number_0 = Payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert number_0 == '3492 449347 30642'
    number_0 = Payment.credit_card_number(CardType.VISA)
    assert number_0 == '4571 3073 3682 2193'
    number_0 = Payment.credit_card_number(CardType.MASTER_CARD)
    assert number_0 == '5111 6600 0088 2279'
    number_0 = Payment.credit_card_number(CardType.VISA)
    assert number_0 == '4864 9993 5227 6990'

# Unit test

# Generated at 2022-06-25 20:56:20.563022
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    string_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:56:22.423373
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    credit_card_number_0 = payment_0.credit_card_number()
    assert credit_card_number_0 == "5476 1724 5497 4167"


# Generated at 2022-06-25 20:56:32.342194
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    int_0 = payment.cvv()
    str_0 = payment.credit_card_number()
    str_1 = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    str_2 = payment.credit_card_number(CardType.MASTER_CARD)
    str_3 = payment.credit_card_number(CardType.VISA)

    assert payment.cvv() == int_0
    assert payment.credit_card_number() == str_0
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == str_1
    assert payment.credit_card_number(CardType.MASTER_CARD) == str_2
    assert payment.credit_card_number(CardType.VISA) == str_3


# Unit test

# Generated at 2022-06-25 20:56:34.470294
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.MASTER_CARD)
    print(str_0)

# Generated at 2022-06-25 20:56:37.839384
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    card_type = CardType.MASTER_CARD

    payment_0 = Payment()
    credit_card_number = payment_0.credit_card_number(card_type)
    assert len(credit_card_number) == 19


# Generated at 2022-06-25 20:56:41.532480
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    int_1 = payment_1.credit_card_number()
    int_2 = payment_1.credit_card_number()
    int_3 = payment_1.credit_card_number()
    int_4 = payment_1.credit_card_number()


# Generated at 2022-06-25 20:56:47.079345
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    # Testing method credit_card_number of class Payment
    test_Payment_credit_card_number_0 = payment_0.credit_card_number('MasterCard')
    assert re.match((r'\d{3} \d{3} \d{3} \d{3}'), test_Payment_credit_card_number_0), \
    'Assertion failed : Could not match the regex in test_Payment_credit_card_number_0'

# Generated at 2022-06-25 20:56:53.879199
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider_0 = Payment()
    provider_0_credit_card_number = provider_0.credit_card_number()
    print("CC number: " + str(provider_0_credit_card_number))
    provider_1 = Payment()
    provider_1_credit_card_number = provider_1.credit_card_number()
    print("CC number: " + str(provider_1_credit_card_number))
    provider_2 = Payment()
    provider_2_credit_card_number = provider_2.credit_card_number()
    print("CC number: " + str(provider_2_credit_card_number))
    provider_3 = Payment()
    provider_3_credit_card_number = provider_3.credit_card_number()

# Generated at 2022-06-25 20:57:18.267334
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    string_0 = payment_1.credit_card_number()
    assert string_0 != None


# Generated at 2022-06-25 20:57:20.470186
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    cardNumber = payment_1.credit_card_number(CardType.VISA)
    print(cardNumber)


# Generated at 2022-06-25 20:57:28.529768
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    try:
        Payment().credit_card_number(card_type=CardType.VISA)
    except NonEnumerableError:
        assert False

    try:
        Payment().credit_card_number(card_type=CardType.MASTER_CARD)
    except NonEnumerableError:
        assert False

    try:
        Payment().credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    except NonEnumerableError:
        assert False

    try:
        Payment().credit_card_number(card_type=CardType.DISCOVER)
    except NotImplementedError:
        assert True

    try:
        Payment().credit_card_number(card_type=CardType.MAESTRO)
    except NotImplementedError:
        assert True


# Generated at 2022-06-25 20:57:35.838114
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Create random Credit Card Numbers
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    assert credit_card_number

    # Visa
    visa_credit_card_number = payment.credit_card_number(CardType.VISA)
    assert re.match(r'^4\d{3} \d{4} \d{4} \d{4}$', visa_credit_card_number)

    # MasterCard
    master_card_credit_card_number = payment.credit_card_number(CardType.MASTER_CARD)
    assert re.match(r'^(5[1-5]|2[2-7])\d{2} \d{4} \d{4} \d{4}$', master_card_credit_card_number)

    #

# Generated at 2022-06-25 20:57:38.695115
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = CardType.AMERICAN_EXPRESS
    str_0 = payment_0.credit_card_number(card_type_0)


# Generated at 2022-06-25 20:57:41.668885
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', credit_card_number)


# Generated at 2022-06-25 20:57:44.718792
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment(seed=5937)
    card_type = CardType.VISA
    str_0 = payment_0.credit_card_number(card_type)
    assert str_0 == '4778 7575 3570 2952'
    

# Generated at 2022-06-25 20:57:46.092112
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_0.credit_card_number()


# Generated at 2022-06-25 20:57:54.790907
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number('Visa')
    assert str_0 != '6166 5299 9885 7974'
    assert str_0 != '1551 7555 9569 6667'
    assert str_0 != '3781 9265 3312 6681'
    assert str_0 != '7533 7749 8644 4951'
    assert str_0 != '5359 1470 6398 5346'
    assert str_0 != '2340 0818 8766 7226'
    assert str_0 != '7641 1808 2126 9274'
    assert str_0 != '5074 5758 9458 3971'
    assert str_0 != '4930 8221 2887 8562'
    assert str_0 != '9555 9167 9513 1675'

# Generated at 2022-06-25 20:57:56.388320
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc = Payment()
    cc.credit_card_number()
    cc.credit_card_number(CardType.VISA)


# Generated at 2022-06-25 20:58:47.932164
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert type(str_0) is str
    assert len(str_0) is 19
    assert str_0[4] is ' '
    assert str_0[9] is ' '
    assert str_0[14] is ' '

# Generated at 2022-06-25 20:58:52.306059
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert isinstance(payment.credit_card_number(card_type='VISA'), str)
    assert len(payment.credit_card_number(card_type='VISA')) == 19


# Generated at 2022-06-25 20:58:56.488105
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment(seed=1)
    asserts = [
        (payment_0.credit_card_number(), '4455 5299 1152 2450'),
        (payment_0.credit_card_number(), '4716 7545 0388 5985'),
    ]
    for assert_ in asserts:
        assert assert_[0] == assert_[1]

# Generated at 2022-06-25 20:58:58.927062
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """ Test class Payment's method credit_card_number() """
    payment_0 = Payment()
    string_0 = payment_0.credit_card_number()
    assert len(string_0) == 19


# Generated at 2022-06-25 20:59:00.991398
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card = payment.credit_card_number(CardType.VISA)

    assert len(credit_card) == 19
    assert ' ' in credit_card
    assert credit_card[:1] == '4'


# Generated at 2022-06-25 20:59:07.861513
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = Payment().credit_card_number(CardType.VISA)
    assert re.search(r'\d{16}', str_0) is not None
    str_0 = Payment().credit_card_number(CardType.MASTER_CARD)
    assert re.search(r'\d{16}', str_0) is not None
    str_0 = Payment().credit_card_number(CardType.AMERICAN_EXPRESS)
    assert re.search(r'\d{15}', str_0) is not None
    card_number = payment_0.credit_card_number()
    assert re.search(r'\d{16}', card_number) is not None


# Generated at 2022-06-25 20:59:11.744578
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_1 = Payment(seed=759477986)
    assert payment_0.credit_card_number() == '4455 5299 1152 2450'
    assert payment_1.credit_card_number() == '4506 8621 0501 5144'


# Generated at 2022-06-25 20:59:13.865536
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = "MASTER_CARD"
    payment = Payment()
    assert payment.credit_card_number(card_type) == "5377 8891 0667 0277"

# Generated at 2022-06-25 20:59:18.467371
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert str_0.isdigit() is True
    assert len(str_0) == 16


# Generated at 2022-06-25 20:59:20.758354
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # get a reference to the class under test
    payment_class = Payment
    # create an instance of the class under test
    payment_instance = payment_class()
    # execute the method under test
    # verify the results by checking the returned value
    assert payment_instance.credit_card_number(card_type=CardType.MASTER_CARD) == '2221 2297 3950 2102'