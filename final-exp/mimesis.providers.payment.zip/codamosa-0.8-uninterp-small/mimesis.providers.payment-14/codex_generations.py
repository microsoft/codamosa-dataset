

# Generated at 2022-06-25 20:55:29.859127
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    list_0 = [
        "MasterCard", "AmericanExpress", "Visa"
    ]
    for card in list_0:
        dict_0 = {
            "MasterCard": "5",
            "AmericanExpress": "3",
            "Visa": "4"
        }
        str_0 = dict_0[card]
        number = payment_0.credit_card_number(card_type=card)  # type: ignore
        assert number.startswith(str_0)

if __name__ == '__main__':
    test_case_0()
    test_Payment_credit_card_number()

# Generated at 2022-06-25 20:55:33.006019
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    for i in range(0, 100):
        assert len(payment_1.credit_card_number()) == 19


# Generated at 2022-06-25 20:55:42.178270
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_1 = Payment()
    payment_2 = Payment()
    payment_3 = Payment()
    payment_4 = Payment()
    payment_5 = Payment()
    payment_6 = Payment()
    payment_7 = Payment()
    payment_8 = Payment()
    payment_9 = Payment()
    card_type = get_random_item(CardType, rnd=payment_0.random)
    assert (payment_9.credit_card_number(card_type) == payment_1.credit_card_number(card_type))
    assert (payment_9.credit_card_number(card_type) == payment_2.credit_card_number(card_type))

# Generated at 2022-06-25 20:55:42.960313
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert len(Payment().credit_card_number()) == 19


# Generated at 2022-06-25 20:55:44.450699
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    int_0 = payment_0.credit_card_number()



# Generated at 2022-06-25 20:55:46.110481
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(None)

# Generated at 2022-06-25 20:55:53.125115
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test for card type VISA
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number(card_type=CardType.VISA)
    assert str_1[1] == '4'
    # Test for card type AMERICAN_EXPRESS
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    assert str_2[1] == '3' or str_2[1] == '7'
    # Test for card type MASTER CARD
    payment_3 = Payment()
    str_3 = payment_3.credit_card_number(card_type=CardType.MASTER_CARD)

# Generated at 2022-06-25 20:55:55.049885
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number(): 
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    assert type(credit_card_number) is str

# Generated at 2022-06-25 20:55:57.527627
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment1 = Payment()
    payment2 = Payment()
    payment3 = Payment()
    print(payment1.credit_card_number(CardType.VISA))
    print(payment2.credit_card_number(CardType.AMERICAN_EXPRESS))
    print(payment3.credit_card_number(CardType.MASTER_CARD))


# Generated at 2022-06-25 20:55:59.593618
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert type(str_0) == str

# Generated at 2022-06-25 20:56:11.611457
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert(re.match(r'^4\d{3} \d{4} \d{4} \d{4}$', payment.credit_card_number()) is not None)
    assert(re.match(r'^5\d{3} \d{4} \d{4} \d{4}$', payment.credit_card_number(CardType.MASTER_CARD)) is not None)
    assert(re.match(r'^3\d{2} \d{6} \d{5}$', payment.credit_card_number(CardType.AMERICAN_EXPRESS)) is not None)

# Generated at 2022-06-25 20:56:12.541387
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_number = payment_0.credit_card_number()
    assert card_number is not None


# Generated at 2022-06-25 20:56:16.369319
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number(CardType.MASTER_CARD)
    str_2 = payment_1.credit_card_number(CardType.AMERICAN_EXPRESS)
    str_3 = payment_1.credit_card_number()
    str_4 = payment_1.credit_card_number('hello')

# Generated at 2022-06-25 20:56:22.695983
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    
    credit_card_types = [CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]
    payment = Payment()
    credit_card_number = payment.credit_card_number(CardType.VISA)
    assert credit_card_number[0] == "4"
    assert credit_card_number[4:8] == " "
    assert credit_card_number[8:12] == " "
    assert credit_card_number[12:16] == " "
    assert credit_card_number[16:20] == " "
    credit_card_number = payment.credit_card_number(CardType.MASTER_CARD)
    assert credit_card_number[0:2] == "52"

# Generated at 2022-06-25 20:56:25.871221
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    credit_card_number_len = len(credit_card_number.replace(" ", ""))
    assert credit_card_number_len == 16


# Generated at 2022-06-25 20:56:35.375621
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert str_0 == "4613 8781 3734 4790"
    str_1 = payment_0.credit_card_number(CardType.VISA)
    assert str_1 == "4523 5884 7044 0929"
    str_2 = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert str_2 == "2747 8256 2169 2368"
    str_3 = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert str_3 == "5250 4939 9115 5361"
    str_4 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert str

# Generated at 2022-06-25 20:56:43.909129
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment(seed=12345)
    str_0 = payment_0.credit_card_number()
    assert str_0 == '4784 8196 4137 0823', "Incorrect item"
    str_1 = payment_0.credit_card_number(card_type=CardType.VISA)
    assert str_1 == '4444 6403 3870 0185', "Incorrect item"
    str_2 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)
    assert str_2 == '5261 5923 7245 4872', "Incorrect item"
    str_3 = payment_0.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-25 20:56:46.370632
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for i in range(0, 100):
        credit_card_number = payment.credit_card_number()
        assert len(credit_card_number) == 19


# Generated at 2022-06-25 20:56:48.412543
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment0 = Payment()
    card_number = payment0.credit_card_number()
    assert len(card_number) == 19


# Generated at 2022-06-25 20:56:49.413603
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()

# Generated at 2022-06-25 20:57:04.459183
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    re_1 = re.compile('[0-9]{4}[ ]{0,1}[0-9]{4}[ ]{0,1}[0-9]{4}[ ]{0,1}[0-9]{4}')
    bool_1 = re_1.match(str_0) != None
    assert bool_1 == True
    

# Generated at 2022-06-25 20:57:06.254636
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test_type = CardType.MASTER_CARD
    payment_test = Payment()
    result = payment_test.credit_card_number(test_type)

    assert CardType.MASTER_CARD in result


# Generated at 2022-06-25 20:57:08.896852
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Generator object.
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert str_0 is not None


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:57:10.237845
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)

# Generated at 2022-06-25 20:57:11.515590
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    test_Payment_credit_card_number_0(payment_0)


# Generated at 2022-06-25 20:57:13.913415
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    print('credit_card_number:', str_0)


# Generated at 2022-06-25 20:57:17.327672
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_test = Payment()
    for i in range(10):
        credit_card_number_0 = payment_test.credit_card_number()
        print(credit_card_number_0)
#        assert len(credit_card_number_0) == 16


# Generated at 2022-06-25 20:57:19.854050
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert isinstance(str_0, str)
    assert len(str_0.split(' ')) == 4

# Generated at 2022-06-25 20:57:27.975250
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    # Test for method credit_card_number with parameter card_type='VISA'
    str_0 = payment.credit_card_number(card_type='VISA')
    assert(str_0[0:1] == '4')
    # Test for method credit_card_number with parameter card_type='MASTER_CARD'
    str_1 = payment.credit_card_number(card_type='MASTER_CARD')
    assert(
        (
            (str_1[0:1] == '5' and str_1[1:2] == '1') or
            (str_1[0:1] == '2' and str_1[1:2] == '2')
        )
    )
    # Test for method credit_card_number with parameter card_type='AMERICAN

# Generated at 2022-06-25 20:57:30.583587
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_0.credit_card_number(card_type = CardType.VISA)


# Generated at 2022-06-25 20:57:57.148474
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_credit_card_number_0 = Payment()
    card_type = CardType.VISA
    str_1 = payment_credit_card_number_0.credit_card_number(card_type)
    card_type = CardType.MASTER_CARD
    card_type = CardType.VISA
    str_2 = payment_credit_card_number_0.credit_card_number(card_type)
    card_type = CardType.MASTER_CARD
    str_3 = payment_credit_card_number_0.credit_card_number(card_type)
    card_type = CardType.AMERICAN_EXPRESS
    str_4 = payment_credit_card_number_0.credit_card_number(card_type)
    str_5 = payment_credit_card_number_0.credit

# Generated at 2022-06-25 20:57:59.558632
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    str_1 = payment_0.credit_card_number(CardType.MASTER_CARD)
    str_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)


# Generated at 2022-06-25 20:58:03.375432
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)


# Generated at 2022-06-25 20:58:07.195571
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    credit_card_number = payment.credit_card_number(card_type)
    assert credit_card_number[0] == '4'
    assert len(credit_card_number) == 19

# Generated at 2022-06-25 20:58:11.041188
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    payment_0 = Payment()
    print("test_Payment_credit_card_number")
    str_0 = payment_0.credit_card_number()

    assert str_0.isdigit() is True
    assert len(str_0) is 16
    assert str_0[14:16] is '07'



# Generated at 2022-06-25 20:58:12.285059
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    assert type(payment_1.credit_card_number()) == str


# Generated at 2022-06-25 20:58:18.422597
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # test for method credit_card_number of class Payment
    # with parameters card type Visa
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number('Visa')
    # with parameters card type MasterCard
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number('MasterCard')
    # with parameters card type AmericanExpress
    payment_3 = Payment()
    str_3 = payment_3.credit_card_number('American_Express')
    # with parameters card type None
    payment_4 = Payment()
    str_4 = payment_4.credit_card_number(None)
    # with parameters card type JCB
    # payment_5 = Payment()
    # str_5 = payment_5.credit_card_number('JCB')

# Generated at 2022-06-25 20:58:25.910642
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(0, 100):
        payment_1 = Payment()
        credit_card_number_1 = payment_1.credit_card_number()
        credit_card_number_2 = payment_1.credit_card_number(CardType.VISA)
        credit_card_number_3 = payment_1.credit_card_number(CardType.MASTER_CARD)

    # Unit test for method credit_card_expiration_date of class Payment
    def test_Payment_credit_card_expiration_date():
        for i in range(0, 100):
            payment_2 = Payment()
            credit_card_expiration_date_1 = payment_2.credit_card_expiration_date()

# Generated at 2022-06-25 20:58:33.479888
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    str_1 = payment.credit_card_number()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}$', str_1)
    str_2 = payment.credit_card_number(card_type=CardType.VISA)
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}$', str_2)
    str_3 = payment.credit_card_number(card_type=CardType.MASTER_CARD)
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}$', str_3)

# Generated at 2022-06-25 20:58:35.957512
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    Test for method credit_card_number of class Payment
    """
    payment_0 = Payment()
    credit_card_number_0 = payment_0.credit_card_number()
    print(credit_card_number_0)


# Generated at 2022-06-25 20:59:21.019794
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    cc_0 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    try:
        cc_1 = payment_0.credit_card_number(CardType.CHINA_UNIONPAY)
    except:
        pass


# Generated at 2022-06-25 20:59:29.426521
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match(r"\d{4} \d{4} \d{4} \d{4}", p.credit_card_number())
    assert re.match(r"\d{4} \d{4} \d{4} \d{4}", p.credit_card_number(CardType.VISA))
    assert re.match(r"\d{4} \d{4} \d{4} \d{4}", p.credit_card_number(CardType.MASTER_CARD))
    assert re.match(r"\d{4} \d{6} \d{5}", p.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-25 20:59:33.064101
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test credit card number
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()
    assert len(str_1) == 19
    assert not str.isdigit(str_1[0])


# Generated at 2022-06-25 20:59:36.013369
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = get_random_item(CardType, rnd=payment_0.random)
    str_0 = payment_0.credit_card_number(card_type=card_type_0)


# Generated at 2022-06-25 20:59:37.501102
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert re.match(r'([\d]{4}[\s]){3}[\d]{4}', payment_0.credit_card_number())


# Generated at 2022-06-25 20:59:41.888201
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number(CardType.VISA) == "4924 2630 4067 4003"
    assert Payment().credit_card_number(CardType.MASTER_CARD) == "5129 6389 4157 8266"
    assert Payment().credit_card_number(CardType.AMERICAN_EXPRESS) == "3737 33981175205"
    assert type(Payment().credit_card_number()) != str

if __name__ == "__main__":
    test_Payment_credit_card_number()

# Generated at 2022-06-25 20:59:45.881836
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number(card_type=CardType.MASTER_CARD)
    (str_1.startswith('2221') or str_1.startswith('5100')) and \
    str_1.endswith('87')


# Generated at 2022-06-25 20:59:52.988756
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())
    assert re.match(r'\d{4} \d{6} \d{5}', payment.credit_card_number(CardType.AMERICAN_EXPRESS))
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number(CardType.MASTER_CARD))
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number(CardType.VISA))

# Generated at 2022-06-25 20:59:54.411239
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    obj = Payment()
    string = obj.credit_card_number()
    assert isinstance(string, str) is True
    assert len(string) == 19

# Generated at 2022-06-25 20:59:58.167585
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    assert payment.credit_card_number(CardType.VISA).startswith('4')
    assert payment.credit_card_number(CardType.MASTER_CARD).startswith('5')
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS).startswith('3')


# Generated at 2022-06-25 21:01:30.458807
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-25 21:01:33.343886
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment(seed=0)
    assert payment_0.credit_card_number() == '4420 5286 7309 8944'



# Generated at 2022-06-25 21:01:42.638642
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()

    assert re.match(r'VISA 4\d{3}\s\d{4}\s\d{4}\s\d{4}', p.credit_card_number())
    assert re.match(r'MASTER_CARD (2221|5[1-5]\d{2})\s\d{4}\s\d{4}\s\d{4}',
                    p.credit_card_number(CardType.MASTER_CARD))
    assert re.match(r'AMERICAN_EXPRESS (34|37)\s\d{6}\s\d{5}',
                    p.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-25 21:01:45.868598
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=None)

#Unit test for method cvv of class Payment

# Generated at 2022-06-25 21:01:51.199401
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert re.findall(r'\d{4} \d{4} \d{4} \d{4}', str_0)


# Generated at 2022-06-25 21:01:52.256163
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type="Visa")

# Generated at 2022-06-25 21:01:55.581778
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    credit_card_number_0 = Payment().credit_card_number()
    str_0 = str(credit_card_number_0)

    assert(re.match(r'^(\d{4} (\d{4} (\d{4} (\d{4})?)?)?)$', str_0))


# Generated at 2022-06-25 21:01:59.235875
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=12345)
    assert payment.credit_card_number() == "4455 5299 1152 2450"
    assert payment.credit_card_number() == "5597 0271 8907 0914"
    assert payment.credit_card_number() == "4539 4303 6403 4939"
    assert payment.credit_card_number() == "4643 8451 0577 6064"

# Generated at 2022-06-25 21:02:02.008309
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(0, 100):
        payment_0 = Payment()
        str_0 = payment_0.credit_card_number()
        assert re.search('^\d{4} \d{4} \d{4} \d{4}$', str_0)



# Generated at 2022-06-25 21:02:10.031421
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    str_1 = payment_0.credit_card_number(CardType.VISA)
    str_2 = payment_0.credit_card_number(CardType.MASTER_CARD)

    card_type_0 = CardType.VISA
    card_type_1 = CardType.MASTER_CARD
    card_type_2 = CardType.AMERICAN_EXPRESS

    payment_1 = Payment()
    str_3 = payment_1.credit_card_number(card_type_0)
    str_4 = payment_1.credit_card_number(card_type_1)
    str_5 = payment_1.credit_card_number(card_type_2)

    payment_2 = Payment()
