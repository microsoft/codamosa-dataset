

# Generated at 2022-06-25 20:55:30.027970
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    list_1 = [8105, 4134, 9513, 8793, 4343, 3780, 4459, 4368]
    payment = Payment(*list_1)
    card_type = get_random_item(CardType)
    int_1 = payment.credit_card_number(card_type)
    return int_1


# Generated at 2022-06-25 20:55:34.358932
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = get_random_item(CardType, rnd=None)
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type)
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:55:39.544073
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    list_of_credit_card = []
    for i in range(1, 10):
        card = payment.credit_card_number(card_type=CardType.VISA)
        list_of_credit_card.append(card)
    assert list_of_credit_card[0] != list_of_credit_card[1] and \
           list_of_credit_card[0] != list_of_credit_card[2]

# Generated at 2022-06-25 20:55:45.288143
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    exp_inputs = [
        (
            CardType.MASTER_CARD,
        ),
        (
            CardType.VISA,
        ),
        (
            CardType.AMERICAN_EXPRESS,
        ),
    ]
    exp_output = '4455 5299 1152 2450'
    for inputs in exp_inputs:
        assert exp_output == Payment(*inputs).credit_card_number(inputs[0])


# Generated at 2022-06-25 20:55:55.786272
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    list_0 = ['M', 'E', 'H', 'I', 'Y', 'P']
    list_1 = ['t', ';', '5', '$', '8', 'c']
    list_2 = ['u', '_', 'y', 'X', 'M', 'P']
    list_3 = ['S', 'w', 'Q', 'd', 'q', '4']
    list_4 = ['A', '-', '+', '+', 'o', 'a']
    list_5 = ['+', '&', '&', 'm', 'm', '0']
    list_6 = [int(1), int(3), int(4), int(1), int(4), int(4)]

# Generated at 2022-06-25 20:56:03.835748
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    The first test case checks that the credit_card_number method in the Payment class
    returns a string of the same length as the length of the card type.
    The second test case checks that the credit_card_number method in the Payment class
    returns a string with a suffix which consists of the last digit.
    The third test case checks that the credit_card_number method in the Payment class
    returns a string with a prefix which consists of the first digit.
    The fourth test case checks that the credit_card_number method in the Payment class
    returns a string with a prefix which consists of the first two digits.
    """

    # test case # 0
    CC_type = CardType.AMERICAN_EXPRESS
    payment_0 = Payment()
    CC_number_0 = payment_0.credit_card_number(CC_type)

# Generated at 2022-06-25 20:56:08.931104
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    int_0 = 1673
    list_0 = [int_0, int_0, int_0, int_0]
    payment_0 = Payment(*list_0)
    str_0 = payment_0.credit_card_number()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', str_0) is not None


# Generated at 2022-06-25 20:56:10.535788
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    obj = Payment()
    assert len(obj.credit_card_number()) == 19


# Generated at 2022-06-25 20:56:13.211267
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    list_0 = [0,0,0]
    payment_0 = Payment(*list_0)
    str_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:56:15.987798
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Arbitrary values
    int_0 = 1673
    list_0 = [int_0, int_0, int_0, int_0]
    payment_0 = Payment(*list_0)
    # Test for method credit_card_number of class Payment
    str_0 = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:56:31.896494
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    data = [payment.credit_card_number(CardType.VISA)]
    data.append(payment.credit_card_number(CardType.MASTER_CARD))
    data.append(payment.credit_card_number(CardType.AMERICAN_EXPRESS))

    assert type(data[0]) is str
    assert type(data[1]) is str
    assert type(data[2]) is str

    assert data[0][0] == '4'
    assert data[1][0] == '5'
    assert data[2][0] == '3'


# Generated at 2022-06-25 20:56:37.165196
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    str = payment.credit_card_number()

    str = payment.credit_card_number(CardType.VISA)

    str = payment.credit_card_number(CardType.MASTER_CARD)

    str = payment.credit_card_number(CardType.AMERICAN_EXPRESS)

    # Void: NotImplementedError: if card_type not supported.
    # str = payment.credit_card_number(CardType.DINERS_CLUB)


# Generated at 2022-06-25 20:56:40.056818
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    chars = (string.digits + ' ')

    for _ in range(1000):
        assert all(char in chars for char in payment.credit_card_number())
        assert len(payment.credit_card_number()) == 19

# Generated at 2022-06-25 20:56:42.343922
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    print(str_0)
    print(type(str_0))


# Generated at 2022-06-25 20:56:45.111113
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()

    expected_result_0 = '4455 5299 1152 2450'
    actual_result_0 = payment_0.credit_card_number()
    assert expected_result_0 == actual_result_0


# Generated at 2022-06-25 20:56:50.902424
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    str_1 = payment_0.credit_card_number()
    assert str_0 != str_1
    assert str_0 != Payment().credit_card_number()
    assert Payment().credit_card_number() != str_1
    assert Payment().credit_card_number() != Payment().credit_card_number()
    print(str_1)


if __name__ == '__main__':
    test_case_0()
    test_Payment_credit_card_number()

# Generated at 2022-06-25 20:56:56.446624
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Assume
    self = Payment()

    # Assert
    result_str_0 = re.match("^\d{4} \d{4} \d{4} \d{4}$", self.credit_card_number(CardType.VISA))
    result_str_1 = re.match("^\d{4} \d{4} \d{4} \d{4}$", self.credit_card_number(CardType.MASTER_CARD))
    result_str_2 = re.match("^\d{4} \d{6} \d{5}$", self.credit_card_number(CardType.AMERICAN_EXPRESS))

    # Test
    assert result_str_0 is not None
    assert result_str_1 is not None

# Generated at 2022-06-25 20:56:56.910295
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test_case_0()

# Generated at 2022-06-25 20:57:06.695366
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', Payment().credit_card_number()) == None
    assert re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', Payment().credit_card_number()) == None
    assert re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', Payment().credit_card_number()) == None
    assert re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', Payment().credit_card_number()) == None

# Generated at 2022-06-25 20:57:08.639830
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert True
    

# Generated at 2022-06-25 20:57:26.886516
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # payment_0 = Payment()
    # assert payment_0.credit_card_number() == None
    try:
        payment_0 = Payment()
        payment_0.credit_card_number(card_type='Angular')
    except NonEnumerableError as e:
        pass


# Generated at 2022-06-25 20:57:34.548147
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    passed = True
    payment_0 = Payment()

    regex_0 = re.compile(r'(\d{4})(\d{4})(\d{4})(\d{4})')
    str_0 = payment_0.credit_card_number()

    assert len(str_0) == 19
    assert str_0 == regex_0.search(str_0).group(1) + " " + \
        regex_0.search(str_0).group(2) + " " + regex_0.search(str_0).group(3) + " " + \
        regex_0.search(str_0).group(4)



# Generated at 2022-06-25 20:57:43.155916
# Unit test for method credit_card_number of class Payment

# Generated at 2022-06-25 20:57:52.339568
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert re.search('^[3350-5599]{4}-[3350-5599]{4}-[3350-5599]{4}-[3350-5599]{4}$', str_0)
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()
    assert re.search('^[3350-5599]{4}-[3350-5599]{4}-[3350-5599]{4}-[3350-5599]{4}$', str_1)
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number()

# Generated at 2022-06-25 20:57:53.617922
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:57:56.961869
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_0.random.seed(5)
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert str_0 == '4455 5299 1152 2450'



# Generated at 2022-06-25 20:58:00.412849
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', Payment.credit_card_number(CardType.VISA))
    assert re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', Payment.credit_card_number(CardType.MASTERCARD))
    assert re.match(r'\d{4}\s\d{6}\s\d{5}', Payment.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-25 20:58:10.738758
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Assert credit_card_number of Visa is a valid credit card
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert luhn_checksum(str_0.replace(' ', ''), 16) == True
    # Assert credit_card_number of American Express is a valid credit card
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert luhn_checksum(str_0.replace(' ', ''), 15) == True
    # Assert credit_card_number of MasterCard is a valid credit card
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert l

# Generated at 2022-06-25 20:58:11.857335
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    str_0 = Payment().credit_card_number()
    length_0 = len(str_0)
    assert length_0 == 19


# Generated at 2022-06-25 20:58:13.126622
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:58:45.689489
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Sample test case
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()

    assert type(str_1) == str # Verify that str_1 is a string


# Generated at 2022-06-25 20:58:51.613697
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print("\nrunning unit test for method credit_card_number of class Payment")
    payment_0 = Payment()
    payment_1 = Payment()
    str_0 = payment_0.credit_card_number()
    str_1 = payment_1.credit_card_number()
    if str_0 == str_1:
        print("Test failed. A random credit card number is always the same")
    else:
        print("Test passed.")


# Generated at 2022-06-25 20:58:55.192852
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    regex_1 = re.compile(r'\d{4}\s\d{4}\s\d{4}\s\d{4}')
    result_1 = regex_1.match(payment_1.credit_card_number())
    assert result_1



# Generated at 2022-06-25 20:58:59.413692
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    str_1 = payment_0.credit_card_number(CardType.MASTER_CARD)
    str_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-25 20:59:03.865941
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print('\nUnittest for method credit_card_number of class Payment:\n')
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number()
    payment_3 = Payment()
    str_3 = payment_3.credit_card_number()
    payment_4 = Payment()
    str_4 = payment_4.credit_card_number()
    payment_5 = Payment()
    str_5 = payment_5.credit_card_number()
    assert type(str_1) is str
    assert type(str_2) is str
    assert type(str_3) is str
    assert type(str_4) is str
    assert type(str_5) is str
    print

# Generated at 2022-06-25 20:59:06.895607
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    stat_0 = set()
    for i in range(1000):
        payment_0 = Payment()
        cc_tmp = payment_0.credit_card_number()
        stat_0.add(cc_tmp)
    assert len(stat_0) == 1000

# Generated at 2022-06-25 20:59:11.601963
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_credit_card_number_0 = Payment()
    payment_credit_card_number_1 = Payment()
    payment_credit_card_number_2 = Payment()
    payment_credit_card_number_0.credit_card_number()
    assert payment_credit_card_number_1.credit_card_number().isdigit() is True
    assert payment_credit_card_number_2.credit_card_number().isdigit() is True

# Generated at 2022-06-25 20:59:15.955627
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Unit test for method credit_card_number of class Payment
    # Generate a random credit card number.
    # :param card_type: Issuing Network. Default is Visa.
    payment_0 = Payment()
    card_type_0 = payment_0.random.randint(1, 50)
    str_0 = payment_0.credit_card_number(card_type=card_type_0)
    assert re.match(r'[0-9]*', str_0)
    assert len(str_0) == 16



# Generated at 2022-06-25 20:59:18.369083
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    result = re.match(r'(\d{4})(\d{4})(\d{4})(\d{4})', Payment().credit_card_number())
    assert result is not None


# Generated at 2022-06-25 20:59:19.431266
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # TODO: implement unittest for this method
    # Actual test
    test_case_0()

# Generated at 2022-06-25 21:00:29.971709
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    card_type_0 = CardType.MASTER_CARD
    str_0 = payment_1.credit_card_number(card_type_0)
    assert len(str_0) == 19


# Generated at 2022-06-25 21:00:31.281128
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number(card_type=None)


# Generated at 2022-06-25 21:00:33.978503
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4532 5866 8038 0122'
    assert payment.credit_card_number() == '5446 2477 1797 8188'
    assert payment.credit_card_number() == '4916 6073 0477 0220'


# Generated at 2022-06-25 21:00:36.653024
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Arrange
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    # Act
    result = re.search(r"(\d{4})\s?(\d{4})\s?(\d{4})\s?(\d{4})", credit_card_number)
    # Assert
    assert result != None


# Generated at 2022-06-25 21:00:40.295217
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    data = [
        ('american_express', str),
        ('master_card', str),
        ('visa', str),
        ]

    for name, expected_type in data:
        method = getattr(Payment(), name)
        result = method()
        assert isinstance(result, expected_type)


# Generated at 2022-06-25 21:00:43.952834
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()
    assert len(str_1) == 19
    str_2 = payment_1.credit_card_number(CardType.VISA)
    assert len(str_2) == 19
    str_3 = payment_1.credit_card_number(CardType.MASTER_CARD)
    assert len(str_3) == 19
    str_4 = payment_1.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(str_4) == 17

# Generated at 2022-06-25 21:00:45.499202
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    number = payment.credit_card_number()
    assert number == '4455 5299 1152 2450'


# Generated at 2022-06-25 21:00:46.687521
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for i in range(100):
        exp = payment.credit_card_number()
        assert len(exp) == 19


# Generated at 2022-06-25 21:00:51.228779
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test random generation
    assert len(Payment().credit_card_number()) == 19
    assert len(Payment().credit_card_number(CardType.VISA)) == 19
    assert len(Payment().credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(Payment().credit_card_number(CardType.AMERICAN_EXPRESS)) == 18

    # Test exceptions
    for argument_type in ['string', 42, 42.0, True, False, None, [], {}]:
        try:
            Payment().credit_card_number(argument_type)
            assert False, 'expected NonEnumerableError'
        except NonEnumerableError:
            pass


# Generated at 2022-06-25 21:00:57.542602
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert type(str_0) is str
    assert str_0.isdigit()
    assert len(str_0) == 16
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert type(str_0) is str
    assert str_0.isdigit()
    assert len(str_0) == 16
    str_0 = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert type(str_0) is str
    assert str_0.isdigit()
    assert len(str_0) == 16
    str_0 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert type

# Generated at 2022-06-25 21:02:52.343122
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type_enum = CardType
    #Test for all kinds of cards
    str_0 = payment.credit_card_number(card_type_enum.VISA)
    str_1 = payment.credit_card_number(card_type_enum.MASTER_CARD)
    str_2 = payment.credit_card_number(card_type_enum.AMERICAN_EXPRESS)
    #Test for random card
    str_3 = payment.credit_card_number()


# Generated at 2022-06-25 21:02:57.884907
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # card_type = CardType.VISA
    # payment_0 = Payment()
    # str_0 = payment_0.credit_card_number(card_type)
    # assert re.match(r'^(\d{4}\s){3}\d{4}$', str_0)
    assert True

# Generated at 2022-06-25 21:02:59.480379
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 21:03:01.551307
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()

    assert str_0 == '4455 5299 1152 2450'



# Generated at 2022-06-25 21:03:06.591196
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.VISA
    card_type_str = str(card_type)
    str_0 = Payment().credit_card_number(card_type=card_type)
    str_1 = Payment().credit_card_number(card_type=card_type_str)
    assert str_0 == str_1


# Generated at 2022-06-25 21:03:11.110053
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()  # a call to a function
    lst_0 = [1, 2, 3]
    lst_0.sort()
    i_0 = payment_0.random.randint(0, 9)
    i_1 = payment_0.random.randint(0, 9)
    payment_1 = Payment(seed=0)
    str_1 = payment_1.credit_card_number()  # a call to a function


# Generated at 2022-06-25 21:03:16.993230
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    # Test case 1
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()

    # Test case 2
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number()

    # Test case 3
    payment_3 = Payment()
    str_3 = payment_3.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)

    # Test case 4
    payment_4 = Payment()
    str_4 = payment_4.credit_card_number(card_type=CardType.MASTER_CARD)

    # Test case 5
    payment_5 = Payment()
    str_5 = payment_5.credit_card_number(card_type=CardType.VISA)

    # Test case 6
    payment_6 = Payment

# Generated at 2022-06-25 21:03:25.243091
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # testing default
    payment0 = Payment()
    credit_card_number0 = payment0.credit_card_number()
    assert credit_card_number0 != payment0.credit_card_number()
    assert len(credit_card_number0.replace(" ", "")) == 16

    # testing argument CardType.VISA
    payment1 = Payment()
    assert payment1.credit_card_number(CardType.VISA) != payment1.credit_card_number(CardType.VISA)
    assert payment1.credit_card_number(CardType.VISA) != payment1.credit_card_number(CardType.MASTER_CARD)
    assert payment1.credit_card_number(CardType.VISA) != payment1.credit_card_number(CardType.AMERICAN_EXPRESS)

    # testing argument Card

# Generated at 2022-06-25 21:03:25.970402
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_0.credit_card_number()



# Generated at 2022-06-25 21:03:30.666184
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number(CardType.MASTER_CARD) #  '4406 9281 5763 2060'
    assert payment_0.credit_card_number(CardType.AMERICAN_EXPRESS) #  '3419 081187 07744'
    assert payment_0.credit_card_number() #  '4920 4168 8098 9291'
    assert payment_0.credit_card_number() #  '4405 8688 7292 5107'
    assert payment_0.credit_card_number(CardType.MASTER_CARD) #  '2221 0332 8141 6220'
    assert payment_0.credit_card_number(CardType.VISA) #  '4539 5838 1474 5592'