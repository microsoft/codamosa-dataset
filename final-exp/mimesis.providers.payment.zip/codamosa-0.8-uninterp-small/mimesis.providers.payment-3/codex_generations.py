

# Generated at 2022-06-25 20:55:23.430604
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    expected = 16
    payment = Payment()
    actual = len(payment.credit_card_number())
    assert expected == actual


# Generated at 2022-06-25 20:55:32.328115
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert str_0.startswith("3421")
    assert len(str_0) == 17
    str_1 = payment_0.credit_card_number(CardType.VISA)
    assert len(str_1) == 19
    str_2 = payment_0.credit_card_number(CardType.VISA)
    assert str_2.startswith("4")
    str_3 = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert len(str_3) == 19
    str_4 = payment_0.credit_card_number(CardType.VISA)
    assert str_4.startswith("4")




# Generated at 2022-06-25 20:55:41.668766
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test when card_type equals CardType.VISA
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    # Test when card_type equals CardType.MASTER_CARD
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number(CardType.MASTER_CARD)
    # Test when card_type equals CardType.AMERICAN_EXPRESS
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number(CardType.AMERICAN_EXPRESS)
    # Test when card_type is not CardType.VISA or CardType.MASTER_CARD
    payment_3 = Payment()

# Generated at 2022-06-25 20:55:45.567854
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payload = "VISA"
    payment = Payment()
    card = payment.credit_card_number(CardType[payload])
    r = re.compile(r"\d{4}\s\d{4}\s\d{4}\s\d{4}")
    r.match(card)
    assert True


# Generated at 2022-06-25 20:55:47.327549
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number() == '4555 5299 1152 2450'


# Generated at 2022-06-25 20:55:49.074539
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.AMERICAN_EXPRESS
    payment = Payment()
    payment.credit_card_number(card_type)


# Generated at 2022-06-25 20:55:50.643319
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=CardType.VISA)



# Generated at 2022-06-25 20:55:55.934463
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert payment_0.is_credit_card_number(str_0)
    assert str_0.count('-') == 0
    assert str_0.count(' ') == 3
    assert str_0[6] == ' '
    assert str_0[11] == ' '
    assert str_0[16] == ' '
    assert str_0[4] in '0123456789'
    assert str_0[16] in '0123456789'
    assert str_0[0] in '0123456789'
    assert int(str_0[15]) == payment_0.luhn_checksum(str_0) % 10


# Generated at 2022-06-25 20:56:04.189836
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}',
                    p.credit_card_number(CardType.VISA)) is not None
    
    assert re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}',
                    p.credit_card_number(CardType.MASTER_CARD)) is not None
    
    assert re.match(r'\d{4}\s\d{6}\s\d{5}',
                    p.credit_card_number(CardType.AMERICAN_EXPRESS)) is not None
    

# Generated at 2022-06-25 20:56:13.823326
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test = Payment()

    # Test CardType.VISA
    CreditCard = test.credit_card_number()
    
    # Check if len is correct
    # Visa should be 16
    assert len(CreditCard) == 16
    for i in range(0,3):
        CreditCard = test.credit_card_number()
        assert len(CreditCard) == 16

    # Check if first digit is correct
    # Visa should start with 4
    check_digit_1 = CreditCard.split()[0][0]
    check_digit_2 = CreditCard.split()[1][0]
    check_digit_3 = CreditCard.split()[2][0]
    check_digit_4 = CreditCard.split()[3][0]
    assert check_digit_1 == '4'

# Generated at 2022-06-25 20:56:22.048040
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)
    str_1 = payment_0.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    str_2 = payment_0.credit_card_number(card_type=CardType.DISCOVERY)


# Generated at 2022-06-25 20:56:25.116373
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc_num = Payment.credit_card_number("Visa")
    print(cc_num)

if __name__=='__main__':
    test_case_0()
    test_Payment_credit_card_number()

# Generated at 2022-06-25 20:56:32.051968
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Create object for class Payment
    payment = Payment()
    # Get card number
    card = payment.credit_card_number()
    # Try fetching card numbers from it
    card_split = card.replace(' ', '')
    card_split_0 = card_split[:4]
    # Assert that it is a valid card number
    assert type(card_split) is str
    assert type(card_split_0) is str
    assert int(card_split_0) >= 0 and int(card_split_0) <= 9999

# Generated at 2022-06-25 20:56:40.334000
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    number_1 = payment_1.credit_card_number()
    number_2 = payment_1.credit_card_number(card_type=CardType.VISA)
    number_3 = payment_1.credit_card_number(card_type=CardType.MASTER_CARD)
    number_4 = payment_1.credit_card_number(
        card_type=CardType.AMERICAN_EXPRESS)

    list_for_test = [number_1, number_2, number_3, number_4]
    for element in list_for_test:
        str1 = int(element.replace(" ", ""))
        str_4 = luhn_checksum(str1)

# Generated at 2022-06-25 20:56:42.827562
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number(card_type=CardType.VISA)

test_case_0()
test_Payment_credit_card_number()

# Generated at 2022-06-25 20:56:44.629787
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert len(str_0) == 19

# Generated at 2022-06-25 20:56:50.773470
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    tuple_0 = (
        CardType.VISA,
        CardType.MASTER_CARD,
        CardType.AMERICAN_EXPRESS,
    )
    assert get_random_item(tuple_0, (), (), rnd=payment_1.random) in (
        CardType.VISA,
        CardType.MASTER_CARD,
        CardType.AMERICAN_EXPRESS,
    )
    assert payment_1.credit_card_number(CardType.VISA) in (
        '4455 5299 1152 2450',
    )

# Generated at 2022-06-25 20:56:53.042176
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card = payment.credit_card_number()
    assert len(card) == 19 or len(card) == 16
    assert card[4] == ' '
    assert card[9] == ' '
    assert card[14] == ' '

# Generated at 2022-06-25 20:56:54.703939
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    assert re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}$', payment.credit_card_number())

# Generated at 2022-06-25 20:56:59.048287
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    str_1 = payment.credit_card_number(CardType.MASTER_CARD)
    str_2 = payment.credit_card_number(CardType.VISA)
    str_3 = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(str_1.replace(" ","")) is 16
    assert len(str_2.replace(" ","")) is 16
    assert len(str_3.replace(" ","")) is 15
    assert type(str_1) is str
    assert type(str_2) is str
    assert type(str_3) is str


# Generated at 2022-06-25 20:57:11.351243
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert re.match(r'\d{16}', payment_0.credit_card_number())



# Generated at 2022-06-25 20:57:13.132985
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(0, 10):
        payment_1 = Payment()
        credit_card_number_0 = payment_1.credit_card_number()



# Generated at 2022-06-25 20:57:16.402665
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_1 = Payment()
    assert (payment_1.credit_card_number(CardType.VISA) != payment_0.credit_card_number(CardType.VISA))



# Generated at 2022-06-25 20:57:24.596586
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment_0 = Payment()
    valid_number_0 = Payment_0.credit_card_number()
    valid_number_1 = '4455 5299 1152 2450'
    valid_number_2 = Payment_0.credit_card_number(CardType.VISA)
    valid_number_3 = Payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    valid_number_4 = Payment_0.credit_card_number(CardType.MASTER_CARD)
    valid_number_5 = Payment_0.credit_card_number(CardType.DISCOVER)
    valid_number_6 = Payment_0.credit_card_number(CardType.JCB)

    # If card_type is not an enum object of the CardType class

# Generated at 2022-06-25 20:57:29.750447
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    printing = False
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    crc = luhn_checksum(str_0[:-1])
    crc_str_0 = str_0[-1]
    assert crc_str_0 == crc
    if printing:
        print("str_0: ", str_0)


# Generated at 2022-06-25 20:57:32.513167
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()
    print(str_1)
    str_2 = payment_1.credit_card_number()
    print(str_2)

# Generated at 2022-06-25 20:57:33.310667
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test for this method
    return True



# Generated at 2022-06-25 20:57:35.472800
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card = payment.credit_card_number()
    assert len(credit_card) == 19

# Generated at 2022-06-25 20:57:37.481522
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(payment_0.random.choice(CardType))


# Generated at 2022-06-25 20:57:39.553032
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number() == '4545 9223 4431 6606'


# Generated at 2022-06-25 20:58:04.614578
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test = Payment()
    card = test.credit_card_number()
    assert isinstance(card, str)
    assert len(card.replace(' ', '')) == 16
    assert card[-1] == luhn_checksum(card[:-1])

# Generated at 2022-06-25 20:58:06.925487
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(str(payment.credit_card_number())) == 19


# Generated at 2022-06-25 20:58:08.240375
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:58:11.239361
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    int_0 = payment_0.credit_card_number()
    assert int_0 != 34
    assert int_0 != 37
    assert int_0 != 21
    assert int_0 != 22


# Generated at 2022-06-25 20:58:14.506743
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_1 = Payment()

    str_0 = payment_0.credit_card_number("CardType.MasterCard")
    assert len(str_0) == 19

    str_1 = payment_1.credit_card_number("CardType.AmericanExpress")
    assert len(str_1) == 17


# Generated at 2022-06-25 20:58:21.099075
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(str_0) == 17
    str_1 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(str_1) == 17
    str_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(str_2) == 17
    str_3 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(str_3) == 17
    str_4 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(str_4) == 17
    str_5 = payment

# Generated at 2022-06-25 20:58:23.330387
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    engine_0 = Payment()
    str_0 = engine_0.credit_card_number(8)
    str_1 = engine_0.credit_card_number()

# Generated at 2022-06-25 20:58:28.499709
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()

    valid_card_regexp = re.compile(r'^([1-9]{1}[0-9]{15}|[1-9]{1}[0-9]{15}|[1-9]{1}[0-9]{15})$')
    if valid_card_regexp.match(str_0):
        assert True
    else:
        assert False



# Generated at 2022-06-25 20:58:30.072149
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pl = Payment()
    for i in range(10):
        assert isinstance(pl.credit_card_number(), str)


# Generated at 2022-06-25 20:58:33.127037
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    bool_0 = bool(re.search('^\\d{4} \\d{4} \\d{4} \\d{4}$', str_0))
    assert bool_0 is True


# Generated at 2022-06-25 20:59:26.366426
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)


# Generated at 2022-06-25 20:59:35.482443
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Unit test: test default behaviour with no input
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    boolean_0 = len(str_0) == 19
    assert boolean_0
    # Unit test: test behaviour with input CardType.VISA
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number(CardType.VISA)
    boolean_1 = len(str_1) == 19
    boolean_2 = str_1[:1] == '4'
    assert (boolean_1 and boolean_2)
    # Unit test: test behaviour with input CardType.MASTER_CARD
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number(CardType.MASTER_CARD)
    boolean_

# Generated at 2022-06-25 20:59:39.390671
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment('en')
    assert re.match(r'^\d{16}$', payment_0.credit_card_number(CardType.VISA))
    assert re.match(r'^\d{16}$', payment_0.credit_card_number(CardType.MASTER_CARD))
    assert re.match(r'^\d{15}$', payment_0.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-25 20:59:42.020626
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    payment_1 = Payment()
    cc_num_1 = payment_1.credit_card_number()

    payment_2 = Payment()
    cc_num_2 = payment_2.credit_card_number()

    assert cc_num_1 != cc_num_2


# Generated at 2022-06-25 20:59:44.492999
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    print(str_0)


# Generated at 2022-06-25 20:59:46.592556
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    credit_card_number_0 = payment_0.credit_card_number()
    assert isinstance(credit_card_number_0, str)


# Generated at 2022-06-25 20:59:48.734969
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for the credit card number method of the payment class"""
    payment = Payment()
    assert bool(re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', payment.credit_card_number()))



# Generated at 2022-06-25 20:59:54.049540
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = get_random_item(CardType, rnd=payment_0.random)
    str_0 = payment_0.credit_card_number(card_type=card_type_0)
    str_1 = payment_0.credit_card_number(card_type=card_type_0)
    str_2 = payment_0.credit_card_number(card_type=card_type_0)



# Generated at 2022-06-25 21:00:00.888908
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from random import seed

    # Random numbers initialization
    seed(20)

    # test_0 - all arguments are optional, no arguments are specified, expected outcome is
    # a credit card number;
    test_0_expected_outcome: str = '4040 4517 1412 2431';
    test_0_actual_outcome: str = Payment(seed=20).credit_card_number();
    assert test_0_expected_outcome == test_0_actual_outcome;

    # test_1 - the argument card_type is specified, expected outcome is a credit card number;
    test_1_expected_outcome: str = '5023 4890 4635 6932';
    test_1_actual_outcome: str = Payment(seed=20).credit_card_number(CardType.MASTER_CARD);
    assert test_

# Generated at 2022-06-25 21:00:02.473584
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    cardtype_0 = CardType.VISA
    str_0 = payment_0.credit_card_number(cardtype_0)



# Generated at 2022-06-25 21:01:46.671567
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Generating CreditCardNumber with Seed "1"
    payment_0 = Payment(seed=1)
    assert payment_0.credit_card_number(CardType.MASTER_CARD) == "5576 7970 5873 5122"



# Generated at 2022-06-25 21:01:51.342647
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(None)


# Generated at 2022-06-25 21:01:53.042484
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    print(re.compile(r'\d{16}').match(str_0))


# Generated at 2022-06-25 21:01:55.794390
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    regex = re.compile(r'\d{4} \d{4} \d{4} \d{4}')
    assert re.fullmatch(regex, Payment().credit_card_number()) is not None



# Generated at 2022-06-25 21:02:02.485385
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    from mimesis.providers.base import BaseProvider
    _BaseProvider__random = BaseProvider._BaseProvider__random
    _BaseProvider__seed = BaseProvider._BaseProvider__seed
    _BaseProvider__tokenizer = BaseProvider._BaseProvider__tokenizer
    _Payment__person = Payment._Payment__person
    # Setup
    c = Payment()
    card_type = CardType.VISA
    # Exercise the SUT
    result = c.credit_card_number(card_type)
    # Assert
    assert isinstance(result, str)
    assert result.startswith('4')
    assert _Payment__person == Payment._Payment__person
    assert _BaseProvider__random == BaseProvider._BaseProvider__

# Generated at 2022-06-25 21:02:10.479680
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert isinstance(payment.credit_card_number(CardType.VISA), str)
    assert len(payment.credit_card_number(CardType.VISA)) == 19
    assert payment.credit_card_number(CardType.VISA).split()[0][0] == '4'

    assert isinstance(payment.credit_card_number(CardType.MASTER_CARD), str)
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert payment.credit_card_number(CardType.MASTER_CARD).split()[0][0] == '2' or payment.credit_card_number(CardType.MASTER_CARD).split()[0][0] == '5'


# Generated at 2022-06-25 21:02:13.588079
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number(card_type = CardType.VISA)
    print("Card type: {}".format(CardType.VISA.value))
    print("Credit card number: {}".format(credit_card_number))


# Generated at 2022-06-25 21:02:17.607006
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = CardType.VISA
    str_0 = payment_0.credit_card_number(card_type_0)
    expected = "4455 5299 1152 2450"
    assert expected == str_0

# Generated at 2022-06-25 21:02:21.857033
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment_1.credit_card_number())

# Generated at 2022-06-25 21:02:25.895789
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert str_0 is not None
