

# Generated at 2022-06-25 20:55:29.530248
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for _ in range(10):
        card_number = payment.credit_card_number()
        assert len(card_number) == 19
        assert re.match(r'\d{16}', card_number)
        assert card_number[4] == ' '
        assert card_number[9] == ' '
        assert card_number[14] == ' '
        assert card_number[-1] == luhn_checksum(card_number[:-1])


# Generated at 2022-06-25 20:55:34.700797
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = None
    str_0 = payment_0.credit_card_number(card_type_0)
    assert re.match(r'^\d{4} \d{4} \d{4} \d{4}$', str_0)


# Generated at 2022-06-25 20:55:43.611599
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert len(str_0) == 19
    assert str_0.count(' ') == 3
    assert str_0.count('4') == 1
    assert not str_0.replace(' ','').isdigit()
    assert str_0.isdigit() == False

    payment_1 = Payment()
    str_1 = payment_1.credit_card_number(CardType.MASTER_CARD)
    assert len(str_1) == 19
    assert str_1.count(' ') == 3
    assert str_1.count('2') == 1
    assert not str_1.replace(' ','').isdigit()
    assert str_1.isdigit() == False

    payment

# Generated at 2022-06-25 20:55:50.442984
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card = payment.credit_card_number(CardType.VISA)
    assert credit_card == '4543 6222 6123 7121'
    assert isinstance(credit_card, str)

    credit_card = payment.credit_card_number(CardType.MASTER_CARD)
    assert credit_card == '2421 5412 3904 8078'
    assert isinstance(credit_card, str)

    credit_card = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert credit_card == '3401 754809 00498'
    assert isinstance(credit_card, str)

# Generated at 2022-06-25 20:55:54.082882
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type='Visa')
    str_1 = payment_0.credit_card_number(card_type='AmericanExpress')
    str_2 = payment_0.credit_card_number(card_type='MasterCard')
    assert isinstance(str_0, str)
    assert isinstance(str_1, str)
    assert isinstance(str_2, str)


# Generated at 2022-06-25 20:55:58.590198
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    print(str_0)
    # Output:
    # 4585 3926 8058 7806
    
    str_1 = payment_0.credit_card_number(CardType.MASTER_CARD)
    print(str_1)
    # Output:
    # 5195 9357 5453 2146
    
    str_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    print(str_2)
    # Output:
    # 3731 006876 84557

# Generated at 2022-06-25 20:56:05.526332
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Payment.credit_card_number()
    # Expected True
    print(len(Payment().credit_card_number()) == 19)
    # Expected True
    print(len(Payment().credit_card_number(CardType.MASTER_CARD)) == 19)
    # Expected True
    print(len(Payment().credit_card_number(CardType.AMERICAN_EXPRESS)) == 17)
    # Expected True
    print(len(Payment().credit_card_number()) == 19)
    # Expected True
    print(len(Payment().credit_card_number(CardType.MASTER_CARD)) == 19)
    # Expected True
    print(len(Payment().credit_card_number(CardType.AMERICAN_EXPRESS)) == 17)
    # Expected True


# Generated at 2022-06-25 20:56:07.694285
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert type(p.credit_card_number(CardType.VISA)) == str


# Generated at 2022-06-25 20:56:10.300215
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test for default value of card_type
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    print(str_0)


# Generated at 2022-06-25 20:56:12.326061
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    print(card_number)

# Generated at 2022-06-25 20:56:20.152511
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment0 = Payment('en')
    card_type0 = payment0.random.choice([card_type for card_type \
    in CardType])
    credit_card_number0 = payment0.credit_card_number(card_type0)
    assert bool((re.match('^(\d{4} ){3}\d{4}$', credit_card_number0)))


# Generated at 2022-06-25 20:56:28.602672
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Initialize the instance of Payment
    payment_0 = Payment()
    # Get a random credit card type to give to the method credit_card_number
    rand_type = payment_0.credit_card_type()
    credit_card_number_0 = payment_0.credit_card_number(rand_type)
    # Get the correct length of the card number
    if rand_type == 0:
        # Visa's card number's length is 16
        assert len(credit_card_number_0) == 16
    elif rand_type == 1:
        # MasterCard's card number's length is 16
        assert len(credit_card_number_0) == 16
    elif rand_type == 2:
        # American Express's card number's length is 15
        assert len(credit_card_number_0) == 15

# Unit

# Generated at 2022-06-25 20:56:32.250012
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    str_1 = payment.credit_card_number()
    len_str_1 = len(str_1.replace(' ', ''))

    # The string returned by credit_card_number must be 16 characters long
    assert len_str_1 == 16


# Generated at 2022-06-25 20:56:40.672401
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cardType = CardType.VISA
    result1 = Payment()
    result1.credit_card_number(cardType)

    cardType = CardType.MASTER_CARD
    result2 = Payment()
    result2.credit_card_number(cardType)

    cardType = CardType.AMERICAN_EXPRESS
    result3 = Payment()
    result3.credit_card_number(cardType)

    cardType = CardType.DISCOVER
    result4 = Payment()
    result4.credit_card_number(cardType)

    cardType = CardType.DINERS_CLUB
    result5 = Payment()
    result5.credit_card_number(cardType)

    cardType = CardType.JCB
    result6 = Payment()
    result6.credit_card_number(cardType)




# Generated at 2022-06-25 20:56:42.507897
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    instance = Payment()
    result = instance.credit_card_number()
    assert isinstance(result, str)


# Generated at 2022-06-25 20:56:44.641944
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)


# Generated at 2022-06-25 20:56:45.780435
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    s = payment_0.credit_card_number()

# Generated at 2022-06-25 20:56:47.480713
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()

# Generated at 2022-06-25 20:56:49.171174
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_0.credit_card_number(CardType.MASTER_CARD)


# Generated at 2022-06-25 20:56:50.118802
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()


# Generated at 2022-06-25 20:57:01.822738
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment(seed=int(0))
    str_0 = payment_0.credit_card_number(card_type=None)
    assert str_0 == "4477 9301 2471 9472"
    str_1 = payment_0.credit_card_number(card_type=None)
    assert str_1 == "4426 2777 4671 2072"
    str_2 = payment_0.credit_card_number(card_type=None)
    assert str_2 == "4605 5249 3911 1736"
    str_3 = payment_0.credit_card_number(card_type=None)
    assert str_3 == "4639 8308 2466 4224"
    str_4 = payment_0.credit_card_number(card_type=None)

# Generated at 2022-06-25 20:57:06.589316
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    NUM = 50
    payment = Payment()
    for _ in range(NUM):
        assert len(payment.credit_card_number(CardType.VISA)) == 16
        print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))
        assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 15
        print(payment.credit_card_number(CardType.MASTER_CARD))
        assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 16

# Generated at 2022-06-25 20:57:09.265597
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test payment_0.credit_card_number()"""
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)



# Generated at 2022-06-25 20:57:10.656149
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:57:18.858171
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    rnd_0 = Payment()
    exp_0 = rnd_0.credit_card_number()
    i = 0
    while exp_0[i] == ' ':
        i += 1
    luhn = 0
    double = False
    while i < len(exp_0):
        if exp_0[i] != ' ':
            if double:
                luhn += int(exp_0[i])
                double = False
            else:
                if (int(exp_0[i]) * 2) >= 10:
                    luhn += (int(exp_0[i]) * 2) - 9
                    double = True
                else:
                    luhn += int(exp_0[i]) * 2
        i += 1
    last_digit = luhn % 10

# Generated at 2022-06-25 20:57:27.013007
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # In case card_type is None, we check that the returned value is included
    # in the set {CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS}
    payment_0 = Payment()
    assert payment_0.credit_card_number() in {'4455 5299 1152 2450', '5429 9369 6293 3043', '3700 7900 8547 583'}
    payment_1 = Payment()
    assert payment_1.credit_card_number(card_type=None) in {'4455 5299 1152 2450', '5429 9369 6293 3043', '3700 7900 8547 583'}
    # In case card_type is not None, we check that the returned value starts
    # with the card_type, and is not equal to 'False

# Generated at 2022-06-25 20:57:34.624374
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    str_1 = payment_0.credit_card_number(CardType.MASTER_CARD)
    str_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    # Make sure the string is in the correct format
    assert str_0.split(" ")[0] == str_0.split(" ")[1][0:4]
    assert str_1.split(" ")[0] == str_1.split(" ")[1][0:4]
    assert str_2.split(" ")[0] == str_2.split(" ")[1][0:4]


# Generated at 2022-06-25 20:57:43.220007
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment(seed=26)
    str_0 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)
    assert str_0 == "4627 9033 1208 7140"
    str_1 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)
    assert str_1 == "5161 1769 1814 1210"
    str_2 = payment_0.credit_card_number(card_type=CardType.VISA)
    assert str_2 == "4809 8252 0527 9043"
    str_3 = payment_0.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    assert str_3 == "3745 020473 47770"

# Generated at 2022-06-25 20:57:49.060612
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    _payment = Payment()
    
    for i in range(10):
        result = _payment.credit_card_number("visa")
        assert result[0] == '4'
        
        result = _payment.credit_card_number("mastercard")
        assert result[0:2] in ['51', '52', '53', '54', '55']
        
        result = _payment.credit_card_number("american_express")
        assert result[0:2] in ['34', '37']

# Generated at 2022-06-25 20:57:51.507294
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    assert credit_card_number is not None


# Generated at 2022-06-25 20:58:13.289554
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    card_number_1 = payment_1.credit_card_number(card_type=CardType.VISA)
    payment_2 = Payment()
    card_number_2 = payment_2.credit_card_number(card_type=CardType.MASTER_CARD)
    payment_3 = Payment()
    card_number_3 = payment_3.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)


# Generated at 2022-06-25 20:58:17.096145
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    # Test mode
    assert payment_0.credit_card_number(
        payment_0.random.choice(list(CardType.list())),
    ) == '5553 7206 4900 2174'

    payment_1 = Payment(seed=1)
    assert payment_1.credit_card_number(
        payment_1.random.choice(list(CardType.list())),
    ) == '5105 1051 0510 5100'


# Generated at 2022-06-25 20:58:24.635674
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()

    # unit test for CardType.VISA
    assert str(payment_0.credit_card_number(CardType.VISA))[:1] == '4'

    # unit test for CardType.MASTER_CARD
    assert int(str(payment_0.credit_card_number(CardType.MASTER_CARD))[:2]) in range(22, 28) or \
        int(str(payment_0.credit_card_number(CardType.MASTER_CARD))[:2]) in range(51, 56)

    # unit test for CardType.AMERICAN_EXPRESS
    assert str(payment_0.credit_card_number(CardType.AMERICAN_EXPRESS))[:2] in ['34', '37']

# Generated at 2022-06-25 20:58:28.043149
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    if str_0 is None:
        print("None")
    else:
        print(" ".join(re.findall("[a-zA-Z0-9]+", str_0)))


# Generated at 2022-06-25 20:58:31.605693
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    data = {}
    data["credit_card_number"] = payment.credit_card_number()
    if (re.match("\d{4} \d{4} \d{4} \d{4}", data["credit_card_number"])):
        print("Success")
    else:
        print("Fail")



# Generated at 2022-06-25 20:58:36.511090
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number()
    # assert payment.credit_card_number(card_type=CardType.VISA)
    # assert payment.credit_card_number(card_type=CardType.MASTER_CARD)
    # assert payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    # try:
    #     assert payment.credit_card_number(card_type=CardType.MAESTRO)
    # except NonEnumerableError:
    #     pass





# Generated at 2022-06-25 20:58:40.974249
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment_0.credit_card_number(CardType.MASTER_CARD) == '5100 4402 9577 6629'
    return True


# Generated at 2022-06-25 20:58:41.456023
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payme

# Generated at 2022-06-25 20:58:43.408568
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_0.credit_card_number('Visa')
    payment_1 = Payment()
    payment_1.credit_card_number('Visa')


# Generated at 2022-06-25 20:58:44.664101
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test = Payment()
    assert len(test.credit_card_number())==19


# Generated at 2022-06-25 20:59:25.192643
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    str_1 = payment_0.credit_card_number(CardType.VISA)
    assert str_0.__len__() >= 16 and str_0.__len__() <= 16
    assert str_0.__eq__(str_1)


# Generated at 2022-06-25 20:59:33.411028
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    num_0 = payment_0.credit_card_number(card_type='MASTER_CARD')
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', num_0)
    num_1 = payment_0.credit_card_number(card_type='VISA')
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', num_1)
    num_2 = payment_0.credit_card_number(card_type='AMERICAN_EXPRESS')
    assert re.match(r'\d{4} \d{6} \d{5}', num_2)


# Generated at 2022-06-25 20:59:35.098551
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert True


# Generated at 2022-06-25 20:59:37.999268
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(0, 10):
        card_number = Payment().credit_card_number()
        if re.match(r'([0-9]{4} ){3}[0-9]{4}', card_number) is None:
            raise ValueError("Generated credit card number is not valid: " + card_number)

# Generated at 2022-06-25 20:59:45.477598
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(random=Random(0))
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number() == '4455 5299 1152 2450'

# Generated at 2022-06-25 20:59:48.442816
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc = Payment()
    assert cc.credit_card_number()
    assert cc.credit_card_number(CardType.VISA)
    assert cc.credit_card_number(CardType.MASTER_CARD)
    assert cc.credit_card_number(CardType.AMERICAN_EXPRESS)

test_Payment_credit_card_number()

# Generated at 2022-06-25 20:59:55.353927
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    payment_2 = Payment()

    card_number_0 = payment_1.credit_card_number()
    print(card_number_0)

    card_type_master_card = CardType.MASTER_CARD
    card_number_1 = payment_2.credit_card_number(card_type_master_card)
    print(card_number_1)

    # Check if the credit card number is a 15 digit or 16 digit
    assert (len(card_number_0) == 16) or (len(card_number_0) == 15)
    assert (len(card_number_1) == 16) or (len(card_number_1) == 15)



# Generated at 2022-06-25 21:00:01.740030
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    print(str_0)
    str_1 = payment_0.credit_card_number()
    print(str_1)
    str_2 = payment_0.credit_card_number()
    print(str_2)
    str_3 = payment_0.credit_card_number()
    print(str_3)
    str_4 = payment_0.credit_card_number()
    print(str_4)
    str_5 = payment_0.credit_card_number()
    print(str_5)
    str_6 = payment_0.credit_card_number()
    print(str_6)
    str_7 = payment_0.credit_card_number()
    print(str_7)

# Generated at 2022-06-25 21:00:03.064453
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert(len(p.credit_card_number()) == 19)


# Generated at 2022-06-25 21:00:08.053414
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    assert payment_1.credit_card_number(CardType.VISA)
    assert payment_1.credit_card_number(CardType.MASTER_CARD)
    assert payment_1.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert not payment_1.credit_card_number(CardType.DISCOVER)



# Generated at 2022-06-25 21:01:21.606981
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_number = Payment(seed=0).credit_card_number()
    assert card_number == "4455 5299 1152 2450"


# Generated at 2022-06-25 21:01:28.568823
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    credit_card_number = payment.credit_card_number(card_type)
    card_number = re.sub(' ', '', credit_card_number)
    assert (card_number[0:4] == str(card_type.value)) and len(card_number) == 16 and (luhn_checksum(card_number) == '')

# Generated at 2022-06-25 21:01:29.780185
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    result = payment.credit_card_number()
    assert len(result) == 19
    assert isinstance(result, str)

# Generated at 2022-06-25 21:01:34.346032
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print("Test credit_card_number of class Payment")
    payment_0 = Payment(seed=33)
    # Test credit_card_number when card type is CardType.VISA
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert (str_0 == "4394 2210 8611 5060")
    # Test credit_card_number when card type is CardType.MASTER_CARD
    str_1 = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert (str_1 == "5567 7890 0675 5382")
    # Test credit_card_number when card type is CardType.AMERICAN_EXPRESS
    str_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-25 21:01:36.565062
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == "4500 9108 4653 1310"

# Generated at 2022-06-25 21:01:40.434232
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    payment_0 = Payment()
    result = payment_0.credit_card_number()
    assert len(result) == 19


# Generated at 2022-06-25 21:01:46.436794
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    payment_0 = Payment()
    card_type_0 = payment_0.credit_card_network()

    card_num_0 = payment_0.credit_card_number()
    card_num_1 = payment_0.credit_card_number(card_type_0)
    assert card_num_0 != card_num_1

    card_num_2 = payment_0.credit_card_number(CardType.VISA)
    card_num_3 = payment_0.credit_card_number(CardType.MASTER_CARD)
    card_num_4 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert card_num_0 == card_num_2 or card_num_1 == card_num_2
    assert card_num_0 == card_num_

# Generated at 2022-06-25 21:01:51.044769
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19


# Generated at 2022-06-25 21:01:52.129441
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card = payment.credit_card_number()
    assert card is not None

# Generated at 2022-06-25 21:01:53.554931
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for _ in range(100):
        print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-25 21:04:24.621953
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    str_0 = payment_0.credit_card_number(CardType.MASTER_CARD)
    str_0 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)



# Generated at 2022-06-25 21:04:26.881017
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert(payment.credit_card_number() != '1234 5678 1234 5678')

# Generated at 2022-06-25 21:04:28.669264
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'


# Generated at 2022-06-25 21:04:30.548377
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    num = p.credit_card_number()
    print(num)

if __name__ == '__main__':
    # test_case_0()
    test_Payment_credit_card_number()

# Generated at 2022-06-25 21:04:35.853598
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=CardType.VISA)
    assert len(str_0) == 19
    assert re.search(r'(^((4\d{3})|(5[1-5]\d{2})|(6011))\d{11}(\d|X)$)',
                     str_0.replace(' ', ''))
    str_1 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)
    assert len(str_1) == 19

# Generated at 2022-06-25 21:04:44.328350
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test case 0
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)
    assert (str_0 == '5490 8428 7141 7836')
    # Test case 1
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number(card_type=CardType.VISA)
    assert (str_1 == '4552 7072 2689 0336')
    # Test case 2
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    assert (str_2 == '3717 739855 61610')
    # Test case 3
    payment_3 = Payment()
    str_

# Generated at 2022-06-25 21:04:45.721853
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    CardType_1 = get_random_item(CardType)
    str_1 = payment_1.credit_card_number(CardType_1)

    pass

# Generated at 2022-06-25 21:04:47.249420
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    str_1 = payment_0.credit_card_number()
    assert str_0 != str_1

# Generated at 2022-06-25 21:04:48.414544
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type = None
    str_0 = payment_0.credit_card_number(card_type)
    print(str_0)

# Generated at 2022-06-25 21:04:50.989558
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    str_0 = payment.credit_card_number()
    str_1 = payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    str_2 = payment.credit_card_number(card_type=CardType.VISA)
    str_3 = payment.credit_card_number(card_type=CardType.MASTER_CARD)
    return str_0, str_1, str_2, str_3
