

# Generated at 2022-06-25 20:55:21.548238
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    enum_item_0 = CardType.MASTER_CARD
    enum_item_1 = CardType.MASTER_CARD
    payment_0 = Payment()
    card_type_0 = payment_0.credit_card_number(enum_item_0)
    card_type_1 = payment_0.credit_card_number(enum_item_1)


# Generated at 2022-06-25 20:55:23.793902
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    if not str_0.isdigit():
        assert(False)


# Generated at 2022-06-25 20:55:26.306246
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.AMERICAN_EXPRESS
    payment = Payment()
    str_0 = payment.credit_card_number(card_type)
    assert str_0 == '3751 427890 05820'
    assert str_0 == payment.credit_card_number()


# Generated at 2022-06-25 20:55:33.152323
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test_0 = Payment()
    test_1 = Payment()
    test_2 = Payment()
    test_3 = Payment()
    test_4 = Payment()
    test_5 = Payment()
    test_6 = Payment()
    test_7 = Payment()
    test_8 = Payment()
    test_9 = Payment()
    test_10 = Payment()
    test_11 = Payment()
    test_12 = Payment()
    test_13 = Payment()
    test_14 = Payment()
    test_15 = Payment()
    test_16 = Payment()
    test_17 = Payment()
    test_18 = Payment()
    test_19 = Payment()
    test_20 = Payment()


# Generated at 2022-06-25 20:55:37.010849
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    arg_0 = CardType.VISA
    expected_0 = "4539 4180 5247 2296"
    actual_0 = Payment().credit_card_number(arg_0)
    assert expected_0 == actual_0, "%r != %r" %(expected_0, actual_0)

# Generated at 2022-06-25 20:55:40.295377
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    int_0 = payment_0.random.randint(0, 2147483647)
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert str_0 == '4455 5299 1152 2450'



# Generated at 2022-06-25 20:55:45.488104
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type = CardType.VISA)
    str_1 = payment_0.credit_card_number(card_type = CardType.MASTER_CARD)
    str_2 = payment_0.credit_card_number(card_type = CardType.AMERICAN_EXPRESS)



# Generated at 2022-06-25 20:55:52.253994
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment('en')
    str_0 = payment_0.credit_card_number()
    assert str_0 == "4005 5247 6654 4552"
    str_1 = payment_0.credit_card_number(card_type=None)
    assert str_1 == "4455 5299 1152 2450"
    str_2 = payment_0.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    assert str_2 == "3400 4089 52615"
    str_3 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)
    assert str_3 == "5324 2564 7929 7678"


# Generated at 2022-06-25 20:55:57.503920
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc = Payment()
    assert len(cc.credit_card_number()) == 19
    assert len(cc.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)) == 17


# Generated at 2022-06-25 20:56:06.433199
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # create a instant of class Payment
    _payment = Payment()
    # create new list that contains all items in class CardType
    enum_all = list(CardType.__members__.values())

    # create the regex pattern to match string in the format:^\d{16}$)
    # ^ represent start of string
    # \d represent all digits between 0-9
    # {16} represent 16 digits
    # $ represent start of string
    regex_pattern = re.compile(r'^\d{16}$')
    # iterate over all CardType enum value
    enum_all = list(CardType.__members__.values())

# Generated at 2022-06-25 20:56:12.917842
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:56:18.148437
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type_0: CardType = CardType.VISA
    credit_card_number_0 = Payment().credit_card_number(
        card_type_0,
    )
    assert credit_card_number_0 == '4800 0000 3541 7386'
    card_type_1: CardType = CardType.MASTER_CARD
    credit_card_number_1 = Payment().credit_card_number(
        card_type_1,
    )
    assert credit_card_number_1 == '2546 1604 4380 5883'
    card_type_2: CardType = CardType.AMERICAN_EXPRESS
    credit_card_number_2 = Payment().credit_card_number(
        card_type_2,
    )

# Generated at 2022-06-25 20:56:24.342234
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test_cases = []
    test_cases.append({
        'name': 'test_case_0',
        'assertEqual': '',
        'assertEqualLength': 16,
        'assertTrue': '',
        'assertIn': '',
    })

    # test_case_0
    test_case_0 = {
        'name': 'test_case_0',
        'assertEqual': '',
        'assertEqualLength': 16,
        'assertTrue': '',
        'assertIn': '',
    }

    test_case_0['assertEqualLength'] = len(test_case_0['assertEqual'])
    test_cases.append(test_case_0)

    # test_case_1

# Generated at 2022-06-25 20:56:27.873944
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()
    assert str_1[0] == '4'
    assert len(str_1) == 17
    assert ' ' in str_1


# Generated at 2022-06-25 20:56:30.132554
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()

# Generated at 2022-06-25 20:56:31.583244
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:56:33.388378
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    obj = Payment()
    str = obj.credit_card_number()
    assert type(str) == str
    assert len(str) == 19

# Generated at 2022-06-25 20:56:36.772815
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_test_0 = Payment()
    str_test_0 = payment_test_0.credit_card_number()
    # result = True
    assert re.match(r'\b(?:\d[ -]*?){13,16}\b', str_test_0)


# Generated at 2022-06-25 20:56:42.706896
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    int_0 = 0
    while int_0 < 100:
        str_0 = payment.credit_card_number()
        if not re.match(r'\d{4} \d{4} \d{4} \d{4}', str_0):
            raise Exception(
                'AssertionError: ' + str_0 +
                ' is not matching the following regular expression: \'\\d{4} \\d{4} \\d{4} \\d{4}\'.'
            )
        int_0 += 1

# Generated at 2022-06-25 20:56:45.463375
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert isinstance(card, str)
    card = payment.credit_card_number()
    assert isinstance(card, str)

# Generated at 2022-06-25 20:57:00.995339
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card = payment.credit_card_number()
    valid = len(card.replace(' ', '')) == 16
    assert valid

# Generated at 2022-06-25 20:57:07.549880
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test with CardType as Visa
    card_type = CardType.VISA
    payment = Payment()
    str = payment.credit_card_number(card_type)
    assert (str[0] == '4')

    # Test with CardType as MasterCard
    card_type = CardType.MASTER_CARD
    payment = Payment()
    str = payment.credit_card_number(card_type)
    assert ((str[0] == '2' and str[1] == '2') or (str[0] == '5' and str[1] == '5'))

    # Test with CardType as AmericanExpress
    card_type = CardType.AMERICAN_EXPRESS
    payment = Payment()
    str = payment.credit_card_number(card_type)

# Generated at 2022-06-25 20:57:09.592744
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    print(str_0)
    assert len(str_0) == 19

# Generated at 2022-06-25 20:57:16.878525
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert len(str_0) == 19

if __name__ == '__main__':
    payment_0 = Payment()
    print(payment_0.credit_card_number())
    print(payment_0.credit_card_expiration_date())
    print(payment_0.cvv())
    print(payment_0.credit_card_owner())
    print(payment_0.credit_card_network())
    print(payment_0.cid())
    print(payment_0.paypal())
    print(payment_0.bitcoin_address())
    print(payment_0.ethereum_address())

# Generated at 2022-06-25 20:57:18.347734
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()

# Generated at 2022-06-25 20:57:19.620911
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert type(Payment().credit_card_number()) == str


# Generated at 2022-06-25 20:57:22.848781
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = CardType.VISA
    str_0 = payment_0.credit_card_number(card_type_0)


if __name__ == '__main__':
    test_case_0()
    test_Payment_credit_card_number()

# Generated at 2022-06-25 20:57:25.455581
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    a = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', a.credit_card_number())


# Generated at 2022-06-25 20:57:34.029507
# Unit test for method credit_card_number of class Payment

# Generated at 2022-06-25 20:57:41.104942
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    generator_ = Payment().random
    number = generator_.randint(4000, 4999)
    str_ = str(number)
    while len(str_) < 16 - 1:
        str_ += generator_.choice(string.digits)
    regex_ = re.compile(r'(\d{4})(\d{4})(\d{4})(\d{4})')
    groups_ = regex_.search(str_ + luhn_checksum(str_)).groups()
    card_ = ' '.join(groups_)
    assert card_ in Payment(seed=0).credit_card_number()


# Generated at 2022-06-25 20:58:06.474900
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert re.match(r'\d{16}', Payment().credit_card_number()) is not None



# Generated at 2022-06-25 20:58:08.372403
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert(type(str_0) == str)


# Generated at 2022-06-25 20:58:10.840083
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert (len(str_0) == 16)


# Generated at 2022-06-25 20:58:14.879594
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert type(Payment().credit_card_number()) == str
    assert Payment().credit_card_number()[0] == '4'
    assert type(Payment().credit_card_number()) == str
    assert Payment().credit_card_number().split(' ')[0] == '3792'
    assert type(Payment().credit_card_number()) == str
    assert Payment().credit_card_number()[0] == '5'

# Generated at 2022-06-25 20:58:17.515727
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    method = Payment().credit_card_number
    assert len(method()) == 16
    assert method(CardType.VISA)[0] == '4'
    assert method(CardType.MASTER_CARD)[0] == '5'
    assert method(CardType.AMERICAN_EXPRESS)[:2] in ['34', '37']

# Generated at 2022-06-25 20:58:19.618197
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert re.match(r'\d+ \d+ \d+ \d+', str_0)

# Generated at 2022-06-25 20:58:24.931049
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    items = [CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]

    payment_iter = Payment()
    # Test for equality
    for card in items:
        assert payment_iter.credit_card_number(card) != payment_iter.credit_card_number(card)

    payment_1 = Payment(seed=1233)
    str_1 = '4455 5299 1152 2450'
    assert str_1 == payment_1.credit_card_number(CardType.VISA)

# Generated at 2022-06-25 20:58:32.648266
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', Payment().credit_card_number()) is not None
    for i in range(100):
        assert re.match(r'\d{4} \d{4} \d{4} \d{4}', Payment().credit_card_number(CardType.VISA)) is not None
    for i in range(100):
        assert re.match(r'\d{4} \d{4} \d{4} \d{4}', Payment().credit_card_number(CardType.MASTER_CARD)) is not None

# Generated at 2022-06-25 20:58:33.563132
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number() != ''


# Generated at 2022-06-25 20:58:36.342394
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    regex_0 = re.compile(r'(\d{4})(\d{4})(\d{4})(\d{4})')
    assert regex_0.search(payment_0.credit_card_number()) is not None


# Generated at 2022-06-25 20:59:31.367993
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    str_1 = payment_0.credit_card_number(CardType.MASTER_CARD)
    str_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-25 20:59:34.263510
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc_0 = Payment().credit_card_number()
    test_0 = cc_0 == ('4922 6531 7989 0651')
    assert test_0 == True

# Generated at 2022-06-25 20:59:40.865679
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert (str_0 == '5477 9400 8239 7811')
    payment_0.random = 'g'
    str_1 = payment_0.credit_card_number()
    # assert (str_1 == '4475674474391277')
    str_2 = payment_0.credit_card_number()
    # assert (str_2 == '3626752396672514')
    str_3 = payment_0.credit_card_number()
    # assert (str_3 == '3625661778990900')
    str_4 = payment_0.credit_card_number()
    # assert (str_4 == '3625549983330900')
    str_5 = payment_0

# Generated at 2022-06-25 20:59:42.380809
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test class Payment method credit_card_number."""
    pay = Payment()
    assert len(pay.credit_card_number()) == 19


# Generated at 2022-06-25 20:59:49.975964
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert(type(payment.credit_card_number(CardType.VISA)) == str)
    assert(type(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == str)
    assert(type(payment.credit_card_number(CardType.MASTER_CARD)) == str)
    assert(type(payment.credit_card_number(get_random_item(CardType, rnd=payment.random))) == str)

if __name__ == '__main__':
    import timeit
    print(timeit.timeit("test_Payment_credit_card_number()", number=100, setup="from __main__ import test_Payment_credit_card_number"))

# Generated at 2022-06-25 20:59:55.380283
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_0.CREDIT_CARD_NETWORKS
    str_0 = payment_0.credit_card_number()
    str_1 = payment_0.credit_card_number(card_type='MasterCard')
    str_2 = payment_0.credit_card_number(card_type='AmericanExpress')
    str_3 = payment_0.credit_card_number(card_type='Visa')
    str_4 = payment_0.credit_card_number('Visa')
    str_5 = payment_0.credit_card_number(CardType.VISA)

# Generated at 2022-06-25 20:59:58.068965
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    try:
        payment = Payment('en')
        payment.credit_card_number(CardType.VISA)
    except NonEnumerableError as e:
        print(e)



# Generated at 2022-06-25 21:00:00.888757
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert isinstance(test_case_0(), str)

# Generated at 2022-06-25 21:00:03.037246
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for _ in range(10):
        payment_0 = Payment()
        str_0 = payment_0.credit_card_number()
        assert len(str_0) == 19
        assert len(str_0.split()) == 4

# Generated at 2022-06-25 21:00:05.446238
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert re.fullmatch(r"\d{16}", Payment().credit_card_number())


# Generated at 2022-06-25 21:01:55.463217
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3720 136962 92836'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5531 170461 762346'
    assert payment.credit_card_number(CardType.VISA) == '4993 874674 131697'
    assert payment.credit_card_number() in [
        '4954 473102 441693',
        '5265 616587 438459',
        '4449 057107 473272',
    ]

    # Unit test for method cvv of class Payment

# Generated at 2022-06-25 21:01:56.709183
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    if test_case_0():
        print("Test case passed")
    else:
        print("Test case failed")


# Generated at 2022-06-25 21:02:00.444949
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()
    if str_1 in [payment_1.credit_card_number() for i in range(10000)]:
        print('1) OK: Credit card number is unique.')
    else:
        print('1) Error: Credit card number is not unique.')
    return


# Generated at 2022-06-25 21:02:08.440480
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) in ['4008 9650 9768 6617', '4788 0275 7913 6118', '4444 6969 8829 7393', '4401 1254 7299 8656', '4488 0651 9230 4447', '4116 8123 2094 0394', '4109 4965 4132 4315', '4658 0227 4583 8236', '4099 7759 4938 0287', '4092 9966 5469 6608']

# Generated at 2022-06-25 21:02:11.372889
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    str_1 = payment_0.credit_card_number()
    assert len(str_0) > 0
    assert str_0 != str_1


# Generated at 2022-06-25 21:02:13.802019
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert re.match('^[2-7]\d{3}\s[2-7]\d{3}\s[2-7]\d{3}\s[2-7]\d{3}$', Payment().credit_card_number())


# Generated at 2022-06-25 21:02:14.704822
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 21:02:19.140028
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_0.credit_card_number(CardType.VISA)
    payment_0.credit_card_number(CardType.MASTER_CARD)
    payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)


# Generated at 2022-06-25 21:02:19.969202
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(1):
        test_case_0()

# Generated at 2022-06-25 21:02:22.200577
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19