

# Generated at 2022-06-25 20:55:31.416994
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()

    # Test Visa card
    credit_card_number = payment.credit_card_number(card_type=CardType.VISA)
    assert credit_card_number[0] == '4'
    assert credit_card_number[1] != '0'

    # Test Mastercard
    credit_card_number = payment.credit_card_number(
        card_type=CardType.MASTER_CARD)
    assert credit_card_number[0:2] != '34'
    assert credit_card_number[0:2] != '37'

    # Test American Express
    credit_card_number = payment.credit_card_number(
        card_type=CardType.AMERICAN_EXPRESS)

    assert credit_card

# Generated at 2022-06-25 20:55:40.769805
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    item_0 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert re.search(r'^\d{4}\s\d{6}\s\d{5}$', item_0)
    item_1 = payment_0.credit_card_number(CardType.DINERS_CLUB)
    assert re.search(r'^\d{4}\s\d{4}\s\d{4}\s\d{4}$', item_1)
    item_2 = payment_0.credit_card_number(CardType.VISA)
    assert re.search(r'^\d{4}\s\d{4}\s\d{4}\s\d{4}$', item_2)
    item_3 = payment

# Generated at 2022-06-25 20:55:47.448657
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 16
    assert ' ' in payment.credit_card_number()
    assert payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) != payment.credit_card_number()
    assert payment.credit_card_number(card_type=CardType.VISA) != payment.credit_card_number()
    assert payment.credit_card_number(card_type=CardType.MASTER_CARD) != payment.credit_card_number()


# Generated at 2022-06-25 20:55:48.741589
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    Number = payment.credit_card_number()
    assert isinstance(Number,str)

# Generated at 2022-06-25 20:55:51.904748
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_0.credit_card_number()
    payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    payment_0.credit_card_number(CardType.MASTER_CARD)
    payment_0.credit_card_number(CardType.VISA)


# Generated at 2022-06-25 20:56:02.942478
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment0 = Payment()
    regex_0 = re.compile(r'(\d{4})\s{1}(\d{4})\s{1}(\d{4})\s{1}(\d{4})')
    assert re.match(regex_0, payment0.credit_card_number(CardType.VISA))
    regex_1 = re.compile(r'(\d{4})\s{1}(\d{6})\s{1}(\d{5})')
    assert re.match(regex_1, payment0.credit_card_number(CardType.AMERICAN_EXPRESS))
    # assert re.match(regex_0, payment1.credit_card_number("MasterCard"))
    # print(payment1.credit_card_number("MasterCard"))

# Generated at 2022-06-25 20:56:04.829512
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
	payment_test = Payment()
	test_credit_card_number = payment_test.credit_card_number()


# Generated at 2022-06-25 20:56:07.614491
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    result_0 = payment_0.credit_card_number()
    assert type(result_0) == str


# Generated at 2022-06-25 20:56:12.659576
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    creditCardNumber = payment.credit_card_number(CardType.VISA)
    print(creditCardNumber)
    pattern = re.compile("^[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}$")
    assert pattern.match(creditCardNumber) != None


# Generated at 2022-06-25 20:56:16.703487
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    credit_card_number_1 = payment_0.credit_card_number()
    credit_card_number_2 = payment_0.credit_card_number(card_type=CardType.VISA)
    assert(credit_card_number_1[0] == '4')
    # test for the card type
    assert(credit_card_number_2[0] == '4')
    # test for the card type
    assert(implement_Luhn(credit_card_number_1))
    assert(implement_Luhn(credit_card_number_2))
    # test for the Luhn algorithm


# Generated at 2022-06-25 20:56:32.369861
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Initialize the class
    payment = Payment(seed=0)

    # Create a list for each of the different types of credit cards
    visa_list = []
    master_card_list = []
    american_express_list = []

    # Create a list of all the different credit card types
    card_types = [CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]

    # Generate each of the credit cards 10000 times
    for i in range(10000):
        visa_list.append(payment.credit_card_number(card_type=CardType.VISA))
        master_card_list.append(payment.credit_card_number(card_type=CardType.MASTER_CARD))

# Generated at 2022-06-25 20:56:34.470176
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    output_1 = payment_1.credit_card_number()
    assert len(output_1) == 19


# Generated at 2022-06-25 20:56:42.946515
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_1 = Payment()
    payment_2 = Payment()
    payment_3 = Payment()
    payment_4 = Payment()
    assert_equal(payment_0.credit_card_number(None), "4455 5299 1152 2450")
    assert_equal(payment_1.credit_card_number(CardType.VISA), "4455 5299 1152 2450")
    assert_equal(payment_2.credit_card_number(CardType.MASTER_CARD), "2221 990X XXXX XXXX")
    assert_equal(payment_3.credit_card_number(CardType.AMERICAN_EXPRESS), "3401 234567 890XX")

# Generated at 2022-06-25 20:56:50.983896
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from random import random
    from mimesis.enums import Gender, CardType

    assert Payment().credit_card_number(CardType.AMERICAN_EXPRESS)
    assert Payment().credit_card_number(CardType.MASTER_CARD)
    assert Payment().credit_card_number(CardType.VISA)
    assert Payment().credit_card_number(CardType.MAESTRO)
    assert Payment().credit_card_number(CardType.DISCOVER)
    assert Payment().credit_card_number(CardType.JCB)
    assert Payment().credit_card_number(CardType.DANKORT)
    assert Payment().credit_card_number(CardType.CUP)
    assert Payment().credit_card_number(CardType.UNIONPAY)


# Generated at 2022-06-25 20:56:53.093877
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number(card_type=CardType.MASTER_CARD) == '5172 3813 5027 5193'

# Test assertion for test_case_1

# Generated at 2022-06-25 20:56:54.718641
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_0 = Payment()
    str_0 = card_0.credit_card_number()
    int_0 = len(str_0)
    assert int_0 == 19


# Generated at 2022-06-25 20:56:56.122730
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=123)
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5354 6974 4312 5183'



# Generated at 2022-06-25 20:57:02.737483
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert len(payment_0.credit_card_number(CardType.VISA)) == 19
    assert len(payment_0.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17

# Generated at 2022-06-25 20:57:06.481444
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    while True:
        try:
            assert re.match(r'[\d]{16}', p.credit_card_number())
            break
        except:
            assert False

if __name__ == '__main__':
    p = Payment()
    print(p.credit_card_expiration_date(18, 20))

# Generated at 2022-06-25 20:57:08.079571
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number().__len__() == 19


# Generated at 2022-06-25 20:57:25.900114
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    assert payment_1.credit_card_number(CardType.VISA)
    assert payment_1.credit_card_number(CardType.MASTER_CARD)
    assert payment_1.credit_card_number(CardType.AMERICAN_EXPRESS)
    try:
        payment_1.credit_card_number(CardType.DISCOVER)
    except NonEnumerableError:
        assert True



# Generated at 2022-06-25 20:57:29.682795
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    credit_card_number_0 = payment_0.credit_card_number()
    credit_card_number_1 = payment_0.credit_card_number()
    assert credit_card_number_0 != credit_card_number_1


# Generated at 2022-06-25 20:57:33.032660
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = get_random_item(CardType, rnd=payment_0.random)
    number_0 = payment_0.credit_card_number(card_type_0)
    assert len(number_0) >= 16


# Generated at 2022-06-25 20:57:36.439671
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    payment_0 = Payment()
    payment_0.credit_card_number(card_type=CardType.VISA)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:57:38.585984
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=24)
    assert payment.credit_card_number() == '4155 8097 2147 6690'


# Generated at 2022-06-25 20:57:42.792996
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_1 = Payment()
    payment_2 = Payment()
    payment_3 = Payment()

    assert payment_0.credit_card_number() != \
        payment_1.credit_card_number(), 'wa'
    assert payment_2.credit_card_number() != \
        payment_3.credit_card_number(), 'wa'

# Generated at 2022-06-25 20:57:50.802225
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    # Test for valid card type value Visa
    assert len(payment_0.credit_card_number(CardType.VISA)) == 19
    # Test for valid card type value MasterCard
    assert len(payment_0.credit_card_number(CardType.MASTER_CARD)) == 19
    # Test for valid card type value AmericanExpress
    assert len(payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    # Test for invalid card type
    # assert len(payment_0.credit_card_number("INVALID")) == 0
    # Test for invalid card type None
    assert len(payment_0.credit_card_number(None)) in (19, 17)


# Generated at 2022-06-25 20:57:52.573157
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert len(payment_0.credit_card_number()) == 19


# Generated at 2022-06-25 20:57:59.474087
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test method Payment.credit_card_number.

    For test case:
    1. Make a payment object.
    2. Generate a random credit card number.
    3. Match the generated credit card number with the expected card numbers.
    4. If the match is successful, the test is successful.
    5. If the match is unsuccessful, the test is unsuccessful.
    :return: True if test successful, False if test unsuccessful.
    """

    payment_0 = Payment()
    number_0 = payment_0.credit_card_number()
    pattern_0 = re.compile(r'4\d{3}(\s|-)\d{4}(\s|-)\d{4}(\s|-)\d{4}')

# Generated at 2022-06-25 20:58:02.863354
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=1)
    cardNumber = payment.credit_card_number()
    assert cardNumber == '4199 3232 0343 5169'

# Generated at 2022-06-25 20:58:30.413723
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 16
    assert type(payment.credit_card_number()) == str


# Generated at 2022-06-25 20:58:32.525717
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    c = Payment()
    r = c.credit_card_number()
    assert len(r) >= 15
    assert len(r) <= 19


# Generated at 2022-06-25 20:58:34.173242
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    dict_1 = payment_1.credit_card_owner()
    assert len(dict_1['credit_card']) == 19


# Generated at 2022-06-25 20:58:35.940736
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card = Payment()
    result = re.match(r'^[0-9]{13,16}$', card.credit_card_number())
    assert result != None

# Generated at 2022-06-25 20:58:38.785064
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    credit_card_number_1 = payment_1.credit_card_number()
    assert type(credit_card_number_1) == str


# Generated at 2022-06-25 20:58:41.781129
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cardtype = "VISA"
    credit_card_number = Payment().credit_card_number(cardtype)

    assert (isinstance(credit_card_number,str))
    assert (len(credit_card_number) == 19)


# Generated at 2022-06-25 20:58:46.227071
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.MASTER_CARD
    assert re.match(r'^(\d{4} ){3}\d{4}$', Payment().credit_card_number(card_type))
    assert re.match(r'^(\d{4} ){3}\d{4}$', Payment().credit_card_number())
    card_type = CardType.AMERICAN_EXPRESS
    assert re.match(r'^(\d{4} ){2}\d{5}$', Payment().credit_card_number(card_type))

# Generated at 2022-06-25 20:58:56.068073
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment(seed=42)
    card_type_1 = payment_1.random.choice(list(CardType))
    re_1 = re.compile(r'(\d{4})\s(\d{4})\s(\d{4})\s(\d{4})')
    str_num_1 = re_1.search(payment_1.credit_card_number(card_type_1)).groups()
    assert str_num_1 == ('4979', '9748', '5190', '1057')
    re_2 = re.compile(r'(\d{4})\s(\d{6})\s(\d{5})')
    str_num_2 = re_2.search(payment_1.credit_card_number(CardType.AMERICAN_EXPRESS)).groups()


# Generated at 2022-06-25 20:59:00.493439
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA).startswith('4')
    assert payment.credit_card_number(CardType.MASTER_CARD).startswith('5')
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS).startswith('3')
    try:
        payment.credit_card_number(CardType.UNKNOWN)
    except NonEnumerableError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 20:59:07.828554
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    v_0 = payment.credit_card_number(CardType.VISA)
    v_1 = payment.credit_card_number(CardType.VISA)

    m_0 = payment.credit_card_number(CardType.MASTER_CARD)
    m_1 = payment.credit_card_number(CardType.MASTER_CARD)

    e_0 = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    e_1 = payment.credit_card_number(CardType.AMERICAN_EXPRESS)

    assert (len(v_0) == 16) and (len(v_1) == 16)
    assert (len(m_0) == 16) and (len(m_1) == 16)

# Generated at 2022-06-25 21:00:08.455912
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    cc = payment.credit_card_number()

    assert len(cc) == 19
    assert cc[6] == ' '


# Generated at 2022-06-25 21:00:10.856426
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert re.match(r'\d{16}', str_0) is not None
    str_1 = payment_0.credit_card_number('MasterCard')
    assert re.match(r'\d{16}', str_1) is not None

# Generated at 2022-06-25 21:00:17.233338
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    random_obj = Random()
    random_obj.seed(0)
    r_list = [3, 9, 3, 2, 5, 9, 0, 2, 6, 9, 1, 0, 5, 9, 0, 2]

    payment_0 = Payment(random_obj)

    # Test method credit_card_number of class Payment with parameters
    # in range [0, 12]
    card_number_0 = payment_0.credit_card_number(card_type=12)
    assert (card_number_0 == "4455 5299 1152 2450")

    # Test method credit_card_number of class Payment with parameters
    # in range [13, 14]
    card_number_1 = payment_0.credit_card_number(card_type=13)