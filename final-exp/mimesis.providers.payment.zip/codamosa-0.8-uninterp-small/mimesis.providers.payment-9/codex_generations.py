

# Generated at 2022-06-25 20:55:31.076401
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment(seed=1596176837)
    int_1 = 7
    str_0 = payment_1.credit_card_number(int_1) # '4455 5299 1152 2450'
    int_2 = 2
    str_1 = payment_1.credit_card_number(int_2) # '4455 5299 1152 2450'
    int_3 = 3
    str_2 = payment_1.credit_card_number(int_3) # '4455 5299 1152 2450'
    int_4 = 0
    str_3 = payment_1.credit_card_number(int_4) # '4455 5299 1152 2450'
    int_5 = 1
    str_4 = payment_1.credit_card_number(int_5) # '4455 5

# Generated at 2022-06-25 20:55:38.704561
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print("Testing credit_card_number in Payment")

    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    print(str_0)

    str_1 = payment_0.credit_card_number(CardType.MASTER_CARD)
    print(str_1)

    str_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    print(str_2)

    str_3 = payment_0.credit_card_number()
    print(str_3)



# Generated at 2022-06-25 20:55:42.938775
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    #  str_0 = payment_0.credit_card_number(card_type=payment_0.random.choice([CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]))
    return str_0

# Generated at 2022-06-25 20:55:47.810766
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = CardType.MASTER_CARD
    str_0 = payment_0.credit_card_number(card_type_0)
    assert len(str_0) == 19
    assert str_0[1] == ' '
    assert str_0[6] == ' '
    assert str_0[11] == ' '
    assert str_0[16] == ' '


# Generated at 2022-06-25 20:55:54.225816
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type = CardType.VISA
    str_0 = payment_0.credit_card_number(card_type)
    assert str_0.startswith('4')
    assert len(str_0.split(' ')) == 4
    card_type = CardType.MASTER_CARD
    str_1 = payment_0.credit_card_number(card_type)
    assert str_1.startswith('5')
    assert len(str_1.split(' ')) == 4
    card_type = CardType.AMERICAN_EXPRESS
    str_2 = payment_0.credit_card_number(card_type)
    assert str_2.startswith('3')
    assert len(str_2.split(' ')) == 3


# Generated at 2022-06-25 20:55:55.366066
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    payment_1.credit_card_number(card_type='VISA')


# Generated at 2022-06-25 20:55:56.726165
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pytest.skip()
    Payment.credit_card_number()
    str_0 = ''
    Payment.credit_card_number(str_0)


# Generated at 2022-06-25 20:56:04.384486
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment"""
    payment = Payment()

    # Test for card_type as None
    card_type = None
    credit_card_number = payment.credit_card_number(card_type)
    assert credit_card_number.isdigit()

    # Test for card_type as VISA
    card_type = CardType.VISA
    credit_card_number = payment.credit_card_number(card_type)
    assert credit_card_number.isdigit()

    # Test for card_type as MASTER_CARD
    card_type = CardType.MASTER_CARD
    credit_card_number = payment.credit_card_number(card_type)
    assert credit_card_number.isdigit()

    # Test for card_type as AMERICAN_EX

# Generated at 2022-06-25 20:56:08.855494
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    expected = re.compile(r'\d{4} \d{4} \d{4} \d{4}')
    assert str_0.__class__ == str
    assert re.match(expected, str_0)


# Generated at 2022-06-25 20:56:14.503673
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    int_0 = -101
    int_1 = -101
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    str_1 = payment_0.credit_card_number(CardType.VISA)
    assert utils.compare_strings(str_0, "4748 6886 7589 6468")
    assert utils.compare_strings(str_1, "4748 6886 7589 6468")


# Generated at 2022-06-25 20:56:22.049626
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()

    assert re.match(r"\d{16}", str_0)


# Generated at 2022-06-25 20:56:29.714832
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_types  = ['VISA', 'MasterCard', 'AmericanExpress']
    payment_test = Payment()
    str_test = payment_test.credit_card_number()
    credit_cards = [str_test]
    credit_card_types = []
    # check the credit card is valid
    for c_type in card_types:
        for card in credit_cards:
            if payment_test.credit_card_number(c_type) in card:
                credit_card_types.append(c_type)

    assert credit_card_types == ['VISA']

# Generated at 2022-06-25 20:56:37.799223
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    case_0 = {
        "Visa": re.compile(r'\d{4} \d{4} \d{4} \d{4}'),
        "MasterCard": re.compile(r'2\d{3} \d{4} \d{4} \d{4}'),
        "American Express": re.compile(r'3[47]\d{2} \d{6} \d{5}')
    }
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert isinstance(str_0, str)
    assert case_0["Visa"].search(str_0)
    str_1 = payment_0.credit_card_number(CardType.MASTER_CARD)

# Generated at 2022-06-25 20:56:40.054324
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert len(Payment().credit_card_number()) == 16
    assert len(Payment().credit_card_number(CardType.AMERICAN_EXPRESS)) == 15


# Generated at 2022-06-25 20:56:43.306264
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.MASTER_CARD
    p = Payment()
    actual_result = p.credit_card_number(card_type)
    expected_result = '4248 3465 1232 2471'
    
    assert actual_result == expected_result


# Generated at 2022-06-25 20:56:46.370228
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    random_i_0 = Payment()
    random_i_1 = Payment(seed=1)
    str_0 = random_i_0.credit_card_number()
    str_1 = random_i_1.credit_card_number()
    assert str_0 != str_1

# Generated at 2022-06-25 20:56:49.814982
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card = payment.credit_card_number()
    assert re.search(r"^\d{4}( |-)[0-9]{4}\1[0-9]{4}\1[0-9]{4}$", credit_card) is not None

# Generated at 2022-06-25 20:56:51.813861
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment(seed=0)
    str_0 = payment_0.credit_card_number()
    assert str_0 == '4334 8950 9389 8696'


# Generated at 2022-06-25 20:56:53.863071
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    str = payment.credit_card_number()
    assert len(re.findall(r'\d', str)) == 16,\
        "The input is not like a credit card number" + str
        

# Generated at 2022-06-25 20:57:01.406494
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_0 = payment_1.credit_card_number()
    str_1 = payment_1.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    str_2 = payment_1.credit_card_number(card_type=CardType.DISCOVER)
    str_3 = payment_1.credit_card_number(card_type=CardType.MASTER_CARD)
    str_4 = payment_1.credit_card_number(card_type=CardType.VISA)
    return

# Generated at 2022-06-25 20:57:21.431479
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_1 = payment_0.credit_card_number()
    assert(str_1 == '4001 9669 9988 1231')  # type: ignore
    str_2 = payment_0.credit_card_number(card_type='Visa')
    assert(str_2 == '4562 0578 9763 3696')  # type: ignore
    str_3 = payment_0.credit_card_number(card_type='MasterCard')
    assert(str_3 == '5441 7744 5820 2739')  # type: ignore
    str_4 = payment_0.credit_card_number(card_type='AmericanExpress')
    assert(str_4 == '3404 82754 84001')  # type: ignore


# Generated at 2022-06-25 20:57:23.432263
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()
    assert (str_1 is not None)


# Generated at 2022-06-25 20:57:26.397434
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from random import seed

    seed(0)

    payment_0 = Payment()
    assert payment_0.credit_card_number() == "4455 5299 1152 2450", "unit test for Payment.credit_card_number()"


# Generated at 2022-06-25 20:57:29.550749
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match('\d{4} \d{4} \d{4} \d{4}',
                    payment.credit_card_number())


# Generated at 2022-06-25 20:57:32.020987
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}',Payment().credit_card_number()), 'Not a valid credit card number'


# Generated at 2022-06-25 20:57:33.852415
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert re.fullmatch(r'^\d{4} \d{4} \d{4} \d{4}$', Payment().credit_card_number()) is not None

# Generated at 2022-06-25 20:57:34.910247
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert type(str_0) == str


# Generated at 2022-06-25 20:57:36.999607
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # AssertionError: NonEnumerableError not raised

    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()



# Generated at 2022-06-25 20:57:45.181341
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    list_1 = [payment_1.credit_card_number() for _ in range(10)]
    list_2 = [
        '4716 6937 1472 8215',
        '4707 9906 8176 1247',
        '4929 8459 1795 3728',
        '4491 6939 4744 9081',
        '4936 3097 2482 4551',
        '4746 5428 7092 5234',
        '4512 4682 3837 9756',
        '4749 9787 3128 7937',
        '4494 0128 5482 9342',
        '4499 9120 8858 4929',
    ]
    assert list_1 == list_2


# Generated at 2022-06-25 20:57:49.724462
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()
    assert(type(str_1) == str), 'Credit Card Number is not a string'
    assert(re.search(r'\d{4} \d{4} \d{4} \d{4}', str_1) is not None), 'Credit Card Number format is not correct'


# Generated at 2022-06-25 20:58:14.910837
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    x = Payment()
    assert x.credit_card_number() == '4556 0162 6724 4092'
    assert x.credit_card_number() == '2223 4122 8787 8249'
    assert x.credit_card_number() == '3356 4122 8787 8249'

# Generated at 2022-06-25 20:58:21.581804
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    credit_card_number_0 = Payment(seed=0).credit_card_number()
    assert credit_card_number_0 == "4547 6603 4647 9243"
    credit_card_number_1 = Payment(seed=1).credit_card_number(card_type=CardType.MASTER_CARD)
    assert credit_card_number_1 == "5232 5812 4372 7128"
    credit_card_number_2 = Payment(seed=2).credit_card_number()
    assert credit_card_number_2 == "4518 0579 9887 2985"
    credit_card_number_3 = Payment(seed=3).credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    assert credit_card_number_3 == "3481 963197 65711"


# Generated at 2022-06-25 20:58:23.134843
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()

# Generated at 2022-06-25 20:58:29.142889
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    rnd = Random()
    rnd.seed(0)
    payment_0 = Payment(rnd)
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert str_0 == '4971 1864 3139 0014'
    str_0 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert str_0 == '3705 649150 43741'
    str_0 = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert str_0 == '5460 9521 1080 0618'



# Generated at 2022-06-25 20:58:35.958409
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for _ in range(30):
        payment_obj_0 = Payment()
        try:
            int_0 = payment_obj_0.credit_card_number(CardType.VISA)
            assert isinstance(int_0, str)
            assert len(int_0) == 19
        except NonEnumerableError as exc:
            print(exc)

    for _ in range(30):
        payment_obj_0 = Payment()
        try:
            int_0 = payment_obj_0.credit_card_number(CardType.MASTER_CARD)
            assert isinstance(int_0, str)
            assert len(int_0) == 19
        except NonEnumerableError as exc:
            print(exc)

    for _ in range(30):
        payment_obj_0 = Payment()

# Generated at 2022-06-25 20:58:40.097575
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    cardTypes = []
    for cardType in CardType:
        cardTypes.append(cardType)
    assert payment.credit_card_number(cardType=cardTypes[0]) != None
    assert payment.credit_card_number(cardType=cardTypes[1]) != None
    assert payment.credit_card_number(cardType=cardTypes[2]) != None

# Generated at 2022-06-25 20:58:46.873590
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert str_0[:14] == '5608 7054 6545 99'
    assert str_0[-2:] == '00'
    str_1 = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert str_1[:14] == '5416 1387 5459 56'
    assert str_1[-2:] == '00'
    str_2 = payment_0.credit_card_number(CardType.VISA)
    assert str_2[:15] == '4029 2917 5245 01'
    assert str_2[-2:] == '00'
    str_3 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-25 20:58:51.457720
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import unittest
    import doctest
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(doctest.DocTestSuite()))
    res = doctest.testmod()
    print('Result: ' + res[1])

# Generated at 2022-06-25 20:58:54.646388
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    obj_0 = Payment("en")
    assert re.match("^\d{4} \d{4} \d{4} \d{4}$", obj_0.credit_card_number(CardType.VISA))



# Generated at 2022-06-25 20:58:57.249232
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert (re.search(r'(?:\d[ -]*?){15,16}', str_0))


# Generated at 2022-06-25 20:59:47.391066
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    regex_0 = re.compile(r'(\d{4}\s\d{4}\s\d{4}\s\d{4})')
    assert regex_0.match(str_0)


# Generated at 2022-06-25 20:59:53.849621
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    str_1 = payment_0.credit_card_number()
    str_2 = payment_0.credit_card_number()
    str_3 = payment_0.credit_card_number()
    str_4 = payment_0.credit_card_number()
    assert isinstance(str_0, str)
    assert isinstance(str_1, str)
    assert isinstance(str_2, str)
    assert isinstance(str_3, str)
    assert isinstance(str_4, str)


# Generated at 2022-06-25 21:00:00.888785
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # first test case
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert (str_0 == "4455 5299 1152 2450")
    # second test case
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()
    assert (str_1 == "5575 7281 0597 3800")
    # third test case
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number()
    assert (str_2 == "4455 5299 1152 2450")
    # forth test case
    payment_3 = Payment()
    str_3 = payment_3.credit_card_number()
    assert (str_3 == "5575 7281 0597 3800")
    # fifth test case
   

# Generated at 2022-06-25 21:00:03.454503
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert str_0 != ""
    assert re.match("^[4][0-9]{12}(?:[0-9]{3})?$", str_0) is not None
    
    

# Generated at 2022-06-25 21:00:08.304543
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    result = 0
    try:
        test_case_0()
    except Exception as e:
        result = 1
        print('Test case for method credit_card_number of class Payment failed.')
        print('Unexpected exception in Payment.credit_card_number().', e)
    assert result == 0
    print('Test case for method credit_card_number of class Payment ran successfully.')

test_Payment_credit_card_number()

# Generated at 2022-06-25 21:00:12.073603
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    possible_network_list = ["AMERICAN EXPRESS", "Diners Club", "Discover", "JCB", "MasterCard", "Visa"]
    card_network_list = []
    for i in range(100):
        card_number_0 = payment_0.credit_card_number()
        card_network_list.append(payment_0.credit_card_network())
    #  make sure the credit card network is among AMEX, Diners Club, Discover, JCB, MasterCard and Visa
    assert set(possible_network_list).issubset(set(card_network_list))

# Generated at 2022-06-25 21:00:13.119820
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert type(Payment().credit_card_number()) is str


# Generated at 2022-06-25 21:00:22.077105
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()

    try:
        str_0 = payment_0.credit_card_number(CardType.VISA)
    except:
        pass

    try:
        str_0 = payment_0.credit_card_number(CardType.MASTER_CARD)
    except:
        pass

    try:
        str_0 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    except:
        pass

    try:
        str_0 = payment_0.credit_card_number(CardType.DISCOVER)
    except NotImplementedError:
        assert True
    except:
        assert False


# Generated at 2022-06-25 21:00:24.372526
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    # Create str_0 by calling method credit_card_number of class Payment
    str_0 = payment_0.credit_card_number(
        card_type=CardType.VISA,
    )
    # Assert condition 1
    assert str_0 == '4455 5299 1152 2450'


# Generated at 2022-06-25 21:00:26.478353
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type_0 = CardType.AMERICAN_EXPRESS
    result_0 = Payment().credit_card_number(card_type_0)
    #assert result_0 == '4455 5299 1152 2450'

