

# Generated at 2022-06-25 20:55:30.100691
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test method credit_card_number of class Payment"""
    payment = Payment()
    cc_number = payment.credit_card_number()

    # Case 1: Test Visa
    cc_number = payment.credit_card_number('visa')
    assert cc_number.startswith('4') == True
    assert len(cc_number) == 16

    # Case 2: Test MasterCard
    cc_number = payment.credit_card_number('mastercard')

# Generated at 2022-06-25 20:55:39.733189
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    # Check that the card_number has a length of 16
    assert len(card_number) == 19
    card_type = payment.credit_card_network()
    assert card_type in ["Visa", "MasterCard", 'American Express']
    card_number = payment.credit_card_number(CardType.MASTER_CARD)
    # Check that the card_number has a length of 16
    assert len(card_number) == 19
    card_type = payment.credit_card_network()
    assert card_type in ["Visa", "MasterCard", 'American Express']
    card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    # Check that the card_number has a

# Generated at 2022-06-25 20:55:45.505965
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print("Testing the credit_card_number method of class Payment")

    # Test VISA credit card
    payment_VISA = Payment()
    credit_card_number_VISA = payment_VISA.credit_card_number(CardType.VISA)
    assert(credit_card_number_VISA[0:1] == "4")
    assert(len(credit_card_number_VISA) == 19)

    # Test MASTER_CARD credit card
    payment_MASTER_CARD = Payment()
    credit_card_number_MASTER_CARD = payment_MASTER_CARD.credit_card_number(CardType.MASTER_CARD)

# Generated at 2022-06-25 20:55:49.410143
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    assert isinstance(payment.credit_card_number(), str)
    assert len(payment.credit_card_number().split(" ")) == 4
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}',
                    payment.credit_card_number()) is not None


# Generated at 2022-06-25 20:55:51.878145
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    card_type = CardType.MASTER_CARD
    credit_card_number_1 = payment_1.credit_card_number(card_type)
    print("test_Payment_credit_card_number")
    print("credit_card_number_1:", credit_card_number_1)


# Generated at 2022-06-25 20:55:58.411077
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    import re
    cc = payment.credit_card_number()
    assert re.match(
        "[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}", cc) is not None


# Generated at 2022-06-25 20:56:00.476430
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    number = payment_0.credit_card_number()
    assert len(number) is 19
    assert isinstance(number, str)
    assert number[-1].isdigit()
    

# Generated at 2022-06-25 20:56:09.905386
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    # Unit test with MasterCard
    CreditCardNumber = payment.credit_card_number(CardType.MASTER_CARD)
    assert bool(re.search(r'^5\d{3}\ \d{4}\ \d{4}\ \d{4}', CreditCardNumber))

    # Unit test with Visa
    CreditCardNumber = payment.credit_card_number(CardType.VISA)
    assert bool(re.search(r'^4\d{3}\ \d{4}\ \d{4}\ \d{4}', CreditCardNumber))

    # Unit test with AmericanExpress
    CreditCardNumber = payment.credit_card_number(CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-25 20:56:14.651131
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    credit_card_number_0 = Payment().credit_card_number()
    credit_card_number_1 = Payment().credit_card_number()
    assert type(credit_card_number_0) == str
    assert type(credit_card_number_1) == str
    assert credit_card_number_0 != credit_card_number_1


# Generated at 2022-06-25 20:56:21.780565
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    payment_0 = Payment()
    assert payment_0.credit_card_number(card_type=CardType.VISA) == '4455 5299 1152 2450'
    assert payment_0.credit_card_number(card_type=CardType.MASTER_CARD) == '2221 4860 7403 5545'
    assert payment_0.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == '3743 2585 665961'
    assert payment_0.credit_card_number(card_type=CardType.DISCOVER) == '6011 5897 9720 4823'

# Generated at 2022-06-25 20:56:41.858998
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    # Unit test for method credit_card_number of class Payment with arg card_type=None

# Generated at 2022-06-25 20:56:44.952123
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0: CardType = get_random_item(CardType, rnd=payment_0.random)
    number_0: str = payment_0.credit_card_number(card_type_0)


# Generated at 2022-06-25 20:56:48.224494
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    expected = re.compile(r'\d{4}\s\d{4}\s\d{4}\s\d{4}')
    assert re.match(expected, payment_0.credit_card_number()) is not None


# Generated at 2022-06-25 20:56:50.938481
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment_1 = payment.credit_card_number()
    payment_2 = payment.credit_card_number(card_type=CardType.MASTER_CARD)
    assert len(payment_1) > 0
    assert len(payment_2) > 0

# Generated at 2022-06-25 20:56:53.624198
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number_expectation = payment.credit_card_number()
    assert " " in credit_card_number_expectation
    assert len(credit_card_number_expectation) > 16
    assert len(credit_card_number_expectation) < 20


# Generated at 2022-06-25 20:57:03.239547
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    number = payment_0.credit_card_number()
    assert (number) is not None
    payment_1 = Payment(seed=12345)
    number_1 = payment_1.credit_card_number()
    assert number_1 == '4256 3087 3032 5383'
    payment_2 = Payment(seed=12345)
    number_2 = payment_2.credit_card_number(
        card_type=CardType.MASTER_CARD,
    )
    assert number_2 == '5282 9578 1165 3070'
    payment_3 = Payment(seed=12345)
    number_3 = payment_3.credit_card_number(
        card_type=CardType.AMERICAN_EXPRESS,
    )

# Generated at 2022-06-25 20:57:06.079203
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment(seed=11123)
    payment_1 = Payment(seed=11123)
    card1 = payment_0.credit_card_number()
    card2 = payment_1.credit_card_number()
    #print(card1, card2)
    assert card1 == card2


# Generated at 2022-06-25 20:57:12.501756
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # test case for visa
    assert len(Payment().credit_card_number()) == 19
    # test case for visa
    assert len(Payment().credit_card_number(CardType.VISA)) == 19
    # test case for master_card
    assert len(Payment().credit_card_number(CardType.MASTER_CARD)) == 19
    # test case for american express
    assert len(Payment().credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    # test case with non-existent card type
    try:
        Payment().credit_card_number(CardType.DISCOVER)
        assert False
    except NonEnumerableError:
        assert True

# Generated at 2022-06-25 20:57:19.932940
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    flag = True
    payment = Payment()
    try:
        assert payment.credit_card_number(CardType.VISA) == '4495 0241 4898 8344'
        assert payment.credit_card_number(CardType.MASTER_CARD) == '5240 0893 1107 1683'
        assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3491 935562 38612'
    except TypeError :
        flag = False
    if flag :
        print("Test case for method credit_card_number of class Payment passed")
    else :
        print("Test case for method credit_card_number of class Payment failed")


# Generated at 2022-06-25 20:57:24.031369
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=42)
    assert payment.credit_card_number() == '4918 2741 6879 3226'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5117 1165 1579 3689'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3737 709532 60404'


# Generated at 2022-06-25 20:57:53.146575
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number() == '4455 5299 1152 2450'


# Generated at 2022-06-25 20:57:58.584746
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment()
    valid_cc_number = provider.credit_card_number(CardType.VISA)
    assert valid_cc_number == '4455 5299 1152 2450'

    valid_cc_number = provider.credit_card_number(CardType.MASTER_CARD)
    assert valid_cc_number == '5363 7792 0754 0171'

    valid_cc_number = provider.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert valid_cc_number == '3460 1486 03130 75'


# Generated at 2022-06-25 20:58:00.832891
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pay = Payment()
    card_num = pay.credit_card_number()
    return True if len(card_num) == 19 else False


# Generated at 2022-06-25 20:58:02.870955
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_0.credit_card_number()

# Generated at 2022-06-25 20:58:04.646983
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{16}', payment.credit_card_number())


# Generated at 2022-06-25 20:58:08.558804
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()

    re_credit_card = re.compile(r'^(\d{4} \d{4} \d{4} \d{4})$')

    assert re_credit_card, credit_card_number


# Generated at 2022-06-25 20:58:16.031967
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card_number_0 = p.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert (re.search(r'(?<!\d)\d{4}[ \-]?\d{6}[ \-]?\d{5}(?!\d)', card_number_0) != None)

    card_number_1 = p.credit_card_number(CardType.MASTER_CARD)
    assert (re.search(r'(?<!\d)\d{4}[ \-]?\d{4}[ \-]?\d{4}[ \-]?\d{4}(?!\d)', card_number_1) != None)


# Generated at 2022-06-25 20:58:21.248440
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    payment_1 = Payment()
    credit_card = payment_1.credit_card_number()
    check = [bool(re.match('^([0-9]{4}[ ]{1}[0-9]{4}[ ]{1}[0-9]{4}[ ]{1}' \
         '[0-9]{4})$',credit_card))]
    is_credit_card_number_good = any(check)
    assert is_credit_card_number_good is True


# Generated at 2022-06-25 20:58:23.883113
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment(seed=0)
    card_type = CardType.MASTER_CARD
    card_number = payment_0.credit_card_number(card_type)
    assert card_number == '5242 8488 8342 5724'

# Generated at 2022-06-25 20:58:24.783701
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number() != Payment().credit_card_number()