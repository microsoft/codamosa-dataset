

# Generated at 2022-06-25 20:55:23.632736
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc_number = Payment().credit_card_number()
    assert (re.match("\d{4} \d{4} \d{4} \d{4}", cc_number) is not None)
    assert (re.match("\d \d \d \d \d \d \d \d \d \d \d \d \d \d \d", cc_number[::-1]) is None)


# Generated at 2022-06-25 20:55:26.961592
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=CardType.VISA)

# Generated at 2022-06-25 20:55:33.131233
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.master_card)
    assert str_0[5:8] == str_0[0:4]
    assert str_0[9:12] == str_0[5:8]
    assert str_0[13:16] == str_0[9:12]
    assert str_0[17:20] == str_0[13:16]
    assert len(str_0) == 19
    assert str_0[17:18] == ' '
    assert str_0[14:15] == ' '
    assert str_0[11:12] == ' '
    assert str_0[8:9] == ' '


# Generated at 2022-06-25 20:55:37.294047
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=CardType.VISA)
    assert (re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', str_0) != None)


# Generated at 2022-06-25 20:55:40.262586
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Initialize
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    str_1 = payment_0.credit_card_number(CardType.MASTER_CARD)


# Generated at 2022-06-25 20:55:43.334643
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_1 = payment_0.credit_card_number()
    assert len(re.sub(r'\s+', '', str_1)) == 16


# Generated at 2022-06-25 20:55:45.682430
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert re.match(Payment().credit_card_number(), '\d{4}\s\d{4}\s\d{4}\s\d{4}$')


# Generated at 2022-06-25 20:55:47.810611
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    cc_num =  payment_1.credit_card_number()
    assert len(cc_num) == 19


# Generated at 2022-06-25 20:55:49.169100
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 4 * 4 + 3 * 1

# Generated at 2022-06-25 20:55:50.519161
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    inst = Payment()
    res = inst.credit_card_number(CardType.VISA)
    assert res is not None


# Generated at 2022-06-25 20:55:55.641819
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()

# Generated at 2022-06-25 20:56:04.056640
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for _ in range(10):
        str_ = payment.credit_card_number(CardType.VISA)
        assert len(str_) == 19
        assert str_.split()[0][0] == '4'
        assert str_[-1] == luhn_checksum(str_[:-1])
        str_ = payment.credit_card_number(CardType.MASTER_CARD)
        assert len(str_) == 19
        assert str_.split()[0][0:2] in ('52', '51', '53')
        assert str_[-1] == luhn_checksum(str_[:-1])
        str_ = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
        assert len(str_) == 17

# Generated at 2022-06-25 20:56:13.669912
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment_0 = Payment(seed=8058)
    str_0 = payment_0.credit_card_number(CardType.VISA)
    str_1 = payment_0.credit_card_number(CardType.MASTER_CARD)
    str_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    str_3 = payment_0.credit_card_number(CardType.DISCOVER)
    str_4 = payment_0.credit_card_number(CardType.DINERS_CLUB)
    str_5 = payment_0.credit_card_number(CardType.JCB)
    str_6 = payment_0.credit_card_number(CardType.UNIONPAY)
   

# Generated at 2022-06-25 20:56:15.161757
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_number_list = []
    for n in range (1,10):
        card_number_list.append(Payment().credit_card_number())
    print(card_number_list)

# Generated at 2022-06-25 20:56:17.412433
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    string_0 = payment_0.credit_card_number()
    assert re.search(r'^\d{4}\s\d{4}\s\d{4}\s\d{4}$', string_0) is not None



# Generated at 2022-06-25 20:56:18.990326
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    print(payment_0.credit_card_number())
    print(payment_0.credit_card_number())
    print(payment_0.credit_card_number())


# Generated at 2022-06-25 20:56:22.696533
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = CardType.VISA
    str_0 = payment_0.credit_card_number(card_type_0)

    payment_1 = Payment(seed=170542)
    card_type_1 = CardType.AMERICAN_EXPRESS
    str_1 = payment_1.credit_card_number(card_type_1)

# Generated at 2022-06-25 20:56:25.312001
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)


# Generated at 2022-06-25 20:56:30.429537
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Create a instance of class Payment
    payment_0 = Payment()
    # Execute method credit_card_number
    res_0 = payment_0.credit_card_number(CardType.VISA)
    # Verify if the returned value is equals to 4455
    assert res_0 == "4455 5299 1152 2450"

# Generated at 2022-06-25 20:56:37.877509
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # As the execution of this method is random, we will execute
    # it 10 times and then collect the stats
    test_dict = {}
    for card_type in CardType:
        test_dict[card_type.value] = 0

    for i in range(10000):
        payment_obj = Payment()
        result = payment_obj.credit_card_number()
        network_name = payment_obj.credit_card_network()
        test_dict[network_name] += 1

    assert test_dict['Visa'] > test_dict['American Express']
    assert test_dict['MasterCard'] > test_dict['American Express']
    return True

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 20:56:48.223820
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    string_0 = Payment().credit_card_number(CardType.VISA)
    assert string_0 == '4455 5299 1152 2450'



# Generated at 2022-06-25 20:56:51.456161
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    Test credit_card_number function
    """
    payment_0 = Payment()
    card_number_0 = payment_0.credit_card_number()
    card_number_1 = payment_0.credit_card_number(CardType.MASTER_CARD)
    card_number_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    card_number_3 = payment_0.credit_card_number(CardType.VISA)



# Generated at 2022-06-25 20:56:53.052065
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_0 = payment_1.credit_card_number()
    print('The credit_card_number is: ', str_0)


# Generated at 2022-06-25 20:56:58.582565
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print('Testing credit_card_number method...')
    card_number = Payment().credit_card_number()
    card_number_2 = Payment().credit_card_number(CardType.MASTER_CARD)
    card_number_3 = Payment().credit_card_number(CardType.AMERICAN_EXPRESS)
    if card_number.startswith('4') and len(card_number) == 19:
        print("Test passed!")
    else:
        print("Test failed!")
    if card_number_2.startswith('5') and len(card_number_2) == 19:
        print("Test passed!")
    else:
        print("Test failed!")

# Generated at 2022-06-25 20:57:01.026280
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    result = payment.credit_card_number()
    assert result is not None


# Generated at 2022-06-25 20:57:06.670386
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
  payment_0 = Payment()
  card_typs_list = [payment_0.card_type.AMERICAN_EXPRESS,payment_0.card_type.MASTER_CARD,payment_0.card_type.VISA]
  random_index = random.randint(0,2)
  card_type_choice = card_typs_list[random_index]
  str_0 = payment_0.credit_card_number(card_type=card_type_choice)
  assert str_0 is not None
  assert str_0 is not ''
  assert len(str_0) == 19


# Generated at 2022-06-25 20:57:13.769694
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test simple cases
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(card_type=CardType.VISA)
    assert(len(str_0) == 19)

    str_1 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)
    assert(len(str_1) == 19)

    str_2 = payment_0.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    assert(len(str_2) == 17)

    # Test card number with no card type specified
    str_3 = payment_0.credit_card_number()
    assert(len(str_3) == 19)


# Generated at 2022-06-25 20:57:18.741928
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    # 1. default value
    str_0 = payment_0.credit_card_number()
    # 2. test CardType
    str_1 = payment_0.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    # 3. test str
    str_2 = payment_0.credit_card_number(card_type="Visa")


# Generated at 2022-06-25 20:57:24.672476
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()
    str_2 = payment_1.credit_card_number()
    assert str_1 != str_2
    str_3 = payment_1.credit_card_number()
    str_4 = payment_1.credit_card_number()
    assert str_3 != str_4
    str_5 = payment_1.credit_card_number()
    str_6 = payment_1.credit_card_number()
    assert str_5 != str_6    
    

# Generated at 2022-06-25 20:57:27.221328
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    credit_card_number_0 = payment_1.credit_card_number()
    assert(isinstance(credit_card_number_0, str))


# Generated at 2022-06-25 20:57:44.078462
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_0.credit_card_number()



# Generated at 2022-06-25 20:57:48.206301
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)

    assert re.search('^\d{4} \d{4} \d{4} \d{4}$', str_0) is not None


# Generated at 2022-06-25 20:57:53.383320
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment.credit_card_number()
    char_count = 0
    for char in payment.credit_card_number():
        if char == " ":
            continue
        if char.isdigit():
            char_count += 1
    if char_count == 16:
        print("test_Payment_credit_card_number: PASS")
    else:
        print("test_Payment_credit_card_number: FAIL")


# Generated at 2022-06-25 20:57:58.823145
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    payment_2 = Payment()
    payment_3 = Payment()
    payment_4 = Payment()

    assert payment_1.credit_card_number() != payment_2.credit_card_number()
    assert payment_2.credit_card_number(CardType.VISA) != payment_3.credit_card_number(CardType.MASTER_CARD)
    assert payment_3.credit_card_number(CardType.AMERICAN_EXPRESS) != payment_4.credit_card_number(CardType.MASTER_CARD)

# Generated at 2022-06-25 20:58:08.691504
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # create Payment instance
    payment_0 = Payment()
    card_type_0 = CardType.VISA

    # call function credit_card_number
    output_0 = payment_0.credit_card_number(card_type_0)
    assert re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', output_0)

    card_type_1 = None

    # call function credit_card_number
    output_1 = payment_0.credit_card_number(card_type_1)
    assert re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', output_1)

    card_type_2 = CardType.AMERICAN_EXPRESS

    # call function credit_card_

# Generated at 2022-06-25 20:58:10.904333
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
        payment = Payment()
        str_1 = payment.credit_card_number()
        print(str_1)
#

# Generated at 2022-06-25 20:58:12.951554
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test = Payment()
    for i in range(200):
        card_no = test.credit_card_number()
        assert len(card_no.replace(" ", "")) == 16


# Generated at 2022-06-25 20:58:16.482506
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    str_1 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    str_2 = payment_0.credit_card_number(CardType.MASTER_CARD)
    str_3 = payment_0.credit_card_number(CardType.VISA)


# Generated at 2022-06-25 20:58:19.210151
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)

    assert len(str_0) == 19
    assert bool(re.match(r'\d{4} \d{4} \d{4} \d{4}', str_0))

test_case_0()
test_Payment_credit_card_number()

# Generated at 2022-06-25 20:58:21.059499
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number() == Payment().credit_card_number()


# Generated at 2022-06-25 20:59:01.419251
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment_1 = Payment()
    Payment_2 = Payment()
    Payment_3 = Payment()
    Payment_4 = Payment()
    
    visa_credit_card_number = Payment_1.credit_card_number(CardType.VISA)
    assert (len(visa_credit_card_number) == 19)
    assert (is_visa_card(visa_credit_card_number))
    
    master_card_credit_card_number = Payment_2.credit_card_number(CardType.MASTER_CARD)
    assert (len(master_card_credit_card_number) == 19)
    assert (is_master_card(master_card_credit_card_number))
    

# Generated at 2022-06-25 20:59:06.706203
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = CardType.VISA
    str_0 = payment_0.credit_card_number(card_type=card_type_0)
    assert str_0.startswith('4')
    assert len(str_0) == 19


if __name__ == '__main__':
    test_case_0()
    test_Payment_credit_card_number()

# Generated at 2022-06-25 20:59:07.702914
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number()

    assert str_1

# Generated at 2022-06-25 20:59:15.376951
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert re.match(r'^\d{4} \d{4} \d{4} \d{4}$', str_0) == True

    payment_1 = Payment(seed=145)
    str_1 = payment_1.credit_card_number(CardType.MASTER_CARD)
    assert re.match(r'^\d{4} \d{4} \d{4} \d{4}$', str_1) == True

    payment_2 = Payment(seed=8)
    str_2 = payment_2.credit_card_number(CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-25 20:59:17.693475
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pay = Payment()
    card = pay.credit_card_number()
    assert(type(card) is str)

# Generated at 2022-06-25 20:59:21.780456
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert str_0 == "4455 5299 1152 2450"

if __name__ == '__main__':
    test_case_0()
    test_Payment_credit_card_number()

# Generated at 2022-06-25 20:59:27.843498
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_t = Payment()
    assert isinstance(payment_t.credit_card_number(), str)
    assert isinstance(payment_t.credit_card_number(CardType.VISA), str)
    assert isinstance(payment_t.credit_card_number(CardType.MASTER_CARD), str)
    assert isinstance(payment_t.credit_card_number(CardType.AMERICAN_EXPRESS), str)


if __name__ == "__main__":
    test_case_0()
    test_Payment_credit_card_number()

# Generated at 2022-06-25 20:59:33.063411
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number(CardType.AMERICAN_EXPRESS) == '3488 712077 89341'
    assert payment_0.credit_card_number(CardType.MASTER_CARD) == '5567 986174 81344'
    assert payment_0.credit_card_number(CardType.VISA) == '4424 539213 79391'


# Generated at 2022-06-25 20:59:36.013148
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    # Assert equality
    assert str_0 == '4455 5299 1152 2450'


# Generated at 2022-06-25 20:59:37.175529
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    assert str_0 is not None