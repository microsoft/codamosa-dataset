

# Generated at 2022-06-25 20:55:28.297603
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment()
    dict_0 = payment_1.credit_card_owner(CardType.VISA)
    str_0 = dict_0['credit_card']
    card_type_0 = str_0[0]
    assert(card_type_0 == '4')


# Generated at 2022-06-25 20:55:31.721564
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert(str_0[0] == '5')

# Generated at 2022-06-25 20:55:35.767024
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_1 = Payment(locale="fr")
    val_0 = payment_0.credit_card_number(payment_1)
    assert val_0 != "3664 5454 6396 4892"


# Generated at 2022-06-25 20:55:40.728644
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type = CardType.VISA
    assert len(payment_0.credit_card_number(card_type)) == 19
    card_type = CardType.MASTER_CARD
    assert len(payment_0.credit_card_number(card_type)) == 19
    card_type = CardType.AMERICAN_EXPRESS
    assert len(payment_0.credit_card_number(card_type)) == 17


# Generated at 2022-06-25 20:55:43.097370
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(10):
        ccNumber = Payment().credit_card_number()
        assert len(ccNumber) == 19


# Generated at 2022-06-25 20:55:47.962954
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.VISA
    payment_0 = Payment()
    assert payment_0.credit_card_number(card_type=card_type) == payment_0.credit_card_number(card_type=card_type)
    assert payment_0.credit_card_number(card_type=card_type) != payment_0.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-25 20:55:52.411671
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.VISA
    card_number_0 = Payment().credit_card_number(card_type)
    card_number_1 = Payment().credit_card_number(card_type)
    card_number_2 = Payment().credit_card_number(card_type)
    assert card_number_0 != card_number_1
    assert card_number_0 != card_number_2
    assert card_number_1 != card_number_2
    assert len(card_number_0) == 19
    assert len(card_number_1) == 19
    assert len(card_number_2) == 19


# Generated at 2022-06-25 20:56:01.342584
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    check = payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)

    # Make sure checksum passes
    assert luhn_checksum(check[:len(check) - 1]) == check[-1]
    assert len(check) in [15, 16]
    assert check[:2] in ['34', '37']


credit_card_number_card_type = {
    'Visa': '4',
    'MasterCard': '5',
    'American Express': '3',
}



# Generated at 2022-06-25 20:56:02.416489
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment.credit_card_number()



# Generated at 2022-06-25 20:56:03.769155
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number() is not None


# Generated at 2022-06-25 20:56:18.223310
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test case 0
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert str_0 in ['VISA', 'MasterCard', 'American Express']
    # Test case 1
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number(CardType.MASTER_CARD)
    assert str_1 in ['VISA', 'MasterCard', 'American Express']
    # Test case 2
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number(CardType.VISA)
    assert str_2 in ['VISA', 'MasterCard', 'American Express']
    # Test case 3
    payment_3 = Payment()

# Generated at 2022-06-25 20:56:20.117102
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_1 = Payment(
        seed=Payment.Meta.name,
    )
    str_1 = payment_1.credit_card_number()



# Generated at 2022-06-25 20:56:22.210874
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment1 = Payment()
    assert type(payment1.credit_card_number(card_type=CardType.VISA) == str)
    payment1.credit_card_number(card_type=CardType.VISA)


# Generated at 2022-06-25 20:56:22.875392
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment.credit_card_number()

# Generated at 2022-06-25 20:56:26.735086
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    ret_0 = p.credit_card_number()
    assert (ret_0 is not None)
    assert (isinstance(ret_0, str) or isinstance(ret_0, unicode))


# Generated at 2022-06-25 20:56:30.887193
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Setting seed
    payment = Payment(seed=None)
    # Unit test
    str_0 = payment.credit_card_number()
    # Testing if output is a string
    assert isinstance(str_0, str)
    # Testing length of string
    assert len(str_0) == 19


# Generated at 2022-06-25 20:56:33.287107
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    str = payment.credit_card_number()
    print(str)
    assert str.__len__() == 19, "The length of str is not 19"



# Generated at 2022-06-25 20:56:34.797412
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:56:38.878709
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test the Payment's method credit_card_number"""
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert re.match(r'[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}', str_0) is not None



# Generated at 2022-06-25 20:56:47.560895
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(100):
        payment_i = Payment()
        card_type_i = payment_i.credit_card_network()
        str_i = payment_i.credit_card_number()
        assert card_type_i in str_i, 'card_type_i: {}'.format(card_type_i)
        assert len(str_i) == 19, 'len(str_i): {}'.format(len(str_i))
        assert ' ' in str_i, 'str_i: {}'.format(str_i)
        assert str_i[0] not in ' ' and str_i[-1] not in ' '
        str_splitted_i = str_i.split(' ')

# Generated at 2022-06-25 20:57:07.135440
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test 0 - Test all possible card type
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    # Test 1 - Test all possible card type
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number(CardType.MASTER_CARD)
    # Test 2 - Test all possible card type
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number(CardType.AMERICAN_EXPRESS)
    # Test 3 - Raise error with incompatible card type
    payment_2 = Payment()
    bool_0 = True
    try:
        payment_2.credit_card_number('Bogus')
    except NonEnumerableError:
        bool_0 = False
    assert bool_0



# Generated at 2022-06-25 20:57:09.064829
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(0, 10):
        test_case_0()

# Test for method credit_card_expiration_date of class Payment

# Generated at 2022-06-25 20:57:12.308469
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    str_1 = payment_0.credit_card_number(CardType.MASTER_CARD)
    # str_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)


# Generated at 2022-06-25 20:57:15.669014
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert type(payment.credit_card_number()) is str
    assert len(payment.credit_card_number()) is 19
    assert " " in payment.credit_card_number()
    assert "-" not in payment.credit_card_number()


# Generated at 2022-06-25 20:57:22.654011
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    cc_number_0 = payment_0.credit_card_number(card_type=CardType.VISA)
    assert re.match(r'\d{16}', cc_number_0)
    cc_number_1 = payment_0.credit_card_number(card_type=CardType.MASTER_CARD)
    assert re.match(r'\d{16}', cc_number_1)
    cc_number_2 = payment_0.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    assert re.match(r'\d{15}', cc_number_2)



# Generated at 2022-06-25 20:57:24.068592
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert(len(payment.credit_card_number()) == 19)


# Generated at 2022-06-25 20:57:26.625162
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    seed = 10
    payment = Payment(seed=seed)
    creditCardNumber = payment.credit_card_number()
    assert creditCardNumber == "4238 5115 9688 4886"


# Generated at 2022-06-25 20:57:30.068095
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match('(?P<cc>\d{4}\s\d{4}\s\d{4}\s\d{4})', payment.credit_card_number())


# Generated at 2022-06-25 20:57:32.474886
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(100):
        payment_0 = Payment()
        str_0 = payment_0.credit_card_number()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 20:57:34.189084
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert(card_number is not None)
    assert(len(card_number) >= 16)

# Generated at 2022-06-25 20:58:08.141241
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Setup
    payment = Payment()

    str_0 = payment.credit_card_number()
    assert str_0 is None

    str_1 = payment.credit_card_number(CardType.VISA)
    assert str_1 is None

    str_2 = payment.credit_card_number(CardType.MASTER_CARD)
    assert str_2 is None

    str_3 = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert str_3 is None

    # Teardown
    payment = None



# Generated at 2022-06-25 20:58:15.663195
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for i in range(0, 100):
        card_type = CardType.VISA
        payment_0 = Payment()
        str_0 = payment_0.credit_card_number(card_type)
        assert len(str_0) == 19
        assert str_0[0:4] == '4xxx'
        assert isinstance(str_0, str)
        
    for i in range(0, 100):
        card_type = CardType.MASTER_CARD
        payment_0 = Payment()
        str_0 = payment_0.credit_card_number(card_type)
        assert len(str_0) == 19
        assert str_0[0:2] == '2x' or str_0[0:2] == '5x'

# Generated at 2022-06-25 20:58:17.421210
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    Generate a random credit card number.
    """
    payment_card_number = Payment()
    assert payment_card_number.credit_card_number() != None


# Generated at 2022-06-25 20:58:21.033666
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert (re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', str_0) is not None)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:58:28.162961
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import random
    import re

    for i in range(1,100):
        obj = Payment(random.Random())
        card_type = None
        str_0 = Payment(random.Random()).credit_card_number(card_type)

        if not isinstance(str_0, str):
            raise AssertionError("Result is not a string")
        if not (re.search('^((\d{4})(\s)(\d{4})(\s)(\d{4})(\s)(\d{4}))$', str_0)):
            raise AssertionError("Result does not look like credit card number")
        if len(str_0) != 19:
            raise AssertionError("Result does not look like credit card number")

# Generated at 2022-06-25 20:58:35.089658
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # list of different parameters
    random_card_type_value = [CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]
    random_card_type_str = ['visa', 'master_card', 'american_express']
    test = Payment()
    # running the method
    for i in range(0, 3):
        result = test.credit_card_number(random_card_type_value[i])
        # getting substring of the first 4 digits and converting to string
        result_str = str(result[:4])
        # checking if the first 4 digits. It corresponds to the card type given

# Generated at 2022-06-25 20:58:36.538137
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    print(str_0)



# Generated at 2022-06-25 20:58:42.460621
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Check what happens if card_type is CardType.VISA
    test_case_0()

    # Check what happens if card_type is CardType.MASTER_CARD
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number(CardType.MASTER_CARD)

    # Check what happens if card_type is CardType.AMERICAN_EXPRESS
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number(CardType.AMERICAN_EXPRESS)



# Generated at 2022-06-25 20:58:49.219573
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    credit_card_number = Payment.__dict__['credit_card_number']
    str_0 = credit_card_number(Payment())

# Generated at 2022-06-25 20:58:51.993776
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()