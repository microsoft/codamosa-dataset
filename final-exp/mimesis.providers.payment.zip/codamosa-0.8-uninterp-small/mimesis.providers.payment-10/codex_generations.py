

# Generated at 2022-06-25 20:55:28.543752
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    bytes_0 = b'\x8f\xa5\xd7+\xc0\x03\xf8\x81\xbc'
    list_0 = [bytes_0]
    payment_0 = Payment(*list_0)
    str_0 = payment_0.credit_card_number()
    __expected = '4748 0981 5896 6667'
    assert (str_0 == __expected)

# Generated at 2022-06-25 20:55:34.088879
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    list_0 = []
    payment_0 = Payment(*list_0)
    str_0 = payment_0.credit_card_number()
    str_1 = payment_0.credit_card_number()
    assert len(str_0) == len(str_1)


# Generated at 2022-06-25 20:55:43.059027
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test 1
    bytes_0 = b'\xaa\xbc\xc9n\xb5?\xdb\x11'
    list_0 = [bytes_0]
    payment_0 = Payment(*list_0)
    str_0 = payment_0.credit_card_number()
    assert len(str_0) > 0
    assert str_0[0].isdigit()
    assert str_0[4] == ' '
    assert str_0[8] == ' '
    assert str_0[-4].isdigit()
    assert str_0[-1].isdigit()
    assert (int(str_0[-4:]) % 10) == 0
    assert str_0[-5].isdigit()
    assert str_0[-9] == ' '
    assert str_

# Generated at 2022-06-25 20:55:45.369091
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    list_0 = [None]
    payment_0 = Payment(*list_0)
    str_0 = payment_0.credit_card_number(None)
    print(str_0)

# Generated at 2022-06-25 20:55:55.749125
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.VISA
    int_0 = 16
    int_1 = 16
    str_0 = get_random_credit_card_number(card_type, int_0, int_1)
    int_2 = 4
    assert len(str_0) == int_2
    int_3 = 4
    assert len(str_0) == int_3
    int_4 = 4
    assert len(str_0) == int_4
    int_5 = 4
    assert len(str_0) == int_5
    int_6 = 4
    assert len(str_0) == int_6
    int_7 = 4
    assert len(str_0) == int_7
    int_8 = 16
    int_9 = 15
    str_1 = get_random_credit_card

# Generated at 2022-06-25 20:56:03.806636
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    bytes_0 = b'{"gender": "male", "age": "adult"}'
    list_0 = [bytes_0]
    payment_1 = Payment(*list_0)
    str_0 = payment_1.credit_card_number()

    bytes_1 = b'{"gender": "male", "age": "adult"}'
    list_1 = [bytes_1]
    payment_2 = Payment(*list_1)
    str_1 = payment_2.credit_card_number()

    bytes_2 = b'{"gender": "male", "age": "adult"}'
    list_2 = [bytes_2]
    payment_3 = Payment(*list_2)
    str_2 = payment_3.credit_card_number()


# Generated at 2022-06-25 20:56:13.430809
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    bytes_0 = b"\xd3k\xcdx\x8b\xe0\xbb\x81\x02"
    list_0 = [bytes_0]
    payment_0 = Payment(*list_0)
    str_0 = payment_0.credit_card_number()
    assert not str_0.__contains__("-")
    assert str_0.endswith("7")
    # AssertionError: assert not str_0.__contains__("-")
    # AssertionError: assert str_0.endswith("7")

    bytes_0 = b"\x1c\xf2\xa8\xdb\xef\x90\xaa\xc9\x97\xa1\xed\x83\xbc\x08"

# Generated at 2022-06-25 20:56:13.945891
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert True

# Generated at 2022-06-25 20:56:18.735527
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = payment_0.random.choice(LICENSE_PLATES)
    str_0 = payment_0.credit_card_number(card_type_0)
    str_1 = payment_0.credit_card_number(card_type_0)
    int_0 = payment_0.random.randint(1, 10)
    str_2 = payment_0.credit_card_number(card_type_0)


# Generated at 2022-06-25 20:56:27.212716
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number()
    assert type(str_0) is str
    payment_1 = Payment()
    str_1 = payment_1.credit_card_number(CardType.VISA)
    assert type(str_1) is str
    payment_2 = Payment()
    str_2 = payment_2.credit_card_number(CardType.MASTER_CARD)
    assert type(str_2) is str
    payment_3 = Payment()
    str_3 = payment_3.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert type(str_3) is str
    payment_4 = Payment()
    str_4 = payment_4.credit_card_number(CardType.MAESTRO)

#

# Generated at 2022-06-25 20:56:34.980522
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    result = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert result

# Generated at 2022-06-25 20:56:39.752024
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number(CardType.VISA) == '4049 8334 8452 3735'
    assert payment_0.credit_card_number(CardType.MASTER_CARD) == '5290 6106 6767 7167'
    assert payment_0.credit_card_number(CardType.AMERICAN_EXPRESS) == '3427 332380 95531'


# Generated at 2022-06-25 20:56:43.357525
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = get_random_item(CardType, rnd=payment_0.random)
    str_0 = payment_0.credit_card_number(card_type_0)

test_case_0()
test_Payment_credit_card_number()

# Generated at 2022-06-25 20:56:46.997380
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = get_random_item(CardType, rnd=payment_0.random)
    str_0 = payment_0.credit_card_number(card_type=card_type_0)
    # print(str_0)


# Generated at 2022-06-25 20:56:51.214857
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    visa = payment.credit_card_number(CardType.VISA)

    # Check the length of the number
    assert len(visa.replace(' ', '')) == 16

    # Check first digit of the number
    assert visa[0] == '4'

    # Check if the number is valid by Luhn algorithm
    assert luhn_checksum(visa.replace(' ', ''))


# Generated at 2022-06-25 20:56:52.473637
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number().startswith('4')

# Generated at 2022-06-25 20:56:55.657607
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    credit_card_number_return = payment_0.credit_card_number(card_type=CardType.VISA)
    # The length of generated credit card number should be 16
    assert len(credit_card_number_return) == 16


if __name__ == "__main__":
    payment_0 = Payment()
    payment_0.credit_card_owner()

# Generated at 2022-06-25 20:57:00.785497
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number() is not None
    assert payment_0.credit_card_number() is not None
    assert payment_0.credit_card_number() is not None
    assert payment_0.credit_card_number() is not None
    assert payment_0.credit_card_number('Visa') is not None
    assert payment_0.credit_card_number('Visa') is not None
    assert payment_0.credit_card_number('MasterCard') is not None
    assert payment_0.credit_card_number('MasterCard') is not None
    assert payment_0.credit_card_number('AmericanExpress') is not None
    assert payment_0.credit_card_number('AmericanExpress') is not None

# Generated at 2022-06-25 20:57:06.478367
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for card_type in CardType:
        payment_0 = Payment()
        str_0 = payment_0.credit_card_number(card_type=card_type)
        assert isinstance(str_0, str)
        assert len(str_0) == 19 or len(str_0) == 16
        assert isinstance(payment_0.credit_card_number(), str)
        assert isinstance(payment_0.credit_card_number(card_type=card_type), str)
        assert isinstance(
            payment_0.credit_card_number(card_type=card_type),
            str)




# Generated at 2022-06-25 20:57:08.358434
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number(CardType.VISA) == '4532 6868 2504 5180'

# Generated at 2022-06-25 20:57:25.600297
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment('en')
    length_0 = 16
    card_type_0 = get_random_item(CardType, rnd=payment_0.random)
    str_0 = payment_0.credit_card_number(CardType.MASTER_CARD)
    assert len(str_0) == length_0
    assert str_0 != payment_0.credit_card_number(CardType.MASTER_CARD)


# Generated at 2022-06-25 20:57:27.986253
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_obj = Payment()

    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment_obj.credit_card_number())



# Generated at 2022-06-25 20:57:33.345028
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    num = payment_0.credit_card_number()
    # Check whether the number is valid
    num_ = re.sub(r'\D', '', num)
    if int(num_[-1]) != luhn_checksum(num_[:-1]):
        print('error')
    # Check the number length
    if len(num_) != 16:
        print('error')


# Generated at 2022-06-25 20:57:35.760698
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    dict_0 = payment_0.credit_card_number()
    print(dict_0)


# Generated at 2022-06-25 20:57:37.482231
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    credit_card_number_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:57:40.155162
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number() is not None, "Unable to create a credit card number"



# Generated at 2022-06-25 20:57:41.569030
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19

# Generated at 2022-06-25 20:57:43.250238
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number(CardType.VISA) == \
        '4455 5299 1152 2450'


# Generated at 2022-06-25 20:57:44.790675
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19


# Generated at 2022-06-25 20:57:48.108932
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(card_type=CardType.VISA)

    assert isinstance(card_number, str) and \
        len(card_number.split()) == 4

# Generated at 2022-06-25 20:58:10.738341
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # VISA
    payment_0 = Payment()
    assert payment_0.credit_card_number(card_type=CardType.VISA)
    assert payment_0.credit_card_number(card_type='VISA')

    # MASTER_CARD
    payment_1 = Payment()
    assert payment_1.credit_card_number(card_type=CardType.MASTER_CARD)
    assert payment_1.credit_card_number(card_type='MASTER_CARD')

    # AMERICAN_EXPRESS
    payment_2 = Payment()
    assert payment_2.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    assert payment_2.credit_card_number(card_type='AMERICAN_EXPRESS')
    assert payment_2.credit_card_number

# Generated at 2022-06-25 20:58:11.470982
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number()

# Generated at 2022-06-25 20:58:15.208066
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    str_0 = payment_0.credit_card_number(CardType.VISA)
    payment_1 = Payment()
    str_0 = payment_1.credit_card_number(CardType.MASTER_CARD)
    payment_2 = Payment()
    str_0 = payment_2.credit_card_number(CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-25 20:58:20.201187
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number(CardType.VISA)
    assert payment_0.credit_card_number(CardType.MASTER_CARD)
    assert payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    try:
        payment_0.credit_card_number(CardType.CHINA_UNIONPAY)
    except NonEnumerableError:
        pass
    try:
        payment_0.credit_card_number(CardType.DISCOVER)
    except NonEnumerableError:
        pass
    try:
        payment_0.credit_card_number(CardType.JCB)
    except NonEnumerableError:
        pass

# Generated at 2022-06-25 20:58:21.990359
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number() == '4455 5299 1152 2450'


# Generated at 2022-06-25 20:58:29.579316
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test Visa
    payment_1 = Payment()
    payment_1.credit_card_number(0)
    payment_1.credit_card_number('0')
    # Test MasterCard
    payment_2 = Payment()
    payment_2.credit_card_number(1)
    payment_2.credit_card_number(CardType['MASTER_CARD'])
    payment_2.credit_card_number('1')
    payment_2.credit_card_number('MASTER_CARD')
    payment_2.credit_card_number('MASTER CARD')
    # Test American Express
    payment_3 = Payment()
    payment_3.credit_card_number(2)
    payment_3.credit_card_number(CardType['AMERICAN_EXPRESS'])
    payment_3.credit_card_

# Generated at 2022-06-25 20:58:35.869538
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    list_of_enums = [CardType.VISA,CardType.MASTER_CARD,CardType.AMERICAN_EXPRESS]
    for enum in list_of_enums:
        credit_card = payment.credit_card_number(enum)
        if enum == CardType.VISA:
            assert credit_card[0:1] == '4'
        elif enum == CardType.MASTER_CARD:
            assert credit_card[0:1] == '5'
        elif enum == CardType.AMERICAN_EXPRESS:
            assert credit_card[0:2] == '34' or credit_card[0:2] == '37'

# test_Payment_credit_card_number()

# Generated at 2022-06-25 20:58:40.583203
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    credit_card_number_0 = payment_0.credit_card_number()
    regex_0 = re.compile(r'\d\d\d\d\s\d\d\d\d\s\d\d\d\d\s\d\d\d\d')

    assert regex_0.search(credit_card_number_0)


# Generated at 2022-06-25 20:58:43.546176
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = get_random_item(CardType, rnd=payment_0.random)
    str_0 = payment_0.credit_card_number(card_type=card_type_0)
    assert str_0.startswith('5')


# Generated at 2022-06-25 20:58:44.661226
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert len(payment_0.credit_card_number()) == 19

# Generated at 2022-06-25 20:59:20.011427
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test_Payment = Payment()
    assert test_Payment.credit_card_number(CardType.VISA)
    assert test_Payment.credit_card_number(CardType.MASTER_CARD)
    assert test_Payment.credit_card_number(CardType.AMERICAN_EXPRESS)


# Generated at 2022-06-25 20:59:21.639414
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    number_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 20:59:27.506477
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print('Testing for method credit_card_number of class Payment')
    payment_0 = Payment()
    credit_card_number_0 = payment_0.credit_card_number()
    credit_card_number_1 = payment_0.credit_card_number(card_type=CardType.VISA)
    print('Result is: ',credit_card_number_0)
    if(credit_card_number_0 == credit_card_number_1):
        print('Succeeded.')
    else:
        print('Failed.')


# Generated at 2022-06-25 20:59:30.963755
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    cc_len = len(credit_card_number)
    assert (cc_len == 17) or (cc_len == 19)
    assert payment.credit_card_number(CardType.VISA) == credit_card_number


# Generated at 2022-06-25 20:59:34.447756
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = get_random_item(CardType, rnd=payment_0.random)
    result_0 = payment_0.credit_card_number(card_type=card_type_0)

# Generated at 2022-06-25 20:59:36.791897
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    for _ in range(1000):
        number = payment_0.credit_card_number()
        assert len(number) == 19
        assert " ".join(number.split()).isdigit()

# Generated at 2022-06-25 20:59:44.094737
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test 1
    payment_0 = Payment(seed=13)
    string_0 = payment_0.credit_card_number()
    assert string_0 == "4070 0003 3819 7305"
    # Test 2
    payment_1 = Payment(seed=22)
    string_1 = payment_1.credit_card_number()
    assert string_1 == "5161 0056 7663 0809"
    # Test 3
    payment_2 = Payment(seed=25)
    string_2 = payment_2.credit_card_number()
    assert string_2 == "5395 7496 7739 6105"
    # Test 4
    payment_3 = Payment(seed=25)
    string_3 = payment_3.credit_card_number(CardType.MASTER_CARD)

# Generated at 2022-06-25 20:59:45.637328
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    cc_num = payment.credit_card_number()
    assert(len(cc_num) == 19)

# Generated at 2022-06-25 20:59:53.195399
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()

    card_number_VISA_Pattern = re.compile(r'^(?:4[0-9]{12}(?:[0-9]{3})?)$')
    card_number_MasterCard_Pattern = re.compile(r'^(?:5[1-5][0-9]{14})$')
    card_number_AmericanExpress_Pattern = re.compile(r'^(?:3[47][0-9]{13})$')

    for i in range(0, 1000):

        card_type = p.random.choice(['VISA', 'MasterCard', 'AmericanExpress'])
        if card_type == 'VISA':
            assert card_number_VISA_Pattern.match(p.credit_card_number())

# Generated at 2022-06-25 20:59:57.326711
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number() == '4455 5299 1152 2450'
    assert Payment().credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert Payment().credit_card_number(CardType.MASTER_CARD) == '2221 0069 1027 9759'
    assert Payment().credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-25 21:00:58.359859
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Input arguments for this method
    card_type = CardType.VISA

    # Perform the tested operation
    result = Payment().credit_card_number(card_type)

    # Validate the result
    assert re.match(r'[0-9]{4} ?[0-9]{4} ?[0-9]{4} ?[0-9]{4}', result) is not None


# Generated at 2022-06-25 21:00:59.661000
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    assert payment_0.credit_card_number() == '4455 5299 1152 2450'


# Generated at 2022-06-25 21:01:03.858337
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    card_type_0 = CardType.MASTER_CARD
    str_0 = payment_0.credit_card_number(card_type_0)
    card_type_1 = CardType.VISA
    str_1 = payment_0.credit_card_number(card_type_1)
    card_type_2 = CardType.AMERICAN_EXPRESS
    str_2 = payment_0.credit_card_number(card_type_2)



# Generated at 2022-06-25 21:01:04.899990
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number() != ''


# Generated at 2022-06-25 21:01:06.486996
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.compile(r'(\d{4})(\d{4})(\d{4})(\d{4})').search(payment.credit_card_number())


# Generated at 2022-06-25 21:01:07.763950
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17


# Generated at 2022-06-25 21:01:08.551556
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    string_0 = payment_0.credit_card_number()


# Generated at 2022-06-25 21:01:13.139166
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    payment_1 = Payment()
    result_0 = payment_0.credit_card_number(CardType.MASTER_CARD)
    result_1 = payment_1.credit_card_number(CardType.AMERICAN_EXPRESS)
    result_2 = payment_0.credit_card_number(CardType.AMERICAN_EXPRESS)
    result_3 = payment_0.credit_card_number(CardType.VISA)
    result_4 = payment_1.credit_card_number()

    assert result_0 == "5115 6794 9241 5672"
    assert result_1 == "3737 039413 05196"
    assert result_2 == "3491 049791 36581"
    assert result_3 == "4501 2845 1435 1647"
   

# Generated at 2022-06-25 21:01:15.082340
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    module = Payment()
    assert re.match(r'^\d{4} \d{4} \d{4} \d{4}$', module.credit_card_number())
    assert (len(module.credit_card_number()) == 19)
    assert module.credit_card_number(None)

# Generated at 2022-06-25 21:01:16.194185
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_0 = Payment()
    choice_0 = payment_0.credit_card_number()
    assert len(choice_0) > 16
    
    