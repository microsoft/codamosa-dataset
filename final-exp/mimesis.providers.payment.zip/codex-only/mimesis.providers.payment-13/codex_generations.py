

# Generated at 2022-06-23 21:30:14.653024
# Unit test for method cid of class Payment
def test_Payment_cid():
    print(Payment().cid())


# Generated at 2022-06-23 21:30:17.275166
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cidNum = payment.cid()
    assert cidNum > 999 and cidNum < 10000


# Generated at 2022-06-23 21:30:20.652361
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card = payment.credit_card_number(card_type = CardType.MASTER_CARD)
    print(card)


# Generated at 2022-06-23 21:30:22.974253
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    pay = Payment('en')
    pay.ethereum_address()
    
test_Payment_ethereum_address()


# Generated at 2022-06-23 21:30:24.338926
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment('en')
    print(p.paypal())
    assert type(p.paypal()) == str

# Generated at 2022-06-23 21:30:26.467682
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    assert re.match(r'0x[0-9a-f]{40}', p.ethereum_address())


# Generated at 2022-06-23 21:30:34.217514
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment('en')
    #there might be a bug in this method, so the testcase doesn't need to be fixed here

# Generated at 2022-06-23 21:30:37.035485
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment."""
    from mimesis.schema import Field
    from mimesis.schema import Schema

    payment = Payment()
    s = Schema(payment)
    data = s.create(5,
        ethereum_address = Field("ethereum_address"),
    )
    print(data)


# Generated at 2022-06-23 21:30:39.265525
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test method credit_card_number of class Payment."""
    payment = Payment()
    print(payment.credit_card_number())

# Generated at 2022-06-23 21:30:41.095522
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    assert Payment.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:30:41.969385
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()

# Generated at 2022-06-23 21:30:43.103702
# Unit test for constructor of class Payment
def test_Payment():
    Payment()

# Generated at 2022-06-23 21:30:45.017921
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert 4 < Payment().cid() < 9999


# Generated at 2022-06-23 21:30:48.086748
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment(localized=True)
    network_list = p.credit_card_network()
    assert network_list == "MasterCard"



# Generated at 2022-06-23 21:30:51.294886
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    bitcoin_address = p.bitcoin_address()
    print(bitcoin_address)
    assert bitcoin_address is not None and len(bitcoin_address) == 34 and bitcoin_address[0] in ("1", "3")


# Generated at 2022-06-23 21:30:53.396401
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    cvv = p.cvv()
    assert len(str(cvv)) == 3


# Generated at 2022-06-23 21:30:58.604107
# Unit test for constructor of class Payment
def test_Payment():
    """Tests constructor from class Payment"""
    p = Payment()
    assert p.cid()
    assert p.paypal()
    assert p.bitcoin_address()
    assert p.ethereum_address()
    assert p.credit_card_network()
    assert p.credit_card_number()
    assert p.credit_card_expiration_date()
    assert p.cvv()
    assert p.credit_card_owner()

# Generated at 2022-06-23 21:31:01.896257
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Create object of class Payment
    payment = Payment()
    # Call method cid
    cid = payment.cid()
    # Check
    assert isinstance(cid, int) == True


# Generated at 2022-06-23 21:31:05.517685
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Unit test for method bitcoin_address of class Payment."""
    payment = Payment('en')
    dict_ = dict()
    for i in range(1000):
        dict_[payment.bitcoin_address()] = True
    assert len(dict_) == 1000


# Generated at 2022-06-23 21:31:08.892373
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    paypal = p.paypal()
    assert isinstance(paypal, str)
    assert 0 < len(paypal) <= 256


# Generated at 2022-06-23 21:31:12.652150
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Unit test for method credit_card_network of class Payment."""
    payment = Payment()
    answer = payment.credit_card_network()
    assert answer in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:31:14.218144
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment is not None


# Generated at 2022-06-23 21:31:15.891602
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    print('Payment.ethereum_address: {}'.format(Payment().ethereum_address()))


# Generated at 2022-06-23 21:31:17.321826
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
  for i in range(10):
    print(Payment().credit_card_owner())


# Generated at 2022-06-23 21:31:19.216700
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment('en', seed=1234567890)
    assert payment.cid() == 1934





# Generated at 2022-06-23 21:31:21.482946
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pay = Payment()
    assert len(pay.paypal()) == len('wolf235@gmail.com')


# Generated at 2022-06-23 21:31:25.038639
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    address = payment.ethereum_address()
    result = re.fullmatch('0x[0-9a-zA-Z]{64}', address)
    assert result != None


# Generated at 2022-06-23 21:31:28.637745
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    assert re.match(r'0x[a-zA-Z0-9]{40}$', p.ethereum_address())


# Generated at 2022-06-23 21:31:31.047207
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    print(payment.cid())
    assert type(payment.cid()) == int


# Generated at 2022-06-23 21:31:39.823751
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    payment.seed(1)
    b = payment.bitcoin_address()
    assert b == "1CnGcZU5jCbw7VkTNHLAgDd7yUxvzSknPY"
    cc = payment.credit_card_number(CardType.VISA)
    assert cc == "4438 4483 3455 0171"
    ccd = payment.credit_card_expiration_date()
    assert ccd == "02/24"
    cvv = payment.cvv()
    assert cv == "343"
    co = payment.credit_card_owner()
    assert co['credit_card'] == "4438 4483 3455 0171"
    assert co['expiration_date'] == "02/24"

# Generated at 2022-06-23 21:31:43.399475
# Unit test for constructor of class Payment
def test_Payment():
    pay = Payment()
    print(pay)
    print(pay.paypal())
    print(pay.credit_card_number())
    print(pay.credit_card_expiration_date())
    print(pay.credit_card_owner())

# Generated at 2022-06-23 21:31:48.845228
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('es')

    for i in range(100):
        # Generate random gender
        gender: Optional[Gender] = p.random.choice([Gender.MALE, Gender.FEMALE])

        # Generate the owner of the card
        owner = p.credit_card_owner(gender=gender)

        # Assert the gender
        assert gender == owner['gender']

        # Assert the name
        assert owner['name'].upper() == owner['credit_card']['owner']

# Generated at 2022-06-23 21:31:50.260201
# Unit test for constructor of class Payment
def test_Payment():
    f = Payment()
    assert str(f) == 'Payment()'

# Generated at 2022-06-23 21:31:51.728553
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    assert type(Payment().credit_card_network()) == str


# Generated at 2022-06-23 21:31:53.834393
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    if __debug__:
        payment = Payment()
        assert isinstance(payment.bitcoin_address(), str)


# Generated at 2022-06-23 21:31:57.914205
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Test cid of class Payment."""
    result = Payment().cid()
    assert isinstance(result, int)
    assert len(str(result)) == 4


# Generated at 2022-06-23 21:32:00.179696
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment(seed=12345)
    result = payment.credit_card_network()
    assert result == "American Express"


# Generated at 2022-06-23 21:32:01.609994
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    assert type(p.credit_card_owner()) == dict

# Generated at 2022-06-23 21:32:04.343779
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    address = Payment().ethereum_address()
    assert address == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'


# Generated at 2022-06-23 21:32:07.541992
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    address1 = Payment().bitcoin_address()
    address2 = Payment().bitcoin_address()
    if address1 == address2:
        raise ("bitcoin_address() method is not random.")
    else:
        print("bitcoin_address PASS")


# Generated at 2022-06-23 21:32:11.074339
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    credit_card_network = payment.credit_card_network()
    assert credit_card_network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:32:13.620647
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    # Regenerate the expression to check if a new value is created.
    for _ in range(10):
        assert 1000 <= payment.cid() <= 9999


# Generated at 2022-06-23 21:32:18.609484
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """Test method paypal of class Payment."""
    payment = Payment()
    result = payment.paypal()
    assert isinstance(result, str)
    assert re.match(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$', result) == True


# Generated at 2022-06-23 21:32:19.990391
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert payment.cvv() > 0

# Generated at 2022-06-23 21:32:21.859983
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert payment.cid() >= 1000 and payment.cid() <= 9999


# Generated at 2022-06-23 21:32:23.889435
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment('en', seed=1)
    return p.Payment.paypal() == 'wolf235@gmail.com'


# Generated at 2022-06-23 21:32:25.192455
# Unit test for method cid of class Payment
def test_Payment_cid():
    a = Payment()
    assert type(a.cid()) == int


# Generated at 2022-06-23 21:32:32.028865
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment

    pp = Payment()

    for i in range(100):
        minimum = 10
        maximum = 15
        assert int(pp.credit_card_expiration_date(minimum, maximum)[-2:]) >= minimum \
               and int(pp.credit_card_expiration_date(minimum, maximum)[-2:]) <= maximum
        assert int(pp.credit_card_expiration_date(minimum, maximum)[:2]) >= 1 \
               and int(pp.credit_card_expiration_date(minimum, maximum)[:2]) <= 12


# Generated at 2022-06-23 21:32:36.498267
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Unit test for method credit_card_network of class Payment."""
    payment = Payment('en')
    payment_result = payment.credit_card_network()
    assert payment_result in CREDIT_CARD_NETWORKS
    print("payment.credit_card_network: ", payment_result)


# Generated at 2022-06-23 21:32:38.347822
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p is not None
    assert isinstance(p, Payment)

# Generated at 2022-06-23 21:32:41.598936
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment('en')
    assert re.match('[13][a-km-zA-HJ-NP-Z1-9]{33}', payment.bitcoin_address())


# Generated at 2022-06-23 21:32:49.770158
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    bitcoin_address = payment.bitcoin_address()
    # First character cannot be '0' or 'O'
    assert bitcoin_address[0] not in ['0', 'O']
    # Last character cannot be '0' or 'O'
    assert bitcoin_address[-1] not in ['0', 'O']
    # First character must be '1' or '3'
    assert bitcoin_address[0] in ['1', '3']
    # Address length must be 34
    assert len(bitcoin_address) == 34
    # Address must contain only letters and digits and address cannot contain 'l' or 'I' or '0' or 'O'

# Generated at 2022-06-23 21:32:52.318419
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # Arrange
    payment = Payment()

    # Act
    result = payment.bitcoin_address()

    # Assert
    assert len(result) == 35


# Generated at 2022-06-23 21:32:53.565478
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    gen = Payment()
    print(gen.cvv())


# Generated at 2022-06-23 21:32:55.393080
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment(seed=1000)
    assert p.cvv() == 319


# Generated at 2022-06-23 21:32:59.239262
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    bitcoin_address = p.bitcoin_address()
    assert len(bitcoin_address) == 35
    assert re.match(r'[13][A-Za-z0-9]{32}', bitcoin_address) is not None


# Generated at 2022-06-23 21:33:05.972816
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    print(payment.credit_card_owner())
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.cvv())
    print(payment.bitcoin_address())
    print(payment.ethereum_address())
    print(payment.credit_card_network())
    print(payment.cid())
    print(payment.paypal())


# Generated at 2022-06-23 21:33:13.460377
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    lists = ['05/20', '04/19', '02/23', '01/22', '11/19', '09/21', '06/16', '07/28', '08/18', '10/17']
    n = 0

    while n < 10:
        sb = Payment()
        name = sb.credit_card_expiration_date()

        if name == lists[n]:
            assert True
        else:
            assert False

        n += 1

# Generated at 2022-06-23 21:33:17.597546
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS
    result = payment.credit_card_network()
    # The result should be always the same
    assert result == 'MasterCard'


# Generated at 2022-06-23 21:33:21.461827
# Unit test for method paypal of class Payment
def test_Payment_paypal():
	x = Payment()
	lst = []
	for i in range(10):
		lst.append(x.paypal())
	lst_2 = list(set(lst))
	assert len(lst) == len(lst_2)

# Generated at 2022-06-23 21:33:25.310767
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    #Create object from Payment class
    payment = Payment()
    #Get list of credit card networks
    card_network = CREDIT_CARD_NETWORKS
    #Get random credit card network
    card_network_random = payment.credit_card_network()
    assert card_network_random in card_network


# Generated at 2022-06-23 21:33:29.996834
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    print(p.credit_card_network())
    print(p.credit_card_network())
    print(p.credit_card_network())


# Generated at 2022-06-23 21:33:34.455421
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    provider = Payment()
    date_card = provider.credit_card_expiration_date()
    data = date_card.split('/')
    month = int(data[0])
    year = int(data[1])
    assert (1 <= month <= 12)
    assert (16 <= year <= 25)

# Generated at 2022-06-23 21:33:36.601293
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    eth_address = Payment().ethereum_address()
    assert len(eth_address) > 0
    assert eth_address.startswith("0x")

# Generated at 2022-06-23 21:33:38.923569
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment()
    print(provider.credit_card_network())


# Generated at 2022-06-23 21:33:42.635205
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert re.match(r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)", payment.paypal())


# Generated at 2022-06-23 21:33:45.040659
# Unit test for constructor of class Payment
def test_Payment():
    obj = Payment(random.Random(0))


# Generated at 2022-06-23 21:33:46.687363
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment is not None



# Generated at 2022-06-23 21:33:53.204938
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment('en')
    # Generate a credit card owner
    print(p.credit_card_owner())
    # Generate a credit card number
    print(p.credit_card_number())
    # Generate an expiration date for a credit card
    print(p.credit_card_expiration_date())
    # Generate a CVV code
    print(p.cvv())
    # Generate a bitcoin address
    print(p.bitcoin_address())
    # Generate an Ethereum address
    print(p.ethereum_address())
    # Generate a PayPal account
    print(p.paypal())
    # Generate a CID code
    print(p.cid())

test_Payment()

# Generated at 2022-06-23 21:33:55.604536
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert re.search(r'\s*\d{3}\s*', Payment().cvv())


# Generated at 2022-06-23 21:33:57.728012
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert Payment().bitcoin_address() != ''
    assert Payment().bitcoin_address() != None


# Generated at 2022-06-23 21:34:03.072822
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    address = Payment().ethereum_address()
    assert len(address) == 42
    assert address.startswith('0x')
    assert re.match(r'0x[0-9a-fA-F]{40}$', address)


# Generated at 2022-06-23 21:34:10.780478
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    p = Payment()
    assert re.search(r'[0-9]{16}', p.credit_card_number(CardType.VISA))
    assert re.search(r'[0-9]{16}', p.credit_card_number(CardType.MASTER_CARD))
    assert re.search(r'[0-9]{15}', p.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-23 21:34:11.558436
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert len(Payment().bitcoin_address(), 34)


# Generated at 2022-06-23 21:34:14.936655
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    data = Payment().credit_card_owner(Gender.MALE)
    assert data == {
        'credit_card': '9636 5868 7296 5798',
        'expiration_date': '02/18',
        'owner': 'MR. DAVID FOWLER'
    }

# Generated at 2022-06-23 21:34:21.172763
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Test credit_card_owner method. It simulates the behavior"""
    p = Payment()
    print ("test_Payment_credit_card_owner")
    print ("Case when gender is none")
    print(p.credit_card_owner())
    print ("Case when gender is male")
    print(p.credit_card_owner(gender=Gender.MALE))
    print ("Case when gender is female")
    print(p.credit_card_owner(gender=Gender.FEMALE))

# Generated at 2022-06-23 21:34:24.918138
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    test_credit_card_owner = Payment()
    result = test_credit_card_owner.credit_card_owner()
    assert result is not None
    assert "credit_card" in result
    assert len(result["credit_card"]) == 19
    assert "expiration_date" in result
    assert len(result["expiration_date"]) == 5
    assert "owner" in result

# Generated at 2022-06-23 21:34:27.905238
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    o = Payment()
    o.credit_card_owner()
    o.credit_card_owner(gender=Gender.MALE)

# Generated at 2022-06-23 21:34:30.032053
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment(seed=0)
    print(p.credit_card_expiration_date())


# Generated at 2022-06-23 21:34:33.320165
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert payment.ethereum_address() == "0x8b42f2c2abfc9b9f3065e8e6dceb3a3f3ac41f38"

# Generated at 2022-06-23 21:34:37.481158
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Test method Payment.cvv().

    Condition of correct working: CVV contains three numbers.

    :return:
    """
    payment = Payment()
    cvv = payment.cvv()
    result = len(str(cvv)) == 3
    assert result is True

# Generated at 2022-06-23 21:34:39.661096
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment(seed=42)
    assert payment.cvv() == 786


# Generated at 2022-06-23 21:34:42.374643
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    eth_address = payment.ethereum_address()
    assert len(eth_address) == 42

# Generated at 2022-06-23 21:34:44.720958
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    _payment = Payment()
    assert _payment.credit_card_owner().__len__() == 3
    assert len(_payment.credit_card_owner()['expiration_date']) == 6
    assert _payment.credit_card_owner()['credit_card'].__len__() == 19


# Generated at 2022-06-23 21:34:50.721985
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    for _ in range(5):
        gender = 'male'
        owner = Payment().credit_card_owner(gender=gender)
        assert len(owner['credit_card']) == 4 * 3 + 3
        assert len(owner['expiration_date']) == 5
        assert re.search(r'^[A-Z]+$', owner['owner'])
        assert owner['owner'].split()[-1] in ['SR', 'JR', 'II', 'III']

# Generated at 2022-06-23 21:34:56.548702
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Test for method credit_card_expiration_date of class Payment"""
    payment_ins = Payment()
    expiration_date = payment_ins.credit_card_expiration_date()
    try:
        assert len(expiration_date) == 5
        assert expiration_date[2] == "/"
    except AssertionError as err:
        print(err)


# Generated at 2022-06-23 21:34:59.829161
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    address = payment.bitcoin_address()
    assert len(address) == 34
    assert address[0] == '1' or address[0] == '3'



# Generated at 2022-06-23 21:35:02.043333
# Unit test for method cid of class Payment
def test_Payment_cid():
    cid = Payment().cid()
    assert isinstance(cid, int) and len(str(cid)) == 4


# Generated at 2022-06-23 21:35:04.573244
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pay = Payment()
    assert re.match(r'^(\d{4} ){3}\d{4}$', pay.credit_card_number())


# Generated at 2022-06-23 21:35:06.352225
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Unit test for method cvv of class Payment."""
    payment = Payment()
    assert isinstance(payment.cvv(), int)


# Generated at 2022-06-23 21:35:09.132202
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.cid() in range(1000, 10000)


# Generated at 2022-06-23 21:35:15.419525
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    ps = Payment()
    number = ps.credit_card_number()
    print(number)
    # import re
    # pattern = r'\d{4} \d{4} \d{4} \d{4}'
    # match = re.fullmatch(pattern, number)

if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-23 21:35:17.340972
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment(seed=1)
    res = p.paypal()
    assert res == 'kathy979@gmail.com'

# Generated at 2022-06-23 21:35:19.447125
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    Payment.ethereum_address(Payment())

# Generated at 2022-06-23 21:35:25.521378
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Unit test for method credit_card_owner of class Payment"""
    payment = Payment()
    gender = Gender.MALE
    result = payment.credit_card_owner(gender)
    assert type(result["credit_card"]) == str
    assert type(result["expiration_date"]) == str
    assert type(result["owner"]) == str
# end test_Payment_credit_card_owner


# Generated at 2022-06-23 21:35:27.277383
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment(seed=1111)
    result = p.cid()
    assert result == 7452


# Generated at 2022-06-23 21:35:30.454191
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment(seed=42)
    result = payment.ethereum_address()
    assert result == "0x5d2eaebc90bb7bd0a97a82d76e2b3a1482f7f3e6"


# Generated at 2022-06-23 21:35:31.385619
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    Payment.seed(0)
    assert Payment().paypal() == "timmie@lander.com"


# Generated at 2022-06-23 21:35:35.883060
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    data = "3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX"
    test1 = Payment.bitcoin_address()
    assert data == test1


# Generated at 2022-06-23 21:35:39.145187
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Unit test for method bitcoin_address of class Payment."""
    re_pattern = r'(3E)[a-zA-Z0-9]+'
    p = Payment()
    bitcoin_address = p.bitcoin_address()
    assert re.match(re_pattern, bitcoin_address)


# Generated at 2022-06-23 21:35:40.394616
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()

    assert len(card_number) == 19

# Generated at 2022-06-23 21:35:41.438699
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert type(Payment(seed=0).cid()) is int



# Generated at 2022-06-23 21:35:43.883663
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment(seed=12345678910)
    assert payment.cvv() == 844


# Generated at 2022-06-23 21:35:47.949382
# Unit test for constructor of class Payment
def test_Payment():
    """Unit test for constructor of class Payment."""

    payment = Payment()
    assert isinstance(payment, Payment)
    assert isinstance(payment, BaseProvider)
    assert payment.__person is not None


# Generated at 2022-06-23 21:35:50.588109
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment."""
    payment = Payment()
    address = payment.ethereum_address()

    assert len(address) == 42
    assert address[:2] == '0x'
    assert address[2:].isalnum()

# Generated at 2022-06-23 21:36:01.931238
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    rc = random.Random()
    random.seed(1)
    err = 0
    for i in range(1000):
        cvv = Payment(random_class=rc).cvv()
        if type(cvv)!=int or not(100<=cvv<=999):
            err += 1
    assert err==0
    assert(Payment(random_class=rc).cvv() == 975)
    assert(Payment(random_class=rc).cvv() == 639)
    assert(Payment(random_class=rc).cvv() == 732)
    assert(Payment(random_class=rc).cvv() == 864)
    assert(Payment(random_class=rc).cvv() == 785)
    assert(Payment(random_class=rc).cvv() == 286)
   

# Generated at 2022-06-23 21:36:09.906472
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis import Generic
    from mimesis.enums import CardType
    # Unit test for assert return type of method
    g = Generic('en')
    assert isinstance(g.payment.credit_card_network(), str)
    # Unit test for assert the content of return type
    card_type = g.payment.credit_card_network()
    assert card_type in [
        CardType.AMERICAN_EXPRESS, CardType.VISA,
        CardType.MASTER_CARD, CardType.DISCOVER
    ]

# Generated at 2022-06-23 21:36:13.273700
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    bitcoin_address = Payment().bitcoin_address()

    assert bitcoin_address[0] in ['1', '3']
    assert len(bitcoin_address) == 34
    assert bitcoin_address[1] in string.ascii_letters + string.digits


# Generated at 2022-06-23 21:36:15.641619
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    #unit test for method cvv of class Payment
    cc = Payment()
    assert cc.cvv() == cc.cvv()

# Generated at 2022-06-23 21:36:17.805921
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    user_email = p.paypal()
    assert user_email
    assert type(user_email) == str


# Generated at 2022-06-23 21:36:24.591383
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Check method Payment's credit_card_expiration_date."""
    c = Payment()
    assert c.credit_card_expiration_date() == '07/22'
    assert c.credit_card_expiration_date(minimum=18, maximum=19) == '12/18'
    assert c.credit_card_expiration_date(minimum=18, maximum=19) == '07/19'
    assert c.credit_card_expiration_date(minimum=18, maximum=19) == '06/18'
    assert c.credit_card_expiration_date(minimum=18, maximum=19) == '02/18'



# Generated at 2022-06-23 21:36:28.653442
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    data = Payment().paypal()
    assert data
    assert isinstance(data, str)
    assert not data.islower()
    assert not data.isupper()
    assert not data.isnumeric()
    assert len(data) >= 8
    assert '@' in data

# Generated at 2022-06-23 21:36:31.392130
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    py_payement = Payment('en')
    credit_card_expiration_date = py_payement.credit_card_expiration_date()
    assert len(credit_card_expiration_date) == 5

# Generated at 2022-06-23 21:36:33.310668
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    # do 20 tests
    for i in range(20):
        # get the random number of cvv
        cvv = p.cvv()
        # check if the number has 3 digits
        assert(isinstance(cvv, int))
        assert(len(str(cvv)) == 3)



# Generated at 2022-06-23 21:36:35.953500
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    for i in range(0, 5):
        payment = Payment(seed=123)
        assert len(payment.bitcoin_address()) == 35


# Generated at 2022-06-23 21:36:42.675391
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    res = payment.credit_card_owner(gender=None)
    res_keys = list(res.keys())
    assert res_keys == ['credit_card', 'expiration_date', 'owner']
    assert re.search('\d{4} \d{4} \d{4} \d{4}', res['credit_card'])
    assert re.search('\d{2}/\d{2}', res['expiration_date'])
    assert res['owner'][0].isupper()
    assert res['owner'].isupper()


# Generated at 2022-06-23 21:36:44.634312
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    p.credit_card_number()

# Generated at 2022-06-23 21:36:47.447482
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    print("credit card owner: " + str(p.credit_card_owner(gender=Gender.MALE)))

# Generated at 2022-06-23 21:36:51.561507
# Unit test for method cvv of class Payment
def test_Payment_cvv():

    # Setup
    import mimesis
    p = mimesis.Payment()

    # Exercise
    actual = p.cvv()

    # Validate
    import re
    pattern = re.compile('[0-9]{3}')
    assert pattern.fullmatch(str(actual))


# Generated at 2022-06-23 21:36:54.450893
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    address = Payment().bitcoin_address()
    p = re.compile('^[1|3][a-km-zA-HJ-NP-Z1-9]{25,34}$')
    assert p.match(address)

# Generated at 2022-06-23 21:37:04.905204
# Unit test for constructor of class Payment
def test_Payment():
    """Check if constructor of class Payment works.
    """
    payment = Payment()
    assert payment.cid() != None
    assert payment.paypal() != None
    assert payment.bitcoin_address() != None
    assert payment.bitcoin_address() != 'Addresses in Bitcoin use a custom 59-character base58'
    assert payment.ethereum_address() != None
    assert payment.ethereum_address() != 'Ethereum addresses are composed of the prefix "0x",'
    assert payment.credit_card_network() != None
    assert payment.credit_card_number(CardType.VISA) != None
    assert payment.credit_card_number(CardType.MASTER_CARD) != None
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) != None
    assert payment.credit_card_

# Generated at 2022-06-23 21:37:08.281065
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    credit_card_class = Payment()
    credit_card_number = credit_card_class.credit_card_number()
    print(credit_card_number)
    assert isinstance(credit_card_number, str)
    print(credit_card_class)

# Generated at 2022-06-23 21:37:08.734951
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    Payment().cvv()

# Generated at 2022-06-23 21:37:19.029474
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    cc = p.credit_card_number()
    cc_exp_date = p.credit_card_expiration_date()
    cc_owner = p.credit_card_owner(gender=Gender.FEMALE)
    
    assert(re.search(r'\d{4} \d{4} \d{4} \d{4}', cc) is not None)
    assert(re.search(r'\d\d/\d{2}', cc_exp_date) is not None)
    assert(cc in cc_owner['credit_card'])
    assert(cc_exp_date in cc_owner['expiration_date'])

# Generated at 2022-06-23 21:37:21.510625
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    x = Payment()

    assert isinstance(x.paypal(),str)
    assert len(x.paypal()) >= 6
    assert x.paypal()[-10:] == '@gmail.com'


# Generated at 2022-06-23 21:37:23.022784
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert len(Payment().cid()) == 4


# Generated at 2022-06-23 21:37:27.134100
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    expected = {'credit_card': '5274 7946 9585 3171', 'expiration_date': '05/17', 'owner': 'DAVID GILBERT'}
    assert Payment('en').credit_card_owner() == expected

# Generated at 2022-06-23 21:37:28.283197
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cid = payment.cid()
    assert 1000 < cid < 9999


# Generated at 2022-06-23 21:37:30.933225
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    x = Payment().credit_card_number()
    assert re.search(r'\d{4} \d{4} \d{4} \d{4}',x)!=None

# Generated at 2022-06-23 21:37:31.919748
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    # print(payment.bitcoin_address())


# Generated at 2022-06-23 21:37:33.794745
# Unit test for method cid of class Payment
def test_Payment_cid():
	p = Payment()
	assert len(str(p.cid())) == 4


# Generated at 2022-06-23 21:37:35.880886
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert '@' in payment.paypal()


# Generated at 2022-06-23 21:37:38.025726
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    assert Payment().paypal() in ['wolf235@gmail.com', 'wolf235@gmail.com', 'wolf235@gmail.com']


# Generated at 2022-06-23 21:37:42.010628
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    result = payment.bitcoin_address()
    assert (result[0] in ['1', '3'])
    assert (len(result) == 34)

# Generated at 2022-06-23 21:37:45.955185
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Unit test for method credit_card_expiration_date of class Payment."""
    payment = Payment(seed=42)
    date = payment.credit_card_expiration_date()
    assert date == '01/23'

# Generated at 2022-06-23 21:37:48.287702
# Unit test for method cid of class Payment
def test_Payment_cid():
    x = Payment()
    for i in range(0, 1000):
        assert x.cid() >= 1000 and x.cid() <= 9999


# Generated at 2022-06-23 21:37:58.293408
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    print("===== test_Payment() =====\n")
    print("===== payment.cid() =====\n")
    print(payment.cid())

    print("===== payment.paypal() =====\n")
    print(payment.paypal())

    print("===== payment.bitcoin_address() =====\n")
    print(payment.bitcoin_address())

    print("===== payment.ethereum_address() =====\n")
    print(payment.ethereum_address())

    print("===== payment.credit_card_network() =====\n")
    print(payment.credit_card_network())

    print("===== payment.credit_card_number() =====\n")
    print(payment.credit_card_number())


# Generated at 2022-06-23 21:38:01.299605
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    a = Payment(seed=12)
    i = 0
    while i <= 10:
        assert a.cvv() in range(100, 999)
        i+=1


# Generated at 2022-06-23 21:38:07.448636
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    obj = Payment()
    assert type(obj.credit_card_owner()) == dict
    assert obj.credit_card_owner()["credit_card"].count(" ") == 3
    assert re.search(r"(01|02|03|04|05|06|07|08|09|10|11|12)/2019", obj.credit_card_owner()["expiration_date"]) != None
    assert obj.credit_card_owner()["owner"].count(" ") == 1

# Generated at 2022-06-23 21:38:08.153420
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    pass

# Generated at 2022-06-23 21:38:09.944884
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    for i in range(10):
        print(Payment().bitcoin_address())


# Generated at 2022-06-23 21:38:11.221521
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert Payment().cvv() <= 999


# Generated at 2022-06-23 21:38:13.061325
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_num = Payment.credit_card_number()
    assert isinstance(card_num, str)

# Generated at 2022-06-23 21:38:22.394963
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    print("CID: ", p.cid())
    print("PayPal: ", p.paypal())
    print("Bitcoin address: ", p.bitcoin_address())
    print("CID: ", p.cid())
    print("Ethereum address: ", p.ethereum_address())
    print("Credit card network: ", p.credit_card_network())
    print("Credit card number: ", p.credit_card_number())
    print("Credit card expiration date: ", p.credit_card_expiration_date())
    print("CVV: ", p.cvv())
    print("Credit card owner: ", p.credit_card_owner())

if __name__ == "__main__":
    test_Payment()

# Generated at 2022-06-23 21:38:25.149557
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    print('Testing method cid of class Payment')
    for i in range(10):
        print('  Test ' + str(i) + ':')
        print('    ' + str(p.cid()))

# Generated at 2022-06-23 21:38:27.815991
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert re.search(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", payment.paypal()) != None



# Generated at 2022-06-23 21:38:29.321182
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    pay = Payment()
    cvv = pay.cvv()
    assert cvv <= 999 and cvv >= 100


# Generated at 2022-06-23 21:38:31.520222
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    assert re.match(r'0x[0-9a-f]{40}', p.ethereum_address())

# Generated at 2022-06-23 21:38:34.558498
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    test_Payment = Payment()
    assert Payment.__name__ == 'Payment'
    assert test_Payment.__class__.__name__ == 'Payment'
    assert type(test_Payment.paypal()).__name__ == 'str'
    assert '@' in test_Payment.paypal()
    assert '.' in test_Payment.paypal()


# Generated at 2022-06-23 21:38:37.641035
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    for i in range(10):
        hang=Payment('en')
        print(hang.cvv())
        print(type(hang.cvv()))

# Generated at 2022-06-23 21:38:40.252724
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment(seed=1234)
    # Check the value is equal to expected value
    assert (p.cid() == 5572)


# Generated at 2022-06-23 21:38:45.617994
# Unit test for constructor of class Payment
def test_Payment():
   
    payment = Payment()
    
    print(payment.paypal())
    print(payment.bitcoin_address())
    print(payment.ethereum_address())
    print(payment.credit_card_network())
    print(payment.credit_card_number())
    print(payment.credit_card_expiration_date())
    print(payment.cvv())
    print(payment.cid())
    print(payment.credit_card_owner())
    
test_Payment()

# Generated at 2022-06-23 21:38:48.357509
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    assert p.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:38:51.257550
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    value = payment.credit_card_expiration_date()
    assert isinstance(value, str) and len(value) == 5, "Unexpected value"

# Generated at 2022-06-23 21:38:54.893468
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # Test for cvv for class Payment
    i = 0
    while i < 20:
        payment = Payment()
        print(payment.cvv())
        i = i + 1

# Generated at 2022-06-23 21:38:58.437916
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    x = Payment()
    number = re.compile(r'(1|3)[a-zA-Z0-9]{33}')
    for _ in range(100):
        assert (number.fullmatch(x.bitcoin_address()) is not None)


# Generated at 2022-06-23 21:39:00.709544
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    payment.credit_card_expiration_date()
    assert payment.credit_card_expiration_date() != payment.credit_card_expiration_date()

# Generated at 2022-06-23 21:39:04.902849
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    result = p.credit_card_owner()
    print(result)
    assert result['owner'] == 'KEATON LOU' or result['owner'] == 'TRAVIS JOEANN'

# Generated at 2022-06-23 21:39:08.449637
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert re.match('^[a-z0-9_]+@[a-z0-9]+(\.[a-z]+){1,3}$', payment.paypal())


# Generated at 2022-06-23 21:39:14.166427
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    seed = 678
    provider = Payment(seed=seed)
    result = provider.credit_card_owner()
    assert result['credit_card'] == '5222 0774 7673 3950'
    assert result['expiration_date'] == '04/19'
    assert result['owner'] == 'EMMA MACKENZIE'

# Generated at 2022-06-23 21:39:20.004671
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # GIVEN
    p = Payment(seed=1234)
    count = 0
    # WHEN
    for _ in range(1000):
        address = p.ethereum_address()
        if (len(address) == 42 and address[0:2] == "0x" and all([c in string.hexdigits for c in address[2:]])):
            count += 1
    # THEN
    print(count)
    assert count == 1000

# Generated at 2022-06-23 21:39:21.913689
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    a = Payment()
    assert len(a.ethereum_address()) == 42

# Generated at 2022-06-23 21:39:26.167139
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    CardOwner = Payment().credit_card_owner(gender = 'male')
    print(CardOwner)
    assert CardOwner['owner'].find('NAN') == -1, 'Wrong name'
    assert CardOwner['credit_card'].find(' ') > 0, 'Wrong credit card number'
    assert CardOwner['expiration_date'].find('/') > -1, 'Wrong date'

# Generated at 2022-06-23 21:39:29.858959
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.random is not None
    assert payment.datetime is not None
    assert payment.seed is not None
    assert payment.__person is not None


# Generated at 2022-06-23 21:39:33.022688
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    provider=Payment()
    assert provider.ethereum_address()=='0x9f9c7937f0c0b1aae3ebe2f2ae0b1a8e0e7f43f9'

# Generated at 2022-06-23 21:39:34.622151
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    result = p.cvv()
    assert result != None



# Generated at 2022-06-23 21:39:35.992953
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment('en')
    assert len(p.credit_card_network()) >= 1


# Generated at 2022-06-23 21:39:39.466984
# Unit test for method cid of class Payment
def test_Payment_cid():
    x = Payment().cid()
    y = Payment().cid()
    assert(type(x) == int)
    assert(type(y) == int)
    assert(len(str(x)) == 4)
    assert(len(str(y)) == 4)


# Generated at 2022-06-23 21:39:40.869586
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    assert Payment().paypal() is not None


# Generated at 2022-06-23 21:39:43.955226
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    obj = Payment()
    result = obj.credit_card_number()
    assert type(result) == str
    assert re.match(r"^\d{4}\s\d{4}\s\d{4}\s\d{4}$", result) is not None


# Generated at 2022-06-23 21:39:46.620093
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    print(payment.credit_card_owner(Gender.MALE))
    print(payment.credit_card_owner(Gender.FEMALE))
    print(payment.credit_card_owner(Gender.NEUTRAL))


# Generated at 2022-06-23 21:39:47.604968
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    test = Payment()
    print(test.credit_card_expiration_date())

# Generated at 2022-06-23 21:39:50.212826
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    network = payment.credit_card_network()
    print(network)
    assert network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:39:55.012966
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    # Test return of method
    assert p.ethereum_address() == '0x48a9c94e70f7d28d8cce0dd321e81b68b2607fc1'

# Generated at 2022-06-23 21:39:58.309582
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    creditCard = Payment()
    card = creditCard.credit_card_network()
    if (card not in CREDIT_CARD_NETWORKS):
        raise ValueError("credit_card_network() method output is not a Credit Card Network")


# Generated at 2022-06-23 21:40:01.336490
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Unit test for method cvv of class Payment.
        This method takes no parameter, it generates three digit number.
    """
    payment = Payment()
    assert payment.cvv() >= 100 and payment.cvv() <= 999



# Generated at 2022-06-23 21:40:13.122679
# Unit test for constructor of class Payment
def test_Payment():
    # unit test for constructor of class Payment
    payment = Payment()
    assert type(payment) is Payment
    assert payment.cid() is not None, 'CID is not generated'
    assert type(payment.paypal()) == str, 'PayPal is not generated'
    assert type(payment.bitcoin_address()) == str, 'Bitcoin address is not generated'
    assert type(payment.ethereum_address()) == str, 'Ethereum address is not generated'
    assert type(payment.credit_card_network()) == str, 'Credit card network is not generated'
    assert type(payment.credit_card_number()) == str, 'Credit card number is not generated'
    assert type(payment.credit_card_expiration_date()) == str, 'Credit card expiration date is not generated'

# Generated at 2022-06-23 21:40:15.552711
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    a = Payment(seed=123)
    for _ in range(100):
        result = a.credit_card_number()
        assert result.isdigit() == True
