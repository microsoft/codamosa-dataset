

# Generated at 2022-06-23 21:30:19.009697
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert isinstance(Payment().cid(),int)


# Generated at 2022-06-23 21:30:28.738786
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    ethereum_address = payment.ethereum_address()
    print(ethereum_address)
    assert re.match(r'^0x[0-9a-f]{40}$', ethereum_address) is not None

# Generated at 2022-06-23 21:30:30.997107
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    for i in range(1000):
        assert 6 <= len(p.credit_card_expiration_date()) <= 7

# Generated at 2022-06-23 21:30:42.335957
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment(seed=42)
    # Testing minimum parameter
    payment.credit_card_expiration_date(minimum=2000)
    assert payment.credit_card_expiration_date() == "11/2000"
    assert payment.credit_card_expiration_date() == "06/2001"
    assert payment.credit_card_expiration_date() == "05/2002"

    # Testing maximum parameter
    payment.credit_card_expiration_date(maximum=2000)
    assert payment.credit_card_expiration_date() == "02/2000"
    assert payment.credit_card_expiration_date() == "01/2000"
    assert payment.credit_card_expiration_date() == "09/2000"

    # Testing minimum and maximum parameters

# Generated at 2022-06-23 21:30:46.917813
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    for _ in range(10):
        result = payment.paypal()
        assert '@' in result
        assert len(result) < 20
        assert '.' not in result.split('@')[1]



# Generated at 2022-06-23 21:30:49.583756
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    print(payment.credit_card_owner(Gender.MALE))
    print(payment.credit_card_owner(Gender.FEMALE))


# Generated at 2022-06-23 21:30:53.870976
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
  payment = Payment()
  assert payment.credit_card_network() == 'Visa' or payment.credit_card_network() == 'MasterCard' or payment.credit_card_network() == 'Discover' or payment.credit_card_network() == 'American Express' or payment.credit_card_network() == 'Maestro'


# Generated at 2022-06-23 21:31:01.384279
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    print("Test when callin g function cid() from class Payment: ", payment.cid())
    print("Test when calling function credit_card_number() from class Payment: ", payment.credit_card_number())
    print("Test when calling function paypal() from class Payment: ", payment.paypal())
    print("Test when calling function credit_card_network() from class Payment: ", payment.credit_card_network())
    print("Test when calling function credit_card_expiration_date() from class Payment: ", payment.credit_card_expiration_date())
    print("Test when calling function cvv() from class Payment: ", payment.cvv())
    print("Test when calling function credit_card_owner() from class Payment: ", payment.credit_card_owner())

# Generated at 2022-06-23 21:31:06.573034
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    owner = p.credit_card_owner(Gender.MALE)
    print(owner)
    assert owner['owner'] is not None and owner['owner'].isalpha() and \
           owner['credit_card'] is not None and owner['credit_card'].isdigit() and \
           owner['expiration_date'] is not None and owner['expiration_date'] != ''


# Generated at 2022-06-23 21:31:11.795071
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment."""
    p = Payment()
    res = p.ethereum_address()
    assert re.match(r'^0x[a-f0-9]{40}$', res), '{} is not in ethereum format.'.format(res)

# Generated at 2022-06-23 21:31:14.616017
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    assert re.match(r'^0x[0-9a-f]{40}$', p.ethereum_address()) is not None

# Generated at 2022-06-23 21:31:19.329595
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment(seed = 666)
    assert len(p.cvv()) == 3
    assert len(p.bitcoin_address()) == 34
    assert len(p.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(p.credit_card_number(CardType.MASTER_CARD)) == 17
    assert len(p.credit_card_number(CardType.VISA)) == 17
    assert len(p.credit_card_owner()["expiration_date"]) == 5
    assert len(p.credit_card_owner()["credit_card"]) == 17
    assert p.credit_card_owner(Gender.MALE)["owner"] == "WILLIAM TAYLOR"

# Generated at 2022-06-23 21:31:22.482322
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    print('\nUnit test for method ethereum_address of class Payment')
    for i in range(0, 10):
        print(Payment().ethereum_address())


# Generated at 2022-06-23 21:31:26.381170
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    paym = Payment('en')
    for _ in range(100):
        card_type = paym.credit_card_type()
        number = paym.credit_card_number(card_type=card_type)
        assert number.isdigit() and len(number) == 16
    return True

# Generated at 2022-06-23 21:31:31.247911
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Unit test for method credit_card_owner of class Payment."""
    payment = Payment()
    result = payment.credit_card_owner()
    assert 'credit_card' in result
    assert 'expiration_date' in result
    assert 'owner' in result

# Generated at 2022-06-23 21:31:38.175126
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment"""
    seed = 1234
    paymentObj = Payment()
    paymentObj.seed(seed)

    # Initialization of expected output:
    expected_ethereum_address = "0x5882F36D7008D0E4345A0D0D33A39E3487B1F284"

    # Computation of output:
    output = paymentObj.ethereum_address()

    # Checking if the expected and the output are the same:
    print(output)
    assert output == expected_ethereum_address

# Generated at 2022-06-23 21:31:42.262205
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    for _ in range(50):
        pat = r'^0x[0-9a-fA-F]{40}$'
        assert re.fullmatch(pat, payment.ethereum_address())


# Generated at 2022-06-23 21:31:47.674204
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """ Test case for method ethereum_address of class Payment. """
    payment = Payment()
    address = "0x9F4fCd4306F5b5c5F31A0fc5c5f5A5B5C5c5c5A5A5"
    payment.random.seed(1)
    result = payment.ethereum_address()
    assert result == address

# Generated at 2022-06-23 21:31:51.854916
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    # create a instance of class Payment
    p = Payment()
    # generate a random credit card network
    test_case = p.credit_card_network()
    print(test_case)
    assert(test_case in CREDIT_CARD_NETWORKS)


# Generated at 2022-06-23 21:31:53.222039
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    test_obj = Payment()
    test_obj.cvv()

# Generated at 2022-06-23 21:31:56.853060
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    for _ in range(10):
        assert(re.search(r'[^@]+@[^@]+\.[^@]+', payment.paypal()) is not None)

# Generated at 2022-06-23 21:31:58.926444
# Unit test for method cid of class Payment
def test_Payment_cid():
    r = Payment()
    r.cid()

# Generated at 2022-06-23 21:32:01.456325
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Expected to return the paypal account
    paypal=Payment(seed=1234).paypal()
    assert paypal=='wolf235@gmail.com'


# Generated at 2022-06-23 21:32:04.183007
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    cvv = Payment()
    assert cvv.cvv() > 100 and cvv.cvv() < 999
    assert cvv.cvv() == cvv.cvv()


# Generated at 2022-06-23 21:32:05.673726
# Unit test for method cid of class Payment
def test_Payment_cid():
    data = Payment()
    assert len(str(data.cid())) == 4


# Generated at 2022-06-23 21:32:06.951165
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    assert payment.credit_card_network() == "MasterCard"

# Generated at 2022-06-23 21:32:10.361662
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment("en")
    for i in range(10):
        assert (payment.credit_card_network()) in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:32:11.893581
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert payment.paypal() is not None


# Generated at 2022-06-23 21:32:15.441823
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    provider = Payment(seed=42)
    email = provider.paypal()
    assert email == 'robertslade@hotmail.com'



# Generated at 2022-06-23 21:32:21.421304
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(seed=0)

    assert p.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert p.credit_card_number(CardType.MASTER_CARD) == '5168 4416 4210 6804'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3761 508027 72238'



# Generated at 2022-06-23 21:32:22.962433
# Unit test for constructor of class Payment
def test_Payment():
    payment_test = Payment()
    assert payment_test.credit_card_owner() is not None

# Generated at 2022-06-23 21:32:25.347483
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Test the output for the method cid of class Payment."""
    p = Payment()
    code = p.cid()
    print("code =", code)
    assert isinstance(code, int)


# Generated at 2022-06-23 21:32:30.992548
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # Create a Payment object
    payment = Payment()

    # Use the method bitcoin_address
    address = payment.bitcoin_address()

    # Check the length of the address
    assert len(address) == 34
    # Check that the address starts with a 1 or a 3
    assert address[0] == '1' or address[0] == '3'


# Generated at 2022-06-23 21:32:35.521137
# Unit test for constructor of class Payment
def test_Payment():
    assert Payment().cid() > 0
    assert Payment().paypal()
    assert Payment().bitcoin_address()
    assert Payment().ethereum_address()
    assert Payment().credit_card_number()
    assert Payment().credit_card_expiration_date()
    assert Payment().cvv() > 0
    assert Payment().credit_card_owner()

# Generated at 2022-06-23 21:32:38.593276
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    seed = 1234
    provider = Payment(seed=seed)
    assert provider.paypal() == 'brianmburke@gmail.com'


# Generated at 2022-06-23 21:32:43.009042
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment_1 = Payment()
    payment_2 = Payment()
    random_payment_1 = payment_1.credit_card_owner()
    random_payment_2 = payment_2.credit_card_owner()
    assert random_payment_1 != random_payment_2


# Generated at 2022-06-23 21:32:46.053748
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    # Arrange
    payment = Payment()

    # Act
    result = payment.credit_card_network()

    # Assert
    assert result in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:32:50.183840
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    address = payment.ethereum_address()
    assert address == "0xe8ece9e6ff7dba52d4c07d37418036a89af9698d"


# Generated at 2022-06-23 21:32:52.117015
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    seed = 2
    rnd = Random(seed)
    payment = Payment(seed=seed)
    for i in range(10):
        assert rnd.randint(100, 999) == payment.cvv()

# Generated at 2022-06-23 21:32:53.991502
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()

    owner = payment.credit_card_owner(gender=Gender.FEMALE)
    assert owner['credit_card'] is not None
    assert owner['expiration_date'] is not None
    assert owner['owner'] is not None

# Generated at 2022-06-23 21:33:04.430203
# Unit test for constructor of class Payment
def test_Payment():
    pay = Payment(seed=42)
    # Generate a random CID.
    assert pay.cid() == 8708
    # Generate a random PayPal account.
    assert pay.paypal() == 'ruth49@gmail.com'
    # Generate a random bitcoin address.
    assert pay.bitcoin_address() == '1MfSVU5j5Ud7Vy4h6EXQPy4KjSKkBwquwP'
    # Generate a random Ethereum address.
    assert pay.ethereum_address() == '0x44b3a7b096c5a6a5a5a5a5a5a5a5a5a5a5a5a5a5a5'
    # Generate a random credit card network.

# Generated at 2022-06-23 21:33:06.058500
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    result = payment.credit_card_network()
    assert result


# Generated at 2022-06-23 21:33:08.224597
# Unit test for method cid of class Payment
def test_Payment_cid():
    mock = Payment()
    assert mock.cid() >= 1000 and mock.cid() <= 9999


# Generated at 2022-06-23 21:33:16.359535
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    network_list = ['VISA','MASTER_CARD','AMERICAN_EXPRESS']
    from re import compile as regex_compiler
    regex_pattern = regex_compiler(r'(\d{4})(\d{4})(\d{4})(\d{4})')

    for network in network_list:
        network_instance = Payment(network)
        credit_card_number = network_instance.credit_card_number(network)
        assert regex_pattern.search(credit_card_number)
        


# Generated at 2022-06-23 21:33:20.776260
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Check generation of random bitcoin address."""
    payment = Payment(seed=0)
    bitcoin = payment.bitcoin_address()
    assert len(bitcoin) == 35
    assert bitcoin.startswith('1') or bitcoin.startswith('3')


# Generated at 2022-06-23 21:33:21.614071
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    a=Payment()
    assert len(a.bitcoin_address()) == 35


# Generated at 2022-06-23 21:33:24.784621
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    b = Payment(seed=1)
    result = b.bitcoin_address()
    assert result == '31uEbMgunupShBVTewXjtqbBv5MndwfXhb'




# Generated at 2022-06-23 21:33:26.534289
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    result = payment.credit_card_network()
    assert type(result) == str


# Generated at 2022-06-23 21:33:27.658391
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    pay = Payment()
    print(pay.cvv())

# Generated at 2022-06-23 21:33:32.175829
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Unit test for method cid of class Payment"""
    p = Payment()
    cid = p.cid()
    assert isinstance(cid, int)
    assert len(str(cid)) == 4


# Generated at 2022-06-23 21:33:35.071036
# Unit test for method cid of class Payment
def test_Payment_cid():
    print("\nTesting method cid of class Payment")
    import random

    random.seed(1)

    payment = Payment()

    for i in range(10):
        print(payment.cid())



# Generated at 2022-06-23 21:33:41.135909
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment(seed=42)
    assert payment.ethereum_address() == '0x89fe1c82320f928dfb43fcfb559a623b8d1a3c3f'
    assert payment.ethereum_address() == '0xf0f83e5119638c2e1d3f3e45ad47fdc89e6a8a39'


# Generated at 2022-06-23 21:33:46.765320
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    bitcoin_address = payment.bitcoin_address()
    print("Bitcoin Address: %s" % bitcoin_address)
    assert len(bitcoin_address) == 34
    assert bitcoin_address[0] == '1' or bitcoin_address[0] == '3'


# Generated at 2022-06-23 21:33:49.001800
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pr = Payment()
    result = pr.credit_card_number(CardType.VISA)
    # print(result)
    assert (len(result) == 19)

# Generated at 2022-06-23 21:33:51.104566
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    print(p.ethereum_address())
    return True



# Generated at 2022-06-23 21:33:57.532995
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    import json
    from mimesis.enums import Gender, CardType
    from mimesis.providers.payment import Payment
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment
    from mimesis.providers.person import Person
    payment = Payment()
    gender = Gender.MALE
    cardType = CardType.VISA
    result = payment.credit_card_owner(cardType,gender)

    # Credit card number
    credit_card_number_result = result['credit_card']
    credit_card_number_expected = payment.credit_card_number(cardType)

# Generated at 2022-06-23 21:33:59.896150
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    print(payment.credit_card_network())


# Generated at 2022-06-23 21:34:04.616103
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    inp = 'gunardi'
    expected = 0.04
    actual = Payment(seed=inp).bitcoin_address()
    assert actual == '147Rx8nEfkx7e1yHQYzwei7VdRpTMjK9V9', 'Actual Error!'

# Generated at 2022-06-23 21:34:08.205968
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()

    for i in range(1, 51):
        assert re.match(r'[0-9][0-9]/[2][0][1-9][6-9]', p.credit_card_expiration_date(minimum=16,maximum=25))
        assert p.credit_card_expiration_date(minimum=16,maximum=25) <= '12/25'
        assert p.credit_card_expiration_date(minimum=16,maximum=25) >= '01/16'

# Generated at 2022-06-23 21:34:10.124339
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment('en')
    assert len(payment.credit_card_expiration_date()) == 5

# Generated at 2022-06-23 21:34:15.611449
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=123)

    assert payment.credit_card_number(card_type=CardType.VISA) == '4555 5299 1152 2450'
    assert payment.credit_card_number(card_type=CardType.MASTER_CARD) == '5256 2079 8348 5734'
    assert payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == '3775 272708 87356'

# Generated at 2022-06-23 21:34:18.811727
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=1)
    for _ in range(100):
        result = payment.credit_card_number()
        assert len(result) == 19
        assert type(result) == str


# Generated at 2022-06-23 21:34:20.214842
# Unit test for method cid of class Payment
def test_Payment_cid():
    o = Payment()
    print(o.cid())

# Generated at 2022-06-23 21:34:23.375093
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment(random.Random(), None)
    cid = payment.cid()
    assert isinstance(cid, int)
    assert cid > 999
    assert cid < 9999
    print("Method cid of class Payment: Pass")


# Generated at 2022-06-23 21:34:25.528993
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    out = Payment().credit_card_owner(gender='male')
    assert out['credit_card'] is not None
    assert out['expiration_date'] is not None
    assert out['owner'] is not None


# Generated at 2022-06-23 21:34:29.927041
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment
    payment_yuexi = Payment("zh-CN")
    payment_yuexi.credit_card_owner(Gender.FEMALE)



# Generated at 2022-06-23 21:34:31.405852
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    check = Payment()
    print(check.credit_card_owner())

# Generated at 2022-06-23 21:34:35.237801
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Test for basic functionality
    for i in range(10):
        assert len(Payment().ethereum_address()) == 42
        assert Payment().ethereum_address()[0:2] == "0x"


# Generated at 2022-06-23 21:34:35.821238
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()


# Generated at 2022-06-23 21:34:36.965230
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    pass


# Generated at 2022-06-23 21:34:39.914517
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment('en', seed=1)
    credit_card_network = payment.credit_card_network()
    assert credit_card_network == 'MasterCard'


# Generated at 2022-06-23 21:34:43.113649
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    random_number = random.randint(100, 999)
    print(random_number)
    return random_number



# Generated at 2022-06-23 21:34:53.018841
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    import pprint
    from mimesis.enums import Gender
    p = Payment()
    # Test for male
    random_male = p.credit_card_owner(gender=Gender.MALE)
    male_credit_card = random_male['credit_card']
    male_expiration_date = random_male['expiration_date']
    male_owner = random_male['owner']
    expected_male_owner = p.__person.full_name(gender=Gender.MALE).upper()
    # Test for female
    random_female = p.credit_card_owner(gender=Gender.FEMALE)
    female_credit_card = random_female['credit_card']
    female_expiration_date = random_female['expiration_date']
    female_owner = random_female['owner']
    expected_female

# Generated at 2022-06-23 21:34:54.782686
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert isinstance(payment.cvv(),int)

# Generated at 2022-06-23 21:34:58.175223
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment
    provider = Payment()
    for _ in range(100):
        assert isinstance(provider.cvv(), int)


# Generated at 2022-06-23 21:35:01.480030
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    b = Payment()
    value = b.ethereum_address
    while not isinstance(value, str):
        value = b.ethereum_address
    assert isinstance(value, str)


# Generated at 2022-06-23 21:35:04.884273
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    print('Test method ethereum_address of class Payment')
    test_Payment = Payment()
    print(test_Payment.ethereum_address())

if __name__ == '__main__':
    test_Payment_ethereum_address()

# Generated at 2022-06-23 21:35:10.588447
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Test case for method bitcoin_address of class Payment"""    
    from mimesis.providers.payment import Payment
    from mimesis.enums import CardType, Gender
    from mimesis.enums import Locale
    payment_provider = Payment(seed=0)
    print('bitcoin_address')
    print(payment_provider.bitcoin_address())



# Generated at 2022-06-23 21:35:14.771450
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payload = Payment()
    output = payload.bitcoin_address()
    assert isinstance(output, str)
    assert re.match(r'^[a-z,A-Z,1,3]{34}$', output) == True


# Generated at 2022-06-23 21:35:16.516956
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    assert Payment.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:35:19.723103
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    result = payment.cid()
    assert result == payment.cid()


# Generated at 2022-06-23 21:35:22.928812
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # initialization
    payment = Payment()
    # execution
    paypal = payment.paypal()
    # verification
    assert isinstance(paypal, str)
    print("Payment: ", paypal)

# Generated at 2022-06-23 21:35:24.243223
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    print(p.paypal())

# Generated at 2022-06-23 21:35:28.106913
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment('en')
    expected_result = ["wolf235@gmail.com", "wolf235@gmail.com", "wolf235@gmail.com"]
    for i in range(3):
        result = payment.paypal()
        assert result in expected_result


# Generated at 2022-06-23 21:35:33.329136
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    owner = p.credit_card_owner(gender = Gender.MALE)
    assert len(owner) == 3 and 'credit_card' in owner and 'expiration_date' in owner and 'owner' in owner and isinstance(owner['credit_card'], str) and isinstance(owner['expiration_date'], str) and isinstance(owner['owner'], str) and owner['owner'] == owner['owner'].upper()

# Generated at 2022-06-23 21:35:40.791102
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Unit tests for cid method of Payment class.

    test_pay = Payment()

    # Test #1. Non-stop test
    cid_list = []
    for i in range(100000):
        cid_list.append(test_pay.cid())
    print(f'Non-stop cid test: {len(set(cid_list))} unique cid codes of 100000')

    # Test #2. Seed test
    test_pay = Payment(seed=0)
    cid0 = test_pay.cid()
    test_pay = Payment(seed=1)
    cid1 = test_pay.cid()
    if cid0 != cid1:
        print('cid test #2: passed')
    else:
        print('cid test #2: failed')

    """


# Generated at 2022-06-23 21:35:46.298371
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    owner = payment.credit_card_owner()
    print(owner)
    assert owner['owner'] == 'MARGARET JENKINS'
    assert owner['expiration_date'] == '08/24'
    assert owner['credit_card'] == '5010 3291 5080 8346'

# Generated at 2022-06-23 21:35:54.892413
# Unit test for constructor of class Payment
def test_Payment():
    seed = 0
    payment = Payment(seed=seed)
    assert payment.cid() == 6715
    assert payment.paypal() == 'bloomer.katharine@hotmail.com'
    assert payment.bitcoin_address() == '132RX9Y2VN4Z4NFJLRp7wAq1KYuV7KEkmS'
    assert payment.ethereum_address() == '0x1fdc051feeb8c088a433eebcf0ada2bb8faf6ac0'
    assert payment.credit_card_network() == 'MasterCard'
    assert payment.credit_card_number() == '4003 7892 5653 2497'

# Generated at 2022-06-23 21:35:58.983337
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    Payment1 = Payment()
    for i in range(100):
        Payment_paypal = Payment1.paypal()
        assert type(Payment_paypal) == str
        assert len(Payment_paypal.split("@")) == 2


# Generated at 2022-06-23 21:36:00.774697
# Unit test for method cid of class Payment
def test_Payment_cid():
        payment = Payment(seed=1337)
        assert payment.cid() == 8086


# Generated at 2022-06-23 21:36:04.834852
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Test with random string
    temp = []
    for i in range(100):
        p = Payment()
        result = p.ethereum_address()

        if i == 0:
            print("result = " + result)

        assert len(result) == 42

        temp.append(result[:2])
        temp.append(result[2:])

    assert set(temp) == {'0x'}



# Generated at 2022-06-23 21:36:13.873376
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en', seed=12345)
    for i in range(10):
        card_type = get_random_item(CardType, rnd=payment.random)
        number = payment.credit_card_number(card_type=card_type)
        print(number)
# Output:
# 4552 4000 0911 5207
# 6213 4965 5406 6126
# 3488 5594 9351 6459
# 5158 2730 0115 8740
# 5523 9331 7626 7844
# 3257 0298 1748 2891
# 5185 8293 8295 6170
# 5517 5815 1577 5269
# 4969 6221 7502 3474
# 3447 4080 6310 4935

# Generated at 2022-06-23 21:36:22.606795
# Unit test for constructor of class Payment
def test_Payment():
    from mimesis.enums import CardType
    from mimesis.random import Random

    random = Random()
    payment = Payment(random)
    assert payment.seed == random.seed
    assert payment.random == random
    assert payment.__doc__

    assert payment.cid() > 1000 and payment.cid() < 9999
    assert payment.paypal()
    assert payment.bitcoin_address()
    assert payment.ethereum_address()
    assert payment.credit_card_network()
    assert payment.credit_card_number(CardType.VISA)
    assert payment.credit_card_expiration_date(16, 25)
    assert payment.cvv() > 100 and payment.cvv() < 999
    assert payment.credit_card_owner()

# Generated at 2022-06-23 21:36:24.437552
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment('en', seed=0)
    assert payment.cid() == 7452


# Generated at 2022-06-23 21:36:27.955579
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    try:
        P=Payment()
        P.credit_card_network()
        return True
    except:
        return False

#Unit test for method credit_card_number of class Payment

# Generated at 2022-06-23 21:36:32.501852
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    P = Payment('en')
    CCN = P.credit_card_network()
    if not(CCN in ("Visa", "MasterCard", "American Express", "Diners Club", "Discover", "JCB", "Dankort")):
        print("CCN:", CCN)
        print("Error: credit_card_network does not work.")
        exit(1)



# Generated at 2022-06-23 21:36:34.716032
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    x = p.cid()
    assert isinstance(x,int)


# Generated at 2022-06-23 21:36:43.335782
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    from mimesis.providers.payment import Payment
    from mimesis.enums import CardType

    token_example = ['1', '3', '5', 'n', '2']
    payment = Payment(seed=5)
    # bitcoin_address
    assert payment.bitcoin_address() == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'
    # ethereum_address
    assert payment.ethereum_address() == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'
    # credit_card_number
    assert payment.credit_card_number(card_type=CardType.VISA) == '4820 0871 5302 6395'
    assert payment.credit_card_number

# Generated at 2022-06-23 21:36:53.735476
# Unit test for constructor of class Payment
def test_Payment():
    """Test for constructor of class Payment"""
    from mimesis.providers.payment import Payment
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import CardType
    payment1 = Payment()
    payment2 = Payment(seed=12345)
    assert payment1.cvv() != payment2.cvv()
    assert payment1.paypal() != payment2.paypal()
    assert payment1.ethereum_address() != payment2.ethereum_address()
    assert payment1.credit_card_expiration_date() != payment2.credit_card_expiration_date()
    assert payment1.credit_card_network() != payment2.credit_card_network()
    assert payment1.bitcoin_address() != payment2.bitcoin_address()
    assert payment1.credit_card_

# Generated at 2022-06-23 21:36:55.322024
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    assert len(p.paypal()) == len('example@gmail.com')


# Generated at 2022-06-23 21:36:56.735960
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    date = payment.credit_card_expiration_date(18,20)
    print(date)

# Generated at 2022-06-23 21:36:59.359667
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment(seed=123)
    owner = payment.credit_card_owner()
    print (owner)


# Generated at 2022-06-23 21:37:01.506563
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    a = p.paypal()
    b = p.paypal()
    assert(a != b)


# Generated at 2022-06-23 21:37:03.354209
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    print(p.bitcoin_address())


# Generated at 2022-06-23 21:37:04.609537
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment('zh')
    assert p.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:37:07.607329
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    cvv_value = Payment().cvv()

    assert isinstance(cvv_value, int)
    assert len(str(cvv_value)) == 3 # Comprobamos que tenga tres dígitos


# Generated at 2022-06-23 21:37:08.679601
# Unit test for method cid of class Payment
def test_Payment_cid():
	pay = Payment()
	cid = pay.cid()
	print(cid)


# Generated at 2022-06-23 21:37:10.406737
# Unit test for method cid of class Payment
def test_Payment_cid():
    x = Payment(seed=1)
    assert x.cid() == 7452


# Generated at 2022-06-23 21:37:14.409694
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner()
    assert len(owner['credit_card']) == 16
    assert len(owner['expiration_date']) == 5

# Generated at 2022-06-23 21:37:16.209293
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    obj = Payment()
    length = len(obj.paypal())
    assert length >= 6

# Generated at 2022-06-23 21:37:19.208522
# Unit test for method paypal of class Payment
def test_Payment_paypal():
	p = Payment()
	paypal = p.paypal()
	assert re.search(r"\w+@\w+\.\w{2,4}",paypal)


# Generated at 2022-06-23 21:37:22.758439
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment("en")
    print("\nTesting: method cid of class Payment")
    for i in range(10):
        print("{0}:{1}".format(i, payment.cid()))


# Generated at 2022-06-23 21:37:24.991406
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    print("test")
    print(payment.credit_card_owner())
    print("test")

# Generated at 2022-06-23 21:37:27.082680
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Sample = Payment()
    assert len(Sample.credit_card_number()) == 16


# Generated at 2022-06-23 21:37:33.136928
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """Unit test for method paypal of class Payment"""

    paymt = Payment('en', seed=1)
    assert paymt.paypal() == 'rjames@hotmail.com'

    paymt = Payment('en', seed=1)
    assert paymt.paypal() == 'rjames@hotmail.com'

    paymt = Payment('en', seed=1)
    assert paymt.paypal() == 'rjames@hotmail.com'



# Generated at 2022-06-23 21:37:35.295689
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Initialize
    payment = Payment()

    # Generate
    first = payment.paypal()
    second = payment.paypal()

    # Assert
    assert first != second


# Generated at 2022-06-23 21:37:37.842973
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment('en')
    card = payment.credit_card_network()
    assert isinstance(card, str)
    assert card=='MasterCard'


# Generated at 2022-06-23 21:37:38.923079
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert payment.cvv() < 1000 and payment.cvv() >= 100


# Generated at 2022-06-23 21:37:46.824584
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""

    import unittest
    from mimesis.enums import CardType
    from mimesis.exceptions import NonEnumerableError

    class PaymentTestCase(unittest.TestCase):
        """Test case for class Payment"""

        def setUp(self):
            """Set up Paymen class for unit tests."""
            self.payment = Payment('en')

        def test_credit_card_number(self):
            """Testing method credit_card_number."""
            result = self.payment.credit_card_number(CardType.VISA)
            self.assertTrue(re.match(r'\d{4} \d{4} \d{4} \d{4}', result))


# Generated at 2022-06-23 21:37:50.194048
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    # All variables for Person class
    for i in range(1):
        p = Payment('en')
        print('credit_card_network:' + str(p.credit_card_network()))


# Generated at 2022-06-23 21:37:52.770657
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Create a Payment object and check his method ethereum_address
    provider = Payment()
    assert len(provider.ethereum_address()) == 42


# Generated at 2022-06-23 21:37:55.753861
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Preparation
    p = Payment()
    # Action
    result = p.paypal()
    # Verification
    assert len(result) >= 7 # Paypal account is in fact an email


# Generated at 2022-06-23 21:38:02.206055
# Unit test for constructor of class Payment
def test_Payment():
    # Test author and version in the __init__ file
    test = Payment(seed=42)

    assert test._Payment__person.author == 'Dmitriy Beliaev'
    assert test._Payment__person.version == '0.3.3'

    assert test.__doc__ is not None and test.__doc__ is not ""

# Generated at 2022-06-23 21:38:03.889966
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    payment.credit_card_owner()
    assert payment.credit_card_owner() is not None

# Generated at 2022-06-23 21:38:13.063348
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Test for Ethereum address for 100 times.
    for _ in range(100):
        assert len(Payment().ethereum_address()) == 42
        assert len(Payment(seed=1).ethereum_address()) == 42

    # Test for Ethereum address on different seeds.
    assert Payment(seed=1).ethereum_address() == '0x5f5e100701000033f29b7d9a0e80191320ccd14b'
    assert Payment(seed=2).ethereum_address() == '0x5f5e100701000033f29b7d9a0e80191320ccd14b'

    # Test for Ethereum address with custom seed.

# Generated at 2022-06-23 21:38:16.485296
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p1 = Payment()
    p2 = Payment()
    assert p1.credit_card_number() == p2.credit_card_number()

test_Payment_credit_card_number()


# Generated at 2022-06-23 21:38:21.294218
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    Pay = Payment()
    assert isinstance(Pay.bitcoin_address(), str)
    assert Pay.bitcoin_address()[0] in ('1', '3')
    assert len(Pay.bitcoin_address()) == 34
    assert re.match('^(1|3)\w{33}$', Pay.bitcoin_address())


# Generated at 2022-06-23 21:38:23.807170
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    i = p.cid()
    if assert_test(type(i),int):
        print("test_Payment_cid has passed")
        return True
    return False


# Generated at 2022-06-23 21:38:24.626372
# Unit test for constructor of class Payment
def test_Payment():
    Payment()


# Generated at 2022-06-23 21:38:27.368367
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment('en')
    result = payment.cid()
    assert isinstance(result, int) and len(str(result)) == 4


# Generated at 2022-06-23 21:38:35.408924
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    c1 = Payment()
    for i in range(1, 1000):
        # test for random month and random year
        date = c1.credit_card_expiration_date()
        # Expected value is between 01/16 and 12/25
        assert 16 < int(date[3:]) < 25
        assert 1 < int(date[0:2]) < 12
        # test for random month and random year
        date = c1.credit_card_expiration_date()
        # Expected value is between 01/16 and 12/25
        assert 16 < int(date[3:]) < 25
        assert 1 < int(date[0:2]) < 12


# Generated at 2022-06-23 21:38:39.242498
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    lst = []
    count = 0
    while count < 10000:
        lst.append(Payment().cvv())
        count += 1
    print(lst)

if __name__ == "__main__":
    test_Payment_cvv()

# Generated at 2022-06-23 21:38:41.041512
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date(2020, 2023) == '08/23'

# Generated at 2022-06-23 21:38:44.511086
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Test method cvv of class Payment"""
    from mimesis.enums import Gender

    payment = Payment()
    assert isinstance(payment.cvv(),int)
    assert(payment.cvv()) < 999
    assert(payment.cvv()) > 100


# Generated at 2022-06-23 21:38:50.419633
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment('en')
    a = payment.ethereum_address()
    assert len(a) == 42, "a length is not 42"
    assert a[0:2] == '0x', "a not started with 0x"
    assert int(a, 16) != None, "a can not be converted to int"


# Generated at 2022-06-23 21:38:54.140476
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """ Unitest for method ethereum_address of class Payment """
    payment = Payment()
    address = payment.ethereum_address()
    assert isinstance(address, str)

# Generated at 2022-06-23 21:38:56.407525
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment('en')
    r = p.credit_card_network()
    assert r in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:39:00.137480
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    _list = list()
    for _ in range(0, 100):
        tested = Payment(random=Random())
        _list.append(tested.credit_card_network())
        assert tested.credit_card_network() in CREDIT_CARD_NETWORKS
    assert len(set(_list)) > 50


# Generated at 2022-06-23 21:39:01.905219
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc = Payment(seed = 42)
    card = cc.credit_card_number()
    assert card == "4455 5299 1152 2450"

# Generated at 2022-06-23 21:39:05.692519
# Unit test for constructor of class Payment
def test_Payment():
    payment1 = Payment()
    payment2 = Payment()
    assert(payment1.bitcoin_address() == payment2.bitcoin_address())

# Generated at 2022-06-23 21:39:07.208700
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    assert p.cvv() >= 100
    assert p.cvv() <= 999

# Generated at 2022-06-23 21:39:09.758781
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    result = Payment().credit_card_number()
    assert isinstance(result, str)
    assert len(result.replace(' ', '')) == 16


# Generated at 2022-06-23 21:39:13.178541
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()

    print("\nTesting method ethereum_address of class Payment")
    print("\tEthereum address is: %s" % (payment.ethereum_address()))

# Generated at 2022-06-23 21:39:16.442132
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    try:
        payment = Payment()
        cvv = payment.cvv()
        if cvv < 100 or cvv > 999:
            assert False
        else:
            assert True
    except:
        assert False

# Generated at 2022-06-23 21:39:18.133696
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    data= Payment()
    result=data.credit_card_owner()
    print(result)

# Generated at 2022-06-23 21:39:20.004883
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment('en')
    assert payment.paypal() == 'r.dominguez@gmail.com'

# Generated at 2022-06-23 21:39:21.915826
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    provider = Payment()
    assert len(provider.bitcoin_address()) == 34


# Generated at 2022-06-23 21:39:23.264512
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Test case for method ethereum_address"""
    payment = Payment('en')
    # print(payment.ethereum_address())
    

# Generated at 2022-06-23 21:39:25.065285
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Test bitcoin_address of class Payment"""
    payment = Payment()
    print(payment.bitcoin_address())


# Generated at 2022-06-23 21:39:27.722156
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    assert isinstance(payment.credit_card_owner(),dict)
test_Payment_credit_card_owner()


# Generated at 2022-06-23 21:39:37.715849
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    from mimesis.enums import Gender
    from mimesis.enums import CardType
    from mimesis.enums import CardType
    a = Payment('tr')
    assert a.paypal()
    assert a.paypal()
    assert a.paypal()
    assert a.paypal()
    assert a.bitcoin_address()
    assert a.bitcoin_address()
    assert a.bitcoin_address()
    assert a.bitcoin_address()
    assert a.ethereum_address()
    assert a.ethereum_address()
    assert a.ethereum_address()
    assert a.ethereum_address()
    assert a.credit_card_network()
    assert a.credit_card_network()
    assert a.credit_card_network()
    assert a.credit_card_network()


# Generated at 2022-06-23 21:39:39.385334
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert 'Payment' == p.__class__.__name__



# Generated at 2022-06-23 21:39:43.465958
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(5000):
        owner_credit_card = Payment().credit_card_number()
        str_owner_credit_card = owner_credit_card.replace(" ", "")
        print(str_owner_credit_card)
        assert (len(str_owner_credit_card) == 16)


# Generated at 2022-06-23 21:39:45.555331
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    ccn = 0
    try:
        ccn = p.credit_card_number()
    except Exception:
        assert False
    assert ccn is not None

# Generated at 2022-06-23 21:39:48.536829
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    seed = 1
    provider = Payment(seed=seed)
    cvv1 = provider.cvv()
    provider.reset_seed(seed)
    cvv2 = provider.cvv()
    assert cvv1 == cvv2


# Generated at 2022-06-23 21:39:52.965534
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p.cid() == p.cid()
    assert p.paypal() != p.paypal()
    assert p.bitcoin_address() != p.bitcoin_address()
    assert p.ethereum_address() != p.ethereum_address()
    assert p.credit_card_network() in CREDIT_CARD_NETWORKS
    assert p.credit_card_number() != p.credit_card_number()
    assert p.credit_card_expiration_date() != p.credit_card_expiration_date()
    assert p.cvv() == p.cvv()

# Generated at 2022-06-23 21:40:02.637739
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment(seed=123)
    # credit_card: 4455 5299 1152 2450,expiration_date: 07/18,owner: JAMES MCDANIEL
    assert payment.credit_card_owner() == {"credit_card": "4455 5299 1152 2450", "expiration_date": "07/18", "owner": "JAMES MCDANIEL"}
    # credit_card: 3522 5132 7896 8500,expiration_date: 11/21,owner: RANDALL DEAN
    assert payment.credit_card_owner() == {"credit_card": "3522 5132 7896 8500", "expiration_date": "11/21", "owner": "RANDALL DEAN"}
    # credit_card: 4286 5183 9102 6240,expiration_date: 06/18,owner: MRS

# Generated at 2022-06-23 21:40:04.988214
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    text = payment.cvv()
    assert bool(text)


# Generated at 2022-06-23 21:40:15.597457
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    # Test cvv
    cvv = payment.cvv()
    assert type(cvv) == int
    # Test credit_card_expiration_date
    cvv = payment.credit_card_expiration_date()
    assert type(cvv) == str
    # Test credit_card_number
    cvv = payment.credit_card_number()
    assert type(cvv) == str
    # Test paypal
    cvv = payment.paypal()
    assert type(cvv) == str
    # Test bitcoin_address
    cvv = payment.bitcoin_address()
    assert type(cvv) == str
    # Test ethereum_address
    cvv = payment.ethereum_address()
    assert type(cvv) == str
    # Test credit_card_network
    cvv

# Generated at 2022-06-23 21:40:23.191744
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    expected_pattern_visa = re.compile("^[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}$")
    expected_pattern_american_express = re.compile("^[0-9]{4} [0-9]{6} [0-9]{5}$")
    expected_pattern_master_card = re.compile("^[0-9]{4} [0-9]{4} [0-9]{4} [0-9]{4}$")
    payment = Payment()
    visa_result = payment.credit_card_number(CardType.VISA)
    american_express_result = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    master_card