

# Generated at 2022-06-23 21:30:15.307861
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p is not None



# Generated at 2022-06-23 21:30:17.582109
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert payment.cid() in range(1000, 9999 + 1)



# Generated at 2022-06-23 21:30:22.661544
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    '''
    Test for method credit_card_expiration_date of class Payment
    :return:
    '''

    payment = Payment(seed=14)
    result = payment.credit_card_expiration_date(minimum=12, maximum=18)

    assert result == '03/15'

# Generated at 2022-06-23 21:30:26.542272
# Unit test for method cid of class Payment
def test_Payment_cid(): 
	p = Payment()
	arr = []
	for i in range(1, 1000 , 1):
		cid = p.cid()
		arr.append(p.cid())
	for i in range(1, 1000 , 1):
		assert arr[i] > 999 and arr[i] < 10000


# Generated at 2022-06-23 21:30:31.301762
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number().startswith("4")
    assert payment.credit_card_number(CardType.MASTER_CARD).startswith("51")
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS).startswith("37")


# Generated at 2022-06-23 21:30:36.119983
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    x = Payment()
    num = x.cvv()
    assert (len(str(num)) == 3)
    assert(num < 1000)
    assert(num > 99)


# Generated at 2022-06-23 21:30:37.232334
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    random_date = Payment().credit_card_expiration_date()
    assert random_date[2:] == "/20"

# Generated at 2022-06-23 21:30:41.619278
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    eth_addr_regex = re.compile(r'^[13][a-km-zA-HJ-NP-Z1-9]{33}$')
    for i in range(100):
        if not eth_addr_regex.match(Payment().bitcoin_address()):
            return False
    return True


# Generated at 2022-06-23 21:30:43.806345
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    payment.credit_card_network()



# Generated at 2022-06-23 21:30:46.815528
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    x = Payment()
    x.seed(460)
    assert x.cvv() == 759
test_Payment_cvv()


# Generated at 2022-06-23 21:30:50.623544
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    test_object = Payment()
    test_object.random.seed(4)
    assert test_object.bitcoin_address() == "1PMycacnJaSqwwJqjawXBErnLsZ7RkXUAs"


# Generated at 2022-06-23 21:30:51.555205
# Unit test for constructor of class Payment
def test_Payment():
    ip = Payment()
    assert isi

# Generated at 2022-06-23 21:30:54.049139
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    print(payment.cvv())
    print(payment.credit_card_number())

# Invoke the test function
test_Payment()

# Generated at 2022-06-23 21:30:59.142054
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # Create an instance of Payment
    payment = Payment('en')
    # Set a seed for PRNG
    payment.seed(42)
    # Generate a bitcoin address
    print(payment.bitcoin_address())

if __name__ == '__main__':
    test_Payment_bitcoin_address()

# Generated at 2022-06-23 21:31:00.539399
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    p.ethereum_address()


# Generated at 2022-06-23 21:31:02.937770
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert re.match(r'\d{2}\/\d{2}', Payment().credit_card_expiration_date()) is not None

# Generated at 2022-06-23 21:31:08.263538
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    cid = p.cid()
    assert 1 <= cid and cid <= 9999
    paypal = p.paypal()
    assert re.match(r'\w{8,9,10}@\w{1,20}.com', paypal)
    btc_address = p.bitcoin_address()
    assert re.match(
        r'[13][a-km-zA-HJ-NP-Z1-9]{33}', btc_address)
    eth_address = p.ethereum_address()
    assert re.match(
        r'0x[a-fA-F0-9]{40}', eth_address)
    network = p.credit_card_network()
    assert network in CREDIT_CARD_NETWORKS
    ccn1

# Generated at 2022-06-23 21:31:10.998060
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment(seed=4)
    assert payment.cid() == 1030


# Generated at 2022-06-23 21:31:17.320817
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    provider = Payment()
    # is_ethereum_address = re.compile(r'^0x[a-fA-F0-9]{40}$')
    is_ethereum_address = re.compile(r'^0x[0-9a-fA-F]{40}$')
    address = provider.ethereum_address()
    assert is_ethereum_address.match(address), "This string "+address+" is not a valid Ethereum address!"
    print(address)

# Generated at 2022-06-23 21:31:18.906567
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    assert Payment().credit_card_owner().get('owner') != None

# Generated at 2022-06-23 21:31:21.536337
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # create instance of class Payment
    payment = Payment()
    # test random value of credit card expiration date
    assert payment.credit_card_expiration_date()

# Generated at 2022-06-23 21:31:28.224859
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    num1=Payment()
    num2=Payment()
    num3=Payment()
    num4=Payment()
    num5=Payment()
    num6=Payment()
    num7=Payment()
    num8=Payment()
    num9=Payment()
    num10=Payment()
    list1 = [num1.cvv(),num2.cvv(),num3.cvv(),num4.cvv(),num5.cvv(),num6.cvv(),num7.cvv(),num8.cvv(),num9.cvv(),num10.cvv()]
    for i in list1:
        assert i > 99 and i <1000

# Generated at 2022-06-23 21:31:31.095871
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment('en')
    value1 = payment.cvv()
    value2 = payment.cvv()
    assert value2 != value1
    # print(value)

# Generated at 2022-06-23 21:31:35.389845
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert len(payment.ethereum_address()) == 42
    assert payment.ethereum_address()[0] == '0'
    assert payment.ethereum_address()[1] == 'x'


# Generated at 2022-06-23 21:31:36.846438
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert Payment().credit_card_expiration_date()


# Generated at 2022-06-23 21:31:41.079067
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner(Gender.MALE)
    assert owner['credit_card'] != ""
    assert owner['expiration_date'] != ""
    assert owner['owner'] != ""

# Generated at 2022-06-23 21:31:42.562141
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    print(payment.cid())


# Generated at 2022-06-23 21:31:47.571611
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    a = Payment()
    bit_address = a.bitcoin_address()
    assert isinstance(bit_address, str)
    assert len(bit_address) == 34
    assert bit_address[0] in ['1', '3']
    for i in bit_address[1:]:
        assert i in string.ascii_letters + string.digits


# Generated at 2022-06-23 21:31:53.620595
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    provider = Payment()
    #eth_address = provider.ethereum_address()
    eth_address = provider.bitcoin_address()
    print(eth_address)
    assert isinstance(eth_address, str)
    assert re.match('[0-9a-zA-Z]{35}', eth_address) is not None

if __name__ == '__main__':
    test_Payment_ethereum_address()

# Generated at 2022-06-23 21:32:03.477303
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import pytest
    my_seed = 12345
    my_payment = Payment(my_seed)
    assert my_payment.credit_card_number() == '4455 5299 1152 2450'
    assert my_payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 00202 71555'
    assert my_payment.credit_card_number(CardType.MASTER_CARD) == '2209 8700 12499 624'
    with pytest.raises(NonEnumerableError) as e_info:
        my_payment.credit_card_number(CardType.DINERS_CLUB)


# Generated at 2022-06-23 21:32:07.263322
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    seed_ = 496
    x = Payment(seed=seed_)
    assert  x.credit_card_owner(Gender.MALE) == {'credit_card': '5528 5956 6848 6126', 'expiration_date': '02/22', 'owner': 'JOHN PARKER'}


# Generated at 2022-06-23 21:32:12.298958
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card_number = p.credit_card_number()
    assert card_number[0] == '4'
    assert p.random.randint(4000, 4999) <= int(card_number[:4])
    assert int(card_number[12:]) < 10

# Generated at 2022-06-23 21:32:16.509715
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    for i in range(10):
        x = Payment()
        cc_cvv = x.cvv()
        assert 1 <= cc_cvv <= 999
        print(cc_cvv)


# Generated at 2022-06-23 21:32:26.288835
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    print("\nTesting method Payment.credit_card_owner()...\n")
    p = Payment("en", seed = 1)
    print("This is the first testing: " + "-" * 50)
    print("Credit card number: " + p.credit_card_owner()["credit_card"])
    print("Expiration date: " + p.credit_card_owner()["expiration_date"])
    print("Owner: " + p.credit_card_owner()["owner"])
    print("This is the second testing: " + "-" * 50)
    print("Credit card number: " + p.credit_card_owner()["credit_card"])
    print("Expiration date: " + p.credit_card_owner()["expiration_date"])

# Generated at 2022-06-23 21:32:27.107816
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    print(payment.cvv())

# Generated at 2022-06-23 21:32:29.554428
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    ccard = Payment()
    assert ccard.credit_card_expiration_date() == "01/24"

# Generated at 2022-06-23 21:32:33.338475
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    card = ['Discover', 'Visa', 'JCB', 'MasterCard', 'Diners Club', 'Maestro', 'American Express']
    assert payment.credit_card_network() in card



# Generated at 2022-06-23 21:32:34.604926
# Unit test for constructor of class Payment
def test_Payment():
    obj = Payment()
    print(obj)


# Generated at 2022-06-23 21:32:36.396998
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    payment.credit_card_owner()


# Generated at 2022-06-23 21:32:38.066110
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    print(Payment().bitcoin_address())


# Generated at 2022-06-23 21:32:42.189710
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():

    payment = Payment(seed=123)

    assert payment.credit_card_expiration_date(minimum=14, maximum=18) == "02/18"

    assert payment.credit_card_expiration_date(minimum=17, maximum=20) == "09/18"


# Generated at 2022-06-23 21:32:49.498581
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from unittest import TestCase
    from mimesis.specifiers import DatetimeSpecifier
    from mimesis.enums import Gender
    import datetime
    import unittest
    class Test_credit_card_expiration_date(TestCase):
        def setUp(self):
            self.payment = Payment('en')
            self.payment_date = DatetimeSpecifier('en')
            self.payment.seed(10)
            self.payment_date.seed(10)

        def test_Payment_credit_card_expiration_date(self):
            date = self.payment_date.date()
            year = datetime.datetime.strptime(str(date), "%Y-%m-%d").year

# Generated at 2022-06-23 21:32:51.738483
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment('en')
    r = payment.cid()
    print(r)
    assert len(str(r)) == 4


# Generated at 2022-06-23 21:32:53.373284
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    test_obj = Payment()
    assert isinstance(test_obj.credit_card_network(), str)


# Generated at 2022-06-23 21:32:57.078048
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card = payment.credit_card_number(card_type=CardType.VISA)
    assert card[:1] == '4'
    assert len(card) == 19
    assert len(card.split()) == 4


# Generated at 2022-06-23 21:33:00.314954
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    for i in range(10):
        credit_card_network = Payment('en').credit_card_network()
        assert credit_card_network in CREDIT_CARD_NETWORKS



# Generated at 2022-06-23 21:33:04.699308
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # create an instance of Payment class
    test_instance = Payment()
    # call bitcoin_address() method
    bitcoin_address = test_instance.bitcoin_address()
    # verify the result of call
    assert bitcoin_address != None, 'test_Payment_bitcoin_address(): method bitcoin_address() of class Payment return None'
    assert len(bitcoin_address) > 0, 'test_Payment_bitcoin_address(): method bitcoin_address() of class Payment return empty string'

# Generated at 2022-06-23 21:33:06.908385
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    PaymentSeed = Payment(seed=1234)
    assert PaymentSeed.paypal() == 'carter_kelley@hotmail.com'


# Generated at 2022-06-23 21:33:07.610079
# Unit test for constructor of class Payment
def test_Payment():
    assert Payment()

# Generated at 2022-06-23 21:33:09.051638
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    a = payment.credit_card_expiration_date()
    assert len(a) == 5


# Generated at 2022-06-23 21:33:11.972117
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert Payment().bitcoin_address() == "3QkpiN8rJbYrEuVhdDs31KwfkdJWKuFzgv"


# Generated at 2022-06-23 21:33:13.506507
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    assert isinstance(p.cid(), int)

# Generated at 2022-06-23 21:33:24.231937
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    For testing the methoed credit_card_number of class Payment,
    First we will generate a list of 500 credit card numbers of type Visa using the method
    credit_card_number of class Payment,
    Then we will check if the length of the card number is 16 and the first two digits of the
    credit card number is between 4000 to 4999 and if it is a valid luhn number by calling the
    internal method luhn_checksum of class Payment,
    We will do the same for the rest of the credit cards,
    And if the above conditions are all true, then the test will pass,
    Otherwise it will fail.
    """
    Pay = Payment()
    visa_cards = []
    master_cards = []
    american_cards = []
    # Generate 500 Visa cards
    for num in range(500):
        visa

# Generated at 2022-06-23 21:33:26.461417
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    var = "0xe8ece9e6ff7dba52d4c07d37418036a89af9698d"
    print("The ethereum address function of class Payment is:",Payment().ethereum_address())
    assert Payment().ethereum_address() == var


# Generated at 2022-06-23 21:33:28.828602
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    payment.cid()


# Generated at 2022-06-23 21:33:33.100974
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """Test method paypal of class Payment."""
    payment = Payment('en', seed=12345)
    assert payment.paypal() == 'wolf235@gmail.com'
    assert payment.paypal() == 'wolf235@gmail.com'


# Generated at 2022-06-23 21:33:41.910058
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(seed=None)

    assert len(p.credit_card_number()) == 19

# Generated at 2022-06-23 21:33:45.770765
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert len(Payment().cvv()) == 3
    assert len(Payment('en').cvv()) == 3
    assert isinstance(Payment().cvv(), int)
    assert Payment('ru').cvv() in range(100, 999)
    assert Payment('ru').cvv() in range(100, 999)

# Generated at 2022-06-23 21:33:51.015719
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    print(payment.cid())
    print(payment.paypal())
    print(payment.bitcoin_address())
    print(payment.ethereum_address())
    print(payment.credit_card_network())
    print(payment.credit_card_number())
    print(payment.credit_card_expiration_date())
    print(payment.cvv())
    print(payment.credit_card_owner())

if __name__ == "__main__":
    test_Payment()

# Generated at 2022-06-23 21:33:53.090579
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p.__class__.__name__ == "Payment"


# Generated at 2022-06-23 21:33:55.223693
# Unit test for method cid of class Payment
def test_Payment_cid():
    for _ in range(100):
        assert len(str(Payment().cid())) == 4


# Generated at 2022-06-23 21:33:56.322307
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    print(payment.ethereum_address())

# Generated at 2022-06-23 21:33:57.703153
# Unit test for constructor of class Payment
def test_Payment():
    payment_class = Payment()
    assert isinstance(payment_class, Payment)


# Generated at 2022-06-23 21:34:06.536795
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # Testing method cvv of class Payment
    from mimesis.builtins import Payment
    payment = Payment()
    assert payment.cvv() == payment.cvv()
    assert payment.cvv() == payment.cvv()
    assert payment.cvv() == payment.cvv()
    assert payment.cvv() == payment.cvv()
    assert payment.cvv() == payment.cvv()
    assert payment.cvv() == payment.cvv()
    assert payment.cvv() == payment.cvv()



# Generated at 2022-06-23 21:34:08.319112
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment('en')
    minimum = 16
    maximum = 25
    result = payment.credit_card_expiration_date(minimum, maximum)
    print(result)


# Generated at 2022-06-23 21:34:09.554064
# Unit test for method cid of class Payment
def test_Payment_cid():
    provider = Payment(seed=0)
    actual = provider.cid()
    expected = 7452
    assert actual == expected


# Generated at 2022-06-23 21:34:10.756535
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:34:15.798298
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment(seed=123)
    assert payment.credit_card_expiration_date() == '10/19'
    assert payment.credit_card_expiration_date(10) == '08/14'
    assert payment.credit_card_expiration_date(10, 15) == '05/13'
    assert payment.credit_card_expiration_date(14, 15) == '07/14'


# Generated at 2022-06-23 21:34:17.131618
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    Payment = Payment()
    assert type(Payment.cvv()) == int

# Generated at 2022-06-23 21:34:20.747432
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    paypal_account = p.paypal()
    assert isinstance(paypal_account, str)
    assert len(paypal_account) >= 9
    assert paypal_account.count('@') == 1


# Generated at 2022-06-23 21:34:22.778286
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    p = Payment('en')
    ccn = p.credit_card_number()
    assert ccn == '4455 5299 1152 2450'

# Generated at 2022-06-23 21:34:23.896397
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    x = Payment()
    print(x.paypal())


# Generated at 2022-06-23 21:34:24.894526
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment is not None


# Generated at 2022-06-23 21:34:36.872120
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Unit test that uses method bitcoin_address from class Payment to
    check if a string of the correct format is being returned.
    """
    import re
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment
    payment = Payment("en")

    # Test for a bitcoin address
    test_address = payment.bitcoin_address()
    assert len(test_address)==34

    # Test that the address begins with a "1" or a "3"
    assert test_address[0] in ("1","3")

    # Test that the rest of the address is alphanumeric
    test_address_rest = test_address[1:]
    assert (re.match("[a-zA-Z0-9]{33}", test_address_rest) is not None)



# Generated at 2022-06-23 21:34:38.657006
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    assert len(payment.bitcoin_address()) == 34



# Generated at 2022-06-23 21:34:44.306635
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment.credit_card_number()
    payment.credit_card_number(card_type='Visa')
    payment.credit_card_number(card_type='Master Card')
    payment.credit_card_number(card_type='American Express')


# Generated at 2022-06-23 21:34:46.527045
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert re.match(r'.*\@.*\..+', payment.paypal())



# Generated at 2022-06-23 21:34:49.436913
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    print(p.ethereum_address())

if __name__ == "__main__":

    test_Payment_ethereum_address()

# Generated at 2022-06-23 21:34:51.693827
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    assert type(p.ethereum_address()) is str

# Generated at 2022-06-23 21:34:55.627695
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    random_payment = Payment(seed=123)
    assert random_payment.ethereum_address() == "0x4DcfB2c9b9Cf701d475E0a856AaAe0c0F2Dd2A21"

# Generated at 2022-06-23 21:35:00.935425
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment("en")
    res = payment.bitcoin_address()
    assert len(res) == 34
    assert re.match(r'^1+[a-zA-Z0-9]+$', res) != None or re.match(r'^3+[a-zA-Z0-9]+$', res) != None


# Generated at 2022-06-23 21:35:02.701933
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    providers = Payment()
    print(providers.paypal() + "\n")


# Generated at 2022-06-23 21:35:04.571311
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    print(payment.cid())

test_Payment_cid()


# Generated at 2022-06-23 21:35:09.225239
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date(
        minimum=18,
        maximum=24) in [
            '08/19, 08/20',
            '05/18, 11/19',
            '10/24',
            '11/18'
        ]


# Generated at 2022-06-23 21:35:16.885988
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    Test credit_card_number()
    """
    payment = Payment(seed=123456)
    assert payment.credit_card_number(card_type=CardType.VISA) == "4015 7226 8670 1089"
    assert payment.credit_card_number(card_type=CardType.MASTER_CARD) == "5232 2580 5861 9235"
    assert payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == "3410 218848 08189"


# Generated at 2022-06-23 21:35:19.244931
# Unit test for method cid of class Payment
def test_Payment_cid():
    Payment().cid()


# Generated at 2022-06-23 21:35:20.368505
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    print(Payment().paypal())

# Generated at 2022-06-23 21:35:28.977162
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc = Payment()
    assert cc.credit_card_number() == '4569 3182 3802 3439'
    assert cc.credit_card_number() == '5160 4591 1018 9086'
    assert cc.credit_card_number() == '5365 0943 9746 5676'
    assert cc.credit_card_number() == '5200 4313 0642 8088'
    assert cc.credit_card_number() == '5485 6644 9113 6632'
    assert cc.credit_card_number() == '4712 6448 3405 9227'
    assert cc.credit_card_number() == '4169 8990 1608 7549'

# Generated at 2022-06-23 21:35:37.796317
# Unit test for constructor of class Payment
def test_Payment():
    assert Payment().paypal() == 'thomas26@gmail.com'
    assert Payment()
    assert isinstance(Payment().cid(), int)
    assert isinstance(Payment().bitcoin_address(), str)
    assert isinstance(Payment().ethereum_address(), str)
    assert isinstance(Payment().credit_card_network(), str)
    assert isinstance(Payment().credit_card_number(CardType.VISA), str)
    assert isinstance(Payment().credit_card_expiration_date(), str)
    assert isinstance(Payment().cvv(), int)
    assert isinstance(Payment().credit_card_owner(Gender.MALE), dict)


# Generated at 2022-06-23 21:35:40.207317
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # test for valid inputs
    date = Payment().credit_card_expiration_date(20, 30)
    assert type(date) is str
    assert int(date[3:]) >= 20 and int(date[3:]) <= 30


# Generated at 2022-06-23 21:35:42.100651
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cvv = payment.cvv()
    assert isinstance(cvv, int)
    assert cvv > 100 and cvv < 999

# Generated at 2022-06-23 21:35:43.141427
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    m = Payment()
    print(m.credit_card_network())


# Generated at 2022-06-23 21:35:48.049302
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    for _ in range(100):
        pattern = re.compile(r'[a-zA-Z0-9]+@[a-zA-Z0-9]+\.com')
        assert pattern.match(Payment().paypal()) != None


# Generated at 2022-06-23 21:35:54.675131
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    p = Payment('en')
    card = p.credit_card_number(CardType.VISA)
    assert (len(card) == 19)
    assert (str(card).startswith('4'))
    assert (str(card)[4] in ' -')
    card = p.credit_card_number(CardType.MASTER_CARD)
    assert (len(card) == 19)
    assert (str(card).startswith('5'))
    assert (str(card)[4] in ' -')
    card = p.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert (len(card) == 18)
    assert (str(card).startswith('3'))

# Generated at 2022-06-23 21:35:58.742298
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Arrange
    payment = Payment()

    # Act
    ethereum_address = payment.ethereum_address()

    # Assert
    assert len(ethereum_address) == 42
    assert ethereum_address[:3] == '0x'

# Generated at 2022-06-23 21:36:03.932320
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Assert function return value equals expected value
    assert re.match(
        r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$',
        Payment().paypal()
    )


# Generated at 2022-06-23 21:36:06.282710
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert 90 <= Payment().cvv() <= 999


# Generated at 2022-06-23 21:36:08.361171
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    paymentobj = Payment(seed=1134)
    result = paymentobj.bitcoin_address()
    print(result)

# Generated at 2022-06-23 21:36:10.100516
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    result = p.credit_card_network()
    print(result)
    assert isinstance(result, str)


# Generated at 2022-06-23 21:36:12.232730
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    expected = p.credit_card_network()
    assert all([expected in CREDIT_CARD_NETWORKS])

# Generated at 2022-06-23 21:36:16.380495
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment(seed=1234567890)
    assert (payment.ethereum_address() == "0xDb3C0a9aD1ffaA84A43C7e49A1A33CAb79c2aF8f")

# Generated at 2022-06-23 21:36:18.450808
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    print('\n---\ncvv: %s\n---' % p.cvv())


# Generated at 2022-06-23 21:36:21.092356
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    bitcoin_address = payment.bitcoin_address()
    assert(bitcoin_address.startswith("1") or bitcoin_address.startswith("3"))


# Generated at 2022-06-23 21:36:22.151127
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    Payment().cvv()

# Generated at 2022-06-23 21:36:32.001801
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():

    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment

    payment = Payment('en')

    # Test 1, credit_card_owner without parameters:
    owner = payment.credit_card_owner()
    card_number = owner['credit_card']
    owner_name = owner['owner']
    expiration_date = owner['expiration_date']
    assert len(expiration_date) == 5
    assert len(card_number.split()) == 4
    list_name = owner_name.split()
    assert len(list_name) == 2
    assert len(list_name[0]) >= 3
    assert len(list_name[1]) >= 3

    # Test 2, credit_card_owner with gender parameter:

# Generated at 2022-06-23 21:36:35.270182
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    credit_card_network = payment.credit_card_network()
    assert credit_card_network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:36:36.652749
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert payment.cvv() < 1000



# Generated at 2022-06-23 21:36:44.168455
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p=Payment()
    expect_set=[
            {
             'expiration_date': '11/23',
             'owner': 'PHILIP KRAMER',
             'credit_card': '4019 5847 1348 0852'
            },
            {
             'expiration_date': '06/19',
             'owner': 'JESSE DOWNEY',
             'credit_card': '4935 8419 6397 1413'
            },
            {
             'expiration_date': '10/19',
             'owner': 'ROSEMARY WEST',
             'credit_card': '5594 3643 1982 1255'
            }
        ]
    set=[]
    for i in range(3):
        credit_card_owner = p.credit_card_owner()

# Generated at 2022-06-23 21:36:48.287836
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment(random_state=1234)
    cid = payment.cid()
    # should be a 4-digit integer
    assert isinstance(cid, int)
    assert cid > 1000 and cid <10000


# Generated at 2022-06-23 21:36:50.071817
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    card_number = payment.credit_card_number()
    assert card_number == '4455 5299 1152 2450'

# Generated at 2022-06-23 21:36:51.884523
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    credit_card_owner = p.credit_card_owner()
    return credit_card_owner


# Generated at 2022-06-23 21:36:54.982867
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Test method credit card expiration date of class Payment."""
    from random import Random
    random = Random()
    random.seed(1)
    payment = Payment(random)
    result = payment.credit_card_expiration_date(10,15)

    assert result == '08/12'

# Generated at 2022-06-23 21:36:56.680943
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    a = payment.cid()
    assert a is not None
    assert len(str(a)) == 4


# Generated at 2022-06-23 21:36:58.573515
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis.enums import CardType
    ctn = Payment().credit_card_network()
    assert ctn in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:37:03.486334
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Init
    p1 = Payment(seed=1)
    p2 = Payment(seed=1)

    # Action
    r1 = p1.paypal()
    r2 = p2.paypal()

    # Assert
    assert r1 == r2
    assert r1 == 'hicksgraig@yahoo.com'


# Generated at 2022-06-23 21:37:04.529278
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment is not None

# Generated at 2022-06-23 21:37:05.849118
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert Payment().cvv() is not None


# Generated at 2022-06-23 21:37:07.121847
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pay = Payment()
    print(pay.credit_card_number())


# Generated at 2022-06-23 21:37:08.916242
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import Gender
    payment = Payment()
    assert payment.credit_card_expiration_date(minimum = 16, maximum = 25) == "06/16"


# Generated at 2022-06-23 21:37:11.955313
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    if (len(str(payment.cvv())) == 3):
        return True
    else:
        return False


# Generated at 2022-06-23 21:37:14.669592
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    #print(p.ethereum_address())


# Generated at 2022-06-23 21:37:23.540480
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """
    Test method paypal()
    """
    import random
    import mimesis
    payment_p = mimesis.Payment('es')
    for i in range(10):
        assert re.match('^[A-Za-z0-9._%+-]{1,64}@(?:[A-Za-z0-9-]{1,63}\.){1,125}[A-Za-z]{2,63}$', payment_p.paypal())
        assert re.match('^[A-Za-z0-9._%+-]{1,64}@(?:[A-Za-z0-9-]{1,63}\.){1,125}[A-Za-z]{2,63}$', payment_p.paypal())


# Generated at 2022-06-23 21:37:33.444621
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    payment = Payment()
    card_type = get_random_item(CardType)
    card = payment.credit_card_number(card_type)
    assert payment.validate(card_type, card)
    # Invalid Luhn check
    assert not payment.validate(card_type, '1234 5678 1234 5679')
    # Invalid card type
    card_type = get_random_item(CardType)
    while card_type == card_type:
        card_type = get_random_item(CardType)
    assert not payment.validate(card_type, card)
    # Invalid length
    assert not payment.validate(card_type, card[:-1])


# Generated at 2022-06-23 21:37:36.707026
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import random
    import time
    random.seed(time.time())
    payment = Payment('en')
    print(payment.credit_card_number())


# Generated at 2022-06-23 21:37:38.949341
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pay = Payment('en')
    assert re.match(r'\w+@\w+\.\w{2,}', pay.paypal())

# Generated at 2022-06-23 21:37:43.116948
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment=Payment()
    for i in range (0,10):
        res=payment.credit_card_expiration_date()
        assert res[2]=="/"
        assert len(res) ==5
        assert type(res)==str
        assert res[0:2].isdigit()
        assert res[3:].isdigit()

# Generated at 2022-06-23 21:37:48.484941
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    creditCardOwner = payment.credit_card_owner()
    assert creditCardOwner['credit_card'] is not None, "Credit Card owner is NULL!"
    assert creditCardOwner['expiration_date'] is not None, "Expiration Date is NULL!"
    assert creditCardOwner['owner'] is not None, "Owner is NULL!"

# Generated at 2022-06-23 21:37:54.384868
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    obj = Payment()
    assert True if len(str(obj.credit_card_number())) == 16 else False
    assert True if str(obj.credit_card_number(CardType.AMERICAN_EXPRESS))[0] == '3' else False
    assert True if str(obj.credit_card_number(CardType.MASTER_CARD))[0] == '5' else False

# Generated at 2022-06-23 21:37:57.591511
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment('en', seed=1)
    print(p.bitcoin_address())
    assert p.bitcoin_address() == '1Lk4m6yB9QMXWsd6fd5V7m5vp5Z5V7pW8p'


# Generated at 2022-06-23 21:38:00.367668
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    print (Payment().credit_card_expiration_date())  # >>> 11/22


# Generated at 2022-06-23 21:38:05.756128
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    print("Teststart")
    print(Payment().cvv())
    print(Payment().cvv())
    print(Payment().cvv())
    print(Payment().cvv())
    print(Payment().cvv())
    print(Payment().cvv())
    print(Payment().cvv())
    print(Payment().cvv())
    print(Payment().cvv())
    print(Payment().cvv())
    print("Testende")


# Generated at 2022-06-23 21:38:09.293312
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    m = Payment()
    result = m.credit_card_network()
    assert result in CREDIT_CARD_NETWORKS

if __name__ == "__main__":
    m = Payment()
    print(m.credit_card_expiration_date())

# Generated at 2022-06-23 21:38:13.265879
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    x = Payment()
    ans = x.ethereum_address()
    assert ans[0] == '0' and ans[1] == 'x' and len(ans) == 42
    assert ans[2:18] == ans[18:] == ans[19:37]



# Generated at 2022-06-23 21:38:16.224434
# Unit test for method cid of class Payment
def test_Payment_cid():
    l=Payment()
    cid=l.cid()
    assert type(cid) is int
    assert 1000 <= cid <= 9999


# Generated at 2022-06-23 21:38:18.321000
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    result = payment.paypal()
    assert type(result) == str, 'The result must be a string!'


# Generated at 2022-06-23 21:38:20.865554
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    pay = Payment()
    result = pay.cvv()
    assert isinstance(result, int)
    assert len(str(result)) == 3


# Generated at 2022-06-23 21:38:22.102113
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert len(Payment().cid()) == 4


# Generated at 2022-06-23 21:38:23.709175
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Test for method bitcoin_address of class Payment"""
    address = Payment().bitcoin_address()
    assert address.startswith('1') or address.startswith('3')
    assert len(address) == 34

# Generated at 2022-06-23 21:38:25.744666
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment('en')
    address = p.bitcoin_address()
    print(address)
    assert isinstance(address, str)
    assert len(address) == 34

# Generated at 2022-06-23 21:38:28.402299
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    a = Payment()
    assert a.bitcoin_address() == "3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX"
    

# Generated at 2022-06-23 21:38:30.515824
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment('en')
    credit_card_network = payment.credit_card_network()
    assert isinstance(credit_card_network, str)
    assert credit_card_network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:38:36.136632
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment(random=False)
    payment.random.choice = lambda x: True
    payment.random.randint = lambda x, y: True
    assert payment.credit_card_expiration_date() == "02/20"
    payment.random.randint = lambda x, y: False
    assert payment.credit_card_expiration_date() == "01/20"


# Generated at 2022-06-23 21:38:37.812664
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    payment.credit_card_owner()
    # Expect to return a dictionary

# Generated at 2022-06-23 21:38:40.060193
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    print(payment.cid())
    assert len(str(payment.cid())) == 4


# Generated at 2022-06-23 21:38:44.062563
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Unit test for method ethereum_address of class Payment
    payment = Payment(seed=12342345)
    assert payment.ethereum_address() == '0x888250e01a9e9b42d731e70d30d3e852ed3f3af7'

# Generated at 2022-06-23 21:38:45.427490
# Unit test for constructor of class Payment
def test_Payment():
    _payment = Payment()

    assert _payment is not None
    assert _payment.seed is not None


# Generated at 2022-06-23 21:38:50.583825
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner(gender=Gender.MALE)
    assert len(owner) == 3
    assert len(owner['owner']) > 0
    assert len(owner['credit_card']) > 0
    assert len(owner['expiration_date']) > 0

# Generated at 2022-06-23 21:38:53.467737
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment(seed=1)
    print(set([str(p.credit_card_network()) for _ in range(10)]))


# Generated at 2022-06-23 21:38:55.536316
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert payment.paypal() == 'jessicaneil@gmail.com'


# Generated at 2022-06-23 21:38:57.640635
# Unit test for constructor of class Payment
def test_Payment():
    # Create object instance.
    obj = Payment()
    assert isinstance(obj.random, Random)
    assert isinstance(obj.__person, Person)

# Generated at 2022-06-23 21:39:00.227058
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert 3 == len(str(payment.cvv()))


# Generated at 2022-06-23 21:39:04.317085
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis.enums import CardType
    ccn = Payment('en')
    for _ in range(50):
        card_type = ccn.credit_card_network()
        assert CardType.VISA.value in card_type
        assert CardType.MASTER_CARD.value in card_type
        assert CardType.AMERICAN_EXPRESS.value in card_type
    return


# Generated at 2022-06-23 21:39:07.920817
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    print("Start function test_Payment_credit_card_owner()")
    p = Payment('en')
    # create credit card owner
    print(p.credit_card_owner())
    print("End function test_Payment_credit_card_owner()")


# Generated at 2022-06-23 21:39:12.375920
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():

    "Unit test for method credit_card_owner of class Payment"

    payment = Payment()
    owner = payment.credit_card_owner()
    assert isinstance(owner['credit_card'], str)
    assert isinstance(owner['expiration_date'], str)
    assert isinstance(owner['owner'], str)

# Generated at 2022-06-23 21:39:15.424327
# Unit test for constructor of class Payment
def test_Payment():
    obj = Payment()
    cc_num = obj.credit_card_owner()
    print(cc_num['credit_card'])

# Generated at 2022-06-23 21:39:18.602841
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    payment = Payment()
    card_number = payment.credit_card_number()
    print(card_number)
    assert card_number is not None
    assert isinstance(card_number, str) and len(card_number) == 19

# Generated at 2022-06-23 21:39:19.599607
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    print(payment.ethereum_address())

# Generated at 2022-06-23 21:39:22.526381
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert len(payment.paypal()) == 20
    assert "@" in payment.paypal()
    assert "." in payment.paypal()



# Generated at 2022-06-23 21:39:25.497348
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.AMERICAN_EXPRESS
    card_num = Payment().credit_card_number(card_type)
    assert card_num.startswith('3')
    assert card_num.count(' ') == 2
    assert len(card_num.split(' ')) == 4

# Generated at 2022-06-23 21:39:28.111433
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    result = {
        "address": payment.bitcoin_address()
    }
    print(result)


# Generated at 2022-06-23 21:39:38.134158
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # with this call, any call to random.randint should return 3
    # with patch.object(Payment.random, 'randint', side_effect=3):
    import pytest
    from mimesis.enums import Gender, CardType
    from mimesis.exceptions import NonEnumerableError
    ser = Payment(locale='en', seed=9854)

    with pytest.raises(NonEnumerableError):
        ser.credit_card_number(CardType.DISCOVER)

    with pytest.raises(NonEnumerableError):
        ser.credit_card_number(CardType.CARTE_BLANCHE)

    with pytest.raises(NonEnumerableError):
        ser.credit_card_number(CardType.DINERS_CLUB)


# Generated at 2022-06-23 21:39:40.521411
# Unit test for constructor of class Payment
def test_Payment():
    from mimesis.enums import Gender

    p = Payment()
    assert(p != None)
    p = Payment('en')
    assert(p != None)



# Generated at 2022-06-23 21:39:41.430644
# Unit test for constructor of class Payment
def test_Payment():
    temp = Payment()
    assert temp is not None

# Generated at 2022-06-23 21:39:47.330036
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    key_word = {'minimum': int, 'maximum': int}
    provider_1 = Payment(seed=1)
    provider_2 = Payment(seed=1)
    assert provider_1.credit_card_expiration_date() == provider_2.credit_card_expiration_date()
    try:
        provider_1.credit_card_expiration_date(**key_word)
    except Exception as e:
        assert isinstance(e, NonEnumerableError)
    else:
        raise Exception('NonEnumerableError does not raise')


# Generated at 2022-06-23 21:39:51.200764
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    '''
    Unit test for method credit_card_owner of class Payment
    '''
    payment = Payment('en')
    owner = payment.credit_card_owner()
    assert('credit_card' in owner)
    assert('expiration_date' in owner)
    assert('owner' in owner)
    assert(owner['credit_card'].isnumeric())
    assert(owner['expiration_date'].isnumeric() or
           (owner['expiration_date'].isalnum() and '/' in owner['expiration_date']))
    assert(owner['owner'].isalpha())


# Generated at 2022-06-23 21:39:55.603867
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    assert re.match("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", p.paypal())

# Generated at 2022-06-23 21:39:57.719731
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    # Init the Payment class
    payment = Payment()
    print("Payment: " + payment.credit_card_network())



# Generated at 2022-06-23 21:39:58.717960
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    for _ in range(2):
        print(Payment().credit_card_network())


# Generated at 2022-06-23 21:40:00.315985
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # results = []
    # for i in range(20):
    #     results.append(Payment().cvv())
    # print(results)
    print(Payment().cvv())


# Generated at 2022-06-23 21:40:03.084909
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    cvv = Payment()
    assert cvv.cvv()>= 100 and cvv.cvv()<= 999


# Generated at 2022-06-23 21:40:05.313906
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert Payment().bitcoin_address() == "3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX"

# Generated at 2022-06-23 21:40:10.081411
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    CardNumber = p.credit_card_number()
    CardNumber_array = CardNumber.split()
    assert luhn_checksum(CardNumber_array[0] + CardNumber_array[1] + CardNumber_array[2] + CardNumber_array[3]) == ""


# Generated at 2022-06-23 21:40:13.570386
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment()

    for _ in range(100):
        card_num = provider.credit_card_number()
        if len(card_num) != 19:
            raise AssertionError('Length of credit card number is not correct')

# Generated at 2022-06-23 21:40:14.913723
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    print(p.cvv())
