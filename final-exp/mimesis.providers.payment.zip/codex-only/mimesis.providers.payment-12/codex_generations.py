

# Generated at 2022-06-23 21:30:09.889041
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment(seed=101)

    assert p.cid() == 7452


# Generated at 2022-06-23 21:30:14.126048
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert re.match(r'^[13][a-km-zA-HJ-NP-Z1-9]{26,33}$', Payment().bitcoin_address()) is not None


# Generated at 2022-06-23 21:30:25.549577
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import CardType
    from mimesis.enums import Gender
    from mimesis.payments import Payment
    current_year = XX_current_year() # XX_current_year() returns the value of the current year
    minimum = 16
    maximum = 25
    payment = Payment('en')
    assert payment.credit_card_expiration_date(minimum, maximum) in ['{0:02d}/{1}'.format(month, year) for month in range(1, 13) for year in range(16, 26)]
    assert payment.credit_card_expiration_date(minimum, maximum) not in ['{0:02d}/{1}'.format(month, year) for month in range(1, 13) for year in range(current_year - minimum, current_year - maximum)]

# Generated at 2022-06-23 21:30:33.948239
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    print(payment)
    print('\n')
    print(payment.credit_card_owner())
    print('\n')
    print(payment.credit_card_expiration_date())
    print('\n')
    print(payment.cvv())
    print('\n')
    print(payment.credit_card_number())
    print('\n')
    print(payment.ethereum_address())
    print('\n')
    print(payment.bitcoin_address())
    print('\n')
    print(payment.paypal())
    print('\n')
    print(payment.cid())
    print('\n')
    print(payment.credit_card_network())
    print('\n')

if __name__ == '__main__':
    test_Payment

# Generated at 2022-06-23 21:30:36.219695
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    date = Payment()
    assert date.credit_card_expiration_date() == '05/19'

# Generated at 2022-06-23 21:30:40.198742
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    obj = Payment()
    result_dict = obj.credit_card_owner()
    assert result_dict is not None
    assert 'credit_card' in result_dict
    assert 'expiration_date' in result_dict
    assert 'owner' in result_dict


# Generated at 2022-06-23 21:30:49.194148
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # Инициализация класса
    payment = Payment()

    # Проверка на "02/20"
    a = payment.credit_card_expiration_date()
    assert a == "02/20"

    # Проверка на "04/19"
    b = payment.credit_card_expiration_date(16, 18)
    assert b == "04/18"

# Generated at 2022-06-23 21:30:50.579932
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert (len(str(payment.cvv()))) == 3

# Generated at 2022-06-23 21:30:54.143041
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    ethereum_address = Payment().ethereum_address()
    assert len(ethereum_address) == 42
    assert ethereum_address[0:2] == '0x'
    assert ethereum_address[2:].isalnum()


# Generated at 2022-06-23 21:30:57.239605
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    p.seed(123)
    assert p.credit_card_expiration_date() == '11/20'

# Generated at 2022-06-23 21:30:59.431742
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment"""
    p = Payment(random_state=1)
    p.credit_card_number()

# Generated at 2022-06-23 21:31:07.379889
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """
    Unit test for method credit_card_owner of class Payment
    """
    payment = Payment()
    card_number = payment.credit_card_number(CardType.MASTER_CARD)
    owner = payment.__person.full_name(gender=Gender.FEMALE)
    expiration_date = payment.credit_card_expiration_date()
    assert isinstance(payment.credit_card_owner(), dict)
    assert payment.credit_card_owner() == {
        'credit_card': card_number,
        'expiration_date': expiration_date,
        'owner': owner.upper(),
    }


# Generated at 2022-06-23 21:31:16.848364
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    # Test card type VISA
    payment.credit_card_number(card_type=CardType.VISA)
    # Test card type MASTER_CARD
    payment.credit_card_number(card_type=CardType.MASTER_CARD)
    # Test card type AMERICAN_EXPRESS
    payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
    # Test with invalid card type
    try:
        payment.credit_card_number(card_type='NotSupported')
        assert False, 'Expected NonEnumerableError'
    except ValueError:
        pass
    except Exception:
        pass

# Generated at 2022-06-23 21:31:19.892135
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment(seed=42)
    assert payment.ethereum_address() == "0x40dd7e72f9c82f7dbe1c8e1a1628917f02c6d73f"


# Generated at 2022-06-23 21:31:20.881575
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    p.bitcoin_address()

# Generated at 2022-06-23 21:31:22.432029
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    # Assert that a string is returned

# Generated at 2022-06-23 21:31:25.136482
# Unit test for method cid of class Payment
def test_Payment_cid():
	""" Unit test for method cid of class Payment """
	payment = Payment()
	assert payment.cid() >= 1000 and payment.cid() <= 9999


# Generated at 2022-06-23 21:31:27.048158
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment(seed = 42)
    assert payment.cvv() == 392


# Generated at 2022-06-23 21:31:34.073245
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    result = p.credit_card_expiration_date(minimum=16, maximum=25)
    assert len(result) == 5
    assert int(result[3:5]) >= 16 and int(result[3:5]) <= 25
    assert int(result[0:2]) >= 1 and int(result[0:2]) <= 12
    assert result[2] == '/'



# Generated at 2022-06-23 21:31:35.846078
# Unit test for constructor of class Payment
def test_Payment():
    payment_test = Payment("test")
    assert payment_test is not None


# Generated at 2022-06-23 21:31:40.098231
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert payment.ethereum_address() == "0x8bdd9e26f320dbb7e53c65f8bf0a891d440fe2a2"


# Generated at 2022-06-23 21:31:44.062164
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    a = p.bitcoin_address()
    if len(a) == 35:
        print("test_Payment_bitcoin_address SUCCESSFUL")
    else:
        print("test_Payment_bitcoin_address UNSUCCESSFUL")


# Generated at 2022-06-23 21:31:48.590341
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    expiration_date = payment.credit_card_expiration_date()

    owner = payment.credit_card_owner()

    assert owner['credit_card'] == credit_card_number
    assert expiration_date == owner['expiration_date']
    assert payment.__person.full_name(gender=Gender.MALE) in owner['owner']
    assert payment.__person.full_name(gender=Gender.FEMALE) in owner['owner']

# Generated at 2022-06-23 21:31:52.466090
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    for year in range(3,5):
        for month in range(1,13):
            print("\n{}-{}".format(month, year), p.credit_card_expiration_date(year - 1, year))


# Generated at 2022-06-23 21:31:54.129060
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print('Validate credit card number: ' + payment.credit_card_number())


# Generated at 2022-06-23 21:31:59.909373
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    p.credit_card_expiration_date()
    assert p.credit_card_expiration_date(16, 25) == "03/19"
    assert p.credit_card_expiration_date(
        minimum=15, maximum=20) == "09/18"

# Generated at 2022-06-23 21:32:01.255909
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert payment.paypal()


# Generated at 2022-06-23 21:32:11.799614
# Unit test for constructor of class Payment
def test_Payment():
    payments = Payment(seed=42)
    assert payments.cid == 7452
    assert payments.paypal == 'wolf235@gmail.com'
    assert payments.bitcoin_address == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'
    assert payments.ethereum_address == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'
    assert payments.credit_card_network == 'MasterCard'
    assert payments.credit_card_number == '4455 5299 1152 2450'
    assert payments.credit_card_expiration_date == '03/19'
    assert payments.cvv == 324

# Generated at 2022-06-23 21:32:15.255167
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment("en")
    r = p.credit_card_expiration_date()
    assert re.match(r"\d{2}/\d{2}",r)

# Generated at 2022-06-23 21:32:17.117963
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()  # type: Payment
    assert payment.credit_card_network()


# Generated at 2022-06-23 21:32:26.817378
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from random import randint
    from random import seed
    from mimesis.enums import Gender

    # Write in file
    def write_in_file(text, time_seed, time_randint, time_credit_card, time_owner):
        with open("python_class_Payment.txt", "a") as file:
            file.write(text)
            file.write("\n")
        with open("python_class_Payment.txt", "a") as file:
            file.write("time_seed: "+str(time_seed))
            file.write("\n")
            file.write("time_randint: "+str(time_randint))
            file.write("\n")
            file.write("time_credit_card: "+str(time_credit_card))

# Generated at 2022-06-23 21:32:28.061467
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment('en')
    assert type(payment.cvv()) == int

# Generated at 2022-06-23 21:32:36.657764
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # Unit test for method bitcoin_address of class Payment
    for _ in range(10000):
        # 3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX
        bitcoin_address = Payment().bitcoin_address()
        try:
            assert bitcoin_address[0] in ['1', '3']
            assert len(bitcoin_address) == 34
            for single_char in bitcoin_address[1:]:
                assert single_char in (string.digits + string.ascii_letters)
        except AssertionError:
            print(bitcoin_address)
            raise AssertionError


# Generated at 2022-06-23 21:32:40.888775
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment."""
    pay = Payment()
    address = pay.ethereum_address()
    assert address == "0xcc0f6a3c6aadb0ed8fcf38b90e4f695e9f9cef8b"

# Generated at 2022-06-23 21:32:49.506979
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    from mimesis.enums import Gender
    p = Payment('en')
    print(p.paypal())
    print(p.paypal())
    print(p.paypal())
    print(p.paypal())
    print(p.paypal())
    print(p.paypal())
    print(p.paypal())
    print(p.paypal())
    print(p.paypal())
    print(p.credit_card_owner(Gender.MALE))
    print(p.credit_card_owner(Gender.FEMALE))
    print(p.credit_card_owner(Gender.UNDISCLOSED))
    print(p.credit_card_owner(Gender.MALE))
    print(p.credit_card_owner(Gender.FEMALE))

# Generated at 2022-06-23 21:32:51.952642
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    date = payment.credit_card_expiration_date(minimum=0, maximum=25)
    assert date != ""
    assert len(date) == 5
    assert date.find("/") != -1

# Generated at 2022-06-23 21:33:02.192296
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment(seed=42)

    for _ in range(100):
        card_number = payment.credit_card_number(card_type=CardType.VISA)
        assert card_number[0] == "4"
        assert len(card_number) == 19

    for _ in range(100):
        card_number = payment.credit_card_number(card_type=CardType.MASTER_CARD)
        assert card_number[0] in ["2", "5"]
        assert len(card_number) == 19

    for _ in range(100):
        card_number = payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)
        assert card_number[0] in ["3"]

# Generated at 2022-06-23 21:33:03.427253
# Unit test for method cvv of class Payment
def test_Payment_cvv():
	for i in range(10):
		print(Payment().cvv())


# Generated at 2022-06-23 21:33:04.733623
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert '@' in payment.paypal()

# Generated at 2022-06-23 21:33:07.022650
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test = Payment()
    print(test.credit_card_number())



# Generated at 2022-06-23 21:33:08.059043
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert(payment.cid() in range(1000, 9999))

# Generated at 2022-06-23 21:33:13.506492
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    card_owner = Payment()
    owner = card_owner.credit_card_owner(Gender.MALE)

    assert type(owner) == dict
    assert type(owner['credit_card']) == str
    assert type(owner['expiration_date']) == str
    assert type(owner['owner']) == str


# Generated at 2022-06-23 21:33:18.452130
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    assert len(p.ethereum_address()) == 42
    assert p.ethereum_address()[:2] == '0x'
    assert re.match(r'[a-f0-9]', p.ethereum_address()[2:])


# Generated at 2022-06-23 21:33:20.156135
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment is not None

# Generated at 2022-06-23 21:33:22.492609
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis import Payment
    payment = Payment()
    result = payment.credit_card_number()
    assert type(result) == str



# Generated at 2022-06-23 21:33:24.187561
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert Payment().credit_card_expiration_date(10, 20)[-2:] == '/2'

# Generated at 2022-06-23 21:33:26.972183
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    assert payment.credit_card_owner(Gender.MALE) == {'credit_card': '4455 5299 1152 2450', 'expiration_date': '12/17', 'owner': 'ROBERT BUSH'}

# Generated at 2022-06-23 21:33:38.069124
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import sys
    import subprocess
    from mimesis.providers.payment import Payment
    p = Payment()
    ccn = p.credit_card_number()
    print("The credit card number is %s" % ccn)
    ccntype = p.credit_card_network()
    print("The credit card network is %s" % ccntype)
    # get a card type to check for
    chosentype = sys.argv[1]
    if ccntype not in chosentype:
        print("ERROR: Credit card type not correct")
        sys.exit(1)
    # remove spaces in credit card number
    ccnwospace = ccn.replace(" ", "")
    # call luhn checksum to make sure it is a valid number

# Generated at 2022-06-23 21:33:39.609542
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    test = payment.paypal()
    assert type(test) == str
    assert re.match(r'\w+@\w+\.[a-z]{2,3}', test) != None


# Generated at 2022-06-23 21:33:48.801859
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    p.credit_card_expiration_date(minimum=16, maximum=25)
    p.credit_card_expiration_date(minimum=16, maximum=25)
    p.credit_card_expiration_date(minimum=16, maximum=25)
    p.credit_card_expiration_date(minimum=16, maximum=25)
    p.credit_card_expiration_date(minimum=16, maximum=25)
    p.credit_card_expiration_date(minimum=16, maximum=25)
    p.credit_card_expiration_date(minimum=16, maximum=25)
    p.credit_card_expiration_date(minimum=16, maximum=25)
    p.credit_card_expiration_date(minimum=16, maximum=25)
    p.credit

# Generated at 2022-06-23 21:33:49.846803
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    print(p.cid())

# Generated at 2022-06-23 21:33:53.510419
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # GIVEN
    provider = Payment()

    # WHEN
    cvv = provider.cvv()

    # THEN
    assert cvv > 100
    assert cvv < 100000



# Generated at 2022-06-23 21:33:55.860019
# Unit test for method cid of class Payment
def test_Payment_cid():
    obj = Payment('en', seed=0)
    assert obj.cid() == 7452


# Generated at 2022-06-23 21:33:58.673311
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    obj = Payment()

    # Run method
    result = obj.cvv()

    # Run assertion
    assert result > 0
    assert result < 1000


# Generated at 2022-06-23 21:34:05.304940
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert True == re.match(r'\d{16}', p.credit_card_number())
    assert True == re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', p.credit_card_number(CardType.VISA))
    assert True == re.match(r'\d{4}\s\d{4}\s\d{4}\s\d{4}', p.credit_card_number(CardType.MASTER_CARD))
    assert True == re.match(r'\d{4}\s\d{6}\s\d{5}', p.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-23 21:34:06.541215
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    a = Payment()
    b = Payment()
    assert a.credit_card_expiration_date() != b.credit_card_expiration_date()

# Generated at 2022-06-23 21:34:10.779854
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Test unit for class Payment method bitcoin_address"""
    payment = Payment()

    assert isinstance(payment, Payment)
    assert re.match(r'[13][a-zA-Z0-9]{33}$', payment.bitcoin_address())


# Generated at 2022-06-23 21:34:12.665345
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment(random)
    assert payment.cid() > 1000
    assert payment.cid() < 10000


# Generated at 2022-06-23 21:34:16.487110
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment('en')
    assert len(payment.credit_card_network()) <= 12
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:34:18.958066
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cid = payment.cid()
    assert isinstance(cid, int)


# Generated at 2022-06-23 21:34:22.322694
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    assert(len(Payment().credit_card_owner()['credit_card']) == 16)
    assert(len(Payment().credit_card_owner()['expiration_date']) == 5)
    assert(len(Payment().credit_card_owner()['owner']) >= 5)

# Generated at 2022-06-23 21:34:24.831104
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment"""
    payment = Payment()
    assert payment.ethereum_address() == '0x4e1aae7d4b4e4b8c3b2ec38e9c9808f073313b70'

# Generated at 2022-06-23 21:34:36.694341
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""

    from mimesis import Payment
    payment = Payment("en")
    card_type = payment.random.choice(list(CardType))
    card_num = payment.credit_card_number(card_type)
    assert len(card_num) <= 19, "credit_card_number(): wrong number length"
    if card_type == CardType.VISA:
        assert card_num.startswith("4"), "credit_card_number(): it is not VISA"
    if card_type == CardType.MASTER_CARD:
        assert card_num.startswith("2"), "credit_card_number(): it is not MasterCard"

# Generated at 2022-06-23 21:34:46.750575
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment('ru')
    # print(payment.cvv())
    # print(payment.credit_card_owner())
    # print(payment.credit_card_expiration_date())
    # print(payment.credit_card_number())
    # print(payment.credit_card_number(CardType.MASTER_CARD))
    # print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))
    # print(payment.credit_card_network())
    # print(payment.bitcoin_address())
    # print(payment.ethereum_address())
    # print(payment.paypal())
    print(payment.cid())



# Generated at 2022-06-23 21:34:49.638062
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    result = payment.cvv()
    assert type(result) == int

if __name__ == '__main__':
    test_Payment_cvv()

# Generated at 2022-06-23 21:34:55.829140
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
	# initialize a random number generator with a random seed
	random.seed(datetime.now())
	print("random seed: " + str(random.getstate()))
	# create an instance of class Payment
	payment = Payment()
	# test method ethereum_address() 10 times
	for i in range(10):
		print(payment.ethereum_address())

# Generated at 2022-06-23 21:35:03.841177
# Unit test for method cid of class Payment
def test_Payment_cid():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    p = Payment()
    
    cid = p.cid()
    assert(cid >= 1000 and cid <= 9999)

    p2 = Payment()
    cid2 = p2.cid()
    assert(cid2 >= 1000 and cid2 <= 9999)
    assert(cid != cid2)

    p3 = Payment(seed=1)
    cid3 = p3.cid()
    assert(cid == cid3)



# Generated at 2022-06-23 21:35:09.008977
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match('[0-9]{16}', p.credit_card_number())
    assert re.match('[0-9]{15}', p.credit_card_number(CardType.AMERICAN_EXPRESS))
    #Credit card number for Card Type 'VISA'
    assert re.match('4[0-9]{15}', p.credit_card_number(CardType.VISA))
    #Credit card number for Card Type 'MASTER_CARD'
    assert re.match('5[1-5][0-9]{14}', p.credit_card_number(CardType.MASTER_CARD))
    # Credit card number for Card Type 'AMERICAN_EXPRESS'

# Generated at 2022-06-23 21:35:14.469856
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment1 = Payment('en')
    payment2 = Payment('en')
    payment3 = Payment('en')
    print("1st Bitcoin address: ", payment1.bitcoin_address())
    print("2nd Bitcoin address: ", payment2.bitcoin_address())
    print("3rd Bitcoin address: ", payment3.bitcoin_address())


# Generated at 2022-06-23 21:35:17.234548
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    a = Payment()
    b = a.paypal()
    regex = re.compile(r'[\w.]+@[\w.]+')
    assert regex.search(b)


# Generated at 2022-06-23 21:35:23.500902
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    assert len(Payment().credit_card_owner()['credit_card']) == 19
    assert len(Payment().credit_card_owner()['expiration_date']) == 5
    assert len(Payment().credit_card_owner()['owner']) >= 3
    print('credit_card_owner() ok')


# Generated at 2022-06-23 21:35:24.784664
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment_provider = Payment()
    print('Payment.paypal: {}'.format(payment_provider.paypal()))


# Generated at 2022-06-23 21:35:25.906355
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    assert Payment().paypal() == 'jwilliams@gmail.com'

# Generated at 2022-06-23 21:35:28.850194
# Unit test for method cid of class Payment
def test_Payment_cid():
    a = Payment()
    results = []
    for _ in range(10):
        result = a.cid()
        results.append(result)
    print(results)
    

# Generated at 2022-06-23 21:35:31.628723
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    res = payment.paypal()
    assert isinstance(res, str)
    assert len(res.replace('@', '').replace('.', '')) >= 3


# Generated at 2022-06-23 21:35:32.537464
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    print(p.cvv())

# Generated at 2022-06-23 21:35:41.601632
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():

    p1 = Payment()
    result = p1.credit_card_owner()
    assert isinstance(result, dict)

    p2 = Payment(random_state=1)
    result = p2.credit_card_owner()
    assert isinstance(result, dict)
    assert result == {'credit_card': '5543 9099 9295 6014', 'expiration_date': '04/17', 'owner': 'JOHNNY F. ATKINSON'}

    p3 = Payment(random_state=2)
    result = p3.credit_card_owner()
    assert isinstance(result, dict)
    assert result == {'credit_card': '4213 2063 3293 4967', 'expiration_date': '06/21', 'owner': 'SHARON B. MORGAN'}

    p4 = Payment

# Generated at 2022-06-23 21:35:42.773406
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert Payment().cvv()

# Generated at 2022-06-23 21:35:47.802031
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    print('Testing method cvv of class Payment')
    payment = Payment()
    cvv = payment.cvv()
    assert len(str(cvv)) == 3
    assert isinstance(cvv, int)
    print('Successfully tested method cvv of class Payment')


# Generated at 2022-06-23 21:35:49.319356
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    assert Payment().paypal() == 'takagikuhn@inbox.ru'

# Generated at 2022-06-23 21:35:52.750672
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    result = payment.credit_card_network()
    print('Credit Card Network is :  ', result)


# Generated at 2022-06-23 21:35:54.417892
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()

    # test the function cid is working correctly
    assert isinstance(int(payment.cid()), int)


# Generated at 2022-06-23 21:35:58.509092
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    assert payment.credit_card_owner().get('credit_card') is not None
    assert payment.credit_card_owner().get('expiration_date') is not None
    assert payment.credit_card_owner().get('owner') is not None


# Generated at 2022-06-23 21:36:00.349765
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    for i in range(10):
        print(payment.cid())


# Generated at 2022-06-23 21:36:02.926413
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert Payment().credit_card_expiration_date() == '06/16', "Wrong exipration date!"



# Generated at 2022-06-23 21:36:08.941094
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    paypal_pattern = re.compile(
        r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    )
    for _ in range(100):
        assert re.match(paypal_pattern, Payment().paypal())


# Generated at 2022-06-23 21:36:11.195393
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()      # from mimesis import Payment
    addr = payment.bitcoin_address()
    assert addr is not None


# Generated at 2022-06-23 21:36:13.986714
# Unit test for constructor of class Payment
def test_Payment():
    """

    """
    payment = Payment()
    assert payment.__class__.__name__ == 'Payment'
    assert hasattr(payment, 'seed')
    assert hasattr(payment, 'random')
    assert hasattr(payment, 'datetime')


# Generated at 2022-06-23 21:36:20.969656
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    a = Payment()
    print(a.bitcoin_address())
    print(a.ethereum_address())
    b = a.credit_card_number()
    print(b)
    c = a.credit_card_expiration_date()
    print(c)
    d = Payment()
    e = Person()
    f = e.full_name(gender=Gender.MALE)
    print(d.credit_card_owner(gender=Gender.MALE))

# Generated at 2022-06-23 21:36:23.738207
# Unit test for method cid of class Payment
def test_Payment_cid():
    for x in range(10):
        payment = Payment()
        cid = payment.cid()
        assert len(str(cid)) == 4


# Generated at 2022-06-23 21:36:28.901825
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number(CardType.VISA) == "4444 4444 4444 4444"
    assert Payment().credit_card_number(CardType.MASTER_CARD) == "5555 5555 5555 5555"
    assert Payment().credit_card_number(CardType.AMERICAN_EXPRESS) == "3333 3333 3333 333"


# Generated at 2022-06-23 21:36:34.094340
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment
    payment = Payment('en')
    owner = payment.credit_card_owner(gender=Gender.MALE)
    assert isinstance(owner, dict)
    assert isinstance(owner.get('credit_card'), str)
    assert isinstance(owner.get('expiration_date'), str)
    assert isinstance(owner.get('owner'), str)

# Generated at 2022-06-23 21:36:37.973943
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Unit test for method bitcoin_address of class Payment"""
    # Create instance
    p = Payment()

    # Generate bitcoin_address
    res = p.bitcoin_address()

    # Check result
    assert res.startswith("1") or res.startswith("3")
    assert len(res) == 34
    assert all([i in string.ascii_letters + string.digits for i in res[1:]])

# Generated at 2022-06-23 21:36:41.472057
# Unit test for method cvv of class Payment
def test_Payment_cvv():
  assert isinstance(Payment(seed=0).cvv(),int) # check return type
  assert (Payment(seed=0).cvv() > 99 and Payment(seed=0).cvv() < 1000) # check return value


# Generated at 2022-06-23 21:36:44.146876
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment_class = Payment()
    payment_class.paypal()
    print(payment_class.paypal())


# Generated at 2022-06-23 21:36:50.440190
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    print(card_number)
    print('-' * 80)
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.VISA))

# Generated at 2022-06-23 21:36:56.393162
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Unit test for method cid of class Payment."""

    # Test with seed = 0
    p = Payment(seed=0)
    print("Payment.cid(): ", p.cid())
    print("\n")

    # Test with seed = 1
    p = Payment(seed=1)
    print("Payment.cid(): ", p.cid())
    print("\n")

    # Test with seed = 10
    p = Payment(seed=10)
    print("Payment.cid(): ", p.cid())
    print("\n")


# Generated at 2022-06-23 21:37:02.685544
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    print('credit_card_number: {}'.format(credit_card_number))
    assert len(credit_card_number) == 19
    assert credit_card_number.replace(" ", "").isdigit()

    credit_card_number = payment.credit_card_number(CardType.MASTER_CARD)
    print('credit_card_number: {}'.format(credit_card_number))
    assert len(credit_card_number) == 19
    assert credit_card_number.replace(" ", "").isdigit()

    credit_card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    print('credit_card_number: {}'.format(credit_card_number))

# Generated at 2022-06-23 21:37:05.978286
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()

    credit_card_owner = payment.credit_card_owner()
    assert 'credit_card' in credit_card_owner
    assert 'expiration_date' in credit_card_owner
    assert 'owner' in credit_card_owner

# Generated at 2022-06-23 21:37:07.237355
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert(isinstance(Payment().cvv(), int))



# Generated at 2022-06-23 21:37:12.787928
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    pay = Payment()
    # print("Owner of credit card: ")
    # print(pay.credit_card_owner())
    # print("")
    print("Owner of credit card(female): ")
    print(pay.credit_card_owner(Gender.FEMALE))
    print("Owner of credit card(male): ")
    print(pay.credit_card_owner(Gender.MALE))

    # print("Owner of credit card(female): ")
    # print(pay.credit_card_owner(Gender.FEMALE))
    # print("Owner of credit card(male): ")
    # print(pay.credit_card_owner(Gender.MALE))
    # print("Owner of credit card(male): ")
    # print(pay.credit_card_owner(Gender.MALE))
    # print("

# Generated at 2022-06-23 21:37:14.521748
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    _payment = Payment()
    _paym = Payment(seed=1)
    assert _payment.credit_card_expiration_date() == "02/24"
    assert _paym.credit_card_expiration_date() == "06/21"


# Generated at 2022-06-23 21:37:18.309984
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cid = payment.cid()
    if not isinstance(cid, int) and not (1000 <= cid <= 9999):
        raise AssertionError
test_Payment_cid()


# Generated at 2022-06-23 21:37:21.453007
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    expected = CREDIT_CARD_NETWORKS
    provider = Payment(seed=42)
    result = provider.credit_card_network()
    assert result in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:37:23.664614
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    pay = Payment('en')
    test_master = pay.credit_card_network()
    print(test_master)

# Generated at 2022-06-23 21:37:25.761279
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert isinstance(payment, Payment)


# Generated at 2022-06-23 21:37:28.324390
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    result = payment.credit_card_expiration_date(15, 16)
    print(result)


# Generated at 2022-06-23 21:37:36.537982
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    # Test the function by calling it multiple times
    payment_provider = Payment(seed=1234)
    payment_provider_1 = Payment(seed=1234)
    payment_provider_2 = Payment(seed=1234)
    payment_provider_3 = Payment(seed=1234)
    payment_provider_4 = Payment(seed=1234)
    payment_provider_5 = Payment(seed=1234)

    assert payment_provider.credit_card_network() == "American Express"
    assert payment_provider_1.credit_card_network() == "American Express"
    assert payment_provider_2.credit_card_network() == "American Express"
    assert payment_provider_3.credit_card_network() == "American Express"
    assert payment_provider_4.credit_card

# Generated at 2022-06-23 21:37:38.214796
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Test method cid of Payment class."""
    cid = Payment('en')
    assert cid.cid() in range(1000, 9999)



# Generated at 2022-06-23 21:37:39.942101
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert payment.cvv() > 0
    assert isinstance(payment.cvv(), int)


# Generated at 2022-06-23 21:37:40.542271
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    pass

# Generated at 2022-06-23 21:37:43.267698
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    result = payment.credit_card_expiration_date()
    assert result is not None
    assert len(result) == 5
    assert result[2] == '/'


# Generated at 2022-06-23 21:37:46.687360
# Unit test for method cid of class Payment
def test_Payment_cid():
    for _ in range(3):
        result = Payment().cid()
        assert result < 1000 or result > 9999


# Generated at 2022-06-23 21:37:48.960377
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # Returns string expired date in format MM/YY
    result = Payment().credit_card_expiration_date()
    expect_result = "10/24"
    assert (result == expect_result)

# Generated at 2022-06-23 21:37:51.434918
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment(seed=12345678)
    assert payment.cid() == 8539


# Generated at 2022-06-23 21:37:56.885645
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()

    # Test for normal way of data using.
    result = payment.credit_card_expiration_date()

    assert result == '07/24', 'Fail! It must be "07/24"'

    # Test for minimum and maximum
    result = payment.credit_card_expiration_date(minimum=10, maximum=25)

    assert result == '03/12', 'Fail! It must be "03/12"'

# Generated at 2022-06-23 21:38:02.640752
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Test for method credit_card_owner of class Payment"""
    owner = Payment().credit_card_owner()
    assert all([
        owner['credit_card'] is not None,
        owner['expiration_date'] is not None,
        owner['owner'] is not None
    ])
    return True

# Generated at 2022-06-23 21:38:04.503309
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    a = Payment()
    result = a.credit_card_network()
    print(result)
    # result: 'MasterCard'



# Generated at 2022-06-23 21:38:06.808130
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment('en', seed=42)
    date = payment.credit_card_expiration_date()
    assert date == '03/17'

# Generated at 2022-06-23 21:38:12.226451
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Unit test for method credit_card_expiration_date of class Payment"""
    payment = Payment()
    print(payment.credit_card_expiration_date(20, 25))
    assert payment.credit_card_expiration_date() in \
        ['03/20', '04/22', '06/21', '11/25', '12/20']


# Generated at 2022-06-23 21:38:15.636583
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # Initialize
    test = Payment()
    # Run test
    for _ in range(100):
        assert test.cvv() in range(100, 999)
    # Clean up
    test = None

# Generated at 2022-06-23 21:38:17.606664
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    py = Payment()
    num = py.credit_card_number()
    print(num)


# Generated at 2022-06-23 21:38:18.898523
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    print(Payment.Pyment().cvv())


# Generated at 2022-06-23 21:38:23.112823
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
	# Unit test for method credit_card_number of class Payment for all card types
	card_types = [CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]
	for i in range(20):
		print(Payment().credit_card_number(card_types[i]))



# Generated at 2022-06-23 21:38:24.273295
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number()


# Generated at 2022-06-23 21:38:26.470277
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert Payment().credit_card_number() in '4515454545454545'.split()

# Generated at 2022-06-23 21:38:28.488887
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    bitcoin_address = p.bitcoin_address()
    assert bitcoin_address[0] in ['1','3']
    assert len(bitcoin_address) == 34



# Generated at 2022-06-23 21:38:34.361867
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from random import Random
    rnd = Random()
    rnd.seed(42)
    payment = Payment(random.Random)
    for _ in range(30):
        assert re.search(r'\d{4} \d{4} \d{4} \d{4}',  payment._Payment__credit_card_number(CardType.VISA))
        assert re.search(r'\d{4} \d{4} \d{4} \d{4}',  payment._Payment__credit_card_number(CardType.MASTER_CARD))
        assert re.search(r'\d{4} \d{6} \d{5}',  payment._Payment__credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-23 21:38:40.012452
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    provider = Payment()
    # result = provider.bitcoin_address()
    # assert provider.check_bit_address(result) and provider.check_bitcoin_address(result)
    for i in range(0, 100):
        result = provider.bitcoin_address()
        assert provider.check_bit_address(result) and provider.check_bitcoin_address(result)


# Generated at 2022-06-23 21:38:43.149306
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payu = Payment()
    assert re.match("^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$", payu.paypal()) is not None

# Generated at 2022-06-23 21:38:47.170336
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment('en')
    assert payment.credit_card_number()
    assert payment.cvv()
    assert payment.credit_card_owner()
    assert payment.credit_card_network()
    assert payment.credit_card_expiration_date()
    assert payment.cid()
    assert payment.paypal()
    assert payment.bitcoin_address()
    assert payment.ethereum_address()


# Generated at 2022-06-23 21:38:51.848122
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    print(payment.bitcoin_address())
    print(payment.bitcoin_address())
    print(payment.bitcoin_address())
    print(payment.bitcoin_address())
    print(payment.bitcoin_address())
    # print(payment.credit_card_owner())

# Generated at 2022-06-23 21:38:56.127483
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # Expected result from Mimesis 4.0.4
    expected = 872
    # Actual result from Mimesis 5.0.2
    actual = Payment().cvv()
    # Unit test
    assert expected == actual


# Generated at 2022-06-23 21:39:01.143862
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print(Payment().credit_card_number())
    print(Payment().credit_card_number(CardType.VISA))
    print(Payment().credit_card_number(CardType.MASTER_CARD))
    print(Payment().credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-23 21:39:11.416127
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p.cid() in range(1000, 9999)
    assert '@' in p.paypal()
    assert p.bitcoin_address()[0] in ['1', '3']
    assert p.bitcoin_address()[34] + p.bitcoin_address()[35] not in ['11', '22', '33']
    assert '0x' in p.ethereum_address() 
    assert p.credit_card_network() in CREDIT_CARD_NETWORKS
    assert p.credit_card_number(CardType.VISA)[0] == '4'
    assert p.credit_card_number(CardType.MASTER_CARD)[0] in ['2', '5']

# Generated at 2022-06-23 21:39:15.237639
# Unit test for constructor of class Payment
def test_Payment():
    test_object = Payment()
    print(test_object.paypal())

if __name__ == "__main__":
    test_Payment()

# Generated at 2022-06-23 21:39:18.088239
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    # Get the result of the method.
    bitcoin_address = payment.bitcoin_address()
    # Check that the result is a string.
    assert isinstance(bitcoin_address, str)


# Generated at 2022-06-23 21:39:22.347133
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    seed = 43

    min_year = 17
    max_year = 30
    month = 3
    year = 19

    p = Payment(seed=seed)
    assert p.credit_card_expiration_date(min_year, max_year) == "{}/{}".format(month, year)

# Generated at 2022-06-23 21:39:24.684166
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cid = payment.cid()
    assert isinstance(cid, int), '{} is not int'.format(cid)
    assert cid < 10000 and cid >= 1000, '{} is not correct'.format(cid)


# Generated at 2022-06-23 21:39:26.521201
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Test 1
    print(Payment().cid())



# Generated at 2022-06-23 21:39:30.559362
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date() == '09/20'
    assert payment.credit_card_expiration_date(minimum=16, maximum=25) == '11/21'
    return True


# Generated at 2022-06-23 21:39:33.690782
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    for i in range(1000):
        address = payment.bitcoin_address()
        assert address[0] in ['1', '3']  # check address type
        assert len(address) == 35  # check address length


# Generated at 2022-06-23 21:39:35.399093
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment(seed=777)
    assert p.cid() == 7452



# Generated at 2022-06-23 21:39:37.907290
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert isinstance(payment.cid(), int)
    assert len(str(payment.cid())) == 4
    assert payment.cid() < 10000
    assert payment.cid() > 999


# Generated at 2022-06-23 21:39:39.931214
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():

    p = Payment('en')
    p.credit_card_owner()
    assert p.credit_card_owner()
    print('Successfully tested method credit_card_owner of class Payment')


# Generated at 2022-06-23 21:39:42.264025
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    r = Payment()
    r.credit_card_expiration_date()
    r.credit_card_expiration_date(10, 10)


# Generated at 2022-06-23 21:39:44.426374
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    assert Payment().ethereum_address() == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'


# Generated at 2022-06-23 21:39:55.910535
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    
    test_obj = Payment()
    res = test_obj.credit_card_owner(gender=test_obj.random.choice(Gender))
    resp = {}

# Generated at 2022-06-23 21:40:02.082158
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Generate random credit card owner
    my_obj = Payment()
    my_owner = my_obj.credit_card_owner()
    print("\nTest for method credit_card_owner of class Payment")
    print("Credit card owner:")
    print("\t", my_owner['owner'])
    print("Credit card number:")
    print("\t", my_owner['credit_card'])
    print("Credit card expiration date:")
    print("\t", my_owner['expiration_date'])



# Generated at 2022-06-23 21:40:07.797858
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # Init Payment class
    payment = Payment()
    
    # Call method bitcoin_address
    bitcoin_address = payment.bitcoin_address()
    
    # Check address type
    assert type(bitcoin_address) == str, "Check address type"
    
    # Check address length
    assert len(bitcoin_address) == 35, "Check address length"

# Generated at 2022-06-23 21:40:10.018617
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    t_card_type = Payment('en').credit_card_network()
    # assert t_card_type in CardType.__members__
    print(t_card_type)

# test_Payment_credit_card_network()


