

# Generated at 2022-06-23 21:30:11.892005
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # assert Payment().cvv() is not None
    print(Payment().cvv())


# Generated at 2022-06-23 21:30:13.827379
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert type(payment.cvv()) == int


# Generated at 2022-06-23 21:30:14.963389
# Unit test for method cvv of class Payment
def test_Payment_cvv():

    r = Payment(seed=0)
    assert r.cvv() == 379

# Generated at 2022-06-23 21:30:19.956223
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Check that the cvv function works correctly"""
    payment = Payment('en')
    cvv = payment.cvv()
    assert len(str(cvv)) == 3
    assert type(cvv) == int
    assert cvv >= 100
    assert cvv <= 999

# Generated at 2022-06-23 21:30:21.042953
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()


# Generated at 2022-06-23 21:30:23.318720
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    a=Payment()
    # call method to test
    b=a.cvv()
    assert b >= 100 and b <= 999

# Generated at 2022-06-23 21:30:27.074308
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    cr_card_owner = Payment()
    owner_list = []
    for i in range(100):
        owner = cr_card_owner.credit_card_owner()
        owner_list.append(owner)
    print(owner_list)

if __name__ == "__main__":
    test_Payment_credit_card_owner()

# Generated at 2022-06-23 21:30:30.063042
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment(seed=1)
    card_network = payment.credit_card_network()
    assert card_network == 'Visa'


# Generated at 2022-06-23 21:30:36.420578
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    assert len(Payment().credit_card_number()) == 17
    assert len(Payment().credit_card_number(CardType.VISA)) == 17
    assert len(Payment().credit_card_number(CardType.MASTER_CARD)) == 17
    assert len(Payment().credit_card_number(CardType.AMERICAN_EXPRESS)) == 16

# Generated at 2022-06-23 21:30:40.578472
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    network = p.credit_card_network()
    print('network = ' + network)
    assert network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:30:43.965651
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment(seed=10)
    assert payment.random.getrandbits(10) == 1570766453
    return payment

# Generated at 2022-06-23 21:30:48.304062
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    paypal = payment.paypal()
    assert isinstance(paypal, str)
    assert re.match(r"[\w\.+-]+@[\w\.-]+", paypal)


# Generated at 2022-06-23 21:30:50.090014
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment('en')
    result = p.credit_card_network()
    print(result)


# Generated at 2022-06-23 21:30:55.468155
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Case: gender = None
    credit_card_owner = Payment().credit_card_owner()
    assert credit_card_owner.get("credit_card") != None
    assert credit_card_owner.get("expiration_date") != None
    assert credit_card_owner.get("owner") != None
    # Case: gender = Gender.MALE
    credit_card_owner = Payment().credit_card_owner(Gender.MALE)
    assert credit_card_owner.get("credit_card") != None
    assert credit_card_owner.get("expiration_date") != None
    assert credit_card_owner.get("owner") != None
    # Case: gender = Gender.FEMALE
    credit_card_owner = Payment().credit_card_owner(Gender.FEMALE)
    assert credit_card_owner.get

# Generated at 2022-06-23 21:30:58.110186
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment("en")
    assert isinstance(payment.cid(), int)


# Generated at 2022-06-23 21:31:06.418385
# Unit test for constructor of class Payment
def test_Payment():
    my_payment = Payment()
    my_payment.cid()
    my_payment.paypal()
    my_payment.bitcoin_address()
    my_payment.ethereum_address()
    my_payment.credit_card_network()
    my_payment.credit_card_number(CardType.VISA)
    my_payment.credit_card_expiration_date()
    my_payment.cvv()
    my_payment.credit_card_owner(Gender.MALE)
    my_payment.credit_card_owner(Gender.FEMALE)
    my_payment.credit_card_owner()

# Generated at 2022-06-23 21:31:08.739358
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    print('Test paypal method of class Payment')
    p = Payment()
    print(p.paypal())


# Generated at 2022-06-23 21:31:12.596739
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    r = p.cvv()
    assert r is not None
    assert type(r) == int
    assert r >= 100
    assert r <= 999


# Generated at 2022-06-23 21:31:14.616230
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment('zh')
    for i in range(10):
        print(payment.paypal())


# Generated at 2022-06-23 21:31:16.811394
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    x = Payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(x) == 17
    assert x[:2] in ['37', '34']

# Generated at 2022-06-23 21:31:19.736178
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Test for method ethereum_address of class Payment."""
    p = Payment()
    result = p.ethereum_address()
    assert len(result) == 42

# Generated at 2022-06-23 21:31:23.112344
# Unit test for method cid of class Payment
def test_Payment_cid():
    provider = Payment()
    cid_ = provider.cid()
    print(cid_)
    assert len(str(cid_)) == 4
    assert isinstance(cid_, int)


# Generated at 2022-06-23 21:31:25.080478
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    credit_number = Payment().credit_card_number()
    assert len(credit_number.replace(' ', '')) == 16

# Generated at 2022-06-23 21:31:36.875403
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment(seed = 0)
    assert payment.credit_card_owner(gender =Gender.MALE) == {"credit_card":"4153 1071 9292 8139", "expiration_date":"05/20", "owner":"JEREMY ALLEN"}

    payment1 = Payment(seed = 0)
    assert payment1.credit_card_owner(gender =Gender.FEMALE) == {"credit_card":"4153 1071 9292 8139", "expiration_date":"05/20", "owner":"JEREMY ALLEN"}

    payment2 = Payment(seed = 0)
    assert payment2.credit_card_owner(gender =Gender.MALE) == {"credit_card":"4153 1071 9292 8139", "expiration_date":"05/20", "owner":"JEREMY ALLEN"}

    payment3 = Payment

# Generated at 2022-06-23 21:31:39.375168
# Unit test for method cid of class Payment
def test_Payment_cid():
    x = Payment()
    print(x.cid())

# Generated at 2022-06-23 21:31:41.339559
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date() == '10/21'

# Generated at 2022-06-23 21:31:44.461608
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert len(str(payment.cid())) == 4


# Generated at 2022-06-23 21:31:46.330899
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment()
    assert provider.credit_card_network() in CREDIT_CARD_NETWORKS # Noqa: W503


# Generated at 2022-06-23 21:31:47.862976
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    print(payment.cid())


# Generated at 2022-06-23 21:31:50.384959
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment('en')
    assert payment.cvv() > 0 and payment.cvv() <= 999;


# Generated at 2022-06-23 21:31:52.044416
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Unit test for method credit_card_network of class Payment."""
    p = Payment()
    for i in range(10):
        p.credit_card_network()


# Generated at 2022-06-23 21:31:56.156778
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    import random

    # Testing with random output
    while True:
        test = Payment(random.Random(1))
        owner = test.credit_card_owner()
        if 5 == owner['credit_card'] == owner['owner']:
            break

    assert owner == {'credit_card': '5', 'expiration_date': '08/23', 'owner': '5'}

# Generated at 2022-06-23 21:31:59.118019
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    random.seed(1)
    assert Payment().cvv() == 456



# Generated at 2022-06-23 21:32:00.853743
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    a = Payment()
    result = a.bitcoin_address()
    assert len(result)==34

# Generated at 2022-06-23 21:32:02.675107
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    result = Payment().bitcoin_address()
    assert len(result) == 34


# Generated at 2022-06-23 21:32:05.051416
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    result = payment.credit_card_network()
    assert isinstance(result, str) and len(result) > 0


# Generated at 2022-06-23 21:32:10.597134
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    number = '5229 3452 2117 0910'
    exp_date = '07/21'
    owner = 'Haiti BESSE'
    result = Payment('en').credit_card_owner()
    assert result['credit_card'] == number
    assert result['expiration_date'] == exp_date
    assert result['owner'] == owner

# Generated at 2022-06-23 21:32:13.054408
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Arrange
    p = Payment(seed=42)

    # Act
    result = p.cid()

    # Assert
    assert result == '9198'


# Generated at 2022-06-23 21:32:14.611600
# Unit test for constructor of class Payment
def test_Payment():
    pass

# Generated at 2022-06-23 21:32:16.516410
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    cc = p.credit_card_number()
    assert len(cc) == 19

# Generated at 2022-06-23 21:32:21.998387
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment"""
    from unittest import TestCase
    from mimesis import Payment
    payment=Payment()
    payment.random.seed(2)
    address = payment.ethereum_address()
    assert address == '0xf1f2d0c89b574097e1e8c031e76d62d7f34e0510'

# Generated at 2022-06-23 21:32:23.314445
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    assert Payment.credit_card_network('en') in CREDIT_CARD_NETWORKS

# Generated at 2022-06-23 21:32:24.965397
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    pay = Payment('en')
    print(pay.credit_card_owner())




# Generated at 2022-06-23 21:32:27.794165
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment(random=random)
    result = payment.credit_card_network()
    assert result == CREDIT_CARD_NETWORKS[0] or result == CREDIT_CARD_NETWORKS[1]


# Generated at 2022-06-23 21:32:29.509758
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    print(Payment().paypal())

# Generated at 2022-06-23 21:32:31.454944
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Unit test for method cvv of class Payment."""
    payment = Payment('en')
    print(payment.cvv())

# Generated at 2022-06-23 21:32:34.588332
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert isinstance(payment, Payment) is True
    assert isinstance(payment, BaseProvider) is True
    assert payment.random.getrandbits(100) is not None


# Generated at 2022-06-23 21:32:36.396025
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment('en')
    print(payment.cid())



# Generated at 2022-06-23 21:32:40.741227
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    p = payment.credit_card_owner()
    print(p)
    # {'credit_card': '5139 4874 4089 5258', 'expiration_date': '12/17', 'owner': 'TAMARA COOKSON'}


# Generated at 2022-06-23 21:32:45.436383
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert len(Payment.credit_card_expiration_date.__doc__) > 0
    result = Payment().credit_card_expiration_date()
    assert re.search(r'\d{2}/\d{2}', result) is not None
    assert len(result) == 5



# Generated at 2022-06-23 21:32:48.435355
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.VISA
    card_number = Payment().credit_card_number(card_type)
    assert card_type.name.lower() in card_number
    assert len(card_number.replace(' ', '')) == 16


# Generated at 2022-06-23 21:32:50.764695
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    assert p.credit_card_owner()['owner'] == 'TAYLOR SMITH'



# Generated at 2022-06-23 21:32:52.098186
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    payment.paypal()
    assert True


# Generated at 2022-06-23 21:32:54.012469
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    ethereum_address = payment.ethereum_address()
    assert isinstance(ethereum_address, str)
    assert len(ethereum_address) == 42


# Generated at 2022-06-23 21:32:56.897145
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    ethAddress = Payment()
    assert re.match(r'^0x[a-fA-F0-9]{40}$', ethAddress.ethereum_address()), True


# Generated at 2022-06-23 21:33:07.048479
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Mock random.randint value
    global mock_randint
    mock_randint = -1
    def mock_randint_return(*args, **kwargs):
        global mock_randint

        if mock_randint == -2:
            return -2
        
        if mock_randint == -1:
            mock_randint = -2
            return 16
        elif mock_randint == -2:
            mock_randint = -3
            return 21
        elif mock_randint == -3:
            mock_randint = -4
            return 1
        elif mock_randint == -4:
            mock_randint = -5
            return 4999
        elif mock_randint == -5:
            mock_randint = -6
            return 12

# Generated at 2022-06-23 21:33:08.848445
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment(seed=100)
    payment.paypal()
    assert payment.paypal() == 'sherlyn_4@hotmail.com'


# Generated at 2022-06-23 21:33:09.809260
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    assert Payment().paypal() == Payment().paypal()


# Generated at 2022-06-23 21:33:12.198416
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    cvv_code = Payment().cvv()
    assert cvv_code >= 100 and cvv_code <= 999


# Generated at 2022-06-23 21:33:13.822493
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    x = Payment()
    print(x.credit_card_network())


# Generated at 2022-06-23 21:33:24.481098
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    print("\n\nUnit test for method credit_card_expiration_date of class Payment")
    payment = Payment()
    month = payment.random.randint(1, 12)
    year = payment.random.randint(16, 25)
    day = payment.random.randint(1, 31)
    minimum = 16
    maximum = 25
    print("\ntesting with value: month: {0} year: {1} day: {2} minimum: {3} maximum: {4}".format(month, year, day, minimum, maximum))

    value = (month, year, day, minimum, maximum)
    if month == 0 or maximum < minimum:
        print("Test failed because of invalid value")
    elif day == 0:
        print("Test failed because of invalid value")
    elif month > 12:
        print

# Generated at 2022-06-23 21:33:27.637137
# Unit test for constructor of class Payment
def test_Payment():
    from mimesis import Payment
    from mimesis.enums import CardType
    result = Payment()
    assert result.credit_card_number(CardType.VISA)
    assert result.credit_card_expiration_date(20, 30)
    assert result.credit_card_owner(0)

# Generated at 2022-06-23 21:33:29.746671
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    assert 'Visa' in Payment().credit_card_network()
    assert 'MasterCard' in Payment().credit_card_network()
    assert 'American Express' in Payment().credit_card_network()


# Generated at 2022-06-23 21:33:31.799755
# Unit test for method cid of class Payment
def test_Payment_cid():
	p = Payment()
	res = p.cid()
	assert len(res) == 4
	

# Generated at 2022-06-23 21:33:35.435041
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    ethereum_address_list = []
    for i in range(1000):
        address = p.ethereum_address()
        ethereum_address_list.append(address)
    assert len(ethereum_address_list) == 1000


# Generated at 2022-06-23 21:33:36.962510
# Unit test for method cid of class Payment
def test_Payment_cid():
    pass


# Generated at 2022-06-23 21:33:39.435836
# Unit test for constructor of class Payment
def test_Payment():
    # Check for constructor of class Payment
    payment = Payment()
    assert payment is not None
    assert isinstance(payment, Payment)



# Generated at 2022-06-23 21:33:42.422832
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner()
    print(owner)
    assert type(owner) == dict
    # assert type(owner) == Payment.Meta


# Generated at 2022-06-23 21:33:50.949706
# Unit test for method cid of class Payment
def test_Payment_cid():
    from mimesis.enums import Gender
    from mimesis.mimesis import Mimesis
    from mimesis.providers.enums import CardType

    mimesis = Mimesis(locale='en')
    payment = mimesis.payment

    cid = payment.cid()
    assert 1001 <= cid <= 9999

    credit_card_number = payment.credit_card_number()
    assert len(credit_card_number) == 19

    credit_card_number_with_type = payment.credit_card_number(CardType.VISA)
    assert len(credit_card_number_with_type) == 19

    bitcoin_address = payment.bitcoin_address()
    assert len(bitcoin_address) == 34

    cvv = payment.cvv()
    assert 100 <= cvv <= 999



# Generated at 2022-06-23 21:33:52.687223
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert isinstance(Payment.cvv(), int)


# Generated at 2022-06-23 21:33:57.729144
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    expected = {
        'credit_card': '4850 0129 8977 0622',
        'expiration_date': '06/21',
        'owner': 'KERRIE JACOBS'
    }
    actual = payment.credit_card_owner()
    assert actual == expected

# Generated at 2022-06-23 21:34:02.592968
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Initiate a instance of the class Payment
    Payment_ = Payment()
    # Get the ethereum address
    test_address = Payment_.ethereum_address()
    # Output the ethereum address
    print(test_address)


# Generated at 2022-06-23 21:34:05.556483
# Unit test for method cid of class Payment
def test_Payment_cid():

    payment = Payment()
    cid = payment.cid()
    print(cid)
    assert cid >= 1000 and cid <= 9999


# Generated at 2022-06-23 21:34:07.426214
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    result = payment.cvv()
    assert result >= 100 and result <= 999


# Generated at 2022-06-23 21:34:12.207934
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """ """
    p = Payment()
    assert p.credit_card_expiration_date() != p.credit_card_expiration_date()
    assert p.credit_card_expiration_date(minimum=18, maximum=20) != p.credit_card_expiration_date(minimum=18, maximum=20)


# Generated at 2022-06-23 21:34:14.851944
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis.providers.payment import Payment
    payment = Payment()
    card_networks = payment.credit_card_network()
    print(card_networks)
    assert card_networks


# Generated at 2022-06-23 21:34:21.797818
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    card_number = p.credit_card_number(CardType.VISA)
    print(card_number)
    card_number = p.credit_card_number(CardType.MASTER_CARD)
    print(card_number)
    card_number = p.credit_card_number(CardType.AMERICAN_EXPRESS)
    print(card_number)

if __name__ == '__main__':
    for i in range(2):
        test_Payment_credit_card_number()

# Generated at 2022-06-23 21:34:24.941075
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    generator = Payment()
    example = generator.bitcoin_address()
    assert example[0] == '3' or '1'
    for i in range(1, 34):
        assert example[i] in string.ascii_letters + string.digits
    assert len(example) == 34


# Generated at 2022-06-23 21:34:31.100986
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    card_owner = payment.credit_card_owner()
    print(card_owner)
    print(type(card_owner))
    print(card_owner.get('credit_card'))
    print(card_owner.get('expiration_date'))
    print(card_owner.get('owner'))


# Generated at 2022-06-23 21:34:33.530725
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    a = Payment()
    ret = a.paypal()
    assert ret == 'wood902@gmail.com'


# Generated at 2022-06-23 21:34:42.612488
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    from mimesis.enums import Gender
    from mimesis.enums import CardType
    payment = Payment(seed=12345)
    owner = payment.credit_card_owner(gender=Gender.FEMALE)
    #print(owner['owner'])
    assert owner['owner'] == 'KIMBERLY GARCÍA', "Error owner"
    #print(owner['credit_card'])
    assert owner['credit_card'] == '4455 5299 1152 2450', "Error credit card"
    #print(owner['expiration_date'])
    assert owner['expiration_date'] == '03/19', "Error expiration date"
    #print(payment.credit_card_number(CardType.VISA))

# Generated at 2022-06-23 21:34:44.381381
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert isinstance(payment.cvv(), int)
    assert isinstance(payment.cvv(seed=0), int)
    assert payment.cvv(seed=0) == 345


# Generated at 2022-06-23 21:34:45.758382
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    print(payment.credit_card_owner())

# Generated at 2022-06-23 21:34:47.624951
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    # Testing for exist network
    test_credit_card_network = p.credit_card_network()
    assert test_credit_card_network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:34:53.258215
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p.cid() > 1000
    assert p.paypal() != ""
    assert p.bitcoin_address() != ""
    assert p.ethereum_address() != ""
    assert p.credit_card_network() != ""
    # assert p.credit_card_number() == ""
    # assert p.credit_card_expiration_date() == ""
    # assert p.credit_card_owner() == ""
    assert p.cvv() > 100

# Generated at 2022-06-23 21:34:56.217798
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    assert payment.credit_card_owner(Gender.MALE) != payment.credit_card_owner(Gender.FEMALE)


# Generated at 2022-06-23 21:35:02.984582
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """ Tests the methode credit_card_number of the class Payment
        The test is successful if the return value of test_Payment_credit_card_number
        is equal to the length of 16.
    """
    testPaymentMethod = Payment()
    try:
        assert len(testPaymentMethod.credit_card_number()) == 16
        ## returns true if the credit card number is a string
        assert isinstance(testPaymentMethod.credit_card_number(), str)
        ## returns true if the credit card number starts with 4
        assert testPaymentMethod.credit_card_number()[0] == "4"
        print('The method credit_card_number of the class Payment works')
    except AssertionError:
        print('The method credit_card_number of the class Payment has a problem')


# Generated at 2022-06-23 21:35:04.529920
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert payment.paypal()


# Generated at 2022-06-23 21:35:07.246126
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """testing method paypal of class Payment"""
    #given
    p1 = Payment()
    p2 = Payment()

    #if
    a = p1.paypal()
    b = p2.paypal()

    #then
    assert a != b


# Generated at 2022-06-23 21:35:10.853147
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment("en")
    print(payment.credit_card_network())
    assert len(payment.credit_card_network()) != 0


# Generated at 2022-06-23 21:35:15.418904
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    flag_fail= False
    p = Payment('en')
    sample_1 = p.ethereum_address()
    sample_2 = p.ethereum_address()
    if(sample_1==sample_2):
        flag_fail= True
    assert flag_fail == False

# Generated at 2022-06-23 21:35:17.901132
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    from mimesis.classes import Payment
    from mimesis.enums import Gender

    p=Payment('en')

    assert p.paypal()  # Test for method paypal of class Payment


# Generated at 2022-06-23 21:35:21.074589
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    obj_pay = Payment(seed=123)
    obj_pay.cvv()
    assert obj_pay.cvv() == 484

# Generated at 2022-06-23 21:35:25.767583
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner(Gender.FEMALE)
    assert isinstance(owner, dict)
    assert 'credit_card' in owner.keys()
    assert 'expiration_date' in owner.keys()
    assert 'owner' in owner.keys()


# Generated at 2022-06-23 21:35:28.759457
# Unit test for method cid of class Payment
def test_Payment_cid():
	# Test whether the function cid of class Payment returns random integers as output
	for i in range(10):
		assert isinstance(Payment().cid(), int) == True  


# Generated at 2022-06-23 21:35:32.238124
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cvv = payment.cvv()
    if cvv < 100 or cvv > 999:
        assert False, "test_Payment_cvv failed: out of range"

    print("test_Payment_cvv success")
    return True


# Generated at 2022-06-23 21:35:34.723682
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from pprint import pprint
    pp = pprint
    payment = Payment()
    pprint(payment.credit_card_owner())

# unit test for method credit_card_number of class Payment

# Generated at 2022-06-23 21:35:37.333305
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    import datetime
    from mimesis.enums import Gender
    assert isinstance(Payment().credit_card_owner(), dict)
    assert Payment().credit_card_owner()


# Generated at 2022-06-23 21:35:39.798377
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment(seed=1)
    assert payment.bitcoin_address() == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'

# Generated at 2022-06-23 21:35:41.329292
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment(seed=1337)
    res = payment.cvv()
    assert(res == 395)



# Generated at 2022-06-23 21:35:42.113247
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert len(Payment().cvv()) == 3

# Generated at 2022-06-23 21:35:47.851817
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    provider = Payment(seed=1234567890)
    test_value = provider.bitcoin_address()
    real_value = '1J7mdg5rbQyUHENYdx39WVWK7fsLpEoXZy'
    assert test_value == real_value


# Generated at 2022-06-23 21:35:50.089493
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.VISA
    payment = Payment(seed=42)
    number = payment.credit_card_number(card_type)
    assert number == "4477 4998 5067 7188"

# Generated at 2022-06-23 21:35:52.750577
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    print(p.bitcoin_address())


# Generated at 2022-06-23 21:35:55.429226
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment('z')
    assert payment.cvv() == zprod.product(
        zbase.integers(1, 9), zbase.integers(0, 9), zbase.integers(0, 9),
        zbase.integers(0, 9))


# Generated at 2022-06-23 21:35:57.970057
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    from mimesis.enums import Gender
    from mimesis.enums import CardType

    payment = Payment()
    paypal = payment.paypal()
    person = Person('en', seed=payment.seed)
    assert(person.email() == paypal)


# Generated at 2022-06-23 21:36:00.856844
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Unit test for credit_card_network method of class Payment."""
    p = Payment()
    result = p.credit_card_network()
    print(result)
    pass


# Generated at 2022-06-23 21:36:02.003760
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
	assert Payment().credit_card_network() == 'Diners Club'


# Generated at 2022-06-23 21:36:11.236953
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    def loop_iterates(start, end, length, num_of_iterations):
        nums = 0
        for num in range(start, end):
            str_num = str(num)
            while len(str_num) < length - 1:
                str_num += '0'
            if luhn_checksum(str_num):
                nums += 1
        return nums

    assert loop_iterates(4000, 4999, 16, 10) == 100
    assert loop_iterates(5100, 5599, 16, 10) == 500
    assert loop_iterates(2221, 2720, 16, 10) == 500

# Generated at 2022-06-23 21:36:12.757785
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    _payment = Payment('en')
    _credit_card_network = _payment.credit_card_network()


# Generated at 2022-06-23 21:36:15.593857
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    assert (payment.credit_card_number() != payment.credit_card_number())


# Generated at 2022-06-23 21:36:20.674045
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert isinstance(payment.cid(), int)
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS
    assert isinstance(payment.credit_card_number(), str)
    assert isinstance(payment.credit_card_expiration_date(), str)
    assert isinstance(payment.credit_card_owner(), dict)

# Generated at 2022-06-23 21:36:22.054804
# Unit test for constructor of class Payment
def test_Payment():
    assert Payment() is not None

# Generated at 2022-06-23 21:36:23.149873
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert Payment.cvv() in range(100,999)

# Generated at 2022-06-23 21:36:26.663788
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    owner = Payment().credit_card_owner()
    assert len(owner['credit_card'].split(' ')) == 4
    assert len(owner['expiration_date']) == 5
    assert owner['owner']

# Generated at 2022-06-23 21:36:29.070062
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    payment.seed(hash("BANKING"))
    for _ in range(1000):
        payment.credit_card_network()


# Generated at 2022-06-23 21:36:32.027391
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    assert payment.bitcoin_address() == "1GtCJwPpZcYfZFtGXBNW6xzH7eMmTkTbFc"


# Generated at 2022-06-23 21:36:37.239445
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """
    Unit test for method credit_card_network of class Payment
    """

    # Create instance of class Payment
    test_instance = Payment()

    # Create list for results of method credit_card_network
    credit_card_network_list = []
    for _ in range(100):
        credit_card_network_list.append(test_instance.credit_card_network())

    # Check the different between list of results
    assert (len(set(credit_card_network_list))) == len(credit_card_network_list)

# Generated at 2022-06-23 21:36:40.587950
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    # If a list has 5 values, then it must have 4 commas.
    assert len(re.findall(',', str(payment.credit_card_expiration_date(16, 20)))) == 4

# Generated at 2022-06-23 21:36:44.099315
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    for i in range(0, 100):
        cvv = payment.cvv()
        print(cvv)

#Unit test for method credit_card_number of class Payment

# Generated at 2022-06-23 21:36:50.393563
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    p.set_random_seed(1234)
    assert p.credit_card_number() == '4333 2882 6027 4490'
    assert p.credit_card_number(CardType.MASTER_CARD) == '5245 6926 8679 2182'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3763 248330 83265'

# Generated at 2022-06-23 21:36:54.831261
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Test credit_card_network method."""
    expected = ('AmericanExpress', 'JCB', 'Discover', 'Visa', 'Maestro', 'Unionpay', 'DinersClub-CarteBlanche', 'MasterCard', 'DinersClub-International', 'DinersClub-USA&Canada', 'InstaPayment')
    result = Payment().credit_card_network()
    assert result in expected



# Generated at 2022-06-23 21:36:55.909338
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment('en')
    print(p.credit_card_number())

# Generated at 2022-06-23 21:36:58.408295
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cid = payment.cid()
    assert cid <= 9999 and cid >= 1000
    assert len(str(cid)) == 4
    print(f"CID: {cid}")


# Generated at 2022-06-23 21:37:03.002845
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    test = Payment()
    assert test.credit_card_owner() == {
        'credit_card': '4191 6303 7230 1783',
        'expiration_date': '07/21',
        'owner': 'JOHATHAN KENNEDY',
    }


# Generated at 2022-06-23 21:37:08.903091
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    import mimesis
    payment = mimesis.Payment('de')
    address = payment.bitcoin_address()
    # ValueError: too many values to unpack (expected 2)
    # address = (x,y)
    # ValueError: too many values to unpack (expected 2)
    # address = (x,y,z)
    # TypeError: 'int' object is not subscriptable
    # address = [].append("a")
    print("Bitcoin address: " + address)


# Generated at 2022-06-23 21:37:13.244442
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """
    Unit test for method paypal of class Payment
    """
    payment = Payment('pl')

    assert payment.paypal() == "ekaterina.wozniak@gmail.com"

# Generated at 2022-06-23 21:37:15.458469
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS

# Generated at 2022-06-23 21:37:19.951125
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert Payment().bitcoin_address() in ["1f1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX",
                                           "3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX"]
    

# Generated at 2022-06-23 21:37:22.653694
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    result = p.bitcoin_address()
    assert len(result) == 35
    assert result[0] == '1' or result[0] == '3'

# Generated at 2022-06-23 21:37:26.269585
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """
    Test for random expiration date generation
    """
    p = Payment()
    assert p.credit_card_expiration_date() != p.credit_card_expiration_date()



# Generated at 2022-06-23 21:37:28.754969
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    expected = '4455 5299 1152 2450'
    actual = Payment().credit_card_number()
    assert actual == expected

# Generated at 2022-06-23 21:37:33.664412
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    ethereum_list = []
    payment = Payment()
    for i in range(50):
        ethereum_address = payment.ethereum_address()
        assert len(ethereum_address) == 42
        assert ethereum_address[0:2] == '0x'
        assert ethereum_address not in ethereum_list
        ethereum_list.append(ethereum_address)

# Generated at 2022-06-23 21:37:39.701912
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    import random
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.payment import Payment
    p = Payment('en', random=random.Random(1))
    a = Address('en', random=random.Random(1))
    ad = p.ethereum_address()
    print("address value: ", ad)


# Generated at 2022-06-23 21:37:43.658745
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    result = p.ethereum_address()
    assert len(result) == 42
    assert result[0:2] == "0x"
    assert result[2:].isalnum()


if __name__ == "__main__":
    test_Payment_ethereum_address()

# Generated at 2022-06-23 21:37:45.457752
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    Paymentx = Payment('en', seed=0)
    bitcoin_address = Paymentx.bitcoin_address()
    assert len(bitcoin_address) == 34


# Generated at 2022-06-23 21:37:47.893410
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import Gender
    generator = Payment('en', seed=4556)
    result = generator.credit_card_expiration_date(minimum = 16, maximum = 25)
    assert (result == '06/17')


# Generated at 2022-06-23 21:37:52.094206
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment(seed=1) # seed for reproducible results
    assert p.ethereum_address() == '0x769b5a0cffcc837ea3d3ff43617690e8832f9f64'

# Generated at 2022-06-23 21:37:53.973267
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment(seed=42)
    assert p.cvv() == 787


# Generated at 2022-06-23 21:37:56.381332
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    a = p.credit_card_network()
    assert isinstance(a, str)
    assert a in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:37:59.402416
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment=Payment()
    assert payment.bitcoin_address()==payment.bitcoin_address()


# Generated at 2022-06-23 21:38:02.262985
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    a = p.cvv()
    assert isinstance(a, int)
    assert len(str(a)) == 3


# Generated at 2022-06-23 21:38:08.482075
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment
    month_result = payment.credit_card_expiration_date(payment).split('/')[0]
    assert month_result == 1 or month_result == 2 or month_result == 3 or month_result == 4 or month_result == 5 or month_result == 6 or month_result == 7 or month_result == 8 or month_result == 9 or month_result == 10 or month_result == 11 or month_result == 12


# Generated at 2022-06-23 21:38:13.680119
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    print(Payment.Meta.name)
    print(Payment().ethereum_address())
    print(Payment().ethereum_address())
    print(Payment().ethereum_address())
    print(Payment().ethereum_address())
    print(Payment().ethereum_address())

test_Payment_ethereum_address()

# Generated at 2022-06-23 21:38:14.628036
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # Arrange

    # Act
    result = Payment().credit_card_expiration_date()
    # Assert
    assert isinstance(result, str)

# Generated at 2022-06-23 21:38:16.120992
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment('en')
    print(p.paypal())


# Generated at 2022-06-23 21:38:20.249786
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment("en")
    credit_card_network = p.credit_card_network()
    assert credit_card_network in ['Maestro', 'Visa', 'JCB', 'American Express', 'MasterCard', 'Diners Club', 'Discover', 'China UnionPay', 'Carte Blanche']


# Generated at 2022-06-23 21:38:23.321283
# Unit test for method cid of class Payment
def test_Payment_cid():
    card = Payment()
    cid = card.cid()
    assert isinstance(cid, int)



# Generated at 2022-06-23 21:38:30.149484
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import random
    random.seed(0)
    payment = Payment('en')
    visa_card = payment.credit_card_number()
    master_card = payment.credit_card_number(CardType.MASTER_CARD)
    american_express_card = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert visa_card == '4958 8245 9405 5267'
    assert master_card == '5152 0164 6473 1065'
    assert american_express_card == '3777 371696 42375'



# Generated at 2022-06-23 21:38:38.525231
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number(CardType.MASTER_CARD) == "5303 5121 1176 6568"
    assert p.credit_card_number(CardType.VISA) == "4532 3785 8244 0087"
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == "3737 898533 85637"
    from mimesis.exceptions import NonEnumerableError
    try:
        p.credit_card_number(CardType.DISCOVER)
    except NonEnumerableError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 21:38:40.299805
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    Payment_test = Payment('en')
    assert type(Payment_test.cvv()) == int

# Generated at 2022-06-23 21:38:47.738820
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    if __name__ == '__main__':
        owner = Payment().credit_card_owner()
        assert owner.get("credit_card") != None
        assert owner.get("expiration_date") != None
        assert owner.get("owner") != None
"""
TEST_CODE_FOR_Payment_credit_card_owner = {
    'test_Payment_credit_card_owner':
        ''' 
        card = Payment().credit_card_owner()
        assert card.get("credit_card") != None
        assert card.get("expiration_date") != None
        assert card.get("owner") != None
        ''',
}

if __name__ == '__main__':
    print(Payment().credit_card_owner())
    import doctest
    doctest.testmod()
"""

# Generated at 2022-06-23 21:38:50.497367
# Unit test for method cid of class Payment
def test_Payment_cid():
  print("\n=== test method cid of class Payment ===\n")
  b = Payment()
  c = b.cid()
  print(c)


# Generated at 2022-06-23 21:38:54.626974
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    result = Payment(seed=42).ethereum_address()
    assert result == "0x4270971c974a6b5e5cfeea5b5c619bcd6c5da01b"

# Generated at 2022-06-23 21:39:03.418646
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import CardType
    from mimesis.enums import Gender
    from mimesis.excpetions import NonEnumerableError
    from mimesis.exceptions import MaskNotFound
    from mimesis.providers.payment import Payment

    payment = Payment()
    payment.seed(12345)
    d = payment.credit_card_expiration_date(16, 25)

    d = payment.credit_card_expiration_date()
    assert (d[0] == '0') | (d[0] == '1')
    assert d[2] == '/'
    assert int(d[3]) >= 6
    assert int(d[3]) < 10
    assert int(d[4]) >= 0
    assert int(d[4]) < 10

    d = payment.credit_card_ex

# Generated at 2022-06-23 21:39:06.026898
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment('en')
    print("Test Payment method cid:")
    print(payment.cid())


# Generated at 2022-06-23 21:39:06.967496
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    assert payment.bitcoin_address()  != None

# Generated at 2022-06-23 21:39:08.615890
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    assert p.credit_card_owner()['owner'] is not None

# Generated at 2022-06-23 21:39:19.474517
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment('ru')
    # p.bitcoin_address() => '1TSvfLX9rwo6xJMP6G5y5Y5bV7DU6pwfV' - FAILED
    # p.bitcoin_address() => '1NkaL5Y5NAgf5pwfV7DU6pwfV7DU6pwfV' - FAILED
    # p.bitcoin_address() => '1RiAE6uzMj2ZifT9YgRrkSgzQXRiAE6uz' - FAILED
    res = p.bitcoin_address()
    assert len(res) == 35, "len(res) = {}, expected = 35".format(len(res))

# Generated at 2022-06-23 21:39:22.043515
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # payment.py
    # Test method paypal of class Payment
    pm = Payment()
    assert pm.paypal() == pm.__person.email()

# Generated at 2022-06-23 21:39:24.579931
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    assert re.match(r'[13][a-km-zA-HJ-NP-Z0-9]{33}', p.bitcoin_address())


# Generated at 2022-06-23 21:39:26.369617
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment is not None
    assert payment.random is not None

# Generated at 2022-06-23 21:39:29.674558
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():  # noqa: D103
    payment = Payment()
    credit_card_owner = payment.credit_card_owner()
    assert isinstance(credit_card_owner, dict)

# Generated at 2022-06-23 21:39:32.483061
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    random_network = payment.credit_card_network()
    assert isinstance(random_network, str)
    assert random_network in CREDIT_CARD_NETWORKS

# Generated at 2022-06-23 21:39:37.443518
# Unit test for method cid of class Payment
def test_Payment_cid():
    from mimesis.enums import  CardType

    payment = Payment('en')
    cc_type = CardType.MASTER_CARD
    cc_num1 = payment.credit_card_number(card_type=cc_type)
    cc_num2 = payment.credit_card_number(card_type=cc_type)
    print(cc_num1)
    print(cc_num2)

# Generated at 2022-06-23 21:39:41.307194
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    seed = 123
    payment = Payment(seed=seed)
    assert payment.cvv() == 435
    assert payment.cvv() == 0
    assert payment.cvv() == 933
    assert payment.cvv() == 533
    assert payment.cvv() == 15


# Generated at 2022-06-23 21:39:43.844010
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """
    Test ethereum_address() method
    :return:
    """
    payment = Payment()
    payment.ethereum_address()
    print("eth address:", payment.ethereum_address())


# Generated at 2022-06-23 21:39:44.939478
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment('en')
    print(p.credit_card_owner())

# Generated at 2022-06-23 21:39:47.290675
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Unit test for method cid of class Payment."""
    for i in range(500):
        assert len(Payment().cid()) == 4


# Generated at 2022-06-23 21:39:48.681853
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cid = payment.cid()
    print("cid : ", cid)


# Generated at 2022-06-23 21:39:51.566083
# Unit test for constructor of class Payment
def test_Payment():
    try:
        obj = Payment()
        result = True
    except:
        result = False

    assert result


# Generated at 2022-06-23 21:39:55.497065
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    print("Testing paypal method of class Payment...")
    string_to_check = Payment().paypal()

    assert "@" in string_to_check
    assert "." in string_to_check


# Generated at 2022-06-23 21:39:57.222425
# Unit test for method cid of class Payment
def test_Payment_cid():
    class_ = Payment()
    assert str(class_.cid()).isdecimal()


# Generated at 2022-06-23 21:39:59.038115
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == payment.credit_card_number()


# Generated at 2022-06-23 21:40:00.693532
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    a = Payment('ua')
    print(a.credit_card_network())


# Generated at 2022-06-23 21:40:06.890520
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.payment import Payment
    payment = Payment()
    card = payment.credit_card_expiration_date()
    assert card is not None
    assert isinstance(card, str)
    assert len(card) == 5


# Generated at 2022-06-23 21:40:10.594089
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    address = p.ethereum_address()
    assert isinstance(address,str)
    assert len(address) == 42 # 2+40, 2 for '0x', 40 for the hex string
