

# Generated at 2022-06-23 21:30:16.889127
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    Unit test for method credit_card_number of class Payment
    """
    p = Payment()
    p.set_seed(123456)
    assert p.credit_card_number(CardType.VISA) == "4455 5299 1152 2450"
    assert p.credit_card_number(CardType.VISA) == "4455 5299 1152 2450"
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == "3431 91040 61956"

# Generated at 2022-06-23 21:30:18.864553
# Unit test for constructor of class Payment
def test_Payment():
    assert Payment().__class__.__name__ == 'Payment'


# Generated at 2022-06-23 21:30:24.503348
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test_cases = {
        CardType.VISA: '4455 5299 1152 2450',
        CardType.MASTER_CARD: '5311 6251 2208 6967',
        CardType.AMERICAN_EXPRESS: '3489 694070 43887'
    }
    r = Payment()
    for card_type in test_cases:
        if r.credit_card_number(card_type) != test_cases[card_type]:
            assert False
    assert True

# Generated at 2022-06-23 21:30:33.757925
# Unit test for method cid of class Payment
def test_Payment_cid():
    # case 1
    payment = Payment(seed=3664)
    result = payment.cid()
    print("test_Payment_cid_1: ", result)
    assert result == 7916
    # case 2
    payment = Payment(seed=3664)
    result = payment.cid()
    print("test_Payment_cid_2: ", result)
    assert result == 7916
    # case 3
    payment = Payment(seed=3664)
    result = payment.cid()
    print("test_Payment_cid_3: ", result)
    assert result == 7916
    # case 4
    payment = Payment(seed=3664)
    result = payment.cid()
    print("test_Payment_cid_4: ", result)
    assert result == 7916
    # case

# Generated at 2022-06-23 21:30:35.307267
# Unit test for method cid of class Payment
def test_Payment_cid():
    Payment().cid()


# Generated at 2022-06-23 21:30:36.719604
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    assert payment.credit_card_owner().get('owner') != None

# Generated at 2022-06-23 21:30:44.002994
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    import itertools

    payment = Payment()
    test_dict = {}
    # test 10000 times and every time there is not repeating
    for i in range(10000):
        test_dict[payment.paypal()] = 1
    assert len(test_dict) == 10000
    # test 100 times and check whether there is the same one in cache
    payment2 = Payment()
    for i in range(100):
        assert payment.paypal() != payment2.paypal()
    # test cache
    for i in range(100):
        assert payment.paypal() == payment.paypal()


# Generated at 2022-06-23 21:30:46.182749
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert type(payment.cvv()) is int


# Generated at 2022-06-23 21:30:48.538929
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    res = payment.ethereum_address()
    assert res is not None
    print(res)



# Generated at 2022-06-23 21:30:57.623442
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    import json
    owner = Payment().credit_card_owner()
    print(owner)
    cc = owner['credit_card']
    exp = owner['expiration_date']
    owner = owner['owner']
    d = Payment().credit_card_number()
    print(d)
    print(type(d))
    print(Payment().credit_card_network())
    print(Payment().eth_address())

    print(Payment().bitcoin_address())
    print(Payment().credit_card_number())
    print(Payment().credit_card_number(CardType.AMERICAN_EXPRESS))
    print(Payment().credit_card_number(CardType.MASTER_CARD))
    print(Payment().credit_card_number(CardType.VISA))

    print(Payment().cvv())


# Generated at 2022-06-23 21:31:01.337190
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    #Given
    p = Payment()
    #When
    expiration_date = p.credit_card_expiration_date()
    #Then
    assert expiration_date != 15
    assert expiration_date != 23
    assert expiration_date != 26

# Generated at 2022-06-23 21:31:03.840961
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payload = Payment()
    print(payload.credit_card_network()) #payload.credit_card_network()
    assert payload.credit_card_network() != ''

# Generated at 2022-06-23 21:31:05.109864
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
	assert Payment().credit_card_expiration_date() == "03/19"

# Generated at 2022-06-23 21:31:12.252800
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    ethereum_address = Payment().ethereum_address()
    assert len(ethereum_address) == 42
    assert ethereum_address[0] == '0' and ethereum_address[1] == 'x'
    assert ethereum_address[2:] == 'e8ece9e6ff7dba52d4c07d37418036a89af9698d'



# Generated at 2022-06-23 21:31:16.069275
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """ :py:meth:Payment.credit_card_expiration_date
    Unit test"""
    provider = Payment()
    assert len(provider.credit_card_expiration_date()) == 5
    assert isinstance(provider.credit_card_expiration_date(),str)

# Generated at 2022-06-23 21:31:18.291492
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert re.compile(r'0x[a-f0-9]{40}').match(payment.ethereum_address())

# Generated at 2022-06-23 21:31:21.589162
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment(seed=7)
    result = payment.paypal()
    assert result == 'jeffreytucker@yahoo.com'



# Generated at 2022-06-23 21:31:28.906075
# Unit test for constructor of class Payment
def test_Payment():
    provider = Payment()
    cid = provider.cid()
    # Display cid information on console
    print('=========================== CID information ===========================')
    print('Credit card id: ', cid)
    assert cid != 0
    
    paypal = provider.paypal()
    # Display paypal information on console
    print('=========================== PAYPAL information ===========================')
    print('PAYPAL email: ', paypal)
    assert paypal != ''
    
    bitcoin_address = provider.bitcoin_address()
    # Display bitcoin information on console
    print('=========================== Bitcoin information ===========================')
    print('Bitcoin address: ', bitcoin_address)
    assert bitcoin_address != ''
    
    ethereum_address = provider.ethereum_address()
    # Display ethereum information on console

# Generated at 2022-06-23 21:31:32.647058
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment('en','card_network','expiration_date','owner')
    assert p.credit_card_network() in CREDIT_CARD_NETWORKS
    assert p.expiration_date() is not None
    assert p.owner() is not None

# Generated at 2022-06-23 21:31:36.154546
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    p = payment.credit_card_number(CardType.MASTER_CARD)
    print(p)
    assert isinstance(p, str)
    print("Finished")


# Generated at 2022-06-23 21:31:38.317651
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert isinstance(payment, Payment)

# Generated at 2022-06-23 21:31:41.973059
# Unit test for constructor of class Payment
def test_Payment():
    temp_Payment_1 = Payment()
    temp_Payment_2 = Payment(seed=123)
    assert temp_Payment_1 is not None
    assert temp_Payment_2 is not None


# Generated at 2022-06-23 21:31:48.531088
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner()
    assert owner['credit_card'] is not None
    assert owner['expiration_date'] is not None
    assert owner['owner'] is not None

    owner = payment.credit_card_owner(gender=Gender.MALE)
    assert owner['credit_card'] is not None
    assert owner['expiration_date'] is not None
    assert owner['owner'] is not None


# Generated at 2022-06-23 21:31:50.843772
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    res = payment.credit_card_network()
    assert res in CREDIT_CARD_NETWORKS

# Generated at 2022-06-23 21:31:52.227031
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert Payment().bitcoin_address() != ""


# Generated at 2022-06-23 21:31:55.168139
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """Tests for Payment class.
    This function test the paypal method of class Payment
    """
    payment = Payment()
    paypal = payment.paypal()
    assert isinstance(paypal, str)


# Generated at 2022-06-23 21:32:02.247837
# Unit test for constructor of class Payment
def test_Payment():
    # p = Payment('en')
    # print(p.paypal())
    # print(p.bitcoin_address())
    # print(p.ethereum_address())
    # print(p.credit_card_network())
    # print(p.credit_card_number())
    # print(p.credit_card_expiration_date())
    # print(p.cvv())
    # print(p.credit_card_owner())
    pass

# Generated at 2022-06-23 21:32:12.670619
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()

    print('Test cid()')
    assert(type(p.cid()) == int)

    print('Test paypal()')
    assert(p.paypal().endswith('@gmail.com'))

    print('Test bitcoin_address()')
    assert(p.bitcoin_address()[0:2] == '1' or p.bitcoin_address()[0:2] == '3')

    print('Test ethereum_address()')
    assert(p.ethereum_address()[0:2] == '0x' and len(p.ethereum_address()) == 42)

    print('Test credit_card_network()')
    assert(type(p.credit_card_network()) == str)

    print('Test credit_card_number()')

# Generated at 2022-06-23 21:32:15.059336
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    mp = Payment()
    print(mp.paypal())


# Generated at 2022-06-23 21:32:16.931112
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    assert len(p.credit_card_expiration_date()) == 5


# Generated at 2022-06-23 21:32:22.044364
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.facade import Payment as fPayment
    p = Payment()
    for i in range(10):
        print(p.credit_card_owner())
        print(p.credit_card_owner(gender=Gender.FEMALE))
        print(fPayment().credit_card_owner(gender=Gender.MALE))

# Generated at 2022-06-23 21:32:24.781493
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Unit test for method cid of class Payment."""
    from mimesis.builtins import Payment
    payment = Payment()
    assert isinstance(payment.cid(), int)


# Generated at 2022-06-23 21:32:27.358750
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Unit test for method credit_card_network of class Payment."""
    p = Payment()
    network = p.credit_card_network()
    assert network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:32:29.466378
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert isinstance(payment, Payment) == True


# Generated at 2022-06-23 21:32:31.812350
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment(seed=2)
    print("ethereum_address():", payment.ethereum_address())

# Generated at 2022-06-23 21:32:35.245203
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Setup
    p = Payment()

    # Exercise
    result = p.ethereum_address()

    # Verify
    assert len(result) == 42
    assert result[0:2] == '0x'


# Generated at 2022-06-23 21:32:41.814618
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    with open('test.txt', 'w', encoding='utf-8') as f:
        for i in range(1000):
            card_type = get_random_item(CardType, rnd=random)
            card = Payment(seed=i).credit_card_number(card_type=card_type)
            f.write(str(card_type) + ' ' + card)
            f.write('\n')


# Generated at 2022-06-23 21:32:44.879829
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    assert re.match(r'^0x[a-fA-F0-9]{40}$', Payment().ethereum_address())



# Generated at 2022-06-23 21:32:48.057281
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    from mimesis.enums import Gender
    p = Payment()
    cvv = p.cvv()
    assert isinstance(cvv, int), "cvv must be integer"
    assert len(str(cvv)) == 3, "cvv must be 3 digits"


# Generated at 2022-06-23 21:32:51.881135
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Test method bitcoin_address of class Payment."""
    assert re.match(r"^[13][a-km-zA-HJ-NP-Z1-9]{33}$", \
        Payment().bitcoin_address()) is not None


# Generated at 2022-06-23 21:32:59.805526
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pay_ = Payment()
    assert re.match("^[A-Za-z0-9]+[.]?[A-Za-z0-9]+@[A-Za-z0-9]+[.]?[A-Za-z0-9]+[.][a-z]{2,4}$", pay_.paypal())
    assert re.match("^[A-Za-z0-9]+[.]?[A-Za-z0-9]+@[A-Za-z0-9]+[.]?[A-Za-z0-9]+[.][a-z]{2,4}$", pay_.paypal())

# Generated at 2022-06-23 21:33:03.245844
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    assert re.match(r"^[\w\.\+\-]+\@[\w]+\.[a-z]{2,3}$", p.paypal())


# Generated at 2022-06-23 21:33:10.661565
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    payment = Payment(seed=4)
    assert payment.credit_card_owner() == {'credit_card': '2763 1299 2248 5393', 'expiration_date': '04/20', 'owner': 'PAMELA YOUNG'}
    assert payment.credit_card_owner(Gender.FEMALE) == {'credit_card': '4513 4419 5135 9882', 'expiration_date': '12/20', 'owner': 'EVAN WILLIAMS'}
    assert payment.credit_card_owner(Gender.MALE) == {'credit_card': '2353 4470 8552 0745', 'expiration_date': '06/21', 'owner': 'JACK ELLIS'}

# Generated at 2022-06-23 21:33:12.248631
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p=Payment()
    assert len(str(p.cvv())) == 3

# Generated at 2022-06-23 21:33:15.671154
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # print(Payment().ethereum_address())
    assert Payment().ethereum_address() == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'

# Generated at 2022-06-23 21:33:18.756901
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    result = payment.cid()
    assert isinstance(result, int)
    assert len(str(result)) == 4


# Generated at 2022-06-23 21:33:20.011604
# Unit test for constructor of class Payment
def test_Payment():
    provider = Payment()
    assert provider

# Generated at 2022-06-23 21:33:21.505360
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    for _ in range(100):
        cid = payment.cid()
        assert 1000 <= cid <= 9999


# Generated at 2022-06-23 21:33:27.152653
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Tests for the method cvv of the class Payment."""
    from mimesis.enums import Gender

    payment = Payment('en')
    # Test 1
    assert payment.cvv() in range(100, 999)

    # Test 2
    assert payment.cvv() in range(100, 999)

    # Test 3
    assert payment.cvv() in range(100, 999)

    # Test 4
    assert payment.cvv() in range(100, 999)



# Generated at 2022-06-23 21:33:31.355539
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """
        Method test :
        Instance Payment().credit_card_expiration_date()
        and assert result
    """
    assert Payment().credit_card_expiration_date() == '03/21'

# Generated at 2022-06-23 21:33:33.715096
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment('en')
    payment.set_seed(1234567890)
    print(payment.paypal())


# Generated at 2022-06-23 21:33:35.034572
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cvv = payment.cvv()
    assert len(cvv) == 3


# Generated at 2022-06-23 21:33:41.923348
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Test for method ethereum_address of class Payment."""
    payment = Payment()
    ethereum_address = payment.ethereum_address()
    assert len(ethereum_address) == 42
    assert ethereum_address.startswith('0x')
    assert ethereum_address[2:].isalnum()

if __name__ == '__main__':
    # Unit test for method ethereum_address of class Payment
    test_Payment_ethereum_address()

# Generated at 2022-06-23 21:33:45.093526
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    obj = Payment()
    assert obj.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:33:49.756482
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment_instance = Payment()
    payment_instance.seed(0)
    assert payment_instance.credit_card_network() == 'Visa'
    assert payment_instance.credit_card_network() == 'MasterCard'
    assert payment_instance.credit_card_network() == 'American Express'


# Generated at 2022-06-23 21:33:53.826584
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    test = Payment()
    paypal = test.paypal()
    assert isinstance(paypal, str)
    assert re.findall('^[\w-]+@[\w-]+\.[\w-]+$', paypal)


# Generated at 2022-06-23 21:33:57.633695
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    # property test
    assert p.ethereum_address()[0] == '0'
    assert p.ethereum_address()[1] == 'x'


# Generated at 2022-06-23 21:34:04.517296
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    result = p.credit_card_expiration_date(minimum = 16, maximum = 25)
    assert len(result) == 5
    assert int(result[0:2]) >=1 and int(result[0:2]) <= 12
    assert int(result[3:7]) >=16 and int(result[3:7]) <= 25



# Generated at 2022-06-23 21:34:06.397047
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert len(str(payment.cvv())) == 3


# Generated at 2022-06-23 21:34:11.413218
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment."""
    payment = Payment(seed=666)
    x = payment.ethereum_address()
    assert (x == '0x4f8fc78b6d36e6ef0f93835cb8cb07edf1a12d44')


# Generated at 2022-06-23 21:34:22.921160
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import random
    random.seed(0)
    payment = Payment(seed = 0)
    print("Test credit_card_number:")
    assert payment.credit_card_number(card_type=None) == "5444 8072 0082 0139"
    assert payment.credit_card_number(card_type=None) == "4634 4369 3153 9160"
    assert payment.credit_card_number(card_type=None) == "4534 9054 7224 2164"
    assert payment.credit_card_number(card_type=None) == "4181 8982 9085 8249"
    assert payment.credit_card_number(card_type=None) == "4012 8398 4166 4574"

# Generated at 2022-06-23 21:34:27.019391
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment('en')
    assert type(p.credit_card_expiration_date()) == str
    reg_ex = re.compile(r'\d{2}/\d{2}')
    assert re.match(reg_ex, p.credit_card_expiration_date())
    reg_ex = re.compile(r'\d{2}/\d{4}')
    assert re.match(reg_ex, p.credit_card_expiration_date(minimum=2018, maximum=2022))

# Generated at 2022-06-23 21:34:38.155431
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Unit test for method credit_card_owner of class Payment"""
    payment = Payment()
    owner = payment.credit_card_owner()
    assert isinstance(owner, dict)
    assert sorted(owner) == ['credit_card', 'expiration_date', 'owner']
    assert int(owner['credit_card'][0]) in [4, 5]
    assert len(owner['credit_card'].replace(' ', '')) == 16
    assert len(owner['credit_card'].split(' ')) == 4
    assert int(owner['credit_card'].split(' ')[-1]) == luhn_checksum(owner['credit_card'].replace(' ', '')[:-1])
    assert '/' in owner['expiration_date']
    assert len(owner['expiration_date']) == 5

# Generated at 2022-06-23 21:34:39.964463
# Unit test for constructor of class Payment
def test_Payment():
    test = Payment(('en',))
    print(test)

# Generated at 2022-06-23 21:34:42.326405
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    P = Payment()
    assert isinstance(P.credit_card_owner(), dict)

# Generated at 2022-06-23 21:34:51.718186
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment('en', seed=12345)
    assert payment.cid()==6511
    assert payment.paypal()=="masonthomas@aol.com"
    assert payment.bitcoin_address()=="1XV7ZvJkW2V8jybYQ2f7GvTtCnmR8eZcjX"
    assert payment.ethereum_address()=='0xcc8aA48Ef1F7A3bC1e0A3F38A0d0519a4F4a5786'
    assert payment.credit_card_network()=="Visa"
    assert payment.credit_card_number()=="2697 8553 8741 2205"
    assert payment.credit_card_expiration_date()=="09/21"
    assert payment

# Generated at 2022-06-23 21:34:56.453687
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    result = payment.credit_card_expiration_date()
    regex = re.compile(r'([01][0-2]|[0-9])/([1-9]\d|\d)')
    assert re.match(regex, result) is not None



# Generated at 2022-06-23 21:34:59.136499
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # With a fixed seed, the random card number is always the same.
    p = Payment(seed=1)
    assert p.credit_card_expiration_date() == '08/21'

# Generated at 2022-06-23 21:35:03.977861
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    provider = Payment()
    # tester = provider.paypal()
    assert str(provider.paypal()).__class__.__name__ == 'str'
    assert str(provider.paypal()).__class__.__name__ != 'int'
    assert provider.paypal().__class__.__name__ != 'Person'


# Generated at 2022-06-23 21:35:05.888473
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment_obj = Payment(seed=0)

    expiration_date = payment_obj.credit_card_expiration_date(minimum = 16, maximum = 25)

    print(expiration_date)

    assert expiration_date == "04/22"



# Generated at 2022-06-23 21:35:09.419022
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    new_payment = Payment('en', seed=123)
    result = new_payment.credit_card_expiration_date()
    assert result == '02/24'


# Generated at 2022-06-23 21:35:10.646748
# Unit test for method cid of class Payment
def test_Payment_cid():
    obj = Payment("en", seed=0)
    test_cid = obj.cid()
    # Assertion
    assert test_cid == 5881


# Generated at 2022-06-23 21:35:15.221741
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # This test is not a good one, since
    # it tests a method of the derived class Person
    """Test method paypal of class Payment"""
    payment = Payment('en', seed=0)
    assert payment.paypal() == 'wolf235@gmail.com'


# Generated at 2022-06-23 21:35:16.517515
# Unit test for method cid of class Payment
def test_Payment_cid():
    cid = Payment()
    print(cid.cid())


# Generated at 2022-06-23 21:35:19.727417
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment(seed=42)
    print(payment.ethereum_address())


# Generated at 2022-06-23 21:35:21.820291
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    assert len(str(p.cid())) == 4



# Generated at 2022-06-23 21:35:22.903817
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    assert p.bitcoin_address()

# Generated at 2022-06-23 21:35:25.593442
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment_class = Payment()
    assert (payment_class.cvv()>=100 and payment_class.cvv()<=999)


# Generated at 2022-06-23 21:35:28.936394
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Testing whether valid credit card number is generated
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    valid = payment.luhn_checksum(credit_card_number.replace(' ', ''))
    assert valid == 0


# Generated at 2022-06-23 21:35:33.083218
# Unit test for method cid of class Payment
def test_Payment_cid():
    a = Payment(random=False)
    assert a.cid() == '7452'
    assert a.cid() == '7452'
    assert a.cid() == '7452'
    assert a.cid() == '7452'
    assert a.cid() == '7452'


# Generated at 2022-06-23 21:35:36.228978
# Unit test for method cid of class Payment
def test_Payment_cid():
    py = Payment()
    assert type(py.cid()) == int
    assert len(str(py.cid())) == 4
    assert py.cid() >= 1000 and py.cid() <= 9999


# Generated at 2022-06-23 21:35:39.413952
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment(seed=12345)
    assert p.credit_card_owner() == {'credit_card': '4455 5299 1152 2450', 'expiration_date': '07/22', 'owner': 'LEONARD KLEIN'}


# Generated at 2022-06-23 21:35:41.217896
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment"""
    p = Payment("en")
    ccn = p.credit_card_number();
    return ccn

# Generated at 2022-06-23 21:35:42.574656
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    for n in range(10000):
        assert len(p.credit_card_number()) == 16

# Generated at 2022-06-23 21:35:44.911575
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    cc = payment.credit_card_number()
    print(cc)

# Generated at 2022-06-23 21:35:47.493359
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    ownership = payment.credit_card_owner()
    assert bool(ownership)

# Generated at 2022-06-23 21:35:50.005729
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    obj = Payment()
    assert isinstance(obj.credit_card_owner, dict)

test = Payment()
print(test.credit_card_owner())



# Generated at 2022-06-23 21:35:53.276543
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    class_obj = Payment()
    assert isinstance(class_obj.paypal(), str)


# Generated at 2022-06-23 21:35:57.420180
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    # Set minimum and maximum to a default number
    exp_date = payment.credit_card_expiration_date()
    assert len(exp_date) == 6
    assert (exp_date[2]) == "/"
    

# Generated at 2022-06-23 21:35:59.159963
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment(seed=0)
    assert payment.credit_card_network() == 'Visa'


# Generated at 2022-06-23 21:36:06.562963
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    provider = Payment()
    result_0 = provider.credit_card_owner()
    result_1 = provider.credit_card_owner(Gender.MALE)
    result_2 = provider.credit_card_owner(Gender.FEMALE)

    print(result_0)
    print(result_1)
    print(result_2)

if __name__ == '__main__':
    test_Payment_credit_card_owner()

# Generated at 2022-06-23 21:36:09.906188
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis import enums
    from mimesis import Payment
    test_payment = Payment()

    for i in range(0,6):
        print(test_payment.credit_card_expiration_date())


# Generated at 2022-06-23 21:36:10.901033
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    b = Payment('en')
    b.bitcoin_address()
    

# Generated at 2022-06-23 21:36:12.197646
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment(seed=20)
    payment.ethereum_address()

# Generated at 2022-06-23 21:36:20.971056
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.cid() == payment.cid()

    assert payment.paypal() != payment.paypal()

    assert payment.bitcoin_address() != payment.bitcoin_address()

    assert payment.ethereum_address() != payment.ethereum_address()

    assert payment.credit_card_network() != payment.credit_card_network()

    assert payment.credit_card_number() != payment.credit_card_number()

    assert payment.credit_card_expiration_date() != payment.credit_card_expiration_date()

    assert payment.cvv() != payment.cvv()

    assert payment.credit_card_owner() != payment.credit_card_owner()

# Generated at 2022-06-23 21:36:22.516936
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    r = Payment('en')
    print(r.bitcoin_address())


# Generated at 2022-06-23 21:36:25.621635
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    seed=1467490182
    Payment_credit_card_network = Payment(seed=seed).credit_card_network()
    assert Payment_credit_card_network == "Visa"


# Generated at 2022-06-23 21:36:29.715548
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    from mimesis.providers.person import Person
    import re
    p = Payment()
    pattern = re.compile(r'\d{3}')
    assert re.search(pattern,p.cvv())


# Generated at 2022-06-23 21:36:35.378651
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert Payment().credit_card_expiration_date(0,16) == '03/17'
    assert Payment().credit_card_expiration_date(16,17) == '08/17'
    assert Payment().credit_card_expiration_date(17,18) == '09/18'
    assert Payment().credit_card_expiration_date(18,25) == '02/20'
    assert Payment().credit_card_expiration_date(25,30) == '09/26'

# Generated at 2022-06-23 21:36:37.790422
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Setup
    payment = Payment()

    # Exercise
    output = payment.cid()

    # Verify
    assert type(output) == int



# Generated at 2022-06-23 21:36:40.475135
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """
    unit test for method paypal of class Payment
    """
    instance = Payment()
    assert instance.paypal()


# Generated at 2022-06-23 21:36:42.651052
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    assert p.credit_card_network() in CREDIT_CARD_NETWORKS



# Generated at 2022-06-23 21:36:53.039787
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment."""
    from mimesis.enums import CardType

    # Instantiate Payment
    test_payment = Payment()

    # Test for Visa CC
    # Unit test to test if a random Visa card number is valid
    assert re.fullmatch(r'\d{4} \d{4} \d{4} \d{4}',
                        test_payment.credit_card_number()) is not None

    # Unit test to test if a random Visa card number with length 16 is valid
    assert re.fullmatch(r'\d{4} \d{4} \d{4} \d{4}',
                        test_payment.credit_card_number(CardType.VISA)) is not None

    # Test for MasterCard CC
    # Unit test to test if a random MasterCard

# Generated at 2022-06-23 21:37:02.862939
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Unit test for method credit_card_expiration_date of class Payment
    """
    from mimesis.data import CREDIT_CARD_NETWORKS
    from mimesis.enums import CardType, Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.random import get_random_item
    from mimesis.shortcuts import luhn_checksum
    p = Payment("en")
    assert(type(p.credit_card_expiration_date()) == str)
    assert(type(p.credit_card_expiration_date(16, 25)) == str)
    return


# Generated at 2022-06-23 21:37:05.438109
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import CardType, Gender
    owner = Payment()
    print(owner.credit_card_owner(gender=Gender.FEMALE))


# Generated at 2022-06-23 21:37:07.068496
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment(seed=11)
    result = payment.cvv()
    assert result == 816


# Generated at 2022-06-23 21:37:10.278621
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    Test to assert that the credit card number is valid.
    """
    payment = Payment()
    card_num = payment.credit_card_number()
    assert str(type(card_num)) == "<class 'str'>"
    assert type(card_num.split(" ")[0]) == int

# Generated at 2022-06-23 21:37:16.254611
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    random_choice = payment.random.choice
    payment.random.choice = lambda item: item[0]
    assert payment.credit_card_network() == 'Visa'
    payment.random.choice = random_choice

test_Payment_credit_card_network()


# Generated at 2022-06-23 21:37:19.952999
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    payment.seed(123)
    result = payment.ethereum_address()
    assert result == "0x66e82bfd47d0179b58d72f1c0ffa6c39be2349ff"
    print('Test successful')

# Generated at 2022-06-23 21:37:31.114495
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(card_type=CardType.MASTER_CARD)

# Generated at 2022-06-23 21:37:33.066700
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test method credit_card_number of class Payment."""
    bank = Payment('en')
    assert len(bank.credit_card_number()) == 19

# Generated at 2022-06-23 21:37:36.536570
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_types = [CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]
    for card_type in card_types:
        p = Payment(seed=1)
        card = p.credit_card_number(card_type=card_type)
        assert luhn_checksum(card.replace(' ', '')) == '0'

# Generated at 2022-06-23 21:37:39.895172
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis import Payment
    creditCardNetwork = Payment()
    creditCardNetwork_1 = creditCardNetwork.credit_card_network()
    assert creditCardNetwork_1 in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:37:41.685222
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    result = Payment().cvv()
    assert len(str(result)) == 3


# Generated at 2022-06-23 21:37:42.876673
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    print(p.bitcoin_address())

# Generated at 2022-06-23 21:37:49.190843
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment('ja')
    assert payment.get_locale() == 'ja'
    assert payment.bitcoin_address() != payment.ethereum_address()
    assert payment.credit_card_network() != payment.credit_card_network()
    assert (len(payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)) \
    == len(payment.credit_card_number(card_type=CardType.MASTER_CARD)))

# Generated at 2022-06-23 21:37:52.626764
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment(seed=1)
    assert p.ethereum_address() == '0x68b66adebfd672e839fb8a653218b36593d5b5ab'

# Generated at 2022-06-23 21:37:56.921945
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    for _ in range(100):
        x = Payment()
        address = x.bitcoin_address()
        assert len(address) == 35
        assert address[0] == '1' or address[0] == '3'
        for letter in address[1:]:
            assert letter in string.ascii_letters or letter in string.digits


# Generated at 2022-06-23 21:37:59.402292
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
	payment = Payment()
	assert len(payment.ethereum_address()) == 42

# Generated at 2022-06-23 21:38:02.264591
# Unit test for method cid of class Payment
def test_Payment_cid():
  payment_1 = Payment()
  d = payment_1.cid()
  assert type(d) == int, 'Type of output must be int'


# Generated at 2022-06-23 21:38:03.168240
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    print(payment.bitcoin_address())

# Generated at 2022-06-23 21:38:06.575335
# Unit test for method cid of class Payment
def test_Payment_cid():
    obj = Payment(seed=42)
    a = obj.cid()
    assert a == 1583
    assert isinstance(a, int)


# Generated at 2022-06-23 21:38:12.430641
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Create instance of class Payment
    testPayment = Payment()
    # Generate credit card number with CardType VISA
    testResult = testPayment.credit_card_number(CardType.VISA)
    # Store regular expression
    regex = re.compile(r'^\d{16}$')
    # Check if the testResult match with the regular expression
    assert(regex.match(testResult))

# Generated at 2022-06-23 21:38:17.822523
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    nums = []
    for i in range(0, 1000):
        num = Payment().cvv()
        nums.append(num)

    assert isinstance(nums[0], int), "int?"
    assert len(str(nums[0])) == 3, "3 digits?"
    assert nums[0] in range(100, 1000), "3 digits?"


# Generated at 2022-06-23 21:38:26.138429
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment(seed=1111)
    # minimum <= maximum
    assert payment.credit_card_expiration_date(minimum=16, maximum=25) == "01/18"
    assert payment.credit_card_expiration_date(minimum=15, maximum=25) == "09/21"
    assert payment.credit_card_expiration_date(minimum=16, maximum=25) == "02/23"
    # minimum > maximum
    assert payment.credit_card_expiration_date(minimum=25, maximum=16) == "01/18"
    assert payment.credit_card_expiration_date(minimum=25, maximum=15) == "09/21"
    assert payment.credit_card_expiration_date(minimum=25, maximum=16) == "02/23"

# Generated at 2022-06-23 21:38:32.391329
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Test for method credit_card_expiration_date of class Payment"""
    from mimesis.enums import Gender

    import datetime

    def get_first_or_default(lst: list, func: object) -> object:
        """
            Return first object or default value.

            :param lst: list
            :param func: predicate
            :return: first object or default value
        """
        return next((x for x in lst if func(x)), None)

    def Return_False_for_2():
        """Return False for 2"""
        return False

    def Return_True_for_2():
        """Return True for 2"""
        return True

    def Return_False_for_0():
        """Return False for 0"""
        return False


# Generated at 2022-06-23 21:38:34.160740
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment('en')
    if payment.cvv() not in range(100, 1000):
        print("Fail for method cvv")


# Generated at 2022-06-23 21:38:37.072393
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.random.seed is None

    payment = Payment(seed=1)
    assert payment.random.seed == 1

# Generated at 2022-06-23 21:38:40.797848
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Unit test for method bitcoin_address of class Payment"""
    test = Payment()
    assert re.search(r'^[13][a-km-zA-HJ-NP-Z1-9]{33}$', test.bitcoin_address()) is not None


# Generated at 2022-06-23 21:38:45.461349
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    t = 0
    p = Payment()
    for i in range(10):
        a = p.ethereum_address()
        print(a)
        if re.match(r'0x[a-fA-F0-9]{40}$', a) is None:
            t = 1
            print('test Ethereum address fail')
    if t == 0:
        print('test Ethereum address successful')


# Generated at 2022-06-23 21:38:53.261569
# Unit test for constructor of class Payment
def test_Payment():
    a = Payment()
    from mimesis.enums import CardType
    assert a.credit_card_number(CardType.VISA) is not None
    assert a.credit_card_number(CardType.MASTER_CARD) is not None
    assert a.credit_card_number(CardType.AMERICAN_EXPRESS) is not None
    assert a.credit_card_number() is not None
    assert a.credit_card_network() is not None
    assert a.cid() is not None
    assert a.cvv() is not None
    assert a.credit_card_owner() is not None

# Generated at 2022-06-23 21:39:00.626724
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    result = payment.credit_card_owner(gender=Gender.MALE)
    assert result['expiration_date'][2] == '/'
    assert len(result['expiration_date']) == 5
    assert result['expiration_date'][0] == '0' or result['expiration_date'][0] == '1'
    for i in range(4, 16):
        assert result['credit_card'][i] != ' '
    assert len(result['credit_card'].split(' ')) == 4


# Generated at 2022-06-23 21:39:01.872081
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert 100 <= payment.cvv() <= 999

# Generated at 2022-06-23 21:39:06.965978
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Payment class instance
    payment = Payment("en")

    # The method cid of Payment class instance
    result = payment.cid()
    print("cid: ")
    print(result)
    assert isinstance(result, int)


# Generated at 2022-06-23 21:39:08.949746
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert len(Payment().credit_card_expiration_date()) == 5


# Generated at 2022-06-23 21:39:10.805535
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    assert payment.credit_card_owner()['owner'] == "PAUL FOSTER"
    

# Generated at 2022-06-23 21:39:13.084616
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment=Payment()
    print(payment.credit_card_number())

# Generated at 2022-06-23 21:39:14.899262
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    return Payment().credit_card_expiration_date()


# Generated at 2022-06-23 21:39:17.787041
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    # Check randomness
    # TODO: make a test case when there is only one credit card network
    assert Payment().credit_card_network() == Payment().credit_card_network()


# Generated at 2022-06-23 21:39:24.991074
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    fake = Payment()
    # Set the current year
    i = 0
    while i < 2:
        # Generate expiration date of credit card
        cc_exp_date = fake.credit_card_expiration_date(minimum=2016, maximum=2019)
        exp_date = cc_exp_date.split("/")
        # assert that the month is in the range of 1 and 12
        assert(1 <= int(exp_date[0]) <= 12)
        # assert that the year is in the range of 2016 and 2019
        assert(2016 <= int(exp_date[1]) <= 2019)
        i += 1

# Generated at 2022-06-23 21:39:27.722256
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # The minimum length of an Ethereum address is 40.
    m = Payment()
    assert len(m.ethereum_address()) >= 40

# Generated at 2022-06-23 21:39:32.252974
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    for i in range(10):
        et = Payment()
        eth = et.ethereum_address()
        assert type(eth) == str
        assert len(eth) == 42
        assert eth.startswith("0x")
        assert eth[2:].isalnum()


# Generated at 2022-06-23 21:39:35.026882
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    test_Payment = Payment('en')
    print(test_Payment.credit_card_number())
    print(test_Payment.credit_card_number(CardType.VISA))
    print(test_Payment.credit_card_number(CardType.MASTER_CARD))
    print(test_Payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-23 21:39:38.382742
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """ Unit test for method ethereum_address of class Payment"""
    payment = Payment()
    try:
        assert payment.ethereum_address()
        assert re.fullmatch(r"0x[0-9a-fA-F]{40}$",payment.ethereum_address())
    except AssertionError:
        pass

# Generated at 2022-06-23 21:39:39.627954
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    payment.bitcoin_address()


# Generated at 2022-06-23 21:39:43.051471
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card = payment.credit_card_number()
    assert len(credit_card) == 19
    CreditCard = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert len(CreditCard) == 17

# Generated at 2022-06-23 21:39:50.360007
# Unit test for constructor of class Payment
def test_Payment():
    # pylint: disable=unused-variable
    # pylint: disable=line-too-long
    # pylint: disable=unused-import
    # pylint: disable=bare-except
    # pylint: disable=import-outside-toplevel
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.payment import Payment
    from mimesis.enums import Gender, CardType

    p = Payment()
    p.random

    p.credit_card_number()
    p.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)

    p.credit_card_expiration_date()
    p.credit_card_expiration_date(maximum=27, minimum=18)

    p.credit_card_network()

   

# Generated at 2022-06-23 21:39:53.194754
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert re.match("[13][a-km-zA-HJ-NP-Z1-9]{25,34}", Payment().bitcoin_address())

# Generated at 2022-06-23 21:39:56.476879
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    credit_card_network = payment.credit_card_network()
    assert credit_card_network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:39:57.915160
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    print(Payment().credit_card_network())


# Generated at 2022-06-23 21:40:00.413411
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    credit_card_network = payment.credit_card_network()
    assert credit_card_network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:40:04.101479
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    for _ in range(100):
        result = payment.cid()
        assert 100 <= result < 10000
        assert type(result) == int



# Generated at 2022-06-23 21:40:09.285036
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    print("Unit test for method paypal of class Payment")
    test_Payment_paypal_obj = Payment()
    for i in range(0,10):
        test_Payment_paypal_var = test_Payment_paypal_obj.paypal()
        print(test_Payment_paypal_var)
