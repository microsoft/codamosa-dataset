

# Generated at 2022-06-23 21:30:21.040917
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment
    print('\ncvv from class Payment: ')
    instance = Payment()
    print('\nTesting gender enum: ')
    print('Default value gender is None: ', instance.cvv())



# Generated at 2022-06-23 21:30:25.664960
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    from mimesis.enums import Gender
    from pprint import pprint
    from mimesis.providers.payment import Payment

    p = Payment('en')
    p.seed(1234356)
    # pprint(p.paypal())

    p.seed(1234356)
    pprint(p.credit_card_owner(gender=Gender.FEMALE))

# Generated at 2022-06-23 21:30:31.413538
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    exp_owner = payment.credit_card_owner()
    # test length of credit card number
    assert len(exp_owner['credit_card']) == 19
    # test length of expiration date
    assert len(exp_owner['expiration_date']) == 5
    # test length of owner's name
    assert len(exp_owner['owner'].split(' ')) == 2

# Generated at 2022-06-23 21:30:34.204048
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    print(payment.paypal())


# Generated at 2022-06-23 21:30:36.419008
# Unit test for constructor of class Payment
def test_Payment():
    # Initialize class Payment
    payment = Payment()

    # Check if attribute has been initialized
    assert payment.seed is not None

# Generated at 2022-06-23 21:30:38.294777
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date() == '06/18'
    # Should be valid for 2019/08/01
    assert payment.credit_card_expiration_date(18) == '08/19'

# Generated at 2022-06-23 21:30:40.620346
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    result = Payment().credit_card_expiration_date()
    assert type(result) == str
    assert len(result) == 5


# Generated at 2022-06-23 21:30:45.251926
# Unit test for method cid of class Payment
def test_Payment_cid():
    from mimesis.builtins import RussiaSpecProvider

    p = Payment()
    p.add_provider(RussiaSpecProvider)
    assert isinstance(p.cid(), int) == True


# Generated at 2022-06-23 21:30:49.099062
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment(10)

    owner = payment.credit_card_owner()
    print(owner)
    assert owner.get('credit_card') != None
    assert owner.get('expiration_date') != None
    assert owner['owner'] != None

# Generated at 2022-06-23 21:30:55.426523
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    for i in range(1,10):
        print(Payment().paypal())
        # Result:
#         michael437@gmail.com
#         trevorsmith@outlook.com
#         lynn93@outlook.com
#         brandy80@sbcglobal.net
#         larry67@sbcglobal.net
#         wayne89@outlook.com
#         randy95@icloud.com
#         ronald73@hotmail.com
#         stephanie61@icloud.com

# Generated at 2022-06-23 21:31:01.897780
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    print("Payment.credit_card_network() -> ", end = '')
    card_network = Payment().credit_card_network()
    # check for the returned value to be a string
    assert(isinstance(card_network, str))
    # check for the returned value to be non-empty string
    assert(len(card_network) >= 1)
    print("PASSED")


# Generated at 2022-06-23 21:31:04.382635
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    PP = Payment()
    for _ in range(100):
        cvv = PP.cvv()
        assert len(str(cvv)) == 3


# Generated at 2022-06-23 21:31:05.395359
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    p.paypal()

# Generated at 2022-06-23 21:31:08.308554
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment(seed=42)
    result = payment.cid()
    assert(result == "7483")


# Generated at 2022-06-23 21:31:12.755172
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment_obj = Payment()
    credit_card_network_value = payment_obj.credit_card_network()
    assert credit_card_network_value in ['VISA', 'MasterCard', 'AmericanExpress']


# Generated at 2022-06-23 21:31:14.711038
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payload = Payment()
    print(payload.credit_card_expiration_date(20,23))

# Generated at 2022-06-23 21:31:19.390233
# Unit test for constructor of class Payment
def test_Payment():
    a = Payment()
    print(a.credit_card_owner(gender = Gender.FEMALE))
    print(a.paypal())
    print(a.bitcoin_address() + " " + str(len(a.bitcoin_address())))
    print(a.ethereum_address() + " " + str(len(a.ethereum_address())))
    print(a.credit_card_network())
    print(a.credit_card_number(card_type = CardType.AMERICAN_EXPRESS) + " " + str(len(a.credit_card_number(card_type = CardType.AMERICAN_EXPRESS))))
    print(a.credit_card_expiration_date(minimum = 16, maximum = 17))
    print(a.cid())
    print(a.cvv())
   

# Generated at 2022-06-23 21:31:22.048763
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment(seed=42)
    result = payment.cid()

    assert 4382 <= result <= 7366


# Generated at 2022-06-23 21:31:23.184527
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment(seed=0)
    assert payment.credit_card_expiration_date() == '03/16'

# Generated at 2022-06-23 21:31:27.087868
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    testObj = Payment()
    res = testObj.credit_card_network()
    # Check if res is one of the values in enum classes of CREDIT_CARD_NETWORKS
    assert res in CREDIT_CARD_NETWORKS
    print("\nThe unit test case passed!")
    assert 1


# Generated at 2022-06-23 21:31:29.747904
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cvv = payment.cvv()
    assert cvv

# Generated at 2022-06-23 21:31:39.113389
# Unit test for method credit_card_expiration_date of class Payment

# Generated at 2022-06-23 21:31:40.260775
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pass



# Generated at 2022-06-23 21:31:45.619371
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    credit_cards = [Payment().credit_card_number(card_type) for card_type in list(CardType)]
    for credit_card in credit_cards:
        if re.match(r'^[4-6]\d{3} \d{4} \d{4} \d{4}$', credit_card) is None:
            assert False
        else:
            assert True

# Generated at 2022-06-23 21:31:47.622444
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert len(payment.credit_card_expiration_date()) == 7

# Generated at 2022-06-23 21:31:52.178433
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    print("Test method bitcoin_address of class Payment")
    seed_ = [1, 2, 3, 4, 5]
    for seed in seed_:
        from mimesis import Payment
        p = Payment(seed)
        print("seed = ", seed)
        print("Result = ", p.bitcoin_address())

# Generated at 2022-06-23 21:31:57.692790
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment("en")
    print('paypal: ', payment.paypal())
    print('btc: ', payment.bitcoin_address())
    print('eth: ', payment.ethereum_address())
    print('credit_card_number: ', payment.credit_card_number())
    print('credit_card_network: ', payment.credit_card_network())
    print('credit_card_expiration_date: ', payment.credit_card_expiration_date())
    print('cvv: ', payment.cvv())

test_Payment()

# Generated at 2022-06-23 21:32:00.312026
# Unit test for method cid of class Payment
def test_Payment_cid():
    for _ in range(10):
        x = Payment.cid()
        assert isinstance(x, int)
        assert x >= 1000 and x <= 9999


# Generated at 2022-06-23 21:32:00.955194
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()

# Generated at 2022-06-23 21:32:03.435812
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment('en')
    result = payment.credit_card_owner()
    print(result)
    assert result is not None

test_Payment()

# Generated at 2022-06-23 21:32:04.760882
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment(seed=1234)
    assert p.paypal() == 'graham.wright@yahoo.com'

# Generated at 2022-06-23 21:32:09.151265
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    queryset = set()
    for i in range(10000):
        card_type = get_random_item(CardType)  # type: ignore
        r = Payment().credit_card_number(card_type=card_type)
        queryset.add(r)
    assert len(queryset) == 10000

# Generated at 2022-06-23 21:32:13.235467
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    bitcoin_addr=Payment().bitcoin_address()
    #testing length
    assert len(bitcoin_addr)==35
    #testing structure if the first 2 characters is a number
    assert bitcoin_addr[0] in string.digits
    assert bitcoin_addr[1] in string.digits

# Generated at 2022-06-23 21:32:17.459812
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    generator = Payment()
    rv = generator.ethereum_address()
    assert type(rv) == str
    assert re.match(r"0x[0-9a-fA-F]{40}", rv)

# Generated at 2022-06-23 21:32:27.135460
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    Payment1 = Payment()
    Payment2 = Payment()
    Payment3 = Payment()
    Payment4 = Payment()
    Payment5 = Payment()
    Payment6 = Payment()
    Payment7 = Payment()
    assert Payment1.bitcoin_address() == '1Lcykn8KMwRZvJ7eB4gg6CrH4yKq2gv58Z'
    assert Payment2.bitcoin_address() == '1K7bUx61MoUc8zJ5Kjv5G7aU6QN1bYWUd'
    assert Payment3.bitcoin_address() == '1JjXCvH7n1f4cBAskSgPtzRmvD7mBJS4Cf'

# Generated at 2022-06-23 21:32:29.554951
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.__class__.__name__ == 'Payment'


# Generated at 2022-06-23 21:32:30.513320
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    print(Payment().paypal())



# Generated at 2022-06-23 21:32:34.671611
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """
    Testing the method paypal of class Payment
    """
    print("Testing paypal method of class Payment")
    from mimesis import Payment
    P = Payment()
    print(P.paypal())
    print("--------------------------")
    return True


# Generated at 2022-06-23 21:32:41.721270
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Create a Payment object
    pay = Payment()

    # Test card type is VISA
    credit_card = pay.credit_card_number(CardType.VISA)
    assert credit_card[0] == '4'

    # Test card type is MasterCard
    credit_card = pay.credit_card_number(CardType.MASTER_CARD)
    assert credit_card[0] == '5'

    # Test card type is American Express
    credit_card = pay.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert credit_card[0] == '3'

# Generated at 2022-06-23 21:32:46.226172
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """
    test_Payment_credit_card_network() will test for credit_card_network method of class Payment
    if the method is working properly as intended
    """
    test_obj = Payment()
    assert test_obj.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:32:50.188097
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Arrange
    payment = Payment()
    # Act
    actual = payment.credit_card_number()
    # Assert
    assert actual.count(" ") == 3
    assert len(actual.replace(" ", "")) == 16


# Generated at 2022-06-23 21:32:50.785194
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    c = Payment()
    print(c.paypal())


# Generated at 2022-06-23 21:32:52.085363
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    paypal_email = p.paypal()
    assert (paypal_email == "sbrown56@yahoo.com")

# Generated at 2022-06-23 21:32:53.513461
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment._seed == 1234
    assert payment._random_method == 'random.SystemRandom'


# Generated at 2022-06-23 21:32:56.486598
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    payment.credit_card_owner(gender=Gender.MALE)
    payment.credit_card_owner(gender=Gender.FEMALE)
    payment.credit_card_owner()

# Generated at 2022-06-23 21:32:58.297747
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    result = payment.credit_card_number()
    print(result)


# Generated at 2022-06-23 21:33:03.791237
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Unit test for method credit_card_owner of class Payment
    """
    testclass = Payment()
    testclass.credit_card_owner()

    testclass.credit_card_owner(Gender.MALE)
    testclass.credit_card_owner(Gender.FEMALE)

    testclass.credit_card_owner(Gender.UNKNOWN)


# Generated at 2022-06-23 21:33:04.733481
# Unit test for method cid of class Payment
def test_Payment_cid():
    x = Payment.cid()

# Generated at 2022-06-23 21:33:12.691689
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Test_Payment_bitcoin_address.

    This method tests the method 'bitcoin_address' of class 'Payment'.
    """
    # Preparation
    seed = 1234567890
    provider = Payment(seed=seed)
    regex = re.compile('[13][A-Za-z0-9]{32}')
    # Exercise
    actual = provider.bitcoin_address()
    # Verify
    assert regex.match(actual)


# Generated at 2022-06-23 21:33:23.591694
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.credit_card import CREDIT_CARD_REGEX
    p = RussiaSpecProvider(seed=42)
    # Generate random credit card owner with random gender
    credit_card_owner = p.payment.credit_card_owner()
    assert credit_card_owner['owner'] != ''
    assert re.match(CREDIT_CARD_REGEX, credit_card_owner['credit_card'])
    assert re.match(
        r'\d\d/\d{2}', credit_card_owner['expiration_date'])
    # Generate male credit card owner
    credit_card_owner_male = p.payment.credit_card_owner(
        gender=Gender.MALE)

# Generated at 2022-06-23 21:33:27.337510
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    n = p.credit_card_expiration_date()
    try:
        assert n
    except:
        assert False
    try:
        assert len(n) == 5
    except:
        assert False
    try:
        assert '/' in n
    except:
        assert False
    return 1

# Generated at 2022-06-23 21:33:34.072115
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Initialize the test
    payment = Payment()
    # Execute the test
    card = payment.credit_card_owner()
    # Verify that the test is correct
    assert card == {
                'credit_card': '4951 1561 8226 9020',
                'owner': 'JESSICA MERTZ',
                'expiration_date': '08/21'
        }

# Generated at 2022-06-23 21:33:35.136070
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    p.credit_card_owner()

# Generated at 2022-06-23 21:33:39.281747
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Test a credit_card_network from Payment class."""
    payment = Payment()
    credit_card_network = payment.credit_card_network()
    assert credit_card_network in CREDIT_CARD_NETWORKS



# Generated at 2022-06-23 21:33:42.236288
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    assert p.paypal() == 'schoenpadberg@hotmail.com'
    assert re.match(r'\w+@\w+\.\w+', p.paypal())

# Generated at 2022-06-23 21:33:46.378775
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    from mimesis.shortcuts import DataGenerator
    from mimesis.enums import Databases, PaymentTypes
    data = DataGenerator('en')
    bb = Payment('en')
    assert(data.databases.find(Databases.BITCOIN_ADDRESS) == bb.bitcoin_address())


# Generated at 2022-06-23 21:33:48.925851
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    payment = Payment('en', seed=123456)
    result = payment.credit_card_number()
    expected = '4455 5299 1152 2450'
    print(result)
    assert result == expected

# Generated at 2022-06-23 21:33:54.187335
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    expiration_date = payment.credit_card_expiration_date()
    year = int(expiration_date[-2:])
    month = int(expiration_date[:-3])
    if month < 0 or month > 12 or year < 16 or year > 25:
        raise AssertionError("Expiration date is invalid")

# Generated at 2022-06-23 21:33:55.081666
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert payment.paypal() == "wolf235@gmail.com"

# Generated at 2022-06-23 21:34:03.192571
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Function to test the method Payment.bitcoin_address."""
    payment = Payment(seed=1234567)
    assert payment.bitcoin_address() == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'
    assert payment.bitcoin_address() == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'
    assert payment.bitcoin_address() == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'
    assert payment.bitcoin_address() == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'

# Generated at 2022-06-23 21:34:06.444022
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    class_payment = Payment(seed=1)
    str_paypal = class_payment.paypal()
    assert str_paypal == "jeremy.richardson@hotmail.com"



# Generated at 2022-06-23 21:34:08.156333
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    assert type(p.cid()) == int



# Generated at 2022-06-23 21:34:17.039705
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    test_cid = payment.cid()
    test_paypal = payment.paypal()
    test_bit_address = payment.bitcoin_address()
    test_eth_address = payment.ethereum_address()
    test_net = payment.credit_card_network()
    test_card_num = payment.credit_card_number()
    test_date = payment.credit_card_expiration_date()
    test_cvv = payment.cvv()
    test_owner = payment.credit_card_owner()
    assert len(str(test_cid)) == 4
    assert re.match(r"^\S+@\S+\.\S+$", test_paypal)

# Generated at 2022-06-23 21:34:21.670793
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    assert len(p.bitcoin_address()) == 34
    assert p.bitcoin_address()[0] == '1' or p.bitcoin_address()[0] == '3'
    assert len(re.sub("[^A-Za-z0-9]", "", p.bitcoin_address())) == 34



# Generated at 2022-06-23 21:34:24.299354
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date(
    ) in ['07/22', '09/22', '03/22', '12/22', '2/22', '8/22', '10/22']

# Generated at 2022-06-23 21:34:29.014632
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    assert p.paypal()
    assert p.paypal() == p.paypal()
    assert p.paypal() == p.paypal()
    assert p.paypal() == p.paypal()

#Unit test for method bitcoin_address of class Payment

# Generated at 2022-06-23 21:34:35.812268
# Unit test for method cid of class Payment
def test_Payment_cid():
    p1 = Payment()
    x = p1.cid()
    p2 = Payment()
    y = p2.cid()
    y1 = y
    while y1 == y:
        p2 = Payment()
        y = p2.cid()
    y2 = y
    while y2 == y:
        p2 = Payment()
        y = p2.cid()
    assert x != y1 and x != y2 and y1 != y2



# Generated at 2022-06-23 21:34:38.441497
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    import mimesis
    import mimesis.enums
    payment = mimesis.Payment()
    payment.credit_card_number(mimesis.enums.CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-23 21:34:43.620881
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for i in range(1000):
        p = Payment()
        v1 = p.credit_card_number()
        v2 = p.credit_card_number()
        if v1 != v2:
            print(v1)
            print(v2)



# Generated at 2022-06-23 21:34:50.486290
# Unit test for method cid of class Payment
def test_Payment_cid():
    p=Payment()
    print(p.cid())
    print(p.paypal())
    print(p.bitcoin_address())
    print(p.ethereum_address())
    print(p.credit_card_network())
    print(p.credit_card_number())
    print(p.credit_card_expiration_date())
    print(p.cvv())
    print(p.credit_card_owner())


if __name__ == '__main__':
    test_Payment_cid()

# Generated at 2022-06-23 21:35:01.954729
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    ans = p.cid()
    assert isinstance(ans, int)
    ans = p.paypal()
    assert isinstance(ans, str)
    ans = p.bitcoin_address()
    assert isinstance(ans, str)
    ans = p.ethereum_address()
    assert isinstance(ans, str)
    ans = p.credit_card_network()
    assert isinstance(ans, str)
    ans = p.credit_card_number()
    assert isinstance(ans, str)
    ans = p.credit_card_expiration_date()
    assert isinstance(ans, str)
    ans = p.cvv()
    assert isinstance(ans, int)
    ans = p.credit_card_owner()
    assert isinstance(ans, dict)

# Generated at 2022-06-23 21:35:03.673165
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment(seed=42)
    assert payment.credit_card_network() == 'American Express'

# Generated at 2022-06-23 21:35:05.368823
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner()
    assert isinstance(owner['credit_card'], str)
    assert isinstance(owner['expiration_date'], str)
    assert isinstance(owner['owner'], str)

# Generated at 2022-06-23 21:35:11.221898
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Unit test for method credit_card_owner of class Payment."""
    pr = Payment(seed=100)
    print(pr.credit_card_owner(gender=Gender.FEMALE))
    # {'credit_card': '7572 7557 4323 1373', 'expiration_date': '01/23', 'owner': 'KAYLEE NEAL'}


# Generated at 2022-06-23 21:35:12.647293
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    print(Payment('ru').paypal())


# Generated at 2022-06-23 21:35:18.099477
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    payment = Payment()
    assert payment.credit_card_owner().keys() == {'credit_card',
                                                  'expiration_date',
                                                  'owner'}
    assert payment.credit_card_owner(Gender.MALE).get('owner') != \
           payment.credit_card_owner(Gender.FEMALE).get('owner')

# Generated at 2022-06-23 21:35:21.816931
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    # The result address by default should be 40 characters long
    assert(len(payment.ethereum_address()) == 42)


# Generated at 2022-06-23 21:35:23.579357
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert type(Payment().paypal()) == str


# Generated at 2022-06-23 21:35:25.693708
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Test method of class Payment."""
    payment = Payment()
    creditCardNetwork = payment.credit_card_network()
    assert creditCardNetwork != None
    assert isinstance(creditCardNetwork, str)
    assert creditCardNetwork != "Error"



# Generated at 2022-06-23 21:35:27.918893
# Unit test for method cid of class Payment
def test_Payment_cid():
    from mimesis import Payment
    Payment_inst = Payment(seed=123)
    assert Payment_inst.cid() == 7452


# Generated at 2022-06-23 21:35:31.450361
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment_m = Payment()
    owner = payment_m.credit_card_owner()
    assert owner['expiration_date'] == '01/19'
    assert owner['owner'] == 'MR. DAVID WHITE'
    assert owner['credit_card'][:2] == '42'

# Generated at 2022-06-23 21:35:41.454003
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date(minimum=3, maximum=29) == '01/21'
    assert payment.credit_card_expiration_date(minimum=3, maximum=29) == '01/21'
    assert payment.credit_card_expiration_date(minimum=3, maximum=29) == '01/21'
    assert payment.credit_card_expiration_date(minimum=3, maximum=29) == '01/21'
    assert payment.credit_card_expiration_date(minimum=3, maximum=29) == '01/21'
    assert payment.credit_card_expiration_date(minimum=3, maximum=29) == '01/21'

# Generated at 2022-06-23 21:35:44.330027
# Unit test for method cid of class Payment
def test_Payment_cid():
	cid = Payment().cid()
	assert type(cid) == int
	assert (cid >= 1000 and cid <= 9999)


# Generated at 2022-06-23 21:35:51.389064
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    card = Payment(seed = 123456789)

    result1 = card.credit_card_expiration_date(minimum = 10, maximum = 10)
    assert result1 == '11/10'

    result2 = card.credit_card_expiration_date(minimum = 10, maximum = 20)
    assert result2 == '08/20'

    result3 = card.credit_card_expiration_date(minimum = 12, maximum = 15)
    assert result3 == '04/12'


# Generated at 2022-06-23 21:35:52.226978
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment().credit_card_number()

# Generated at 2022-06-23 21:36:02.398611
# Unit test for constructor of class Payment
def test_Payment():
    """Test for constructor of class Payment"""
    payment_provider = Payment()
    assert payment_provider != None
    # Test for credit_card_number function
    assert payment_provider.credit_card_number() != None
    # Test for credit_card_expiration_date function
    assert payment_provider.credit_card_expiration_date() != None
    # Test for cvv function
    assert payment_provider.credit_card_owner() != None
    # Test for credit_card_owner function
    assert payment_provider.credit_card_owner() != None
    # Test for bitcoin_address function
    assert payment_provider.bitcoin_address() != None
    # Test for etherum_address function
    assert payment_provider.ethereum_address() != None

test_Payment()

# Generated at 2022-06-23 21:36:04.692460
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    x = Payment.Payment(seed=404).credit_card_network()
    assert x == 'JCB'


# Generated at 2022-06-23 21:36:09.437872
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment('en', seed=42)
    btc_add = payment.bitcoin_address()
    assert btc_add == "1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX"


# Generated at 2022-06-23 21:36:11.699824
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment(seed=1234)
    result = provider.credit_card_network()
    assert result == 'MasterCard'


# Generated at 2022-06-23 21:36:17.490408
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=30901)
    result = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert result == '4455 5299 1152 2450' or \
           result == '4455 5299 1152 2450' or \
           result == '4455 5299 1152 2450' or \
           result == '4455 5299 1152 2450'
    print("Finish unit test for Payment.credit_card_number()")



# Generated at 2022-06-23 21:36:19.445568
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    fake = Payment()
    print(fake.credit_card_expiration_date())

#Unit test for method credit_card_expiration_date of class Payment

# Generated at 2022-06-23 21:36:26.335266
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    from mimesis.enums import Gender
    # Method __init__ of class Person
    payment = Payment()
    paypal_account = payment.paypal()
    assert re.match("[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", paypal_account)


# Generated at 2022-06-23 21:36:27.565488
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    cc = Payment()
    print(cc.credit_card_owner())

# Generated at 2022-06-23 21:36:29.232918
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    number = payment.credit_card_number()
    assert len(number) == 19

# Generated at 2022-06-23 21:36:37.335299
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Initialize with a user-defined seed
    from mimesis import Payment
    from mimesis.enums import CardType
    p = Payment(seed=123)
    # Generate a random credit card number for Visa.
    cc_number = p.credit_card_number(CardType.VISA)
    print('credit card number for Visa: '+ cc_number)

    # Generate a random credit card number for American Express
    cc_number = p.credit_card_number(CardType.AMERICAN_EXPRESS)
    print('credit card number for American Express: ' + cc_number)
    # Generate a random credit card number for Master Card
    cc_number = p.credit_card_number(CardType.MASTER_CARD)
    print('credit card number for Master Card: ' + cc_number)


# Generated at 2022-06-23 21:36:38.643318
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment is not None


# Generated at 2022-06-23 21:36:41.434380
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    result = Payment().ethereum_address()
    assert len(result) == 42
    assert result[0:2] == '0x'



# Generated at 2022-06-23 21:36:52.180020
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Test for method credit_card_owner of class Payment"""
    from mimesis.enums import Gender
    from pprint import pprint

    pay = Payment()

    # Case 1: gender is provided
    gender = Gender.MALE
    result = pay.credit_card_owner(gender = gender)
    assert(isinstance(result, dict))
    assert(result["credit_card"].isnumeric() == True)
    assert(result["expiration_date"].replace("/", "").isnumeric() == True)
    assert(result["owner"].isupper() == True)

    # Case 1: gender is not provided
    result = pay.credit_card_owner()
    assert(isinstance(result, dict))
    assert(result["credit_card"].isnumeric() == True)

# Generated at 2022-06-23 21:36:59.981666
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    person_ = Payment()
    """
    owner = {
            'credit_card': self.credit_card_number(),
            'expiration_date': self.credit_card_expiration_date(),
            'owner': self.__person.full_name(gender=gender).upper(),
        }
    """
    credit_card = person_.credit_card_number()
    expiration_date = person_.credit_card_expiration_date()
    owner = person_.__person.full_name(gender=person_.random.choice(Gender)).upper()
    assert owner['credit_card'] == credit_card
    assert owner['expiration_date'] == expiration_date
    assert owner['owner'] == owner

# Generated at 2022-06-23 21:37:03.886220
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    list1 = []
    for i in range(10000):
        list1.append(payment.bitcoin_address())
    list1 = list(set(list1))
    assert len(list1) == 10000


# Generated at 2022-06-23 21:37:05.571191
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert(len(Payment().credit_card_expiration_date().split("/")) == 2)

# Generated at 2022-06-23 21:37:10.688431
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    card_type = CardType.VISA
    result = payment.credit_card_number(card_type)
    assert len(result) == 19 # should have 16 digits + 3 spaces
    assert result[4] == ' ' # 5th character should be a space
    assert result[9] == ' ' # 10th character should be a space
    assert result[14] == ' ' # 15th character should be a space
    assert result.startswith('4') # should start with 4, which is the starting of card_type VISA

    card_type = CardType.MASTER_CARD
    result = payment.credit_card_number(card_type)
    assert len(result) == 19 # should have 16 digits + 3 spaces
    assert result[4] == ' ' # 5th character should be a space
    assert result

# Generated at 2022-06-23 21:37:13.471489
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():

    test_method_of_class(Payment, method_name="credit_card_owner")

# Generated at 2022-06-23 21:37:22.845945
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    #Random credit card owner
    payment1 = Payment()
    owner1 = payment1.credit_card_owner()

    #Credit card owner by default
    payment2 = Payment()
    owner2 = payment2.credit_card_owner(Gender.MALE)

    #Credit card owner with random gender
    payment3 = Payment()
    owner3 = payment3.credit_card_owner(Gender.FEMALE)
    
    assert type(owner1['credit_card']) == type(owner2['credit_card']) == type(owner3['credit_card']) == str
    assert type(owner1['expiration_date']) == type(owner2['expiration_date']) == type(owner3['expiration_date']) == str

# Generated at 2022-06-23 21:37:27.357685
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    payment.seed(0)
    address = payment.bitcoin_address()
    assert address == "3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX"


# Generated at 2022-06-23 21:37:29.259313
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    address = payment.ethereum_address()
    if len(address) != 42:
        raise Exception("wrong length of the returned ethereum address")

# Generated at 2022-06-23 21:37:31.029824
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    test_Payment = Payment('en')
    print (test_Payment.ethereum_address())


# Generated at 2022-06-23 21:37:32.324946
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    assert len(payment.bitcoin_address()) == 34


# Generated at 2022-06-23 21:37:40.753982
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en', seed=42)
    visa_card = payment.credit_card_number(CardType.VISA)
    assert visa_card == '4539 5907 5242 9337'
    mastercard_card = payment.credit_card_number(CardType.MASTER_CARD)
    assert mastercard_card == '5178 5353 1660 8066'
    american_express_card = payment.credit_card_number(
        CardType.AMERICAN_EXPRESS)
    assert american_express_card == '3477 801671 80421'



# Generated at 2022-06-23 21:37:42.876396
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    for i in range(100):
        p = Payment()
        result = p.cvv()
        assert len(str(result)) == 3

# Generated at 2022-06-23 21:37:48.286046
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    for i in range(0,1000):
        print(p.bitcoin_address())
        # if p.bitcoin_address() != "1JztLWos5K7LsqW5E78EASgiVBaCe6f7cD":
        #     print(p.bitcoin_address())



# Generated at 2022-06-23 21:37:50.603812
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    for _ in range(10):
        print(Payment().credit_card_network())

# Generated at 2022-06-23 21:37:54.064386
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert re.match('[A-Za-z0-9.]{3,50}@[A-Za-z0-9.]{2,20}', payment.paypal())


# Generated at 2022-06-23 21:37:57.365180
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    owner = p.credit_card_owner(Gender.MALE)
    assert owner == {'credit_card': '4532 9341 5683 8939',
                     'expiration_date': '03/18',
                     'owner': 'MITCHELL BARTON'}

# Generated at 2022-06-23 21:38:03.619568
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert len(p.credit_card_number()) == 16
    assert len(p.credit_card_number(CardType.VISA)) == 16
    assert len(p.credit_card_number(CardType.MASTER_CARD)) == 16
    assert len(p.credit_card_number(CardType.AMERICAN_EXPRESS)) == 15

# Generated at 2022-06-23 21:38:11.637425
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')

    card_type = CardType.VISA
    credit_card_number = payment.credit_card_number(card_type=card_type)
    assert len(credit_card_number) == 19
    assert credit_card_number[:1] == '4'

    card_type = CardType.MASTER_CARD
    credit_card_number = payment.credit_card_number(card_type=card_type)
    assert len(credit_card_number) == 19
    assert credit_card_number[:2] in ('22', '51')

    card_type = CardType.AMERICAN_EXPRESS
    credit_card_number = payment.credit_card_number(card_type=card_type)
    assert len(credit_card_number) == 17
    assert credit_card

# Generated at 2022-06-23 21:38:13.524335
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    cvv = Payment(seed=123).cvv()
    assert cvv >= 100 and cvv <= 999

# Generated at 2022-06-23 21:38:16.873761
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    print("A random bitcoin address is " + payment.bitcoin_address())

if __name__ == '__main__':
    test_Payment_bitcoin_address()

# Generated at 2022-06-23 21:38:18.595636
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    result_str = payment.paypal()
    print(result_str)



# Generated at 2022-06-23 21:38:22.058256
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    import mimesis.providers.payment
    print(mimesis.providers.payment.Payment().ethereum_address())


# Generated at 2022-06-23 21:38:24.225774
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    for i in range(5):
        # print(p.credit_card_expiration_date())
        pass

# Generated at 2022-06-23 21:38:26.245178
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # create object Payment
    p = Payment()
    print(p.bitcoin_address())
    print(len(p.bitcoin_address()))


# Generated at 2022-06-23 21:38:28.169629
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment() # create a object Payment
    value = payment.ethereum_address() # get a ethereum address
    assert len(value) == 42 # check the length of it


# Generated at 2022-06-23 21:38:31.185293
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Unit test for method credit_card_number of class Payment
    # Create object Payment with seed random = 123456789
    py = Payment(random_seed = 123456789)
    #print(py.credit_card_number(CardType.VISA))
    assert py.credit_card_number(CardType.VISA) == '4728 8796 9901 8244'

# Generated at 2022-06-23 21:38:41.230894
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment(seed=1)
    assert p.credit_card_expiration_date(16, 20) == '01/18'
    assert p.credit_card_expiration_date(16, 20) == '01/20'
    assert p.credit_card_expiration_date(16, 20) == '01/19'
    assert p.credit_card_expiration_date(16, 20) == '12/18'
    assert p.credit_card_expiration_date(16, 20) == '04/18'
    assert p.credit_card_expiration_date(16, 20) == '07/18'
    assert p.credit_card_expiration_date(16, 20) == '08/18'

    p = Payment(seed=2)
    assert p.credit_card_expiration_

# Generated at 2022-06-23 21:38:43.097522
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    seed = 42
    p = Payment(seed=seed)
    assert p.cvv() == 489 # first call
    assert p.cvv() == 678 # second call

# Generated at 2022-06-23 21:38:46.161636
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    address = payment.ethereum_address()
    assert type(address) is str
    assert len(address) == 42

# Generated at 2022-06-23 21:38:48.505043
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment('en')
    print(p.credit_card_network())



# Generated at 2022-06-23 21:38:50.749351
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    a = Payment.credit_card_network()
    assert(isinstance(a, str))


# Generated at 2022-06-23 21:38:53.884641
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    print(p.cvv())
    print(p.credit_card_owner())
    print(p.credit_card_number())

# Generated at 2022-06-23 21:38:57.249979
# Unit test for method cid of class Payment
def test_Payment_cid():
    test_cid = Payment(random.random())
    assert test_cid.cid() >= 1000
    assert test_cid.cid() <= 9999
    assert type(test_cid.cid()) == int

    

# Generated at 2022-06-23 21:39:04.730493
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    y = Payment('en')
    a = y.credit_card_expiration_date(18, 18)
    assert a == "01/18"
    a = y.credit_card_expiration_date(16, 25)
    assert 16 <= int(a[-2:]) <= 25
    a = y.credit_card_expiration_date(0, 99)
    assert 0 <= int(a[-2:]) <= 99


# Generated at 2022-06-23 21:39:08.615373
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    num = payment.credit_card_number()
    assert len(num) == 19
    assert (re.match(r'\d{4} \d{4} \d{4} \d{4}', num) is not None)



# Generated at 2022-06-23 21:39:09.995281
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    # payment.bitcoin_address()
    payment.bitcoin_address()



# Generated at 2022-06-23 21:39:11.886554
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Test that this method return true value."""
    random_value = 23
    payment = Payment()
    assert payment.credit_card_expiration_date(16, 25)[3:5] == str(random_value)

# Generated at 2022-06-23 21:39:16.932436
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
  payment = Payment()
  assert payment.credit_card_owner()
  assert payment.credit_card_owner(Gender.MALE)
  assert payment.credit_card_owner(Gender.FEMALE)
  assert payment.credit_card_owner(Gender.NEUTRAL)


# Generated at 2022-06-23 21:39:18.603079
# Unit test for method cvv of class Payment
def test_Payment_cvv():
   p = Payment(seed=987654321)
   assert p.cvv() == 873


# Generated at 2022-06-23 21:39:23.519273
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    import random

    p = Payment()
    random.seed(1)
    result = p.credit_card_owner()

    expected = {'credit_card': '4444 4988 5049 5267',
                'expiration_date': '07/21',
                'owner': 'BEN RODRIGUEZ'}

    assert result == expected


# Generated at 2022-06-23 21:39:24.429675
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment is not None


# Generated at 2022-06-23 21:39:35.007463
# Unit test for constructor of class Payment
def test_Payment():
    seed = '15887547a6e9510cfc9fbd5ebd9c6579c5c5dfd982b5d42319732c575956686a'
    payment = Payment()
    payment.seed(seed)
    assert payment.seed == seed
    assert payment.random == payment.random
    assert payment.__person.name() == 'John'
    payment.random.seed(seed)
    assert payment.cid() == 4467
    assert payment.paypal() == 'Frederick.Jensen@yahoo.com'
    assert payment.bitcoin_address() == '3QMKJ9bA8VyjF6YwCz7pbgJ1F8V7GSaMpb'

# Generated at 2022-06-23 21:39:37.448477
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    seed = 123
    payment = Payment(seed=seed)
    assert payment.paypal() == "e1t45d2f@gmail.com"
    return


# Generated at 2022-06-23 21:39:39.044245
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    pp = Payment()
    for i in range(0,10):
        print(pp.credit_card_expiration_date())


# Generated at 2022-06-23 21:39:40.200146
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    object = Payment()
    assert object.paypal() != None


# Generated at 2022-06-23 21:39:44.147297
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment(seed=42)
    print(payment.ethereum_address())
    assert payment.ethereum_address() == '0x9007dd473f0a09a48bef8e20c2d5c5b5d5c5b5c5b5c5b5c5b'


# Generated at 2022-06-23 21:39:45.596787
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    print(payment.credit_card_expiration_date())


# Generated at 2022-06-23 21:39:47.330613
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # case: cvv_random_2digits
    assert len(str(Payment().cvv())) == 3



# Generated at 2022-06-23 21:39:49.402087
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment(locale='zh')
    bitcoin_address = payment.bitcoin_address()
    print(bitcoin_address)
    
if __name__ == "__main__":
    test_Payment_bitcoin_address()

# Generated at 2022-06-23 21:39:53.642208
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    x = Payment()
    y = Payment()
    count = 0
    for _ in range(100):
        if x.cvv() != y.cvv():
            count += 1
    assert count == 100


# Generated at 2022-06-23 21:39:56.125811
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    test_object = Payment()
    assert type(test_object.cvv()) is int


# Generated at 2022-06-23 21:39:57.569750
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment()
    print(provider.credit_card_number())

# Generated at 2022-06-23 21:40:00.453209
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    obj = Payment()
    assert re.match(r'(1|3)[a-zA-Z0-9]{33}', obj.bitcoin_address()) is not None


# Generated at 2022-06-23 21:40:03.612654
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:40:07.473758
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment(seed=1)
    bitcoin_address = payment.bitcoin_address()
    assert bitcoin_address == '1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2'


# Generated at 2022-06-23 21:40:08.659505
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment is not None

# Generated at 2022-06-23 21:40:11.241289
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    pay = p.paypal()
    assert isinstance(pay, str) is True
    assert '@' in pay is True


# Generated at 2022-06-23 21:40:15.001240
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    pattern = re.compile(r'[13][A-Za-z0-9]{33}')
    addr = payment.bitcoin_address()
    match = pattern.match(addr)
    assert(match.group()) == addr


# Generated at 2022-06-23 21:40:22.456503
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    #test for random generation of a credit card number
    payment = Payment()
    assert payment.credit_card_number()
    assert payment.credit_card_number(CardType.VISA)
    assert payment.credit_card_number(CardType.MASTER_CARD)
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS)

    #test for invalid input to method
    payment = Payment()
    try:
        payment.credit_card_number(CardType.DISCOVER)
    except NonEnumerableError:
        assert True
    except:
        assert False

    #test for invalid data type in argument
    try:
        payment.credit_card_number('VISA')
    except TypeError:
        assert True
    except:
        assert False