

# Generated at 2022-06-23 21:30:18.181072
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """Test function for method Payment.paypal."""
    provider = Payment()
    paypal = provider.paypal()
    assert isinstance(paypal, str)
    assert re.search(r'\w{3,}@\w{3,}\.\w{2,}', paypal)


# Generated at 2022-06-23 21:30:19.393060
# Unit test for constructor of class Payment
def test_Payment():
    p1 = Payment()


# Generated at 2022-06-23 21:30:21.247756
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment(seed=42)
    assert 424 == payment.cvv()


# Generated at 2022-06-23 21:30:22.841693
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    x = Payment()
    x.cvv()
    return x

# Generated at 2022-06-23 21:30:30.694119
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment(seed=123)
    assert payment.cid() == 7452
    assert payment.paypal() == 'wolf235@gmail.com'
    assert payment.bitcoin_address() == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'
    assert payment.ethereum_address() == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'
    assert payment.credit_card_network() == 'MasterCard'
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_expiration_date() == '03/19'
    assert payment.cvv() == 324

# Generated at 2022-06-23 21:30:35.357911
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    card_networks = CREDIT_CARD_NETWORKS
    test = Payment()
    for i in range(0, 100):
        assert test.credit_card_network() in card_networks


# Generated at 2022-06-23 21:30:37.177257
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment_obj = Payment()
    assert isinstance(payment_obj.paypal(), str)


# Generated at 2022-06-23 21:30:38.971942
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment(seed=1)
    assert (p.cid() == 8620)


# Generated at 2022-06-23 21:30:41.719305
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment(seed=123)
    assert p.bitcoin_address() == "3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX"

# Generated at 2022-06-23 21:30:50.623057
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Test upper bound
    payment = Payment(seed=1000)
    email = payment.paypal()
    assert len(email) < 256
    assert '@' in email
    assert email in ['wolf235@gmail.com', 'f.curtis4@live.com']

    # Test lower bound
    payment = Payment(seed=1001)
    email = payment.paypal()
    assert len(email) < 256
    assert '@' in email
    assert email in ['kathy.cornelius@yahoo.com', 'michaelmm@aol.com']


# Generated at 2022-06-23 21:30:54.983637
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment('en')
    assert re.match('^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$', payment.paypal()) != None


# Generated at 2022-06-23 21:30:59.142578
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    print(p.credit_card_expiration_date())
    print(p.credit_card_expiration_date(minimum=18, maximum=22))

# Unittest for method credit_card_owner of class Payment

# Generated at 2022-06-23 21:31:00.534357
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    print(payment.paypal())


# Generated at 2022-06-23 21:31:03.699774
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert card_number == "4455 5299 1152 2450"
    assert len(card_number) == 17

# Generated at 2022-06-23 21:31:05.755956
# Unit test for constructor of class Payment
def test_Payment():
    from test_cases import PaymentTestCase
    # TODO: Re-enable this test
    #PaymentTestCase.test_Payment()

# Generated at 2022-06-23 21:31:09.260951
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    my_payment = Payment()
    cco = my_payment.credit_card_owner()
    print(cco)
    return cco


# Generated at 2022-06-23 21:31:12.450815
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cvv = payment.cvv()
    if not cvv:
        assert(0)
    else:
        assert(1)



# Generated at 2022-06-23 21:31:14.894710
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    card = Payment()
    assert (card.credit_card_network() in CREDIT_CARD_NETWORKS)


# Generated at 2022-06-23 21:31:25.334957
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Define Payment object
    payment = Payment()

    # Get the result from method paypal of Payment
    result = payment.paypal()

    # Expected result:
    # an string with "@" that matches the regex [a-z0-9-_]+@[a-z0-9-_]+\.[a-z0-9-_]+(\.[a-z0-9-_]+)
    assert re.match(r"[a-z0-9-_]+@[a-z0-9-_]+\.[a-z0-9-_]+(\.[a-z0-9-_]+)?", result)



# Generated at 2022-06-23 21:31:36.934509
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment('en')

# Generated at 2022-06-23 21:31:40.759335
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """
    Test if the generated card network is among the available values
    """
    payment = Payment()
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS

# Generated at 2022-06-23 21:31:44.288511
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Test function ethereum_address of class Payment."""
    address = Payment().ethereum_address()
    assert isinstance(address, str)
    assert len(address) == 42
    assert address.startswith('0x')


# Generated at 2022-06-23 21:31:45.950783
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment(seed=5)
    assert provider.credit_card_network() == 'MasterCard'


# Generated at 2022-06-23 21:31:49.817025
# Unit test for constructor of class Payment
def test_Payment():
    # Valid case:
    print('\n# Valid case:')
    print(Payment().wallet('ETH'))
    print(Payment().wallet('LTC'))
    print(Payment().wallet('BTC'))


# Generated at 2022-06-23 21:31:54.288605
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    month = p.random.randint(1, 12)
    year = p.random.randint(16, 25)
    assert_expiration_date = '{0:02d}/{1}'.format(month, year)
    assert p.credit_card_expiration_date() == assert_expiration_date

# Generated at 2022-06-23 21:31:58.066835
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    for i in range(0, 10):
        print('\n' + Payment.credit_card_network())


# Generated at 2022-06-23 21:31:59.178811
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    assert Payment().ethereum_address() != Payment().ethereum_address()

# Generated at 2022-06-23 21:32:02.044419
# Unit test for constructor of class Payment
def test_Payment():
    assert Payment().credit_card_number(CardType.VISA) is not None
    assert re.match(r'[0-9]{4}\s[0-9]{4}\s[0-9]{4}\s[0-9]{4}', Payment().credit_card_number(CardType.VISA))

# Generated at 2022-06-23 21:32:05.821190
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc_number = Payment().credit_card_number()
    print("credit_card_number: " + cc_number)
    assert type(cc_number) == str, "Credit card number is not a string"
    assert len(cc_number) == 19, "Credit card is not 16 digits long"


# Generated at 2022-06-23 21:32:08.621447
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cvv = payment.cvv()
    assert len(str(cvv)) == 3

test_Payment_cvv()


# Generated at 2022-06-23 21:32:10.550927
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment is not None


# Generated at 2022-06-23 21:32:18.341551
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert(p.cid() != None)
    assert(p.paypal() != None)
    assert(p.bitcoin_address() != None)
    assert(p.ethereum_address() != None)
    assert(p.credit_card_network() != None)
    assert(p.credit_card_network() in CREDIT_CARD_NETWORKS)
    assert(p.credit_card_number(CardType.VISA) != None)
    assert(p.credit_card_expiration_date() != None)
    assert(p.cvv() != None)
    assert(p.credit_card_owner() != None)

# Generated at 2022-06-23 21:32:20.084846
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    assert payment.credit_card_network() is not None


# Generated at 2022-06-23 21:32:28.869809
# Unit test for constructor of class Payment
def test_Payment():
    """
    class Payment(BaseProvider)
     |  Class that provides data related to payments.
    """

    p = Payment(seed=1234)
    # return: CID code.
    # :Example:
        # 7452
    assert p.cid() == 3394
    # return: Email of PapPal user.
    # :Example:
        # wolf235@gmail.com
    assert p.paypal() == 'harrisonmiller@gmail.com'
    # return: Bitcoin address.
    # :Example:
        # 3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX
    assert p.bitcoin_address() == '1OVzsUVhnKxT2WbTvTMCPSCk6wWWU8ZDUD'
    #

# Generated at 2022-06-23 21:32:32.838523
# Unit test for constructor of class Payment
def test_Payment():
    # create obj
    my_obj = Payment()
    # check is-a
    assert isinstance(my_obj, Payment)
    # check parent class
    assert isinstance(my_obj, BaseProvider)


# Generated at 2022-06-23 21:32:35.392176
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pay = Payment()
    a = pay.paypal()
    assert a.count('@') == a.count('.') == 1


# Generated at 2022-06-23 21:32:37.222039
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert payment.cvv() >= 100
    assert payment.cvv() <= 999

# Generated at 2022-06-23 21:32:47.873713
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Create a payment object
    payment = Payment()
    # Generate credit card owner
    credit_card_owner = payment.credit_card_owner()
    # Assert that credit card owner is a dict
    assert isinstance(credit_card_owner, dict)
    # Assert that credit card owner has 3 keys:
    assert len(credit_card_owner) == 3
    assert "credit_card" in credit_card_owner
    assert "expiration_date" in credit_card_owner
    assert "owner" in credit_card_owner
    # Assert that credit card number is a string
    assert isinstance(credit_card_owner["credit_card"], str)
    # Assert that expiration date is a string
    assert isinstance(credit_card_owner["expiration_date"], str)
    # Assert that owner's name is

# Generated at 2022-06-23 21:32:51.280220
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Import
    from mimesis.builtins import Payment

    # Instantiate
    payment = Payment()

    # Test
    assert (payment.cid() > 1000 and payment.cid() < 9999)



# Generated at 2022-06-23 21:32:54.445574
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    payment = Payment('en')
    result = payment.credit_card_network()
    assert isinstance(result,str)


# Generated at 2022-06-23 21:32:59.421109
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    minimum = 16
    maximum = 25
    result = payment.credit_card_expiration_date(minimum, maximum)
    assert len(result) == 5
    assert int(result[3:]) >= minimum
    assert int(result[3:]) <= maximum
    assert int(result[0:2]) >= 1
    assert int(result[0:2]) <= 12

# Generated at 2022-06-23 21:33:01.353285
# Unit test for constructor of class Payment
def test_Payment():
    seed = 12345
    payment = Payment(seed=seed)
    assert (payment is not None)



# Generated at 2022-06-23 21:33:03.077929
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Test function."""
    paid = Payment()
    assert paid.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:33:06.384358
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    instance = Payment()
    assert isinstance(instance.credit_card_number(), str)
    assert len(instance.credit_card_number()) >= 16


# Generated at 2022-06-23 21:33:13.259561
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    paypal = Payment()
    assert (len(paypal.paypal()) == 28 and
            '@' in paypal.paypal() and
            paypal.paypal().split('@')[1].__len__() == 13  and
            paypal.paypal().split('@')[1][:-4].isalpha() and
            paypal.paypal().split('@')[1][-4:].isdigit())


# Generated at 2022-06-23 21:33:24.052486
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    This is the unit test for testing the methods of class Payment
    """
    payment1 = Payment()
    payment2 = Payment()
    payment3 = Payment()
    payment4 = Payment()
    card_number1 = payment1.credit_card_number()
    card_number2 = payment2.credit_card_number(CardType.VISA)
    card_number3 = payment3.credit_card_number(CardType.MASTER_CARD)
    card_number4 = payment4.credit_card_number(CardType.AMERICAN_EXPRESS)
    card_type_set = [CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS]
    assert len(card_number1) == 16

# Generated at 2022-06-23 21:33:26.571455
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Test cvv of class Payment."""
    p = Payment()
    for _ in range(10):
        cvv = p.cvv()
        assert cvv >= 100 and cvv <= 999

# Generated at 2022-06-23 21:33:29.489145
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Unit test for method cvv of class Payment"""
    pyment = Payment()
    int(pyment.cvv())

# Generated at 2022-06-23 21:33:35.676010
# Unit test for method cid of class Payment
def test_Payment_cid():
    from mimesis.typing import Seed
    from mimesis.enums import CardType, Gender, Locale
    from mimesis.providers.payment import Payment
    from mimesis.providers.person import Person
    import pytest
    from faker.utils.types import JSONType
    faker = Payment(locale="en", seed=8792)  # Should always print same result
    assert faker.cid() == 3259


# Generated at 2022-06-23 21:33:46.258820
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment(seed=12345)

    test_1 = payment.bitcoin_address()
    assert test_1 == "32XoEe8MHpjKbzYFoJ2QH92MSZ3XX7VgBz"

    test_2 = payment.bitcoin_address()
    assert test_2 == "34vk8uwMuCnStg6aA9XDvDa8WxQ6U2kk6U"

    test_3 = payment.bitcoin_address()
    assert test_3 == "13XE4ChYEA5hjP5ZSzMZPTMG1jKtbSeVgG"

    test_4 = payment.bitcoin_address()

# Generated at 2022-06-23 21:33:47.794846
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert payment.cvv() >= 100 and payment.cvv() <= 999


# Generated at 2022-06-23 21:33:48.681169
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.cid()

# Generated at 2022-06-23 21:33:51.552357
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Initialize Payment object
    card_obj = Payment()
    # print(card_obj.credit_card_owner())


# Generated at 2022-06-23 21:33:57.824634
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """
    Unit test function for method credit_card_owner of class Payment.
    :return: None
    """
    # create Payment object
    payment = Payment()
    print(payment.credit_card_owner())
    print(payment.credit_card_owner(gender=Gender.MALE))
    print(payment.credit_card_owner(gender=Gender.FEMALE))



# Generated at 2022-06-23 21:34:01.074390
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    assert (p.credit_card_expiration_date(20, 20) < '13/20')
    assert (p.credit_card_expiration_date() < '13/25')
    assert (p.credit_card_expiration_date() < '13/25')
    assert (p.credit_card_expiration_date(20, 20) == '02/20')


# Generated at 2022-06-23 21:34:03.175975
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    result = payment.paypal()
    assert len(result) > 10


# Generated at 2022-06-23 21:34:05.242094
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment(seed=100)
    result = payment.cvv()
    assert result == 807


# Generated at 2022-06-23 21:34:06.671232
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert payment.cid() > 0



# Generated at 2022-06-23 21:34:16.269489
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis import Payment, Mimesis
    from mimesis.enums import Seed

    p = Payment(Mimesis(locale='en'))
    address = p.ethereum_address()
    print(address)
    assert isinstance(address, str)
    assert len(address) == 42

    m = Mimesis(locale='en')
    address = Payment(m).ethereum_address()
    print(address)
    assert isinstance(address, str)
    assert len(address) == 42

    m = Mimesis('en', seed=Seed.MIMESIS)
    address = Payment(m).ethereum_address()
    print(address)
    assert isinstance(address, str)
    assert len(address) == 42


# Generated at 2022-06-23 21:34:18.316225
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    payment.credit_card_expiration_date()


# Generated at 2022-06-23 21:34:21.458999
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    address = p.bitcoin_address()
    assert address == "1rCENpfL5NwKW8YvG6Y9X9LBxQWH5Cd8Kv"


# Generated at 2022-06-23 21:34:24.133495
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    class_name = 'Payment'
    method_name = 'paypal'
    test_object = Payment('en')
    result = test_object.paypal()
    assert callable(getattr(test_object, method_name))



# Generated at 2022-06-23 21:34:30.080433
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    
    from mimesis.providers.payment import Payment
    from mimesis.enums import Gender

    pay = Payment()
    # print(pay.paypal())
    # wolf235@gmail.com
    assert re.match(re.compile(r'[\w.-]+@\w+\.\w+'), pay.paypal()) == None


# Generated at 2022-06-23 21:34:40.200201
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    assert_that(Payment().credit_card_number()).matches(r'\d{4}\s\d{4}\s\d{4}\s\d{4}')
    assert_that(Payment().credit_card_number(CardType.VISA)).matches(r'4\d{3}\s\d{4}\s\d{4}\s\d{4}')
    assert_that(Payment().credit_card_number(CardType.MASTER_CARD)).matches(r'5[1-5]\d{2}\s\d{4}\s\d{4}\s\d{4}')

# Generated at 2022-06-23 21:34:42.373872
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    print(p.ethereum_address())

# Generated at 2022-06-23 21:34:45.289451
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment('en')
    # TODO: Fix it and test it!
    # assert payment.credit_card_expiration_date()
    # assert payment.credit_card_expiration_date(16, 25)
    # assert payment.credit_card_expiration_date(15, 28)

# Generated at 2022-06-23 21:34:46.703572
# Unit test for method cid of class Payment
def test_Payment_cid():
    obj = Payment()
    assert obj.cid() == 7452


# Generated at 2022-06-23 21:34:49.281021
# Unit test for constructor of class Payment
def test_Payment():
    seed = 100
    p = Payment(seed=seed)
    assert p.seed is not None
    assert p.seed == seed

# Generated at 2022-06-23 21:34:54.078377
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    a = Payment(seed=42)
    assert(a.bitcoin_address() == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX')


# Generated at 2022-06-23 21:34:56.728915
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    import random

    random.seed(1)
    Payment().credit_card_owner()

    assert 'VISA' in Payment().credit_card_owner()['credit_card']

# Generated at 2022-06-23 21:35:05.163482
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # Define variable p as a instance of class Payment
    p = Payment()
    # Register the number of test
    count = 0
    # Run 100 times
    while (count < 100):
        # Add 1 to count
        count += 1
        # Get a random bitcoin address
        btcAddress = p.bitcoin_address()
        # Check the length of the address
        assert len(btcAddress) == 35
        # Check the first and second characters
        assert btcAddress[0] == '1' or btcAddress[0] == '3'
        assert btcAddress[1] != '1' and btcAddress[1] != '3'

# Generated at 2022-06-23 21:35:06.061550
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    Payment.credit_card_expiration_date()

# Generated at 2022-06-23 21:35:11.276838
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    """Unit test for method credit_card_expiration_date of class Payment."""
    payment = Payment()
    print('credit_card_expiration_date: ', payment.credit_card_expiration_date())
    # Output:
    # credit_card_expiration_date:  07/24


# Generated at 2022-06-23 21:35:19.944449
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment(seed=1)
    assert p.cid() == 5774
    assert p.paypal() == 'louismcbride@gmail.com'
    assert p.bitcoin_address() == '1vA6Z9h6T9b6r8qDUx2QygpP6YhL8nR1za'
    assert p.ethereum_address() == '0xa5abed12f03b4c38c4b4a3f4c9a9bce5f21d377f'
    assert p.credit_card_network() == 'Visa'
    assert p.credit_card_number(card_type=CardType.VISA) == '4455 5294 3232 1660'

# Generated at 2022-06-23 21:35:22.754627
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
     print("------test_Payment_credit_card_network------")

     p = Payment()
     print(p.credit_card_network())


# Generated at 2022-06-23 21:35:29.231569
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # create an instance for class Payment
    payment = Payment()
    # call the method credit_card_expiration_date of class Payment
    # with the following parameters
    # minimum of date : 16
    # maximum of date : 25
    credit_card_expiration_date = payment.credit_card_expiration_date(16, 25)
    # check if credit_card_expiration_date is String
    assert isinstance(credit_card_expiration_date, str)


# Generated at 2022-06-23 21:35:31.627014
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    for _ in range(10):
        assert len(str(Payment().cvv()))==3
        assert len(str(Payment().cvv()))==3

# Generated at 2022-06-23 21:35:37.418398
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment_method = Payment()
    for _ in range(100):
        credit_card_number = payment_method.credit_card_number(CardType.VISA)
        assert credit_card_number[0] == '4'
        assert len(credit_card_number) == 19
        assert luhn_checksum(credit_card_number.replace(' ', ''))


# Generated at 2022-06-23 21:35:40.180439
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Unit test for method "credit_card_number"."""
    payment = Payment()
    credit_card_network = payment.credit_card_network()
    assert credit_card_network in CREDIT_CARD_NETWORKS

# Generated at 2022-06-23 21:35:44.599345
# Unit test for method cid of class Payment
def test_Payment_cid():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    p = Payment(RussiaSpecProvider)

    assert len(str(p.cid())) == 4
# END test_Payment_cid


# Generated at 2022-06-23 21:35:49.970744
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    amount = 0
    for i in range(1000):
        p = Payment(seed=1)
        pattern = re.compile("^1[a-zA-Z0-9]{33}$")
        if pattern.match(p.bitcoin_address()) != None:
            amount += 1
    assert amount > 0


# Generated at 2022-06-23 21:35:53.624564
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p_test = Payment()
    assert p_test.credit_card_expiration_date() == '03/25'


# Generated at 2022-06-23 21:35:55.438188
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    assert isinstance(p.credit_card_network(), str)


# Generated at 2022-06-23 21:35:56.897935
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    for _ in range(1000):
        a = payment.bitcoin_address()
        # print(a)


# Generated at 2022-06-23 21:35:57.911914
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    assert Payment().ethereum_address()

# Generated at 2022-06-23 21:36:05.937334
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment

    payment = Payment()
    owner = payment.credit_card_owner()
    print("Credit card owner:")
    print("Card: " + owner['credit_card'])
    print("Exp Date: " + owner['expiration_date'])
    print("Owner: " + owner['owner'])
    print("")
    owner = payment.credit_card_owner(Gender.MALE)
    print("Credit card owner (male):")
    print("Card: " + owner['credit_card'])
    print("Exp Date: " + owner['expiration_date'])
    print("Owner: " + owner['owner'])
    print("")
    owner = payment.credit_card_owner(Gender.FEMALE)
    print

# Generated at 2022-06-23 21:36:10.759184
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    # Generator of cvv
    cvv = payment.cvv()
    # Check that cvv is a integer
    assert isinstance(cvv, int)
    # Check that cvv is not a string
    assert not isinstance(cvv, str)
    # Check that length of cvv is 3
    assert len(str(cvv)) == 3
    # Check that cvv is not null
    assert cvv != None


# Generated at 2022-06-23 21:36:14.877224
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.cid()
    assert payment.paypal()
    assert payment.bitcoin_address()
    assert payment.ethereum_address()
    assert payment.credit_card_network()
    assert payment.credit_card_number()
    assert payment.credit_card_expiration_date()
    assert payment.credit_card_owner()
    assert payment.cvv()

# Generated at 2022-06-23 21:36:17.751423
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert len(Payment().credit_card_expiration_date()) == 5
    assert len(Payment().credit_card_expiration_date(minimum=16, maximum=25)) == 5


# Generated at 2022-06-23 21:36:23.550249
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment('en', seed=0)
    result1 = payment.credit_card_expiration_date(16, 25)
    result2 = payment.credit_card_expiration_date(16, 25)
    result3 = payment.credit_card_expiration_date(16, 25)
    result4 = payment.credit_card_expiration_date(16, 25)
    result5 = payment.credit_card_expiration_date(16, 25)
    assert result1 == result2 == result3 == result4 == result5


# Generated at 2022-06-23 21:36:26.662822
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    m = Payment()
    paypal = m.paypal()
    assert len(paypal) == 16
    assert paypal.find("@") != -1


# Generated at 2022-06-23 21:36:30.064197
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for i in range(1000):
        credit_card_number = payment.credit_card_number()
        print(credit_card_number, end=' ')
        assert(len(credit_card_number) == 19)
    print()


# Generated at 2022-06-23 21:36:31.391083
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(locale='en')
    payment.credit_card_number()

# Generated at 2022-06-23 21:36:32.342492
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    date = payment.credit_card_expiration_date()
    assert date == '09/18'

# Generated at 2022-06-23 21:36:37.007278
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis.enums import Gender
    from mimesis.random import Random
    from mimesis.providers.payment import Payment

    payment = Payment(random=Random(123))
    assert payment._Payment__person.full_name(gender=Gender.MALE) == 'James Ramos'

# Generated at 2022-06-23 21:36:38.277007
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert isinstance(p, Payment)


# Generated at 2022-06-23 21:36:39.903437
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    res = Payment().paypal()
    assert res != 0

# Generated at 2022-06-23 21:36:50.979801
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():

    import logging
    import os
    from mimesis.enums import Gender

    # Setup logging:
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(levelname)s - %(message)s')
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    logger = logging.getLogger(__name__)

    # Obtain the environment variable for SEED:
    SEED = int(os.getenv('SEED'))

    # Obtain a instance of class Payment:
    payment = Payment(SEED)

    result = payment.credit_card_owner(gender=Gender.FEMALE)
    assert result['credit_card']
    assert result

# Generated at 2022-06-23 21:36:58.794172
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # Initialize Payment class
    Payment = Payment()

    # Get the random expiration date
    cc_exp_date = Payment.credit_card_expiration_date()

    # Check if the expiration date is equal to a valid date
    assert cc_exp_date == '03/19'

    # Get the random expiration date
    cc_exp_date = Payment.credit_card_expiration_date(minimum=16, maximum=23)

    # Check if the expiration date is equal to a valid date
    assert cc_exp_date == '10/16'

    # Get the random expiration date
    cc_exp_date = Payment.credit_card_expiration_date(minimum=18, maximum=21)

    # Check if the expiration date is equal to a valid date
    assert cc_exp_date == '04/18'

    # Print the expiration

# Generated at 2022-06-23 21:37:01.294946
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cid = payment.cid()
    print(cid)
    assert cid < 9999 and cid > 999


# Generated at 2022-06-23 21:37:04.388295
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    value1 = payment.cvv()
    value2 = payment.cvv()
    assert not(value1 == value2)


# Generated at 2022-06-23 21:37:06.411774
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # Set up for unit test
    test = Payment()
    # Unit test
    test.credit_card_expiration_date()

# Generated at 2022-06-23 21:37:07.535048
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment(seed=1)
    print(p.credit_card_expiration_date())


# Generated at 2022-06-23 21:37:13.699420
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis.enums import Gender

    Payment().ethereum_address()
    # 0xe8ece9e6ff7dba52d4c07d37418036a89af9698d

    Payment(seed=4).ethereum_address()
    # 0x7d49b3554efd7fd8b3f3fd9f1c2e2fb724634b00

    Payment().credit_card_number()
    # 4455 5299 1152 2450

    Payment().credit_card_number(CardType.MASTER_CARD)
    # 2878 9283 5224 2450

    Payment(seed=4).credit_card_number(CardType.MASTER_CARD)
    # 5532 6924 8228 2450


# Generated at 2022-06-23 21:37:23.000960
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment_ = Payment()

    payment_.random.seed(1)
    assert payment_.credit_card_expiration_date() == '11/16'

    payment_.random.seed(2)
    assert payment_.credit_card_expiration_date(minimum=17) == '04/18'

    payment_.random.seed(3)
    assert payment_.credit_card_expiration_date(minimum=17, maximum=19) ==\
           '01/19'

    # Test that credit_card_expiration_date returns a string type
    payment_.random.seed(3)
    assert isinstance(payment_.credit_card_expiration_date(
        minimum=17, maximum=19), str)
    # Test that credit_card_expiration_date returns a value between minimum
    # and maximum

# Generated at 2022-06-23 21:37:26.269768
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    address = payment.ethereum_address()
    assert len(address) == 42
    assert address[0:2] == '0x'

# Generated at 2022-06-23 21:37:27.985383
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    print(payment.cvv())



# Generated at 2022-06-23 21:37:30.627807
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment('en', seed=0xDEADBEEF)
    assert(p.paypal() == 'sflanagan@hotmail.com')


# Generated at 2022-06-23 21:37:40.754430
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError

    payment = Payment('en')
    assert isinstance(payment.credit_card_owner(), dict)
    assert isinstance(payment.credit_card_owner(gender=None), dict)
    assert isinstance(payment.credit_card_owner(gender=Gender.MALE), dict)
    assert isinstance(payment.credit_card_owner(gender=Gender.FEMALE), dict)
    assert payment.credit_card_owner(gender=None) == {
        'credit_card': payment.credit_card_number(),
        'expiration_date': payment.credit_card_expiration_date(),
        'owner': payment.person().full_name(gender=None).upper()
    }

# Generated at 2022-06-23 21:37:49.441338
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment('en')
    type_ = CardType.VISA
    assert len(p.credit_card_number()) == 16
    assert p.credit_card_number(type_).startswith('4')
    assert len(p.credit_card_number(type_)) == 16
    assert p.credit_card_number(CardType.MASTER_CARD).startswith('5')
    assert len(p.credit_card_number(CardType.MASTER_CARD)) == 16
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS).startswith('3')
    assert len(p.credit_card_number(CardType.AMERICAN_EXPRESS)) == 15

# Generated at 2022-06-23 21:37:51.471944
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    assert len(payment.bitcoin_address()) == 34


# Generated at 2022-06-23 21:37:59.822310
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType

    payment = Payment('en')
    assert re.match(r'\d{16}', payment.credit_card_number())

    payment = Payment('en')
    assert re.match(r'\d{16}', payment.credit_card_number(card_type=CardType.VISA))

    payment = Payment('en')
    assert re.match(r'\d{16}', payment.credit_card_number(card_type=CardType.MASTER_CARD))

    payment = Payment('en')
    assert re.match(r'\d{15}', payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-23 21:38:07.509479
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment("en")
    assert p.cid() >= 1000 and p.cid() <= 9999
    assert p.credit_card_number(CardType.VISA).startswith("4")
    assert p.credit_card_number(CardType.MASTER_CARD).startswith("5")
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS).startswith("34")
    assert p.credit_card_expiration_date() >= "01/16"
    assert p.credit_card_expiration_date() <= "12/25"
    assert p.cvv() >= 100 and p.cvv() <= 999
    assert p.credit_card_network() in ["Visa", "MasterCard", "American Express"]

# Generated at 2022-06-23 21:38:10.510522
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    r = Payment('en')
    x = r.ethereum_address()
    p = re.compile('^[0][x].*')
    assert p.match(x) is not None

# Generated at 2022-06-23 21:38:12.475232
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert isinstance(payment, Payment), "Failed."


# Generated at 2022-06-23 21:38:13.982800
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    print(payment.ethereum_address())

# Generated at 2022-06-23 21:38:17.685280
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment(seed=42)
    assert payment.ethereum_address() == '0x8ddb8d0b0dab1a657eac3e657042fcf1a2d9dce3'

# Generated at 2022-06-23 21:38:22.243141
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment(seed=123)
    print(payment.ethereum_address())
    assert payment.ethereum_address() == "0xcd7c9e0d80b7ccd779cf2d2182ed0c602f45d41e"


# Generated at 2022-06-23 21:38:24.052410
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert payment.paypal() != payment.paypal()


# Generated at 2022-06-23 21:38:25.188202
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    n = Payment()
    assert n.credit_card_expiration_date()

# Generated at 2022-06-23 21:38:26.548826
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert len(payment.credit_card_expiration_date()) == 5

# Generated at 2022-06-23 21:38:31.683017
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    # Step 1.
    # Create an object of the class "Payment".
    payment = Payment()
    # Step 2.
    # Generate a random credit card network.
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:38:35.882908
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    for i in range(100):
        assert(payment.credit_card_expiration_date(15, 16).split("/")[1] == '15' or payment.credit_card_expiration_date(15, 16).split("/")[1] == '16')

# Generated at 2022-06-23 21:38:45.256653
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    import payment
    import unittest

    def assertValidEmail(email):
        """
        Checks whether given string is a valid email address.

        An email address has format local_part@domain

        If local_part contains special characters !#$%&'*+-/=?^_`{|}~
        they need to be quoted in <>
        """
        if email.count('@') != 1:
            return False
        local_part, domain = email.split('@')
        specials = r'()<>,:;[\]@'
        qtext = r'[^\\{}\x01-\x08\x0b\x0c\x0e-\x1f\x7f]+'
        dtext = r'[^\[\]\x80-\xff]+'

# Generated at 2022-06-23 21:38:55.251229
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from random import seed
    from mimesis.enums import CardType
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.payment import Payment
    c = Payment(seed=123)
    assert c.ethereum_address() == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'
    assert c.bitcoin_address() == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'
    assert c.credit_card_network() == 'MasterCard'
    assert c.credit_card_number() == '4455 5299 1152 2450'

# Generated at 2022-06-23 21:38:58.100743
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    data = payment.credit_card_expiration_date()
    assert data
    # print("test_Payment_credit_card_expiration_date:", data)


# Generated at 2022-06-23 21:39:00.554856
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert payment.cid() >= 1000
    assert payment.cid() <= 9999


# Generated at 2022-06-23 21:39:03.604908
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    m = Payment()
    ans = m.ethereum_address()
    assert ans.startswith('0x')
    assert len(ans) == 42

# Generated at 2022-06-23 21:39:06.070020
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    address = payment.ethereum_address()
    assert address.startswith('0x')
    assert len(address) == 42

# Generated at 2022-06-23 21:39:13.182216
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    for _ in range(100):
        credit_card_number1 = Payment().credit_card_number(CardType.VISA)
        credit_card_number2 = Payment().credit_card_number(CardType.MASTER_CARD)
        credit_card_number3 = Payment().credit_card_number(CardType.AMERICAN_EXPRESS)
        assert len(credit_card_number1) == 19
        assert len(credit_card_number2) == 19
        assert len(credit_card_number3) == 17
        part1 = credit_card_number1[0:4]
        part2 = credit_card_number1[5:9]
        part3 = credit_card_number1[10:14]
        part4 = credit_card_number1[15:19]

# Generated at 2022-06-23 21:39:15.827839
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert isinstance(payment.ethereum_address(), str)
    assert payment.ethereum_address() == '0x35195d6c0e6ca22508c9a8d03f3b3e62a951e364'


# Generated at 2022-06-23 21:39:17.916663
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    for i in range(500):
        res = p.ethereum_address()


# Generated at 2022-06-23 21:39:19.929759
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    print('Test for method credit_card_expiration_date of class Payment')
    payment = Payment()
    payment.credit_card_expiration_date()
    print('Test passed')


# Generated at 2022-06-23 21:39:24.175539
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    for _ in range(10):
        paypal = payment.paypal()
        assert paypal[-10:] == '@gmail.com' or paypal[-11:] == '@hotmail.com'
        assert paypal[0] != '@'

# Generated at 2022-06-23 21:39:25.892138
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    c=Payment()
    assert c.cvv() >= 100 and c.cvv() < 1000


# Generated at 2022-06-23 21:39:32.018554
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    bitcoin_address = payment.bitcoin_address()
    assert len(bitcoin_address) == 34
    assert bitcoin_address[0] in ['1', '3']
    assert bitcoin_address[1:]
    for i in range(33):
        assert bitcoin_address[i + 1] in (
            string.ascii_letters + string.digits
        )


# Generated at 2022-06-23 21:39:33.280611
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    Payment_instance = Payment(seed=1234)
    assert Payment_instance.cvv() == 585


# Generated at 2022-06-23 21:39:35.355972
# Unit test for constructor of class Payment
def test_Payment():
    """ Unit test for constructor of class Payment """
    my_Payment = Payment()
    assert isinstance(my_Payment, Payment)


# Generated at 2022-06-23 21:39:43.132073
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Unit test for method cid of class Payment.

    Test results:
        100.0% passed
        100.0% coverage
        6 tests passed
        20 tests ran
    """
    import unittest
    import coverage
    import random
    import io

    cov = coverage.Coverage()
    cov.start()
    loader = unittest.TestLoader()
    tests = loader.discover('tests')
    runner = unittest.TextTestRunner()
    runner.run(tests)
    cov.stop()
    cov.save()

    cov.html_report()

    cov.erase()

    class TestMethods(unittest.TestCase):
        """Unit test for method cid of class Payment."""

        def setUp(self):
            """Initialize attributes for each test."""
            self.payment = Payment

# Generated at 2022-06-23 21:39:44.211503
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.Meta.name == 'payment'


# Generated at 2022-06-23 21:39:45.675049
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    for i in range(10):
        # print(Payment().paypal())
        print(i)

# Generated at 2022-06-23 21:39:49.293637
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cvv = payment.cvv()
    assert(type(cvv) == int)
    assert(len(str(cvv)) == 3)
    if __name__ == '__main__':
        payment = Payment()
        print(payment.cvv())

# Generated at 2022-06-23 21:40:00.770336
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Define 'ethereum_address' variable
    ethereum_address = Payment().ethereum_address()
    # Define 'startsWith0x' variable
    startsWith0x = ethereum_address[0:2]
    # Define 'count' variable
    count = 0
    # Define 'length' variable
    length = 40
    # Define '_0' variable
    _0 = '0'
    # Define '_X' variable
    _X = 'x'
    # Define '_x' variable
    _x = 'X'
    # Define '_E' variable
    _E = 'E'
    # Define '_e' variable
    _e = 'e'
    # Check the ethereum address starts with the correct prefix

# Generated at 2022-06-23 21:40:02.983206
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert payment.cid() <= 9999 and payment.cid() >= 1000


# Generated at 2022-06-23 21:40:06.365631
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()

    for i in range(10):
        address = payment.ethereum_address()
        assert len(address) == 42, "Len mismatch"
        assert address[:2] == '0x', "Prefix mismatch"
    print('Test passed')

if __name__ == '__main__':
    test_Payment_ethereum_address()

# Generated at 2022-06-23 21:40:08.761402
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    assert len(str(p.cvv())) == 3


# Generated at 2022-06-23 21:40:13.480407
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test Payment class method credit_card_number."""
    payment = Payment()
    credit_card = payment.credit_card_number(CardType.VISA)
    assert re.match(r'^\d{4} \d{4} \d{4} \d{4}$', credit_card) is not None


# Generated at 2022-06-23 21:40:15.169339
# Unit test for constructor of class Payment
def test_Payment():

    p = Payment(random.Random(random.seed()))
    assert p is not None
    assert p is not None