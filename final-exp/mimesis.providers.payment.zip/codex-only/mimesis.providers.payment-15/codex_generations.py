

# Generated at 2022-06-23 21:30:21.519704
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    for i in range(10):
        if Payment().bitcoin_address().startswith("3"):
            print("test_Payment_bitcoin_address for class Payment passed")
            break
    else:
         raise AssertionError("test_Payment_bitcoin_address for class Payment failed")

# Generated at 2022-06-23 21:30:25.778555
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    credit_card_owner = payment.credit_card_owner()
    assert credit_card_owner['credit_card'] == '4024 0071 4277 3727'
    assert credit_card_owner['expiration_date'] == '04/16'
    assert credit_card_owner['owner'] == 'Bernard S. Gallagher'

# Generated at 2022-06-23 21:30:29.541255
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    ethereum_address = Payment("en", seed=20).ethereum_address()
    assert ethereum_address == "0xcd758eda0e7bd47bc088e8a94a323c1d"


# Generated at 2022-06-23 21:30:31.760004
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment('ru', seed=0)
    i = 0
    while i < 10:
        assert (payment.cid() > 0)
        i += 1


# Generated at 2022-06-23 21:30:32.909098
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(seed=1)
    assert p.credit_card_number() == '4444 4666 3111 0095'


# Generated at 2022-06-23 21:30:35.562073
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert isinstance(payment, Payment)
    assert payment.__doc__ != None


# Generated at 2022-06-23 21:30:38.572328
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    data = []
    try:
        for i in range(10):
            data.append(payment.paypal())
    except Exception:
        print('Exception')
    assert data != []

# Generated at 2022-06-23 21:30:45.638855
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.data import CREDIT_CARD_NETWORKS
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.payment import Payment
    from mimesis.providers.person import Person
    from mimesis.random import get_random_item
    from mimesis.shortcuts import luhn_checksum

    payment = Payment()
    owner = payment.credit_card_owner(gender=Gender.MALE)
    #print(owner)
    assert isinstance(owner, (dict,))
    assert owner['credit_card']
    assert owner['expiration_date']
    assert owner['owner']


# Generated at 2022-06-23 21:30:48.626889
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    paymt = Payment(seed=42)
    assert paymt.credit_card_network() == "Visa"
    assert paymt.credit_card_network() == "Visa"
    assert paymt.credit_card_network() == "Visa"


# Generated at 2022-06-23 21:30:55.351978
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert len(payment.credit_card_expiration_date(16, 16)) == 5
    assert len(payment.credit_card_expiration_date(16, 25)) == 5
    assert len(payment.credit_card_expiration_date(17, 25)) == 5
    assert len(payment.credit_card_expiration_date(15, 25)) == 5
    assert len(payment.credit_card_expiration_date(25, 25)) == 5
    assert len(payment.credit_card_expiration_date(0, 0)) == 5


# Generated at 2022-06-23 21:30:59.961401
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    pp = payment.paypal()
    s = pp.find("@")
    if s == -1:
        print("method: paypal, test failed!")
    else:
        print("method: paypal, test passed!")


# Generated at 2022-06-23 21:31:04.331983
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pay = Payment()
    list_email = []
    try:
        for _ in range(10):
            list_email.append(pay.paypal())
    except Exception as error:
        print(error)
    assert(len(set(list_email)) == 10)


# Generated at 2022-06-23 21:31:11.601321
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    res = p.credit_card_expiration_date()

# Generated at 2022-06-23 21:31:16.810998
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert callable(payment.credit_card_number)
    assert callable(payment.credit_card_expiration_date)
    assert callable(payment.credit_card_owner)
    assert callable(payment.credit_card_network)
    assert callable(payment.bitcoin_address)
    assert callable(payment.ethereum_address)


# Generated at 2022-06-23 21:31:26.180680
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    pattern_of_visa = re.compile(r'4\d{3}\d{4}\d{4}\d{4}')
    pattern_of_mastercard = re.compile(
        r'5[1-5]\d{2}\d{4}\d{4}\d{4}')
    pattern_of_american_express = re.compile(
        r'3[4|7]\d{2}\d{6}\d{5}')
    credit_card_number = payment.credit_card_number()
    assert bool(re.match(pattern_of_visa, credit_card_number))
    credit_card_number = payment.credit_card_number(CardType.MASTER_CARD)

# Generated at 2022-06-23 21:31:31.440410
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    import random
    import numbers
    seed = random.randint(0, 100)
    provider = Payment(seed=seed)
    value = provider.cvv()
    assert isinstance(value, numbers.Integral)
    assert 0 <= value <= 999
    assert value == provider.cvv()


# Generated at 2022-06-23 21:31:35.718053
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    ethereum_address = Payment.ethereum_address(Payment)
    assert (len(ethereum_address) == 42)
    assert (ethereum_address.startswith('0x'))


# Generated at 2022-06-23 21:31:39.928324
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """
    Asserts that ethereum_address() return address
    """
    ethereum_address = Payment.Payment.ethereum_address()
    assert type(ethereum_address) is str


# Generated at 2022-06-23 21:31:44.286444
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    for i in range(10):
        myPayment = Payment()
        myAdrs = myPayment.ethereum_address()
        assert re.match('^0x[a-fA-F0-9]{40}$', myAdrs) is not None, 'Ethereum address not formatted correctly'

# Generated at 2022-06-23 21:31:46.442894
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Init
    payment = Payment()

    # Perfect case
    assert(len(str(payment.cid())) == 4)


# Generated at 2022-06-23 21:31:49.520606
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment('en')
    for i in range(5):
        print (payment.credit_card_network())
    # visa mastro card amex


# Generated at 2022-06-23 21:31:52.936766
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():

    validator = re.compile(r'[13][A-Za-z0-9]{32}')
    btc_addr = Payment().bitcoin_address()

    assert validator.search(btc_addr)


# Generated at 2022-06-23 21:31:53.877885
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    Payment.credit_card_network()


# Generated at 2022-06-23 21:32:03.056129
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    print('Unit test for method credit_card_expiration_date of class Payment: ', end='')
    payment = Payment()
    print(payment.credit_card_expiration_date()[0:2] in ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'], end='; ')
    print(payment.credit_card_expiration_date()[3:5] in ['16', '17', '18', '19', '20', '21', '22', '23'])


# Generated at 2022-06-23 21:32:05.447571
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    pay = Payment(seed=12345)
    for i in range(1000):
        assert len(str(pay.cvv())) == 3


# Generated at 2022-06-23 21:32:12.298744
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment("en")
    assert len(payment.credit_card_expiration_date()) == 5
    assert "12/25" > payment.credit_card_expiration_date()
    assert "01/20" < payment.credit_card_expiration_date()
    assert payment.credit_card_expiration_date("13") == "03/16"
    assert payment.credit_card_expiration_date("15", "16") == "05/16"

# Generated at 2022-06-23 21:32:15.622927
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    # print(p.cvv())
    assert len(str(p.cvv())) == 3


# Generated at 2022-06-23 21:32:19.623263
# Unit test for method paypal of class Payment
def test_Payment_paypal():
	pay = Payment()
	credit_card = pay.credit_card_owner()
	assert type(credit_card['credit_card']) is str
	assert type(credit_card['expiration_date']) is str
	assert type(credit_card['owner']) is str

# Generated at 2022-06-23 21:32:22.592836
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment_ob = Payment()
    res = payment_ob.credit_card_network()
    assert isinstance(res, str)
    assert res in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:32:23.538340
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()

    assert payment is not None

# Generated at 2022-06-23 21:32:29.932428
# Unit test for constructor of class Payment
def test_Payment():
    #
    # 1.
    payment = Payment()
    assert hasattr(payment, "CREDIT_CARD_NETWORKS")
    assert hasattr(payment, "Meta")
    assert hasattr(payment, "Meta")
    assert hasattr(payment, "Meta")
    assert hasattr(payment, "Meta")
    assert hasattr(payment, "Meta")
    assert hasattr(payment, "Meta")
    assert hasattr(payment, "Meta")
    assert hasattr(payment, "Meta")
    assert hasattr(payment, "Meta")
    assert hasattr(payment, "Meta")
    assert hasattr(payment, "Meta")


# Generated at 2022-06-23 21:32:34.460049
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payload = {
        "address": '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'
    }
    payment = Payment("en")
    results = payment.bitcoin_address()
    assert results == payload.get("address")


# Generated at 2022-06-23 21:32:37.748914
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment(use_json=False)
    assert re.match(r'0x[a-zA-Z0-9]{40}', p.ethereum_address())

# Generated at 2022-06-23 21:32:41.569501
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():

    _Payment = Payment()
    _Payment.seed(0)
    address = _Payment.ethereum_address()

    assert address == '0xf00f9aa9e0ab8d5c0cd1a84a36a0a8f5b5f5f5a5'

# Generated at 2022-06-23 21:32:48.837637
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Unit test for method credit_card_owner of class Payment"""
    # Initialize a Payment object
    payment = Payment()
    # Call the credit_card_owner method
    owner = payment.credit_card_owner()
    # Check the type returned by method credit_card_owner
    assert isinstance(owner, dict)
    # Check the length of owner
    assert len(owner) == 3
    # Check the keys in the dict
    assert 'credit_card' in owner
    assert 'expiration_date' in owner
    assert 'owner' in owner
    # Check the type of the items in the dict
    assert isinstance(owner['credit_card'], str)
    assert isinstance(owner['expiration_date'], str)
    assert isinstance(owner['owner'], str)


# Generated at 2022-06-23 21:32:51.142693
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    import random
    provider = Payment(random.Random(123))
    assert provider.cvv() == 454


# Generated at 2022-06-23 21:32:54.294630
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment(seed=1234)
    assert payment.ethereum_address() == "0x95d6e17ef6c0e16d0b6f8ce7465924bd9bdd9b13"


# Generated at 2022-06-23 21:32:56.756787
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner()
    assert 'credit_card' in owner
    assert 'expiration_date' in owner
    assert 'owner' in owner

# Generated at 2022-06-23 21:32:58.600273
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    pay=Payment()
    assert pay.credit_card_network() in CREDIT_CARD_NETWORKS

# Generated at 2022-06-23 21:33:08.159283
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    random_Payment_ethereum_address = []
    for i in range(10):
        x = Payment(seed = i)
        random_Payment_ethereum_address.append(x.ethereum_address())

    assert random_Payment_ethereum_address[0] == '0x5e5c5d5a5f676d68c09a73f9a5f5d5e5e8c4348eb4c4d4d4f4d4c4ceb4c4d4d4f4d4c4c4d4d4d4c4c4f4c4d4d4f4c4c4d4d4d4c4c4f4c4d'

# Generated at 2022-06-23 21:33:10.956396
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    num = payment.cvv()
    assert len(str(num)) == 3 and type(num) == int

# Generated at 2022-06-23 21:33:14.356182
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment('en')
    # payment.seed(2)
    # print(payment.paypal())
    assert payment.paypal() == 'garrettmcallister@yahoo.com'

# Generated at 2022-06-23 21:33:23.046990
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    print('Test method credit_card_owner of class Payment')
    payment = Payment()

    # test with default gender
    owner = payment.credit_card_owner()
    print(owner)

    # test with Male gender
    owner = payment.credit_card_owner(Gender.MALE)
    print(owner)

    # test with Female gender
    owner = payment.credit_card_owner(Gender.FEMALE)
    print(owner)

    # test with None
    owner = payment.credit_card_owner(None)
    print(owner)

if __name__ == "__main__":
    test_Payment_credit_card_owner()

# Generated at 2022-06-23 21:33:30.446049
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Create a class
    payment = Payment()
    # Create a class for a person
    person = Person('en')
    # Create a list for mocked names
    names = []
    # Mocking for credit card owner names
    for i in range(1, 100):
        # Create a name
        names.append(person.full_name(gender=None).upper())
    # Create a set for comparing of mocked and real credit card owner names
    result = set(names)
    # Create a list for real credit card owner names
    real_names = []
    # Iteration
    for i in range(1, 100):
        # Get a real credit card owner name
        name = payment.credit_card_owner(gender=None)['owner']
        # Add a real name to a list
        real_names.append(name)
    # Create

# Generated at 2022-06-23 21:33:34.456272
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis import Payment
    payment = Payment()
    addr = payment.ethereum_address()
    assert len(addr) == 42
    assert (addr[:2] == '0x')
    assert (addr[2:].isalnum())


# Generated at 2022-06-23 21:33:35.524842
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert payment.cid()


# Generated at 2022-06-23 21:33:38.579955
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test a method credit_card_number()."""
    payment = Payment()
    print(payment.credit_card_number())

# Generated at 2022-06-23 21:33:41.606276
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    address = payment.ethereum_address()
    print(address)

if __name__ == "__main__":
    test_Payment_ethereum_address()

# Generated at 2022-06-23 21:33:44.716280
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    if __name__ == '__main__':
        payment = Payment()
        print(payment.credit_card_network())


# Generated at 2022-06-23 21:33:47.358461
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis.enums import Gender
    random = Payment()
    random.person.gender = Gender.FEMALE
    assert random.person.gender == Gender.FEMALE

# Generated at 2022-06-23 21:33:49.230504
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    print(p.credit_card_expiration_date())
test_Payment_credit_card_expiration_date()

# Generated at 2022-06-23 21:33:57.285513
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    p.credit_card_number()
    p.credit_card_number(CardType.VISA)
    p.credit_card_number(CardType.MASTER_CARD)
    p.credit_card_number(CardType.AMERICAN_EXPRESS)
    try:
        p.credit_card_number('NotACard')
    except NonEnumerableError:
        print("Testing non-enumerable card type works")
test_Payment_credit_card_number()

# Generated at 2022-06-23 21:33:59.339430
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
      generate = Payment()
      assert generate.credit_card_number().__len__() == 19
      assert generate.credit_card_number(CardType.AMERICAN_EXPRESS).__len__() == 18


# Generated at 2022-06-23 21:34:02.592881
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    Payment = Payment()
    l = [Payment.bitcoin_address() for i in range(100)]
    assert (len(l) == 100)


# Generated at 2022-06-23 21:34:13.390690
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    try:
        from mimesis.enums import Gender
    except ModuleNotFoundError:
        from mimesis.builtins import Gender
    from mimesis.providers.payment import Payment as cc
    payment = cc()
    credit_card_owner = payment.credit_card_owner(Gender.FEMALE)
    assert isinstance(credit_card_owner, dict)
    assert isinstance(credit_card_owner['credit_card'], str)
    assert isinstance(credit_card_owner['expiration_date'], str)
    assert isinstance(credit_card_owner['owner'], str)
    assert credit_card_owner['owner'].upper() == credit_card_owner['owner']

# Generated at 2022-06-23 21:34:23.636102
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    # Test BaseProvider's constructor
    assert isinstance(payment._random, type(payment.random))
    assert payment.random is not payment._random
    assert isinstance(payment.random, type(payment._seed))
    assert payment.random is payment._seed
    assert payment.random is payment.seed
    assert payment.random == payment._seed
    assert payment.random == payment._random
    assert payment.random == payment.seed
    assert payment._use_enum is Payment.use_enum
    assert isinstance(payment.__dict__, dict)
    assert '_random' in payment.__dict__
    assert '_seed' in payment.__dict__
    assert '_use_enum' in payment.__dict__
    assert payment.random == payment.seed
    assert payment.random == payment._seed
    assert payment

# Generated at 2022-06-23 21:34:24.860584
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment("en")
    for i in range(5):
        print(payment.cid())

# Generated at 2022-06-23 21:34:28.397474
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Test for method credit_card_network of class Payment."""
    payment = Payment()
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS

# Generated at 2022-06-23 21:34:32.994852
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    network = payment.credit_card_network()
    print('Network: ', network)
    credit = payment.credit_card_number()
    print('Credit Card: ', credit)
    owner = payment.credit_card_owner()
    print('Owner: ', owner)


# Generated at 2022-06-23 21:34:34.481257
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # Generate random cvv
    print(Payment().cvv())



# Generated at 2022-06-23 21:34:42.958325
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for i in range(100):
        card_number = payment.credit_card_number(CardType.VISA)
        assert card_number[0] == '4'
    for i in range(100):
        card_number = payment.credit_card_number(CardType.MASTER_CARD)
        assert (2221 <= int(card_number[:4]) <= 2720) or (5100 <= int(card_number[:4]) <= 5599)
    for i in range(100):
        card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
        assert card_number[0] == '3' and (card_number[1] == '4' or card_number[1] == '7')

# Generated at 2022-06-23 21:34:45.945668
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """This function tests the function ethereum_address of
    the provider class Payment.
    """
    # assert type(Payment().ethereum_address()) == 'str'
    return Payment().ethereum_address()

# Generated at 2022-06-23 21:34:50.786437
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis.enums import CardType
    from mimesis.exceptions import NonEnumerableError

    payment = Payment()
    cc = payment.credit_card_network()
    assert cc in CREDIT_CARD_NETWORKS

    try:
        payment.credit_card_number(card_type='test')
    except NonEnumerableError:
        return True
    return False

# Generated at 2022-06-23 21:34:53.509297
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    for _ in range(10):
        print(payment.credit_card_network())


# Generated at 2022-06-23 21:35:04.153359
# Unit test for constructor of class Payment
def test_Payment():
    my_Payment = Payment('en')
    # assert my_Payment.seed == '5d00879e8b0a43a96a3ef3e991fa6b9e', 'seed is wrong'
    assert my_Payment.cid() >= 1000 and my_Payment.cid() <= 9999, 'cid() is wrong'
    assert re.match(r'[\w.-]+@[\w.-]+.\w+', my_Payment.paypal()), 'paypal() is wrong'
    assert re.match(r'[13]{1}[a-zA-Z0-9]{33}', my_Payment.bitcoin_address()), 'bitcoin_address() is wrong'

# Generated at 2022-06-23 21:35:05.439796
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert len(str(Payment().cvv())) == 3


# Generated at 2022-06-23 21:35:08.426320
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    print(payment.bitcoin_address())
    print(payment.bitcoin_address())
    print(payment.bitcoin_address())


# Generated at 2022-06-23 21:35:18.741899
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    visa_cards = []
    amex_cards = []
    master_cards = []

    for _ in range(100):
        card = p.credit_card_number()
        if card.startswith('4'):
            visa_cards.append(card)
        elif card.startswith('34') or card.startswith('37'):
            amex_cards.append(card)
        elif re.match(r'5(\d){3}', card):
            master_cards.append(card)

    assert len(visa_cards) == 100
    assert len(amex_cards) == 100
    assert len(master_cards) == 100

    for card in visa_cards:
        assert card.startswith('4')
        assert len(card) == 19

# Generated at 2022-06-23 21:35:22.244874
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    number = payment.cvv()
    assert isinstance(number, int)
    assert len(str(number)) == 3
    assert number >= 100 and number <= 999


# Generated at 2022-06-23 21:35:24.378686
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment('en')
    result = payment.cvv()
    print(result)


# Generated at 2022-06-23 21:35:26.589086
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    test_Payment = Payment('en')
    assert isinstance(test_Payment.paypal(), str)


# Generated at 2022-06-23 21:35:29.913349
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    a = p.ethereum_address()

    if(re.match('0x[a-fA-F0-9]{40}', a) is None):
        assert False
    else:
        assert True

# Generated at 2022-06-23 21:35:32.280943
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Define Variables
    payment = Payment()
    # Execute function
    result = payment.paypal()
    # Check assertions
    assert type(result) == str


# Generated at 2022-06-23 21:35:33.488137
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert isinstance(payment, Payment)


# Generated at 2022-06-23 21:35:35.561764
# Unit test for method cid of class Payment
def test_Payment_cid():
    """
    test function cid of class Payment
    """
    Payment_a = Payment()
    assert Payment_a.cid() in range(100,10000)



# Generated at 2022-06-23 21:35:37.502078
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    research = Payment()

    assert research.credit_card_network() in CREDIT_CARD_NETWORKS



# Generated at 2022-06-23 21:35:47.950314
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    print('Testing method credit_card_expiration_date of class Payment')
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.typing import DatetimeTimestamp
    import datetime
    p = Payment()
    s = set()
    n = 100
    for i in range(n):
        r = p.credit_card_expiration_date()
        s.add(r)
    print("{} random expiration date generate between 01/16 and 01/25".format(len(s)))
    assert len(s) >= ((n / 9) * 8)
    s = set()
    for i in range(n):
        m = p.random.randint(1, 12)
        y = p.random.randint(16, 25)

# Generated at 2022-06-23 21:35:50.586688
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    cco = {
        'credit_card': '4455 5299 1152 2450',
        'expiration_date': '03/19',
        'owner': 'JACHIN RICHARD'
    }
    assert Payment().credit_card_owner() == cco


# Generated at 2022-06-23 21:35:54.074447
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    # Test paypal method
    assert re.match('\w+@\w+', payment.paypal())


# Generated at 2022-06-23 21:35:55.546434
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    print(payment.cid())


# Generated at 2022-06-23 21:36:01.658257
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p.cid() == 7452
    assert p.paypal() == "wolf235@gmail.com"
    assert p.bitcoin_address() == "3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX"
    assert p.ethereum_address() == "0xe8ece9e6ff7dba52d4c07d37418036a89af9698d"

# Generated at 2022-06-23 21:36:06.905807
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """
    Test paypal of class Payment.
    """
    payment = Payment()
    result = payment.paypal()
    assert re.match(r'([\w-]+.)+[\w-]+@([\w-]+.)+[\w-]+', result) \
        is not None



# Generated at 2022-06-23 21:36:09.486879
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    pp = Payment()
    # print(pp.cvv())
    assert pp.cvv() >= 100
    assert pp.cvv() <= 999


# Generated at 2022-06-23 21:36:11.743927
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    PAYMENT = Payment()

    # Check data generation
    assert 'mastercard' in PAYMENT.credit_card_network().lower()


# Generated at 2022-06-23 21:36:16.294544
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type = CardType.VISA
    p = Payment()
    num = p.credit_card_number(card_type)
    print(num)
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', num)


# Generated at 2022-06-23 21:36:18.829494
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # type: () -> None
    
    """Unit test for method cvv of class Payment."""

    generator = Payment()
    value = generator.cvv()
    assert value in range(100,999)

# Generated at 2022-06-23 21:36:21.206285
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment(seed=123)
    assert p.cvv() == 962



# Generated at 2022-06-23 21:36:23.097685
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    print(payment.credit_card_owner())

# test_Payment()

# Generated at 2022-06-23 21:36:24.996450
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    for i in range(10):
        print(p.paypal())

# Generated at 2022-06-23 21:36:30.775753
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    for _ in range(100):
        assert Payment.credit_card_network() in CREDIT_CARD_NETWORKS

"""
TODO

- [x] random.choice -> rnd.choice
- [ ] credit_card_owner -> person
- [ ] credit_card_number -> rnd.choice(length = 16)

- [ ] test_Payment_credit_card_owner
"""

# Generated at 2022-06-23 21:36:34.517297
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment("en")
    print(payment.credit_card_network())
    print(payment.credit_card_number())
    print(payment.credit_card_expiration_date())
    print(payment.credit_card_owner())
    print(payment.cvv())


# Generated at 2022-06-23 21:36:42.647600
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # Initialize seed for random generator
    seed = 10
    # Initialize class
    payment = Payment(seed)
    # Get first bitcoin address
    bitcoin_address = payment.bitcoin_address()
    print(bitcoin_address)
    # Get second bitcoin address
    bitcoin_address = payment.bitcoin_address()
    print(bitcoin_address)
    # Get third bitcoin address
    bitcoin_address = payment.bitcoin_address()
    print(bitcoin_address)
    # Get fourth bitcoin address
    bitcoin_address = payment.bitcoin_address()
    print(bitcoin_address)
    # Get fifth bitcoin address
    bitcoin_address = payment.bitcoin_address()
    print(bitcoin_address)



# Generated at 2022-06-23 21:36:49.208768
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    credit_card_network1 = p.credit_card_network()
    credit_card_network2 = p.credit_card_network()
    assert credit_card_network1 in CREDIT_CARD_NETWORKS
    assert credit_card_network2 in CREDIT_CARD_NETWORKS
    assert credit_card_network1 != credit_card_network2


# Generated at 2022-06-23 21:36:52.059251
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    c = Payment()
    print(c.credit_card_owner())
    print(c.credit_card_owner('Male'))

if __name__ == "__main__":
    test_Payment_credit_card_owner()

# Generated at 2022-06-23 21:36:53.484802
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    for i in range(0, 5):
        print(p.cvv())
    return 0


# Generated at 2022-06-23 21:36:55.129467
# Unit test for constructor of class Payment
def test_Payment():
    print('test_Payment')
    payment = Payment()
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS

test_Payment()

# Generated at 2022-06-23 21:36:56.558564
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    cvv = Payment().cvv()
    assert len(str(cvv)) == 3


# Generated at 2022-06-23 21:36:59.124611
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    for elem in range(0,10):
        print(payment.bitcoin_address())



# Generated at 2022-06-23 21:37:01.663521
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pay = Payment()
    assert (pay.credit_card_number(CardType.VISA) == '4455 5299 1152 2450')



# Generated at 2022-06-23 21:37:09.418447
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    print('test_Payment_credit_card_network()')

    from mimesis.enums import CardType

    card_type = CardType.MAESTRO
    p = Payment('en')
    print(len(p.credit_card_network()))
    print(len(p.credit_card_number()))
    print(p.credit_card_number(card_type))
    print(p.credit_card_expiration_date(16, 25))
    print(p.cvv())
    print(p.credit_card_owner())
if __name__ == '__main__':
    test_Payment_credit_card_network()

# Generated at 2022-06-23 21:37:21.109812
# Unit test for constructor of class Payment
def test_Payment():
    from mimesis.enums import Gender
    from mimesis.enums import CardType
    payment = Payment('en')
    credit_card_owner = payment.credit_card_owner(Gender.MALE)
    card_type = CardType
    cid = payment.cid()
    paypal = payment.paypal()
    bitcoin_address = payment.bitcoin_address()
    ethereum_address = payment.ethereum_address()
    credit_card_network = payment.credit_card_network()
    credit_card_number = payment.credit_card_number(card_type.VISA)
    expiration_date = payment.credit_card_expiration_date()
    cvv = payment.cvv()

    print(credit_card_owner)
    print(cid)
    print(paypal)
    print

# Generated at 2022-06-23 21:37:29.139598
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    payment.credit_card_number(card_type=CardType.VISA)
    print(payment.credit_card_number(card_type=CardType.VISA))
    print(payment.credit_card_number(card_type=CardType.MASTER_CARD))
    print(payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS))
    # print(payment.credit_card_number(card_type="unknown")

# Generated at 2022-06-23 21:37:32.403279
# Unit test for constructor of class Payment
def test_Payment():
    # Test objects
    card = Payment()
    print("Card Number: ", card.credit_card_number())
    print("CCV number: ", card.cvv())
    print("Card expiration date: ", card.credit_card_expiration_date())

# Generated at 2022-06-23 21:37:33.840830
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert len(payment.ethereum_address()) == 42

# Generated at 2022-06-23 21:37:34.847790
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment('en', seed=10)
    result = payment.cid()
    assert result == 8182


# Generated at 2022-06-23 21:37:39.467222
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    for i in range(100):
        a = Payment()
        b = a.credit_card_network()
        if a.meta.language != 'en':
            assert b != a.credit_card_network()
        assert b == a.credit_card_network()
        assert b in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:37:40.797129
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    print(p.credit_card_network())


# Generated at 2022-06-23 21:37:42.604357
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    print("Payment.bitcoin_address():", p.bitcoin_address())


# Generated at 2022-06-23 21:37:45.491458
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Type hinting
    assert isinstance(Payment().cid(), int)


# Generated at 2022-06-23 21:37:46.760244
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    print(payment.bitcoin_address())

test_Payment_bitcoin_address()

# Generated at 2022-06-23 21:37:50.621202
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment"""
    numcard = Payment().credit_card_number()
    assert len(numcard) == 19, 'Номер карты некорректный'
    assert re.search('\D', numcard) is not None, 'Номер карты некорректный'



# Generated at 2022-06-23 21:37:55.192895
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pay = Payment()
    print(pay.paypal())
    assert re.search(r'[0-9a-zA-Z_]{0,19}@[0-9a-zA-Z]{1,13}\.[com,cn,net]{1,3}', pay.paypal())


# Generated at 2022-06-23 21:37:59.453127
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    test_credit_card_owner = Payment()
    print('')
    print('Credit card owner: ', test_credit_card_owner.credit_card_owner())



# Generated at 2022-06-23 21:38:01.383568
# Unit test for constructor of class Payment
def test_Payment():
    # initialize the class Payment
    payment = Payment()
    assert payment is not None


# Generated at 2022-06-23 21:38:03.498038
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment(locale="en")
    assert isinstance(payment.cvv(), int)


# Generated at 2022-06-23 21:38:07.640117
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    cvv = payment.cvv()
    assert isinstance(cvv, int), 'Error: cvv is not a string!'
    assert len(str(cvv)) == 3, 'Error: cvv is not a string of length 3!'


# Generated at 2022-06-23 21:38:17.589470
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    owner_data = p.credit_card_owner()
    # Check existence of each key in dict
    assert "credit_card" in owner_data
    assert "expiration_date" in owner_data
    assert "owner" in owner_data
    # Check validation of credit card number
    assert len(str(owner_data["credit_card"]).replace(' ','')) == 16
    # Check validation of expiration date
    assert len(str(owner_data["expiration_date"]).split('/')) == 2
    assert len(str(owner_data["expiration_date"]).split('/')[1]) == 2
    # Check validation of owner name
    assert len(str(owner_data["owner"]).split(' ')) >= 2

# Generated at 2022-06-23 21:38:22.515525
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for i in range(1, 100):
        card_type = CardType(i%4 + 1)
        credit_card_number = payment.credit_card_number(card_type)
        assert len(credit_card_number.replace(' ', '')) == 16


# Generated at 2022-06-23 21:38:26.699537
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Initialize an instance of class Payment
    payment = Payment(seed=100)
    # Generate the Ethereum address
    result = payment.ethereum_address()
    # Expected address
    expected = '0xcc01f7c0dd4fb4d711d63a77b5f5c2a5b5def521'
    # Assert
    assert result == expected

# Generated at 2022-06-23 21:38:28.461766
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    for _ in range(100):
        result = Payment().paypal()
        assert isinstance(result, str)
        assert len(result) > 0
        assert '@' in result


# Generated at 2022-06-23 21:38:29.907597
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert Payment(seed=1).credit_card_expiration_date() == '01/20'

# Generated at 2022-06-23 21:38:34.350011
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    Payment_ = Payment()
    assert len(Payment_.credit_card_number()) == 19
    assert len(Payment_.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(Payment_.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17


# Generated at 2022-06-23 21:38:39.629674
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    def test_ethereum_address(seed):
        payment = Payment(seed=seed)
        assert payment.ethereum_address() == '0xce822a82f1a30f09b6544d7c845b5bb990904d79'
    for seed in range(10):
        test_ethereum_address(seed)

# Generated at 2022-06-23 21:38:41.039760
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    assert type(p.cid()) == int

# Generated at 2022-06-23 21:38:45.404087
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """unit test for Payment.cvv"""
    from mimesis.providers import Payment
    seed = 1234567890
    provider = Payment(seed=seed)
    cvv_1 = provider.cvv()
    provider = Payment(seed=seed)
    cvv_2 = provider.cvv()
    assert cvv_1 == cvv_2

# Generated at 2022-06-23 21:38:48.170704
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment('en')
    assert p.credit_card_expiration_date() == '10/26'


# Generated at 2022-06-23 21:38:52.616023
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis.enums import CardType
    Payment1 = Payment('en', seed=0)
    for i in range(10):
        result = Payment1.ethereum_address()
        assert result.startswith('0x')
        assert len(result) == 42

#Unit test for method credit_card_owner of class Payment

# Generated at 2022-06-23 21:39:02.471901
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    card = Payment('en')

    # Generating a random credit card owner for a specified gender
    card_owner = card.credit_card_owner(gender=Gender.MALE)
    owner = card_owner['owner']
    assert ' ' in owner # Check if the name is composed of a first and a last name
    first_name, last_name = owner.split(' ')
    assert first_name.islower() # Check if the first name is lower case
    assert last_name.isupper() # Check if the last name is upper case

    # Generating a random credit card owner without specifying a gender
    card_owner = card.credit_card_owner()
    owner = card_owner['owner']
    assert ' ' in owner # Check if the name is composed of a first and a last name
   

# Generated at 2022-06-23 21:39:09.002335
# Unit test for method cid of class Payment
def test_Payment_cid():
    from mimesis.enums import CardType
    from mimesis.builtins import CardInfo

    Payment_inst = Payment("en")

    card_info = CardInfo("en")
    for _ in range(100):
        cid = Payment_inst.cid()
        assert cid.__class__ is int
        assert len(str(cid)) == 4
        assert 0 <= cid <= 9999

    # test random_card_number
    for card_type in (CardType.VISA, CardType.MASTER_CARD, CardType.AMERICAN_EXPRESS):
        card = Payment_inst.credit_card_number(card_type)
        assert card.__class__ is str
        assert card.strip() == card
        assert len(card) <= 19

    # test ethereum_address

# Generated at 2022-06-23 21:39:10.525723
# Unit test for method cid of class Payment
def test_Payment_cid():
    a = Payment().cid()
    print(a)


if __name__ == '__main__':
    test_Payment_cid()

# Generated at 2022-06-23 21:39:15.892016
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(seed=13)
    print(payment.credit_card_number())
    print(payment.credit_card_number())
    print(payment.credit_card_number())
    print(payment.credit_card_number())
    print(payment.credit_card_number())


# Generated at 2022-06-23 21:39:17.343049
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    wallet = Payment()
    assert re.match(r"0x[a-z0-9]+", wallet.ethereum_address())

# Generated at 2022-06-23 21:39:18.320076
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    assert payment.credit_card_owner() != None

# Generated at 2022-06-23 21:39:21.516302
# Unit test for method cid of class Payment
def test_Payment_cid():
    from mimesis.enums import Gender
    p = Payment('en')
    x = p.cid()
    assert isinstance(x, int), 'Failed to generate cid.'
    assert len(str(x)) == 4, 'Failed to generate cid.'
    assert x >= 1000 and x <= 9999, 'Failed to generate cid.'


# Generated at 2022-06-23 21:39:24.260865
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    import pprint
    pp = pprint.PrettyPrinter(indent=4)

    p = Payment()
    out = p.credit_card_owner()
    pp.pprint(out)



# Generated at 2022-06-23 21:39:28.062031
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    result = Payment(seed=42).credit_card_owner()
    assert result == {'credit_card': '2234 9056 4592 3395', 'expiration_date': '05/17', 'owner': 'ANNETTE BOWMAN'}

# Generated at 2022-06-23 21:39:30.745088
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    a = Payment()
    global c
    c = a.paypal()
    assert c != a.paypal()



# Generated at 2022-06-23 21:39:35.722587
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    # Creating instance of class Payment
    payment_instance = Payment
    # The list of already existing names
    existing_names = CREDIT_CARD_NETWORKS
    # Random choice from the list of already existing names
    random_choice = payment_instance.credit_card_network()
    # Checking if random_choice is in the list of already existing names
    assert random_choice in existing_names


# Generated at 2022-06-23 21:39:38.884129
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner()
    assert owner['expiration_date'] is not None
    assert owner['credit_card'] is not None
    assert owner['owner'] is not None


# Generated at 2022-06-23 21:39:40.211251
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    generator = Payment()
    print(generator.cvv())



# Generated at 2022-06-23 21:39:41.276129
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    result = Payment()
    print(result.credit_card_expiration_date())

# Generated at 2022-06-23 21:39:45.758318
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    #  In this function, we produce a fresh instance of the Payment class. Then, we call the function cvv of Payment
    #  and save the result in variable x. Then we call the random.randint of mimesis. 
    #  Then, we check if randomly generated number (by randint) is equal to the result of cvv method
    payment = Payment()
    x = payment.cvv()
    assert(x==payment.random.randint(100,999))

# Generated at 2022-06-23 21:39:47.398736
# Unit test for method cid of class Payment
def test_Payment_cid():
        p = Payment(seed=128)
        assert 7452 == p.cid()


# Generated at 2022-06-23 21:39:52.107780
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    date = payment.credit_card_expiration_date()

    assert(len(date) == 5)
    assert(date[2] == "/")

    month = int(date[0:2])
    year = int(date[3:])

    assert(month > 0)
    asser

# Generated at 2022-06-23 21:39:56.932405
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """
    Test method credit_card_owner.
    """
    p = Payment()
    assert p.credit_card_owner() == {'credit_card': '4908 3299 0408 2090', 'expiration_date': '05/22', 'owner': 'KEVIN LEWIS'}

# Generated at 2022-06-23 21:40:01.233868
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import CardType
    payment = Payment('en', seed=42)
    test_cases = [{
        CardType.UNDEFINED: '03/19',
    }]

    for card_type in CardType.__members__.values():
        for test_case in test_cases:
            assert test_case.get(card_type) == payment.credit_card_expiration_date()

# Generated at 2022-06-23 21:40:11.890251
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    address = p.bitcoin_address()
    # Check whether address is valid
    assert address[0] == "1" or address[0] == "3"
    assert len(address) == 34 
    # Check whether address is valid
    assert address[0] == "1" or address[0] == "3"
    assert len(address) == 34
    # Check whether address is valid
    assert address[0] == "1" or address[0] == "3"
    assert len(address) == 34
    # Check whether address is valid
    assert address[0] == "1" or address[0] == "3"
    assert len(address) == 34



# Generated at 2022-06-23 21:40:15.042481
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    min = 15
    max = 25
    # Default value
    assert len( payment.credit_card_expiration_date() ) == 5
    assert len( payment.credit_card_expiration_date(min, max) ) == 5

# Generated at 2022-06-23 21:40:19.906231
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    r = p.bitcoin_address()
    assert len(r) == 35, \
        "Length of Bitcoin address did not equal 35 characters"
    assert r.startswith("3") or r.startswith("1"), \
        "Bitcoin address did not start with '1' or '3'"
    assert r.isalnum(), \
        "Bitcoin address did not only contain alphanumeric characters"
