

# Generated at 2022-06-23 21:30:21.204132
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    pr = Payment()
    ethereum_address_list = []
    for i in range(100):
        ethereum_address_list.append(pr.ethereum_address())
    print(ethereum_address_list)
    for i in range(len(ethereum_address_list)):
        if ethereum_address_list[i][0] == '0' and ethereum_address_list[i][1] == 'x':
            print('pass')
        else:
            print('fail')


# Generated at 2022-06-23 21:30:23.149407
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    result = Payment().credit_card_network()
    assert result in CREDIT_CARD_NETWORKS



# Generated at 2022-06-23 21:30:26.353480
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test the method credit_card_number of class Payment
    with card type Visa
    """
    card_number = Payment().credit_card_number(card_type=CardType.VISA)
    assert(card_number[0] == '4')


# Generated at 2022-06-23 21:30:31.150633
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    import random
    import pytest

    random = random.Random()
    random.seed(11)

    payment = Payment(random=random)
    owner = payment.credit_card_owner()

#     print("------", owner)
    assert owner['credit_card'] == '4569 5695 9371 1333'


# Generated at 2022-06-23 21:30:34.317590
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    res = Payment().paypal()
    assert isinstance(res, str)


# Generated at 2022-06-23 21:30:37.375930
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    address_list = []
    assert len(address_list) == 0
    for _ in range(100):
        address = p.ethereum_address()
        address_list.append(address)
    assert len(address_list) > 0
    for address in address_list:
        assert address.startswith('0x')
        assert len(address) == 42


# Generated at 2022-06-23 21:30:41.158346
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Unit test for method credit_card_owner of class Payment."""
    pp = Payment()
    data = pp.credit_card_owner()
    assert 'credit_card' in data
    assert 'expiration_date' in data
    assert 'owner' in data
    return

# Generated at 2022-06-23 21:30:46.653271
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Test for method ethereum_address of class Payment."""
    p = Payment('en')
    result = p.ethereum_address()
    assert isinstance(result, str)
    assert len(result) == 42
    assert result.startswith('0x')


# Generated at 2022-06-23 21:30:49.337694
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    assert re.match(r"^[13][0-9a-zA-Z]+$", payment.bitcoin_address())


# Generated at 2022-06-23 21:30:54.049442
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Test for ethereum_address method.

    The successing test checks if the result (eth address) is correct
    or not. Check if it starts with 0x and if it has right length.
    """
    p = Payment('en')
    eth = p.ethereum_address()
    assert eth[0:2] == '0x'
    assert len(eth) == 42

# Generated at 2022-06-23 21:31:00.810015
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.payload import Payment
    from mimesis.enums import *

    payment = Payment()
    month = payment.credit_card_expiration_date()
    month_future = payment.credit_card_expiration_date(minimum=20)
    month_past = payment.credit_card_expiration_date(minimum=10, maximum=15)

    assert month != month_future != month_past


# Generated at 2022-06-23 21:31:02.259604
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    print("Test method paypal of class Payment : ", Payment().paypal())


# Generated at 2022-06-23 21:31:04.021199
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment('en')
    value = payment.bitcoin_address()
    assert True


# Generated at 2022-06-23 21:31:06.864356
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network(): # noqa: D202
    payment = Payment()
    result = payment.credit_card_network()
    assert isinstance(result, str)
    assert result in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:31:10.544495
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    cc = Payment()
    cc_number = cc.credit_card_number()
    assert(len(cc_number) == 19)
    assert(isinstance(cc_number, str))


# Generated at 2022-06-23 21:31:14.560747
# Unit test for method cid of class Payment
def test_Payment_cid():
    cid1 = Payment()
    cid2 = Payment()
    cid3 = Payment()
    print(cid1.cid())
    print(cid2.cid())
    print(cid3.cid())


# Generated at 2022-06-23 21:31:17.645406
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment.random
    card_type = get_random_item(CardType, rnd=p)
    card_num = p.payment.credit_card_number(card_type=card_type)
    assert len(card_num.replace(' ', '')) == 16

# Generated at 2022-06-23 21:31:19.824498
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    ethereum_address = Payment().ethereum_address()
    assert len(ethereum_address) == 42


# Generated at 2022-06-23 21:31:24.028936
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    result = p.credit_card_owner()
    assert isinstance(result, dict)
    assert "credit_card" in result
    assert "expiration_date" in result
    assert "owner" in result
    assert "owner" in result


# Generated at 2022-06-23 21:31:26.921215
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    assert re.search("[13][a-zA-Z0-9]{33}", p.bitcoin_address()) is not None
    assert len(p.bitcoin_address()) == 35


# Generated at 2022-06-23 21:31:29.241153
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    print(payment.cid())


# Generated at 2022-06-23 21:31:33.020809
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    for i in range(10):
        assert len(payment.bitcoin_address()) == 34
        assert payment.bitcoin_address().startswith('3') or payment.bitcoin_address().startswith('1')


# Generated at 2022-06-23 21:31:38.339020
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment('en')
    assert payment.cid() != None
    assert payment.paypal() != None
    assert payment.bitcoin_address() != None
    assert payment.ethereum_address() != None
    assert payment.credit_card_network() != None
    assert payment.credit_card_number() != None
    assert payment.credit_card_expiration_date() != None
    assert payment.cvv() != None
    assert payment.credit_card_owner() != None

# Generated at 2022-06-23 21:31:43.208914
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    credit_card_network = payment.credit_card_network()
    # If the returned value is in the list CREDIT_CARD_NETWORKS, it means that we have a valid value
    assert credit_card_network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:31:49.374285
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    test = 0

    p = Payment()
    for i in range(100):
        month = p.credit_card_expiration_date()[0:2]
        year = p.credit_card_expiration_date()[3:]
        if (month > '12' or month < '01'):
            test += 1
        if (year < '16' or year > '25'):
            test += 1
    assert test == 0

# Generated at 2022-06-23 21:31:51.893099
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Test method credit_card_network of class Payment.

    Testing method credit_card_network of class Payment.
    """
    credit_card_network = Payment('en', seed=4321).credit_card_network()
    assert credit_card_network in CREDIT_CARD_NETWORKS



# Generated at 2022-06-23 21:31:56.055287
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Test with default parameters
    obj = Payment()
    obj_cid = obj.cid()
    assert type(obj_cid) is int
    assert obj_cid >= 1000
    assert obj_cid <= 9999
    obj_cid_2 = obj.cid()
    assert obj_cid != obj_cid_2


# Generated at 2022-06-23 21:32:06.864303
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.enums import CardType
    test_payment = Payment('en')
    test_payment.credit_card_owner(Gender.MALE)
    test_payment.credit_card_owner(Gender.FEMALE)
    test_payment.credit_card_owner(Gender.NEUTRAL)
    test_payment.credit_card_owner()

    # make sure exception is raised when CardType is not given
    # or is not in CardType enum class
    try:
        test_payment.credit_card_number()
    except NonEnumerableError:
        print('tested NonEnumerableError')

    try:
        test_payment.credit_card_number(CardType.VISA)
    except NonEnumerableError:
        print('tested NonEnumerableError')

# Generated at 2022-06-23 21:32:08.961007
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    t = Payment('en')
    x = t.paypal()
    print(x)



# Generated at 2022-06-23 21:32:14.710473
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """
    Unit test for method ethereum_address of class Payment

    Expected Result: Test should return a string with 16 hexadecimal digits
    """
    print("Testing ethereum address generation")
    payment = Payment()
    result = payment.ethereum_address()
    assert(len(result) == 42)
    assert(result[0:2] == "0x")
    assert(result[2:].isalnum)


# Generated at 2022-06-23 21:32:16.219386
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p.seed



# Generated at 2022-06-23 21:32:18.124647
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment(seed=0)
    print(p.credit_card_owner())


# Generated at 2022-06-23 21:32:22.946646
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import CardType

    p = Payment()
    card_num = p.credit_card_number(card_type=CardType.VISA)
    assert p.credit_card_expiration_date(maximum=25) is not None
    assert p.credit_card_expiration_date(minimum=16, maximum=25) is not None


# Generated at 2022-06-23 21:32:26.371083
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    instance = Payment('en')
    assert re.match(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$',
                     instance.paypal())

# Generated at 2022-06-23 21:32:26.887790
# Unit test for constructor of class Payment
def test_Payment():
    pass

# Generated at 2022-06-23 21:32:30.018512
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    returned = p.paypal()
    assert isinstance(returned, str)
    assert len(returned) > 0



# Generated at 2022-06-23 21:32:32.004065
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date()


# Generated at 2022-06-23 21:32:35.093662
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    assert payment.bitcoin_address() == "1CnZUuR6GXv6n9SWW3q3yHghvdE2QT6B89"

# Generated at 2022-06-23 21:32:38.189908
# Unit test for method cid of class Payment
def test_Payment_cid():
    expected = 10000
    actual = Payment()
    actual.random.randint = lambda a,b: expected
    assert actual.cid() == expected


# Generated at 2022-06-23 21:32:48.325833
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_array = [CardType.VISA, CardType.AMERICAN_EXPRESS,
                  CardType.MASTER_CARD]
    result = True
    payment = Payment()
    for card in card_array:
        value = payment.credit_card_number(card)
        if card == CardType.VISA:
            if (re.match(r"^(?:4[0-9]{12}(?:[0-9]{3})?)$", value) == None):
                result = False
        elif card == CardType.AMERICAN_EXPRESS:
            if (re.match(r"^(?:3[47][0-9]{13})$", value) == None):
                result = False

# Generated at 2022-06-23 21:32:49.830770
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    p.credit_card_network()


# Generated at 2022-06-23 21:32:54.507113
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # Test various conditions
    import random
    gender_tuple = Gender.get_list()

    gender = get_random_item(gender_tuple, random)
    gender_string = gender.name

    min = random.randint(1, 5)
    max = random.randint(min, 15)

    random_Payment = Payment(random.seed())
    random_Payment.credit_card_expiration_date(min, max)
    random_Payment.credit_card_owner(gender_string)

    assert True


# Generated at 2022-06-23 21:33:03.222818
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    test_set = [
        ('00/00'),
        ('00/16'),
        ('00/25'),
        ('12/16'),
        ('12/25'),
        ('12/26'),
        ('01/26'),
    ]
    p = Payment()
    credit_card_expiration_date = p.credit_card_expiration_date()
    assert credit_card_expiration_date not in test_set
    credit_card_expiration_date = p.credit_card_expiration_date(
        minimum=0,
        maximum=0,
    )
    assert credit_card_expiration_date in test_set


# Generated at 2022-06-23 21:33:04.224756
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.__dict__ != {}

# Generated at 2022-06-23 21:33:08.450768
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_number = "4455 5299 1152 2450"
    payment = Payment()
    distance = 0
    for i in range(0, 100):
        new_card_number = payment.credit_card_number(card_type=CardType.VISA)
        distance += levenshtein_distance(card_number, new_card_number)
    assert distance / 100 <= 16


# Generated at 2022-06-23 21:33:10.432202
# Unit test for constructor of class Payment
def test_Payment():
    obj = Payment()
    assert obj is not None


# Generated at 2022-06-23 21:33:13.311392
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    email = Payment('en').paypal()
    assert re.match(r'^[-\w+.]+@(\w+\.)+\w+$', email)


# Generated at 2022-06-23 21:33:17.498626
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Arrange
    seed = "202006191124"
    payment = Payment(seed=seed)

    # Act
    cid = payment.cid()

    # Assert
    assert cid == 7660


# Generated at 2022-06-23 21:33:22.134275
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    from mimesis.utils import get_digits

    payment = Payment('ru')
    assert payment.credit_card_network() in [
        card_type.value for card_type in CardType
    ]


# Generated at 2022-06-23 21:33:27.342922
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    # Test if data returns is not empty
    if not payment.credit_card_expiration_date():
        raise AssertionError("payment.credit_card_expiration_date must not return an empty string")

    # Test if data returns is not empty
    if not payment.credit_card_expiration_date(minimum=5, maximum=5):
        raise AssertionError("payment.credit_card_expiration_date must not return an empty string")

# Generated at 2022-06-23 21:33:32.902201
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    # Arrange
    from mimesis.providers.payment import Payment

    # Act
    payment_provider = Payment()
    credit_card_network = payment_provider.credit_card_network()

    # Assert
    assert credit_card_network in CREDIT_CARD_NETWORKS

# Generated at 2022-06-23 21:33:36.674836
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    #Defining a seed
    seed = 1
    #Creating the object payment with seed
    payment = Payment(seed = seed)
    #Calling the method paypal
    paypal = payment.paypal()
    #Asserting the value of paypal method
    assert paypal == "irvin.skiles@hotmail.com"


# Generated at 2022-06-23 21:33:44.777161
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    credit_card_num = Payment().credit_card_number(CardType.VISA)
    assert re.match(r'^\d{4}\s\d{4}\s\d{4}\s\d{4}$', credit_card_num)
    credit_card_num = Payment().credit_card_number(CardType.MASTER_CARD)
    assert re.match(r'^\d{4}\s\d{4}\s\d{4}\s\d{4}$', credit_card_num)
    credit_card_num = Payment().credit_card_number(CardType.AMERICAN_EXPRESS)
    assert re.match(r'^\d{4}\s\d{6}\s\d{5}$', credit_card_num)


# Generated at 2022-06-23 21:33:50.229621
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    credit_card_owner = Payment('en').credit_card_owner(gender=Gender.FEMALE)
    assert credit_card_owner['credit_card'] == '4455 5299 1152 2450'
    assert credit_card_owner['expiration_date'] == '03/19'
    assert credit_card_owner['owner'] == 'KELLY GROSS'

# Generated at 2022-06-23 21:33:53.879591
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Test for class Payment"""
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.payment import Payment

    # Create a payment
    payment = Payment('en')
    # Test credit_card_owner
    print(payment.credit_card_owner(gender=Gender.MALE))
    print(payment.credit_card_owner(gender=Gender.FEMALE))

# Generated at 2022-06-23 21:34:00.245506
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Initialization
    payment = Payment()

    # Test
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)

    # Assertion
    assert len(card_number) == 19
    assert card_number[:4] == "4222"
    assert card_type.value in card_number
    assert card_number[-1:] == "0"


# Generated at 2022-06-23 21:34:04.149503
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment_ins = Payment(seed=31)
    bitcoin_Addr = payment_ins.bitcoin_address()
    print(bitcoin_Addr)
    assert bitcoin_Addr


# Generated at 2022-06-23 21:34:05.604490
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    card = Payment()
    print(card.cvv())


# Generated at 2022-06-23 21:34:06.333412
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    print(p.ethereum_address())


# Generated at 2022-06-23 21:34:09.711948
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment(_random=False)
    card_owner = payment.credit_card_owner(gender=Gender.FEMALE)

    assert card_owner['owner'] == 'ROSA JACKSON'

# Generated at 2022-06-23 21:34:15.906518
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()

    assert len(payment.cid()) > 0
    assert len(payment.paypal()) > 0
    assert len(payment.bitcoin_address()) > 0
    assert len(payment.ethereum_address()) > 0
    assert len(payment.credit_card_network()) > 0
    assert len(payment.credit_card_number()) > 0
    assert len(payment.credit_card_expiration_date()) > 0
    assert len(payment.cvv()) > 0
    assert len(payment.credit_card_owner()) > 0

# Generated at 2022-06-23 21:34:17.775494
# Unit test for constructor of class Payment
def test_Payment():
    payment=Payment()
    print(payment.credit_card_owner())


# Generated at 2022-06-23 21:34:19.141190
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    cvv = Payment().cvv()
    assert type(cvv) is int


# Generated at 2022-06-23 21:34:21.460014
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    assert re.match(r'[\w.+-]+@[\w-]+\.[a-zA-Z]{2,}', Payment().paypal())


# Generated at 2022-06-23 21:34:22.671042
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    print(payment.paypal())


# Generated at 2022-06-23 21:34:23.894672
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert (Payment().cid() > 999) & (Payment().cid() < 10000)


# Generated at 2022-06-23 21:34:27.429130
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment=Payment()
    print(payment.credit_card_owner())
    # print(payment.credit_card_number(card_type=1))
# test_Payment_credit_card_owner()

# Generated at 2022-06-23 21:34:38.491712
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    print(p.bitcoin_address())
    print(p.bitcoin_address())
    print(p.bitcoin_address())

    print(p.credit_card_expiration_date())
    print(p.credit_card_expiration_date())
    print(p.credit_card_expiration_date())
    print(p.credit_card_expiration_date())

    print(p.credit_card_expiration_date(20, 25))
    print(p.credit_card_expiration_date(20, 25))

    print(p.credit_card_network())
    print(p.credit_card_network())

    print(p.credit_card_number())
    print(p.credit_card_number())
    print(p.credit_card_number())


# Generated at 2022-06-23 21:34:46.526026
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    print(p.cid())
    print(p.paypal())
    print(p.bitcoin_address())
    print(p.ethereum_address())
    print(p.credit_card_network())
    print(p.credit_card_number())
    print(p.credit_card_number(CardType.VISA))
    print(p.credit_card_expiration_date())
    print(p.credit_card_owner(Gender.MALE))


# Generated at 2022-06-23 21:34:48.062791
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment_provider = Payment()

    #Test with standalone
    bitcoin_address = payment_provider.bitcoin_address()
    assert bitcoin_address is not None

# Generated at 2022-06-23 21:34:50.063302
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment('en', seed=4) # random number 4
    assert payment.bitcoin_address() == '1G2S6UJTKWNofH6cHTKQ2DgF8nxBxCxNfV'

# Generated at 2022-06-23 21:34:52.547381
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert payment.cid() in range(1000, 9999)
    

# Generated at 2022-06-23 21:34:55.974279
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment
    payment = Payment('en', seed=99999)
    assert payment.person.Gender.MALE is Gender.MALE

# Generated at 2022-06-23 21:35:06.057081
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import CardType, Gender
    from mimesis.providers.payment import Payment
    p = Payment(seed=42)

# Generated at 2022-06-23 21:35:12.095013
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    assert payment.credit_card_owner().get('owner') == "NICHOLAS STONE"
    assert payment.credit_card_owner().get('credit_card') == "4455 5299 1152 2450"
    assert payment.credit_card_owner().get('expiration_date') == "08/24"



# Generated at 2022-06-23 21:35:16.218672
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment()

    # Verify that the method returns one of the given networks
    networks = CREDIT_CARD_NETWORKS
    for _ in range(10):
        assert provider.credit_card_network() in networks


# Generated at 2022-06-23 21:35:19.280154
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment('en')
    assert len(payment.credit_card_network()) > 2


# Generated at 2022-06-23 21:35:28.714728
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_type_list = list(CardType)
    payment = Payment("en")
    random_card_number = payment.credit_card_number()
    # Test that random_card_number is a 16-digit of string
    assert len(random_card_number) == 19
    assert isinstance(random_card_number, str)
    # Test that random_card_number is a string containing only numbers
    for char in random_card_number:
        assert char.isdigit()
    # Test that random_card_number with card_type argument is valid
    for card_type in card_type_list:
        valid = payment.credit_card_number(card_type)
        if card_type == CardType.VISA:
            assert valid[:1] == "4"
            assert len(valid) == 19
        el

# Generated at 2022-06-23 21:35:30.050044
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    p.credit_card_expiration_date()

# Generated at 2022-06-23 21:35:33.839048
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # Test with default value
    def _test_default():
        assert 0 < Payment().cvv() <= 999

    # Test with custom value
    Payment.seed(1234)
    assert Payment().cvv() == 922

    # Test with random value
    Payment.seed()
    _test_default()

    # Try call this function with an argument
    Payment.seed()
    try:
        Payment().cvv(0)
    except TypeError:
        pass
    else:
        assert False, 'Should have raised an error'

# Generated at 2022-06-23 21:35:42.252357
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    from mimesis.enums import Gender
    from mimesis.providers.payment import Payment
    from mimesis.data import CREDIT_CARD_NETWORKS
    import numpy as np
    payment = Payment(seed=55555)
    assert(payment.cvv() in np.arange(100, 999))
    assert(payment.credit_card_network() in CREDIT_CARD_NETWORKS)
    assert(payment.bitcoin_address()!=payment.bitcoin_address())
    assert(type(payment.bitcoin_address())==str)
    assert(payment.ethereum_address()!=payment.ethereum_address())
    assert(type(payment.ethereum_address())==str)
    assert(payment.paypal()!=payment.paypal())

# Generated at 2022-06-23 21:35:47.493506
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    assert p.credit_card_owner(Gender.NEUTRAL) \
        == {'credit_card': '5447 6458 2170 3116',
            'expiration_date': '08/19',
            'owner': 'RUBY MCNEIL'}

# Generated at 2022-06-23 21:35:50.006401
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    c = Payment()
    for i in range(50):
        print (c.cvv())
        assert 3<=len(str(c.cvv()))

# Generated at 2022-06-23 21:35:52.202337
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert Payment().cid() >= 1000



# Generated at 2022-06-23 21:35:54.269799
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert re.search(r'\d{3}', str(payment.cvv()))

# Generated at 2022-06-23 21:35:56.409230
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    x = payment.cvv()
    assert type(x) is int


# Generated at 2022-06-23 21:35:57.704108
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    sp = Payment()
    pa = sp.paypal()
    print(pa)


# Generated at 2022-06-23 21:36:00.649391
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    pm = Payment(seed=1)
    assert pm.bitcoin_address() == "1HXyhe9V64hiYGFVDnir4GwMtgobnuZUNi"


# Generated at 2022-06-23 21:36:02.368594
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    assert p is not None

# Generated at 2022-06-23 21:36:07.254260
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    credit_card_owner = payment.credit_card_owner(Gender.MALE)
    print(credit_card_owner)

if __name__ == "__main__":
    test_Payment_credit_card_owner()

# Generated at 2022-06-23 21:36:10.716278
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Unit test for method credit_card_network of class Payment."""
    payment = Payment('en')
    data = payment.credit_card_network()
    assert data in CREDIT_CARD_NETWORKS



# Generated at 2022-06-23 21:36:12.348106
# Unit test for method cid of class Payment
def test_Payment_cid():
    x = Payment()
    res = x.cid()
    assert type(res) == int


# Generated at 2022-06-23 21:36:14.443421
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment(seed=123)
    assert p.paypal() == "carol.shelton@yahoo.com"

# Generated at 2022-06-23 21:36:16.996102
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    test_obj = Payment()
    test_obj.seed(0)
    assert test_obj.paypal() == "mloore@kim.info"


# Generated at 2022-06-23 21:36:19.335288
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    credit_card_network = payment.credit_card_network()
    assert credit_card_network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:36:21.548868
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    pay = Payment()
    #Test that the length of the expiration date is 5
    assert len(pay.credit_card_expiration_date()) == 5


# Generated at 2022-06-23 21:36:23.443516
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    seed = 5
    assert Payment(seed=seed).credit_card_network() == 'MasterCard'



# Generated at 2022-06-23 21:36:28.688278
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    result = p.credit_card_number(p.random.choice(list(CardType)))
    assert result is not ""
    assert result is not None
    assert result is not "4455 5299 1152 2450"
    assert isinstance(result, str)

if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-23 21:36:30.738560
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    for i in range(100):
        print(Payment('en').paypal())


# Generated at 2022-06-23 21:36:32.929616
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    credit_card_owner = payment.credit_card_owner()
    print(credit_card_owner)


# Generated at 2022-06-23 21:36:33.977787
# Unit test for constructor of class Payment
def test_Payment():
    Payment()

# Generated at 2022-06-23 21:36:41.661061
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner()
    assert len(owner) == 3
    assert re.match(
        r'[4-6]\d{3} \d{4} \d{4} \d{4}',
        owner['credit_card'],
    ) is not None
    assert re.match(r'\d{2}/\d{2}', owner['expiration_date']) is not None
    assert re.match(r'[A-Z]{2,}\s[A-Z]{2,}', owner['owner']) is not None

# Generated at 2022-06-23 21:36:43.851679
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    result = Payment().credit_card_network()
    assert result in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:36:48.387051
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """
    This is a unit test for method credit_card_number of class Payment.
    It returns True or False. If a random credit card number generated by this method starts with '4', the test will pass.
    """
    return Payment().credit_card_number().startswith('4')

# Generated at 2022-06-23 21:36:51.164929
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    res = payment.cid()
    assert res >= 1000
    assert res <= 9999

    payment = Payment(seed=0)
    res = payment.cid()
    assert res >= 1000
    assert res <= 9999



# Generated at 2022-06-23 21:36:54.332445
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    try:
        credit_card_network = payment.credit_card_network()
    except:
        raise Exception("Fail to generate credit card network")
    print(f"Credit card network: {credit_card_network}")



# Generated at 2022-06-23 21:36:57.540348
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    Payment = Payment()
    CREDIT_CARD_NETWORKS = ('Visa', 'MasterCard', 'American Express')
    for _ in range(10):
        result = Payment.credit_card_network()
        assert result in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:37:00.787492
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    assert payment.credit_card_owner()
    assert payment.credit_card_owner(Gender.FEMALE)
    assert payment.credit_card_owner(Gender.MALE)


# Generated at 2022-06-23 21:37:08.559068
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    import unittest

    class PaymentTestCase(unittest.TestCase):
        def setUp(self):
            self.payment_ = Payment()

        def test_payment_credit_card_expiration_date(self):
            expire_date = self.payment_.credit_card_expiration_date()

            self.assertNotEqual('13/13', expire_date)
            self.assertNotEqual('00/00', expire_date)

            self.assertNotIn('/0', expire_date)
            self.assertNotIn('/1', expire_date)

    unittest.main()


# Generated at 2022-06-23 21:37:10.012803
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment(seed=41684)
    assert p.cid() == 5703


# Generated at 2022-06-23 21:37:13.788499
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    a = Payment(seed=1)
    assert a.paypal() == 'pitneybowes@gmail.com'



# Generated at 2022-06-23 21:37:18.018598
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """
    Unit tests for method bitcoin_address of class Payment
    """
    p = Payment("en")
    assert re.match("^[13][A-Za-z0-9]{33}$", p.bitcoin_address()) is not None


# Generated at 2022-06-23 21:37:25.191011
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    i = 0
    while i < 10:
        pay = Payment('en', seed=1)
        print(pay.ethereum_address())
        i += 1
# Output: 0xe8ece9e6ff7dba52d4c07d37418036a89af9698d
#         0x293e3b3f7b07a611e85e28550a2a1a7cde2a01a3
#         0x3ba3aeba23b6d24c7a0e2a1855f2c2e1bea6a06f
#         0x0c7037e64e39c4b6aaef0c4e88cb14cb7d99c8e8
#         0x2b48d12b5910b8e15a27c44a

# Generated at 2022-06-23 21:37:29.373391
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    print('Test method Payment.credit_card_number()')
    print('Expected result: 4455 5299 1152 2450')
    payment  =Payment(random=False)
    print('Result: ' + payment.credit_card_number())


# Generated at 2022-06-23 21:37:30.786582
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    print(payment.credit_card_owner())

# Generated at 2022-06-23 21:37:35.527986
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    address = payment.ethereum_address()

    assert len(address) > 1
    assert address[:2] == '0x'
    if address[2:3] == '0':
        assert len(address) == 42
    elif address[2:3] == 'f':
        assert len(address) == 43

# Generated at 2022-06-23 21:37:37.659755
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    s = p.credit_card_network()
    assert s in ['Visa', 'MasterCard']


# Generated at 2022-06-23 21:37:39.565921
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert payment.cid() >= 1000 and payment.cid() <= 9999


# Generated at 2022-06-23 21:37:41.389167
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    assert Payment().credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:37:45.319235
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    result = payment.cvv()
    assert isinstance(result, int) and (100 <= result <= 999)
    assert len(str(result)) == 3


# Generated at 2022-06-23 21:37:47.744574
# Unit test for constructor of class Payment
def test_Payment():
    #Creating test variable
    payment_class = Payment()
    #Testing of constructor of class Payment
    assert payment_class.__class__.__name__ == "Payment"


# Generated at 2022-06-23 21:37:50.381385
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    assert p.cvv() == p.cvv()


# Generated at 2022-06-23 21:37:52.580987
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment('hi')
    payment2 = Payment('hi', seed=3)
    assert payment.random == payment2.random


# Generated at 2022-06-23 21:38:00.844150
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment(seed=50)
    assert(p.cid() == 3843)
    assert(p.paypal() == 'samuel.morris@gmail.com')
    assert(p.bitcoin_address() == '1Fy5U5d6UutjXhJBr6LzZ6F3q3BjZ6PQoA')
    assert(p.ethereum_address() == '0x8d6e686c284e5a6f0f6f8ae0dab48f9e9f4bf4e8')
    assert(p.credit_card_network() == 'American Express')
    assert(p.credit_card_number() == '4455 5299 1152 2450')
    assert(p.credit_card_expiration_date() == '03/19')


# Generated at 2022-06-23 21:38:06.883572
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment(seed=123456)
    assert payment.cid() == 5809
    assert payment.paypal() == "nicholasjamesphillips@gmail.com"
    assert payment.bitcoin_address() == "3EJLLqb8WwA47kvRUZBqsUJp8xWx9TC6vV"
    assert payment.ethereum_address() == "0xf4c4d20b0eb0ea8f5fe47d0dd59e33bde6e8b622"
    assert payment.credit_card_networ

# Generated at 2022-06-23 21:38:09.763802
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()

    # default
    payment.credit_card_network()

    # False
    payment.credit_card_network(None)


# Generated at 2022-06-23 21:38:12.630994
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    print("Test method cvv.")
    print("\tExpect result is int.")
    assert isinstance(p.cvv(), int)


# Generated at 2022-06-23 21:38:14.141985
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    p.credit_card_owner()

# Generated at 2022-06-23 21:38:18.595044
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment(seed=42)
    owner = payment.credit_card_owner()
    assert owner['credit_card'] == '4455 5299 1152 2450'
    assert owner['expiration_date'] == '03/20'
    assert owner['owner'] == 'SARAH HALL'

# Generated at 2022-06-23 21:38:22.477299
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    numbers = [16,17,18,19,20,21,22,23,24,25]
    payment = Payment()
    for number in numbers:
        card_expiration_date = payment.credit_card_expiration_date(minimum=number)
        print(card_expiration_date)

# Generated at 2022-06-23 21:38:23.715591
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.name == 'payment'

# Generated at 2022-06-23 21:38:33.201252
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
	from mimesis.providers.payment import Payment
	from mimesis import seed
	from mimesis.enums import CardType, Gender
	from mimesis.data import CREDIT_CARD_NETWORKS
	from mimesis.enums import CardType, Gender
	from mimesis.exceptions import NonEnumerableError
	from mimesis.providers.base import BaseProvider
	from mimesis.providers.person import Person
	from mimesis.random import get_random_item
	from mimesis.shortcuts import luhn_checksum
	
	# Init the payment class
	my_payment = Payment(seed=seed)
	
	# Calling the method
	my_payment.bitcoin_address()

# Generated at 2022-06-23 21:38:37.677626
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    print('cid: ', payment.cid())
    print('paypal: ', payment.paypal())
    print('bitcoin_address: ', payment.bitcoin_address())
    print('ethereum_address: ', payment.ethereum_address())
    print('credit_card_network: ', payment.credit_card_network())
    print('credit_card_number: ', payment.credit_card_number())
    print('credit_card_expiration_date: ', payment.credit_card_expiration_date())
    print('cvv: ', payment.cvv())
    print('credit_card_owner: ', payment.credit_card_owner())


# Generated at 2022-06-23 21:38:40.700705
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    provider = Payment(seed=42)
    assert provider.cvv() == 619
    assert provider.cvv() == 619
    assert provider.cvv() == 619


# Generated at 2022-06-23 21:38:43.385295
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Test the method credit_card_network of class Payment."""
    p = Payment()
    res = p.credit_card_network()
    assert res in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:38:48.266415
# Unit test for constructor of class Payment
def test_Payment():
    payment1 = Payment()
    assert isinstance(payment1, Payment)
    assert hasattr(payment1, 'random')
    assert hasattr(payment1, 'datetime')
    assert hasattr(payment1, '__person')


# Generated at 2022-06-23 21:38:51.183711
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payload = Payment('en', seed=111).paypal()
    assert payload == 'linda_fernandez@yahoo.com'
    assert isinstance(payload, str)


# Generated at 2022-06-23 21:38:53.934535
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    print("Payment_paypal")
    p = Payment()
    print(p.paypal())

# Generated at 2022-06-23 21:38:56.935544
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    cvv = Payment().cvv()
    assert isinstance(cvv, int), 'cvv type is incorrect'
    assert (len(str(cvv)) == 3), 'cvv length is incorrect'


# Generated at 2022-06-23 21:38:58.565673
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    pay = Payment('en')
    assert len( str(pay.cvv())) == 3



# Generated at 2022-06-23 21:39:00.179757
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    tp = Payment()
    print(tp.credit_card_network())


# Generated at 2022-06-23 21:39:03.487175
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    credit_card = payment.credit_card_number()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}$', credit_card) is not None


if __name__ == '__main__':
    test_Payment()

# Generated at 2022-06-23 21:39:06.396382
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    a = Payment()
    print(a.cvv())
    print(a.credit_card_owner(Gender.FEMALE))

# test_Payment_cvv()

# Generated at 2022-06-23 21:39:07.760158
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    print(payment.credit_card_network())


# Generated at 2022-06-23 21:39:09.908813
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    assert re.match(r'0x[a-fA-F0-9]{40}', Payment().ethereum_address()) is not None


# Generated at 2022-06-23 21:39:11.384859
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    output = payment.cvv()
    assert len(str(output)) == 3 or len(str(output)) == 4

# Generated at 2022-06-23 21:39:13.860895
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert len(Payment().cid()) != 0


# Generated at 2022-06-23 21:39:18.432329
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis.providers.payment import Payment

    payment = Payment(seed=1)

    address=payment.ethereum_address()

    print(address)

    assert address == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'


# Generated at 2022-06-23 21:39:22.854982
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    '''
    The letest code of method ethereum_address of class Payment
    '''
    # test_count = 1
    # test_count = len(new_Payment.ethereum_address())
    test_count = 100
    error = {}
    # Preprocessing
    new_Payment = Payment()
    # test_count = 1
    # test_count = len(new_Payment.ethereum_address())
    test_count = 10
    error = {}

    # Unit test
    print('Ethereum address validation test:')
    print('*' * 80)
    i = 0
    while i < test_count:
        new_address = new_Payment.ethereum_address()
        print('\r[{}] '.format(new_address), end='')


# Generated at 2022-06-23 21:39:24.089427
# Unit test for method cid of class Payment
def test_Payment_cid():
    provider = Payment('en')
    assert provider.cid()



# Generated at 2022-06-23 21:39:26.472826
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for function Payment.ethereum_address()."""
    assert len(Payment.ethereum_address()) == 42

# Generated at 2022-06-23 21:39:36.675074
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    import datetime
    import mimesis.enums as enums
    import mimesis.providers.payment
    # Create a Payment object
    payment = mimesis.providers.payment.Payment()
    # Create a credit card owner
    credit_card_owner = payment.credit_card_owner()
    # Unit test for the attribute 'credit_card' of the returned dict
    # Tests a pattern with the regex module, including lenght
    # Test the type of the attribute 'credit_card'
    assert isinstance(credit_card_owner['credit_card'], str), \
        "Object 'credit_card' has to be a str"
    # Test the lenght of attribute 'credit_card'

# Generated at 2022-06-23 21:39:40.211929
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    cid1 = payment.cid()
    cid2 = payment.cid()
    assert isinstance(cid1, int)
    assert cid1 < 10000
    assert cid1 > 999
    assert cid1 != cid2


# Generated at 2022-06-23 21:39:41.508471
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    method = Payment()
    result = method.paypal()
    assert result != None


# Generated at 2022-06-23 21:39:47.542177
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    provider = Payment()
    print("Тест метода credit_card_owner класса Payment")
    print("\tПроверка для мужского пола")
    result = provider.credit_card_owner(gender=Gender.MALE)
    print(result)
    print("\tПроверка для женского пола")
    result = provider.credit_card_owner(gender=Gender.FEMALE)
    print(result)


# Generated at 2022-06-23 21:39:50.539604
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    pay = Payment('en')
    assert re.match(r'^\d{4}\s\d{4}\s\d{4}\s\d{4}$', pay.credit_card_number())

# Generated at 2022-06-23 21:39:53.006827
# Unit test for method cid of class Payment
def test_Payment_cid():
    providerFixture = Payment()
    output = providerFixture.cid()
    assert output == 7452


# Generated at 2022-06-23 21:40:02.695219
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.payment import Payment
    from mimesis.random import Random

    p = Payment(seed=100)
    p1 = Person(seed=100)

    # The address will look like ethereum address
    assert p.ethereum_address() == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'

    # The address will look like ethereum address
    assert p.ethereum_address() == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'

    # The address will look like ethereum address

# Generated at 2022-06-23 21:40:04.635833
# Unit test for method cid of class Payment
def test_Payment_cid():
    print(Payment())
    print(Payment().cid())



# Generated at 2022-06-23 21:40:12.071083
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.exceptions import NonEnumerableError
    from mimesis import Payment

    card_num = Payment()

    # Test invalid enum CardType
    try:
        card_num.credit_card_number(card_type='MasterCard')
    except NonEnumerableError:
        assert True

    # Test valid enum CardType
    assert card_num.credit_card_number(card_type=CardType.AMERICAN_EXPRESS)


# Generated at 2022-06-23 21:40:13.749480
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert type(payment.credit_card_expiration_date()) is str


# Generated at 2022-06-23 21:40:15.086155
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Call the method paypal of class Payment
    assert Payment().paypal() is not None

# Generated at 2022-06-23 21:40:16.413011
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    print(p.paypal())

