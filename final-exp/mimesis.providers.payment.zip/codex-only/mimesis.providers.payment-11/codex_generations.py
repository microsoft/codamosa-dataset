

# Generated at 2022-06-23 21:30:21.120699
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    global instance
    instance = Payment()
    if len(str(instance.cvv())) == 3:
        if instance.cvv() >= 100 and instance.cvv() <= 999:
            return True
        else:
            return False
    else:
        return False

if __name__ == '__main__':
    print("Test for method cvv of class Payment: ", test_Payment_cvv())

# Generated at 2022-06-23 21:30:25.740939
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # Arrange
    payment = Payment()

    # Act
    for _ in range(100):
        result = payment.bitcoin_address()
        # Assert
        assert result[0] in ['1', '3']
        assert len(result) == 34
        assert re.match(r'^[A-Za-z0-9]+$', result[1:])


# Generated at 2022-06-23 21:30:27.875380
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment=Payment()
    assert isinstance(payment.credit_card_owner(), dict)



# Generated at 2022-06-23 21:30:28.512570
# Unit test for constructor of class Payment
def test_Payment():
    Payment()

# Generated at 2022-06-23 21:30:30.796607
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    from mimesis import Payment
    payment = Payment()
    assert payment.cvv() in range(100, 999)


# Generated at 2022-06-23 21:30:34.254913
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    try:
        payment = Payment()
        payment.credit_card_network()
    except Exception as e:
        print(e)


# Generated at 2022-06-23 21:30:37.933900
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Unit test for method cvv of class Payment"""
    testcases = list(range(1000))
    for t in testcases:
        payment = Payment(seed=t)
        res = payment.cvv()
        assert type(res) == int
        assert res > 99 and res < 1000
        tmp = Payment()
        res2 = tmp.cvv()
        assert type(res2) == int
        assert res2 > 99 and res2 < 1000
        assert res != res2


# Generated at 2022-06-23 21:30:39.705319
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    a = p.paypal()
    assert isinstance(a, str)

# Generated at 2022-06-23 21:30:41.357150
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    check = Payment(seed = 42)
    string = check.cvv()
    assert string


# Generated at 2022-06-23 21:30:44.904904
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    pay = Payment()
    pay.cvv()
    # Assert function: assert_equal(func(x), y)

# Generated at 2022-06-23 21:30:51.382036
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Test method credit_card_owner of class Payment."""
    gender = Gender.MALE
    payment = Payment()
    owner = payment.credit_card_owner(gender)
    print('Credit card: ', owner['credit_card'])
    print('Expiration date: ', owner['expiration_date'])
    print('Owner: ', owner['owner'])
    cvv = payment.cvv()
    print('CVV: ', cvv)


# Generated at 2022-06-23 21:30:56.781284
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    network = payment.credit_card_network()
    assert str == type(network)
    assert len(network) >= 4
    assert (str(network)).split(' ')[0] in [
        'Visa', 'MasterCard', 'American'
    ]


# Generated at 2022-06-23 21:30:59.001072
# Unit test for method cid of class Payment
def test_Payment_cid():
    p=Payment()
    cid=p.cid()
    assert cid<9999 and cid>1000


# Generated at 2022-06-23 21:31:00.389787
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    print(p.credit_card_network())

# Generated at 2022-06-23 21:31:02.888842
# Unit test for method cid of class Payment
def test_Payment_cid():
    """test class Payment method cid"""
    data = Payment()
    assert type(data.cid()) == int


# Generated at 2022-06-23 21:31:06.864165
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    date = Payment().credit_card_expiration_date()

    # Check month < 12
    month = date.split('/')[0]
    assert int(month) < 12

    # Check year > 15
    year = date.split('/')[1]
    assert int(year) > 15


# Generated at 2022-06-23 21:31:08.254886
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    print(payment.ethereum_address())

# Generated at 2022-06-23 21:31:18.789955
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    Payment.credit_card_number() == '4455 5299 1152 2450'
    assert Payment.credit_card_number() == '4455 5299 1152 2450'
    assert Payment.credit_card_number(card_type=CardType.VISA) == '4455 5299 1152 2450'
    assert Payment.credit_card_number(card_type=CardType.MASTER_CARD) == '2248 3978 5236 6058'
    assert Payment.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == '3777 9282 0168851'
    assert Payment.credit_card_number(card_type=CardType.UNIONPAY) == '6215 8120 8090 0202'


# Generated at 2022-06-23 21:31:23.340939
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # @since 2019-12-31
    payment = Payment(seed=1577768200)
    minimum = payment.random.randint(16, 25)
    maximum = payment.random.randint(16, 25)
    assert len(payment.credit_card_expiration_date(minimum, maximum)) < 5

# Generated at 2022-06-23 21:31:25.294739
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    assert Payment().credit_card_owner(gender=Gender.FEMALE)['owner'] == 'Elisa Rocha'

# Generated at 2022-06-23 21:31:26.721794
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    t = Payment('en')
    print(t.credit_card_owner())

# Generated at 2022-06-23 21:31:31.196912
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    ethereum_address = payment.ethereum_address()
    print(ethereum_address)
    ethereum_address = payment.ethereum_address()
    print(ethereum_address)


# Generated at 2022-06-23 21:31:38.146405
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis.enums import CardType
    """
    Tests the generation of ethereum address by class Payment
    """
    payment = Payment()
    assert re.match('^0x[a-f0-9]{40}$', payment.ethereum_address())
    assert re.match('^0x[a-f0-9]{40}$', payment.ethereum_address(seed=42))
    assert re.match('^0x[a-f0-9]{40}$', payment.ethereum_address(seed='seed'))


# Generated at 2022-06-23 21:31:40.039192
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert Payment().cid()  # No exception


# Generated at 2022-06-23 21:31:44.728225
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    assert(p.paypal() in ['wolf235@gmail.com',
                          'harris99@hotmail.com',
                          'hotdog8@yahoo.com',
                          'hardy_beverly@gmail.com',
                          'tucker50@gmail.com'])


# Generated at 2022-06-23 21:31:48.974980
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    a = Payment()
    l = [a.cvv() for i in range(100000)]
    s = set(l)
    assert len(l)==len(s)
    assert max(l)<=999
    assert min(l)>=100

# Generated at 2022-06-23 21:31:57.688974
# Unit test for constructor of class Payment
def test_Payment():
    print('Testing constructor of class Payment.')
    p = Payment()
    usedMethods = 0
    try:
        p.provider
        print('Failed to raise an exception when using constructor of'\
              + 'class Payment.')
    except Exception as e:
        print('Successfully raised an exception when using constructor of'\
              + 'class Payment. Exception message: ' + str(e))
        usedMethods += 1
    try:
        p.random
        print('Failed to raise an exception when using constructor of'\
              + 'class Payment.')
    except Exception as e:
        print('Successfully raised an exception when using constructor of'\
              + 'class Payment. Exception message: ' + str(e))
        usedMethods += 1

# Generated at 2022-06-23 21:32:00.745640
# Unit test for constructor of class Payment
def test_Payment():
    """Test Payment.
    :return: True, if the tests are passed.
    :rtype: bool
    """
    # Test constructor of class Payment
    payment = Payment()
    assert payment is not None, 'Constructor of class Payment is not working.'
    return True

# Unit test of cid method

# Generated at 2022-06-23 21:32:03.611399
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    number = payment.bitcoin_address()
    # print("number = ", number)

    assert type(number) == str
    assert len(number) == 34



# Generated at 2022-06-23 21:32:05.823296
# Unit test for constructor of class Payment
def test_Payment():
    provider = Payment()
    assert len(provider.credit_card_number()) == 19
    assert len(provider.credit_card_number(card_type=CardType.MASTER_CARD)) == 19


# Generated at 2022-06-23 21:32:10.307897
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    result = p.credit_card_expiration_date()
    print("Result credit_card_expiration_date test:\n " + result)

if __name__ == '__main__':
    test_Payment_credit_card_expiration_date()

# Generated at 2022-06-23 21:32:19.459230
# Unit test for constructor of class Payment
def test_Payment():
    x = Payment()
    ##########################################################################
    # test cid()
    for i in range(10):
        assert x.cid() in range(1000, 9999)


    ##########################################################################
    # test paypal()
    # TODO: write test function


    ##########################################################################
    # test bitcoin_address()
    # TODO: write test function


    ##########################################################################
    # test ethereum_address()
    # TODO: write test function


    ##########################################################################
    # test credit_card_network()
    # TODO: write test function


    ##########################################################################
    # test credit_card_number()
    # TODO: write test function


    ##########################################################################
    # test credit_card_expiration_date()
    # TODO

# Generated at 2022-06-23 21:32:20.872872
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment('en')
    print(payment.bitcoin_address())


# Generated at 2022-06-23 21:32:24.738271
# Unit test for method cid of class Payment
def test_Payment_cid():
    '''
    This is the unit test function for method cid of class Payment
    '''
    if __name__ == "__main__":
        payment = Payment()

        assert isinstance(payment.cid(), int)
        assert 1000 <= payment.cid() <= 9999



# Generated at 2022-06-23 21:32:28.986605
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    """Test credit_card_owner method of Payment class."""
    payment = Payment()
    card_owner = payment.credit_card_owner()
    assert isinstance(card_owner, dict)
    assert isinstance(card_owner['credit_card'], str)
    assert isinstance(card_owner['expiration_date'], str)
    assert isinstance(card_owner['owner'], str)

# Generated at 2022-06-23 21:32:39.184577
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    print(p.credit_card_number())
    print(p.credit_card_number())
    print(p.credit_card_number())
    print(p.credit_card_number())
    print(p.credit_card_number())
    print(p.credit_card_number(card_type=CardType.MASTER_CARD))
    print(p.credit_card_number(card_type=CardType.MASTER_CARD))
    print(p.credit_card_number(card_type=CardType.MASTER_CARD))
    print(p.credit_card_number(card_type=CardType.MASTER_CARD))
    print(p.credit_card_number(card_type=CardType.MASTER_CARD))

# Generated at 2022-06-23 21:32:45.965498
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    t = Payment()
    # t.credit_card_number(CardType.VISA)
    # t.credit_card_number(CardType.MASTER_CARD)
    # t.credit_card_number(CardType.AMERICAN_EXPRESS)
    # t.credit_card_number(CardType.DISCOVER)
    # t.credit_card_number(CardType.DINERS_CLUB)
    t.credit_card_number()

# Generated at 2022-06-23 21:32:52.101871
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    result = p.credit_card_owner()
    assert (
        result['credit_card'] ==
        '4475 0248 5993 7413'
    )
    assert (
        result['expiration_date'] ==
        '11/20'
    )
    assert (
        result['owner'] ==
        'BENJAMIN POTTER'
    )

# Generated at 2022-06-23 21:32:53.425576
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    result = Payment().bitcoin_address()
    assert str(type(result)) == "<class 'str'>"
    print('Payment().bitcoin_address() => ', result)


# Generated at 2022-06-23 21:32:54.885696
# Unit test for method cid of class Payment
def test_Payment_cid():
    obj = Payment()
    assert len(obj.cid()) == 4


# Generated at 2022-06-23 21:32:56.186498
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    print(payment.credit_card_owner())

# Generated at 2022-06-23 21:33:01.587097
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    instance = Payment()
    try:
        for i in range(1000):
            card_type = get_random_item(CardType, rnd=instance.random)
            assert len(instance.credit_card_number(card_type)) == 19
    except Exception as e:
        print(e)
        assert True == False
    assert True == True



# Generated at 2022-06-23 21:33:08.846036
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Test with random seed
    from mimesis import Random
    rnd = Random(seed=13)
    p = Payment(seed=13)
    assert p.ethereum_address() == '0x2c5efc74137964e09f9e8b2d2c06787b0c63b481'

    # Test with random seed
    from mimesis import Random
    rnd = Random(seed=27)
    p = Payment(seed=27)
    assert p.ethereum_address() == '0x10c56d53e2f60a63556ffd33b81eafc0eb6425c6'


# Generated at 2022-06-23 21:33:10.106089
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    result = payment.credit_card_network()
    assert type(result) == str


# Generated at 2022-06-23 21:33:12.493323
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    result = payment.credit_card_network()
    assert(result in CREDIT_CARD_NETWORKS)

# Generated at 2022-06-23 21:33:16.716487
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    print("Testing credit_card_network of class Payment ...")
    result = Payment().credit_card_network()
    print(result)
    assert isinstance(result, str), "The result should be an string"
    print("credit_card_network of class Payment OK")


# Generated at 2022-06-23 21:33:18.922899
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date() in range(16, 25)

# Generated at 2022-06-23 21:33:20.341208
# Unit test for method cid of class Payment
def test_Payment_cid():
    code = Payment().cid()
    # Verification that the result is a number
    assert isinstance(code, int) and (code > 999 and code <= 9999)


# Generated at 2022-06-23 21:33:22.133869
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """
    Test for method paypal of class Payment
    """
    assert Payment().paypal() == Payment(seed=12345).paypal()
    assert Payment().paypal().count('@') == 1


# Generated at 2022-06-23 21:33:23.615055
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert re.compile(r'\b[0-9a-fA-F]{40}\b').match(payment.ethereum_address()) != None

# Generated at 2022-06-23 21:33:24.874268
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    for i in range(10):
        assert isinstance(p.cid(), int)


# Generated at 2022-06-23 21:33:27.180929
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    # We create an instance of Payment class called instance
    instance = Payment('en')
    # We call method credit_card_network() and we print the result
    print(instance.credit_card_network())


# Generated at 2022-06-23 21:33:31.409196
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Uncomment next line to show example test
    result = Payment().cid()
    # print(result)
    assert isinstance(result, int)
    assert result > 0


# Generated at 2022-06-23 21:33:41.136049
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Initialize a seed
    seed = "3ec2054d0c62b7d6"

    # Initialize Payment Object
    p1 = Payment(seed=seed)
    p1.credit_card_owner()
    # Card number = 4362 9447 7002 2875
    # Expiration date = 05/17
    # Owner = 'Alex Blevins'
    
    p2 = Payment(seed=seed)
    p2.credit_card_owner()
    # Card number = 4362 9447 7002 2875
    # Expiration date = 05/17
    # Owner = 'Alex Blevins'

    # Need to initialize a new Payment object to obtain a new result
    p3 = Payment(seed=seed)
    p3.credit_card_owner()
    # Card number = 4362 9447 7002 2875


# Generated at 2022-06-23 21:33:42.804535
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    NumberGenerator = Payment()
    assert type(NumberGenerator.credit_card_network()) == str


# Generated at 2022-06-23 21:33:46.577383
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number(CardType.VISA))
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-23 21:33:48.511246
# Unit test for constructor of class Payment
def test_Payment():
    # Create a Payment object
    payment = Payment()
    # Assert equality true
    assert isinstance(payment, Payment) == True

# Generated at 2022-06-23 21:33:53.612471
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    payment = Payment('en')
    cardVisa = payment.credit_card_number(CardType.VISA)
    assert cardVisa[:2] == '40'
    assert cardVisa[:1] != '4'


# Generated at 2022-06-23 21:34:02.642580
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Test the case the card_type is None
    for i in range(100):
        card = Payment(seed = 42).credit_card_number()
        assert (len(card.split()) == 4)
        assert (card[0] == '4')
        assert (card[-1] in string.digits)

    # Test the case the card_type is CardType.VISA
    card = Payment(seed = 42).credit_card_number(CardType.VISA)
    assert (len(card.split()) == 4)
    assert (card[0] == '4')
    assert (card[1] in string.digits)
    assert (card[2] in string.digits)
    assert (card[3] in string.digits)
    assert (card[4] == ' ')

# Generated at 2022-06-23 21:34:04.782216
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert isinstance(payment.cvv(), int)



# Generated at 2022-06-23 21:34:06.203747
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    p.credit_card_expiration_date()

# Generated at 2022-06-23 21:34:11.606668
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    owner = payment.credit_card_owner()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', owner['credit_card']) is not None
    assert re.match(r'\d{2}/\d{2}', owner['expiration_date']) is not None

# Generated at 2022-06-23 21:34:17.087051
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment(seed=12345)
    expected_bitcoin_address = '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'
    assert payment.bitcoin_address() == expected_bitcoin_address


# Generated at 2022-06-23 21:34:21.045404
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment('en')
    result = provider.credit_card_network()
    # Make sure that we received a string 
    assert(isinstance(result, str)) 
    # Make sure that we received a string with only letters 
    assert result.isalpha()


# Generated at 2022-06-23 21:34:22.869835
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    m = Payment('en')
    assert Payment.Meta.name == "payment"
    assert m.paypal() != m.paypal()

# Generated at 2022-06-23 21:34:26.643904
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():

    # Initializa the Payment object
    py = Payment()

    # create a dictineer
    cc_owner = py.credit_card_owner()

    # Check if the owner key is in the dictineer
    assert 'owner' in cc_owner

    # Check if the owner key is in the dictineer
    assert 'credit_card' in cc_owner

    # Check if the owner key is in the dictineer
    assert 'expiration_date' in cc_owner

# Generated at 2022-06-23 21:34:28.770851
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    seed = 6
    import random
    random.seed(seed)
    print('seed:', seed)
    payment = Payment(seed=seed)
    print(payment.credit_card_network())
    random.seed(seed)
    print(payment.credit_card_network())


# Generated at 2022-06-23 21:34:32.459430
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    """Unit test for method bitcoin_address of class Payment"""
    payment = Payment()
    assert re.match(r'^[13][A-Za-z0-9]{33}$', payment.bitcoin_address()) is not None


# Generated at 2022-06-23 21:34:38.847888
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    provider = Payment(seed=1234)
    credit_card = provider.credit_card_number()

    regex = re.compile(r'(\d{4})(\d{4})(\d{4})(\d{4})')
    groups = regex.search(  # type: ignore
        credit_card,
    ).groups()
    credit_card = ' '.join(groups)
    assert credit_card == '4985 7190 6162 4547'

# Generated at 2022-06-23 21:34:43.977100
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment(seed=12345)
    eth_address = p.ethereum_address()
    assert eth_address == '0x0fd97b25ccce99b93d006601cf1fbf9d64e94a61'


# Generated at 2022-06-23 21:34:45.758932
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment(seed=1)

    assert len(payment.credit_card_expiration_date()) == 5

# Generated at 2022-06-23 21:34:47.755915
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment('en')
    assert p.credit_card_owner(Gender.MALE)
    assert p.credit_card_owner(Gender.FEMALE)

# Generated at 2022-06-23 21:34:49.681980
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert payment.paypal() != payment.paypal()


# Generated at 2022-06-23 21:35:01.380489
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    CREDIT_CARD_NETWORKS_len = len(CREDIT_CARD_NETWORKS)
    payment = Payment()
    result_payment_credit_card_network = payment.credit_card_network()
    CREDIT_CARD_NETWORKS_len_flag = False
    for i in range(CREDIT_CARD_NETWORKS_len):
        if CREDIT_CARD_NETWORKS[i] == result_payment_credit_card_network:
            CREDIT_CARD_NETWORKS_len_flag = True
    if not CREDIT_CARD_NETWORKS_len_flag:
        print("The function of method credit_card_network of class Payment is an error")

from mimesis.enums import CardType
from mimesis.providers.payment import Payment


# Generated at 2022-06-23 21:35:03.123521
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    a = Payment()
    address = a.bitcoin_address()
    assert type(address) is str


# Generated at 2022-06-23 21:35:05.629589
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment('en')
    output = payment.cid()
    assert (isinstance(output, int))
    assert (len(str(output)) == 4)


# Generated at 2022-06-23 21:35:08.173634
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment("en")
    result = payment.paypal()
    print(result)
    
test_Payment_paypal()

# Generated at 2022-06-23 21:35:15.993785
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():

    # Defining the Payment object
    Payment_object = Payment()

    # Testing the first gender
    print(Payment_object.credit_card_owner(gender=Gender.FEMALE))

    # Testing the second gender
    print(Payment_object.credit_card_owner(gender=Gender.MALE))

    # Testing the third gender
    print(Payment_object.credit_card_owner(gender=Gender.BOTH))

    # Testing the default
    print(Payment_object.credit_card_owner())

# Generated at 2022-06-23 21:35:17.669913
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    print(payment.cid())


# Generated at 2022-06-23 21:35:20.223575
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p=Payment()
    s = p.credit_card_network()
    assert True

# Generated at 2022-06-23 21:35:24.444280
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    test_class = Payment(seed=123456)
    assert test_class.ethereum_address() == '0xed4bb69cfecb6fb8d01abbd93dfa770fd25fd0fd'


# Generated at 2022-06-23 21:35:25.598424
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    assert(type(p.cvv()) == int)

# Generated at 2022-06-23 21:35:27.324403
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    assert payment.credit_card_owner()["credit_card"] == payment.credit_card_number()

# Generated at 2022-06-23 21:35:29.596827
# Unit test for method cid of class Payment
def test_Payment_cid():
    """Unit test for method cid of class Payment"""
    payment=Payment('en')
    assert payment.cid() > 0


# Generated at 2022-06-23 21:35:30.949474
# Unit test for method cid of class Payment
def test_Payment_cid():
    for i in range(10):
        assert(isinstance(Payment().cid(), int))


# Generated at 2022-06-23 21:35:32.363805
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert Payment().credit_card_expiration_date() != Payment().credit_card_expiration_date()
    print("test_Payment_credit_card_expiration_date() success")


# Generated at 2022-06-23 21:35:36.185698
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    obj = Payment()
    print("Generated a random credit card number : %s " % obj.credit_card_number())
    print("Generated a random credit card number : %s " % obj.credit_card_number())



# Generated at 2022-06-23 21:35:38.418378
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    minimum = 1000
    maximum = 9999
    value = payment.cid()
    assert value >= minimum and value <= maximum


# Generated at 2022-06-23 21:35:41.966410
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Initialize Payment class
    payment = Payment()
    # Generate address
    generated_address = payment.ethereum_address()
    # Check that generated address is valid
    assert generated_address[0:2] == '0x'
    # Check that generated address is 40 char in length
    assert len(generated_address) == 42

# Generated at 2022-06-23 21:35:43.297185
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment(seed=0)
    
    assert payment.cid() == 7452
    

# Generated at 2022-06-23 21:35:45.474475
# Unit test for method cid of class Payment
def test_Payment_cid():
    cid = Payment().cid()
    assert isinstance(cid, int)


# Generated at 2022-06-23 21:35:47.648383
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    assert type (Payment().credit_card_network()) == str


# Generated at 2022-06-23 21:35:49.815329
# Unit test for method cid of class Payment
def test_Payment_cid():
    print("test_Payment_cid()")
    p = Payment()
    print(p.cid())


# Generated at 2022-06-23 21:35:53.873428
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    s = set()
    for _ in range(1000):
        s.add(p.bitcoin_address())
    assert len(s) == 1000


# Generated at 2022-06-23 21:35:55.999441
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    assert isinstance(p.paypal(), str)


# Generated at 2022-06-23 21:35:57.866007
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment('en')
    assert isinstance(payment,Payment)



# Generated at 2022-06-23 21:36:05.900816
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()

    # VISA
    assert isinstance(payment.credit_card_number(CardType.VISA), str)
    assert payment.credit_card_number(CardType.VISA).startswith('4')
    assert 4 <=  len(payment.credit_card_number(CardType.VISA).split(' ')) <= 5

    # MasterCard
    assert isinstance(payment.credit_card_number(CardType.MASTER_CARD), str)
    assert payment.credit_card_number(CardType.MASTER_CARD).startswith('5')
    assert 4 <=  len(payment.credit_card_number(CardType.MASTER_CARD).split(' ')) <= 5

    # American Express

# Generated at 2022-06-23 21:36:10.485948
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    card_type = get_random_item(CardType, rnd=random)
    number = Payment.credit_card_number(card_type = card_type)
    network = Payment.credit_card_network(number = number)
    assert network == card_type
    
    

# Generated at 2022-06-23 21:36:12.158106
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    test = p.cvv()
    assert test > 99 and test < 1000


# Generated at 2022-06-23 21:36:18.544586
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test method credit_card_number of class Payment"""
    p = Payment(seed=123)
    assert p.credit_card_number(CardType.VISA) == '4554 5299 1152 2450'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3411 111111 11115'
    assert p.credit_card_number(CardType.MASTER_CARD) == '5167 9751 5017 8556'


# Generated at 2022-06-23 21:36:20.510119
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    x = Payment()
    y = Payment()
    assert x.bitcoin_address() != y.bitcoin_address()


# Generated at 2022-06-23 21:36:27.807910
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    generated_cards = Payment()
    for card_type in CardType:
        if card_type == CardType.AMERICAN_EXPRESS:
            assert len(generated_cards.credit_card_number(CardType.AMERICAN_EXPRESS)) == 15
        else:
            assert len(generated_cards.credit_card_number(card_type)) == 16

if __name__ == '__main__':
    test_Payment_credit_card_number()

# Generated at 2022-06-23 21:36:29.449532
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    obj = Payment('en')
    result = obj.cvv()
    assert result is not None


# Generated at 2022-06-23 21:36:40.302518
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    start = 40000000000000
    p = Payment()
    for i in range(100):
        for card_type in CardType:
            assert len(p.credit_card_number(card_type)) == 16
            if card_type == CardType.VISA:
                assert start <= int(p.credit_card_number(card_type)) < start + 10000
            elif card_type == CardType.MASTER_CARD:
                assert ((2221000000000 <= int(p.credit_card_number(card_type)) < 2222000000000)
                        or (5100000 <= int(p.credit_card_number(card_type)) < 56000000))

# Generated at 2022-06-23 21:36:42.097190
# Unit test for method cid of class Payment
def test_Payment_cid():
    provider = Payment()
    result = provider.cid()
    assert type(result) == int


# Generated at 2022-06-23 21:36:44.732107
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    card_num = Payment().credit_card_number(CardType.VISA)
    assert card_num[0] == '4'


# Generated at 2022-06-23 21:36:48.866810
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    bitcoin_address = payment.bitcoin_address()
    assert re.match('^[13][a-km-zA-HJ-NP-Z1-9]{33}', bitcoin_address) == True

# Generated at 2022-06-23 21:36:50.678673
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment(random.randint(1,10))
    assert payment.credit_card_expiration_date() != None
    
    

# Generated at 2022-06-23 21:36:52.564296
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for i in range(10):
        print(payment.credit_card_number())


# Generated at 2022-06-23 21:36:54.412551
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    assert isinstance(payment.cvv(), int)
    assert len(str(payment.cvv())) == 3


# Generated at 2022-06-23 21:36:56.393162
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    PROOF = 0x0123456789abcdef
    
    payment = Payment()
    assert payment.ethereum_address() == format(PROOF, 'x')

# Generated at 2022-06-23 21:37:03.687105
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert payment.cid() is not None
    assert payment.paypal() is not None
    assert payment.bitcoin_address() is not None
    assert payment.ethereum_address() is not None
    assert payment.credit_card_network() is not None
    assert payment.cvv() is not None
    assert payment.credit_card_number() is not None
    assert payment.credit_card_expiration_date() is not None
    assert payment.credit_card_owner()

# Generated at 2022-06-23 21:37:07.195246
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    for i in range(10):
        credit_card_network = payment.credit_card_network()
        assert credit_card_network in CREDIT_CARD_NETWORKS
        assert isinstance(credit_card_network, str)


# Generated at 2022-06-23 21:37:12.562439
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    temp = Payment()
    x = temp.credit_card_owner()
    assert(x['credit_card'].find('VISA') > 0 and x['expiration_date'].find('/') == 2)
    x = temp.credit_card_owner(Gender.MALE)
    assert(x['credit_card'].find('VISA') > 0 and x['expiration_date'].find('/') == 2)
    x = temp.credit_card_owner(Gender.FEMALE)
    assert(x['credit_card'].find('VISA') > 0 and x['expiration_date'].find('/') == 2)

# Generated at 2022-06-23 21:37:16.254876
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    owner = payment.bitcoin_address()
    assert(re.match(r'[13][A-Za-z0-9]{33}', owner))


# Generated at 2022-06-23 21:37:24.647271
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    #Arrange
    Gender = Gender.MALE
    expected_cc_num = '4455 5299 1152 2450'
    expected_exp_date = '05/24'
    person = Person('en', seed=123)
    expected_owner = person.full_name(gender=Gender)
    #Act
    payment = Payment(seed=123)
    result = payment.credit_card_owner(gender=Gender)
    #Assert
    assert result['credit_card'] == expected_cc_num
    assert result['expiration_date'] == expected_exp_date
    assert result['owner'] == expected_owner.upper()

# Generated at 2022-06-23 21:37:34.495493
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    import pytest
    from mimesis.providers.payment import Payment
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError

    p = Payment()
    p1 = Payment()
    p2 = Payment()
    p3 = Payment()
    p4 = Payment()
    p5 = Payment()
    p6 = Payment()
    p7 = Payment()
    p8 = Payment()

    assert isinstance(p.credit_card_expiration_date(), str)
    assert len(p.credit_card_expiration_date()) == 5
    assert isinstance(p.credit_card_expiration_date(minimum=16, maximum=20), str)
    assert len(p.credit_card_expiration_date(minimum=16, maximum=20)) == 5
    assert isinstance

# Generated at 2022-06-23 21:37:35.980573
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    print (p.ethereum_address())

# Generated at 2022-06-23 21:37:38.246335
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment()
    value = provider.credit_card_network()
    assert (value in CREDIT_CARD_NETWORKS)



# Generated at 2022-06-23 21:37:42.231684
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    expected_owner = {
        'credit_card': '5336 5272 9586 6515',
        'expiration_date': '02/17',
        'owner': 'BRADLEY SALISBURY'
    }
    assert expected_owner == Payment().credit_card_owner(gender=Gender.MALE)

# Generated at 2022-06-23 21:37:48.518774
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment('en')
    card_type = CardType.VISA
    expectedResult = "4455 5299 1152 2450"
    result = payment.credit_card_number(card_type=card_type)
    if result == expectedResult:
        print("PASS, Result: " + result + " Expected: " + expectedResult)
    else:
        print("FAIL, Result: " + result + " Expected: " + expectedResult)

# Generated at 2022-06-23 21:37:52.816072
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Test credit_card_network method of Payment class."""
    payment = Payment()
    credit_card_network = payment.credit_card_network()
    assert credit_card_network in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:37:54.984344
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment()
    print(provider.credit_card_network())


# Generated at 2022-06-23 21:38:00.113305
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    assert(Payment().credit_card_owner().get('credit_card').count('/') == 1)
    assert(Payment().credit_card_owner()['credit_card'].count(' ') == 3)



# Generated at 2022-06-23 21:38:03.738279
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment('en')
    card_network = payment.credit_card_network()
    assert card_network in CREDIT_CARD_NETWORKS, 'card_network should in CREDIT_CARD_NETWORKS'


# Generated at 2022-06-23 21:38:06.755029
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    cvv = Payment()
    # cvv code must be in the range of 100 to 999
    assert 100 <= cvv.cvv() <= 999


# Generated at 2022-06-23 21:38:10.363258
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    res = payment.credit_card_network()
    assert res in CREDIT_CARD_NETWORKS, \
        "Failed: res is not in CREDIT_CARD_NETWORKS"


# Generated at 2022-06-23 21:38:12.817351
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    print(p.bitcoin_address())
    assert isinstance(p.bitcoin_address(), str)


# Generated at 2022-06-23 21:38:14.967016
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert isinstance(payment.cid(), int)


# Generated at 2022-06-23 21:38:21.341801
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Tests for all cardtypes and count of their occurance for 10 cardnumers."""

    num_test = 10
    cards = {cardtype: 0 for cardtype in CardType}
    payment = Payment()

    for _ in range(num_test):
        card_type = payment.credit_card_network()
        cards[card_type] += 1

    print(cards)
    assert cards['Visa'] == num_test, "Cardtype Visa was not generated {} times.".format(num_test)

# Generated at 2022-06-23 21:38:25.640384
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    assert payment.credit_card_expiration_date() in ['01/16','02/16','03/16','04/16','05/16','06/16','07/16','08/16','09/16','10/16','11/16','12/16']

# Generated at 2022-06-23 21:38:34.434065
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    from mimesis.providers.person import Person

    payment = Payment('en')
    person = Person('en')

    visa_count = 0
    master_card_count = 0
    american_express_count = 0

    print("\nTest credit card network: ")
    for i in range(1, 11):
        if payment.credit_card_network() == CardType.VISA:
            visa_count += 1
        elif payment.credit_card_network() == CardType.MASTER_CARD:
            master_card_count += 1
        else:
            american_express_count += 1
        print(payment.credit_card_network())


# Generated at 2022-06-23 21:38:39.242561
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    gender = Gender.MALE
    credit_card_owner = payment.credit_card_owner(gender=Gender.MALE)
    assert credit_card_owner["owner"].split(" ")[0].lower() == payment.__person.gender(gender=Gender.MALE)

# Generated at 2022-06-23 21:38:41.416497
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    result = payment.cvv()
    print('cvv is ' + str(result))


# Generated at 2022-06-23 21:38:42.798737
# Unit test for constructor of class Payment
def test_Payment():
    obj = Payment()
    assert obj
# test_Payment()


# Generated at 2022-06-23 21:38:47.919871
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Option 1:
    pay = Payment()
    print(pay.credit_card_number())

    # Option 2:
    from mimesis.enums import CardType
    print(Payment().credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-23 21:38:52.059353
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    eth_address = Payment().ethereum_address()
    assert(len(eth_address) == 42)
    assert(eth_address[0:2] == '0x')
    assert(re.match('[a-fA-F0-9]+', eth_address[2:]) != None)


# Generated at 2022-06-23 21:38:57.117449
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    b = p.credit_card_number()
    print(b)


if __name__ == '__main__':
    test_Payment_credit_card_number()
    # print(Payment().credit_card_number(CardType.MASTER_CARD))

# Generated at 2022-06-23 21:38:59.761375
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    mp = Payment()
    card_cvv = mp.cvv()
    assert len(str(card_cvv)) == 3
    assert type(card_cvv) == int
    assert 0 < card_cvv < 1000

# Generated at 2022-06-23 21:39:02.121239
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    provider = Payment('zh', seed=9)
    paypal = provider.paypal()
    assert isinstance(paypal, str)
    assert len(paypal) > 0


# Generated at 2022-06-23 21:39:06.518855
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    assert p.ethereum_address() 
    assert len(p.ethereum_address()) == 42
    assert isinstance(p.ethereum_address(), str)


# Generated at 2022-06-23 21:39:13.429864
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    payment = Payment()
    credit_card_owner_male = payment.credit_card_owner(gender=Gender.MALE)
    print(credit_card_owner_male)
    assert credit_card_owner_male['owner'].split()[1] == payment.person.surname(gender=Gender.MALE)
    credit_card_owner_female = payment.credit_card_owner(gender=Gender.FEMALE)
    print(credit_card_owner_female)
    assert credit_card_owner_female['owner'].split()[1] == payment.person.surname(gender=Gender.FEMALE)
    credit_card_owner = payment.credit_card_owner()
    print(credit_card_owner)

# Generated at 2022-06-23 21:39:19.475079
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(seed=42, locale='en')
    assert p.credit_card_number(card_type=CardType.VISA) == '4455 5299 1152 2450'
    assert p.credit_card_number(card_type=CardType.MASTER_CARD) == '5213 3857 9839 7575'
    assert p.credit_card_number(card_type=CardType.AMERICAN_EXPRESS) == '3742 621827 46750'

# Generated at 2022-06-23 21:39:22.088355
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pay = Payment(seed=1)
    assert pay.paypal() == 'Pasquali@example.com'


# Generated at 2022-06-23 21:39:24.619599
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment('en')
    print(payment.credit_card_expiration_date())

if __name__ == '__main__':
    test_Payment_credit_card_expiration_date()

# Generated at 2022-06-23 21:39:27.770923
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    import pytest
    from mimesis.enums import Gender

    payment = Payment()

    gender = Gender
    assert isinstance(payment.credit_card_owner(gender), dict)

# Generated at 2022-06-23 21:39:33.381232
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # initialize the Payment class
    p = Payment()
    # => function call
    # calling the function paypal with no arguments, will return
    # a random email address.
    s = p.paypal()
    # ensure the type of return value
    assert isinstance(s, str)
    # check if the string contains '@', symbol
    assert '@' in s
    # => end of the function call

# Generated at 2022-06-23 21:39:35.006763
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    result = payment.ethereum_address()
    assert result is not None


# Generated at 2022-06-23 21:39:39.552841
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    # 1.Arrange
    UnitTest = Payment()
    UnitTest.seed(5)
    # 2.Act
    result = UnitTest.bitcoin_address()
    # 3.Assert
    assert result == '1Ce23p8uw7VcJgEzK9X2QkAu83tPmjtDGk'


# Generated at 2022-06-23 21:39:42.304467
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    eth_address = p.ethereum_address()
    assert eth_address[:2] == '0x'
    assert eth_address[2:].isalnum()

# Generated at 2022-06-23 21:39:49.097121
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    payment = Payment(seed=42)
    # random.seed(42)
    # TODO: To continue test
    # card = payment._Payment__credit_card_number(CardType.VISA) # '4355 5299 1152 2450'
    # expiration_date = payment._Payment__credit_card_expiration_date(16, 25) # '03/19'
    # full_name = payment._Payment__person.full_name(Gender.MALE).upper() # 'LINDSAY GILBERT'
    # owner = {'credit_card':card, 'expiration_date':expiration_date, 'owner':full_name} # {
    # 'credit_card': '4355 5299

# Generated at 2022-06-23 21:39:52.606076
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    provider = Payment()
    address = provider.bitcoin_address()
    assert len(address) == 34
    assert address[0] in ['1', '3']


# Generated at 2022-06-23 21:39:55.215663
# Unit test for constructor of class Payment
def test_Payment():
    print("test_Payment")
    payment = Payment(seed=1)
    assert payment.paypal() is not None

# Generated at 2022-06-23 21:40:02.038309
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    min_year = 16
    max_year = 25
    for _ in range(0, 100):
        m, y = Payment().credit_card_expiration_date(minimum=min_year,
                                                     maximum=max_year).split('/')
        if len(y) != 2:
            raise Exception(
                "The length of expiration year is not 2, but: " + str(len(y)))
        if(int(y) + 2000 < min_year or int(y) + 2000 > max_year):
            raise Exception(
                "The expiration year is not between " + str(min_year) +
                " and " + str(max_year) + ", but: " + str(int(y) + 2000))

# Generated at 2022-06-23 21:40:13.617204
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
	# This test is for method credit_card_number of class Payment
	# This test is for CardType.VISA
	# 1st test
	# This test is for cardtype = CardType.VISA
	# expected = 4000
	print("Test 1st: ")
	VISA = Payment()
	cardtype = VISA.credit_card_number(card_type = CardType.VISA)
	print(cardtype)
	# 2nd test
	# This test is for cardtype = CardType.MASTER_CARD
	# expected = 2221
	print("Test 2nd: ")
	MASTER_CARD = Payment()
	cardtype = MASTER_CARD.credit_card_number(card_type = CardType.MASTER_CARD)
	print(cardtype)
	# 3rd test
	#

# Generated at 2022-06-23 21:40:17.362424
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    from mimesis.providers.payment import Payment
    p = Payment('en', seed=12345)
    assert p.ethereum_address() == '0xFF55A1EB8E67A734D09387A59CBFE22D6A87930A'
