

# Generated at 2022-06-23 21:30:12.034077
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    assert isinstance(payment.credit_card_owner(), dict)

# Generated at 2022-06-23 21:30:21.441423
# Unit test for method credit_card_owner of class Payment

# Generated at 2022-06-23 21:30:25.393893
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert payment.ethereum_address() == "0x7B0C5d721d9D96FbF46C1A637e7926A2bC2A0f53"
    assert len(payment.ethereum_address()) == 42


# Generated at 2022-06-23 21:30:29.934695
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    pmt = Payment()
    credit_card = pmt.credit_card_network()
    assert credit_card in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:30:31.270341
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    print('\nMethod bitcoin_address of class Payment.')
    print(Payment().bitcoin_address())


# Generated at 2022-06-23 21:30:36.873645
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    name = payment.credit_card_owner()
    assert name['owner'] == 'DENNIS KEMPER'
    assert name['credit_card'] == '5458 6551 9484 4929'
    assert name['expiration_date'] == '02/17'

# Generated at 2022-06-23 21:30:40.747257
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    provider = Payment()
    print("\nTesting bitcoin_address:\n")
    print("Bitcoin address: {}".format(provider.bitcoin_address()))
    

# Generated at 2022-06-23 21:30:51.123779
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    cvv = payment.cvv()
    assert isinstance(cvv, int), 'Expected int, but got %s' % type(cvv)
    cvv = payment.cvv()
    assert isinstance(cvv, int), 'Expected int, but got %s' % type(cvv)
    # There should be no assert
    # Let's test the constructor of Person
    assert hasattr(payment, '__person'), 'Expected __person'
    person = payment.__person
    assert isinstance(person, Person), 'Expected Person, but got %s' % type(person)
    # There should be no assert



# Generated at 2022-06-23 21:30:53.488181
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    assert re.match(r'0x[a-fA-F0-9]{40}', payment.ethereum_address())

# Generated at 2022-06-23 21:30:55.414088
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    assert isinstance(Payment().cvv(), int)


# Generated at 2022-06-23 21:30:58.452542
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    result = Payment().cvv()
    assert len(str(result)) == 3
    assert type(result) == int


# Generated at 2022-06-23 21:31:02.840520
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    """Testing for method credit_card_network of class Payment"""

    for _ in range(50):
        # Create object Payment
        payment = Payment()

        # Create variable function
        function = payment.credit_card_network()

        # Check result of function
        assert function in CREDIT_CARD_NETWORKS

# Generated at 2022-06-23 21:31:04.899013
# Unit test for constructor of class Payment
def test_Payment():
    """Unit test for constructor of class Payment"""
    payment = Payment(seed=123456)
    assert payment is not None


# Generated at 2022-06-23 21:31:07.544951
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment('en')
    assert re.match(r'[13][a-km-zA-HJ-NP-Z1-9]{33}', p.bitcoin_address()) is not None


# Generated at 2022-06-23 21:31:12.344769
# Unit test for method cid of class Payment
def test_Payment_cid(): 
    import random
    # Generate random number as seed
    seed = random.randint(1000, 10000)
    # Seed the random number generator
    random.seed(seed)

    # Generate a random number
    expected = random.randint(1000, 9999)
    
    # Seed the random number generator
    random.seed(seed)

    # Create a Payment object, use the same seed
    p = Payment(seed=seed)

    # Call method cid of class Payment, and got the same number
    real = p.cid()

    # Compare expected and real
    assert(expected == real)



# Generated at 2022-06-23 21:31:18.141456
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    methods_results = []

    for _ in range(10):
        payment = Payment(seed=random.randint(1, 200))
        result = payment.ethereum_address()
        methods_results.append(result)
    #print(methods_results)
    if len(methods_results) > len(set(methods_results)):
        print("error: method return the same result")
        assert False


len_str_random = []

# Generated at 2022-06-23 21:31:20.614375
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment(random.Random())
    print (payment.credit_card_network())


# Generated at 2022-06-23 21:31:22.933281
# Unit test for method cid of class Payment
def test_Payment_cid():
    test_Payment = Payment(seed=42)
    assert test_Payment.cid() == 5395


# Generated at 2022-06-23 21:31:24.245612
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    print(payment.credit_card_network())


# Generated at 2022-06-23 21:31:26.069610
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    providerObject = Payment()
    print(providerObject.ethereum_address())


# Generated at 2022-06-23 21:31:29.998424
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    for _ in range(10):
        assert bool(re.match(r'^0x[a-f0-9]{40}$', payment.ethereum_address()))

# Generated at 2022-06-23 21:31:33.289270
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # Create a instance of class Payment
    payment = Payment()
    # Get the method for test
    func = payment.paypal
    # Check the type of returned value
    assert func() is not None

# Generated at 2022-06-23 21:31:36.594065
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    """
    Check a Paypal account
    """
    assert re.search(r'\w+@\w+\.\w+',Payment().paypal()) is not None


# Generated at 2022-06-23 21:31:39.028995
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    pay = Payment()
    print(pay.paypal())


# Generated at 2022-06-23 21:31:41.078913
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    obj = Payment()
    result = obj.paypal()
    print(result)



# Generated at 2022-06-23 21:31:47.241493
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert Payment().bitcoin_address() in ['1N9vFcFkf4Nq3p4NjBwaDxoNwWzSQ2BK1J',
                                           '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX',
                                           '1KtJZRNbBCsCDLxnDFbwJgKjyUUFRi9XjP']



# Generated at 2022-06-23 21:31:49.373227
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    value = Payment().cvv()
    isinstance(value, int) and 100 <= value <= 999


# Generated at 2022-06-23 21:31:50.939561
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    print(p.cvv())


# Generated at 2022-06-23 21:31:55.350457
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    expiration_date = p.credit_card_expiration_date()
    assert expiration_date is not None and isinstance(expiration_date, str)
    expiration_date = p.credit_card_expiration_date(minimum=1, maximum=40)
    assert expiration_date is not None and isinstance(expiration_date, str)


# Generated at 2022-06-23 21:32:01.167172
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    print("doing Payment_credit_card_network test...")
    result_set = []
    payment = Payment()
    for i in range(100):
        result = payment.credit_card_network()
        result_set.append(result)
    assert len(result_set) == len(set(result_set))



# Generated at 2022-06-23 21:32:04.109391
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    # First, we create a Payment object
    payment = Payment()
    # Then, we generate a CVV
    cvv = payment.cvv()
    # Finally, we check that the CVV is a 3-digit integer
    assert type(cvv) == int and 100 <= cvv <= 999

# Generated at 2022-06-23 21:32:06.491140
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    test_cases = (
        payment.credit_card_number,
        payment.credit_card_expiration_date
    )
    for test_case in test_cases:
        assert test_case()

# Generated at 2022-06-23 21:32:10.654420
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    """Unit test for method cvv of class Payment"""
    # Execute method under test
    result = Payment().cvv()
    # Check result
    assert isinstance(result, int)
    assert len(str(result)) == 3


# Generated at 2022-06-23 21:32:18.755857
# Unit test for constructor of class Payment
def test_Payment():
    """Unit test for payment"""

    payment = Payment()

    assert payment.cid() >= 1000
    assert payment.cid() <= 9999
    assert payment.paypal() != ''
    assert payment.bitcoin_address() != ''
    assert payment.ethereum_address() != ''
    assert payment.credit_card_network() in CREDIT_CARD_NETWORKS
    str_num = payment.credit_card_number()
    assert len(str_num) >= 16
    assert len(str_num) <= 24
    assert payment.credit_card_expiration_date() != ''
    assert payment.cvv() >= 100
    assert payment.cvv() <= 999
    assert payment.credit_card_owner() != {}

# Generated at 2022-06-23 21:32:21.375865
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    assert Payment().ethereum_address() == '0x86b84d7f869a8775e77c85c1e69fdf0a8d8a9f42'

# Generated at 2022-06-23 21:32:24.880147
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Test method ethereum_address of class Payment."""
    obj = Payment(seed=12345)
    assert obj.ethereum_address() == '0xe8ece9e6ff7dba52d4c07d37418036a89af9698d'

# Generated at 2022-06-23 21:32:29.087633
# Unit test for constructor of class Payment
def test_Payment():

    test = Payment()

    assert test.cid()
    assert test.paypal()
    assert test.bitcoin_address()
    assert test.ethereum_address()
    assert test.credit_card_network()
    assert test.credit_card_number()
    assert test.credit_card_expiration_date()
    assert test.cvv()
    assert test.credit_card_owner()

# Generated at 2022-06-23 21:32:30.056993
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert len(payment.paypal()) > 0



# Generated at 2022-06-23 21:32:36.798805
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment

    p = Payment()

    for _ in range(100):
        assert len(p.credit_card_expiration_date()) == 5

    for _ in range(100):
        assert len(p.credit_card_expiration_date(minimum=0, maximum=1)) == 5

    for _ in range(100):
        assert len(p.credit_card_expiration_date(minimum=94, maximum=99)) == 5



# Generated at 2022-06-23 21:32:41.009086
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    print("\n#Unit test for method credit_card_network of class Payment")

    from mimesis.enums import CardType
    p = Payment()
    card_type = p.credit_card_network()
    assert card_type in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:32:43.605915
# Unit test for method cid of class Payment
def test_Payment_cid():
    seed = 1
    p = Payment(seed=seed)
    result = p.cid()
    assert result == 9464



# Generated at 2022-06-23 21:32:45.517791
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment(seed=0)

    value = payment.cid()

    assert value == 7250


# Generated at 2022-06-23 21:32:50.071507
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():

    from mimesis.enums import CardType

    sub = Payment(seed=42)
    for _ in range(100):
        assert sub.credit_card_number(CardType.VISA).startswith('4')
        assert sub.credit_card_number(CardType.AMERICAN_EXPRESS).startswith('34')
        assert sub.credit_card_number(CardType.AMERICAN_EXPRESS).startswith('37')
        assert sub.credit_card_number(CardType.MASTER_CARD).startswith(('5', '2'))

# Generated at 2022-06-23 21:32:51.463045
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert type(payment.paypal()) == str


# Generated at 2022-06-23 21:32:53.448683
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    num = payment.credit_card_number(CardType.VISA)
    print(num)


# Generated at 2022-06-23 21:33:03.977071
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.payment import Payment

    payment = Payment('en')
    owner = payment.credit_card_owner(gender = Gender.MALE)
    assert isinstance(owner, dict)
    assert owner['credit_card'].isdigit()
    assert len(owner['credit_card']) == 16
    assert owner['expiration_date']
    assert owner['owner'].isupper()

    owner = payment.credit_card_owner(gender = Gender.FEMALE)
    assert isinstance(owner, dict)
    assert owner['credit_card'].isdigit()
    assert len(owner['credit_card']) == 16
    assert owner['expiration_date']

# Generated at 2022-06-23 21:33:11.033988
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')

    # Test with Gender male
    owner = payment.credit_card_owner(gender=Gender.MALE)
    assert isinstance(owner, dict)
    assert 'credit_card' in owner
    assert isinstance(owner['credit_card'], str)
    assert 'expiration_date' in owner
    assert 'owner' in owner
    assert isinstance(owner['expiration_date'], str)
    assert isinstance(owner['owner'], str)
    # Test with Gender female
    owner = payment.credit_card_owner(gender=Gender.FEMALE)
    assert isinstance(owner, dict)
    assert 'credit_card' in owner
    assert isinstance(owner['credit_card'], str)
    assert 'expiration_date' in owner
    assert 'owner' in owner
   

# Generated at 2022-06-23 21:33:12.593982
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    cc = Payment()
    print(cc.ethereum_address())

# Generated at 2022-06-23 21:33:14.473281
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    x = Payment('en', seed=0)
    assert x.bitcoin_address() == '1ADjtD5fRHBgLp1McbyH8djvYXjpmSAfZo'


# Generated at 2022-06-23 21:33:24.990520
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment(localization='en')
    if p.credit_card_number() == p.credit_card_number():
        print("Both credit card numbers are equal")
    else:
        print("The credit card numbers are different")
    if p.credit_card_number(CardType.MASTER_CARD) == p.credit_card_number(CardType.MASTER_CARD):
        print("Both credit card numbers are equal")
    else:
        print("The credit card numbers are different")
    if p.credit_card_number(CardType.AMERICAN_EXPRESS) == p.credit_card_number(CardType.AMERICAN_EXPRESS):
        print("Both credit card numbers are equal")
    else:
        print("The credit card numbers are different")


# Generated at 2022-06-23 21:33:28.130097
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    print(payment.credit_card_network())


# Generated at 2022-06-23 21:33:36.675239
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    from mimesis.providers.payment import Payment
    from mimesis.enums import Gender

    P = Payment('en')
    re_paypal = re.compile('\w+@\w+\.\w+')
    # Check for default locale (en)
    for i in range(0, 10):
        res = P.paypal()
        if not re_paypal.match(res):
            assert False

    # Check for non-default locale
    P = Payment('ru')
    for i in range(0, 10):
        res = P.paypal()
        if not re_paypal.match(res):
            assert False


# Generated at 2022-06-23 21:33:40.039996
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    assert p.paypal() == "davidson.jake@hotmail.com"


# Generated at 2022-06-23 21:33:41.833975
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    print('\nBitcoin address: ', payment.bitcoin_address())


# Generated at 2022-06-23 21:33:44.111804
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    item = Payment()
    print(item.credit_card_expiration_date())
    assert item.credit_card_expiration_date(16, 20) != None



# Generated at 2022-06-23 21:33:53.146152
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment("en", seed=100)
    assert "Maria" in p.credit_card_owner(Gender.FEMALE)["owner"]
    assert "Watson" in p.credit_card_owner(Gender.FEMALE)["owner"]
    assert "4922" in p.credit_card_owner(Gender.FEMALE)["credit_card"]
    assert "6280" in p.credit_card_owner(Gender.FEMALE)["credit_card"]
    assert "05/21" in p.credit_card_owner(Gender.FEMALE)["expiration_date"]

# Generated at 2022-06-23 21:33:56.303036
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    item = payment.cid()
    assert type(item) is int
    assert item >= 1000 and item <= 9999


# Generated at 2022-06-23 21:33:59.757806
# Unit test for method cid of class Payment
def test_Payment_cid():
    # Get an instance of Payment provider class
    pay = Payment()

    # Get a random cid
    cid = pay.cid()

    # Check the length of cid
    if len(str(cid)) == 4:
        print("The length of cid is the same")
    else:
        print("The length of cid is not the same")


# Generated at 2022-06-23 21:34:06.535746
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    number = p.credit_card_number(CardType.VISA)
    assert number[:1] == '4'
    assert len(number) == 19
    assert number[:4] == '4455'
    assert number[-1] == str(luhn_checksum(number[:-1]))
    print("test_Payment: OK")

if __name__ == "__main__":
    test_Payment()

# Generated at 2022-06-23 21:34:10.779077
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment1 = Payment()
    print(payment1.credit_card_number())
    print(payment1.credit_card_number(CardType.MASTER_CARD))
    print(payment1.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-23 21:34:16.366747
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    result = payment.credit_card_number(CardType.VISA)
    assert type(result) == str

    result = payment.credit_card_number(CardType.MASTER_CARD)
    assert type(result) == str

    result = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert type(result) == str

    result = payment.credit_card_number()
    assert type(result) == str


# Generated at 2022-06-23 21:34:20.704798
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment(random_state=1)
    owner = p.credit_card_owner()
    assert owner['credit_card'] == '5500 2094 0170 0343'
    assert owner['expiration_date'] == '08/18'
    assert owner['owner'] == 'BRUCE HYDE'

# Generated at 2022-06-23 21:34:21.923970
# Unit test for constructor of class Payment
def test_Payment():
    py = Payment()
    assert hasattr(py, '_random')

# Generated at 2022-06-23 21:34:24.336568
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment(seed=0)
    assert payment.credit_card_network() == "Visa"
    assert payment.credit_card_network() == "MasterCard"
    assert payment.credit_card_network() == "Visa"


# Generated at 2022-06-23 21:34:26.090331
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment('en')
    payment.bitcoin_address()

# Generated at 2022-06-23 21:34:29.288177
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment(random=True)
    print(payment.credit_card_number())
    assert payment.credit_card_number() is not None


# Generated at 2022-06-23 21:34:30.793354
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    p = Payment()
    print(p.cvv())



# Generated at 2022-06-23 21:34:35.501021
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    assert len(p.bitcoin_address()) == 34
    assert p.bitcoin_address().startswith('1') or p.bitcoin_address().startswith('3')

if __name__ == "__main__":
    p = Payment()
    print(p.bitcoin_address())

# Generated at 2022-06-23 21:34:37.803078
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    assert p.credit_card_network() in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:34:39.964870
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment('en')

    assert len(str(payment.cvv())) == 3


# Generated at 2022-06-23 21:34:42.780425
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    assert CREDIT_CARD_NETWORKS.count(Payment().credit_card_network()) == 1

# Generated at 2022-06-23 21:34:45.359125
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert(('3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX' == Payment().bitcoin_address()))


# Generated at 2022-06-23 21:34:50.093351
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    sample_ethereum_address = payment.ethereum_address()
    ethereum_address_pattern = re.compile(r'0x[a-zA-Z0-9]{40}')
    assert re.match(ethereum_address_pattern, sample_ethereum_address)

# Generated at 2022-06-23 21:34:54.532919
# Unit test for constructor of class Payment
def test_Payment():
    pp = Payment('en')
    print(pp.credit_card_owner())
    print(pp.credit_card_owner(gender=Gender.FEMALE))

if __name__ == "__main__":
    test_Payment()

# Generated at 2022-06-23 21:34:57.183475
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    method_caller = Payment()
    assert re.match(r'^\S+@\S+\.\S+$', method_caller.paypal())

# Generated at 2022-06-23 21:34:58.694855
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    assert p.ethereum_address()

# Generated at 2022-06-23 21:35:03.915084
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    # Unit test should raise no exception
    try:
        seed = 0
        i = 0
        while i < 10:
            i = i + 1
            Payment(seed=seed).ethereum_address()
            seed = seed + 1
    except Exception as e:
        print("Failed case #1: " + str(e))
        assert 0


# Generated at 2022-06-23 21:35:10.106511
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    import unittest
    class testPayment_credit_card_expiration_date(unittest.TestCase):

        def test_returnValidDate(self):
            #arrange
            from mimesis.builtins import Payment
            import random
            import re
            card = Payment()
            length = random.randint(16, 25)
            #act
            result = card.credit_card_expiration_date(length)
            #assert
            self.assertEqual(re.match(r'\d{2}/\d{2}', result), re.match(r'\d{2}/\d{2}', result))
        def test_returnInvalidDate(self):
            #arrange
            from mimesis.builtins import Payment
            import random
            import re
            card = Payment()
            length

# Generated at 2022-06-23 21:35:19.400205
# Unit test for constructor of class Payment
def test_Payment():
    from mimesis.enums import Gender
    p = Payment()
    assert p.__doc__ != ""
    cid_code = p.cid()
    assert isinstance(cid_code, int)
    assert (cid_code >= 1000) and (cid_code <= 9999)
    assert p.paypal() != ""
    assert p.bitcoin_address() != ""
    assert p.ethereum_address() != ""
    assert p.credit_card_network() != ""
    card_num = p.credit_card_number(CardType.VISA)
    assert card_num != ""
    assert card_num.count(" ") == 4
    assert len(card_num) == 19
    card_date = p.credit_card_expiration_date()
    assert card_date != ""

# Generated at 2022-06-23 21:35:21.162492
# Unit test for method cid of class Payment
def test_Payment_cid():
    import random
    seed = random.randint(0, 1000)
    payment = Payment(seed=seed)
    cid = payment.cid()
    print(cid)


# Generated at 2022-06-23 21:35:29.550800
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    assert isinstance(payment.paypal(), str)
    assert payment.random.choice(string.ascii_letters) in payment.paypal()
    assert payment.random.choice(string.ascii_letters) in payment.paypal()
    assert payment.random.choice(string.ascii_letters) in payment.paypal()
    assert payment.random.choice(string.ascii_letters) in payment.paypal()
    assert payment.random.choice(string.ascii_letters) in payment.paypal()
    assert payment.random.choice(string.ascii_letters) in payment.paypal()


# Generated at 2022-06-23 21:35:35.523891
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment
    """
    from mimesis.enums import Locale
    from mimesis.providers.payment import Payment
    payment = Payment(Locale.EN.value, seed=1)
    m1 = payment.ethereum_address()
    m2 = payment.ethereum_address()

    assert m1 == m2
    # print("m1 = " , m1)
    # print("m2 = " , m2)

    # print("m1 = " , m1)

# Generated at 2022-06-23 21:35:37.128023
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    P = Payment()
    assert len(P.credit_card_owner()) == 3

# Generated at 2022-06-23 21:35:38.357095
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    print(payment.bitcoin_address())


# Generated at 2022-06-23 21:35:40.442373
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    generated_bitcoin_address = payment.bitcoin_address()
    print('Generated bitcoin address: ', generated_bitcoin_address)


# Generated at 2022-06-23 21:35:43.709916
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    res = Payment().bitcoin_address()
    print(res)
    res = Payment().bitcoin_address()
    print(res)
    res = Payment().bitcoin_address()
    print(res)
    res = Payment().bitcoin_address()
    print(res)
    res = Payment().bitcoin_address()
    print(res)


# Generated at 2022-06-23 21:35:46.047809
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment(seed=1234567)
    assert payment.paypal() == "ybeach@hotmail.com"

# Generated at 2022-06-23 21:35:49.575717
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    paypals = set()
    for i in range(10**4):
        paypals.add(payment.paypal())
    assert len(paypals) == 10**4

# Generated at 2022-06-23 21:35:54.802787
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    for _ in range(1000):
        value = payment.credit_card_network()
        if not isinstance(value, str):
            raise Exception('value is not string')
        # print(value)
        assert isinstance(value, str)


# Generated at 2022-06-23 21:35:59.400737
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
	p = Payment()
	ans = p.ethereum_address()
	assert ans is not None
	assert len(ans) > 15
	assert ans[0:2] == '0x'
	assert ans[2:].isalnum()
	assert len(ans[2:]) == 40


# Generated at 2022-06-23 21:36:01.883191
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment('en')
    owner = payment.credit_card_owner()
    print(owner)


# Generated at 2022-06-23 21:36:06.040069
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
	pay = Payment(seed=123)
	assert pay.bitcoin_address() == '1CKvwx1m5A5rBkMjmhGv5m5gXmPexmAVLT'


# Generated at 2022-06-23 21:36:10.562699
# Unit test for constructor of class Payment
def test_Payment():
    import unittest
    class testPayment(unittest.TestCase):
        def test_Payment_init(self):
            self.assertIsInstance(Payment(), Payment)
            self.assertIsInstance(Payment('ua'), Payment)
            self.assertIsInstance(Payment('ru', seed=1), Payment)
    unittest.main(module=__name__)

# Unit tests for cid(_) method of class Payment

# Generated at 2022-06-23 21:36:13.073164
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    assert Payment().credit_card_expiration_date() == "12/20"
    assert Payment().credit_card_expiration_date(minimum=10, maximum=19) == "04/15"


# Generated at 2022-06-23 21:36:17.755506
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
        import random
        rng = random.Random()
        rng.seed(100)
        p = Payment(rng)
        p.bitcoin_address()
        assert p.bitcoin_address() == '1N2i5n8A8QFub5UEYw6z5vfv7D5i56yvyX'

# Generated at 2022-06-23 21:36:26.373971
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    minimum = 10
    maximum = 20
    expiration_date = payment.credit_card_expiration_date(minimum, maximum)
    expiration_date_by_year = expiration_date.split('/')[1]
    print(expiration_date_by_year)
    # Check the value of year is in range (minimum, maximum)
    assert minimum <= int(expiration_date_by_year) <= maximum, "test_Payment_credit_card_expiration_date failed"

if __name__ == '__main__':
    test_Payment_credit_card_expiration_date()

# Generated at 2022-06-23 21:36:27.609631
# Unit test for method cid of class Payment
def test_Payment_cid():
    p = Payment()
    p.cid()


# Generated at 2022-06-23 21:36:28.927047
# Unit test for method cid of class Payment
def test_Payment_cid():
    payment = Payment()
    assert 0 < payment.cid() < 10000



# Generated at 2022-06-23 21:36:31.263163
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
	assert re.search(r'^\d{4} \d{4} \d{4} \d{4}$', Payment().credit_card_number())

# Generated at 2022-06-23 21:36:32.285774
# Unit test for constructor of class Payment
def test_Payment():
    assert Payment()


# Generated at 2022-06-23 21:36:38.363982
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    # Store the results of each iteration of the loop
    results = []
    # 10 times runs
    for _ in range(10):
        # Create a Payment object
        obj = Payment()
        # Call method credit_card_expiration_date
        # and save the result
        results.append(obj.credit_card_expiration_date())
    # Print the results
    for result in results:
        print(result)


# Generated at 2022-06-23 21:36:40.343633
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert type(Payment().cid()) == int


# Generated at 2022-06-23 21:36:51.472967
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    print("\n" + "#"*3 + " " + "bitcoin_address" + " " + "#"*3)

    payment = Payment()
    bitcoin_address = payment.bitcoin_address()
    print(bitcoin_address)
    print(len(bitcoin_address))

    assert isinstance(bitcoin_address, str)
    assert len(bitcoin_address) == 34
    payment = Payment(seed="1111")
    bitcoin_address = payment.bitcoin_address()
    assert bitcoin_address == "1jJE8xwW6xvUjKQJzY2B8fUrW9Cv1JpHj"
    payment = Payment(seed="2222")
    bitcoin_address = payment.bitcoin_address()

# Generated at 2022-06-23 21:36:52.732046
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    assert len(Payment().bitcoin_address()) == 36



# Generated at 2022-06-23 21:36:54.528746
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    appTest = Payment()
    print(appTest.credit_card_owner())
    print(appTest.credit_card_owner(Gender.FEMALE))

# Generated at 2022-06-23 21:37:04.992670
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    # this function will run a unit test for method paypal of class Payment
    # first, create an instance of Payment()
    paymnt = Payment()
    # assume that the result must be a str
    resultIsStr = isinstance(paymnt.paypal(), str)
    # assume that the length of the result must be more than 10
    resultLength = len(paymnt.paypal()) > 10
    # assume that the result must have '@' and '.'
    resultHasAt = '@' in paymnt.paypal()
    resultHasDot = '.' in paymnt.paypal()
    # an email must be in a form of [anything]@[anything].[anything]
    # so, we got 3 things to check:
    # if the result is a str
    # if it has more than 10 chars
    #

# Generated at 2022-06-23 21:37:07.320280
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    result = Payment(seed=1000).credit_card_network()
    assert result == 'MasterCard', "test_Payment_credit_card_network()"


# Generated at 2022-06-23 21:37:08.558593
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment()
    print(payment.bitcoin_address())

# Generated at 2022-06-23 21:37:10.875048
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    p = Payment()
    assert isinstance(p.paypal(), str)
    assert isinstance(p.bitcoin_address(), str)
    assert p.bitcoin_address().startswith(('1', '3'))


# Generated at 2022-06-23 21:37:15.553995
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    p = Payment()
    assert re.search(r'^[13][a-km-zA-HJ-NP-Z1-9]{33}$', p.bitcoin_address())


# Generated at 2022-06-23 21:37:18.159690
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment()
    l = list(p.credit_card_network() for _ in range(3))
    assert len(set(l)) == 3


# Generated at 2022-06-23 21:37:21.733718
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
  from mimesis.enums import CardType
  from mimesis.providers.payment import Payment
  cardNetworks = ['Visa','MasterCard','American Express','Discover']
  for i in range(100):
    p = Payment()
    assert p.credit_card_network() in cardNetworks

# Generated at 2022-06-23 21:37:25.414862
# Unit test for method cid of class Payment
def test_Payment_cid():
    cid = Payment.payment().cid()
    cid_list = []
    cid_list.append(cid)
    print(cid)
    #print(cid_list)


# Generated at 2022-06-23 21:37:34.829348
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    import unittest
    from mimesis.enums import Gender

    class TestPayment(unittest.TestCase):
        def setUp(self):
            self.creditCardOwner = Payment().credit_card_owner(gender=Gender.MALE)

        def test_generate_credit_card_owner_with_male_gender(self):
            self.assertIn('credit_card', self.creditCardOwner)
            self.assertIn('expiration_date', self.creditCardOwner)
            self.assertIn('owner', self.creditCardOwner)
            self.assertIsInstance(self.creditCardOwner['credit_card'], str)
            self.assertIsInstance(self.creditCardOwner['expiration_date'], str)
            self.assertIsInstance(self.creditCardOwner['owner'], str)

    return un

# Generated at 2022-06-23 21:37:36.596152
# Unit test for method cid of class Payment
def test_Payment_cid():
    a = Payment('en')
    assert a.cid() in range(1000, 10000)
    assert len(str(a.cid())) == 4


# Generated at 2022-06-23 21:37:45.227692
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():

    from mimesis import Payment

    # Seed
    crypto = Payment('en', seed=42)

    # Random method
    assert crypto.bitcoin_address() == '1HuisCdJaQnx2EBHZLQ9TmBmFTgsmdTzKs'

    # Unit test
    crypto_42 = Payment('en', seed=42)
    crypto_42_1 = Payment('en', seed=42)
    crypto_42_2 = Payment('en', seed=42)
    crypto_42_3 = Payment('en', seed=42)

    assert crypto_42.bitcoin_address() == '1HuisCdJaQnx2EBHZLQ9TmBmFTgsmdTzKs'

# Generated at 2022-06-23 21:37:47.973583
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment_object = Payment()
    result = payment_object.credit_card_owner()
    assert isinstance(result['credit_card'], str)
    assert isinstance(result['expiration_date'], str)
    assert isinstance(result['owner'], str)

# Generated at 2022-06-23 21:37:58.059196
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    import random
    import math
    import statistics

    # init seed and class
    seed = random.randint(1, 999999)
    print("seed: " + str(seed))
    testclass = Payment(seed=seed)

    # get and print results
    results = []
    for i in range(0, 10):
        results.append({'result': int(testclass.credit_card_expiration_date(20, 20)['year']),
                        'expacted': 20,
                        'output': testclass.credit_card_expiration_date(20, 20)})

    print("results: " + str(results))

    # test mean
    print("mean: " + str(statistics.mean(map(lambda x: x['result'], results))))

# Generated at 2022-06-23 21:38:00.514848
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    provider = Payment()
    email = provider.paypal()
    assert email is not None


# Generated at 2022-06-23 21:38:06.707692
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    # Test function
    payment = Payment('en')
    credit_card = payment.credit_card_owner()
    assert isinstance(credit_card, dict) == True
    assert len(credit_card) == 3
    assert 'credit_card' in credit_card == True
    assert 'expiration_date' in credit_card == True
    assert 'owner' in credit_card == True
    assert isinstance(credit_card['credit_card'], str) == True
    assert isinstance(credit_card['expiration_date'], str) == True

# Generated at 2022-06-23 21:38:08.781939
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    print(p.credit_card_number(CardType.VISA))

# Generated at 2022-06-23 21:38:11.595706
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    provider = Payment('en')
    random_CreditCardNetwork = provider.credit_card_network()
    assert random_CreditCardNetwork in CREDIT_CARD_NETWORKS

# Generated at 2022-06-23 21:38:13.061436
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    p = Payment()
    print(p.credit_card_owner())

# Generated at 2022-06-23 21:38:15.585005
# Unit test for method cid of class Payment
def test_Payment_cid():
    assert len(str(Payment().cid())) == 4
    assert type(Payment().cid()) is int


# Generated at 2022-06-23 21:38:17.448813
# Unit test for method cvv of class Payment
def test_Payment_cvv():
    payment = Payment()
    a = payment.cvv()
    assert a > 0 and a < 1000



# Generated at 2022-06-23 21:38:19.178582
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    payment = Payment()
    payment.provider.random.seed(0)
    assert payment.paypal() == 'graham_williamson@yahoo.com'


# Generated at 2022-06-23 21:38:22.907580
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    gen_instance = Payment()
    assert gen_instance.credit_card_expiration_date(16, 25) == '03/19'

# Generated at 2022-06-23 21:38:26.943371
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    """Unit test for method ethereum_address of class Payment"""
    test_object = Payment()
    result = test_object.ethereum_address()
    assert len(result) == 42
    # print(result)
    # print(f'Тип полученного объекта - {type(result)}')


# Generated at 2022-06-23 21:38:29.728096
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    request_ = Payment(seed = 123456789)
    response = request_.credit_card_owner(gender=Gender.MALE)
    assert response.values() == dict_values_required_for_test_credit_card_owner

# Generated at 2022-06-23 21:38:38.766550
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    print("generate random cid: ", payment.cid())
    print("generate random paypal: ", payment.paypal())
    print("generate random bitcoin address: ", payment.bitcoin_address())
    print("generate random ethereum address: ", payment.ethereum_address())
    print("generate random credit card network: ", payment.credit_card_network())
    print("generate random credit card number: ", payment.credit_card_number())
    print("generate random credit card expiration date: ", payment.credit_card_expiration_date())
    print("generate random cvv: ", payment.cvv())
    print("generate random credit card owner: ", payment.credit_card_owner())

# Generated at 2022-06-23 21:38:43.383589
# Unit test for constructor of class Payment
def test_Payment():
    p = Payment()
    # p.bitcoin_address()
    assert Payment().bitcoin_address()
    print(p.credit_card_expiration_date())
    print(p.credit_card_expiration_date(16, 26))
    print(p.credit_card_number())

if __name__ == "__main__":
    test_Payment()

# Generated at 2022-06-23 21:38:54.065734
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    p = Payment()
    p1 = Payment(seed=1)
    p2 = Payment(seed=2)

    assert p.credit_card_expiration_date() == p1.credit_card_expiration_date()
    assert p.credit_card_expiration_date() == p2.credit_card_expiration_date()

    assert p.credit_card_expiration_date() == '02/17'
    assert p1.credit_card_expiration_date() == '02/17'
    assert p2.credit_card_expiration_date() == '02/17'

    assert p.credit_card_expiration_date(1) == '06/19'
    assert p.credit_card_expiration_date(1, 2) == '01/01'

    assert p1.credit_card_

# Generated at 2022-06-23 21:38:56.671397
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment()
    result = payment.credit_card_expiration_date()
    assert result != "03/15"
    assert result != "03/26"

# Generated at 2022-06-23 21:38:58.311324
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    a = Payment()
    assert a.credit_card_expiration_date() == "04/16"


# Generated at 2022-06-23 21:39:04.185216
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    result = Payment.credit_card_expiration_date(2019, 2021)

    if result[3] != "/":
        raise Exception("Error in Payment.credit_card_expiration_date")

    if len(result) != 5:
        raise Exception("Error in Payment.credit_card_expiration_date")

    if result == "00/0":
        raise Exception("Error in Payment.credit_card_expiration_date")

    if int(result[0] + result[1]) > 12:
        raise Exception("Error in Payment.credit_card_expiration_date")


# Generated at 2022-06-23 21:39:12.307132
# Unit test for constructor of class Payment
def test_Payment():
    from mimesis.enums import Gender
    from mimesis.enums import CardType
    test_data = Payment()
    #test_data.__person = Person('en', seed=test_data.seed)
    assert isinstance(test_data.cid(), int)
    assert isinstance(test_data.paypal(), str)
    assert isinstance(test_data.bitcoin_address(), str)
    assert isinstance(test_data.ethereum_address(), str)
    assert isinstance(test_data.credit_card_network(), str)
    assert isinstance(test_data.credit_card_number(CardType.VISA), str)
    assert isinstance(test_data.credit_card_expiration_date(), str)
    assert isinstance(test_data.cvv(), int)
    assert isinstance

# Generated at 2022-06-23 21:39:15.288112
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
#    pytest.skip()
    p = Payment()
    print(p.credit_card_owner(Gender.MALE))


# Generated at 2022-06-23 21:39:17.384824
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    payment = Payment()
    result = payment.credit_card_network()
    assert result in CREDIT_CARD_NETWORKS


# Generated at 2022-06-23 21:39:21.601989
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    instances = []
    count = 0
    while count < 1000:
        instances.append(Payment(seed=count).bitcoin_address())
        count = count + 1
    # At the end of the loop, print the instances
    print(*instances, sep='\n')
    # Store the instances
    with open('data/Payment/bitcoin_address.txt', 'w', encoding='utf-8') as file:
        file.writelines(f'{instance}\n' for instance in instances)


# Generated at 2022-06-23 21:39:22.638218
# Unit test for method credit_card_expiration_date of class Payment
def test_Payment_credit_card_expiration_date():
    payment = Payment(locale='en')
    payment.credit_card_expiration_date()

# Generated at 2022-06-23 21:39:23.974405
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    provider = Payment()
    print(provider.ethereum_address())

test_Payment_ethereum_address()

# Generated at 2022-06-23 21:39:25.641231
# Unit test for constructor of class Payment
def test_Payment():
    payment = Payment()
    assert hasattr(payment, "_seed")
    assert hasattr(payment, "_random")


# Generated at 2022-06-23 21:39:28.630884
# Unit test for method cid of class Payment
def test_Payment_cid():
    obj = Payment()
    print (obj.cid())
    # The result is 4 digits
    assert 4 <= len(str(obj.cid())) <= 4


# Generated at 2022-06-23 21:39:30.420578
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    payment = Payment()
    print('Payment: ', payment.ethereum_address())

# Generated at 2022-06-23 21:39:32.842793
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    p = Payment('en')
    a = p.credit_card_network()
    assert a in ['Visa', 'MasterCard', 'American Express', 'China UnionPay']

# Generated at 2022-06-23 21:39:34.350730
# Unit test for method credit_card_owner of class Payment
def test_Payment_credit_card_owner():
    payment = Payment()
    p = payment.credit_card_owner(gender=Gender.MALE)
    print("p is: " , p)

# Generated at 2022-06-23 21:39:35.498822
# Unit test for method ethereum_address of class Payment
def test_Payment_ethereum_address():
    p = Payment()
    assert len(p.ethereum_address()) == 42

# Generated at 2022-06-23 21:39:39.009258
# Unit test for method bitcoin_address of class Payment
def test_Payment_bitcoin_address():
    payment = Payment(seed=42)
    bitcoin_address = payment.bitcoin_address()
    assert bitcoin_address == '3EktnHQD7RiAE6uzMj2ZifT9YgRrkSgzQX'


# Generated at 2022-06-23 21:39:46.357289
# Unit test for method credit_card_network of class Payment
def test_Payment_credit_card_network():
    from random import seed
    from mimesis.enums import CardType
    seed(0)
    payment = Payment(seed=0)
    assert payment.credit_card_network() == 'Visa'
    assert payment.credit_card_network() == 'Visa'
    assert payment.credit_card_network() == 'MasterCard'
    assert payment.credit_card_network() == 'Visa'
    assert payment.credit_card_network() == 'MasterCard'
    assert payment.credit_card_network() == 'Visa'
    assert payment.credit_card_network() == 'Visa'
    assert payment.credit_card_network() == 'MasterCard'
    assert payment.credit_card_network() == 'American Express'
    assert payment.credit_card_network() == 'MasterCard'
    seed(0)

# Generated at 2022-06-23 21:39:50.275451
# Unit test for constructor of class Payment
def test_Payment():
    paypal = Payment('en')
    assert type(paypal.credit_card_expiration_date(minimum=16, maximum=25)) == str
    assert type(paypal.credit_card_network()) == str
    assert 'xxxx' not in paypal.credit_card_number(card_type=CardType.MASTER_CARD)
    assert type(paypal.credit_card_number()) == str
    assert type(paypal.paypal()) == str

# Generated at 2022-06-23 21:39:53.102850
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    _seed = 0
    _payment = Payment(_seed).paypal()
    assert _payment == 'mark.brown@narod.ru'


# Generated at 2022-06-23 21:39:56.040920
# Unit test for method cid of class Payment
def test_Payment_cid():
    test_obj = Payment()

    test_obj.random.seed(1)
    assert test_obj.cid() == 7452


# Generated at 2022-06-23 21:40:03.077994
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    payment = Payment()
    card_number = payment.credit_card_number(card_type=CardType.VISA)
    check_digit = int(card_number[-1])
    control_sum = 0
    for i in range(0, len(card_number) - 1, 2):
        control_sum += int(card_number[i])
    for i in range(1, len(card_number), 2):
        digit = int(card_number[i]) * 2
        control_sum += digit % 10 + digit // 10
    assert check_digit == (10 - (control_sum % 10)) % 10

# Generated at 2022-06-23 21:40:06.127933
# Unit test for method paypal of class Payment
def test_Payment_paypal():
    obj = Payment('en')
    result = obj.paypal()
    print(result)


if __name__ == "__main__":
    test_Payment_paypal()

# Generated at 2022-06-23 21:40:13.794231
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    instance = Payment(seed=1234)
    cardVisa = instance.credit_card_number(CardType.VISA)
    assert cardVisa == "4192 4359 5104 9704"
    cardMastercard = instance.credit_card_number(CardType.MASTER_CARD)
    assert cardMastercard == "5100 6481 1063 2797"
    cardAmericanexpress = instance.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert cardAmericanexpress == "3404 360667 46763"