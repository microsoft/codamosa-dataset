

# Generated at 2022-06-17 22:55:39.132546
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 250'


# Generated at 2022-06-17 22:55:43.564650
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'


# Generated at 2022-06-17 22:55:51.065459
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment."""
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())
    assert re.match(r'\d{4} \d{6} \d{5}', payment.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-17 22:56:01.195038
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 5299 1152 2450'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3600 5299 1152 2450'
    assert payment.credit_card_number(CardType.JCB) == '3528 5299 1152 2450'

# Generated at 2022-06-17 22:56:13.259996
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[0:4] == card_number[5:9]
    assert card_number[0:4] == card_number[10:14]
    assert card_number[0:4] == card_number[15:19]
    assert card_number[0:4] != card_number[1:5]
    assert card_number[0:4] != card_number[2:6]
    assert card_number[0:4] != card_number[3:7]


# Generated at 2022-06-17 22:56:16.717983
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 22:56:23.492159
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0892 8074 8092'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:56:28.327695
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number.count(' ') == 3
    assert card_number[0] == '4'
    assert card_number[-1] == '0'


# Generated at 2022-06-17 22:56:31.886659
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 22:56:38.552880
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 245'


# Generated at 2022-06-17 22:56:49.169438
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number())

# Generated at 2022-06-17 22:56:58.948284
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    from mimesis.random import Random
    from mimesis.typing import Seed

    random = Random()
    seed = Seed.create_from_hex('f5e3c3f5e3c3f5e3')
    random.seed(seed)
    payment = Payment(random)

    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0981 4981 5454'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 0981 4981 545'
    assert payment.credit_card

# Generated at 2022-06-17 22:57:01.514780
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[-1] == luhn_checksum(card_number[:-1])


# Generated at 2022-06-17 22:57:04.823774
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 22:57:07.106369
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())

# Generated at 2022-06-17 22:57:10.745439
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0892 4444 5555'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:57:18.061502
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:57:23.209605
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'

# Generated at 2022-06-17 22:57:29.327235
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    credit_card_number = payment.credit_card_number(card_type)
    assert credit_card_number[0] == '4'
    assert len(credit_card_number) == 19
    assert credit_card_number[4] == ' '
    assert credit_card_number[9] == ' '
    assert credit_card_number[14] == ' '

# Generated at 2022-06-17 22:57:36.745337
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 4982 5984 6091'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number() == '4455 5299 1152 2450'

# Generated at 2022-06-17 22:58:11.417882
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[-1] == luhn_checksum(card_number[:-1])


# Generated at 2022-06-17 22:58:17.747947
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment."""
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 8098 6091'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:58:27.521888
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[1] == ' '
    assert card_number[5] == ' '
    assert card_number[9] == ' '
    assert card_number[13] == ' '
    assert card_number[17] == ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number

# Generated at 2022-06-17 22:58:34.907069
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 3456'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number() == '4455 5299 1152 2450'


# Generated at 2022-06-17 22:58:35.992120
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert card_number[0] == '4'


# Generated at 2022-06-17 22:58:41.095544
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number.count(' ') == 3
    assert card_number[0] == '4'
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[-1].isdigit()


# Generated at 2022-06-17 22:58:46.895736
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:58:51.109209
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 22:58:54.871198
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19


# Generated at 2022-06-17 22:59:04.547635
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 4983 9098 0982'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 91304'


# Generated at 2022-06-17 22:59:39.781759
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:59:43.575042
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'

# Generated at 2022-06-17 22:59:55.103591
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '


# Generated at 2022-06-17 22:59:58.357403
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[-1] == luhn_checksum(card_number[:-1])


# Generated at 2022-06-17 23:00:03.380741
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 23:00:14.135322
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    credit_card_number = payment.credit_card_number(card_type)
    assert len(credit_card_number) == 19
    assert credit_card_number[0] == '4'
    assert credit_card_number[1] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert credit_card_number[2] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert credit_card_number[3] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

# Generated at 2022-06-17 23:00:16.806820
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '


# Generated at 2022-06-17 23:00:23.152322
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 5892 7098'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 23:00:29.206916
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 23:00:32.979280
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))
