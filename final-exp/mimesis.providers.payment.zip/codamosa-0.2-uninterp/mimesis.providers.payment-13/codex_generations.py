

# Generated at 2022-06-17 22:55:38.282528
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '


# Generated at 2022-06-17 22:55:50.592621
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[-1] == '0'
    assert card_number[-2] == '0'
    assert card_number[-3] == '0'
    assert card_number[-4] == '0'
    assert card_number[-5] == '0'
    assert card_number[-6] == '0'
    assert card_number[-7] == '0'
    assert card_number[-8] == '0'
    assert card_number[-9] == '0'

# Generated at 2022-06-17 22:55:57.179382
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3454 5678'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number() == '4455 5299 1152 2450'

# Generated at 2022-06-17 22:56:05.389540
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 22:56:12.468962
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4554 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 22:56:20.752439
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7890'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 1111 1111 1117'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3056 9309 0259 04'
    assert payment.credit_card_number(CardType.JCB) == '3530 1113 3330 0000'

# Generated at 2022-06-17 22:56:25.631674
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '


# Generated at 2022-06-17 22:56:27.027304
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())


# Generated at 2022-06-17 22:56:34.370270
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[:1] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] == ' '
    assert card_number[-1] == luhn_checksum(card_number[:-1])
    card_type = CardType.MASTER_CARD
    card_number = payment.credit_card_number(card_type)
    assert card_number[:2] in ['22', '51']
    assert len(card_number) == 19

# Generated at 2022-06-17 22:56:37.473197
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '


# Generated at 2022-06-17 22:56:50.585625
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment.credit_card_number(CardType.VISA)
    payment.credit_card_number(CardType.MASTER_CARD)
    payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    try:
        payment.credit_card_number(CardType.DISCOVER)
    except NonEnumerableError:
        pass
    else:
        assert False

# Generated at 2022-06-17 22:56:57.909378
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 250'


# Generated at 2022-06-17 22:57:04.705372
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0891 8984 8094'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3714 4903 5398 431'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 8078 6092 5962'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3056 9309 0259 04'
    assert payment.credit_card_number(CardType.JCB) == '3530 1113 3330 0000'
    assert payment.credit_card_number

# Generated at 2022-06-17 22:57:09.173074
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:57:15.459552
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())
    assert re.match(r'\d{4} \d{6} \d{5}', payment.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-17 22:57:20.574813
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 4587'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 22:57:27.234923
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 6096 4981'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 22:57:34.072592
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == "4455 5299 1152 2450"
    assert payment.credit_card_number(CardType.MASTER_CARD) == "2221 5299 1152 2450"
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == "3400 5299 1152 250"


# Generated at 2022-06-17 22:57:38.158005
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19


# Generated at 2022-06-17 22:57:48.869543
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 1111 1111 1117'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3056 9309 0259 04'
    assert payment.credit_card_number(CardType.JCB) == '3530 1113 3330 0000'

# Generated at 2022-06-17 22:58:32.473887
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 2222 2222'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 1111 1111 1117'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3018 8888 8888 888'
    assert payment.credit_card_number(CardType.JCB) == '3566 1111 1111 1113'

# Generated at 2022-06-17 22:58:33.818181
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number()


# Generated at 2022-06-17 22:58:38.886162
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[1] == ' '
    assert card_number[5] == ' '
    assert card_number[9] == ' '
    assert card_number[13] == ' '


# Generated at 2022-06-17 22:58:45.157653
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 2545'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3745 623456 54567'


# Generated at 2022-06-17 22:58:49.854992
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[-1] == str(luhn_checksum(card_number[:-1]))


# Generated at 2022-06-17 22:58:52.897322
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'


# Generated at 2022-06-17 22:58:54.797297
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())

# Generated at 2022-06-17 22:59:04.502603
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 5891 0897'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:59:11.098599
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number(CardType.VISA))
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number(CardType.MASTER_CARD))
    assert re.match(r'\d{4} \d{6} \d{5}', payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 22:59:15.500517
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'


# Generated at 2022-06-17 22:59:55.103465
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0891 8097 7092'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:59:59.457132
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == "4455 5299 1152 2450"
    assert payment.credit_card_number(CardType.MASTER_CARD) == "5100 5299 1152 2450"
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == "3400 5299 1152 250"


# Generated at 2022-06-17 23:00:04.810188
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '


# Generated at 2022-06-17 23:00:11.964539
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 23:00:14.473620
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}',
                    payment.credit_card_number())

# Generated at 2022-06-17 23:00:24.702306
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 1111 1111 1117'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3600 1111 1111 115'
    assert payment.credit_card_number(CardType.JCB) == '3566 1111 1111 1113'

# Generated at 2022-06-17 23:00:33.350648
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[0:4] == '4455'
    assert card_number[5:9] == '5299'
    assert card_number[10:14] == '1152'
    assert card_number[15:19] == '2450'


# Generated at 2022-06-17 23:00:38.970775
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4556 9091 5981 9097'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 6094 6094 6094'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 23:00:41.457008
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match(r'^\d{4} \d{4} \d{4} \d{4}$', p.credit_card_number())


# Generated at 2022-06-17 23:00:45.240646
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() is not None
    assert payment.credit_card_number(CardType.VISA) is not None
    assert payment.credit_card_number(CardType.MASTER_CARD) is not None
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) is not None
