

# Generated at 2022-06-17 22:55:27.562518
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())


# Generated at 2022-06-17 22:55:29.576858
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())

# Generated at 2022-06-17 22:55:33.537837
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    number = payment.credit_card_number(card_type)
    assert number[0] == '4'
    assert len(number) == 19
    assert number[4] == ' '
    assert number[9] == ' '
    assert number[14] == ' '
    assert number[18] == ' '
    assert number[-1] == luhn_checksum(number[:-1])


# Generated at 2022-06-17 22:55:39.225653
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:55:41.449398
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())

# Generated at 2022-06-17 22:55:45.757411
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    assert payment.credit_card_number(card_type) == '4455 5299 1152 2450'

# Generated at 2022-06-17 22:55:47.588063
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'

# Generated at 2022-06-17 22:55:58.688405
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert card_number.count(' ') == 3
    assert len(card_number.replace(' ', '')) == 16
    assert card_number[0] == '4'
    assert card_number[0:2] in ['40', '41', '42', '43', '44', '45', '46', '47', '48', '49']

# Generated at 2022-06-17 22:56:05.539637
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:56:11.845651
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '


# Generated at 2022-06-17 22:56:21.710956
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    credit_card_number = payment.credit_card_number(card_type)
    assert credit_card_number[0] == '4'


# Generated at 2022-06-17 22:56:28.327008
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 22:56:33.646454
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[0] == '4'
    assert card_number[1] == '4'
    assert card_number[2] == '5'
    assert card_number[3] == '5'
    assert card_number[5] != '0'
    assert card_number[6] != '0'
    assert card_number[7] != '0'
    assert card_number[8] != '0'
    assert card_number[10] != '0'
    assert card

# Generated at 2022-06-17 22:56:40.237084
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:56:47.824946
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 22:56:53.670978
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 250'


# Generated at 2022-06-17 22:57:03.344580
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:57:10.575815
# Unit test for method credit_card_number of class Payment

# Generated at 2022-06-17 22:57:16.867040
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 22:57:19.366455
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'^\d{4} \d{4} \d{4} \d{4}$', payment.credit_card_number())

# Generated at 2022-06-17 22:57:36.295265
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number() == '4455 5299 1152 2450'
    assert p.credit_card_number(CardType.MASTER_CARD) == '5100 0247 9098 8093'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:57:42.561824
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'

# Generated at 2022-06-17 22:58:04.569455
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number.count(' ') == 3
    assert card_number[0] == '4'
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[-1].isdigit()
    assert card_number[-2].isdigit()
    assert card_number[-3].isdigit()
    assert card_number[-4].isdigit()
    assert card_number[-5].isdigit()
    assert card_number[-6].isdigit()
    assert card_number[-7].isdigit()

# Generated at 2022-06-17 22:58:07.302886
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())


# Generated at 2022-06-17 22:58:08.383844
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment.credit_card_number()

# Generated at 2022-06-17 22:58:12.021125
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 5678'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:58:17.704647
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 22:58:21.004352
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 0984 5894'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 22:58:32.375983
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert p.credit_card_number(CardType.MASTER_CARD) == '5100 0897 7098 6076'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert p.credit_card_number(CardType.DISCOVER) == '6011 5940 3184 3787'
    assert p.credit_card_number(CardType.DINERS_CLUB) == '3056 9309 0259 04'
    assert p.credit_card_number(CardType.JCB) == '3530 1113 3330 0000'

# Generated at 2022-06-17 22:58:35.308607
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19


# Generated at 2022-06-17 22:59:07.366035
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 1234 5678 9012'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'


# Generated at 2022-06-17 22:59:15.755712
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 4963 8056 8073'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:59:20.546079
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'

# Generated at 2022-06-17 22:59:24.882784
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 4354 0982'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 22:59:31.441017
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[-1] == luhn_checksum(card_number[:-1])

    card_number = payment.credit_card_number(CardType.MASTER_CARD)
    assert card_number[0] == '5'
    assert len(card_number) == 19
    assert card_number[-1] == luhn_checksum(card_number[:-1])

    card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert card_number[0] == '3'
    assert len(card_number) == 17
    assert card_

# Generated at 2022-06-17 22:59:38.310271
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    from mimesis.enums import CardType
    from mimesis.providers.payment import Payment
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'

# Generated at 2022-06-17 22:59:42.633098
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4556 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 250'


# Generated at 2022-06-17 22:59:55.103622
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:59:57.325832
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())

# Generated at 2022-06-17 23:00:04.810638
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number() == '4455 5299 1152 2450'
    assert p.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert p.credit_card_number(CardType.MASTER_CARD) == '5100 0897 6092 0982'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
