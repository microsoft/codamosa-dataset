

# Generated at 2022-06-17 22:55:29.306752
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19


# Generated at 2022-06-17 22:55:32.796818
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert p.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:55:35.005569
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())


# Generated at 2022-06-17 22:55:46.411970
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[-1] == luhn_checksum(card_number[:-1])
    card_number = payment.credit_card_number(CardType.MASTER_CARD)
    assert card_number[0] == '5'
    assert len(card_number) == 19
    assert card_number[-1] == luhn_checksum(card_number[:-1])
    card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert card_number[0] == '3'
    assert len(card_number) == 17
    assert card_

# Generated at 2022-06-17 22:55:57.730528
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment."""
    payment = Payment()
    assert re.match(r'^\d{4} \d{4} \d{4} \d{4}$', payment.credit_card_number())
    assert re.match(r'^\d{4} \d{4} \d{4} \d{4}$', payment.credit_card_number(CardType.VISA))
    assert re.match(r'^\d{4} \d{4} \d{4} \d{4}$', payment.credit_card_number(CardType.MASTER_CARD))

# Generated at 2022-06-17 22:56:02.665652
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[18] in string.digits


# Generated at 2022-06-17 22:56:09.446719
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 7098 9072'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 22:56:15.866072
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 22:56:17.401402
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number() != p.credit_card_number()

# Generated at 2022-06-17 22:56:23.637511
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 4455 5299'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3711 1111 1111 111'

# Generated at 2022-06-17 22:56:41.087124
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 245'


# Generated at 2022-06-17 22:56:49.169447
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == "4455 5299 1152 2450"
    assert payment.credit_card_number(CardType.MASTER_CARD) == "5100 5299 1152 2450"
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == "3400 5299 1152 245"


# Generated at 2022-06-17 22:56:53.930405
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number()
    assert payment.credit_card_number(CardType.VISA)
    assert payment.credit_card_number(CardType.MASTER_CARD)
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS)


# Generated at 2022-06-17 22:57:06.553666
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment."""
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert card_number.startswith('4')
    assert len(card_number) == 19
    card_number = payment.credit_card_number(CardType.MASTER_CARD)
    assert card_number.startswith('5')
    assert len(card_number) == 19
    card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert card_number.startswith('3')
    assert len(card_number) == 17

# Generated at 2022-06-17 22:57:18.540494
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 8073 6076 7097'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3711 7098 9056 707'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 4984 5984 8074'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3096 8079 9079 807'
    assert payment.credit_card_number(CardType.JCB) == '3530 8079 9079 807'
   

# Generated at 2022-06-17 22:57:27.193702
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[0:4] == '4455'
    assert card_number[5:9] == '5299'
    assert card_number[10:14] == '1152'
    assert card_number[15:19] == '2450'


# Generated at 2022-06-17 22:57:34.023262
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 22:57:40.571034
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 9071 0341'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 22:57:46.436505
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:58:04.568832
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[5] == ' '
    assert card_number[10] == ' '
    assert card_number[15] == ' '
    assert card_number[18] == ' '
    assert card_number[19] == ' '
    assert card_number[20] == ' '
    assert card_number[21] == ' '
    assert card_number[22] == ' '
    assert card_number[23] == ' '
    assert card_number[24] == ' '
    assert card_number[25] == ' '
    assert card_number[26] == ' '
    assert card_number[27] == ' '

# Generated at 2022-06-17 22:58:42.019292
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:58:47.117801
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'
