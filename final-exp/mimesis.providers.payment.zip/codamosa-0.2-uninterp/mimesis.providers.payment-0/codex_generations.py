

# Generated at 2022-06-17 22:55:35.756662
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:55:40.839335
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 22:55:42.944401
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())

# Generated at 2022-06-17 22:55:50.790757
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:55:56.072266
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'

# Generated at 2022-06-17 22:56:03.794887
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 4351 7078'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 8224 6310 005'

# Generated at 2022-06-17 22:56:10.161678
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] == ' '
    assert card_number[19] == '\n'
    assert card_number[20] == '\n'
    assert card_number[21] == '\n'
    assert card_number[22] == '\n'
    assert card_number[23] == '\n'
    assert card_number[24] == '\n'
    assert card_number[25] == '\n'

# Generated at 2022-06-17 22:56:15.784257
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0894 5123 9085'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:56:20.020151
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 22:56:24.284743
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    print(p.credit_card_number(CardType.VISA))
    print(p.credit_card_number(CardType.MASTER_CARD))
    print(p.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 22:56:43.577051
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] == ' '
    assert card_number[0:4] == '4455'
    assert card_number[5:9] == '5299'
    assert card_number[10:14] == '1152'
    assert card_number[15:19] == '2450'


# Generated at 2022-06-17 22:56:50.034706
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert p.credit_card_number(CardType.MASTER_CARD) == '2221 2720 2222 2222'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'

# Generated at 2022-06-17 22:56:56.589194
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 0894 5891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 22:57:07.973419
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[4:9] != card_number[9:14]
    assert card_number[9:14] != card_number[14:19]
    assert card_number[4:9] != card_number[14:19]


# Generated at 2022-06-17 22:57:15.266516
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'


# Generated at 2022-06-17 22:57:20.834379
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[0:4] in ['4000', '4999']


# Generated at 2022-06-17 22:57:27.492122
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17


# Generated at 2022-06-17 22:57:34.914578
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[18] == luhn_checksum(card_number[:-1])


# Generated at 2022-06-17 22:57:41.230964
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:58:04.568936
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] == ' '
    assert card_number[-1] == luhn_checksum(card_number[:-1])


# Generated at 2022-06-17 22:58:42.737249
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    assert len(credit_card_number) == 19
    assert credit_card_number[0:4] in ['4000', '4999']
    assert credit_card_number[5:9] in ['2221', '2720', '5100', '5599']
    assert credit_card_number[10:12] in ['34', '37']
    assert credit_card_number[13:15] in ['01', '12']
    assert credit_card_number[16:18] in ['16', '25']

# Generated at 2022-06-17 22:58:46.818370
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number()
    assert payment.credit_card_number(CardType.VISA)
    assert payment.credit_card_number(CardType.MASTER_CARD)
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS)

# Generated at 2022-06-17 22:58:53.237804
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert card_number is not None
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[-1].isdigit()
    assert card_number[-1] == luhn_checksum(card_number[:-1])


# Generated at 2022-06-17 22:59:01.554518
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:59:07.819443
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number(CardType.VISA)) == 19
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19


# Generated at 2022-06-17 22:59:15.146113
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17

# Generated at 2022-06-17 22:59:20.301626
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    assert len(credit_card_number) == 19
    assert credit_card_number[4] == ' '
    assert credit_card_number[9] == ' '
    assert credit_card_number[14] == ' '
    assert credit_card_number[-1] == luhn_checksum(credit_card_number[:-1])


# Generated at 2022-06-17 22:59:23.213686
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())


# Generated at 2022-06-17 22:59:28.212737
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 22:59:33.511479
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[-1] == luhn_checksum(card_number[:-1])