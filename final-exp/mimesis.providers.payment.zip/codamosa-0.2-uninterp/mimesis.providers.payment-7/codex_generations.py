

# Generated at 2022-06-17 22:55:28.048110
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '

# Generated at 2022-06-17 22:55:33.734265
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 8076 5270'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    try:
        payment.credit_card_number(CardType.DISCOVER)
    except NonEnumerableError:
        assert True
    else:
        assert False


# Generated at 2022-06-17 22:55:39.394645
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:55:51.737648
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] == ' '
    assert card_number[-1] == '0'
    assert card_number[-2] == '0'
    assert card_number[-3] == '0'
    assert card_number[-4] == '0'
    assert card_number[-5] == '0'
    assert card_number[-6] == '0'
    assert card_number[-7] == '0'
    assert card_number[-8]

# Generated at 2022-06-17 22:55:54.748521
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'

# Generated at 2022-06-17 22:56:03.435198
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4556 7892 5892 7072'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5155 5892 5892 7072'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3489 9892 5892 707'


# Generated at 2022-06-17 22:56:11.926675
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 245'


# Generated at 2022-06-17 22:56:20.374213
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 18
    assert len(payment.credit_card_number(CardType.VISA)) == 19
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.DISCOVER)) == 19
    assert len(payment.credit_card_number(CardType.DINERS_CLUB)) == 19
    assert len(payment.credit_card_number(CardType.JCB)) == 19
    assert len(payment.credit_card_number(CardType.UNIONPAY)) == 19


# Generated at 2022-06-17 22:56:25.632009
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 22:56:30.704378
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0892 6097 7077'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:56:40.237108
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[-1] == luhn_checksum(card_number[:-1])


# Generated at 2022-06-17 22:56:47.406837
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 245'


# Generated at 2022-06-17 22:56:57.906060
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert card_number is not None
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[5] == ' '
    assert card_number[9] == ' '
    assert card_number[13] == ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '

# Generated at 2022-06-17 22:56:59.875725
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'


# Generated at 2022-06-17 22:57:06.055403
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '

# Generated at 2022-06-17 22:57:11.333200
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 250'


# Generated at 2022-06-17 22:57:18.579519
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4556 6071 6097 7076'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5111 4254 8091 9098'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0963 9085 8'

# Generated at 2022-06-17 22:57:24.875106
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:57:32.227830
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 5299 1152 2450'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3600 5299 1152 2450'
    assert payment.credit_card_number(CardType.JCB) == '3566 5299 1152 2450'

# Generated at 2022-06-17 22:57:38.160169
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19


# Generated at 2022-06-17 22:58:02.246145
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'

# Generated at 2022-06-17 22:58:09.289788
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[1] == ' '
    assert card_number[5] == ' '
    assert card_number[9] == ' '
    assert card_number[13] == ' '
    assert card_number[17] == ' '


# Generated at 2022-06-17 22:58:12.851380
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[-1] == '0' or card_number[-1] == '5'


# Generated at 2022-06-17 22:58:19.383351
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'
    assert payment.credit_card_number() == '4455 5299 1152 2450'


# Generated at 2022-06-17 22:58:24.991704
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:58:26.725561
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for i in range(10):
        print(payment.credit_card_number())

# Generated at 2022-06-17 22:58:33.168475
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:58:35.384428
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:58:39.051038
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 22:58:48.696651
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    payment.credit_card_number()
    payment.credit_card_number(CardType.VISA)
    payment.credit_card_number(CardType.MASTER_CARD)
    payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    payment.credit_card_number(CardType.DISCOVER)
    payment.credit_card_number(CardType.DINERS_CLUB)
    payment.credit_card_number(CardType.JCB)
    payment.credit_card_number(CardType.UNIONPAY)
    payment.credit_card_number(CardType.MAESTRO)
    payment.credit_card_number(CardType.SWITCH)
    payment.credit_card_number(CardType.SOLO)
    payment.credit_card

# Generated at 2022-06-17 22:59:09.175054
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] == ' '
    assert card_number[19] == '\n'


# Generated at 2022-06-17 22:59:15.240864
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA).startswith('4')
    assert payment.credit_card_number(CardType.MASTER_CARD).startswith('5')
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS).startswith('3')


# Generated at 2022-06-17 22:59:18.102711
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:59:25.937290
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[1] == ' '
    assert card_number[5] == ' '
    assert card_number[9] == ' '
    assert card_number[13] == ' '
    assert card_number[17] == ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number

# Generated at 2022-06-17 22:59:29.958188
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0862 8095 6074'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 22:59:32.863185
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())

# Generated at 2022-06-17 22:59:38.564194
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 4455'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:59:41.935443
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 22:59:46.281030
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = payment.random.choice(list(CardType))
    card_number = payment.credit_card_number(card_type)
    assert card_number.count(' ') == 3
    assert len(card_number.replace(' ', '')) == 16

# Generated at 2022-06-17 22:59:55.103513
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 23:00:34.313767
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 5897 5897'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'


# Generated at 2022-06-17 23:00:38.493766
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19


# Generated at 2022-06-17 23:00:43.419773
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 8072 0654'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 23:00:49.388524
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 23:00:53.965628
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 23:00:59.155535
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0981 4896 6056'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 0981 4896 605'


# Generated at 2022-06-17 23:01:02.307318
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number())


# Generated at 2022-06-17 23:01:07.525796
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 6078 3232 7072'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 23:01:11.263421
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 23:01:17.632648
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    assert len(credit_card_number) == 19
    assert credit_card_number[0] == '4'
    assert credit_card_number[4] == ' '
    assert credit_card_number[9] == ' '
    assert credit_card_number[14] == ' '


# Generated at 2022-06-17 23:02:31.214618
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == "4455 5299 1152 2450"
    assert payment.credit_card_number(CardType.MASTER_CARD) == "5100 5299 1152 2450"
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == "3400 5299 1152 250"


# Generated at 2022-06-17 23:02:39.942903
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())
    assert re.match(r'\d{4} \d{6} \d{5}', payment.credit_card_number(CardType.AMERICAN_EXPRESS))
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number(CardType.MASTER_CARD))
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number(CardType.VISA))

# Unit test

# Generated at 2022-06-17 23:02:42.882998
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[-1] == luhn_checksum(card_number[:-1])


# Generated at 2022-06-17 23:02:47.896812
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 23:02:53.225117
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 23:02:58.028504
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number())
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number(CardType.VISA))
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number(CardType.MASTER_CARD))
    assert re.match(r'\d{4} \d{6} \d{5}', p.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 23:03:02.498902
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 16
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 15
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 16
    assert len(payment.credit_card_number(CardType.VISA)) == 16


# Generated at 2022-06-17 23:03:05.936230
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 6292 8079 9063'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 23:03:09.391111
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '

# Generated at 2022-06-17 23:03:12.467677
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert len(card_number) == 19
    assert card_number[0] == '4'
