

# Generated at 2022-06-17 22:55:36.452904
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0892 3456 7892'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number() == '4455 5299 1152 2450'

# Generated at 2022-06-17 22:55:41.776952
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 8092 5982 6092'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:55:53.433598
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number())
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number(CardType.VISA))
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number(CardType.MASTER_CARD))
    assert re.match(r'\d{4} \d{6} \d{5}', p.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-17 22:56:04.089449
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 5100 5599'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 1111 1111 1117'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3056 930902 5904'
    assert payment.credit_card_number(CardType.JCB) == '3530 1113 3330 0000'

# Generated at 2022-06-17 22:56:15.738929
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] == ' '
    assert card_number[5:9].isdigit()
    assert card_number[10:14].isdigit()
    assert card_number[15:18].isdigit()
    assert card_number[19].isdigit()
    assert luhn_checksum(card_number[:-1]) == card_number[-1]

    card_type = CardType.MAS

# Generated at 2022-06-17 22:56:19.987369
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7892'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:56:28.419941
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[0:4] == '4455'
    assert card_number[5:9] == '5299'
    assert card_number[10:14] == '1152'
    assert card_number[15:19] == '2450'


# Generated at 2022-06-17 22:56:32.461106
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 6094 4982 7098'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 22:56:36.325644
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number()) is not None

# Generated at 2022-06-17 22:56:43.403499
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    assert len(credit_card_number) == 19
    assert credit_card_number[0] == '4'
    assert credit_card_number[5] == ' '
    assert credit_card_number[9] == ' '
    assert credit_card_number[13] == ' '
    assert credit_card_number[17] == ' '
    assert credit_card_number[18] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']


# Generated at 2022-06-17 22:56:59.909885
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 4455 5299'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3711 1111 1111 115'


# Generated at 2022-06-17 22:57:06.732467
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 5698'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'


# Generated at 2022-06-17 22:57:15.770682
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() != payment.credit_card_number()
    assert payment.credit_card_number(CardType.VISA) != payment.credit_card_number(CardType.MASTER_CARD)
    assert payment.credit_card_number(CardType.VISA) != payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert payment.credit_card_number(CardType.MASTER_CARD) != payment.credit_card_number(CardType.AMERICAN_EXPRESS)


# Generated at 2022-06-17 22:57:17.309845
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())


# Generated at 2022-06-17 22:57:22.198601
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19


# Generated at 2022-06-17 22:57:31.722761
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Test for method credit_card_number of class Payment"""
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 0896 8098'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 0982 6096 8098'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3010 0990 3349 5898'
    assert payment.credit_card_number(CardType.JCB) == '3566 0020 2036 0498'


# Generated at 2022-06-17 22:57:37.531925
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 22:57:43.485507
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 22:58:04.568612
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 245'


# Generated at 2022-06-17 22:58:09.013966
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'

# Generated at 2022-06-17 22:58:33.169524
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[-1] == '0'
    assert card_number[-2] == '0'
    assert card_number[-3] == '0'
    assert card_number[-4] == '0'
    assert card_number[-5] == '0'
    assert card_number[-6] == '0'
    assert card_number[-7] == '0'
    assert card_number[-8] == '0'
    assert card_number[-9] == '0'

# Generated at 2022-06-17 22:58:38.262670
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 22:58:48.666904
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    assert len(credit_card_number) == 19
    assert credit_card_number[0] == '4'
    assert credit_card_number[1] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert credit_card_number[2] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert credit_card_number[3] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert credit_card_number[4] == ' '

# Generated at 2022-06-17 22:58:54.086702
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:59:00.710989
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 22:59:10.231426
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[:4] in ['4000', '4999']
    assert card_number[-1] == luhn_checksum(card_number[:-1])
    card_type = CardType.MASTER_CARD
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '5'
    assert len(card_number) == 19
    assert card_number[:2] in ['22', '27']
    assert card_number[-1] == luhn_checksum(card_number[:-1])

# Generated at 2022-06-17 22:59:16.680062
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '


# Generated at 2022-06-17 22:59:25.152863
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() != payment.credit_card_number()
    assert payment.credit_card_number(CardType.VISA) != payment.credit_card_number(CardType.MASTER_CARD)
    assert payment.credit_card_number(CardType.VISA) != payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert payment.credit_card_number(CardType.MASTER_CARD) != payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert payment.credit_card_number(CardType.VISA) != payment.credit_card_number(CardType.MASTER_CARD)

# Generated at 2022-06-17 22:59:29.958193
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 245'


# Generated at 2022-06-17 22:59:36.717706
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 7077 6095'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 23:00:08.267101
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 6094 4984 6094'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 23:00:11.846483
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    assert payment.credit_card_number(card_type) == '4455 5299 1152 2450'

# Generated at 2022-06-17 23:00:15.692056
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0894 5209 0984'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 23:00:23.913971
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[0:4] == '4455'
    assert card_number[5:9] == '5299'
    assert card_number[10:14] == '1152'
    assert card_number[15:19] == '2450'


# Generated at 2022-06-17 23:00:34.613019
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 0982 5981 9077'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 0982 5981 9077'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3056 9382 5981 9077'
    assert payment.credit_card_number(CardType.JCB) == '3530 0982 5981 9077'
    assert payment

# Generated at 2022-06-17 23:00:38.746166
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19


# Generated at 2022-06-17 23:00:43.931317
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0892 5892 7072'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 23:00:49.968885
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19


# Generated at 2022-06-17 23:00:54.538245
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19


# Generated at 2022-06-17 23:01:02.897029
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[0:4] == '4455'
    assert card_number[5:9] == '5299'
    assert card_number[10:14] == '1152'
    assert card_number[15:19] == '2450'


# Generated at 2022-06-17 23:01:47.135536
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 4981 5578 6092'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 23:01:50.476914
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 7098 5149 5981'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 23:01:57.854590
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[-1] == luhn_checksum(card_number[:-1])


# Generated at 2022-06-17 23:02:05.716657
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert card_number.count(' ') == 3
    assert len(card_number.replace(' ', '')) == 16
    assert card_number.startswith('4')
    card_number = payment.credit_card_number(CardType.MASTER_CARD)
    assert card_number.count(' ') == 3
    assert len(card_number.replace(' ', '')) == 16
    assert card_number.startswith('5')
    card_number = payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert card_number.count(' ') == 2
    assert len(card_number.replace(' ', '')) == 15
    assert card_number.startswith('3')
    card_number = payment

# Generated at 2022-06-17 23:02:11.708019
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[18] == luhn_checksum(card_number[0:18])


# Generated at 2022-06-17 23:02:14.535340
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 23:02:21.460932
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[1] == ' '
    assert card_number[5] == ' '
    assert card_number[9] == ' '
    assert card_number[13] == ' '
    assert card_number[17] == ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number[18] != ' '
    assert card_number

# Generated at 2022-06-17 23:02:25.485175
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 23:02:30.624844
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 11524 50'


# Generated at 2022-06-17 23:02:36.564846
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 5678'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 1111 1111 1117'


# Generated at 2022-06-17 23:03:56.097679
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 23:03:58.924063
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'


# Generated at 2022-06-17 23:04:01.536511
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 23:04:04.400985
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 16
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 15
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 16
    assert len(payment.credit_card_number(CardType.VISA)) == 16
    assert len(payment.credit_card_number(CardType.DISCOVER)) == 16


# Generated at 2022-06-17 23:04:07.201605
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '


# Generated at 2022-06-17 23:04:14.749080
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 23:04:18.167271
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19


# Generated at 2022-06-17 23:04:22.769618
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 23:04:27.609030
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[1] == ' '
    assert card_number[5] == ' '
    assert card_number[9] == ' '
    assert card_number[13] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 23:04:30.159590
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[-1] == luhn_checksum(card_number[:-1])