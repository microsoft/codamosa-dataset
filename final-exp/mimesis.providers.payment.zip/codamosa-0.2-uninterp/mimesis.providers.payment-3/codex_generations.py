

# Generated at 2022-06-17 22:55:39.174447
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    # Create an object of class Payment
    payment = Payment()
    # Generate a random credit card number
    credit_card_number = payment.credit_card_number()
    # Check if the credit card number is valid
    assert luhn_checksum(credit_card_number.replace(' ', '')) == 0


# Generated at 2022-06-17 22:55:46.259059
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 8092 8092'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:55:51.336487
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '


# Generated at 2022-06-17 22:56:00.160090
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7894'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:56:07.338284
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[18] in string.digits


# Generated at 2022-06-17 22:56:13.882347
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'

# Generated at 2022-06-17 22:56:18.469235
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7892'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:56:25.507230
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3445 5299 1152 245'


# Generated at 2022-06-17 22:56:30.293605
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:56:41.875800
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA)
    assert payment.credit_card_number(CardType.MASTER_CARD)
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert payment.credit_card_number()
    assert payment.credit_card_number(CardType.VISA)
    assert payment.credit_card_number(CardType.MASTER_CARD)
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS)
    assert payment.credit_card_number()
    assert payment.credit_card_number(CardType.VISA)
    assert payment.credit_card_number(CardType.MASTER_CARD)

# Generated at 2022-06-17 22:56:56.642009
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17


# Generated at 2022-06-17 22:57:05.334835
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:57:16.967318
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 4555 5299'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3711 1111 1111 115'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 1111 1111 1117'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3011 1111 1111 113'
    assert payment.credit_card_number(CardType.JCB) == '2131 1111 1111 1113'

# Generated at 2022-06-17 22:57:19.834359
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match(r'^\d{4} \d{4} \d{4} \d{4}$', p.credit_card_number())


# Generated at 2022-06-17 22:57:22.648587
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'


# Generated at 2022-06-17 22:57:28.365628
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 22:57:36.600772
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3451 4455'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'
    assert payment.credit_card_number() == '4455 5299 1152 2450'


# Generated at 2022-06-17 22:57:42.880892
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:57:48.345548
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:58:04.569236
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    credit_card_number = payment.credit_card_number(card_type)
    assert credit_card_number[0] == '4'
    assert len(credit_card_number) == 19
    assert credit_card_number[-1] == luhn_checksum(credit_card_number[:-1])
    card_type = CardType.MASTER_CARD
    credit_card_number = payment.credit_card_number(card_type)
    assert credit_card_number[0] == '5'
    assert len(credit_card_number) == 19
    assert credit_card_number[-1] == luhn_checksum(credit_card_number[:-1])
    card_type = CardType.AMERICAN_EXPRESS

# Generated at 2022-06-17 22:58:38.801322
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'

# Generated at 2022-06-17 22:58:45.157385
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:58:50.929958
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 8098 8097'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:58:56.052258
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:59:01.266414
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19


# Generated at 2022-06-17 22:59:08.486147
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0894 9074 3452'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number() == '4455 5299 1152 2450'


# Generated at 2022-06-17 22:59:15.540583
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())
    assert re.match(r'\d{4} \d{6} \d{5}', payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 22:59:20.338115
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:59:23.769085
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    # Create an instance of class Payment
    payment = Payment()
    # Generate a random credit card number
    credit_card_number = payment.credit_card_number()
    # Check if the generated credit card number is valid
    assert luhn_checksum(credit_card_number) == 0

# Generated at 2022-06-17 22:59:29.958593
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 23:00:30.430183
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17


# Generated at 2022-06-17 23:00:34.460480
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 6098 9053 3386'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 7058 9982 543'
    assert payment.credit_card_number() == '4455 5299 1152 2450'


# Generated at 2022-06-17 23:00:39.510838
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 245'


# Generated at 2022-06-17 23:00:44.643664
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 23:00:49.241152
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17


# Generated at 2022-06-17 23:00:55.722711
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[0:4] == '4455'
    assert card_number[5:9] == '5299'
    assert card_number[10:14] == '1152'
    assert card_number[15:19] == '2450'


# Generated at 2022-06-17 23:01:06.517315
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert card_number[1] == '4'
    assert card_number[2] == '4'
    assert card_number[3] == '5'
    assert card_number[4] == ' '
    assert card_number[5] == '5'
    assert card_number[6] == '2'
    assert card_number[7] == '9'
    assert card_number[8] == '9'
    assert card_number[9] == ' '
    assert card_number[10] == '1'
    assert card_number[11] == '1'

# Generated at 2022-06-17 23:01:11.046590
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 23:01:13.460841
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    for i in range(10):
        print(payment.credit_card_number())


# Generated at 2022-06-17 23:01:18.881379
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
