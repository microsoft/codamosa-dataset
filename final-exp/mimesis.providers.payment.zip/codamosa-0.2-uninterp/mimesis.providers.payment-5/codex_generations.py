

# Generated at 2022-06-17 22:55:34.113686
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_type.value in card_number
    assert len(card_number) == 19
    assert ' ' in card_number
    assert card_number[0:4].isdigit()
    assert card_number[5:9].isdigit()
    assert card_number[10:14].isdigit()
    assert card_number[15:19].isdigit()


# Generated at 2022-06-17 22:55:43.171135
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment"""
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    assert len(credit_card_number) == 19
    assert credit_card_number[4] == ' '
    assert credit_card_number[9] == ' '
    assert credit_card_number[14] == ' '
    assert credit_card_number[0:4] == '4455'
    assert credit_card_number[5:9] == '5299'
    assert credit_card_number[10:14] == '1152'
    assert credit_card_number[15:19] == '2450'


# Generated at 2022-06-17 22:55:51.655600
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 22:56:00.160088
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:56:12.185132
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 4983 5983'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 5940 3184 3187'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3018 8982 7349 598'
    assert payment.credit_card_number(CardType.JCB) == '3530 1113 3330 0000'

# Generated at 2022-06-17 22:56:17.041515
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '


# Generated at 2022-06-17 22:56:23.492738
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 9073 5981'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 22:56:26.930739
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())

# Generated at 2022-06-17 22:56:31.351373
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:56:42.586643
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 7074 5984'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 8923 5687 0963'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3056 9383 3387 0'
    assert payment.credit_card_number(CardType.JCB) == '3530 1113 3330 0000'

# Generated at 2022-06-17 22:56:51.503220
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 22:56:56.242466
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:57:05.068107
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 22:57:10.171143
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'


# Generated at 2022-06-17 22:57:16.867527
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[-1] == luhn_checksum(card_number[:-1])


# Generated at 2022-06-17 22:57:21.933083
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19


# Generated at 2022-06-17 22:57:31.570491
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 5299 1152 2450'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3600 5299 1152 2450'
    assert payment.credit_card_number(CardType.JCB) == '3528 5299 1152 2450'

# Generated at 2022-06-17 22:57:37.386741
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == "4455 5299 1152 2450"
    assert payment.credit_card_number(CardType.MASTER_CARD) == "5100 5299 1152 2450"
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == "3400 5299 1152 250"


# Generated at 2022-06-17 22:57:39.647853
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())
    print(payment.credit_card_number(CardType.MASTER_CARD))
    print(payment.credit_card_number(CardType.AMERICAN_EXPRESS))


# Generated at 2022-06-17 22:58:04.568828
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    credit_card_number = payment.credit_card_number()
    assert len(credit_card_number) == 19
    assert credit_card_number[0] == '4'
    assert credit_card_number[1] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert credit_card_number[2] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert credit_card_number[3] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    assert credit_card_

# Generated at 2022-06-17 22:58:20.289713
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'


# Generated at 2022-06-17 22:58:25.873795
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 4567'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 22:58:32.138786
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 245'

# Generated at 2022-06-17 22:58:34.219290
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'


# Generated at 2022-06-17 22:58:42.116837
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 4452 5552'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 5940 3184 3687'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3018 8076 6098 043'
    assert payment.credit_card_number(CardType.JCB) == '3530 1113 3330 0000'

# Generated at 2022-06-17 22:58:47.180399
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 6098 4982 9056'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'

# Generated at 2022-06-17 22:58:49.212915
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())


# Generated at 2022-06-17 22:58:59.802856
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0894 7894 5894'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 5940 3184 3188'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3056 9309 0259 04'
    assert payment.credit_card_number(CardType.JCB) == '3530 1113 3330 0000'

# Generated at 2022-06-17 22:59:07.114774
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3700 5299 1152 250'


# Generated at 2022-06-17 22:59:15.412732
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:59:38.108681
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 19
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 17
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 19
    assert len(payment.credit_card_number(CardType.VISA)) == 19


# Generated at 2022-06-17 22:59:42.379861
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'


# Generated at 2022-06-17 22:59:43.435794
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())


# Generated at 2022-06-17 22:59:46.288796
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() != payment.credit_card_number()


# Generated at 2022-06-17 22:59:55.103634
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[0:4] == '4455'
    assert card_number[5:9] == '5299'
    assert card_number[10:14] == '1152'
    assert card_number[15:19] == '2450'


# Generated at 2022-06-17 22:59:58.356527
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'


# Generated at 2022-06-17 23:00:04.810181
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert p.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert p.credit_card_number(CardType.MASTER_CARD) == '2221 5299 1152 2450'
    assert p.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'

# Generated at 2022-06-17 23:00:15.203847
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0897 9072 5892'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 5940 3184 3187'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3056 9383 8078 30'
    assert payment.credit_card_number(CardType.JCB) == '3530 1113 3330 0000'
    assert payment.credit_card_number(CardType.VOYAGER)

# Generated at 2022-06-17 23:00:22.562923
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 6054 4897 0892'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 23:00:27.187366
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    """Unit test for method credit_card_number of class Payment."""
    payment = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number())
    assert re.match(r'\d{4} \d{6} \d{5}', payment.credit_card_number(CardType.AMERICAN_EXPRESS))
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number(CardType.MASTER_CARD))
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', payment.credit_card_number(CardType.VISA))

# Unit test

# Generated at 2022-06-17 23:01:07.279886
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 23:01:11.507839
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[-1] == luhn_checksum(card_number[:-1])


# Generated at 2022-06-17 23:01:20.996965
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] == ' '
    assert card_number[19] == ' '
    assert card_number[20] == ' '
    assert card_number[21] == ' '
    assert card_number[22] == ' '
    assert card_number[23] == ' '
    assert card_number[24] == ' '
    assert card_number[25] == ' '
    assert card_number[26] == ' '
    assert card_number[27] == ' '

# Generated at 2022-06-17 23:01:27.214168
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 0894 5563 6095'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 23:01:35.618033
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '
    assert card_number[0:4] == '4455'
    assert card_number[5:9] == '5299'
    assert card_number[10:14] == '1152'
    assert card_number[15:19] == '2450'


# Generated at 2022-06-17 23:01:41.706152
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number()
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 23:01:49.800548
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    p = Payment()
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number())
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number(CardType.VISA))
    assert re.match(r'\d{4} \d{4} \d{4} \d{4}', p.credit_card_number(CardType.MASTER_CARD))
    assert re.match(r'\d{4} \d{6} \d{5}', p.credit_card_number(CardType.AMERICAN_EXPRESS))

# Generated at 2022-06-17 23:02:00.344975
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 250'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 5299 1152 2450'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3096 5299 1152 2450'
    assert payment.credit_card_number(CardType.JCB) == '3530 5299 1152 2450'

# Generated at 2022-06-17 23:02:09.494402
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 5678'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'
    assert payment.credit_card_number(CardType.DISCOVER) == '6011 1111 1111 1117'
    assert payment.credit_card_number(CardType.DINERS_CLUB) == '3000 0000 0000 04'
    assert payment.credit_card_number(CardType.JCB) == '3530 1113 3330 0000'

# Generated at 2022-06-17 23:02:12.159972
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert len(payment.credit_card_number()) == 16
    assert len(payment.credit_card_number(CardType.AMERICAN_EXPRESS)) == 15
    assert len(payment.credit_card_number(CardType.VISA)) == 16
    assert len(payment.credit_card_number(CardType.MASTER_CARD)) == 16


# Generated at 2022-06-17 23:03:19.918646
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[0] == '4'
    assert len(card_number) == 19


# Generated at 2022-06-17 23:03:29.938773
# Unit test for method credit_card_number of class Payment

# Generated at 2022-06-17 23:03:36.778850
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert len(card_number) == 19
    assert card_number[0] == '4'
    assert card_number[1] == ' '
    assert card_number[5] == ' '
    assert card_number[9] == ' '
    assert card_number[13] == ' '
    assert card_number[17] == ' '
    assert card_number[18] != ' '


# Generated at 2022-06-17 23:03:41.063405
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 0000 0000 009'
    assert payment.credit_card_number() == '4455 5299 1152 2450'


# Generated at 2022-06-17 23:03:45.996863
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_number = payment.credit_card_number(CardType.VISA)
    assert card_number[0] == '4'
    assert len(card_number) == 19
    assert card_number[4] == ' '
    assert card_number[9] == ' '
    assert card_number[14] == ' '
    assert card_number[18] == ' '
    assert card_number[-1] == '0'
    assert card_number[-2] == '0'
    assert card_number[-3] == '0'
    assert card_number[-4] == '0'
    assert card_number[-5] == '0'
    assert card_number[-6] == '0'
    assert card_number[-7] == '0'
    assert card

# Generated at 2022-06-17 23:03:46.868463
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    print(payment.credit_card_number())


# Generated at 2022-06-17 23:03:52.189880
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    card_type = CardType.VISA
    card_number = payment.credit_card_number(card_type)
    assert card_number[:1] == '4'
    assert len(card_number) == 19
    assert card_number[-1:] == '0'
    assert card_number[-2:] == '10'
    assert card_number[-3:] == '010'
    assert card_number[-4:] == '1010'
    assert card_number[-5:] == '01010'
    assert card_number[-6:] == '101010'
    assert card_number[-7:] == '0101010'
    assert card_number[-8:] == '10101010'
    assert card_number[-9:] == '010101010'
    assert card

# Generated at 2022-06-17 23:03:54.987481
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 2720 3456 7891'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 23:03:58.764746
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number(CardType.VISA) == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '2221 6092 7092 4862'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3782 822463 10005'


# Generated at 2022-06-17 23:04:01.157667
# Unit test for method credit_card_number of class Payment
def test_Payment_credit_card_number():
    payment = Payment()
    assert payment.credit_card_number() == '4455 5299 1152 2450'
    assert payment.credit_card_number(CardType.MASTER_CARD) == '5100 5299 1152 2450'
    assert payment.credit_card_number(CardType.AMERICAN_EXPRESS) == '3400 5299 1152 245'