

# Generated at 2022-06-21 23:25:15.814266
# Unit test for function raw
def test_raw():
    raw("this is a byte string")
    raw(b"this is a byte string")
    raw(None)
    # Bad type passed in
    try:
        raw(1)
    except:
        pass
    # Content type not passed in - default should be used
    resp = raw(None)
    assert resp.content_type == "application/octet-stream"
    # Content type passed in - should be used
    resp = raw(None,content_type='text/html')
    assert resp.content_type == "text/html"



# Generated at 2022-06-21 23:25:27.714850
# Unit test for function html
def test_html():
    from sanic import Sanic
    from sanic.response import html, text
    
    app = Sanic()
    
    @app.route("/")
    async def handler(request):
        if request.args.get("mode") == "html":
            return html("<html><body>foo</body></html>")
        else:
            return text("foo")
    
    request, response = app.test_client.get("/")
    assert response.text == "foo"
    
    request, response = app.test_client.get("/?mode=html")
    assert response.text == "<html><body>foo</body></html>"



# Generated at 2022-06-21 23:25:33.763213
# Unit test for function json
def test_json():
    data = {}
    data["data"] = "success"
    data["reason"] = "ok"
    response = json(data)
    assert response.stream.send is None
    assert response.body == b'{"data": "success", "reason": "ok"}'
    assert response.content_type == "application/json"
    assert response.status == 200
    assert response.headers == {}


# Generated at 2022-06-21 23:25:38.839535
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    class Mock:
        def __init__(self):
            self.asgi = False

        def send(self, data, end_stream=None):
            pass

    mock = Mock()
    # test no arguments
    response = StreamingHTTPResponse(streaming_fn=None, status=200, headers=None, content_type='text/plain; charset=utf-8', chunked='deprecated')
    assert response.status == 200
    assert response._cookies == None
    response.stream = mock
    response.send()



# Generated at 2022-06-21 23:25:40.474204
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_fn = lambda response: response.stream.send(b"data")
    r = StreamingHTTPResponse(streaming_fn)
    r.stream = Http()
    asyncio.run(r.send())



# Generated at 2022-06-21 23:25:52.792642
# Unit test for function file_stream
def test_file_stream():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import SanicException
    from sanic.app import Sanic
    from sanic.response import file_stream
    import sanic
    import tempfile
    import os
    import inspect
    import types
    import unittest
    class TestSanicResponse(unittest.TestCase):
        def test_file_stream(self):
            app = Sanic("test_file_stream")
            @app.route("/asdf")
            async def asdf(request):
                return await file_stream('test_response.py',status=200)
            request, response = app.test_client.get('/asdf')
            self.assertEqual(response.status, 200)

# Generated at 2022-06-21 23:25:59.230898
# Unit test for constructor of class BaseHTTPResponse
def test_BaseHTTPResponse():
    response = BaseHTTPResponse()
    assert isinstance(response.headers, Header)
    assert not isinstance(response.headers, dict)
    assert response.cookies is None

    response = BaseHTTPResponse()
    assert isinstance(response.cookies, CookieJar)
    assert not isinstance(response.cookies, dict)
    assert isinstance(response.headers, Header)
    assert not isinstance(response.headers, dict)



# Generated at 2022-06-21 23:26:05.393556
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    returned_value = None
    def sample_streaming_fn(response):
        assert response is not None
    returned_value = StreamingHTTPResponse(sample_streaming_fn).send()
    assert returned_value is None

# Generated at 2022-06-21 23:26:11.686562
# Unit test for function stream
def test_stream():
    def test():
        async def sample_streaming_fn(response):
            await response.write("foo")
            await asyncio.sleep(1)
            await response.write("bar")
            await asyncio.sleep(1)

        async def asy():
            return stream(sample_streaming_fn)

        a=asy()
        for i in range(10):
            print(i)
            a.send("a")
        a.close()

    test()

# Generated at 2022-06-21 23:26:21.599201
# Unit test for function text
def test_text():
     body="Bonjour"
     content_type="text/plain; charset=utf-8"
     response = HTTPResponse(body, status=200, headers=None, content_type=content_type)
     body_text = response.body
     body_decode = str(body_text, 'utf-8')
     assert body_decode=='Bonjour'
     assert response.content_type=='text/plain; charset=utf-8'
#
#

# Generated at 2022-06-21 23:26:38.860359
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    h = HTTPResponse("1")
    assert(h.body == b"1")
    assert(h.headers == Header({}))
    assert(h.status == 200)
    assert(h.content_type is None)
    assert(h._cookies is None)

    h = HTTPResponse("1", status=201)
    assert(h.body == b"1")
    assert(h.headers == Header({}))
    assert(h.status == 201)
    assert(h.content_type is None)
    assert(h._cookies is None)

    h = HTTPResponse("1", headers={"a": "b"})
    assert(h.body == b"1")
    assert(h.headers == Header({"a": "b"}))

# Generated at 2022-06-21 23:26:46.923305
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    """
    Test StreamingHTTPResponse.write
    """
    from unittest import TestCase

    from unittest.mock import Mock

    from sanic.response import StreamingHTTPResponse

    class TestStreamingHTTPResponseWrite(TestCase):
        def test_StreamingHTTPResponse_write_instance(self):
            streaming_http_response = StreamingHTTPResponse(
                streaming_fn=Mock()
            )
            self.assertIsInstance(
                streaming_http_response, StreamingHTTPResponse
            )

    test = TestStreamingHTTPResponseWrite()
    test.test_StreamingHTTPResponse_write_instance()



# Generated at 2022-06-21 23:26:53.176081
# Unit test for function json
def test_json():
    d = {'name':'uestc','pwd':'uestc','age':24}
    a = json(d)
    assert a.body == b'{"age": 24, "name": "uestc", "pwd": "uestc"}'
test_json()


# Generated at 2022-06-21 23:27:00.786119
# Unit test for function raw
def test_raw():
    def raise_exception_type():
        raw("Test", 200, {}, "test/plain; charset=utf-8")
    def raise_exception_headers():
        raw("Test", 200, {}, "test/plain; charset=utf-8")
    def raise_exception_content_type():
        raw("Test", 200, {}, "test/plain; charset=utf-8")
    assert raw("Test", 200, {}, "text/plain; charset=utf-8") == HTTPResponse("Test", 200, {}, "text/plain; charset=utf-8")
    pytest.raises(TypeError, raise_exception_type())
    pytest.raises(TypeError, raise_exception_headers())

# Generated at 2022-06-21 23:27:11.388890
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from time import sleep
    from urllib.request import urlopen
    from uuid import uuid4
    from websocket import create_connection, WebSocket

    async def handler(request):
        ws = WebSocketResponse()
        await ws.prepare(request)
        ws.send(123)
        return ws

    async def request_handler(request):
        return HTTPResponse(status=200)

    app = Sanic("test_BaseHTTPResponse_send")
    app.websocket_handlers["/test"] = handler
    app.add_route(request_handler, "/")

    server = app.create_server

# Generated at 2022-06-21 23:27:19.418065
# Unit test for function html
def test_html():
    a = html("<body></body>")
    assert a.content_type == "text/html; charset=utf-8"
    assert a.body == "<body></body>"
    a = html("<body>", status=200, headers=None)
    assert a.content_type == "text/html; charset=utf-8"
    assert a.body == "<body>"
    assert a.status == 200
    a = html(b"<body>")
    assert a.content_type == "text/html; charset=utf-8"
    assert a.body == b"<body>"



# Generated at 2022-06-21 23:27:30.797180
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    test_BaseHTTPResponse = BaseHTTPResponse()
    test_BaseHTTPResponse.asgi = True
    test_BaseHTTPResponse.body = b'\xba\xa2\x8aR\x12\x0bH\x8a\xe4\x88\x05\x0e\x0b\x03\x04'
    test_BaseHTTPResponse.content_type = 'application/json'
    test_BaseHTTPResponse.stream = Http()
    test_BaseHTTPResponse.status = 200
    test_BaseHTTPResponse.headers = {'Server': 'sanic', 'Connection': 'keep-alive'}
    data = 'test'
    end_stream = True
    test_BaseHTTPResponse

# Generated at 2022-06-21 23:27:33.198498
# Unit test for function json
def test_json():
    assert json({"a": 1}).body == b'{"a":1}'
    assert json({1}, default=str).body == b'{1}'


# Generated at 2022-06-21 23:27:42.060536
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    async def test(request):
        return stream(sample_streaming_fn)

    from sanic.app import Sanic
    app = Sanic(__name__)
    app.add_route(test, "/", methods=["GET"])

    _, response = app.test_client.get("/")
    assert response.status == 200
    assert response.body == b"foobar"


# Generated at 2022-06-21 23:27:47.438584
# Unit test for constructor of class BaseHTTPResponse
def test_BaseHTTPResponse():
    rh = BaseHTTPResponse()
    assert rh.asgi == False
    assert rh.body == None
    assert rh.content_type == None
    assert rh.stream == None
    assert rh.status == None
    assert rh.headers == Header({})
    assert rh._cookies == None
    assert rh.cookies == None
    assert [(name, f"{value}".encode(errors='surrogateescape')) for name, value in rh.headers.items()] == []


# Generated at 2022-06-21 23:28:08.347674
# Unit test for function html
def test_html():
    def html_func():
        return '<p> test </p>'

    class HTMLClass:
        def __html__(self):
            return html_func()

    ht = HTMLClass()
    assert html(ht).body == html_func().encode()
    assert html(html_func()).body == html_func().encode()



# Generated at 2022-06-21 23:28:19.354977
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    app = Sanic("test_BaseHTTPResponse_send")
    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response._encode_body("a") == b"a"
    assert response.processed_headers == (("content-type", b"text/html; charset=utf-8"),)
    assert response.cookies == CookieJar(response.headers)
    assert response.send(data="a")
    assert response.send(data=None)
    assert response.send(data="a", end_stream=True)
    assert response.send(end_stream=True) == None

# Generated at 2022-06-21 23:28:21.209059
# Unit test for function html
def test_html():
    response = html("<a href='https://localhost/index.html'>index</a>")
    assert response.headers["content-type"] == "text/html; charset=utf-8"



# Generated at 2022-06-21 23:28:25.538281
# Unit test for constructor of class BaseHTTPResponse
def test_BaseHTTPResponse():
    """
    This function is intended to test the constructor of
    class BaseHTTPResponse.
    """
    try:
        from ujson import dumps as json_dumps
    except ImportError:
        # This is done in order to ensure that the JSON response is
        # kept consistent across both ujson and inbuilt json usage.
        from json import dumps

        json_dumps = partial(dumps, separators=(",", ":"))
    class BaseHTTPResponse:
        """
        The base class for all HTTP Responses
        """

        _dumps = json_dumps

        def __init__(self):
            self.asgi: bool = False
            self.body: Optional[bytes] = None
            self.content_type: Optional[str] = None
            self.stream: Http = None

# Generated at 2022-06-21 23:28:28.668092
# Unit test for function stream
def test_stream():
    def streaming_fn(response):
        await response.write("foo")
        await response.write("bar")
    assert stream(streaming_fn, status=200, content_type="text/plain") is not None


# Generated at 2022-06-21 23:28:40.353290
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.exceptions import InvalidUsage
    from sanic.streams import StreamProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol

    response = BaseHTTPResponse()
    stream = StreamProtocol(HOST, PORT)
    response.stream = stream
    response.send("Hello, test!")
    if stream.send is None:
        assert False

    stream.send = None
    response.send("Hello", True)
    if stream.send is not None:
        assert False

    # Test for exception
    stream.send = None
    response.send("Hello")
    if stream.send is not None:
        assert False

    stream.send = None
    response.send("Hello", False)

# Generated at 2022-06-21 23:28:41.966592
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    StreamingHTTPResponse()



# Generated at 2022-06-21 23:28:51.151364
# Unit test for function redirect
def test_redirect():
    response1 = redirect("/path", status=301)
    assert response1.status == 301
    assert response1.headers["Location"] == "/path"
    assert response1.content_type == "text/html; charset=utf-8"

    response2 = redirect("http://www.google.com")
    assert response2.status == 302
    assert response2.headers["Location"] == "http://www.google.com"
    assert response2.content_type == "text/html; charset=utf-8"

    response3 = redirect("http://www.google.com", status=307)
    assert response3.status == 307
    assert response3.headers["Location"] == "http://www.google.com"
    assert response3.content_type == "text/html; charset=utf-8"


# Generated at 2022-06-21 23:28:55.434910
# Unit test for function text
def test_text():
    response = text("Test", 200, None, "text/plain; charset=utf-8")
    assert type(response) == HTTPResponse


# Generated at 2022-06-21 23:29:03.110029
# Unit test for function stream
def test_stream():
    assert stream(None, None, None, None, None).status == 200
    assert stream(None, None, None, None, None).headers == {}
    assert stream(None, None, None, None, None).content_type == 'text/plain; charset=utf-8'
    assert isinstance(stream(None, None, None, None, None), StreamingHTTPResponse)


# Generated at 2022-06-21 23:29:43.000643
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():

    from .test_server import _test_route

    @_test_route("test_base_http_response")
    async def _(request):
        response = BaseHTTPResponse()
        response.content_type = "application/json"
        response.body = '{"test": "It worked!"}'
        return response

    app = Sanic("test_BaseHTTPResponse_send")
    app.add_route(_, "/test_base_http_response")

    request, response = app.test_client.get("/test_base_http_response")
    assert response.json == {"test": "It worked!"}



# Generated at 2022-06-21 23:29:44.947776
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    StreamingHTTPResponse(None)



# Generated at 2022-06-21 23:29:47.341209
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    import asyncio
    from sanic import Sanic
    from sanic.response import StreamingHTTPResponse

    app = Sanic()

    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    def test(request):
        return StreamingHTTPResponse(sample_streaming_fn)



# Generated at 2022-06-21 23:29:51.229715
# Unit test for constructor of class BaseHTTPResponse
def test_BaseHTTPResponse():
    response = BaseHTTPResponse()
    assert response.asgi is False
    assert response.body is None
    assert response.content_type is None
    assert response.stream is None
    assert response.status is None
    assert response.headers == Header({})
    assert response._cookies is None


# Generated at 2022-06-21 23:29:52.389913
# Unit test for function html
def test_html():
    body = "<p>Hello World!</p>"
    assert html(body)



# Generated at 2022-06-21 23:29:58.949901
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
  obj = StreamingHTTPResponse(arg0, arg1, arg2, arg3, arg4)
  try:
    obj.send()
    raise RuntimeError("Expected exception did not occur")
  except NotImplementedError:
    pass
  except:
    raise RuntimeError("Unexpected exception occurred")


# Generated at 2022-06-21 23:30:01.238416
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # this method is a coroutine, so we can not directly test it at this class.
    pass

    pass



# Generated at 2022-06-21 23:30:08.954823
# Unit test for function json
def test_json():
    # status, headers, content_type,body
    a = json('{}',status=200, content_type="application/json",dumps=json_dumps)
    assert a.status == 200
    assert a.content_type == "application/json"
    assert a.body == b"{}"
    # body
    a = json('{}')
    assert a.body == b"{}"
    a = json({'a':1})
    assert a.body == b'{"a":1}'
    # status, headers, content_type,body,kwargs
    a = json('{}',status=200, content_type="application/json",dumps=json_dumps,separators=(",", ":"))
    assert a.body == b"{}"

# Generated at 2022-06-21 23:30:14.921704
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write("chunk1")
        await response.write("chunk2")

    response = stream(streaming_fn, status=200, content_type="text/plain; charset=utf-8")
    assert response.status == 200
    assert response.content_type == "text/plain; charset=utf-8"
    assert response.streaming_fn == streaming_fn



# Generated at 2022-06-21 23:30:25.805281
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    # Setup
    streaming_fn = lambda x: x
    status = 200
    headers = None
    content_type = "text/plain; charset=utf-8"
    chunked = "deprecated"

    actual = StreamingHTTPResponse(streaming_fn, status, headers, content_type)

    # Assert
    assert isinstance(actual, StreamingHTTPResponse)
    assert actual.streaming_fn == streaming_fn
    assert actual.status == status
    assert actual.headers == headers
    assert actual.content_type == content_type
    assert actual.chunked == chunked



# Generated at 2022-06-21 23:30:43.842052
# Unit test for function json
def test_json():
    json({"hello": "world"})

# Generated at 2022-06-21 23:30:51.302392
# Unit test for function html
def test_html():
    import warnings
    from types import FunctionType
    from sanic.response import html
    from gettext import gettext as _

    class TestClass:
        def __html__(self):
            return "hello world, i am __html__"

        def _repr_html_(self):
            return "hello world, i am _repr_html_"

    class TestClass2:
        def __html__(self):
            return "hello world, i am __html__2"

        def __str__(self):
            return "woof"

    # The following two cases are for checking if a warning is raised, when passed
    # an object that can't be encoded and when encoding fails due to unsupported
    # type.
    class TestClass3:
        def __init__(self, other_object):
            self.other_object = other

# Generated at 2022-06-21 23:31:00.052897
# Unit test for function redirect
def test_redirect():
    assert (redirect('https://httpbin.org').headers['Location'] == 'https://httpbin.org')
    assert (redirect('https://httpbin.org', headers={'Content-Type': 'app/json'}).headers['Content-Type'] == 'app/json')
    assert (redirect('https://httpbin.org', status=303).status == 303)
    assert (redirect('https://httpbin.org', content_type="application/javascript").content_type == "application/javascript")
    
test_redirect()
 

# Generated at 2022-06-21 23:31:09.683105
# Unit test for function stream
def test_stream():
    app = Starlette()

    @app.route("/")
    async def index(request):
        async def streaming_fn(response):
            await response.send(b"foo")
            await response.send(b"bar")

        return stream(streaming_fn)

    client = TestClient(app)
    response = client.get("/")
    assert response.status_code == 200
    assert response.headers["content-type"] == "text/plain; charset=utf-8"
    assert response.content == b"foobar"



# Generated at 2022-06-21 23:31:17.071633
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    @app.route('/')
    async def handler(request):
        return StreamingHTTPResponse(
            lambda r: None,
            status=200,
            headers={},
            content_type='text/plain',
            chunked=True
        )
    request, response = app.test_client.get('/')
    assert response.status == 200



# Generated at 2022-06-21 23:31:18.033001
# Unit test for function empty
def test_empty():
    assert empty()


# Generated at 2022-06-21 23:31:22.854440
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write("foo")
        await response.write("bar")

    response = StreamingHTTPResponse(
        streaming_fn,
        content_type="text/plain",
        status=200,
    )
    assert response.content_type == "text/plain"
    assert response.status == 200
    assert response.streaming_fn == streaming_fn

    # Test the StreamHTTPResponse send method
    response.streaming_fn = None
    response.body = "foobar"
    response.end_stream = True
    response.stream.send = mock.Mock()
    response.send()
    response.stream.send.assert_called_with("foobar", end_stream=True)

    # Test the StreamHTTPResponse write method

# Generated at 2022-06-21 23:31:27.590969
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    import asyncio

    async def main(data=None, end_stream=None):
        response = BaseHTTPResponse()
        response.asgi = False
        response.body = None
        response.content_type = None
        response.stream = Http()
        response.status = None
        response.headers = Header(dict())
        response._cookies = None
        return await response.send(data=None, end_stream=None)



# Generated at 2022-06-21 23:31:28.058452
# Unit test for constructor of class BaseHTTPResponse
def test_BaseHTTPResponse():
	pass

# Generated at 2022-06-21 23:31:32.793345
# Unit test for function file
def test_file():
    location = "C:/Users/10539/sanic/server.py"
    status = 200
    mime_type = None
    headers = None
    filename = "server.py"
    assert file(location, status, mime_type, headers, filename)



# Generated at 2022-06-21 23:32:10.952617
# Unit test for function file
def test_file():
    assert file("/tmp/test", status=200).status == 200
    assert file("/tmp/test", mime_type="text/plain").content_type == "text/plain"
    assert "Content-Disposition" in file("/tmp/test", filename="test.test").headers



# Generated at 2022-06-21 23:32:15.277861
# Unit test for function redirect
def test_redirect():
    res = redirect("https://example.com/")
    assert res.status == 302
    assert res.headers["Location"] == "https://example.com/"
    assert (
        "https://example.com/"
        == unquote_plus(res.headers["Location"])
    )
    assert res.body is None

    res = redirect("https://example.com/", status=303)
    assert res.status == 303
    assert res.headers["Location"] == "https://example.com/"
    assert (
        "https://example.com/"
        == unquote_plus(res.headers["Location"])
    )
    assert res.body is None

    res = redirect(
        "https://example.com/?param=%+plus",
        status=303,
        content_type="text/plain",
    )
   

# Generated at 2022-06-21 23:32:26.792050
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    def test_1():
        class MockStream:
            send = None
            def __init__(self):
                pass

        class MockResponse(StreamingHTTPResponse):
            def __init__(self):
                self.asgi = False
                self.body = None
                self.content_type = None
                self.stream = MockStream()
                self.status = None
                self.headers = {}
                self._cookies = None
                self.streaming_fn = None

        response = MockResponse()
        response.stream.send = Mock()
        asyncio.run(response.send())
        response.stream.send.assert_not_called()

        response.stream.send.reset_mock()
        asyncio.run(response.send(None, True))
        response.stream.send.assert_not_

# Generated at 2022-06-21 23:32:37.572911
# Unit test for function file_stream
def test_file_stream():
    import pytest
    import tempfile
    import os
    import asyncio
    from sanic import Sanic
    from sanic.response import json

    @pytest.fixture(
        scope="session",
        params=["file_stream", "raw", "file"]
    )
    def app_and_file(request):
        """
        Create a temporary file, sanic app, and handler for testing file*
        functions.
        """
        file_name = "testdata.txt"
        async def handler(request):
            if request.method == "GET":
                try:
                    return await request.app.file_func(
                        file_name,
                        _range=request.range,
                    )
                except Exception as ex:
                    exc_info = sys.exc_info()

# Generated at 2022-06-21 23:32:43.651174
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    def send(*args, **kwargs):
        pass
    e = StreamingHTTPResponse(None, 200)
    e.send = send
    assert e.streaming_fn is None
    e.send("", True)
    assert e.streaming_fn is None



# Generated at 2022-06-21 23:32:56.365948
# Unit test for function file_stream
def test_file_stream():
    assert file_stream('tests/test_responses.py') is not None



# Generated at 2022-06-21 23:33:08.348046
# Unit test for function html
def test_html():
    assert (
        html("<html>")
        ._encode_body("<html>")
        .decode("utf-8")
        == "<html>"
    )
    assert (
        html(b"<html>")
        ._encode_body("<html>")
        .decode("utf-8")
        == "<html>"
    )
    assert (
        html("<html>")
        ._encode_body("<html>")
        .decode("utf-8")
        == "<html>"
    )
    assert html("<html>").content_type == "text/html; charset=utf-8"
    assert html("<html>").headers == {}



# Generated at 2022-06-21 23:33:12.688021
# Unit test for function file
def test_file():
    file(location='/',status=200,mime_type='mime_type',headers={'headers':''},filename='filename',_range=Range(start=0,end=1,total=2))


# Generated at 2022-06-21 23:33:17.509136
# Unit test for function text
def test_text():
    body = 'test'
    status = 200
    headers = {'key1':'value1'}
    content_type = 'test/test'

    res = text(body, status, headers, content_type)
    assert res.body == body
    assert res.status == status
    assert res.headers == headers
    assert res.content_type == content_type


# Generated at 2022-06-21 23:33:21.574963
# Unit test for function raw
def test_raw():
    assert raw(body="raw", status=200, headers=None, content_type="text/html")
    assert raw(body="raw", status=200, headers=None, content_type=None)



# Generated at 2022-06-21 23:34:40.678523
# Unit test for function empty
def test_empty():
    assert empty(status=123, headers={"hello": "world"})
    assert empty(status=123)
    assert empty(headers={"hello": "world"})
    assert empty()



# Generated at 2022-06-21 23:34:48.881197
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    response = StreamingHTTPResponse(
        streaming_fn=None,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
    )
    response.stream.send = asynctest.CoroutineMock()

    async def coro():
        return None
    response.stream.send.return_value = coro()

    response.write('test')
    assert response.stream.send.called

# Generated at 2022-06-21 23:34:53.021458
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    import asyncio
    from sanic import Sanic
    from sanic.response import StreamingHTTPResponse

    app = Sanic('test_StreamingHTTPResponse_write')

    @app.route("/")
    async def test(request):
        response = await request.respond()
        await response.send("foo", False)
        await asyncio.sleep(1)
        await response.send("bar", False)
        await asyncio.sleep(1)
        await response.send("", True)
        return response

    request, response = app.test_client.get('/')

    assert response.status == 200
    assert response.text.strip() == 'foobar'



# Generated at 2022-06-21 23:35:06.324594
# Unit test for function stream
def test_stream():
    @app.route("/html", name="stream_html")
    async def stream_html(request):
        async def streaming_fn(response):
            await response.write("<div>")
            await response.write("<span>")
            await response.write("</span>")
            await response.write("</div>")

        return stream(streaming_fn, content_type='text/html')

    client = app.test_client()
    response = client.get("/html")
    assert response.status_code == 200
    assert response.http_version == "HTTP/1.1"
    assert response.headers["Content-Type"] == "text/html"
    assert b"<div>" in response.raw_body
    assert b"<span>" in response.raw_body
    assert b"</span>" in response