

# Generated at 2022-06-21 23:25:37.885009
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    response = StreamingHTTPResponse(lambda : None, 200)
    assert response.streaming_fn is not None
    assert response.status == 200
    assert response.content_type == 'text/plain; charset=utf-8'
    assert response.headers == {}
    assert response._cookies is None


# Generated at 2022-06-21 23:25:50.457038
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    import trio
    stream_mock = Mock()
    data = b"foo"
    end_stream = True
    response = StreamingHTTPResponse(
        streaming_fn = None,
        status = 200,
        headers = None,
        content_type = "text/html",
        chunked = True,
    )
    response.stream = stream_mock
    response.send(data, end_stream)
    stream_mock.send.assert_called_with(b"foo", True)
    stream_mock.send.reset_mock()
    data = None
    end_stream = None
    response.send(data, end_stream)
    assert stream_mock.send.call_count == 0
    stream_mock.send.reset_mock

# Generated at 2022-06-21 23:25:59.200473
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    class TestStream:
        async def send(self, data=None, end_stream=True):
            return (data, end_stream)

    def test_streaming_function(obj):
        pass
    test_str_chunked = "deprecated"
    test_str_content_type = "text/plain; charset=utf-8"
    t = StreamingHTTPResponse(
        test_streaming_function,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
        chunked="deprecated",
    )
    assert t.streaming_fn == test_streaming_function
    assert t.status == 200
    assert t.content_type == test_str_content_type
    assert t.stream is None

# Generated at 2022-06-21 23:26:10.146560
# Unit test for function stream
def test_stream():
    from quart.testing import QuartClient
    from quart import Quart
    from datetime import datetime
    app = Quart(__name__)

    @app.route('/')
    async def index():
        async def streaming_fn(response):
            await response.send(str(datetime.now()))
            await asyncio.sleep(1)
            await response.send(str(datetime.now()))
            await asyncio.sleep(1)
            await response.send(str(datetime.now()), True)
            # return stream(streaming_fn, content_type='text/plain')

        return stream(streaming_fn, content_type='text/plain')

    client = QuartClient(app)
    response = client.get('/')
    assert response.status_code == 200

# Generated at 2022-06-21 23:26:18.820522
# Unit test for constructor of class BaseHTTPResponse
def test_BaseHTTPResponse():
    # Test constructor of BaseHTTPResponse
    r = BaseHTTPResponse()
    assert r.asgi == False
    assert r.body == None
    assert r.content_type == None
    assert r.stream == None
    assert r.status == None
    assert r.headers == Header({})
    assert r._cookies == None


# Generated at 2022-06-21 23:26:21.764809
# Unit test for function redirect
def test_redirect():
    top=app.router.add_get('/top_page', top_page)
    redirect=app.router.add_get('/other_page', redirect_page)


# Generated at 2022-06-21 23:26:33.319704
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    from sanic.response import StreamingHTTPResponse
    from sanic.asgi import HttpProtocol
    from sanic import Sanic
    from types import SimpleNamespace

    app = Sanic('test')

    @app.route('/')
    async def handler(request):
        foo_async_gen = (i async for i in range(10))
        async def sample_streaming_fn(response):
            await response.write('a')
            await response.write('b')
            await asyncio.sleep(1)
            await response.write(foo_async_gen)
            await response.write(BytesIO(b"cde"))
            await response.write(b"fg")
            await response.write(b"h")
            await response.write(1)
            await response.write(b"j")

# Generated at 2022-06-21 23:26:40.053836
# Unit test for function file
def test_file():
    location = "tests/requests/test_file.txt"
    mime_type = guess_type(location)[0] or "text/plain"
    f = HTTPResponse(
        body=location,
        status=200,
        headers="",
        content_type=mime_type,
    )
  

# Generated at 2022-06-21 23:26:44.787903
# Unit test for function redirect
def test_redirect():
    assert (
        redirect("/foo", status=307, content_type="text/plain")
        .headers["Location"]
        .value
        == "/foo"
    )
    assert (
        redirect("http://testserver.com/foo", status=307)
        .headers["Location"]
        .value
        == "http://testserver.com/foo"
    )

# Generated at 2022-06-21 23:26:51.266539
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    """
    This test will check the functionality of the write in class StreamingHTTPResponse
    """
    # initial values
    status = 200
    headers = None
    content_type = "text/plain; charset=utf-8"
    chunked = "deprecated"
    StreamingHTTPResponse(streaming_fn, status, headers, content_type, chunked)
    streaming_fn = None
    data = None
    # check if the function is correct
    try:
        StreamingHTTPResponse.write(streaming_fn, data)
    except NotImplementedError:
        assert True



# Generated at 2022-06-21 23:27:03.644307
# Unit test for function raw
def test_raw():
    body = "hello"
    status = 200
    resp = raw(body, status)
    assert body in resp.body and status == resp.status



# Generated at 2022-06-21 23:27:07.777401
# Unit test for function raw
def test_raw():
    raw=HTTPResponse(
        body="hello",
        status=200,
        headers='hello',
        content_type="text.plain",
    )
    print(raw.body)
    print(raw.status)
    print(raw.headers)
    print(raw.content_type)



# Generated at 2022-06-21 23:27:15.545329
# Unit test for function file_stream
def test_file_stream():
    async def test():
        headers = {
            "Content-Disposition":
                'attachment; filename="test.txt"',
            "Content-Range":
                'bytes 0-5/6',
        }
        filename = 'test.txt'
        location = filename
        content = 'test.'
        response = await file_stream(
            location,
            headers = headers,
            filename = filename,
            _range = Range(0, 5, 6)
        )
        assert response.status == 206
        await response.send()
        assert response.stream.out_buffer == content
    
    loop = get_event_loop()
    loop.run_until_complete(test())



# Generated at 2022-06-21 23:27:18.392706
# Unit test for function raw
def test_raw():
    response=raw(body='test', status=200, headers=None, content_type='test/test')
    assert response.body == b'test'
    assert response.status == 200
    assert response.content_type == 'test/test'

# Generated at 2022-06-21 23:27:20.269331
# Unit test for function text
def test_text():
    assert text("hello")



# Generated at 2022-06-21 23:27:22.979888
# Unit test for function text
def test_text():
    body = "a"
    status = 200
    headers = None
    content_type = "text/plain; charset=utf-8"
    assert isinstance(text(body, status, headers, content_type),HTTPResponse) == True
    assert type(text(body, status, headers, content_type)).__name__ == "HTTPResponse"


# Generated at 2022-06-21 23:27:31.157265
# Unit test for function empty
def test_empty():

    # Test with custom headers
    headers = {"Custom-Header": "Content"}
    response = empty(status=200, headers=headers)
    assert response.body == b""
    assert response.status == 200
    assert response.headers["Custom-Header"] == "Content"
    assert response.headers["Content-Type"] == DEFAULT_HTTP_CONTENT_TYPE

    # Test without custom headers
    response = empty(status=204)
    assert response.body == b""
    assert response.status == 204
    assert response.headers["Content-Type"] == DEFAULT_HTTP_CONTENT_TYPE



# Generated at 2022-06-21 23:27:32.873595
# Unit test for function file
def test_file():
    file(location="", status=200, mime_type="", headers="", filename="")

# Generated at 2022-06-21 23:27:36.703466
# Unit test for function html
def test_html():
    from sanic.views import HTTPMethodView

    class HelloView(HTTPMethodView):
        def get(self, request):
            return html("<h1>Hello World!</h1>")
    assert "Hello World!" in str(HelloView().get(None))



# Generated at 2022-06-21 23:27:46.953815
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    test_response = HTTPResponse(b"", status = 200)
    assert (test_response.body == b"")
    assert (test_response.status == 200)
    assert (test_response.content_type == None)
    assert (test_response.headers == Header({}))
    assert (test_response._cookies == None)
    test_response = HTTPResponse(b"test", status = 200, headers = {}, content_type = "application/json")
    assert (test_response.body == b"test")
    assert (test_response.status == 200)
    assert (test_response.content_type == "application/json")
    assert (test_response.headers == Header({}))
    assert (test_response._cookies == None)



# Generated at 2022-06-21 23:28:06.145462
# Unit test for function file_stream
def test_file_stream():
    async def assert_file_stream(location):
        response = await file_stream(location)
        assert response.status == 200
        assert response.content_type == "text/plain"
        streaming_fn = response.streaming_fn
        assert streaming_fn is not None
        stream = StreamBuffer()
        response.stream = stream
        await streaming_fn(response)
        assert await stream.read_and_restore() == b"hello"
    asyncio.run(assert_file_stream(Path(__file__).parent / "hello.txt"))  # type: ignore


# Generated at 2022-06-21 23:28:14.146253
# Unit test for function html
def test_html():
    assert html("test").body == b"test"
    assert html("test").status == 200
    assert html("test").content_type == "text/html; charset=utf-8"
    assert html("test", status=404).body == b"test"
    assert html("test", content_type="text/plain").body == b"test"



# Generated at 2022-06-21 23:28:17.824057
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # streaming_fn = None
    # status = None
    # headers = None
    # content_type = None
    # chunked = None
    # base_http_response = BaseHTTPResponse()
    # streaming_response = StreamingHTTPResponse(streaming_fn, status, headers, content_type, chunked)
    # assert asyncio.coroutines.iscoroutine(streaming_response.send()) == True
    pass



# Generated at 2022-06-21 23:28:29.548340
# Unit test for function file_stream
def test_file_stream():
    import os
    import asynctest
    from sanic import Sanic
    from sanic.response import file_stream

    app = Sanic()


    async def test(request):
        return await file_stream(os.getcwd()+"/test.py")


    request, response = app.test_client.get(
        '/', headers={"Range": "bytes=0-8"})
    assert response.status is 206
    request, response = app.test_client.get(
        '/', headers={"Range": "bytes=0-8"})
    assert response.status is 206
    request, response = app.test_client.get('/')
    assert response.status is 200

# Generated at 2022-06-21 23:28:38.989596
# Unit test for function file_stream
def test_file_stream():
    async def test_content(request):
        return await file_stream("test_file.txt")
    # write a text file
    with open("test_file.txt", "w") as fd:
        fd.write("Hello, world!")

    # Test the whole process

    app = Sanic("test_file_stream")
    app.add_route(test_content, "/test")

    client = app.test_client
    response = client.get("/test")
    assert response.status == 200
    assert response.body == b"Hello, world!"

    os.remove("test_file.txt")



# Generated at 2022-06-21 23:28:44.154417
# Unit test for function raw
def test_raw():
    '''
    example:
    raw("hello")
    '''
    r = raw("hello")
    assert r.body == b"hello"
    assert r.status == 200
    assert r.headers == {}
    assert r.content_type == DEFAULT_HTTP_CONTENT_TYPE


# Generated at 2022-06-21 23:28:47.024705
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    def sample_streaming_fn(self):
        self.body = 'foo';
    test_StreamingHTTPResponse = StreamingHTTPResponse(sample_streaming_fn);
    test_StreamingHTTPResponse.send();


# Generated at 2022-06-21 23:28:50.886401
# Unit test for function stream
def test_stream():
    from quart import Quart
    app = Quart(__name__)
    @app.route("/")
    async def index(request):
        async def streaming_fn(response):
            await response.write("foo")
            await response.write("bar")
        return stream(streaming_fn, content_type="text/plain")
    client = app.test_client()
    rv = client.get("/")
    assert rv.data == b"foobar"

# Generated at 2022-06-21 23:29:01.512591
# Unit test for function json
def test_json():
    assert json(1) == HTTPResponse(b"1")
    assert json(1, foo="bar") == HTTPResponse(b'{"foo":"bar"}')
    assert json(b"foo") == HTTPResponse(b'"foo"')
    assert json(1, status=404) == HTTPResponse(b"1", status=404)
    assert json(
        1, headers={"foo": "bar"}
    ) == HTTPResponse(b"1", headers={"foo": "bar"})
    assert json(1, content_type="test/test") == HTTPResponse(
        b"1", content_type="test/test"
    )



# Generated at 2022-06-21 23:29:13.769511
# Unit test for function file_stream
def test_file_stream():
    import os
    from sanic import Sanic
    from sanic.response import file_stream
    import tempfile
    import asyncio

    app = Sanic(__name__)

    @app.route("/")
    async def handler(request):
        fd, path = tempfile.mkstemp()

        with os.fdopen(fd, "wb") as temp:
            temp.write(os.urandom(1024))

        return await file_stream(path, chunk_size=200)

    async def _test():
        request, response = app.test_client.get("/")
        assert response.status == 200
        assert len(await response.read()) == 1024

    asyncio.get_event_loop().run_until_complete(_test())



# Generated at 2022-06-21 23:29:34.485196
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # BaseHTTPResponse._encode_body(data)
    if data is None:
        return b""
    return (
        data.encode() if hasattr(data, "encode") else data  # type: ignore
    )


# Generated at 2022-06-21 23:29:39.692391
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    """__init__ unit test for class StreamingHTTPResponse"""
    StreamingHTTPResponse(
        streaming_fn=StreamingHTTPResponse, 
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
        chunked="deprecated"
    )

# Generated at 2022-06-21 23:29:49.054736
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    response = HTTPResponse()
    assert response.body is None
    assert response.status == 200
    assert response.headers == {}
    assert response.content_type == None

    response = HTTPResponse(body = "Super Mario", status = 404, headers = {'content-type': 'application/json'}, content_type = 'application/json')
    assert response.body == b"Super Mario"
    assert response.status == 404
    assert response.headers == {"content-type": "application/json"}
    assert response.content_type == 'application/json'

# Unit tests for isinstance of class HTTPResponse

# Generated at 2022-06-21 23:29:55.190843
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    async def set_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    headers = {"abc": "123"}
    content_type = "text/plain; charset=utf-8"
    chunked = "deprecated"
    streaming = StreamingHTTPResponse(
        set_streaming_fn, status=200, headers=headers, content_type=content_type, chunked=chunked
    )
    assert isinstance(streaming, StreamingHTTPResponse)



# Generated at 2022-06-21 23:30:03.855272
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    '''Test StreamingHTTPResponse constructor with the following arguments:
    StreamingHTTPResponse(
        streaming_fn: StreamingFunction,
        status: int = 200,
        headers: Optional[Union[Header, Dict[str, str]]] = None,
        content_type: str = "text/plain; charset=utf-8",
        chunked="deprecated",
    )
    '''
    streamingHTTPResponse = StreamingHTTPResponse(streaming_fn="", status=200, headers="", content_type="", chunked="")
    return streamingHTTPResponse


# Generated at 2022-06-21 23:30:13.693088
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():   
    response = HTTPResponse(body='1', status=200, headers={'Content-Type': 'text/plain; charset=utf-8'}, content_type='text/plain; charset=utf-8')
    assert response.body is not None
    assert response.status == 200
    assert response.headers is not None
    assert response.headers['Content-Type'] == 'text/plain; charset=utf-8'
    assert response.content_type == 'text/plain; charset=utf-8'


# Generated at 2022-06-21 23:30:26.798961
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest import TestCase, main
    from unittest.mock import patch, MagicMock
    from asyncio import ensure_future, get_event_loop, wait_for
    from sanic import Sanic
    from sanic.response import StreamingHTTPResponse
    from sanic.response import HTTPResponse

    app = Sanic()

    @app.route("/")
    @app.websocket("/ws")
    async def handler(request):
        return StreamingHTTPResponse(streaming_fn=lambda x: x.write("hello"))

    with patch("sanic.response.StreamingHTTPResponse._encode_body") as mock_encode_method:
        with patch("sanic.response.BaseHTTPResponse.send") as mock_send_method:
            request

# Generated at 2022-06-21 23:30:38.850199
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from async_generator import async_generator, yield_
    from types import SimpleNamespace
    from unittest.mock import create_autospec, AsyncMock

    @async_generator
    async def f(self):
        await yield_(self.stream.send.return_value)

    response = StreamingHTTPResponse(f, 200)
    response.stream = create_autospec(SimpleNamespace, spec=True)
    response.stream.send = AsyncMock()

    async def run_test():
        await response.send()
        response.stream.send.assert_called()

    loop.run_until_complete(run_test())
    assert response.streaming_fn is None


# Generated at 2022-06-21 23:30:40.491491
# Unit test for function redirect
def test_redirect():
    res = redirect("http://..")
    assert res.get_header("Location") == "http://.."
    assert "Location" in res.headers
    assert res.status == 302

# Generated at 2022-06-21 23:30:46.395574
# Unit test for function html
def test_html():
    obj = HTTPResponse("ok")
    assert type(obj) == HTTPResponse
    assert obj.body == b"ok"
    assert obj.status == 200
    assert isinstance(obj.headers, Header)
    assert obj.content_type == "text/html; charset=utf-8"



# Generated at 2022-06-21 23:31:20.601403
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    assert HTTPResponse() is not None


# Generated at 2022-06-21 23:31:28.669167
# Unit test for function empty
def test_empty():
    assert not empty(204).body
    assert empty(500).status == 500
    assert not empty(200, {"X-Custom-Header": "test"}).headers
    assert empty(418).content_type == "text/plain; charset=utf-8"
    assert empty(204).content_type == "text/plain; charset=utf-8"



# Generated at 2022-06-21 23:31:33.148975
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    streaming_fn = StreamingFunction
    StreamingHTTPResponse(streaming_fn=streaming_fn)
    StreamingHTTPResponse(streaming_fn=streaming_fn, content_type="text/html")



# Generated at 2022-06-21 23:31:37.789850
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    assert HTTPResponse(status=200).status == 200
    assert HTTPResponse(status=200, headers={}).status == 200


# Generated at 2022-06-21 23:31:45.142294
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    class MockStream:
        def __init__(self):
            self.send = None

    mock_stream = MockStream()
    async def mock_send(self, data, end_stream=True):
        self.send = (data, end_stream)
    mock_stream.send = mock_send

    response = HTTPResponse(body=None)
    response.stream = mock_stream
    await response.send(end_stream=True)
    assert mock_stream.send == (b"", True)
    
    await response.send(data="something", end_stream=True)
    assert mock_stream.send == (b"something", True)
    
    await response.send(data="something")
    assert mock_stream.send == (b"something", False)

# Generated at 2022-06-21 23:31:54.575678
# Unit test for function text
def test_text():
    test_text_string = "Everything is awesome."
    test_text_status = 200
    test_text_headers = {
        "Content-Type": "text/plain; charset=utf-8",
        "Content-Length": "23",
    }
    response = text(
        body=test_text_string,
        status=test_text_status,
        headers=test_text_headers,
        content_type="text/plain; charset=utf-8",
    )
    assert response.body == test_text_string
    assert response.status == test_text_status
    assert response.headers == test_text_headers
    assert response.content_type == "text/plain; charset=utf-8"
    # test_text_wrong_body_type

# Generated at 2022-06-21 23:32:01.510859
# Unit test for function file
def test_file():
    import os
    import tempfile
    import pytest
    import aiofiles
    basedir = tempfile.gettempdir()
    filename = "test.txt"
    with open(os.path.join(basedir, filename), "w") as f:
        f.write("Hello, world!")
    async def test_open():
        async with await aiofiles.open(os.path.join(basedir, filename), 'rb') as f:
            await f.seek(0)
            assert await f.read() == b"Hello, world!"
    pytest.run_asyncio(test_open())



# Generated at 2022-06-21 23:32:13.013546
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    fn = lambda x : None
    resp = StreamingHTTPResponse(fn)
    resp.status = 200
    resp.content_type = 'text/plain; charset=utf-8'
    resp.headers['content_type'] = 'text/plain; charset=utf-8'
    resp.headers.setdefault("content-type", 'text/plain; charset=utf-8')
    resp.headers.pop('content_type')
    resp.headers['Content-Type'] = 'text/plain; charset=utf-8'



# Generated at 2022-06-21 23:32:18.748649
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write("foo")
        await response.write("bar")
    response = stream(streaming_fn, content_type="text/plain")
    return response

assert isinstance(test_stream(), StreamingHTTPResponse)



# Generated at 2022-06-21 23:32:24.286937
# Unit test for function stream
def test_stream():
    s = '''async def streaming_fn(response):
                await response.write('foo')
                await response.write('bar')'''
    exec(s)
    exec('stream(streaming_fn, content_type=\'text/plain\')')
# test_stream()

# Generated at 2022-06-21 23:33:08.276368
# Unit test for function file
def test_file():
    assert (
        file("sanic/helpers.py").headers["Content-Disposition"]
        == 'attachment; filename="helpers.py"'
    )
    assert (
        file("sanic/helpers.py", mime_type="text/html").headers[
            "Content-Disposition"
        ]
        == 'attachment; filename="helpers.py"'
    )
    assert (
        file("sanic/helpers.py", filename="foo.txt").headers[
            "Content-Disposition"
        ]
        == 'attachment; filename="foo.txt"'
    )

# Generated at 2022-06-21 23:33:13.710226
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
  c1=StreamingHTTPResponse(None,200,{},"message/gg")
  c2=StreamingHTTPResponse(None,200,None,"message/gg")
  assert c1._cookies == None and c2._cookies==None

# Generated at 2022-06-21 23:33:19.102898
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    # test with valid data
    response = HTTPResponse("Hello world", 200)
    assert response.body == "Hello world"
    assert response.status == 200
    assert response.headers == Header({})
    assert response.content_type == "text/plain"

    # test with invalid data
    response = HTTPResponse(b"Hello world", "200")
    assert response.body == None
    assert response.status == 200
    assert response.headers == Header({})
    assert response.content_type == None


# Generated at 2022-06-21 23:33:24.420690
# Unit test for function empty
def test_empty():
    r = empty(headers={"test": "pass"})
    assert isinstance(r, HTTPResponse)
    assert r.body == b""
    assert r.status == 204
    assert r.headers["test"] == "pass"



# Generated at 2022-06-21 23:33:28.731939
# Unit test for function redirect
def test_redirect():
    """Unit test for function redirect"""
    response = redirect("https://api2cart.github.io/")
    assert response.status == 302
    assert "Location" in response.headers
    assert response.headers["Location"] == "https://api2cart.github.io/"


# Generated at 2022-06-21 23:33:37.998838
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    async def example():
        obj1 = BaseHTTPResponse()
        obj2 = BaseHTTPResponse()
        obj1.stream = obj2
        obj1.stream.send = None
        await obj1.send (data = None, end_stream = None)
        await obj1.send(data=None, end_stream=True)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(example())

# Generated at 2022-06-21 23:33:51.743941
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')
    assert type(streaming_fn) == types.FunctionType
    assert type(stream(streaming_fn, content_type='text/plain')) == StreamingHTTPResponse
    assert type(empty()) == HTTPResponse
    assert type(json({'a': 'b', 'c': 'd'}, status=200, headers=None, content_type='application/json')) == HTTPResponse
    assert type(text('hello', status=200, headers=None, content_type='text/plain; charset=utf-8')) == HTTPResponse

# Generated at 2022-06-21 23:34:03.011029
# Unit test for constructor of class HTTPResponse
def test_HTTPResponse():
    from unittest import TestCase, main
    from io import StringIO
    from logging import StreamHandler, getLogger

    class TestMain(TestCase):
        def test_HTTPResponse_basic(self):
            """
            Basic test for HTTPResponse class
            :return:
            """
            htr = HTTPResponse()
            self.assertEqual(htr.body, None)
            self.assertEqual(htr.content_type, None)
            self.assertEqual(htr.status, 200)
            self.assertEqual(htr.headers, Header({}))
            self.assertEqual(htr._cookies, None)
            self.assertIsInstance(htr._cookies, CookieJar)


# Generated at 2022-06-21 23:34:09.713066
# Unit test for function raw
def test_raw():
    assert raw("Hello").body == b"Hello"
    assert raw("Hello", content_type="text/plain").content_type == "text/plain"
    assert raw("Hello", status=301).status == 301
    assert raw("Hello", headers={"something": "else"}).headers["something"] == "else"



# Generated at 2022-06-21 23:34:12.187928
# Unit test for function html
def test_html():
    assert html('foo').body == b'foo'
    assert html(b'foo').body == b'foo'


# Generated at 2022-06-21 23:35:25.095839
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    import pytest
    import sanic
    app = sanic.Sanic()

    @app.route('/')
    async def test(request):
        return sanic.HTTPResponse('test')

    request, response = app.test_client.get('/')
    assert response.status == 200
    assert response.text == 'test'
