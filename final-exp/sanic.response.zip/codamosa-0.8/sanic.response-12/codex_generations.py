

# Generated at 2022-06-22 15:11:21.123611
# Unit test for function file
def test_file():
    # Prevent close warning
    # https://github.com/aio-libs/aiofiles/issues/74
    import warnings
    warnings.simplefilter("ignore")

    from aiohttp.test_utils import AioHTTPTestCase, unittest_run_loop
    from sanic import Sanic
    from sanic.response import text

    class TestFile(AioHTTPTestCase):
        def get_app(self):
            app = Sanic("test_file")

            @app.route("/test_file")
            async def test_file(request):
                filepath = __file__
                print(filepath)
                return await file(filepath)

            return app


# Generated at 2022-06-22 15:11:22.641780
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    pass



# Generated at 2022-06-22 15:11:27.712306
# Unit test for function file
def test_file():
    async def test():
        import os
        file_location = os.path.dirname(os.path.realpath(__file__))
        file_location += "/test_responses.py"
        response = await file(location=file_location)
        assert response.status == 200
        assert response.content_type == "text/x-python"
        assert response.body[:5] == b"from"
    asyncio.run(test())




# Generated at 2022-06-22 15:11:31.206059
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # Create instance of class StreamingHTTPResponse
    streaming_fn = lambda x: \
        None
    status = 200
    headers = {}
    content_type = "text/plain; charset=utf-8"
    # chunked = 'deprecated'
    # TODO: mock class Http to implement send method
    # http_mock = mock.Mock(spec=Http, send=return_magic_mock)
    # streaming_http_response = StreamingHTTPResponse(streaming_fn, status, headers, content_type)




# Generated at 2022-06-22 15:11:47.735258
# Unit test for function file_stream
def test_file_stream():
    async def func():
        response = await file_stream(location="a.txt", 
                                headers={'Content-Disposition': 
                                'attachment; filename="a.txt"'}, 
                                chunk_size=1,
                                status=200,
                                mime_type="text/plain",
                                _range=None)
        
        assert response.streaming_fn.__name__ == '_streaming_fn'
    
    code = func()
    asyncio.get_event_loop().run_until_complete(code)
    
    
    
    
    

# Generated at 2022-06-22 15:11:52.075568
# Unit test for function file
def test_file():
    assert(file("/root/test") == HTTPResponse(body=b"", status=200, headers={}, content_type="text/plain") )

# Generated at 2022-06-22 15:11:56.285439
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    response = StreamingHTTPResponse(Mock())
    response.status = 1
    response.content_type="application/json"
    response.headers="headers"
    response._cookies=None
    result=response.send()
    assert result == None


# Generated at 2022-06-22 15:12:03.495991
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.sanic import Sanic
    from sanic.testing import HOST, sanic_endpoint_test

    app = Sanic()

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(streaming_fn=test_stream_func)

    async def test_stream_func(response):
        await response.write("foo")
        await response.write("bar")

    if __name__ == "__main__":
        sanic_endpoint_test(app, endpoint=handler)
        import asyncio
        asyncio.run(test_stream_func)
    else:
        test_stream_func()



# Generated at 2022-06-22 15:12:09.076749
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)
        await response.write("")
        await asyncio.sleep(1)
        await response.send("baz", True)

    @app.post("/")
    async def test(request):
        return stream(sample_streaming_fn)
    
    sample_streaming_fn = sample_streaming_fn
    test = test



# Generated at 2022-06-22 15:12:16.863236
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    import asyncio
    import pprint
    from sanic import Sanic

    app = Sanic(__name__)
    async def sample_streaming_fn(response):
        await response.send("foo", False)
        await asyncio.sleep(1)
        await response.send("bar", False)
        await asyncio.sleep(1)
        await response.send("", True)
        return response
    
    
    @app.route("/")
    async def test(request):
        return StreamingHTTPResponse(sample_streaming_fn)

    req, resp = app.test_client.post('/')
    resp.body = b''
    pprint.pprint(resp.body)



# Generated at 2022-06-22 15:12:36.284021
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic import Sanic
    from sanic.response import HTTPResponse
    from sanic.request import Request
    app = Sanic()

    @app.route("/")
    async def index(request):
        return HTTPResponse("Hello World", content_type="text/plain")

    request, response = app.test_client.get("/")
    assert response.body == b"Hello World"
    assert response.status == 200
    assert response.headers["Content-Length"] == "11"
    assert response.headers["Content-Type"] == "text/plain"


# Generated at 2022-06-22 15:12:44.536917
# Unit test for function file_stream
def test_file_stream():
    import pathlib

    async def test(request):
        return await file_stream(pathlib.Path(__file__).absolute())
    app = Sanic()
    app.add_route(test, '/')
    _, response = app.test_client.get('/')
    assert response.status == 200
    assert len(response.headers) == 4
    assert response.headers.get('Content-Type') == 'text/x-python'
    assert response.headers.get('Content-Disposition') == 'attachment; filename="resp.py"'
    assert response.headers.get('Content-Range') == f'bytes 0-{len(response.text)}/{len(response.text)}'
    assert response.headers.get('Transfer-Encoding') == 'chunked'

# Generated at 2022-06-22 15:13:01.088842
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from .request import Request
    from .client import TestClient
    from .websocket import WebSocketProtocol, WebSocketConnection

    async def streaming_fn(response):
        await response.write('foo')
        await asyncio.sleep(1)
        await response.write('bar')
        await asyncio.sleep(1)


    def create_app():
        app = Sanic('test_StreamingHTTPResponse_write')
        app.ws = None

        @app.websocket('/ws')
        async def websocket(request, ws):
            app.ws = ws

        @app.route('/ws')
        async def get_websocket(request):
            await app.ws.send('received')

        @app.route('/stream')
        async def handler(request):
            return Streaming

# Generated at 2022-06-22 15:13:02.763527
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    BaseHTTPResponse.send(None)

# Generated at 2022-06-22 15:13:06.230913
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    response_send = BaseHTTPResponse()
    data = None
    end_stream = None
    response_send.send(data,end_stream)


# Generated at 2022-06-22 15:13:14.009718
# Unit test for function file
def test_file():
    location = "tests/test_static/test.txt"
    filename = "test.txt"
    status = 201
    mime_type = "test/test"
    headers ={"Content-Disposition": "attachment; filename=test.txt"}
    _range = Range(start=0, end=3, total=3)
    HTTPResponse(
        body=open(location).read(),
        status=status,
        headers=headers,
        content_type=mime_type,
    )



# Generated at 2022-06-22 15:13:21.354640
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import HTTPResponse, default_headers_factory

    request = Request(b"GET", u"/", headers={})
    app = None
    status = None
    headers = default_headers_factory(
        request, app, status
    )  # type: Header  # type: ignore
    response = HTTPResponse(305, headers=headers,)
    response.headers = response.cookies



# Generated at 2022-06-22 15:13:25.937677
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    wrt = StreamingHTTPResponse(None, None, None, None, None)
    wrt.write(None)
    wrt.send(None, None)

# Generated at 2022-06-22 15:13:32.032460
# Unit test for function file
def test_file():
    if sys.platform != "win32":
        import os.path
        import tempfile
        with tempfile.TemporaryDirectory() as tmpdirname:
            testfile = "test.txt"
            filepath = os.path.join(tmpdirname, testfile)
            with open(filepath, "w") as f:
                f.write("test")

            resp = file(filepath)
            assert resp.__class__ == HTTPResponse



# Generated at 2022-06-22 15:13:33.989400
# Unit test for function html
def test_html():
    assert html(1).body == b"1"



# Generated at 2022-06-22 15:13:52.147685
# Unit test for function file
def test_file():
    async def test():
        test_dir = path.dirname(path.abspath(__file__))
        location = path.join(test_dir, "file_test.txt")
        response = await file(location, filename='test.txt')
        assert response.status == 200
        assert response.body.decode() == "test"

        with open(location, "w") as f:
            f.write("hello")
        response = await file(location, filename='test.txt')
        assert response.body.decode() == "hello"

        with open(location, "w") as f:
            f.write("hello")
        response = await file(location, filename='test.txt', _range=Range(0, 10))
        assert response.status == 206
        assert response.body.decode() == "hello"

# Generated at 2022-06-22 15:13:57.745537
# Unit test for function file_stream
def test_file_stream():
    async def go():
        f = await file_stream("static/9b9f6d1510ec5537c3d668e8b17c642e")
        while True:
            chunk = await f.stream.read()
            if not chunk:
                break
        f.stream.close()
    asyncio.run(go())

# Generated at 2022-06-22 15:14:01.108665
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    with pytest.raises(AttributeError):
        class TestStreamingHTTPResponse:
            def __init__(self):
                self.streaming_fn = None
        TestStreamingHTTPResponse.write()

# Generated at 2022-06-22 15:14:06.081745
# Unit test for function file_stream
def test_file_stream():
    location = "./labs/test.txt"
    status = 200
    chunk_size = 4096
    mime_type = "text/plain"
    headers = None
    filename = None
    _range = "bytes="+str(0)+"-"+str(5)
    res = file_stream(location, status, chunk_size, mime_type, headers, filename, _range)
    assert str(res) == "<HTTPResponse 207 bytes [text/plain]>"
    assert res.status == 207

# Generated at 2022-06-22 15:14:17.656096
# Unit test for function file_stream
def test_file_stream():
    # Simple functional testing
    async def get_file(loop):
        import tempfile as tf
        import sys
        import os

        with tf.NamedTemporaryFile(mode="w") as f:
            f.write(os.linesep.join(["line 1", "line 2", "line 3"]))
            f.flush()
            async with await open_async(f.name, mode="rb") as infile_async:
                async with await open_async(
                    sys.argv[1], "wb", loop=loop
                ) as outfile_async:
                    async for chunk in infile_async:
                        await outfile_async.write(chunk)
    import sys
    import asyncio


# Generated at 2022-06-22 15:14:18.591265
# Unit test for function file_stream
def test_file_stream():
    pass



# Generated at 2022-06-22 15:14:28.013948
# Unit test for function file_stream
def test_file_stream():
    import shutil
    import tempfile
    import os
    import asyncio
    import io
    import httpx

    async def echo_response(_responses):
        async for response in _responses:
            await response.send(response.body)

    with tempfile.TemporaryDirectory() as tempdir:
        # Note: This test uses `shutil.copy` to recreates the initial file
        #  after sending requests to make sure that the file is the same
        #  as the one initially read from by `open` (And not a file
        #  tha body has been changed by some requests)
        test_file_path = os.path.join(tempdir, "test_file")


# Generated at 2022-06-22 15:14:29.042729
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    # Initialize class
    pass


# Generated at 2022-06-22 15:14:35.657890
# Unit test for function file
def test_file():
    async def test():
        mime_type = "text/plain"
        headers = {}
        _range = Range(start=0, end=10, size=100, total=100)
        filename = "tests.py"
        status = 200
        location = "./tests.py"
        file_result = await file(location, status, mime_type, headers, filename, _range)
        assert file_result.status == status

    asyncio.run(test())



# Generated at 2022-06-22 15:14:40.077859
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    response = BaseHTTPResponse()
    response.stream = Http()
    response.stream.completed = False
    response.stream.chunked = False
    response.stream.send = None
    await response.send(data="test")
    assert response.stream.body == b"test"


# Generated at 2022-06-22 15:15:06.106125
# Unit test for function json
def test_json():
    # Check if the callback is being caleld 
    def dumps(body):
        return 'check'
    assert json(body=[], status=200, headers={}, content_type="application/json", dumps=dumps)

JSONHTTPResponse = json



# Generated at 2022-06-22 15:15:18.436246
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import mock
    from unittest.mock import sentinel as sentinel
    response = StreamingHTTPResponse(
        streaming_fn = sentinel.streaming_fn,
        status = 200,
        headers = sentinel.headers,
        content_type = "text/plain; charset=utf-8",
        chunked = "deprecated"
    )
    response.send = mock.MagicMock()
    response.send.return_value = sentinel.return_value
    response.write(sentinel.data)
    assert response.send.call_args_list == [
        mock.call(b''),
        mock.call(mock.ANY, False)
    ]
    assert response.send.call_args[0][0] == sentinel.return_value

# Generated at 2022-06-22 15:15:22.012593
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    data_to_send=b"abcdefghijkl"
    send_func=None
    send_stream=MockStream(send_func)
    BaseHTTPResponse.stream=send_stream
    BaseHTTPResponse.send(data_to_send)
    assert send_stream.data==data_to_send

# Generated at 2022-06-22 15:15:31.418980
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    class StubSend:
        def __init__(self):
            self.result = None
        async def __call__(self, data, end_stream):
            self.result = data

    from sanic.response import StreamingHTTPResponse
    import asyncio

    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    response = StreamingHTTPResponse(sample_streaming_fn)
    response.stream = StubSend()

    loop = asyncio.get_event_loop()
    loop.run_until_complete(response.send('baz', True))
    assert response.stream.result.decode() == 'baz'



# Generated at 2022-06-22 15:15:33.096780
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    pass

    # TODO: Implement test
    assert True # implement your test here



# Generated at 2022-06-22 15:15:35.077464
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    streamingHTTPResponse = StreamingHTTPResponse(None,1,None,"")
    assert streamingHTTPResponse.write


# Generated at 2022-06-22 15:15:44.729587
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    request = MagicMock()
    request.app = MagicMock()
    request.app.router = MagicMock()
    request.app.error_handler = MagicMock()
    request.app.loop = MagicMock()
    request.app.config = MagicMock()
    request.app.config.REQUEST_MAX_SIZE = 10485760
    request.app.config.REQUEST_TIMEOUT = 10
    request.app.config.KEEP_ALIVE = True
    request.app.config.KEEP_ALIVE_TIMEOUT = 5
    request.content = MagicMock()
    request.content.read = MagicMock()
    request._is_streamed = True
    request.parsed_json = MagicMock()

# Generated at 2022-06-22 15:15:55.277071
# Unit test for function file
def test_file():
    """Unit test for file"""

    async def test_headers():
        """Unit test for headers"""
        assert (
            (await file(__file__, headers={"Test-Header": "123"})).headers[
                "Test-Header"
            ]
            == "123"
        )

    async def test_status():
        """Unit test for status"""
        assert (await file(__file__, status=500)).status == 500

    async def test_filename():
        """Unit test for filename"""
        assert "/test.py" in (await file(__file__, filename="test.py")).headers[
            "Content-Disposition"
        ]

    async def test_mime_type():
        """Unit test for mime_type"""

# Generated at 2022-06-22 15:15:59.835455
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    sample_streaming_fn = write_sample_streaming_fn()
    streaming_response = StreamingHTTPResponse(streaming_fn=sample_streaming_fn)
    try:
        asyncio.run(streaming_response.write("foo"))
    except:
        raise
    return streaming_response



# Generated at 2022-06-22 15:16:02.487036
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
  data = None
  end_stream = None
  BaseHTTPResponseInstance.send(data, end_stream)


# Generated at 2022-06-22 15:16:45.183991
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    def mock_StreamingFunction(response):
        return asyncio.sleep(1)
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    from asyncio import sleep
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        async def get(self, request):
            return StreamingHTTPResponse(mock_StreamingFunction)

    request, response = MyView.get(Request({}, b"", "GET"))
    assert response.streaming_fn is not None

# Generated at 2022-06-22 15:16:54.296998
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic import Sanic
    from sanic.response import stream
    from sanic.constants import HTTP_METHODS
    app = Sanic("test_BaseHTTPResponse_send")

    async def handler(request):
        return stream(app.handle_request, request)

    @app.route("/", methods=HTTP_METHODS)
    async def post_handler(request):
        return HTTPResponse(
            b"test",
            status=200,
            headers={"X-Custom-Header": "yes"},
            content_type="application/json",
            cookies={"test": "works"},
        )

    request, response = app.test_client.get("/")
    app.handle_request = handler
    assert response.status == 200


# Generated at 2022-06-22 15:17:03.639478
# Unit test for function file_stream
def test_file_stream():
    async def sample_handler(request):
        return await file_stream("./test.py", filename="test.py")

    app = Sanic("test_file_stream")
    app.add_route(sample_handler, "/")

    _, response = app.test_client.get("/")
    data = response.body.decode()
    # Check if the file was successfuly streamed
    assert data[:6] == "#!/usr"
    # Check if the headers contain the filename override
    assert response.headers["Content-Disposition"] == 'attachment; filename="test.py"'



# Generated at 2022-06-22 15:17:11.314597
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():

    async def streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)
        
    test_object = StreamingHTTPResponse(streaming_fn)

    ###

    with pytest.deprecated_call():
        assert streaming_fn(test_object) is not None
    assert StreamingHTTPResponse._dumps is not None
    assert test_object.send("foo", False) is not None



# Generated at 2022-06-22 15:17:20.142374
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    import asyncio

    class Response():
        status=200
        
    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)
    response=StreamingHTTPResponse(status=200,streaming_fn=sample_streaming_fn)
    assert response.status==200
    asyncio.run(response.send("foo",False))
    asyncio.run(response.send("bar",False))
    asyncio.run(response.send("",True))
    
    
    
    


# Generated at 2022-06-22 15:17:29.725843
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from aiounittest import async_test
    from sanic.app import Sanic
    import asyncio
    from datetime import datetime
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_StreamingHTTPResponse_write")
    request = "request"
    response = StreamingHTTPResponse("streaming_fn", 200, "headers", "content_type", "chunked")
    response_body = response._encode_body("data")
    @asyncio.coroutine
    def stub_coro():
        asyncio.sleep(1)
        return None
    response.send = stub_coro
    @asyncio.coroutine
    def test():
        result = yield from response.write("data")
        return result

# Generated at 2022-06-22 15:17:37.899021
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.testing import SanicTestClient

    app = Sanic("test_BaseHTTPResponse_send")

    @app.route("/", methods=["GET"])
    async def handler(request: Request) -> HTTPResponse:
        return HTTPResponse(body="Test body", headers={"X-Foo": "Bar"})

    request, response = app.test_client.get("/")

    assert response.text == "Test body"
    assert response.headers.get("X-Foo") == "Bar"

# Generated at 2022-06-22 15:17:44.692402
# Unit test for function file_stream
def test_file_stream():
    
    data = BytesIO()

    def sanic(self):
        asyncio.iscoroutine(self)
        return self

    async def _streaming_fn(response):
        async with await open_async(location, mode="rb") as f:
            return f.read()
    return StreamingHTTPResponse(
        streaming_fn=_streaming_fn,
    )

# Generated at 2022-06-22 15:17:50.670921
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_fn=None
    status = 200
    headers = None
    content_type = "text/plain; charset=utf-8"
    chunked = "deprecated"

    obj = StreamingHTTPResponse(streaming_fn,status,headers,content_type,chunked)
    result=obj.send()
    assert result is not None


# Generated at 2022-06-22 15:18:00.196967
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from unittest import TestCase

    from sanic.asgi import MockStream
    from .test_models import mock_coro

    class Test(TestCase):
        def setUp(self):
            self.response = BaseHTTPResponse()
            self.response.stream = MockStream()
            self.response.stream.send = mock_coro()

        def test_no_args(self):
            async def test():
                await self.response.send()
                self.response.stream.send.assert_called_with(
                    b"", end_stream=True
                )

            asyncio.run(test())

        def test_data_not_None_end_not_None(self):
            async def test():
                await self.response.send(b"test", True)
                self.response.stream.send

# Generated at 2022-06-22 15:19:04.671000
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    response=HTTPResponse('hi')
    assert response.send()


# Generated at 2022-06-22 15:19:06.472592
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
  response = BaseHTTPResponse()
  response.stream = Http()
  response.send(data = '[]',end_stream = True)

# Generated at 2022-06-22 15:19:09.760123
# Unit test for function file_stream
def test_file_stream():
    import asyncio
    loop = asyncio.get_event_loop()
    def get_location():
        import os
        dirname = os.path.dirname(__file__)
        return os.path.join(dirname, 'example.py')
    f_stream_response = loop.run_until_complete(file_stream(get_location()))
    assert f_stream_response.status == 200


# Generated at 2022-06-22 15:19:12.654336
# Unit test for function json
def test_json():
    import ujson

    assert ujson.dumps({"foo": "bar"}) == json({"foo": "bar"}).body.decode()



# Generated at 2022-06-22 15:19:20.584820
# Unit test for function file_stream
def test_file_stream():
    @tornado.gen.coroutine
    def test_file(self):
        s = yield file_stream("/tmp/test.txt")
        self.assertEqual(s.status, 200)
        self.assertEqual(s.content_type, "text/plain")
        self.assertEqual(s.headers["Content-Disposition"], 'attachment; filename="test.txt"')
        self.assertEqual(s.headers["Content-Length"], "11")

    get_event_loop().run_until_complete(test_file)




# Generated at 2022-06-22 15:19:30.774695
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    import os
    import sys
    import unittest
    import pytest
    from unittest.mock import patch
    from sanic import Sanic
    from sanic.response import StreamingHTTPResponse


    class StreamingResponseTest(unittest.TestCase):
        def test_streaming_resp_write(self):
            app = Sanic("test_stream_resp")
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)
                await response.write("baz")
                await asyncio.sleep(1)

            @app.route("/")
            def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = app

# Generated at 2022-06-22 15:19:35.309550
# Unit test for function file
def test_file():
    async def a():
        file(location="./sanic.py") # initializing function
        a() # calling function
test_file()

# Testing file function
async def a():
    file(location="./sanic.py") # initializing function
    a() # calling function

# Generated at 2022-06-22 15:19:35.856089
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    pass

# Generated at 2022-06-22 15:19:36.467046
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    pass

# Generated at 2022-06-22 15:19:43.095200
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # encoding: utf-8
    """
    Test StreamingHTTPResponse.send()
    """
    import unittest
    import os
    import sys
    import aiohttp

    import asyncio
    from urllib.parse import urlencode
    sys.path.append("../../sanic")
    from sanic import Sanic
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import ServerError

    class TestStreamingHTTPResponse():

        @staticmethod
        def test_StreamingHTTPResponse_send_1(loop):
            app = Sanic('test_StreamingHTTPResponse_send_1')
