

# Generated at 2022-06-22 15:12:09.404444
# Unit test for function file
def test_file():
    headers = {"Content-Range": "bytes 0-3/3"}
    out_stream = b'foo'
    status = 206
    mime_type = "text/plain"
    filename = 'test.txt'
    directory = '.'
    location = f'/{directory}/{filename}'
    _range = Range(start=0, end=3, total=3)
    
    assert HTTPResponse.file(location, status=status, mime_type=mime_type, headers=headers, filename=filename, _range=_range) == HTTPResponse(out_stream, status=status, headers=headers, content_type=mime_type)

# Generated at 2022-06-22 15:12:17.563527
# Unit test for function file
def test_file():
    return file("/home/bartosz/Downloads/arbeit.blend", status=200, mime_type="application/blend", filename="arbeit.blend")

async def redirect(
    location: str,
    status: Optional[int] = None,
    headers: Optional[Dict[str, str]] = None,
) -> HTTPResponse:
    """Return a response object with redirect method.

    :param location: Location of file on system.
    :param status: Status code.
    :param headers: Custom Headers.
    """
    url = quote_plus(location)
    if status is None:
        status = 302


# Generated at 2022-06-22 15:12:23.269149
# Unit test for function file_stream
def test_file_stream():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    import tempfile
    import asyncio
    import json


    # init app
    app = Sanic("test_file_stream")


    # create temp file
    file_name = tempfile.NamedTemporaryFile().name


    # write some content
    with open(file_name, 'w')as f:
        f.write("test")


    # create sample route
    @app.route("/<sample>")
    def test(request: Request, sample: str):
        return file_stream(file_name, chunked=True)


    # create client
    client = app.test_client
    request, response = client.get(
        '/')

    # ensure content
   

# Generated at 2022-06-22 15:12:34.148523
# Unit test for function file_stream
def test_file_stream():
    location = ''.join(["D:\\coding_projects\\sanic_example\\tests", "/sanic.py"])
    response = HDFResponse(location)
    assert response.body == HDFResponse(location).body
    assert response.status == HDFResponse(location).status
    assert response.chunk_size == HDFResponse(location).chunk_size
    assert response.mime_type == HDFResponse(location).mime_type
    assert response.headers == HDFResponse(location).headers
    assert response.filename == HDFResponse(location).filename
    assert response.chunked == HDFResponse(location).chunked
    assert response.range == HDFResponse(location).range
    assert response.streaming_fn == HDFResponse(location).streaming_fn


# Generated at 2022-06-22 15:12:40.096893
# Unit test for function file
def test_file():
    with open('E:\\pyProject\\pythonEx\\g.txt', 'w') as f:
        f.write('123')
    headers = {}
    filename = 'g.txt'
    a = asyncio.run(file('E:\\pyProject\\pythonEx\\g.txt', 200, None, headers, filename))
    print(a.body)
test_file()

# Generated at 2022-06-22 15:12:53.211665
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    import asyncio

    from sanic import Sanic
    from sanic.exceptions import ServerError

    app = Sanic()

    async def sample_streaming_fn(response):
        await response.write("foo")
        for _ in range(5):
            await asyncio.sleep(1)
            await response.write("bar")
        await response.write("")

    @app.route("/")
    async def test(request):
        return StreamingHTTPResponse(
            sample_streaming_fn,
            status=200,
            headers={"X-Stream": "True"},
            content_type="text/html",
        )

    _, response = app.test_client.get("/")
    assert response.status == 200
    assert response.text == "foobarbarbarbarbar"

# Generated at 2022-06-22 15:13:05.299024
# Unit test for function file_stream
def test_file_stream():
    @app.route("/")
    async def handler(request):
        return await file_stream(__file__)

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.body == open(__file__, "rb").read()



# Generated at 2022-06-22 15:13:08.064186
# Unit test for function file_stream
def test_file_stream():
    async def test():
        response = await file_stream(__file__)
        assert response.stream.__class__.__name__ == 'FileWrapper'
    short_test_runner(test)


# Generated at 2022-06-22 15:13:20.398366
# Unit test for function file
def test_file():
    # Default case
    location = './tests/test_utils_multipart.py'
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    response = await file(location,status,mime_type,headers,filename,_range)
    assert response.status==200
    assert response.headers=={'Content-Type':'text/x-python'}
    assert response.body!=None

    # Test status
    location = './tests/test_utils_multipart.py'
    status = 206
    mime_type = None
    filename = 'test_utils_multipart.py'
    _range = Range(0,10,100)
    response = await file(location,status,mime_type,filename,_range)
   

# Generated at 2022-06-22 15:13:32.146028
# Unit test for function file_stream
def test_file_stream():
    @app.route('/')
    async def test(request: Request) -> StreamingHTTPResponse:
        return await file_stream('/tmp/testfile', chunk_size=4096)

    server = app.create_server(host='0.0.0.0')
    r = loop.run_until_complete(server)

# Generated at 2022-06-22 15:13:41.062340
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    assert True



# Generated at 2022-06-22 15:13:52.016897
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
  tx = HTTPRequest(
      SocketProtocol(~0, ~0, '/tmp'),
      'POST',
      '/',
      'HTTP/1.1',
      Headers({'aa': 'bb'}),
      False,
      False,
      None,
      'remote_addr',
      'scheme'
      'body'
  )
  stream = SanicASGIRequest(tx, 'localhost', '80', 'POST', '/', 'HTTP/1.1', {}, [])
  response = HTTPResponse('Hello')
  # Test if the response is an instance of BaseHTTPResponse
  assert isinstance(response, BaseHTTPResponse)
  # Test if the body is not empty
  assert response.body != None
  # Test if the content type is set
  assert response.content_type

# Generated at 2022-06-22 15:13:54.711350
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    coro = BaseHTTPResponse().send()
    coro.send(None)
    coro.throw(None)
    coro.close()


# Generated at 2022-06-22 15:14:04.690253
# Unit test for function file

# Generated at 2022-06-22 15:14:05.997025
# Unit test for function stream
def test_stream():
    @app.post("/")
    async def test(request):
        return stream(sample_streaming_fn, content_type='text/plain')


# Generated at 2022-06-22 15:14:11.126407
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # Initialize mock objects


    # Call method
    http_response = StreamingHTTPResponse()
    result = http_response.send(
        data=None, end_stream=None,
    )

    # Check result
    assert result == None


# Generated at 2022-06-22 15:14:21.095107
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from asyncio import sleep, new_event_loop
    from io import BytesIO
    from unittest.mock import patch

    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request

    request = Request(
        None, "GET", "/", headers={"CONTENT_TYPE": "application/json"}
    )
    request.stream = request.body = BytesIO(b"foo")

    @patch("sanic.response.streaming_fn")
    def test_http_response_streaming_fn(mocked_streaming_fn):
        mocked_streaming_fn.return_value = sleep(1)
        resp = StreamingHTTPResponse(mocked_streaming_fn)

# Generated at 2022-06-22 15:14:29.839598
# Unit test for function file_stream
def test_file_stream():
    import sys
    import os
    new_path = os.path.dirname(os.path.abspath(__file__))+"/../"
    sys.path.append(new_path)
    loc = new_path+'/tests/test_data/test_pdf.pdf'
    async def test_file_stream():
        res = await file_stream(loc, status=200, chunk_size=512)
        assert res.content_type == "application/pdf"
        assert res.status == 200
    import asyncio
    loop = asyncio.new_event_loop()
    loop.run_until_complete(test_file_stream())
    loop.close()



# Generated at 2022-06-22 15:14:30.902792
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    pass

    assert True



# Generated at 2022-06-22 15:14:36.057449
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from mock import Mock
    from sanic.response import StreamingHTTPResponse

    r = StreamingHTTPResponse(Mock())
    r.stream.send = Mock()
    r.write(b' test ')
    r.stream.send.assert_called_once_with(b' test ', False)

# Generated at 2022-06-22 15:14:57.340211
# Unit test for function file_stream
def test_file_stream():
    def _write_file(filename, size):
        with open(filename, "wb") as f:
            f.write(os.urandom(size))

    def _download_file(filename, url):
        try:
            with urlopen(url) as go:
                with open(filename, "wb") as f:
                    f.write(go.read())
        except Exception:
            pass

    def _compare(filename1, filename2):
        with open(filename1, "rb") as f1:
            with open(filename2, "rb") as f2:
                return f1.read() == f2.read()


# Generated at 2022-06-22 15:15:00.422496
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    stream = StreamingHTTPResponse(streaming_fn = None, status = 200, headers = None, content_type = "text/plain; charset=utf-8", chunked = "deprecated")
    assert stream.send() == None



# Generated at 2022-06-22 15:15:05.034121
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from typing import Optional
    from unittest.mock import Mock

    streaming_fn = Mock()
    r = StreamingHTTPResponse(streaming_fn)
    r.write("foo")
    streaming_fn.assert_called_with(r)
    assert r.streaming_fn is None


# Generated at 2022-06-22 15:15:17.934852
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import TestCase

    class test_StreamingHTTPResponse_write0(TestCase):
        def test(self):

            class obj:
                def __init__(self):
                    self._cookies = None
                    self.headers = Header({})
                    self.stream = None
                    self.body = None

            class attrs:
                def __init__(self):
                    self.send = None
                    pass
            setattr(obj, "stream", attrs())
            setattr(obj, "asgi", False)
            setattr(obj, "content_type", None)
            setattr(obj, "status", 200)
            StreamingHTTPResponse_write_object = StreamingHTTPResponse_write(obj)
            StreamingHTTPResponse_write_object.write(self)
           

# Generated at 2022-06-22 15:15:24.833465
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    url = "https://api.github.com/repos/channelcat/sanic/issues?state=closed"
    request, response = app.asgi_client.get(url)
    assert response.status == 200
    assert len(response.headers) == 11
    assert response.headers["Server"] == "GitHub.com"
    assert response.headers["Expires"] == "Sun, 09 Feb 2020 12:25:39 GMT"
    assert response.headers["ETag"] == 'W/"5e40f8e5-1460"'
    assert response.headers["Last-Modified"] == "Tue, 07 Jan 2020 22:55:41 GMT"
    assert response.headers["X-RateLimit-Limit"] == "5000"
    assert response.headers["X-RateLimit-Remaining"] == "4996"
    assert response.headers

# Generated at 2022-06-22 15:15:34.650196
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    response = StreamingHTTPResponse(
        streaming_fn=None,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
        chunked="deprecated",
    )
    stream = Http.Stream()
    response.stream = stream
    assert response.streaming_fn is None
    assert response.status == 200
    assert response.content_type == "text/plain; charset=utf-8"
    assert response.headers == {}
    assert response._cookies is None
    assert response._encode_body("haha") == b"haha"
    assert response.asgi == False
    assert response.body is None
    assert response.content_type == "text/plain; charset=utf-8"
    assert response.stream == stream

# Generated at 2022-06-22 15:15:44.359718
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.testing import SanicTestClient
    from sanic import Sanic
    from sanic.response import html,HTTPResponse,text
    app = Sanic(__name__)

    @app.route("/")
    async def test(request):
        return html('<b>await stream</b>')
    @app.route("/test")
    async def test2(request):
        response = HTTPResponse()
        response.body = 'test'
        response.status = 200
        await response.send(data=b'test data')
        return response


    request, response = SanicTestClient(app).get("/")
    assert response.status == 200
    assert response.text == '<b>await stream</b>'

# Generated at 2022-06-22 15:15:54.721188
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    class Http():
        def __init__(self):
            self.send = None
    obj = BaseHTTPResponse()
    obj.stream = Http()
    data = None
    end_stream = None
    assert obj.send(data, end_stream) is None
    data = 'sanic'
    end_stream = False
    assert obj.send(data, end_stream) is None
    data = 'sanic'
    end_stream = True
    assert obj.send(data, end_stream) is None
    data = ''
    end_stream = True
    assert obj.send(data, end_stream) is None
    data = ''
    end_stream = None
    assert obj.send(data, end_stream) is None
    data

# Generated at 2022-06-22 15:15:58.846476
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import mock

    response = StreamingHTTPResponse(None)
    response.send = mock.Mock()
    response.write(b"foobar")
    response.send.assert_called_with(b"foobar", False)



# Generated at 2022-06-22 15:16:06.422505
# Unit test for function file_stream
def test_file_stream():
    # Create the file to be used in the test
    import tempfile
    import os
    
    tf = tempfile.NamedTemporaryFile()
    try:
        tf_name = tf.name
        tf.write(b'\r\n'.join(b'Test line %d' % i for i in range(1000)))
        tf.seek(0)
        
        response = file_stream(tf_name)
        print(response.body)
    finally:
        tf.close()


# Generated at 2022-06-22 15:16:30.216586
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    response = StreamingHTTPResponse(None)
    response.content_type = "text/plain; charset=utf-8"
    response.headers = {}
    response.status = 200
    response._cookies = None
    response.stream = None
    response.write = StreamingHTTPResponse.write
    response.streaming_fn = None
    try:
        yield from response.write("")
        success()
    except Exception:
        fail()
test_StreamingHTTPResponse_write()

# Generated at 2022-06-22 15:16:34.791948
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    response = StreamingHTTPResponse(lambda x: 1, 200, {}, DEFAULT_HTTP_CONTENT_TYPE)
    assert response.streaming_fn(response) == 1
    assert response.content_type == DEFAULT_HTTP_CONTENT_TYPE
    assert response.status == 200
    assert response.headers == Header({})
    assert response._cookies == None


# Generated at 2022-06-22 15:16:46.011830
# Unit test for function file
def test_file():
    headers = {
        "Content-Disposition":"attachment; filename=\"test.txt\""
    }
    async def call_file(body, mime_type, status, headers):
        res = await file(body, mime_type, status, headers)
        return res
    loop = asyncio.get_event_loop()
    res = loop.run_until_complete(call_file("test.txt", "text/plain", 200, headers))
    assert res.status == 200
    assert res.headers.get("Content-Disposition") == "attachment; filename=\"test.txt\""
    assert res.body == None
    assert res.content_type == "text/plain"
    # test for file not exist

# Generated at 2022-06-22 15:16:51.317644
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return StreamingHTTPResponse(sample_streaming_fn)


# Generated at 2022-06-22 15:16:55.871565
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import stream, text

    async def streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def test(request):
        return stream(streaming_fn)

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.text == "foobar"


# Generated at 2022-06-22 15:17:07.555784
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    # this test is to ensure that the deprecated StreamingHTTPResponse
    # constructor does not get modified by accident.

    def streaming_fn1(response):
        return response

    def streaming_fn2(response, arg1, arg2, arg3):
        return arg1 + arg2 + arg3

    def streaming_fn3(response, *args):
        return len(args)

    response = StreamingHTTPResponse(streaming_fn1)
    assert response.streaming_fn(response) is response
    assert response.status == 200
    assert not response.headers
    assert response.content_type == "text/plain; charset=utf-8"

    response = StreamingHTTPResponse(streaming_fn1, headers=None)
    assert response.streaming_fn(response) is response
    assert response.status

# Generated at 2022-06-22 15:17:12.968595
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    import asynctest

    @asynctest.mock.patch("sanic.response.StreamingHTTPResponse.write")
    async def test(write_fn):
        response = StreamingHTTPResponse(None)
        await response.write("foo")
        write_fn.assert_called_once_with("foo")

# Generated at 2022-06-22 15:17:20.605197
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    response = BaseHTTPResponse()
    stream = Http()
    stream.send = asyncio.coroutine(lambda x: 0)
    response.stream = stream
    assert response.send is not None
    
    response1 = BaseHTTPResponse()
    response1.stream = stream
    assert response1.send is not None
    
    response2 = BaseHTTPResponse()
    response2.stream = stream
    assert response2.send is not None
    stream.send = None
    assert response2.send is None



# Generated at 2022-06-22 15:17:30.194413
# Unit test for function file_stream
def test_file_stream():
    import asyncio
    from os import getcwd
    from sanic.constants import DEFAULT_HEADERS
    from sanic.response import StreamingHTTPResponse

    assert file_stream('/tmp/b.log').status == 200
    assert file_stream('/tmp/b.log').headers == DEFAULT_HEADERS
    assert file_stream('/tmp/b.log').content_type == 'text/plain'
    assert file_stream('/tmp/b.log').body == ''

    assert file_stream('/tmp/b.log', status=400, filename='a.log').status == 400
    assert file_stream('/tmp/b.log', status=400, filename='a.log').headers == DEFAULT_HEADERS

# Generated at 2022-06-22 15:17:41.458530
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    import asyncio


    @asyncio.coroutine
    def mock_coro():
        pass


    mock_mock_coro = Mock(side_effect=mock_coro())
    with patch('sanic.response.StreamingHTTPResponse.streaming_fn') as mock_StreamingHTTPResponse_streaming_fn:
        mock_StreamingHTTPResponse_streaming_fn.return_value = mock_mock_coro

# Generated at 2022-06-22 15:18:17.957046
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import mock

    stream = mock.MagicMock()
    fn = mock.MagicMock()
    response = StreamingHTTPResponse(fn, stream=stream)
    response.write(b"foo")
    stream.send.assert_called_with(b"foo", end_stream=False)



# Generated at 2022-06-22 15:18:19.863517
# Unit test for function file
def test_file():
    f = file("/tmp/file", status=123, mime_type="abcd", headers={})



# Generated at 2022-06-22 15:18:23.039985
# Unit test for function file
def test_file():
    location = "/tmp/tempfile.txt"
    with open(location, mode="w") as outfile:
        outfile.write("test")

    response = asyncio.run(file(location))
    assert response.body == b"test"



# Generated at 2022-06-22 15:18:29.808141
# Unit test for function file_stream

# Generated at 2022-06-22 15:18:35.350950
# Unit test for function file_stream
def test_file_stream():
    """
    TEST: function file_stream
    """
    def test_streaming_fn(response):
        async def _streaming_fn(response):
            async with await open_async(location, mode="rb") as f:
                if _range:
                    await f.seek(_range.start)
                    to_send = _range.size
                    while to_send > 0:
                        content = await f.read(min((_range.size, chunk_size)))
                        if len(content) < 1:
                            break
                        to_send -= len(content)
                        await response.write(content)
                else:
                    while True:
                        content = await f.read(chunk_size)
                        if len(content) < 1:
                            break
                        await response.write(content)

    return StreamingHTTPResp

# Generated at 2022-06-22 15:18:45.216207
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.compat import b
    from sanic.response import HTTPResponse
    from sanic.streams import EMPTY_PAYLOAD
    import mock
    import pytest
    from sanic.compat import isawaitable

    @mock.patch.object(BaseHTTPResponse, 'send')
    def test(mock_method):
        HTTPResponse('foo', status=200)
        mock_method.assert_not_called()
        HTTPResponse('foo', status=200, headers=None)
        mock_method.assert_not_called()

        def async_mock(data=None, end_stream=None):
            assert data == (b('foo'), )
            assert end_stream is False
            return data

        mock_method.side_effect = async_m

# Generated at 2022-06-22 15:18:47.090713
# Unit test for function file_stream
def test_file_stream():
    #TODO
    pass


stream = StreamingHTTPResponse

# Generated at 2022-06-22 15:18:50.371373
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    dat = {'a':1,'b':2,'c':3}
    assert dumps(dat,separators=(',', ':')) == StreamingHTTPResponse._dumps(dat)

# Generated at 2022-06-22 15:18:57.131294
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    async def mock_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    async def test():
        return stream(mock_streaming_fn)

    # -- test-begin --
    response = test_run(test)
    body = test_read(response)
    assert body == b"foobar"
    # -- test-end --



# Generated at 2022-06-22 15:19:01.404452
# Unit test for function file
def test_file():
    async def test():
        import os.path
        current_path = os.path.abspath(os.path.dirname(__file__))
        file_ = os.path.join(current_path, "files", "sample.txt")
        await file(file_, filename="sample.txt")

    asyncio.run(test())



# Generated at 2022-06-22 15:21:23.735090
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # 1
    test_StreamingHTTPResponse_obj = StreamingHTTPResponse(None, None, None, None, None)
    test_StreamingHTTPResponse_obj.stream = None
    test_StreamingHTTPResponse_obj.streaming_fn = None
    test_assert_equal_list_list(list(), await test_StreamingHTTPResponse_obj.send())
    # 2
    test_StreamingHTTPResponse_obj = StreamingHTTPResponse(None, None, None, None, None)
    test_StreamingHTTPResponse_obj.stream = None
    test_StreamingHTTPResponse_obj.streaming_fn = None

# Generated at 2022-06-22 15:21:26.277982
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    stream_fn =  lambda response: response.write("foo")
    resp = StreamingHTTPResponse(stream_fn, 200)
    


# Generated at 2022-06-22 15:21:27.291130
# Unit test for function file_stream
def test_file_stream():
    async def test_coro():
        return await file_stream(location=__file__)

    assert run_sync(test_coro)



# Generated at 2022-06-22 15:21:36.772346
# Unit test for function file
def test_file():
    # Testing with a text file
    file1 = "./files/test_file_1.txt"
    file2 = "./files/test_file_2.txt"
    file3 = "./files/test_file_3.txt"

    # Make a request to get a text file, if the file is not found return a message
    response = await response.file(file1, status=404)
    assert response.status == 404
    assert response.body == b"File not found"

    response = await response.file(file2, status=404, filename="nice_file.txt")
    assert response.status == 404
    assert response.body == b"File not found"

    # Make a request to get a text file, if the file is found
    response = await response.file(file3, status=200)

# Generated at 2022-06-22 15:21:39.518016
# Unit test for function html
def test_html():
    body = "<html><head><title>test</title></head><body>test</body></html>"
    res = html(body, headers={"Content-Type": "text/html"})
    assert isinstance(res, HTTPResponse)
    assert isinstance(res.body, bytes)



# Generated at 2022-06-22 15:21:47.378854
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from types import SimpleNamespace
    from io import BytesIO
    from unittest.mock import patch

    from sanic.response import BaseHTTPResponse

    send_coro = AsyncMock()
    send_coro.return_value = None
    stream = SimpleNamespace()
    stream.send = send_coro

    async def _test_BaseHTTPResponse_send(
            data, end_stream, send_coro, expected_data, expected_end_stream):

        response = BaseHTTPResponse()
        response.stream = stream
        await response.send(data, end_stream)

        assert send_coro.await_count == 1
        call_args = send_coro.call_args
        args, kwargs = call_args

# Generated at 2022-06-22 15:21:53.085562
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse, StreamHTTPResponse

    from sanic.exceptions import abort
    app = Sanic(name="sanic-testing")

    @app.route("/")
    async def handler(request: Request) -> HTTPResponse:
        response = HTTPResponse(
            b"hello", headers={"content_type": "text/html"}, status=200
        )
        response.send(b"world", end_stream=False)
        response.send(None)
        return response
