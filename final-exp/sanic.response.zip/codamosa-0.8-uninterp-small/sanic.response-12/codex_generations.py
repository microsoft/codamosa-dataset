

# Generated at 2022-06-26 03:51:09.908762
# Unit test for function file
def test_file():
    file(location='True')
    file(location=True)
    file(location='True', status=200)
    file(location=True, status=200)
    file(location='True', status=200, mime_type="text/plain")
    file(location=True, status=200, mime_type="text/plain")
    file(location='True', status=200, mime_type="text/plain", headers={'key1': 'value1'})
    file(location=True, status=200, mime_type="text/plain", headers={'key1': 'value1'})
    file(location='True', status=200, mime_type="text/plain", headers={'key1': 'value1'}, filename="sources.txt")

# Generated at 2022-06-26 03:51:13.559700
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    base_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn, status=200, headers=None, content_type='text/plain; charset=utf-8', chunked='deprecated')
    # Call function send of base_h_t_t_p_response_0
    assert base_h_t_t_p_response_0.send(data=None, end_stream=None)


# Generated at 2022-06-26 03:51:26.408036
# Unit test for function file
def test_file():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    location = "welcome.html"
    status = 200
    mime_type = "text/html"
    filename = "welcome.html"
    h_t_t_p_response_0 = HTTPResponse(
        body=base_h_t_t_p_response_0.body,
        status=base_h_t_t_p_response_0.status,
        headers=base_h_t_t_p_response_0.headers,
        content_type=base_h_t_t_p_response_0.content_type
    )

# Generated at 2022-06-26 03:51:29.381319
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(sample_streaming_fn)
    data_0 = ""
    end_stream_0 = True
    streaming_h_t_t_p_response_0.send(data_0, end_stream_0)


# Generated at 2022-06-26 03:51:32.078751
# Unit test for function file
def test_file():
    location_0 = "/home/bhargav/ds18b20/data.txt"
    file(location_0)

if (__name__ == "__main__"):
    test_case_0()
    test_file()

# Generated at 2022-06-26 03:51:37.996952
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    result: Union[None] = base_h_t_t_p_response_0.send()
    assert result == None


# Generated at 2022-06-26 03:51:40.768198
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(base_h_t_t_p_response_0)
    streaming_h_t_t_p_response_0.write("test_value_0")


# Generated at 2022-06-26 03:51:51.545020
# Unit test for function file_stream
def test_file_stream():
    # Set variable(s)
    location = __file__
    mime_type = 'text/html'
    status = 200
    chunk_size = 1000
    headers = None
    filename = 'test_file_stream.py'
    chunked = 'deprecated'
    _range = None
    rv = file_stream(location, status, chunk_size, mime_type, headers, filename, chunked, _range)
    assert isinstance(rv, StreamingHTTPResponse)


# Generated at 2022-06-26 03:51:57.301372
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    asyc_obj_0 = StreamingHTTPResponse(streaming_fn=base_h_t_t_p_response_0.send)
    asyc_obj_0.write(data=None)

# Generated at 2022-06-26 03:52:05.066840
# Unit test for function file_stream
def test_file_stream():
    assert (
        file_stream("/tmp/sanic_app/static/js/app.32ee21b9.js", status=200, chunk_size=4096, mime_type=None, headers=None, filename="app.32ee21b9.js.map", chunked="deprecated").__class__.__name__ == "StreamingHTTPResponse"
    )
    try:
        test_case_0()
    except Exception:
        print("fail")
        return
    print("pass")


# Generated at 2022-06-26 03:52:17.639583
# Unit test for function file_stream
def test_file_stream():
    # Test cases
    filename = "test.txt"
    location="hw-testing/test.txt"
    headers = {"Content-Disposition": 'attachment; filename="test.txt"'}
    print(file_stream(location, filename=filename, headers =headers))


# Generated at 2022-06-26 03:52:33.843088
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # case 0:
    base_h_t_t_p_response_send_0 = BaseHTTPResponse()
    base_h_t_t_p_response_send_0.status = 204
    base_h_t_t_p_response_send_0.stream = None
    base_h_t_t_p_response_send_0.headers = Header({'content-type': 'text/plain', 'content-length': '0'})
    # assert base_h_t_t_p_response_send_0.send(data=None, end_stream=None) == None
    base_h_t_t_p_response_send_0.send(data=None, end_stream=None)
    # assert base_h_t_t_p_response_send_0.status ==

# Generated at 2022-06-26 03:52:40.669469
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    # variable assignment
    data = None
    end_stream = None
    # test body
    base_h_t_t_p_response_0.send(data, end_stream)



# Generated at 2022-06-26 03:52:44.960582
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    """
    Writes a chunk of data to the streaming response.
    """

    test_streaming_response = StreamingHTTPResponse(test_case_0)
    test_streaming_response.write("foo")

# Generated at 2022-06-26 03:52:55.234968
# Unit test for function file
def test_file():
    location = "./test_files/test.txt"
    test_file_0 = {
        "body": b"hello world\n",
        "content_type": "text/plain",
        "headers": {"Content-Disposition": 'attachment; filename="test.txt"'},
        "status": 200,
    }

    assert await file(location) == HTTPResponse(**test_file_0)


# Generated at 2022-06-26 03:52:57.990702
# Unit test for function json
def test_json():
    body = None
    status = 200
    headers = None
    content_type = "application/json"
    dumps = None
    json(body, status, headers, content_type, dumps)


# Generated at 2022-06-26 03:53:12.026560
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    base_h_t_t_p_response_0 = StreamingHTTPResponse()
    streaming_fn_0 = lambda response: response.send() #FIXME: lambda
    base_h_t_t_p_response_0.streaming_fn = streaming_fn_0
    base_h_t_t_p_response_0.status = 200
    base_h_t_t_p_response_0.headers = Header()
    base_h_t_t_p_response_0.content_type = "text/html; charset=utf-8"
    base_h_t_t_p_response_0.stream = None
    base_h_t_t_p_response_0.asgi = False
    base_h_t_t_p_response_0.body = None
   

# Generated at 2022-06-26 03:53:17.291135
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    streaming_h_t_t_p_response_1 = StreamingHTTPResponse(lambda *args, **kwargs: None)
    streaming_h_t_t_p_response_1.write(args[0])


# Generated at 2022-06-26 03:53:21.163523
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(base_h_t_t_p_response_0.send)
    streaming_h_t_t_p_response_0.write("")


# Generated at 2022-06-26 03:53:28.644612
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    data = None
    end_stream = None
    # Test for TypeError
    try:
        base_h_t_t_p_response_0.send(data, end_stream)
    except TypeError:
        pass


# Generated at 2022-06-26 03:53:49.174088
# Unit test for function json
def test_json():
    json_1_0 = json(object())


# Generated at 2022-06-26 03:53:58.058106
# Unit test for function file
def test_file():
    # TODO: Need to create the file "location" first, then remove it afterward
    # It is not really feasible to use a temporary file here, as it can be
    # opened in the same way by file(). Forcing the file to be created in
    # the tests folder is the next worst thing.
    location = path.join(path.dirname(__file__), "test")
    file_callable_0 = file(location)
    file_callable_1 = file(location, _range=None)
    file_callable_2 = file(location, status=0)
    file_callable_3 = file(location, mime_type="value")
    file_callable_4 = file(location, headers=None)
    file_callable_5 = file(location, filename="value")
    file_callable_6

# Generated at 2022-06-26 03:54:04.714321
# Unit test for function file
def test_file():
    location = "foo"
    status = 200
    mime_type = "foo"
    headers = {"foo": "foo", "bar": "foo", "baz": "foo"}
    filename = "foo"
    _range = Range("foo")
    test_case_0()
    file(location, status, mime_type, headers, filename, _range)




# Generated at 2022-06-26 03:54:14.278688
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    TEST_CASE_NUM = 0

    # Create mock objects
    request_0 = Http()

    # Generate mock response using AutoMock
    response_0 = request_0._respond()

    # Perform method under test
    response_0.stream.send = response_0._send
    response_0.stream.send('', False)
    response_0.stream.send('', True)

# Generated at 2022-06-26 03:54:16.992085
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    data = "arg1_1"
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(async_fn_fn)
    try:
        streaming_h_t_t_p_response_0.write(data)
    except Exception as ex:
        print(ex)


# Generated at 2022-06-26 03:54:25.192891
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)
    response = StreamingHTTPResponse(streaming_fn=sample_streaming_fn)
    response.send(data="None", end_stream=True)


# Generated at 2022-06-26 03:54:38.029518
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    http_0 = Http()
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn=None, status=200, headers=None, content_type="text/plain; charset=utf-8", chunked="deprecated")
    streaming_h_t_t_p_response_0.stream = http_0
    try:
        streaming_h_t_t_p_response_0.send(data=None, end_stream=None)
    except Exception as e:
        raise Exception(e.args)


# Generated at 2022-06-26 03:54:50.587591
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    base_h_t_t_p_response_0.status = 204
    base_h_t_t_p_response_0.headers = Header()
    base_h_t_t_p_response_0.headers.add_header('Pragma', 'no-cache')
    base_h_t_t_p_response_0.headers.add_header('Connection', 'keep-alive')
    base_h_t_t_p_response_0.headers.add_header('Cache-Control', 'no-cache, no-store, must-revalidate')
    base_h_t_t_p_response_0.headers.add_header('Server', 'nginx/1.12.2')
   

# Generated at 2022-06-26 03:54:54.339385
# Unit test for function stream
def test_stream():
    try:
        stream(streaming_fn = lambda : None)
    except:
        print("Test failed")


# Generated at 2022-06-26 03:55:03.796741
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    # Instantiating mock arguments
    global_print_0 = str
    global_print_1 = str
    global_print_2 = str

    async def async_global_print_0(msg):
        global_print_0(msg)
    global_print_0 = async_global_print_0
    async def async_global_print_1(msg):
        global_print_1(msg)
    global_print_1 = async_global_print_1
    async def async_global_print_2(msg):
        global_print_2(msg)
    global_print_2 = async_global_print_2

    # Instantiating mock object for BaseHTTPResponse
    base_h_t_t_p_response_0 = BaseHTTPResponse()

    # Instantiating mock object for Streaming

# Generated at 2022-06-26 03:55:33.094225
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    base_h_t_t_p_response_0.status = 200
    base_h_t_t_p_response_0.base_h_t_t_p_response_0_send_0 = await base_h_t_t_p_response_0.send("", True)


# Generated at 2022-06-26 03:55:36.118497
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base = BaseHTTPResponse()
    # test args
    data = ""
    end_stream = False
    # return value
    assert base.send(data,end_stream) == None



# Generated at 2022-06-26 03:55:45.339535
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Setup
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    data = None
    end_stream = None
    expected = None

    # Testing
    base_h_t_t_p_response_0.send(data, end_stream)
    # verify results



# Generated at 2022-06-26 03:55:50.751180
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    base_h_t_t_p_response_0 = StreamingHTTPResponse( lambda : None )
    base_h_t_t_p_response_0.stream = Http()
    base_h_t_t_p_response_0.stream.send = asyncio.coroutine(lambda data, end_stream: None)

    base_h_t_t_p_response_0.send(None, None)


# Generated at 2022-06-26 03:55:59.372734
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn=sample_streaming_fn)
    data = None
    # This should work, but it results in:
    # TypeError: 'NoneType' object is not callable
    # await streaming_h_t_t_p_response_0.send(data)

# Generated at 2022-06-26 03:56:03.824008
# Unit test for function json

# Generated at 2022-06-26 03:56:13.717612
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_1 = BaseHTTPResponse()
    data = None
    end_stream = None
    test_0 = base_h_t_t_p_response_1.stream.send
    if ( test_0 ):
        if (end_stream):
            if not data:
                return
    data = (
            data.encode()  # type: ignore
            if hasattr(data, "encode")
            else data or b""
        )
    async def test_f_1(data: bytes, end_stream: bool):
        return
    test_f_1(data,end_stream)



# Generated at 2022-06-26 03:56:15.363784
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    assert 0 < await StreamingHTTPResponse.send()



# Generated at 2022-06-26 03:56:21.702288
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return stream(sample_streaming_fn)


# Generated at 2022-06-26 03:56:27.626791
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    # Testing a method of a class is no problem. woot.
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(None, None, None, None, None)
    # There is no reason to test this method. It is not a linear code.
    streaming_h_t_t_p_response_0.write(None)

# Generated at 2022-06-26 03:56:51.916471
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Declare the arguments
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    data = 10
    end_stream = 10
    # Invoke method
    base_h_t_t_p_response_0.send(data, end_stream)


# Generated at 2022-06-26 03:56:59.242580
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # The code to test must set the following global variables.
    global call_count

    call_count = 0
    def streaming_fn_0(response: BaseHTTPResponse):
        global call_count
        call_count += 1
        
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn_0)
    streaming_h_t_t_p_response_0.send('foo', True)
    assert call_count == 1

# Generated at 2022-06-26 03:57:02.135862
# Unit test for function stream
def test_stream():
    streaming_function = streaming_function = lambda response: None
    status = 200
    headers = None
    content_type = 'text/plain'
    chunked = 'deprecated'
    stream(streaming_function, status, headers, content_type, chunked)

# Generated at 2022-06-26 03:57:14.602605
# Unit test for function file
def test_file():
    async def coroutine_0():
        await file(location = 'location')
    def mock_open(mode = None):
        async def coroutine_1():
            return f
        return coroutine_1
    patch_object(builtins, 'open', mock_open)
    f = mock.Mock
    f.seek = mock.MagicMock()
    f.read = mock.MagicMock()
    f.__aenter__ = mock.MagicMock()
    f.__aexit__ = mock.MagicMock()
    f.__aenter__.return_value = f
    try:
        asyncio.run(coroutine_0())
    except Exception as e:
        assert False

# Generated at 2022-06-26 03:57:17.133448
# Unit test for function file_stream
def test_file_stream():
    assert any(file_stream() for _ in range(10))


# Generated at 2022-06-26 03:57:24.748909
# Unit test for function file_stream
def test_file_stream():
    def fun_0(self):
        self.stream.send = fun_1

    def fun_1(self, *args, **kwargs):
        self.dummy_0 = 1

    base_h_t_t_p_response_0 = BaseHTTPResponse()
    base_h_t_t_p_response_0.__class__.send = fun_0
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(
        streaming_fn=base_h_t_t_p_response_0.dummy_0
    )
    streaming_h_t_t_p_response_0.send("", True)

# Generated at 2022-06-26 03:57:37.597050
# Unit test for function file

# Generated at 2022-06-26 03:57:40.409321
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    base_h_t_t_p_response_0.send()


# Generated at 2022-06-26 03:57:45.002256
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    def streaming_fn(response):
        pass
    s_h_t_t_p_r_0 = StreamingHTTPResponse(streaming_fn)
    s_h_t_t_p_r_0.send()


# Generated at 2022-06-26 03:57:54.102506
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    def sample_streaming_fn(response):
        response.send('foo', False)
        response.send('bar', False)
        response.send('', True)

    base_h_t_t_p_response_1 = StreamingHTTPResponse(sample_streaming_fn)
    base_h_t_t_p_response_1.send('foo', False)
    base_h_t_t_p_response_1.send('bar', False)
    base_h_t_t_p_response_1.send('', True)



# Generated at 2022-06-26 03:58:39.564530
# Unit test for function file_stream
def test_file_stream():
    location = "location"
    status = 200
    chunk_size = 4096
    chunked = "deprecated"

    # Call function to init return object
    return_object = file_stream(location, status, chunk_size, chunked)

    # Test return type and return object
    assert isinstance(return_object, StreamingHTTPResponse), (
        f"Expected {type(StreamingHTTPResponse)}, "
        f"but returned {type(return_object)}"
    )


# Generated at 2022-06-26 03:58:42.780937
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(sample_streaming_fn)
    streaming_h_t_t_p_response_0.write(0)


# Generated at 2022-06-26 03:58:54.954048
# Unit test for function file_stream
def test_file_stream():
    mime_type = "text/plain"
    chunk_size = 4096
    location = "testcase/filename"
    status = 200
    headers = {}
    filename = "filename"
    _range = None
    def _streaming_fn(response):
        print(response)
    _streaming_ht_t_p_response_1 = StreamingHTTPResponse(streaming_fn = _streaming_fn, status = status, headers = headers, content_type = mime_type)
    streaming_ht_t_p_response_1 = _streaming_ht_t_p_response_1
    # Expected: StreamingHTTPResponse(streaming_fn = _streaming_fn, status = status, headers = headers, content_type = mime_type)
    

# Generated at 2022-06-26 03:59:06.416293
# Unit test for function file_stream
def test_file_stream():

    # Create instances of mock class
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    base_h_t_t_p_response_1 = BaseHTTPResponse()
    base_h_t_t_p_response_2 = BaseHTTPResponse()
    base_h_t_t_p_response_3 = BaseHTTPResponse()
    base_h_t_t_p_response_4 = BaseHTTPResponse()
    base_h_t_t_p_response_5 = BaseHTTPResponse()
    base_h_t_t_p_response_6 = BaseHTTPResponse()
    base_h_t_t_p_response_7 = BaseHTTPResponse()
    base_h_t_

# Generated at 2022-06-26 03:59:16.923801
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():

    # Assume that class StreamingHTTPResponse has been initialized with the following values
    streaming_ht_t_p_response_streaming_fn = lambda a: 0
    streaming_ht_t_p_response_status = 200
    streaming_ht_t_p_response_headers = {}
    streaming_ht_t_p_response_content_type = "text/plain; charset=utf-8"
    streaming_ht_t_p_response_chunked = "deprecated"


# Generated at 2022-06-26 03:59:19.097892
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    response_1 = StreamingHTTPResponse
    response_1.write("")
    return response_1


# Generated at 2022-06-26 03:59:23.814587
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    try:
        streaming_h_t_t_p_response_0 = StreamingHTTPResponse(lambda: 0)
        streaming_h_t_t_p_response_0.send(end_stream=False)
    except (UnboundLocalError, AttributeError):
        pass


# Generated at 2022-06-26 03:59:36.319674
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    base_h_t_t_p_response_0.stream = Http()
    base_h_t_t_p_response_0.content_type = 'text/html'
    base_h_t_t_p_response_0.status = 200
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(base_h_t_t_p_response_0.streaming_fn, 200,base_h_t_t_p_response_0.headers,base_h_t_t_p_response_0.content_type,base_h_t_t_p_response_0.chunked)

# Generated at 2022-06-26 03:59:43.533803
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    data = None
    end_stream = None
    # Case 1
    if data is None and end_stream is None:
        end_stream = True
    # Case 2
    if end_stream and not data and not base_h_t_t_p_response_0.stream.send:
        pass
    # Case 3
    if hasattr(data, "encode"):
        data = data.encode()
    else:
        data = data or b""


# Generated at 2022-06-26 03:59:53.079888
# Unit test for function file
def test_file():
    # Test for function file
    headers = {}
    mime_type = "text/plain"
    filename = ""
    location = "text.txt"
    headers = headers or {}
    if filename:
        headers.setdefault("Content-Disposition", f'attachment; filename="{filename}"')
    filename = filename or path.split(location)[-1]
    mime_type = mime_type or guess_type(filename)[0] or "text/plain"
    assert mime_type == "text/plain"
