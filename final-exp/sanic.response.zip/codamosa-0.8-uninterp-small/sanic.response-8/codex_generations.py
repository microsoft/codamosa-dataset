

# Generated at 2022-06-26 03:50:56.222517
# Unit test for function html
def test_html():
    body = 'ssss'
    status = 200 
    headers = dict() 
    result = HTTPResponse(  # type: ignore
        body,
        status=status,
        headers=headers,
        content_type="text/html; charset=utf-8",
    )


# Generated at 2022-06-26 03:50:59.459856
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    pass


# Generated at 2022-06-26 03:51:05.661079
# Unit test for function file
def test_file():
    out_stream = None
    headers = {}
    location = "location"
    mime_type = "mime_type"
    _range = Range(10, 10, 20)
    filename = "filename"
    file(location, _range=_range, headers=headers, mime_type=mime_type, filename=filename)


# Generated at 2022-06-26 03:51:18.239018
# Unit test for function file_stream
def test_file_stream():
    # Create test file.
    with open('test_file.txt', mode='w+') as f_1:
        f_1.write('This is a test file.')
    
    # Initializes function with test data
    location = 'test_file.txt'
    status = 200
    chunk_size = 4096
    mime_type = None
    headers = {}
    filename = 'test_file.txt'
    _range = None
    (output_1, output_2) = file_stream(location, status, 
        chunk_size, mime_type, headers, filename, _range)

    # Asserts the output is equal to a specified class
    assert type(output_1) == StreamingHTTPResponse
    assert type(output_2) == StreamingHTTPResponse

    # Closes test file,

# Generated at 2022-06-26 03:51:20.372543
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn=None, status=200, headers=None, content_type='text/plain; charset=utf-8', chunked='deprecated')


# Generated at 2022-06-26 03:51:28.110585
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response = BaseHTTPResponse()
    input_0 = asyncio.Future()
    input_1 = asyncio.Future()
    base_h_t_t_p_response.stream = Http(input_0)
    input_1 = None
    asyncio.get_event_loop().run_until_complete(base_h_t_t_p_response.send(input_1))


# Generated at 2022-06-26 03:51:37.734236
# Unit test for function file_stream
def test_file_stream():
    location = "filename"
    status = 200
    chunk_size = 4096
    mime_type = None
    headers = None
    filename = None
    chunked = None
    _range = None

    file_stream(location, status, chunk_size, mime_type, headers, filename, chunked, _range)


if __name__ == "__main__":
    test_file_stream()

# Generated at 2022-06-26 03:51:44.303705
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    # Method of class StreamingHTTPResponse
    # test_case_0
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(base_h_t_t_p_response_0)
    streaming_h_t_t_p_response_0.write("This is a test")
    assert streaming_h_t_t_p_response_0 == streaming_h_t_t_p_response_0

# Generated at 2022-06-26 03:51:51.375189
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(None, None, None, None, None)
    streaming_h_t_t_p_response_0.write("foo")
    streaming_h_t_t_p_response_0.write(None)



# Generated at 2022-06-26 03:52:02.295676
# Unit test for function html
def test_html():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    h_t_t_p_response_0 = HTTPResponse(
        headers=None,
        status=200,
        content_type="text/html; charset=utf-8",
        body=b"<!DOCTYPE html>"
    )
    assert h_t_t_p_response_0 == html(b"<!DOCTYPE html>")


# Generated at 2022-06-26 03:52:20.793178
# Unit test for function file
def test_file():
    location = ""
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    file(location, status, mime_type, headers, filename, _range)


# Generated at 2022-06-26 03:52:24.953866
# Unit test for function file_stream
def test_file_stream():
    location = "D3V4L3NhbXBsZS5qcw=="
    status = 0
    chunk_size = 3
    mime_type = "text/plain"
    headers = {"headers": "headers"}
    filename = "D3V4L3NhbXBsZS5qcw=="
    chunked = "deprecated"
    _range = 3
    # AssertionError: 'asyncio.StreamWriter' object has no attribute 'write'
    file_stream(location, status, chunk_size, mime_type, headers, filename, chunked, _range)


# Generated at 2022-06-26 03:52:31.586820
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_fn = StreamingFunction
    status = 200
    headers = None
    content_type = 'text/plain; charset=utf-8'
    chunked = 'deprecated'
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn, status, headers, content_type, chunked)


# Generated at 2022-06-26 03:52:40.015612
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    end_stream = None
    #data is None
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    base_h_t_t_p_response_0.asgi = False
    base_h_t_t_p_response_0.body = None
    base_h_t_t_p_response_0.content_type = None
    base_h_t_t_p_response_0.stream = None
    base_h_t_t_p_response_0.status = None
    base_h_t_t_p_response_0.headers = None
    base_h_t_t_p_response_0._cookies = None
    base_h_t_t_p_response_0.stream.send = None
    base_h_

# Generated at 2022-06-26 03:52:43.686708
# Unit test for function file
def test_file():
    file_0 = file(location=None, status=200, mime_type=None, headers=None, filename=None, _range=None)

# Generated at 2022-06-26 03:52:49.588244
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    # Class StreamingHTTPResponse has an attr streaming_fn of type StreamingFunction, which is not tested.
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn=None, status=200, headers=None, content_type='text/plain; charset=utf-8', chunked=deprecated)

    # Invoke method write on streaming_h_t_t_p_response_0
    streaming_h_t_t_p_response_0.write()


# Generated at 2022-06-26 03:52:50.387557
# Unit test for function file_stream
def test_file_stream():
    assert callable(file_stream)


# Generated at 2022-06-26 03:52:57.164713
# Unit test for function html
def test_html():
    test_body = "Hello world"
    test_status = 200
    test_html = html(test_body, test_status)
    assert test_html.body.decode() == test_body
    assert test_html.status == test_status
    assert test_html.content_type == "text/html; charset=utf-8"


blob = raw



# Generated at 2022-06-26 03:53:09.068926
# Unit test for function html
def test_html():
    test_case_0()
    # Initialization
    body : str = 'random_string'
    status : int = 200
    headers : Optional[Dict[str, str]] = None
    # Test function
    out = html(body, status, headers)
    # Verification
    assert out is not None
    assert isinstance(out, HTTPResponse)
    assert out.body == body.encode()
    assert out.status == status
    assert out.content_type == 'text/html; charset=utf-8'
    assert out.headers == Header(headers or {})


# Generated at 2022-06-26 03:53:13.554634
# Unit test for function file_stream
def test_file_stream():
    location = ""
    status = 0

    # Return type assertion
    assert isinstance(file_stream(location, status), StreamingHTTPResponse)


# Generated at 2022-06-26 03:53:38.569912
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    print("\n\nMethod: send of class BaseHTTPResponse")
    # construct object
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    # initialize object
    test_case_0()
    # set method params
    data = None
    end_stream = None
    # call send method
    base_h_t_t_p_response_0.send(data, end_stream)



# Generated at 2022-06-26 03:53:45.157109
# Unit test for function file_stream
def test_file_stream():
    l_o_c_a_t_i_o_n_0 = "some location"
    s_t_a_t_u_s_0 = 100
    c_h_u_n_k_s_i_z_e_0 = 1000
    m_i_m_e_t_y_p_e_0 = "some mime_type"
    h_e_a_d_e_r_s_0 = {"some": "headers"}
    f_i_l_e_n_a_m_e_0 = "some filename"
    c_h_u_n_k_e_d_0 = "some chunked"
    _r_a_n_g_e_0 = Range(100, 200)
    
    # Test StreamHTTPResponse creation

# Generated at 2022-06-26 03:53:48.126464
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    base_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn=StreamingFunction(), status=int('hello'), headers={}, content_type='', chunked='deprecated')
    base_h_t_t_p_response_0.write(data='hello')


# Generated at 2022-06-26 03:53:51.339516
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    base_h_t_t_p_response_0 = StreamingHTTPResponse()
    status_0 = 202
    headers_0 = dict({})
    content_type_0 = 'text/plain; charset=utf-8'
    base_h_t_t_p_response_0.send(status_0, headers_0, content_type_0)



# Generated at 2022-06-26 03:53:59.541833
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(sample_streaming_fn)
    streaming_h_t_t_p_response_0.write("content a")
    streaming_h_t_t_p_response_0.write("content b")
    streaming_h_t_t_p_response_0.write("content c")


# Generated at 2022-06-26 03:54:08.442383
# Unit test for function file
def test_file():
    import socket
    import os

    def bind_socket(address, backlog=100):
        so = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        so.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        so.bind(address)
        so.listen(backlog)
        return so

    from unittest.mock import patch
    from sanic.http import HttpConnection

    def server(request):
        __tracebackhide__ = True

        assert request.get("uri") == "/"

        # The only thing we want to test is that the headers are
        # correctly set when sending a file, so doing nothing here
        # is enough
        pass


# Generated at 2022-06-26 03:54:14.941440
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse()
    streaming_h_t_t_p_response_0.streaming_fn = 'example'
    streaming_h_t_t_p_response_0.write('example')


# Generated at 2022-06-26 03:54:25.270564
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():

    async def sample_streaming_fn(response):
        response.write("foo")
        await asyncio.sleep(1)
        response.write("bar")
        await asyncio.sleep(1)

    streaming_h_t_t_p_response_streaming_fn = StreamingHTTPResponse(sample_streaming_fn)
    streaming_h_t_t_p_response_streaming_fn.write("get_factory")


# Generated at 2022-06-26 03:54:28.124728
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    assert ((base_h_t_t_p_response_0.send("str", True) == None))


# Generated at 2022-06-26 03:54:34.681068
# Unit test for function file_stream
def test_file_stream():
    import unittest
    import io
    from unittest.mock import patch
    from tempfile import TemporaryFile
    import pathlib

    def encode(s):
        return s.encode()

    class TestStreamingHTTPResponse(unittest.TestCase):
        def setUp(self):
            self.response = StreamingHTTPResponse(None, None)

        def test_content_type(self):
            self.assertEqual(self.response.content_type, "text/plain; charset=utf-8")

        def test_status(self):
            self.assertEqual(self.response.status, 200)

        def test_headers(self):
            self.assertEqual(self.response.headers, {})


# Generated at 2022-06-26 03:54:57.417984
# Unit test for function file
def test_file():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    test_case_0()



# Generated at 2022-06-26 03:55:04.618805
# Unit test for function file_stream
def test_file_stream():
    location = 'test_file_stream.txt'
    chunk_size = 4096
    test_file = open(location,'w')
    test_file.write('test_file_stream.txt')
    test_file.close()

    async def _streaming_fn(response):
        async with await open_async(location, mode="rb") as f:
            while True:
                content = await f.read(chunk_size)
                if len(content) < 1:
                    break
                await response.write(content)
    response = StreamingHTTPResponse(streaming_fn=_streaming_fn, status=200, headers=None, content_type='text/plain; charset=utf-8')
    future = asyncio.ensure_future(response.send())

# Generated at 2022-06-26 03:55:11.066164
# Unit test for function file_stream
def test_file_stream():
    location = "tests/test_data/test_cookie_jar.json"
    chunk_size = 4096
    mime_type = None
    headers = None
    filename = None
    chunked = "deprecated"
    _range = None
    file_stream(location, chunk_size, mime_type, headers, filename, chunked, _range)


# Generated at 2022-06-26 03:55:18.039446
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(lambda x: x)
    streaming_h_t_t_p_response_0.send("foo")



# Generated at 2022-06-26 03:55:25.391632
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    """
    .. code-block:: python

        async def sample_streaming_fn(response):
            await response.write("foo")
            await asyncio.sleep(1)
            await response.write("bar")
            await asyncio.sleep(1)

        @app.post("/")
        async def test(request):
            return stream(sample_streaming_fn)
    """
    def sample_streaming_fn(response):
        return response.write("foo")


# Generated at 2022-06-26 03:55:36.709352
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    data_string_0 = "string0123456789"

    # Test case where data != None + end_stream != None,
    # and data is a String + end_stream is a bool

    base_h_t_t_p_response_0.send(data_string_0, end_stream=True)
    base_h_t_t_p_response_0.send(data_string_0, end_stream=False)



# Generated at 2022-06-26 03:55:42.602548
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    def sample_streaming_fn(response):
        asyncio.sleep(1)
    
    return stream(sample_streaming_fn).write()



# Generated at 2022-06-26 03:55:46.461719
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    # TODO: improve the test case
    assert True

test_case_0()
test_StreamingHTTPResponse_write()

# Generated at 2022-06-26 03:55:47.197709
# Unit test for function file_stream
def test_file_stream():
    assert True


# Generated at 2022-06-26 03:55:50.697235
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write(): 
    streaming_h_t_t_p_response_3 = StreamingHTTPResponse(streaming_fn, status, headers, content_type)
    streaming_h_t_t_p_response_3.write(data)


# Generated at 2022-06-26 03:56:38.440534
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    def sample_streaming_fn(response):
        pass

    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(sample_streaming_fn)
    # Function that returns a Coroutine[Any, Any, None] that is actually
    # implemented as awaitable and wrapping a Future[None] object
    def test_send() -> Coroutine[Any, Any, None]:
        streaming_h_t_t_p_response_0.stream = streaming_h_t_t_p_response_0
        # send the data
        coroutine_0 = streaming_h_t_t_p_response_0.send()
        # Wait for the coroutine to terminate
        coroutine_0.send(None)
    test_send()


# Generated at 2022-06-26 03:56:46.762671
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_f_n_0 = lambda base_h_t_t_p_response_0, data, end_stream: None
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_f_n_0)
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    #
    #
    streaming_h_t_t_p_response_0.stream = base_h_t_t_p_response_0
    streaming_h_t_t_p_response_0.status = 200
    streaming_h_t_t_p_response_0.content_type = "application/json"
    #
    streaming_h_t_t_p_response_0.headers = ["foo", "bar"]
    #
   

# Generated at 2022-06-26 03:56:55.981052
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # Setup
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse()
    streaming_h_t_t_p_response_0.stream = Http()
    streaming_h_t_t_p_response_0.stream.send = (lambda *args, **kwargs: None)
    streaming_h_t_t_p_response_0.stream.send_headers = (lambda *args, **kwargs: None)

    # Unit test
    streaming_h_t_t_p_response_0.send(None, True)



# Generated at 2022-06-26 03:57:03.943314
# Unit test for function file_stream
def test_file_stream():
    location = path.join(path.abspath(path.dirname(__file__)), 'hello-world.txt')
    chunk_size = 4096
    mime_type = None
    headers = None
    filename = 'hello-world.txt'
    chunked = "deprecated"
    status = 200
    _range = None
    base_h_t_t_p_response_0 = file_stream(location, status, chunk_size, mime_type, headers, filename, chunked, _range)
    assert(base_h_t_t_p_response_0.status == 200)
    assert(base_h_t_t_p_response_0.content_type == 'text/plain')

# Generated at 2022-06-26 03:57:14.218498
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(lambda x : asyncio.sleep(1000), status = 200, content_type = "text/plain; charset=utf-8")
    streaming_h_t_t_p_response_0.stream = Http()
    streaming_h_t_t_p_response_0.stream.send = lambda x, y : asyncio.sleep(1000)
    asyncio.run(streaming_h_t_t_p_response_0.send("cNy1aL", True))


# Generated at 2022-06-26 03:57:20.004158
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():

    expected_result = None

    base_h_t_t_p_response_0 = BaseHTTPResponse()
    data = None
    end_stream = None
    result = base_h_t_t_p_response_0.send(data, end_stream)

    assert result == expected_result

# Generated at 2022-06-26 03:57:31.265836
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Create an instance of BaseHTTPResponse
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    # Create an instance of StreamHttpProtocol
    stream_h_t_t_p_protocol_0 = StreamHttpProtocol()
    # Set attribute 'stream' of 'BaseHTTPResponse' instance to 'stream_h_t_t_p_protocol_0'
    base_h_t_t_p_response_0.stream = stream_h_t_t_p_protocol_0
    # Unit test for method send
    base_h_t_t_p_response_0.send(None, True)



# Generated at 2022-06-26 03:57:36.264618
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # Setup
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(lambda : None)

    # Target
    await streaming_h_t_t_p_response_0.send()



# Generated at 2022-06-26 03:57:44.411230
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn=(lambda b_h_t_t_p_response_0: b_h_t_t_p_response_0.send(data="a", end_stream=False)), headers=None, chunked="deprecated")
    # assert streaming_h_t_t_p_response_0.send() == None
    streaming_h_t_t_p_response_1 = StreamingHTTPResponse(streaming_fn=None, headers=None, chunked="deprecated")
    streaming_h_t_t_p_response_1.stream = Mock()
    # assert streaming_h_t_t_p_response_1.send() == None


# Generated at 2022-06-26 03:57:46.037144
# Unit test for function file_stream
def test_file_stream():
    assert file_stream("text.txt") is not None


# Generated at 2022-06-26 03:59:03.307626
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():

    """
    Test case for method StreamingHTTPResponse.write is generated during
    runtime for each invocation of the method.
    """

    pass

# Generated at 2022-06-26 03:59:11.176416
# Unit test for function file
def test_file():
    sample_location = "/tmp/sample.txt"
    sample_mime_type = "text/html"
    sample_headers = Header({})
    sample_filename = "sample.txt"
    sample_range = {"start": 0, "end": 1, "total": 2}
    sample_status = 500
    file(location=sample_location, mime_type=sample_mime_type, headers=sample_headers, filename=sample_filename, _range=sample_range, status=sample_status)
    assert True


# Generated at 2022-06-26 03:59:19.708970
# Unit test for function file
def test_file():
    location = 'location'
    mime_type = 'mime_type'
    headers = dict()
    filename = 'filename'
    _range = None
    filename = filename
    headers['Content-Type'] = 'text/plain; charset=utf-8'
    header_content_type = headers['Content-Type']
    content_type = header_content_type
    headers['Content-Type'] = 'text/plain; charset=utf-8'
    header_content_type = headers['Content-Type']
    content_type = header_content_type
    headers['Content-Type'] = 'text/plain; charset=utf-8'
    header_content_type = headers['Content-Type']
    content_type = header_content_type

# Generated at 2022-06-26 03:59:23.610392
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    data = None
    end_stream = None
    base_h_t_t_p_response_0.send(data, end_stream)


# Generated at 2022-06-26 03:59:31.789656
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(test_StreamingHTTPResponse_write)
    streaming_h_t_t_p_response_0._encode_body(streaming_h_t_t_p_response_0)
    streaming_h_t_t_p_response_0.write(streaming_h_t_t_p_response_0)



# Generated at 2022-06-26 03:59:36.987272
# Unit test for function html
def test_html():
    # set up
    body = "body"
    expected = b"<html><head></head><body>body</body></html>\n"
    response = html(body)
    # execution
    actual = response.body
    # test
    assert actual == expected



# Generated at 2022-06-26 03:59:45.610461
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    status = 200
    headers = None
    content_type = "text/plain; charset=utf-8"
    chunked = "deprecated"
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_h_t_t_p_response_0, status, headers, content_type, chunked)
    data = None
    end_stream = None
    if data is None and end_stream is None:
        end_stream = True
    if end_stream and not data and streaming_h_t_t_p_response_0.stream.send is None:
        return
    data = (
        data.encode()  # type: ignore
        if hasattr(data, "encode")
        else data or b""
    )
    streaming_h_t_t_

# Generated at 2022-06-26 03:59:52.608645
# Unit test for function file
def test_file():
    location_0 = PurePath(quote_plus("test_case_0"))
    status_0 = 200
    mime_type_0 = None
    headers_0 = None
    filename_0 = None
    _range_0 = None
    file(location_0, status_0, mime_type_0, headers_0, filename_0, _range_0)

# Generated at 2022-06-26 03:59:54.265890
# Unit test for function file
def test_file():
    file("test", 200, "text/plain", {}, "test")


# Generated at 2022-06-26 04:00:03.830942
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse()
    streaming_h_t_t_p_response_0.stream = None
    streaming_h_t_t_p_response_0.status = 500
    streaming_h_t_t_p_response_0.content_type = None
    streaming_h_t_t_p_response_0.headers = None
    streaming_h_t_t_p_response_0._cookies = None
    streaming_h_t_t_p_response_0.streaming_fn = None
    streaming_h_t_t_p_response_0.send()
