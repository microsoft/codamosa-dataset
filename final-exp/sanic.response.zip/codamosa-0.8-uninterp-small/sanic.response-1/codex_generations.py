

# Generated at 2022-06-26 03:51:02.706180
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    streaming_fn = StreamingHTTPResponse.__init__
    callable_0 = streaming_fn(streaming_fn, int())
    var_0 = callable_0.write(str())



# Generated at 2022-06-26 03:51:07.134645
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():

    # Dummy variables for callable's arguments
    callable_0 = None
    var_1 = ""
    var_2 = ""

    with pytest.raises(TypeError):
        var_0 = StreamingHTTPResponse(callable_0)
        var_0.send(var_1, var_2)



# Generated at 2022-06-26 03:51:09.838497
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    callable_0 = None
    var_0 = StreamingHTTPResponse(callable_0)


# Generated at 2022-06-26 03:51:12.775770
# Unit test for function json
def test_json():
    var_0 = 3
    var_1 = 200
    var_2 = None
    var_3 = "application/json"
    var_4 = None
    var_5 = None
    var_6 = json(var_0, var_1, var_2, var_3, var_4, var_5)


# Generated at 2022-06-26 03:51:24.752573
# Unit test for function file
def test_file():
    str_0 = ""
    str_1 = "filename"
    str_2 = "text/plain"
    int_0 = 0
    dict_0 = dict()
    dict_0["range"] = int_0
    dict_0["mime_type"] = str_2
    dict_0["headers"] = dict_0
    dict_0["status"] = int_0
    dict_0["filename"] = str_1
    dict_0["location"] = str_0
    dict_2 = {'headers': {'Content-Disposition': 'attachment; filename="filename"'}, 'status': 200, 'content_type': 'text/plain'}
    dict_0["result"] = dict_2
    dict_0["self"] = dict_0
    file(**dict_0)


# Generated at 2022-06-26 03:51:28.581343
# Unit test for function file_stream
def test_file_stream():
    with pytest.raises(TypeError):
        file_stream(location=Bytearray(), status=204, chunk_size=204, mime_type=None, headers=None, filename=None, chunked="deprecated", _range=None)


# Generated at 2022-06-26 03:51:34.163237
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    async def async_callable(arg_0):
        return None
    var_0 = StreamingHTTPResponse(async_callable)
    var_0.write(1)


# Generated at 2022-06-26 03:51:36.124970
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    callable_0 = None
    var_0 = StreamingHTTPResponse(callable_0)
    data_0 = None
    var_0.write(data_0)


# Generated at 2022-06-26 03:51:39.827484
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # case 0
    callable_0 = None
    var_0 = StreamingHTTPResponse(callable_0)
    var_0.send(None, None)



# Generated at 2022-06-26 03:51:54.118094
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    callable_0 = None
    test_case_0()
    var_0 = StreamingHTTPResponse(callable_0)
    var_1 = StreamingHTTPResponse(callable_0, 201)
    var_2 = StreamingHTTPResponse(callable_0, 400, {"a": "b", "c": "d"})
    var_3 = StreamingHTTPResponse(callable_0, 200, {"a": "b", "c": "d"}, "text/html")
    var_4 = StreamingHTTPResponse(callable_0, 200, {"a": "b", "c": "d"}, "text/html", True)

# Generated at 2022-06-26 03:52:12.171420
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    url = "arg2"
    int_0 = 1
    response = StreamingHTTPResponse(
        streaming_fn = test_case_0,
        status = 500,
        headers = {},
        content_type = "text/plain; charset=utf-8",
        chunked = "deprecated")
    response.send(url, int_0, True)


# Generated at 2022-06-26 03:52:20.169184
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    StreamingHTTPResponse_inst = StreamingHTTPResponse(test_case_0, 1, {}, 'text/plain; charset=utf-8', 'deprecated')
    try:
        int_0 = 1
        StreamingHTTPResponse_inst.write(int_0)
    except Exception as e:
        raise e


# Generated at 2022-06-26 03:52:32.508442
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    int_0 = -1
    # Creation of object 'StreamingHTTPResponse_0' of class 'StreamingHTTPResponse'
    StreamingHTTPResponse_0 = StreamingHTTPResponse(test_case_0, int_0)
    # Assignation of 'StreamingHTTPResponse_0' is 'StreamingHTTPResponse_0.send(None, False)'
    StreamingHTTPResponse_0 = StreamingHTTPResponse_0.send(None, False)


# Generated at 2022-06-26 03:52:40.711833
# Unit test for function stream
def test_stream():
    int_0 = test_case_0()
    str_0 = "."
    body_0 = str_0.rpartition(".")[2]
    str_1 = "."
    body_1 = str_1.rpartition(".")[2]
    str_2 = "."
    str_3 = "."
    body_2 = str_2.rpartition(".")[2]
    body_3 = str_3.rpartition(".")[2]
    int_1 = test_case_0()
    response_body = body_1.encode("utf-8")
    stream_fn_0 = StreamingHTTPResponse.set_body
    response_body = body_2.encode("utf-8")
    stream_fn_0 = StreamingHTTPResponse.set_body
   

# Generated at 2022-06-26 03:52:48.458281
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    class_0 = BaseHTTPResponse()
    class_0.steam = "Default parameter is None. But here is a str"
    class_0.steam.send = None
    test_send(class_0, "Default parameter is None. But here is a str", "Default parameter is None. But here is a str")
    test_send(class_0, "Default parameter is None. But here is a str", None)
    test_send(class_0, None, "Default parameter is None. But here is a str")
    class_0.steam.send = None
    t

# Generated at 2022-06-26 03:52:50.723017
# Unit test for function file_stream
def test_file_stream():
    test_case_0()
    test_case_1()

# Generated at 2022-06-26 03:52:52.356557
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    test_case_0()

# Generated at 2022-06-26 03:52:59.756892
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Input parameters
    BaseHTTPResponse_send_data = {"data": None, "end_stream": None}

    # Define event handlers
    def handler_on_timer_0():
        BaseHTTPResponse_send_data
        BaseHTTPResponse().send()

    def handler_on_timer_1():
        BaseHTTPResponse_send_data
        BaseHTTPResponse().send()

    # Define test cases
    def test_case_0():
        # Initialize events
        timer_0 = Timer(0.0, False, handler_on_timer_0)
        # Execute events
        timer_0.start()
        # Verify outputs


# Generated at 2022-06-26 03:53:12.693277
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    # Create the instance of the class (line 642)
    int_0 = 1

    # Get the element with id int_0 (line 643)
    int_1 = int_0
    int_1 = int_1[0]
    
    # Check that the element int_1 is not None (line 644)
    assert (int_1 != None)
    # Create the instance of the class (line 645)
    streaming_response_0 = StreamingHTTPResponse(int_1)
    assert (streaming_response_0 != None)
    # Call the method write of class StreamingHTTPResponse (line 646)
    int_2 = 1

    # Get the element with id int_2 (line 647)
    int_2 = int_2
    int_2 = int_2[0]
    

# Generated at 2022-06-26 03:53:16.147246
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    obj_0 = BaseHTTPResponse()
    # Begin function call
    test_BaseHTTPResponse_send_0 = test_BaseHTTPResponse_send_0()
    # End function call
    test_BaseHTTPResponse_send_0 = test_BaseHTTPResponse_send_0
    test_case_0()
    test_case_0()

# End of test case

# Generated at 2022-06-26 03:53:34.721163
# Unit test for function file_stream
def test_file_stream():
    # Instance of class PurePath
    path_0 = path.PurePath('C:\\Users\\bzahorchak\\Desktop\\test\\test.txt')

    # set chunk_size
    chunk_size = 32

    # set chunked
    chunked = 'deprecated'

    # set headers
    headers = {'Content-Disposition': 'attachment; filename="C:\\Users\\bzahorchak\\Desktop\\test\\test.txt"'}

    # set filename
    filename = None

    # set mime_type
    mime_type = None

    # set location
    location = path_0

    # set _range
    _range = None

    # set status
    status = 200

    # Function call to file_stream

# Generated at 2022-06-26 03:53:36.223700
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    int_0 = 1


# Generated at 2022-06-26 03:53:41.407441
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # Generate instance of class StreamingHTTPResponse
    StreamingHTTPResponse_instance = StreamingHTTPResponse(streaming_fn = lambda x: test_case_0())
    assert StreamingHTTPResponse_instance is not None


# Generated at 2022-06-26 03:53:48.824135
# Unit test for function stream
def test_stream():
    def test_function(response):
        response.write(b'foo')
        response.write(b'bar')

    stream_0 = stream(test_function, content_type='text/plain')
    int_0 = len(stream_0)


# Generated at 2022-06-26 03:53:52.435926
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():

    streamingHTTPResponse_0 = StreamingHTTPResponse(test_case_0)
    streamingHTTPResponse_0.send()


# Generated at 2022-06-26 03:53:58.932762
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    cls_0 = StreamingHTTPResponse
    StreamingHTTPResponse_0 = cls_0()
    StreamingHTTPResponse_0.write()
test_case_0()
test_StreamingHTTPResponse_write()

# Generated at 2022-06-26 03:54:03.931013
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    a = BaseHTTPResponse()
    a.stream = Http()
    a.stream.send = PartialMock()
    a.send('a')
    a.stream.send.assert_called_once_with('a')


# Generated at 2022-06-26 03:54:13.292253
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    stream = Stream(None)
    stream.send = asyncio.coroutine(None)
    response = BaseHTTPResponse()
    response.stream = stream
    message = []
    coro = response.send()
    try:
        coro.send(None)
    except StopIteration as e:
        message.append(e.value)

    assert message == [None]


# Generated at 2022-06-26 03:54:17.792135
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    int_0 = 1
    str_0 = "Hello"
    bool_0 = True
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()



# Generated at 2022-06-26 03:54:18.966633
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    test_case_0()

if __name__ == '__main__':
    test_BaseHTTPResponse_send()

# Generated at 2022-06-26 03:54:31.223870
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # call function
    test_case_0()

test_StreamingHTTPResponse_send()

# Generated at 2022-06-26 03:54:44.430854
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # These are all actually unused now, but are kept in so as not to
    # break external code.
    #
    # These arguments should stay in alphabetical order.
    #
    # Arguments:
    #   data: Optional[Union[AnyStr]] = None,
    #   end_stream: Optional[bool] = None,
    #
    # Returns:
    #   None
    class TestResponse(BaseHTTPResponse):
        def __init__(self):
            self.stream = None
        async def _send(self, data, end_stream):
            pass
    test_resp = TestResponse()
    test_StreamingHTTPResponse = StreamingHTTPResponse(test_case_0)

    # Case 0
    data = 'aaabbbccc'
    end_stream = True
    test

# Generated at 2022-06-26 03:54:51.534378
# Unit test for function file_stream
def test_file_stream():
    # Setup
    from pathlib import Path, PurePath
    from tempfile import TemporaryDirectory, NamedTemporaryFile


# Generated at 2022-06-26 03:54:53.661313
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Note that this test case is only responsible to test the correctness of the
    # generated trace, so the concrete parameter is not important.
    response = BaseHTTPResponse()
    response.stream = Http()
    response.stream.send = test_case_0
    response.send("abc")
    return True



# Generated at 2022-06-26 03:54:55.998131
# Unit test for function html
def test_html():
    assert html("<html></html>") == b'<html></html>'


# Generated at 2022-06-26 03:55:03.515320
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_fn = lambda: test_case_0()
    status = 200
    headers = None
    content_type = "text/plain; charset=utf-8"
    chunked = "deprecated"
    obj = StreamingHTTPResponse(streaming_fn,status,headers,content_type,chunked)
    # Expected value: 'StreamingHTTPResponse'
    test0 = type(obj)
    # Expected value: "<class 'sanic.response.StreamingHTTPResponse'>"
    test1 = str(test0)
    assert test1 == "<class 'sanic.response.StreamingHTTPResponse'>"



# Generated at 2022-06-26 03:55:13.958956
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    test_instance = BaseHTTPResponse()
    test_instance.status = 1
    test_instance.asgi = True
    test_instance.content_type = "NULL"
    test_instance.stream = None
    test_instance.headers = Header()

    test_instance.headers.setdefault("content-type", test_instance.content_type)
    if test_instance.status in (304, 412):
        test_instance.headers = remove_entity_headers(test_instance.headers)
    if has_message_body(test_instance.status):
        test_instance.headers.setdefault("content-type", test_instance.content_type)

# Generated at 2022-06-26 03:55:23.483234
# Unit test for function file_stream
def test_file_stream():
    # Setup inputs
    location = pathlib.Path('/path/to/file')
    status = 1
    chunk_size = 1
    mime_type = 'text/plain'
    headers = {'Content-Disposition':'attachment; filename="test_file"'}
    filename = 'test_file'
    chunked = 'deprecated'
    _range = Range('test_range')

    # Run function
    result = file_stream(
        location,
        status,
        chunk_size,
        mime_type,
        headers,
        filename,
        chunked,
        _range)

    # Get the type of result
    result_type = type(result)

    # Test with assertion
    assert result_type == StreamingHTTPResponse



# Generated at 2022-06-26 03:55:28.455076
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    test_case_0()

if __name__ == '__main__':
    test_StreamingHTTPResponse_send()

# Generated at 2022-06-26 03:55:34.673880
# Unit test for function file
def test_file():
    test_location = "." # *.*
    test_mime_type = "text/plain"
    test_filename = "init.py"
    test_headers = {'Content-Disposition': 'attachment; filename="'+test_filename+'"'}
    test_range = None
    test_status = 200

    result = file(test_location, test_status, test_mime_type,test_headers,test_filename,test_range)
    assert(result != HTTPResponse)


# Generated at 2022-06-26 03:55:57.786181
# Unit test for function file_stream
def test_file_stream():
    # file_stream: Location of file on system
    location_0 = ''
    # file_stream: The size of each chunk in the stream (in bytes)
    chunk_size_0 = 4096
    # file_stream: Specific mime_type
    mime_type_0 = None
    # file_stream: Custom Headers
    headers_0 = None
    # file_stream: Override filename
    filename_0 = None
    # file_stream: Deprecated
    chunked_0 = 'deprecated'
    # file_stream:
    _range_0 = None
    # file_stream: Return a streaming response object with file data
    file_stream(location_0, chunk_size_0, mime_type_0, headers_0, filename_0, chunked_0, _range_0)


# Generated at 2022-06-26 03:56:06.599078
# Unit test for function file
def test_file():
    location_0: str = "foo"
    status_0: int = 200
    mime_type_0: Optional[str] = "foo"
    headers_0: Optional[Dict[str, str]] = {'foo': 'foo'}
    filename_0: Optional[str] = "foo"
    _range_0: Optional[Range] = Range(0, 0, 0)
    x_0: HTTPResponse = file(location_0, status_0, mime_type_0, headers_0, filename_0, _range_0)


# Generated at 2022-06-26 03:56:09.915302
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn=streaming_function_0, status=123, headers=None, content_type="text/plain; charset=utf-8", chunked="deprecated")
    # Test 0
    try:
        streaming_h_t_t_p_response_0.send(data=str_0)
    except Exception as e:
        print(str(e))
    # Test 1
    try:
        streaming_h_t_t_p_response_0.send()
    except Exception as e:
        print(str(e))


# Generated at 2022-06-26 03:56:17.158904
# Unit test for function html
def test_html():
    body = 'aaa'
    status = 200
    headers = {'aaa':'bbb'}
    result = html(body, status, headers)
    assert isinstance(result, HTTPResponse)
    assert result.body == body.encode()
    assert result.status == status
    assert result.headers == {'aaa':'bbb'}
    assert result.content_type == 'text/html; charset=utf-8'


# Generated at 2022-06-26 03:56:18.712549
# Unit test for function file_stream
def test_file_stream():
    file_0 = file_stream(location)


# Generated at 2022-06-26 03:56:27.327318
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return stream(sample_streaming_fn)

    response = test(request={})
    assert response.response.status == 200
    assert response.response.content_type == "text/plain; charset=utf-8"
    assert response.response.headers == {}

# Generated at 2022-06-26 03:56:40.099419
# Unit test for function file
def test_file():
    # tests for Python 3.7 and greater
    location_0 = str(PurePath('/path/to', 'somefile.txt'))
    mime_type_0 = 'text/plain'
    filename_0 = 'somefile.txt'
    _range_0 = Range(start=2, end=3, size=2)
    # file(location=location_0, mime_type=mime_type_0, filename=filename_0, _range=_range_0)

    # tests for Python 3.6 and earlier

    # tests for Python 3.7 and greater
    location_1 = str(PurePath('/path/to', 'somefile.txt'))
    mime_type_1 = None
    filename_1 = None
    _range_1 = None
    # file(location=location_1, m

# Generated at 2022-06-26 03:56:42.720936
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    await base_h_t_t_p_response_0.send()



# Generated at 2022-06-26 03:56:55.782121
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn = write, status = 200)
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse()
    streaming_h_t_t_p_response_0.streaming_fn = write
    streaming_h_t_t_p_response_0.status = 200
    streaming_h_t_t_p_response_0.headers = Header()
    streaming_h_t_t_p_response_0._cookies = None
    streaming_h_t_t_p_response_0.write("foo")


# Generated at 2022-06-26 03:56:58.489388
# Unit test for function file
def test_file():
    file_0 = await file((str), status=(int), mime_type=(str), headers=(dict), filename=(str), _range=(int))


# Generated at 2022-06-26 03:57:30.306096
# Unit test for function file_stream

# Generated at 2022-06-26 03:57:34.429924
# Unit test for function file_stream
def test_file_stream():
    fname = 'examples/sanic/app.py'
    chunk_size = 4096
    mime_type = None
    headers = None
    filename = None
    chunked = None
    _range = Range(start=0, end=1, total=1)
    result_returned = [False]
    async def _streaming_fn(response):
        assert (response._cookies is None)
        assert (response.content_type == "text/plain")
        assert (response.headers is None)
        assert (response.status == 200)
        await response.write(b"a")
        async with await open_async(fname, mode="rb") as f:
            assert (f is not None)
            if _range:
                await f.seek(_range.start)

# Generated at 2022-06-26 03:57:41.216249
# Unit test for function file_stream
def test_file_stream():
    location = path.join(path.dirname(__file__), "../testdata/main.py")
    chunk_size = 4096
    mime_type = None
    headers = {}

    chunked="deprecated"
    filename=None
    _range=None

    actual_return_value = file_stream(location, chunk_size, mime_type, headers, filename, chunked, _range)
    expected_return_value = None
    assert expected_return_value == actual_return_value


# Generated at 2022-06-26 03:57:47.607515
# Unit test for function file_stream
def test_file_stream():
    location = "" 
    status = 200
    chunk_size = 4096
    mime_type = None
    headers = None
    filename = None
    chunked = "deprecated"
    _range = None 
    file_stream_0 = file_stream(location, status, chunk_size, mime_type, headers, filename, chunked, _range)


# Generated at 2022-06-26 03:57:53.295472
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Initialize
    BaseHTTPResponse.__init__(base_h_t_t_p_response_0)

    # Call the method
    BaseHTTPResponse.send(base_h_t_t_p_response_0, data=None, end_stream=None)


# Generated at 2022-06-26 03:58:00.657105
# Unit test for function file
def test_file():
    import asyncio
    import tempfile
    import os
    import gc
    loop = asyncio.get_event_loop()
    
    # mock path
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)
    
    # mock location
    location = temp_path
    
    # mock status
    status = 200
    
    # mock mime_type
    mime_type = None
    
    # mock headers
    headers = None
    
    # mock filename
    filename = None
    
    # mock _range
    _range = None
    
    # mock out_stream
    out_stream = b'asdf'
    
    # mock f
    f = tempfile.TemporaryFile()
    
    # mock _range.start

# Generated at 2022-06-26 03:58:03.909680
# Unit test for function file_stream
def test_file_stream():
    response = asyncio.run(file_stream("psutil.py", chunk_size=100))
    return response


# Generated at 2022-06-26 03:58:08.513142
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    # Test for function send of class BaseHTTPResponse
    assert base_h_t_t_p_response_0.send() is None


# Generated at 2022-06-26 03:58:13.937141
# Unit test for function html
def test_html():
    text_str = "Some HTML"
    resp1 = html(text_str)
    assert resp1.status == 200
    assert resp1.content_type == 'text/html; charset=utf-8'
    assert resp1.headers == Header({})
    assert resp1.body == text_str.encode()

# Generated at 2022-06-26 03:58:19.835551
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse()
    response = streaming_h_t_t_p_response_0.send(data=None, end_stream=None)
    response_1 = streaming_h_t_t_p_response_0.send(data='', end_stream=None)
    response_2 = streaming_h_t_t_p_response_0.send(data='', end_stream=True)
    response_3 = streaming_h_t_t_p_response_0.send(data=None, end_stream=True)


# Generated at 2022-06-26 03:59:14.253600
# Unit test for function file_stream
def test_file_stream():
    assert(asyncio.run(file_stream("/tmp/test_file.txt")))
    assert(asyncio.run(file_stream("/tmp/test_file.txt", header="test header")))
    assert(asyncio.run(file_stream("/tmp/test_file.txt", status=200)))
    assert(asyncio.run(file_stream("/tmp/test_file.txt", mime_type="text/plain")))
    assert(asyncio.run(file_stream("/tmp/test_file.txt", filename="test_file.txt")))
    assert(asyncio.run(file_stream("/tmp/test_file.txt", chunk_size=4096)))

# Generated at 2022-06-26 03:59:15.942966
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_1 = BaseHTTPResponse()


# Generated at 2022-06-26 03:59:19.245928
# Unit test for function file
def test_file():
    # Test arguments:
    location = "./tests/data/test_image.png"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None

    return file(location, status, mime_type, headers, filename, _range)



# Generated at 2022-06-26 03:59:31.040840
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from asgiref.sync import async_to_sync
    import asyncio
    async def sample_streaming_fn(response):
        await response.write('foo')
        await asyncio.sleep(1)
        await response.write('bar')
        await asyncio.sleep(1)
    async def sample_streaming_fn_body(response):
        await response.write('foo')
        await asyncio.sleep(1)
        await response.write('bar')
        await asyncio.sleep(1)
    streaming_fn = sample_streaming_fn
    status = 200
    content_type = 'text/plain; charset=utf-8'
    chunked = 'deprecated'
    sample_streaming_fn = async_to_sync(sample_streaming_fn)

# Generated at 2022-06-26 03:59:39.225779
# Unit test for function html
def test_html():
    # Arguments used for testing
    body = 'string'
    status = 200
    headers = {}
    expected_result = HTTPResponse(  # type: ignore
        body,
        status=status,
        headers=headers,
        content_type="text/html; charset=utf-8",
    )
    # Call the function under test
    actual_result = html(body, status, headers)
    
    # Verify the result
    assert actual_result == expected_result



# Generated at 2022-06-26 03:59:43.014549
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    try:
        base_h_t_t_p_response_0.send()
    except Exception as e:
        print('Caught exception in BaseHTTPResponse.send(): ', e)



# Generated at 2022-06-26 03:59:48.475076
# Unit test for function file
def test_file():
    location = 'test'
    status = 200
    mime_type = 'test'
    headers = None
    filename = 'test'
    _range = None
    try:
        result = file(location, status, mime_type, headers, filename, _range)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 03:59:53.027509
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    base_h_t_t_p_response_0 = BaseHTTPResponse()
    assert(base_h_t_t_p_response_0.send("1"))



# Generated at 2022-06-26 04:00:02.447259
# Unit test for function stream
def test_stream():
    base_h_t_t_p_response_0 = BaseHTTPResponse()

    def streaming_fn(response):
        return response.write("string content")

    def streaming_fn_1(response):
        return response.write("string content")
    headers = {}
    content_type = "text/plain; charset=utf-8"
    status = 200
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn_1, status, headers, content_type)
    stream(streaming_fn, content_type="text/plain")


# Generated at 2022-06-26 04:00:11.431660
# Unit test for function file
def test_file():
    # param: location: Union[str, PurePath]
    # param: status: int = 200
    # param: mime_type: Optional[str] = None
    # param: headers: Optional[Dict[str, str]] = None
    # param: filename: Optional[str] = None
    # param: _range: Optional[Range] = None
    file_0 = file(location=None, status=None, mime_type=None, headers=None, filename=None, _range=None)
