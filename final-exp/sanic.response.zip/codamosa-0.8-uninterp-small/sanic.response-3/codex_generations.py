

# Generated at 2022-06-26 03:51:06.221908
# Unit test for function file_stream
def test_file_stream():
    location = 'tests/data/hello.txt'
    chunk_size = 4096
    mime_type = 'text/plain'
    headers = {}
    filename = 'hello.txt'
    chunked = 'deprecated'
    _range = None
    h_t_t_p_response_2 = file_stream(location=location, chunk_size=chunk_size, mime_type=mime_type, headers=headers, filename=filename, chunked=chunked, _range=_range)


# Generated at 2022-06-26 03:51:17.441157
# Unit test for function file_stream
def test_file_stream():

    file_path = os.path.dirname(os.path.realpath(__file__)) + "/data.txt"
    loop = asyncio.get_event_loop()
    a = loop.run_until_complete(file_stream(file_path))
    assert type(a) == StreamingHTTPResponse
    assert a.content_type == 'text/plain'
    assert type(a.status) == int
    assert a.status == 200
    assert type(a.headers) == Header
    assert type(a.streaming_fn) == types.FunctionType
    assert a.streaming_fn.__name__ == "streaming_fn"



# Generated at 2022-06-26 03:51:20.578573
# Unit test for function file_stream
def test_file_stream():
    h_t_t_p_response_0 = HTTPResponse()



# Generated at 2022-06-26 03:51:31.167678
# Unit test for method write of class StreamingHTTPResponse

# Generated at 2022-06-26 03:51:35.862388
# Unit test for function file_stream
def test_file_stream():
    assert asyncio.iscoroutinefunction(
        file_stream
    ), f"{file_stream.__name__} should be a coroutine"    



# Generated at 2022-06-26 03:51:38.342859
# Unit test for function file
def test_file():
    assert isinstance(file("/tmp"), HTTPResponse)


# Generated at 2022-06-26 03:51:40.868718
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    h_t_t_p_response_0 = HTTPResponse()
    h_t_t_p_response_0.send()


# Generated at 2022-06-26 03:51:41.650216
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():

    assert BaseHTTPResponse().send() == None


# Generated at 2022-06-26 03:51:44.337426
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    h_t_t_p_response_0 = StreamingHTTPResponse()


# Generated at 2022-06-26 03:51:50.548781
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    h_t_t_p_response_0 = HTTPResponse()
    await open_async()
    await h_t_t_p_response_0.send(data=None, end_stream=True)


# Generated at 2022-06-26 03:52:13.382468
# Unit test for function file_stream
def test_file_stream():
    path = "./"
    chunk_size = 4096
    headers = {}
    filename = "."
    chunked = "deprecated"
    test_file_stream_0 = file_stream(path, chunk_size=chunk_size, headers=headers, filename=filename, chunked=chunked)


# Generated at 2022-06-26 03:52:21.416227
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    test_streaming_ht_t_p_response_0 = StreamingHTTPResponse(0)
    data_0 = None
    end_stream_0 = None
    test_streaming_ht_t_p_response_0.send(data_0, end_stream_0)
    data_1 = ""
    end_stream_1 = True
    test_streaming_ht_t_p_response_0.send(data_1, end_stream_1)
    data_2 = "0"
    end_stream_2 = True
    test_streaming_ht_t_p_response_0.send(data_2, end_stream_2)
    data_3 = "1"
    end_stream_3 = True

# Generated at 2022-06-26 03:52:26.928989
# Unit test for function file_stream
def test_file_stream():
    str_0 = "src/sanic/response.py"
    chunk_size_0 = 4096
    h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn=None, status=200, headers=None, content_type="text/plain; charset=utf-8")
    h_t_t_p_response_1 = file_stream(location=str_0, status=200, chunk_size=chunk_size_0, mime_type=None, headers=None, filename=None, _range=None)
    assert h_t_t_p_response_0.status == h_t_t_p_response_1.status
    assert h_t_t_p_response_0.headers == h_t_t_p_response_1.headers
    assert h_

# Generated at 2022-06-26 03:52:32.339934
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    h_t_t_p_response_0 = StreamingHTTPResponse(test_StreamingHTTPResponse_write_0)
    h_t_t_p_response_0.write(h_t_t_p_response_0)


# Generated at 2022-06-26 03:52:33.925196
# Unit test for function file
def test_file():
    assert file("") is not None


# Generated at 2022-06-26 03:52:44.917752
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    """
    Unit test for method send of class StreamingHTTPResponse
    """
    # Define a function that will be executed by send
    def func0(arg0):
        """
        This is a function executed by send to return a value
        """
        ret0 = None
        ret0 = arg0.body
        return ret0
        pass

    param0 = func0
    ret0 = StreamingHTTPResponse.send(param0)
    assert isinstance(ret0, StreamingHTTPResponse)
    pass


# Generated at 2022-06-26 03:52:57.285428
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Create the instance
    h_t_t_p_response_0 = HTTPResponse()
    # Call the method with a str or bytes type instance
    h_t_t_p_response_0.send(data="abc", end_stream=True)
    # Call the method with a str or bytes type instance
    h_t_t_p_response_0.send(data="abc", end_stream=False)
    # Call the method with a str or bytes type instance
    h_t_t_p_response_0.send(data="", end_stream=True)


# Generated at 2022-06-26 03:53:05.551119
# Unit test for function file_stream
def test_file_stream():
    # If a warning is raised, the test will fail
    file_stream('test_file_stream_location', chunk_size=4096, mime_type='test_file_stream_mime_type', headers='test_file_stream_headers', filename='test_file_stream_filename', _range=None)


# Generated at 2022-06-26 03:53:19.184551
# Unit test for function file
def test_file():
    location = '/home/sec/Desktop/json_data_files/js1.json'
    status = 200
    headers = {'Content-Disposition': 'attachment; filename="js1.json"'}
    out_stream = b'{"age": 20, "city": "London", "name": "Jack"}'
    mime_type = 'application/json'
    response = HTTPResponse(body=out_stream, status=status, headers=headers, content_type=mime_type)

    assert isinstance(response, HTTPResponse)
    assert response.body == out_stream
    assert response.status == status
    assert response.headers == headers
    assert response.content_type == mime_type


# Generated at 2022-06-26 03:53:25.992987
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    b_h_t_t_p_response_0 = BaseHTTPResponse()
    data = ""
    end_stream = False
    b_h_t_t_p_response_0.send(data, end_stream)

# Definition for method set_cookie of class HTTPResponse

# Generated at 2022-06-26 03:53:44.686628
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    def sample_streaming_fn(response: StreamingHTTPResponse):
        async def sample_streaming_fn_inner():
            await response.write("foo")
            await asyncio.sleep(1)
            await response.write("bar")
            await asyncio.sleep(1)

        return sample_streaming_fn_inner()

    with HTTPResponse() as response:
        async def test():
            return await sample_streaming_fn(response)

        async def test2():
            await response.stream(test)
            return response

        _return_value_0 = await test2()


# Generated at 2022-06-26 03:53:51.396804
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Success Type
    h_t_t_p_response_0 = HTTPResponse()
    h_t_t_p_response_0.send(data=None)
    h_t_t_p_response_0.send(end_stream=True)
    h_t_t_p_response_0.send(data=None, end_stream=True)
    h_t_t_p_response_0.send(end_stream=True, data=None)
    h_t_t_p_response_0.send(data="", end_stream=True)
    h_t_t_p_response_0.send(end_stream=True, data="")
    h_t_t_p_response_0.send()
    h_t_t_p_response_0.send

# Generated at 2022-06-26 03:54:05.379246
# Unit test for function file
def test_file():
    # h_t_t_p_response_0 = file(location=PurePath(0), _range=Range(0, 0, 0), filename=None, status=0, mime_type=None, headers=None)
    # assert h_t_t_p_response_0.cookies == None

    # h_t_t_p_response_1 = file(location="", _range=Range(0, 0, 0), filename=None, status=0, mime_type=None, headers=None)
    # assert h_t_t_p_response_1.cookies == None

    h_t_t_p_response_2 = file(location=PurePath(0), _range=Range(0, 0, 0), filename="", status=0, mime_type=None, headers=None)
    assert h

# Generated at 2022-06-26 03:54:18.612427
# Unit test for function file_stream
def test_file_stream():
    # Test #0
    location_0 = "Hello World!"
    mime_type_0 = "text/plain"
    filename_0 = "Let It Go"
    chunked_0 = "deprecated"
    _range_0 = -1
    h_t_t_p_response_0 = StreamingHTTPResponse(
        location_0, mime_type_0, filename_0, chunked_0, _range_0
    )
    # Test #1
    location_1 = "Hello World!"
    mime_type_1 = "text/plain"
    filename_1 = "Let It Go"
    chunked_1 = "deprecated"
    _range_1 = 0

# Generated at 2022-06-26 03:54:27.599245
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    h_t_t_p_response_0 = StreamingHTTPResponse(  # type: ignore
        lambda x: None
    )
    h_t_t_p_response_0.send(
        b"Y\xdb\xef\xe1\x03\xfc\x8e\xba\xc5\x94\xa9\x8f\xfb\x03\xa0\x81\xf8\x12",
        False
    )


# Generated at 2022-06-26 03:54:41.649211
# Unit test for function file_stream
def test_file_stream():
    # Init
    location = 'location'
    status = 200
    chunk_size = 4096
    mime_type = 'mime_type'
    headers = {}
    filename = 'filename'
    chunked = 'deprecated'
    _range = Range()

    # Invoke function
    streaming_http_response_0 = file_stream(
        location,
        status=status,
        chunk_size=chunk_size,
        mime_type=mime_type,
        headers=headers,
        filename=filename,
        chunked=chunked,
        _range=_range)

    # Check for correct type of result
    assert(isinstance(streaming_http_response_0, StreamingHTTPResponse))
    # Check for correct instance attributes

# Generated at 2022-06-26 03:54:46.634168
# Unit test for function file_stream
def test_file_stream():
    try:
        file_stream(chunk_size = 4096, headers = None, location = "test_cases/test_case_0/test_0.txt", mime_type = None, status = None, filename = None)
    except Exception as e:
        print(e)



# Generated at 2022-06-26 03:54:54.176917
# Unit test for function file_stream
def test_file_stream():
    location = path.join(path.dirname(__file__), "example_files", "CSAR.zip")
    chunk_size = 4096
    mime_type = None
    headers = {}
    filename = None
    chunked = "deprecated"
    _range = None


# Generated at 2022-06-26 03:54:58.667587
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    h_t_t_p_response_0 = StreamingHTTPResponse(streaming_fn=test_case_0)
    h_t_t_p_response_0.send(chunked="deprecated")

# Generated at 2022-06-26 03:55:11.945634
# Unit test for function file
def test_file():
    path_0 = 'foobar.txt'
    file(path_0, status=200, headers={}, mime_type='text/plain')
    path_1 = 'bar/baz.txt'
    file(path_1, filename='foobar.txt', mime_type='text/plain')
    path_2 = '/tmp/foo.txt'
    file(path_2, headers={}, mime_type='text/plain')
    path_3 = '/tmp/baz.txt'
    file(path_3, mime_type='text/plain', filename='baz.txt')
    path_4 = 'foo/bar.txt'
    file(path_4, mime_type='text/plain')



# Generated at 2022-06-26 03:55:32.873089
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    h_t_t_p_response_0 = HTTPResponse()
    str_0 = 'U6Md$'
    str_1 = 'QPYrD'
    str_2 = '1:$@(j'
    # AssertionError: assert isinstance(value, str)
    # AssertionError: assert isinstance(value, str)
    # AssertionError: assert isinstance(value, str)
    # AssertionError: assert isinstance(value, str)
    # AssertionError: assert isinstance(value, str)
    # AssertionError: assert isinstance(value, str)
    # AssertionError: assert isinstance(value, str)
    # AssertionError: assert isinstance(value, str)
    # AssertionError: assert isinstance(

# Generated at 2022-06-26 03:55:35.733543
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    h_t_t_p_response_0 = StreamingHTTPResponse()
    h_t_t_p_response_0.send()



# Generated at 2022-06-26 03:55:36.865607
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    pass


# Generated at 2022-06-26 03:55:44.129163
# Unit test for function file
def test_file():
    print("Testing {}".format("file"))
    test_file_1("")
    test_file_2("")
    test_file_3("")
    test_file_4("")
    test_file_5("")


# Generated at 2022-06-26 03:55:49.958829
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Arrange
    h_t_t_p_response_0 = HTTPResponse()
    data_1 = ""
    end_stream_2 = None
    # Act
    method_result_3 = h_t_t_p_response_0.send(data=data_1, end_stream=end_stream_2)

    # Assert
    assert method_result_3 == None



# Generated at 2022-06-26 03:56:04.970172
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():

    h_t_t_p_response_0 = HTTPResponse()
    h_t_t_p_response_1 = HTTPResponse()
    h_t_t_p_response_2 = HTTPResponse()
    h_t_t_p_response_3 = HTTPResponse()
    h_t_t_p_response_4 = HTTPResponse()
    h_t_t_p_response_5 = HTTPResponse()
    h_t_t_p_response_6 = HTTPResponse()
    h_t_t_p_response_7 = HTTPResponse()
    h_t_t_p_response_8 = HTTPResponse()
    h_t_t_p_response_9 = HTTPResponse()

# Generated at 2022-06-26 03:56:15.477023
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # Create an instance of StreamingHTTPResponse
    streaming_h_t_t_p_response = StreamingHTTPResponse('Real')
    # Create an instance of HTTPResponse
    http_response_0 = HTTPResponse(status=404, body=data)
    http_response_0.headers['Cookie'] = 'key=value'
    http_response_0.headers['Content-Length'] = 'sth'
    result = streaming_h_t_t_p_response.send(http_response_0)
    try:
        assert isinstance(result, HTTPResponse)
        print(True)
    except Exception:
        print(False)



# Generated at 2022-06-26 03:56:22.845771
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    h_t_t_p_response_0 = HTTPResponse()
    stream = None
    try:
        h_t_t_p_response_0.send(stream)
    except:
        pass
    # Exception thrown here
    stream = None
    try:
        h_t_t_p_response_0.send(stream)
    except:
        pass


# Generated at 2022-06-26 03:56:29.106701
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse()

    # Test 1: Normal Operation
    # Write data to the streaming HTTPResponse
    streaming_h_t_t_p_response_0._write(b"test_data")

    # Test 2: Argument Type
    # Write an integer to the streaming HTTPResponse
    streaming_h_t_t_p_response_0._write(42)



# Generated at 2022-06-26 03:56:40.355094
# Unit test for function file_stream
def test_file_stream():
    location = 'location'
    status = 200
    chunk_size = 4096
    mime_type = 'mime_type'
    headers = dict()
    filename = 'filename'
    chunked = 'deprecated'
    _range = Range()
    # h_t_t_p_response_0 = file_stream(location, status, chunk_size, mime_type, headers, filename, chunked, _range)
    res = file_stream(location, status, chunk_size, mime_type, headers, filename, chunked, _range)
    assert res is not None
    assert isinstance(res, StreamingHTTPResponse)


# Generated at 2022-06-26 03:56:56.760197
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    st_h_t_t_p_response_0 = StreamingHTTPResponse(None)
    st_h_t_t_p_response_1 = StreamingHTTPResponse(sample_streaming_fn)
    st_h_t_t_p_response_2 = StreamingHTTPResponse(sample_streaming_fn)


# Generated at 2022-06-26 03:57:00.217308
# Unit test for function file_stream
def test_file_stream():
    # Check if the stream can be read in
    out_stream = file_stream('./unitest_data.txt')
 

if __name__ == "__main__":
    # print(test_case_0.__annotations__)
    test_file_stream()

# Generated at 2022-06-26 03:57:02.791841
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    h = Http()
    h.send = None
    http_response = HTTPResponse()
    http_response.stream = h
    http_response.send(data=None, end_stream=None)

# Generated at 2022-06-26 03:57:08.331422
# Unit test for function file
def test_file():
    # TODO: Update this test once we have a way to import files
    # This is just a placeholder to test the function call.
    file(location="test_file", status=200, mime_type=None, headers=None, filename=None, _range=None)


# Generated at 2022-06-26 03:57:20.546736
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    x_0 = None
    x_1 = True
    x_2 = False
    y = (x_1 or x_2)
    z = (False or x_2)

    # Value to generate
    HttpStream_0 = HttpStream()
    HttpStream_0.send = True
    HttpStream_0.set_status = True

    h_t_t_p_response_0 = HTTPResponse()
    h_t_t_p_response_0.stream = HttpStream_0

    # Call method send of class BaseHTTPResponse
    h_t_t_p_response_0.send(
        data=x_0,
        end_stream=y,
    )


# Generated at 2022-06-26 03:57:30.148813
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    streaming_h_t_t_p_response_0 = StreamingHTTPResponse(
        lambda response: None,
        chunked="deprecated",
        content_type="text/plain; charset=utf-8",
        headers=None,
        status=200)

    streaming_h_t_t_p_response_0._encode_body("foo")
    streaming_h_t_t_p_response_0._encode_body("bar")
    streaming_h_t_t_p_response_0._encode_body("")


# Generated at 2022-06-26 03:57:36.076471
# Unit test for function file_stream
def test_file_stream():
    (content, headers) = file_stream(
        location='/tmp/foo',
        chunk_size=4096,
        mime_type=None,
        headers=None,
        filename='foo.html',
        chunked="deprecated",
        _range=None
    )


# Generated at 2022-06-26 03:57:44.528804
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    import requests

    class StreamingHTTPResponse_send_0:
        def __init__(self):
            super().__init__()

    StreamingHTTPResponse_send_0.send = StreamingHTTPResponse.send
    StreamingHTTPResponse_send_0._encode_body = StreamingHTTPResponse._encode_body
    StreamingHTTPResponse_send_0.write = StreamingHTTPResponse.write
    StreamingHTTPResponse_send_0.stream = Http()
    StreamingHTTPResponse_send_0.stream.send = requests.get.send

    StreamingHTTPResponse_send_1 = StreamingHTTPResponse_send_0()
    data_1 = None
    end_stream_1 = None
    StreamingHTTPResponse_send

# Generated at 2022-06-26 03:57:49.546453
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    h_t_t_p_response_1 = StreamingHTTPResponse(None, 200, None, "text/plain; charset=utf-8", "deprecated")
    await h_t_t_p_response_1.send("", True)

# Generated at 2022-06-26 03:57:52.420061
# Unit test for function file
def test_file():
    returned_value_of_test_case_1 = await file(location, status, mime_type)
    assert returned_value_of_test_case_1 == None


# Generated at 2022-06-26 03:58:39.990226
# Unit test for function file
def test_file():
    filename = "test_case_4.txt"
    location = "test_case_4.txt"
    mime_type = "text/plain"
    status = 200
    headers = None
    _range = None
    obj_h_t_t_p_response = file(location, status, mime_type, headers, filename, _range)
    assert isinstance(obj_h_t_t_p_response, HTTPResponse)



# Generated at 2022-06-26 03:58:52.203948
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    h_t_t_p_response_0 = HTTPResponse()
    h_t_t_p_response_1 = HTTPResponse(status=200)
    h_t_t_p_response_2 = HTTPResponse(body=b'{"hello": "world"}')
    h_t_t_p_response_3 = HTTPResponse(status=200, body=b'{"hello": "world"}')
    h_t_t_p_response_4 = HTTPResponse(status=200, body=b'{"hello": "world"}', headers={"Content-Type": "application/json"})
    h_t_t_p_response_5 = HTTPResponse(text="Hello")
    h_t_t_p_response_6 = HTTPResp

# Generated at 2022-06-26 03:58:59.866219
# Unit test for function file_stream
def test_file_stream():
    unit_test_file_path = "../tests/unit_test_files/test.txt"
    headers_0 = dict()
    headers_0["Content-Disposition"] = 'attachment; filename="test.txt"'
    stream_0 = file_stream(unit_test_file_path, headers=headers_0)
    assert(isinstance(stream_0, StreamingHTTPResponse))
    assert(stream_0.__slots__ == ("streaming_fn", "status", "content_type", "headers", "_cookies"))
    assert(stream_0.content_type is "text/plain")
    assert(stream_0.status is 200)
    assert(stream_0.headers == headers_0)
    assert(isinstance(stream_0.streaming_fn, types.FunctionType))

# Generated at 2022-06-26 03:59:11.351737
# Unit test for function file_stream
def test_file_stream():
    location_0 = 42
    status_0 = 100
    chunk_size_0 = 100
    mime_type_0 = "test_value_3"
    filename_0 = "test_value_4"
    chunked_0 = "z"
    test_streaming_fn_0 = asyncio.coroutine(lambda x: None)
    # Function call with options
    test_file_stream_0 = StreamingHTTPResponse(
        streaming_fn=test_streaming_fn_0,
        status=status_0,
        chunk_size=chunk_size_0,
        mime_type=mime_type_0,
        filename=filename_0,
        chunked=chunked_0,
    )
    assert test_file_stream_0.streaming_fn is test_streaming

# Generated at 2022-06-26 03:59:19.091018
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    h_t_t_p_response_1 = HTTPResponse()
    h_t_t_p_response_1.asgi = False
    h_t_t_p_response_1.body = None
    h_t_t_p_response_1.content_type = None
    h_t_t_p_response_1.stream = None
    h_t_t_p_response_1.status = None
    h_t_t_p_response_1.headers = None
    h_t_t_p_response_1._cookies = None
    result = h_t_t_p_response_1.send( data = None, end_stream = None )


# Generated at 2022-06-26 03:59:27.860734
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    # Init
    async def async_fun_0():
        return
    h_t_t_p_response_0 = StreamingHTTPResponse(status=500, streaming_fn=async_fun_0, content_type="text/plain; charset=utf-8", headers=None)
    h_t_t_p_response_0.stream = None

    # Invocation of method
    await h_t_t_p_response_0.write("")

    # Check
    assert h_t_t_p_response_0.stream is None



# Generated at 2022-06-26 03:59:30.261521
# Unit test for function file_stream
def test_file_stream():
    # Test 1
    try:
        test_file_stream_0()
    except Exception:
        raise Exception



# Generated at 2022-06-26 03:59:34.334393
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    h_t_t_p_response_1 = HTTPResponse()
    h_t_t_p_response_1.send(h_t_t_p_response_1)


# Generated at 2022-06-26 03:59:38.299970
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # This test is considered to be completed if there is no exception
    streaming_ht_t_p_response_0 = StreamingHTTPResponse(lambda x: True)
    streaming_ht_t_p_response_0.send("")


# Generated at 2022-06-26 03:59:46.300613
# Unit test for function html
def test_html():
    h_1 = html("This is a string")
    assert h_1.content_type == "text/html; charset=utf-8"
    assert h_1.body == b"This is a string"

    h_2 = html("This is another string", headers={"header":"value"})
    assert h_2.content_type == "text/html; charset=utf-8"
    assert h_2.body == b"This is another string"
    assert h_2.headers == Header({'header': "value"})

    h_3 = html("<html><body>This is a string</body></html>")
    assert h_3.content_type == "text/html; charset=utf-8"