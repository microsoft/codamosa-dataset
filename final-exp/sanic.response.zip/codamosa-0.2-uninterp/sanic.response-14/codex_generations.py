

# Generated at 2022-06-18 05:57:46.784273
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import mock_open


# Generated at 2022-06-18 05:57:51.634765
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 05:57:54.842164
# Unit test for function html
def test_html():
    assert html("<html>") == HTTPResponse(
        body="<html>",
        status=200,
        headers=None,
        content_type="text/html; charset=utf-8",
    )


# Generated at 2022-06-18 05:58:06.124724
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommon

# Generated at 2022-06-18 05:58:14.380754
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')

    response = stream(streaming_fn, content_type='text/plain')
    assert response.streaming_fn == streaming_fn
    assert response.content_type == 'text/plain'
    assert response.status == 200
    assert response.headers == {}
    assert response._cookies == None


# Generated at 2022-06-18 05:58:22.149235
# Unit test for function file_stream
def test_file_stream():
    async def test():
        location = "./test_file_stream.txt"
        with open(location, "w") as f:
            f.write("test_file_stream")
        response = await file_stream(location)
        assert response.body == b"test_file_stream"
        os.remove(location)
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()



# Generated at 2022-06-18 05:58:32.194325
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = "text/plain"
        headers = {}
        filename = "test_file.txt"
        _range = None
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                out_stream = await f.read(_range.size)
                headers[
                    "Content-Range"
                ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
                status = 206
            else:
                out_stream = await f.read()

        mime_type = mime_type or guess_type(filename)[0] or "text/plain"
        return

# Generated at 2022-06-18 05:58:43.741485
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import _encode_body
    from sanic.response import send
    from sanic.response import processed_headers
    from sanic.response import cookies
    from sanic.response import _dumps
    from sanic.response import __init__
    from sanic.response import __slots__
    from sanic.response import __getitem__
    from sanic.response import __setitem__
    from sanic.response import __delitem__
    from sanic.response import __contains__
    from sanic.response import __iter__

# Generated at 2022-06-18 05:58:54.917648
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 05:58:59.775123
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def test(request):
        return StreamingHTTPResponse(
            lambda response: response.write("Hello world!"),
            content_type="text/plain",
        )

    request, response = app.test_client.get("/")

    assert response.text == "Hello world!"



# Generated at 2022-06-18 05:59:18.229862
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 05:59:22.570675
# Unit test for function file_stream
def test_file_stream():
    async def test_fn(request):
        return await file_stream('./test_file_stream.py')

    app.add_route(test_fn, '/')
    client = app.test_client
    resp = client.get('/')
    assert resp.status == 200
    assert resp.text == open('./test_file_stream.py').read()


# Generated at 2022-06-18 05:59:34.044085
# Unit test for function file
def test_file():
    async def test_file_async():
        file_path = "./tests/test_file.txt"
        response = await file(file_path)
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.body == b"test_file"
        response = await file(file_path, filename="test_file_new.txt")
        assert response.headers["Content-Disposition"] == 'attachment; filename="test_file_new.txt"'
        response = await file(file_path, mime_type="text/html")
        assert response.content_type == "text/html"
        response = await file(file_path, _range=Range(0, 3, 4))
        assert response.status == 206

# Generated at 2022-06-18 05:59:39.335754
# Unit test for function file
def test_file():
    async def test():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 05:59:47.740512
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.server import HttpProtocol as HttpProtocol_
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol as WebSocketProtocol_
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol as WebSocketCommonProtocol_
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed as WebSocketConnectionClosed_
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketError as WebSocketError_
    from sanic.websocket import WebSocketState

# Generated at 2022-06-18 05:59:58.707005
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol

# Generated at 2022-06-18 06:00:04.054963
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./tests/test_files/test.txt"
        status = 200
        mime_type = "text/plain"
        headers = {}
        filename = "test.txt"
        _range = None
        response = await file(location, status, mime_type, headers, filename, _range)
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.body == b"Hello World"
    test_file_async()



# Generated at 2022-06-18 06:00:10.898328
# Unit test for function file_stream
def test_file_stream():
    async def test_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    assert StreamingHTTPResponse(
        streaming_fn=test_streaming_fn,
        status=200,
        headers={},
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:00:20.858078
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import mock_open


# Generated at 2022-06-18 06:00:32.444621
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection

# Generated at 2022-06-18 06:00:51.073848
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import asyncio
    from sanic.response import file_stream
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT

    async def test_file_stream_handler(request):
        return await file_stream(__file__, chunk_size=1)

    app = Sanic("test_file_stream")
    app.add_route(test_file_stream_handler, "/test_file_stream")

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    server = app.create_server(host=HOST, port=PORT, return_asyncio_server=True)
    server = loop.run_until_complete(server)


# Generated at 2022-06-18 06:00:59.614357
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.compat import Header
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.compat import Header
    from sanic.helpers import has_message_body, remove_entity_headers

# Generated at 2022-06-18 06:01:01.092937
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Test for method send of class BaseHTTPResponse
    # This test is not complete
    # TODO: Complete this test
    pass



# Generated at 2022-06-18 06:01:11.757455
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketCommonReader
    from sanic.websocket import WebSocketCommon

# Generated at 2022-06-18 06:01:16.481180
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:01:22.809935
# Unit test for function file_stream
def test_file_stream():
    async def test_stream(response):
        async with await open_async("test.txt", mode="rb") as f:
            while True:
                content = await f.read(1024)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_stream,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:01:32.489911
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.helpers import has_message_body
    from sanic.helpers import remove_entity_headers
    from sanic.compat import Header
    from sanic.compat import open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body
    from sanic.helpers import remove_entity_headers

# Generated at 2022-06-18 06:01:39.173605
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    response = StreamingHTTPResponse(sample_streaming_fn)
    assert response.streaming_fn == sample_streaming_fn
    assert response.status == 200
    assert response.content_type == "text/plain; charset=utf-8"
    assert response.headers == Header({})
    assert response._cookies == None


# Generated at 2022-06-18 06:01:47.595709
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest import TestCase

    class TestStreamingHTTPResponse(TestCase):
        def test_write(self):
            response = StreamingHTTPResponse(Mock())
            response.stream = Mock()
            response.write("foo")
            response.stream.send.assert_called_once_with(b"foo", end_stream=False)

    test = TestStreamingHTTPResponse()
    test.test_write()

# Generated at 2022-06-18 06:01:58.343544
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range

# Generated at 2022-06-18 06:02:24.361636
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.server import HttpProtocol as HttpProtocol_
    from sanic.server import HttpProtocol as HttpProtocol__
    from sanic.server import HttpProtocol as HttpProtocol___
    from sanic.server import HttpProtocol as HttpProtocol____
    from sanic.server import HttpProtocol as HttpProtocol_____
    from sanic.server import HttpProtocol as HttpProtocol______
    from sanic.server import HttpProtocol as HttpProtocol_______
    from sanic.server import HttpProtocol as HttpProtocol________
    from sanic.server import HttpProtocol as HttpProtocol_________
    from sanic.server import HttpProt

# Generated at 2022-06-18 06:02:33.374769
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.websocket import WebSocketProtocol

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(
                    streaming_fn, content_type="text/plain"
                )

            request, response = self.create_request(
                "/", headers={"Upgrade": "websocket"}
            )

# Generated at 2022-06-18 06:02:45.805119
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                out_stream = await f.read(_range.size)
                headers[
                    "Content-Range"
                ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
                status = 206
            else:
                out_stream = await f.read()

        mime_type = mime_type or guess_type(filename)[0] or "text/plain"

# Generated at 2022-06-18 06:02:51.236859
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    response = StreamingHTTPResponse(Mock())
    response.stream = Mock()
    response.write("foo")
    response.stream.send.assert_called_once_with(b"foo", end_stream=False)



# Generated at 2022-06-18 06:02:58.687075
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketCommonReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketCommonWriter
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocket

# Generated at 2022-06-18 06:03:09.425032
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)

# Generated at 2022-06-18 06:03:18.967673
# Unit test for function file_stream
def test_file_stream():
    async def test():
        location = "./tests/test_file.txt"
        status = 200
        chunk_size = 4096
        mime_type = "text/plain"
        headers = {}
        filename = "test_file.txt"
        chunked = "deprecated"
        _range = None
        headers = headers or {}
        if filename:
            headers.setdefault(
                "Content-Disposition", f'attachment; filename="{filename}"'
            )
        filename = filename or path.split(location)[-1]
        mime_type = mime_type or guess_type(filename)[0] or "text/plain"
        if _range:
            start = _range.start
            end = _range.end
            total = _range.total


# Generated at 2022-06-18 06:03:29.116772
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedAbnormalClosure
    from sanic.websocket import WebSocketConnectionClosedTLSHandshake
    from sanic.websocket import WebSocketConnectionClosedPolicyViolation
    from sanic.websocket import WebSocketConnectionClosedTooLarge

# Generated at 2022-06-18 06:03:39.527041
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http

# Generated at 2022-06-18 06:03:51.945984
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:04:21.188761
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    import asyncio
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol

    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    response = StreamingHTTPResponse(sample_streaming_fn)
    response.stream = HttpProtocol(Mock(), Mock())
    response.stream.send = Mock()
    response.stream.send.return_value = asyncio.Future()
    response.stream.send.return_value.set_result(None)
    response.stream.send.return_value.done.return_value = True

# Generated at 2022-06-18 06:04:29.305332
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import TestCase
    from unittest.mock import Mock, patch

    class TestStreamingHTTPResponse(TestCase):
        def test_write(self):
            with patch("sanic.response.StreamingHTTPResponse.send") as mock_send:
                mock_send.return_value = None
                response = StreamingHTTPResponse(None)
                response.write("foo")
                mock_send.assert_called_once_with(b"foo")

    return TestStreamingHTTPResponse



# Generated at 2022-06-18 06:04:35.667901
# Unit test for function file_stream
def test_file_stream():
    async def test_stream():
        async with await open_async("test.txt", mode="rb") as f:
            while True:
                content = await f.read(1024)
                if len(content) < 1:
                    break
                await response.write(content)
    return StreamingHTTPResponse(
        streaming_fn=test_stream,
        status=200,
        headers={},
        content_type="text/plain",
    )



# Generated at 2022-06-18 06:04:37.442611
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # Test for method send of class StreamingHTTPResponse
    # This is a static method
    pass



# Generated at 2022-06-18 06:04:45.941598
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedAbnormal
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedTLSHandshake
    from sanic.websocket import WebSocketConnectionClosedPolicyViolation
    from sanic.websocket import WebSocketConnectionClosedTooLarge

# Generated at 2022-06-18 06:04:57.379127
# Unit test for function file_stream
def test_file_stream():
    async def test_stream(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)
    location = "./test_file_stream.txt"
    chunk_size = 4096
    mime_type = "text/plain"
    headers = {}

# Generated at 2022-06-18 06:04:59.950210
# Unit test for function file
def test_file():
    location = "./sanic/response.py"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    file(location, status, mime_type, headers, filename, _range)


# Generated at 2022-06-18 06:05:11.393066
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import asyncio
    from sanic.response import file_stream
    from sanic.server import HttpProtocol
    from sanic.testing import SanicTestClient

    app = Sanic("test_file_stream")
    _, tmp_file = tempfile.mkstemp()

    @app.route("/")
    async def handler(request):
        return await file_stream(tmp_file)

    with open(tmp_file, "w") as f:
        f.write("Hello World")

    client = SanicTestClient(app, protocol=HttpProtocol)
    request, response = client.get("/")
    assert response.status == 200
    assert response.body == b"Hello World"

    os.remove(tmp_file)



# Generated at 2022-06-18 06:05:17.092474
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(b"<html>").content_type == "text/html; charset=utf-8"
    assert html(b"<html>").status == 200
    assert html(b"<html>").headers == {}



# Generated at 2022-06-18 06:05:25.128382
# Unit test for function file
def test_file():
    from sanic.response import HTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic(__name__)

    @app.route("/")
    async def handler(request):
        return await file("tests/test_server.py")

    request, response = SanicTestClient(app).get("/")
    assert response.status == 200
    assert isinstance(response, HTTPResponse)
    assert response.body == b"from sanic.response import HTTPResponse\n"



# Generated at 2022-06-18 06:06:22.611971
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import PropertyMock
    from unittest.mock import mock_open
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import DEFAULT

# Generated at 2022-06-18 06:06:30.894449
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.compat import Header

# Generated at 2022-06-18 06:06:36.369577
# Unit test for function file
def test_file():
    async def test_file_async():
        file_path = path.join(path.dirname(__file__), "test.txt")
        response = await file(file_path)
        assert response.body == b"Hello World!"
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.headers["Content-Disposition"] == 'attachment; filename="test.txt"'
    test_file_async()



# Generated at 2022-06-18 06:06:45.624919
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.status, 200)
            self.assertEqual(response.body, b"foobar")

    TestStreamingHTTPResponse().test_streaming_response()


# Generated at 2022-06-18 06:06:50.221742
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()


# Generated at 2022-06-18 06:06:55.321959
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()


# Generated at 2022-06-18 06:07:04.593000
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:07:13.684993
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest import mock
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Protocol
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType

# Generated at 2022-06-18 06:07:19.341297
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./tests/test_files/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()



# Generated at 2022-06-18 06:07:26.242167
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.testing import SanicTestClient

    app = Sanic('test_StreamingHTTPResponse_write')

    @app.route('/')
    async def handler(request):
        return StreamingHTTPResponse(
            streaming_fn=lambda response: response.write('Hello world!'),
            content_type='text/plain')

    request, response = app.test_client.get('/')

    assert response.text == 'Hello world!'
