

# Generated at 2022-06-18 05:57:56.258675
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketStream
    from sanic.websocket import WebSocketCommonStream
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketCommonConnectionClosed

# Generated at 2022-06-18 05:57:58.348124
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')

    response = stream(streaming_fn, content_type='text/plain')
    assert response.streaming_fn == streaming_fn
    assert response.content_type == 'text/plain'
    assert response.status == 200
    assert response.headers == {}


# Generated at 2022-06-18 05:58:04.441792
# Unit test for function file_stream
def test_file_stream():
    async def test():
        location = "./test_file_stream.txt"
        with open(location, "w") as f:
            f.write("test")
        response = await file_stream(location)
        assert response.body == b"test"
        os.remove(location)
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())


# Generated at 2022-06-18 05:58:20.734762
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import shutil
    import asyncio
    from sanic.response import file_stream
    from sanic.response import HTTPResponse

    def test_file_stream_generator():
        for i in range(10):
            yield str(i) * 1024

    def test_file_stream_generator_2():
        for i in range(10):
            yield str(i) * 1024

    def test_file_stream_generator_3():
        for i in range(10):
            yield str(i) * 1024

    async def test_file_stream_async_generator():
        for i in range(10):
            yield str(i) * 1024


# Generated at 2022-06-18 05:58:28.465251
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain",
    )


# Generated at 2022-06-18 05:58:35.661501
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    import asyncio
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.websocket import WebSocketProtocol

    class Test(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/", protocol=WebSocketProtocol)
            self.assertEqual(response.body, b"foobar")

    test = Test()
    test.test_streaming

# Generated at 2022-06-18 05:58:47.326166
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    import asyncio
    import pytest
    from unittest.mock import Mock
    from sanic.response import BaseHTTPResponse
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.http import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import WebSocketProtocol
    from sanic.models.protocol_types import WebSocketState
    from sanic.models.protocol_types import WebSocketType
    from sanic.models.protocol_types import WebSocket
    from sanic.models.protocol_types import WebSocketMessage

# Generated at 2022-06-18 05:58:57.377258
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import mock
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open


# Generated at 2022-06-18 05:59:09.313343
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol

# Generated at 2022-06-18 05:59:16.406963
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import patch
    from unittest import TestCase

    class TestStreamingHTTPResponse(TestCase):
        @patch("sanic.response.StreamingHTTPResponse.send")
        def test_write(self, mock_send):
            response = StreamingHTTPResponse(lambda x: None)
            response.write("foo")
            mock_send.assert_called_once_with(b"foo")

    test = TestStreamingHTTPResponse()
    test.test_write()

# Generated at 2022-06-18 05:59:46.771660
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.testing import SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_send")

    async def streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return StreamingHTTPResponse(streaming_fn)

    request, response = app.test_client.post("/")

    assert response.status == 200
    assert response.text == "foobar"



# Generated at 2022-06-18 05:59:57.940124
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                out_stream = await f.read(_range.size)
                headers[
                    "Content-Range"
                ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
                status = 206
            else:
                out_stream = await f.read()

        mime_type = mime_type or guess_type(filename)[0] or "text/plain"

# Generated at 2022-06-18 06:00:05.299202
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import StreamProtocol
    from sanic.models.protocol_types import WebSocketProtocol
    from sanic.models.protocol_types import WebSocketState
    from sanic.models.protocol_types import WebSocketType
    from sanic.models.protocol_types import WebSocketType
    from sanic.models.protocol_types import WebSocketType

# Generated at 2022-06-18 06:00:14.978746
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_write")

    @app.route("/")
    async def handler(request):
        async def streaming_fn(response):
            await response.write("foo")
            await asyncio.sleep(1)
            await response.write("bar")
            await asyncio.sleep(1)

        return StreamingHTTPResponse(streaming_fn)

    request, response = app.test_client.get("/")

    assert response.text == "foobar"



# Generated at 2022-06-18 06:00:23.295358
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.websocket import WebSocketProtocol

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await response.write("bar")

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.get("/")
            self.assertEqual(response.body, b"foobar")

    TestStreamingHTTPResponse().test_streaming_response()


# Generated at 2022-06-18 06:00:32.651633
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)
    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:00:41.958916
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)
    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:00:45.482597
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol()).body == b"<html>"



# Generated at 2022-06-18 06:00:54.878940
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 06:01:01.243765
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient
    from sanic import Sanic

    app = Sanic("test_BaseHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(b"Awesome!")

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.body == b"Awesome!"



# Generated at 2022-06-18 06:01:27.124016
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "tests/test_file.txt"
        status = 200
        mime_type = "text/plain"
        headers = {}
        filename = "test_file.txt"
        _range = None
        response = await file(location, status, mime_type, headers, filename, _range)
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.body == b"This is a test file"
    test_file_async()


# Generated at 2022-06-18 06:01:31.672978
# Unit test for function file
def test_file():
    async def test_file_async(location, status, mime_type, headers, filename, _range):
        return await file(location, status, mime_type, headers, filename, _range)

    assert test_file_async("/tmp/test.txt", 200, None, None, None, None)


# Generated at 2022-06-18 06:01:40.384671
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def test(request):
        return StreamingHTTPResponse(
            lambda response: response.write("foo"),
            status=200,
            headers={"test": "test"},
            content_type="text/plain; charset=utf-8",
        )

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.headers.get("test") == "test"

# Generated at 2022-06-18 06:01:52.050527
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketStream
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError

# Generated at 2022-06-18 06:02:02.368561
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async(__file__, mode="rb") as f:
            content = await f.read()
        response = await file_stream(__file__)
        assert response.status == 200
        assert response.content_type == "text/x-python"
        assert response.body == content
        response = await file_stream(__file__, _range=Range(0, 10, 100))
        assert response.status == 206
        assert response.content_type == "text/x-python"
        assert response.body == content[0:10]
        assert response.headers["Content-Range"] == "bytes 0-10/100"
    asyncio.run(test())



# Generated at 2022-06-18 06:02:10.396502
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketStream
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketError

# Generated at 2022-06-18 06:02:15.642494
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:02:27.216444
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest import mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import Range
    from sanic.compat import Header, open_async
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message

# Generated at 2022-06-18 06:02:34.676169
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http

# Generated at 2022-06-18 06:02:47.456149
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_inner():
        file_stream_response = await file_stream(
            "./test_file_stream.py",
            status=200,
            chunk_size=4096,
            mime_type=None,
            headers=None,
            filename=None,
            chunked="deprecated",
            _range=None,
        )
        assert file_stream_response.status == 200
        assert file_stream_response.content_type == "text/plain"
        assert file_stream_response.headers == {}
        assert file_stream_response.stream.send is not None
        assert file_stream_response.streaming_fn is not None
        assert file_stream_response.stream.send is not None
        assert file_stream_response.stream.send is not None
        assert file_stream

# Generated at 2022-06-18 06:03:33.004818
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers

# Generated at 2022-06-18 06:03:36.906765
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"



# Generated at 2022-06-18 06:03:41.243930
# Unit test for function html
def test_html():
    assert html("<html></html>") == HTTPResponse(
        "<html></html>",
        status=200,
        headers=None,
        content_type="text/html; charset=utf-8",
    )



# Generated at 2022-06-18 06:03:41.939419
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    pass


# Generated at 2022-06-18 06:03:54.210444
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range


# Generated at 2022-06-18 06:04:01.318005
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 06:04:06.330972
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:04:14.764797
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain",
    )



# Generated at 2022-06-18 06:04:23.341239
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import DEFAULT
    from unittest.mock import AsyncMock
    from unittest.mock import PropertyMock
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_

# Generated at 2022-06-18 06:04:35.221523
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.cookies import CookieJar
    from sanic.compat import Header
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.cookies import CookieJar

# Generated at 2022-06-18 06:06:51.224348
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # BaseHTTPResponse.send(data=None, end_stream=None)
    pass


# Generated at 2022-06-18 06:07:00.785766
# Unit test for function file
def test_file():
    async def test():
        response = await file("/tmp/test.txt")
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.body == b"test"
        response = await file("/tmp/test.txt", filename="test.txt")
        assert response.headers["Content-Disposition"] == 'attachment; filename="test.txt"'
        response = await file("/tmp/test.txt", _range=Range(0, 3, 4))
        assert response.status == 206
        assert response.headers["Content-Range"] == "bytes 0-3/4"
        assert response.body == b"test"
    asyncio.run(test())



# Generated at 2022-06-18 06:07:05.978632
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("tests/test_file", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)
    assert StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain",
    )



# Generated at 2022-06-18 06:07:15.642923
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    import asyncio
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed

    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    async def test(request):
        return StreamingHTTPResponse(sample_streaming_fn)

    app = Sanic("test_StreamingHTTPResponse_write")
    app.add_route(test, "/")

    client = await app.create_client(host=HOST, port=PORT)
    ws = await client.ws_connect("/")

# Generated at 2022-06-18 06:07:26.240548
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketCommon


# Generated at 2022-06-18 06:07:33.730742
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import create_autospec
    from unittest.mock import mock_open