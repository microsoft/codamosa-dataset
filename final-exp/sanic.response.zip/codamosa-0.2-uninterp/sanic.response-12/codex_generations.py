

# Generated at 2022-06-18 05:57:46.784300
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.status, 200)
            self.assertEqual(response.body, b"foobar")

# Generated at 2022-06-18 05:57:58.593222
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 05:58:08.462664
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommonConnectionClosed
    from sanic.websocket import WebSocketCommonError
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommonConnectionClosed
    from sanic.websocket import WebSocketCommonError
    from sanic.websocket import WebSocketCommonState
   

# Generated at 2022-06-18 05:58:21.573764
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import FileStream
    from sanic.response import FileStream
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import FileStream
    from sanic.response import FileStream
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import FileStream
    from sanic.response import FileStream
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import FileStream

# Generated at 2022-06-18 05:58:29.217866
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("tests/test_file.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    assert StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain",
    )



# Generated at 2022-06-18 05:58:36.035348
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import text
    from sanic.response import json
    from sanic.response import html
    from sanic.response import file
    from sanic.response import redirect
    from sanic.response import stream
    from sanic.response import file_stream
    from sanic.response import json_dumps
    from sanic.response import HTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import HT

# Generated at 2022-06-18 05:58:48.062700
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol

# Generated at 2022-06-18 05:58:54.862219
# Unit test for function file_stream
def test_file_stream():
    async def test():
        location = "./tests/test_file.txt"
        response = await file_stream(location)
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.headers["Content-Disposition"] == 'attachment; filename="test_file.txt"'
        assert response.body == b"test"
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()



# Generated at 2022-06-18 05:58:58.382322
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"



# Generated at 2022-06-18 05:59:09.929308
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    response = HTTPResponse()
    response.send(data=None, end_stream=None)
    response.send(data=None, end_stream=True)
    response.send(data=None, end_stream=False)
    response.send(data='', end_stream=None)
    response.send(data='', end_stream=True)
    response.send(data='', end_stream=False)
    response.send(data='a', end_stream=None)
    response.send(data='a', end_stream=True)
    response.send(data='a', end_stream=False)
    response.send(data=b'', end_stream=None)
    response.send(data=b'', end_stream=True)
   

# Generated at 2022-06-18 05:59:45.104168
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Stream
    from sanic.models.protocol_types import StreamBuffer
    from sanic.models.protocol_types import StreamBuffer
    from sanic.models.protocol_types import StreamBuffer
    from sanic.models.protocol_types import StreamBuffer
    from sanic.models.protocol_types import StreamBuffer
    from sanic.models.protocol_types import StreamBuffer
    from sanic.models.protocol_types import StreamBuffer
    from sanic.models.protocol_types import Stream

# Generated at 2022-06-18 05:59:56.502920
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.status, 200)
            self.assertEqual(response.text, "foobar")

    test_StreamingHTTPResponse = TestStreamingHTTPResponse

# Generated at 2022-06-18 06:00:04.602644
# Unit test for function file_stream
def test_file_stream():
    async def test_stream(response):
        async with await open_async("test.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    response = StreamingHTTPResponse(
        streaming_fn=test_stream,
        status=200,
        headers={},
        content_type="text/plain; charset=utf-8",
    )
    assert response.status == 200
    assert response.content_type == "text/plain; charset=utf-8"
    assert response.headers == {}
    assert response.streaming_fn == test_stream
    assert response.stream.send == None
    assert response.stream.receive == None

# Generated at 2022-06-18 06:00:14.702255
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel

    mock_stream = Mock()
    mock_stream.send = Mock()
    mock_stream.send.return_value = sentinel.send_return_value

    response = StreamingHTTPResponse(None)
    response.stream = mock_stream

    data = sentinel.data
    expected_data = data.encode() if hasattr(data, "encode") else data

    assert response.write(data) == sentinel.send_return_value
    mock_stream.send.assert_called_once_with(expected_data, end_stream=None)


# Generated at 2022-06-18 06:00:18.787447
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:00:26.287755
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async def _streaming_fn(response):
            async with await open_async(location, mode="rb") as f:
                if _range:
                    await f.seek(_range.start)
                    to_send = _range.size
                    while to_send > 0:
                        content = await f.read(min((_range.size, chunk_size)))
                        if len(content) < 1:
                            break
                        to_send -= len(content)
                        await response.write(content)
                else:
                    while True:
                        content = await f.read(chunk_size)
                        if len(content) < 1:
                            break
                        await response.write(content)


# Generated at 2022-06-18 06:00:31.875089
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./tests/test_file"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)

    test_file_async()



# Generated at 2022-06-18 06:00:39.050719
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest import mock
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol

    mock_stream = Mock(spec=HttpProtocol)
    mock_stream.send = Mock()
    mock_stream.send.return_value = None
    mock_stream.send.__name__ = "send"

    mock_streaming_fn = Mock()
    mock_streaming_fn.return_value = None
    mock_streaming_fn.__name__ = "streaming_fn"

    mock_args = Mock()
    mock_args.__name__ = "args"

    mock_kwargs = Mock()
    mock_kwargs.__name__ = "kwargs"

    mock_data = Mock()

# Generated at 2022-06-18 06:00:50.107511
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
   

# Generated at 2022-06-18 06:00:54.653786
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(b"<html>").content_type == "text/html; charset=utf-8"
    assert html(b"<html>").status == 200
    assert html(b"<html>").headers == {}



# Generated at 2022-06-18 06:01:15.920768
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http

# Generated at 2022-06-18 06:01:25.336077
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
   

# Generated at 2022-06-18 06:01:35.893717
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:01:46.648082
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            request, response = self.create_request(
                method="POST", path="/", headers={"Content-Type": "text/plain"}
            )

            response = StreamingHTTPResponse(
                streaming_fn,
                status=200,
                headers={"Content-Type": "text/plain"},
                content_type="text/plain; charset=utf-8",
            )
            response.stream

# Generated at 2022-06-18 06:01:52.950067
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage
    from sanic.server import HttpProtocol as HttpProtocolServer
    from sanic.websocket import WebSocketProtocol as WebSocketProtocolServer
    from sanic.server import WebSocketProtocol as WebSocketProtocolServer
    from sanic.server import HttpProtocol as HttpProtocolServer
    from sanic.websocket import WebSocketProtocol as WebSocketProtocolServer
    from sanic.server import WebSocketProtocol as WebSocketProtocolServer

# Generated at 2022-06-18 06:02:04.344335
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.server import HttpProtocol as HttpProtocol_
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProt

# Generated at 2022-06-18 06:02:08.968774
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient

    app = Sanic("test_BaseHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(b"Hello")

    request, response = app.test_client.get("/")

    assert response.body == b"Hello"



# Generated at 2022-06-18 06:02:14.864126
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"
    assert html(HTMLProtocol(b"<html>")).body == b"<html>"



# Generated at 2022-06-18 06:02:26.701545
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.compat import is_coroutine_function
    import asyncio
    import pytest
    import sys
    import os
    import io
    import contextlib
    import tempfile

    @contextlib.contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = io.StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old

    @contextlib.contextmanager
    def stderrIO(stderr=None):
        old = sys.stderr

# Generated at 2022-06-18 06:02:30.904891
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = "text/plain"
        headers = {}
        filename = "test.txt"
        _range = None
        await file(location, status, mime_type, headers, filename, _range)

    asyncio.run(test())



# Generated at 2022-06-18 06:02:57.329081
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.server import HttpProtocol as HttpProtocol_
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol as WebSocketProtocol_
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol as WebSocketCommonProtocol_
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed as WebSocketConnectionClosed_
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketError as WebSocketError_
    from sanic.websocket import WebSocketReader

# Generated at 2022-06-18 06:03:02.219763
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()


# Generated at 2022-06-18 06:03:13.328370
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import mock
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr
    from sanic.response import Union
    from sanic.response import bytes
    from sanic.response import hasattr
    from sanic.response import partial
    from sanic.response import warn
    from sanic.response import Header
    from sanic.response import Dict
    from sanic.response import str
    from sanic.response import int
    from sanic.response import CoroutineMock
    from sanic.response import Mock
    from sanic.response import patch


# Generated at 2022-06-18 06:03:20.480281
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:03:30.271343
# Unit test for function file
def test_file():
    async def test_file_async():
        file_path = path.join(path.dirname(__file__), "test_file.txt")
        response = await file(file_path)
        assert response.body == b"This is a test file."
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.headers["Content-Disposition"] == 'attachment; filename="test_file.txt"'
        response = await file(file_path, filename="test_file2.txt")
        assert response.headers["Content-Disposition"] == 'attachment; filename="test_file2.txt"'
        response = await file(file_path, filename="test_file2.txt", _range=Range(0, 3, 4))
        assert response.body == b"This"
       

# Generated at 2022-06-18 06:03:34.405688
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)

    test_file_async()



# Generated at 2022-06-18 06:03:47.131554
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestClient
    from sanic import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 06:03:51.945143
# Unit test for function file
def test_file():
    async def test():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:03:57.719677
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(b"<html>").content_type == "text/html; charset=utf-8"
    assert html("<html>").content_type == "text/html; charset=utf-8"
    assert html(b"<html>").status == 200
    assert html("<html>").status == 200



# Generated at 2022-06-18 06:04:10.340478
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers

# Generated at 2022-06-18 06:04:39.800111
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.server import HttpProtocol as HttpProtocol_
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http

# Generated at 2022-06-18 06:04:47.030663
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 06:04:58.048153
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    import asyncio
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def setUp(self):
            super().setUp()

            async def sample_streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.post("/")
            async def test(request):
                return StreamingHTTPResponse(sample_streaming_fn)

        def test_streaming_response(self):
            response = self.get("/", stream=True)
            self.assertEqual(response.body, b"foobar")

# Generated at 2022-06-18 06:05:07.868792
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import text
    from sanic.response import json
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream
    from sanic.response import raw
    from sanic.response import json_dumps
    from sanic.response import HTTPResponseBody
    from sanic.response import HTTPResponseStream
    from sanic.response import HTTPResponseFile
    from sanic.response import HTTPResponseRedirect
    from sanic.response import HTTPResponseStreaming

# Generated at 2022-06-18 06:05:19.296948
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import asyncio
    from sanic.response import file_stream
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT

    app = Sanic("test_file_stream")

    @app.route("/")
    async def handler(request):
        return await file_stream(__file__, chunk_size=1024)

    @app.websocket("/ws")
    async def ws_handler(request, ws):
        await ws.send(__file__)

    loop = asyncio.get_event_loop()

# Generated at 2022-06-18 06:05:24.379069
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:05:32.279076
# Unit test for function file
def test_file():
    async def test():
        assert await file("tests/test_files/test.txt")
        assert await file("tests/test_files/test.txt", filename="test.txt")
        assert await file("tests/test_files/test.txt", filename="test.txt", _range=Range(0, 5, 6))
        assert await file("tests/test_files/test.txt", filename="test.txt", _range=Range(0, 5, 6), mime_type="text/plain")
        assert await file("tests/test_files/test.txt", filename="test.txt", _range=Range(0, 5, 6), mime_type="text/plain", headers={"Content-Disposition": 'attachment; filename="test.txt"'})
    loop = asyncio.get_event_loop()
    loop.run_until

# Generated at 2022-06-18 06:05:42.947029
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 06:05:50.179518
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_test(request):
        return await file_stream(
            "tests/test_utils/test_file.txt",
            status=200,
            chunk_size=4096,
            mime_type=None,
            headers=None,
            filename=None,
            chunked="deprecated",
            _range=None,
        )

    app = Sanic("test_file_stream")
    app.add_route(test_file_stream_test, "/test_file_stream")
    request, response = app.test_client.get("/test_file_stream")
    assert response.status == 200
    assert response.text == "This is a test file.\n"



# Generated at 2022-06-18 06:06:00.733419
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header
    from sanic.http import Http

# Generated at 2022-06-18 06:06:31.041299
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:06:39.989665
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import DEFAULT
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:06:49.722006
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    import asyncio
    from sanic.response import StreamingHTTPResponse

    async def test_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    response = StreamingHTTPResponse(test_streaming_fn)
    response.stream = Mock()
    response.stream.send = Mock()
    response.stream.send.return_value = asyncio.Future()
    response.stream.send.return_value.set_result(None)

# Generated at 2022-06-18 06:07:00.376705
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.compat import Header, open_async
    from sanic.http import Http
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers


# Generated at 2022-06-18 06:07:07.643328
# Unit test for function file
def test_file():
    async def test_file_inner():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                out_stream = await f.read(_range.size)
                headers[
                    "Content-Range"
                ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
                status = 206
            else:
                out_stream = await f.read()

        mime_type = mime_type or guess_type(filename)[0] or "text/plain"

# Generated at 2022-06-18 06:07:11.571297
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()


# Generated at 2022-06-18 06:07:20.804731
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_StreamingHTTPResponse_write")

    async def streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(streaming_fn)

    request, response = SanicTestClient(app).get("/")
    assert response.text == "foobar"



# Generated at 2022-06-18 06:07:28.824330
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import test_StreamingHTTPResponse_write
    from sanic.response import test_StreamingHTTPResponse_send
    from sanic.response import test_StreamingHTTPResponse_init
    from sanic.response import test_StreamingHTTPResponse_init_with_chunked
    from sanic.response import test_StreamingHTTPResponse_init_with_headers
    from sanic.response import test_StreamingHTTPResponse_init_with_status
    from sanic.response import test_StreamingHTTPResponse_init_with_content