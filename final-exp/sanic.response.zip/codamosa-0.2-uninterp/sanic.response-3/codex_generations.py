

# Generated at 2022-06-18 05:57:50.729740
# Unit test for function file
def test_file():
    async def test():
        assert await file("/tmp/test.txt")
    test()


# Generated at 2022-06-18 05:57:56.071574
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()


# Generated at 2022-06-18 05:58:07.026627
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_StreamingHTTPResponse_send(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.post("/")
            async def test(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request(
                "POST", "/", protocol=WebSocketProtocol
            )
           

# Generated at 2022-06-18 05:58:12.400849
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 05:58:25.885645
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol

    app = Sanic("test_StreamingHTTPResponse_write")

    @app.websocket("/test")
    async def test(request, ws):
        await ws.send("foo")
        await asyncio.sleep(1)
        await ws.send("bar")
        await asyncio.sleep(1)

    request, response = app.test_client.get("/test", protocol=WebSocketProtocol)
    assert response.status == 101
    assert response.headers["upgrade"] == "websocket"
    assert response.headers["connection"] == "upgrade"


# Generated at 2022-06-18 05:58:30.110663
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()


# Generated at 2022-06-18 05:58:40.803832
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import PropertyMock
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 05:58:52.952149
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic.views import CompositionView

    app = Sanic("test_StreamingHTTPResponse_write")

    class StreamingView(CompositionView):
        async def get(self, request):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            return StreamingHTTPResponse(streaming_fn)

    app.add_route(StreamingView.as_view(), "/")

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "foobar"



# Generated at 2022-06-18 05:59:03.978727
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketCommonConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketCommonConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketCommonConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
   

# Generated at 2022-06-18 05:59:13.560909
# Unit test for function file_stream
def test_file_stream():
    async def test_stream(response):
        async with await open_async(location, mode="rb") as f:
            while True:
                content = await f.read(chunk_size)
                if len(content) < 1:
                    break
                await response.write(content)
    location = "sanic/response.py"
    chunk_size = 4096
    mime_type = "text/plain"
    headers = {}
    filename = "response.py"
    chunked = "deprecated"
    _range = None
    status = 200
    streaming_fn = test_stream
    assert StreamingHTTPResponse(streaming_fn, status, headers, mime_type)


# Generated at 2022-06-18 05:59:35.040739
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_

# Generated at 2022-06-18 05:59:45.857573
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import patch
    from unittest.mock import Mock
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 05:59:57.323664
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header

# Generated at 2022-06-18 05:59:59.890736
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:00:11.005828
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import text
    from sanic.response import json
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream
    from sanic.response import json_dumps
    from sanic.response import stream
    from sanic.response import file_stream
    from sanic.response import raw
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse

# Generated at 2022-06-18 06:00:20.988637
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')

    response = stream(streaming_fn, content_type='text/plain')
    assert response.streaming_fn == streaming_fn
    assert response.content_type == 'text/plain'
    assert response.status == 200
    assert response.headers == {}
    assert response._cookies == None
    assert response.stream.send == None
    assert response.stream.receive == None
    assert response.stream.close == None
    assert response.stream.closed == False
    assert response.stream.transport == None
    assert response.stream.protocol == None
    assert response.stream.extra == None
    assert response.stream.loop == None
    assert response.stream.stream_id == None
    assert response.stream

# Generated at 2022-06-18 06:00:25.750150
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:00:33.417204
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic
    from sanic.response import text

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(text("test"))

    request, response = app.test_client.get("/")

    assert response.text == "test"


# Generated at 2022-06-18 06:00:45.945001
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async with await open_async("test.txt", mode="rb") as f:
            content = await f.read()
        async with await open_async("test.txt", mode="rb") as f:
            content_range = await f.read(10)
        async def _streaming_fn(response):
            async with await open_async("test.txt", mode="rb") as f:
                content_stream = await f.read()
            await response.write(content_stream)
        response = StreamingHTTPResponse(
            streaming_fn=_streaming_fn,
            status=200,
            headers={},
            content_type="text/plain; charset=utf-8",
        )
        assert response.status == 200

# Generated at 2022-06-18 06:00:52.669792
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain",
    )



# Generated at 2022-06-18 06:01:35.846414
# Unit test for function file_stream
def test_file_stream():
    async def test_stream():
        async with await open_async("test.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    response = StreamingHTTPResponse(
        streaming_fn=test_stream,
        status=200,
        headers={},
        content_type="text/plain",
    )
    response.send()


# Generated at 2022-06-18 06:01:46.601180
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
   

# Generated at 2022-06-18 06:01:57.652580
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Stream
    from sanic.models.protocol_types import StreamProtocol
    from sanic.models.protocol_types import StreamProtocolType
    from sanic.models.protocol_types import StreamType
    from sanic.models.protocol_types import StreamWriter
    from sanic.models.protocol_types import StreamWriterType
    from sanic.models.protocol_types import StreamWriterProtocol
    from sanic.models.protocol_types import StreamWriterProtocolType

# Generated at 2022-06-18 06:02:07.796201
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestClient
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_BaseHTTPResponse_send")

    @app.websocket("/test")
    async def handler(request, ws):
        await ws.send("test")
        await ws.send("test2")
        await ws.send("test3")

    request, response = app.test_client.get("/test", protocol=WebSocketProtocol)

    assert response.status == 101
    assert response.protocol == WebSocketProtocol

    assert response.stream.send is not None
    assert response.stream.send_str is not None
    assert response.stream.send_bytes is not None

# Generated at 2022-06-18 06:02:16.388203
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async("test.txt", mode="w") as f:
            await f.write("Hello World")
        response = await file_stream("test.txt")
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.headers["Content-Disposition"] == 'attachment; filename="test.txt"'
        assert response.body == b"Hello World"
        os.remove("test.txt")
    asyncio.run(test())


# Generated at 2022-06-18 06:02:25.517805
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.testing import SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            streaming_fn=lambda response: response.write("hello"),
            content_type="text/plain",
        )

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "hello"



# Generated at 2022-06-18 06:02:33.005102
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_write")

    async def streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.route("/")
    async def test(request):
        return StreamingHTTPResponse(streaming_fn)

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "foobar"



# Generated at 2022-06-18 06:02:45.804935
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header

# Generated at 2022-06-18 06:02:55.922990
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import AsyncMock, Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import RequestParameters
    from sanic.models.protocol_types import RequestParameters
    from sanic.models.protocol_types import RequestParameters
    from sanic.models.protocol_types import RequestParameters
    from sanic.models.protocol_types import RequestParameters
    from sanic.models.protocol_types import RequestParameters
    from sanic.models.protocol_types import RequestParameters
    from sanic.models.protocol_types import RequestParameters

# Generated at 2022-06-18 06:03:05.144039
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.testing import SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_write")

    @app.route("/")
    async def handler(request):
        async def streaming_fn(response):
            await response.write("foo")
            await asyncio.sleep(1)
            await response.write("bar")
            await asyncio.sleep(1)

        return StreamingHTTPResponse(streaming_fn)

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.body == b"foobar"



# Generated at 2022-06-18 06:03:56.591458
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class StreamingHTTPResponseTest(HttpTestCase):
        def test_send(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def test(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.get("/")
            self.assertEqual(response.text, "foobar")

    StreamingHTTPResponseTest().test_send()



# Generated at 2022-06-18 06:04:08.797774
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import asyncio
    from sanic.response import StreamingHTTPResponse
    from sanic.response import file_stream
    from sanic.testing import SanicTestClient

    app = Sanic("test_file_stream")

    @app.route("/")
    async def test(request):
        fd, path = tempfile.mkstemp()
        os.close(fd)
        with open(path, "wb") as f:
            f.write(b"Hello World!")
        response = await file_stream(path)
        os.remove(path)
        return response

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.body == b"Hello World!"


# Generated at 2022-06-18 06:04:14.252934
# Unit test for function file
def test_file():
    async def test():
        location = "./sanic/response.py"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:04:22.970725
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol

    app = Sanic("test_BaseHTTPResponse_send")

    @app.websocket("/test")
    async def test(request, ws):
        await ws.send("Hello")
        await ws.send("World")

    request, response = app.test_client.get("/test", protocol=WebSocketProtocol)

    assert response.status == 101
    assert response.headers.get("upgrade", "").lower() == "websocket"
    assert response.headers.get("connection", "").lower() == "upgrade"

# Generated at 2022-06-18 06:04:34.910772
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnection

# Generated at 2022-06-18 06:04:39.717782
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()



# Generated at 2022-06-18 06:04:46.958837
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:04:55.354103
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import TestCase
    from unittest.mock import patch

    class TestStreamingHTTPResponse(TestCase):
        def test_write(self):
            from sanic.response import StreamingHTTPResponse

            response = StreamingHTTPResponse(lambda x: None)
            with patch.object(response, "send") as mock_send:
                response.write("foo")
                mock_send.assert_called_once_with(b"foo")

    return TestStreamingHTTPResponse



# Generated at 2022-06-18 06:05:02.508432
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import shutil
    import asyncio
    from sanic.response import file_stream
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedAbnormalClosure
    from sanic.websocket import WebSocketConnectionClosedTLSHandshake
    from sanic.websocket import WebSocketConnection

# Generated at 2022-06-18 06:05:13.884350
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                out_stream = await f.read(_range.size)
                headers[
                    "Content-Range"
                ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
                status = 206
            else:
                out_stream = await f.read()

        mime_type = mime_type or guess_type(filename)[0] or "text/plain"

# Generated at 2022-06-18 06:06:57.164169
# Unit test for function html
def test_html():
    class Test:
        def __html__(self):
            return "html"
        def _repr_html_(self):
            return "repr_html"
    assert html("html").body == b"html"
    assert html(b"html").body == b"html"
    assert html(Test()).body == b"html"
    assert html(Test()).content_type == "text/html; charset=utf-8"
    assert html(Test()).status == 200
    assert html(Test(), status=404).status == 404
    assert html(Test(), headers={"test": "test"}).headers["test"] == "test"



# Generated at 2022-06-18 06:07:06.069209
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 06:07:15.717731
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.status, 200)
            self.assertEqual(response.text, "foobar")

    TestStreamingHTTPResponse().test_streaming_response()



# Generated at 2022-06-18 06:07:26.340351
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketError

# Generated at 2022-06-18 06:07:33.819527
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
   