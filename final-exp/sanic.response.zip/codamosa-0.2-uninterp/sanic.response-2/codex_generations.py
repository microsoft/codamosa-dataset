

# Generated at 2022-06-18 05:57:41.652825
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import shutil
    from sanic.response import file_stream
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import BaseHTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import empty
    from sanic.response import json
    from sanic.response import text
    from sanic.response import raw
    from sanic.response import html
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream
    from sanic.response import redirect
    from sanic.response import HTTPResponse
    from sanic.response import BaseHTTPResponse


# Generated at 2022-06-18 05:57:51.995595
# Unit test for function file_stream
def test_file_stream():
    async def test(request):
        return await file_stream(
            location=__file__,
            chunk_size=1024,
            mime_type="text/plain",
            headers={"Content-Disposition": 'attachment; filename="test.py"'},
            filename="test.py",
        )

    app = Sanic("test_file_stream")
    app.add_route(test, "/", methods=["GET"])

    _, response = app.test_client.get("/")
    assert response.status == 200
    assert response.headers.get("Content-Disposition") == 'attachment; filename="test.py"'
    assert response.headers.get("Content-Type") == "text/plain"
    assert response.text == open(__file__).read()



# Generated at 2022-06-18 05:58:00.882008
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)
    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 05:58:06.019125
# Unit test for function file
def test_file():
    async def test():
        response = await file(__file__)
        assert response.status == 200
        assert response.content_type == "text/x-python"
        assert response.headers["Content-Disposition"] == 'attachment; filename="test_responses.py"'
        assert response.body.decode() == open(__file__).read()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())



# Generated at 2022-06-18 05:58:12.354472
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 05:58:25.837562
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body
    from sanic.helpers import remove_entity_headers
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body
    from sanic.helpers import remove_entity_headers

# Generated at 2022-06-18 05:58:34.184366
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async def _streaming_fn(response):
            async with await open_async(location, mode="rb") as f:
                if _range:
                    await f.seek(_range.start)
                    to_send = _range.size
                    while to_send > 0:
                        content = await f.read(min((_range.size, chunk_size)))
                        if len(content) < 1:
                            break
                        to_send -= len(content)
                        await response.write(content)
                else:
                    while True:
                        content = await f.read(chunk_size)
                        if len(content) < 1:
                            break
                        await response.write(content)


# Generated at 2022-06-18 05:58:45.611717
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    import asyncio
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.body, b"foobar")

    test = TestStreamingHTTPResponse()
    test.test_streaming_response()



# Generated at 2022-06-18 05:58:56.135034
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedAbnormalClosure
    from sanic.websocket import WebSocketConnectionClosedTLSHandshake
    from sanic.websocket import WebSocketConnectionClosedPolicyViolation
    from sanic.websocket import WebSocketConnectionClosedMessageTooBig

# Generated at 2022-06-18 05:59:07.306832
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    import pytest
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.websocket("/ws")
    async def handler(request, ws):
        await ws.send("test")

    request, response = app.test_client.get("/ws", protocol=WebSocketProtocol)

    assert response.status == 101
    assert response.headers["Upgrade"] == "websocket"
    assert response.headers["Connection"] == "Upgrade"
    assert response.headers["Sec-WebSocket-Accept"] == "dGhlIHNhbXBsZSBub25jZQ=="

# Generated at 2022-06-18 05:59:42.640610
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.websocket import WebSocketProtocol

    class Test(HttpTestCase):
        def test_send(self):
            @self.app.route("/")
            async def handler(request):
                return HTTPResponse(body="test")

            request, response = self.get("/")
            assert response.body == b"test"
            assert response.status == 200
            assert response.content_type == "text/plain"
            assert response.headers["Content-Length"] == "4"
            assert response.stream is not None
            assert response.stream.send is not None

            request, response = self.get("/", protocol=WebSocketProtocol)
            assert response.body == b"test"


# Generated at 2022-06-18 05:59:54.064066
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE

# Generated at 2022-06-18 06:00:03.011799
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_

# Generated at 2022-06-18 06:00:14.179190
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.websocket import WebSocketProtocol

    class Test(HttpTestCase):
        def test_send(self):
            @self.app.route("/")
            async def handler(request):
                response = HTTPResponse("Hello")
                await response.send(request)
                return response

            request, response = self.get("/")
            self.assertEqual(response.text, "Hello")

            @self.app.route("/")
            async def handler(request):
                response = HTTPResponse("Hello")
                await response.send(request)
                await response.send(request)
                return response

            request, response = self.get("/")
            self.assertEqual

# Generated at 2022-06-18 06:00:20.565560
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    response = BaseHTTPResponse()
    response.stream = HttpProtocol()
    response.stream.send = None
    response.send(None, None)
    response.stream.send = None
    response.send(None, True)
    response.stream.send = None
    response.send(None, False)
    response.stream.send = None
    response.send("", None)
    response.stream.send = None
    response.send("", True)
    response.stream.send = None
    response.send("", False)
    response.stream.send = None
    response.send("test", None)
    response.stream.send = None
    response.send("test", True)
    response

# Generated at 2022-06-18 06:00:30.914482
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.testing import SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_write")

    @app.route("/")
    async def handler(request):
        async def streaming_fn(response):
            await response.write("foo")
            await asyncio.sleep(1)
            await response.write("bar")
            await asyncio.sleep(1)

        return StreamingHTTPResponse(streaming_fn)

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.body == b"foobar"



# Generated at 2022-06-18 06:00:38.567011
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import DEFAULT
    from unittest.mock import PropertyMock
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:00:49.883903
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http

# Generated at 2022-06-18 06:00:58.761277
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.body, b"foobar")

    test_StreamingHTTPResponse = TestStreamingHTTPResponse()

# Generated at 2022-06-18 06:01:08.140703
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_StreamingHTTPResponse_send")

    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return StreamingHTTPResponse(sample_streaming_fn)

    request, response = SanicTestClient(
        app, server_kwargs={"debug": True}
    ).post("/")

    assert response.status == 200
    assert response.body == b"foobar"



# Generated at 2022-06-18 06:01:38.210771
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    import asyncio
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.testing import SanicTestClient
    from sanic.testing import HOST, PORT
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import NotFound
    from sanic.exceptions import FileNotFound

# Generated at 2022-06-18 06:01:49.882761
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import Http
    from sanic.streams import Stream
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.helpers import has_message_body
    from sanic.helpers import remove_entity_headers
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol

# Generated at 2022-06-18 06:01:53.669417
# Unit test for function file
def test_file():
    location = "./tests/test_file.txt"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    asyncio.run(file(location, status, mime_type, headers, filename, _range))


# Generated at 2022-06-18 06:02:05.084727
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)

# Generated at 2022-06-18 06:02:11.673491
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open


# Generated at 2022-06-18 06:02:22.948342
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr
    from sanic.response import Optional
    from sanic.response import Union
    from sanic.response import Tuple
    from sanic.response import bytes
    from sanic.response import str
    from sanic.response import Dict
    from sanic.response import Header
    from sanic.response import Callable
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr
    from sanic.response import Optional
    from sanic.response import Union

# Generated at 2022-06-18 06:02:32.974615
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient
    from sanic.websocket import WebSocketProtocol

    class TestBaseHTTPResponse(HttpTestCase):
        def test_send(self):
            app = Sanic("test_BaseHTTPResponse_send")

            @app.route("/")
            async def handler(request):
                response = HTTPResponse(body="test")
                await response.send(data="test", end_stream=True)
                return response

            request, response = self.create_request(app, "/")
            self.assertEqual(response.body, b"test")

            request, response = self.create_request(app, "/")

# Generated at 2022-06-18 06:02:42.139027
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers=None,
        content_type="text/plain",
    )


# Generated at 2022-06-18 06:02:53.390069
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestClient
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_BaseHTTPResponse_send")

    @app.websocket("/test")
    async def test(request, ws):
        await ws.send("test")
        await ws.send("test")
        await ws.send("test")
        await ws.send("test")

    request, response = app.test_client.get("/test", protocol=WebSocketProtocol)

    assert response.status == 101
    assert response.body == b""
    assert response.headers["Upgrade"] == "websocket"
    assert response.headers["Connection"] == "Upgrade"

# Generated at 2022-06-18 06:02:56.705652
# Unit test for function file
def test_file():
    async def test():
        location = "./test/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:03:54.210184
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 06:03:59.392271
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient

    class TestStreamingHTTPResponse(HttpTestCase):
        def setUp(self):
            super().setUp()
            self.app.config.KEEP_ALIVE = False

        async def test_streaming_response(self):
            async def sample_streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def test(request):
                return StreamingHTTPResponse(sample_streaming_fn)

            request, response = await self.create_request("/", method="GET")

# Generated at 2022-06-18 06:04:11.513715
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import mock
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr
    from sanic.response import Optional
    from sanic.response import Union
    from sanic.response import Tuple
    from sanic.response import Iterator
    from sanic.response import Dict
    from sanic.response import Callable
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr
    from sanic.response import Optional
    from sanic.response import Union
    from sanic.response import T

# Generated at 2022-06-18 06:04:16.183839
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(b"<html>").content_type == "text/html; charset=utf-8"
    assert html(b"<html>").status == 200



# Generated at 2022-06-18 06:04:18.157129
# Unit test for function file
def test_file():
    location = "./test_file.txt"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    async def test():
        return await file(location, status, mime_type, headers, filename, _range)
    assert test()


# Generated at 2022-06-18 06:04:21.313494
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock

    response = StreamingHTTPResponse(Mock())
    response.stream = Mock()
    response.write("foo")
    response.stream.send.assert_called_once_with(b"foo", end_stream=False)



# Generated at 2022-06-18 06:04:22.421576
# Unit test for function file
def test_file():
    async def test():
        await file("test.txt")
    test()


# Generated at 2022-06-18 06:04:31.778297
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            streaming_fn=lambda response: response.write("test"),
            content_type="text/plain",
        )

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "test"



# Generated at 2022-06-18 06:04:41.652773
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:04:53.283674
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import patch
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http

# Generated at 2022-06-18 06:05:46.041060
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    import asyncio
    import pytest
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import HOST, PORT

    async def streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @pytest.mark.asyncio
    async def test_streaming_fn():
        app = Sanic("test_streaming_fn")

        @app.websocket("/")
        async def handler(request, ws):
            response = StreamingHTTPResponse(streaming_fn)
            await response.send(None, True)


# Generated at 2022-06-18 06:05:55.447584
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:05:59.481158
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:06:07.095658
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import asyncio
    from sanic.response import file_stream
    from sanic.server import HttpProtocol
    from sanic.testing import SanicTestClient

    async def test_file_stream_handler(request):
        return await file_stream(__file__, chunk_size=1)

    app = Sanic("test_file_stream")
    app.add_route(test_file_stream_handler, "/test_file_stream")

    client = SanicTestClient(app, protocol=HttpProtocol)
    request, response = client.get("/test_file_stream")
    assert response.status == 200
    assert response.body == open(__file__, "rb").read()

    # Test range

# Generated at 2022-06-18 06:06:19.325005
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 06:06:28.153556
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.streams import StreamProtocol
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketStreamProtocol
    from sanic.websocket import WebSocketCommonStreamProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedAbnormalClosure
    from sanic.websocket import WebSocketConnectionClosedTLSHand

# Generated at 2022-06-18 06:06:34.666621
# Unit test for function file
def test_file():
    location = "./test_file.txt"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    async def test_file():
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                out_stream = await f.read(_range.size)
                headers[
                    "Content-Range"
                ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
                status = 206
            else:
                out_stream = await f.read()

        mime_type = mime_type or guess_type(filename)[0] or "text/plain"

# Generated at 2022-06-18 06:06:43.312178
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.streams import StreamProtocol
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import sentinel
    from unittest.mock import sentinel
    from unittest.mock import sentinel
    from unittest.mock import sentinel
    from unittest.mock import sentinel
    from unittest.mock import sentinel
    from unittest.mock import sentinel
    from unittest.mock import sentinel
    from unittest.mock import sentinel
    from unittest.mock import sentinel
    from unittest.mock import sentinel

# Generated at 2022-06-18 06:06:53.001133
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_write")

    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return StreamingHTTPResponse(sample_streaming_fn)

    request, response = app.test_client.post("/")

    assert response.status == 200
    assert response.body == b"foobar"



# Generated at 2022-06-18 06:07:02.836534
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
