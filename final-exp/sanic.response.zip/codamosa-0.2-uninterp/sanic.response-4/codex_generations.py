

# Generated at 2022-06-18 05:58:03.217802
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import call
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 05:58:07.370089
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()


# Generated at 2022-06-18 05:58:20.834793
# Unit test for method send of class StreamingHTTPResponse

# Generated at 2022-06-18 05:58:31.232957
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_BaseHTTPResponse_send")

    @app.websocket("/test")
    async def test(request, ws):
        await ws.send("Hello")
        await ws.send("World")
        await ws.send("!")

    request, response = SanicTestClient(
        app, protocol=WebSocketProtocol
    ).get("/test")
    assert response.status == 101
    assert response.headers["upgrade"] == "websocket"
    assert response.headers["connection"] == "upgrade"
    assert response.headers["sec-websocket-accept"]

# Generated at 2022-06-18 05:58:41.968694
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar

# Generated at 2022-06-18 05:58:53.950253
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 05:59:04.735929
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 05:59:15.172271
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            response = self.get("/")
            self.assertEqual(response.text, "foobar")

    test = TestStreamingHTTPResponse()
    test.test_streaming_response()



# Generated at 2022-06-18 05:59:23.885045
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http

# Generated at 2022-06-18 05:59:32.222852
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_StreamingHTTPResponse_write")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            streaming_fn=lambda response: response.write("foo")
        )

    request, response = SanicTestClient(app).get("/")

    assert response.text == "foo"



# Generated at 2022-06-18 05:59:53.922437
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http

# Generated at 2022-06-18 05:59:57.681594
# Unit test for function file
def test_file():
    location = "./sanic/response.py"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    file(location, status, mime_type, headers, filename, _range)


# Generated at 2022-06-18 06:00:06.908537
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:00:09.766930
# Unit test for function file_stream
def test_file_stream():
    async def test_stream():
        return await file_stream(location="test.txt", chunk_size=1024)
    assert test_stream()


# Generated at 2022-06-18 06:00:11.837938
# Unit test for function file
def test_file():
    async def test():
        assert await file('/home/sang/Desktop/test.txt')
    test()


# Generated at 2022-06-18 06:00:21.593073
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
   

# Generated at 2022-06-18 06:00:33.688445
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import json
    from sanic.response import text
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream
    from sanic.response import json_dumps
    from sanic.response import json_loads
    from sanic.response import HTTPResponseBody
    from sanic.response import StreamingHTTPResponseBody
    from sanic.response import StreamingHTTPResponse
    from sanic.response import stream

# Generated at 2022-06-18 06:00:46.205693
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.constants import HTTP_STATUS_CODES
    from sanic.constants import SERVER_SOFTWARE
    from sanic.constants import SERVER_SOFTWARE_STATEMENT
    from sanic.constants import SERVER_SOFTWARE_STATEMENT_SHORT
    from sanic.constants import SERVER_SOFTWARE_STATEMENT_DEBUG
    from sanic.constants import SERVER_SOFTWARE_STATEMENT_DEBUG_SHORT
    from sanic.constants import SERVER_SOFTWARE_STATEMENT_TESTING
    from sanic.constants import SERVER_SOFTWARE_STATEMENT_TEST

# Generated at 2022-06-18 06:00:55.513185
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import WebSocketProtocol
    from sanic.models.protocol_types import WebSocketState
    from sanic.models.protocol_types import WebSocketType
    from sanic.models.protocol_types import WebSocketExtension
    from sanic.models.protocol_types import WebSocketExtensionParameter
    from sanic.models.protocol_types import WebSocketExtensionParameterValue
    from sanic.models.protocol_types import WebSocketExtensionParameterValueType

# Generated at 2022-06-18 06:01:03.917849
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
   

# Generated at 2022-06-18 06:01:18.732737
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)

    test_file_async()



# Generated at 2022-06-18 06:01:27.501536
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_as

# Generated at 2022-06-18 06:01:37.753934
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedByClient
    from sanic.websocket import WebSocketConnectionClosedByServer
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedAbnormalClosure
    from sanic.websocket import WebSocketConnectionClosedTLSHandshake

# Generated at 2022-06-18 06:01:45.412866
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            lambda response: response.write("Hello, world!"),
            content_type="text/plain",
        )

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "Hello, world!"



# Generated at 2022-06-18 06:01:57.034445
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_

# Generated at 2022-06-18 06:02:04.733307
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async def streaming_fn(response):
            async with await open_async(location, mode="rb") as f:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)
        return StreamingHTTPResponse(
            streaming_fn=streaming_fn,
            status=status,
            headers=headers,
            content_type=mime_type,
        )


# Generated at 2022-06-18 06:02:13.213813
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.py", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:02:16.586258
# Unit test for function html
def test_html():
    assert html("test").body == b"test"
    assert html(b"test").body == b"test"
    assert html(HTMLProtocol("test")).body == b"test"



# Generated at 2022-06-18 06:02:21.390674
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:02:31.831025
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import asyncio
    from sanic.response import StreamingHTTPResponse
    from sanic.response import file_stream

    async def test_file_stream_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    def test_file_stream_fn_2(response):
        response.write("foo")
        time.sleep(1)
        response.write("bar")
        time.sleep(1)

    def test_file_stream_fn_3(response):
        response.write("foo")
        time.sleep(1)
        response.write("bar")
        time.sleep(1)
        response.write("")


# Generated at 2022-06-18 06:02:54.760712
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')

    response = stream(streaming_fn, content_type='text/plain')
    assert response.streaming_fn == streaming_fn
    assert response.content_type == 'text/plain'
    assert response.status == 200
    assert response.headers == {}
    assert response._cookies == None



# Generated at 2022-06-18 06:02:58.383448
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:03:09.097682
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest import TestCase
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Protocol
    from sanic.models.protocol_types import ProtocolTypes
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType

# Generated at 2022-06-18 06:03:18.759093
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr
    from sanic.response import Optional
    from sanic.response import Union
    from sanic.response import Tuple
    from sanic.response import Iterator
    from sanic.response import Dict
    from sanic.response import Callable
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr
    from sanic.response import Optional
    from sanic.response import Union

# Generated at 2022-06-18 06:03:28.953032
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range

# Generated at 2022-06-18 06:03:35.592820
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(1024)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
    )


# Generated at 2022-06-18 06:03:48.480671
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async with await open_async("file_stream.py", mode="rb") as f:
            content = await f.read()
        async def _streaming_fn(response):
            async with await open_async("file_stream.py", mode="rb") as f:
                while True:
                    chunk = await f.read(4096)
                    if len(chunk) < 1:
                        break
                    await response.write(chunk)
        response = StreamingHTTPResponse(
            streaming_fn=_streaming_fn,
            status=200,
            headers={},
            content_type="text/plain",
        )
        result = await response.stream.read()
        assert result == content
    loop = asyncio.get_event_loop()
    loop.run

# Generated at 2022-06-18 06:03:50.577337
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')

    response = stream(streaming_fn, content_type='text/plain')
    assert response.streaming_fn == streaming_fn
    assert response.content_type == 'text/plain'
    assert response.status == 200
    assert response.headers == {}


# Generated at 2022-06-18 06:03:55.422222
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()



# Generated at 2022-06-18 06:04:01.564049
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestClient
    from sanic import Sanic

    app = Sanic("test_StreamingHTTPResponse_send")

    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return StreamingHTTPResponse(sample_streaming_fn)

    request, response = HttpTestClient(app).post("/")

    assert response.status == 200
    assert response.body == b"foobar"



# Generated at 2022-06-18 06:04:31.246803
# Unit test for function file
def test_file():
    async def test_file_async():
        file_path = path.join(path.dirname(__file__), "test_file.txt")
        response = await file(file_path)
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.body == b"This is a test file."

    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_file_async())



# Generated at 2022-06-18 06:04:32.563126
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')

    return stream(streaming_fn, content_type='text/plain')


# Generated at 2022-06-18 06:04:42.299195
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import shutil
    import asyncio
    from sanic.response import file_stream
    from sanic.server import HttpProtocol
    from sanic.testing import SanicTestClient

    async def test_stream(request):
        return await file_stream(
            os.path.join(os.path.dirname(__file__), 'test_file_stream.py'),
            chunk_size=10
        )

    app = Sanic('test_file_stream')
    app.add_route(test_stream, '/')

    request, response = app.test_client.get('/')
    assert response.status == 200

# Generated at 2022-06-18 06:04:44.210818
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Test for method send of class BaseHTTPResponse
    # This method is tested in test_HttpProtocol_send_response
    pass


# Generated at 2022-06-18 06:04:55.566799
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:05:00.129142
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    def streaming_fn(response):
        response.write("foo")
        response.write("bar")
    response = StreamingHTTPResponse(streaming_fn)
    assert response.streaming_fn == streaming_fn
    assert response.status == 200
    assert response.headers == {}
    assert response.content_type == "text/plain; charset=utf-8"
    assert response._cookies == None


# Generated at 2022-06-18 06:05:11.599703
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
   

# Generated at 2022-06-18 06:05:22.883780
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers

# Generated at 2022-06-18 06:05:31.569517
# Unit test for function file
def test_file():
    import os
    import tempfile
    import shutil
    from sanic.response import file
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.constants import HTTP_METHODS
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.testing import SanicTestClient

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create the test file
    test_file = os.path.join(temp_dir, "test.txt")
    with open(test_file, "w") as f:
        f.write("test")

    app = Sanic("test_file")

    @app.route("/")
    async def handler(request):
        return await file

# Generated at 2022-06-18 06:05:42.273929
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                out_stream = await f.read(_range.size)
                headers[
                    "Content-Range"
                ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
                status = 206
            else:
                out_stream = await f.read()

        mime_type = mime_type or guess_type(filename)[0] or "text/plain"

# Generated at 2022-06-18 06:06:46.781177
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_StreamingHTTPResponse_write")
    client = SanicTestClient(app)

    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return StreamingHTTPResponse(sample_streaming_fn)

    request, response = client.post("/")
    assert response.status == 200
    assert response.text == "foobar"


# Generated at 2022-06-18 06:06:57.123426
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:07:04.139043
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)
    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:07:13.178119
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import WebSocketProtocolType
    from sanic.models.protocol_types import WebSocketState
    from sanic.models.protocol_types import WebSocketType
    from sanic.models.protocol_types import WebSocket
    from sanic.models.protocol_types import WebSocketMessage
    from sanic.models.protocol_types import WebSocketMessageType

# Generated at 2022-06-18 06:07:15.678377
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')

    response = stream(streaming_fn, content_type='text/plain')
    assert response.streaming_fn == streaming_fn
    assert response.status == 200
    assert response.content_type == 'text/plain'
    assert response.headers == {}
    assert response._cookies == None


# Generated at 2022-06-18 06:07:26.274400
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.status, 200)
            self.assertEqual(response.text, "foobar")
    TestStreamingHTTPResponse().test_streaming_response()
#

# Generated at 2022-06-18 06:07:32.157881
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            streaming_fn=lambda response: response.write("Hello"),
            content_type="text/plain",
        )

    request, response = SanicTestClient(app).get("/")

    assert response.status == 200
    assert response.text == "Hello"



# Generated at 2022-06-18 06:07:41.935806
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
