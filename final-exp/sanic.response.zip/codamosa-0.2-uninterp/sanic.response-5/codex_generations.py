

# Generated at 2022-06-18 05:57:57.405158
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            lambda r: r.write("Hello"), content_type="text/plain"
        )

    request, response = SanicTestClient(app).get("/")
    assert response.text == "Hello"



# Generated at 2022-06-18 05:58:02.462292
# Unit test for function file
def test_file():
    async def test():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 05:58:10.494606
# Unit test for function file_stream
def test_file_stream():
    async def test():
        import os
        import tempfile
        import shutil
        import asyncio
        from sanic.response import file_stream
        from sanic.request import Request
        from sanic.response import HTTPResponse
        from sanic.server import HttpProtocol
        from sanic.websocket import WebSocketProtocol
        from sanic.websocket import ConnectionClosed
        from sanic.websocket import WebSocketConnectionClosed
        from sanic.websocket import WebSocketDisconnect
        from sanic.websocket import WebSocketError
        from sanic.websocket import WebSocketTimeout
        from sanic.websocket import WebSocketProtocolError
        from sanic.websocket import WebSocketPayloadTooBig
        from sanic.websocket import WebSocketConnectionClosedOK


# Generated at 2022-06-18 05:58:17.412403
# Unit test for function stream
def test_stream():
    def streaming_fn(response):
        response.write('foo')
        response.write('bar')
    response = stream(streaming_fn, content_type='text/plain')
    assert response.streaming_fn == streaming_fn
    assert response.headers == None
    assert response.content_type == 'text/plain'
    assert response.status == 200


# Generated at 2022-06-18 05:58:28.783103
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header

# Generated at 2022-06-18 05:58:33.696686
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"
    assert html(HTMLProtocol(b"<html>")).body == b"<html>"



# Generated at 2022-06-18 05:58:35.381040
# Unit test for function file
def test_file():
    async def test():
        assert await file("/tmp/test.txt")
    test()


# Generated at 2022-06-18 05:58:47.004491
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async def _streaming_fn(response):
            async with await open_async(location, mode="rb") as f:
                if _range:
                    await f.seek(_range.start)
                    to_send = _range.size
                    while to_send > 0:
                        content = await f.read(min((_range.size, chunk_size)))
                        if len(content) < 1:
                            break
                        to_send -= len(content)
                        await response.write(content)
                else:
                    while True:
                        content = await f.read(chunk_size)
                        if len(content) < 1:
                            break
                        await response.write(content)


# Generated at 2022-06-18 05:58:56.907749
# Unit test for function file
def test_file():
    async def test():
        response = await file("/tmp/test.txt")
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.body == b"test"
        response = await file("/tmp/test.txt", filename="test.txt")
        assert response.headers["Content-Disposition"] == 'attachment; filename="test.txt"'
        response = await file("/tmp/test.txt", _range=Range(0, 0, 1))
        assert response.status == 206
        assert response.headers["Content-Range"] == "bytes 0-0/1"
        assert response.body == b"t"
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())



# Generated at 2022-06-18 05:59:09.065592
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.server import HttpProtocol
    import asyncio
    import pytest
    import sys
    import os
    import io
    import json
    import ujson
    import time
    import random
    import string
    import logging
    import socket
    import contextlib
    import warnings
    import traceback
    import unittest
    import unittest.mock
    import ssl
    import multiprocessing
    import subprocess
    import signal
    import tempfile
    import shutil
    import atexit
    import functools
    import types
    import collections
    import gc
    import re
    import base64
    import zlib
    import inspect
    import concurrent.futures
    import concurrent

# Generated at 2022-06-18 05:59:26.040619
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers

# Generated at 2022-06-18 05:59:37.440447
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open


# Generated at 2022-06-18 05:59:43.269763
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_coro():
        import os
        import tempfile
        from sanic.response import file_stream
        from sanic.response import HTTPResponse
        from sanic.response import StreamingHTTPResponse
        from sanic.response import StreamingFunction

        def test_file_stream_fn(response):
            assert isinstance(response, StreamingHTTPResponse)
            assert isinstance(response.streaming_fn, StreamingFunction)
            assert response.status == 200
            assert response.content_type == "text/plain"
            assert response.headers == {"Content-Disposition": 'attachment; filename="test.txt"'}
            assert response.stream.send is not None


# Generated at 2022-06-18 05:59:53.288317
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(request):
        return await file_stream(
            location=__file__,
            status=200,
            chunk_size=4096,
            mime_type=None,
            headers=None,
            filename=None,
            chunked="deprecated",
            _range=None,
        )
    app = Sanic("test_file_stream")
    app.add_route(test_file_stream_fn, "/test_file_stream")
    request, response = app.test_client.get("/test_file_stream")
    assert response.status == 200
    assert response.body == open(__file__, "rb").read()



# Generated at 2022-06-18 05:59:55.701105
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')

    response = stream(streaming_fn, content_type='text/plain')
    assert response.streaming_fn == streaming_fn
    assert response.content_type == 'text/plain'
    assert response.status == 200
    assert response.headers == {}
    assert response._cookies == None


# Generated at 2022-06-18 06:00:04.086327
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    import pytest
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr
    from sanic.response import Optional
    from sanic.response import Union

# Generated at 2022-06-18 06:00:15.457011
# Unit test for function file_stream
def test_file_stream():
    async def test_stream(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)
    # Test file_stream
    location = "./test_file"
    chunk_size = 4096
    mime_type = "text/plain"
   

# Generated at 2022-06-18 06:00:24.160015
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestClient
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.response import StreamingHTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTT

# Generated at 2022-06-18 06:00:34.554910
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic import Sanic
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HOST, PORT

    app = Sanic("test_StreamingHTTPResponse_send")

    async def streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(streaming_fn)

    request, response = app.test_client.get("/")
    assert response.status == 200
    assert response.text == "foobar"



# Generated at 2022-06-18 06:00:39.978819
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:00:57.057753
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.testing import SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            streaming_fn=lambda response: response.write("Hello world!"),
            content_type="text/plain",
        )

    request, response = app.test_client.get("/")

    assert response.text == "Hello world!"



# Generated at 2022-06-18 06:00:58.901226
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Test the send method of BaseHTTPResponse
    # TODO: Write unit test
    pass


# Generated at 2022-06-18 06:01:08.343584
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
   

# Generated at 2022-06-18 06:01:19.080719
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import WebSocketProtocolType
    from sanic.models.protocol_types import WebSocketState
    from sanic.models.protocol_types import WebSocketType
    from sanic.models.protocol_types import WebSocketType
    from sanic.models.protocol_types import WebSocketType
    from sanic.models.protocol_types import WebSocketType

# Generated at 2022-06-18 06:01:27.732861
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 06:01:28.603916
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # TODO: Add tests
    pass


# Generated at 2022-06-18 06:01:38.732640
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.websocket import WebSocketProtocol

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(0.1)
                await response.write("bar")
                await asyncio.sleep(0.1)
                await response.write("baz")

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.status, 200)

# Generated at 2022-06-18 06:01:46.600187
# Unit test for function file_stream
def test_file_stream():
    async def test_stream(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_stream,
        status=200,
        headers=None,
        content_type="text/plain",
    )


# Generated at 2022-06-18 06:01:52.883199
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream(location, chunk_size, mime_type, headers, filename, chunked, _range):
        if chunked != "deprecated":
            warn(
                "The chunked argument has been deprecated and will be "
                "removed in v21.6"
            )

        headers = headers or {}
        if filename:
            headers.setdefault(
                "Content-Disposition", f'attachment; filename="{filename}"'
            )
        filename = filename or path.split(location)[-1]
        mime_type = mime_type or guess_type(filename)[0] or "text/plain"
        if _range:
            start = _range.start
            end = _range.end
            total = _range.total


# Generated at 2022-06-18 06:02:04.255492
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import ConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketDisconnect

# Generated at 2022-06-18 06:02:27.290631
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')
    response = stream(streaming_fn, content_type='text/plain')
    assert response.streaming_fn == streaming_fn
    assert response.headers == {}
    assert response.content_type == 'text/plain'
    assert response.status == 200


# Generated at 2022-06-18 06:02:36.995275
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr
    from sanic.response import NoneType
    from sanic.response import Optional
    from sanic.response import Union
    from sanic.response import Tuple
    from sanic.response import Iterator
    from sanic.response import Dict
    from sanic.response import Callable
    from sanic.response import Header
    from sanic.response import Http
    from sanic.response import CookieJar
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr

# Generated at 2022-06-18 06:02:47.142970
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        response = await file(location, status, mime_type, headers, filename, _range)
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.body == b"This is a test file."
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_file_async())


# Generated at 2022-06-18 06:02:48.148779
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # TODO: Implement
    pass


# Generated at 2022-06-18 06:02:56.986767
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import mock_open
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import patch
    from unittest.mock import mock_open
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import patch
    from unittest.mock import mock_open


# Generated at 2022-06-18 06:03:07.442905
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketProtocol13
    from sanic.websocket import WebSocketProtocol76
    from sanic.websocket import WebSocketProtocolHybi13
    from sanic.websocket import WebSocketProtocolHybi10
    from sanic.websocket import WebSocketProtocolHixie76
    from sanic.websocket import WebSocketProtocolRfc6455
    from sanic.websocket import WebSocketProtocolRfc6455
    from sanic.websocket import WebSocketProtocolRfc6455

# Generated at 2022-06-18 06:03:16.168881
# Unit test for function file_stream
def test_file_stream():
    async def test_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    response = StreamingHTTPResponse(
        streaming_fn=test_streaming_fn,
        status=200,
        headers={},
        content_type="text/plain; charset=utf-8",
    )
    assert response.streaming_fn == test_streaming_fn
    assert response.status == 200
    assert response.headers == {}
    assert response.content_type == "text/plain; charset=utf-8"



# Generated at 2022-06-18 06:03:21.997740
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)

# Generated at 2022-06-18 06:03:28.059341
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.helpers import has_message_body
    from sanic.helpers import remove_entity_headers
    from sanic.compat import Header
    from sanic.http import Http
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range

# Generated at 2022-06-18 06:03:34.860909
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import asyncio
    from sanic.response import file_stream
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic()

    @app.route("/")
    async def test(request):
        return await file_stream(
            os.path.join(os.path.dirname(__file__), "test.py"),
            chunk_size=1
        )

    client = SanicTestClient(app, port=8000)
    request, response = client.get("/")
    assert response.status == 200
    assert response.headers.get("Content-Type") == "text/x-python"
    assert response.body == b"import unittest\n"


# Generated at 2022-06-18 06:04:22.017877
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async(location, mode="rb") as f:
            content = await f.read()
        async with await open_async(location, mode="rb") as f:
            while True:
                content_stream = await f.read(chunk_size)
                if len(content_stream) < 1:
                    break
                content_stream = content_stream
        assert content == content_stream
    location = "./tests/test_file.txt"
    chunk_size = 4096
    asyncio.run(test())


# Generated at 2022-06-18 06:04:26.283404
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:04:38.071741
# Unit test for function file
def test_file():
    import os
    import asyncio
    from sanic.response import file
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_file")

    @app.route("/")
    async def handler(request):
        return await file(
            os.path.join(os.path.dirname(__file__), "static", "test.html")
        )

    request, response = SanicTestClient(app).get("/")
    assert response.status == 200
    assert response.headers["Content-Type"] == "text/html"
    assert response.text == "Hello world!"


# Generated at 2022-06-18 06:04:41.621355
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()



# Generated at 2022-06-18 06:04:45.669687
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:04:57.050141
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import patch
    from unittest import TestCase
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body

    class TestStreamingHTTPResponse(TestCase):
        def setUp(self):
            self.stream = HttpProtocol(None, None, None, None)
            self.streaming_fn = None
            self.status = 200
            self.content_type = DEFAULT_HTTP_CONTENT_TYPE
            self.headers = Header({})
            self._cookies = None


# Generated at 2022-06-18 06:05:03.274379
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import MagicMock
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import text
    from sanic.response import json
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream
    from sanic.response import raw
    from sanic.response import json_dumps
    from sanic.response import HTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import HTTPResponse

# Generated at 2022-06-18 06:05:11.261912
# Unit test for function file
def test_file():
    async def test_file_async():
        file_path = path.join(path.dirname(__file__), "test_file.txt")
        response = await file(file_path)
        assert response.body == b"This is a test file.\n"
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.headers["Content-Disposition"] == 'attachment; filename="test_file.txt"'
    test_file_async()


# Generated at 2022-06-18 06:05:19.208022
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)
    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:05:24.202868
# Unit test for function file
def test_file():
    async def test():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:07:06.300901
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:07:10.324826
# Unit test for function file
def test_file():
    async def test():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:07:18.016667
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)
    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain",
    )



# Generated at 2022-06-18 06:07:27.002388
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import WebSocketProtocol
    from sanic.models.protocol_types import WebSocketState
    from sanic.models.protocol_types import WebSocketType
    from sanic.models.protocol_types import WebSocketExtension
    from sanic.models.protocol_types import WebSocketExtensionParameter
    from sanic.models.protocol_types import WebSocketExtension