

# Generated at 2022-06-18 05:57:26.211005
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')

    return stream(streaming_fn, content_type='text/plain')


# Generated at 2022-06-18 05:57:31.729872
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import mock
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr
    from sanic.response import bytes
    from sanic.response import hasattr
    from sanic.response import partial
    from sanic.response import warn
    from sanic.response import Header
    from sanic.response import Dict
    from sanic.response import str
    from sanic.response import Optional
    from sanic.response import Union
    from sanic.response import Callable
    from sanic.response import Coroutine
    from sanic.response import Any
   

# Generated at 2022-06-18 05:57:37.924311
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async("test.txt", mode="rb") as f:
            content = await f.read()
        async def _streaming_fn(response):
            await response.write(content)
        return StreamingHTTPResponse(
            streaming_fn=_streaming_fn,
            status=200,
            headers={},
            content_type="text/plain; charset=utf-8",
        )
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())


# Generated at 2022-06-18 05:57:46.696198
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import WebSocketProtocol
    from sanic.models.protocol_types import WebSocketProtocol
    from sanic.models.protocol_types import WebSocketProtocol
    from sanic.models.protocol_types import WebSocketProtocol
    from sanic.models.protocol_types import WebSocketProtocol

# Generated at 2022-06-18 05:57:51.251818
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call

    mock_stream = Mock()
    mock_stream.send = Mock()
    mock_stream.send.return_value = None

    mock_streaming_fn = Mock()
    mock_streaming_fn.return_value = None

    mock_data = Mock()

    mock_args = Mock()
    mock_kwargs = Mock()

    streaming_http_response = StreamingHTTPResponse(
        streaming_fn=mock_streaming_fn,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
        chunked="deprecated",
    )

    streaming_http_response.stream = mock_stream

    streaming_

# Generated at 2022-06-18 05:57:57.237292
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketStream
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketTimeout
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketHandshakeError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import Web

# Generated at 2022-06-18 05:58:07.595823
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Protocol
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolVersion
    from sanic.models.protocol_types import ProtocolVersion
    from sanic.models.protocol_types import ProtocolVersion
    from sanic.models.protocol_types import ProtocolVersion
    from sanic.models.protocol_types import ProtocolVersion

# Generated at 2022-06-18 05:58:20.823824
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import asyncio
    from sanic.response import file_stream
    from sanic.server import HttpProtocol

    async def test_file_stream_handler(request):
        return await file_stream(
            os.path.join(tempfile.gettempdir(), "test.txt"),
            headers={"Content-Disposition": "attachment; filename=test.txt"}
        )

    app = Sanic("test_file_stream")
    app.add_route(test_file_stream_handler, "/test_file_stream")

    request, response = app.test_client.get("/test_file_stream")
    assert response.status == 200
    assert response.headers.get("Content-Disposition") == "attachment; filename=test.txt"


# Generated at 2022-06-18 05:58:28.568614
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain",
    )


# Generated at 2022-06-18 05:58:34.012365
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(b"<html>").content_type == "text/html; charset=utf-8"
    assert html(b"<html>").status == 200
    assert html(b"<html>").headers == {}



# Generated at 2022-06-18 05:58:54.206602
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def test(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.body, b"foobar")
            self.assertEqual(response.status, 200)

    TestStreamingHTTPResponse().test_streaming_response()



# Generated at 2022-06-18 05:59:05.100161
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import AsyncMock
    from unittest.mock import create_autospec
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import PropertyMock
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import AsyncMock
    from unittest.mock import create_autospec

# Generated at 2022-06-18 05:59:11.934811
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain",
    )



# Generated at 2022-06-18 05:59:17.354939
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(
            location,
            status,
            mime_type,
            headers,
            filename,
            _range,
        )
    test()



# Generated at 2022-06-18 05:59:23.001519
# Unit test for function file
def test_file():
    async def test_file_async():
        file_path = path.join(path.dirname(__file__), "../../README.md")
        response = await file(file_path)
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.body.startswith(b"# Sanic")

    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_file_async())



# Generated at 2022-06-18 05:59:33.448452
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    import asyncio
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_send")

    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return StreamingHTTPResponse(sample_streaming_fn)

    request, response = app.test_client.post("/")

    assert response.status == 200
    assert response.text == "foobar"



# Generated at 2022-06-18 05:59:44.620811
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 05:59:56.084795
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_

# Generated at 2022-06-18 06:00:01.006676
# Unit test for function file
def test_file():
    location = "./test.txt"
    status = 200
    mime_type = "text/plain"
    headers = {"Content-Disposition": 'attachment; filename="test.txt"'}
    filename = "test.txt"
    _range = Range(start=0, end=1, total=2)
    file(location, status, mime_type, headers, filename, _range)


# Generated at 2022-06-18 06:00:12.485599
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range

# Generated at 2022-06-18 06:00:59.132595
# Unit test for function file
def test_file():
    import os
    import tempfile
    import shutil
    import asyncio
    from sanic.response import file
    from sanic.exceptions import NotFound

    async def test_file_exists(loop):
        temp_dir = tempfile.mkdtemp()
        temp_file = os.path.join(temp_dir, "test.txt")
        with open(temp_file, "w") as f:
            f.write("test")

        request, response = await file(temp_file)
        assert response.body == b"test"
        assert response.status == 200
        assert response.headers["Content-Type"] == "text/plain"

        shutil.rmtree(temp_dir)

    async def test_file_not_found(loop):
        temp_dir = tempfile.mkdtemp()
       

# Generated at 2022-06-18 06:01:08.714236
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_

# Generated at 2022-06-18 06:01:19.530225
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock, patch
    from sanic.response import StreamingHTTPResponse
    from sanic.streams import StreamProtocol

    stream = Mock(spec=StreamProtocol)
    stream.send = Mock()
    stream.send.return_value = None

    response = StreamingHTTPResponse(None)
    response.stream = stream

    response.write("foo")
    stream.send.assert_called_once_with(b"foo", end_stream=False)

    stream.send.reset_mock()

    response.write(b"bar")
    stream.send.assert_called_once_with(b"bar", end_stream=False)

    stream.send.reset_mock()

    response.write(b"baz")
    stream.send.assert_called_once

# Generated at 2022-06-18 06:01:23.114759
# Unit test for function file
def test_file():
    async def test():
        response = await file("./test.txt")
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.body == b"test"
    asyncio.run(test())



# Generated at 2022-06-18 06:01:27.061105
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"
    assert html(HTMLProtocol(b"<html>")).body == b"<html>"



# Generated at 2022-06-18 06:01:37.239723
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.constants import DEFAULT_

# Generated at 2022-06-18 06:01:48.468504
# Unit test for function file
def test_file():
    from sanic.response import HTTPResponse
    from sanic.exceptions import FileNotFound
    from sanic.constants import TEST_DIR
    from sanic.utils import sanic_endpoint_test
    from sanic.server import HttpProtocol
    import os
    import tempfile

    async def test_file_not_found(app, test_client):
        request, response = await sanic_endpoint_test(
            app.handle_request,
            "GET",
            "/",
            headers={"Range": "bytes=0-10"},
        )
        assert response.status == 404


# Generated at 2022-06-18 06:01:59.308600
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.constants import HTTP_METHODS
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import FileStream
    from sanic.response import StreamingHTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import Streaming

# Generated at 2022-06-18 06:02:08.933494
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError

# Generated at 2022-06-18 06:02:21.346938
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:03:03.444121
# Unit test for function file
def test_file():
    async def test():
        return await file("test.txt")

    assert test().status == 200
    assert test().content_type == "text/plain"
    assert test().body == b"test"



# Generated at 2022-06-18 06:03:14.459056
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers

# Generated at 2022-06-18 06:03:19.571929
# Unit test for function file_stream
def test_file_stream():
    async def test_stream(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)
    return StreamingHTTPResponse(
        streaming_fn=test_stream,
        status=200,
        headers={},
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:03:21.115061
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # TODO: Add tests for BaseHTTPResponse.send
    pass


# Generated at 2022-06-18 06:03:28.178655
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(__file__, mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    assert StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:03:37.628987
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
   

# Generated at 2022-06-18 06:03:50.399531
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketCommonReader

# Generated at 2022-06-18 06:03:54.253831
# Unit test for function html
def test_html():
    assert html("<html>") == HTTPResponse(
        "<html>",
        status=200,
        headers=None,
        content_type="text/html; charset=utf-8",
    )



# Generated at 2022-06-18 06:04:01.343591
# Unit test for function file_stream
def test_file_stream():
    async def test_stream(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)
    location = "test.txt"
    chunk_size = 4096
    mime_type = "text/plain"
    headers = {}

# Generated at 2022-06-18 06:04:13.084829
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async

# Generated at 2022-06-18 06:05:41.192716
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:05:49.076603
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_test(test_client):
        @test_client.app.route("/")
        async def handler(request):
            return await file_stream(
                "tests/test_files/test_file.txt",
                status=200,
                chunk_size=4096,
                mime_type="text/plain",
                headers={"Content-Disposition": "attachment; filename=test_file.txt"},
                filename="test_file.txt",
                chunked="deprecated",
                _range=None,
            )

        resp = await test_client.get("/")
        assert resp.status == 200
        assert resp.body == b"This is a test file\n"

    run_test_coroutine(test_file_stream_test)



# Generated at 2022-06-18 06:05:54.221942
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async("test.txt", mode="w") as f:
            await f.write("test")
        response = await file_stream("test.txt")
        assert response.body == b"test"
        os.remove("test.txt")
    asyncio.run(test())



# Generated at 2022-06-18 06:06:01.626164
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_StreamingHTTPResponse_write")

    async def streaming_fn(response):
        await response.write("foo")
        await response.write("bar")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(streaming_fn)

    request, response = SanicTestClient(app).get("/")

    assert response.text == "foobar"


# Generated at 2022-06-18 06:06:07.862023
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_send")

    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.route("/")
    async def test(request):
        return StreamingHTTPResponse(sample_streaming_fn)

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "foobar"



# Generated at 2022-06-18 06:06:19.814808
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.testing import HOST, PORT
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.log import logger
    import asyncio
    import pytest
    import socket
    import time
    import sys
    import os
    import json
    import pytest
    import ujson
    import logging
    import warnings
    import time
    import sys
    import os
    import json
    import pytest
    import ujson
    import logging
    import warnings
    import time
    import sys
    import os
    import json
    import pytest
    import ujson
    import logging
    import warnings
    import time

# Generated at 2022-06-18 06:06:23.779121
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:06:31.806971
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import PropertyMock
    from unittest.mock import AsyncMock
    from unittest.mock import CoroutineMock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY

# Generated at 2022-06-18 06:06:40.882055
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr
    from sanic.response import Optional
    from sanic.response import Union

# Generated at 2022-06-18 06:06:50.882045
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from unittest.mock import patch
    from unittest import TestCase
    from asyncio import Future
    import pytest
    import asyncio

    class TestBaseHTTPResponse(BaseHTTPResponse):
        def __init__(self):
            super().__init__()
            self.stream = HttpProtocol()
            self.stream.send = Future()

    test_base_http_response = TestBaseHTTPResponse()
    test_base_http_response.stream.send.set_result(None)

    @pytest.mark.asyncio
    async def test_send_data_none_end_stream_none():
        await test_base_http_response.send()
