

# Generated at 2022-06-18 05:58:08.360002
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.server import HttpProtocol as HttpProtocol_
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.helpers import has_message_body
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body
    from sanic.compat import Header
    from sanic.helpers import remove_entity_headers

# Generated at 2022-06-18 05:58:10.404228
# Unit test for function file
def test_file():
    # TODO: Add unit test for function file
    pass



# Generated at 2022-06-18 05:58:15.635020
# Unit test for function html
def test_html():
    assert html("<html></html>").body == b"<html></html>"
    assert html(b"<html></html>").body == b"<html></html>"
    assert html(HTMLProtocol("<html></html>")).body == b"<html></html>"



# Generated at 2022-06-18 05:58:27.591521
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await response.write("bar")

            request, response = self.create_request_and_response(
                method="POST", uri="/", headers={"Content-Type": "text/plain"}
            )
            response = StreamingHTTPResponse(
                streaming_fn,
                status=200,
                headers={"Content-Type": "text/plain"},
                content_type="text/plain; charset=utf-8",
            )
            response.stream = request.stream
            response.asgi = True
            response

# Generated at 2022-06-18 05:58:37.309589
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 05:58:41.066041
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"



# Generated at 2022-06-18 05:58:46.444171
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 05:58:51.838495
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = "text/plain"
        headers = {}
        filename = "test.txt"
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 05:58:59.725035
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.compat import Header
    from sanic.helpers import remove_entity_headers
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range

# Generated at 2022-06-18 05:59:00.896772
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # TODO: Implement test
    pass


# Generated at 2022-06-18 05:59:25.245112
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.status, 200)
            self.assertEqual(response.text, "foobar")

    TestStreamingHTTPResponse().test_streaming_response()



# Generated at 2022-06-18 05:59:30.537073
# Unit test for function file
def test_file():
    async def test():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 05:59:40.802432
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_send")

    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return StreamingHTTPResponse(sample_streaming_fn)

    request, response = app.test_client.post("/")

    assert response.status == 200
    assert response.text == "foobar"



# Generated at 2022-06-18 05:59:44.536781
# Unit test for function file
def test_file():
    async def test():
        response = await file("/tmp/test.txt")
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.body == b"hello world"

    asyncio.run(test())



# Generated at 2022-06-18 05:59:56.038859
# Unit test for function file_stream
def test_file_stream():
    async def test_stream(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)

    location = "./test_file_stream.txt"
    chunk_size = 4096
    mime_type = "text/plain"
    headers = {}

# Generated at 2022-06-18 06:00:04.318363
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.asgi import ASGIProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import WebSocketProtocol
    from sanic.models.protocol_types import ASGIProtocol
    from sanic.models.protocol_types import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range

# Generated at 2022-06-18 06:00:15.736563
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommonConnectionClosed
    from sanic.websocket import WebSocketCommonDisconnect

# Generated at 2022-06-18 06:00:24.339619
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
   

# Generated at 2022-06-18 06:00:32.905612
# Unit test for function file_stream
def test_file_stream():
    async def test():
        location = "./test_file_stream.txt"
        with open(location, "w") as f:
            f.write("Hello World")
        response = await file_stream(location)
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.body == b"Hello World"
        os.remove(location)
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()



# Generated at 2022-06-18 06:00:45.431406
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:01:13.075125
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketCommonWriter
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketCommonReader
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommon
    from sanic.websocket import WebSocketState

# Generated at 2022-06-18 06:01:19.872795
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async("test.txt", mode="rb") as f:
            content = await f.read()
        response = await file_stream("test.txt")
        assert response.body == content
        assert response.content_type == "text/plain"
        assert response.status == 200
        assert response.headers == {"Content-Type": "text/plain"}
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())



# Generated at 2022-06-18 06:01:28.175711
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.websocket import WebSocketProtocol

    class Test(HttpTestCase):
        def test_send(self):
            @self.app.route("/")
            async def handler(request):
                return HTTPResponse(b"test")

            request, response = self.get("/")
            assert response.stream.send is not None
            assert response.stream.send_headers is not None
            assert response.stream.send_headers is not None
            assert response.stream.protocol is not None
            assert isinstance(response.stream.protocol, WebSocketProtocol)
            assert response.stream.protocol.transport is not None
            assert response.stream.protocol.transport.get_extra_

# Generated at 2022-06-18 06:01:38.426551
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    import asyncio
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
   

# Generated at 2022-06-18 06:01:50.178565
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_

# Generated at 2022-06-18 06:01:55.371221
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream", mode="rb") as f:
            while True:
                content = await f.read(chunk_size)
                if len(content) < 1:
                    break
                await response.write(content)
    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=status,
        headers=headers,
        content_type=mime_type,
    )


# Generated at 2022-06-18 06:02:03.882742
# Unit test for function file_stream
def test_file_stream():
    async def test_func():
        async with await open_async("test.txt", mode="rb") as f:
            content = await f.read()
        async def _streaming_fn(response):
            await response.write(content)
        return StreamingHTTPResponse(
            streaming_fn=_streaming_fn,
            status=200,
            headers={},
            content_type="text/plain",
        )
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_func())


# Generated at 2022-06-18 06:02:14.257497
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import patch
    from unittest.mock import Mock
    from unittest.mock import MagicMock
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import DEFAULT
    from unittest.mock import create_autospec
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:02:19.960117
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async("test.txt", mode="w") as f:
            await f.write("test")
        response = await file_stream("test.txt")
        assert response.body == b"test"
        os.remove("test.txt")
    asyncio.run(test())



# Generated at 2022-06-18 06:02:30.484812
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.response import HTTPResponse
    from sanic.response import HTTPResponseBody
    from sanic.response import HTTPResponseStream
    from sanic.response import HTTPResponseText
    from sanic.response import HTTPResponseFile
    from sanic.response import HTTPResponseRaw
    from sanic.response import HTTPResponseJson
    from sanic.response import HTTPResponseRedirect
    from sanic.response import HTTPResponseStream
    from sanic.response import HTTPResponseTemplate
    from sanic.response import HTTPResponseFileStream
    from sanic.response import HTTPResponseFile
    from sanic.response import HTTPResponseRedirect


# Generated at 2022-06-18 06:02:57.267595
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"
    assert html(HTMLProtocol(b"<html>")).body == b"<html>"
    assert html(HTMLProtocol(b"<html>")).content_type == "text/html; charset=utf-8"



# Generated at 2022-06-18 06:03:01.218001
# Unit test for function file
def test_file():
    location = "./test_file.txt"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    file(location, status, mime_type, headers, filename, _range)


# Generated at 2022-06-18 06:03:06.737905
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestClient

    app = Sanic("test_BaseHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return HTTPResponse("Hello")

    request, response = app.test_client.get("/")

    assert response.text == "Hello"


# Generated at 2022-06-18 06:03:08.215874
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    # StreamingHTTPResponse.write()
    pass


# Generated at 2022-06-18 06:03:17.996475
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:03:22.499109
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:03:31.661419
# Unit test for function file_stream
def test_file_stream():
    async def test_stream(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)
    location = "./test.txt"
    chunk_size = 4096
    mime_type = None
    headers = None
    filename = None
    chunk

# Generated at 2022-06-18 06:03:43.381382
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.helpers import has_message_body
    from sanic.helpers import remove_entity_headers
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.helpers import has_message_body

# Generated at 2022-06-18 06:03:48.684054
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:03:49.342074
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    pass

# Generated at 2022-06-18 06:04:39.584442
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestClient
    from sanic.app import Sanic

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            streaming_fn=lambda response: response.write("Hello world!")
        )

    request, response = HttpTestClient(app).get("/")
    assert response.text == "Hello world!"



# Generated at 2022-06-18 06:04:46.886205
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock, patch
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers

# Generated at 2022-06-18 06:04:53.862462
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    def streaming_fn(response):
        response.write("foo")
        response.write("bar")
        response.write("baz")
    response = StreamingHTTPResponse(streaming_fn)
    response.send("foo", False)
    response.send("bar", False)
    response.send("baz", True)
    assert response.streaming_fn is None
    assert response.body is None


# Generated at 2022-06-18 06:05:01.682556
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.status, 200)
            self.assertEqual(response.body, b"foobar")

    TestStreamingHTTPResponse().test_streaming_response()



# Generated at 2022-06-18 06:05:05.067404
# Unit test for function file
def test_file():
    async def test():
        response = await file(location="test.txt")
        assert response.body == b"test"
        assert response.status == 200
        assert response.content_type == "text/plain"
    asyncio.run(test())



# Generated at 2022-06-18 06:05:09.078253
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async("test.txt", mode="rb") as f:
            content = await f.read()
            assert content == b"test"
    asyncio.run(test())


# Generated at 2022-06-18 06:05:20.768912
# Unit test for function file_stream
def test_file_stream():
    async def test():
        import os
        from sanic.response import file_stream
        from sanic.server import HttpProtocol
        from sanic.testing import SanicTestClient

        app = Sanic("test_file_stream")

        @app.route("/")
        async def handler(request):
            return await file_stream(
                os.path.join(os.path.dirname(__file__), "test_file_stream.py")
            )

        request, response = app.test_client.get("/")
        assert response.status == 200
        assert response.headers["Content-Type"] == "text/x-python"
        assert response.body == b"# Unit test for function file_stream\n"

    test()



# Generated at 2022-06-18 06:05:24.433868
# Unit test for function file
def test_file():
    location = "./test.txt"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    file(location, status, mime_type, headers, filename, _range)


# Generated at 2022-06-18 06:05:31.472153
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.http import Http
    from sanic.cookies import CookieJar
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.http import Http
    from sanic.cookies import CookieJar
    from sanic.compat import Header

# Generated at 2022-06-18 06:05:42.111035
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import InvalidUsage
    from sanic.testing import HOST, PORT
    import pytest
    import asyncio
    import socket
    import uvloop
    import json
    import os
    import sys
    import time
    import traceback
    import warnings
    import aiohttp
    import aiofiles
    import aiohttp.web
    import aiohttp.test_utils
    import aiohttp.web_exceptions
    import aiohttp.web_reqrep
    import aiohttp.web_urldispatcher
    import aiohttp.web_ws
    import aiohttp.web_fileresponse
    import aiohttp.web