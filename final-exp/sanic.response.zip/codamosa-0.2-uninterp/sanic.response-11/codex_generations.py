

# Generated at 2022-06-18 05:57:50.734787
# Unit test for function file
def test_file():
    location = "./sanic/response.py"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    file(location, status, mime_type, headers, filename, _range)


# Generated at 2022-06-18 05:57:54.672528
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"



# Generated at 2022-06-18 05:58:02.688728
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream", mode="rb") as f:
            while True:
                content = await f.read(chunk_size)
                if len(content) < 1:
                    break
                await response.write(content)
    assert StreamingHTTPResponse(streaming_fn=test_file_stream_fn, status=200, headers=None, content_type="text/plain")


# Generated at 2022-06-18 05:58:10.636752
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 05:58:23.718483
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import shutil
    import asyncio
    from sanic.response import file_stream
    from sanic.response import HTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_file_stream")

    @app.route("/")
    async def test(request):
        return await file_stream(
            "tests/test_files/test.txt",
            headers={"Content-Disposition": "attachment; filename=test.txt"},
            filename="test.txt",
        )


# Generated at 2022-06-18 05:58:33.057123
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import mock
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import Coroutine
    from sanic.response import Any
    from sanic.response import AnyStr
    from sanic.response import Union
    from sanic.response import bytes
    from sanic.response import b
    from sanic.response import hasattr
    from sanic.response import encode
    from sanic.response import send

# Generated at 2022-06-18 05:58:44.622852
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.websocket import WebSocketProtocol

    class Test(HttpTestCase):
        def test_send(self):
            async def handler(request):
                response = HTTPResponse(body="test")
                await response.send(data="test2")
                return response

            request, response = self.create_request(
                "/', methods=['GET']", handler
            )
            self.assertEqual(response.body, b"test2")

        def test_send_websocket(self):
            async def handler(request):
                response = HTTPResponse(body="test")
                await response.send(data="test2")
                return response

            request, response = self.create_request

# Generated at 2022-06-18 05:58:55.450769
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers

# Generated at 2022-06-18 05:59:00.480241
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 05:59:05.701692
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()


# Generated at 2022-06-18 05:59:23.195463
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 05:59:30.536653
# Unit test for function file_stream
def test_file_stream():
    async def test():
        response = await file_stream('./test_file_stream.txt')
        assert response.status == 200
        assert response.content_type == 'text/plain'
        assert response.headers['Content-Disposition'] == 'attachment; filename="test_file_stream.txt"'
        assert response.body == b'Hello World!'
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())


# Generated at 2022-06-18 05:59:42.254950
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import shutil
    import asyncio
    from sanic.response import file_stream
    from sanic.testing import SanicTestClient

    app = Sanic("test_file_stream")

    @app.route("/")
    async def test(request):
        return await file_stream("tests/test_file.txt")

    @app.route("/range")
    async def test_range(request):
        return await file_stream("tests/test_file.txt", _range=Range(0, 2))

    @app.route("/range_start")
    async def test_range_start(request):
        return await file_stream("tests/test_file.txt", _range=Range(2, None))


# Generated at 2022-06-18 05:59:46.125731
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"
    assert html(HTMLProtocol(b"<html>")).body == b"<html>"



# Generated at 2022-06-18 05:59:54.108378
# Unit test for function file_stream
def test_file_stream():
    async def test():
        location = "./tests/test_file.txt"
        response = await file_stream(location)
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.headers["Content-Disposition"] == 'attachment; filename="test_file.txt"'
        assert response.body == b"This is a test file."
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()



# Generated at 2022-06-18 06:00:03.048272
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.response import HTTPResponse
    from sanic.response import text
    from sanic.response import json
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream
    from sanic.response import raw
    from sanic.response import json_dumps
    from sanic.response import HTTPResponseBody
    from sanic.response import HTTPResponseStream
    from sanic.response import HTTPResponseFile
    from sanic.response import HTTPResponseFileStream
    from sanic.response import HTT

# Generated at 2022-06-18 06:00:07.568331
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        return await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:00:16.832979
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_write")

    async def streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.route("/")
    async def test(request):
        return StreamingHTTPResponse(streaming_fn)

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "foobar"

# Generated at 2022-06-18 06:00:23.775273
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.testing import SanicTestClient
    from sanic.testing import async_test

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            lambda response: response.write(b"test"),
            content_type="text/plain",
        )

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.body == b"test"



# Generated at 2022-06-18 06:00:35.356142
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:01:24.941780
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header

# Generated at 2022-06-18 06:01:35.429313
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
   

# Generated at 2022-06-18 06:01:46.549770
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:01:57.652421
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:02:01.855960
# Unit test for function file
def test_file():
    location = "./test.txt"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    file(location, status, mime_type, headers, filename, _range)


# Generated at 2022-06-18 06:02:10.119623
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range

# Generated at 2022-06-18 06:02:22.125336
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http

# Generated at 2022-06-18 06:02:32.392980
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.app import Sanic
    from sanic.testing import SanicTestClient
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketError

# Generated at 2022-06-18 06:02:45.043736
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.helpers import has_message_body, remove_entity_headers

# Generated at 2022-06-18 06:02:55.437203
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream(location):
        async with await open_async(location, mode="rb") as f:
            content = await f.read()
        return content

    async def test_file_stream_range(location, start, end):
        async with await open_async(location, mode="rb") as f:
            await f.seek(start)
            content = await f.read(end - start)
        return content

    async def test_file_stream_range_chunked(location, start, end, chunk_size):
        async with await open_async(location, mode="rb") as f:
            await f.seek(start)
            content = b""
            while True:
                chunk = await f.read(chunk_size)
                if len(chunk) < 1:
                    break

# Generated at 2022-06-18 06:03:36.907433
# Unit test for function file
def test_file():
    async def test():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:03:43.482546
# Unit test for function file
def test_file():
    assert file("/tmp/test.txt")
    assert file("/tmp/test.txt", mime_type="text/plain")
    assert file("/tmp/test.txt", headers={"Content-Disposition": "attachment"})
    assert file("/tmp/test.txt", filename="test.txt")
    assert file("/tmp/test.txt", _range=Range(0, 10, 100))



# Generated at 2022-06-18 06:03:55.338062
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    from sanic.response import file_stream
    from sanic.testing import SanicTestClient

    app = Sanic("test_file_stream")

    @app.route("/")
    async def test(request):
        return await file_stream(__file__)

    client = SanicTestClient(app, port=8888)
    request, response = client.get("/")
    assert response.status == 200
    assert response.body == open(__file__, "rb").read()

    @app.route("/range")
    async def test(request):
        return await file_stream(__file__, _range=Range(0, 10))

    client = SanicTestClient(app, port=8888)
    request, response = client.get("/range")
    assert response

# Generated at 2022-06-18 06:03:58.658575
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.testing import SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            lambda r: r.write("Hello"), content_type="text/plain"
        )

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "Hello"



# Generated at 2022-06-18 06:04:04.971531
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(b"<html>").content_type == "text/html; charset=utf-8"
    assert html(b"<html>").status == 200
    assert html(b"<html>").headers == {}



# Generated at 2022-06-18 06:04:06.481307
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    # StreamingHTTPResponse.send() -> None
    pass


# Generated at 2022-06-18 06:04:17.850955
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http

# Generated at 2022-06-18 06:04:25.108102
# Unit test for function file
def test_file():
    async def test_file_async():
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                out_stream = await f.read(_range.size)
                headers[
                    "Content-Range"
                ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
                status = 206
            else:
                out_stream = await f.read()

        mime_type = mime_type or guess_type(filename)[0] or "text/plain"
        return HTTPResponse(
            body=out_stream,
            status=status,
            headers=headers,
            content_type=mime_type,
        )


# Generated at 2022-06-18 06:04:36.636906
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_

# Generated at 2022-06-18 06:04:45.467003
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open


# Generated at 2022-06-18 06:06:20.216662
# Unit test for function file_stream
def test_file_stream():
    async def test():
        import os
        import tempfile
        import shutil
        import asyncio
        from sanic.response import file_stream
        from sanic.response import HTTPResponse
        from sanic.server import HttpProtocol
        from sanic.websocket import WebSocketProtocol
        from sanic.server import serve
        from sanic.testing import SanicTestClient

        class TestProtocol(HttpProtocol):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.transport = None
                self.stream = None

            def connection_made(self, transport):
                self.transport = transport

            def connection_lost(self, exc):
                pass

            def data_received(self, data):
                pass



# Generated at 2022-06-18 06:06:22.781790
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Test for method send of class BaseHTTPResponse
    # This method is tested by the test_HTTPResponse_send()
    pass


# Generated at 2022-06-18 06:06:28.311322
# Unit test for function file_stream
def test_file_stream():
    async def test_streaming_fn(response):
        async with await open_async("test.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_streaming_fn,
        status=200,
        headers={},
        content_type="text/plain",
    )



# Generated at 2022-06-18 06:06:34.734472
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Protocol
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import Protocol

# Generated at 2022-06-18 06:06:39.743878
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_BaseHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return HTTPResponse("OK")

    request, response = SanicTestClient(app).get("/")

    assert response.text == "OK"


# Generated at 2022-06-18 06:06:49.480757
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import WebSocketProtocol
    from sanic.models.protocol_types import WebSocketState
    from sanic.models.protocol_types import WebSocketType
    from sanic.models.protocol_types import WsMessage
    from sanic.models.protocol_types import WsMessageType
    from sanic.models.protocol_types import WsCloseCode
    from sanic.models.protocol_types import WsCloseReason
    from sanic.models.protocol_types import WsCloseType

# Generated at 2022-06-18 06:06:57.127529
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(1024)
                if len(content) < 1:
                    break
                await response.write(content)
    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:07:06.010525
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY

    mock_stream = Mock()
    mock_stream.send = Mock()
    mock_stream.send.return_value = None

    mock_streaming_fn = Mock()
    mock_streaming_fn.return_value = None

    mock_data = Mock()

    mock_args = Mock()
    mock_kwargs = Mock()

    mock_super = Mock()
    mock_super.send = Mock()
    mock_super.send.return_value = None

    with patch("sanic.response.BaseHTTPResponse.send", mock_super.send):
        response = StreamingHTTPResponse(mock_streaming_fn)

# Generated at 2022-06-18 06:07:15.643369
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import mock_open
    from unittest.mock import DEFAULT
    from unittest.mock import create_autospec
    from unittest.mock import PropertyMock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import MagicMock

# Generated at 2022-06-18 06:07:26.241592
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import text
    from sanic.response import json
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream
    from sanic.response import json_dumps
    from sanic.response import stream_with_context
    from sanic.response import raw
    from sanic.response import file_stream
    from sanic.response import file
    from sanic.response import json
    from sanic.response import html
    from sanic.response import text
    from sanic.response import redirect
    from sanic.response import stream