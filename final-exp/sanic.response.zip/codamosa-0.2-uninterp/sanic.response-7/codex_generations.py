

# Generated at 2022-06-18 05:58:02.135201
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketProtocol

# Generated at 2022-06-18 05:58:10.290156
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.websocket("/")
    async def handler(request, ws):
        response = StreamingHTTPResponse(
            streaming_fn=lambda response: response.write("foo"),
            status=200,
            headers=None,
            content_type="text/plain; charset=utf-8",
        )
        await response.send()

    request, response = app.test_client.get("/", protocol=WebSocketProtocol)

    assert response.status == 200
    assert response.body == b"foo"



# Generated at 2022-06-18 05:58:16.049461
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(b"<html>").content_type == "text/html; charset=utf-8"
    assert html(b"<html>").status == 200



# Generated at 2022-06-18 05:58:17.908379
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    # StreamingHTTPResponse.write(data)
    return



# Generated at 2022-06-18 05:58:26.222405
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream", mode="rb") as f:
            while True:
                content = await f.read(chunk_size)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=status,
        headers=headers,
        content_type=mime_type,
    )



# Generated at 2022-06-18 05:58:34.424317
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase, sanic_test

    class TestStreamingHTTPResponse(HttpTestCase):
        def setUp(self):
            super().setUp()
            self.app.config.KEEP_ALIVE = False

        @sanic_test
        async def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = await self.create_request("/", method="GET")
           

# Generated at 2022-06-18 05:58:38.957822
# Unit test for function file
def test_file():
    async def test():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 05:58:51.004153
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest import mock
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import Mock
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import create_autospec
    from unittest.mock import mock_open

# Generated at 2022-06-18 05:58:54.990548
# Unit test for function file
def test_file():
    async def test():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 05:59:06.167330
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE

# Generated at 2022-06-18 05:59:24.011956
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.testing import SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_send")
    test_client = SanicTestClient(app, port=8888)

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            streaming_fn=lambda response: response.write("foo")
        )

    request, response = test_client.get("/")
    assert response.text == "foo"



# Generated at 2022-06-18 05:59:35.723252
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_

# Generated at 2022-06-18 05:59:40.544080
# Unit test for function file
def test_file():
    location = "./test_file.txt"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    asyncio.run(file(location, status, mime_type, headers, filename, _range))


# Generated at 2022-06-18 05:59:48.244804
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.exceptions import InvalidUsage
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Protocol
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolVersion
    from sanic.models.protocol_types import Request
    from sanic.models.protocol_types import RequestParameters
    from sanic.models.protocol_types import Response
    from sanic.models.protocol_types import ResponseParameters
   

# Generated at 2022-06-18 05:59:59.187105
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 06:00:05.962121
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_BaseHTTPResponse_send")

    @app.websocket("/")
    async def handler(request, ws):
        await ws.send("test")
        await ws.send("test2")
        await ws.send("test3")
        await ws.close()

    request, response = app.test_client.get("/", protocol=WebSocketProtocol)

    assert response.status == 101
    assert response.protocol == WebSocketProtocol
    assert response.stream is not None
    assert response.stream.send is not None

    response.send("test")
    response.send

# Generated at 2022-06-18 06:00:16.845204
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:00:25.008519
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol

# Generated at 2022-06-18 06:00:34.777787
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        async def streaming_fn(response):
            await response.write("foo")
            await asyncio.sleep(1)
            await response.write("bar")
            await asyncio.sleep(1)

        return StreamingHTTPResponse(streaming_fn)

    request, response = app.test_client.get("/")

    assert response.text == "foobar"



# Generated at 2022-06-18 06:00:46.944271
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:01:01.511726
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"
    assert html(HTMLProtocol(b"<html>")).body == b"<html>"



# Generated at 2022-06-18 06:01:09.880747
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            streaming_fn=lambda response: response.write("Hello world!")
        )

    request, response = SanicTestClient(
        app, server_kwargs={"debug": True}
    ).get("/")
    assert response.text == "Hello world!"



# Generated at 2022-06-18 06:01:14.852489
# Unit test for function file
def test_file():
    async def test():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:01:24.451536
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.request import RequestParameters
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Protocol
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolTypeEnum
    from sanic.models.protocol_types import ProtocolTypeFactory
    from sanic.models.protocol_types import ProtocolTypeFactory
    from sanic.models.protocol_types import ProtocolTypeFactory

# Generated at 2022-06-18 06:01:28.315603
# Unit test for function file
def test_file():
    async def test():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:01:38.575178
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_coro():
        async def streaming_fn(response):
            await response.write("foo")
            await asyncio.sleep(1)
            await response.write("bar")
            await asyncio.sleep(1)

        response = StreamingHTTPResponse(
            streaming_fn=streaming_fn,
            status=200,
            headers={"content-type": "text/plain"},
        )
        assert response.status == 200
        assert response.headers == {"content-type": "text/plain"}
        assert response.content_type == "text/plain"
        assert response.cookies == CookieJar({"content-type": "text/plain"})
        assert response.processed_headers == [
            (b"content-type", b"text/plain")
        ]
        assert response

# Generated at 2022-06-18 06:01:43.593912
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"
    assert html(HTMLProtocol(b"<html>")).body == b"<html>"



# Generated at 2022-06-18 06:01:49.880748
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(b"<html>").content_type == "text/html; charset=utf-8"
    assert html(b"<html>").status == 200
    assert html(b"<html>").headers == {}



# Generated at 2022-06-18 06:02:01.293088
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.websocket("/ws")
    async def handler(request, ws):
        await ws.send("1")
        await ws.send("2")
        await ws.send("3")

    request, response = app.test_client.get("/ws", protocol=WebSocketProtocol)

    assert response.status == 101
    assert response.protocol == WebSocketProtocol

    response.streaming_fn = lambda x: x.send("4")
    response.send("5")


# Generated at 2022-06-18 06:02:06.893664
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient

    app = Sanic("test_BaseHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(b"Hello")

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.body == b"Hello"



# Generated at 2022-06-18 06:02:31.449656
# Unit test for function file
def test_file():
    async def test():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:02:44.081261
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
   

# Generated at 2022-06-18 06:02:54.739916
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_

# Generated at 2022-06-18 06:02:58.644876
# Unit test for function file
def test_file():
    async def test_file_coro():
        location = "./sanic/response.py"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_coro()



# Generated at 2022-06-18 06:03:09.423071
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import text
    from sanic.response import json
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream
    from sanic.response import raw
    from sanic.response import json_dumps
    from sanic.response import stream_with_context
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHT

# Generated at 2022-06-18 06:03:15.572509
# Unit test for function file_stream
def test_file_stream():
    async def test():
        with open("test.txt", "w") as f:
            f.write("test")
        response = await file_stream("test.txt")
        assert response.body == b"test"
        os.remove("test.txt")
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()


# Generated at 2022-06-18 06:03:27.229333
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock

    mock_stream = Mock()
    mock_stream.send = Mock()
    mock_stream.send.return_value = None

    mock_streaming_fn = Mock()
    mock_streaming_fn.return_value = None

    response = StreamingHTTPResponse(
        streaming_fn=mock_streaming_fn,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
        chunked="deprecated",
    )
    response.stream = mock_stream

    response.send(None, None)

    mock_streaming_fn.assert_called_once_with(response)
    mock_stream.send.assert_called_once_with(b"", end_stream=None)



# Generated at 2022-06-18 06:03:30.795944
# Unit test for function file
def test_file():
    async def test():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:03:40.404248
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_func():
        async def _streaming_fn(response):
            async with await open_async("test.txt", mode="rb") as f:
                while True:
                    content = await f.read(4096)
                    if len(content) < 1:
                        break
                    await response.write(content)
        return StreamingHTTPResponse(
            streaming_fn=_streaming_fn,
            status=200,
            headers={},
            content_type="text/plain",
        )
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_file_stream_func())



# Generated at 2022-06-18 06:03:52.420460
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import asyncio
    from sanic.response import file_stream
    from sanic.exceptions import NotFound

    async def test_file_stream_fn(request):
        return await file_stream(
            os.path.join(tempfile.gettempdir(), "test.txt"),
            headers={"Content-Disposition": "attachment; filename=test.txt"}
        )

    async def test_file_stream_fn_not_found(request):
        return await file_stream(
            os.path.join(tempfile.gettempdir(), "test_not_found.txt"),
            headers={"Content-Disposition": "attachment; filename=test.txt"}
        )


# Generated at 2022-06-18 06:04:38.071534
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = "text/plain"
        headers = {}
        filename = "test.txt"
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:04:46.184567
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.status, 200)
            self.assertEqual(response.body, b"foobar")

# Generated at 2022-06-18 06:04:57.577956
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.server import HttpProtocol
    from sanic.testing import SanicTestClient
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedByServer
    from sanic.websocket import WebSocketConnectionClosedByClient
    from sanic.websocket import WebSocketConnectionClosedException

# Generated at 2022-06-18 06:05:00.758686
# Unit test for function file
def test_file():
    async def test():
        location = "./sanic/response.py"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)

    asyncio.run(test())



# Generated at 2022-06-18 06:05:12.306971
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_BaseHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(b"test")

    request, response = app.test_client.get("/")

    assert response.body == b"test"
    assert response.status == 200
    assert response.headers["CONTENT-TYPE"] == "text/plain; charset=utf-8"

    @app.websocket("/ws")
    async def feed(request, ws):
        await ws.send("1")
        await ws.send("2")
        await ws

# Generated at 2022-06-18 06:05:20.040707
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async("test.txt", mode="rb") as f:
            content = await f.read()
        async def _streaming_fn(response):
            await response.write(content)
        return StreamingHTTPResponse(
            streaming_fn=_streaming_fn,
            status=200,
            headers={},
            content_type="text/plain",
        )
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())


# Generated at 2022-06-18 06:05:29.473550
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = "text/plain"
        headers = {"Content-Disposition": 'attachment; filename="test_file.txt"'}
        filename = "test_file.txt"
        _range = None
        response = await file(location, status, mime_type, headers, filename, _range)
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.headers["Content-Disposition"] == 'attachment; filename="test_file.txt"'
        assert response.body == b"test_file\n"
    test_file_async()



# Generated at 2022-06-18 06:05:39.801146
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_write(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.get("/")
            self.assertEqual(response.text, "foobar")

    TestStreamingHTTPResponse().test_write()

# Generated at 2022-06-18 06:05:47.476438
# Unit test for function file_stream
def test_file_stream():
    async def test_streaming_fn(response):
        async with await open_async("test.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)
    test = StreamingHTTPResponse(
        streaming_fn=test_streaming_fn,
        status=200,
        headers=None,
        content_type="text/plain",
    )
    assert test.streaming_fn == test_streaming_fn
    assert test.status == 200
    assert test.headers == None
    assert test.content_type == "text/plain"


# Generated at 2022-06-18 06:05:51.817350
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)
    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:07:32.995038
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.status, 200)
            self.assertEqual(response.body, b"foobar")

# Generated at 2022-06-18 06:07:42.873976
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_async():
        async def test_streaming_fn(response):
            async with await open_async(location, mode="rb") as f:
                if _range:
                    await f.seek(_range.start)
                    to_send = _range.size
                    while to_send > 0:
                        content = await f.read(min((_range.size, chunk_size)))
                        if len(content) < 1:
                            break
                        to_send -= len(content)
                        await response.write(content)
                else:
                    while True:
                        content = await f.read(chunk_size)
                        if len(content) < 1:
                            break
                        await response.write(content)
        return test_streaming_fn
