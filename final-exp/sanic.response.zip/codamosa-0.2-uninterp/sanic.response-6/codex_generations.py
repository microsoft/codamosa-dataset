

# Generated at 2022-06-18 05:57:37.289238
# Unit test for function file
def test_file():
    location = "./test.txt"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    async with await open_async(location, mode="rb") as f:
        if _range:
            await f.seek(_range.start)
            out_stream = await f.read(_range.size)
            headers[
                "Content-Range"
            ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
            status = 206
        else:
            out_stream = await f.read()

    mime_type = mime_type or guess_type(filename)[0] or "text/plain"

# Generated at 2022-06-18 05:57:45.814102
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    import asyncio
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient

    app = Sanic("test_StreamingHTTPResponse_write")

    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return StreamingHTTPResponse(sample_streaming_fn)

    request, response = app.test_client.post("/")

    assert response.status == 200
    assert response.text == "foobar"



# Generated at 2022-06-18 05:57:52.925719
# Unit test for function file

# Generated at 2022-06-18 05:57:56.025354
# Unit test for function json
def test_json():
    assert json({"a": 1}) == HTTPResponse(b'{"a": 1}', status=200, content_type='application/json')


# Generated at 2022-06-18 05:58:04.238350
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers=None,
        content_type="text/plain",
    )



# Generated at 2022-06-18 05:58:07.814772
# Unit test for function file
def test_file():
    async def test():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 05:58:16.183026
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient

    app = Sanic("test_BaseHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(b"Hello")

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.body == b"Hello"



# Generated at 2022-06-18 05:58:21.562526
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./sanic/response.py"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()



# Generated at 2022-06-18 05:58:27.405513
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write("foo")
        await response.write("bar")

    response = stream(streaming_fn, content_type="text/plain")
    assert response.streaming_fn == streaming_fn
    assert response.content_type == "text/plain"
    assert response.status == 200
    assert response.headers == {}



# Generated at 2022-06-18 05:58:35.135738
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                out_stream = await f.read(_range.size)
                headers[
                    "Content-Range"
                ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
                status = 206
            else:
                out_stream = await f.read()

        mime_type = mime_type or guess_type(filename)[0] or "text/plain"

# Generated at 2022-06-18 05:59:00.589996
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 05:59:11.611374
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import mock_open
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call

# Generated at 2022-06-18 05:59:21.178175
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async def streaming_fn(response):
            await response.send("foo")
            await asyncio.sleep(1)
            await response.send("bar")
            await asyncio.sleep(1)

        response = StreamingHTTPResponse(
            streaming_fn=streaming_fn,
            status=200,
            headers={},
            content_type="text/plain; charset=utf-8",
        )
        assert response.status == 200
        assert response.content_type == "text/plain; charset=utf-8"
        assert response.headers == {}
        assert response.streaming_fn == streaming_fn
        await response.send()

    asyncio.run(test_file_stream())


# Generated at 2022-06-18 05:59:25.635188
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 05:59:37.146463
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import HTML

# Generated at 2022-06-18 05:59:47.162324
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async("test.txt", mode="rb") as f:
            content = await f.read()
        response = await file_stream("test.txt")
        assert response.body == content
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.headers == {}
        response = await file_stream("test.txt", filename="test.txt")
        assert response.headers == {
            "Content-Disposition": 'attachment; filename="test.txt"'
        }
        response = await file_stream("test.txt", _range=Range(0, 10, 100))
        assert response.status == 206

# Generated at 2022-06-18 05:59:58.225326
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommon

# Generated at 2022-06-18 06:00:05.465267
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.response import HTTPResponse
    from sanic.response import text
    from sanic.response import json
    from sanic.response import html
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import redirect
    from sanic.response import stream
    from sanic.response import raw
    from sanic.response import json_dumps
    from sanic.response import stream_with_context
    from sanic.response import HTTPResponseBody
    from sanic.response import HTTPResponseStream
    from sanic.response import HTTPResponseFile
    from sanic.response import HTTPResp

# Generated at 2022-06-18 06:00:07.706791
# Unit test for function file
def test_file():
    async def test():
        assert await file("test.txt")
    asyncio.run(test())



# Generated at 2022-06-18 06:00:18.339399
# Unit test for function file
def test_file():
    import os
    import tempfile
    import shutil
    import asyncio
    from sanic.response import file

    tmp_dir = tempfile.mkdtemp()
    file_path = os.path.join(tmp_dir, 'test.txt')
    with open(file_path, 'w') as f:
        f.write('test')

    async def test_file_response():
        response = await file(file_path)
        assert response.body == b'test'
        assert response.status == 200
        assert response.content_type == 'text/plain'
        assert response.headers['Content-Type'] == 'text/plain'

    async def test_file_response_with_range():
        response = await file(file_path, _range=Range(0, 2, 4))
        assert response.body == b

# Generated at 2022-06-18 06:00:31.875053
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"



# Generated at 2022-06-18 06:00:39.077058
# Unit test for function file
def test_file():
    location = "./test.txt"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    async with await open_async(location, mode="rb") as f:
        if _range:
            await f.seek(_range.start)
            out_stream = await f.read(_range.size)
            headers[
                "Content-Range"
            ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
            status = 206
        else:
            out_stream = await f.read()

    mime_type = mime_type or guess_type(filename)[0] or "text/plain"

# Generated at 2022-06-18 06:00:50.107674
# Unit test for function file
def test_file():
    import os
    import tempfile
    import shutil
    from sanic.response import file
    from sanic.testing import SanicTestClient

    app = Sanic("test_file")

    @app.route("/")
    async def test(request):
        return await file(__file__)

    @app.route("/download")
    async def test_download(request):
        return await file(__file__, filename="test.py")

    @app.route("/download_range")
    async def test_download_range(request):
        return await file(__file__, _range=(0, 10))

    @app.route("/download_range_invalid")
    async def test_download_range_invalid(request):
        return await file(__file__, _range=(0, 100))


# Generated at 2022-06-18 06:00:54.030799
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import json
    from sanic.response import text
    from sanic.response import html
    from sanic.response import redirect
    from sanic.response import file
    from sanic.response import file_stream
    from sanic.response import stream
    from sanic.response import json_dumps
    from sanic.response import json_loads
    from sanic.response import stream_with_context

# Generated at 2022-06-18 06:00:59.131633
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_test():
        async with await open_async("test_file_stream.txt", mode="w") as f:
            await f.write("test_file_stream")
        response = await file_stream("test_file_stream.txt")
        assert response.body == b"test_file_stream"
        os.remove("test_file_stream.txt")
    asyncio.run(test_file_stream_test())



# Generated at 2022-06-18 06:01:08.702709
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Protocol
    from sanic.models.protocol_types import ProtocolType
    from sanic.models.protocol_types import ProtocolVersion
    from sanic.models.protocol_types import Request
    from sanic.models.protocol_types import Response
    from sanic.models.protocol_types import Stream
    from sanic.models.protocol_types import StreamType
    from sanic.models.protocol_types import StreamWriter
    from sanic.models.protocol_types import URL

# Generated at 2022-06-18 06:01:19.541786
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range

# Generated at 2022-06-18 06:01:27.979162
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import Http
    from sanic.response import Header
    from sanic.response import CookieJar
    from sanic.response import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.response import has_message_body
    from sanic.response import remove_entity_headers
    from sanic.response import json_dumps
    from sanic.response import partial
    from sanic.response import warn
    from sanic.response import quote_plus
    from sanic.response import guess_type
    from sanic.response import path
    from sanic.response import PurePath

# Generated at 2022-06-18 06:01:33.103705
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()


# Generated at 2022-06-18 06:01:41.159085
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel

    mock_stream = Mock()
    mock_stream.send = Mock()

    mock_response = StreamingHTTPResponse(
        streaming_fn=None,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
        chunked="deprecated",
    )
    mock_response.stream = mock_stream

    with patch.object(
        StreamingHTTPResponse, "_encode_body", return_value=sentinel.encoded
    ):
        mock_response.write(sentinel.data)

    mock_stream.send.assert_called_once_with(sentinel.encoded, end_stream=None)


# Generated at 2022-06-18 06:02:12.433412
# Unit test for function file
def test_file():
    location = "./test_file.txt"
    status = 200
    mime_type = None
    headers = None
    filename = None
    _range = None
    file(location, status, mime_type, headers, filename, _range)


# Generated at 2022-06-18 06:02:20.494857
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestClient
    from sanic.app import Sanic

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            lambda response: response.write("Hello world!")
        )

    request, response = app.test_client.get("/")

    assert response.text == "Hello world!"



# Generated at 2022-06-18 06:02:28.161059
# Unit test for function file_stream
def test_file_stream():
    async def test_stream(response):
        async with await open_async("test_file_stream.py", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_stream,
        status=200,
        headers={},
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:02:39.480466
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 06:02:42.649552
# Unit test for function html
def test_html():
    class Test:
        def __html__(self):
            return '<html>'
    assert html(Test()).body == b'<html>'


# Generated at 2022-06-18 06:02:53.595187
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:03:02.862758
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import Range

# Generated at 2022-06-18 06:03:13.918993
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:03:19.431390
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)
    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:03:29.561878
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 06:04:13.045699
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return stream(sample_streaming_fn)


# Generated at 2022-06-18 06:04:22.577994
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import DEFAULT
    from unittest.mock import PropertyMock
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:04:27.284119
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"
    assert html(HTMLProtocol(b"<html>")).body == b"<html>"



# Generated at 2022-06-18 06:04:39.370626
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.status, 200)
            self.assertEqual(response.text, "foobar")
    # Unit test for method send of class StreamingHTTPResponse

# Generated at 2022-06-18 06:04:45.035030
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async("test.txt", mode="rb") as f:
            content = await f.read()
        response = await file_stream("test.txt")
        assert response.body == content
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.headers == {"Content-Type": "text/plain"}
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()



# Generated at 2022-06-18 06:04:56.460351
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 06:05:02.383410
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("tests/test_file.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain",
    )



# Generated at 2022-06-18 06:05:13.696413
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.asgi import ASGIProtocol
    from sanic.constants import ASGI_VERSION
    from sanic.compat import is_coroutine_function
    from sanic.exceptions import InvalidUsage
    from sanic.websocket import WebSocketProtocol
    from sanic.asgi import ASGIProtocol
    from sanic.constants import ASGI_VERSION
    from sanic.compat import is_coroutine_function
    from sanic.exceptions import InvalidUsage
    from sanic.websocket import WebSocketProtocol
    from sanic.asgi import ASGIProtocol
    from sanic.constants import ASGI_VERSION
   

# Generated at 2022-06-18 06:05:25.172045
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.server import HttpProtocol as HttpProtocolServer
    from sanic.server import serve
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.helpers import has_message_body
    from sanic.helpers import remove_entity_headers
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol

# Generated at 2022-06-18 06:05:28.953408
# Unit test for function file
def test_file():
    async def test():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()
