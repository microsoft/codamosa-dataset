

# Generated at 2022-06-18 05:58:02.967733
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import asyncio
    from sanic.response import file_stream
    from sanic.server import HttpProtocol

    async def test_file_stream_handler(request):
        return await file_stream(__file__)

    app = Sanic("test_file_stream")
    app.add_route(test_file_stream_handler, "/test_file_stream")

    _, db_fd = tempfile.mkstemp()
    os.close(db_fd)

    loop = asyncio.new_event_loop()

# Generated at 2022-06-18 05:58:10.822336
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    import shutil
    import asyncio
    from sanic.response import file_stream
    from sanic.exceptions import NotFound

    def create_file(path, size):
        with open(path, 'wb') as f:
            f.seek(size - 1)
            f.write(b'\0')

    def create_temp_file(size):
        fd, path = tempfile.mkstemp()
        os.close(fd)
        create_file(path, size)
        return path

    def remove_temp_file(path):
        os.remove(path)

    def create_temp_dir():
        return tempfile.mkdtemp()

    def remove_temp_dir(path):
        shutil.rmtree(path)


# Generated at 2022-06-18 05:58:16.827432
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(b"<html>").content_type == "text/html; charset=utf-8"
    assert html(b"<html>").status == 200



# Generated at 2022-06-18 05:58:21.714842
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 05:58:27.061117
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"
    assert html(HTMLProtocol(b"<html>")).body == b"<html>"



# Generated at 2022-06-18 05:58:32.536818
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient
    from sanic import Sanic

    app = Sanic("test_BaseHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return HTTPResponse("OK")

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "OK"



# Generated at 2022-06-18 05:58:39.459878
# Unit test for function file_stream
def test_file_stream():
    async def test_stream(response):
        async with await open_async("test.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_stream,
        status=200,
        headers={},
        content_type="text/plain",
    )



# Generated at 2022-06-18 05:58:47.959363
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 05:58:57.601551
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.response import HTTPResponse
    from sanic.response import HTTPResponseBody
    from sanic.response import HTTPResponseStream
    from sanic.response import HTTPResponseFile
    from sanic.response import HTTPResponseRedirect
    from sanic.response import HTTPResponseRaw
    from sanic.response import HTTPResponseText
    from sanic.response import HTTPResponseJSON
    from sanic.response import HTTPResponseFileStream
    from sanic.response import HTTPResponseStreaming
    from sanic.response import HTT

# Generated at 2022-06-18 05:59:03.425910
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()


# Generated at 2022-06-18 05:59:21.978138
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.models.protocol_types import WebSocketProtocol
    from sanic.models.protocol_types import WebSocketState
    from sanic.models.protocol_types import WebSocketStream
    from sanic.models.protocol_types import WebSocketMessage
    from sanic.models.protocol_types import WebSocketMessageType
    from sanic.models.protocol_types import WebSocketCloseCode
    from sanic.models.protocol_types import WebSocketClose

# Generated at 2022-06-18 05:59:33.436576
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import remove_entity_headers
    from sanic.compat import Header
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.helpers import has_message_body
    from sanic.constants import DEFAULT_HTTP_CONT

# Generated at 2022-06-18 05:59:44.579867
# Unit test for function json
def test_json():
    assert json({"a": 1}) == HTTPResponse(b'{"a": 1}', status=200, headers=None, content_type='application/json')
    assert json({"a": 1}, status=201) == HTTPResponse(b'{"a": 1}', status=201, headers=None, content_type='application/json')
    assert json({"a": 1}, status=202, headers={'a': 'b'}) == HTTPResponse(b'{"a": 1}', status=202, headers={'a': 'b'}, content_type='application/json')

# Generated at 2022-06-18 05:59:54.947367
# Unit test for function file_stream
def test_file_stream():
    async def test_stream():
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)
    return test_stream


# Generated at 2022-06-18 06:00:01.321167
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    response = StreamingHTTPResponse(sample_streaming_fn)
    assert response.streaming_fn == sample_streaming_fn
    assert response.status == 200
    assert response.content_type == "text/plain; charset=utf-8"
    assert response.headers == {}
    assert response._cookies == None


# Generated at 2022-06-18 06:00:12.534145
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:00:22.101211
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http

# Generated at 2022-06-18 06:00:34.355959
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async def _streaming_fn(response):
            async with await open_async(location, mode="rb") as f:
                if _range:
                    await f.seek(_range.start)
                    to_send = _range.size
                    while to_send > 0:
                        content = await f.read(min((_range.size, chunk_size)))
                        if len(content) < 1:
                            break
                        to_send -= len(content)
                        await response.write(content)
                else:
                    while True:
                        content = await f.read(chunk_size)
                        if len(content) < 1:
                            break
                        await response.write(content)


# Generated at 2022-06-18 06:00:46.677398
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.websocket import WebSocketProtocol

    class Test(HttpTestCase):
        def test_send(self):
            @self.app.route("/")
            async def handler(request):
                response = HTTPResponse("Hello")
                await response.send(data="World")
                return response

            request, response = self.get("/")
            self.assertEqual(response.body, b"World")

            @self.app.websocket("/ws")
            async def handler(request, ws):
                response = HTTPResponse("Hello")
                await response.send(data="World")
                return response


# Generated at 2022-06-18 06:00:49.931025
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(HTMLProtocol("<html>")).body == b"<html>"



# Generated at 2022-06-18 06:01:20.268949
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.testing import SanicTestClient

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_write(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request_and_response(
                "/", method="POST"
            )
            self.app.handle_request(request, response)


# Generated at 2022-06-18 06:01:28.362352
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:01:38.613264
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HOST, PORT
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosedOK
    from sanic.websocket import WebSocketConnectionClosedError
    from sanic.websocket import WebSocketConnectionClosedNoStatusReceived
    from sanic.websocket import WebSocketConnectionClosedAbnormalClosure
    from sanic.websocket import WebSocketConnectionClosedTLSHandshake
    from sanic.websocket import WebSocketConnectionClosedPolicyViolation
    from sanic.websocket import WebSocketConnectionClosedTooLarge

# Generated at 2022-06-18 06:01:49.700839
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.testing import SanicTestClient
    from sanic.testing import async_test

    app = Sanic("test_StreamingHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(
            lambda response: asyncio.sleep(0.5, loop=app.loop),
            headers={"Content-Type": "text/plain"},
        )

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.headers.get("Content-Type") == "text/plain"



# Generated at 2022-06-18 06:02:01.087492
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import sentinel
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:02:09.687949
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    request = Request.blank('/')
    request.transport = Mock()
    request.transport.get_extra_info.return_value = None
    request.transport.is_closing.return_value = False
    request.transport.write.return_value = None
    request.transport.close.return_value = None
    request.transport.abort.return_value = None
    request.transport.set_tcp_cork.return_value = None
    request.transport.set_tcp_nodelay.return_value = None
    request.transport.set_write_buffer_limits.return_value = None

# Generated at 2022-06-18 06:02:22.087528
# Unit test for constructor of class StreamingHTTPResponse
def test_StreamingHTTPResponse():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import stream
    from sanic.views import json
    from sanic.views import text
    from sanic.views import html
    from sanic.views import file
    from sanic.views import redirect
    from sanic.views import file_stream
    from sanic.views import file_stream
    from sanic.views import file_stream
    from sanic.views import file_stream
    from sanic.views import file_stream
    from sanic.views import file_stream
    from sanic.views import file_stream

# Generated at 2022-06-18 06:02:31.111800
# Unit test for function file_stream
def test_file_stream():
    async def test():
        response = await file_stream(
            location=__file__,
            status=200,
            chunk_size=4096,
            mime_type=None,
            headers=None,
            filename=None,
            chunked="deprecated",
            _range=None,
        )
        assert response.status == 200
        assert response.content_type == "text/x-python"
        assert response.headers == {}
        assert response.streaming_fn is not None
        assert response.body is None

    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()



# Generated at 2022-06-18 06:02:42.087472
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_streaming_response(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.body, b"foobar")


# Generated at 2022-06-18 06:02:53.346617
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.http import HttpProtocol
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse

# Generated at 2022-06-18 06:03:19.734745
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)
                    if len(content) < 1:
                        break
                    await response.write(content)


# Generated at 2022-06-18 06:03:29.802602
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import patch
    from unittest.mock import Mock
    from unittest.mock import MagicMock
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import DEFAULT
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import sentinel
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:03:40.675059
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketCommonState
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketError


# Generated at 2022-06-18 06:03:48.172713
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(b"<html>").content_type == "text/html; charset=utf-8"
    assert html("<html>").content_type == "text/html; charset=utf-8"
    assert html(b"<html>").status == 200
    assert html("<html>").status == 200



# Generated at 2022-06-18 06:03:58.166460
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header, open_async
    from sanic.constants import DE

# Generated at 2022-06-18 06:04:10.696155
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE

# Generated at 2022-06-18 06:04:18.354652
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.py", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers=None,
        content_type="text/plain; charset=utf-8",
    )



# Generated at 2022-06-18 06:04:22.211797
# Unit test for function file
def test_file():
    async def test():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)

    asyncio.run(test())



# Generated at 2022-06-18 06:04:34.183054
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase
    from sanic.websocket import WebSocketProtocol

    class Test(HttpTestCase):
        def test_send(self):
            @self.app.route("/")
            async def handler(request):
                response = HTTPResponse(b"Test")
                await response.send(b"Test")
                return response

            request, response = self.get("/")
            self.assertEqual(response.body, b"Test")

        def test_send_websocket(self):
            @self.app.websocket("/")
            async def handler(request, ws):
                response = HTTPResponse(b"Test")
                await response.send(b"Test")
                return response



# Generated at 2022-06-18 06:04:43.675135
# Unit test for function file
def test_file():
    async def test():
        assert (await file("test.txt")).body == b"test"
        assert (await file("test.txt", _range=Range(0, 2, 3))).body == b"tes"
        assert (await file("test.txt", _range=Range(0, 2, 3))).status == 206
        assert (await file("test.txt", _range=Range(0, 2, 3))).headers[
            "Content-Range"
        ] == "bytes 0-2/3"
        assert (await file("test.txt", _range=Range(0, 2, 3))).headers[
            "Content-Type"
        ] == "text/plain"

# Generated at 2022-06-18 06:05:44.903275
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async("test.txt", mode="w") as f:
            await f.write("test")
        response = await file_stream("test.txt")
        assert response.body == b"test"
        assert response.status == 200
        assert response.content_type == "text/plain"
        os.remove("test.txt")
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())


# Generated at 2022-06-18 06:05:51.669811
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_write(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.post("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("POST", "/")
            self.assertEqual(response.status, 200)
            self.assertEqual(response.text, "foobar")

    TestStreamingHTTPResponse().test_write()

# Generated at 2022-06-18 06:05:57.924622
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from sanic.response import StreamingHTTPResponse

    response = StreamingHTTPResponse(None)
    response.stream = Mock()
    response.write("foo")
    response.stream.send.assert_called_once_with(b"foo", end_stream=False)



# Generated at 2022-06-18 06:06:05.554588
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import HTTPResponse
    from sanic.testing import HttpTestCase, SanicTestClient
    from sanic.websocket import WebSocketProtocol

    app = Sanic("test_BaseHTTPResponse_send")

    @app.route("/")
    async def handler(request):
        return HTTPResponse(b"test")

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.body == b"test"

    @app.websocket("/ws")
    async def handler(request, ws):
        await ws.send("test")

    request, response = app.test_client.get("/ws", protocol=WebSocketProtocol)

    assert response.status == 101
    assert response.body == b

# Generated at 2022-06-18 06:06:11.736559
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_coro():
        location = "./test_file_stream.txt"
        with open(location, "w") as f:
            f.write("test_file_stream")
        response = await file_stream(location)
        assert response.body == b"test_file_stream"
        os.remove(location)
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_file_stream_coro())


# Generated at 2022-06-18 06:06:14.612567
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    # Test for method send of class BaseHTTPResponse
    # This method is tested in test_HTTPResponse_send
    pass


# Generated at 2022-06-18 06:06:24.827115
# Unit test for function file_stream
def test_file_stream():
    import os
    import tempfile
    from sanic.response import file_stream
    from sanic.testing import SanicTestClient

    app = Sanic("test_file_stream")

    @app.route("/")
    async def handler(request):
        return await file_stream(
            os.path.join(tempfile.gettempdir(), "test.txt"),
            headers={"Content-Disposition": "attachment; filename=test.txt"}
        )

    client = SanicTestClient(app, protocol=HttpProtocol)
    response = client.get("/")
    assert response.status == 200
    assert response.headers.get("Content-Disposition") == "attachment; filename=test.txt"



# Generated at 2022-06-18 06:06:32.536749
# Unit test for function file_stream
def test_file_stream():
    async def test():
        location = "./test/test_file.txt"
        status = 200
        chunk_size = 4096
        mime_type = None
        headers = None
        filename = None
        chunked = "deprecated"
        _range = None
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                to_send = _range.size
                while to_send > 0:
                    content = await f.read(min((_range.size, chunk_size)))
                    if len(content) < 1:
                        break
                    to_send -= len(content)
                    await response.write(content)
            else:
                while True:
                    content = await f.read(chunk_size)

# Generated at 2022-06-18 06:06:36.671953
# Unit test for function file
def test_file():
    async def test():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()



# Generated at 2022-06-18 06:06:46.038649
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.server import HttpProtocol as HttpProtocol_
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol as WebSocketProtocol_
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketCommonProtocol as WebSocketCommonProtocol_
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketConnectionClosed as WebSocketConnectionClosed_
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketError as WebSocketError_
    from sanic.websocket import WebSocketState