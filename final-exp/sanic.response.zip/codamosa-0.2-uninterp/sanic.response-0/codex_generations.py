

# Generated at 2022-06-18 05:57:49.107624
# Unit test for function stream
def test_stream():
    @app.route("/")
    async def index(request):
        async def streaming_fn(response):
            await response.write('foo')
            await response.write('bar')

        return stream(streaming_fn, content_type='text/plain')

    client = TestClient(app)
    response = client.get("/")
    assert response.status_code == 200
    assert response.text == "foobar"


# Generated at 2022-06-18 05:57:54.365220
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()



# Generated at 2022-06-18 05:58:05.950825
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest import TestCase

    class TestStreamingHTTPResponse(TestCase):
        @patch("sanic.response.super")
        def test_write(self, mock_super):
            mock_stream = Mock()
            mock_stream.send = Mock()
            mock_stream.send.return_value = None
            mock_streaming_fn = Mock()
            mock_streaming_fn.return_value = None
            mock_data = Mock()
            mock_data.encode = Mock()
            mock_data.encode.return_value = None
            mock_kwargs = Mock()
            mock_kwargs.get = Mock()
            mock_kwargs.get.return_value = None

# Generated at 2022-06-18 05:58:20.647072
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http

# Generated at 2022-06-18 05:58:31.080522
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.compat import Header
    from sanic.helpers import has_message_body
    from sanic.helpers import remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.compat import Header
    from sanic.helpers import has_message_body
    from sanic.helpers import remove_entity_

# Generated at 2022-06-18 05:58:35.078719
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')

    response = stream(streaming_fn, content_type='text/plain')
    assert response.streaming_fn == streaming_fn
    assert response.content_type == 'text/plain'
    assert response.status == 200
    assert response.headers == {}
    assert response._cookies == None


# Generated at 2022-06-18 05:58:46.701836
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                out_stream = await f.read(_range.size)
                headers[
                    "Content-Range"
                ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
                status = 206
            else:
                out_stream = await f.read()

        mime_type = mime_type or guess_type(filename)[0] or "text/plain"

# Generated at 2022-06-18 05:58:51.296543
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')

    response = stream(streaming_fn, content_type='text/plain')
    assert response.content_type == 'text/plain'
    assert response.streaming_fn == streaming_fn
    assert response.status == 200
    assert response.headers == {}
    assert response._cookies == None
    assert response.stream.send == None
    assert response.stream.receive == None
    assert response.stream.close == None
    assert response.stream.closed == False
    assert response.stream.is_client == False
    assert response.stream.is_server == False
    assert response.stream.is_bidi == False
    assert response.stream.is_unidirectional == False

# Generated at 2022-06-18 05:58:59.430795
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import text
    from sanic.response import json
    from sanic.response import html
    from sanic.response import file
    from sanic.response import redirect
    from sanic.response import stream
    from sanic.response import file_stream
    from sanic.response import json_dumps
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse
    from sanic.response import StreamingHTTPResponse

# Generated at 2022-06-18 05:59:05.217814
# Unit test for function stream
def test_stream():
    async def streaming_fn(response):
        await response.write('foo')
        await response.write('bar')

    response = stream(streaming_fn, content_type='text/plain')
    assert response.streaming_fn == streaming_fn
    assert response.content_type == 'text/plain'
    assert response.status == 200
    assert response.headers == {}


# Generated at 2022-06-18 05:59:24.253010
# Unit test for function file
def test_file():
    async def test():
        location = path.join(path.dirname(__file__), "test_file.txt")
        response = await file(location)
        assert response.body == b"test"
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.headers.get("Content-Disposition") is None
        response = await file(location, filename="test.txt")
        assert response.headers.get("Content-Disposition") == 'attachment; filename="test.txt"'
        response = await file(location, _range=Range(0, 2, 3))
        assert response.body == b"te"
        assert response.status == 206
        assert response.headers.get("Content-Range") == "bytes 0-2/3"
    asyncio.run(test())




# Generated at 2022-06-18 05:59:35.918232
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import WebSocketCommonConnection
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnection
    from sanic.websocket import Web

# Generated at 2022-06-18 05:59:45.553621
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import SanicTestClient
    from sanic import Sanic

    app = Sanic("test_StreamingHTTPResponse_write")

    async def streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.route("/")
    async def handler(request):
        return StreamingHTTPResponse(streaming_fn)

    request, response = app.test_client.get("/")

    assert response.status == 200
    assert response.text == "foobar"



# Generated at 2022-06-18 05:59:57.009418
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import mock_open
    from unittest.mock import MagicMock
    from unittest.mock import ANY
    from unittest.mock import DEFAULT
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open

# Generated at 2022-06-18 06:00:05.197536
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.models.protocol_types import Range
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body
    from sanic.helpers import remove_entity_headers
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body
    from sanic.helpers import remove_entity_headers

# Generated at 2022-06-18 06:00:13.262116
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("/tmp/test.txt", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain",
    )



# Generated at 2022-06-18 06:00:22.648496
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./tests/test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None

        async with await open_async(location, mode="rb") as f:
            if _range:
                await f.seek(_range.start)
                out_stream = await f.read(_range.size)
                headers[
                    "Content-Range"
                ] = f"bytes {_range.start}-{_range.end}/{_range.total}"
                status = 206
            else:
                out_stream = await f.read()

        mime_type = mime_type or guess_type(filename)[0] or "text/plain"

# Generated at 2022-06-18 06:00:34.704391
# Unit test for method send of class StreamingHTTPResponse
def test_StreamingHTTPResponse_send():
    from sanic.response import StreamingHTTPResponse
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import stream
    from sanic.views import StreamBuffer
    from sanic.views import StreamBufferView
    from sanic.views import StreamBufferView
    from sanic.views import StreamBufferView
    from sanic.views import StreamBufferView
    from sanic.views import StreamBufferView
    from sanic.views import StreamBufferView
    from sanic.views import StreamBufferView
    from sanic.views import StreamBufferView
    from sanic.views import StreamBufferView
    from sanic.views import StreamBufferView
    from sanic.views import StreamBufferView
    from sanic.views import StreamBufferView
    from sanic.views import StreamBuffer

# Generated at 2022-06-18 06:00:46.143346
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HttpTestCase

    class TestStreamingHTTPResponse(HttpTestCase):
        def test_write(self):
            async def streaming_fn(response):
                await response.write("foo")
                await asyncio.sleep(1)
                await response.write("bar")
                await asyncio.sleep(1)

            @self.app.route("/")
            async def handler(request):
                return StreamingHTTPResponse(streaming_fn)

            request, response = self.create_request("/")
            self.assertEqual(response.status, 200)
            self.assertEqual(response.text, "foobar")

# Generated at 2022-06-18 06:00:55.435029
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import MagicMock
    from sanic.response import StreamingHTTPResponse
    from sanic.response import BaseHTTPResponse
    from sanic.response import StreamingFunction
    from sanic.response import Http
    from sanic.response import Header
    from sanic.response import CookieJar
    from sanic.response import HTMLProtocol
    from sanic.response import Range
    from sanic.response import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.response import has_message_body
    from sanic.response import remove_entity_headers
    from sanic.response import Http
    from sanic.response import Header
    from sanic.response import CookieJar
    from sanic.response import HTMLProtocol
    from sanic.response import Range

# Generated at 2022-06-18 06:01:34.295071
# Unit test for function file
def test_file():
    async def test():
        return await file(location="./test.txt", status=200, mime_type=None, headers=None, filename=None, _range=None)
    print(test())


# Generated at 2022-06-18 06:01:39.352098
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        location = "./test_file_stream.txt"
        with open(location, "w") as f:
            f.write("hello world")
        response = await file_stream(location)
        assert response.body == b"hello world"
        os.remove(location)
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_file_stream())



# Generated at 2022-06-18 06:01:47.463184
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async("test.txt", mode="rb") as f:
            content = await f.read()
        response = await file_stream("test.txt")
        assert response.body == content
        assert response.status == 200
        assert response.content_type == "text/plain"
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())
    loop.close()



# Generated at 2022-06-18 06:01:58.192915
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import Mock
    from unittest.mock import patch
    from unittest.mock import sentinel
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import MagicMock
    from unittest.mock import create_autospec
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_open
    from unittest.mock import mock_

# Generated at 2022-06-18 06:02:03.125385
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:02:05.164974
# Unit test for function html
def test_html():
    class TestClass:
        def __html__(self):
            return "test"
    assert html(TestClass()).body == b"test"



# Generated at 2022-06-18 06:02:11.707663
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.constants import HTTP_STATUS_CODES
    from sanic.constants import SERVER_SOFTWARE
    from sanic.constants import SERVER_SOFTWARE_STATEMENT
    from sanic.constants import SERVER_SOFTWARE_STATEMENT_SHORT
    from sanic.constants import SERVER_SOFTWARE_STATEMENT_DEBUG
    from sanic.constants import SERVER_SOFTWARE_STATEMENT_DEBUG_SHORT
    from sanic.constants import SERVER_SOFTWARE_STATEMENT_TESTING
    from sanic.constants import SERVER_SOFTWARE_STATEMENT_TEST

# Generated at 2022-06-18 06:02:22.949069
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.compat import Header
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from ujson import dumps as json_dumps
    from json import dumps
    from urllib.parse import quote_plus
    from warnings import warn
    from os import path
    from pathlib import PurePath

# Generated at 2022-06-18 06:02:32.974414
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream():
        async def _streaming_fn(response):
            async with await open_async(location, mode="rb") as f:
                if _range:
                    await f.seek(_range.start)
                    to_send = _range.size
                    while to_send > 0:
                        content = await f.read(min((_range.size, chunk_size)))
                        if len(content) < 1:
                            break
                        to_send -= len(content)
                        await response.write(content)
                else:
                    while True:
                        content = await f.read(chunk_size)
                        if len(content) < 1:
                            break
                        await response.write(content)


# Generated at 2022-06-18 06:02:39.375699
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    async def sample_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    @app.post("/")
    async def test(request):
        return stream(sample_streaming_fn)


# Generated at 2022-06-18 06:03:16.151117
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    pass

    # TODO: Add tests for BaseHTTPResponse.send



# Generated at 2022-06-18 06:03:27.638113
# Unit test for function file_stream
def test_file_stream():
    async def test_fn(request):
        return await file_stream(
            "./test_file_stream.py",
            status=200,
            chunk_size=4096,
            mime_type=None,
            headers=None,
            filename=None,
            chunked="deprecated",
            _range=None,
        )

    app = Sanic("test_file_stream")
    app.add_route(test_fn, "/test_file_stream")
    client = app.test_client
    request, response = client.get("/test_file_stream")
    assert response.status == 200

# Generated at 2022-06-18 06:03:34.602692
# Unit test for function file_stream
def test_file_stream():
    import os
    from sanic import Sanic
    from sanic.response import file_stream
    from sanic.response import text
    from sanic.response import HTTPResponse
    from sanic.response import StreamingHTTPResponse

    app = Sanic()

    @app.route("/")
    async def test(request):
        return file_stream(
            "tests/test_file.txt",
            headers={"Content-Type": "application/octet-stream"},
            filename="test_file.txt",
        )


# Generated at 2022-06-18 06:03:40.572300
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test_file_async()


# Generated at 2022-06-18 06:03:52.509471
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.http import Http
    from sanic.compat import Header, open_async
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range


# Generated at 2022-06-18 06:03:56.983449
# Unit test for function file_stream
def test_file_stream():
    async def test_streaming_fn(response):
        await response.write("foo")
        await asyncio.sleep(1)
        await response.write("bar")
        await asyncio.sleep(1)

    assert StreamingHTTPResponse(streaming_fn=test_streaming_fn).streaming_fn == test_streaming_fn


# Generated at 2022-06-18 06:04:09.060858
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from sanic.response import StreamingHTTPResponse
    from sanic.testing import HOST, PORT
    from sanic import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.response import HTTPResponse
    from sanic.request import Request
    import asyncio
    import pytest
    import ujson

    app = Sanic("test_StreamingHTTPResponse_write")

    @app.websocket("/test")
    async def test(request, ws):
        response = StreamingHTTPResponse(
            streaming_fn=lambda response: asyncio.sleep(0.5)
        )
        await response.write("foo")
        await asyncio.sleep(0.5)
        await response.write("bar")

# Generated at 2022-06-18 06:04:19.807737
# Unit test for method write of class StreamingHTTPResponse
def test_StreamingHTTPResponse_write():
    from unittest.mock import patch
    from sanic.response import StreamingHTTPResponse
    from sanic.request import Request
    from sanic.exceptions import InvalidUsage
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketReader
    from sanic.websocket import WebSocketWriter
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketCommonState

# Generated at 2022-06-18 06:04:30.424822
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.helpers import remove_entity_headers
    from sanic.models.protocol_types import HTMLProtocol, Range
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar

# Generated at 2022-06-18 06:04:34.776832
# Unit test for function file
def test_file():
    async def test():
        return await file(location="test.txt", status=200, mime_type=None, headers=None, filename=None, _range=None)
    assert test() == HTTPResponse(body=b'', status=200, headers={}, content_type='text/plain')



# Generated at 2022-06-18 06:05:51.323011
# Unit test for function file_stream
def test_file_stream():
    async def test(request):
        return await file_stream(
            location=__file__,
            status=200,
            chunk_size=4096,
            mime_type=None,
            headers=None,
            filename=None,
            chunked="deprecated",
            _range=None,
        )

    app = Sanic("test_file_stream")
    app.add_route(test, "/test_file_stream")

    request, response = app.test_client.get("/test_file_stream")
    assert response.status == 200
    assert response.headers.get("Content-Type") == "text/x-python"
    assert response.headers.get("Content-Disposition") == None
    assert response.headers.get("Content-Range") == None

# Generated at 2022-06-18 06:05:58.180952
# Unit test for function file
def test_file():
    async def test():
        location = "./test.txt"
        status = 200
        mime_type = "text/plain"
        headers = {"Content-Disposition": 'attachment; filename="test.txt"'}
        filename = "test.txt"
        _range = None
        await file(location, status, mime_type, headers, filename, _range)
    test()


# Generated at 2022-06-18 06:06:03.910151
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream_fn(response):
        async with await open_async("test_file_stream.py", mode="rb") as f:
            while True:
                content = await f.read(4096)
                if len(content) < 1:
                    break
                await response.write(content)

    return StreamingHTTPResponse(
        streaming_fn=test_file_stream_fn,
        status=200,
        headers={},
        content_type="text/plain",
    )



# Generated at 2022-06-18 06:06:05.029493
# Unit test for function file
def test_file():
    assert asyncio.run(file("/home/user/file.txt"))


# Generated at 2022-06-18 06:06:10.542997
# Unit test for function file_stream
def test_file_stream():
    async def test_file_stream(location, chunk_size, mime_type, headers, filename, chunked, _range):
        if chunked != "deprecated":
            warn(
                "The chunked argument has been deprecated and will be "
                "removed in v21.6"
            )

        headers = headers or {}
        if filename:
            headers.setdefault(
                "Content-Disposition", f'attachment; filename="{filename}"'
            )
        filename = filename or path.split(location)[-1]
        mime_type = mime_type or guess_type(filename)[0] or "text/plain"
        if _range:
            start = _range.start
            end = _range.end
            total = _range.total


# Generated at 2022-06-18 06:06:15.397403
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(b"<html>").content_type == "text/html; charset=utf-8"
    assert html(b"<html>").status == 200



# Generated at 2022-06-18 06:06:22.991459
# Unit test for function file
def test_file():
    async def test_file_async():
        location = "./test_file.txt"
        status = 200
        mime_type = None
        headers = None
        filename = None
        _range = None
        response = await file(location, status, mime_type, headers, filename, _range)
        assert response.status == 200
        assert response.content_type == "text/plain"
        assert response.body == b"test_file"
    test_file_async()



# Generated at 2022-06-18 06:06:27.159303
# Unit test for function html
def test_html():
    assert html("<html>").body == b"<html>"
    assert html(b"<html>").body == b"<html>"
    assert html(b"<html>").content_type == "text/html; charset=utf-8"
    assert html(b"<html>").status == 200
    assert html(b"<html>").headers == {}



# Generated at 2022-06-18 06:06:31.676999
# Unit test for function file_stream
def test_file_stream():
    async def test():
        async with await open_async("test_file_stream.txt", mode="w") as f:
            await f.write("test")
        response = await file_stream("test_file_stream.txt")
        assert response.body == b"test"
        os.remove("test_file_stream.txt")
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())


# Generated at 2022-06-18 06:06:40.783695
# Unit test for method send of class BaseHTTPResponse
def test_BaseHTTPResponse_send():
    from sanic.response import BaseHTTPResponse
    from sanic.http import HttpProtocol
    from sanic.constants import DEFAULT_HTTP_CONTENT_TYPE
    from sanic.cookies import CookieJar
    from sanic.models.protocol_types import HTMLProtocol
    from sanic.helpers import has_message_body, remove_entity_headers
    from sanic.http import Http
    from sanic.models.protocol_types import Range
    from ujson import dumps as json_dumps
    from json import dumps
    from functools import partial
    from unittest.mock import Mock
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import ANY
   