

# Generated at 2022-06-25 17:21:00.830851
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Verify that a TypeError is raised when invalid types of objects
    # are passed
    invalid_type_0 = 1
    assert_raises(TypeError, to_namedtuple, invalid_type_0)
    invalid_type_1 = object()
    assert_raises(TypeError, to_namedtuple, invalid_type_1)
    invalid_type_2 = object()
    assert_raises(TypeError, to_namedtuple, invalid_type_2)
    invalid_type_3 = object()
    assert_raises(TypeError, to_namedtuple, invalid_type_3)
    invalid_type_4 = object()
    assert_raises(TypeError, to_namedtuple, invalid_type_4)
    invalid_type_5 = object()

# Generated at 2022-06-25 17:21:11.276352
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import NamedTuple
    from collections import namedtuple

    class TestClass(NamedTuple):
        a: int = 1
        b: int = 2
        c: int = 3

    dic = {'a': 1, 'b': 2}
    namespace = SimpleNamespace(a=1, b=2, c=3)
    # noinspection PyTypeChecker
    tup = (1, 2, 3)
    # noinspection PyTypeChecker
    out = (1, 2, 3)
    # noinspection PyTypeChecker
    list_0 = [1, 2, 3]
    out_0 = [1, 2, 3]

    nt: NamedTuple = to_namedtuple(dic)
    assert nt == TestClass(**dic)

    nt: Named

# Generated at 2022-06-25 17:21:15.504126
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_dic = [{'a': 1, 'b': 2}]
    actual = to_namedtuple(test_dic)
    target = [NamedTuple(a=1, b=2)]
    assert actual == target, 'should equal'

# Generated at 2022-06-25 17:21:29.625012
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    # noinspection PyUnresolvedReferences
    """Convert a dict to :obj:`NamedTuple <collections.namedtuple>`"""
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from collections import OrderedDict
    from types import SimpleNamespace


# Generated at 2022-06-25 17:21:42.165758
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Unit test for _to_namedtuple
    # test_case_0
    list_0 = None
    assert _to_namedtuple(list_0) is list_0, "Did not return expected value."
    # test_case_1
    list_0 = []
    assert _to_namedtuple(list_0) == list_0, "Did not return expected value."
    # test_case_2
    list_0 = ['a', 1, 'b']
    assert _to_namedtuple(list_0) == list_0, "Did not return expected value."
    # test_case_3
    list_0 = ['a', {'a': 1, 'b': 2}, 'b']

# Generated at 2022-06-25 17:21:54.692840
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    assert to_namedtuple(dic_0) == NamedTuple(a=1, b=2)
    dic_1 = {'a': 1, '_b': 2, 'c': {'a': 1}}
    assert to_namedtuple(dic_1) == NamedTuple(a=1, c=NamedTuple(a=1))
    dict_2 = OrderedDict({'a': 1, 'b': 2})
    assert to_namedtuple(dict_2) == NamedTuple(a=1, b=2)
    list_0 = [1, 2, 3]
    assert to_namedtuple(list_0) == [1, 2, 3]

# Generated at 2022-06-25 17:22:07.916368
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print(test_case_0.__name__)
    try:
        test_case_0()
    except:
        print("FAILED: test_case_0")
    else:
        print("PASSED")
    print()

    list_0 = []
    var_0 = to_namedtuple(list_0)

    # Unit test for function _to_namedtuple
    print(test_case_1.__name__)
    try:
        test_case_1()
    except:
        print("FAILED: test_case_1")
    else:
        print("PASSED")
    print()

    list_1 = [1, 2, 3]
    var_1 = to_namedtuple(list_1)
    list_2 = [1, var_0, 3]
   

# Generated at 2022-06-25 17:22:19.966231
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    ExpectedNamedTuple = namedtuple('ExpectedNamedTuple', 'a b c')

    obj = {'a': 1, 'b': 2, 'c': 3}
    var_0 = to_namedtuple(obj)
    assert isinstance(var_0, ExpectedNamedTuple)
    assert var_0.a == 1
    assert var_0.b == 2
    assert var_0.c == 3

    obj = {'a': 1, 'b': {'a': 1, 'b': 2}, 'c': 3}
    var_1 = to_namedtuple(obj)
    assert isinstance(var_1, ExpectedNamedTuple)
    assert var_1.a == 1

# Generated at 2022-06-25 17:22:30.084140
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test #0
    try:
        test_case_0()
    except TypeError:
        pass
    else:
        assert False

    # Test #1
    list_0 = [
        {'a': {"b": 1}},
        {'a': {"b": NamedTuple(x=1, y=2)}}
    ]
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0, list)
    assert isinstance(var_0[0], NamedTuple)
    assert isinstance(var_0[1], NamedTuple)
    assert not isinstance(var_0[0].a, NamedTuple)
    assert isinstance(var_0[1].a, NamedTuple)

# Generated at 2022-06-25 17:22:42.109548
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case #0
    # In this test case, the list object is null.
    # The result should be a null reference exception.
    try:
        test_case_0()
    except TypeError:
        pass
    except Exception as e:
        raise e

    # Test case #1
    # In this test case, the list contains a 3 character string object.
    # The result should be a named tuple.
    list_1 = ['cat']
    var_1 = to_namedtuple(list_1)
    assert var_1 == ('cat',)

    # Test case #2
    # In this test case, the list contains a 5 character string object.
    # The result should be a named tuple.
    list_2 = ['house']
    var_2 = to_namedtuple(list_2)
    assert var

# Generated at 2022-06-25 17:23:00.612089
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils as utils

    # Test empty dictionary
    dictionary = {}
    namedtuple_0 = utils.to_namedtuple(dictionary)
    assert namedtuple_0 == namedtuple("NamedTuple", "")

    # Test simple dictionary
    dictionary = {"a": 1, "b": 2}
    namedtuple_0 = utils.to_namedtuple(dictionary)
    assert namedtuple_0 == namedtuple("NamedTuple", "a b")(a=1, b=2)

    # Test dictionary with invalid keys
    dictionary = {"1a": 1, "b": 2}
    namedtuple_0 = utils.to_namedtuple(dictionary)

# Generated at 2022-06-25 17:23:03.652967
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_with_list_0()
    test_with_list_1()
    test_with_namedtuple_0()
    test_with_namedtuple_1()
    test_with_tuple_0()
    test_with_tuple_1()



# Generated at 2022-06-25 17:23:16.218800
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    
    list_0 = {
        'a': '1',
        'b': '2',
        'c': '3',
        'd': '4'
    }
    
    try:
        var_0 = to_namedtuple(list_0)
    except Exception:
        var_0 = sys.exc_info()[1]
    assert isinstance(var_0, NamedTuple)
    
    list_1 = {
        'a': '1',
        'b': '2',
        'c': '3',
        'd': '4'
    }
    
    try:
        var_1 = to_namedtuple(list_1)
    except Exception:
        var_1 = sys.exc_info()[1]

# Generated at 2022-06-25 17:23:27.791967
# Unit test for function to_namedtuple
def test_to_namedtuple():

    list_0 = ['a', 1, 2]
    list_1 = to_namedtuple(list_0)
    assert list_0 is not list_1, (
        "to_namedtuple(list) should have returned a new list object"
    )

    tuple_0 = (1, 2, 3)
    tuple_1 = to_namedtuple(tuple_0)
    assert tuple_0 is not tuple_1, (
        "to_namedtuple(tuple) should have returned a new tuple object"
    )

    list_0 = ['a', 1, 2]
    assert len(list_0) == 3, (
        "Length of list_0 should have been 3"
    )

# Generated at 2022-06-25 17:23:33.925589
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    dic = collections.OrderedDict()
    dic[''] = None
    dic['a'] = 1
    dic['b'] = 2
    var_0 = to_namedtuple(dic)

    assert var_0 == NamedTuple(a=1, b=2)

# Generated at 2022-06-25 17:23:41.796779
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    # noinspection PyTypeChecker
    assert to_namedtuple(dic) == nt

    dic = {'a': 1, 'b': 2, '_c': 3, '1': 'test'}
    nt = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    # noinspection PyTypeChecker
    assert to_namedtuple(dic) == nt

    dic = {'c': 3, '1': 'test', 'a': 1, 'b': 2}

# Generated at 2022-06-25 17:23:50.809047
# Unit test for function to_namedtuple
def test_to_namedtuple():
    in_0 = None
    out_0 = None
    assert to_namedtuple(in_0) == out_0

    in_1 = [{'a': 1, 'b': 2}]
    out_1 = [(NamedTuple(a=1, b=2),)]
    assert to_namedtuple(in_1) == out_1

    in_2 = [{'a': 1, '_b': 2}]
    out_2 = [(NamedTuple(a=1, _b=2),)]
    assert to_namedtuple(in_2) == out_2

    in_3 = [{'a': 1, '1b': 2}]
    out_3 = [(NamedTuple(a=1, _b=2),)]

# Generated at 2022-06-25 17:23:57.398385
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection SpellCheckingInspection
    list_0 = [{'a': 1, 'b': 2, '_c': 3}, {'c': 6, 'd': 7}, {'g': 9}]
    # noinspection SpellCheckingInspection
    list_1 = [{'a': 1, 'b': 2}, {'c': 6, 'd': 7, 'f': 8}, {'g': 9}]
    list_2 = [{'a': 1, 'b': 2}, {'c': 6, 'd': 7}, {'g': 9}]
    list_3 = [{'a': 1, 'b': 2}, {'c': 6, 'd': 7}, {'g': 9}]

    # noinspection PyTypeChecker
    tuple_0: NamedTuple = to_named

# Generated at 2022-06-25 17:24:05.241809
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Var 0
    lst_0: List[Dict] = [
        {'a': 1, 'b': 2},
        {'a': 0, 'c': 3},
        {'a': 1, 'b': 3, 'c': 2}
    ]
    lst_1: List[Dict] = [
        {'a': 1, 'b': 2},
        {'a': 0, 'c': 3},
        {'a': 1, 'b': 3, 'c': 2}
    ]
    var_0 = to_namedtuple(lst_0)
    for item in var_0:
        assert item == lst_1.pop(0)
        assert isinstance(item, NamedTuple)
    # Var 1

# Generated at 2022-06-25 17:24:13.345537
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [
        [
            'a',
            {
                'A': 'A'
            },
            1,
            None,
            True
        ]
    ]
    var_0 = to_namedtuple(list_0)
    assert(var_0 == [NamedTuple(a='A', A='A', _1=1, _2=None, _3=True)])
    list_1 = []
    var_1 = to_namedtuple(list_1)
    assert(var_1 == [])
    list_2 = [
        {
            'A': 'A',
            'a': 'a'
        }
    ]
    var_2 = to_namedtuple(list_2)

# Generated at 2022-06-25 17:24:36.129869
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection SpellCheckingInspection
    list_0 = [1, 2, 3]
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0, list)
    assert len(var_0) == 3

    # noinspection SpellCheckingInspection
    list_1 = [1, 2, 3, {'a': 1, 'b': 2}]
    var_1 = to_namedtuple(list_1)
    assert isinstance(var_1, list)
    assert len(var_1) == 4
    assert isinstance(var_1[3], NamedTuple)

    # noinspection SpellCheckingInspection
    tuple_0 = (1, 2, 3)
    var_2 = to_namedtuple(tuple_0)
    assert isinstance

# Generated at 2022-06-25 17:24:38.851248
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:24:45.550728
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test for function to_namedtuple
    """
    list_0 = [None]
    var_0 = to_namedtuple(list_0)
    list_1 = ['Lorem ipsum', (None,), {'AAA': 1, 'BBB': None}, [None], SimpleNamespace(
        a=1, b=2, c={3: 4, 5: 6}), SimpleNamespace(a=1), SimpleNamespace(a=1), SimpleNamespace(
            a=1), SimpleNamespace(a=1), SimpleNamespace(a=1), SimpleNamespace(
                a=1), SimpleNamespace(a=1), SimpleNamespace(a=1), SimpleNamespace(
                    a=1), SimpleNamespace(a=1), SimpleNamespace(a=1)]
    var_1 = to

# Generated at 2022-06-25 17:24:52.227789
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [{'z': 3}, {'v':8}]
    namedtuple_0 = to_namedtuple(list_0)
    assert namedtuple_0[0].z == 3
    print("Unit test for function to_namedtuple is passed!")

test_case_0()
test_to_namedtuple()

# Generated at 2022-06-25 17:25:02.208819
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    var_0 = to_namedtuple(list_0[0])
    # check if var_0 makes a correct namedtuple
    assert var_0.a == 1
    assert var_0.b == 2
    # check if var_0 is a namedtuple
    assert isinstance(var_0, NamedTuple)

    # check the original list_0
    assert list_0[0]['a'] == 1
    assert list_0[0]['b'] == 2
    assert list_0[1]['a'] == 3
    assert list_0[1]['b'] == 4
    assert isinstance(list_0[0], dict)

# Generated at 2022-06-25 17:25:08.895627
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import choice, randint
    from string import (
        ascii_letters,
        digits,
    )
    from unittest import TestCase
    from flutils.namedtupleutils import to_namedtuple
    choices = ascii_letters + digits
    rand_str = lambda: ''.join(
        [choice(choices) for _ in range(randint(1, 20))]
    )

    def get_random_list(_list: List[Any], depth: int = 0) -> List[Any]:
        depth -= 1
        _list.append(rand_str())
        if depth != 0:
            _list.append(get_random_list([], depth))
        return _list

    class _TestCase(TestCase):
        def test_case_0(self):
            list_0 = None

# Generated at 2022-06-25 17:25:13.329649
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Test to_namedtuple'''
    assert True


if __name__ == '__main__':
    test_case_0()
    test_to_namedtuple()

# Generated at 2022-06-25 17:25:23.603348
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Setup
    tup = ('abc', ('abc', 'xyz'), [('abc', 'xyz')])
    exp = to_namedtuple(tup)

    # Test
    list_0 = None
    var_0 = to_namedtuple(list_0)
    dic_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dic_0)
    dic_0 = OrderedDict()
    dic_0['a'] = 1
    dic_0['b'] = 2
    var_0 = to_namedtuple(dic_0)
    list_0 = [('abc', 1), ('xyz', 2)]
    var_0 = to_namedtuple(list_0)
    obj_0 = SimpleNamespace()
   

# Generated at 2022-06-25 17:25:28.898142
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(list_0)
    assert var_0 == {'a': 1, 'b': 2}

# Generated at 2022-06-25 17:25:40.077847
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.x = SimpleNamespace(a=1, b=2, c=3)

        def tearDown(self):
            del self.x

        def test_case_0(self):
            x = {'a': 1, 'b': 2}
            var_0 = to_namedtuple(x)
            self.assertEqual(var_0.a, 1)
            self.assertEqual(var_0.b, 2)

        def test_case_1(self):
            x = {'a': 1, 'b': 2, 'c': 3}
            var_0 = to_namedtuple(x)
            self.assertEqual(var_0.a, 1)

# Generated at 2022-06-25 17:26:08.159715
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = OrderedDict()
    dic_0[0] = 'a'
    dic_0[1] = 1
    dic_0[2] = [2, 3, 4]
    dic_0[3] = {5: [6, 7, 8]}
    dic_0[4] = (4, 5, 6)

    var_0 = to_namedtuple(dic_0)

    assert var_0._fields == (0, 1, 2, 3, 4)
    assert var_0.a == 1
    assert var_0.b == (2, 3, 4)
    assert var_0.c.d == (6, 7, 8)
    assert var_0.e == (4, 5, 6)



# Generated at 2022-06-25 17:26:16.515057
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3
        }
    }
    named = to_namedtuple(dic)
    assert named.b.c == 2

    out: NamedTuple = namedtuple('NamedTuple', ['a', 'b'])
    assert named.b == out(c=2, d=3)


# Generated at 2022-06-25 17:26:27.164970
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import (
        to_namedtuple,
        _to_namedtuple,
    )
    from types import SimpleNamespace

    dic_0 = {'a': 1, 'b': 2, 'c': 3}
    dic_0_out = to_namedtuple(dic_0)
    assert isinstance(dic_0_out, namedtuple)
    assert len(dic_0_out) == 3

    dic_1 = {'a': 1, 'b': 2, 'c': 3}
    dic_1_out = to_namedtuple(dic_1)
    assert isinstance(dic_1_out, namedtuple)
    assert len(dic_1_out) == 3

    d

# Generated at 2022-06-25 17:26:36.398625
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = dict(a=1, b=2)
    n = to_namedtuple(d)
    assert n.a == 1
    assert n.b == 2

    od = OrderedDict([('c', 3), ('d', 4), ('a', 1), ('b', 2)])
    n = to_namedtuple(od)
    assert n.c == 3
    assert n.d == 4
    assert n.a == 1
    assert n.b == 2

    sn = SimpleNamespace(e=5, f=6, a=1, b=2)
    n = to_namedtuple(sn)
    assert n.e == 5
    assert n.f == 6
    assert n.a == 1
    assert n.b == 2

    list_0 = None
    var_0 = to_named

# Generated at 2022-06-25 17:26:47.388743
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test function :func:`to_namedtuple`.

    """
    my_list = (
        {"a": 1, "b": 2},
        {"a": 3, "b": {"c": 4, "d": 5}},
    )
    res = to_namedtuple(my_list)
    assert res[0] == NamedTuple(a=1, b=2)
    assert res[1] == NamedTuple(a=3, b=NamedTuple(c=4, d=5))
    my_list = (
        {'a': 1, 'b': 2, 'c': 3},
        {'a': 4, 'b': 5, 'c': 6},
    )
    res = to_namedtuple(my_list)

# Generated at 2022-06-25 17:26:48.883209
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:27:01.581994
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Setup

    thing_0 = dict(a=1)
    thing_1 = dict(a=[1, 2, 3], b=[1, 2], c=dict(d=1, e=2))
    thing_2 = NamedTuple('Thing', a=1)
    thing_3 = SimpleNamespace(a=1, b=2)
    thing_4 = SimpleNamespace(a='b')
    thing_5 = OrderedDict([('z', 1), ('a', 2), ('b', 3)])
    thing_6 = OrderedDict([('a', SimpleNamespace(b=1))])
    thing_7 = [1, 2]
    thing_8 = tuple(thing_7)
    thing_9 = [1, 2, [1, 2, 3]]

# Generated at 2022-06-25 17:27:03.570688
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    the_module = sys.modules[__name__]
    the_module.test_case_0()

# Generated at 2022-06-25 17:27:15.163806
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Tests the function ``to_namedtuple`` from the module ``namedtupleutils.py``."""

    TestData = namedtuple('TestData', ['input', 'expected_result'])


# Generated at 2022-06-25 17:27:24.973913
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:28:11.242524
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    import json
    import sys

    EXIT_CODE = 0

    # Order Matters
    OrderedDict({
        'b': 2,
        'a': 1,
    })

    # A NamedTuple cannot be mutable
    my_dict = OrderedDict([
        ('c', 3),
        ('b', 2),
        ('a', 1),
    ])
    named_tuple = to_namedtuple(my_dict)
    named_tuple.a = 4
    my_dict['a'] = 4
    assert named_tuple.a != my_dict['a']

    # Unordered dict

# Generated at 2022-06-25 17:28:22.950966
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    # Test for bad calls
    with pytest.raises(TypeError):
        test_case_0()

    # Test for good calls
    assert to_namedtuple('abc') == 'abc'
    assert (
        to_namedtuple(
            {'a': 1, 'b': 2, '__c': 3}
        ) ==
        namedtuple('NamedTuple', 'a b')(a=1, b=2)
    )

# Generated at 2022-06-25 17:28:33.779766
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.ordered_utils import convert_dict
    from flutils.stringutils import is_identifier
    from flutils.testutils import RandomStr
    from flutils.typed_utils import is_typed_dict

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    dic_0 = {'a': 1, 'b': 2}
    nt_0 = to_namedtuple(dic_0)
    assert isinstance(nt_0, namedtuple)
    assert nt_0.a == 1
    assert nt_0.b == 2
    dic_1 = {'a': 1, 'b': [1, 2], 'd': dict(a=1, b=2)}

# Generated at 2022-06-25 17:28:40.286856
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print("\nStarting unit test for to_namedtuple().")
    print("  If assertion errors occur, the function fails.")
    try:
        test_case_0()
    except AssertionError as e:
        print("\n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        print("An assertion error has ocurred.")
        print("Assertion message:  {}".format(e))
        print("Aborting tests.")
        print("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%")
        return

    print("\nFinished unit test successfully.")
    return


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:28:50.583075
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test function:
    list_0 = [{'a': 1}, {'b': 2}]
    list_1 = to_namedtuple(list_0)
    assert isinstance(list_1, list)
    assert str(list_1) == "[NamedTuple(a=1), NamedTuple(b=2)]"
    dict_0 = {'a': 1, 'b': 2}
    dict_1 = to_namedtuple(dict_0)
    assert str(dict_1) == "NamedTuple(a=1, b=2)"
    dict_2 = OrderedDict({'a': 1, 'b': 2})
    dict_3 = to_namedtuple(dict_2)

# Generated at 2022-06-25 17:28:58.843786
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = ['a', 'b', 'c']
    list_1 = ['d', 'e']
    list_2 = [list_1, 'f']
    list_3 = []
    list_4 = [list_0, list_1, list_2, list_3]
    dict_0 = {'a': 1, 'b': 2, 'c': 3}
    dict_1 = {'d': 1, 'e': 2, 'f': 3}
    dict_2 = {'g': dict_1, 'h': dict_0}
    dict_3 = OrderedDict()
    dict_4 = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
    ])

# Generated at 2022-06-25 17:29:06.844895
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_1 = {'a': 6, 'b': 3, 'c': 2, 'd': 4, 'e': 1, 'f': 5}
    namedtuple_1 = to_namedtuple(dict_1)
    assert namedtuple_1.a == 6
    assert namedtuple_1.b == 3
    assert namedtuple_1.c == 2
    assert namedtuple_1.d == 4
    assert namedtuple_1.e == 1
    assert namedtuple_1.f == 5



# Generated at 2022-06-25 17:29:12.613617
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = ['a',1]
    var_0 = to_namedtuple(list_0)
    assert var_0 == NamedTuple(a='a', b=1)
    dict_0 = {'a':1,'b':2}
    var_1 = to_namedtuple(dict_0)
    assert var_1 == NamedTuple(a=1, b=2)


# Generated at 2022-06-25 17:29:24.151720
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = ['b', 'c', 'a']
    var_0 = to_namedtuple(list_0)
    assert var_0 == [
        'b', 'c', 'a'
    ]
    dic_0 = OrderedDict()
    dic_0['c'] = 'd'
    dic_0['a'] = 'b'
    var_1 = to_namedtuple(dic_0)
    assert var_1 == (
        'b', 'd'
    )
    list_1 = ['b', 'c', 'a']
    var_2 = to_namedtuple(list_1)
    assert var_2 == [
        'b', 'c', 'a'
    ]
    assert type(var_2) == list

# Generated at 2022-06-25 17:29:32.189507
# Unit test for function to_namedtuple
def test_to_namedtuple():
    validator_0: List[str] = []
    list_0: List[str] = []
    list_1: List[str] = validator_0
    list_1 = to_namedtuple(list_0)
    var_0: Tuple[int, ...] = tuple()
    list_2: Tuple[int, ...] = var_0
    list_2 = to_namedtuple(list_2)
    dict_0: dict = dict()
    dict_1: dict = dict()
    dict_1 = to_namedtuple(dict_0)
    dict_2: list = list()
    dict_2 = to_namedtuple(dict_2)
    dict_3: str = str()
    dict_3 = to_namedtuple(dict_3)
    dict_4: T