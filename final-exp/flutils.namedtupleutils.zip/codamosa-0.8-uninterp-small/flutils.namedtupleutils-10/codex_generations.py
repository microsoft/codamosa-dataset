

# Generated at 2022-06-25 17:20:56.857058
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert callable(to_namedtuple)
    test_case_0()
    assert True
# EOF

# Generated at 2022-06-25 17:21:00.599745
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert 1 + 1 == 2

# Coverage test
if __name__ == '__main__':
    test_to_namedtuple()
    test_case_0()

# Generated at 2022-06-25 17:21:02.738057
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert False

# Module level fixture for function to_namedtuple

# Generated at 2022-06-25 17:21:03.293303
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-25 17:21:13.478742
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections

    dic_0 = {'a': 1, 'b': 2}
    mapped_0 = to_namedtuple(dic_0)
    assert mapped_0 == collections.namedtuple('NamedTuple', 'a b')(1, 2)

    dic_1 = {'a': 1, 'b': 2, 'c': 3}
    mapped_1 = to_namedtuple(dic_1)
    assert mapped_1 == collections.namedtuple('NamedTuple', 'a b c')(1, 2, 3)

    dic_2 = OrderedDict()
    dic_2['a'] = 1
    dic_2['b'] = 2
    dic_2['c'] = 3
    mapped_2 = to_namedtuple(dic_2)
   

# Generated at 2022-06-25 17:21:19.799258
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Test:', 'test_to_namedtuple')
    from pprint import pprint
    from random import random
    from fractions import Fraction
    rand_int = lambda: int(random() * 10)
    rand_frac = lambda: Fraction(random())
    dct = dict(a=rand_int())
    nt = to_namedtuple(dct)
    pprint(nt)
    assert nt.a == dct['a']
    lst = [rand_int(), rand_frac(), rand_int(), rand_frac()]
    x = to_namedtuple(lst)
    pprint(x)
    assert isinstance(x, list)
    assert all(isinstance(y, Fraction) for y in x[1::2])

# Generated at 2022-06-25 17:21:27.346170
# Unit test for function to_namedtuple
def test_to_namedtuple():
    mapping_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(mapping_0)
    

if __name__ == '__main__':
    # Note: Only using unittest.main so that command line parameters can
    #       be used to specify a testing directory.
    #       See: https://stackoverflow.com/a/29629751/1142250
    unittest.main()

# Generated at 2022-06-25 17:21:33.751566
# Unit test for function to_namedtuple
def test_to_namedtuple():
    global dict_0
    dict_0 = dict(a=1, b=2)
    var_0 = to_namedtuple(dict_0)
    assert var_0.a == 1


if __name__ == '__main__':
    test_case_0()
    test_to_namedtuple()

# Generated at 2022-06-25 17:21:43.400302
# Unit test for function to_namedtuple
def test_to_namedtuple():
    foo = namedtuple('foo', 'a b c d e')
    assert to_namedtuple({'a': 1, 'b': 2}) == foo(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == foo(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3, 'C': 4}) == foo(a=1, b=2, C=4)
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3, 'C': 4, 'c': 5}) == foo(a=1, b=2, C=4, c=5)

# Generated at 2022-06-25 17:21:50.811331
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'_a': 1, 'b': 2}) == NamedTuple(b=2)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

# Generated at 2022-06-25 17:22:11.273302
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    from flutils.datetimeutils import make_datetime
    from typing import Dict, List

    lst: List[Dict] = [
        {
            'id': 0,
            'name': 'a name',
            'date_time': make_datetime('2000-01-01 00:00:00'),
            'list': [1, 2, 3],
        },
        {
            'id': 1,
            'date_time': make_datetime('2000-01-01 00:00:00'),
            'list': [1, 2, 3],
        },
    ]

    lst_nt: List[NamedTuple] = to_namedtuple(lst)

    assert isinstance(lst_nt, list)
    assert len(lst_nt) == 2

# Generated at 2022-06-25 17:22:25.089640
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({"a": 1, "b": 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({1: 2}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2, '1': 3}) == NamedTuple(a=1, b=2)

    assert to_namedtuple(OrderedDict([("a", 1), ("b", 2)])) == \
        NamedTuple(a=1, b=2)

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(tuple([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-25 17:22:32.495912
# Unit test for function to_namedtuple
def test_to_namedtuple():
    out = to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(out, NamedTuple)
    assert out.a == 1 and out.b == 2
    value = dict(a=1, b=2)
    out = to_namedtuple(value)
    assert isinstance(out, NamedTuple)
    assert out.a == 1 and out.b == 2
    value = OrderedDict(b=2, a=1)
    out = to_namedtuple(value)
    assert isinstance(out, NamedTuple)
    assert out == (1, 2)
    value = SimpleNamespace(a=1, b=2)
    out = to_namedtuple(value)
    assert isinstance(out, NamedTuple)
    assert out == (1, 2)

# Generated at 2022-06-25 17:22:44.806591
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Fail - TypeError: Can convert only 'list', 'tuple', 'dict' to a
    # NamedTuple; got: (NoneType) None
    test_case_0()

    tuple_1 = namedtuple('tuple_1', ('a', 'b', 'c'))(1, 2, 3)
    var_1 = to_namedtuple(tuple_1)
    try:
        assert var_1 == tuple_1
    except AssertionError:
        print('AssertionError raised with namedtuple.  Expected: %s, '
              'Got: %s' % (tuple_1, var_1))

    tuple_2 = (1, 2, 3, 4, 5)
    var_2 = to_namedtuple(tuple_2)

# Generated at 2022-06-25 17:23:01.247490
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert type(dic).__name__ == 'dict'
    with pytest.raises(TypeError) as exception_info:
        # noinspection PyTypeChecker
        to_namedtuple(dic)
    assert 'got: (%r) %s' % (type(dic).__name__, dic) in str(
        exception_info.value
    )
    orig_lst = ['a', 1, 'b', 2]
    lst = ['a', 1, 'b', 2]
    assert type(lst).__name__ == 'list'
    with pytest.raises(TypeError) as exception_info:
        # noinspection PyTypeChecker
        to_namedtuple(lst)

# Generated at 2022-06-25 17:23:07.456859
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from random import choice
    from string import printable

    def _generate_random_identifier() -> str:
        if choice([True, False]):
            return ''.join(choice(printable) for _ in range(10))
        return ''.join(
            choice((printable + ' ').replace('\t', '')) for _ in range(10)
        )

    def _assert_state(
            obj: Any,
            out: Any,
            depth: int = 0
    ) -> None:
        # noinspection PyProtectedMember
        obj_fields = tuple(obj._fields)
        # noinspection PyProtectedMember
        out_fields = tuple(out._fields)
        assert out_fields == obj_fields


# Generated at 2022-06-25 17:23:20.872199
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': {'c_a': 3, 'c_b': 4}}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=NamedTuple(c_a=3, c_b=4))

    dic = {'a': 1, 'b': 2, 'c': {'c_a': 3, 'c_b': 4}, 'd': {'d_a': 5, 'd_b': 6}}

# Generated at 2022-06-25 17:23:21.785148
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:23:26.545992
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Get parameters for test
    params: List[Any] = [
    ]
    # Perform the test
    result: Any = to_namedtuple(*params)
    # Verify the results
    assert result is None


if __name__ == "__main__":
    # noinspection PyTypeChecker
    test_to_namedtuple()

# Generated at 2022-06-25 17:23:34.830126
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from copy import deepcopy
    from types import SimpleNamespace

    class _Test(NamedTuple):
        var_0: str
        var_1: int
        var_2: str
        var_3: List[int]
        var_4: int
        var_5: str
        var_6: str
        var_7: List[int]
        var_8: int
        var_9: str
        var_10: List[int]
        var_11: int
        var_12: str
        var_13: str
        var_14: List[int]
        var_15: int
        var_16: str
        var_17: int
        var_18: str
        var_19: str
        var_20: List[int]
        var

# Generated at 2022-06-25 17:23:49.777283
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [1, 2, (3, {4: 5})]
    list_1 = to_namedtuple(list_0)
    assert list_1 == [1, 2, (3, NamedTuple(**{'4': 5}))]
    tuple_0 = (1, 2, [3, {4: 5, 6: 7}])
    tuple_1 = to_namedtuple(tuple_0)
    assert tuple_1 == (1, 2, [3, NamedTuple(**{'4': 5, '6': 7})])
    dict_0 = {'a': 1, 'b': 2}
    dict_1 = to_namedtuple(dict_0)
    assert dict_1 == NamedTuple(**{'a': 1, 'b': 2})

# Generated at 2022-06-25 17:24:00.075044
# Unit test for function to_namedtuple
def test_to_namedtuple():
    item = SimpleNamespace(
        a0=0,
        b1=1,
        x=None,
        y=None,
        z=None,
    )
    dic = {
        '1a': 1,  # 1
        'b': 2,
        'c': 3,
        'a2': 4,  # 2
        '_d': 5,
        'e_': 6,
        '_f_': 7,
        'g__': 8,
        'ab_a0': 'a',
        'ab_a1': 'b',
        'ab_a2': 'c',
        'ab_a3': 'd',
    }
    dic.update(item.__dict__)
    dic.update(item.__dict__)

# Generated at 2022-06-25 17:24:11.393540
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 'b', 'c': {'d': {'e': 'e'}}}) == \
        NamedTuple(a=1, b='b', c=NamedTuple(d=NamedTuple(e='e')))
    assert to_namedtuple(
        OrderedDict([('d', 2), ('e', 'e'), ('f', {'g': 3})]),
    ) == \
        NamedTuple(d=2, e='e', f=NamedTuple(g=3))
    assert to_namedtuple([{'a': 1, 'b': 2}, 23]) == \
        [NamedTuple(a=1, b=2), 23]

# Generated at 2022-06-25 17:24:21.493097
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import logging
    import sys
    import unittest

    class ToNamedtupleTestCase(unittest.TestCase):

        def setUp(self):
            logging.basicConfig(
                stream=sys.stderr,
                level=logging.DEBUG,
            )
            self.logger = logging.getLogger(__name__)
            self.logger.debug('******************** TEST STARTED ********************')

        def tearDown(self):
            self.logger.debug('******************** TEST ENDED **********************')

        def test_to_namedtuple_case_0(self):
            tuple_0 = 1
            var_0 = to_namedtuple(tuple_0)
            self.assertEqual(var_0, None)


# Generated at 2022-06-25 17:24:23.395930
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert False

# Generated at 2022-06-25 17:24:36.893614
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert repr(to_namedtuple({'a': {'b': 1}})) \
        == 'NamedTuple(a=NamedTuple(b=1))'
    assert repr(to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))) \
        == 'NamedTuple(a=1, b=2)'
    assert repr(to_namedtuple([{'a': 1}, {'b': 2}])) \
        == '[NamedTuple(a=1), NamedTuple(b=2)]'
    assert repr(to_namedtuple(('a', 'b'))) \
        == "('a', 'b')"

# Generated at 2022-06-25 17:24:44.954882
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from copy import copy
    from typing import Any, Dict, Union
    from collections import OrderedDict
    from types import SimpleNamespace

    class MyClass:
        v: Any

        def __init__(self, v: Any):
            self.v = v

    # end class MyClass

    dic: Dict[str, Union[int, str, MyClass]] = {'a': 1, 'b': '2'}
    dic['c'] = MyClass(3)

    named_tuple_0 = to_namedtuple(dic)
    named_tuple_1 = to_namedtuple(OrderedDict(dic))
    named_tuple_2 = to_namedtuple(
        SimpleNamespace(**dic)
    )

    lst = [1, 2, '3']

# Generated at 2022-06-25 17:24:57.989829
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = {'a': 1, 'b': 2}
    expected_0 = NamedTuple(a=1, b=2)
    actual_0: Any = to_namedtuple(tuple_0)
    assert actual_0 == expected_0

    tuple_1 = {'b': 2, 'a': 1}
    expected_1 = NamedTuple(a=1, b=2)
    actual_1: Any = to_namedtuple(tuple_1)
    assert actual_1 == expected_1

    tuple_2 = {'b': 2, 'a': {'c': 3, 'd': 4}}
    expected_2 = NamedTuple(b=2, a=NamedTuple(c=3, d=4))

# Generated at 2022-06-25 17:25:04.935378
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = OrderedDict(a=1, b=2, _c=3, d_=4)
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple) is True
    assert out == NamedTuple(a=1, b=2, d_=4)

    obj = {'a': 1, 'b': 2, '_c': 3, 'd_': 4}
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple) is True
    assert out == NamedTuple(a=1, b=2, d_=4)

    obj = ('a', 1, 'b', 2, '_c', 3, 'd_', 4)
    out = to_namedtuple(obj)

# Generated at 2022-06-25 17:25:15.806425
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert tuple(to_namedtuple('Hi')._fields) == ('H', 'i')
    assert tuple(to_namedtuple([])._fields) == ()
    assert tuple(to_namedtuple({'a': 1, 'b': 2})._fields) == ('a', 'b')
    assert tuple(to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))._fields) \
           == ('a', 'b')
    assert tuple(to_namedtuple((1, 2))._fields) == ('_1', '_2')
    assert tuple(to_namedtuple([1, 2])._fields) == ('_1', '_2')
    obj = (1, 2)
    inner = to_namedtuple(obj)

# Generated at 2022-06-25 17:25:27.154231
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = [['b', 'c', 'a'], ['e', 'f', 'd'], {'g': 1, 'h': 2, 'i': 3}]
    expected_0 = [['b', 'c', 'a'], ['e', 'f', 'd'], namedtuple('NamedTuple', ['g', 'h', 'i'])(1, 2, 3)]
    actual_0 = to_namedtuple(tuple_0)
    assert actual_0 == expected_0

    tuple_1 = [['b', 'c', 'a'], 'a', {'g': 1, 'h': 2, 'i': 3}]

# Generated at 2022-06-25 17:25:31.650446
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Argument 'obj' is None
    tuple_0 = None
    var_0 = to_namedtuple(tuple_0)
    assert var_0 is tuple_0

    # Argument 'obj' is of type 'dict'
    tuple_1 = {'a': 1, 'b': 2}
    var_1 = to_namedtuple(tuple_1)
    assert isinstance(var_1, NamedTuple)
    assert(hasattr(var_1, 'a') and hasattr(var_1, 'b'))
    assert(var_1.a == 1 and var_1.b == 2)
    assert(var_1[0] == 1 and var_1[1] == 2)

    # Argument 'obj' is of type 'ordered dict'

# Generated at 2022-06-25 17:25:41.345331
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple({}), NamedTuple)
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), NamedTuple)
    assert isinstance(to_namedtuple({'name': 'test'}), NamedTuple)
    assert isinstance(to_namedtuple([1, 2, 3]), list)
    assert isinstance(to_namedtuple([1, 2, {'a': 1}]), list)
    assert isinstance(to_namedtuple((1, 2, 3)), tuple)
    assert isinstance(to_namedtuple((1, 2, {'a': 1})), tuple)
    assert str(to_namedtuple({'a': 1})) == 'NamedTuple(a=1)'

# Generated at 2022-06-25 17:25:52.489666
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import Dict, List, Union
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from flutils.validators import validate_identifier

    # type: Union[OrderedDict, Dict, List]

# Generated at 2022-06-25 17:26:02.896202
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = None
    var_0 = to_namedtuple(tuple_0)

    tuple_1 = (
        ("name", "Olga"),
        ("age", 31),
        ("sex", "female")
    )
    var_1 = to_namedtuple(tuple_1)

    tuple_2 = {
        "a": 1,
        "b": 2
    }
    var_2 = to_namedtuple(tuple_2)

    tuple_3 = {
        "a": 1,
        "b": 2
    }
    var_3 = to_namedtuple(tuple_3)

    tuple_4 = {
        "a": 1,
        "b": 2
    }
    var_4 = to_namedtuple(tuple_4)

    tuple_5

# Generated at 2022-06-25 17:26:05.069615
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Write code to test function to_namedtuple here
    return


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:26:13.415864
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from flutils.testutils import regular_func_test
    from typing import List, Tuple

    obj = {'a': 1, 'b': 2}
    obj2 = {'a': 1, 'b': 2, 'c': 3}
    obj3 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    ntup = namedtuple('NamedTuple', ['a', 'b'])
    ntup2 = namedtuple('NamedTuple', ['a', 'b', 'c'])
    ntup3 = namedtuple('NamedTuple', ['a', 'b', 'c', 'd'])


# Generated at 2022-06-25 17:26:18.095022
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    tuple_0 = to_namedtuple(dic)
    assert tuple_0
    assert len(tuple_0) == 2
    assert tuple_0.a == 1
    assert tuple_0.b == 2


# Generated at 2022-06-25 17:26:28.876785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from typing import (
        List,
        NamedTuple,
        Tuple,
        Union,
    )

    dic: OrderedDict = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2

    test_0 = to_namedtuple(dic)
    assert test_0.a == 1
    assert test_0.b == 2

    test_1 = to_namedtuple(list(dic.keys()))

    assert test_0 is not test_1
    test_2 = to_namedtuple(test_0)
    assert test_0 is not test_2
    test_3 = to_namedtuple(tuple(test_0))
    assert test_

# Generated at 2022-06-25 17:26:37.143290
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Case 0
    try:
        tuple_0 = None
        var_0 = to_namedtuple(tuple_0)
    except TypeError:
        pass
    else:
        assert False

    # Case 1
    try:
        tuple_0 = ''
        var_0 = to_namedtuple(tuple_0)
    except TypeError:
        pass
    else:
        assert False

    # Case 2
    try:
        tuple_0 = 0
        var_0 = to_namedtuple(tuple_0)
    except TypeError:
        pass
    else:
        assert False

    # Case 3
    try:
        tuple_0 = []
        var_0 = to_namedtuple(tuple_0)
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-25 17:26:51.980917
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import List
    from types import SimpleNamespace
    from collections import namedtuple, OrderedDict
    from itertools import product


# Generated at 2022-06-25 17:27:03.549138
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections.abc import Mapping
    from collections import OrderedDict
    from types import SimpleNamespace
    import unittest

    DictTuple = namedtuple('DictTuple', ['a', 'b'])

    class Example(Mapping):
        def __init__(self, dic: OrderedDict):
            self.dic = dic

        def __getitem__(self, item):
            return self.dic[item]

        def __iter__(self):
            return iter(self.dic)

        def __len__(self):
            return len(self.dic)


# Generated at 2022-06-25 17:27:15.175767
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({1: 'a'}) == NamedTuple(a=1)
    assert to_namedtuple({2: 'b', 1: 'a'}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({1: 'a', 2: 'b'}) == NamedTuple(a=1, b=2)
    assert to_namedtuple

# Generated at 2022-06-25 17:27:16.054248
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True


# Generated at 2022-06-25 17:27:25.698920
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest


# Generated at 2022-06-25 17:27:33.405050
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # first test ommit
    tuple_0 = None
    with pytest.raises(TypeError):
        var_0 = to_namedtuple(tuple_0)

    # second test:
    tuple_1 = {'a': 1, 'b': 2}
    var_1 = to_namedtuple(tuple_1)
    assert isinstance(var_1, namedtuple)
    assert var_1.a == 1
    assert var_1.b == 2



# Generated at 2022-06-25 17:27:43.724278
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data: List[Tuple[str, str]] = [
        (
            "to_namedtuple(None)",
            """
            TypeError: Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (%r) None
            """
        ),
    ]
    for test_case, expected in data:
        with pytest.raises(Exception) as actual:
            eval(test_case)
        expected = textwrap.dedent(expected.strip('\n'))
        assert expected == str(actual.value), (test_case, expected, str(actual.value))

    pytest.main([__file__])

# Generated at 2022-06-25 17:27:52.824871
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections.abc import Sequence
    from types import SimpleNamespace
    from typing import Mapping as Mapping_T
    from typing import Sequence as Sequence_T

    # Setup fixtures:
    test_cases = OrderedDict()
    test_cases[0] = (
        None,
        TypeError,
        "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
        "got: (%r) %s",
    )
    test_cases[1] = (
        [{'a': 1}, {'b': 2}],
        [NamedTuple(a=1), NamedTuple(b=2)],
    )

# Generated at 2022-06-25 17:28:04.606944
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import randint, random
    from flutils.namedtupleutils import to_namedtuple
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from datetime import date
    from cattr import (
        register_unstructure_hook,
    )
    from typing import Dict, List, Tuple
    from datetime import date as _date
    from typing import NamedTuple as _NamedTuple
    from typing import NewType

    register_unstructure_hook(_date, lambda x: x.isoformat())

    def _to_namedtuple(
            obj: Any
    ) -> Union[OrderedDict, namedtuple]:
        if isinstance(obj, OrderedDict):
            keys = tuple(sorted(obj.keys()))
            args = []


# Generated at 2022-06-25 17:28:12.702968
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils
    import pytest
    with pytest.raises(TypeError):
        flutils.namedtupleutils.to_namedtuple(None)

    expected_output = (None,)
    assert expected_output == flutils.namedtupleutils.to_namedtuple(
        (None,)
    )

    expected_output = (1, 2, 3)
    assert expected_output == flutils.namedtupleutils.to_namedtuple(
        (1, 2, 3)
    )

    expected_output = ('a', 'b', 'c')
    assert expected_output == flutils.namedtupleutils.to_namedtuple(
        ('a', 'b', 'c')
    )

    expected_output = ['a', 'b', 'c']
    assert expected_output

# Generated at 2022-06-25 17:28:31.013021
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import io

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.out = io.StringIO()  # type: io.StringIO
            self.err = io.StringIO()  # type: io.StringIO

        def tearDown(self):
            self.out.close()
            self.err.close()

        def test_case_0(self):
            tuple_0 = None
            var_0 = to_namedtuple(tuple_0)

        def test_case_1(self):
            tuple_0 = 1
            var_0 = to_namedtuple(tuple_0)

        def test_case_2(self):
            tuple_0 = True
            var_0 = to_namedtuple

# Generated at 2022-06-25 17:28:39.313299
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Getting the view of the current directory
    current_directory = os.getcwd()
    # Confirming that the current working directory is the example directory
    assert current_directory.endswith('/flutils/tests/namedtupleutils')
    # Getting the sample data
    # noinspection PyPackageRequirements
    with open('json_sample.json', 'r') as sample:
        # Reading the sample data
        sample_data = json.load(sample)
        # Transforming sample data into a namedtuple
        json_namedtuple = to_namedtuple(sample_data)
        # Checking that the sample data has been transformed into a namedtuple
        assert isinstance(json_namedtuple, NamedTuple)
        # Checking that the namedtuple has all the appropriate keys

# Generated at 2022-06-25 17:28:49.934039
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        def test_to_namedtuple_none(self):
            tuple_0 = None
            var_0 = to_namedtuple(tuple_0)
            self.assertIsNone(var_0)

        def test_to_namedtuple(self):
            tuple_0 = {'a': {'B': 4, 'c': 4}, 'b': 2, 'C': 3}
            var_0 = to_namedtuple(tuple_0)
            self.assertIs(var_0.__class__.__name__, 'NamedTuple')
            self.assertIs(type(var_0), namedtuple)

# Generated at 2022-06-25 17:28:58.434355
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case 0
    tuple_0 = None
    var_0 = to_namedtuple(tuple_0)
    # Test case 1
    list_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(list_0)
    var_1 = {'a': 2, 'b': 4}
    var_2 = var_0 == var_1
    var_2 = var_2 and type(var_0) is dict
    var_2 = var_2 and type(var_1) is dict
    # Test case 2
    tuple_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(tuple_0)
    var_1 = {'a': 2, 'b': 4}
    var_2 = var_

# Generated at 2022-06-25 17:29:09.598825
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({'b': 2, 'A': 1, 'c': 3}) == NamedTuple(A=1, b=2, c=3)
    assert to_namedtuple({'b': 2, 'A': 1, 'C': 3}) == NamedTuple(A=1, C=3, b=2)


# Generated at 2022-06-25 17:29:16.569727
# Unit test for function to_namedtuple
def test_to_namedtuple():
    x = {'a': {'b': 2, 'c': 3}, 'b': 2}
    y = to_namedtuple(x)
    assert hasattr(y, 'a')
    assert hasattr(y, 'b')
    assert hasattr(y.a, 'b')
    assert hasattr(y.a, 'c')
    assert y.a.b == 2
    assert y.a.c == 3
    assert y.b == 2

    x = [1, 2, 3, 4]
    y = to_namedtuple(x)
    assert isinstance(y[0], int)
    assert isinstance(y[1], int)

    x = {'a': {'b': 2, 'c': 3}, 'b': 2}
    x = SimpleNamespace(**x)

# Generated at 2022-06-25 17:29:20.376376
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    make = namedtuple('NamedTuple', 'a b')
    comp = make(1, 2)
    out = to_namedtuple(dic)
    assert out == comp



# Generated at 2022-06-25 17:29:30.167074
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    odic = OrderedDict((('a', 1), ('b', 2)))
    list_0 = [1, 2, 3]
    dict_0 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    sns_0 = SimpleNamespace(**dict_0)
    odict_0 = OrderedDict((('a', 1), ('b', 2), ('c', 3), ('d', 4)))
    sns_1 = SimpleNamespace(**odict_0)
    sns_2 = SimpleNamespace(a=1, b=2, c=3, d=4)
    tuple_1 = (1, 2, 3)
    tuple_2 = ('a', 'b', 'c', 'd')


# Generated at 2022-06-25 17:29:41.483433
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Simple test for to_namedtuple
    tuple_0 = None
    var_0 = to_namedtuple(tuple_0)

    # Simple test for to_namedtuple
    tuple_0 = {"a": 5}
    var_0 = to_namedtuple(tuple_0)

    # Simple test for to_namedtuple
    tuple_0 = {"a": 5, "b": 6}
    var_0 = to_namedtuple(tuple_0)

    # Simple test for to_namedtuple
    tuple_0 = {"b": 6, "a": 5}
    var_0 = to_namedtuple(tuple_0)

    # Simple test for to_namedtuple
    tuple_0 = {"a": 5, "b": 6, "c": 7}

# Generated at 2022-06-25 17:29:51.582171
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3, 'c': 4}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert hasattr(out, 'c')
    assert not hasattr(out, '_c')

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    dic['_c'] = 3
    dic['c'] = 4
    out = to_namedtuple(dic)
    assert out.a == 1

# Generated at 2022-06-25 17:30:25.416347
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == [namedtuple('NamedTuple', ('a', 'b'))(1, 2), namedtuple('NamedTuple', ('a', 'b'))(3, 4)]
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple(None) == None

# Generated at 2022-06-25 17:30:33.573251
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping, Sequence
    from types import SimpleNamespace
    from typing import TypeVar, NamedTuple, Union

    T = TypeVar('T', bound=Union[NamedTuple, Sequence, Mapping, SimpleNamespace])

    def _create_dict() -> OrderedDict:
        return OrderedDict([
            ('a', 1),
            ('b', SimpleNamespace(c=2, d=3)),
            ('c', OrderedDict([
                ('d', 4),
                ('e', 5),
            ]))
        ])

    def _create_tup() -> Tuple[int, int, int]:
        return (1, 2, 3)


# Generated at 2022-06-25 17:30:44.482183
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple([[]]) == [[]]
    assert to_namedtuple([[], []]) == [[], []]
    assert to_namedtuple([[], [[]]]) == [[], [[]]]
    assert to_namedtuple(['a']) == ['a']
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple(['a', ['a', 'b'], 'c']) == ['a', ['a', 'b'], 'c']

# Generated at 2022-06-25 17:30:52.310134
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test function to_namedtuple
    # Test cases:
    input_0 = {
      'a': {
        'b': 1,
        'c': 2,
      },
      'b': {
        'd': 3,
      }
    }
    NamedTuple = namedtuple('NamedTuple', ['a', 'b'])
    expected_0 = NamedTuple(
        a=NamedTuple(b=1, c=2),
        b=NamedTuple(d=3),
    )
    var_0 = to_namedtuple(input_0)
    assert var_0 == expected_0

    input_1 = (
      {
        'a': 1,
        'b': 2,
      },
      {
        'c': 3,
      }
    )
