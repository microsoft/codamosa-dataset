

# Generated at 2022-06-25 17:21:02.907452
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)

    dic = {'a': {'c': 1, 'd': 2}, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(
        namedtuple('NamedTuple', 'c d')(1, 2), 2)

    dic = {'a': {'c': 1, 'd': 2}, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(
        namedtuple('NamedTuple', 'c d')(1, 2), 2)


# Generated at 2022-06-25 17:21:09.250973
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Case 0
    try:
        test_case_0()
    except Exception as e:
        print('Sprint: 0 / Expected: No Exception / Got: ', e)

# Main
test_to_namedtuple()

# Generated at 2022-06-25 17:21:18.663517
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple

    orig = {
        'a': 1,
        'b': '2',
        'c': {
            'd': '4'
        }
    }

    out = to_namedtuple(orig)
    obj = namedtuple('obj', 'a b c')

    # noinspection PyTypeChecker
    out_tuple = obj(
        a=1,
        b='2',
        c=namedtuple(
            'obj', 'd'
        )(d='4'),
    )

    assert out == out_tuple


if __name__ == '__main__':
    import argparse
    from pprint import pprint
    from flutils.namedtupleutils import to_namedtuple



# Generated at 2022-06-25 17:21:30.136191
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # 1. Setup
    import copy

    dict_0 = {'a': {'b': {'c': [1, 2, 3]}}}
    dict_1 = copy.copy(dict_0)
    dict_2 = copy.copy(dict_0)
    dict_3 = copy.copy(dict_0)
    dict_4 = copy.copy(dict_0)
    dict_5 = copy.copy(dict_0)
    dict_6 = copy.copy(dict_0)
    dict_7 = copy.copy(dict_0)
    dict_8 = copy.copy(dict_0)
    dict_9 = copy.copy(dict_0)
    dict_10 = copy.copy(dict_0)
    dict_11 = copy.copy(dict_0)


# Generated at 2022-06-25 17:21:42.447752
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple0 = ()  # type: Tuple[Any, ...]

# Generated at 2022-06-25 17:21:47.581653
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = [{'a': 1, 'b': 2}, {'c': 3}, {'e': 5}, {'d': 4}]
    try:
        var = to_namedtuple(obj)
        print('var = %s' % var)
    except TypeError as err:
        print('Expected exception: %s' % err)
    obj = {'a': 1, 'b': 2, 'c': 3}
    try:
        var = to_namedtuple(obj)
        print('var = %s' % var)
    except TypeError as err:
        print('Expected exception: %s' % err)
    obj = {'a': 1, 'b': 2, 'c': 3, 1: 100}

# Generated at 2022-06-25 17:22:00.120845
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    tuple_0 = (dic_0, dic_0)
    var_0 = to_namedtuple(tuple_0)
    dic_1 = {'a': {'b': {'c': {'a1': 1, 'b2': 2, 'a3': 3}}}}
    namedtuple_0 = to_namedtuple(dic_1)
    namedtuple_1 = to_namedtuple(namedtuple_0)
    assert namedtuple_1 == namedtuple_0
    tuple_1 = namedtuple_0
    namedtuple_1 = to_namedtuple(tuple_1)
    assert namedtuple_1 == namedtuple_0
    namedtuple_2 = to_namedt

# Generated at 2022-06-25 17:22:13.020524
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple

    tuple_0 = (5, 'bob', 4.5, True)
    answer_0 = (5, 'bob', 4.5, True)
    var_0 = to_namedtuple(tuple_0)
    assert var_0 == answer_0

    list_1 = [5, 'bob', 4.5, True]
    answer_1 = [5, 'bob', 4.5, True]
    var_1 = to_namedtuple(list_1)
    assert var_1 == answer_1

    tuple_2 = (None,)
    answer_2 = (None,)
    var_2 = to_namedtuple(tuple_2)
    assert var_2 == answer_2


# Generated at 2022-06-25 17:22:22.270884
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # namedtuple
    namedtuple_0 = to_namedtuple(
        namedtuple('TestType', 'a b c')
    )
    assert isinstance(namedtuple_0, NamedTuple)
    try:
        namedtuple_0.d
    except AttributeError:
        pass
    else:
        assert False, "Did not raise AttributeError"
    assert namedtuple_0.a == namedtuple_0.b == namedtuple_0.c is None
    assert repr(namedtuple_0) == "TestType(a=None, b=None, c=None)"

    # list of namedtuples
    list_0 = [
        namedtuple('TestType', 'a b c'),
        namedtuple('TestType', 'a b c'),
    ]
    var_0

# Generated at 2022-06-25 17:22:25.130696
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    named_dic: NamedTuple = to_namedtuple(dic)
    assert named_dic == (1, 2)



# Generated at 2022-06-25 17:22:39.490784
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case 0
    tuple_0 = (0, )
    var_0 = to_namedtuple(tuple_0)
    assert var_0 == NamedTuple(item_0=0)
    # Test case 1
    tuple_0 = (0, 1, 2)
    var_0 = to_namedtuple(tuple_0)
    assert var_0 == NamedTuple(item_0=0, item_1=1, item_2=2)
    # Test case 2
    tuple_0 = (0, 1, 2)
    var_0 = to_namedtuple(tuple_0)
    assert var_0 == NamedTuple(item_0=0, item_1=1, item_2=2)
    # Test case 3
    list_0 = [0, 1, 2]


# Generated at 2022-06-25 17:22:51.282788
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Setup variables
    dic = {'a': 1, 'b': 2}

    # Convert to a NamedTuple
    # noinspection PyTypeChecker
    tup: NamedTuple = to_namedtuple(dic)

    # Check if the object is a NamedTuple
    assert isinstance(tup, NamedTuple), "The object is not a NamedTuple"

    # Check if the object has expected attributes
    assert hasattr(tup, 'a'), "The object does not have attribute 'a'"
    assert hasattr(tup, 'b'), "The object does not have attribute 'b'"

    # Check if the object does not have unexpected attributes
    assert not hasattr(tup, 'c'), "The object has unexpected attribute 'c'"

    # Check if each attribute has the correct value

# Generated at 2022-06-25 17:22:57.190099
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Testing exception TypeError: Can convert only 'list', 'tuple', 'dict' to
    # a NamedTuple; got: ('str',)
    try:
        to_namedtuple('test')
    except TypeError:
        pass

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:23:06.180208
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Tests for the _to_namedtuple function."""

    # noinspection PyShadowingBuiltins
    def _test_to_namedtuple_type(
            obj_in: _AllowedTypes,
            namespace: bool = False
    ):
        if namespace:
            obj_in = SimpleNamespace(**obj_in)
        obj_out = _to_namedtuple(obj_in)
        assert isinstance(obj_out, NamedTuple)

    # noinspection PyShadowingBuiltins
    def _test_to_namedtuple_values(
            obj_in: _AllowedTypes,
            namespace: bool = False
    ):
        if namespace:
            obj_in = SimpleNamespace(**obj_in)
        obj_out = _to_namedtuple(obj_in)

# Generated at 2022-06-25 17:23:19.761114
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    dic_1 = OrderedDict(a=1, b=2, c=3)
    dic_2 = OrderedDict(a=1, b=2, c=3, d=4)
    dic_3 = OrderedDict(a=1, b=2, c=3, d=4, e=5)
    nstp = SimpleNamespace(a=1, b=2)
    nstp_1 = SimpleNamespace(b=2, a=1)
    nstp_2 = SimpleNamespace(b=2, a=1, c=3)
    nstp_3 = SimpleNamespace(b=2, a=1, c=3, d=4)
    nstp_4 = SimpleNames

# Generated at 2022-06-25 17:23:33.447575
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for correct return type
    assert type(to_namedtuple(dict())) is tuple
    assert type(to_namedtuple(OrderedDict())) is tuple
    # Test for correct return type when including other types
    assert type(to_namedtuple({"a": "a", "b": 1, "c": 1.0})) is tuple
    assert type(to_namedtuple({"a": "a", "b": 1, "c": 1.0})) is tuple
    assert type(to_namedtuple({"a": "a", "b": 1, "c": 1.0})) is tuple
    # Test for correct return type when including other types in a list
    assert type(to_namedtuple({"a": "a", "b": 1, "c": 1.0})) is tuple
   

# Generated at 2022-06-25 17:23:41.796560
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
        }
    }
    var_0 = to_namedtuple(obj)
    if isinstance(var_0, NamedTuple):
        var_0.a
        var_0.b
        var_0.c
        var_0.c.d
        var_0.c.e

    obj = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', {
            'd': 3,
            'e': 4,
        }),
    ])
    var_0 = to_namedtuple(obj)
    if isinstance(var_0, NamedTuple):
        var_0._fields
        var

# Generated at 2022-06-25 17:23:54.532804
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for the default case
    tuple_0 = (1, 2, 3, 4)
    tuple_0 = to_namedtuple(tuple_0)
    assert type(tuple_0) == NamedTuple
    assert tuple_0 == NamedTuple(1, 2, 3, 4)

    # Test for the namedtuple case
    ntuple_0 = NamedTuple('1', '2')
    ntuple_0 = to_namedtuple(ntuple_0)
    assert type(ntuple_0) == NamedTuple
    assert ntuple_0 == NamedTuple('1', '2')

    # Test for the list case
    list_0 = [1, 2, 3, 4]
    list_0 = to_namedtuple(list_0)

# Generated at 2022-06-25 17:24:03.826249
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    tuple_0 = (
        {
            'a': 1,
            'b': 'A',
            'c': (1, 2),
            'd': {
                'e': 4,
                'f': 'E',
            },
            'g': [1, 2, 'A', 'B']
        },
        1,
        {
            'a': 11,
            'b': 'AA',
            'c': (11, 22),
            'd': {
                'e': 44,
                'f': 'EE',
            },
            'g': [11, 22, 'AA', 'BB']
        }
    )


# Generated at 2022-06-25 17:24:13.070798
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = 'a'
    b = 'b'
    c = 'c'
    d = 'd'
    e = 'e'
    f = 'f'
    one = '1'
    two = '2'
    three = '3'
    four = '4'
    five = '5'
    six = '6'
    seven = '7'
    eight = '8'
    nine = '9'
    ten = '10'
    eleven = '11'
    twelve = '12'
    thirteen = '13'
    fourteen = '14'
    fifteen = '15'
    sixteen = '16'
    seventeen = '17'
    eighteen = '18'
    nineteen = '19'
    twenty = '20'
    twenty_one = '21'
    twenty_two = '22'

# Generated at 2022-06-25 17:24:28.517171
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dic_0)
    assert var_0 == (1, 2)

    ordered_dic_0 = OrderedDict(a=1, b=2)
    var_1 = to_namedtuple(ordered_dic_0)
    assert var_1 == (1, 2)

    list_0 = [1, 2]
    var_2 = to_namedtuple(list_0)
    assert var_2 == [1, 2]

    tuple_0 = (1, 2)
    var_3 = to_namedtuple(tuple_0)
    assert var_3 == (1, 2)

    tuple_1 = (1, 2, dic_0, list_0)


# Generated at 2022-06-25 17:24:41.218858
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:24:49.174164
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = to_namedtuple({})
    assert tuple_0 == ()
    tuple_1 = to_namedtuple({'a': 1, 'b': 2})
    assert tuple_1 == (1, 2)
    tuple_2 = to_namedtuple({'a': 1, 'b': {'a': 1, 'b': 2}})
    assert tuple_2.a == 1
    assert tuple_2.b == (1, 2)
    tuple_3 = to_namedtuple({'a': 1, 'b': {'a': 1, 'b': {'a': 1, 'b': 2}}})
    assert tuple_3.a == 1
    assert tuple_3.b.a == 1
    assert tuple_3.b.b == (1, 2)
    tuple_4 = to_namedt

# Generated at 2022-06-25 17:25:03.071521
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Testing when an empty tuple is provided
    assert hasattr(to_namedtuple(()), '_fields') is True
    # Testing when a list is provided
    assert isinstance(to_namedtuple([]), list) is True
    # Testing when a tuple is provided
    assert isinstance(to_namedtuple((1, 2)), tuple) is True
    # Testing when a list is provided
    assert isinstance(to_namedtuple([1, 2]), list) is True
    # Testing when a Mapping object is provided
    assert isinstance(to_namedtuple({'a': 1}), namedtuple) is True
    # Testing when a Mapping object is provided
    assert isinstance(to_namedtuple({'a': {'b': 2}}), namedtuple) is True
    # Testing when a simple namespace object is provided

# Generated at 2022-06-25 17:25:09.285519
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for sequence (list)
    var_0 = [1, 2, 3]
    var_1 = to_namedtuple(var_0)
    assert var_1 == (1, 2, 3)
    var_2 = to_namedtuple([[1, 2, 3], [4, 5, 6]])
    assert var_2 == ((1, 2, 3), (4, 5, 6))
    var_3 = to_namedtuple([[1, 2, 3], (4, 5, 6)])
    assert var_3 == ((1, 2, 3), (4, 5, 6))
    var_4 = to_namedtuple(['a', 'b', 'c'])
    assert var_4 == ('a', 'b', 'c')

    # Test for mapping (dict)
    var_5

# Generated at 2022-06-25 17:25:21.611981
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == to_namedtuple(tuple()) == \
        to_namedtuple(OrderedDict()) == to_namedtuple([])
    assert to_namedtuple({'a': 0}) == to_namedtuple(tuple(['a'])) == \
        to_namedtuple(OrderedDict({'a': 0})) == to_namedtuple(['a'])
    assert to_namedtuple({'a': 0, 'b': 1}) == to_namedtuple(tuple(['a', 'b']))\
        == to_namedtuple(OrderedDict({'a': 0, 'b': 1})) == \
        to_namedtuple(['a', 'b'])

# Generated at 2022-06-25 17:25:24.343664
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == namedtuple('NamedTuple', 'a b')(a=1, b=2)



# Generated at 2022-06-25 17:25:37.630764
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # using a simple list convert to namedtuple
    test_list_0 = ['a','b','c','d','e','f' ]
    print('Original:    ',test_list_0)
    new_nt = to_namedtuple(test_list_0)
    print('Converted:   ',new_nt)
    # using a simple dictionary, with key strings convert to namedtuple
    test_dict_0 = {'alpha':'a', 'beta':'b', 'gamma':'c', 'delta':'d', 'epsilon':'e', 'zeta':'z' }
    print('\nOriginal:    ',test_dict_0)
    new_nt = to_namedtuple(test_dict_0)
    print('Converted:   ',new_nt)
    # using a simple list

# Generated at 2022-06-25 17:25:49.773481
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test the presence of the _started argument
    obj = ['abc', 'def', {'ghi': (1, 2, 3)}, 'jkl', (1, 2, 3)]
    out = to_namedtuple(obj)
    assert out[2].ghi == (1, 2, 3)

    # Test the absence of the _started argument (second argument)
    obj = ['abc', 'def', {'ghi': (1, 2, 3)}, 'jkl', (1, 2, 3)]
    out = to_namedtuple(obj)
    assert out[2].ghi == (1, 2, 3)



# Generated at 2022-06-25 17:26:02.807309
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection SpellCheckingInspection
    example_dict = {
        'a': 1,
        'b': 2
    }
    struct = to_namedtuple(example_dict)
    assert struct.a == 1
    assert struct.b == 2

    struct = to_namedtuple([example_dict])
    assert struct[0].a == 1
    assert struct[0].b == 2

    struct = to_namedtuple(OrderedDict(example_dict))
    assert struct.a == 1
    assert struct.b == 2

    struct = to_namedtuple(SimpleNamespace(**example_dict))
    # assert struct.a == 1
    # assert struct.b == 2

    example_list = [1, 2]
    struct = to_namedtuple(example_list)

# Generated at 2022-06-25 17:26:09.079437
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _test_case_0()



# Generated at 2022-06-25 17:26:20.762021
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Set up test data
    test_data = [
        {
            'inputs': [
                {
                    'a': 1,
                    'b': 2
                }
            ],
            'outputs': [
                """<class 'collections.namedtuple'>"""
            ]
        }
    ]

    expected_outputs = [
        """<class 'collections.namedtuple'>"""
    ]


    # Execute the test
    for test_number, test in enumerate(test_data):
        # Set up test inputs
        inputs = test['inputs']

        var_0 = to_namedtuple(inputs[0])

        # Assert the outputs
        assert isinstance(var_0, collections.namedtuple)



# Generated at 2022-06-25 17:26:27.358347
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(tuple()) == to_namedtuple(list())
    assert to_namedtuple(OrderedDict(a=1, b=2)) == to_namedtuple(dict(a=1, b=2))
    assert to_namedtuple(OrderedDict(a=1, b=2)) == to_namedtuple(OrderedDict(b=2, a=1))
    assert to_namedtuple(OrderedDict(a=1, b=2)) != to_namedtuple(OrderedDict(b=1, a=2))
    assert to_namedtuple(OrderedDict(a=1, b=2)) != to_namedtuple(dict(a=1, b=2))

# Generated at 2022-06-25 17:26:36.535402
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:26:47.422018
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.ordered_enum import OrderedEnum

    class Class0(object):
        # noinspection PyMissingConstructor,PyUnusedLocal
        def __init__(self, *args: Any, **kwargs: Any):
            pass

    here = os.path.abspath(os.path.dirname(__file__))
    with open(os.path.join(here, 'test_to_namedtuple.json'), 'r') as file:
        data = file.read()
    data = json.loads(data)
    expected = data['expected']
    del data['expected']
    for case, vals in data.items():
        if case.startswith('expected'):
            continue
        msg = repr(vals['obj'])
        obj = vals['obj']

# Generated at 2022-06-25 17:26:53.859598
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Check if function returns the correct type
    def test_types():
        assert isinstance(var_0, tuple)
        assert isinstance(var_1, list)
        assert isinstance(var_2, NamedTuple)
        assert isinstance(var_3, list)
        assert isinstance(var_4, tuple)
        assert isinstance(var_5, dict)
        assert isinstance(var_6, tuple)
        assert isinstance(var_7, list)
        assert isinstance(var_8, tuple)
        assert isinstance(var_9, dict)
        assert isinstance(var_10, tuple)

    # Check if the correct output was made
    def test_outputs():
        assert var_0 == tuple_0
        assert var_1 == tuple_1
        assert var_2 == tuple_2


# Generated at 2022-06-25 17:27:04.194506
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import date
    from collections import namedtuple

    # pylint: disable=invalid-name

# Generated at 2022-06-25 17:27:15.686394
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Expected results
    tuple_0 = (('a', 1), ('b', 2))
    tuple_1 = ('a', 1)
    list_0 = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    list_1 = [tuple_1, {'c': 3, 'd': 4}]
    list_2 = [tuple_1, ('c', 3), ('d', 4)]
    list_3 = ['a', 1]
    list_4 = ('a', 1, ['c', 3], ('d', 4))
    named_0 = namedtuple('named_0', 'a b')(a=1, b=2)
    named_1 = namedtuple('named_1', 'a')(a=1)
    named_2 = namedtuple

# Generated at 2022-06-25 17:27:25.419472
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    tuple_0 = (1, 2, 3, 4, 5, 6)
    list_0 = [1, 2, 3, 4, 5, 6]
    list_1 = [1, 2, {'a': 4, 'b': 5, 'c': 6}, 3, 4, 5, 6]
    list_2 = [1, 2, [1, 2, 3, 4, 5, 6], 3, 4, 5, 6]
    list_3 = [1, 2, (1, 2, 3, 4, 5, 6), 3, 4, 5, 6]
    list_4 = [1, 2, [1, 2, (1, 2, 3, 4, 5, 6), 3, 4, 5, 6], 3, 4, 5, 6]
   

# Generated at 2022-06-25 17:27:36.085663
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) ==\
           NamedTuple(a=1, b=2)

    assert to_namedtuple([]) == []
    assert to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]) ==\
           [NamedTuple(a=1, b=2), NamedTuple(c=3, d=4)]

    assert to_namedtuple(SimpleNamespace(a=1, b=2)) ==\
           NamedTuple(a=1, b=2)



# Generated at 2022-06-25 17:28:02.761301
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # No docstring, so can only ignore the line, not the function
    tuple_0 = ('abc', 'def')  # type: ignore[assignment]
    var_0 = to_namedtuple(tuple_0)
    assert var_0.abc == 'abc'
    assert var_0.def_ == 'def'
    var_1 = var_0._asdict()
    assert var_1['abc'] == 'abc'
    assert var_1['def_'] == 'def'
    str_0 = to_namedtuple(var_0)
    assert str_0 == var_0


if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-25 17:28:11.463373
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = {
        'a': 1,
        'b': 2
    }
    var_0 = to_namedtuple(a)
    assert isinstance(var_0, NamedTuple)
    assert set(var_0._fields) == {'a', 'b'}
    b = ('a', 'b')
    var_1 = to_namedtuple(b)
    assert var_1 == b
    c = OrderedDict()
    c['a'] = 1
    c['b'] = 2
    d = SimpleNamespace()
    d.a = 1
    d.b = 2
    var_2 = to_namedtuple(c)
    assert var_2 == var_0
    var_3 = to_namedtuple(d)
    assert var_3 == var_0



# Generated at 2022-06-25 17:28:22.949970
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:28:31.095853
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Case 0
    try:
        tuple_0 = ()
        var_0 = to_namedtuple(tuple_0)
    except TypeError:
        pass
    else:
        raise Exception('Case 0 failed')

    # Case 1
    try:
        tuple_1 = (1)
        var_1 = to_namedtuple(tuple_1)
    except TypeError:
        pass
    else:
        raise Exception('Case 1 failed')


if __name__ == '__main__':
    test_case_0()
    test_to_namedtuple()

# Generated at 2022-06-25 17:28:39.382567
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test conversion of various objects."""
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert type(out).__name__ == 'NamedTuple'
    assert out == (1, 2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert type(out).__name__ == 'NamedTuple'
    assert out == (1, 2)

    dic = {'a': 1, 'b': 2}
    dic2 = {'c': 3, 'd': 4}

# Generated at 2022-06-25 17:28:50.000888
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    import collections
    # load some random data we want to convert
    data = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    tuple_0 = (data, )
    tuple_1 = (tuple_0, )
    expected = collections.namedtuple('Test', ('a', 'b', 'c'))(1, 2, 3)

    # convert the dict data
    result = to_namedtuple(data)
    assert result == expected
    assert not isinstance(result, dict)

    # convert the tuple with the dict data
    result = to_namedtuple(tuple_0)
    assert tuple_0 == result
    assert not isinstance(result, dict)

# Generated at 2022-06-25 17:28:58.452591
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    tuple_0 = (1, 2, 3, 4, 5, 6)
    var_0 = to_namedtuple(tuple_0)
    assert var_0 == tuple_0

    tuple_0 = ('a', 'b', 'c', 'd', 'e', 'f')
    var_0 = to_namedtuple(tuple_0)
    assert var_0 == tuple_0

    tuple_0 = (1, 'b', 3, 'd', 5, 'f')
    var_0 = to_namedtuple(tuple_0)
    assert var_0 == tuple_0

    list_0 = [1, 2, 3, 4, 5, 6]
    var_0 = to_namedt

# Generated at 2022-06-25 17:29:09.597356
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic_a = {'a': 1, 'b': 2}
    attrs = to_namedtuple(dic_a)
    assert hasattr(attrs, 'a')
    assert hasattr(attrs, 'b')
    assert vars(attrs)
    assert attrs.a == dic_a['a']
    assert attrs.b == dic_a['b']

    dic_b = {'b': 2, 'a': 1}
    attrs = to_namedtuple(dic_b)
    assert hasattr(attrs, 'a')
    assert hasattr(attrs, 'b')
    assert vars(attrs)
    assert attrs.a == dic_a['a']
    assert attrs

# Generated at 2022-06-25 17:29:16.579594
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from unittest import TestCase, main

    from flutils.params import _ParamDict

    class _TestToNamedTuple(TestCase):

        def test_to_namedtuple(self):
            var_0 = to_namedtuple({'a': 1})
            self.assertIsInstance(var_0, namedtuple)
            self.assertEqual(var_0.a, 1)

            var_1 = to_namedtuple({'a': 1, 'b': 2})
            self.assertIsInstance(var_1, namedtuple)
            self.assertEqual(var_1.a, 1)
            self.assertEqual(var_1.b, 2)


# Generated at 2022-06-25 17:29:27.257854
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = ()
    tuple_1 = (1, 2, 3)
    tuple_2 = (1, 2, 3, (4, 5, 6))
    tuple_3 = (1, 2, 3, {'q': 0, 'w': 1})
    tuple_4 = (1, 2, 3, {'q': 0, 'w': {'e': 0, 'r': []}})
    tuple_5 = (1, 2, 3, {'q': 0, 'w': {'e': 0, 'r': {'w': 1}}})
    tuple_6 = (1, 2, 3, {'q': 0, 'w': {'e': 0, 'r': {'w': 1, 't': 1}}})
    print(to_namedtuple(tuple_0))

# Generated at 2022-06-25 17:29:46.021840
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test with a list
    list_0 = [{'a': 0, 'b': 1}, {'a': 1, 'b': 2}, {'a': 2, 'b': 3}]
    result_0 = to_namedtuple(list_0)
    # Test with a tuple
    tuple_0 = ({'a': 0, 'b': 1}, {'a': 1, 'b': 2}, {'a': 2, 'b': 3})
    result_1 = to_namedtuple(tuple_0)
    # Test with a dictionary
    dict_0 = {'a': 0, 'b': 1}
    result_2 = to_namedtuple(dict_0)
    # Test with the wrong type
    dict_1 = {'a': 0, 'b': 1}
    result_3 = to_

# Generated at 2022-06-25 17:29:54.381881
# Unit test for function to_namedtuple
def test_to_namedtuple():
    expected = (1, 2, 3)
    tuple_0 = (1, 2, 3)
    var_0 = to_namedtuple(tuple_0)
    assert var_0 is expected
    tuple_1 = (1, 2, 3, {'a': 4, 'b': 5})
    expected = (1, 2, 3, NamedTuple(a=4, b=5))
    var_1 = to_namedtuple(tuple_1)
    assert var_1 == expected
    list_0 = [1, 2, 3, {'a': 4, 'b': 5}]
    expected = [1, 2, 3, NamedTuple(a=4, b=5)]
    var_2 = to_namedtuple(list_0)
    assert var_2 == expected

# Generated at 2022-06-25 17:29:55.823851
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple function."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:30:04.731196
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data: List[Union[str, int, float, Mapping, List, SimpleNamespace]] = [
        'some string',
        0,
        0.0,
        [1, 2, ['a', True, None, 'b']],
        {'a': 1, 'b': 'c', 'd': [1, 2, 3]},
        SimpleNamespace(a=1, b=None),
        SimpleNamespace(a=1, b='c', d=[1, 2, 3]),
        SimpleNamespace(a=None, b='c', d=[1, 2, 3]),
        SimpleNamespace(a=1234.5678, b='c', d=[1, 2, 3]),
        SimpleNamespace(a=1234.5678, b='c', d=[1, 2, None]),
    ]


# Generated at 2022-06-25 17:30:15.274946
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = {'a': 1, 'b': 2}
    expected = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(data) == expected
    assert tuple(to_namedtuple(data)._fields) == ('a', 'b')
    assert to_namedtuple(data).a == 1
    assert to_namedtuple(data).b == 2
    data = [1, 2, 3, 4]
    expected = [1, 2, 3, 4]
    assert to_namedtuple(data) == expected
    data = [{'a': 1}, {'a': 2}]

# Generated at 2022-06-25 17:30:25.338799
# Unit test for function to_namedtuple
def test_to_namedtuple():
    expected = namedtuple('NamedTuple', 'a,b')(1, 2)
    actual = to_namedtuple({'b': 2, 'a': 1})
    assert actual == expected
    expected = namedtuple('NamedTuple', 'a,b')(1, 2)
    actual = to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert actual == expected
    expected = namedtuple('NamedTuple', 'a,b')(1, 2)
    actual = to_namedtuple(SimpleNamespace(a=1, b=2))
    assert actual == expected
    expected = namedtuple('NamedTuple', 'a,b,c')(1, [3, 4], {5: 6})

# Generated at 2022-06-25 17:30:33.509429
# Unit test for function to_namedtuple
def test_to_namedtuple():
    make = namedtuple('NamedTuple', 'a b c')
    tuple_0 = make(1, 2, 3)
    var_0 = to_namedtuple(tuple_0)
    var_1 = to_namedtuple([1, 2, 3])
    var_2 = to_namedtuple({'a': 1, 'b': 2, 'c': 3})
    var_3 = to_namedtuple(OrderedDict((('a', 1), ('b', 2), ('c', 3))))
    var_4 = to_namedtuple(SimpleNamespace(a=1, b=2, c=3))
    assert isinstance(var_0, NamedTuple)
    assert isinstance(var_1, list)
    assert isinstance(var_2, NamedTuple)

# Generated at 2022-06-25 17:30:44.403169
# Unit test for function to_namedtuple
def test_to_namedtuple():

    def test_case_0():
        tuple_0 = ()
        var_0 = to_namedtuple(tuple_0)

    def test_case_1():
        tuple_0 = (1,)
        var_0 = to_namedtuple(tuple_0)

    def test_case_2():
        tuple_0 = (1, 'a')
        var_0 = to_namedtuple(tuple_0)

    def test_case_3():
        tuple_0 = (1, 'a', 3.0)
        var_0 = to_namedtuple(tuple_0)

    def test_case_4():
        tuple_0 = (1, 'a')
        tuple_1 = (2, 'b')
        tuple_2 = (tuple_0, tuple_1)
        var

# Generated at 2022-06-25 17:30:52.236044
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic_0 = {'a': 1, 'b': 2}

    tuple_0 = (1, 2, 3)

    dic_1 = {'a': 1, 'b': 2, 'c': tuple_0}

    dic_2 = {'a': 1, 'b': 2, 'c': {'x': 1, 'y': 2}}

    dict_with_tuple = {'a': 1, 'b': 2, 'c': (3, 4)}

    dict_with_list = {'a': 1, 'b': 2, 'c': [3, 4]}

    dict_with_list_dict = {'a': 1, 'b': 2, 'c': [{'x': 1, 'y': 2}]}
