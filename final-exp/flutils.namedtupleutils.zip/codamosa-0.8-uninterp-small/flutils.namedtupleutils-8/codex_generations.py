

# Generated at 2022-06-25 17:21:04.299857
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test case for the ``to_namedtuple`` function."""
    simple_namespace_0 = SimpleNamespace(name='foo', val=1, v2=2)
    simple_namespace_1 = dict(
        name='foo', val=1, v2=2, __val__1=42
    )
    simple_namespace_2 = OrderedDict(
        name='foo', val=1, v2=2, __val__1=42
    )
    simple_namespace_3 = dict(
        name='foo', val=1, v2=2, __val__1=42, __dict__={
            'a': 1, 'b': 2
        }
    )

# Generated at 2022-06-25 17:21:14.198565
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = SimpleNamespace()
    simple_namespace_0.a = 1
    simple_namespace_0.b = 3
    var_0 = to_namedtuple(simple_namespace_0)
    assert hasattr(var_0, 'a')
    assert var_0.a == simple_namespace_0.a
    assert hasattr(var_0, 'b')
    assert var_0.b == simple_namespace_0.b
    simple_namespace_1 = SimpleNamespace()
    simple_namespace_1.c = 'test_case_0'
    simple_namespace_1.d = 'test_case_1'
    var_1 = to_namedtuple(simple_namespace_1)
    assert hasattr(var_1, 'c')

# Generated at 2022-06-25 17:21:15.026139
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()

# Generated at 2022-06-25 17:21:29.591948
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [
        namedtuple('nt', ('a', 'b')),
        {'a': 1, 'b': 2},
        dict(a=1, b=2),
        OrderedDict(a=1, b=2),
        SimpleNamespace(a=1, b=2),
        [1, 2],
        (1, 2),
        1,
        'a',
        None,
    ]
    out_0 = to_namedtuple(list_0)
    assert list_0 == out_0


# Generated at 2022-06-25 17:21:42.130433
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:21:54.692520
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = cast(SimpleNamespace, SimpleNamespace())
    simple_namespace_0.a = 1
    simple_namespace_0.b = 2
    simple_namespace_1 = cast(SimpleNamespace, SimpleNamespace())
    simple_namespace_1.c = 3
    simple_namespace_1.d = 4
    simple_namespace_1.e = 5
    simple_namespace_1.f = 6
    simple_namespace_1.g = 7

    var_1 = simple_namespace_0.a
    var_2 = simple_namespace_0.b
    var_3 = simple_namespace_1.f
    var_4 = simple_namespace_1.g

    # Test no return value (TypeError)
    var_5 = to_namedtuple

# Generated at 2022-06-25 17:21:56.573409
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case #0
    simple_namespace_0 = None
    var_0 = to_namedtuple(simple_namespace_0)
    assert var_0 is None

# Generated at 2022-06-25 17:22:10.678343
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    simple_namespace_0 = SimpleNamespace(a=1, b=2)
    var_0 = to_namedtuple(simple_namespace_0)
    print(var_0)
    assert isinstance(var_0, namedtuple('NamedTuple', 'a b'))
    assert var_0.a == 1
    assert var_0.b == 2
    
    ordereddict_0 = OrderedDict(
        a=1,
        b=2,
        c=3,
        d=4,
        e=5,
    )
    var_1 = namespaced_0 = to_namedtuple(ordereddict_0)
    print(var_1)

# Generated at 2022-06-25 17:22:25.007152
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # simple test
    dic = {'a': 1, 'b': 2}
    nt: NamedTuple = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt._fields == ('a', 'b')

    # test multiple depths
    dic_2 = {'a': 1, 'b': dic}
    nt_2: NamedTuple = to_namedtuple(dic_2)
    assert nt_2.a == 1
    assert nt_2.b.a == 1
    assert nt_2.b.b == 2
    assert nt_2.b._fields == ('a', 'b')

    # test with collections.OrderedDict
    from collections import OrderedDict
    odic = Ordered

# Generated at 2022-06-25 17:22:32.443904
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # These are test cases for function to_namedtuple.
    # assert False
    # assert True
    from flutils.namedtupleutils import to_namedtuple
    # from flutils.namedtupleutils import _to_namedtuple

    dic_0 = {
        'a': {'a': 1, 'b': 2},
        'b': {'a': 1},
        'c': {'d': 3, 'c': 2},
        'd': {
            'a': 1,
            'b': 2,
            'c': 2,
        },
    }
    named_tuple_0 = to_namedtuple(dic_0)
    assert isinstance(named_tuple_0, namedtuple)

# Generated at 2022-06-25 17:22:44.102334
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class Test(object):
        def test_to_namedtuple_0(self):
            namedtuple_0 = NamedTuple('NamedTuple' + '', ['foo', 'bar'])
            assert to_namedtuple(namedtuple_0) == (1, 2)
        def test_to_namedtuple_1(self):
            list_0 = ['foo', 'bar']
            assert to_namedtuple(list_0) == ['foo', 'bar']
        def test_to_namedtuple_2(self):
            dict_0 = {'foo': 1, 'a': 2}
            assert to_namedtuple(dict_0) == NamedTuple('NamedTuple' + '', ['a', 'foo'])
        def test_to_namedtuple_3(self):
            dict

# Generated at 2022-06-25 17:22:53.833928
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import datetime as dt
    import unittest

    class ToNamedTupleTests(unittest.TestCase):

        def test_case_0(self):
            obj = {'t': dt.datetime.now(), 'a': {'b': [1, 2]}}
            tup = to_namedtuple(obj)
            self.assertIn('t', tup._fields)
            self.assertIn('a', tup._fields)
            t = getattr(tup, 'a')
            self.assertIn('b', t._fields)
            t = getattr(tup, 'b')
            self.assertIn('t', t._fields)


# Generated at 2022-06-25 17:23:03.885093
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = SimpleNamespace(
        attr_0=0,
        attr_1=1,
        attr_2=2,
    )
    assert to_namedtuple(simple_namespace_0) == namedtuple(
        'NamedTuple',
        ['attr_0', 'attr_1', 'attr_2'],
    )(0, 1, 2)
    simple_namespace_0 = SimpleNamespace(
        attr_0='0',
        attr_1='1',
        attr_2='2',
    )

# Generated at 2022-06-25 17:23:09.106551
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test type error
    with pytest.raises(TypeError):
        test_case_0()

    # Test namedtuple
    a = namedtuple('A', 'a b c')(3, 2, 1)
    a2 = to_namedtuple(a)
    assert a == a2
    assert a is not a2

    # Test list
    simple_list = [1, 2, 3]
    # noinspection PyTypeChecker
    var_1 = to_namedtuple(simple_list)
    assert isinstance(var_1, list)
    # noinspection PyTypeChecker
    assert var_1 == simple_list

    # Test tuple
    simple_tuple = (1, 2, 3)
    # noinspection PyTypeChecker

# Generated at 2022-06-25 17:23:21.529256
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = SimpleNamespace()
    simple_namespace_0.a = SimpleNamespace()
    simple_namespace_0.a.b = SimpleNamespace()
    simple_namespace_0.a.b.c = 3
    simple_namespace_0.d = 4
    var_0 = to_namedtuple(simple_namespace_0)
    assert isinstance(var_0, tuple)
    assert len(var_0) == 2
    assert isinstance(var_0.a, tuple)
    assert len(var_0.a) == 1
    assert isinstance(var_0.a.b, tuple)
    assert len(var_0.a.b) == 1
    assert var_0.a.b.c == 3
    assert var_0.d == 4
    var

# Generated at 2022-06-25 17:23:30.073519
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0 = dict(a=1, b=2)
    namedtuple_0 = to_namedtuple(dict_0)
    assert namedtuple_0.a == 1
    assert namedtuple_0.b == 2
    dict_0 = dict(a=1, _b=2)
    namedtuple_0 = to_namedtuple(dict_0)
    assert namedtuple_0.a == 1
    try:
        namedtuple_0.b
    except AttributeError:
        pass
    else:
        raise AssertionError('AttributeError not raised')
    dict_1 = dict(a=1, _b=2)
    dict_2 = dict(c=3, d=4)
    dict_3 = dict(e=5, f=dict_1)
    dict_

# Generated at 2022-06-25 17:23:33.355697
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

# Generated at 2022-06-25 17:23:39.386637
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_1 = SimpleNamespace()
    setattr(simple_namespace_1, 'a', 1)
    setattr(simple_namespace_1, 'b', 2)
    var_2 = to_namedtuple(simple_namespace_1)
    assert var_2[0] == 1
    assert var_2[1] == 2


# Generated at 2022-06-25 17:23:50.719137
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Testing positional only arguments
    dic = {'a': 1, 'b': 2}
    obj: NamedTuple = to_namedtuple(dic)
    out = obj._asdict()
    expected = {'a': 1, 'b': 2}
    assert out == expected

    dic = {'_b': 2, 'a': 1}
    obj: NamedTuple = to_namedtuple(dic)
    out = obj._asdict()
    expected = {'a': 1}
    assert out == expected

    dic = OrderedDict([('a', 1), ('b', 2)])
    obj: NamedTuple = to_namedtuple(dic)
    out = obj._asdict()
    expected = OrderedDict([('a', 1), ('b', 2)])
    assert out

# Generated at 2022-06-25 17:24:00.504660
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import random
    import string

    # tuple of some of the valid python identifiers (strings)
    identifiers = (
        '_', '_a', 'b___', 'b_a', 'a123', 'a', 'a_123', 'a___',
    )  # type: Tuple[str, ...]

    # test for each item in identifiers
    for item in identifiers:
        assert hasattr(to_namedtuple({item: 1}), item)
        assert hasattr(to_namedtuple({item: 1}), item) is True
        assert hasattr(to_namedtuple({item: 1}), item) == True
        assert hasattr(to_namedtuple({item: 1}), item) is not False
        assert hasattr(to_namedtuple({item: 1}), item) is not None

    # test

# Generated at 2022-06-25 17:24:13.578196
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) == 1
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(['a']) == ['a']
    assert to_namedtuple(('a',)) == ('a',)
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert to_namedtuple(SimpleNamespace(a=1, b=2, c=3)).a == 1
    assert to_namedtuple(SimpleNamespace(a=1, b=2, c=3)).b == 2

# Generated at 2022-06-25 17:24:25.517826
# Unit test for function to_namedtuple
def test_to_namedtuple():
    set_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(set_0)
    assert var_0 == NamedTuple(a=1, b=2)
    dict_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dict_0)
    assert var_0 == NamedTuple(a=1, b=2)
    ordered_dict_0 = OrderedDict(
        [
            ('b', 2),
            ('a', 1),
        ],
    )
    var_0 = to_namedtuple(ordered_dict_0)
    assert var_0 == NamedTuple(b=2, a=1)

# Generated at 2022-06-25 17:24:40.157594
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple([]), list)
    assert to_namedtuple([]) == []
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert isinstance(to_namedtuple([['a', 'b']])[0], NamedTuple)
    assert isinstance(to_namedtuple([{'a': 1, 'b': 2}])[0], NamedTuple)
    assert isinstance(to_namedtuple(tuple()), tuple)
    assert to_namedtuple(tuple()) == tuple()
    assert isinstance(to_namedtuple((('a', 'b')))[0], NamedTuple)
    assert to_namedtuple(tuple(('a', 'b'))) == ('a', 'b')

# Generated at 2022-06-25 17:24:46.124304
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dict_0 = {
        'a': 1,
        'b': 2,
    }
    dict_0_expected = namedtuple('NamedTuple', 'a b')(
        a=1,
        b=2,
    )
    dict_0_result = to_namedtuple(dict_0)
    assert dict_0_result == dict_0_expected

    dict_1 = {
        'b': 2,
        'a': 1,
    }
    dict_1_expected = namedtuple('NamedTuple', 'a b')(
        a=1,
        b=2,
    )
    dict_1_result = to_namedtuple(dict_1)
    assert dict_1_result == dict_1_expected


# Generated at 2022-06-25 17:24:58.737933
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import os
    import sys
    import unittest

    class TD(unittest.TestCase):

        def test_case_0(self):
            """This test checks for an attempt to convert a None value."""
            simple_namespace_0 = None
            with self.assertRaises(TypeError):
                to_namedtuple(simple_namespace_0)

        def test_case_1(self):
            """This test checks a dictionary convert to a NamedTuple."""
            dic = {'a': 1, 'b': 2}
            var_0 = to_namedtuple(dic)
            self.assertEqual(var_0.a, 1)
            self.assertEqual(var_0.b, 2)


# Generated at 2022-06-25 17:25:08.272583
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = SimpleNamespace(attr='attr', attr_0='attr_0')
    namedtuple_0 = to_namedtuple(simple_namespace_0)
    assert namedtuple_0.attr == 'attr'
    assert namedtuple_0.attr_0 == 'attr_0'
    assert isinstance(namedtuple_0, NamedTuple)
    simple_namespace_1 = SimpleNamespace(attr_1='attr_1', attr_2='attr_2')
    namedtuple_1 = to_namedtuple(simple_namespace_1)
    assert namedtuple_1.attr_1 == 'attr_1'
    assert namedtuple_1.attr_2 == 'attr_2'
    assert isinstance(namedtuple_1, NamedTuple)
   

# Generated at 2022-06-25 17:25:21.076591
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from flutils.namedtupleutils import to_namedtuple

    from collections import OrderedDict

    from flutils.datatypes import DotDict

    obj_1 = SimpleNamespace(
        a=1,
        b=2,
        c=3,
    )

    obj_2 = obj_1.__dict__

    obj_3 = OrderedDict(
        a=1,
        b=2,
        c=3,
    )

    obj_4 = DotDict(
        a=1,
        b=2,
        c=3,
    )

    obj_5 = obj_4.as_dict()

    obj_6 = {
        'a': 1,
        'b': 2,
        'c': 3,
    }


# Generated at 2022-06-25 17:25:37.172928
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import random

    # Test 1
    dic = {
        'a': 1,
        'b': 2,
    }
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    # Test 2
    a, b, c, d, e, f, g, h, i, j, k, l = [
        random.random() for _ in range(12)
    ]

# Generated at 2022-06-25 17:25:46.035538
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import patch

    from flutils.namedtupleutils import (
        to_namedtuple,
    )

    # Create a fresh instance of to_namedtuple()
    func = to_namedtuple

    # Test various objects
    assert not func('')
    assert not func(b'')
    assert func(dict())
    assert func(list())
    assert func(tuple())



# Generated at 2022-06-25 17:25:56.237211
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyPackageRequirements
    import pytest

    # Create a class that implements the abstract base class
    class MockDict(Mapping):
        @property
        def _attr(self):
            return {'a': 1, 'b': 2}

        def __getitem__(self, item):
            return self._attr[item]

        def __len__(self):
            return len(self._attr)

        def __iter__(self):
            return iter(self._attr)

    d_0 = MockDict()

# Generated at 2022-06-25 17:26:09.922687
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-25 17:26:21.604860
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    # Arrange
    simple_namespace_0 = SimpleNamespace()
    simple_namespace_0.a = 1
    simple_namespace_0.b = 2

    simple_namespace_1 = SimpleNamespace()
    simple_namespace_1.a = 3
    simple_namespace_1.b = 4

    simple_namespace_2 = SimpleNamespace()
    simple_namespace_2.a = 5
    simple_namespace_2.b = 6

    simple_namespace_3 = SimpleNamespace()
    simple_namespace_3.a = 7
    simple_namespace_3.b = 8

    simple_namespace_4 = SimpleNamespace()
    simple_namespace_4.a = 9
    simple_namespace_4.b = 10

    simple_names

# Generated at 2022-06-25 17:26:27.812979
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    test_dict_0 = {'a': 1, 'b': 2, '_c': 3}
    var_0 = to_namedtuple(test_dict_0)
    assert var_0 == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)

    test_dict_1 = OrderedDict([('a', 1)])
    var_1 = to_namedtuple(test_dict_1)
    assert var_1 == namedtuple('NamedTuple', ['a'])(a=1)

    test_list_0 = [{'a': 1}]
    var_2 = to_namedtuple(test_list_0)

# Generated at 2022-06-25 17:26:36.727024
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyPep8Naming
    class Test_to_namedtuple_0:
        TEST_CASE = 0
        OBJ = None
        EXPECTED = None


    # noinspection PyPep8Naming
    class Test_to_namedtuple_1:
        TEST_CASE = 1
        OBJ = namedtuple('TestCase', ['TEST', 'CASE'])
        EXPECTED = namedtuple('NamedTuple', ['TEST', 'CASE'])


    # noinspection PyPep8Naming
    class Test_to_namedtuple_2:
        TEST_CASE = 2
        OBJ = namedtuple('TestCase', ['TEST', 'CASE'])(TEST=1, CASE=2)

# Generated at 2022-06-25 17:26:47.626074
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple([{}]) == [NamedTuple()]
    assert to_namedtuple([{'a': {}}]) == [NamedTuple(a=NamedTuple())]
    assert to_namedtuple([{'a': {'b': 1}}]) == [NamedTuple(a=NamedTuple(b=1))]
    assert to_namedtuple([0]) == [0]
    assert to_namedtuple([[]]) == [[]]
    assert to_namedtuple([(1,), (2,)]) == [NamedTuple(_0=1), NamedTuple(_0=2)]

# Generated at 2022-06-25 17:26:50.835144
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('unit test: {}'.format(__name__))
    test_case_0()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:27:02.790813
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    namedtuple_0 = to_namedtuple(dic)
    var_0 = namedtuple_0.a
    var_1 = namedtuple_0.b
    simple_namespace_0 = SimpleNamespace(a=var_0, **{'b': var_1})
    tuple_0 = (var_0, var_1)
    list_0 = [var_0, var_1]
    from collections import OrderedDict
    ordered_dic_0 = OrderedDict(a=1, b=2)
    namedtuple_1 = to_namedtuple(simple_namespace_0)
    assert namedtuple_0 == namedtuple_1


# Generated at 2022-06-25 17:27:14.750077
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = SimpleNamespace(a=1, b='2')
    var_0 = to_namedtuple(simple_namespace_0)
    var_1 = to_namedtuple(var_0)
    assert var_0 == NamedTuple(a=1, b='2')
    assert var_0 == var_1
    assert var_0.a == 1
    assert var_0.b == '2'
    dict_0 = dict(a=1, b='2')
    var_0 = to_namedtuple(dict_0)
    var_1 = to_namedtuple(var_0)
    assert var_0 == NamedTuple(a=1, b='2')
    assert var_0 == var_1
    assert var_0.a == 1
    assert var_0

# Generated at 2022-06-25 17:27:24.646795
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = None
    var_0 = to_namedtuple(simple_namespace_0)
    simple_namespace_0 = SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)
    simple_namespace_0.a = 1
    var_0 = to_namedtuple(simple_namespace_0)
    # var_0 = var_0.a  # Lint check
    simple_namespace_0.b = [1, ]
    var_0 = to_namedtuple(simple_namespace_0)
    expected = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=[1])
    assert var_0 == expected
    simple_namespace_0.c = {1: 2, }
    var_

# Generated at 2022-06-25 17:27:35.662204
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_namespace_0 = [
        {
            'zero': 0,
            'one': 1,
        },
        {
            'key': 2
        },
        {
            'key': 3,
        },
        {
            'key': 4,
            'other_key': 5,
        },
        {
            'key': 6,
            'other_key': 7,
        },
    ]
    var_0 = to_namedtuple(list_namespace_0)

# Generated at 2022-06-25 17:27:51.194496
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert 1 == 1
    test_case_0()


# Execute pytest-cov
if 'pytestcov' in locals().keys():
    pytestcov()
else:
    test_to_namedtuple()

# Generated at 2022-06-25 17:28:02.861304
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Verify that the correct exception is raised when an improper object
    # is passed to to_namedtuple
    try:
        # noinspection PyUnresolvedReferences
        to_namedtuple(3)
    except TypeError as e:
        assert str(e) == "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (int) 3"
    else:
        raise AssertionError(
            "The function to_namedtuple failed to raise the exception: "
            "'Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
            "got: (int) 3'")

    # Verify that a NamedTuple with keys that are not valid identifiers are
    # not converted
    a = {'a': 1, 'b': 1}
    b = to_named

# Generated at 2022-06-25 17:28:11.536007
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from types import SimpleNamespace
    from typing import NamedTuple, Tuple


    class _TestTuple0(NamedTuple):
        a: int
        b: str
        c: bool


    class _TestTuple1(NamedTuple):
        a: bool
        b: int
        c: str
        d: float
        e: _TestTuple0


    test_list_0: List[Any] = [1, 'a', True, [2, 3, False], _TestTuple0, (1, 2)]
    named_tuple_0 = to_namedtuple(test_list_0)
    assert isinstance(named_tuple_0, list)
    assert len(named_tuple_0) == len(test_list_0)
   

# Generated at 2022-06-25 17:28:15.619960
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = {
        'one': 1,
        'two': [2, 2, 2, 2],
        'three': {'a': 3, 'b': 3, 'c': 3},
    }

    # test class
    class TestClass:
        def __init__(self, value: int) -> None:
            self.value = value

        def __eq__(self, other: Any) -> bool:
            if isinstance(other, type(self)):
                return self.value == other.value
            return False

    simple_namespace_0 = SimpleNamespace(**data)
    out_0 = to_namedtuple(simple_namespace_0)
    assert out_0 == simple_namespace_0


# Generated at 2022-06-25 17:28:27.161503
# Unit test for function to_namedtuple
def test_to_namedtuple():

    config_0_0 = {
        'test_case_0': {
            'test_0': 'test_1'
        }
    }
    config_0_1 = {
        'test_case_0': {
            'test_0': 'test_0'
        }
    }
    config_0_2 = {
        'test_case_0': {
            'test_0': 'test_2'
        }
    }
    config_0_3 = {
        'test_case_0': {
            'test_0': 'test_3'
        }
    }
    config_0_4 = {
        'test_case_0': {
            'test_0': 'test_4'
        }
    }


# Generated at 2022-06-25 17:28:36.546311
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dic_0)

    dict_0 = {'a': {'b': 3}, 'c': 4}
    var_1 = to_namedtuple(dict_0)

    lis_0 = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 5, 'b': 6}]
    var_2 = to_namedtuple(lis_0)

    list_0 = [{'a': {'b': 1}, 'c': 2}, {'a': {'b': 3}, 'c': 4}]
    var_3 = to_namedtuple(list_0)


# Generated at 2022-06-25 17:28:48.175921
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # TODO: remove after testing is complete
    raise ValueError('Unit test is not implemented')

    dic_0 = OrderedDict((('a', 1), ('b', 2)))
    result_0 = to_namedtuple(dic_0)
    print(result_0)

    lst_0 = [
        1,
        'two',
        3,
        dic_0,
        'four',
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13,
        14,
        15,
        16,
        17,
        18,
        19,
        20,
    ]
    result_0 = to_namedtuple(lst_0)
    print(result_0)

    dic_

# Generated at 2022-06-25 17:28:54.266919
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = SimpleNamespace(a=1, b=2)
    var_0 = to_namedtuple(simple_namespace_0)
    assert isinstance(var_0, NamedTuple)

    ordered_dict_0 = OrderedDict(a=1, b=2, c=3)
    var_0 = to_namedtuple(ordered_dict_0)
    assert isinstance(var_0, NamedTuple)
    assert var_0.a == 1
    assert var_0.b == 2
    assert var_0.c == 3

    dic_0 = {'a': 1, 'b': 2, 'c': 3}
    var_0 = to_namedtuple(dic_0)
    assert isinstance(var_0, NamedTuple)
    assert var_

# Generated at 2022-06-25 17:29:01.184113
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Testing if the output from the function to_namedtuple is correct
    # noinspection PyTypeChecker
    list_0 = [
        None,
        True,
        1,
        1.0,
        'a'
    ]
    # noinspection PyTypeChecker
    dict_0 = {
        'a': None,
        'b': True,
        'c': 1,
        'd': 1.0,
        'e': 'a'
    }
    # noinspection PyTypeChecker
    dict_1 = OrderedDict({
        'a': None,
        'b': True,
        'c': 1,
        'd': 1.0,
        'e': 'a'
    })
    # noinspection PyTypeChecker

# Generated at 2022-06-25 17:29:11.928029
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest  # type: ignore
    from pytest import raises  # type: ignore

    simple_namespace_0 = SimpleNamespace(
        a=1,
        b=2,
    )
    var_0 = to_namedtuple(simple_namespace_0)
    assert type(var_0) == SimpleNamespace
    assert type(var_0) == SimpleNamespace

    dict_0 = {
        'a': 1,
        'b': 2,
    }
    var_0 = to_namedtuple(dict_0)
    assert type(var_0) == namedtuple
    assert type(var_0) == namedtuple

    assert raises(TypeError, test_case_0)

# Generated at 2022-06-25 17:29:41.571857
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0 = dict(data=1, list_0=[1, 2, (3, 4, 5), 6])
    dict_0['dict_0'] = dict(a=1, b=2, c=3)
    dict_0['dict_0']['dict_1'] = dict(a=1, b=2, c=3)
    try:
        to_namedtuple(dict_0)
    except TypeError as exc:
        exc
    dict_0['list_0'][2] = dict(a=1, b=2, c=3)
    dict_0['list_0'][2]['list_1'] = list(range(10))
    try:
        to_namedtuple(dict_0)
    except TypeError as exc:
        exc

# Generated at 2022-06-25 17:29:51.610020
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'c': 3, 'a': 1}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(OrderedDict(a=1, b=2, c=3)) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(OrderedDict(c=3, b=2, a=1)) == NamedTuple(c=3, b=2, a=1)

# Generated at 2022-06-25 17:29:59.754290
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from types import SimpleNamespace

    List0 = ['A', {'B': '2', 'C': 4}]
    tuple0 = ('A', {'B': '2', 'C': 4})
    tuple1 = ('A', {'B': '2', 'C': 4}, 'D', 'E', 'F')
    OrderedDict0 = OrderedDict([('A', {'B': '2', 'C': 4}), ('D', '4')])
    OrderedDict1 = OrderedDict([('A', [{'B': '2', 'C': 4}, 5])])

# Generated at 2022-06-25 17:30:11.503924
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dictionary_0 = {'key_0': 'value_0', 'key_1': 'value_1'}
    assert len(dictionary_0.keys()) == 2
    import sys
    if sys.version_info < (3, 7):
        assert dictionary_0.keys() == ['key_0', 'key_1']
    else:
        assert isinstance(dictionary_0.keys(), list)
        assert dictionary_0.keys() == ['key_0', 'key_1']
    assert len(dictionary_0.values()) == 2
    if sys.version_info < (3, 7):
        assert dictionary_0.values() == ['value_0', 'value_1']
    else:
        assert isinstance(dictionary_0.values(), list)

# Generated at 2022-06-25 17:30:20.418576
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d1 = {'a': 1, 'b': 2}
    assert to_namedtuple(d1) == namedtuple('NamedTuple', sorted(d1.keys()))(1, 2)
    d2 = OrderedDict(a=1, b=2)
    assert to_namedtuple(d2) == namedtuple('NamedTuple', d2.keys())(1, 2)
    l1 = [1, 2]
    assert to_namedtuple(l1) == [1, 2]

    obj = {'a': 1, 'b': {'c': 2}}
    t1 = to_namedtuple(obj)
    assert t1.a == 1
    assert t1.b.c == 2


# Generated at 2022-06-25 17:30:29.889181
# Unit test for function to_namedtuple
def test_to_namedtuple():
    if True:
        mapping_0 = {'a': 0, 'b': 1, 'c': 2}
        var_0 = to_namedtuple(mapping_0)
        assert isinstance(var_0, NamedTuple), f"{repr(var_0)} is not of type {repr(NamedTuple)}"
        assert getattr(var_0, 'a') == 0, f"Expected an attribute 'a' having value {repr(0)}, but got: {repr(getattr(var_0, 'a'))}"
        assert getattr(var_0, 'b') == 1, f"Expected an attribute 'b' having value {repr(1)}, but got: {repr(getattr(var_0, 'b'))}"

# Generated at 2022-06-25 17:30:36.421641
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)
    assert isinstance(var_0, namedtuple)

    dict_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dict_0)
    assert isinstance(var_0, namedtuple)

    list_0 = [{'a': 1}, {'b': 2}]
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0[0], namedtuple)
    assert var_0[0].a == 1
    assert var_0[1].b == 2


# Generated at 2022-06-25 17:30:44.363298
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test function inputtypes.
    simple_namespace_0 = SimpleNamespace(**{'a': 1, 'b': 2, 'c': 3})
    named_tuple_0 = to_namedtuple(simple_namespace_0)
    assert named_tuple_0.a == 1
    assert named_tuple_0.b == 2
    assert named_tuple_0.c == 3


if __name__ == '__main__':
    test_to_namedtuple()