

# Generated at 2022-06-25 17:21:02.907406
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case 0:
    obj = []
    expected = to_namedtuple(obj)
    assert isinstance(expected, tuple)
    assert isinstance(expected, NamedTuple)
    assert expected == []

    obj = {}
    expected = to_namedtuple(obj)
    assert isinstance(expected, tuple)
    assert isinstance(expected, NamedTuple)
    assert expected == ()

    obj = OrderedDict.fromkeys('abc')
    expected = to_namedtuple(obj)
    assert isinstance(expected, tuple)
    assert isinstance(expected, NamedTuple)
    assert expected == (None, None, None)
    assert expected._fields == ('a', 'b', 'c')

    obj = {'a': 1,
           'b': 2,
           'c': 3,
           }

# Generated at 2022-06-25 17:21:16.804586
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')

# Generated at 2022-06-25 17:21:29.717408
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [
        {
            'a': 1,
            'b': 2,
            'c': {
                'd': 2,
                'f': [1, 2, 3],
                'g': {'h': 1},
            },
        },
        {
            'x': 1,
            'y': 2,
            'z': {
                'd': 2,
                'f': [1, 2, 3],
                'g': {'h': 1},
            },
        },
    ]
    var_0 = to_namedtuple(list_0)
    # expected: True
    var_1 = len(var_0) == 2
    # expected: set
    var_2 = type(var_0)
    # expected: tuple

# Generated at 2022-06-25 17:21:42.201783
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Get function under test
    from flutils.namedtupleutils import to_namedtuple

    # Assert functions
    from flutils.namedtupleutils import (
        _to_namedtuple,
    )

    # Assert types
    from collections import (
        OrderedDict,
        defaultdict,
    )
    from collections.abc import (
        Mapping,
        Sequence,
    )
    from typing import (
        Any,
        cast,
    )

    # Assert test fixtures
    import pytest

    # Ensure attribute not set
    with pytest.raises(AttributeError):
        assert var_0

    # Test built-in types
    # Test empty dict
    dict_0 = dict()
    dict_1 = dict_0.copy()

# Generated at 2022-06-25 17:21:47.443922
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    res = to_namedtuple(dic)
    assert res == namedtuple('NamedTuple', 'a b')(1, 2)

    lis = [1, 2, 3]
    res = to_namedtuple(lis)
    assert res == [1, 2, 3]

    lis.append(['a', 1])
    res = to_namedtuple(lis)
    assert res == [1, 2, 3, ['a', 1]]

    lis.append({'a': 1, 'b': 2})
    res = to_namedtuple(lis)
    assert res == [1, 2, 3, ['a', 1], namedtuple('NamedTuple', 'a b')(1, 2)]


# Generated at 2022-06-25 17:22:00.047897
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [1, 2, 3]
    list_1 = to_namedtuple(list_0)
    assert list_0 == [1, 2, 3]
    assert list_1 == [1, 2, 3]

    list_0 = [1, 2, 3, None, 'dog', 'cat']
    list_1 = to_namedtuple(list_0)
    assert list_0 == [1, 2, 3, None, 'dog', 'cat']
    assert list_1 == [1, 2, 3, None, 'dog', 'cat']

    tuple_0 = (1, 2, 3, None, 'dog', 'cat')
    list_1 = to_namedtuple(tuple_0)
    assert tuple_0 == (1, 2, 3, None, 'dog', 'cat')
   

# Generated at 2022-06-25 17:22:02.147731
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True

# Generated at 2022-06-25 17:22:11.779747
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    dic = {'a': 1, 'b': 2}
    namedtuple_0 = to_namedtuple(dic)
    assert namedtuple_0.a == 1
    assert namedtuple_0.b == 2
    for i in range(10):
        dic['c'] = i
        namedtuple_0 = to_namedtuple(dic)
        assert namedtuple_0.c == i
    #
    list_0 = [
        1,
        2,
        {'a': 1, 'b': 2},
    ]
    var_0 = to_namedtuple(list_0)
    assert var_0[0] == 1
   

# Generated at 2022-06-25 17:22:25.130678
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}, {'e': 5, 'f': 6}]
    list_1 = [{'a': 1, 'b': 2}, [], {'c': 3, 'd': 4}, {'e': 5, 'f': 6}]
    list_2 = [[{'a': 1, 'b': 2}], [], {'c': 3, 'd': 4}, [{'e': 5, 'f': 6}]]
    dict_0 = {'a': 1, 'b': 2}
    dict_1 = {'a': 1, 'b': 2, '__repr__': None}

# Generated at 2022-06-25 17:22:32.558515
# Unit test for function to_namedtuple
def test_to_namedtuple():
    func = to_namedtuple
    # Partition the input domain
    # ensure the case list_0 is handled correctly
    list_0 = None
    assert func(list_0) is None

    # ensure the case list_1 is handled correctly
    list_1 = []
    assert func(list_1) == []

    # ensure the case list_2 is handled correctly
    list_2 = [0]
    assert func(list_2) == [0]

    # ensure the case list_3 is handled correctly
    list_3 = [None]
    assert func(list_3) == (None,)

    # ensure the case list_4 is handled correctly
    list_4 = ['', '', '']
    assert func(list_4) == ('', '', '')

    # ensure the case list_5 is handled correctly
    list

# Generated at 2022-06-25 17:22:46.271358
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # yes
    assert to_namedtuple({}) == cast(namedtuple, namedtuple())
    assert to_namedtuple({'a': 1, 'b': 2}) == cast(
        namedtuple, namedtuple(a=1, b=2)
    )
    assert to_namedtuple({'b': 2, 'a': 1}) == cast(
        namedtuple, namedtuple(a=1, b=2)
    )
    assert to_namedtuple([]) == []
    assert to_namedtuple([1, 2]) == [1, 2]

# Generated at 2022-06-25 17:23:00.549919
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    NamedTuple_0 = to_namedtuple(dic)
    assert NamedTuple_0 == (2, 3)
#
#
# from collections import namedtuple
#
#
# # noinspection PyShadowingNames
# def to_namedtuple(obj: Any, _started: bool = False) -> Any:
#     if _started is False:
#         raise TypeError(
#             "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
#             "got: (%r) %s" % (type(obj).__name__, obj)
#         )
#     if isinstance(obj, Mapping):
#         return _to_namedtuple_dict(obj)
#     if isinstance(obj,

# Generated at 2022-06-25 17:23:06.833966
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # called for object that is not a list and not a dict
    assert to_namedtuple(None) == None

    # called for object that is not a list and not a dict
    assert to_namedtuple('abc') == 'abc'

    # called for object that is not a list and not a dict
    assert to_namedtuple('1') == '1'

    # called for object that is not a list and not a dict
    assert to_namedtuple(1) == 1

    # called for object that is not a list and not a dict
    assert to_namedtuple(1.1) == 1.1

    # called for namedtuple
    assert to_namedtuple(namedtuple('_', 'a b')(1, 2)) == namedtuple('NamedTuple', 'a b')(1, 2)



# Generated at 2022-06-25 17:23:20.424341
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # ensure NamedTuple is returned
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    # ensure that _XXX are filtered out
    dic = {'_a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(b=2)
    dic = {'a': 1, '_b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1)
    dic = {'_a': 1, '_b': 2}
    assert to_namedtuple(dic) == NamedTuple()
    # ensure basic list is returned
    dic = {'a': 1, 'b': 2}
    assert to_

# Generated at 2022-06-25 17:23:25.141585
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dictionary_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dictionary_0)
    assert var_0.a == 1
    assert var_0.b == 2


if __name__ == '__main__':
    test_case_0()
    test_to_namedtuple()

# Generated at 2022-06-25 17:23:34.182653
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = []
    list_0.append(None)
    list_0.append(None)
    var_0 = to_namedtuple(list_0)
    assert (var_0 is not None)
    assert (var_0 == [None, None])
    dic_0 = {}
    list_0 = []
    list_0.append(None)
    list_0.append(None)
    dic_0['a'] = list_0
    dic_1 = {}
    dic_0['b'] = dic_1
    dic_1['c'] = None
    var_0 = to_namedtuple(dic_0)
    assert (var_0 is not None)
    assert (var_0.a == [None, None])

# Generated at 2022-06-25 17:23:45.595595
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:23:59.123121
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test type str
    var_0 = to_namedtuple('string')
    assert isinstance(var_0, str)

    # Test type dict
    dict_0 = {'a': 1, 'b': 2}
    var_1 = to_namedtuple(dict_0)
    assert isinstance(var_1, NamedTuple)

    # Test type dict
    dict_1 = {'a': {'b': 2, 'c': 3}, 'd': 4}
    var_2 = to_namedtuple(dict_1)
    assert isinstance(var_2, NamedTuple)

    # Test type dict
    dict_2 = {'a': [1, 2, 3], 'b': [4, 5], 'c': 6}
    var_3 = to_namedtuple(dict_2)


# Generated at 2022-06-25 17:24:05.554628
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pickle  # noqa: E402

    list_0 = [{'a': 1}, {'b': 2}]
    var_0 = to_namedtuple(list_0)
    nt: List[Any] = var_0
    assert nt[0].a == 1
    assert nt[1].b == 2
    assert pickle.loads(pickle.dumps(nt)) == nt

    list_1 = [{'a': 1, 'b': 2}]
    var_1 = to_namedtuple(list_1)
    nt: List[Any] = var_1
    assert nt[0].a == 1
    assert nt[0].b == 2
    assert pickle.loads(pickle.dumps(nt)) == nt


# Generated at 2022-06-25 17:24:13.499972
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import main, TestCase
    from unittest.mock import Mock, MagicMock, patch

    class Case0(TestCase):
        # noinspection PyTypeChecker
        @patch('flutils.namedtupleutils.to_namedtuple')
        def test_to_namedtuple_0(self, mocked: Mock):
            test_case_0()
            mocked.assert_called_once()

    class Case1(TestCase):
        def test_to_namedtuple_0(self):
            test_case_0()

    class Case2(TestCase):
        def test_to_namedtuple_0(self):
            test_case_0()

    class Case3(TestCase):
        def test_to_namedtuple_0(self):
            test_case_0()



# Generated at 2022-06-25 17:24:26.771894
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    var_0: NamedTuple = to_namedtuple(dic)
    assert var_0.a == 1
    assert var_0.b == 2
    var_1: dict = {'a': 1, 'b': 2}
    var_2: str = to_namedtuple(var_1)
    assert var_2 == str(var_1)
    var_3: dict = {'a': 1, 'b': 2}
    var_4: str = to_namedtuple(var_3)
    assert var_4 == str(var_3)
    var_5: dict = {'a': 1, 'b': 2}
    var_6: str = to_namedtuple(var_5)
    assert var_6 == str

# Generated at 2022-06-25 17:24:40.662653
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(None) is None, 'None needs to be None'
    assert to_namedtuple(1) == 1, 'Non-convertable needs to be returned'
    assert to_namedtuple('1') == '1', 'Non-convertable needs to be returned'
    assert to_namedtuple(1.1) == 1.1, 'Non-convertable needs to be returned'

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3], 'List needs to unchanged'
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3), 'Tuple needs to unchanged'

    # ---------------------------------------------------------------
    # List or tuple
    # ---------------------------------------------------------------

# Generated at 2022-06-25 17:24:47.384715
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dct_0 = {'a': 1, 'b': 2}
    nt_0 = to_namedtuple(dct_0)
    assert nt_0.a == 1
    assert nt_0.b == 2

    list_0 = [
        'a',
        None,
        [
            {'a': 'a', 'b': 'b'},
            {'1': '1', '2': '2'},
        ],
        {
            'a': 'a',
            'b': 'b',
        },
    ]
    out_0 = to_namedtuple(list_0)
    assert isinstance(out_0, list)

    od_0 = OrderedDict(
        (
            ('a', 1),
            ('b', 2)
        )
    )


# Generated at 2022-06-25 17:24:59.506362
# Unit test for function to_namedtuple
def test_to_namedtuple():

    class tester(object):
        def test_to_namedtuple_0(self):
            list_0 = [3.14, 'spam', ['ham', 'eggs'], 1, 2.7]
            var_0 = to_namedtuple(list_0)
            assert len(var_0) == 5, \
                'Failed to convert all of the items in the list'
            assert str(var_0[2]) == "NamedTuple(0='ham', 1='eggs')", \
                'Failed to convert the list within the list'
            assert str(var_0[0]) == '3.14', \
                'Failed to convert the float to a NamedTuple'
            assert var_0[3] == 1, \
                'Failed to convert the int to a NamedTuple'


# Generated at 2022-06-25 17:25:02.979844
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:25:15.701608
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]]
    list_1 = to_namedtuple(list_0)
    assert list_1[0].NamedTuple[0] == 1
    assert list_1[1].NamedTuple[1] == 7
    assert list_1[2].NamedTuple[2] == 11
    assert list_1[3].NamedTuple[3] == 16
    
    list_0 = [1, 2, 3]
    list_1 = to_namedtuple(list_0)
    assert list_1[0] == 1
    assert list_1[1] == 2
    assert list_1[2] == 3
    
    dict_

# Generated at 2022-06-25 17:25:25.108616
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # These are used in the tests.
    dict_0: dict = {'astring': 'astring', 'anint': 1, 'afloat': 1.1, 'a_list': [], 'a_dict': {}}
    odict_0 = OrderedDict(dict_0.items())
    dict_1: dict = {'astring': 'astring', 'anint': 1, 'afloat': 1.1, 'a_list': [], 'a_dict': {}}
    dict_1['a_list'] = ['alist element']
    dict_1['a_dict'] = {'adict key': {}}
    dict_2: dict = {'astring': 'astring', 'anint': 1, 'afloat': 1.1, 'a_list': [], 'a_dict': {}}

# Generated at 2022-06-25 17:25:38.182487
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Unit test for function to_namedtuple
    dic = {
        'a': 1,
        'b': 2,
    }
    oup = to_namedtuple(dic)
    assert hasattr(oup, 'a')
    assert hasattr(oup, 'b')
    assert oup.a == 1
    assert oup.b == 2
    assert len(oup) == 2
    assert 'a' in oup
    assert 'b' in oup

    dic = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
        },
    }
    oup = to_namedtuple(dic)
    assert hasattr(oup, 'a')
    assert hasattr(oup, 'b')
   

# Generated at 2022-06-25 17:25:52.009912
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    import types
    import unittest

    class TestClass(unittest.TestCase):

        def test_to_namedtuple_0(self):
            a = {'a': 1, 'b': 2}
            var_0 = to_namedtuple(a)
            self.assertEqual(var_0.a, 1)
            self.assertEqual(var_0.b, 2)

        def test_to_namedtuple_1(self):
            a = {'a': 1, 'b': 2}
            var_0 = to_namedtuple(a)
            self.assertEqual(var_0.a, 1)
            self.assertEqual(var_0.b, 2)
            self.assertEqual(var_0[0], 1)

# Generated at 2022-06-25 17:25:59.227386
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        NamedTuple(a=1, b=2)
    assert to_namedtuple(dict(a=1, b=2, c=3)) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple('abc') == 'abc'
    assert to_namedtuple(tuple('abc')) == NamedTuple(a='a', b='b', c='c')
    assert to_namedtuple(list('abc')) == [NamedTuple(a='a', b='b', c='c')]
    ord_dic

# Generated at 2022-06-25 17:26:21.500285
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    dic_1 = {'b': 2, 'a': 1}
    var_0 = to_namedtuple(dic)
    test_case_0()


if __name__ == '__main__':
    list_0 = None
    test_case_0()
    test_to_namedtuple()

# Generated at 2022-06-25 17:26:27.766523
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(list_0)
    assert var_0 == NamedTuple(a=1, b=2), var_0
    dic_0 = {'a': 1, 'b': 2, 'c': '3'}
    var_1 = to_namedtuple(dic_0)
    assert var_1 == NamedTuple(a=1, b=2, c='3'), var_1
    list_1 = [1, 2, 3, 4]
    var_2 = to_namedtuple(list_1)
    assert var_2 == [1, 2, 3, 4], var_2
    list_2 = list(range(10, 20))

# Generated at 2022-06-25 17:26:31.951864
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Test ``to_namedtuple`` function.
    """
    list_0 = [0, 1, 2]
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0, list)
    assert len(var_0) == 3
    assert var_0[0] == 0
    assert var_0[1] == 1
    assert var_0[2] == 2
    assert isinstance(var_0[0], int)
    assert isinstance(var_0[1], int)
    assert isinstance(var_0[2], int)

    list_0 = [0, [0, 1, 2], 2]
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0, list)
    assert len(var_0) == 3

# Generated at 2022-06-25 17:26:38.451726
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert test_case_0() == None, 'expected None -> received {type(test_case_0().__name__)}'
    # TODO complete unit test
    # assert _test_to_namedtuple() == None, 'assert _test_to_namedtuple'

if __name__ == '__main__':
    from flutils import LoggingRedirector
    import logging
    import unittest


    class TestNamedTupleUtils(unittest.TestCase):

        def setUp(self):
            self.rdr = LoggingRedirector()
            self.rdr.start()

        def tearDown(self):
            self.rdr.stop()

        def test_to_namedtuple(self):
            test_case_0()
            # TODO complete unit test
            # assert _test

# Generated at 2022-06-25 17:26:41.563027
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True


if __name__ == '__main__':
    test_to_namedtuple()
    print('all tests OK')

# Generated at 2022-06-25 17:26:50.536520
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_list_0: List[Any] = [
        [
            {'a': 1, 'b': 2},
            [{'a': 1, 'b': 2}],
            {'a': 1, 'b': 2},
        ],
        [
            [
                {'a': 1, 'b': 2},
                {'a': 1, 'b': 2},
            ],
            {'a': 1, 'b': 2},
        ],
        {'a': 1, 'b': 2},
    ]

# Generated at 2022-06-25 17:27:02.569268
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test case #0:
    list_0 = None
    var_0 = to_namedtuple(list_0)
    try:
        assert var_0 == None
    except AssertionError:
        print('Expected:', None)
        print('Actual:  ', var_0)

    # Test case #1:
    list_1 = 1
    var_1 = to_namedtuple(list_1)
    try:
        assert var_1 == 1
    except AssertionError:
        print('Expected:', 1)
        print('Actual:  ', var_1)

    # Test case #2:
    dic_0 = {'a': 1, 'b': 2}
    var_2 = to_namedtuple(dic_0)

# Generated at 2022-06-25 17:27:14.565926
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Given an empty dictionary
    dictionary = {}
    # When we convert the dictionary to a namedtuple
    namedtuple = to_namedtuple(dictionary)
    # Then we should have a NamedTuple with no attributes
    assert hasattr(namedtuple, '_fields') and not namedtuple._fields
    # Given two keys with valid and invalid identifiers
    dictionary = {'a': {'b': 2}, 'c': 3, '_d': 4}
    # When we convert the dictionary to a namedtuple
    namedtuple = to_namedtuple(dictionary)
    # Then we should have a NamedTuple with one attribute
    assert hasattr(namedtuple, '_fields') and len(namedtuple._fields) == 1
    # And we should have the valid identifier
    assert 'a' in namedtuple._fields

# Generated at 2022-06-25 17:27:24.478666
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import mock
    from .fixtures.namedtupleutils import (
        case1,
        case2,
    )
    with mock.patch.object(
        sys,
        'exit',
        side_effect=testcase_helpers.exit_exception
    ):
        with pytest.raises(testcase_helpers.ExitException):
            test_case_0()

    def case_0():
        assert to_namedtuple(case1.input_0) == case1.expected_0  # noqa: E501
        assert to_namedtuple(case1.input_1) == case1.expected_1  # noqa: E501
        assert to_namedtuple(case1.input_2) == case1.expected_2  # noqa: E501
        assert to_named

# Generated at 2022-06-25 17:27:35.624397
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test base error
    try:
        to_namedtuple(None)
    except TypeError:
        pass
    else:
        raise AssertionError('Error: Failed test')

    # Test empty list
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert len(var_0) == 0

    # Test empty dict
    dict_0 = {}
    var_1 = to_namedtuple(dict_0)
    assert len(var_1._fields) == 0

    # Test simple dict
    dict_0 = {'a': 1, 'b': 2, 'c': 3, 'x': 'z'}
    var_2 = to_namedtuple(dict_0)
    for itm in var_2._fields:
        assert itm in dict_0

# Generated at 2022-06-25 17:27:55.682067
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Assert that the class has the right attributes
    assert hasattr(to_namedtuple, '__call__')
    assert hasattr(to_namedtuple, '__annotations__')
    assert hasattr(to_namedtuple, '__doc__')
    assert hasattr(to_namedtuple, '__module__')
    assert hasattr(to_namedtuple, '__name__')
    assert hasattr(to_namedtuple, '__qualname__')
    assert hasattr(to_namedtuple, '__dict__')

    # Set the arguments for the test
    arg = {'a': 1, 'b': 2}

    # Run the test
    out = to_namedtuple(arg)

    # Verify the output
    assert out == arg



# Generated at 2022-06-25 17:28:06.091039
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic = {
        'c': 3,
        'b': 2,
        'a': 1,
    }
    # noinspection PyTypeChecker
    expected = namedtuple(
        'NamedTuple',
        (
            'a',
            'b',
            'c',
        )
    )
    # noinspection PyTypeChecker
    expected = expected(
        1,
        2,
        3
    )
    actual = to_namedtuple(dic)
    assert actual == expected

    list_0 = [dic, dic]
    var_0 = to_namedtuple(list_0)
    expected = [expected, expected]
    assert var_0 == expected


# Generated at 2022-06-25 17:28:13.711464
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import datetime
    from typing import Dict, List, Optional, Tuple

    _AllowedTypes = Union[
        List,
        Tuple,
        Mapping,
        NamedTuple,
        SimpleNamespace,
    ]

    _OutType = Union[
        List,
        Tuple,
        NamedTuple,
    ]

    class _TestCase(NamedTuple):
        data: _AllowedTypes
        out: _OutType

    class _TestCaseDict(NamedTuple):
        data: Mapping
        out: NamedTuple

    class _ExpectError(NamedTuple):
        data: _AllowedTypes
        err_type: Optional[BaseException]


# Generated at 2022-06-25 17:28:25.342452
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Setup
    list_1 = []
    tup_1 = ()
    list_2 = ["test1", "test2"]
    tup_2 = ("test1", "test2")
    namedtup_1 = namedtuple("TestNamedtup1", ["one", "two"])(1, 2)
    list_3 = [1, 2]
    tup_3 = (1, 2)
    namedtup_2 = namedtuple("TestNamedtup2", ["one", "two"])("test1", "test2")
    test_dict_1 = {"one": 1, "two": 2}
    test_dict_2 = {"one": "test1", "two": "test2"}

# Generated at 2022-06-25 17:28:35.196931
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pformat
    list_0 = [
        {
            'a': 1,
            'b': 2,
            'd': {
                'a': 3,
                'b': 4
            }
        },
        {
            'a': 5,
            'b': 6,
            'd': {
                'a': 7,
                'b': 8
            }
        },
        {
            'a': 9,
            'b': 0,
            'd': {
                'a': 1,
                'b': 2
            }
        }
    ]

# Generated at 2022-06-25 17:28:40.698003
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0: dict = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dict_0)

    dict_1: dict = {'b': 2, 'a': 1}
    var_1 = to_namedtuple(dict_1)

    list_0 = [dict_0, dict_1]
    var_2 = to_namedtuple(list_0)

    list_1 = [var_0, var_1]
    var_3 = to_namedtuple(list_1)


if __name__ == '__main__':
    to_namedtuple(None)

# Generated at 2022-06-25 17:28:50.894581
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit Tests for function to_namedtuple.
    """
    from collections import OrderedDict
    from types import SimpleNamespace

    list_0 = ['abc', 1, 2.4, True, None]
    assert to_namedtuple(list_0) == list_0, \
        'Failed to return `list` as `list`.'

    tuple_0 = ('abc', 1, 2.4, True, None)
    assert to_namedtuple(tuple_0) == tuple_0, \
        'Failed to return `tuple` as `tuple`.'

    tuple_0 = ('abc', 1, 2.4, True, None)
    assert to_namedtuple(tuple_0) == tuple_0, \
        'Failed to return `tuple` as `tuple`.'

# Generated at 2022-06-25 17:28:59.051316
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dictionary = {'a': 1, 'b': 2}
    out_0 = to_namedtuple(dictionary)
    try:
        assert out_0.a == 1
        assert out_0.b == 2
    except AttributeError:
        assert False
    try:
        assert out_0[0] == 1
        assert out_0[1] == 2
    except (AttributeError, TypeError):
        assert False
    dictionary_0 = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2}}
    out_0 = to_namedtuple(dictionary_0)

# Generated at 2022-06-25 17:29:06.808076
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_mapping = {
        'val_0': 0,
        'val_1': 1,
        'val_2': 2,
        'val_3': 3,
        'val_4': 4,
        'val_5': 5,
        'val_6': 6,
        'val_7': 7,
        'val_8': 8,
        'val_9': 9,
    }
    test_namedtuple_0 = to_namedtuple(test_mapping)


# Generated at 2022-06-25 17:29:15.324412
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    nt_0 = to_namedtuple(dic_0)
    assert nt_0.a == 1
    assert nt_0.b == 2

    tup_0 = (1, 2)
    nt_0 = to_namedtuple(tup_0)
    assert nt_0[0] == 1
    assert nt_0[1] == 2

    dic_0 = {'a': 1, 'b': 2}
    list_0 = [dic_0, dic_0, {'c': 3, 'd': 4}]
    nt_0 = to_namedtuple(list_0)
    assert type(nt_0) == list
    assert type(nt_0[0]) == Named

# Generated at 2022-06-25 17:29:52.426405
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    namedtup = NamedTuple(a=1, b=2)
    list_0 = [dic, namedtup]
    list_1 = to_namedtuple(list_0)
    assert isinstance(list_1, list)
    assert isinstance(list_1[0], NamedTuple)
    assert isinstance(list_1[1], NamedTuple)
    assert list_1[0] == namedtup
    assert list_1[1] == namedtup
    dict_0 = {'a': 1, 'b': 2}
    namedtup_0 = NamedTuple(a=1, b=2)
    dict_1 = OrderedDict((('a', 1), ('b', 2)))

# Generated at 2022-06-25 17:29:55.323945
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    try:
        list_0 = None
        var_0 = to_namedtuple(list_0)
    except Exception:
        pytest.fail("Unable to convert list_0 to namedtuple.")
    try:
        list_0 = None
        var_0 = to_namedtuple(list_0)
    except Exception:
        pytest.fail("Unable to convert list_0 to namedtuple.")



# Generated at 2022-06-25 17:30:04.271479
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = None
    list_1 = [list_0]
    mapped = to_namedtuple(list_1)
    assert mapped[0] is list_0

    list_0 = {'a': 'apple', 'b': 'banana'}
    list_1 = [1, 2, 3, list_0]
    mapped = to_namedtuple(list_1)
    assert mapped[3].a == 'apple'

    list_0 = {'a': 'apple', 'b': 'banana'}
    list_1 = [1, 2, 3, list_0]
    mapped = to_namedtuple(list_1)
    assert mapped[3].a == 'apple'

    list_0 = {'a': 'apple', 'b': 'banana'}

# Generated at 2022-06-25 17:30:14.901414
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # simple dict
    dic = {'a': 1, 'b': 2}
    nt_dic = to_namedtuple(dic)
    assert nt_dic.a == 1
    assert nt_dic.b == 2

    # simple dict converted to list
    list_dic = list(dic.items())
    nt_list_dic = to_namedtuple(list_dic)
    assert nt_list_dic.a == dic['a']
    assert nt_list_dic.b == dic['b']

    # simple dict converted to list, then tuple
    tuple_list_dic = tuple(list_dic)
    nt_tuple_list_dic = to_namedtuple(tuple_list_dic)
    assert nt

# Generated at 2022-06-25 17:30:25.257206
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:30:33.438850
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0 = {'a': 1, 'b': 2}
    val_0 = to_namedtuple(dict_0)
    assert val_0.a == 1
    assert val_0.b == 2

    dict_1 = OrderedDict([('a', 1), ('b', 2)])
    val_1 = to_namedtuple(dict_1)
    assert val_1.a == 1
    assert val_1.b == 2

    dict_2 = {(1, 2): 3}
    val_2 = to_namedtuple(dict_2)
    assert val_2.a == 3

    dict_3 = {1: 2, 3: 4}
    val_3 = to_namedtuple(dict_3)
    assert val_3.a == 2
    assert val_3.b

# Generated at 2022-06-25 17:30:44.324006
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    list_0 = OrderedDict([('a', 100), ('b', 200)])
    OrderedTuple = namedtuple('OrderedTuple', list(list_0.keys()))
    var_0 = to_namedtuple(list_0)
    var_1 = isinstance(var_0, OrderedTuple)
    assert var_1
    assert var_0 == OrderedTuple(a=100, b=200)
    list_0 = {'a': 100, 'b': 200}
    var_0 = to_namedtuple(list_0)
    var_1 = isinstance(var_0, NamedTuple)
    assert var_1
    assert var_0 == NamedTuple(a=100, b=200)


# Generated at 2022-06-25 17:30:52.161402
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj_0 = [OrderedDict({'a': 1, 'b': 2})]
    val_0 = to_namedtuple(obj_0)
    assert isinstance(val_0, list)
    assert isinstance(val_0[0], namedtuple)
    assert val_0[0].a == 1
    assert val_0[0].b == 2

    obj_1 = [1, 2, 3, 4]
    val_1 = to_namedtuple(obj_1)
    assert isinstance(val_1, list)
    assert list(val_1) == obj_1

    obj_2 = namedtuple('NamedTuple', 'a, b')(1, 2)
    val_2 = to_namedtuple(obj_2)