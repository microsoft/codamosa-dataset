

# Generated at 2022-06-25 17:20:58.258900
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    tup = (1, 2, 3)
    dic_0 = {'a': 1, 'b': 2, 'c': (1, 2, 3)}
    dic_1 = {'a': 1, 'b': 2, 'c': (1, 2, 3, {'a': 1, 'b': 2})}
    odic = OrderedDict(dic_0)
    ns_0 = cast(SimpleNamespace, SimpleNamespace(**dic))
    ns_1 = cast(SimpleNamespace, SimpleNamespace(**dic_0))
    ns_2 = cast(SimpleNamespace, SimpleNamespace(**dic_1))

    # Mapping
    var_0 = to_namedtuple(dic)
    var_1

# Generated at 2022-06-25 17:21:09.150785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    dict_0 = dict(a=0, b=1)
    dict_1 = dict(b=0, c=1)
    namedtuple_0 = to_namedtuple(dict_0)
    namedtuple_1 = to_namedtuple(dict_1)
    assert isinstance(namedtuple_0, tuple)
    assert isinstance(namedtuple_1, tuple)
    assert namedtuple_0.a == dict_0['a']
    assert namedtuple_1.c == dict_1['c']


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:21:17.636262
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Unit test for to_namedtuple, type None
    # Store value of original
    orig_list_0 = []
    orig_list_1 = list()
    orig_list_2 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    orig_list_3 = [None, False, True, 0, 1, 2.0, 3.141592653589793,
                   'hello', 'world', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]]
    # Test for "from" option = 0

# Generated at 2022-06-25 17:21:19.104424
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()

# Generated at 2022-06-25 17:21:27.100117
# Unit test for function to_namedtuple
def test_to_namedtuple():
    nt_0 = to_namedtuple([])
    assert nt_0.__class__.__name__ == 'NamedTuple'
    assert nt_0 == NamedTuple()

    nt_1 = to_namedtuple({'a': 1, 'b': 2})
    assert nt_1.__class__.__name__ == 'NamedTuple'
    assert nt_1 == NamedTuple(a=1, b=2)


# Generated at 2022-06-25 17:21:40.256967
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    # Values are None
    # Value is list
    list_0 = [None]
    var_0 = to_namedtuple(list_0)
    list_0 = [None, None]
    var_0 = to_namedtuple(list_0)
    list_0 = [None, 1, None, None]
    var_0 = to_namedtuple(list_0)
    # Value is dict
    dict_0 = {}
    var_0 = to_namedtuple(dict_0)
    dict_0 = {'a': None}
    var_0 = to_namedtuple(dict_0)
    dict_0 = {'a': 1, 'b': 2}
   

# Generated at 2022-06-25 17:21:44.222188
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()


# Service entry point

# Generated at 2022-06-25 17:21:55.100905
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = OrderedDict({'a': 1, 'b': 2})
    list_1 = {'a': 1, 'b': 2}
    list_2 = [1, 2, 3]
    list_3 = 'test'
    list_4 = SimpleNamespace(a=1, b=2)
    var_0 = to_namedtuple(list_0)
    var_1 = to_namedtuple(list_1)
    var_2 = to_namedtuple(list_2)
    var_3 = to_namedtuple(list_3)
    var_4 = to_namedtuple(list_4)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:22:07.438801
# Unit test for function to_namedtuple
def test_to_namedtuple():
    try:
        to_namedtuple('hello')
    except TypeError:
        pass
    else:
        raise Exception('Expected a TypeError to be raised.')

    dic = {}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    odic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(odic)
    assert out.a == 1
    assert out.b == 2


# Generated at 2022-06-25 17:22:19.929675
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import io
    import flutils.namedtupleutils

    if sys.__stdout__.encoding == 'UTF-8':
        result_str = "NamedTuple(a=1, b=2)\n"
    else:  # pragma: no cover
        result_str = "NamedTuple(a=1, b=2)\r\n"

    dic = {'a': 1, 'b': 2}
    out = flutils.namedtupleutils.to_namedtuple(dic)

    # noinspection PyUnresolvedReferences
    stdout = sys.stdout
    # noinspection PyUnresolvedReferences
    sys.stdout = buffer = io.StringIO()
    print(out)
    # noinspection PyUnresolvedReferences
    sys.stdout = std

# Generated at 2022-06-25 17:22:31.655595
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # def test_case_01():
    dic_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dic_0)
    assert var_0.a == 1
    assert var_0.b == 2

    # def test_case_02():
    dic_0 = {'d': 3, 'b': 2, 'a': 1}
    var_0 = to_namedtuple(dic_0)
    assert var_0.a == 1
    assert var_0.b == 2
    assert var_0.d == 3

    # def test_case_03():
    dic_0 = OrderedDict()
    dic_0['d'] = 3
    dic_0['b'] = 2
    dic_0['a'] = 1

# Generated at 2022-06-25 17:22:43.881046
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Function Name:  test_to_namedtuple()
    Parameters:     None
    Returns:        None
    """
    a, b, c = 1, 2, 3
    list_0 = [a, b, c]
    ordered_dict_0 = OrderedDict()
    ordered_dict_0['a'] = a
    ordered_dict_0['b'] = b
    ordered_dict_0['c'] = c
    dict_0 = {'a': a, 'b': b, 'c': c}
    namespace_0 = SimpleNamespace()
    namespace_0.a = a
    namespace_0.b = b
    namespace_0.c = c
    tuple_0 = (a, b, c)

# Generated at 2022-06-25 17:23:00.484231
# Unit test for function to_namedtuple
def test_to_namedtuple():
    for case in [
        [
            {
                'a': 'b',
                'c': 'd',
            },
            'ab'
        ],
        [
            {
                'a': 'b',
                'c': 'd',
            },
            'ab',
            {
                'e': 'f',
                'g': 'h',
            },
            'hi',
            'bob',
            {
                'a': {
                    'b': 3,
                    'c': 5,
                },
                'c': {
                    'e': 1,
                    'f': 3,
                }
            }
        ],
    ]:
        case[0] = to_namedtuple(case[0])
        case[1] = to_namedtuple(case[1])

# Generated at 2022-06-25 17:23:15.342548
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0: Mapping[str, int] = {'c': 2, 'b': 3, 'd': 4, 'a': 5}
    namedtuple_0: NamedTuple[int, int, int, int] = to_namedtuple(dic_0)
    assert namedtuple_0.b == 3
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert type(var_0) is list
    assert not var_0
    dict_0 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    namedtuple_1: NamedTuple[int, int, int, int] = _to_namedtuple(dict_0)
    assert namedtuple_1.a == 1
    dic_0: Ord

# Generated at 2022-06-25 17:23:27.311675
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple('') == ''
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple('a b c') == 'a b c'

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, 3: 3, 4: 4}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')

# Generated at 2022-06-25 17:23:33.008710
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing to_namedtuple...', end='')
    import json
    import sys

    dic_0 = {
        'a': 1,
        'b': 2,
    }
    nt_0 = to_namedtuple(dic_0)
    assert isinstance(nt_0, NamedTuple)
    assert isinstance(nt_0, tuple)
    assert isinstance(nt_0, SimpleNamespace)
    assert isinstance(nt_0, Mapping)
    assert hasattr(nt_0, 'a')
    assert hasattr(nt_0, 'b')
    assert nt_0.a == 1
    assert nt_0.b == 2
    assert getattr(nt_0, 'a') == 1


# Generated at 2022-06-25 17:23:41.796160
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Case 0
    test_c0_a = Tuple[int]([1, 2, 3])
    test_c0_b = to_namedtuple(test_c0_a)
    assert test_c0_b == (1, 2, 3)
    test_c0_a = List[int]([1, 2, 3])
    test_c0_b = to_namedtuple(test_c0_a)
    assert test_c0_b == [1, 2, 3]
    test_c0_a = (1, 2, 3)
    test_c0_b = to_namedtuple(test_c0_a)
    assert test_c0_b == (1, 2, 3)
    test_c0_a = [1, 2, 3]
    test_c

# Generated at 2022-06-25 17:23:50.809056
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    assert to_namedtuple(dic_0) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    dic_1 = {'a': 1, 'b': {'c': 3, 'd': 4}}
    assert to_namedtuple(dic_1) == namedtuple('NamedTuple', ('a', 'b'))(1,
                                                                        namedtuple('NamedTuple', (
                                                                            'c', 'd'))(3, 4))
    ordered_dict_0 = OrderedDict()
    ordered_dict_0['a'] = 1
    ordered_dict_0['b'] = 2
    assert to_namedtuple(ordered_dict_0)

# Generated at 2022-06-25 17:23:57.398168
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple."""
    import sys
    import unittest

    class ToNamedTupleTestCase(unittest.TestCase):

        def setUp(self) -> None:
            self.list_0 = []
            self.list_1 = ['a']
            self.list_2 = ['a', {'b': 'B'}]
            self.list_3 = ['a', {'b': 'B'}, {'c': {'d': 'D'}}]
            self.list_4 = ['a', {'b': 'B'}, {'c': {'d': 'D'}}, ['e', 'f']]

# Generated at 2022-06-25 17:24:03.885453
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namespaceutils import (
        filter_namespace,
        get_attribute_names,
        namespace_to_dict,
        namespace_to_odict,
    )
    from flutils.namedtupleutils import (
        to_key_tuple,
        to_namedtuple,
    )

    ns0 = SimpleNamespace(a=1, b=2, c=3, d=4)
    assert get_attribute_names(ns0) == ['a', 'b', 'c', 'd']
    assert namespace_to_dict(ns0) == {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-25 17:24:15.200149
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tup_0 = (
        'a',
        'b',
        'c'
    )
    var_0 = to_namedtuple(tup_0)
    assert var_0 == NamedTuple(a='a', b='b', c='c')

    var_1 = to_namedtuple({'a': 1, 'b': 2, 'c': 3})
    assert var_1 == NamedTuple(a=1, b=2, c=3)

    from collections import OrderedDict
    var_2 = to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)]))
    assert var_2 == NamedTuple(a=1, b=2, c=3)


# Generated at 2022-06-25 17:24:26.048529
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0 = dict(
        a=1,
        b=2,
        c=dict(x=10, y=20, z=30)
    )
    new_dict = to_namedtuple(dict_0)
    assert new_dict == dict_0
    dict_1 = dict(
        a=1,
        b=2,
    )
    new_dict = to_namedtuple(dict_1)
    assert new_dict == dict_1

# Generated at 2022-06-25 17:24:40.642737
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple
    """

    dic_0: dict = {'a': 1, 'b': 2}
    nt_0 = to_namedtuple(dic_0)

    dic_1: dict = {'a': 1, 'b': 2, '_c': 3, '_c_': 4, 'C': 5, '-c': 6}
    nt_1 = to_namedtuple(dic_1)

    dic_2: dict = {'a': 1, 'b': 2}
    nt_2 = to_namedtuple(dic_2)

    dic_3 = OrderedDict([('a', 1), ('b', 2)])
    nt_3 = to_namedtuple(dic_3)

    dic_4

# Generated at 2022-06-25 17:24:47.383084
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for function to_namedtuple, case 0
    # The type of the test case is: dict
    # The expected to_namedtuple() returns is: NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    # Test for function to_namedtuple, case 1
    # The type of the test case is: dict
    # The expected to_namedtuple() returns is: NamedTuple(a=1, b=2)
    dic = {'a': 1, 'd': {'b': 1}, 'b': 2}

# Generated at 2022-06-25 17:24:59.504478
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from collections.abc import Mapping
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import Union

    list_0 = []
    assert to_namedtuple(list_0) == ()

    list_0 = [namedtuple('NamedTuple', 'a b')(1, 2)]
    assert to_namedtuple(list_0) == \
           [namedtuple('NamedTuple', 'a b')(1, 2)]

    dic_0 = {}
    assert to_namedtuple(dic_0) == namedtuple('NamedTuple', '')()

    dic_0 = dict(a=1)

# Generated at 2022-06-25 17:25:08.322096
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:25:13.728066
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('\n\nTesting function to_namedtuple...')
    test_case_0()


# Run the unit tests when this file is called directly
if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:25:18.878800
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test converting a dictionary."""
    dic = {'a': 1, 'b': 2}
    var = to_namedtuple(dic)
    assert isinstance(var, NamedTuple)
    assert sorted(var._fields) == ['a', 'b']
    assert var.a == 1
    assert var.b == 2



# Generated at 2022-06-25 17:25:26.836647
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_1 = [1]
    var_1 = to_namedtuple(list_1)
    list_2 = [1, 2, 3]
    var_2 = to_namedtuple(list_2)
    list_3 = [1, None, None]
    var_3 = to_namedtuple(list_3)
    list_4 = [1, 2, 3, ['a', 'b']]
    var_4 = to_namedtuple(list_4)
    list_5 = [1, 2, 3, [1, 2, 3], {'a': 1, 'b': 2}]
    var_5 = to_namedtuple(list_5)

# Generated at 2022-06-25 17:25:39.413922
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # test_case_0
    list_0 = []
    var_0 = to_namedtuple(list_0)
    isinstance(var_0, list)
    # test_case_1
    list_0 = ['a', 'b', 'c']
    var_0 = to_namedtuple(list_0)
    isinstance(var_0, list)
    # test_case_2
    list_0 = [1, 2, 3]
    var_0 = to_namedtuple(list_0)
    isinstance(var_0, list)
    # test_case_3
    dic_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dic_0)
    isinstance(var_0, NamedTuple)
    # test

# Generated at 2022-06-25 17:25:53.284764
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = dict(first='Jane', last='Doe', age=23)
    a = to_namedtuple(a)
    assert a.first == 'Jane'
    assert a.last == 'Doe'
    assert a.age == 23

    a = dict(nested=dict(first='Jane', last='Doe', age=23))
    a = to_namedtuple(a)
    assert a.nested.first == 'Jane'
    assert a.nested.last == 'Doe'
    assert a.nested.age == 23

    a = dict(nested=[dict(first='Jane', last='Doe', age=23)])
    a = to_namedtuple(a)
    assert a.nested[0].first == 'Jane'

# Generated at 2022-06-25 17:26:00.117537
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_to_namedtuple_case_0(self):
            list_0 = []
            var_0 = to_namedtuple(list_0)
            self.assertTrue(isinstance(var_0, list))
            self.assertFalse(isinstance(var_0, tuple))
            self.assertFalse(isinstance(var_0, NamedTuple))

        def test_to_namedtuple_case_1(self):
            list_0 = [1]
            var_0 = to_namedtuple(list_0)
            self.assertTrue(isinstance(var_0, list))

# Generated at 2022-06-25 17:26:05.984383
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)

    orderdic = OrderedDict()
    orderdic['a'] = 1
    orderdic['b'] = 2
    assert to_namedtuple(orderdic) == namedtuple(
        'NamedTuple', 'a b')(1, 2)

    tup = (1, 2)
    out = to_namedtuple(tup)
    assert out == (1, 2)

    tup = (1, dic, 2)
    out = to_namedtuple(tup)

# Generated at 2022-06-25 17:26:15.688750
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # setup
    dict_0 = {'a': 1, 'b': 2}
    dict_1 = {'c': 3, 'd': 4}

    # execute
    result_0 = to_namedtuple({'a': 1, 'b': 2})
    result_1 = to_namedtuple({'c': 3, 'd': 4})

    # verify
    assert(result_0.a == 1)
    assert(result_0.b == 2)
    assert(result_1.c == 3)
    assert(result_1.d == 4)

# Generated at 2022-06-25 17:26:27.089805
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [1, 2]
    var_0 = to_namedtuple(list_0)
    assert var_0 == (1, 2)
    assert type(var_0) == tuple
    dict_0 = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    var_1 = to_namedtuple(dict_0)
    assert var_1 == NamedTuple(a=1, b=2, c=3)
    assert type(var_1) == NamedTuple
    dict_1 = OrderedDict(
        a=1,
        b=2,
        c=3,
    )
    var_2 = to_namedtuple(dict_1)

# Generated at 2022-06-25 17:26:30.874734
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {
        'a': 1,
        'b': {'c': 2},
    }
    obj = to_namedtuple(obj)
    assert obj.a == 1
    assert obj.b.c == 2

# Generated at 2022-06-25 17:26:37.979221
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # test the variable, var_0, against the provided variable, list_0,
    # from the source code
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0, list) is True
    assert len(var_0) == 0
    dict_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dict_0)
    assert var_0.a == 1
    assert var_0.b == 2
    od_0 = OrderedDict({'a': 1, 'b': 2})
    var_0 = to_namedtuple(od_0)
    assert var_0.a == 1
    assert var_0.b == 2

# Generated at 2022-06-25 17:26:48.662284
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections.abc import Mapping
    from collections import OrderedDict
    from typing import NamedTuple
    from types import SimpleNamespace

    # Basic conversion of Mapping to NamedTuple
    class MyNamedTuple(NamedTuple):
        a: str
        b: str
        c: str

    dic = {'a': '1', 'b': '2', 'c': '3'}
    nt = to_namedtuple(dic)
    assert isinstance(nt, Mapping)
    assert isinstance(nt, NamedTuple)
    assert isinstance(nt, MyNamedTuple)
    assert nt.a == '1'
    assert nt.b == '2'
    assert nt.c == '3'

# Generated at 2022-06-25 17:27:01.500566
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import flutils.namedtupleutils as ntutils
    # noinspection Mypy
    from collections import namedtuple, OrderedDict  # type: ignore[no-redef]

    # noinspection Mypy
    from types import SimpleNamespace  # type: ignore[no-redef]

    TestCase = ntutils.to_namedtuple(
        OrderedDict({'a': 1, 'b': 2, 'c': OrderedDict({'d': 3})})
    )
    TestCase_0 = TestCase(1, 2, TestCase(3))
    TestCase_1 = TestCase(1, 2, TestCase(3))
    TestCase_2 = TestCase(2, 3, TestCase(1))

# Generated at 2022-06-25 17:27:13.498590
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert str(to_namedtuple({'a': 1, 'b': 2})) == 'NamedTuple(a=1, b=2)'
    assert str(to_namedtuple({'a': 1, 'b': 2, '_c': 3})) == 'NamedTuple(a=1, b=2)'
    assert str(to_namedtuple({'a': 1, 'b': 2, 'c': {'_c': 3}})) == 'NamedTuple(a=1, b=2, c=NamedTuple())'
    assert str(to_namedtuple({'a': 1, 'b': 2, 'c': {'c': 3}})) == 'NamedTuple(a=1, b=2, c=NamedTuple(c=3))'

# Generated at 2022-06-25 17:27:31.605737
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Unit test for function to_namedtuple'''

    # Test scenario }
    # Simple test case for function to_namedtuple
    #
    # Given an object that is a namedtuple
    # When  I attempt to convert it to a new namedtuple
    # Then  the returned namedtuple attributes match
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0, list)
    assert var_0 == []

    # Test scenario }
    # Simple test case for function to_namedtuple
    #
    # Given an object that is a namedtuple
    # When  I attempt to convert it to a new namedtuple
    # Then  the returned namedtuple attributes match
    tuple_0 = ()
    var_0 = to_namedtuple

# Generated at 2022-06-25 17:27:38.858718
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj_0 = {"a": 1, "b": 2}
    obj_1 = to_namedtuple(obj_0)
    print(obj_1)
    print()

    obj_0 = {"a": 1, "b": {"c": 3}}
    obj_1 = to_namedtuple(obj_0)
    print(obj_1)
    print()

    obj_0 = {"a": 1, "b": "a"}
    try:
        _ = to_namedtuple(obj_0)
    except TypeError:
        print("TypeError")
    print()

    obj_0 = tuple()
    obj_1 = to_namedtuple(obj_0)
    print(obj_1)
    print()

    obj_0 = []

# Generated at 2022-06-25 17:27:49.370445
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import os
    import logging
    from tempfile import gettempdir
    from pathlib import Path
    from flutils import root_logger

    module_ = sys.modules[__name__]
    log = root_logger.getChild(module_.__name__)
    prefix = root_logger.name
    logger_name = module_.__name__
    if prefix in logger_name:
        logger_name = logger_name.replace(prefix + '.', '')
    log_path = Path(gettempdir(), 'test')
    os.makedirs(log_path, exist_ok=True)
    log_file = Path(log_path, 'unittest_%s.log' % (logger_name,))

# Generated at 2022-06-25 17:27:55.752194
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections.abc import Sequence
    from collections.abc import MutableSequence
    from typing import List
    list_0: List[int] = [1, 2]
    var_0: Sequence = list_0
    var_1 = to_namedtuple(var_0)
    assert isinstance(var_1, list)
    assert len(var_1) == 2
    assert isinstance(var_1[0], int)
    assert var_1[0] == 1
    assert isinstance(var_1[1], int)
    assert var_1[1] == 2
    tuple_0: Tuple[int, int] = (1, 2)
    var_2: Sequence = tuple_0
    var_3 = to_namedtuple

# Generated at 2022-06-25 17:28:06.142105
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Setup
    list_0 = [1, 2, 3, 4, 5]
    list_1 = [
        1,
        (('a', 1), ('b', 2)),
        3,
        4,
        5,
    ]
    list_2 = [
        1,
        {'a': 1, 'b': 2},
        3,
        4,
        5,
    ]
    dict_0 = dict(a=1, b=2, c=3, d=4, e=5)
    dict_1 = dict(
        a=1,
        b={'a': 1, 'b': 2},
        c=3,
        d=4,
        e=5,
    )

# Generated at 2022-06-25 17:28:13.772370
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert var_0 == NamedTuple()

    list_1 = [1, 2, 3]
    var_1 = to_namedtuple(list_1)
    assert var_1 == (1, 2, 3)

    list_2 = [2, 3, 4]
    var_2 = to_namedtuple(list_2)
    assert var_2 == (2, 3, 4)

    list_3 = [3, 4, 5]
    var_3 = to_namedtuple(list_3)
    assert var_3 == (3, 4, 5)

    tuple_0 = ()
    var_4 = to_namedtuple(tuple_0)
    assert var_4 == NamedTuple()

   

# Generated at 2022-06-25 17:28:25.427025
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0 = {
        'a': 1,
        'b': 2
    }
    var_0 = to_namedtuple(dict_0)
    if not hasattr(var_0, 'a'):
        raise Exception()
    if not hasattr(var_0, 'b'):
        raise Exception()
    if not type(var_0.a) is int:
        raise Exception()
    if not type(var_0.b) is int:
        raise Exception()
    if not var_0.a == 1:
        raise Exception()
    if not var_0.b == 2:
        raise Exception()
    dict_1 = {
        'a': {
            'b': 1
        },
        'c': 2
    }
    var_1 = to_namedtuple(dict_1)

# Generated at 2022-06-25 17:28:35.280639
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # single mapping
    example_0 = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
    }
    from collections import OrderedDict
    example_1 = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
        ('d', 4),
    ])
    example_2 = {
        '__annotations__': {
            'a': int,
            'b': str,
            'c': int,
        },
        'a': 1,
        'b': '2',
        'c': 3,
    }
    var_0 = to_namedtuple({})
    var_1 = to_namedtuple(example_0)

# Generated at 2022-06-25 17:28:40.392307
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # <Value> -> <Error>
    from flutils.testingutils import (
        raises,
    )

    # noinspection PyUnusedLocal
    def fn():
        # <Value1> -> <Value2>
        # Check all Value1 and Value2 combinations.
        pass
    returns(fn,
            [
                # <Value1> -> <Value2>
            ]
            )



# Generated at 2022-06-25 17:28:47.148655
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()
    assert 1 <= 1


if __name__ == '__main__':
    import os
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))))
    import flutils.namedtupleutils
    flutils.namedtupleutils.test_to_namedtuple()

# Generated at 2022-06-25 17:29:04.541744
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2
    }
    namedtup = to_namedtuple(dic)
    assert dic == namedtup._asdict()
    assert {'a': 1, 'b': 2} == namedtup._asdict()



# Generated at 2022-06-25 17:29:13.172825
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils as nt
    #
    # Test for to_namedtuple()
    #
    # Test for tuple
    tup_0: tuple = (0, 1)
    obj_0 = nt.to_namedtuple(tup_0)
    assert obj_0 == (0, 1)
    #
    # Test for list
    list_0: list = [0, 1]
    obj_1 = nt.to_namedtuple(list_0)
    assert obj_1 == [0, 1]



# Generated at 2022-06-25 17:29:24.466922
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [
        OrderedDict({
            'a': 1,
            'c': 0,
            'b': 2,
        }),
        OrderedDict({
            'b': 3,
            'a': 2,
            'c': 1,
        }),
    ]
    var_0 = to_namedtuple(list_0)
    assert len(list_0) == 2
    assert len(var_0) == 2
    assert isinstance(var_0[0], NamedTuple)
    assert isinstance(var_0[1], NamedTuple)
    assert var_0[0].a == 1
    assert type(var_0[0].a) is int
    assert var_0[1].b == 3
    assert type(var_0[1].b) is int
   

# Generated at 2022-06-25 17:29:32.429216
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': {
            'a0': 1, 'a1': 2,
        },
        'b': {
            'b0': {
                'b0a': '', 'b0b': '',
            },
            'b1': {
                'b1a': {
                    'b1aa': '', 'b1ab': '',
                },
                'b1b': {
                    'b1ba': '', 'b1bb': '',
                },
            },
        },
        'c': {
            'c0': {
                'c0a': '', 'c0b': '',
            }, 'c1': {
                'c1a': '', 'c1b': '',
            },
        },
    }
    var_0 = to_namedt

# Generated at 2022-06-25 17:29:42.823571
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic_0 = dict(a=1, b=2)
    namedtuple_0 = to_namedtuple(dic_0)
    assert namedtuple_0 == namedtuple('NamedTuple', 'a, b')(a=1, b=2)

    dic_1 = dict(_a=1, b=2)
    namedtuple_1 = to_namedtuple(dic_1)
    assert namedtuple_1 == namedtuple('NamedTuple', 'b')(b=2)

    dic_2 = dict(a=1, B=2)
    namedtuple_2 = to_namedtuple(dic_2)

# Generated at 2022-06-25 17:29:52.752612
# Unit test for function to_namedtuple
def test_to_namedtuple():  # pragma: no cover
    from pprint import pprint
    dct = OrderedDict([
        ('a', OrderedDict([('b', [{'c': {'d': 'e'}}])])),
        ('f', 1),
    ])
    nt: NamedTuple
    nt = to_namedtuple(dct)
    pprint(nt._asdict())
    dct = OrderedDict([
        ('a', OrderedDict([('b', [{'c': {'d': 'e'}}])])),
        ('f', 1),
    ])
    nt = to_namedtuple(dct)
    pprint(nt._asdict())

# Generated at 2022-06-25 17:30:00.586856
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Run function to_namedtuple with arguments list_0 (set to [])
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert var_0 == NamedTuple()

    # Run function to_namedtuple with arguments dict_0 (set to {'a': 1, 'b': 2})
    dict_0 = {'a': 1, 'b': 2}
    var_1 = to_namedtuple(dict_0)
    assert var_1 == NamedTuple(a=1, b=2)

    # Run function to_namedtuple with arguments dict_1 (set to {'b': 3, 'a': 2})
    dict_1 = {'b': 3, 'a': 2}
    var_2 = to_namedtuple(dict_1)

# Generated at 2022-06-25 17:30:10.728471
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing function to_namedtuple ...')
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    print('... OK')
# End of unit tests.


# Generated at 2022-06-25 17:30:17.253084
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # test_case_0
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0, list)
    assert var_0 == []
    # test_case_1
    dic_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dic_0)
    assert isinstance(var_0, tuple)
    assert var_0.a == 1
    assert var_0.b == 2
    # test_case_2
    list_0 = [1, 2, 3]
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0, list)
    assert var_0 == [1, 2, 3]
    # test_case_3
    d

# Generated at 2022-06-25 17:30:18.329672
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()

# Generated at 2022-06-25 17:30:53.880924
# Unit test for function to_namedtuple
def test_to_namedtuple():
    namedtuple_0 = to_namedtuple({})
    namedtuple_1 = to_namedtuple({'a': 1})
    namedtuple_2 = to_namedtuple({'a': 1, 'b': 2})
    namedtuple_3 = to_namedtuple({'b': 2, 'a': 1})
    namedtuple_4 = to_namedtuple({'b': 2, 'a': 1, 'c': {'a': 1}})
    namedtuple_5 = to_namedtuple({'b': 2, 'a': 1, 'c': {'a': 1, 'b': 2}})
    str_0 = to_namedtuple('x')
    str_1 = to_namedtuple('xaybz')