

# Generated at 2022-06-25 17:21:01.873794
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d0 = {}
    d0['a'] = 1
    d0['b'] = 'b'
    nt0 = to_namedtuple(d0)
    assert(type(nt0) ==  namedtuple('NamedTuple', 'a b') and nt0.a == 1 and nt0.b == 'b')
    o0 = OrderedDict()
    o0['a'] = 1
    o0['b'] = 'b'
    o0['c'] = 'c'
    o0['d'] = [1,2,3]
    o0['e'] = OrderedDict()
    o0['e']['a'] = 1
    o0['e']['b'] = 2
    nt1 = to_namedtuple(o0)

# Generated at 2022-06-25 17:21:12.339356
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple."""
    # Create a simple object to convert
    list_0 = [1, 2, 3]
    list_1 = [
        {'a': 1, 'b': 2},
        {'c': 3, 'd': 4},
        {'e': 5, 'f': 6},
    ]
    list_2 = [
        {'_a': 1, 'b': 2},
        {'c': 3, '_d': 4},
        {'e': 5, '_f': 6},
    ]

# Generated at 2022-06-25 17:21:21.744856
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Try to convert an integer to a NamedTuple
    try:
        to_namedtuple(1)
    except TypeError:
        pass
    else:
        raise AssertionError('Entered unchanged integer')

    # Try to convert a NamedTuple to a NamedTuple
    try:
        to_namedtuple(to_namedtuple(1))
    except TypeError:
        pass
    else:
        raise AssertionError('Entered unchanged NamedTuple')

    # Convert an empty dictionary to a NamedTuple
    dic_0 = {}
    var_0 = to_namedtuple(dic_0)
    assert var_0 == to_namedtuple(dic_0)

    # Convert an empty OrderedDict to a NamedTuple
    dic_1 = OrderedDict()
   

# Generated at 2022-06-25 17:21:30.926818
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test when object is an empty list
    list_1 = []
    assert to_namedtuple(list_1) == []
    # Test when object is a list
    list_2 = ['a', 'b', 'c']
    assert to_namedtuple(list_2) == ['a', 'b', 'c']
    # Test when object is an empty tuple
    tuple_1 = tuple()
    assert to_namedtuple(tuple_1) == tuple()
    # Test when object is a tuple
    tuple_2 = ('a', 'b', 'c')
    assert to_namedtuple(tuple_2) == ('a', 'b', 'c')
    # Test when object is an empty dictionary
    dict_1 = {}
    assert to_namedtuple(dict_1) == tuple()
    # Test when

# Generated at 2022-06-25 17:21:37.903938
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {
        'a': 1,
        'b': 'test',
        'c': True,
        'd': {
            'e': 1,
            'f': 'test',
            'g': True,
        },
    }

    out = to_namedtuple(obj)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert hasattr(out, 'c')
    assert hasattr(out, 'd')
    assert out.a == 1
    assert out.b == 'test'
    assert out.c is True
    assert hasattr(out.d, 'e')
    assert hasattr(out.d, 'f')
    assert hasattr(out.d, 'g')
    assert out.d.e == 1
    assert out.d.f

# Generated at 2022-06-25 17:21:45.246647
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple

    assert to_namedtuple('') == ''
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple('a_a') == 'a_a'
    assert to_namedtuple('a1') == 'a1'
    # assert to_namedtuple('_a') == '_a'
    # assert to_namedtuple('_A') == '_A'

    NT = namedtuple('NamedTuple', 'a b c')
    assert to_namedtuple(NT(1, 2, 3)) == NT(1, 2, 3)

    assert to_namedtuple({}) == NT()


# Generated at 2022-06-25 17:21:49.203707
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:21:58.693046
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test for function to_namedtuple
    """

    # Case 0

    list_0 = []
    var_0 = to_namedtuple(list_0)
    var_1 = to_namedtuple(list_0)
    assert var_0 == var_1
    assert var_0 is not list_0
    assert isinstance(var_0, tuple)
    assert isinstance(var_1, tuple)
    assert var_0.__class__ is NamedTuple
    assert var_1.__class__ is NamedTuple
    assert var_0.__annotations__ == {}
    assert var_1.__annotations__ == {}
    assert var_0._fields == ()
    assert var_1._fields == ()
    assert var_0 == ()

    # Case 1


# Generated at 2022-06-25 17:22:04.940320
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import datetime

    a = {
        'a': 1,
        'b': 2,
        'c': datetime.datetime.now()
    }
    b = to_namedtuple(a)
    assert hasattr(b, 'a')
    assert hasattr(b, 'b')
    assert hasattr(b, 'c')
    assert b.a == a['a']
    assert b.b == a['b']
    assert b.c == a['c']
    assert b == a

    a = {
        'a': 1,
        '_b': 2,
        'c': datetime.datetime.now()
    }
    b = to_namedtuple(a)
    assert hasattr(b, 'a')
    assert not hasattr(b, '_b')
    assert has

# Generated at 2022-06-25 17:22:08.091365
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    obj_0 = to_namedtuple(dic_0)
    assert obj_0.a == 1
    assert obj_0.b == 2



# Generated at 2022-06-25 17:22:25.246552
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case #0
    list_0 = [
        {'a': 1},
        {'b': 2},
        {'c': 3},
    ]
    expect_0 = [
        NamedTuple(a=1),
        NamedTuple(b=2),
        NamedTuple(c=3),
    ]
    var_0 = to_namedtuple(list_0)
    try:
        assert var_0 == expect_0
    except AssertionError:
        raise AssertionError(
            'Expected: %r, Got: %r' % (expect_0, var_0)
        )

    # Test case #1
    tuple_0 = (
        {'a': 1},
        {'b': 2},
        {'c': 3},
    )
    expect_

# Generated at 2022-06-25 17:22:32.596315
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.miscutils import DummyClass, DummySubClass
    from random import sample

    def make_list(
            num_elems: int,
            set_to_test: set,
            _set_to_use: set = None
    ) -> 'OrderedDict[str, Any]':
        if _set_to_use is None:
            # noinspection PyProtectedMember
            _set_to_use = set_to_test._items  # type: ignore[attr-defined]
        max_ = len(_set_to_use)
        if not max_:
            raise ValueError(
                "Cannot generate a list with a set to test that does not have "
                "any items."
            )
        out = OrderedDict()

# Generated at 2022-06-25 17:22:44.849404
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    import flutils.configdata as _configdata

    dic_0 = _configdata.load_dict(_configdata.get_default_config_path())
    nt_0 = to_namedtuple(dic_0)
    assert isinstance(nt_0, NamedTuple)
    assert hasattr(nt_0, 'db_connect')
    assert hasattr(nt_0.db_connect, 'dns')
    assert hasattr(nt_0.db_connect.dns, 'username')
    assert hasattr(nt_0.db_connect.dns, 'password')
    assert hasattr(nt_0.db_connect.dns, 'host')
    assert hasattr(nt_0.db_connect.dns, 'database')

# Generated at 2022-06-25 17:23:01.247488
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import random  # type: ignore[import] # noqa
    import string  # type: ignore[import] # noqa
    from collections import OrderedDict  # type: ignore[import] # noqa

    from flutils.validators import validate_identifier  # type: ignore[import] # noqa

    # noinspection PyArgumentList
    def random_string(
            length: int = 3,
            lowercase: bool = True
    ) -> str:
        """Create a random string."""
        if lowercase is True:
            chars = string.ascii_lowercase
        else:
            chars = string.ascii_letters
        rand_str = ''.join(random.choice(chars) for i in range(length))
        return rand_str

    def test_dict():
        dic = {}

# Generated at 2022-06-25 17:23:07.477670
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest

    dict_0 = {'a': 1, 'b': 2}
    dict_1 = {'c': 1, 'd': 2}

    odict_0 = OrderedDict({'a': 1, 'b': 2})
    odict_1 = OrderedDict({'c': 1, 'd': 2})

    snamespace_0 = SimpleNamespace(**{'a': 1, 'b': 2})
    snamespace_1 = SimpleNamespace(**{'c': 1, 'd': 2})


    assert to_namedtuple(dict_0) == to_namedtuple(odict_0)
    assert to_namedtuple(dict_1) == to_namedtuple(odict_1)
   

# Generated at 2022-06-25 17:23:20.870562
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Setup
    dict_0 = {'a': 1, 'b': 2}
    dict_1 = dict(c=3, d=4)
    dict_2 = dict(e=5, f=6)

    # List
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert var_0 == [], 'var_0: ' + repr(var_0) + ' != []'

    list_0 = ['a']
    var_0 = to_namedtuple(list_0)
    assert var_0 == ['a'], 'var_0: ' + repr(var_0) + ' != [\'a\']'

    list_0 = ['a', dict_0]
    var_0 = to_namedtuple(list_0)
    assert var_0

# Generated at 2022-06-25 17:23:22.761382
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test function to_namedtuple
    # Target function
    _ = to_namedtuple
    # Test cases
    test_case_0()

# Generated at 2022-06-25 17:23:25.542345
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Case 0
    assert test_case_0() is None


# noinspection PyUnusedLocal

# Generated at 2022-06-25 17:23:32.094677
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert var_0 == list_0
    assert var_0 is list_0

    tuple_0 = ()
    var_0 = to_namedtuple(tuple_0)
    assert var_0 == tuple_0
    assert var_0 is tuple_0

    dict_0 = dict()
    var_0 = to_namedtuple(dict_0)
    assert var_0 == dict_0
    assert var_0 is dict_0

    dict_0 = OrderedDict()
    var_0 = to_namedtuple(dict_0)
    assert var_0 == dict_0
    assert var_0 is dict_0

    dict_1 = {'a': 1, 'b': 2}
    var_0

# Generated at 2022-06-25 17:23:41.232222
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    obj = OrderedDict()
    obj['a'] = 1
    obj['b'] = 2
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    obj = SimpleNamespace(a=1, b=2)
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    obj = [{'a': 1, 'b': 2}, {'a': 2, 'b': 1}, {'a': 1, 'b': 2}]
    out = to_namedtuple(obj)

# Generated at 2022-06-25 17:23:52.358679
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:24:00.825929
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2}
    od = OrderedDict(dic)
    nt = to_namedtuple(od)
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'_a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert nt.b == 2


# Generated at 2022-06-25 17:24:11.749072
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = {'a': 1, 'b': 2}
    a_tup = to_namedtuple(a)
    assert isinstance(a_tup, NamedTuple)
    a_tup = cast(NamedTuple, a_tup)
    assert hasattr(a_tup, 'a')
    assert hasattr(a_tup, 'b')
    assert a_tup.a == 1
    assert a_tup.b == 2
    c = {'c': 3, 'b': 4}
    c_tup = to_namedtuple(c)
    assert isinstance(c_tup, NamedTuple)
    c_tup = cast(NamedTuple, c_tup)
    assert hasattr(c_tup, 'c')

# Generated at 2022-06-25 17:24:22.061325
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test a list.
    test_list = [1, 2, 3]
    test_result = to_namedtuple(test_list)
    test_expected = []
    for test_value in test_list:
        test_expected.append(test_value)
    assert test_result == test_expected, \
        "Got: \n%r\nExpected: \n%r" % (test_result, test_expected)

    # Test a list with a dictionary.
    test_list = [{'a': 1, 'b': 2}]
    test_result = to_namedtuple(test_list)
    test_expected = []
    for test_value in test_list:
        test_expected.append(to_namedtuple(test_value))

# Generated at 2022-06-25 17:24:35.780354
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple."""
    # noinspection Mypy
    # noinspection PyTypeChecker
    test_data = OrderedDict([
        ('list', [[], [{'a': 1}], [{'a': 1}, {'a': 2}, {'a': 3}]]),
        ('tuple', [(), ({'a': 1},), ({'a': 1}, {'a': 2}, {'a': 3})])
    ])
    for test_type, tests in test_data.items():
        for in_var in tests:
            var = to_namedtuple(in_var)
            assert isinstance(var, list) or isinstance(var, tuple)
            if isinstance(var, list):
                for val in var:
                    assert isinstance(val, tuple)

# Generated at 2022-06-25 17:24:44.403039
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [3,2,1]
    var_0 = to_namedtuple(list_0)

    list_1 = ['a', 'b']
    var_1 = to_namedtuple(list_1)

    list_2 = [{'a': 'a'}, {'b': 'b'}]
    var_2 = to_namedtuple(list_2)

    list_3 = [{'a': 'a'}, {'b': 'b'}, {'a': 'a'}]
    var_3 = to_namedtuple(list_3)

    list_4 = [{'a': 'a'}, {'b': 'b'}, {'a': 'a', 'b': 'b'}]
    var_4 = to_namedtuple(list_4)



# Generated at 2022-06-25 17:24:54.205082
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Create 2 test cases for a given outcome.
    # Create 2 test cases for a given outcome.
    # Create 2 test cases for a given outcome.
    test_cases = []
    temp = type("example_tuple_0", (), {})
    temp.example_attr_0 = 'foo'
    temp.example_attr_1 = 2
    temp.__dict__.update({'example_attr_0': 'foo', 'example_attr_1': 2})
    list_0 = [temp, temp]
    list_0.append(temp)
    temp_0 = type("example_tuple_1", (), {})
    temp_0.example_attr_0 = 'foo'
    temp_0.example_attr_1 = 2

# Generated at 2022-06-25 17:25:07.190464
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test with empty list
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0, list) and len(var_0) == 0
    # Test with list of dictionaries
    list_1 = [
        {
            'a': 1,
            'b': 2,
        },
        {
            'c': 3,
            'd': 4,
        },
    ]
    var_1 = to_namedtuple(list_1)
    assert isinstance(var_1, list)
    assert len(var_1) == 2
    assert hasattr(var_1[0], 'a')
    assert hasattr(var_1[0], 'b')
    assert not hasattr(var_1[0], 'c')
    assert not has

# Generated at 2022-06-25 17:25:19.455083
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0, list)
    assert not len(var_0)

    list_0.append(1)
    var_1 = to_namedtuple(list_0)
    assert isinstance(var_1, list)
    assert 1 == var_1[0]
    assert len(var_1) == 1

    list_0.append(True)
    var_1 = to_namedtuple(list_0)
    assert isinstance(var_1, list)
    assert 1 == var_1[0]
    assert True == var_1[1]
    assert len(var_1) == 2

    list_0.append('first')

# Generated at 2022-06-25 17:25:28.999176
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from collections.abc import Mapping, Sequence
    from types import SimpleNamespace
    from typing import Dict, List, Optional, Tuple, Union, get_type_hints
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import to_namedtuple
    from pprint import pprint
    from flutils import logger
    import logging
    logger.setup_root(level=logging.DEBUG)
    msgs = []


# Generated at 2022-06-25 17:25:52.240352
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Case 0:
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert var_0._fields == []
    assert var_0.__class__.__name__ == 'NamedTuple'
    var_1 = to_namedtuple(list_0)
    assert var_1._fields == []
    assert var_1.__class__.__name__ == 'NamedTuple'

    # Case 1:
    tuple_0 = (1, 2)
    var_0 = to_namedtuple(tuple_0)
    assert var_0._fields == ('f0', 'f1')
    assert var_0.f0 == 1
    assert var_0.f1 == 2

# Generated at 2022-06-25 17:25:59.408908
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_cases = [
        0,
        1,
        2,
        3,
        4,
        5,
    ]
    for case in test_cases:
        if case == 0:
            list_0 = []
            var_0 = to_namedtuple(list_0)
            var_1 = to_namedtuple(list_0)
        elif case == 1:
            list_0 = []
            list_1 = [list_0]
            var_0 = to_namedtuple(list_1)
            var_1 = to_namedtuple(list_1)
        elif case == 2:
            list_0 = []
            list_1 = [list_0]
            list_2 = [list_1]
            var_0 = to_namedtuple(list_2)

# Generated at 2022-06-25 17:26:02.867298
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = []
    var_0 = to_namedtuple(list_0)
    var_1 = to_namedtuple(list_0)

    assert var_0 == var_1
    assert isinstance(var_0, tuple)
    assert isinstance(var_1, tuple)


# Generated at 2022-06-25 17:26:05.031447
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # TODO: Add tests
    assert True

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 17:26:13.425659
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.constants import _NT, NT
    from flutils.namedtupleutils import (
        _NT, as_ordered_dict, as_tuple,
        to_ordereddict, to_tuple,
    )
    from flutils._helpers import (
        _get_namedtuple_attrs,
        _get_namespace_attrs,
        _get_ordered_dict_keys,
    )

    # Test various types of dictionaries
    dic_0 = {'a': 1, 'b': 2}
    dic_1 = OrderedDict(a=1, b=2)
    dic_2 = dict(a=1, b=2)
    dic_2a = {'a': 1, 'b': 2}

# Generated at 2022-06-25 17:26:23.409657
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Unit test for function to_namedtuple
    list_0 = []
    var_0 = to_namedtuple(list_0)
    list_1 = [1, 2, 3, 4]
    var_1 = to_namedtuple(list_1)
    assert var_1._fields == ('0', '1', '2', '3')
    assert var_1[0] == 1
    assert var_1[1] == 2
    assert var_1[2] == 3
    assert var_1[3] == 4
    list_2 = [1]
    var_2 = to_namedtuple(list_2)
    assert var_2._fields == ('0',)
    assert var_2[0] == 1

# Generated at 2022-06-25 17:26:34.225513
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Set up test objects
    list_0 = []  # initialize list
    list_0.extend(range(0, 32))  # add the range of numbers 0 to 31
    list_1 = []  # initialize list
    list_1.append(to_namedtuple(list_0))  # append to_namedtuple to list 1
    list_1.append(to_namedtuple(list_0))  # append to_namedtuple to list 1
    list_1.append(to_namedtuple(list_0))  # append to_namedtuple to list 1
    tuple_0 = ()  # initialize tuple
    tuple_1 = (1, 2, 3, 4, 5)  # initialize tuple
    dict_0 = {}  # initialize dictionary
    dict_0['a'] = 1

# Generated at 2022-06-25 17:26:46.000378
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    dic_1 = {'a': 1, 'b': 2}
    list_0 = [dic_0, dic_1]
    tuple_0 = (dic_0, dic_1)
    dic_2 = {'a': [1, 2], 'b': (1, 2)}
    dic_3 = {'a': [1, 2], 'b': (1, 2)}
    list_1 = [dic_2, dic_3]
    tuple_1 = (dic_2, dic_3)
    list_2 = [{'a': {'b': 1}}]
    obj_1 = SimpleNamespace()
    obj_1.a = 1
    obj_1.b = 2
   

# Generated at 2022-06-25 17:26:50.054776
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: ()  -> NamedTuple
    """ Unit test for function to_namedtuple."""

    test_case_0()


if __name__ == '__main__':
    test_to_namedtuple()
    # assert inspect.getsource(to_namedtuple)

    # TODO:  assert inspect.getsource(test_to_namedtuple)

# Generated at 2022-06-25 17:27:02.299061
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case 0
    list_0 = [{
        'a': 'a',
        'b': 'b',
    }, {
        'a': 'a',
        'b': 'b',
    }]
    var_0 = to_namedtuple(list_0)
    assert var_0 == ([NamedTuple(a='a', b='b'), NamedTuple(a='a', b='b')], )

    # Test case 1
    list_0 = [{
        'a': 'a',
        'b': 'b',
    }, {
        'a': 'a',
        'b': 'b',
    }]
    var_0 = to_namedtuple(list_0)

# Generated at 2022-06-25 17:27:33.573799
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Try out simple dictionary conversion
    dic_0 = {'a': 1, 'b': 2}
    ans_0 = to_namedtuple(dic_0)
    val_0 = (ans_0.a, ans_0.b)
    assert val_0 == (1, 2)

    # Try out nested dictionary conversion
    dic_1 = {'a': {'a_a': 'a', 'a_b': 1}, 'b': 2}
    ans_1 = to_namedtuple(dic_1)
    val_1 = (ans_1.a.a_a, ans_1.a.a_b, ans_1.b)
    assert val_1 == ('a', 1, 2)

    # Try out nested dictionary conversion with different case

# Generated at 2022-06-25 17:27:45.717140
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test converting an object to a namedtuple
    """
    # tuple
    tuple_0 = (1, 2)
    var_0 = to_namedtuple(tuple_0)
    assert var_0.__class__.__name__ == 'NamedTuple'
    assert var_0.a == 1
    assert var_0.b == 2
    # list
    list_0 = [1, 2]
    var_1 = to_namedtuple(list_0)
    assert var_1.__class__.__name__ == 'NamedTuple'
    assert var_1.a == 1
    assert var_1.b == 2
    # list of tupes
    list_1 = [(1, 2), (1, 2)]

# Generated at 2022-06-25 17:27:53.951333
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test with a List
    list_0 = [1, 2, 3]
    var_0 = to_namedtuple(list_0)
    var_1 = to_namedtuple([])
    var_2 = to_namedtuple([
        1, [2, [3]], [4, '5', 6]
    ])

    # Test with a Tuple
    tup_0 = (1, 2, 3)
    var_3 = to_namedtuple(tup_0)
    var_4 = to_namedtuple(())
    var_5 = to_namedtuple((
        1, (2, (3,)), (4, '5', 6)
    ))

    # Test with a Mapping (dict)

# Generated at 2022-06-25 17:28:05.609578
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dic)
    list_0 = [
        {'a': 1, 'b': 2},
        {'b': 2, 'a': 1},
        {'a': 3, 'b': 2},
        {'a': 2, 'b': 1},
    ]

    odic = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
        ('d', 4),
        ('e', 5),
        ('f', 6),
    ])

    nstup = SimpleNamespace(**dic)

    cast(List[Any], var_0)
    var_0 = list(list_0)

# Generated at 2022-06-25 17:28:09.372562
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = []
    var_0 = to_namedtuple(list_0)
    var_1 = to_namedtuple(list_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:28:20.567923
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = (
        'PYTHON',
        (1, 2, 3),
        {},
        {'a': 1, 'b': 2},
        {'a': 1, 'c': 3},
        {'a': 1, 'b': 2, 'c': 3},
    )
    tuple_1 = [
        'PYTHON',
        (1, 2, 3),
        {},
        {'a': 1, 'b': 2},
        {'a': 1, 'c': 3},
        {'a': 1, 'b': 2, 'c': 3},
    ]
    ordered_dict_0 = OrderedDict({'a': 1, 'b': 2})
    namespace_0 = SimpleNamespace(a=1, b=2)


# Generated at 2022-06-25 17:28:30.302675
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test:
    to_namedtuple({})
    # Test:
    to_namedtuple(OrderedDict())
    # Test:
    to_namedtuple({'a': 1})
    # Test:
    to_namedtuple(OrderedDict([('a', 1)]))
    # Test:
    to_namedtuple({'a': 1, 'b': 2})
    # Test:
    to_namedtuple(OrderedDict(a=1, b=2, c=3))
    # Test:
    to_namedtuple([])
    # Test:
    to_namedtuple([1, 2, 3])

# Generated at 2022-06-25 17:28:38.790236
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:28:40.933715
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dic)



# Generated at 2022-06-25 17:28:51.042553
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit Tests for function to_namedtuple
    """
    list_1 = [None]
    var_2 = to_namedtuple(list_1)
    list_1 = list_1[:1]
    assert list_1 == [None]
    list_2 = ['name', 'id', 'date']
    var_3 = to_namedtuple(list_2)
    tuple_1 = (None, 1, 2)
    var_4 = to_namedtuple(tuple_1)
    list_3 = [1.0, 2.0, 3.0]
    var_5 = to_namedtuple(list_3)
    dict_1 = {'a': 1, 'b': 2}
    var_6 = to_namedtuple(dict_1)

# Generated at 2022-06-25 17:29:42.493041
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections.abc import Mapping
    from collections import OrderedDict, namedtuple
    from typing import TypeVar, Union, List, Tuple, NamedTuple
    from collections import namedtuple as namedtuple_

    NT = TypeVar('NT', bound=NamedTuple)

    dic = {'a': 1, 'b': 2}
    dic = OrderedDict(a=1, b=2)
    dic = {
        'a': {
            'b': {
                'c': 1,
                'd': 2,
            },
            'e': {
                'f': 3,
                'g': 4,
            },
        },
    }

# Generated at 2022-06-25 17:29:52.426257
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0: dict = {'a': 1, 'b': 2}
    dict_0_nt = to_namedtuple(dict_0)
    assert hasattr(dict_0_nt, 'a')
    dict_0_nt = to_namedtuple(dict_0)
    assert hasattr(dict_0_nt, 'a')
    list_0: list = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    list_0_nt = to_namedtuple(list_0)
    assert hasattr(list_0_nt[0], 'a')
    list_0_nt = to_namedtuple(list_0)
    assert hasattr(list_0_nt[0], 'a')

# Generated at 2022-06-25 17:30:00.359772
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case 3
    # Testing list of empty tuple
    expected_3 = [NamedTuple()]
    actual_3 = to_namedtuple([()])
    assert actual_3 == expected_3, (
        "Expected: " + str(expected_3) + "\n"
        "Actual:   " + str(actual_3)
    )
    # Test case 4
    # Testing list with empty tuple and 1, 2
    expected_4 = [NamedTuple(), 1, 2]
    actual_4 = to_namedtuple([(), 1, 2])
    assert actual_4 == expected_4, (
        "Expected: " + str(expected_4) + "\n"
        "Actual:   " + str(actual_4)
    )
    # Test case 5
    # Testing list with

# Generated at 2022-06-25 17:30:12.238660
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2
    assert out == (1, 2)
    assert out._fields == ('a', 'b')
    assert out._asdict() == {'a': 1, 'b': 2}
    assert out._replace(a=2) == (2, 2)

    dic = {'a': 1, 'b': 2, '_c': 3, '_d_': 4}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2
    assert out == (1, 2)

# Generated at 2022-06-25 17:30:21.282815
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing function to_namedtuple')

    obj = OrderedDict({'b': [2, 3], 'a': [1, 2]})
    obj = to_namedtuple(obj)
    assert obj.a[0] == 1
    assert obj.a[1] == 2
    assert obj.b[0] == 2
    assert obj.b[1] == 3

    obj = to_namedtuple(obj)
    assert obj.a[0] == 1
    assert obj.a[1] == 2
    assert obj.b[0] == 2
    assert obj.b[1] == 3

    obj = {'b': [2, 3], 'a': [1, 2]}
    obj = to_namedtuple(obj)
    assert obj.a[0] == 1
    assert obj.a

# Generated at 2022-06-25 17:30:30.722505
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({"a": 1, "b": 2}) == to_namedtuple((("a", 1), ("b", 2)))
    assert to_namedtuple({"a": 1, "b": 2}) == to_namedtuple({"a": 1, "b": 2, "c": 3})["ab"]
    assert to_namedtuple({"a": 1, "b": 2}) == to_namedtuple(
        {"a": 1, "b": 2, "c": 3, "d": 4}
    )["ab"]
    assert to_namedtuple({"a": 1, "b": 2}) == to_namedtuple(
        {"a": 1, "b": 2, "c": 3, "d": 4}
    )["abcd"[:2]]
    assert to_namedtuple

# Generated at 2022-06-25 17:30:38.972514
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Tests for function to_namedtuple"""

# Generated at 2022-06-25 17:30:48.717920
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections.abc import Mapping
    from typing import Union
    from flutils.miscutils import to_namedtuple
    from flutils import validators
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import (
        _AllowedTypes,
        _to_namedtuple,
    )
    import types, builtins
    var_0 = to_namedtuple([] )
    assert isinstance(var_0, tuple)
    assert hasattr(var_0, '_fields')
    var_1 = to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(var_1, namedtuple)
    assert var_1.a == 1
    assert var_1.b == 2
    var_2 = to_