

# Generated at 2022-06-25 17:21:03.546353
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data_0 = {'a': 1, 'b': 2}
    output_0 = to_namedtuple(data_0)
    assert repr(output_0) == "NamedTuple(a=1, b=2)"
    assert output_0.a == 1 and output_0.b == 2
    data_1 = OrderedDict({'a': 1, 'b': 2})
    output_1 = to_namedtuple(data_1)
    assert repr(output_1) == "NamedTuple(a=1, b=2)"
    assert output_1.a == 1 and output_1.b == 2
    data_2 = SimpleNamespace(**data_0)
    output_2 = to_namedtuple(data_2)

# Generated at 2022-06-25 17:21:05.319631
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

# Generated at 2022-06-25 17:21:06.282338
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True


# Generated at 2022-06-25 17:21:14.730290
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.b = None
    simple_namespace_0.a = 1
    var_0 = to_namedtuple(simple_namespace_0)
    assert hasattr(var_0, 'a') and hasattr(var_0, 'b')
    assert var_0.a == simple_namespace_0.a and var_0.b == simple_namespace_0.b


# Generated at 2022-06-25 17:21:29.592018
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class OrderedDict(dict):
        def __init__(self, arr):
            super().__init__((key, None) for key in arr)

        def __setitem__(self, key, value):
            if key not in self:
                raise KeyError('')
            return super().__setitem__(key, value)

    dic = OrderedDict(('a', 'b', 'c'))
    dic['a'] = 1
    dic['b'] = 2
    dic['c'] = dic
    assert dic == {'a': 1, 'b': 2, 'c': dic}
    dic[1] = dic
    assert dic == {'a': 1, 'b': 2, 'c': dic, 1: dic}

# Generated at 2022-06-25 17:21:34.261057
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    to_namedtuple(dic)
    test_case_0()

# Generated at 2022-06-25 17:21:35.274609
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # TODO: Add test cases here
    pass

# Generated at 2022-06-25 17:21:39.566432
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert callable(to_namedtuple)

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(["-vv", "--log-cli-level=debug", "test_namedtupleutils.py"]))

# Generated at 2022-06-25 17:21:54.050304
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    # TODO: Fix the test

    dic = {'a': 1, 'b': 2}
    res_0 = to_namedtuple(dic)
    assert res_0._fields == ('a', 'b')

    dic = {'a': 1, 'b': 2, '_c': 3}
    res_0 = to_namedtuple(dic)
    assert res_0._fields == ('a', 'b')

    dic = {'aa': 1, '_a': 2, 'b': 3}
    res_0 = to_namedtuple(dic)
    assert res_0._fields == ('b',)

    d = {'a': 1, 'b': 2}

# Generated at 2022-06-25 17:22:02.262015
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0 = {'a': 1, 'b': 2}
    dict_1 = {'c': 3, 'd': 4}
    dict_2 = {'e': 5, 'f': 6}
    dict_3 = {'g': 7, 'h': 8}
    list_0 = [dict_0, dict_1, dict_2, dict_3]
    list_1 = [dict_0, dict_1, dict_2, dict_3]
    tuple_0 = (dict_0, dict_1, dict_2, dict_3)
    tuple_1 = (dict_0, dict_1, dict_2, dict_3)

    list_of_lists = [list_0, list_1]

    list_of_dicts = [dict_0, dict_1]
    tuple_of

# Generated at 2022-06-25 17:22:06.226007
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True

# Generated at 2022-06-25 17:22:19.838217
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test cases
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)


if __name__ == '__main__':
    import sys
    import timeit
    import flutils

    print(flutils.__version__)
    print()

    # print(sys.version)
    # print()

    # print(timeit.timeit(
    #     'test_to_namedtuple()',
    #     number=1,
    #     setup='from __main__ import test_to_namedtuple',
    # ))

# flutils version: 3.3.0
#
# Python version: 3.7.3 (default, Mar 27 2019, 22:11:17)
# [GCC 7.3.0]

# Generated at 2022-06-25 17:22:30.083888
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) is not None
    assert to_namedtuple({
        'a': 1,
    }) is not None
    assert to_namedtuple({
        'a': 1,
        'b': 2,
    }) is not None
    assert to_namedtuple({
        'a': 1,
        'b': 2,
        'c': 3,
    }) is not None
    assert to_namedtuple({
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
    }) is not None
    assert to_namedtuple({
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5,
    }) is not None
    assert to_namedt

# Generated at 2022-06-25 17:22:31.416136
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()

# Test cases for function _to_namedtuple

# Generated at 2022-06-25 17:22:43.633172
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for correct conversion to named tuple
    test_dict = {'a': 1, 'b': 2}
    test_tuple = (1, 2)
    test_list = [1, 2]
    test_dict['c'] = test_dict
    test_dict['d'] = test_tuple
    test_dict['e'] = test_list
    test_tuple = (test_dict, test_tuple, test_list)
    test_list = [test_dict, test_tuple, test_list]
    named_tuple_dict = to_namedtuple(test_dict)
    named_tuple_tuple = to_namedtuple(test_tuple)
    named_tuple_list = to_namedtuple(test_list)

# Generated at 2022-06-25 17:23:00.485018
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    import typing
    import types
    assert to_namedtuple({'a': 1, 'b': 2}) == collections.namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple({'b': 2, 'a': 1}) == collections.namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple(collections.OrderedDict([('c', 3), ('a', 1), ('b', 2)])) == collections.namedtuple('NamedTuple', ['c', 'a', 'b'])(3, 1, 2)

# Generated at 2022-06-25 17:23:07.142451
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.name = 'x'
    simple_namespace_0.age = 20
    var_0 = to_namedtuple(simple_namespace_0)
    var_1 = to_namedtuple(simple_namespace_0.__dict__)
    var_2 = to_namedtuple(var_1)
    var_3 = to_namedtuple(simple_namespace_0)
    assert var_0.name == 'x'
    assert var_1.name == 'x'
    assert var_2.name == 'x'
    assert var_3.name == 'x'

if (__name__ == '__main__'):
    test_case_0()
    test_to_namedtuple()

# Generated at 2022-06-25 17:23:20.642104
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Dict, List

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()

    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(1)

    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)

    dict_var_1: Dict[str, int] = {'a': 1, 'b': 2}
    assert to_namedtuple(dict_var_1) == namedtuple('NamedTuple', 'a b')(1, 2)

    dict_var_2: OrderedDict[str, int] = OrderedDict(a=1, b=2)
    assert to_namedtuple

# Generated at 2022-06-25 17:23:29.005895
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Run test with mock data
    def simple_namespace_0(self):
        pass
    class_0 = type('SimpleNamespace', (), {'__repr__': simple_namespace_0, '__str__': simple_namespace_0})
    simple_namespace_0 = class_0()
    var_0 = to_namedtuple(simple_namespace_0)

    # Run test with actual data
    # TODO: implement actual data test
    # simple_namespace_0 = module_0.SimpleNamespace()
    # var_0 = to_namedtuple(simple_namespace_0)

# Run unit tests for this module (optional)
if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:23:36.421326
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:23:50.721859
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test a simple namespace
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.a = 1
    simple_namespace_0.b = 2
    var_0 = to_namedtuple(simple_namespace_0)
    assert var_0 == NamedTuple(a=1, b=2)
    # Test a simple namespace with underscore first attribute
    simple_namespace_1 = module_0.SimpleNamespace()
    simple_namespace_1.a = 1
    simple_namespace_1._b = 2
    var_1 = to_namedtuple(simple_namespace_1)
    assert var_1 == NamedTuple(a=1, b=2)
    # Test a list of simple namespace
    simple_namespace_2 = module_0.SimpleNames

# Generated at 2022-06-25 17:23:51.635089
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True

# Generated at 2022-06-25 17:24:00.804548
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:24:11.763147
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test a basic usage."""
    dic = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    nt = to_namedtuple(dic)
    assert getattr(nt, 'a') == 1
    assert getattr(nt, 'b') == 2
    assert getattr(nt, 'c').d == 4
    assert getattr(nt, 'c').e == 5

    dic = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    nt = to_namedtuple(OrderedDict(dic))
    assert getattr(nt, 'a') == 1
    assert getattr(nt, 'b') == 2
    assert getattr(nt, 'c').d == 4
    assert get

# Generated at 2022-06-25 17:24:12.315393
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-25 17:24:23.535869
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # simple case
    simple_namespace_0 = module_0.SimpleNamespace()

    # test simple case
    var_0 = to_namedtuple(simple_namespace_0)

    # validation: simple case
    assert(var_0 == simple_namespace_0)

    # setup
    simple_namespace_1 = module_0.SimpleNamespace(a=1, b=2)

    # test setup
    var_1 = to_namedtuple(simple_namespace_1)

    # validation: setup
    assert(var_1 == simple_namespace_1)

    # setup
    named_tuple_0 = namedtuple('NamedTuple', 'a,b')(1, 2)

    # test setup
    var_2 = to_namedtuple(named_tuple_0)



# Generated at 2022-06-25 17:24:24.321064
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert callable(to_namedtuple)


# Generated at 2022-06-25 17:24:38.615411
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert callable(to_namedtuple)
    from collections import OrderedDict
    from collections import namedtuple
    from collections.abc import Mapping
    from collections.abc import Sequence
    from numbers import Number
    from types import SimpleNamespace
    #
    #
    #
    assert isinstance(to_namedtuple([1, 2, 3]), list)
    assert isinstance(to_namedtuple((1, 2, 3)), tuple)
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), namedtuple)
    assert isinstance(to_namedtuple(OrderedDict([
        ('a', 1),
        ('b', 2),
    ])), namedtuple)

# Generated at 2022-06-25 17:24:49.127076
# Unit test for function to_namedtuple
def test_to_namedtuple():
    try:
        # Check type of NamedTuple, for namedtuple.
        # Coverage: Branch not covered by test
        # ----
        # type: (Any) -> Tuple[NamedTuple, NamedTuple]
        # ----
        #
        # type: (Any) -> Tuple[NamedTuple, Any]
        dummy_namedtuple_0 = None  # type: NamedTuple
        var_0 = to_namedtuple(dummy_namedtuple_0)
    except TypeError:
        pass

# Generated at 2022-06-25 17:25:03.077248
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lst = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, [{'a': 5, 'b': 6}]]
    nt_lst = to_namedtuple(lst)
    assert nt_lst[0].a == 1 and nt_lst[0].b == 2
    assert nt_lst[1].a == 3 and nt_lst[1].b == 4
    assert nt_lst[2][0].a == 5 and nt_lst[2][0].b == 6

    tup = (1, 2, 3)
    nt_tup = to_namedtuple(tup)
    assert nt_tup == (1, 2, 3)


# Generated at 2022-06-25 17:25:16.593753
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(["a", "b", "c"]) == NamedTuple(a='a', b='b', c='c')
    assert to_namedtuple(("a", "b", "c")) == NamedTuple(a='a', b='b', c='c')
    assert to_namedtuple({"a": "a", "b": "b", "c": "c"}) == NamedTuple(a='a', b='b', c='c')
    assert to_namedtuple({"a": "a", "b": "b", "c": "c"},) == NamedTuple(a='a', b='b', c='c')

# Generated at 2022-06-25 17:25:25.783784
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    to_namedtuple_0 = to_namedtuple(simple_namespace_0)
    if to_namedtuple_0 is None:
        var_0 = None
    else:
        var_0 = to_namedtuple_0.__class__
    try:
        assert var_0 == module_0.SimpleNamespace
    except AssertionError:
        raise AssertionError(var_0)

if __name__ == '__main__':
    import sys
    import doctest
    # noinspection PyUnresolvedReferences
    import flutils.namedtupleutils

    doctest.testmod(sys.modules[__name__])


# Generated at 2022-06-25 17:25:34.909868
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# noinspection PyUnresolvedReferences
try:
    import __main__ as module_0

# noinspection PyBroadException
    try:
        try:
            module_0.test_case_0()
        except NameError:
            pass
    except:
        pass

finally:
    del module_0

if __name__ == '__main__':
    test_to_namedtuple()
    pass

# Generated at 2022-06-25 17:25:42.459607
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0 = dict()
    var_0 = to_namedtuple(dict_0)
    dict_1 = dict()
    dict_1['var_1'] = dict()
    dict_1['var_1']['var_2'] = 'var_3'
    dict_4 = dict()
    dict_4['var_1'] = dict()
    dict_4['var_1']['var_2'] = dict()
    dict_4['var_1']['var_2']['var_3'] = 'var_4'
    dict_1['var_1']['var_5'] = dict_4['var_1']['var_2']['var_3']
    dict_1['var_1']['var_6'] = 'var_7'

# Generated at 2022-06-25 17:25:53.132829
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test with some simple case(s).

    # Test an empty dictionary.
    simple_dictionary_0 = {}
    var_0 = to_namedtuple(simple_dictionary_0)
    assert var_0 == ()

    # Test an empty list.
    simple_list_0 = []
    var_1 = to_namedtuple(simple_list_0)
    assert var_1 == []

    # Test an empty namedtuple.
    simple_tuple_0 = namedtuple('simple_tuple_0', '')()
    var_2 = to_namedtuple(simple_tuple_0)
    assert var_2 == ()

    # Test a simple dictionary.
    simple_dictionary_1 = {'simple_key_0': 'simple_value_0'}
    var_3 = to_

# Generated at 2022-06-25 17:26:00.010785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(('a', 'b')) == _to_namedtuple(('a', 'b'), _started=True)
    assert to_namedtuple(['a', 'b']) == _to_namedtuple(['a', 'b'], _started=True)
    assert to_namedtuple([1, 2]) == _to_namedtuple([1, 2], _started=True)
    assert to_namedtuple([1.0, 2.0]) == _to_namedtuple([1.0, 2.0], _started=True)
    assert to_namedtuple({'a': 1, 'b': 2}) == _to_namedtuple({'a': 1, 'b': 2}, _started=True)

# Generated at 2022-06-25 17:26:02.891747
# Unit test for function to_namedtuple
def test_to_namedtuple():
    for index in range(0, 10):
        simple_namespace_0 = module_0.SimpleNamespace()
        var_0 = to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:26:09.927965
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple({}) == ()
    assert to_namedtuple(OrderedDict()) == ()
    assert to_namedtuple([[]]) == [[]]
    assert to_namedtuple((())) == ((),)
    assert to_namedtuple({}) == ()
    assert to_namedtuple(OrderedDict()) == ()
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) == (1, 2, 3)
    assert to_named

# Generated at 2022-06-25 17:26:21.605114
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections as module_0
    import typing as module_1
    foo_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(foo_0)
    assert isinstance(var_0, module_0.namedtuple)
    assert var_0.a == 1
    assert var_0.b == 2
    bar_0 = {'b': 1, 'a': 2}
    var_1 = to_namedtuple(bar_0)
    assert isinstance(var_1, module_0.namedtuple)
    assert var_1.a == 2
    assert var_1.b == 1
    # test converting nested dict to namedtuple
    var_2 = to_namedtuple({'a': {'b': 1, 'c': 2}})

# Generated at 2022-06-25 17:26:24.074659
# Unit test for function to_namedtuple
def test_to_namedtuple():
    ns = SimpleNamespace()
    ns.a = 1
    ns.b = 2
    x = to_namedtuple(ns)
    assert isinstance(x, namedtuple)
    assert x.a == 1
    assert x.b == 2

# Generated at 2022-06-25 17:26:38.605948
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(to_namedtuple({'a': 1, 'b': 2})) == NamedTuple(a=1, b=2)
    assert to_namedtuple(['a']) == ['a']
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(1) == 1
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple(to_namedtuple([1, 2])) == to_namedtuple([1, 2])
    assert to_namedtuple(to_namedtuple(['a', 'b'])) == to_namedtuple(['a', 'b'])
    assert to_namedtuple(to_namedtuple(OrderedDict([('a', 1)]))) == NamedTuple

# Generated at 2022-06-25 17:26:49.222357
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import Dict, List, Tuple, Union
    import unittest

    from flutils.namedtupleutils import to_namedtuple

    class TestToNamedTuple(unittest.TestCase):
        def setUp(self):
            self.od_baseline: OrderedDict = OrderedDict((
                ('a', 1),
                ('b', 2),
                ('c', 3),
            ))


# Generated at 2022-06-25 17:27:01.783064
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for to_namedtuple w/o default param
    simple_namespace_0 = SimpleNamespace()
    simple_namespace_0.attr_0 = 0
    var_0 = to_namedtuple(simple_namespace_0)
    assert isinstance(var_0, NamedTuple)
    assert getattr(var_0, 'attr_0') == 0

    # Test for to_namedtuple passing OrderedDict
    ordered_dict_0 = OrderedDict()
    ordered_dict_0['attr_0'] = 0
    ordered_dict_0['attr_1'] = 1
    ordered_dict_0['attr_2'] = 2
    ordered_dict_0['attr_3'] = 3
    var_1 = to_namedtuple(ordered_dict_0)

# Generated at 2022-06-25 17:27:13.748390
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from types import SimpleNamespace
    from collections import (
        OrderedDict,
    )
    import flutils.namedtupleutils as module_1

    # Test NamedTuple
    var_0 = module_1.NamedTuple()
    var_1 = to_namedtuple(var_0)
    assert var_1 == var_0

    # Test List
    var_0 = []
    var_1 = to_namedtuple(var_0)
    assert var_1 == var_0

    # Test Tuple
    var_0 = ()
    var_1 = to_namedtuple(var_0)
    assert var_1 == var_0

    # Test OrderedDict
    var_0 = OrderedDict()
    var_1 = to_namedtuple(var_0)
   

# Generated at 2022-06-25 17:27:15.130479
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True

# noinspection PyShadowingBuiltins

# Generated at 2022-06-25 17:27:24.946324
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    assert to_namedtuple(simple_namespace_0) == NamedTuple()
    simple_namespace_1 = module_0.SimpleNamespace()
    simple_namespace_1.a = 1
    simple_namespace_1.b = 2
    simple_namespace_1.c = 3
    var_0 = to_namedtuple(simple_namespace_1)
    assert var_0 == NamedTuple(a=1, b=2, c=3)
    ordered_dict_0 = OrderedDict()
    ordered_dict_0['a'] = 1
    ordered_dict_0['b'] = 2
    ordered_dict_0['c'] = 3
    var_1 = to_namedtuple(ordered_dict_0)

# Generated at 2022-06-25 17:27:25.859350
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True

# Generated at 2022-06-25 17:27:36.294277
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace(x=1, y=2)
    assert to_namedtuple(simple_namespace_0) == to_namedtuple(simple_namespace_0.__dict__)
    assert to_namedtuple(simple_namespace_0) == to_namedtuple(OrderedDict(x=1, y=2))
    assert to_namedtuple(simple_namespace_0) == to_namedtuple((1, 2))
    assert to_namedtuple(simple_namespace_0) == to_namedtuple([1, 2])
    assert to_namedtuple(simple_namespace_0) == to_namedtuple([1, 2])

# Generated at 2022-06-25 17:27:37.183627
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

import pytest


# Generated at 2022-06-25 17:27:46.942755
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert callable(to_namedtuple)
    assert isinstance(to_namedtuple([]), list)
    assert isinstance(to_namedtuple(()), tuple)
    assert isinstance(to_namedtuple({}), NamedTuple)
    assert isinstance(to_namedtuple({'a': 1}), NamedTuple)
    assert isinstance(
        to_namedtuple({'a': 1, 'b': 2}),
        NamedTuple
    )
    assert isinstance(
        to_namedtuple({'b': 2, 'a': 1}),
        NamedTuple
    )
    assert isinstance(
        to_namedtuple(OrderedDict({'a': 1, 'b': 2})),
        NamedTuple
    )

# Generated at 2022-06-25 17:28:02.860229
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:28:11.533855
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    dic = {'a': 1, 'b': 2}
    namedtuple_0 = to_namedtuple(dic)
    assert hasattr(namedtuple_0, 'a')
    assert hasattr(namedtuple_0, 'b')
    simple_namespace_0 = module_0.SimpleNamespace()
    namedtuple_1 = to_namedtuple(simple_namespace_0)
    assert hasattr(namedtuple_1, '')
    dic_0 = {'a': 1, 'b': 2}
    namedtuple_2 = to_namedtuple(dic_0)
    assert hasattr(namedtuple_2, 'a')
    assert hasattr(namedtuple_2, 'b')
    simple_namespace_1 = module

# Generated at 2022-06-25 17:28:15.584812
# Unit test for function to_namedtuple
def test_to_namedtuple():
    x = to_namedtuple(['abc', 123, dict(a=1, b=2, c=3), dict(a=1)])
    assert x == NamedTuple('abc', 123, NamedTuple(a=1, b=2, c=3), NamedTuple(a=1))
    x = to_namedtuple(['abc', 123, dict(a=1, b=2, c=3), dict(a=1)], foo=1)
    assert x == ('abc', 123, NamedTuple(a=1, b=2, c=3), NamedTuple(a=1))
    x = to_namedtuple(['abc', 123, dict(a=1, b=2, c=3), dict(a=1)], foo=1)

# Generated at 2022-06-25 17:28:27.124781
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test a dictionary
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    # Test an ordered dictionary
    dic = OrderedDict({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    nt = to_namedtuple(dic)
    assert nt == NamedTuple(a=1, b=2, c=3, d=4)

    # Test a dictionary with other dictionaries
    dic = OrderedDict({'a': {'x': 1, 'y': 2}, 'b': 2, 'c': 3, 'd': 4})
    nt = to_namedtuple(dic)

# Generated at 2022-06-25 17:28:32.042035
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case with the following parameter values:
    # obj = {'a': 1, 'b': 2}

    # noinspection PyTypeChecker
    obj_0: dict = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(obj_0)
    assert var_0.a == 1
    assert var_0.b == 2
    # Test case with the following parameter values:
    # obj = ['a', 1]

    # noinspection PyTypeChecker
    obj_0: list = ['a', 1]
    var_0 = to_namedtuple(obj_0)
    assert var_0[0] == 'a'
    assert var_0[1] == 1
    # Test case with the following parameter values:
    # obj = (1, 'b')

   

# Generated at 2022-06-25 17:28:40.013914
# Unit test for function to_namedtuple
def test_to_namedtuple():
    try:
        assert to_namedtuple('to_namedtuple') == 'to_namedtuple'
    except Exception:
        raise AssertionError
    try:
        assert to_namedtuple([{'to_namedtuple': 'to_namedtuple'}]) == [NamedTuple(to_namedtuple='to_namedtuple')]
    except Exception:
        raise AssertionError
    try:
        assert to_namedtuple([{'a': 'to_namedtuple', 'b': [{'to_namedtuple': 'to_namedtuple'}]}]).to_namedtuple == 'to_namedtuple'
    except Exception:
        raise AssertionError

# Generated at 2022-06-25 17:28:44.302831
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test for function to_namedtuple"""
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)


# Unit test runner

# Generated at 2022-06-25 17:28:48.096984
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    out2 = to_namedtuple(out)
    assert out2 == out

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:28:55.413596
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Testing: Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got:

    # Testing: dict -> dict
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.b = 2
    simple_namespace_0.a = 1
    simple_namespace_0.c = 3
    var_0 = to_namedtuple(simple_namespace_0)
    assert var_0.a == 1
    assert var_0.b == 2
    assert var_0.c == 3

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:29:01.832854
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test namedtuple from dict
    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert result == NamedTuple(a=1, b=2)

    # Test namedtuple from list
    lst = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    result = to_namedtuple(lst)
    assert result == [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]

    # Test namedtuple from tuple
    tup = ({'a': 1, 'b': 2}, {'a': 3, 'b': 4})
    result = to_namedtuple(tup)

# Generated at 2022-06-25 17:29:25.357887
# Unit test for function to_namedtuple
def test_to_namedtuple():
    try:
        to_namedtuple([1, 2, 3])
    except TypeError as e:
        assert str(e) == "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (%r) [1, 2, 3]"
    except:
        raise
    try:
        to_namedtuple(tuple([1, 2, 3]))
    except TypeError as e:
        assert str(e) == "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (%r) (1, 2, 3)"
    except:
        raise
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

# Generated at 2022-06-25 17:29:33.024660
# Unit test for function to_namedtuple
def test_to_namedtuple():
    arg0_0 = module_0.SimpleNamespace()
    arg0_0.var_0 = module_0.SimpleNamespace()
    arg0_0.var_0.var_0 = True
    arg0_0.var_0.var_1 = 2
    arg0_0.var_0.var_2 = 3.0
    arg0_0.var_0.var_3 = '4.0'
    arg0_0.var_0.var_4 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(arg0_0)

# Generated at 2022-06-25 17:29:43.215070
# Unit test for function to_namedtuple
def test_to_namedtuple():
    first_dict = {"a": 1, "b": 2, "c": {"c": 1, "d": 2}}
    first_named_tuple = to_namedtuple(first_dict)
    assert isinstance(first_named_tuple, NamedTuple)
    assert first_named_tuple.a == 1
    assert first_named_tuple.b == 2
    assert isinstance(first_named_tuple.c, NamedTuple)
    assert first_named_tuple.c.c == 1
    assert first_named_tuple.c.d == 2


# Generated at 2022-06-25 17:29:53.121741
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pformat, pprint
    from typing import Dict, List
    from types import SimpleNamespace

    def _json_parse(json_str):
        from json import loads

        data = loads(json_str)
        return to_namedtuple(data)

    from datetime import datetime as module_0
    dt = module_0.strptime('2019-07-20T12:08:04-05:00', '%Y-%m-%dT%H:%M:%S%z')

    header = SimpleNamespace()
    header.task = 'task'
    header.user = 'me'
    header.machines = ['machine_1', 'machine_2']
    header.hostname = 'host_name'
    header.time = dt

# Generated at 2022-06-25 17:29:54.516046
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert False, "Unable to find expected exception"


import types as module_1
import types as module_2


# Generated at 2022-06-25 17:30:02.398388
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    assert to_namedtuple(simple_namespace_0) == \
        NamedTuple()
    from collections import OrderedDict
    ordered_dict_0 = OrderedDict()
    ordered_dict_0['a'] = 1
    ordered_dict_0['b'] = 2
    assert to_namedtuple(ordered_dict_0) == \
        NamedTuple(a=1, b=2)
    # Test that non-identifier type names are kept.
    ordered_dict_1 = OrderedDict()
    ordered_dict_1['a'] = 1
    ordered_dict_1['b.b'] = 2

# Generated at 2022-06-25 17:30:14.188338
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case where input is a dictionary
    simple_namespace_0 = module_0.SimpleNamespace()
    attr_0 = module_0.SimpleNamespace()
    attr_0.attr_0 = [1, 2, 3]
    simple_namespace_0.attr_0 = attr_0
    simple_namespace_0.attr_1 = {1: 2, 3: 4}
    simple_namespace_0.attr_2 = [1, 2, 3]
    var_0 = to_namedtuple(simple_namespace_0)
    # Test case where input is an ordered dictionary
    ordered_dict_0 = OrderedDict()
    ordered_dict_0[1] = 1
    ordered_dict_0[3] = 3
    ordered_dict_0[2] = 2
   

# Generated at 2022-06-25 17:30:24.246803
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections.abc import Sequence
    from types import SimpleNamespace
    from types import getmro
    from typing import Dict
    from typing import List
    from typing import Mapping as Mapping0
    from typing import NamedTuple
    from typing import Tuple
    from typing import Type
    from typing import Union
    import types as module_0
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.a = 1
    simple_namespace_0.b = 2
    simple_namespace_0.c = 3
    simple_namespace_0.d = 4
    # simple_namespace_0.e = 5
    var_0 = to_namedtuple(simple_namespace_0)
   

# Generated at 2022-06-25 17:30:32.874442
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Example 1
    dic = dict(a=1, b=2)
    out = to_namedtuple(dic)
    assert out == NamedTuple(a=1, b=2)
    # Example 2
    ordered_dic = OrderedDict(a=1, b=2)
    out = to_namedtuple(ordered_dic)
    assert out == NamedTuple(a=1, b=2)
    # Example 3
    simple_namespace = SimpleNamespace(a=1, b=2)
    out = to_namedtuple(simple_namespace)
    assert out == NamedTuple(a=1, b=2)
    # Example 4
    list_of_dict = [dict(a=1, b=2)]

# Generated at 2022-06-25 17:30:43.392168
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # simple namespace
    simple_namespace = module_0.SimpleNamespace()
    assert to_namedtuple(simple_namespace) == NamedTuple()
    assert isinstance(to_namedtuple(simple_namespace), NamedTuple)
    simple_namespace.a = 1
    assert to_namedtuple(simple_namespace) == NamedTuple(a=1)
    simple_namespace.b = 2
    assert to_namedtuple(simple_namespace) == NamedTuple(a=1, b=2)
    simple_namespace = module_0.SimpleNamespace(a=1, b=2)
    assert to_namedtuple(simple_namespace) == NamedTuple(a=1, b=2)

    # dictionary
    dictionary = dict()