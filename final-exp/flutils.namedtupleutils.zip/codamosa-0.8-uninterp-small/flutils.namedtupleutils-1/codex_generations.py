

# Generated at 2022-06-25 17:21:03.504964
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None

    with pytest.raises(ValueError):
        test_case_0()

    tuple_0 = [
        {
            "a": 1,
            "b": 2,
            "c": 3,
            "d": [
                4.0,
                5.5
            ],
            "e": {
                "f": None,
                "g": 6
            }
        },
        {
            "a": 1,
            "b": 2,
            "c": 3,
            "d": [
                4.0,
                5.5
            ],
            "e": {
                "f": None,
                "g": 6
            }
        }
    ]
    result = to_namedtuple(tuple_0)

# Generated at 2022-06-25 17:21:10.732749
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = OrderedDict((
        ('_', 1),
        ('1A', True),
        ('A', 2),
        ('B', OrderedDict((
            ('a', 1),
            ('b', 2),
        ))),
    ))
    out = to_namedtuple(data)
    assert isinstance(out, NamedTuple)
    assert out.A == 2
    assert out.B.a == 1
    assert out.B.b == 2



# Generated at 2022-06-25 17:21:14.218091
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:21:20.159713
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_0 = {
        'a': 123,
        'b': 'hi',
        'c': None,
    }
    var_1 = to_namedtuple(var_0)
    var_2 = repr(var_1)
    var_2 = var_2 == "NamedTuple(a=123, b='hi', c=None)"
    var_3 = var_1.a
    var_3 = var_3 == 123
    var_4 = var_1.b
    var_4 = var_4 == 'hi'
    var_5 = var_1.c
    var_5 = var_5 is None
    var_6 = isinstance(var_1, NamedTuple)
    var_7 = var_1._asdict()

# Generated at 2022-06-25 17:21:30.734956
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict((('a', 1), ('b', 2)))) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(**{'a': 1, 'b': 2})) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(**{'b': 2, 'a': 1})) == NamedTuple(a=1, b=2)

# Generated at 2022-06-25 17:21:35.189285
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = to_namedtuple({'a': 1, 'b': 2})
    print(obj)


# noinspection PyUnresolvedReferences

# Generated at 2022-06-25 17:21:44.103294
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the function to_namedtuple."""
    # Case 0:
    var_0 = 'Hello, world'
    var_1 = to_namedtuple(var_0)
    assert var_0 == var_1
    var_0 = -40.25
    var_1 = to_namedtuple(var_0)
    assert var_0 == var_1
    var_0 = (1, 2, 3)
    var_1 = to_namedtuple(var_0)
    assert var_0 == var_1
    var_0 = [1, 2, 3]
    var_1 = to_namedtuple(var_0)
    assert var_0 == var_1
    var_0 = {'hello': 'world'}
    var_1 = to_namedtuple(var_0)

# Generated at 2022-06-25 17:21:47.888465
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 17:22:00.477874
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test proper exception is thrown when given type is None
    try:
        var_0 = None
        to_namedtuple(var_0)
        assert False
    except TypeError:
        assert True

    # Test proper exception is thrown when given type is not allowed
    try:
        var_1 = []
        to_namedtuple(var_1)
        assert False
    except TypeError:
        assert True

    # Test proper exception is thrown when given list item is not allowed
    try:
        var_2 = ['']
        to_namedtuple(var_2)
        assert False
    except TypeError:
        assert True

    # Test proper exception is thrown when given list item is not allowed

# Generated at 2022-06-25 17:22:05.619293
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import randint
    import string

    def _make_dic():
        depth = randint(1, 2)
        out: Mapping = {}
        for letter in string.ascii_letters[:randint(1, 3)]:
            if depth == 1:
                val = randint(-100, 100)
            else:
                val = _make_dic()
            out[letter] = val
        return out

    test_0 = _make_dic()
    out = to_namedtuple(test_0)
    assert isinstance(out, NamedTuple)

    # Test an empty dictionary.
    test_1: Mapping = {}
    out = to_namedtuple(test_1)
    assert isinstance(out, NamedTuple)

    # Test an OrderedDict.

# Generated at 2022-06-25 17:22:19.989487
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_0 = {}
    var_1 = to_namedtuple(var_0)
    var_2 = {}
    var_3 = to_namedtuple(var_2)
    var_4 = {}
    var_5 = to_namedtuple(var_4)
    var_6 = {}
    var_7 = to_namedtuple(var_6)
    var_8 = {}
    var_9 = to_namedtuple(var_8)
    var_10 = {}
    var_11 = to_namedtuple(var_10)
    var_12 = {}
    var_13 = to_namedtuple(var_12)
    var_14 = {}
    var_15 = to_namedtuple(var_14)
    var_16 = {}
    var_17 = to_named

# Generated at 2022-06-25 17:22:30.118435
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.testingutils import (
        make_random_numbers,
        make_random_string,
    )

    mak = make_random_numbers
    make = make_random_string
    var_0 = {
        make(): mak(), make(): mak(), make(): mak(),
        make(): mak(), make(): mak(), make(): mak(),
    }
    var_1 = to_namedtuple(var_0)
    assert var_1.__dict__ == var_0
    var_2 = var_0.copy()
    var_2.update({
        make(): mak(), make(): mak(), make(): mak(),
        make(): mak(), make(): mak(), make(): mak(),
    })
    var_3 = to_namedtuple(var_2)

# Generated at 2022-06-25 17:22:42.154423
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Sequence
    from pprint import pprint

    _namedtuple = namedtuple('NamedTuple', 'a b c')
    dic = {'a': 1, 'b': 2, 'c': 3}
    # noinspection PyTypeChecker
    lst: list = [1, 2, 3, dic]
    dic_lst_tup = (_namedtuple(1, 2, 3), lst, tuple(lst))

# Generated at 2022-06-25 17:22:52.896660
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    def assert_msg(
            msg: str,
            var_0: Union[tuple, dict],
            var_1: Union[NamedTuple, tuple, dict],
            exp_0: Union[NamedTuple, tuple, dict],
            exp_1: Union[NamedTuple, tuple, dict],
    ) -> None:
        var_2 = to_namedtuple(var_0)
        assert var_2 == exp_0
        var_3 = to_namedtuple(var_1)
        assert var_3 == exp_1

    var_0 = (1, 2, 3)
    var_1: tuple = (1, 2, 3)
    exp_0 = (1, 2, 3)
    exp_1 = (1, 2, 3)


# Generated at 2022-06-25 17:23:02.286019
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from flutils.namedtupleutils import to_namedtuple
    import sys

    obj_0 = (1, 2)

    obj_2 = to_namedtuple(obj_0)
    obj_1 = (1, 2)
    assert obj_2 == obj_1

    obj_3 = NamedTuple(*obj_0)
    obj_2 = to_namedtuple(obj_3)
    obj_1 = obj_3
    assert obj_2 == obj_1

    obj_4 = SimpleNamespace(c=1, a=2, b=3)
    obj_2 = to_namedtuple(obj_4)
    obj_1 = obj_4
    obj_1.a = 1
    obj_1.b = 2

# Generated at 2022-06-25 17:23:08.712742
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple"""
    from io import StringIO
    from flutils.namedtupleutils import to_namedtuple
    from flutils.test import TestExceptionWrapper
    from collections import OrderedDict
    from types import SimpleNamespace

# Generated at 2022-06-25 17:23:21.381839
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    var_0 = ['a', 'b']
    var_1 = (1, 2)
    var_2 = {'a': 1, 'b': 2}
    var_3 = (1, 2)
    var_4 = (1, var_0)
    var_5 = (1, (1, (1, (1, (1, 2)))))
    var_6 = (1, var_1, (1, (1, (1, (1, 2)))))
    var_7 = {'a': 1, 'b': 1, 'c': 1, 'd': 1, 'e': 1}
    var_8 = {'a': 1, 'b': 1, 'c': 1, 'd': 1, 'e': 1, 'f': {}}

# Generated at 2022-06-25 17:23:29.983474
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == NamedTuple(a=1, b=2, c=3, d=4)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == NamedTuple(a=1, b=2, c=3, d=4, e=5)

# Generated at 2022-06-25 17:23:33.754375
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    dic = {'a': 1, 'b': 2}

    # Act
    result = to_namedtuple(dic)

    # Assert
    assert result.a == 1
    assert result.b == 2



# Generated at 2022-06-25 17:23:45.540884
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import date, datetime
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    dic = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': {
            'a': 1,
            'b': 2
        },
        'e': [
            {
                'c': {
                    'a': 1,
                    'b': 2
                }
            }
        ]
    }
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3
    assert out.d.a == 1
    assert out.d.b == 2
    assert out.e[0].c.a == 1

# Generated at 2022-06-25 17:23:57.419040
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    obj = OrderedDict([('a', 1), ('b', 2)])
    out: Any
    out = to_namedtuple(obj)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert out.a == 1
    assert out.b == 2
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert out.a == 1
    assert out.b == 2
    obj = {'a': 1, 'b': 2, '_c': 3, '_d': 4}
    out = to_namedt

# Generated at 2022-06-25 17:24:05.241736
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = {'a': 1, 'b': 2}
    b = to_namedtuple(a)
    assert b.a == 1
    assert b.b == 2

    a = {'a': 1, 'b': 2, 'c_': 3, 'd3': 4}
    b = to_namedtuple(a)
    assert b.a == 1
    assert b.b == 2

    a = [
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
    ]
    b = to_namedtuple(a)
    assert all([x.a == 1 for x in b])
    assert all([x.b == 2 for x in b])


# Generated at 2022-06-25 17:24:13.344751
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': {
            'b': 1,
            'c': 2,
        },
        'd': {
            'e': 3,
            'f': 4,
        },
    }
    nt = to_namedtuple(dic)
    assert repr(nt) == "NamedTuple(a=NamedTuple(b=1, c=2), d=NamedTuple(e=3, f=4))"

    dic = {
        'a': 1,
        'b': 2,
    }
    nt = to_namedtuple(dic)
    assert repr(nt) == "NamedTuple(a=1, b=2)"

    dic = {
        'a': 1,
        'b': 2,
    }
    lst

# Generated at 2022-06-25 17:24:25.428608
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:24:40.033073
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_0 = [1, 2, 3]
    var_0 = to_namedtuple(var_0)
    assert isinstance(var_0, list)
    assert var_0 == (1, 2, 3)
    var_0 = [{}, {'a': 1}, {'b': 2}]
    var_0 = to_namedtuple(var_0)
    assert isinstance(var_0, list)
    assert var_0 == (NamedTuple(), NamedTuple(a=1), NamedTuple(b=2))
    var_0 = [{'a': 1}, {'b': 2}]
    var_0 = to_namedtuple(var_0)
    assert isinstance(var_0, list)

# Generated at 2022-06-25 17:24:49.151354
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from os.path import expanduser
    from pprint import pprint
    from typing import Dict, List, Optional

    from flutils.namedtupleutils import to_namedtuple

    var_results_2: List[Optional[Dict[str, str]]] = [{
        'origin': 'PVD', 'destination': 'DFW'}]

    var_2: List[Any] = [{
        'origin': 'PVD', 'destination': 'DFW'}]

    var_3 = to_namedtuple(var_2)

    assert type(var_3) == list
    assert var_3 == var_results_2
    assert var_3[0] == var_results_2[0]


# Generated at 2022-06-25 17:25:03.072761
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    # parametrize the test inputs
    var_0 = None
    var_1 = (1, 2, 3)
    var_2 = (1, 2, '3', 4)
    var_3 = [1, 2, '3', 4]
    var_4 = []
    var_5 = tuple(var_4)
    var_6 = {'a': 1, 'b': 2}
    var_7 = OrderedDict((('a', 1), ('b', 2)))
    var_8 = {'a': 1, 'b': 2, '_c': 4}
    var_9 = {'a': 1, 'b': {'c': 3, 'd': 4}}

# Generated at 2022-06-25 17:25:15.370887
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == NamedTuple(a=1, b=2, c=3, d=4)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == NamedTuple(a=1, b=2, c=3, d=4, e=5)

# Generated at 2022-06-25 17:25:24.913989
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedtuple(unittest.TestCase):
        def test_to_namedtuple_0(self):
            var_0 = 'a'
            with self.assertRaises(TypeError):
                to_namedtuple(var_0)

        def test_to_namedtuple_1(self):
            var_0 = 'a'
            var_1 = to_namedtuple([var_0])
            self.assertEqual(var_1, ['a'])

        def test_to_namedtuple_2(self):
            var_0 = 1
            var_1 = to_namedtuple([var_0])
            self.assertEqual(var_1, [1])

        def test_to_namedtuple_3(self):
            var_0

# Generated at 2022-06-25 17:25:38.028027
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from types import (
        SimpleNamespace,
    )

    from flutils.namedtupleutils import to_namedtuple

    var_0 = ['a', 'b', 'c', 'd', 'e']
    var_1 = to_namedtuple(var_0)
    assert isinstance(var_1, list)
    assert var_1[0] == 'a'
    assert var_1[1] == 'b'
    assert var_1[2] == 'c'
    assert var_1[3] == 'd'
    assert var_1[4] == 'e'

    var_0 = ('a', 'b', 'c', 'd', 'e')
    var_1 = to_namedtuple(var_0)
   

# Generated at 2022-06-25 17:25:50.040929
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()


if __name__ == '__main__':
    import doctest
    doctest.testfile('README.rst')

# Generated at 2022-06-25 17:25:58.870791
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_0 = list()
    var_1 = to_namedtuple(var_0)
    assert isinstance(var_1, list)
    var_0 = list()
    var_0.append("22")
    var_1 = to_namedtuple(var_0)
    assert isinstance(var_1, list)
    var_0 = list()
    var_0.append("22")
    var_0.append("11")
    var_1 = to_namedtuple(var_0)
    assert isinstance(var_1, list)
    var_0 = list()
    var_0.append("22")
    var_0.append("11")
    var_0.append("1")
    var_1 = to_namedtuple(var_0)

# Generated at 2022-06-25 17:26:02.604448
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True

if __name__ == '__main__':
    # Unit test of function to_namedtuple
    test_to_namedtuple()
    test_case_0()

# Generated at 2022-06-25 17:26:09.810856
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from contextlib import redirect_stdout
    from io import StringIO
    from collections import OrderedDict
    from types import SimpleNamespace

    value = dict(a=1, b=2, c=dict(d=3, e=4, f=5))
    expected = 'NamedTuple(a=1, b=2, c=NamedTuple(d=3, e=4, f=5))'

    result = to_namedtuple(value)
    assert expected == str(result)

    value = dict(b=2, a=1, c=dict(f=5, e=4, d=3))
    expected = 'NamedTuple(a=1, b=2, c=NamedTuple(d=3, e=4, f=5))'

    result = to_namedtuple

# Generated at 2022-06-25 17:26:21.523454
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils
    import flutils.validators
    import typing_extensions
    # Type aliases
    NamedTuple_0 = typing.NamedTuple('NamedTuple_0', [('a', int), ('b', int)])
    str_0 = str()
    def func_0():
        var_0: typing.NamedTuple = typing_extensions.NamedTuple('NamedTuple', [('a', int), ('b', int)])
        var_1: typing.Optional[typing.NamedTuple] = flutils.namedtupleutils.to_namedtuple(str())
        var_2: typing.Optional[typing.NamedTuple] = flutils.namedtupleutils.to_namedtuple(list())

# Generated at 2022-06-25 17:26:33.796714
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_0 = to_namedtuple([])
    var_1 = to_namedtuple([{}])
    var_2 = to_namedtuple([{'a': 1, 'b': 2}])
    var_3 = to_namedtuple([{'a': 2, 'b': 1}])
    var_4 = to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}])
    var_5 = to_namedtuple([{'a': {'a': 1, 'b': 2}}])
    var_6 = to_namedtuple({'a': {'a': 1, 'b': 2}})
    var_7 = to_namedtuple(['_x', 'x_', 'x1'])
    var_8 = to_named

# Generated at 2022-06-25 17:26:45.442019
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from operator import itemgetter

    dic = {'a': 1, 'b': {'c': 3}, 'd': 4}
    to_namedtuple(dic)

    named_tuple = namedtuple('NamedTuple', 'a b c')
    var_0 = named_tuple(a=1, b=None, c=3)
    var_1 = to_namedtuple(var_0)

    dic = {'a': 1, 'b': 2}
    var_0 = namedtuple('NamedTuple', ['b', 'a'])(**dic)
    var_1 = to_namedtuple(var_0)
    var_2 = to_namedtuple(var_1)

    tup = (1, 2, 3)
    var_0 = to_namedt

# Generated at 2022-06-25 17:26:52.791847
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # List
    var_0 = []
    assert to_namedtuple(var_0) == []

    var_1 = [1]
    assert to_namedtuple(var_1) == [1]

    var_2 = [{'a': 2, 'b': 3}]
    assert to_namedtuple(var_2) == [NamedTuple(a=2, b=3)]

    var_3 = [{'a': 2, 'b': [1, 2, 3]}]
    # noinspection PyTypeChecker
    out_3 = [NamedTuple(a=2, b=[1, 2, 3])]
    assert to_namedtuple(var_3) == out_3

    var_4 = [[{'a': 1}, {'b': 2}]]
    # noins

# Generated at 2022-06-25 17:27:02.969293
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function."""
    test_case_0()
    assert True


if __name__ == '__main__':
    """Runs all functions with 'test_' prefix."""
    import sys

    mod = sys.modules[__name__]

    # noinspection PyUnresolvedReferences
    for func_name in dir(mod):
        if not func_name.startswith('test_'):
            continue
        # noinspection PyUnresolvedReferences
        func = getattr(mod, func_name)
        # noinspection PyBroadException
        try:
            func()
        except Exception:
            # noinspection PyProtectedMember
            print('Exception in %s' % func._test_name)

# Generated at 2022-06-25 17:27:14.879848
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class TestValue(NamedTuple):
        a: int = 0  # type: ignore[assignment]
        b: int = 1  # type: ignore[assignment]
    item = OrderedDict()
    item['a'] = 'a value'
    item['b'] = 1
    item['c'] = TestValue(1, 1)
    item['d'] = [TestValue(2, 2), TestValue(3, 3)]
    item['d'].append(TestValue(4, 4))
    item['e'] = item['d'][0]
    item['f'] = item['d'][1]
    item['g'] = item['d'][2]
    item['h'] = 'h'
    val = to_namedtuple(item)
    assert val.a == 'a value'
   

# Generated at 2022-06-25 17:27:39.196465
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test with non-code objects
    assert to_namedtuple('Hello world') == 'Hello world'

    # Test with NamedTuple
    named_tuple = namedtuple('NamedTuple', 'a b c')
    assert to_namedtuple(named_tuple(1, 2, 3)) == named_tuple(1, 2, 3)

    # Test with OrderedDict
    ordered_dict = OrderedDict(a=1, b=2, c=3)
    assert to_namedtuple(ordered_dict) == namedtuple('NamedTuple', 'a b c')(
        1, 2, 3
    )

    # Test with SimpleNamespace
    simple_name_space = SimpleNamespace(a=1, b=2, c=3)

# Generated at 2022-06-25 17:27:49.790398
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    # noinspection PyUnusedLocal,PyTypeChecker
    def test(var_0: Any, var_1: str, var_2: str) -> bool:
        """
        $to_namedtuple(var_0) == var_1
        :param var_0:
        :param var_1:
        :param var_2:
        :return:
        """
        try:
            var_3 = to_namedtuple(var_0)
            return var_3 == eval(var_1)
        except Exception as var_4:
            print(f'Exception: {var_4}')
            return False


# Generated at 2022-06-25 17:28:01.069081
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Testing when obj is None
    nt_0: NamedTuple = to_namedtuple(None)
    assert nt_0 == NamedTuple()
    # Testing when obj is a list
    nt_1: List[NamedTuple] = to_namedtuple([])
    assert isinstance(nt_1, list)
    assert not nt_1
    nt_2: List[NamedTuple] = to_namedtuple([0, 1, 2])
    assert isinstance(nt_2, list)
    assert nt_2[0] == 0
    assert nt_2[1] == 1
    assert nt_2[2] == 2
    # Testing when obj is a string
    nt_3: str = to_namedtuple('a')

# Generated at 2022-06-25 17:28:03.692150
# Unit test for function to_namedtuple
def test_to_namedtuple():
    in_out = {
        'a': 1,
        'b': 2
    }
    assert to_namedtuple(in_out) == in_out



# Generated at 2022-06-25 17:28:12.112803
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:28:23.228546
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # A
    assert to_namedtuple({}) == NamedTuple()  # type: ignore

    # B
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)  # type: ignore

    # C
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)  # type: ignore

    # D
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)  # type: ignore

    # E

# Generated at 2022-06-25 17:28:34.074898
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    TestNamedTuple = namedtuple('TestNamedTuple', 'a b')
    TestSimpleNamespace = SimpleNamespace
    TestSimpleNamespace.__name__ = 'TestSimpleNamespace'
    TestNamedTuple.__name__ = 'TestNamedTuple'
    TestSimpleNamespace = SimpleNamespace

    assert to_namedtuple([]) == []
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(TestNamedTuple(1, 2)) == TestNamedTuple(1, 2)

# Generated at 2022-06-25 17:28:40.997116
# Unit test for function to_namedtuple
def test_to_namedtuple():

    var_0 = {}
    var_1 = to_namedtuple(var_0)  # type: NamedTuple
    assert isinstance(var_1, NamedTuple)

    var_0 = {'a': 1, 'b': 2}
    var_1 = to_namedtuple(var_0)  # type: NamedTuple
    assert isinstance(var_1, NamedTuple)

    var_0 = {'a': 1, 'b': {'b1': 11, 'b2': 12}}
    var_1 = to_namedtuple(var_0)  # type: NamedTuple
    assert isinstance(var_1, NamedTuple)

    var_0 = OrderedDict({'a': 1, 'b': {'b1': 11, 'b2': 12}})
    var_

# Generated at 2022-06-25 17:28:43.923700
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:28:54.546869
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import List

    from flutils.debugutils import trace_function

    trace_function(test_to_namedtuple.__name__)

    EXPECTED = (
        ("a", 1),
        ("b", '2'),
        ("c", {'c_a': '1', 'c_b': 2}),
        ("d", [{'a': 1}, {'b': 2}]),
    )
    NAMED_TUPLE = namedtuple('NamedTuple', tuple(key for key, _ in EXPECTED))
    input_dat = dict(EXPECTED)
    dat = to_namedtuple(input_dat)
    assert isinstance(dat, NAMED_TUPLE)
    assert dat == NAMED_TUPLE(*input_dat.values())

# Generated at 2022-06-25 17:29:35.445211
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    data = {
        'a': 1,
        'b': 2,
    }
    exp_data = to_namedtuple(data)
    assert exp_data.a == 1
    assert exp_data.b == 2

    bad_data = {
        '1': 1,
        '2': 2,
        '_': 0,
        'a': 3,
        'b': 4,
    }
    with pytest.raises(TypeError):
        exp_data = to_namedtuple(bad_data)

    bad_data_2 = {
        1: 1,
        2: 2,
        3: 3,
    }
    with pytest.raises(TypeError):
        exp_data = to_namedtuple(bad_data_2)


# Generated at 2022-06-25 17:29:44.442609
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from datetime import datetime
    from types import SimpleNamespace
    from typing import Dict, List, Tuple

    dic = dict(a=1, b=2)
    nt_0 = to_namedtuple(dic)
    nt_1 = to_namedtuple(('a', 1))
    nt_2 = to_namedtuple([dic, ('a', 1)])
    nt_3 = to_namedtuple(OrderedDict(a=1, b=2))
    nt_4 = to_namedtuple(SimpleNamespace(b=2, a=1))

    assert isinstance(dic, dict)
    assert isinstance(nt_0, NamedTuple)
    assert isinstance(nt_1, NamedTuple)
   

# Generated at 2022-06-25 17:29:45.090308
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    test_case_0()

# Generated at 2022-06-25 17:29:52.171815
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils import namedtupleutils
    
    var_0 = {'a': 1, 'b': 2}
    var_1 = namedtupleutils.to_namedtuple(var_0)

    var_2 = (1, 2)
    var_3 = namedtupleutils.to_namedtuple(var_2)

    var_4 = [1, 2]
    var_5 = namedtupleutils.to_namedtuple(var_4)

    var_6 = None
    var_7 = namedtupleutils.to_namedtuple(var_6)


# Generated at 2022-06-25 17:29:58.607477
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:30:10.212544
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_2 = [{'a': 1, 'b': {'c': 3}}, {'b': {'c': 30}, 'a': 10}]
    var_3 = (
        {'a': 1, 'b': {'c': 3}}, 
        {'b': {'c': 30}, 'a': 10}
    )
    var_4 = {'a': 1, 'b': {'c': 3}}
    var_5 = {'b': {'c': 30}, 'a': 10}
    # Testing to_namedtuple with normal values
    var_6 = to_namedtuple(var_2)
    assert isinstance(var_6, list)
    for var_7 in var_6:
        assert isinstance(var_7, NamedTuple)
        assert var_7.a

# Generated at 2022-06-25 17:30:17.067826
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(tuple()) == tuple()
    assert to_namedtuple({}) == NamedTuple()

    assert to_namedtuple({'name': 'value'}) == NamedTuple(name='value')
    assert to_namedtuple({'name': 'value'}) == to_namedtuple(OrderedDict(name='value'))
    assert to_namedtuple(OrderedDict(name='value')) == to_namedtuple(SimpleNamespace(name='value'))

    data = dict(name='value')
    assert to_namedtuple(data) == NamedTuple(name='value')
    data = OrderedDict(name='value')
    assert to_namedtuple(data) == NamedTuple(name='value')
   

# Generated at 2022-06-25 17:30:20.183817
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    named_tuple = to_namedtuple(dic)
    assert named_tuple.a == 1



# Generated at 2022-06-25 17:30:23.113867
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple().
    """
    #  empty list,
    var_0 = []
    assert isinstance(to_namedtuple(var_0), list)



# Generated at 2022-06-25 17:30:31.914855
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.py23compat import (
        PY2,
        PY3,
    )
    from typing import (
        List,
        NamedTuple,
        Tuple,
        Union,
    )
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from types import SimpleNamespace

    _TupleT = cast(Tuple[int, str], (2, 'two'))
    _ListT = cast(List[str], ['a', 'b', 'c'])
    _DictT = cast(OrderedDict, OrderedDict([(2, 'two'), (1, 'one')]))
    _DictT2 = cast(dict, {'a': 1})
    _EmptyDictT = cast(dict, {})
    _EmptyD