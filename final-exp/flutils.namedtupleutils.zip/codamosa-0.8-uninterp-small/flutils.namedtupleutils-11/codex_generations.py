

# Generated at 2022-06-25 17:21:05.484509
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'b': 99, 'a': ['a', 'b', {'c': 99}], 'c': ['d', 'e']}
    out = to_namedtuple(dic)
    assert out.a == ('a', 'b', NamedTuple(c=99))
    assert out.b == 99
    assert out.c == ('d', 'e')

    odic = OrderedDict([('b', 99), ('a', ['a', 'b', {'c': 99}]), ('c', ['d', 'e'])])
    out = to_namedtuple(odic)
    assert out.b == 99
    assert out.a == ('a', 'b', NamedTuple(c=99))
    assert out.c == ('d', 'e')


# Generated at 2022-06-25 17:21:16.233756
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # module level function
    # test function to_namedtuple
    assert True
    tuple_1 = (1, 2, 3, 4, 5)
    var_1 = to_namedtuple(tuple_1)
    assert var_1.__class__.__name__ == 'NamedTuple'
    assert (var_1.__getnewargs__() == (1, 2, 3, 4, 5))
    assert (var_1.__getstate__() is None)
    assert (var_1._fields == ('_1', '_2', '_3', '_4', '_5'))
    assert (var_1._replace() == var_1)

# Generated at 2022-06-25 17:21:20.968280
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('> Start test_to_namedtuple <')
    print('> Function to_namedtuple: True <')
    assert to_namedtuple((1, 2, 3, 4, 5)) == namedtuple('NamedTuple', '')()
    print('> Function to_namedtuple: True <')
    assert to_namedtuple((1, 2, 3, 4, 5)) == namedtuple('NamedTuple', '')()
    print('> Function to_namedtuple: True <')
    assert to_namedtuple([]) == []
    print('> Function to_namedtuple: True <')
    assert to_namedtuple([1, 2, 3, 4, 5]) == []
    print('> Function to_namedtuple: True <')
    assert to_namedtuple({}) == namedt

# Generated at 2022-06-25 17:21:31.832923
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import (
        namedtuple,
        OrderedDict,
    )
    make = namedtuple('NamedTuple', 'a b')
    odic = OrderedDict({'a': 1, 'b': 2})
    odic2 = OrderedDict({'c': 1, 'd': 2})
    odic3 = OrderedDict({'b': [1, 2], 'a': [odic, odic2]})
    odic4 = OrderedDict({
        'a': 1,
        'b': 2,
        'c': {
            'a': 1,
            'b': 2,
            'd': [0, 1]
        }
    })

# Generated at 2022-06-25 17:21:42.916311
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test conversion of a NamedTuple
    tuple_0 = (1, 2, 3, 4)
    var_0 = to_namedtuple(tuple_0)
    assert var_0.__class__ == namedtuple('NamedTuple', ('0', '1', '2', '3'))
    assert var_0._fields == ('0', '1', '2', '3')
    assert var_0[0] == 1
    assert var_0[1] == 2
    assert var_0.__repr__() == "NamedTuple(0=1, 1=2, 2=3, 3=4)"
    assert var_0[2] == 3
    assert var_0[3] == 4
    # Test conversion of a list
    list_0 = [1, 2, 3, 4]
   

# Generated at 2022-06-25 17:21:59.673648
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = (
        {'a': {'b': 'c'}},
        3,
        [
            {'g': 'h'},
            {'i': {'j': 'k'}},
            {'c': {'d': {'e': 'f'}}},
            (1, 2),
            [
                {'l': 'm'},
                {'n': 'o'},
                {'p': {'q': 'r'}},
            ],
        ],
    )
    namedtuple_0 = to_namedtuple(tuple_0)
    assert tuple_0[0]['a']['b'] == 'c'
    assert namedtuple_0[0].a.b == 'c'
    assert tuple_0[1] == 3
    assert namedt

# Generated at 2022-06-25 17:22:05.293904
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # "NamedTupleUtils.test_to_namedtuple"
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from types import SimpleNamespace

    from typing import (
        Any,
        Dict,
        List,
        NamedTuple,
        Tuple,
        Union,
    )

    tuple_0: Tuple[int, ...] = (1, 2, 3)
    var_0 = to_namedtuple(tuple_0)
    assert isinstance(var_0, NamedTuple)
    assert isinstance(var_0, tuple)
    assert len(var_0) == len(tuple_0)
    assert var_0.count(1) == 1
    assert var

# Generated at 2022-06-25 17:22:14.416357
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import (
        List,
        NamedTuple,
        Tuple,
    )
    from collections import OrderedDict

    my_list = [
        1,
        {'a': 10, 'b': 20},
        (False, True, 'xyz'),
        [2, 3, 4],
    ]
    var_0 = to_namedtuple(my_list)

    my_tuple = (
        1,
        {'a': 10, 'b': 20},
        (False, True, 'xyz'),
        [2, 3, 4],
    )
    var_1 = to_namedtuple(my_tuple)


# Generated at 2022-06-25 17:22:26.492417
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test to_namedtuple function
    """

    # create a dictionary
    dic = {"item_1": 1, "item_2": 2, "item_3": 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'item_1 item_2 item_3')(1, 2, 3)

    # create a dictionary using OrderedDict
    from collections import OrderedDict
    dic = OrderedDict((("item_1", 1), ("item_2", 2), ("item_3", 3)))
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'item_1 item_2 item_3')(1, 2, 3)

    # create a dictionary with nested dictionary

# Generated at 2022-06-25 17:22:39.946061
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    obj = [
        {
            'first_name': 'George',
            'last_name': 'Costanza',
        },
        {
            'first_name': 'Jerry',
            'last_name': 'Seinfeld',
        },
        {
            'first_name': 'Elaine',
            'last_name': 'Benes',
        },
    ]
    obj_1 = OrderedDict(
        first_name='George',
        last_name='Costanza',
    )
    obj_2 = SimpleNamespace(
        first_name='George',
        last_name='Costanza',
    )
    obj_3 = dict(
        first_name='George',
        last_name='Costanza',
    )

# Generated at 2022-06-25 17:22:56.222896
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test for function to_namedtuple
    """
    dic = dict(a=1, b=2)
    var = to_namedtuple(dic)
    assert type(var) is namedtuple('NamedTuple', list(dic.keys()))



# Generated at 2022-06-25 17:23:05.646879
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': [1, 2]}) == namedtuple('NamedTuple', ['a'])([1, 2])
    assert to_namedtuple({'a': (1, 2)}) == namedtuple('NamedTuple', ['a'])((1, 2))
    assert to_namedtuple({'a': {'b': 1}}) == namedtuple('NamedTuple', ['a'])(dict(b=1))
    assert to_namedtuple({'a': 1, 'b': {'c': {'d': 1, 'e': 2}}}) == namedtuple(
        'NamedTuple', ['a', 'b']
    )(1, dict(c=dict(d=1, e=2)))


# Generated at 2022-06-25 17:23:19.278210
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_dict = {
        'a': 1,
        'b': 2,
    }
    test_dict_0 = {
        'a': [1, 2, 3],
        'b': [],
        'c': [
            [1, 2, 3],
            [
                {'a': 1, 'b': 2},
                {'a': 1, 'c': 2},
            ],
        ],
        'd': {
            'a': 1,
            'b': 2,
            'c': 3,
            'd': 6,
            'e': 5,
            'f': 4,
        },
        'e': 'a',
        'f': 1.0,
    }

# Generated at 2022-06-25 17:23:28.695849
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple([[], {}]) == [NamedTuple(), NamedTuple()]
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple(
        [
            {'a': 1, 'b': 2},
            {'a': 3, 'b': 4},
        ]
    ) == [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]

# Generated at 2022-06-25 17:23:35.140342
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # ! test namespace
    class Namespace0(SimpleNamespace):
        a = 'abc'
        b = 'def'
        c = 'ghi'
    nspc = Namespace0()
    nspc_conv = to_namedtuple(nspc)
    assert isinstance(nspc_conv, tuple)

    # ! test simple tuple
    tple = ('a', 'b', 'c')
    tple_conv = to_namedtuple(tple)
    assert isinstance(tple_conv, tuple)
    tple = ('a', 'b', dict(c='d'))
    tple_conv = to_namedtuple(tple)
    assert isinstance(tple_conv, tuple)
    tple_conv_1 = tple_conv[2]

# Generated at 2022-06-25 17:23:38.504593
# Unit test for function to_namedtuple
def test_to_namedtuple():
    if not isinstance(to_namedtuple, Callable):
        raise AssertionError()

# vim: :noTabs=true:

# Generated at 2022-06-25 17:23:50.265393
# Unit test for function to_namedtuple
def test_to_namedtuple():
    namedtuple_0 = to_namedtuple(())
    namedtuple_1 = to_namedtuple(OrderedDict([]))
    namedtuple_2 = to_namedtuple([])
    # 'tuple' object has no attribute '_fields'
    # str = to_namedtuple('')
    namedtuple_3 = to_namedtuple(OrderedDict(a=1))
    namedtuple_4 = to_namedtuple(OrderedDict(b=2, a=1))
    # TypeError: Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (dict) {}
    # namedtuple_5 = to_namedtuple(SimpleNamespace(a=1))

# Generated at 2022-06-25 17:24:00.488103
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from types import SimpleNamespace
    a_dict = {'a': 'a', 'b': 'b'}
    for key in a_dict.keys():
        assert validate_identifier(key, allow_underscore=False)
    assert a_dict.keys() == {'a', 'b'}
    sorted_keys = sorted(a_dict.keys())
    assert sorted_keys
    assert a_dict == {'a': 'a', 'b': 'b'}
    assert hasattr(a_dict, 'keys')
    a_dict['a'] = 2
    at: NamedTuple = to_namedtuple(a_dict)
    assert isinstance(at, NamedTuple)

# Generated at 2022-06-25 17:24:11.595661
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Test for function to_namedtuple'''
    for _i in range(25):
        print('Test', _i)
        if _i == 0:
            tuple_0 = ()
            var_0 = to_namedtuple(tuple_0)
            var_1 = ()
            assert var_0 == var_1, 'Failed assert 0'
        elif _i == 1:
            tuple_1 = (1, 2, 3)
            var_2 = to_namedtuple(tuple_1)
            var_3 = (1, 2, 3)
            assert var_2 == var_3, 'Failed assert 1'
        elif _i == 2:
            dic = {1: 1, 2: 2, 3: 3}
            var_4 = to_namedtuple(dic)

# Generated at 2022-06-25 17:24:12.570134
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """The function to_namedtuple."""
    pass

# Generated at 2022-06-25 17:24:29.239235
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Create a list of 'int'
    list_0 = [1,2,3]
    # Call function 'to_namedtuple'
    try:
        returned_value_0 = to_namedtuple(
            list_0
        )
    except TypeError:
        returned_value_0 = None
    # Check if the value returned
    # by function 'to_namedtuple'
    # is equal to '1'
    assert returned_value_0 == [1,2,3]
    # Create a list of 'int'
    list_0 = []
    # Call function 'to_namedtuple'
    try:
        returned_value_0 = to_namedtuple(
            list_0
        )
    except TypeError:
        returned_value_0 = None
    # Check if the value returned


# Generated at 2022-06-25 17:24:40.762553
# Unit test for function to_namedtuple
def test_to_namedtuple():

    with raises(TypeError):
        to_namedtuple(test_case_0)

    with raises(TypeError):
        to_namedtuple(RuntimeError())

    assert to_namedtuple({'a': 1, 'b': 2}) == (1, 2)
    assert to_namedtuple(dict(b=2, a=1)) == (1, 2)
    assert to_namedtuple(dict(
        a=1,
        b=dict(
            c=OrderedDict(
                d=3,
                e=dict(
                    f=4,
                    g=5
                )
            )
        ),
        h=6
    )) == (1, (3, (4, 5)), 6)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:24:47.447170
# Unit test for function to_namedtuple
def test_to_namedtuple():
  # Test with None.
  with pytest.raises(TypeError) as err:
    to_namedtuple(None)
  assert str(err.value) == "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (NoneType) None"

  # Test with int.
  with pytest.raises(TypeError) as err:
    to_namedtuple(1)
  assert str(err.value) == "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (int) 1"

  # Test with float.
  with pytest.raises(TypeError) as err:
    to_namedtuple(1.1)

# Generated at 2022-06-25 17:24:59.568463
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class TempClass:
        def __init__(self):
            self.variable_0: int = 0
            self.variable_1: str = ''


# Generated at 2022-06-25 17:25:08.348003
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test case where obj is not a list or a tuple or a dict
    with pytest.raises(TypeError):
        assert to_namedtuple(1)
        assert to_namedtuple(1.1)
        assert to_namedtuple(True)
        assert to_namedtuple('test')
        assert to_namedtuple(AssertionError())
        assert to_namedtuple(PendingDeprecationWarning)

    # Test case where obj is a list
    try:
        assert to_namedtuple([]) == []
    except TypeError as err:
        test_case_0()
    try:
        assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    except TypeError as err:
        test_case_0()

# Generated at 2022-06-25 17:25:14.544836
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    expected = NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == expected


if __name__ == '__main__':
    if test_to_namedtuple():
        pass

# Generated at 2022-06-25 17:25:24.622148
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import json

    # - 0 -

# Generated at 2022-06-25 17:25:37.830935
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import defaultdict, OrderedDict
    from types import SimpleNamespace

    # check exceptions
    try:
        to_namedtuple('test')
        test_case_0
    except AssertionError:
        pass

    # test list conversion
    lst = [1, 2, 3]
    lst_conv = to_namedtuple(lst)
    assert lst_conv == [1, 2, 3]
    assert lst != lst_conv

    # test unordered dict conversion
    dic = {'a': 1, 'b': 2}
    dic_conv = to_namedtuple(dic)
    assert dic_conv.a == 1
    assert dic_conv.b == 2

# Generated at 2022-06-25 17:25:51.894499
# Unit test for function to_namedtuple
def test_to_namedtuple():
    try:
        var_0 = AssertionError()
        assert False, (var_0, var_0.__class__.__name__)
    except AssertionError:
        var_1 = AssertionError()
        assert False, (var_1, var_1.__class__.__name__)
    except:
        pass
    try:
        var_2 = to_namedtuple(1)  # type: ignore[no-any-return]
        assert False, (var_2, var_2.__class__.__name__)
    except TypeError:
        var_3 = TypeError()
        assert False, (var_3, var_3.__class__.__name__)
    except:
        pass

# Generated at 2022-06-25 17:26:07.426848
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Setup
    var_0 = to_namedtuple(())
    var_1 = to_namedtuple('')
    var_2 = to_namedtuple([])
    var_3 = to_namedtuple({})
    var_4 = to_namedtuple({})
    var_5 = to_namedtuple({'a': 1, 'b': 2})
    var_6 = to_namedtuple((1, 2, 3))
    var_7 = to_namedtuple(['a', 'b', 'c'])
    var_8 = to_namedtuple([1, 2, 3, 4, 5])
    var_9 = to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)]))

# Generated at 2022-06-25 17:26:20.167256
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import os
    import sys
    import pytest

    from flutils.namedtupleutils import (
        __file__ as filepath,
        __name__ as funcname,
        to_namedtuple,
    )
    from collections import OrderedDict
    from types import SimpleNamespace
    from pprint import pprint


# Generated at 2022-06-25 17:26:27.065350
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test
    dic = {'a': 1, 'b': 2}
    var = to_namedtuple(dic)
    assert var.a == 1
    assert var.b == 2

    # Test
    dic = {"a": 2, "b": 1}
    var = to_namedtuple(dic)
    assert var.b == 1
    assert var.a == 2

    # Test
    dic = {"a": 2, "b": {"c": 3, "d": 4}}
    var = to_namedtuple(dic)
    assert var.a == 2
    assert var.b.c == 3
    assert var.b.d == 4

    # Test

# Generated at 2022-06-25 17:26:36.341192
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:26:39.865815
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)

    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert out.a == 1
    assert out.b == 2



# Generated at 2022-06-25 17:26:50.269054
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple((1, 2, 3)) == \
        (1, 2, 3)
    assert to_namedtuple([1, 2, 3]) == \
        [1, 2, 3]
    assert to_namedtuple([[1], [[2], 2], ("a", {"b": 2})]) == \
        [[1], [[2], 2], ("a", NamedTuple(b=2))]
    assert to_namedtuple({"a": 1}) == \
        NamedTuple(a=1)
    assert to_namedtuple({"b": 2, "a": 1}) == \
        NamedTuple(a=1, b=2)

# Generated at 2022-06-25 17:27:02.454453
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:27:14.427741
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Function to_namedtuple"""
    import flutils.namedtupleutils as nutils

    # list
    lst_0 = []
    lst_0_result = nutils.to_namedtuple(lst_0)
    lst_1 = [{}]
    lst_1_result = nutils.to_namedtuple(lst_1)
    lst_2 = [{}, {'a': 1, 'b': 2}]
    lst_2_result = nutils.to_namedtuple(lst_2)
    lst_3 = [{'a': 1, 'b': 2}]
    lst_3_result = nutils.to_namedtuple(lst_3)

# Generated at 2022-06-25 17:27:18.349973
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    tuple_0 = (1, 2)
    dic_1 = {'a': 1, 'b': tuple_0}
    obj_0 = SimpleNamespace(a=1, b=dic_1)
    expect_0 = to_namedtuple(dic_0)
    expect_1 = to_namedtuple(obj_0)
    expect_2 = to_namedtuple(tuple_0)
    actual_0 = to_namedtuple(dic_0)
    actual_1 = to_namedtuple(obj_0)
    actual_2 = to_namedtuple(tuple_0)
    assert expect_0 == actual_0
    assert expect_1 == actual_1
    assert expect_2 == actual_2

# Generated at 2022-06-25 17:27:26.642828
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    tuple_0 = (1, 2, 3, 4)
    tuple_1 = ((1, 2, 3), (4, 5, 6))
    list_0 = [1, 2, 3, 4]
    list_1 = [dic_0, tuple_0, list_0]
    list_2 = [list_1, list_1]
    dic_1 = dict(a=1, b=2, c=3)
    dic_2 = dict(a=1, b=dic_1, c=3)
    dic_3 = dict(a=1, b=dic_1, c=tuple_1)

# Generated at 2022-06-25 17:27:36.703022
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test 0: Empty List and Empty Tuple
    tuple_0 = ()
    list_0 = []
    var_0 = to_namedtuple(tuple_0)
    var_1 = to_namedtuple(list_0)
    assert len(var_0) == 0
    assert len(var_0._fields) == 0
    assert len(var_1) == 0
    assert len(var_1._fields) == 0

    # Test 1: List of Dictionaries and Tuple of Dictionaries
    list_1 = [{'a': 1, 'b': 2, 1: 3}]
    tuple_1 = ({'a': 1, 'b': 2, 1: 3},)
    var_2 = to_namedtuple(list_1)

# Generated at 2022-06-25 17:28:01.311936
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:28:10.368441
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0: dict = {}
    dic_0['a'] = 1
    dic_0['b'] = 2
    dic_0['c'] = 3
    dic_0['d'] = 4
    tuple_0 = (1, 2, 3, 4)
    list_0 = [1, 2, 3, 4]
    list_0_0 = [1, 2, 3, 4]
    list_0_0.append(dic_0)
    list_0_1 = [1, 2, 3, 4]
    list_0_1.append(tuple_0)
    list_0.append(list_0_0)
    list_0.append(list_0_1)
    list_0.append(dic_0)

# Generated at 2022-06-25 17:28:22.362775
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test namedtuple conversion
    # Test a valid namedtuple
    nt_0 = namedtuple('NamedTuple', ['a', 'b'])
    nt_1 = nt_0(1, 2)
    var_0 = to_namedtuple(nt_1)
    assert nt_1 == var_0
    assert type(var_0) is nt_0

    # Test a valid namedtuple with no attributes
    nt_0 = namedtuple('NamedTuple', [])
    nt_1 = nt_0()
    var_0 = to_namedtuple(nt_1)
    assert nt_1 == var_0
    assert type(var_0) is nt_0

    # Test list conversion
    # Test a valid list

# Generated at 2022-06-25 17:28:32.894783
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0: dict = {'a': 1, 'b': 2}
    out_0 = to_namedtuple(dic_0)
    assert out_0.a == 1
    assert out_0.b == 2

    dic_1: dict = {'a': 1, 'b': 2, '_c': 3}
    out_1 = to_namedtuple(dic_1)
    assert not hasattr(out_1, '_c')

    dic_2: dict = {'a': 1, 'b': 2, '_c': {'a': 1, 'b': 2}}
    out_2 = to_namedtuple(dic_2)
    assert not hasattr(out_2, '_c')
    assert out_2.a == 1
    assert out_2.b

# Generated at 2022-06-25 17:28:40.504910
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:28:50.744093
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Conversion of an empty tuple into a namedtuple.
    tuple_0 = ()
    var_0 = to_namedtuple(tuple_0)
    assert isinstance(var_0, NamedTuple)
    assert not var_0._fields

    tuple_0 = (0,)
    var_0 = to_namedtuple(tuple_0)
    assert isinstance(var_0, NamedTuple)
    assert var_0._fields == ('_1',)
    assert var_0[0] == 0

    tuple_0 = (1, 2, 3)
    var_0 = to_namedtuple(tuple_0)
    assert isinstance(var_0, NamedTuple)
    assert var_0._fields == ('_1', '_2', '_3')
    assert var_0[0]

# Generated at 2022-06-25 17:28:55.921277
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test for function to_namedtuple
    :return:
    """
    from io import StringIO
    from unittest import TestCase, main
    from unittest.mock import Mock, patch

    from flutils.namedtupleutils import to_namedtuple

    class TestToNamedTuple(TestCase):

        def test_case_0(self):
            """
            No parameter.
            :return:
            """
            from collections import namedtuple
            from typing import Tuple

            tuple_0: Tuple = ()
            var_0 = to_namedtuple(tuple_0)  # NamedTuple()
            self.assertEqual(var_0, namedtuple('NamedTuple', '')())


# Generated at 2022-06-25 17:29:07.422452
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    # noinspection PyTypeChecker
    nt: NamedTuple = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, '_b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1

    dic = {'a': 1, '__b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1


# Generated at 2022-06-25 17:29:15.681989
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Create a dictionary to be converted to a NamedTuple
    test_dict = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    actual_dict = to_namedtuple(test_dict)
    expected_dict = namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)
    # Make sure the NamedTuple is what we expect
    assert actual_dict == expected_dict

    # Create a dictionary with a value that is a dictionary.  Ensure it is
    # converted to a NamedTuple.
    test_dict = {
        'a': 1,
        'b': 2,
        'c': {
            'a': 1,
            'b': 2,
            'c': 3,
        },
    }


# Generated at 2022-06-25 17:29:26.668139
# Unit test for function to_namedtuple
def test_to_namedtuple():

    def assert_namedtuple(
            obj: _AllowedTypes,
            fields: List[str],
            values: List[Any]
    ) -> None:
        nt: NamedTuple = to_namedtuple(obj)
        assert isinstance(nt, NamedTuple)
        assert nt._fields == tuple(fields)
        assert values == list(nt)
        # noinspection PyProtectedMember
        assert all(isinstance(val, getattr(nt, field))
                   for val, field in zip(values, nt._fields))

    def assert_list_of_namedtuple(
            obj: _AllowedTypes,
            fields: List[str],
            values: List[Any],
            out: Union[List[Any], Tuple[Any, ...], str]
    ) -> None:
        assert_

# Generated at 2022-06-25 17:29:56.419236
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dictionary_0 = {'a': 1, 'b': 2}
    namedtuple_0 = to_namedtuple(dictionary_0)
    dictionary_1 = {'a': 1, 'b': 2, 'c': 3}
    namedtuple_1 = to_namedtuple(dictionary_1)
    list_0 = ['a', 'b', 'c']
    namedtuple_2 = to_namedtuple(list_0)
    dictionary_2 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    namedtuple_3 = to_namedtuple(dictionary_2)
    tuple_0 = ('a', 'b', 'c')
    namedtuple_4 = to_namedtuple(tuple_0)

# cProfile.run('test_

# Generated at 2022-06-25 17:30:06.537344
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = (1, 2)
    list_0 = [1, 2]
    dict_0 = {'a': 1, 'b': 2}
    dict_1 = {'b': 2, 'a': 1}
    od = OrderedDict()
    od['a'] = 1
    od['b'] = 2
    od_1 = OrderedDict()
    od_1['b'] = 2
    od_1['a'] = 1
    ns = SimpleNamespace()
    ns.a = 1
    ns.b = 2
    tuple_1 = (tuple_0, list_0, dict_0, od, ns)
    tuple_2 = (tuple_0, list_0, dict_1, od_1, ns)

# Generated at 2022-06-25 17:30:15.625936
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    tuple_0 = ('c', dic_0)
    dic_0['c'] = tuple_0
    list_0 = [4, dic_0]
    tuple_0 = (1, list_0)
    dic_0['d'] = list_0
    list_0.append(dic_0)
    list_0.append(tuple_0)
    dic_1 = {'a': 1, 'b': 2}
    dic_2 = {'a': 1, 'b': 2}
    dic_1['d'] = dic_0
    dic_0['e'] = dic_1
    dic_0['f'] = dic_2

# Generated at 2022-06-25 17:30:25.615990
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_1 = {'a': 1, 'b': 2}
    tuple_1 = to_namedtuple(dic_1)
    assert type(tuple_1) == namedtuple('NamedTuple', 'a b')
    assert tuple_1.a == 1
    assert tuple_1.b == 2

    dic_2 = {'a': 1, 'b': {'c': 3}}
    tuple_2 = to_namedtuple(dic_2)
    assert type(tuple_2.b) == namedtuple('NamedTuple', 'c')
    assert tuple_2.b.c == 3

    dic_3 = {'a': [1, 2, 3], 'b': 2}
    tuple_3 = to_namedtuple(dic_3)

# Generated at 2022-06-25 17:30:33.727073
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # default case
    tuple_1 = (1, 'a')
    var_1 = to_namedtuple(tuple_1)
    assert isinstance(var_1, tuple)
    assert len(var_1) == 2
    assert var_1.__class__.__name__ == 'NamedTuple'
    assert var_1._fields == ('0', '1')
    assert var_1[0] == 1
    assert var_1[1] == 'a'
    # simple tuple
    tuple_2 = (1, 'a', 3)
    var_2 = to_namedtuple(tuple_2)
    assert var_2._fields == ('0', '1', '2')
    assert var_2[0] == 1
    assert var_2[1] == 'a'
    assert var_

# Generated at 2022-06-25 17:30:44.668518
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == NamedTuple(a=1, b=2)
    dic = OrderedDict()
    dic['c'] = 3
    dic['d'] = 4
    out = to_namedtuple(dic)
    assert out == NamedTuple(c=3, d=4)
    dic = {'e': 5, 'f': 6}
    out = to_namedtuple(dic)
    assert out == NamedTuple(e=5, f=6)
    lst = [1, 2, 3, 4]
    out = to_namedtuple(lst)
    assert out == [1, 2, 3, 4]

# Generated at 2022-06-25 17:30:52.494046
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def check_obj(
            obj: _AllowedTypes,
            expected: _AllowedTypes,
    ) -> None:
        converted = to_namedtuple(obj)
        assert type(obj) is type(converted)
        assert converted.__class__ is not obj.__class__
        assert str(converted) == str(expected)

    check_obj(
        (),
        (),
    )
    check_obj(
        [],
        [],
    )
    check_obj(
        [1, 2, 3],
        [1, 2, 3],
    )
    check_obj(
        (1, 2, 3),
        (1, 2, 3),
    )
    check_obj(
        {},
        (),
    )