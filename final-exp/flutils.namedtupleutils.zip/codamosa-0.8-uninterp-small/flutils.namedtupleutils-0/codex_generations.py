

# Generated at 2022-06-25 17:20:52.829193
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {"a": 1, "b": 2}
    named_tuple_1 = to_namedtuple(dic)
    class_0 = named_tuple_1.__class__
    assert class_0 is namedtuple, 'Class is %s' % repr(class_0)
    assert 'a' in named_tuple_1._fields, 'Attribute a not in %s._fields' % repr(named_tuple_1._fields)
    assert 'b' in named_tuple_1._fields, 'Attribute b not in %s._fields' % repr(named_tuple_1._fields)
    attribute_0 = named_tuple_1.a
    assert attribute_0 is 1, 'Bad attribute a: %s' % repr(attribute_0)

# Generated at 2022-06-25 17:20:58.639749
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Assert (typing.Mapping[str, typing.Any], bool) -> typing.Any
    assert callable(to_namedtuple)
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 17:21:13.304828
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj_0 = {'a': 1, 'b': 2}
    out_0 = to_namedtuple(obj_0)
    obj_1 = {'a.b': 1, 'b.c': 2}
    out_1 = to_namedtuple(obj_1)
    obj_2 = {'a.b': 1, 'b.c': 2}
    out_2 = to_namedtuple(obj_2)
    obj_3 = {'a': {'b': 1}, 'b': 2}
    out_3 = to_namedtuple(obj_3)
    obj_4 = {'a': 1, 'b': 2}
    out_4 = to_namedtuple(obj_4)
    obj_5 = (1, 2)

# Generated at 2022-06-25 17:21:16.928373
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert not hasattr(test_to_namedtuple, '_test_completed')
    test_to_namedtuple._test_completed = True
    test_case_0()

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:21:18.705810
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-25 17:21:30.162729
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # str -> bool
    assert to_namedtuple('') == NamedTuple()
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple('12') == '12'
    assert to_namedtuple('aB') == 'aB'
    assert to_namedtuple('_a') == '_a'
    assert to_namedtuple('_') == '_'
    assert to_namedtuple('__') == '__'
    assert to_namedtuple('__a') == '__a'
    assert to_namedtuple('@!@') == '@!@'

    # list -> list
    assert to_namedtuple([]) == []
    assert to_namedtuple([[]]) == []

# Generated at 2022-06-25 17:21:42.447398
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'f': 0}) == to_namedtuple(to_namedtuple({'f': 0}))
    assert to_namedtuple({'f': 0}) == to_namedtuple(to_namedtuple({'f': 0}))
    assert to_namedtuple({'f': 0, 'g': 1}) == to_namedtuple(to_namedtuple({'f': 0, 'g': 1}))
    assert to_namedtuple({'f': 0, 'g': 1, 'h': 2}) == to_namedtuple(to_namedtuple({'f': 0, 'g': 1, 'h': 2}))
    assert to_namedtuple({'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4}) == to_named

# Generated at 2022-06-25 17:21:58.310819
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
    assert 1 == 1
   

# Generated at 2022-06-25 17:22:02.439771
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert type(to_namedtuple(1)) == int

# Generated at 2022-06-25 17:22:13.586829
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == NamedTuple(a=1, b=2)

    nt = NamedTuple(a=1, b=2)
    out = to_namedtuple(nt)
    assert out == nt

    sn = module_0.SimpleNamespace(a=1, b=2)
    out = to_namedtuple(sn)
    assert out == nt

    lst = [1, 2, 3, 4]
    out = to_namedtuple(lst)
    assert out == lst

    tup = tuple(lst)
    out = to_namedtuple(tup)
    assert out == tup


# Generated at 2022-06-25 17:22:23.408836
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Setup
    simple_namespace_0 = module_0.SimpleNamespace()
    # Assertion
    exception_message = "Expected object to be of type 'NamedTuple', but "
    exception_message += "instead got 'NoneType'."
    with pytest.raises(Exception, match=exception_message) as exception:
        to_namedtuple(simple_namespace_0)
    assert type(exception) == Exception

# Generated at 2022-06-25 17:22:26.856076
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Assertions
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)
    assert var_0 is not None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:22:30.192654
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:22:42.243522
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test for function to_namedtuple."""
    # Test cases
    def test_case_0():
        simple_namespace_0 = module_0.SimpleNamespace()
        var_0 = to_namedtuple(simple_namespace_0)
    def test_case_1():
        simple_namespace_0 = module_0.SimpleNamespace()
        simple_namespace_0.name = "abc"
        var_0 = to_namedtuple(simple_namespace_0)
    def test_case_2():
        simple_namespace_0 = module_0.SimpleNamespace()
        simple_namespace_0.name = "abc"
        simple_namespace_0.age = 30
        var_0 = to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:22:52.953592
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Raise TypeError with message only when started is None
    try:
        to_namedtuple(1)
    except TypeError as err:
        assert err.args[0] == "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: '(int) 1'"

    # Raise TypeError with message only when started is None
    try:
        to_namedtuple('a')
    except TypeError as err:
        assert err.args[0] == "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: '(str) a'"

    # _to_namedtuple(1)
    # _to_namedtuple('a')
    # _to_namedtuple(1, True)
    # _to_namedtuple('a', True)

    # Call

# Generated at 2022-06-25 17:23:02.313666
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test an empty SimpleNamespace
    simple_namespace_0 = SimpleNamespace()
    assert to_namedtuple(simple_namespace_0) == simple_namespace_0

    # Test an empty NamedTuple
    namedtuple_0 = namedtuple('Test', '')()
    assert to_namedtuple(namedtuple_0) == namedtuple_0

    # Test a non-empty NamedTuple
    namedtuple_1 = namedtuple('Test', 'a b c')
    expected_namedtuple_1 = namedtuple_1(a=1, b=2, c=3)
    assert to_namedtuple(expected_namedtuple_1) == expected_namedtuple_1

    # Test a NamedTuple inside an object and verify that the type remains the
    # same
    namespace

# Generated at 2022-06-25 17:23:03.482079
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True == False

# more testing of to_namedtuple...

# Generated at 2022-06-25 17:23:16.103601
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = dict()
    NamedTuple0 = to_namedtuple(dic)
    assert type(NamedTuple0) is namedtuple('NamedTuple', '')

    dic = dict()
    NamedTuple0 = to_namedtuple(dic)
    assert NamedTuple0() == NamedTuple0()

    dic = dict(a=1, b=2)
    NamedTuple0 = to_namedtuple(dic)
    assert type(NamedTuple0) is namedtuple('NamedTuple', ['a', 'b'])

    dic = dict(a=1, b=2)
    NamedTuple0 = to_namedtuple(dic)

# Generated at 2022-06-25 17:23:27.718457
# Unit test for function to_namedtuple
def test_to_namedtuple():

    sample = {
        'a': 1,
        'b': 2,
        'c': {'d': 3}
    }
    x = to_namedtuple(sample)
    assert all([x.a == 1, x.b == 2, x.c.d == 3])

    def func_0(x):
        return x

    assert all([
        isinstance(x, tuple),
        isinstance(x.a, int),
        isinstance(x.b, int),
        isinstance(x.c, tuple),
        isinstance(x.c.d, int),
    ])

    sample2 = {
        'a': 1,
        'b': 2,
        'c': {'d': 3, 'e': {'f': 4}}
    }

# Generated at 2022-06-25 17:23:41.393409
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple('str') == 'str'
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'0': '1'}) == NamedTuple(**{'0': '1'})
    assert to_namedtuple({'0': '1', '1': '2', '2': '3'}) == NamedTuple(**{'0': '1', '1': '2', '2': '3'})
    assert to_namedtuple({'a': '1', 'c': '2', 'b': '3'}) == NamedTuple(**{'a': '1', 'b': '3', 'c': '2'})

# Generated at 2022-06-25 17:23:59.089085
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Example 1:
    class SimpleClass:
        a = 1
        b = 2
        c = None

    simple_class = SimpleClass()
    assert to_namedtuple(simple_class) == SimpleClass()

    # Example 2:
    namedtuple_tuple = collections.namedtuple('SimpleNamedtuple', 'a b c')
    namedtuple_instance = namedtuple_tuple(1, 2, None)
    assert simple_class == to_namedtuple(namedtuple_instance)

    # Example 3:
    assert to_namedtuple(simple_class) == namedtuple_instance

    # Example 4:
    simple_namespace = SimpleNamespace()
    assert to_namedtuple(simple_namespace) == collections.namedtuple('NamedTuple', '')()

# Generated at 2022-06-25 17:24:10.885443
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _0 = {'a': 1, 'b': 2}
    _1 = to_namedtuple(_0)
    assert hasattr(_1, 'a')
    assert hasattr(_1, 'b')
    assert _1.a == 1
    assert _1.b == 2
    _2 = {'b': 2, 'a': 1}
    _3 = to_namedtuple(_2)
    assert hasattr(_3, 'a')
    assert hasattr(_3, 'b')
    assert _3.a == 1
    assert _3.b == 2
    _4 = OrderedDict({'a': 1, 'b': 2})
    _5 = to_namedtuple(_4)
    assert hasattr(_5, 'a')
    assert hasattr(_5, 'b')
    assert _5.a

# Generated at 2022-06-25 17:24:21.390057
# Unit test for function to_namedtuple
def test_to_namedtuple():
    error_message = 'Failed with ({}), expecting ({}), got ({})'
    var_0 = to_namedtuple({'a': 1, 'b': 2})
    assert var_0 == ('a', 'b')
    var_0 = to_namedtuple({'a': 1})
    assert var_0 == ('a',)
    var_0 = to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert var_0 == ('a', 'b')
    var_0 = to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))
    assert var_0 == ('b', 'a')

# Generated at 2022-06-25 17:24:35.491817
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    obj = {"a": 1, "b": 2}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)
    obj = {"a": 1, "b": 2, "c": 3}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2, c=3)
    obj = (1, 2, 3)
    assert to_namedtuple(obj) == (1, 2, 3)
    obj = ["a", "b", "c"]
    assert to_namedtuple(obj) == ["a", "b", "c"]
    obj = {1: 2, 3: 4}

# Generated at 2022-06-25 17:24:44.279750
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for a valid namedtuple
    simple_dictionary = {'a': 1, 'b': 2}
    expected = ('a', 'b')
    assert expected == to_namedtuple(simple_dictionary)._fields
    # Test for a valid namedtuple
    ordered_dictionary = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    expected = ('a', 'b', 'c')
    assert expected == to_namedtuple(ordered_dictionary)._fields
    # Test for a valid namedtuple
    simple_list = [1, 2, 3]
    expected = (1, 2, 3)
    assert expected == to_namedtuple(simple_list)
    # Test for an invalid namedtuple

# Generated at 2022-06-25 17:24:57.895234
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Sequence
    from functools import singledispatch
    from types import SimpleNamespace
    from typing import (
        Any,
        NamedTuple,
        Tuple,
        Union,
        cast,
    )
    from flutils.validators import validate_identifier
    import sys
    import types as module_0
    def test_case_0():
        simple_namespace_0 = module_0.SimpleNamespace()
        _args_0 = {'_started': False, 'obj': simple_namespace_0}
        _to_namedtuple_0 = _to_namedtuple(**_args_0)
        assert isinstance(_to_namedtuple_0, NamedTuple)

# Generated at 2022-06-25 17:25:04.171940
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for example 1
    dic_0 = {'a': 1, 'b': 2}
    nt_0 = to_namedtuple(dic_0)
    assert nt_0.a == 1
    assert nt_0.b == 2

# Generated at 2022-06-25 17:25:08.153095
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert callable(to_namedtuple), "to_namedtuple is not callable"

    assert not hasattr(to_namedtuple, '_to_namedtuple')

    assert to_namedtuple.__dict__['_to_namedtuple'].__name__ == '_to_namedtuple'

# Generated at 2022-06-25 17:25:16.220694
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({})
    assert to_namedtuple(OrderedDict(a=1))
    assert to_namedtuple(SimpleNamespace())
    assert to_namedtuple(SimpleNamespace(a=1))
    assert to_namedtuple([])
    assert to_namedtuple((1, 2, 3))
    assert to_namedtuple(tuple(OrderedDict(a=1, b=2)))

# Generated at 2022-06-25 17:25:19.159229
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(args=sys.argv))

# Generated at 2022-06-25 17:25:25.774784
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test with a dictionary.
    dictionary_0 = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    namedtuple_0 = to_namedtuple(dictionary_0)
    assert namedtuple_0._fields == ('a', 'b', 'c')
    assert namedtuple_0.a == 1
    assert namedtuple_0.b == 2
    assert namedtuple_0.c == 3

    # Test with a List.
    list_0 = [
        {
            'a': 1,
            'b': 2,
            'c': 3
        },
        {
            'a': 4,
            'b': 5,
            'c': 6
        }
    ]

# Generated at 2022-06-25 17:25:39.334662
# Unit test for function to_namedtuple
def test_to_namedtuple():
    ordered_dict_0 = OrderedDict()
    ordered_dict_0['a'] = 1
    ordered_dict_0['b'] = 2
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.a = 1
    simple_namespace_0.b = 2
    ordered_dict_1 = OrderedDict()
    ordered_dict_1['a'] = 1
    ordered_dict_1['b'] = ordered_dict_0
    assert ordered_dict_1.keys() == {'a', 'b'}
    assert ordered_dict_1['b'] == ordered_dict_0
    namedtuple_0 = to_namedtuple(list())
    assert isinstance(namedtuple_0, list)
    assert namedtuple_0 == []
    ordered_

# Generated at 2022-06-25 17:25:46.032689
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic = OrderedDict({'a': 1, 'b': 2})
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out == (1, 2)

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out == (1, 2)

    dic = {'b': 2, 'a': 1}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out == (1, 2)

    dic = {'a': 1, '_b': 2}
    out = to

# Generated at 2022-06-25 17:25:56.236628
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Make sure an empty SimpleNamespace is returned
    # as a NamedTuple with no fields.
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)
    assert(var_0._fields == ())
    assert(len(var_0) == 0)

    # Make sure a SimpleNamespace with two fields
    # is returned as NamedTuple with two fields.
    simple_namespace_1 = module_0.SimpleNamespace()
    simple_namespace_1.a = 1
    simple_namespace_1.b = 2

    var_1 = to_namedtuple(simple_namespace_1)
    assert(var_1._fields == ('a', 'b'))
    assert(len(var_1) == 2)


# Generated at 2022-06-25 17:26:02.534283
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)
    simple_namespace_1 = module_0.SimpleNamespace()
    simple_namespace_1.var_0 = 1
    var_1 = to_namedtuple(simple_namespace_1)


if __name__ == '__main__':
    try:
        test_case_0()
    except NameError as e:
        print(e)
    try:
        test_to_namedtuple()
    except NameError as e:
        print(e)

# Generated at 2022-06-25 17:26:03.857334
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()


# Generated at 2022-06-25 17:26:13.394760
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple(None) is None
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(OrderedDict({'a': 1, 'b': 2})) == \
        NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) == \
        NamedTuple(a=1, b=2, c=3)
   

# Generated at 2022-06-25 17:26:15.788985
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True  # Don't know how to test this yet
test_to_namedtuple()

# Generated at 2022-06-25 17:26:27.091381
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test nested namedtuples
    nested_namedtuple_0 = namedtuple('nested_namedtuple_0', 'a b')
    var_0 = to_namedtuple(nested_namedtuple_0(nested_namedtuple_0(1, 2), 3))
    var_1 = namedtuple('var_1', 'a b')
    nested_namedtuple_1 = to_namedtuple(var_1(1, 2))
    var_2 = to_namedtuple([1, 2, nested_namedtuple_0(nested_namedtuple_1, 3)])
    d = {'a': 1, 'b': {'c': 2}}
    # Ensure keys are sorted alphabetically
    var_3 = to_namedtuple(d)

# Generated at 2022-06-25 17:26:36.341692
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple({'b': 2, 'c': 3, 'a': 1}) == namedtuple('NamedTuple', ['a', 'b', 'c'])(a=1, b=2, c=3)
    assert to_namedtuple({'b': 2, 'c': 3, 'a': 1, 'd': [1,2,3]}) == namedtuple('NamedTuple', ['a', 'b', 'c', 'd'])(a=1, b=2, c=3, d=[1,2,3])

# Generated at 2022-06-25 17:26:44.125303
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()

# Generated at 2022-06-25 17:26:46.205960
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import types
    simple_namespace_0 = types.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:26:53.221407
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(0) == 0
    assert to_namedtuple(True) is True
    test_case_0()
    source = [
        {
            'a': 1,
            'b': 2,
        },
        {
            'c': 3,
            'd': 4,
        },
    ]
    out1 = [
        NamedTuple(a=1, b=2),
        NamedTuple(c=3, d=4),
    ]
    out2 = to_namedtuple(source)
    assert out1 == out2
    assert (out1[0].a, out1[0].b) == (out2[0].a, out2[0].b)

# Generated at 2022-06-25 17:27:03.928247
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Try to convert a list.
    lst_0 = []
    lst_0_out = to_namedtuple(lst_0)
    assert lst_0_out == lst_0

    # Try to convert a tuple.
    tpl_0 = tuple()
    tpl_0_out = to_namedtuple(tpl_0)
    assert tpl_0_out == tpl_0

    # Try to convert a dict.
    dic_0 = {'a': 1, 'b': 2}
    dic_0_out = to_namedtuple(dic_0)
    assert dic_0_out == dic_0
    dic_1 = {'a': 1, 'b': 2, 'c': object()}
    dic_1_out = to_named

# Generated at 2022-06-25 17:27:09.679130
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.a = 1
    simple_namespace_0.b = 2
    var_0 = to_namedtuple(simple_namespace_0)
    var_1 = var_0.a
    var_2 = var_0.b


# Generated at 2022-06-25 17:27:10.736453
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True
    test_case_0()

# Generated at 2022-06-25 17:27:21.520041
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:27:26.237419
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test classes
    class New:
        """Docstring for new class"""

        pass


    # Test attributes
    simple_namespace_0 = module_0.SimpleNamespace()
    # Test calls
    test_case_0()
    # Test exception raise
    with pytest.raises(TypeError):
        to_namedtuple(New())
    with pytest.raises(TypeError):
        to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:27:28.131481
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert ( # Assert whether function can properly do tests
        test_case_0() is None
    )


# Generated at 2022-06-25 17:27:37.575310
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0 = dict(a=1, c=dict(b='a', d=2))
    assert to_namedtuple(dict_0) == namedtuple('NamedTuple', ['a', 'c'])(a=1, c=namedtuple('NamedTuple', ['b', 'd'])(b='a', d=2))
    dict_1 = dict(a=1, c=dict(b='a', d=2), e=34)
    assert to_namedtuple(dict_1) == namedtuple('NamedTuple', ['a', 'c', 'e'])(a=1, c=namedtuple('NamedTuple', ['b', 'd'])(b='a', d=2), e=34)

# Generated at 2022-06-25 17:27:45.548483
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Tests to wrap up function to_namedtuple
    test_case_to_namedtuple(test_case_0)
    
    

# Generated at 2022-06-25 17:27:53.858774
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class Class0(object):
        def __init__(self, var0):
            self.var0 = var0
        def meth0(self):
            pass
        @property
        def prop0(self):
            return self.var0
        @prop0.setter
        def prop0(self, value):
            self.var0 = value
    def func0(var0):
        return var0 + 1
    class Class0(object):
        def __init__(self, var0):
            self.var0 = var0
        def meth0(self):
            pass
        @property
        def prop0(self):
            return self.var0
        @prop0.setter
        def prop0(self, value):
            self.var0 = value

# Generated at 2022-06-25 17:27:58.050937
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_0 = to_namedtuple([1, 2, 3, 4])
    assert var_0 == [1, 2, 3, 4]  # type: ignore[misc]


# Generated at 2022-06-25 17:28:01.805353
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace = module_0.SimpleNamespace()
    res = to_namedtuple(simple_namespace)
    expected_res = ()
    assert res == expected_res

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:28:10.711674
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Tests a typical scenario
    simple_namespace_0 = module_0.SimpleNamespace(a=1, b=2)
    var_0 = to_namedtuple(simple_namespace_0)
    var_1 = to_namedtuple(var_0)
    var_2 = to_namedtuple({'a':1, 'b':2, 'c':3})
    assert var_1 == var_2
    assert var_0.a == 1 and var_0.b == 2
    assert var_2.a == 1 and var_2.b == 2 and var_2.c == 3
    assert var_1.a == 1 and var_1.b == 2 and var_1.c == 3
    assert isinstance(var_0, namedtuple)

# Generated at 2022-06-25 17:28:13.348339
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple(True), None)


# Generated at 2022-06-25 17:28:16.424364
# Unit test for function to_namedtuple
def test_to_namedtuple():
    with pytest.raises(TypeError):
        simple_namespace_0 = module_0.SimpleNamespace()
        var_0 = to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:28:28.031266
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import _to_namedtuple

    _T_0_T_0 = to_namedtuple(['0'])
    assert isinstance(_T_0_T_0, list)
    assert len(_T_0_T_0) == 1
    assert _T_0_T_0[0] == '0'
    assert isinstance(_T_0_T_0[0], str)

    _T_0_T_1 = to_namedtuple([{'a': '0'}, {'b': '1'}])
    assert isinstance(_T_0_T_1, list)
    assert len(_T_0_T_1) == 2
    assert _T_0_T_1[0] == NamedTuple(a='0')
    assert _T_0

# Generated at 2022-06-25 17:28:37.270337
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(
        to_namedtuple({'a': 1, 'b': 2}),
        namedtuple('NamedTuple', ['a', 'b'])
    )
    assert isinstance(
        to_namedtuple([]),
        list
    )
    assert isinstance(
        to_namedtuple(()),
        tuple
    )
    assert isinstance(
        to_namedtuple(1),
        int
    )
    assert isinstance(
        to_namedtuple(''),
        str
    )

# Generated at 2022-06-25 17:28:48.778122
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:28:59.330178
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()

test_to_namedtuple()

# Generated at 2022-06-25 17:29:02.550935
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)

# vim: set filetype=python ts=4 sw=4 tw=72 expandtab:

# Generated at 2022-06-25 17:29:13.806786
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _test_to_namedtuple(
            expected: Any,
            obj: Any,
            *,
            is_type: bool = False,
            is_equal: bool = True,
    ) -> None:
        actual = to_namedtuple(obj)
        if is_type:
            assert isinstance(actual, expected)
        elif is_equal:
            assert expected == actual
        else:
            assert expected is not actual

    def _test_to_namedtuple_exception(
            expected: Exception,
            obj: Any,
    ) -> None:
        try:
            to_namedtuple(obj)
        except expected:
            pass
        else:
            assert False

    _test_to_namedtuple_exception(TypeError, None)
    _test_to_namedtuple

# Generated at 2022-06-25 17:29:24.816013
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Assert that when trying to convert a string, an exception is raised
    with pytest.raises(TypeError):
        _to_namedtuple('A string')
    # Assert that when trying to convert a string, an exception is raised
    with pytest.raises(TypeError):
        _to_namedtuple(43)
    # Assert that when trying to convert a string, an exception is raised
    with pytest.raises(TypeError):
        _to_namedtuple({'one': 1, 'two': 'two'})
    # Assert that when trying to convert a string, an exception is raised
    with pytest.raises(TypeError):
        _to_namedtuple(['one', 'two'])
    # Assert that when trying to convert a string, an exception is raised

# Generated at 2022-06-25 17:29:26.146863
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Dummy asserts to avoid warnings
    assert True
    assert True


# Generated at 2022-06-25 17:29:33.500839
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert_equal(isinstance(to_namedtuple(dict(a=1)), NamedTuple), True)
    assert_equal(isinstance(to_namedtuple(dict(a=1, b=2)), NamedTuple), True)
    assert_equal(to_namedtuple(dict(a=1, b=2)), _NamedTuple(a=1, b=2))
    assert_equal(isinstance(to_namedtuple(OrderedDict(a=1, b=2)), NamedTuple), True)
    assert_equal(to_namedtuple(OrderedDict(a=1, b=2)), _NamedTuple(a=1, b=2))

# Generated at 2022-06-25 17:29:44.418431
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test that proper TypeErrors are raised when given unexpected data types
    _values = [
        1,
        [1],
        (1, ),
        dict(),
        types.SimpleNamespace(),
    ]
    for _v in _values:
        with pytest.raises(TypeError):
            to_namedtuple(_v)

    # Test that a basic NamedTuple is created and returned
    _values = [
        dict(a=2),
        [dict(a=2)],
        (dict(a=2), ),
        types.SimpleNamespace(a=2),
    ]
    for _v in _values:
        _v = to_namedtuple(_v)
        assert isinstance(_v, tuple)
        assert _v._fields == ('a',)
        assert _v.a == 2



# Generated at 2022-06-25 17:29:47.732630
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)


# Generated at 2022-06-25 17:29:55.569882
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Sequence
    from functools import singledispatch
    from types import SimpleNamespace, MappingProxyType
    from typing import Any, Dict, List, Tuple, Union

    # Test case #0
    simple_namespace_0 = SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)

    # Test case #1
    ordered_dict_1 = OrderedDict()
    ordered_dict_1.update(a=1)
    ordered_dict_1.update(b=2)
    var_1 = to_namedtuple(ordered_dict_1)

    # Test case #2
    list_2 = [1, 2, 3]
    var_2 = to_namedtuple(list_2)

    #

# Generated at 2022-06-25 17:29:57.593722
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass


# Start the tests
if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(['-x'], [__file__]))

# Generated at 2022-06-25 17:30:27.786664
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestCase(unittest.TestCase):
        def test_basic(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertEqual(tuple(out._fields), ('a', 'b'))
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)

        def test_not_allowed_type(self):
            self.assertRaises(TypeError, to_namedtuple, 'a')
            self.assertRaises(TypeError, to_namedtuple, 1)

        def test_unnamed_dict(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)

# Generated at 2022-06-25 17:30:35.095063
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # using the string representation of each type, test the type
    assert type(to_namedtuple({'a': 1, 'b': 2})).__name__ == 'NamedTuple'
    assert type(to_namedtuple(OrderedDict(a=1, b=2))).__name__ == 'NamedTuple'
    assert type(to_namedtuple(dict(a=1, b=2))).__name__ == 'NamedTuple'
    assert type(to_namedtuple(OrderedDict(a=1, b=2))).__name__ == 'NamedTuple'
    assert type(to_namedtuple(SimpleNamespace(a=1, b=2))).__name__ == 'NamedTuple'

# Generated at 2022-06-25 17:30:36.877481
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(simple_namespace_0) == to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:30:47.310740
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # try converting a simple dictionary
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    # try converting a dictionary with a dictionary as a value
    dic = {'a': 1, 'b': {'c': 2, 'd': 3}}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=NamedTuple(c=2, d=3))

    # try converting an OrderedDict
    from collections import OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    # try converting a dictionary with a list
   