

# Generated at 2022-06-25 17:21:02.669776
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test of to_namedtuple
    """
    test_dict = {
        'a': 'apple',
        'b': 'banana',
        'c': 'cat',
        'd': 'dog',
        'e': 'exterminate!',
    }
    test_list = [
        ['a', 'apple'],
        ['e', 'exterminate!'],
        ['b', 'banana'],
        ['c', 'cat'],
        ['d', 'dog'],
    ]
    test_ordered_dict = OrderedDict(
        [
            ('b', 'banana'),
            ('a', 'apple'),
            ('c', 'cat'),
            ('d', 'dog'),
            ('e', 'exterminate!'),
        ]
    )
    test_namespace

# Generated at 2022-06-25 17:21:13.367308
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Initialize test variables
    tuple_0 = (1, 2, 3)
    tuple_1 = (1, 'a', 3.0)
    dict_0 = {'a': 1.1, 'b': 2, 'c': 3.0}
    dict_1 = OrderedDict([('a', 1), ('b', 2), ('c', 3.0)])
    dict_2 = {'a': [1.1, 2, 3.0], 'b': dict_1, 'c': dict_0}
    dict_3 = {'a': [1.1, 2, 3.0], 'b': dict_2, 'c': dict_0}
    dict_4 = {'a': [1.1, 2, 3.0], 'b': dict_3, 'c': dict_0}
    dict_

# Generated at 2022-06-25 17:21:19.960388
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = dict(a=1, b=2)
    exp_0 = 'NamedTuple(a=1, b=2)'
    act_0 = repr(to_namedtuple(dic_0))
    assert exp_0 == act_0
    dic_1 = dict(__a=1, _b=2, c=3)
    exp_1 = 'NamedTuple(c=3)'
    act_1 = repr(to_namedtuple(dic_1))
    assert exp_1 == act_1
    dic_2 = dict(a=1, b=2, c=3)
    exp_2 = 'NamedTuple(a=1, b=2, c=3)'
    act_2 = repr(to_namedtuple(dic_2))
   

# Generated at 2022-06-25 17:21:30.685513
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dic_0)
    assert var_0.a == 1
    assert var_0.b == 2

    list_0 = [1, 2, 3, 4, 5]
    var_1 = to_namedtuple(list_0)
    assert var_1[0] == 1
    assert var_1[1] == 2
    assert var_1[2] == 3
    assert var_1[3] == 4
    assert var_1[4] == 5

    tuple_0 = (1, 2, 3, 4, 5)
    var_2 = to_namedtuple(tuple_0)
    assert var_2[0] == 1
    assert var_2[1] == 2


# Generated at 2022-06-25 17:21:37.241241
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert isinstance(obj, NamedTuple)


if __name__ == '__main__':
    test_case_0()
    test_to_namedtuple()

# Generated at 2022-06-25 17:21:45.103796
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import Dict, List, Tuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.objects import dict_compare, deep_compare
    from flutils.typesutils import flatten_dict

    # Test for empty OrderedDict
    expected = OrderedDict()
    observed = to_namedtuple(OrderedDict())
    assert dict_compare(expected, observed) is True, \
        'OrderedDict != OrderedDict'

    # Test for empty dict
    expected = OrderedDict()
    observed = to_namedtuple({})
    assert dict_compare(expected, observed) is True, \
        'dict != OrderedDict'

    # Test for empty list
    expected = []
    observed = to

# Generated at 2022-06-25 17:21:56.658134
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = ()
    var_0 = to_namedtuple(tuple_0)
    tuple_1 = (1, 2, 3)
    var_1 = to_namedtuple(tuple_1)
    tuple_2 = (1, 2, 3, [4, 5, 6], 7, 8, 9)
    var_2 = to_namedtuple(tuple_2)
    dict_0 = {}
    var_3 = to_namedtuple(dict_0)
    dict_1 = {'a': 1, 'b': 2}
    var_4 = to_namedtuple(dict_1)
    dict_2 = {'a': 1, 'b': 2, 'c': (3, 4, 5)}
    var_5 = to_namedtuple(dict_2)
    dict_

# Generated at 2022-06-25 17:22:10.776919
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Simple test of function to_namedtuple"""
    assert to_namedtuple(None) == None
    assert to_namedtuple([]) == ()
    assert to_namedtuple(([], [])) == (NamedTuple(), NamedTuple())
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': {'c': 3}}) == NamedTuple(a=1, b=NamedTuple(c=3))

# Generated at 2022-06-25 17:22:25.013735
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest


# Generated at 2022-06-25 17:22:36.433244
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Setup
    test_dict = {'a': 10, 'b': 20}
    test_list = [{'a': 10, 'b': 20}, {'a': 1000, 'b': 2000}]
    test_list_1 = [{'a': 10, 'b': 20}, {'a': 1000, 'b': 2000}]
    test_list_2 = [{'a': 10, 'b': 20}, {'a': 1000, 'b': 2000}]
    test_list_3 = [{'a': 10, 'b': 20}, {'a': 1000, 'b': 2000}]
    test_list_4 = [{'a': 10, 'b': 20}, {'a': 1000, 'b': 2000}]

# Generated at 2022-06-25 17:22:51.770601
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Make sure the docstring examples work
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    val = to_namedtuple(dic)
    assert val.a == 1
    assert val.b == 2
    assert isinstance(val, namedtuple)
    assert val.__doc__ is not None
    assert len(val.__doc__.splitlines()) == 1
    assert val.a.__doc__ is None
    assert val.b.__doc__ is None
    list_0 = [
        {
            'c': 3,
            'd': 4,
        },
        {
            'e': 5,
            'f': 6,
        },
    ]
    val = to_namedtuple(list_0)
   

# Generated at 2022-06-25 17:22:53.055269
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:23:02.369169
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for function to_namedtuple
    print("Unit test for function to_namedtuple")

    # Test for cases "Tuple" and "EmptyTuple"
    tuple_0 = ()
    var_0 = to_namedtuple(tuple_0)
    tuple_1 = ()
    var_1 = type(var_0) == tuple_1

    # Test for cases "List" and "EmptyList"
    list_0 = []
    var_0 = to_namedtuple(list_0)
    list_1 = []
    var_1 = type(var_0) == list_1

    # Test for cases "dict" and "Mapping"
    dict_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dict_0)
    dict_1

# Generated at 2022-06-25 17:23:04.410098
# Unit test for function to_namedtuple
def test_to_namedtuple():
    input_0 = ()
    output_0 = to_namedtuple(input_0)
    expected_0 = ()
    assert output_0 == expected_0



# Generated at 2022-06-25 17:23:13.276492
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from asrt import assert_true
    # test None
    var_0 = to_namedtuple(None)
    assert_true(var_0 is None)
    # test integers
    var_0 = to_namedtuple(2)
    assert_true(var_0 is 2)
    var_0 = to_namedtuple(1)
    assert_true(var_0 is 1)
    # test floats
    var_0 = to_namedtuple(2.0)
    assert_true(var_0 is 2.0)
    var_0 = to_namedtuple(1.2)
    assert_true(var_0 is 1.2)
    # test string
    var_0 = to_namedtuple('test')

# Generated at 2022-06-25 17:23:27.274724
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = (1, 2, 3, 4, 5)
    var_0 = to_namedtuple(tuple_0)
    assert list(var_0) == [1, 2, 3, 4, 5]
    tuple_0 = (1, 2, 3, 4, 5, )
    var_1 = to_namedtuple(tuple_0)
    assert list(var_1) == [1, 2, 3, 4, 5]
    tuple_0 = (1, 2, 3, 4, 5,)
    var_2 = to_namedtuple(tuple_0)
    assert list(var_2) == [1, 2, 3, 4, 5]
    tuple_0 = (1, 2, 3, 4, 5)
    var_3 = to_namedtuple(tuple_0)

# Generated at 2022-06-25 17:23:41.392960
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.collectionsutils import get_keys

    data = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': {
            'x': 1,
            'y': 2,
            'z': 3,
        }
    }

    nt_0 = to_namedtuple(data)
    assert isinstance(nt_0, NamedTuple)
    assert get_keys(nt_0) == ['a', 'b', 'c', 'd', 'e']

    od_0 = OrderedDict()
    od_0['a'] = 1
    od_0['b'] = 2
    od_0['c'] = 3
    od_0['d'] = 4
    od_0

# Generated at 2022-06-25 17:23:54.095226
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = ()
    var_0 = to_namedtuple(tuple_0)
    assert var_0 == NamedTuple()

    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert var_0 == []

    dict_0 = {}
    var_0 = to_namedtuple(dict_0)
    assert var_0 == NamedTuple()

    dict_1 = {
        '_a': 0,
        'b': 1,
        'c': 2,
        'd': 3
    }
    var_0 = to_namedtuple(dict_1)
    assert var_0 == NamedTuple(b=1, c=2, d=3)



# Generated at 2022-06-25 17:24:00.693663
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = (1, 2, 3)
    tuple_1 = (1, 2, 3)
    assert tuple_0 == tuple_1


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:24:11.690353
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:24:28.517599
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection LongLine
    """Tests the function to_namedtuple.

    Reads in a tuple and returns a namedtuple. If a dictionary or a list is
    read in then it still returns a tuple. This function is also called upon
    every elements in the list or tuple, so everything is converted if
    possible.

    Args:
        None.

    Returns:
        None.

    Raises:
        None.
    """

    # Arrays of tuples,
    # each tuple with a key, the expected input, and the return value.
    # noinspection LongLine

# Generated at 2022-06-25 17:24:41.219082
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()

    # test 0 - tuple
    var = to_namedtuple((1, 2, 3))
    assert type(var) is tuple
    assert var == (1, 2, 3)

    # test 1 - tuple
    var = to_namedtuple((1, 2, {'a': 10, 'b': 20}))
    assert type(var) is tuple
    assert var == (1, 2, NamedTuple(a=10, b=20))

    # test 2 - list
    var = to_namedtuple([1, 2, {'a': 10, 'b': 20}])
    assert type(var) is list

# Generated at 2022-06-25 17:24:43.285942
# Unit test for function to_namedtuple
def test_to_namedtuple():
    for i in range(1):
        test_case_0()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:24:57.754108
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from __main__ import to_namedtuple

    tuple_0 = ()
    var_0 = to_namedtuple(tuple_0)

    assert var_0 == Namespace()

    tuple_0 = (1, 2)
    var_0 = to_namedtuple(tuple_0)

    assert var_0 == (1, 2)

    tuple_0 = ('__main__', 'sys')
    var_0 = to_namedtuple(tuple_0)

    assert var_0 == ('__main__', 'sys')

    tuple_0 = ['__main__', 'sys']
    var_0 = to_namedtuple(tuple_0)

    assert var_0 == ['__main__', 'sys']

    tuple_0 = (123, ['__main__', 'sys'], 'abc')


# Generated at 2022-06-25 17:25:08.248662
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from types import (
        SimpleNamespace,
    )
    from typing import (
        Any,
        List,
        NamedTuple,
        Tuple,
        Type,
        Union,
    )

    make_tuple = namedtuple('TestTuple', ['a', 'b', 'c'])

    ordered_dict_0: OrderedDict = OrderedDict()
    ordered_dict_0['a'] = 1
    ordered_dict_0['b'] = 2

    ordered_dict_1: OrderedDict = OrderedDict()
    ordered_dict_1['a'] = 'a'
    ordered_dict_1['b'] = 'b'

    ordered_dict_2: OrderedDict = Ord

# Generated at 2022-06-25 17:25:21.077195
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {
        'a': 1,
        'b': 2,
    }
    odic_0 = OrderedDict(
        a=1,
        b=2,
    )
    tuple_0 = (
        {
            'a': 1,
            'b': 2,
        },
    )
    list_0 = [
        {
            'a': 1,
            'b': 2,
        },
    ]
    namespace_0 = SimpleNamespace(
        a=1,
        b=2,
    )
    namedtuple_0 = cast(NamedTuple, to_namedtuple(dic_0))
    namedtuple_1 = cast(NamedTuple, to_namedtuple(odic_0))

# Generated at 2022-06-25 17:25:31.989321
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection SpellCheckingInspection
    d = {
        '_a': 'a_val',
        'B': 'b_val',
        'c': 'c_val',
        'd': 'd_val',
    }
    tn = to_namedtuple(d)
    assert len(tn) == 2
    assert tn.B == 'b_val'
    assert tn.c == 'c_val'


# Generated at 2022-06-25 17:25:41.496933
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    tuple_0 = (1, 2, 3)
    list_0 = [1, 2, 3]
    str_0 = 'abc'
    dic_1 = {'a': 1, 'b': {'c': 3, 'd': 4, (1, 2): 5, 'e': [1, 2, 3]}}
    list_1 = [1, 2, {'a': 1, 'b': 2}, 4]
    list_2 = ['a', 'b']
    list_3 = [1, 2, 'a', 'b']
    ns = SimpleNamespace(a=1, b=2)
    od = OrderedDict()
    od['a'] = 1
    od['b'] = 2

# Generated at 2022-06-25 17:25:52.559839
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({}) == NamedTuple(())  # type: ignore[arg-type]
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(b=2, a=1)
    dic: Dict[str, Any] = {}
    dic['a'] = 1
    dic['b'] = 2
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = OrderedDict()

# Generated at 2022-06-25 17:25:59.671787
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Tests to make sure that the to_namedtuple function can be called without any errors being thrown
    tuple_0 = ()
    var_0 = to_namedtuple(tuple_0)
    func_0 = lambda val: var_0
    if callable(func_0):
        func_0(var_0)
    tuple_1 = [{}]
    var_1 = to_namedtuple(tuple_1)
    func_1 = lambda val: var_1
    if callable(func_1):
        func_1(var_1)
    tuple_2 = {}
    var_2 = to_namedtuple(tuple_2)
    func_2 = lambda val: var_2
    if callable(func_2):
        func_2(var_2)

# Generated at 2022-06-25 17:26:17.005777
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Case: Tuple
    tuple_0 = (1, {'a': 1, 'b': 2}, 'a')
    var_0 = to_namedtuple(tuple_0)
    assert isinstance(var_0, tuple)
    assert isinstance(var_0[1], NamedTuple)
    assert var_0[1] == to_namedtuple({'a': 1, 'b': 2})


# Generated at 2022-06-25 17:26:27.478106
# Unit test for function to_namedtuple
def test_to_namedtuple():
    expected = 0
    actual = to_namedtuple(0)
    assert actual == expected


# Generated at 2022-06-25 17:26:36.613871
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test with a list
    tuple_0 = (1, 2, [3, 4, 5, (6, 7), {'a': 8, 'b': 0.5}, 9])
    tuple_1 = (1, 2, [3, 4, 5, (6, 7), {'a': 8, 'b': 0.5, 'c': (1, 2, 3)}, 9])
    list_0 = [1, 2, [3, 4, 5, (6, 7), {'a': 8, 'b': 0.5}, 9]]
    list_1 = [1, 2, [3, 4, 5, (6, 7), {'a': 8, 'b': 0.5, 'c': (1, 2, 3)}, 9]]

    # Make a generic namedtuple
    NamedTuple_0 = namedt

# Generated at 2022-06-25 17:26:47.502876
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import choice
    from string import ascii_lowercase

    def _gen_id(l: int) -> str:
        return ''.join(choice(ascii_lowercase) for _ in range(l))

    def _gen_lst() -> List[Any]:
        from random import randrange
        out = []
        for _ in range(randrange(10)):
            out.append(_gen_id(randrange(4, 10)))
            out.append(randrange(10))
        return out

    def _gen_dic() -> Dict[str, Any]:
        from random import randrange
        out = {}
        for _ in range(randrange(3, 10)):
            out[_gen_id(randrange(4, 10))] = randrange(10)
        return out


# Generated at 2022-06-25 17:26:53.879634
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple ."""
    tuple_0 = ()
    var_0 = to_namedtuple(tuple_0)
    assert var_0 == ()

    tuple_1 = (1, 2)
    var_1 = to_namedtuple(tuple_1)
    assert var_1 == (1, 2)

    tuple_2 = ('a', 'b')
    var_2 = to_namedtuple(tuple_2)
    assert var_2 == ('a', 'b')

    tuple_3 = ('a', 'b', 1, 2)
    var_3 = to_namedtuple(tuple_3)
    assert var_3 == ('a', 'b', 1, 2)

    tuple_4 = ('a', 'b', (1, 2))
    var_4 = to_

# Generated at 2022-06-25 17:27:04.195137
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Tests that an OrderedDict is converted to a NamedTuple.
    dic = OrderedDict([('a', 1), ('b', 2)])
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    val = to_namedtuple(dic)
    assert isinstance(val, NamedTuple)
    assert val == expected
    # Tests that a dictionary is converted to a NamedTuple.
    dic = {'a': 1, 'b': 2}
    val = to_namedtuple(dic)
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert isinstance(val, NamedTuple)
    assert val == expected
    # Tests that an OrderedDict that has items that cannot be

# Generated at 2022-06-25 17:27:15.674243
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test to_namedtuple with empty tuple
    tuple_0 = ()
    var_0 = to_namedtuple(tuple_0)
    assert var_0 == ()

    # Test to_namedtuple with empty list
    list_0 = []
    var_1 = to_namedtuple(list_0)
    assert var_1 == []

    # Test to_namedtuple with simple dictionary
    dict_0 = {'a': 1, 'b': 2}
    var_2 = to_namedtuple(dict_0)
    assert var_2 == (1, 2)

    # Test to_namedtuple with complex dictionary
    dict_1 = {}
    dict_1['a'] = 1
    dict_1['b'] = {}
    dict_1['b']['ba'] = 2
    dict

# Generated at 2022-06-25 17:27:25.409803
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Case 0.0
    tuple_0 = tuple()
    var_0 = to_namedtuple(tuple_0)
    assert isinstance(var_0, NamedTuple)
    assert var_0.__class__.__name__ == 'NamedTuple'
    assert not var_0._fields

    # Case 0.1
    tuple_0 = tuple()
    var_0 = to_namedtuple(tuple_0)
    assert isinstance(var_0, NamedTuple)
    assert var_0.__class__.__name__ == 'NamedTuple'
    assert not var_0._fields

    # Case 0.2
    tuple_0 = (1, 2)
    var_0 = to_namedtuple(tuple_0)

# Generated at 2022-06-25 17:27:36.085177
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test namedtuple creation."""
    dic = {'a': 1, 'b': 2, 'c': {'d': 3}}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c.d == 3
    dic = [{'a': 1, 'b': 2, 'c': {'d': 3}}]
    nt = to_namedtuple(dic)
    assert nt[0].a == 1
    assert nt[0].b == 2
    assert nt[0].c.d == 3
    dic = {'a': 1, 'b': 2, 'c': [{'d': 3}, {'d': 4}]}

# Generated at 2022-06-25 17:27:45.963420
# Unit test for function to_namedtuple
def test_to_namedtuple():

    tuple_0 = (1, 2, 3, 4, 5)
    var_0 = to_namedtuple(tuple_0)
    assert isinstance(var_0, tuple)
    assert var_0.__doc__ is not None

    list_0 = ['a', 'b', 'c', 'd', 'e']
    var_1 = to_namedtuple(list_0)
    assert isinstance(var_1, list)
    assert var_1.__doc__ is not None

    dict_0 = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    var_2 = to_namedtuple(dict_0)
    assert isinstance(var_2, NamedTuple)
    assert var_2.__doc__ is not None

    tuple_

# Generated at 2022-06-25 17:28:07.373490
# Unit test for function to_namedtuple
def test_to_namedtuple():
    result = to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4})
    assert isinstance(result, NamedTuple)
    assert result.a == 1
    assert result.b == 2
    assert result.c == 3
    assert result.d == 4

    tup = (1, (2, (3, (4, ))), )
    result = to_namedtuple(tup)
    assert isinstance(result, tuple)
    assert isinstance(result[1], tuple)
    assert isinstance(result[1][1], tuple)
    assert isinstance(result[1][1][1], tuple)
    assert result[1][0] == 2
    assert result[1][1][0] == 3

# Generated at 2022-06-25 17:28:14.617591
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(()) == ()
    assert to_namedtuple([]) == []
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()

    assert to_namedtuple([{}, {'a': 1}]) == [{}, NamedTuple(a=1)]
    assert to_namedtuple(()) == ()
    assert to_namedtuple({"a": 1, "b": 2, "c": 3}) == \
           NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({"a": 1, "b": [], "c": 3}) == \
           NamedTuple(a=1, b=[], c=3)
    assert to_namedtuple({"a": 1, "b": 1, "c": 3})

# Generated at 2022-06-25 17:28:26.130353
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict, namedtuple
    from types import SimpleNamespace

    # If the given type is of `list` or `tuple`, each item will be
    # recursively converted to a `NamedTuple <collections.namedtuple>`
    # provided the items can be converted. Items that cannot be converted
    # will still exist in the returned `obj`.
    #
    # If the given type is of `list` the return value will be a new `list`.
    # This means the items are not changed in the given `obj`.
    test_list = [1, 2, 3]
    test_tuple = (1, 2, 3,)
    test_out_list = to_namedtuple(test_list)
    test_out_tuple = to_namedtuple(test_tuple)
   

# Generated at 2022-06-25 17:28:35.724689
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for None input
    # No exception should be raised
    assert to_namedtuple(None) is None

    # Test for empty dict input
    test_dict = {}
    result = to_namedtuple(test_dict)
    assert not result._fields

    # Test for empty OrderedDict input
    test_dict = OrderedDict()
    result = to_namedtuple(test_dict)
    assert not result._fields

    # Test for empty list input
    test_list = []
    result = to_namedtuple(test_list)
    assert not len(result)

    # Test for empty tuple input
    test_tuple = ()
    result = to_namedtuple(test_tuple)
    assert not result._fields

    # Test for int input
    test_int = 5

# Generated at 2022-06-25 17:28:46.795458
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for function to_namedtuple."""
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from operator import attrgetter
    classtuple_0 = namedtuple('namedtuple_0', 'field_0, field_1')
    nametuple_0 = classtuple_0('1', '2')
    tuple_0 = ('a', 1)
    tuple_1 = ('a', 1, ('b', 2))
    tuple_2 = ('a', 1, ('b', 2, ('c', 3)))
    tuple_3 = ('a', 1, ('b', 2, ('c', 3, ('d', 4))))

# Generated at 2022-06-25 17:28:52.476489
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(
        name='test_to_namedtuple',
        optionflags=doctest.ELLIPSIS
    )


if __name__ == '__main__':
    print('Running doctests.')
    test_case_0()
    test_to_namedtuple()
    print('Done.')

# Generated at 2022-06-25 17:28:57.624769
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # TODO: Update test_to_namedtuple
    import unittest
    import doctest
    suite = unittest.TestSuite()
    suite.addTest(doctest.DocTestSuite(setUp=test_case_0))
    return suite


# Make sure tests are not run on import
if __name__ == '__main__':
    import unittest
    unittest.TextTestRunner().run(test_to_namedtuple())

# Generated at 2022-06-25 17:29:08.369693
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0 = {"a": 1, "b": 2}
    str_0 = to_namedtuple(dict_0)
    assert str_0 == NamedTuple(a=1, b=2)
    dict_1 = dict(a=1, b=2)
    str_1 = to_namedtuple(dict_1)
    assert str_1 == NamedTuple(a=1, b=2)
    dict_2 = dict({("a", 1), ("b", 2)})
    str_2 = to_namedtuple(dict_2)
    assert str_2 == NamedTuple(a=1, b=2)
    dict_3 = {"a": 1, "b": 2}
    dict_3.setdefault("A", 3)

# Generated at 2022-06-25 17:29:15.968151
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import OrderedDict
    from collections.abc import Mapping
    from collections import namedtuple as _namedtuple
    from types import SimpleNamespace
    from typing import List, Tuple, Union

    _AllowedTypes = Union[List, Mapping, _namedtuple, SimpleNamespace, Tuple]

    OrderedDict_Mapping = OrderedDict  # type: ignore
    SimpleNamespace_Mapping = SimpleNamespace  # type: ignore

    assert issubclass(OrderedDict, OrderedDict_Mapping)
    assert issubclass(SimpleNamespace, SimpleNamespace_Mapping)

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1

# Generated at 2022-06-25 17:29:26.740415
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test this will return a dict
    dict_0 = {
        'a': 1,
        'b': 2,
    }
    var_0 = to_namedtuple(dict_0)
    assert isinstance(var_0, NamedTuple)
    assert var_0 == NamedTuple(a=1, b=2)

    # Test this will return a list
    list_0 = [
        {
            'a': 1,
            'b': 2,
        },
        {
            'a': 3,
            'b': 4,
        },
    ]
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0, list)

# Generated at 2022-06-25 17:29:55.189526
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from typing import (
        NamedTuple,
        Tuple,
    )

    ExampleTuple = NamedTuple(
        'ExampleTuple',
        (
            ('first', int),
            ('second', str),
            ('third', list),
        )
    )

    dic = {
        'first': 1,
        'second': 'second',
        'third': [1, 2, 3, 4],
    }

    expect: Union[ExampleTuple, Tuple] = ExampleTuple(
        1,
        'second',
        [
            ExampleTuple(1, 'second', [1, 2, 3, 4],),
        ]
    )

    assert to_namedtuple(dic) == expect


# Generated at 2022-06-25 17:30:04.151025
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = (1, 2, 3)
    assert isinstance(to_namedtuple(tuple_0), tuple)
    assert tuple_0 == to_namedtuple(tuple_0)
    list_0 = [1, 2, 3]
    assert isinstance(to_namedtuple(list_0), list)
    assert list_0 == to_namedtuple(list_0)
    dic_0 = {'a': 1, 'b': 2, 'c': 3}
    assert isinstance(to_namedtuple(dic_0), namedtuple)
    assert dic_0['a'] == to_namedtuple(dic_0).a
    assert dic_0['b'] == to_namedtuple(dic_0).b
    assert dic_0['c'] == to

# Generated at 2022-06-25 17:30:14.790651
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    from .test_data_namedtupleutils import (
        TEST_DATA_NAMEDTUPLE,
        TEST_DATA_NAMEDTUPLE_JSON,
        TEST_DATA_NAMEDTUPLE_JSON_DUMP_SORT_KEYS,
    )
    from flutils.jsonutils import jsonify
    import json
    import pprint

    nametuple_tk = to_namedtuple(TEST_DATA_NAMEDTUPLE)
    jsonified = jsonify(nametuple_tk)

    print(
        json.dumps(
            jsonified,
            indent=4,
            sort_keys=TEST_DATA_NAMEDTUPLE_JSON_DUMP_SORT_KEYS
        )
    )
    print()

   

# Generated at 2022-06-25 17:30:25.136928
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    # _ == bool
    tuple_0 = (0, 2, 1, 1, -1, 1, 1, 1, 1, 0, 0, 1, 1, 1)
    var_0 = to_namedtuple(tuple_0)
    assert isinstance(var_0, tuple)
    assert var_0 == tuple_0

    tuple_0 = (0, 2, 1, 1, -1, 1, 1, 1, 1, 0, 0, 1, 1, 1)
    var_0 = to_namedtuple((tuple_0,))
    assert isinstance(var_0, tuple)
    assert var_0 == tuple_0


# Generated at 2022-06-25 17:30:33.337674
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_0 = (1, 2, 3)
    tuple_1 = to_namedtuple(tuple_0)
    assert isinstance(tuple_1, NamedTuple)
    assert tuple_1._fields == ('_0', '_1', '_2')

    list_0 = [1, 2, 3, 4, 5]
    list_1 = to_namedtuple(list_0)
    assert isinstance(list_1, list)
    assert type(list_1[0]) is int

    dict_0 = {'a': 1}
    dict_1 = to_namedtuple(dict_0)
    assert isinstance(dict_1, NamedTuple)
    assert dict_1._fields == ('a',)

    dict_0 = {1: 'a'}
    dict_1 = to_

# Generated at 2022-06-25 17:30:44.190397
# Unit test for function to_namedtuple
def test_to_namedtuple():
    t = [{'a': 1, 'b': 2}]
    var = to_namedtuple(t)
    assert len(var) == 1
    assert var[0].a == 1
    assert var[0].b == 2

    t = {'a': 1, 'b': 2}
    var = to_namedtuple(t)
    assert var.a == 1
    assert var.b == 2

    t = (1, 2, 3, 4)
    var = to_namedtuple(t)
    assert isinstance(var, tuple)

    t = ['a', 'b', 'c', 'd']
    var = to_namedtuple(t)
    assert isinstance(var, list)

    t = OrderedDict([('a', 1), ('b', 2)])
    var = to_