

# Generated at 2022-06-25 17:21:02.599837
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import types
    import collections
    import collections.abc
    import typing

    simple_namespace_0 = types.SimpleNamespace()
    assert to_namedtuple(simple_namespace_0) == collections.namedtuple('NamedTuple', '()')(

    )

    dict_0 = {}
    assert to_namedtuple(dict_0) == collections.namedtuple('NamedTuple', '()')(

    )

    ordered_dict_0 = collections.OrderedDict()
    assert to_namedtuple(ordered_dict_0) == collections.namedtuple('NamedTuple', '()')(

    )

    list_0 = []
    assert to_namedtuple(list_0) == []

    tuple_0 = ()

# Generated at 2022-06-25 17:21:10.522334
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.a = 1
    simple_namespace_0.b = [2, 3]
    simple_namespace_0.c = {'d': 4, 'e': 5}
    simple_namespace_0.f = (6, 7)
    var_0 = to_namedtuple(simple_namespace_0)
    print(var_0.a, var_0.b, var_0.c, var_0.f)


# Generated at 2022-06-25 17:21:16.066240
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True == True

# noinspection PyShadowingBuiltins
if __name__ == '__main__':
    test_to_namedtuple()
    test_case_0()

# Generated at 2022-06-25 17:21:28.299071
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections.abc import Mapping
    from collections import OrderedDict
    from types import SimpleNamespace
    for obj in (
            (),
            [],
            {},
            {'a': 1, 'b': 2},
            OrderedDict([('a', 1), ('b', 2)]),
            SimpleNamespace(b=2, a=1),
            SimpleNamespace(a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8, i=9, j=10)
    ):
        print(to_namedtuple(obj))

# cProfile.run('test_to_namedtuple()')
'Pass'

# Generated at 2022-06-25 17:21:37.744522
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(None) is None
    assert to_namedtuple([]) == ()
    assert to_namedtuple(()) == ()
    assert to_namedtuple({}) == ()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple([1]) == (1,)
    assert to_namedtuple((1,)) == (1,)
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple({'a': {'b': {'c': 0}}}) == NamedTuple(a=NamedTuple(b=NamedTuple(c=0)))

# Generated at 2022-06-25 17:21:40.994806
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test for to_namedtuple
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)



if __name__ == '__main__':
    test_case_0()
    test_to_namedtuple()

# Generated at 2022-06-25 17:21:41.751080
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()

# Generated at 2022-06-25 17:21:44.993643
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_0 = to_namedtuple({
        'a': 1,
        'b': 2,
    })
    assert isinstance(var_0, tuple)
    assert var_0 == (1, 2)
    assert len(var_0) == 2
    assert var_0.a == 1
    assert var_0.b == 2
    test_case_0()


# Generated at 2022-06-25 17:21:59.882748
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.attr_0 = 0
    simple_namespace_0.attr_1 = None
    simple_namespace_0.attr_2 = 'str'
    simple_namespace_0.attr_3 = 'str'
    simple_namespace_0.attr_4 = 'str'
    simple_namespace_0.attr_5 = 'str'
    simple_namespace_0.attr_6 = 'str'
    tuple_0 = to_namedtuple(simple_namespace_0)
    assert(getattr(tuple_0, 'attr_0') == 0)
    assert(getattr(tuple_0, 'attr_1') is None)

# Generated at 2022-06-25 17:22:05.371923
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_1 = to_namedtuple(simple_namespace_0)
    var_2 = to_namedtuple(simple_namespace_0)
    var_3 = to_namedtuple(simple_namespace_0)
    var_4 = to_namedtuple(simple_namespace_0)
    var_5 = to_namedtuple(simple_namespace_0)
    var_6 = to_namedtuple(simple_namespace_0)
    var_7 = to_namedtuple(simple_namespace_0)
    var_8 = to_namedtuple(simple_namespace_0)
    var_9 = to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:22:10.278364
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert callable(to_namedtuple)

# noinspection PyUnreachableCode,PyCompatibility

# Generated at 2022-06-25 17:22:25.008142
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0: Mapping[str, Any] = {
        'a': 1,
        'b': 2,
    }
    named_tuple_0 = to_namedtuple(dic_0)
    assert isinstance(named_tuple_0, NamedTuple)
    assert named_tuple_0.a == 1
    assert named_tuple_0.b == 2

    dic_1: Mapping[str, Any] = {
        'a': 1,
        'b': 2,
    }
    od: OrderedDict = OrderedDict(dic_1)
    named_tuple_1 = to_namedtuple(od)
    assert isinstance(named_tuple_1, NamedTuple)
    assert named_tuple_1.a == 1
    assert named_

# Generated at 2022-06-25 17:22:25.968563
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert callable(to_namedtuple)

# Generated at 2022-06-25 17:22:39.329643
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import pytest
    from _pytest.doctest import DoctestItem

    # --------------------------------------------------
    # Defaults

    # --------------------------------------------------
    # Non-trivial use cases

    # --------------------------------------------------
    # Assertions
    assert True, 'Unit test completed.'


if __name__ == "__main__":
    test_case_0()

    print(
        'Testing completed on {date}.'.format(date=str(datetime.datetime.now()))
    )
    print(
        'Testing completed on {date}.'.format(date=str(datetime.datetime.now()))
    )
    print(
        'Testing completed on {date}.'.format(date=str(datetime.datetime.now()))
    )

# Generated at 2022-06-25 17:22:51.257898
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # SimpleNamespace
    tail = to_namedtuple({
        'foo': 1,
        'bar': 2,
    })
    assert tail == NamedTuple(bar=2, foo=1)
    head = to_namedtuple({
        'foo': 1,
        'bar': 2,
    })
    assert head == tail

    # list
    tail = to_namedtuple([
        {'foo': 1, 'bar': 2},
        {'foo': 3, 'bar': 4},
    ])
    assert head == tail
    head = tail

    # tuple
    tail = to_namedtuple((
        {'foo': 1, 'bar': 2},
        {'foo': 3, 'bar': 4},
    ))
    assert head == tail
    head = tail

    # tuple (contains a list

# Generated at 2022-06-25 17:23:01.601422
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert (to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2}
    assert (to_namedtuple(dic) == NamedTuple(a=1, b=2))

    assert (to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)])

    assert (
        to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
        == NamedTuple(a=1, b=2)
    )


# Generated at 2022-06-25 17:23:07.650263
# Unit test for function to_namedtuple
def test_to_namedtuple():
    ###########################################################################
    # Test 1: Given a mapping, return the keys as NamedTuple attributes.
    ###########################################################################
    dic_0 = {}
    namedtuple_0 = to_namedtuple(dic_0)
    assert namedtuple_0.__class__.__name__ == 'NamedTuple'

    dic_0 = {'a': 1}
    namedtuple_0 = to_namedtuple(dic_0)
    assert namedtuple_0.__class__.__name__ == 'NamedTuple'
    assert namedtuple_0.a == 1

    dic_0 = {'a': 1, 'b': 2}
    namedtuple_0 = to_namedtuple(dic_0)

# Generated at 2022-06-25 17:23:21.013894
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # test for name
    assert to_namedtuple({'name':'John'}) == (NamedTuple(name='John',),)
    # test for invalid type
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.name = 'John'
    with pytest.raises(TypeError):
        to_namedtuple(simple_namespace_0)
    # test for nested namespace
    assert to_namedtuple({'name':{'first':'John','last':'Smith'}}) == (NamedTuple(name=(NamedTuple(first='John',last='Smith',),),),)
    # test for ordered dict
    ordered_dict_0 = collections.OrderedDict()
    ordered_dict_0['name'] = 'John'
    ordered_dict

# Generated at 2022-06-25 17:23:29.730273
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == namedtuple('NamedTuple', ('a', 'b', 'c'))(1, 2, 3)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) == namedtuple('NamedTuple', ('a', 'b', 'c'))(1, 2, 3)
    assert to_namedtuple(dict(a=1, b=2, c=3)) == namedtuple('NamedTuple', ('a', 'b', 'c'))(1, 2, 3)


# Generated at 2022-06-25 17:23:38.811240
# Unit test for function to_namedtuple
def test_to_namedtuple():
    param_0 = NamedTuple('NamedTuple_0', [])
    param_1 = to_namedtuple(param_0)
    param_2 = [NamedTuple('NamedTuple_1', [])]
    param_3 = to_namedtuple(param_2)
    param_4 = {'a': 1}
    param_5 = to_namedtuple(param_4)
    param_6 = [{'a': 1}, {'b': 2}]
    param_7 = to_namedtuple(param_6)
    param_8 = [{'a': 1}, {'b': [{'c': 3}]}]
    param_9 = to_namedtuple(param_8)



# Generated at 2022-06-25 17:23:54.762483
# Unit test for function to_namedtuple
def test_to_namedtuple():
    it = {'a':1, 'b':2}
    rv = to_namedtuple(it)
    assert str(rv) == "NamedTuple(a=1, b=2)"
    assert rv.a == 1
    assert rv.b == 2

    it = {'a':1, 'b':2}
    it = OrderedDict(sorted(it.items()))
    rv = to_namedtuple(it)
    assert str(rv) == "NamedTuple(a=1, b=2)"
    assert rv.a == 1
    assert rv.b == 2

    it = OrderedDict([('a', 1), ('b', 2)])
    rv = to_namedtuple(it)

# Generated at 2022-06-25 17:24:03.846593
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple

    def test_get_set(obj):
        for key, val in obj.__dict__.items():
            if key in {'_asdict', '_fields'}:
                continue
            newval = getattr(obj, key)
            setattr(obj, key, newval)

    def check_to_namedtuple(obj):
        ntobj = to_namedtuple(obj)
        assert isinstance(obj, namedtuple)
        assert isinstance(ntobj, namedtuple)
        assert obj != ntobj, 'make new object'
        test_get_set(ntobj)

    check_to_namedtuple(namedtuple('test', 'a b')(1, 2))
    check_to

# Generated at 2022-06-25 17:24:05.704873
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()
    assert True

# Generated at 2022-06-25 17:24:12.357563
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    assert type(to_namedtuple(simple_namespace_0)) == _to_namedtuple.registry.__getitem__(module_0.SimpleNamespace)()
    assert type(to_namedtuple(simple_namespace_0)) == _to_namedtuple.registry.__getitem__(module_0.SimpleNamespace)()
    assert type(to_namedtuple(simple_namespace_0)) == _to_namedtuple.registry.__getitem__(module_0.SimpleNamespace)()

# Generated at 2022-06-25 17:24:23.573704
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lst: List[Any] = []
    # lst.append(1)
    lst.append('foo')
    # assert isinstance(to_namedtuple(lst), tuple)
    assert isinstance(to_namedtuple(lst), list)
    assert to_namedtuple(lst) == ['foo']

    dct = dict(foo=1, bar=2)
    assert isinstance(to_namedtuple(dct), NamedTuple)
    out = to_namedtuple(dct)
    assert out.bar == 2
    assert out.foo == 1

    simple_namespace = module_0.SimpleNamespace()
    simple_namespace.foo = 1
    simple_namespace.bar = 2
    assert isinstance(to_namedtuple(simple_namespace), NamedTuple)

# Generated at 2022-06-25 17:24:37.120118
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace = module_0.SimpleNamespace()
    var = to_namedtuple(simple_namespace)
    simple_namespace.foo = {'a': 1, 'b': 2}
    var_1 = to_namedtuple(simple_namespace)
    simple_namespace.bar = [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]
    var_2 = to_namedtuple(simple_namespace)
    assert var == NamedTuple()
    assert var_1 == NamedTuple(foo=NamedTuple(a=1, b=2))

# Generated at 2022-06-25 17:24:42.618961
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_0 = to_namedtuple(
        {
            'a': 1,
            'b': 2,
            'c': [4, 5, 6],
        }
    )
    var_1 = to_namedtuple(
        'Test'
    )

    assert var_0 == NamedTuple(a=1, b=2, c=(4, 5, 6))
    assert var_1 == 'Test'

# Generated at 2022-06-25 17:24:45.344934
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)


if __name__ == '__main__':
    pass

# Generated at 2022-06-25 17:24:58.129994
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple('this') == 'this'
    assert to_namedtuple(123) == 123
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(['this', 'is', 'a', 'list']) == ['this', 'is', 'a', 'list']
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple((1, 2, 3)) != [1, 2, 3]
    assert to_namedtuple(['this', 'is', 'a', 'list']) == ['this', 'is', 'a', 'list']

# Generated at 2022-06-25 17:25:03.585723
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {"a": 1, "b": 2}
    var_0 = to_namedtuple(dic_0)

import collections.abc as module_1


# Generated at 2022-06-25 17:25:15.473324
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:25:21.243216
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils as module_0
    # Test case for function to_namedtuple
    simple_namespace_0 = module_0.test_case_0.simple_namespace_0
    # Test case for function to_namedtuple
    with pytest.raises(TypeError):
        assert module_0.to_namedtuple(simple_namespace_0)


# Generated at 2022-06-25 17:25:37.220342
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.foo = 'bar'
    simple_namespace_0.baz = 'quux'
    var_0 = to_namedtuple(simple_namespace_0)
    assert var_0 == (('baz', 'quux'), ('foo', 'bar'))
    var_0 = to_namedtuple(simple_namespace_0)
    assert var_0 == (('baz', 'quux'), ('foo', 'bar'))
    simple_namespace_0.baz = 'quux'
    simple_namespace_0.foo = 'bar'
    var_0 = to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:25:51.365428
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test multiple types
    simple_namespace_0 = module_0.SimpleNamespace()
    assert to_namedtuple(simple_namespace_0) == NamedTuple()
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple(OrderedDict()) == NamedTuple()
    assert to_namedtuple(OrderedDict([('a', 1)])) == NamedTuple(a=1)
    assert to_namedtuple(['a']) == ['a']
    assert to_namedtuple(('a',)) == ('a',)

# Generated at 2022-06-25 17:26:07.396492
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Type error if the obj does not have keys or attributes
    str_0 = 'string'
    with pytest.raises(TypeError):
        var_0 = to_namedtuple(str_0)

    # SimpleNamespace to NamedTuple
    dict_0 = dict(a=1, b=2)
    simple_namespace_0 = module_0.SimpleNamespace(**dict_0)
    var_0 = to_namedtuple(simple_namespace_0)
    assert var_0.a == 1
    assert var_0.b == 2

    # Mapping to NamedTuple
    dict_0 = dict(a=1, b=2)
    var_0 = to_namedtuple(dict_0)
    assert var_0.a == 1
    assert var_0.b == 2



# Generated at 2022-06-25 17:26:08.724392
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True


# Generated at 2022-06-25 17:26:20.859892
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test with SimpleNamespace
    from types import SimpleNamespace
    s = SimpleNamespace(name='a', value=1)
    # Convert SimpleNamespace to a NamedTuple
    nt = to_namedtuple(s)
    # Verify NamedTuple has the right attributes
    assert hasattr(nt, 'name')
    assert nt.name == 'a'
    assert hasattr(nt, 'value')
    assert nt.value == 1
    # Verify we can't update NamedTuple attributes (immutable)
    # noinspection PyTypeChecker
    with pytest.raises(AttributeError):
        nt.name = 'b'
    # Verify we can't set new attributes (immutable)
    # noinspection PyTypeChecker
    with pytest.raises(AttributeError):
        nt.new

# Generated at 2022-06-25 17:26:23.806910
# Unit test for function to_namedtuple
def test_to_namedtuple():
    arg_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(arg_0)
    assert var_0 == OrderedDict([('a', 1), ('b', 2)])

# Test case for to_namedtuple

# Generated at 2022-06-25 17:26:26.892532
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Unit test for to_namedtuple
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:26:36.190334
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Tests the to_namedtuple function defined in namedtupleutils.py
    import collections as module_0
    import typing as module_1
    import typing as module_2
    # Tests for function to_namedtuple
    # Test for function to_namedtuple where the given type is of list
    # Testing if the return value is a new list
    # This means the items are not changed in the given obj
    # Testing if each item is recursively converted to a NamedTuple
    # provided the items can be converted.  Items that cannot be converted
    # will still exist in the returned object
    var_0 = module_0.OrderedDict()
    var_0["a"] = 1
    var_0["b"] = 2
    var_0["c"] = 3

# Generated at 2022-06-25 17:26:56.624597
# Unit test for function to_namedtuple
def test_to_namedtuple():
    sequence_0 = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    var_0 = to_namedtuple(sequence_0)
    assert var_0 == (NamedTuple(a=1, b=2), NamedTuple(a=3, b=4))

# Generated at 2022-06-25 17:27:05.083373
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from copy import deepcopy
    from flutils.namedtupleutils import _to_namedtuple
    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace
    class TestToNamedtuple(unittest.TestCase):

        def setUp(self):
            self.cust_dict = {'a': 1, 'b': 2}
            self.cust_dict_long = {'a': 1, 'b': 2, 'c': 3}
            self.cust_val = 3
            self.cust_dict_with_val = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-25 17:27:07.331634
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert(1 == 1)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:27:19.042101
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert_equal(to_namedtuple([1, {'a': [3, 4]}]), [1, NamedTuple(a=[3, 4])])
    assert_equal(
        to_namedtuple({'a': 1, 'b': 2}),
        NamedTuple(a=1, b=2)
    )
    assert_equal(
        to_namedtuple({'a': 1, 'b': 2}, use_sort=False),
        NamedTuple(b=2, a=1)
    )
    assert_equal(to_namedtuple({'a': 1, 'b': None}), NamedTuple(a=1, b=None))
    assert_equal(
        to_namedtuple({'a': [3, 4]}),
        NamedTuple(a=[3, 4])
    )

# Generated at 2022-06-25 17:27:27.021768
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    with pytest.raises(TypeError):
        to_namedtuple(1)

    with pytest.raises(FileNotFoundError):
        to_namedtuple('D:\\open.txt')

    from types import SimpleNamespace

    obj = SimpleNamespace()
    assert isinstance(to_namedtuple(obj), tuple)

    obj = SimpleNamespace(a=1, b=2, c=3)
    tup = to_namedtuple(obj)
    assert len(tup) == 3
    assert tup[0] == 1
    assert tup[1] == 2
    assert tup[2] == 3

    obj = SimpleNamespace(a=1, c=3, b=2)
    tup = to_namedtuple(obj)

# Generated at 2022-06-25 17:27:36.855721
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test a single argument function with type SimpleNamespace

    class SimpleNamespace_0(object):
        pass

    simple_namespace_0 = SimpleNamespace_0()
    test_var_0 = to_namedtuple(simple_namespace_0)
    assert(isinstance(test_var_0, namedtuple('NamedTuple', '')))
    assert(len(test_var_0) == 0)

    simple_namespace_1 = SimpleNamespace_0()
    simple_namespace_1.foo = 1
    test_var_1 = to_namedtuple(simple_namespace_1)
    assert(isinstance(test_var_1, namedtuple('NamedTuple', 'foo')))
    assert(test_var_1.foo == 1)

    simple_namespace_2 = Simple

# Generated at 2022-06-25 17:27:46.578840
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from collections.abc import (
        Mapping,
        Sequence,
    )
    from types import SimpleNamespace
    from typing import (
        Any,
        List,
        NamedTuple,
        Tuple,
        Union,
    )
    from flutils.validators import validate_identifier
    # Setup
    out: Union[NamedTuple, Tuple, List] = None
    # _to_namedtuple
# _to_namedtuple.register(Any)
    # test_case_0
    simple_namespace_0 = module_0.SimpleNamespace() # type: SimpleNamespace
    var_0 = to_namedtuple(simple_namespace_0) # type: Union[NamedTuple, T

# Generated at 2022-06-25 17:27:54.685951
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

# Generated at 2022-06-25 17:28:05.656957
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Example 1:
    dic = {'a': 1, 'b': 2}
    # Type: <class 'collections.namedtuple'>
    assert type(to_namedtuple(dic)) is namedtuple
    # Value: NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Example 2:
    ordered_dict = OrderedDict(a=1, b=2)
    # Type: <class 'collections.namedtuple'>
    assert type(to_namedtuple(ordered_dict)) is namedtuple
    # Value: NamedTuple(a=1, b=2)
    assert to_namedtuple(ordered_dict) == namedtuple

# Generated at 2022-06-25 17:28:09.975680
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)

if __name__ == '__main__':
    import flutils.namedtupleutils
    flutils.namedtupleutils.__hf_unit_test__()

# Generated at 2022-06-25 17:28:49.488374
# Unit test for function to_namedtuple
def test_to_namedtuple():
    namedtuple_0 = to_namedtuple({})
    namedtuple_1 = to_namedtuple({'a': 1, 'b': 2, 'c': 3})
    assert hasattr(namedtuple_0, "a") is False
    assert hasattr(namedtuple_0, "b") is False
    assert hasattr(namedtuple_1, "a") is True
    assert hasattr(namedtuple_1, "b") is True
    assert getattr(namedtuple_1, "a") == 1
    assert getattr(namedtuple_1, "b") == 2
    assert hasattr(namedtuple_1, "c") is True
    assert getattr(namedtuple_1, "c") == 3



# Generated at 2022-06-25 17:28:55.109465
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # SimpleNamespace(b=2, a=1)
    dic = dict(a=1, b=2)
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert isinstance(out, tuple)
    assert not isinstance(out, list)
    assert out.a == 1
    assert out.b == 2
    assert out[0] == 1
    assert out[1] == 2
    assert len(out) == 2

    # (1, 2)
    tup = list(dic.values())
    out = to_namedtuple(tup)
    assert isinstance(out, tuple)
    assert not isinstance(out, list)
    assert len(out) == 2
    assert out[0] == 1
    assert out[1] == 2

# Generated at 2022-06-25 17:29:01.656371
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('\nTest number: 0')
    test_case_0()

# Create a dictionary to represent this module
# This is primarily for the purposes of including this module in the documentation
# noinspection PyMissingOrEmptyDocstring

# Generated at 2022-06-25 17:29:13.275109
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple(1) == 1
    # Test for list with identification
    assert to_namedtuple([{'a': 1}, {'a': 2}]) == [NamedTuple(a=1), NamedTuple(a=2)]
    # Test for list without identifcation
    assert to_namedtuple([{'1': 1}, {'2': 2}]) == [NamedTuple(_1=1), NamedTuple(_2=2)]
    # Test for tuple with identification
    assert to_namedtuple(({'a': 1}, {'a': 2})) == (NamedTuple(a=1), NamedTuple(a=2))
    # Test for tuple without identifcation

# Generated at 2022-06-25 17:29:23.894502
# Unit test for function to_namedtuple
def test_to_namedtuple():
    ###
    # Setup
    ###
    dic = {'a': 1, 'b': 2}
    namedtuple_0 = to_namedtuple(dic)
    assert hasattr(namedtuple_0, 'b')
    assert namedtuple_0.a == 1
    assert namedtuple_0.b == 2
    ###
    # Teardown
    ###
    # noop
    ###
    # Assertions
    ###
    namedtuple_0
    if __name__ == "__main__":
        print("\n")
        simple_namespace_0 = module_0.SimpleNamespace()
        var_0 = to_namedtuple(simple_namespace_0)
        print("\n")

# Generated at 2022-06-25 17:29:31.952262
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test if the exception 'TypeError' it's raise when is given a 'str' type
    # as argument.
    with pytest.raises(TypeError):
        str_0 = 'str_0'
        to_namedtuple(str_0)
    # Test if the exception 'TypeError' it's raise when is given a 'int' type
    # as argument.
    with pytest.raises(TypeError):
        int_0 = 1
        to_namedtuple(int_0)
    # Test if the exception 'TypeError' it's raise when is given a 'float'
    # type as argument.
    with pytest.raises(TypeError):
        float_0 = 1.1
        to_namedtuple(float_0)
    # Test if the exception 'TypeError' it's raise when is given

# Generated at 2022-06-25 17:29:42.482049
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:29:52.426097
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyPep8Naming
    def _check_converted_namedtuple(
            obj: str,
            expected: Any,
            _started: bool = False
    ) -> None:
        _NT = cast(NamedTuple, expected)
        for attr in _NT._fields:
            value = getattr(expected, attr)
            if isinstance(value, list):
                assert isinstance(obj, list)
            elif isinstance(value, namedtuple):
                assert isinstance(obj, namedtuple)
            else:
                assert not isinstance(obj, (list, namedtuple))
            assert attr in obj, (attr, obj)
            assert getattr(obj, attr) == value
        assert len(obj) == len(expected)
        out = obj._asdict()

# Generated at 2022-06-25 17:29:54.072974
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass


if __name__ == '__main__':
    # Unit test for function to_namedtuple
    test_to_namedtuple()

# Generated at 2022-06-25 17:29:59.924992
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def test_function_0():
        var_0 = to_namedtuple({'a': 1, 'b': 2})
        assert isinstance(var_0, tuple)
        assert var_0 == ('a', 'b')
    def test_function_1():
        var_0 = to_namedtuple([{'a': 1, 'b': 2}])
        assert isinstance(var_0, list)
        assert var_0 == [('a', 'b')]
    def test_function_2():
        var_0 = to_namedtuple((('a', 1), ('b', 2)))
        assert isinstance(var_0, tuple)
        assert var_0 == ('a', 'b')