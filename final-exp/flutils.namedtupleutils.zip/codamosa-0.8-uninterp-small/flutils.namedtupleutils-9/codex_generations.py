

# Generated at 2022-06-25 17:21:00.873690
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for when the given type is of dict and the dictionary has no keys
    assert isinstance(to_namedtuple({}), namedtuple) is True
    assert hasattr(to_namedtuple({}), '__dict__') is False
    assert hasattr(to_namedtuple({}), '__slots__') is False

    # Test for when the given type is of dict and the dictionary contains keys
    # that can be attributes
    dic = {'a': 1, 'b': 2}
    assert isinstance(to_namedtuple(dic), namedtuple) is True
    assert hasattr(to_namedtuple(dic), '__dict__') is False
    assert hasattr(to_namedtuple(dic), '__slots__') is False
    assert to_namedtuple(dic).a

# Generated at 2022-06-25 17:21:14.989245
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) == 1
    assert to_namedtuple('foo') == 'foo'
    assert to_namedtuple(True) is True

    d = {'a': 1, 'b': 2}
    out = to_namedtuple(d)
    assert out == d
    assert out.a == 1
    assert out.b == 2
    assert out[0] == 1
    with pytest.raises(AttributeError):
        out.c

    d = {'_c': 3}
    out = to_namedtuple(d)
    assert out._c == 3
    with pytest.raises(AttributeError):
        out.c

    d = {'0c': 3}
    out = to_namedtuple(d)

# Generated at 2022-06-25 17:21:29.592115
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Calling function 'to_namedtuple'
    # Variable (type: module) 'simple_namespace_0' undefined
    var_0 = to_namedtuple(simple_namespace_0)

    # Calling function 'to_namedtuple'
    # Variable (type: class 'dict') 'var_0' undefined
    # Variable (type: class 'dict') 'var_0' undefined
    var_1 = to_namedtuple(var_0)

    # Calling function 'to_namedtuple'
    # Variable (type: class 'list') 'var_0' undefined
    # Variable (type: class 'list') 'var_0' undefined
    var_2 = to_namedtuple(var_0)

    # Calling function 'to_namedtuple'
    # Variable (type: class 'str') 'var_0

# Generated at 2022-06-25 17:21:40.584726
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # setup
    test_data_0: List[Tuple[Mapping, NamedTuple]] = [
        ({'a': 1, 'b': 2}, NamedTuple(a=1, b=2)),
        ({'a': 1, 'b': 2, }, NamedTuple(a=1, b=2)),
        ({'a': 1, 'b': 2, 'c': 3}, NamedTuple(a=1, b=2, c=3)),
    ]
    for data, result in test_data_0:
        # test
        response = to_namedtuple(data)
        # verify
        assert response == result



# Generated at 2022-06-25 17:21:47.607054
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': [{'c': 3}, {'c': 4}]}) == namedtuple('NamedTuple', ['a', 'b'])(a=[namedtuple('NamedTuple', ['c'])(c=3), namedtuple('NamedTuple', ['c'])(c=4)], b=2)

# Generated at 2022-06-25 17:21:54.125139
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:22:06.746984
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from types import (
        SimpleNamespace,
    )
    import typing as func_0
    simple_namespace_0 = SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)
    dic_0 = OrderedDict()
    list_0 = list()
    tuple_0 = tuple()
    tuple_1 = tuple()
    var_1 = to_namedtuple(dic_0)
    var_2 = to_namedtuple(list_0)
    var_3 = to_namedtuple(tuple_0)
    var_4 = to_namedtuple(tuple_1)
    if var_0 is not simple_namespace_0:
        var_0 = to_namedtuple

# Generated at 2022-06-25 17:22:15.120784
# Unit test for function to_namedtuple
def test_to_namedtuple():
    x = SimpleNamespace()
    x.a = 1
    x.b = 2
    assert to_namedtuple(x) == NamedTuple(a=1, b=2)
    x = {'a': 1, 'b': 2}
    assert to_namedtuple(x) == NamedTuple(a=1, b=2)
    x = OrderedDict()
    x['a'] = 1
    x['b'] = 2
    assert to_namedtuple(x) == NamedTuple(a=1, b=2)
    x = {'a': 1, 'b': 2}
    y = [1, 2, 3, 4]
    z = [x, y]

# Generated at 2022-06-25 17:22:21.400240
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)

    # Check type of ``var_0``
    assert isinstance(var_0, (list, tuple, NamedTuple))
    assert var_0 == ()

# Generated at 2022-06-25 17:22:30.211693
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0 = dict()
    dict_0["a"] = 1
    dict_0["b"] = 2
    var_0 = to_namedtuple(dict_0)
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.a = 1
    simple_namespace_0.b = 2
    var_1 = to_namedtuple(simple_namespace_0)
    dict_1 = dict()
    dict_1["a"] = 1
    dict_1["b"] = 2
    dict_1["c"] = dict()
    dict_1["c"]["d"] = 4
    dict_1["c"]["e"] = 5
    dict_1["f"] = dict()
    dict_1["f"]["g"] = 6
    dict_

# Generated at 2022-06-25 17:22:43.577700
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    @singledispatch
    def _to_namedtuple(
            obj: Any,
            _started: bool = False
    ) -> Any:
        if _started is False:
            raise TypeError(
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                "got: (%r) %s" % (type(obj).__name__, obj)
            )
        return obj


    # noinspection PyUnusedLocal,Mypy
    @_to_namedtuple.register(Mapping)
    def _(
            obj: Mapping,
            _started: bool = False
    ) -> Union[NamedTuple, Tuple]:
        keys = []

# Generated at 2022-06-25 17:22:53.574194
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils

    assert namedtuple('NamedTuple', '')() == \
        flutils.namedtupleutils.to_namedtuple({})
    assert namedtuple('NamedTuple', '')() == \
        flutils.namedtupleutils.to_namedtuple(OrderedDict())

    assert namedtuple('NamedTuple', 'a b')() == \
        flutils.namedtupleutils.to_namedtuple({})
    assert namedtuple('NamedTuple', 'a b')() == \
        flutils.namedtupleutils.to_namedtuple(OrderedDict())

    assert namedtuple('NamedTuple', 'a b')() == \
        flutils.namedtupleutils.to_namedtuple(types.SimpleNamespace())



# Generated at 2022-06-25 17:23:02.528995
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for function to_namedtuple
    simple_namespace_0 = module_0.SimpleNamespace()

    # Verify the conversion.
    var_0 = to_namedtuple(simple_namespace_0)
    print("var_0: %s\n" % var_0)
    assert var_0 == NamedTuple(empty=NamedTuple()), "Invalid output: %s" % var_0


# Generated at 2022-06-25 17:23:05.196689
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)


# Generated at 2022-06-25 17:23:11.339055
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(args=[__file__]))

# Generated at 2022-06-25 17:23:18.610814
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Tested with namedtuples

    # Tested with namedtuples
    assert to_namedtuple(NamedTuple(a=1, b=2)) == NamedTuple(a=1, b=2)

    from collections import OrderedDict

    # Tested with OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    # Tested with SimpleNamespace
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)

    # Tested with mutable and immutable seqs
    var_0 = to_namedtuple(['a'])

    # Edge cases

    var_

# Generated at 2022-06-25 17:23:24.164561
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': {'c': 3}}) == NamedTuple(
        a=1,
        b=NamedTuple(c=3)
    )
    assert to_namedtuple({
        'a': 1,
        'b': {
            'c': 3,
            '__d': 4
        }
    }) == NamedTuple(
        a=1,
        b=NamedTuple(c=3)
    )

# Generated at 2022-06-25 17:23:33.779464
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test that line numbers are shown in traceback
    #  assert False, 'Failed in function: "{}" at line {}'.format(
    #      "test_to_namedtuple", sys._getframe().f_lineno
    #  )
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)
    assert repr(var_0) == "NamedTuple()", f"Expected: 'NamedTuple()', got {repr(var_0)}"
    dic = {'a': 1, 'b': 2}
    var_1 = to_namedtuple(dic)

# Generated at 2022-06-25 17:23:39.077324
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_0 = {'a': 1, 'b': 2, 'c': 3}
    var_1 = to_namedtuple(var_0)
    test_case_0()

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:23:50.718997
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Here we create a dict with keys that are not in the right
    # format to be recognized as attribute names.  This means that
    # this input will be returned as is.
    simple_namespace_0 = module_0.SimpleNamespace()
    dict_0 = dict()
    dict_0[0] = simple_namespace_0
    dict_0['_test'] = 1
    dict_0['test_test'] = 2
    dict_0['test test'] = 3
    dict_0['test-test'] = 4
    dict_0['test+test'] = 5
    dict_0['test$test'] = 6
    dict_0['test%test'] = 7
    dict_0['test/test'] = 8
    dict_0['test(test'] = 9
    dict_0['test)test'] = 10

# Generated at 2022-06-25 17:23:59.922026
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)


# Generated at 2022-06-25 17:24:11.335506
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import random

    random.seed(0)


# Generated at 2022-06-25 17:24:21.423841
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import types as module_0
    import collections.abc as module_1
    import typing as module_2
    import typing as module_3
    import functools as module_4
    import collections as module_5

    class Test(unittest.TestCase):
        def test_0(self):
            simple_namespace_0 = module_0.SimpleNamespace()
            var_0 = to_namedtuple(simple_namespace_0)
            self.assertIsInstance(var_0, module_5.namedtuple)
            self.assertEqual(var_0, module_5.namedtuple('NamedTuple', '')())
            self.assertIsInstance(var_0, module_2.NamedTuple)

# Generated at 2022-06-25 17:24:22.660645
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True

# Generated at 2022-06-25 17:24:36.175221
# Unit test for function to_namedtuple
def test_to_namedtuple():
    #FIXME: 
    assert isinstance(to_namedtuple({}), tuple), 'should return tuple'
    assert isinstance(to_namedtuple([]), list), 'should return list'
    assert to_namedtuple({}) == to_namedtuple(namedtuple('', '')()), 'should be equal'
    assert to_namedtuple({}) == to_namedtuple(types.SimpleNamespace()), 'should be equal'
    test_case_0()

if __name__ == '__main__':
    import types as module_0
    import types as module_1
    import types as module_2

    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_1 = module_1.SimpleNamespace()

# Generated at 2022-06-25 17:24:44.615513
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Create the variables
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.var_0 = module_0.SimpleNamespace()
    simple_namespace_0.var_0.var_0 = 'test_str_0'
    simple_namespace_0.var_1 = 'test_str_1'
    dict_0 = OrderedDict()
    dict_0['var_0'] = 'test_str_0'
    list_0 = [None, '', 'test_str_0']
    list_0[0] = dict_0
    # Function to_namedtuple
    var_0 = to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:24:57.943433
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Set up test case 0
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)

    # Set up test case 1
    simple_namespace_1 = module_0.SimpleNamespace()
    simple_namespace_1.a = 1
    simple_namespace_1.b = 2
    var_1 = to_namedtuple(simple_namespace_1)

    # Set up test case 2
    dic_0 = {'a': 1, 'b': 2, 'c': 'abc'}
    var_2 = to_namedtuple(dic_0)

    # Set up test case 3
    lis_0 = []
    var_3 = to_namedtuple(lis_0)

    # Set up test

# Generated at 2022-06-25 17:25:08.248557
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)
    test_var_0 = NamedTuple('SimpleNamespace', [])
    assert var_0 == test_var_0
    simple_namespace_1 = module_0.SimpleNamespace(a=1)
    var_1 = to_namedtuple(simple_namespace_1)
    test_var_1 = NamedTuple('SimpleNamespace', [('a', 1)])
    assert var_1 == test_var_1
    simple_namespace_2 = module_0.SimpleNamespace(a=1, b=2)
    var_2 = to_namedtuple(simple_namespace_2)

# Generated at 2022-06-25 17:25:21.077645
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections import namedtuple
    from types import SimpleNamespace
    # Test for a List
    simple_list_0 = [
        1,
        2,
        3
    ]
    assert to_namedtuple(simple_list_0) == [1, 2, 3]
    # Test for a Mapping
    simple_dict_0 = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    assert to_namedtuple(simple_dict_0) == namedtuple('NamedTuple', ['a', 'b', 'c'])(a=1, b=2, c=3)
    # Test for a Mapping

# Generated at 2022-06-25 17:25:37.172567
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)

    if not type(nt).__name__ == 'NamedTuple':
        raise AssertionError('Expect %r to be of type %r, but received: %r' % ('nt', 'NamedTuple', type(nt)))

    if not nt.b == 2:
        raise AssertionError('Expect %r to be of value %r, but received: %r' % ('nt.b', 2, nt.b))

    dic = {'a': 1, 'b': [2, '3', {'4': 4}]}
    nt = to_namedtuple(dic)

    if not type(nt).__name__ == 'NamedTuple':
        raise Assert

# Generated at 2022-06-25 17:25:55.431387
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test with a simple namespace.
    #
    # Create a simple namespace.
    simple_namespace_0 = module_0.SimpleNamespace()
    # Validate the simple namespace is a SimpleNamespace.
    assert isinstance(simple_namespace_0, module_0.SimpleNamespace)
    # Convert the simple namespace to a NamedTuple.
    var_0 = to_namedtuple(simple_namespace_0)
    # Validate the returned value is a tuple.
    assert isinstance(var_0, tuple)

    # Test with a list that is not empty.
    #
    # Create a list with a dictionary.
    list_0 = ['a', 1, {'b': 2}]
    # Convert the list to a NamedTuple.
    var_0 = to_namedtuple(list_0)


# Generated at 2022-06-25 17:26:03.459622
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.a = 1
    simple_namespace_0.b = 2
    simple_namespace_0.c = 3
    var_0 = to_namedtuple(simple_namespace_0)
    # Check if NamedTuple is returned
    assert var_0 == namedtuple('NamedTuple', ['a', 'b', 'c'])(a=1, b=2, c=3)
   
    # Check if numeric keys are changed
    ordered_dict_0 = OrderedDict()
    ordered_dict_0.update({1: 1, 2: 2, 3: 3})
    var_1 = to_namedtuple(ordered_dict_0)

# Generated at 2022-06-25 17:26:10.938109
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.attr_0 = to_namedtuple(simple_namespace_0)
    assert hasattr(simple_namespace_0, 'attr_0')
    assert type(simple_namespace_0.attr_0) == to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:26:21.985410
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Empty dictionary
    var_0 = to_namedtuple({})
    assert repr(var_0) == "NamedTuple(b'')"
    # Mapping with single key-value
    var_0 = to_namedtuple({'a': 1})
    assert repr(var_0) == "NamedTuple(a=1)"
    # Mapping with multiple keys-values
    var_0 = to_namedtuple({'a': 1, 'B': 2, '3c': 3})
    assert repr(var_0) == "NamedTuple(B=2, a=1, _3c=3)"
    # NamedTuple
    var_0 = to_namedtuple(NamedTuple)

# Generated at 2022-06-25 17:26:34.152435
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('test_to_namedtuple')
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple)
    assert out.a == 1
    assert out.b == 2
    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple)
    assert out.a == 1
    assert out.b == 2
    dic = OrderedDict(a=1, b=2)
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple)
    assert out.a == 1
    assert out.b == 2

# Generated at 2022-06-25 17:26:34.758049
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-25 17:26:46.544684
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # test_to_namedtuple_0
    try:
        to_namedtuple(None)
    except:
        pass
    else:
        raise AssertionError('to_namedtuple(None) did not raise a TypeError')

    # test_to_namedtuple_1
    try:
        to_namedtuple(stdout)
    except:
        pass
    else:
        raise AssertionError('to_namedtuple(stdout) did not raise a TypeError')

    # test_to_namedtuple_2
    try:
        to_namedtuple(open('not a real file'))
    except:
        pass

# Generated at 2022-06-25 17:26:53.413439
# Unit test for function to_namedtuple
def test_to_namedtuple():
                        # FIXME: Use assert_type from the flutils.assertutils
                        # module instead of using hasattr directly
                        # [boolean, string]
                        # TODO: Come up with a new simple test case
    _simple_namespace_0 = module_0.SimpleNamespace()
    _var_0 = to_namedtuple(_simple_namespace_0)
    assert hasattr(_var_0, '__dict__') is False
    assert hasattr(_var_0, '__slots__') is False
    assert _var_0 == ()
    _list_0 = [{}, _simple_namespace_0]
    _var_0 = to_namedtuple(_list_0)
    assert hasattr(_var_0, '__dict__') is False
    assert hasattr(_var_0, '__slots__')

# Generated at 2022-06-25 17:27:04.038495
# Unit test for function to_namedtuple
def test_to_namedtuple():
    ordered_dict_0 = OrderedDict()
    simple_dict_0: SimpleNamespace
    simple_dict_1: SimpleNamespace
    simple_dict_2: SimpleNamespace
    simple_dict_3: SimpleNamespace
    simple_dict_4: SimpleNamespace
    simple_dict_0 = SimpleNamespace()
    simple_dict_1 = SimpleNamespace()
    simple_dict_2 = SimpleNamespace()
    simple_dict_3 = SimpleNamespace()
    simple_dict_4 = SimpleNamespace()
    simple_dict_0.simple_dict_0 = simple_dict_1
    simple_dict_0.simple_dict_1 = simple_dict_2
    simple_dict_2.simple_dict_2 = simple_dict_3
    simple_dict_3.simple_dict_3 = simple

# Generated at 2022-06-25 17:27:15.556722
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import copy
    import datetime
    import decimal
    import fractions
    from collections import OrderedDict
    from dateutil import tz
    from decimal import Decimal
    from fractions import Fraction
    from numbers import Number
    from uuid import UUID

    assert to_namedtuple([]) == []
    assert to_namedtuple(OrderedDict()) == NamedTuple()

    # Basic types
    assert to_namedtuple(OrderedDict(a=1)) == NamedTuple(a=1)
    assert to_namedtuple(OrderedDict(a=False)) == NamedTuple(a=False)
    assert to_namedtuple(OrderedDict(a='a')) == NamedTuple(a='a')
    assert to_namedtuple(OrderedDict(a=None)) == Named

# Generated at 2022-06-25 17:27:37.272090
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test cases for to_namedtuple
    simple_namespace_1 = module_0.SimpleNamespace(
        a=10,
        b='str',
        c=None,
    )
    var_0 = to_namedtuple(simple_namespace_1)
    assert isinstance(var_0, tuple)
    assert hasattr(var_0, 'a')
    assert hasattr(var_0, 'b')
    assert hasattr(var_0, 'c')
    assert var_0.a == 10
    assert var_0.b == 'str'
    assert var_0.c == None

# Generated at 2022-06-25 17:27:46.984716
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import copy
    import types as module_0

    dict_0 = dict()
    dict_0['a'] = 1
    dict_0['b'] = 2
    dict_0['c'] = 3
    dict_0['d'] = 4
    dict_0['e'] = 5
    dict_0['f'] = 6
    dict_0['g'] = 7
    dict_0['h'] = 8
    dict_0['i'] = 9
    dict_0['j'] = 10
    dict_0['k'] = 11
    dict_0['l'] = 12
    dict_0['m'] = 13
    dict_0['n'] = 14
    dict_0['o'] = 15
    dict_0['p'] = 16
    dict_0['q'] = 17
    dict_0['r'] = 18

# Generated at 2022-06-25 17:27:50.269218
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Case 0:
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)


import unittest


# Generated at 2022-06-25 17:28:01.717500
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # create an instance of the NamedTuple
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.a = 1
    simple_namespace_0.c = 2
    simple_namespace_0.b = simple_namespace_0
    var_0 = to_namedtuple(simple_namespace_0)
    assert (var_0.a == 1)
    assert (var_0.b.a == 1)
    assert (var_0.c == 2)
    var_0.b.a = 3
    assert (var_0.a == 3)
    assert (var_0.b.a == 3)
    assert (var_0.c == 2)
    assert (var_0.b.c == 2)

# Generated at 2022-06-25 17:28:04.738971
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test arguments
    pass

    # Test return value
    assert True


if __name__ == '__main__':
    import unittest

    unittest.main('test_to_namedtuple')

# Generated at 2022-06-25 17:28:15.784122
# Unit test for function to_namedtuple
def test_to_namedtuple():
    items_0 = [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}, {'a': 1, 'b': 2}]
    expected_0 = [NamedTuple(a=1, b=2), NamedTuple(a=1, b=2), NamedTuple(a=1, b=2)]
    actual_0 = to_namedtuple(items_0)
    assert expected_0 == actual_0
    items_1 = (1, 2, 3, 4)
    expected_1 = (1, 2, 3, 4)
    actual_1 = to_namedtuple(items_1)
    assert expected_1 == actual_1
    items_2 = {'a': 1, 'b': 2}

# Generated at 2022-06-25 17:28:27.457004
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test of function to_namedtuple, case 0
    test_case_0()


if __name__ == '__main__':
    import sys
    import unittest


    class UnitTests(unittest.TestCase):
        def test_to_namedtuple(self):
            # Test of function to_namedtuple, case 0
            test_case_0()
            # Test of function to_namedtuple, case 1
            # This is a comment in case 1
            # In case 1, x = 2
            x_0 = 2
            # y = 'a'
            y_0 = 'a'
            var_0 = to_namedtuple(y_0)

    test_suite = unittest.TestSuite()

# Generated at 2022-06-25 17:28:36.740528
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:28:45.495238
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.foo = 'bar'
    simple_namespace_0.baz = 'qux'
    namedtuple_1 = to_namedtuple(simple_namespace_0)
    assert namedtuple_1.foo == 'bar'
    assert namedtuple_1.baz == 'qux'
    namedtuple_0 = to_namedtuple(namedtuple_1)
    assert isinstance(namedtuple_0, NamedTuple)

# Generated at 2022-06-25 17:28:56.779951
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    # dictionary
    dic_0 = {'a': 1, 'b': 2}
    nt_0 = to_namedtuple(dic_0)
    assert nt_0.a == 1
    assert nt_0.b == 2
    dic_1 = {'a': 1, 'b': 2, '_c': 3}
    nt_1 = to_namedtuple(dic_1)
    hasattr(nt_1, '_c')
    dic_2 = OrderedDict(dic_0)
    nt_2 = to_namedtuple(dic_2)
    assert nt_2[0] == dic_0

# Generated at 2022-06-25 17:29:34.447388
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_28 = to_namedtuple(simple_namespace_0)

if __name__ == '__main__':
    try:
        test_case_0()
    except SystemExit:
        pass
    except:
        print("unexpected error:", sys.exc_info()[0])
    try:
        test_to_namedtuple()
    except SystemExit:
        pass
    except:
        print("unexpected error:", sys.exc_info()[0])

# flutils.namedtupleutils.to_namedtuple.to_namedtuple
# flutils.namedtupleutils.to_namedtuple._to_namedtuple
# flutils.namedtupleutils.to_namedtuple._to_namedtuple

# Generated at 2022-06-25 17:29:42.339271
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    simple_namespace_0.d = 0
    simple_namespace_0.a = 0
    simple_namespace_0.c = 0
    simple_namespace_0.b = 0
    var_0 = to_namedtuple(simple_namespace_0)
    print('var_0: {}'.format(var_0))


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:29:44.599679
# Unit test for function to_namedtuple
def test_to_namedtuple():
    simple_namespace_0 = module_0.SimpleNamespace()
    var_0 = to_namedtuple(simple_namespace_0)

# Generated at 2022-06-25 17:29:48.806694
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    def test_to_namedtuple(
            simple_namespace_0: module_0.SimpleNamespace
    ) -> NamedTuple:
        var_0 = to_namedtuple(simple_namespace_0)
        return var_0

# Generated at 2022-06-25 17:29:56.360058
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj_1 = {'a': 1, 'b': 2}
    namedtuple_0 = to_namedtuple(obj_1)
    assert namedtuple_0.a == 1
    assert namedtuple_0.b == 2
    list_0 = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    var_0 = to_namedtuple(list_0)
    assert var_0[0].a == 1
    assert var_0[0].b == 2
    assert var_0[1].a == 3
    assert var_0[1].b == 4
    obj_0 = OrderedDict((('c', 3), ('a', 1), ('b', 2)))
    namedtuple_1 = to_namedtuple(obj_0)

# Generated at 2022-06-25 17:29:59.078680
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = {'a': 1, 'b': 2}
    b = to_namedtuple(a)
    assert b.a == 1


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:30:00.509552
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:30:12.440510
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import types as module_0
    def test_case_0():
        simple_namespace_0 = module_0.SimpleNamespace()
        var_0 = to_namedtuple(simple_namespace_0)

    def test_case_1():
        simple_namespace_0 = module_0.SimpleNamespace()
        simple_namespace_1 = module_0.SimpleNamespace()
        simple_namespace_1.foo = simple_namespace_0
        simple_namespace_1.bar = simple_namespace_0
        simple_namespace_1.baz = simple_namespace_0
        var_0 = to_namedtuple(simple_namespace_1)

    def test_case_2():
        simple_namespace_0 = module_0.SimpleNamespace()
        simple_namespace_

# Generated at 2022-06-25 17:30:16.329897
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert [1, 2] == to_namedtuple([1, 2])
    assert [1, 2] == to_namedtuple((1, 2))
    assert ['a', 'b', 'c'] == to_namedtuple('abc')

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 17:30:22.819742
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]