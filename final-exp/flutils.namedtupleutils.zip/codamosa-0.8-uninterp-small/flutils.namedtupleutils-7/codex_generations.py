

# Generated at 2022-06-25 17:20:58.059545
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import choice
    from string import ascii_letters, digits
    from itertools import product
    from numbers import Integral
    _o = object
    for length in range(1, 10):
        for idx in range(100):
            allowed = [
                len(ascii_letters),
                len(digits),
                length,
            ]
            len_0 = choice(allowed)
            len_1 = choice(allowed)
            itms = []
            for idx_0 in range(len_0):
                for idx_1 in range(len_1):
                    itms.append(
                        choice(list(product(ascii_letters, digits)))
                    )
            set_0 = set(itms)
            var_0 = to_namedtuple(set_0)
            assert type

# Generated at 2022-06-25 17:21:02.759191
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d0 = dict(a=0, b=1, c=2)
    t0 = to_namedtuple(d0)
    assert t0 == d0
    assert d0.a == t0.a
    d1 = dict(a=0, _b=1, c=2)
    t1 = to_namedtuple(d1)
    assert t1 == d1
    assert d1.a == t1.a
    d2 = dict(a=0, __b=1, c=2)
    t2 = to_namedtuple(d2)
    assert t2 == d2
    assert d2.a == t2.a
    d3 = dict(a=0, b=1, c=2)
    t3 = to_namedtuple(d3)

# Generated at 2022-06-25 17:21:16.641278
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyProtectedMember
    set_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(set_0)
    assert var_0.a == 1
    assert var_0.b == 2

    # noinspection PyProtectedMember
    set_1 = OrderedDict([('a', 1), ('b', 2)])
    var_1 = to_namedtuple(set_1)
    assert var_1.a == 1
    assert var_1.b == 2

    list_0 = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    var_2 = to_namedtuple(list_0)
    assert var_2[0].a == 1

# Generated at 2022-06-25 17:21:29.717508
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # 1st test
    set_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(set_0)
    assert isinstance(var_0, collections.namedtuple)
    try:
        validate_identifier(var_0.a)
    except SyntaxError:
        assert False, "The identifier failed to validate when it should not have."
    assert var_0.a == 1

    # 2nd test
    set_1 = collections.OrderedDict({'a': 1, 'b': 2})
    var_1 = to_namedtuple(set_1)
    assert isinstance(var_1, collections.namedtuple)

# Generated at 2022-06-25 17:21:42.201008
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test 1 - Test if a dictionary is properly converted to a namedtuple
    def test_dict_conversion():
        d = dict(a=1, b=2)
        n = to_namedtuple(d)
        expected = namedtuple('NamedTuple', 'a, b')(a=1, b=2)
        assert n == expected
        assert isinstance(n, NamedTuple)
        assert d['a'] == n.a
        assert d['b'] == n.b

    test_dict_conversion()

    # Test 2 - Test if a SimpleNamespace is properly converted to a namedtuple
    def test_namespace_conversion():
        s = SimpleNamespace(a=1, b=2)
        n = to_namedtuple(s)

# Generated at 2022-06-25 17:21:53.014327
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0 = {'a': 1, 'b': 2}
    tuple_0 = to_namedtuple(dict_0)
    assert tuple_0.a == 1


if __name__ == '__main__':
    dict_0 = {'a': 1, 'b': 2}
    tuple_0 = to_namedtuple(dict_0)
    print(tuple_0.a)

# Generated at 2022-06-25 17:21:58.512079
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0: List[int] = [1, 2, 3]
    list_1: List[int] = [4, 5, 6]
    dict_0: dict = {'a': list_0, 'b': list_1}
    set_0 = to_namedtuple(dict_0)
    assert set_0.a == (1, 2, 3)
    assert set_0.b == (4, 5, 6)

# Generated at 2022-06-25 17:22:12.940418
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print("Testing to_namedtuple")

    # Test case 0
    set0 = None
    var0 = to_namedtuple(set0)

    # Test case 1
    set1 = {'a': 1, 'b': 2}
    var1 = to_namedtuple(set1)
    assert var1.a == 1
    assert var1.b == 2

    # Test case 2
    set2 = {'a': 'a', 'b': 2, 'c': 3}
    var2 = to_namedtuple(set2)
    assert var2.a == 'a'
    assert var2.b == 2
    assert var2.c == 3

    # Test case 3
    set3 = {'a': set1, 'b': 2, 'c': 3}
    var3 = to_namedtuple

# Generated at 2022-06-25 17:22:15.580596
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test Cases
    test_case_0()


if __name__ == '__main__':
    # Test Case
    test_to_namedtuple()

# Generated at 2022-06-25 17:22:27.569203
# Unit test for function to_namedtuple
def test_to_namedtuple():
    expected = NamedTuple(a=1, b=2)
    actual = to_namedtuple({'a': 1, 'b': 2})
    assert expected == actual

    expected = NamedTuple(a=1, b=2)
    actual = to_namedtuple({'a': 1, 'b': 2})
    assert expected == actual

    expected = NamedTuple(a=1, b=2)
    actual = to_namedtuple({'a': 1, 'b': 2})
    assert expected == actual

    expected = NamedTuple(a=1, b=2)
    actual = to_namedtuple({'a': 1, 'b': 2})
    assert expected == actual

    actual = to_namedtuple(None)

    expected = NamedTuple(a=1, b=2)

# Generated at 2022-06-25 17:22:41.559375
# Unit test for function to_namedtuple
def test_to_namedtuple():
    set_0 = ({'foo': 1, 'bar': 2, 'baz': 3}, [1, 2, '3', {'a': 1, 'b': 2}])
    var_0 = to_namedtuple(set_0)

# Generated at 2022-06-25 17:22:52.513352
# Unit test for function to_namedtuple
def test_to_namedtuple():
    set_0 = OrderedDict(a=1, b=2)
    var_0 = to_namedtuple(set_0)
    assert isinstance(var_0, tuple)
    assert isinstance(var_0, NamedTuple)
    assert var_0.a == 1
    assert var_0.b == 2

    set_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(set_0)
    assert isinstance(var_0, tuple)
    assert isinstance(var_0, NamedTuple)
    assert isinstance(var_0, SimpleNamespace)
    assert var_0.a == 1
    assert var_0.b == 2

    set_0 = SimpleNamespace(**set_0)
    var_0 = to_namedtuple

# Generated at 2022-06-25 17:23:02.170641
# Unit test for function to_namedtuple
def test_to_namedtuple():
    val_0 = to_namedtuple({'a': 1, 'b': 2})
    assert val_0.a == 1 and val_0.b == 2

    val_0 = to_namedtuple({'a': 1, 'b': [1, 2]})
    assert val_0.a == 1 and val_0.b == (1, 2)

    val_0 = to_namedtuple({'a': 1, 'b': []})
    assert val_0.a == 1 and val_0.b == ()

    val_0 = to_namedtuple([1, 2, {'a': 1, 'b': 2}])
    assert val_0 == (1, 2, NamedTuple(a=1, b=2))


# Generated at 2022-06-25 17:23:07.953314
# Unit test for function to_namedtuple
def test_to_namedtuple():
    set_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(set_0)
    assert isinstance(var_0, NamedTuple)
    assert isinstance(var_0, tuple)
    assert isinstance(var_0[0], int)
    assert isinstance(var_0[1], int)
    assert var_0 == NamedTuple(a=1, b=2)
    assert var_0[0] == 1
    assert var_0[1] == 2
    assert var_0.a == 1
    assert var_0.b == 2
    set_1 = OrderedDict([('a', 1), ('b', 2)])
    var_1 = to_namedtuple(set_1)
    assert isinstance(var_1, NamedTuple)

# Generated at 2022-06-25 17:23:14.473784
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test case for flutils.namedtupleutils.to_namedtuple

    This is a testing stub for your implementation of the function named
    for this assignment.
    """

    # Replace with your implementation
    assert True is True


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:23:16.181481
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert hasattr(to_namedtuple, '__call__')
    assert callable(to_namedtuple)

# Generated at 2022-06-25 17:23:27.797289
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_arg_0 = to_namedtuple([])
    print(test_arg_0)

    test_arg_0 = to_namedtuple([{}])
    print(test_arg_0)

    test_arg_0 = to_namedtuple({})
    print(test_arg_0)

    test_arg_0 = to_namedtuple(['b', 'a'])
    print(test_arg_0)

    test_arg_0 = to_namedtuple({'a': 'b'})
    print(test_arg_0)

    test_arg_0 = to_namedtuple(['a', 'b'])
    print(test_arg_0)

    test_arg_0 = to_namedtuple({'a': '1', 'b': 2})

# Generated at 2022-06-25 17:23:38.773716
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test 1 with input {'a': 1, 'b': 2}
    dic_0 = {'a': 1, 'b': 2}
    var_1 = to_namedtuple(dic_0)
    assert isinstance(var_1, NamedTuple)
    assert var_1.a == 1
    assert var_1.b == 2

    # Test 2 with input {'a': {'a': 1, 'b': 2}, 'b': 2}
    dic_1 = {'a': {'a': 1, 'b': 2}, 'b': 2}
    var_2 = to_namedtuple(dic_1)
    assert isinstance(var_2, NamedTuple)
    assert isinstance(var_2.a, NamedTuple)
    assert var_2.a.a == 1

# Generated at 2022-06-25 17:23:50.480488
# Unit test for function to_namedtuple
def test_to_namedtuple():
    set_0 = {"a": 1, "b": 2}
    var_0 = to_namedtuple(set_0)
    assert isinstance(var_0, NamedTuple)
    assert list(var_0._fields) == ['a', 'b']
    assert len(var_0._fields) == 2
    assert var_0.a == 1
    assert var_0.b == 2
    set_1 = [{"a": 1, "b": 2}, {"a": 1, "b": 2}]
    var_1 = to_namedtuple(set_1)
    assert isinstance(var_1, list)
    assert isinstance(var_1[0], NamedTuple)
    assert list(var_1[0]._fields) == ['a', 'b']

# Generated at 2022-06-25 17:23:52.913374
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(None) is None

# Generated at 2022-06-25 17:24:10.776351
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # NOTE: tests are run in alphabetical order of module.function name

    from collections import (
        OrderedDict,
        namedtuple,
    )
    from collections.abc import (
        Sequence,
    )
    import sys

    from flutils.namedtupleutils import to_namedtuple

    # case 0
    set_0 = {
        'a': 1,
        'b': 2,
    }
    var_0 = to_namedtuple(set_0)
    assert isinstance(var_0, namedtuple('NamedTuple', 'a b'))
    assert var_0.a == 1
    assert var_0.b == 2

    # case 1
    set_1 = OrderedDict({
        'a': 1,
        'b': 2,
    })
    var_

# Generated at 2022-06-25 17:24:21.390875
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Tuple
    from collections import namedtuple
    from collections.abc import Mapping, Sequence
    from types import SimpleNamespace
    # Test target function
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple

    class Custom(NamedTuple):
        a: int
        b: str
        c: int
        d: str

    class Custom2(NamedTuple):
        a: str
        b: int
        c: str
        d: int

    class Custom3(NamedTuple):
        a: str
        b: int
        c: str

    class Custom4(NamedTuple):
        a: str
        b: int
        c: str
        d: int
        e: object

# Generated at 2022-06-25 17:24:35.490692
# Unit test for function to_namedtuple
def test_to_namedtuple():

    class A(SimpleNamespace):
        x = {'a': 1, 'b': 2, 'OrderedDict': OrderedDict([('a', 'b'), ('b', 'c'), ('c', 'd')])}
        y = [{'a': 1}, {'b': 2}]
        z = {'a': 1, 'b': 2}
        w = [1, 2, 3]
        u = 'a'

    # noinspection PyTypeChecker
    a = A()
    b = to_namedtuple(a)
    assert b.x == NamedTuple(a=1, b=2, OrderedDict=NamedTuple(a='b', b='c', c='d'))

# Generated at 2022-06-25 17:24:44.280166
# Unit test for function to_namedtuple
def test_to_namedtuple():
    set_0 = {
        'a': 1,
        'b': 2,
    }
    var_0 = to_namedtuple(set_0)
    set_1 = {
        'a': 1,
        'b': 2,
        'c': {
            'z': {
                'd': 5,
                'e': 6,
            },
            'y': {
                'f': 7,
                'g': 8,
            }
        }
    }
    var_1 = to_namedtuple(set_1)
    set_2 = {
        'a': 1,
        'b': 2,
        'c': {
            'z': {
                'd': 5,
                'e': 6,
            }
        }
    }
    var_2 = to_named

# Generated at 2022-06-25 17:24:53.917366
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(None) is None
    assert to_namedtuple('') == ''
    assert to_namedtuple({}) == ()
    expected = namedtuple('NamedTuple', ['a'])(a=1)
    assert to_namedtuple({'a': 1}) == expected
    expected = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == expected



# Generated at 2022-06-25 17:25:03.006503
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple([1, [2, 3]]) == [1, [2, 3]]
    assert to_namedtuple([1, OrderedDict([('b', 2)])]) == [1, OrderedDict([('b', 2)])]
    # noinspection PyTypeChecker
    assert to_namedtuple([1, OrderedDict([('b', 2), ('a', 3)])]) == [1, OrderedDict([('b', 2), ('a', 3)])]
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))

# Generated at 2022-06-25 17:25:06.641495
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        def test_0(self):
            test_case_0()

    unittest.main()

# Generated at 2022-06-25 17:25:16.644512
# Unit test for function to_namedtuple
def test_to_namedtuple():

    obj = {}
    out = to_namedtuple(obj)
    assert out == ()

    obj = {'a': 1}
    out = to_namedtuple(obj)
    assert out == NamedTuple(a=1)

    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert out == NamedTuple(a=1, b=2)

    obj = {'a': 1, 'a b': 2}
    out = to_namedtuple(obj)
    assert out == NamedTuple(a_=1, a_b=2)

    obj = {'a': 1, '_a': 2}
    out = to_namedtuple(obj)
    assert out == NamedTuple(a=1)


# Generated at 2022-06-25 17:25:25.648096
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    from functools import singledispatch
    from typing import (
        Any,
        List,
        Tuple,
    )
    from flutils.namedtupleutils import to_namedtuple

    # This is used to support Python 2 and Python 3 with the same syntax
    # The @singledispatch decorator is used for this purpose.
    @singledispatch
    def _to_namedtuple(
            obj: Any,
            _started: bool = False
    ) -> Tuple[Any, ...]:
        if _started is False:
            raise TypeError(sys.exc_info()[1])
        return (obj,)

    # noinspection PyUnusedLocal

# Generated at 2022-06-25 17:25:39.228534
# Unit test for function to_namedtuple
def test_to_namedtuple():
    set_1 = {'a': 1, 'b': 2}
    var_1 = to_namedtuple(set_1)
    assert var_1.a == 1
    assert var_1.b == 2
    assert var_1 == ('a', 'b')
    set_2 = {'b': 2, 'a': 1}
    var_2 = to_namedtuple(set_2)
    assert var_2.a == 1
    assert var_2.b == 2
    assert var_2 == ('a', 'b')
    set_3 = {'b': 2, 'a': 1, 'c': 3}
    var_3 = to_namedtuple(set_3)
    assert var_3.a == 1
    assert var_3.b == 2
    assert var_3.c == 3

# Generated at 2022-06-25 17:25:56.813678
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyTypeChecker
    set_0 = [
        {
            'name': 'James',
            'age': 68,
            'children': [
                {'name': 'Sara', 'age': '32'},
                {'name': 'Jill', 'age': '30'},
                {'name': 'Jack', 'age': '28'}
            ]
        },
        {
            'name': 'James',
            'age': 68,
            'children': [
                {'name': 'Sara', 'age': '32'},
                {'name': 'Jill', 'age': '30'},
                {'name': 'Jack', 'age': '28'}
            ]
        }
    ]
    var_0 = to_namedtuple(set_0)
    # no

# Generated at 2022-06-25 17:26:07.133086
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    a_0 = to_namedtuple(dic)
    assert a_0 == (1, 2)
    dic = {'a': 1, 'b': 2}
    a_1 = to_namedtuple(dic)
    assert a_1 == (1, 2)
    dic = {'a': 1, 'b': 2}
    a_2 = to_namedtuple(dic)
    assert a_2 == (1, 2)
    dic = {'a': 1, 'b': 2}
    a_3 = to_namedtuple(dic)
    assert a_3 == (1, 2)



# Generated at 2022-06-25 17:26:19.416816
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test 0
    try:
        test_case_0()
    except Exception:
        import traceback
        print(traceback.format_exc())
        print("FAILED with idx: 0.")
    else:
        print("PASSED with idx: 0.")
    # Test 1
    set_1 = [
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
    ]
    var_1 = to_namedtuple(set_1)

# Generated at 2022-06-25 17:26:23.147428
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple as tnt

    namedtuple_0 = tnt({'a': 1, 'b': 2})
    assert namedtuple_0.a == 1
    assert namedtuple_0.b == 2

# Generated at 2022-06-25 17:26:34.201345
# Unit test for function to_namedtuple
def test_to_namedtuple():
    set_0 = {'a': 1, 'b': 2}
    set_1 = {'b': 2, 'a': 1}
    set_2 = {'b': 3, 'a': 1}
    var_0 = to_namedtuple(set_0)
    assert var_0 == NamedTuple(a=1, b=2)
    var_1 = to_namedtuple(set_1)
    assert var_1 == NamedTuple(a=1, b=2)
    var_2 = to_namedtuple(set_2)
    assert var_2 == NamedTuple(a=1, b=3)


if __name__ == '__main__':
    # Suck up all command line arguments.
    # This is to allow the use of the argparse module.
    argv = sys

# Generated at 2022-06-25 17:26:45.957613
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case #0
    set_0 = None
    var_0 = to_namedtuple(set_0)
    assert var_0 == None

    # Test case #1
    set_0 = ['_a', 'b']
    var_0 = to_namedtuple(set_0)
    assert var_0 == ['_a', 'b']

    # Test case #2
    set_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(set_0)
    assert var_0 == NamedTuple(a=1, b=2)

    # Test case #3
    set_0 = tuple((2, 1))
    var_0 = to_namedtuple(set_0)
    assert var_0 == (2, 1)

    # Test case #

# Generated at 2022-06-25 17:26:53.082401
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pickle
    from copy import copy
    from random import randint
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from flutils.namedtupleutils import to_namedtuple

    def make_test_object(depth: int) -> Union[dict, OrderedDict]:
        if depth == 0:
            return randint(0, 100)
        if randint(0, 1) == 0:
            out = dict()
        else:
            out = OrderedDict()
        for _ in range(randint(1, 3)):
            key = ''.join(
                chr(randint(97, 122))
                for _ in range(randint(1, 3))
            )
            val = make_test_object(depth - 1)
            out[key]

# Generated at 2022-06-25 17:27:03.871568
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': OrderedDict([('c', 3), ('d', 4)])}) == \
           NamedTuple(a=1, b=NamedTuple(c=3, d=4))
    assert to_namedtuple({'a': 1, 'b': SimpleNamespace(c=3, d=4)}) == \
           NamedTuple(a=1, b=NamedTuple(c=3, d=4))

# Generated at 2022-06-25 17:27:15.374283
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    list_0 = [
        1,
        {'a': 2, 'b': 3},
        ('c', 'd', 'e'),
        ['f', 'g', 'h'],
    ]
    var_0 = to_namedtuple(list_0)
    assert var_0[0] == 1
    assert var_0[3][1] == 'g'

    dict_0 = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3,
        },
        'c': [
            ['d', 'e', 'f'],
            ['g', 'h', 'i'],
        ],
    }

# Generated at 2022-06-25 17:27:25.158365
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    int_0 = 0
    set_0 = None
    var_0 = dic_0
    var_1 = to_namedtuple(var_0)

    # Unit test for function to_namedtuple
    def test_to_namedtuple():
        dic_0 = {'a': 1, 'b': 2}
        int_0 = 0
        set_0 = None
        var_0 = dic_0
        var_1 = to_namedtuple(var_0)
        var_1 = to_namedtuple(set_0)
        print(var_1)

    def test_case_0():
        set_0 = None
        var_0 = to_namedtuple(set_0)

# Generated at 2022-06-25 17:27:52.276637
# Unit test for function to_namedtuple
def test_to_namedtuple():

    set_0 = {}
    var_0 = to_namedtuple(set_0)
    assert var_0 == NamedTuple(a=1, b=2, c=3)

    set_0 = {'a': 1, 'b': {'c': 3.14}, 'd': None}
    var_0 = to_namedtuple(set_0)
    assert var_0 == NamedTuple(a=1, b=NamedTuple(c=3.14), d=None)

    set_0 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    var_0 = to_namedtuple(set_0)
    assert var_0 == NamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-25 17:28:04.075052
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:28:12.376517
# Unit test for function to_namedtuple
def test_to_namedtuple():
    set_0 = {'a': 1, 'b': 2}
    set_1 = to_namedtuple(set_0)
    assert set_0['a'] == set_1.a
    assert set_0['b'] == set_1.b
    set_2 = {'a': 1, 'd': 2}
    set_3 = to_namedtuple(set_2)
    assert set_2['a'] == set_3.a
    assert set_2['d'] == set_3.d
    set_4 = {'a': 1, 'b': {'a': 1, 'b': 2}}
    set_5 = to_namedtuple(set_4)
    assert set_4['a'] == set_5.a
    assert set_4['b']['a'] == set_5

# Generated at 2022-06-25 17:28:23.466734
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), NamedTuple)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert isinstance(to_namedtuple({'a': 1, 'b': 2, 'c': 3}), NamedTuple)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == \
        NamedTuple(a=1, b=2, c=3)
    dic = {'a': 1, 'b': 2, 'c': 3}
    assert isinstance(to_namedtuple(dic), NamedTuple)

# Generated at 2022-06-25 17:28:28.746798
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    dic_0 = {}
    dic_0['a'] = 1
    dic_0['b'] = 2
    # Act
    test_0 = to_namedtuple(dic_0)
    # Assert
    assert test_0.a == 1
    assert test_0.b == 2

# Generated at 2022-06-25 17:28:37.922816
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple(obj)

    This test suite relies on ``to_namedtuple`` working properly since it
    is used in the testing.
    """

    # first, try None

    set_0 = None
    var_1 = None
    assert var_1 == var_1

    # then, try a str

    set_1 = "a"
    var_2 = _to_namedtuple(set_1)
    assert var_2 == "a"

    # next, a named tuple

    Make = namedtuple('Make', 'a, b')
    set_2 = Make(a=1, b=2)
    var_3 = _to_namedtuple(set_2)
    # noinspection PyTypeChecker
    assert var_3 == var_3

    # test a simple tuple



# Generated at 2022-06-25 17:28:49.335409
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1}, {'a': 2}]) == [NamedTuple(a=1), NamedTuple(a=2)]
    assert to_namedtuple(tuple([{'a': 1}, {'a': 2}])) == (NamedTuple(a=1), NamedTuple(a=2))

# Generated at 2022-06-25 17:28:58.084750
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import Dict, List, NamedTuple

    class DictTuple(NamedTuple):
        a: int
        b: int
        c: int
        d: int
        e: int
        hello: int
        hi: int
        my: int

    class MyTuple(NamedTuple):
        a: int
        b: int
        c: int
        d: int
        e: int
        hello: int
        hi: int
        my: int
        hello1: int
        hi1: int
        my1: int
        the_values1: Dict[str, int]
        the_values: OrderedDict[str, int]
        numbers: List[int]

    dic: OrderedDict[str, Any] = OrderedD

# Generated at 2022-06-25 17:29:09.081216
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # SimpleNamespace
    obj = SimpleNamespace(a=1, b=2,)
    out = to_namedtuple(obj)
    assert out.a == obj.a == 1
    assert out.b == obj.b == 2

    # dict
    obj = dict(a=1, b=2)
    out = to_namedtuple(obj)
    assert out.a == obj['a'] == 1
    assert out.b == obj['b'] == 2

    # OrderedDict
    obj = OrderedDict(c=3, a=1, b=2)
    out = to_namedtuple(obj)
    assert out.c == obj['c'] == 3
    assert out.a == obj['a'] == 1
    assert out.b == obj['b'] == 2

    # list
    obj

# Generated at 2022-06-25 17:29:12.943996
# Unit test for function to_namedtuple
def test_to_namedtuple():
    set_0 = {'a': 10, 'b': 20}
    var_0 = to_namedtuple(set_0)
    assert var_0[0] == 10
    assert var_0[1] == 20
    assert var_0._fields == ('a', 'b')

# Generated at 2022-06-25 17:29:44.419629
# Unit test for function to_namedtuple
def test_to_namedtuple():
    set_1 = SimpleNamespace(
        a=1,
        b=2
    )
    var_1 = to_namedtuple(set_1)
    assert var_1.a == 1
    assert var_1.b == 2

    set_1 = SimpleNamespace(
        a=1,
        c=3,
        b=2
    )
    var_1 = to_namedtuple(set_1)
    assert var_1.a == 1
    assert var_1.b == 2
    assert var_1.c == 3


# Generated at 2022-06-25 17:29:45.495807
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_0 = None
    var_1 = to_namedtuple(var_0)


# Generated at 2022-06-25 17:29:54.049957
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test Case #0:
    set_0 = None
    var_0 = None
    set_1 = {
        'b': 1,
        'a': 2,
    }
    var_1 = to_namedtuple(set_1)
    set_2 = {
        'c': 1,
        'a': 2,
    }
    var_2 = to_namedtuple(set_2)
    set_3 = OrderedDict({
        'c': 1,
        'a': 2,
    })
    var_3 = to_namedtuple(set_3)
    set_4 = {
        'b': 1,
    }
    var_4 = to_namedtuple(set_4)

# Generated at 2022-06-25 17:29:56.689702
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest, os
    fname = os.path.basename(__file__)
    pytest.main([fname, '-v', '-p', 'no:warnings'])

# Function to get a testable list of objects

# Generated at 2022-06-25 17:30:07.185804
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test inputs:

    # Test no value
    set_0 = None
    var_0 = to_namedtuple(set_0)

    # Test with bad string
    set_1 = "Not going to work!"
    try:
        var_1 = to_namedtuple(set_1)
    except TypeError:
        pass
    else:
        raise Exception('Bad string should have failed!')

    # Test with good string
    set_2 = "Good string."
    try:
        var_2 = to_namedtuple(set_2)
    except TypeError:
        raise Exception('Good string should not have failed!')

    # Test with bad list
    set_3 = [1, 2.0, 3]
    var_3 = to_namedtuple(set_3)

# Generated at 2022-06-25 17:30:15.858836
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import (
        OrderedDict,
    )
    from types import SimpleNamespace
    from flutils.textutils import camel_to_snake

    list_0 = [{'a': 1}, {'b': 2}]
    tup_0 = to_namedtuple(list_0)
    list_1 = [tup_0, tup_0]
    tup_1 = to_namedtuple(list_1)

# Generated at 2022-06-25 17:30:25.818356
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(b=2, a=1)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert (
        to_namedtuple({'c': 3, 'b': 2, 'a': 1}) ==
        NamedTuple(a=1, b=2, c=3)
    )
    actual = to_namedtuple([{'a': 1}, {'b': 2}, {'c': 3}])

# Generated at 2022-06-25 17:30:33.879049
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test default value of set_0
    set_0 = None
    assert var_0 == set_0
    # Test value of set_1
    set_1 = {}
    var_1 = to_namedtuple(set_1)
    assert var_1 == set_1
    # Test value of set_2
    set_2 = []
    var_2 = to_namedtuple(set_2)
    assert var_2 == set_2
    # Test value of set_3
    set_3 = OrderedDict()
    var_3 = to_namedtuple(set_3)
    assert var_3 == set_3
    # Test value of set_4

# Generated at 2022-06-25 17:30:44.703133
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_0 = to_namedtuple([{'a': 3}, {'c': 4}, {'b': 2}])
    assert isinstance(var_0, list)
    assert isinstance(var_0[0], NamedTuple)
    assert isinstance(var_0[1], NamedTuple)
    assert isinstance(var_0[2], NamedTuple)
    assert var_0[0].a == 3
    assert var_0[1].c == 4
    assert var_0[2].b == 2
    var_1 = to_namedtuple(((4, 5, 6), {'a': 1, 'b': 2}, {3: 4, 5: 6}))
    assert isinstance(var_1[0], tuple)
    assert isinstance(var_1[1], NamedTuple)