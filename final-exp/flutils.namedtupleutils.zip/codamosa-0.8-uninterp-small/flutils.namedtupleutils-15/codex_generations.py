

# Generated at 2022-06-25 17:20:58.527202
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the to_namedtuple function"""
    # var_0 == list
    var_0 = ['a']
    assert to_namedtuple(var_0) == ['a']
    # var_1 == list
    var_1 = ['a', {'b': 'c'}]
    assert to_namedtuple(var_1) == ['a', NamedTuple(b='c')]
    # var_2 == dict
    var_2 = {'a': 'b', 'c': {'d': 'e'}}
    assert to_namedtuple(var_2) == NamedTuple(a='b', c=NamedTuple(d='e'))
    # var_3 == dict
    var_3 = {'a': 'b', '_c': {'d': 'e'}}

# Generated at 2022-06-25 17:21:09.642748
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Case 0
    list_0 = [1, 'abc', {'a': 1}, (1, 2), [1, 2]]
    var_0 = to_namedtuple(list_0)
    # Case 1
    tup_1 = (1, 'abc', {'a': 1}, (1, 2), [1, 2])
    var_1 = to_namedtuple(tup_1)
    # Case 2
    dict_2 = {'a': 1, 'b': 'abc',
              'c': {'d': 1, 'e': 'abc'},
              'f': (1, 2),
              'g': [1, 2]}
    var_2 = to_namedtuple(dict_2)
    # Case 3
    from collections import OrderedDict

# Generated at 2022-06-25 17:21:21.682238
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test -1: to_namedtuple() with one parameter
    test_case_0()

    # Test 0: to_namedtuple() with one parameter
    d = {'first_name': 'John', 'last_name': 'Doe'}
    d_nt = to_namedtuple(d)
    assert isinstance(d_nt, namedtuple)
    assert d_nt.first_name == 'John'
    assert d_nt.last_name == 'Doe'

    # Test 1: to_namedtuple() with one parameter
    d = {'first_name': 'John', '_last_name': 'Doe'}
    d_nt = to_namedtuple(d)
    assert not hasattr(d_nt, '_last_name')

# Generated at 2022-06-25 17:21:31.865990
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from datetime import datetime
    from datetime import timedelta
    from functools import partial
    from pathlib import PurePath
    from uuid import UUID

    from flutils.namedtupleutils import _to_namedtuple

    now = datetime.now()
    today = datetime.today()


# Generated at 2022-06-25 17:21:34.333433
# Unit test for function to_namedtuple
def test_to_namedtuple():
    try:
        test_case_0()

    except Exception:
        print("Exception in test case 0")
        raise

# Run test cases
test_to_namedtuple()

# Generated at 2022-06-25 17:21:43.603373
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # test empty list
    list_0 = []
    var_0 = to_namedtuple(list_0)
    assert isinstance(var_0, list) and not var_0

    list_1 = [1]
    var_1 = to_namedtuple(list_1)
    assert isinstance(var_1, list) and var_1 and var_1[0] == 1

    dic_0 = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    var_2 = to_namedtuple(dic_0)
    assert isinstance(var_2, NamedTuple) and \
           var_2.a == 1 and var_2.b == 2 and var_2.c == 3


# Generated at 2022-06-25 17:21:55.468840
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from copy import deepcopy
    from flutils.namedtupleutils import to_namedtuple

    # Simple tests
    test_0 = {'a': 0, 'b': 1}
    var_0 = to_namedtuple(test_0)
    assert isinstance(var_0, namedtuple)
    assert var_0.a == 0
    assert var_0.b == 1

    test_1 = {'a': 0, 'b': [1, 2, 3]}
    var_1 = to_namedtuple(test_1)
    assert isinstance(var_1, namedtuple)
    assert var_1.a == 0
    assert var_1.b == [1, 2, 3]


# Generated at 2022-06-25 17:21:58.021126
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Sanity check for function to_namedtuple
    dic = {'a': 1, 'b': 2}
    var_0: NamedTuple = to_namedtuple(dic)
    assert var_0.a == 1
    assert var_0.b == 2


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:22:11.409542
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections.abc import Sequence
    from typing import NamedTuple
    from typing import Tuple
    from typing import Union
    from types import SimpleNamespace
    from pytest import raises
    import string
    from random import choice
    from flutils.miscutils import deepcopy
    from flutils.namedtupleutils import to_namedtuple
    letters = tuple(string.ascii_letters)
    all_ascii_letters = deepcopy(letters)
    all_letters = all_ascii_letters + tuple(string.digits) + ('_',)
    all_letters = tuple(sorted(all_letters))
    def _mk_rand_id(length: int) -> str:
        out = ''

# Generated at 2022-06-25 17:22:25.089040
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(SimpleNamespace()) == NamedTuple()
    assert to_namedtuple(SimpleNamespace(a=1)) == NamedTuple(a=1)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=SimpleNamespace(c=3))) == NamedTuple(a=1, b=NamedTuple(c=3))
    assert to_namedtuple(SimpleNamespace(a=1, b=SimpleNamespace(c=3, d=4))) == NamedTuple(a=1, b=NamedTuple(c=3, d=4))

    assert to_namedtuple({}) == NamedTuple()
    assert to_

# Generated at 2022-06-25 17:22:40.003726
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_of_dicts = [
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
        {'a': 5, 'b': 6},
    ]
    var_0 = to_namedtuple(list_of_dicts)
    assert [getattr(item, 'a') for item in var_0] == [1, 3, 5]
    assert [getattr(item, 'b') for item in var_0] == [2, 4, 6]
    assert isinstance(var_0, list) is True


# Generated at 2022-06-25 17:22:42.802088
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple

    Args:
        None

    Returns:
        None
    """
    test_case_0()


# Generated at 2022-06-25 17:22:53.234586
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case 0
    list_0 = list()
    var_0 = to_namedtuple(list_0)
    assert var_0 == list_0

    # Test case 1
    list_0 = list()
    list_0.append(1)
    list_0.append(2)
    list_0.append(3)
    var_0 = to_namedtuple(list_0)
    assert var_0 == list_0

    # Test case 2
    list_0 = list()
    list_0.append({'a': 1, 'b': 2, 'c': 3})
    list_0.append(None)
    list_0.append({'a': 4, 'b': 5, 'c': 6})
    var_0 = to_namedtuple(list_0)
    list_

# Generated at 2022-06-25 17:22:56.507146
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(
        [1, 2, 3]
    ) == [1, 2, 3]



# Generated at 2022-06-25 17:23:05.818159
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({1: 2}) == namedtuple('NamedTuple', ['1'])(2)
    assert to_namedtuple({'a': 1, 'b': 2}) == \
           namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple({'a': 1, 0: 2}) == \
           namedtuple('NamedTuple', ['a'])(1)
    assert to_namedtuple({'a': 1, 'b': {'c': 3}}) == \
           namedtuple('NamedTuple', ['a', 'b'])(1,
                                                namedtuple('NamedTuple',
                                                           ['c'])(3))
    assert to_namedtuple({'a': 1, 'b': [3]})

# Generated at 2022-06-25 17:23:19.514826
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Testing:
    # def to_namedtuple(
    #         obj: Union[List, Mapping, NamedTuple, SimpleNamespace]
    # ) -> Union[List[Any], NamedTuple, Tuple[Any], str]:

    # Setup:

    # Actual:
    actual_0 = to_namedtuple(dict())

    # Verify:
    pass
    # assert actual_0 == ['a'], 'Expected: {}'.format(actual_0)

    # Setup:

    # Actual:
    actual_1 = to_namedtuple(dict())

    # Verify:
    pass
    # assert actual_1 == ['a'], 'Expected: {}'.format(actual_1)

    # Setup:

    # Actual:
    actual_2 = to_namedtuple(dict())

    # Verify:


# Generated at 2022-06-25 17:23:28.824136
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.objutils import object_to_dict

    from_dict = object_to_dict(
        {
            'fname': 'a',
            'lname': 'b',
            'children': [
                {
                    'fname': 'c',
                    'lname': 'd',
                }
            ]
        }
    )
    nt = to_namedtuple(from_dict)

    expected = 'NamedTuple(children=[NamedTuple(fname=\'c\', lname=\'d\')], fname=\'a\', lname=\'b\')'
    assert str(nt) == expected
    assert nt.children[0].fname == 'c'

    first_child = {'fname': 'c', 'lname': 'd'}
    new_child

# Generated at 2022-06-25 17:23:35.177196
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test cases
    test_case_0()
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert isinstance(out, tuple)
    tup = ('a', 1, 2)
    out = to_namedtuple(tup)
    assert out == ('a', 1, 2)
    assert isinstance(out, tuple)
    dic = OrderedDict((('a', 1), ('b', 2)))
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert isinstance(out, tuple)
    dic = {'a': 1, 'b': {'c': 1}}
    out = to_

# Generated at 2022-06-25 17:23:47.528345
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Imports
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple

    # Set up test case
    dict_0 = dict(a=1, b=dict(c=2, d=dict(e='3')))
    dict_1 = OrderedDict(a=1, b=dict(c=2, d=dict(e='3')))

# Generated at 2022-06-25 17:23:59.443819
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Check a dictionary return a NamedTuple
    chk_result = to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(chk_result, NamedTuple)
    assert chk_result == (1, 2)
    assert chk_result.a == 1 and chk_result.b == 2

    # Check all keys (identifiers, or no underscores) return a NamedTuple
    chk_result = to_namedtuple({'a': 1, 'b': 2, 1: 3, '_c': 4})
    assert isinstance(chk_result, NamedTuple)
    assert chk_result == (1, 2)
    assert chk_result.a == 1 and chk_result.b == 2

    # Check a list return a list
    chk_result = to_

# Generated at 2022-06-25 17:24:13.479870
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2}
    assert to_namedtuple(dic_0) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic_1 = {'b': 2, 'a': 1}
    assert to_namedtuple(dic_0) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic_2 = {'b': 2, 'a': 1}
    assert to_namedtuple(dic_1) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic_3 = OrderedDict(b=2, a=1)

# Generated at 2022-06-25 17:24:25.457686
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert callable(to_namedtuple)
    for var_0 in range(0, 100, 10):
        args_0 = [True] * var_0
        var_1 = to_namedtuple(args_0)
        assert isinstance(var_1, list)
        var_2 = var_1.pop()
        assert var_2
        assert not var_1
        args_0 = [False] * var_0
        var_3 = to_namedtuple(args_0)
        assert isinstance(var_3, list)
        var_4 = var_3.pop()
        assert not var_4
        assert not var_3
        args_0 = OrderedDict()
        val_0 = 1
        args_0['a'] = val_0
        args_0['b'] = val

# Generated at 2022-06-25 17:24:40.074114
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [[[[[[[[[[[[]]]]]]]]], []], [[[[[[[[[]]]]]]]]]]]
    var_0 = to_namedtuple(list_0)
    dict_0 = {'a': 1, 'b': 2}
    var_1 = to_namedtuple(dict_0)
    dict_1 = {
        'a': {'b': {'c': {'d': {'e': 1}}}},
        'f': {'g': {'h': {'i': {'j': 2}}}}
    }
    var_2 = to_namedtuple(dict_1)
    dict_2 = {'a': 1, 'b': 2, 'c': {'d': {'e': 3}}, 'f': {'g': {'h': 4}}}
    var

# Generated at 2022-06-25 17:24:47.286687
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'ba': 3}) == namedtuple('NamedTuple', 'a b ba')(a=1, b=2, ba=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'ba': 3, 'c': {'ba': 3, 'c': 4}}) == \
        namedtuple('NamedTuple', 'a b ba c')(a=1, b=2, ba=3, c=namedtuple('NamedTuple', 'c ba')(c=4, ba=3))

# Generated at 2022-06-25 17:24:52.449081
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic).a == 1

    dic = [1, 2, 3]
    assert to_namedtuple(dic)[0] == 1

# Generated at 2022-06-25 17:25:02.270531
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {}
    dic_1 = {'a': 2, 'b': 4}
    dic_2 = {'a': {'c': 4, 'd': 8}, 'b': {'e': 16}}
    tup_0 = tuple([])
    tup_1 = (2, 4)
    tup_2 = ([4, 8], [16])
    lis_0 = list([])
    lis_1 = [2, 4]
    lis_2 = [[4, 8], [16]]
    nt_0 = namedtuple('NamedTuple', '')()
    nt_1 = namedtuple('Nt1', 'a b')(2, 4)

# Generated at 2022-06-25 17:25:08.934326
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [1, 2, 2, "3", {}, {'a': 1}, [], [1, 2], [1, 2, 3]]
    namedtuple_0 = to_namedtuple(list_0)
    namedtuple_1 = to_namedtuple(namedtuple_0)
    tuple_0 = namedtuple_0.a
    assert tuple_0 == namedtuple_1.a
    assert namedtuple_1.a == 1
    tuple_0 = namedtuple_0.b
    assert tuple_0 == namedtuple_1.b
    assert namedtuple_1.b == 2
    tuple_0 = namedtuple_0.a
    assert tuple_0 == namedtuple_1.a
    assert namedtuple_1.a == 1
    tuple_0 = named

# Generated at 2022-06-25 17:25:21.530361
# Unit test for function to_namedtuple

# Generated at 2022-06-25 17:25:28.252757
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = OrderedDict([('a', 1), ('b', 2)])
    exp_fields = OrderedDict([('a', 1), ('b', 2)])
    exp = namedtuple('NamedTuple', 'a b')(**exp_fields)
    out = to_namedtuple(obj)
    assert out == exp

    obj = {'a': 1, 'b': 2}
    exp_fields = OrderedDict([('a', 1), ('b', 2)])
    exp = namedtuple('NamedTuple', 'a b')(**exp_fields)
    out = to_namedtuple(obj)
    assert out == exp

    obj = [1, 2]
    exp = [1, 2]
    out = to_namedtuple(obj)
    assert out == exp

    obj

# Generated at 2022-06-25 17:25:39.719339
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    tuple_0 = to_namedtuple(dic)

    list_0 = [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]
    tuple_1 = to_namedtuple(list_0)

    tuple_2 = (1, 2, 3, 4)
    tuple_3 = to_namedtuple(tuple_2)

    tuple_4 = (1, 2, 3, 4)
    tuple_5 = to_namedtuple(tuple_4)

    list_2 = [1, 2, 3, 4]
    tuple_6 = to_namedtuple(list_2)

    list_3 = [1, 2, 3, 4]

# Generated at 2022-06-25 17:25:52.087282
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_0 = dict()
    dict_0['some_value'] = 20
    dict_0['some_key'] = 'Harry'
    output = to_namedtuple(dict_0)
    assert True

# Generated at 2022-06-25 17:25:59.289783
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the to_namedtuple function."""
    import flutils.namedtupleutils as ntu

    assert hasattr(ntu, 'to_namedtuple')

    obj = {
        'a': 1,
        'b': 2,
    }
    obj = ntu.to_namedtuple(obj)
    assert isinstance(obj, ntu.NamedTuple)
    assert obj.a == 1
    assert obj.b == 2

    obj = {
        'a': 1,
        'b': 2,
        '_d': 4,
    }
    obj = ntu.to_namedtuple(obj)
    assert isinstance(obj, ntu.NamedTuple)
    assert obj.a == 1
    assert obj.b == 2

# Generated at 2022-06-25 17:26:01.159345
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == tuple()

# Generated at 2022-06-25 17:26:09.190738
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # noinspection PyMissingOrEmptyDocstring
    class TestArgs(NamedTuple):
        a: int
        b: int

    # noinspection PyMissingOrEmptyDocstring
    class TestKwargs(NamedTuple):
        a: int
        b: int

    def test_case_0():
        utl_0 = to_namedtuple({'a': 1, 'b': 2})
        assert isinstance(utl_0, TestKwargs)

    test_case_0()

    def test_case_1():
        utl_0 = to_namedtuple({'b': 2, 'a': 1})
        assert isinstance(utl_0, TestKwargs)

    test_case_1()

    def test_case_2():
        utl_0 = to_namedt

# Generated at 2022-06-25 17:26:21.244987
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    var_0: Any = to_namedtuple(dic)
    assert hasattr(var_0, 'a')
    assert hasattr(var_0, 'b')
    assert var_0.a == 1
    assert var_0.b == 2

    dic = {1: 1, 'b': 2}
    var_0: Any = to_namedtuple(dic)
    assert hasattr(var_0, 'b')
    assert getattr(var_0, 'b') == 2
    assert not hasattr(var_0, 1)

    dic = {1: 1, '2': 2}
    var_0: Any = to_namedtuple(dic)
    assert hasattr(var_0, '2')

# Generated at 2022-06-25 17:26:27.622541
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = SimpleNamespace()
    obj.a = 1
    obj.b = 2
    obj.c = SimpleNamespace()
    obj.c.d = 2
    obj.c.e = 3
    obj.c.f = SimpleNamespace()
    obj.c.f.g = 3
    obj.c.f.h = 4
    obj.c.f.i = []
    obj.c.f.i.append(5)
    obj.c.f.i.append(6)
    obj.c.f.i.append(SimpleNamespace())
    obj.c.f.i.append(SimpleNamespace())
    obj.c.f.i.append(9)
    obj.c.f.i.append(8)
    obj.c.f.i.append(7)
    obj

# Generated at 2022-06-25 17:26:29.963492
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:26:37.555452
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace

    inp = [
        {'a': 1, 'b': 2},
        {'c': 3, 'd': 4},
    ]
    exp = [
        (1, 2),
        (3, 4),
    ]
    out = to_namedtuple(inp)
    assert out == exp
    out = to_namedtuple(inp[0]) == exp[0]
    assert out


# Generated at 2022-06-25 17:26:48.413731
# Unit test for function to_namedtuple
def test_to_namedtuple():
    var_0 = to_namedtuple([])
    assert isinstance(var_0, list)
    assert len(var_0) == 0

    var_1 = to_namedtuple(())
    assert isinstance(var_1, tuple)
    assert len(var_1) == 0

    var_2 = to_namedtuple({})
    assert isinstance(var_2, NamedTuple)
    assert len(var_2) == 0

    in_0 = {
        '_a': 1,
        'b': 2,
    }
    var_3 = to_namedtuple(in_0)
    assert isinstance(var_3, NamedTuple)
    assert len(var_3) == 1
    assert var_3.b == in_0['b']


# Generated at 2022-06-25 17:27:01.371575
# Unit test for function to_namedtuple
def test_to_namedtuple():

    input_var = {'a': 1, 'b': 2}
    expected = "NamedTuple(a=1, b=2)"
    output = to_namedtuple(input_var)
    assert(str(output) == expected)

    input_var = {'b': 2, 'a': 1}
    expected = "NamedTuple(a=1, b=2)"
    output = to_namedtuple(input_var)
    assert(str(output) == expected)

    input_var = {'  b': 2, 'a   ': 1}
    expected = "NamedTuple(a=1, b=2)"
    output = to_namedtuple(input_var)
    assert(str(output) == expected)


# Generated at 2022-06-25 17:27:25.120944
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # These are simple test cases.
    import doctest
    doctest.testmod()

    # This is a more advanced test case, but is incomplete.
    # The NamedTuple namedtupleutils.NamedTuple that is created
    # is not the NamedTuple that is in the object returned from
    # the to_namedtuple function.
    from flutils.namedtupleutils import NamedTuple
    dic = {
        'a': 1,
        'b': 2,
        'NamedTuple': NamedTuple(('a', 'b', 'c', 'd'), (1, 2, 3, 4)),
    }
    namedt = to_namedtuple(dic)
    assert isinstance(namedt, NamedTuple)
    assert isinstance(namedt.NamedTuple, NamedTuple)
   

# Generated at 2022-06-25 17:27:35.882948
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = dict(a=1, b=2)
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert len(nt) == len(dic)
    assert nt.a == dic['a']
    assert nt.b == dic['b']
    assert nt._asdict() == dict(a=1, b=2)
    #
    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert len(nt) == len(dic)
    assert nt.a == dic['a']
    assert nt.b == dic['b']

# Generated at 2022-06-25 17:27:45.921440
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import ast

    dic_0_1 = {'a': 1, 'b': 2}
    dic_0_2 = {}
    dic_1 = {'a': 1, 'b': 2}
    dic_2 = {}
    dic_3 = {'a': 1, 'b': 2}
    dic_4 = {'a': 1, 'b': 2}
    dic_5 = {'a': 1, 'b': 2}
    dic_6 = {'a': 1, 'b': 2}
    dic_7_0 = {'a': 1, 'b': 2}
    dic_7_1 = {'a': 1, 'b': 2}
    dic_7_2 = {'a': 1, 'b': 2}
    dic_8_0

# Generated at 2022-06-25 17:27:54.087594
# Unit test for function to_namedtuple
def test_to_namedtuple():
    list_0 = [{
        'a': 1,
        'b': 2,
        'c': 3
    }, {
        'a': 4,
        'b': 5,
        'c': 6
    }, {
        'a': 1,
        'b': 2,
        'c': 3
    }]
    tuple_0_0 = namedtuple('NamedTuple', 'c b a')
    tuple_0_1 = namedtuple('NamedTuple', 'c b a')
    tuple_0_2 = namedtuple('NamedTuple', 'c b a')
    var_0 = to_namedtuple(list_0)
    assert var_0[0] == tuple_0_0(3, 2, 1)

# Generated at 2022-06-25 17:28:05.619782
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the :obj:`to_namedtuple` function"""
    import unittest
    import sys
    if sys.version_info[:2] < (3, 7):
        unittest.skip("Can only test ordering in 3.7+")

    class TestToNamedTuple(unittest.TestCase):
        """Test the :obj:`to_namedtuple` function"""

        def test_empty_values(self):
            """Test empty values"""
            for obj in [
                (),
                [],
                dict(),
                OrderedDict(),
                SimpleNamespace(),
            ]:
                nt = to_namedtuple(obj)
                nt_keys = nt._fields
                self.assertEqual(nt_keys, ())

# Generated at 2022-06-25 17:28:16.938843
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _test_case_0():
        dict_0 = dict()
        var_0 = to_namedtuple(dict_0)

    def _test_case_1():
        dict_0 = dict(a='a')
        var_0 = to_namedtuple(dict_0)

    def _test_case_2():
        dict_0 = dict(a='a', b='b')
        var_0 = to_namedtuple(dict_0)

    def _test_case_3():
        dict_0 = dict(a=1, b=2, c=3)
        var_0 = to_namedtuple(dict_0)

    def _test_case_4():
        from collections import OrderedDict

# Generated at 2022-06-25 17:28:28.381775
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for to_namedtuple
    namedtuple_0 = to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))
    assert namedtuple_0.a == 1
    assert namedtuple_0.b == 2

    # Test for to_namedtuple
    namedtuple_1 = to_namedtuple(OrderedDict([('c', 3), ('b', 2), ('a', 1)]))
    assert namedtuple_1.a == 1
    assert namedtuple_1.b == 2
    assert namedtuple_1.c == 3

    # Test for to_namedtuple
    namedtuple_2 = to_namedtuple(OrderedDict([('c', 3), ('a', 4), ('b', 2)]))
    assert namedtuple_2.a

# Generated at 2022-06-25 17:28:37.610621
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 0, 'b': 1}  # type: Dict[str, int]
    dic_1 = {'b': 1, 'a': 0}  # type: Dict[str, int]

    # Test if function to_namedtuple will convert a dictionary to a named
    # tuple when keys are sorted
    namedtuple_0 = to_namedtuple(dic_0)
    # Test if function to_namedtuple will return a named tuple
    assert isinstance(namedtuple_0, NamedTuple)
    # Test if function to_namedtuple will return a named tuple with two
    # keys, 'a' and 'b'
    assert namedtuple_0._fields == ('a', 'b')
    # Test if function to_namedtuple will return a named tuple with two

# Generated at 2022-06-25 17:28:40.080504
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()


if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-25 17:28:45.788485
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import os
    import sys
    import unittest

    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    test_case_0()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:29:15.294119
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_case_0()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-25 17:29:26.345694
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_0 = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2}, 'd': 8, 'e': ('a', 1), 'f': ['a', 1]}
    tup_0 = (1, 2, 3, 4, 5)
    lst_0 = ['a', 1, dic_0, tup_0]
    ns_0 = SimpleNamespace(a=1, b=2)
    ns_0.c = ns_0
    od_0 = OrderedDict()
    od_0['a'] = 1
    od_0['b'] = 2
    od_0['c'] = ns_0
    od_0['d'] = ('a', 1)
    od_0['e'] = dic_0
    od_0['f']

# Generated at 2022-06-25 17:29:33.643675
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''
    Ensure that the function to_namedtuple works as expected
    '''

    a = {'a': 1, 'b': 2}
    c = to_namedtuple(a)
    assert c.a == 1
    assert c.b == 2

    b = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    c = to_namedtuple(b)
    assert c.a == 1
    assert c.b == 2
    assert c.c.d == 3
    assert c.c.e == 4

    a = [1]
    b = ('1', 2)
    c = {'a': a, 'b': b}
    d = to_namedtuple(c)
    assert d.a == a

# Generated at 2022-06-25 17:29:40.177318
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple.__name__ == 'to_namedtuple'
    assert isinstance(to_namedtuple, type(test_to_namedtuple))
    assert isinstance(test_to_namedtuple, type(test_to_namedtuple))

# Generated at 2022-06-25 17:29:49.966491
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple

    Args:
        None
    """
    def test_dict():
        """Test function `to_namedtuple` with a dictionary.

        Args:
            None
        """
        dic_0: Mapping = OrderedDict([('a', 1), ('b', 2)])
        var_0: NamedTuple = to_namedtuple(dic_0)
        assert var_0.a == 1
        assert var_0.b == 2
    test_dict()

    def test_empty_dict():
        """Test function `to_namedtuple` with an empty dictionary.

        Args:
            None
        """
        dic_0: Mapping = OrderedDict()

# Generated at 2022-06-25 17:29:58.169854
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic_0 = {'a': 1, 'b': 2}
    obj_0 = to_namedtuple(dic_0)
    assert len(obj_0) == 2
    assert obj_0.a == 1
    assert obj_0.b == 2
    dic_1 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    obj_1 = to_namedtuple(dic_1)
    assert len(obj_1) == 4
    assert obj_1.a == 1
    assert obj_1.b == 2
    assert obj_1.c == 3
    assert obj_1.d == 4
    dic_2 = {'a': 1, 'b': 2}
    obj_2 = to_namedtuple(dic_2)

# Generated at 2022-06-25 17:30:09.650999
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case 0:
    list_0 = []
    var_0 = to_namedtuple(list_0)

    # Test case 1:
    list_1 = [1, 2, 3]
    var_1 = to_namedtuple(list_1)

    # Test case 2:
    dict_0 = {'a': 1, 'b': 2}
    var_2 = to_namedtuple(dict_0)

    # Test case 3:
    dict_1 = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': 5}
    var_3 = to_namedtuple(dict_1)

    # Test case 4:

# Generated at 2022-06-25 17:30:16.785682
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Scenario 1: Convert to tuple
    # Expected: Type tuple
    dict_0 = {'a': 1, 'b': 2}
    var_0 = to_namedtuple(dict_0)
    assert isinstance(var_0, tuple)

    # Scenario 2: Convert to namedtuple
    # Expected: Type tuple
    dict_1 = {'a': 1, 'b': 2, 'c': 3}
    var_1 = to_namedtuple(dict_1)
    assert isinstance(var_1, tuple)

    # Scenario 3: Convert to namedtuple
    # Expected: Type list
    list_0 = []
    var_2 = to_namedtuple(list_0)
    assert isinstance(var_2, list)

    # Scenario 4: Convert to namedtuple

# Generated at 2022-06-25 17:30:26.623391
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    lst = [1, 2, 3]
    tup = (1, 2, 3)

    var_0: NamedTuple = to_namedtuple(dic)
    var_1: List[Any] = to_namedtuple(lst)
    var_2: Tuple[Any, ...] = to_namedtuple(tup)
    var_3: Tuple[Any, ...] = to_namedtuple(var_2)
    var_4: NamedTuple = to_namedtuple(var_0)

    assert var_0.a == 1
    assert var_0.b == 2
    assert var_1 == [1, 2, 3]
    assert var_2 == (1, 2, 3)
    assert var_3

# Generated at 2022-06-25 17:30:34.457331
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    def _helper_0(
            obj: List[str],
            exception: bool = False,
            expected: List[str] = None
    ) -> None:
        if exception:
            with pytest.raises(TypeError):
                to_namedtuple(obj)
        else:
            if isinstance(expected, list):
                assert tuple(to_namedtuple(obj)) == tuple(expected)
            else:
                assert to_namedtuple(obj) == expected

    def _helper_1(
            obj: Union[NamedTuple, List],
            expected: Union[NamedTuple, List]
    ) -> None:
        obj = to_namedtuple(obj)
        expected = to_namedtuple(expected)
        assert obj == expected

   