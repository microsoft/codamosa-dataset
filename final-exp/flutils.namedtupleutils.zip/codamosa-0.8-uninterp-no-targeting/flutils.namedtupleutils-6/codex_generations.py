

# Generated at 2022-06-21 12:45:09.302141
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj_dict = {'a': 1, 'b': 2}
    obj_list = [1, 2, 3]
    obj_tuple = (1, 2, 3)
    obj_ordered_dict = OrderedDict(a=1, b=2)
    obj_simple_namespace = SimpleNamespace(a=1, b=2)
    obj_namedtuple = namedtuple('A', 'a b')(1, 2)
    
    assert to_namedtuple(obj_dict) == obj_namedtuple
    assert to_namedtuple(obj_list) == obj_tuple
    assert to_namedtuple(obj_tuple) == obj_tuple
    assert to_namedtuple(obj_ordered_dict) == obj_namedtuple

# Generated at 2022-06-21 12:45:19.477884
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple({'a': 1, 'b': {'x': 3, 'y': 4}}) == namedtuple('NamedTuple', ['a', 'b'])(1, namedtuple('NamedTuple', ['x', 'y'])(3, 4))
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)

# Generated at 2022-06-21 12:45:30.489571
# Unit test for function to_namedtuple
def test_to_namedtuple():
    if __name__ == "__main__":
        print('\nUNIT TEST - to_namedtuple\n')
        # Test 1
        expected = NamedTuple(a=1, b=2)
        actual = to_namedtuple({'a': 1, 'b': 2})
        print(f"Test 1: Expected = {expected}")
        print(f"Test 1: Actual   = {actual}\n")
        assert expected == actual

        # Test 2
        expected = [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]
        actual = to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}])
        print(f"Test 2: Expected = {expected}")

# Generated at 2022-06-21 12:45:37.365069
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from tests.namedtupleutils import to_namedtuple as _to_namedtuple
    assert _to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert _to_namedtuple({'a': 1, 'b': {'c': 3, 'd': 4}, 'e': 5}) == \
        namedtuple('NamedTuple', 'a b e')(a=1, b=namedtuple('NamedTuple', 'c d')(c=3, d=4), e=5)
    assert _to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert _to_namedtuple((1, 2, 3)) == (1, 2, 3)
   

# Generated at 2022-06-21 12:45:46.795980
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    TestStruct = namedtuple('TestStruct', 'a, b')
    TestStruct2 = namedtuple('TestStruct2', 'c, d')
    TestStruct3 = namedtuple('TestStruct3', 'e, f')
    TestStruct4 = namedtuple('TestStruct4', 'g, h, i')
    TestStruct5 = namedtuple('TestStruct5', 'j, k, l')
    inp = {'a':1, 'b':[{'c':2, 'd': 3}, {'e': 4, 'f': 5}],
           'g':[{'h':6, 'i': 7}, {'j': 8, 'k': 9}], 'l':TestStruct5(10, 11, 12)}
    outp = to_namedtuple(inp)
   

# Generated at 2022-06-21 12:45:55.948618
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1 and obj.b == 2
    od = OrderedDict([('a', 1), ('b', 2)])
    obj = to_namedtuple(od)
    assert obj.a == 1 and obj.b == 2
    ns = SimpleNamespace(a=1, b=2)
    obj = to_namedtuple(ns)
    assert obj.a == 1 and obj.b == 2
    tpl = (1, 2)
    obj = to_namedtuple(tpl)
    assert obj == (1, 2)
    lst = [1, 2]
    obj = to_namedtuple(lst)
    assert obj == [1, 2]
    d

# Generated at 2022-06-21 12:46:06.277967
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print(f'\nTesting function to_namedtuple ...')
    from collections import defaultdict
    from collections.abc import Iterable
    from functools import reduce

    from flutils.namedtupleutils import merge_namedtuples
    from flutils.validators import validate_namedtuple
    from flutils.structutils import inherit_namedtuples
    from flutils.structutils import merge_dicts

    nt1 = namedtuple('nt1', ('a', 'b', 'c'))(1, 2, 3)
    nt2 = namedtuple('nt2', ('d', 'e', 'f'))(4, 5, 6)
    nt3 = namedtuple('nt3', ('g', 'h', 'i'))(7, 8, 9)
    nt_merged = merge_namedtu

# Generated at 2022-06-21 12:46:18.729288
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple as tnt
    from collections import (
        deque,
        defaultdict,
        ordereddict,
    )
    dic = {'a': 1, 'b': 2}  # type: dict
    assert tnt(dic) == dic
    od = ordereddict((('a', 1), ('b', 2)))
    assert tnt(od) == od
    dd = defaultdict(set)
    dd['a'].add('b')
    assert tnt(dd) == dd
    dq = deque([1, 2, 3])
    assert list(tnt(dq)) == dq
    tpl = (1, 2, 3)
    assert tnt(tpl) == tpl
    lst = [1, 2, 3]
    assert t

# Generated at 2022-06-21 12:46:31.437099
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Mapping
    from functools import singledispatch
    from types import SimpleNamespace
    from typing import Any, List, NamedTuple, Tuple, Union
    from flutils.validators import validate_identifier

    dic1 = {'a': 1, 'b': 2}
    dic2 = {'a': 1, 'b': 2}
    assert to_namedtuple(dic1) == to_namedtuple(dic2)

    dic1 = OrderedDict([('a', 1), ('b', 2)])
    dic2 = OrderedDict([('b', 2), ('a', 1)])
    assert to_namedtuple(dic1) == to_

# Generated at 2022-06-21 12:46:44.482379
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from flutils.namedtupleutils import to_namedtuple

    class TestCase(unittest.TestCase):
        def test_mapping(self):
            dic = {'a': 1, 'b': 2}
            res = to_namedtuple(dic)
            self.assertEqual(res, ('a', 'b'))

        def test_mapping_nonidentifier(self):
            dic = {'a.b': 1, 'c': 2, 'd.four': 3}
            res = to_namedtuple(dic)
            self.assertEqual(res, ('c',))

        def test_mapping_underscore(self):
            dic = {'_a': 1, 'c': 2, 'd_four': 3}
            res = to_

# Generated at 2022-06-21 12:46:58.386333
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic= {'a': 1, 'b': 2}
    namedtupleobj=to_namedtuple(dic)
    keys=[]
    for key in dic.keys():
        if hasattr(key, 'capitalize'):
            key = cast(str, key)
            if key.isidentifier():
                keys.append(key)
    fields=tuple(sorted(keys))

    # noinspection Mypy
    make = namedtuple('NamedTuple', fields)  # type: ignore[misc]
    # noinspection PyTypeChecker,PyArgumentList
    NamedTupleobj = make(1,2)
    assert namedtupleobj==NamedTupleobj,"NamedTuple not created"

    ordered=OrderedDict({'a': 1, 'b': 2})
   

# Generated at 2022-06-21 12:47:09.015820
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Test function to_namedtuple.

    Args:
        None
    Returns:
        None
    '''

    dic = {'a': 1, 'b': 2}
    try:
        assert to_namedtuple(dic)
    except Exception as e:
        print(e)

    try:
        assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    except Exception as e:
        print(e)

    try:
        assert to_namedtuple(dic).a == 1
    except Exception as e:
        print(e)

    try:
        assert to_namedtuple(dic).b == 2
    except Exception as e:
        print(e)

    dic = {'c': 3, '2': 4}
   

# Generated at 2022-06-21 12:47:21.772910
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = OrderedDict((('a', 1), ('b', 2)))
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)


# Generated at 2022-06-21 12:47:31.996679
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple(3) == 3
    assert to_namedtuple('foo') == 'foo'
    assert to_namedtuple(['foo']) == ['foo']
    assert to_namedtuple(('foo',)) == ('foo',)
    assert to_namedtuple(['bar', 'baz']) == ['bar', 'baz']
    assert to_namedtuple(['bar', 'baz']) == ['bar', 'baz']

    assert to_namedtuple({'foo': 'bar'}) == to_namedtuple('{foo: bar}')
    assert to_namedtuple({'foo': 'bar', 'baz': 'qux'}) == \
           to_namedtuple('{foo: bar, baz: qux}')

# Generated at 2022-06-21 12:47:41.819625
# Unit test for function to_namedtuple
def test_to_namedtuple(): 
    print('Unit test for to_namedtuple')
    print('Testing with tuple of tuples')
    objs = (((1, 2),),((3, 4),))
    out = to_namedtuple(objs)
    print('Input:', objs)
    print('Output:', out)
    print('Testing conversion of dictionary to NamedTuple')
    objs = {'a': 1, 'b': 2}
    out = to_namedtuple(objs)
    print('Input:', objs)
    print('Output:', out)
    print('Testing conversion of OrderedDict to NamedTuple')
    from collections import OrderedDict
    names = {'a': 1, 'b': 2}
    objs = OrderedDict(names)

# Generated at 2022-06-21 12:47:44.361767
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=True)

if __name__ == "__main__":
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 12:47:51.282485
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    tup = (3, 4)
    lst = [5, 6]
    assert isinstance(to_namedtuple(dic), namedtuple)
    assert isinstance(to_namedtuple(tup), tuple)
    assert isinstance(to_namedtuple(lst), list)
    assert to_namedtuple(tup) == (3, 4)
    assert to_namedtuple(lst) == [5, 6]
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ['a', 'b'])(1,2)

# Generated at 2022-06-21 12:48:01.841383
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class Test:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                self.__dict__[key] = value


    from collections import OrderedDict
    from datetime import datetime

    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple(None) is None

    dic = {'a': 1, 'c': 3, 'b': 2}
    x = to_namedtuple(dic)
    assert x._fields == ('a', 'b', 'c') and x.a == 1 and x.b == 2 and x.c == 3
    assert hash(x) == hash(('a', 'b', 'c'))


# Generated at 2022-06-21 12:48:12.575831
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for function to_namedtuple"""
    from datetime import date, datetime, time
    from decimal import Decimal
    from enum import Enum
    from uuid import UUID
    from fractions import Fraction, gcd

    import pytest


    for bad_type in (None, 1, True, Enum, date, datetime, time, Decimal, UUID):
        with pytest.raises(TypeError):
            to_namedtuple(bad_type)


    for good_type in (1, 'a', [1, 2, 3], (4, 5, 6), (1, 'a', [1, 2, 3])):
        out = to_namedtuple(good_type)
        assert out == good_type



# Generated at 2022-06-21 12:48:20.425412
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from pprint import pformat
    from flutils.namedtupleutils import to_namedtuple

    class ClassA(object):

        a: int

        def __init__(self, a: int):
            self.a = a

        def __repr__(self) -> str:
            return 'ClassA(%r)' % self.a


    c = ClassA(1)
    d = ClassA(2)

    od = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    adic = {'b': 2, 'a': 1, 'c': 3}
    dic = {'a': 1, 'b': 2}
    dic2 = {'a': 1, 'b': 2, 'c': od}

# Generated at 2022-06-21 12:48:34.712621
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple([{}]) == [namedtuple('NamedTuple', '')()]
    assert to_namedtuple([{}, {}]) == [namedtuple('NamedTuple', '')(), namedtuple('NamedTuple', '')()]

    my_dict = {'a': 1, 'b': 2, 'D': {'c': 3, 'd': 4}}
    result = to_namedtuple(my_dict)

# Generated at 2022-06-21 12:48:46.135765
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lst = [1, 2, 3, 4, 5]
    lst_res = to_namedtuple(lst)
    assert isinstance(lst_res, list)
    assert lst == lst_res
    tup = (7, 8, 9)
    tup_res = to_namedtuple(tup)
    assert isinstance(tup_res, tuple)
    assert tup == tup_res
    small_dic = {'a': 1, 'b': 2}
    small_dic_res = to_namedtuple(small_dic)
    assert isinstance(small_dic_res, NamedTuple)
    assert len(small_dic_res) == 2
    assert small_dic_res.a == 1

# Generated at 2022-06-21 12:48:55.796567
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {1: 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(b=2)
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

# Generated at 2022-06-21 12:49:05.341722
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    import unittest


# Generated at 2022-06-21 12:49:17.191589
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    import sys

    items = [
        (1,),
        (1, 2, 3),
        [1, 2, 3],
        {'a': 1, 'b': 2, 'c': 3},
        OrderedDict((('a', 1), ('b', 2), ('c', 3))),
        {'a': {'a0': 1, 'b0': 2, 'c0': 3}, 'b': {'a1': 1, 'b1': 2, 'c1': 3}},
    ]

# Generated at 2022-06-21 12:49:27.937136
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup
    lst = [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}, {'a': 1, 'b': 2}]

# Generated at 2022-06-21 12:49:40.805793
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import MagicMock
    from unittest import TestCase

    class Case(TestCase):
        def setUp(self):
            self.mock_validate = MagicMock()
            self.to_namedtuple = to_namedtuple
            self.to_namedtuple_backup = to_namedtuple.__globals__['_to_namedtuple']

        def tearDown(self):
            to_namedtuple.__globals__['_to_namedtuple'] = self.to_namedtuple_backup

        def test_to_namedtuple(self):
            obj = to_namedtuple({'a': 1, 'b': 2})

# Generated at 2022-06-21 12:49:47.453111
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest
    # Dictionary
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)
    # NamedTuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)
    # Tuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)
    # SimpleNamespace
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)
    # List
    dic = {'a': 1, 'b': 2}
   

# Generated at 2022-06-21 12:49:55.360525
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert len(nt) == 2
    assert nt.a == 1
    assert nt.b == 2


if __name__ == '__main__':
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    print(nt)

# Generated at 2022-06-21 12:50:04.934151
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # isinstance(Any, Union[List, Tuple, NamedTuple, Mapping, SimpleNamespace]) is True
    # noinspection PyTypeChecker
    assert isinstance(to_namedtuple(None), type(None))

    # isinstance(str, Union[List, Tuple, NamedTuple, Mapping, SimpleNamespace]) is False
    # noinspection PyTypeChecker
    assert not isinstance(to_namedtuple(''), type(None))

    lyt = to_namedtuple(None)
    # noinspection PyTypeChecker
    assert isinstance(lyt, type(None))
    assert lyt is None

    lyt = to_namedtuple('')
    # noinspection PyTypeChecker
    assert isinstance(lyt, str)
    assert lyt == ''

    l

# Generated at 2022-06-21 12:50:25.761859
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1 and out.b == 2
    odict = OrderedDict(dic)
    odict['c'] = 3
    out = to_namedtuple(odict)
    out_dict = {k: getattr(out, k) for k in odict}
    assert out_dict == odict
    assert out.a == 1 and out.b == 2 and out.c == 3
    simp = SimpleNamespace(a=1, b=2, c=3)
    out = to_namedtuple(simp)
    out_convert = {}

# Generated at 2022-06-21 12:50:34.822788
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from typing import (
        NamedTuple,
        Tuple,
    )

    class NamedMapping(NamedTuple):
        a: int
        b: Tuple[NamedMapping]

    o = [
        {
            'a': 1,
            'b': 2,
        },
        {
            'c': {'d': 3},
            'e': 4,
        },
    ]
    onamed: List[NamedMapping] = to_namedtuple(o)
    assert onamed[1].c.d == 3

# Generated at 2022-06-21 12:50:46.890620
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )

    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': 5}
    exp = OrderedDict([('a', 1), ('b', OrderedDict([('c', 3), ('d', 4)])), ('e', 5)])
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple)

    expected = exp['b']['d']
    actual = out.b.d
    assert expected == actual

    expected = exp['a']
    actual = out.a
    assert expected == actual

    expected = exp['e']
    actual = out.e
    assert expected == actual


# Generated at 2022-06-21 12:50:55.148036
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from types import SimpleNamespace
    from collections import OrderedDict
    from collections import namedtuple
    from flutils.testutils import (
        obj_test_args,
        obj_test_kwargs,
        ObjTestDef,
        obj_test_falsey_args,
        obj_test_falsey_kwargs,
        obj_test_falsey_type,
    )

    make_list = lambda: obj_test_args
    make_tuple = lambda: tuple(obj_test_args)
    make_dict = lambda: obj_test_kwargs
    make_ordered_dict = lambda: OrderedDict(obj_test_kwargs)
    make_simple_namespace = lambda: SimpleNamespace(**obj_test_kwargs)
    make_falsey_dict = lambda: obj_test_false

# Generated at 2022-06-21 12:51:07.436039
# Unit test for function to_namedtuple
def test_to_namedtuple():

    class NamedTupleInherit(NamedTuple):
        pass

    d = {'foo': 1, 'bar': 2}
    o = OrderedDict(d)
    l = [d, o]
    t = tuple(l)
    s = SimpleNamespace(**d)
    n = NamedTuple('NamedTuple', d.keys())(**d)
    ni = NamedTupleInherit('NamedTupleInherit', d.keys())(**d)


# Generated at 2022-06-21 12:51:17.433126
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) ==  NamedTuple(a=1, b=2)
    assert to_namedtuple([dic, dic]) == [NamedTuple(a=1, b=2), NamedTuple(a=1, b=2)]

    dic = {'a': 1, 'b': 2, 'c': dic}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(NamedTuple(**dic)) == NamedTuple

# Generated at 2022-06-21 12:51:20.024164
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    data = to_namedtuple(dic)
    assert repr(data) == "NamedTuple(a=1, b=2)"

# Generated at 2022-06-21 12:51:32.140359
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from operator import itemgetter
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.collectionsutils import (
        flatten_list,
        flatten_dict,
    )
    from flutils.pyutils import (
        sort_list,
        sort_dict,
    )

    # _to_namedtuple() function
    try:
        to_namedtuple(1)
    except TypeError:
        pass
    else:
        raise Exception('to_namedtuple(1) did not raise TypeError')
    try:
        to_namedtuple('1')
    except TypeError:
        pass

# Generated at 2022-06-21 12:51:40.047779
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import main, TestCase

    class _TestCase(TestCase):
        def test__to_namedtuple(self):
            from flutils.namedtupleutils import to_namedtuple
            T = to_namedtuple  # shorthand

            self.assertRaises(
                TypeError,
                T,
                'abc'
            )

            self.assertEqual(
                T({}),
                namedtuple('NamedTuple', '')()
            )

            self.assertEqual(
                T({'a': 1, 'b': 2, 'c': 3}),
                namedtuple('NamedTuple', ('a', 'b', 'c'))(1, 2, 3)
            )


# Generated at 2022-06-21 12:51:41.754046
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-21 12:52:19.399925
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    with open("namedtupleutils.py", "r") as f:
        code = f.read()
    lines = code.split("\n")
    lines = [line for line in lines if line.strip() != ""]
    for line_num, line in enumerate(lines):
        for col_num, char in enumerate(line):
            try:
                char == "'"
            except ValueError:
                print(line_num, col_num, char)
    assert False



# Generated at 2022-06-21 12:52:28.446423
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    dic: dict = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic['c'] = {'d': 3, 'e': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=NamedTuple(d=3, e=4))
    def func():
        pass
    dic['f'] = func
    assert to_namedtuple(dic) == NamedTuple(
        a=1, b=2, c=NamedTuple(d=3, e=4), f=func
    )

# Generated at 2022-06-21 12:52:39.145998
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic['c'] = {'d': 'e'}
    assert to_namedtuple(dic) == \
        namedtuple('NamedTuple', 'a b c')(a=1, b=2, c={'d': 'e'})

    dic['c'] = {'d': 'e', 'f': {'g': 'h'}}
    assert to_namedtuple(dic) == \
        namedtuple('NamedTuple', 'a b c')(a=1, b=2, c={'d': 'e', 'f': {'g': 'h'}})

# Generated at 2022-06-21 12:52:49.356030
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # noinspection DuplicatedCode
    @to_namedtuple
    class TestCase(NamedTuple):
        first: int
        second: int

    test: TestCase = TestCase(1, 2)
    assert test.first == 1
    assert test.second == 2
    assert test == (1, 2)

    # noinspection DuplicatedCode
    @to_namedtuple
    class TestCase(NamedTuple):
        first: int
        second: str

    test: TestCase = TestCase(1, 2)
    assert test.first == 1
    assert test.second == '2'
    assert test == (1, '2')


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:53:00.373976
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import OrderedDict
    from unittest import TestCase
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import NamesTest, NamesTest2

    class TestToNamedtuple(TestCase):

        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertEqual(tuple(out), (1, 2))

        def test_to_namedtuple_ordered_dict(self):
            ordered_dic = OrderedDict()
            ordered_dic['b'] = 2
            ordered_dic['a'] = 1
            out = to_namedtuple(ordered_dic)

# Generated at 2022-06-21 12:53:11.123909
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict({'a': 1, 'b': 2})) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)

    lst = [1, 2, 3]
    lst2 = [1, 2, 3]
    assert to_namedtuple(lst) == lst2
    assert to_namedtuple(lst) == lst2

    assert to_namedtuple('abc') == 'abc'
    assert to_namedt

# Generated at 2022-06-21 12:53:21.662383
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', ('b', 'c')]) == ['a', ('b', 'c')]
    assert to_namedtuple(['a', ('b', 'c')])[0] == 'a'
    assert to_namedtuple(['a', ('b', 'c')])[1] == ('b', 'c')
    assert to_namedtuple(['a', ('b', 'c')])[1][0] == 'b'
    assert to_namedtuple(['a', ('b', 'c')])[1][1] == 'c'

    assert to_namedtuple(('a', ('b', 'c'), 'd')) == ('a', ('b', 'c'), 'd')

# Generated at 2022-06-21 12:53:29.234323
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    def test_obj(obj: Any) -> None:
        to_namedtuple(obj)
        return

    from numbers import (
        Integral,
        Real,
    )
    from types import (
        FunctionType,
        GeneratorType,
        LambdaType,
        MappingProxyType,
        ModuleType,
    )

    test_obj(None)
    test_obj(True)
    test_obj(False)
    test_obj(10)
    test_obj(10.1)
    test_obj('a')
    # noinspection PyProtectedMember
    test_obj(Integral)
    # noinspection PyProtectedMember
    test_obj(Real)
    # noinspection PyProtectedMember
    test_obj(FunctionType)
   

# Generated at 2022-06-21 12:53:35.873653
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dictionary = {
        "ab": [
            {
                "ba": 1
            }
        ],
        "cd": {
            "dc": 2
        },
        "ef": [
            {
                "fe": 3
            },
            {
                "ef": 4
            }
        ]
    }
    out = to_namedtuple(dictionary)
    assert out.ef[0].fe == 3
    assert out.ab[0].ba == 1
    assert out.ef[1].ef == 4
    assert out.cd.dc == 2


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:53:47.692024
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.collectionsutils import to_list
    from flutils.namedtupleutils import to_list

    # noinspection PyUnusedLocal
    def _func(*args, **kwargs):
        pass


# Generated at 2022-06-21 12:54:21.372489
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    try:
        to_namedtuple({})
    except TypeError:
        raise
    else:
        pass



# Generated at 2022-06-21 12:54:31.375976
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple as nt

    Test = nt('Test', 'i j k')
    test = Test(1, 2, 3)

    nt_test = to_namedtuple(test._asdict())

    assert type(test) == type(nt_test)
    assert test.i == nt_test.i

    assert to_namedtuple({'j': 2, 'k': 3, 'i': 1}) == Test(1, 2, 3)
    assert to_namedtuple({'j': 2, 'k': 3, 'i': 1}) == Test(1, 2, 3)
    assert to_namedtuple({'i': 0}) == Test(i=0, j=None, k=None)

# Generated at 2022-06-21 12:54:41.303539
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    import os
    import sys

    from flutils.pathutils import ff_parent

    from flutils.testing import TestHelper
    from flutils.version import Version

    if not TestHelper.use_namedtupleutils:
        return
    th = TestHelper(script=__file__, quiet=True)
    th.addlibpath(ff_parent(__file__))
    th.importlib('flutils.jsonutils', 'jsonutils')
    th.importlib('flutils.namedtupleutils', 'namedtupleutils')
    th.importlib('flutils.pathutils', 'pathutils')
    th.importlib('flutils.version', 'version')

    VERBOSE: int = TestHelper.VERBOSE
    TESTNAME = TestHelper.TESTNAME

# Generated at 2022-06-21 12:54:52.689939
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyTypeChecker
    dic = OrderedDict(
        (
            ('a', 1),
            ('b', 2),
            ('c', 3),
        )
    )
    # noinspection PyTypeChecker
    got: NamedTuple = to_namedtuple(dic)
    exp = (1, 2, 3)
    assert got == exp, '%s != %s' % (got, exp)
    # noinspection PyTypeChecker
    got: List[NamedTuple] = to_namedtuple([dic, dic])
    exp = [exp, exp]
    assert got == exp, '%s != %s' % (got, exp)
    # noinspection PyTypeChecker
    got: Tuple[NamedTuple, ...] = to_namedt

# Generated at 2022-06-21 12:54:59.328524
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple([]) == []
    assert to_namedtuple([{'a': 1}]) == [NamedTuple(a=1)]
    assert to_namedtuple(([{'a': 1}],)) == (NamedTuple(a=1),)
    assert to_namedtuple(({'a': 1},)) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': {'b': 1}}) == NamedTuple(a=NamedTuple(b=1))
    assert to_namedtuple({'a': {'b': {'c': 1, 'd': 2}}}) == \
           Named