

# Generated at 2022-06-21 12:45:17.092313
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    dic2 = {'c': 3, 'd': 4}
    dic3 = {'e': 5, 'f': 6}
    dic4 = {'g': 7, 'h': 8}
    dic5 = {'i': 9, 'j': 10}
    lst = [obj, dic2, dic3, dic4, dic5]
    obj2 = to_namedtuple(lst)
    tup = tuple(obj2)
    obj3 = to_namedtuple(tup)

    assert hasattr(obj3, 'a')
    assert hasattr(obj3, 'b')
    assert hasattr(obj3, 'c')
    assert hasattr

# Generated at 2022-06-21 12:45:28.245315
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace
    from pprint import pprint

    dic = {'a': 1, 'b': 2}
    nt1 = to_namedtuple(dic)
    assert isinstance(nt1, namedtuple)
    assert hasattr(nt1, 'a')
    assert hasattr(nt1, 'b')
    assert nt1 == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    odic = OrderedDict(a=1, b=2)
    nt2 = to_namedtuple(odic)
    assert isinstance(nt2, namedtuple)
    assert hasattr(nt2, 'a')

# Generated at 2022-06-21 12:45:39.263247
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    import pytest

    def validate_type(tuple_type):
        assert isinstance(tuple_type, NamedTuple)
        assert tuple_type.a == 1
        assert tuple_type.b == 2
        assert tuple_type.c == 3

    def validate_type_ordereddict(tuple_type):
        assert isinstance(tuple_type, NamedTuple)
        assert tuple_type.a == 1
        assert tuple_type.b == 2
        assert tuple_type.c == 3

    def validate_type_dict(tuple_type):
        assert isinstance(tuple_type, NamedTuple)
        assert tuple_type.a == 1
        assert tuple_type.b == 2
        assert tuple_type.c == 3

   

# Generated at 2022-06-21 12:45:52.081027
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:46:04.129471
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # empty
    dct = {}
    nt = to_namedtuple(dct)
    assert nt == namedtuple('NamedTuple', '')()
    assert type(nt) == namedtuple('NamedTuple', '')
    assert nt == {}
    assert {} == nt
    print(nt)

    # simple
    dct = {'a': 1,
           'b': 2,
           'c': 3}
    nt = to_namedtuple(dct)
    assert nt == namedtuple('NamedTuple', 'a b c')(1, 2, 3)
    assert type(nt) == namedtuple('NamedTuple', 'a b c')
    assert nt == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-21 12:46:16.995113
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Test the to_namedtuple function.
    '''
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict as odict  # type: ignore[no-redef]
    from types import SimpleNamespace as namespace  # type: ignore[no-redef]
    from collections import namedtuple
    SimpleNamedTuple = namedtuple('SimpleNamedTuple', ['foo', 'bar', 'baz'])

    test_list = [
        [1, 2, 3],
        [2, 3, 4],
        [3, 4, 5],
    ]
    test_list_result = to_namedtuple(test_list)
    assert isinstance(test_list_result, list)

# Generated at 2022-06-21 12:46:25.631822
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    class H(SimpleNamespace):
        a: int = 1
        b: int = 2

    dic = {'a': 1, 'b': 2}
    struc = SimpleNamespace(a=1, b=2)
    lis = [1, 2]
    tup = (1, 2)
    # Act
    act = to_namedtuple(dic)
    act2 = to_namedtuple(lis)
    act3 = to_namedtuple(tup)
    act4 = to_namedtuple(H())
    assert isinstance(act, list)
    assert isinstance(act2, tuple)
    assert isinstance(act3, list)
    assert isinstance(act4, str)

    # Assert

# Generated at 2022-06-21 12:46:38.113767
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Check dict
    dic = {'a': 1, 'b': 2}
    # noinspection PyUnresolvedReferences,PyTypeChecker
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple({}) is NamedTuple()
    # Check list
    lst = [1]
    # noinspection PyUnresolvedReferences,PyTypeChecker
    assert to_namedtuple(lst) == [1]
    assert to_namedtuple([]) == []
    # Check tuple
    tpl = (1, )
    # noinspection PyUnresolvedReferences,PyTypeChecker
    assert to_namedtuple(tpl) == NamedTuple(1,)
    assert to_namedtuple(()) is NamedTuple()

# Generated at 2022-06-21 12:46:48.959681
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Sequence

    from nose.tools import assert_equal, assert_is_instance, raises

    from flutils.namedtupleutils import to_namedtuple

    tests = [
        ([], []),
        ([1, 2], [1, 2]),
        ([1, 'b'], [1, 'b']),
        ((1, 'b'), (1, 'b')),
        (((1, 'b'), ), ((1, 'b'), )),
        ({'a': 1, 'b': 2}, [1, 2]),
    ]

    for test_in, test_out in tests:
        out = to_namedtuple(test_in)
        assert_is_instance(out, Sequence)
        assert_equal(list(out), test_out)

# Generated at 2022-06-21 12:47:01.561590
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
           NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to

# Generated at 2022-06-21 12:47:11.881137
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    """Unit tests for to_namedtuple"""

    import flutils.namedtupleutils as ntu

    assert hasattr(ntu, '__all__')
    assert 'to_namedtuple' in ntu.__all__

    assert hasattr(ntu, '_to_namedtuple')
    assert hasattr(ntu, '_to_namedtuple')

    assert isinstance(ntu._to_namedtuple, singledispatch)

    assert isinstance(ntu._to_namedtuple._registry, dict)
    assert isinstance(ntu._to_namedtuple._registry[Mapping], _to_namedtuple)
    assert isinstance(ntu._to_namedtuple._registry[Sequence], _to_namedtuple)

# Generated at 2022-06-21 12:47:23.722859
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) == 1
    assert to_namedtuple('foo') == 'foo'
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple(OrderedDict([('a', 1)])) == NamedTuple(a=1)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('b', 2), ('a', 1)])) == NamedTuple(b=2, a=1)

# Generated at 2022-06-21 12:47:33.980455
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Test the to_namedtuple function'''
    from pytest import raises
    # test TypeError
    with raises(TypeError):
        to_namedtuple(1)
    # test list
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple([{'c': 1}]) == [NamedTuple(c=1)]
    assert to_namedtuple([{'c': [{'d': 1}]}]) == [NamedTuple(c=[NamedTuple(d=1)])]
    # test dict
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_named

# Generated at 2022-06-21 12:47:43.871071
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print()
    print("------ test_to_namedtuple ------")

    def assert_namedtuple_equals(expected, result):
        assert expected.__name__ == result.__name__
        assert expected._fields == result._fields
        for field in expected._fields:
            assert getattr(expected, field) == getattr(result, field)


# Generated at 2022-06-21 12:47:55.409561
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple(SimpleNamespace()) == namedtuple('NamedTuple', '')()
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple(dict()) == namedtuple('NamedTuple', '')()
    assert to_namedtuple(dict(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple(OrderedDict()) == namedtuple('NamedTuple', '')()
    assert to_namedtuple(OrderedDict(a=1, b=2)) == namedt

# Generated at 2022-06-21 12:47:58.869856
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = {"x":1, "y":2}
    assert data != to_namedtuple(data)
    assert data['x'] == to_namedtuple(data).x
    assert data['y'] == to_namedtuple(data).y

# Generated at 2022-06-21 12:48:10.098530
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    ntuple = to_namedtuple(dic)
    assert ntuple.a == 1 and ntuple.b == 2
    lst = [1, 2, 3]
    lst = to_namedtuple(lst)
    assert isinstance(lst, list)
    assert lst == [1, 2, 3]
    dic = {'a': {'b': 1, 'c': 2}, 'd': 3}
    ntuple = to_namedtuple(dic)
    assert ntuple.a.b == 1 and ntuple.a.c == 2 and ntuple.d == 3
    dic2 = {'a': {'n': 1, 'c': 2}, 'd': 3}
    ntuple

# Generated at 2022-06-21 12:48:18.873325
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from datetime import date, time, datetime
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testingutils import StringIO

    ############################################################################
    # Test for NamedTuple (recursive for items)
    ############################################################################
    inp = {
        'a': 1,
        'b': 2,
    }
    out = to_namedtuple(inp)
    # Examples as a NamedTuple
    assert hasattr(out, '_asdict')
    assert out._fields == ('a', 'b')
    assert out.a == 1
    assert out.b == 2

    inp = {
        'a': 1,
        'b': 2,
        2: 3,
    }
    out = to_namedt

# Generated at 2022-06-21 12:48:29.139139
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    class TestFunc(unittest.TestCase):
        def test_to_namedtuple(self):
            data = {'a': 1}
            data2 = to_namedtuple(data)
            self.assertTrue(hasattr(data2, 'a'))
            self.assertFalse(hasattr(data2, 'b'))
            self.assertTrue(hasattr(data2, '_fields'))
            self.assertTrue(hasattr(data2, '_asdict'))
            self.assertEqual(data2.a, 1)
            self.assertEqual(data2._fields, ('a',))
            self.assertEqual(data2._asdict(), {'a': 1})


# Generated at 2022-06-21 12:48:32.319856
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == collections.namedtuple('NamedTuple', ('a', 'b'))(a=1,b=2)

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:48:48.310041
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # for global objects
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'x': 1, 'y': 2}) == namedtuple('NamedTuple', ['x', 'y'])(1, 2)
    dic = {'x': 1, 'y': 2, '_z': 1}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ['x', 'y'])(1, 2)
    assert to_namedtuple(OrderedDict(x=1, y=2, _z=1)) == namedt

# Generated at 2022-06-21 12:49:00.183546
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace
    from typing import List
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testing import compare_json_with_file

    actual1 = to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)]))
    expected1 = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    compare_json_with_file(expected1, actual1)

    actual2 = to_namedtuple(SimpleNamespace(a=1, b=2, c=3))
    expected2 = OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-21 12:49:07.284619
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple('') == ''
    assert to_namedtuple('1') == '1'
    assert to_namedtuple('True') == 'True'
    assert to_namedtuple(1) == 1
    assert to_namedtuple(True) == True
    assert to_namedtuple(False) == False
    assert to_namedtuple([]) == []
    assert to_namedtuple({'a':1}) == NamedTuple(a=1)
    assert to_namedtuple({'a':True}) == NamedTuple(a=True)
    assert to_namedtuple({'a':{'b':1}}) == NamedTuple(a=NamedTuple(b=1))

# Generated at 2022-06-21 12:49:18.184717
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from doctest import testmod

    results = testmod(
        to_namedtuple,
        extraglobs=dict(to_namedtuple=to_namedtuple)
    )
    assert results.failed == 0

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == to_namedtuple(dic)

    odic = OrderedDict()
    odic['a'] = 1
    odic['b'] = 2
    assert to_namedtuple(odic) == to_namedtuple(dic)

    tpl = (1, 2, 3)
    assert to_namedtuple(tpl) == tpl

    lst = [1, 2, 3]
    assert to_namedtuple(lst) == l

# Generated at 2022-06-21 12:49:28.241168
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function ``to_namedtuple``.
    """
    from flutils.namedtupleutils import to_namedtuple
    from typing import (
        List,
    )

    dic = {'a': 1, 'b': 2, 'f': -1, 'g': -2, 'c': 3, 'e': -3, 'd': 4}
    out1 = to_namedtuple(dic)
    assert out1.a == 1
    assert out1.b == 2
    assert out1.c == 3
    assert out1.d == 4
    assert out1.e == -3
    assert out1.f == -1
    assert out1.g == -2


# Generated at 2022-06-21 12:49:41.067831
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace

    Dic = to_namedtuple({'a': 1, 'b': 2})
    assert Dic.a == 1
    assert Dic.b == 2

    dic = {'a': 1, 'b': 2}
    Dic = to_namedtuple(dic)
    assert Dic.a == 1
    assert Dic.b == 2
    assert dic == {'a': 1, 'b': 2}

    tup = (1, 2, 3)
    Tup = to_namedtuple(tup)
    assert Tup == (1, 2, 3)

    lst = [1, 2, 3]
    Lst = to_namedtuple(lst)

# Generated at 2022-06-21 12:49:53.218459
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2}
    dic2 = {'c': 3, 'd': 4}
    dic['e'] = dic2
    dic['f'] = [1, 2]
    dic['g'] = (1, 2)
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, e=NamedTuple(c=3, d=4), f=[1, 2], g=(1, 2))

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2

# Generated at 2022-06-21 12:50:01.996484
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import Tuple
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple({}) == NamedTuple()

    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)

    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)

    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == NamedTuple(a=1, b=2, c=3, d=4)

    assert to_namedt

# Generated at 2022-06-21 12:50:08.361089
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import patch, sentinel
    from collections import OrderedDict

    with patch('flutils.namedtupleutils._to_namedtuple') as mock_to_namedtuple:
        mock_to_namedtuple.return_value = sentinel.retval
        retval = to_namedtuple(sentinel.object)
        mock_to_namedtuple.assert_called_once_with(
            sentinel.object,
            _started=False
        )
        assert retval is sentinel.retval

        mock_to_namedtuple.reset_mock()
        retval = to_namedtuple([])
        mock_to_namedtuple.assert_called_once_with(
            [],
            _started=False
        )
        assert retval is sentinel.retval

# Generated at 2022-06-21 12:50:21.719455
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnreachableCode
    if False:
        # noinspection PyStatementEffect
        list or tuple
        OrderedDict
        namedtuple

    # noinspection PyUnusedLocal
    def assert_true(expr, msg=None):
        assert expr, msg or 'Expected True'

    # noinspection PyUnusedLocal
    def assert_false(expr, msg=None):
        assert not expr, msg or 'Expected False'

    from operator import itemgetter, attrgetter

    d = OrderedDict()
    d['b'] = 2
    d['c'] = OrderedDict(c=3)
    d['a'] = 1

    nt = to_namedtuple(d)
    assert_true(isinstance(nt, NamedTuple))

# Generated at 2022-06-21 12:50:40.210304
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

# Generated at 2022-06-21 12:50:49.693663
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'a': 1, 'b': 2}
    assert isinstance(to_namedtuple(d), namedtuple)
    assert to_namedtuple(d).a == 1
    d = {'_a': 1, 'b': 2}
    assert isinstance(to_namedtuple(d), namedtuple)
    assert to_namedtuple(d).b == 2
    assert not hasattr(to_namedtuple(d), '_a')
    s = SimpleNamespace(a=1)
    assert isinstance(to_namedtuple(s), namedtuple)

# Author - Ian Orzel

# Generated at 2022-06-21 12:51:01.084875
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier

    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert out.a == 1
    assert out.b == 2

    obj = {'a': 1, 'b': 2}
    keys = []
    for key in obj.keys():
        if hasattr(key, 'capitalize'):
            key = cast(str, key)
            try:
                validate_identifier(key, allow_underscore=False)
            except SyntaxError:
                continue
            if key.isidentifier():
                keys.append(key)


# Generated at 2022-06-21 12:51:12.234523
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic: Mapping[Any, Any] = {
        'a': "a",
        'b': SimpleNamespace(
            a=1,
            b=2,
        ),
        'c': [
            "1",
            "2",
            OrderedDict(
                a=3,
                b=4,
            ),
        ],
        'd': 1,
        'e': 2,
        'f': "3",
        'g': 4,
    }
    out = to_namedtuple(dic)

    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert hasattr(out, 'c')
    assert hasattr(out, 'd')
    assert hasattr(out, 'e')
    assert hasattr(out, 'f')
   

# Generated at 2022-06-21 12:51:20.567166
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert repr(to_namedtuple({'a': 1, 'b': 2, 'c': 3})) == "NamedTuple(a=1, b=2, c=3)"
    assert repr(to_namedtuple({'c': 3, 'b': 2, 'a': 1})) == "NamedTuple(a=1, b=2, c=3)"
    assert repr(to_namedtuple(OrderedDict([('c', 3), ('b', 2), ('a', 1)]))) == "NamedTuple(c=3, b=2, a=1)"
    assert repr(to_namedtuple(SimpleNamespace(a=1, b=2, c=3))) == "NamedTuple(a=1, b=2, c=3)"

# Generated at 2022-06-21 12:51:32.634257
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from flutils.objutils import (
        is_subclass_recursive,
    )
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import get_namedtuple_attrs
    from collections import namedtuple
    import pytest
    from types import (
        MappingProxyType,
        SimpleNamespace,
    )
    from flutils.objutils import (
        is_subclass_recursive,
    )
    from flutils.validators import validate_identifier

    class MockSimpleNamespace(SimpleNamespace):
        __dict__ = MappingProxyType({'a': 1})

    # class List(list):
    #     __

# Generated at 2022-06-21 12:51:35.542241
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == \
        NamedTuple(a=1, b=2)


print('Testing...')
import doctest
doctest.testmod()

# Generated at 2022-06-21 12:51:43.797645
# Unit test for function to_namedtuple
def test_to_namedtuple():
    ''' Unit test for function to_namedtuple '''
    print('Running Tests')
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        ''' Unit test class for to_namedtuple '''
        def test_to_namedtuple(self):
            ''' Testing to_namedtuple '''
            print(self._testMethodDoc)

            dic = {'a': 1, 'b': 2}
            self.assertEqual(
                to_namedtuple(dic),
                namedtuple('', '')()._replace(a=1, b=2)
            )

            dic = {'a': 1, 'b': {'c': 3, 'd': 4}}

# Generated at 2022-06-21 12:51:55.260011
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}
    out = to_namedtuple(dic)
    assert out == namedtuple('NamedTuple', 'a b c d e f')(a=1, b=2, c=3, d=4, e=5, f=6)

    tpl = {'a': 'A', 'b': 'B', 'c': 'C'}
    out = to_namedtuple(tpl)

# Generated at 2022-06-21 12:52:03.138122
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import (
        namedtuple,
        OrderedDict,
    )
    from unittest.mock import Mock
    from types import (
        SimpleNamespace,
    )
    from pytest import raises
    from flutils.validators import (
        ValidationError,
    )
    # Test parameter "obj" type
    obj = 'something'
    with raises(TypeError):
        to_namedtuple(obj)

    obj = 1
    with raises(TypeError):
        to_namedtuple(obj)

    obj = None
    with raises(TypeError):
        to_namedtuple(obj)

    obj = Mock()
    with raises(TypeError):
        to_namedtuple(obj)

    obj = False


# Generated at 2022-06-21 12:52:25.506068
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Test for function to_namedtuple.'''
    import pytest
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    def test_exceptions():
        with pytest.raises(TypeError) as err_info:
            to_namedtuple('test')
        assert str(err_info.value) == (
            "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
            "got: str test"
        )

        with pytest.raises(TypeError) as err_info:
            to_namedtuple(1)

# Generated at 2022-06-21 12:52:35.300975
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2, 'c': {'d': 3}}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.c.d == 3

    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.c.d == 3
    assert out.c.e == 4

    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, 'f': {'g': 5, 'h': 6}}}
    out = to_namedtuple(dic)

# Generated at 2022-06-21 12:52:47.057873
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a':1, 'b':2}
    dic_recursive = {'a': 1, 'b': 2, 'c':{'d':3, 'e':4}}
    dic_ordered = OrderedDict(dic_recursive)
    dic_with_underscore = {'a': 1, 'b': 2, '_c':{'_d':3, '_e':4}}
    dic_with_underscore_ordered = OrderedDict(dic_with_underscore)

    obj = SimpleNamespace(**dic_recursive)
    np1 = namedtuple('NamedTuple', dic_recursive.keys())(*dic_recursive.values())

# Generated at 2022-06-21 12:52:58.532342
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(
        {
            '_a': 1,
            'b': 2,
            'c': {
                'a': 1,
                'b': 2,
            },
        }
    ) == namedtuple('NamedTuple', ['b', 'c'])(2, namedtuple('NamedTuple', ['a', 'b'])(1, 2))

    assert to_namedtuple(
        [{
            '_a': 1,
            'b': 2,
            'c': {
                'a': 1,
                'b': 2,
            },
        }]
    ) == [
        namedtuple('NamedTuple', ['b', 'c'])(2, namedtuple('NamedTuple', ['a', 'b'])(1, 2))
    ]

   

# Generated at 2022-06-21 12:53:10.185678
# Unit test for function to_namedtuple
def test_to_namedtuple():  # noqa: D103,D107
    # Create test data
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    from collections import OrderedDict
    dic = OrderedDict((('a', 1), ('b', 2)))
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'_a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(b=2)

    dic = {'a': 1, '_b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1)

    lst = [1, 2]

# Generated at 2022-06-21 12:53:21.018050
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class ToNamedTupleTest(unittest.TestCase):
        def setUp(self):
            from collections import (
                defaultdict,
                OrderedDict,
            )


# Generated at 2022-06-21 12:53:32.526337
# Unit test for function to_namedtuple
def test_to_namedtuple():
  from collections import (
    OrderedDict,
    namedtuple,
  )
  from collections.abc import (
    Mapping,
    Sequence,
  )
  from functools import singledispatch
  from types import SimpleNamespace
  from typing import (
    Any,
    List,
    NamedTuple,
    Tuple,
    Union,
    cast,
  )
  from flutils.validators import validate_identifier
  
  _AllowedTypes = Union[
    List,
    Mapping,
    NamedTuple,
    SimpleNamespace,
    Tuple,
  ]
  

# Generated at 2022-06-21 12:53:38.559506
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Callable, Dict
    from unittest import TestCase
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    class TestToNamedTuple(TestCase):
        def setUp(self):
            self.dic = OrderedDict({
                'a': 1,
                'b': 2,
            })
            self.dicn = SimpleNamespace(**self.dic)
            self.mocked_dic = namedtuple('MockDict', self.dic.keys())
            self.mocked_dic = self.mocked_dic(**self.dic)

# Generated at 2022-06-21 12:53:49.066642
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    dic2 = to_namedtuple(dic)
    assert isinstance(dic2, NamedTuple)
    assert len(dic2) == 2
    assert dic['a'] == dic2.a
    assert dic['b'] == dic2.b

    lst = [1, 2, 3]
    lst2 = to_namedtuple(lst)
    assert isinstance(lst2, NamedTuple)
    assert len(lst2) == 3
    assert lst[0] == lst2[0]
    assert lst[1] == lst2[1]
    assert lst[2] == lst2[2]

    tup = (1, 2, 3)
    tup2 = to

# Generated at 2022-06-21 12:53:57.976288
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test to_namedtuple.
    Note: Testing nested dicts (dicts containing dicts) are not tested.
    Timing:
        >>> import time
        >>> start = time.perf_counter()
        >>> test_to_namedtuple()
        >>> end = time.perf_counter()
        >>> print(f'{end-start:.2f} seconds to run.')
        0.01 seconds to run.
    """
    # No need to test all permutations.
    dict_a = {'a': 1, 'b': 2}
    dict_b = {'b': 2, 'a': 1}
    dict_c = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-21 12:54:24.524071
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(list(range(10))) == list(range(10))
    assert to_namedtuple(tuple(range(10))) == tuple(range(10))
    assert to_namedtuple(dict(zip(range(10), range(10)))) == NamedTuple(**dict(zip(range(10), range(10))))
    assert to_namedtuple(OrderedDict(zip(range(10), range(10)))) == NamedTuple(**OrderedDict(zip(range(10), range(10))))
    assert to_namedtuple(SimpleNamespace(**dict(zip(range(10), range(10))))) == NamedTuple(**dict(zip(range(10), range(10))))



if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:54:33.565533
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    tup = to_namedtuple(dic)
    assert tup.a == 1
    assert tup.b == 2

# Generated at 2022-06-21 12:54:42.545818
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    d1 = dict(a=1, b=2, c=3)
    d2 = dict(a=1, b=2, c=dict(d=4, e=5), f=dict(g=6, h=7))
    d3 = dict(a=1, b=2, c=dict(d=4, e=5), f=dict(g=6, h=list(range(10))))
    d4 = dict(a=1, b=2, c=dict(d=4, e=5), f=dict(g=6, h=list(range(5))))
    d5 = OrderedDict(a=1, b=2, c=dict(d=4, e=5), f=dict(g=6, h=7))

# Generated at 2022-06-21 12:54:53.436771
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    import unittest
    from flutils.namedtupleutils import to_namedtuple

    class ToNamedTupleTests(unittest.TestCase):
        """Test the to_namedtuple function."""

        def test_01_to_namedtuple(self):
            """Convert a dict to a NamedTuple."""
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertEqual(out, namedtuple('NamedTuple', 'a b')(a=1, b=2))

            dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
           

# Generated at 2022-06-21 12:55:04.516602
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1 and obj.b == 2

    ordered_dic = OrderedDict({'a': 1, 'b': 2})
    ordered_obj = to_namedtuple(ordered_dic)
    assert ordered_obj[0] == 1 and ordered_obj[1] == 2
    assert ordered_obj._fields[0] == 'a' and ordered_obj._fields[1] == 'b'

    lst = [{'c': 3, 'd': 4}, {'e': 5, 'f': 6}]
    lst_obj = to_namedtuple(lst)
    assert lst_obj[0].c == 3 and lst_obj[0].d == 4
