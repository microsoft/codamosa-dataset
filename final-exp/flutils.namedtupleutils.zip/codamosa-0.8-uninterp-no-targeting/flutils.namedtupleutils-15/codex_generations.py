

# Generated at 2022-06-21 12:45:16.971068
# Unit test for function to_namedtuple
def test_to_namedtuple():  # pragma: no cover
    import flutils.namedtupleutils

    def _test(
            in_: Any,
            out: Any,
    ) -> None:
        result = flutils.namedtupleutils.to_namedtuple(in_)
        assert isinstance(result, out)

    _test(
        in_=[
            {'a': 1, 'b': 2},
            {'c': 3, 'd': 4},
        ],
        out=List[NamedTuple],
    )

    _test(
        in_={
            'a': 1,
            'b': [
                {'c': 3, 'd': 4},
                {'e': 5, 'f': 6},
            ],
        },
        out=NamedTuple,
    )


# Generated at 2022-06-21 12:45:28.198512
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test namedtupleutils.to_namedtuple

    """
    from datetime import date, datetime, time
    from decimal import Decimal
    import pytest
    from flutils.namedtupleutils import to_namedtuple, _to_namedtuple
    from flutils.namedtupleutils import _AllowedTypes, _to_namedtuple
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == dic['a']
    assert out.b == dic['b']
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out._fields == ('a', 'b')

# Generated at 2022-06-21 12:45:29.107050
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:45:40.357936
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import OrderedDict

    from flutils.namedtupleutils import to_namedtuple

    def make_namespace_with_attributes_and_values(**kwargs):
        """Make a SimpleNamespace with given attributes and values.

        Args:
            **kwargs:
                The attributes and values to be added to the created
                SimpleNamespace.

        Returns:
            A SimpleNamespace with the given attributes and values.

        Example:
            >>> from flutils.namedtupleutils import make_namespace_with_attributes_and_values
            >>> n = make_namespace_with_attributes_and_values(a=1, b=2)
            >>> n.a
            1
            >>> n.b
            2

        """
        namespace = SimpleNamespace(**kwargs)
        return namespace



# Generated at 2022-06-21 12:45:44.420986
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    named_tuple=to_namedtuple(dic)
    print(named_tuple)
    assert named_tuple.a==1
    assert named_tuple.b==2

# Generated at 2022-06-21 12:45:54.622452
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test for function to_namedtuple
    """
    import unittest
    import sys

    _test_o: Any = {'a': 1, 'b': 2}
    _test_x: Any = 2
    _test_y: Any = [{'a': 1, 'b': 2}, [{'c': 3, 'd': 4}, [{'e': 5, 'f': 6}]]]
    _test_z: Any = OrderedDict({'a': 1, 'b': 2})

    class Testto_namedtuple(unittest.TestCase):
        """
        Test class for to_namedtuple
        """

        kwargs = dict(verbosity=2)


# Generated at 2022-06-21 12:46:05.428956
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple(([1, 2], {'a': 1, 'b': 2})) == (namedtuple('NamedTuple', ('a', 'b'))(1, 2), [1, 2])
    input = [1, 2, {'a': 1, 'b': 2}, ([1, 2, 3], {'a': 1, 'b': 2})]

# Generated at 2022-06-21 12:46:18.005984
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test = {
        'a': 1,
        'b': 2,
    }
    assert to_namedtuple(test).a == 1
    assert test['b'] == 2

    test = [{'a': 1, 'b': 2}, {'a': 2, 'b': 3}]
    assert test[0]['a'] == 1
    assert test[1]['b'] == 3
    assert to_namedtuple(test)[0].b == 2
    assert to_namedtuple(test)[1].a == 2

    from collections import OrderedDict
    test = OrderedDict((
        ('a', 1),
        ('b', 2),
    ))
    assert to_namedtuple(test).b == 2
    assert test['a'] == 1

    from collections import namedtuple
    test = named

# Generated at 2022-06-21 12:46:30.482233
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test out a valid dictionary
    dic = {'a': 1, 'b': 2}
    make = namedtuple('NamedTuple', dic.keys())
    assert to_namedtuple(dic) == make(**dic)
    # Test out a valid list
    lst = [1, 2]
    assert to_namedtuple(lst) == lst
    # Test out an invalid list
    lst = [1, 'a']
    assert to_namedtuple(lst) == lst
    # Test out an invalid dictionary
    dic = {'a': '1', 'b': 2}
    make = namedtuple('NamedTuple', dic.keys())
    assert to_namedtuple(dic) == make(**dic)
    # Test out a SimpleNamespace


# Generated at 2022-06-21 12:46:43.523010
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3
    assert obj.d == 4
    assert obj.e == 5

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, '_f': 6}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2

# Generated at 2022-06-21 12:47:00.595013
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'a': 1, 'b': 2}
    out = to_namedtuple(d)
    assert(str(out) == "NamedTuple(a=1, b=2)")
    d = OrderedDict()
    d['a'] = 1
    d['b'] = 2
    out = to_namedtuple(d)
    assert(str(out) == "NamedTuple(a=1, b=2)")
    l = [1, 2, 3]
    out = to_namedtuple(l)
    assert(str(out) == "[1, 2, 3]")

# Generated at 2022-06-21 12:47:10.076107
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    # NamedTuple
    obj = NamedTuple('NamedTuple', [])
    assert to_namedtuple(obj) == obj

    obj = NamedTuple('NamedTuple', ['a', 'b'], defaults=[1, 2])
    assert to_namedtuple(obj) == obj

    # OrderedDict
    obj = OrderedDict(a=1, b=2)
    assert to_namedtuple(obj) == obj

    assert to_namedtuple(
        OrderedDict(c=1, d=2, a=3, b=4)
    ) == obj


# Generated at 2022-06-21 12:47:22.354860
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from pprint import pformat
    from random import choice
    from string import digits, printable, punctuation


    def random_val(min_len: int = 6, max_len: int = 12, min_depth: int = 1,
                   max_depth: int = 2) -> Any:
        if min_depth > max_depth:
            raise ValueError
        depth = choice(range(min_depth, max_depth))
        if depth == 0:
            return ''.join([choice(printable) for _i in range(
                choice(range(min_len, max_len)))])

# Generated at 2022-06-21 12:47:31.729325
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.collectionsutils import (
        AttrDict,
        OrderedAttrDict,
    )

    assert to_namedtuple({'a': 1, 'b': 2}) == AttrDict({'a': 1, 'b': 2})
    assert to_namedtuple({'b': 2, 'a': 1}) == AttrDict({'a': 1, 'b': 2})
    assert to_namedtuple(OrderedAttrDict([('a', 1), ('b', 2)])) == OrderedAttrDict([('a', 1), ('b', 2)])

# Generated at 2022-06-21 12:47:41.433812
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': {
            'a1': 1,
            'b1': 2,
            'c1': 3,
            'd1': {'a1': 1, 'b1': 2},
        },
        'b': 2,
        'c': 3,
        'd': 'd',
        'e': {
            'a1': 1,
            'b1': 2,
            'c1': 3,
        },
    }
    expected = ('a', 'b', 'c', 'd', 'e')
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert hasattr(nt, 'c')
    assert hasattr(nt, 'd')

# Generated at 2022-06-21 12:47:49.844777
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json

    # Test that an error is raised if a non-dict is
    # passed.  This test is disposed of due to the default
    # handler in the singledispatch.
    try:
        to_namedtuple([1, 2, 3])
    except TypeError:
        pass

    # Create an OrderedDict and convert it to a namedtuple.
    # The ordered dict keys are in order and therefore the
    # keys should be in order.
    ordered = OrderedDict(a=1, b=2, c=3)
    ordered_nt = to_namedtuple(ordered)
    assert ordered_nt == NamedTuple(a=1, b=2, c=3)

    # Create a dict and convert it to a namedtuple.  The
    # order of the keys is not predictable and therefore
   

# Generated at 2022-06-21 12:48:01.197729
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert result.a == 1
    assert result.b == 2
    assert result == (1, 2)
    lst = [{'a': 1, 'c': 3}, {'b': 2}]
    result = to_namedtuple(lst)
    assert result[0].a == 1
    assert result[0].c == 3
    assert result[1].b == 2
    assert result == ([1, 3], [2])
    lst = ['a', 2]
    result = to_namedtuple(lst)
    assert result == ('a', 2)
    result = to_namedtuple([])
    assert result == ()
    result = to_namedtuple(())
    assert result

# Generated at 2022-06-21 12:48:11.984158
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:48:20.044952
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'foo': 1, 'bar': 2, '_1': 3}) == namedtuple('NamedTuple', 'bar foo')(foo=1, bar=2)

# Generated at 2022-06-21 12:48:29.680047
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import types

    # noinspection PyProtectedMember
    class MyClass(types.SimpleNamespace):
        _x: int = 1
        _y: int = 2

        @property
        def __dict__(self) -> dict:
            return {'_x': self._x, '_y': self._y}

    def to_dict_like(keys: Union[List[str], Tuple[str, ...]]) -> list:
        return [{key: key} for key in keys]

    def to_list_like(keys: Union[List[str], Tuple[str, ...]]) -> list:
        return [key for key in keys]


# Generated at 2022-06-21 12:48:34.367378
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    NamedTuple(a=1, b=2) == to_namedtuple(dic)


# Make the to_namedtuple function available as a module level function
to_namedtuple.__doc__ = __doc__ # type: ignore[assignment]
to_namedtuple.__name__ = __name__ # type: ignore[assignment]

# Generated at 2022-06-21 12:48:45.462384
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['abc', 2]) == ['abc', 2]
    assert to_namedtuple(('abc', 2)) == ('abc', 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    class Obj:
        a: int
        b: int
        __slots__ = ('a', 'b')

        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    obj = Obj(1, 2)

# Generated at 2022-06-21 12:48:49.939189
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class Test_to_namedtuple(unittest.TestCase):
        # noinspection PyUnusedLocal
        def setUp(self):
            pass

        def test_dict(self):
            dic = {'a': 1, 'b': 2}
            nt = to_namedtuple(dic)
            self.assertEqual(nt.a, 1)
            self.assertEqual(nt.b, 2)

        def test_dict_recursive(self):
            dic = {'a': 1, 'b': {'c': 3}}
            nt = to_namedtuple(dic)
            self.assertEqual(nt[0], 1)
            self.assertEqual(nt[1].c, 3)


# Generated at 2022-06-21 12:49:01.997229
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from pprint import pprint

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    class MyType(SimpleNamespace):
        a: int = 1
        b: int = 2

    md = MyNamedTuple(a=1, b=2)
    xd = to_namedtuple(md)
    xd2 = to_namedtuple(xd)
    xd3 = to_namedtuple(xd2)
    xd4 = to_namedtuple(xd3)
    pprint(xd4)
    assert xd is not md
    assert xd2 == xd
    assert xd3 == xd
    assert xd4 == xd
    print()


# Generated at 2022-06-21 12:49:13.735307
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic: Mapping = {'a': 1, 'b': 2, 'c': 'd'}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c='d')

    dic['_'] = 'e'
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c='d')

    odict: Mapping = OrderedDict({'a': 1, 'b': 2, 'c': 'd'})
    assert to_namedtuple(odict) == NamedTuple(a=1, b=2, c='d')

    odict['_'] = 'e'

# Generated at 2022-06-21 12:49:21.335984
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from typing import NamedTuple, List, Tuple, Union
    from functools import singledispatch

    class CifInfo(NamedTuple):
        _fields: Tuple[str, str, str, ...]
        _field_types: Tuple[type, type, type, ...]
        _field_defaults: Tuple[Any, Any, Any, ...]
        _field_map: Mapping[str, Any]
        _fields_defaults: List[Tuple[str, Any]]
        _asdict: Mapping[str, Any]


# Generated at 2022-06-21 12:49:30.396468
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import OrderedDict

    # noinspection PyStatementEffect
    """
    Tests for the function to_namedtuple
    """

    # list
    l = [1, 2, 3]
    assert l == to_namedtuple(l)

    l = [1, 2, 3, {'a': 1, 'b': 2, 'c': 3}]
    assert isinstance(to_namedtuple(l)[-1], tuple)

    # list with a dictionary
    l = [1, 2, {'a': 1, 'b': 2, 'c': 3}]
    assert isinstance(to_namedtuple(l)[-1], tuple)

    # tuple
    t = (1, 2, 3)
    assert t == to_namedtuple(t)


# Generated at 2022-06-21 12:49:42.165643
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from datetime import datetime
    from types import SimpleNamespace
    import pytest
    from flutils.validators import (
        validate_datetime,
        validate_identifier,
    )
    dic = OrderedDict((
        ('a', 1),
        ('b', 2),
        ('c', OrderedDict((
            ('d', 3),
            ('e', 4),
            ('f', OrderedDict((
                ('g', 5),
                ('h', 6),
                ('i', 7),
            ))),
        ))),
    ))
    print(dic)
    tup = (1, 2, 3, 4, 5, 6, 7, 8)

    sns = SimpleNamespace()
    sns.a = 1

# Generated at 2022-06-21 12:49:54.098571
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # simple dictionary test
    nt = to_namedtuple({'a': 1, 'b': 2})
    assert nt.a == 1 and nt.b == 2

    # nested dictionary test
    nt = to_namedtuple({'a': 1, 'b': {'c': 3, 'd': 4}})
    assert nt.a == 1 and nt.b.c == 3 and nt.b.d == 4

    # mixed dictionary test
    nt = to_namedtuple({'a': 1, 'b': 2, 'c': [1, 2, {'d': 4, 'e': 5}]})
    assert nt.a == 1 and nt.b == 2 and nt.c[2].d == 4

    # ordered dictionary test

# Generated at 2022-06-21 12:49:56.327910
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-21 12:50:06.006064
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test :func:`to_namedtuple`."""
    import pytest

    class Class:
        pass

    # noinspection PyTypeChecker
    invalid_types = {
        Class(),
        1,
        3.2,
        set(),
        frozenset(),
        bytearray(b'123'),
        Class,
        Exception,
        type,
    }

    for obj in invalid_types:
        with pytest.raises(TypeError):
            _ = to_namedtuple(obj)

# Generated at 2022-06-21 12:50:19.017145
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert isinstance(obj, NamedTuple)
    assert obj.a == 1
    assert obj.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': {'e': 4, '_f': 5, 'g': 6}}
    obj = to_namedtuple(dic)
    assert isinstance(obj, NamedTuple)
    assert isinstance(obj.d, NamedTuple)
    assert obj.a == 1

# Generated at 2022-06-21 12:50:29.463548
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from types import SimpleNamespace

    dic = dict(
        a=dict(
            b=dict(
                c=dict(
                    d=dict(
                        e=dict(
                            f=True,
                            g=False
                        ),
                        h=False
                    ),
                    i=True
                ),
                j=False
            ),
            k=True
        ),
        l=dict(
            m=False,
            n=True
        ),
        o=True,
        p=False
    )
    nt: NamedTuple = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.p is False
    assert nt.o is True
    assert nt.l.n is True

# Generated at 2022-06-21 12:50:40.635332
# Unit test for function to_namedtuple
def test_to_namedtuple():  # pragma: no cover
    from flutils.miscutils import (
        Any,
        Dict,
        DictStrAny,
        DictStrStr,
        TupleStrStr,
        UnionStrStrStrInt,
        ignore_exceptions,
    )

# Generated at 2022-06-21 12:50:47.732640
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    tups = (1, 2, 3)
    assert to_namedtuple(tups) == NamedTuple(x=1, y=2, z=3)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:50:55.518309
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test ``to_namedtuple()`` function."""
    from collections import (
        OrderedDict,
    )
    from types import SimpleNamespace
    import datetime
    import pytest
    import pytz

    timeline = dict(
        Jim=SimpleNamespace(
            Born=pytz.utc.localize(datetime.datetime(1947, 2, 9, 12, 36)),
            Died=pytz.utc.localize(datetime.datetime(2007, 8, 30, 13)),
        ),
    )
    timeline['Jim'].Lived = [
        (
            timeline['Jim'].Died - timeline['Jim'].Born
        ).total_seconds() / 60,
    ]


# Generated at 2022-06-21 12:51:07.782335
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from typing import NamedTuple
    from collections import (
        OrderedDict,
    )

    class _TestNamedTuple(NamedTuple):
        x: int
        y: int

    class _TestNamedTuple2(NamedTuple):
        a: int
        y: int

    class _TestNamedTuple3(NamedTuple):
        a: int
        x: int
        y: int
        d: str

    # dict
    dic = {'a': 1, 'b': 2}
    nt = _TestNamedTuple(**dic)

    nt2 = to_namedtuple(dic)
    assert isinstance(nt2, NamedTuple)
    assert nt2 == nt


# Generated at 2022-06-21 12:51:17.659569
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import randint

    from flutils.namedtupleutils import (
        to_namedtuple,
    )

    class NT(NamedTuple):
        a: int
        b: int

    a = randint(0, 1000)
    b = randint(0, 1000)
    dic = {'a': a, 'b': b}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == a
    assert out.b == b
    assert out == NT(a=a, b=b)

    # Test other types to NamedTuple
    # List
    l = [dic]
    out = to_namedtuple(l)
    assert out == [dic]

# Generated at 2022-06-21 12:51:28.906572
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(dict(a=1)) == namedtuple('NamedTuple', ['a'])(1)

    assert to_namedtuple(dict(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)

    assert to_namedtuple(OrderedDict(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)

    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)

    # noinspection PyTypeChecker

# Generated at 2022-06-21 12:51:38.202241
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)

    dic = {'a': 1, 'd': {'b': 2, 'c': 3}}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'd'))(1, namedtuple('NamedTuple', ('b', 'c'))(2, 3))

    ordic = OrderedDict((('d', {'b': 2, 'c': 3}), ('a', 1)))

# Generated at 2022-06-21 12:51:46.531738
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {"a": 1, "b": [1], "c": {"_a": 7}}
    nt = to_namedtuple(dic)
    assert nt.a == 1 and nt.b[0] == 1 and nt.c._a == 7

if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-21 12:51:57.799523
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    assert_raises(TypeError, to_namedtuple, 1)

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    out = to_namedtuple('str')
    assert out == 'str'

    out = to_namedtuple(['a', 'b'])
    assert out[0] == 'a'
    assert out[1] == 'b'


# Generated at 2022-06-21 12:52:07.911902
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from typing import (
        cast,
        List,
        NamedTuple,
        Sequence,
    )
    from collections.abc import (
        Mapping,
        Sequence,
    )
    from types import SimpleNamespace

    _AllowedTypes = Union[
        List,
        Mapping,
        NamedTuple,
        SimpleNamespace,
        Tuple,
    ]

    class _TempClass(object):
        def __init__(self):
            pass

        # noinspection PyUnusedLocal
        def __getattribute__(self, item):
            return 1


# Generated at 2022-06-21 12:52:11.376255
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils.tests import test_to_namedtuple

    test_to_namedtuple.__test__ = False  # type: ignore
    test_to_namedtuple()

# Generated at 2022-06-21 12:52:22.538132
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from json import loads
    from pprint import pprint
    from types import SimpleNamespace
    from flutils.py23utils import is_str

    dic = {'a': 1, 'b': 2}
    named = to_namedtuple(dic)
    assert named.a == 1
    assert named.b == 2

    dic = {'a': 1, 'b': 2, 'c': '_d'}
    named = to_namedtuple(dic)
    assert named.a == 1
    assert named.b == 2
    assert not hasattr(named, 'c')

    named2 = to_namedtuple(named)
    assert named2.a == 1

# Generated at 2022-06-21 12:52:30.158014
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pytest import raises
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    with raises(TypeError):
        to_namedtuple(SimpleNamespace())
    assert to_namedtuple(SimpleNamespace(a=1)) == (1, )
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == (1, 2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2, c='c')) == (1, 2, 'c')
    assert to_namedtuple(SimpleNamespace(a=1, b=2, c=3)) == (1, 2, 3)

# Generated at 2022-06-21 12:52:40.712119
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from unittest.mock import Mock

    class Test(unittest.TestCase):
        def setUp(self) -> None:
            self.obj = {'a': 1, 'b': 2}
            self.obj_simple = SimpleNamespace(**self.obj)

        def test_to_namedtuple_dict(self) -> None:
            obj = self.obj
            named = to_namedtuple(obj)
            self.assertIsInstance(named, namedtuple)
            self.assertEqual(named.a, 1)
            self.assertEqual(named.b, 2)

        def test_to_namedtuple_simple(self) -> None:
            obj = self.obj_simple
            named = to_namedtuple(obj)

# Generated at 2022-06-21 12:52:52.231113
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit tests for function to_namedtuple
    """

    # Test: no args
    # Expect: TypeError
    try:
        to_namedtuple()
        raise AssertionError("TEST FAILED: no args")
    except TypeError:
        pass

    # Test: SimpleNamespace()
    # Expect: Empty NamedTuple
    namespace = SimpleNamespace()
    expected = namedtuple('NamedTuple', '')()
    assert to_namedtuple(namespace) == expected

    # Test: SimpleNamespace(a=1, b=2)
    # Expect: NamedTuple(a=1, b=2)
    namespace = SimpleNamespace(a=1, b=2)
    make = namedtuple('NamedTuple', ['a', 'b'])
    expected = make

# Generated at 2022-06-21 12:52:54.998013
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from ..testing import run_doctest
    results = run_doctest('flutils.namedtupleutils', 'to_namedtuple')
    assert results.failures == 0

# Generated at 2022-06-21 12:53:04.982623
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2, 'c': 3}
    named_tuple = to_namedtuple(dic)
    print(named_tuple)
    assert named_tuple == NamedTuple(a=1, b=2, c=3)
    dic = {'a': 1, 'c': 3, 'b': 2}
    named_tuple = to_namedtuple(dic)
    print(named_tuple)
    assert named_tuple == NamedTuple(a=1, b=2, c=3)
    odic = OrderedDict()
    odic['c'] = 3
    odic['a'] = 1
    odic['b'] = 2
    named_tuple = to_namedtuple(odic)

# Generated at 2022-06-21 12:53:22.835786
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test list of lists
    items = [
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
        {'a': 5, 'b': 6},
    ]
    expected = [
        NamedTuple(a=1, b=2),
        NamedTuple(a=3, b=4),
        NamedTuple(a=5, b=6),
    ]
    assert to_namedtuple(items) == expected
    # Test list of tuples
    items = [
        ('a', 1), ('b', 2),
        ('a', 3), ('b', 4),
        ('a', 5), ('b', 6),
    ]

# Generated at 2022-06-21 12:53:25.228678
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:53:34.685602
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a1 = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    a2 = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    a3 = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3,
        }
    }
    a4 = {
        'a': {
            'b': {
                'c': 1,
                'd': 2,
            },
            'f': {
                'g': {
                    'h': 3,
                }
            }
        }
    }
    nta1 = to_namedtuple(a1)
    nta2 = to_namedtuple(a2)
    nta3 = to

# Generated at 2022-06-21 12:53:46.818558
# Unit test for function to_namedtuple
def test_to_namedtuple():
    original = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': {'e': 4, 'f': 5},
        'g': [1, 2, 3],
        'h': (1, 2, 3),
        'i': SimpleNamespace(j=6, k=7),
        'l': list(range(3)),
        'm': tuple(range(3)),
        'n': {'o': 6, 'p': 7},
        'q': ('o', 'p',),
        'r': ('o', {'p': 7}),
    }

# Generated at 2022-06-21 12:53:55.433477
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    import pytest
    from collections import OrderedDict
    from collections.abc import Sequence
    from typing import Any, Union

    _AllowedTypes = Union[
        Sequence,
        Mapping,
        SimpleNamespace,
    ]


    def test_to_namedtuple_bad_type(obj: Any) -> None:
        with pytest.raises(TypeError):
            to_namedtuple(obj)


    def test_func(
            obj: _AllowedTypes,
            expected: Any
    ) -> None:
        actual = to_namedtuple(obj)
        assert actual == expected



# Generated at 2022-06-21 12:54:02.433145
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple('') == '', 'string, qtd'
    assert to_namedtuple("") == '', 'string, dqtd'
    assert to_namedtuple('a') == 'a', 'string, qtd, 1 char'
    assert to_namedtuple("a") == 'a', 'string, dqtd, 1 char'
    assert to_namedtuple('ab') == 'ab', 'string, qtd, 2 chars'
    assert to_namedtuple("ab") == 'ab', 'string, dqtd, 2 chars'
    assert to_namedtuple('abc') == 'abc', 'string, qtd, 3 chars'
    assert to_namedtuple("abc") == 'abc', 'string, dqtd, 3 chars'
    assert to_namedtuple(123) == 123

# Generated at 2022-06-21 12:54:11.943077
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test conversion of dictionary to a namedtuple.
    dic = {'a': 1, 'b': 2}
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dic) == expected

    # Test conversion of dictionary that contains nested dictionary to a
    # namedtuple.
    dic = {'a': {'b': 1}}
    expected = namedtuple('NamedTuple', 'a')(a=namedtuple('NamedTuple', 'b')(b=1))
    assert to_namedtuple(dic) == expected

    # Test conversion of dictionary that contains dictionary that contains
    # another dictionary to a namedtuple.
    dic = {'a': {'b': {'c': 1}}}

# Generated at 2022-06-21 12:54:22.809273
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import unittest

    class TestCase(unittest.TestCase):
        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            self.assertEqual(
                repr(to_namedtuple(dic)),
                'NamedTuple(a=1, b=2)'
            )

            dic['_c'] = 3
            self.assertEqual(
                repr(to_namedtuple(dic)),
                'NamedTuple(a=1, b=2)'
            )

            dic = OrderedDict(dic)
            self.assertEqual(
                repr(to_namedtuple(dic)),
                'NamedTuple(a=1, b=2)'
            )

            dic['C'] = 3

# Generated at 2022-06-21 12:54:32.497937
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    from flutils.systemutils import log_func_details
    from flutils.namedtupleutils import (
        to_namedtuple,
        NamedTuple
    )

    log_func_details(to_namedtuple)

    nt = to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2

    nt = to_namedtuple({'b': 2, 'a': 1})
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2
    pprint(nt)  # type:ignore[attr-defined]


# Generated at 2022-06-21 12:54:42.156042
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.mathutils import FuzzyInt
    from flutils.miscutils import NoUnderscoreIdentifier

    class MyNamedTupleLike(NamedTuple):
        pass

    class MySimpleNamespaceLike(SimpleNamespace):
        pass

    assert to_namedtuple(tuple()) == tuple()
    assert to_namedtuple(['b', 'a', 2, 1]) == ['b', 'a', 2, 1]

    dic1 = dict(a=1, b=2)
    namedtup1 = to_namedtuple(dic1)
    assert namedtup1.a == 1
    assert namedtup1.b == 2