

# Generated at 2022-06-21 12:45:19.110781
# Unit test for function to_namedtuple
def test_to_namedtuple():

    def _test_namedtuple(
            obj: Union[
                NamedTuple,
                Mapping,
                List,
                Tuple,
                SimpleNamespace,
                Any,
            ],
    ) -> None:
        obj_nt = to_namedtuple(obj)
        assert isinstance(obj_nt, NamedTuple)
        assert obj_nt is not obj

    def _test_tuple(
            obj: Union[
                NamedTuple,
                Mapping,
                List,
                Tuple,
                SimpleNamespace,
                Any,
            ],
    ) -> None:
        obj_nt = to_namedtuple(obj)
        assert isinstance(obj_nt, tuple)
        assert obj_nt is not obj


# Generated at 2022-06-21 12:45:30.122669
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_dict = {'a': 1, 'b': 2}
    assert to_namedtuple(test_dict) == NamedTuple(a=1, b=2)
    assert to_namedtuple(to_namedtuple(test_dict)) == NamedTuple(a=1, b=2)
    test_list = [1, 2, 3, 4]
    assert to_namedtuple(test_list) == [1, 2, 3, 4]
    assert to_namedtuple(to_namedtuple(test_list)) == [1, 2, 3, 4]
    test_tuple = (1, 2, 3, 4)
    assert to_namedtuple(test_tuple) == (1, 2, 3, 4)

# Generated at 2022-06-21 12:45:37.133623
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    #import doctest
    #doctest.testmod()
    import argparse
    import sys

    parser = argparse.ArgumentParser(
        description="Convert a structure to a NamedTuple."
    )
    parser.add_argument(
        "--verbose",
        "-v",
        dest="verbose",
        action="store_true",
        default=False,
        help="Print out more information",
    )
    parser.add_argument(
        "--quiet",
        "-q",
        dest="quiet",
        action="store_true",
        default=False,
        help="Print out less information",
    )

# Generated at 2022-06-21 12:45:46.651302
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Test the function to_namedtuple
    """
    import pytest


    def test_namedtuple(obj):
        """ Test that an object is returned as the same type
        """
        if isinstance(obj, (list, tuple)):
            olist = True
            odict = False
        else:
            olist = False
            odict = True
        assert isinstance(to_namedtuple(obj), list) == olist
        assert isinstance(to_namedtuple(obj), tuple) == odict


    def test_namedtuple_item(obj, item_idx, item):
        """ Test that an object is returned as the same type
        """
        assert isinstance(to_namedtuple(obj)[item_idx], item)



# Generated at 2022-06-21 12:45:52.778323
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(())._fields == ()
    assert to_namedtuple((5,)).a == 5
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic['c'] = to_namedtuple(dic)
    assert dic['c'] == NamedTuple(a=1, b=2)
    dic['d'] = 'd'
    assert dic['d'] == 'd'

# Generated at 2022-06-21 12:46:04.203905
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from collections import OrderedDict
    from flutils.misc import get_caller_name
    from flutils.namedtupleutils import to_namedtuple
    from flutils.typing import StrList

    def test_arg_types():
        try:
            to_namedtuple(None)
        except TypeError as e:
            assert str(e).startswith(
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple;"
            )
        else:
            assert False, 'TypeError should have been raised.'
    test_arg_types()

    def test_list_with_values():
        mylist = [1, 2, 3]
        obj = to_namedtuple(mylist)

# Generated at 2022-06-21 12:46:17.063163
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) is not None, 'Should not be None'
    assert to_namedtuple(1) is None, 'Should be None'
    assert to_namedtuple('1') is not None, 'Should not be None'
    assert to_namedtuple('1') is None, 'Should be None'
    assert to_namedtuple(True) is not None, 'Should not be None'
    assert to_namedtuple(True) is None, 'Should be None'
    assert to_namedtuple(False) is not None, 'Should not be None'
    assert to_namedtuple(False) is None, 'Should be None'
    assert to_namedtuple(b'1') is not None, 'Should not be None'

# Generated at 2022-06-21 12:46:17.656457
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:46:26.006757
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2}
    tup = to_namedtuple(dic)
    assert tup.a == 1
    assert tup.b == 2
    assert tup._asdict() == dic

    dic = {'a': 1, 'b': 2}
    tup = to_namedtuple(OrderedDict(dic))
    assert tup.a == 1
    assert tup.b == 2
    assert tup._asdict() == dic

    lst = [1, 2]
    ntup = to_namedtuple(lst)
    assert ntup == (1, 2)
    assert ntup._asdict() == dict(enumerate((1, 2)))

# Generated at 2022-06-21 12:46:38.556495
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple."""
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    with pytest.raises(AttributeError) as excinfo:
        out.c
    assert str(excinfo.value) == "'NamedTuple' object has no attribute 'c'"
    with pytest.raises(AttributeError) as excinfo:
        out._c
    assert str(excinfo.value) == "'NamedTuple' object has no attribute '_c'"


# Generated at 2022-06-21 12:46:51.106511
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test case: to_namedtuple"""
    dic = {'a': 1, 'b': 2}
    assert isinstance(to_namedtuple(dic), NamedTuple)
    assert hasattr(to_namedtuple(dic), 'a')
    assert hasattr(to_namedtuple(dic), 'b')
    assert to_namedtuple(dic).a == 1
    assert to_namedtuple(dic).b == 2
    t1 = (1,)
    t2 = (2,)
    assert to_namedtuple([t1, t2]) == [t1, t2]
    t1 = (1, 2)
    t2 = (2, 3)
    assert to_namedtuple([t1, t2]) == [t1, t2]
    assert to_

# Generated at 2022-06-21 12:47:03.301328
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class Obj(object):
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    class Obj1(Obj):
        def __init__(self, a: int, b: int, c: int):
            super().__init__(a, b)
            self.c = c

    obj = Obj(22, 33)
    obj1 = Obj1(22, 33, 44)

    dic: Mapping[str, int] = {'a': 1, 'b': 2}
    odic = OrderedDict([('c', 3), ('d', 4)])
    dic.update(odic)

    lst = [5, 6, obj, obj1]
    tup = tuple(lst)

# Generated at 2022-06-21 12:47:11.705482
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    d = {'a': 1, 'b': 2, 'c': 3, 'C': 4}
    items = list([d] * 10)
    out = to_namedtuple(items)
    nt = out[0]

    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3
    assert nt.C == 4

    assert nt._fields == ('a', 'b', 'c', 'C')

    out = to_namedtuple(d)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3
    assert out.C == 4

    assert out._fields == ('a', 'b', 'c', 'C')

    now = datetime.now()


# Generated at 2022-06-21 12:47:23.492051
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(dic, NamedTuple)
    assert isinstance(dic.a, int)
    assert isinstance(dic.b, int)
    assert dic.a == 1
    assert dic.b == 2

    od = OrderedDict()
    od['a'] = 1
    od['b'] = 2
    dic = to_namedtuple(od)
    assert isinstance(dic, NamedTuple)
    assert isinstance(dic.a, int)
    assert dic.a == 1
    assert isinstance(dic.b, int)
    assert dic.b == 2

    mynamespace = SimpleNamespace()
    mynamespace.a = 1

# Generated at 2022-06-21 12:47:27.579743
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace as sn

    data = {  # type: ignore[var-annotated]
        'a': [1],
        'b': sn(c=3)
    }

    assert to_namedtuple(OrderedDict(data)) ==  data

# Generated at 2022-06-21 12:47:36.855986
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class Obj:
        def __init__(self, x): self.x = x

    assert to_namedtuple([]) == ()
    assert to_namedtuple([1]) == (1,)
    assert to_namedtuple(()) == ()
    assert to_namedtuple((1, )) == (1,)
    assert to_namedtuple({}) == ()
    assert to_namedtuple({1: 2}) == (2,)
    assert to_namedtuple(OrderedDict()) == ()
    assert to_namedtuple(OrderedDict([(1, 2)])) == (2,)
    assert to_namedtuple(SimpleNamespace()) == ()
    assert to_namedtuple(SimpleNamespace(x=1)) == (1,)
    assert to_namedtuple(Obj(1)) == 1
    assert to

# Generated at 2022-06-21 12:47:43.832463
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    """Unit test for function to_namedtuple."""
    from collections import OrderedDict
    from types import SimpleNamespace
    from unittest.mock import patch
    from flutils.structutils import (
        Struct,
    )
    from flutils.namedtupleutils import to_namedtuple
    from flutils.tests import (
        UnitTester,
    )

# Generated at 2022-06-21 12:47:55.356468
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple([]) == []

    dic = {'a': 1, 'b': 2}
    expected = namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple(dic) == expected

    ordered = OrderedDict([('a', 1), ('b', 2)])
    expected = namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple(ordered) == expected


# Generated at 2022-06-21 12:48:03.736646
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from pytest import raises
    from flutils.namedtupleutils import to_namedtuple

    with raises(TypeError):
        # noinspection PyTypeChecker
        to_namedtuple(1)

    with raises(TypeError):
        # noinspection PyTypeChecker
        to_namedtuple(object())

    nt1 = to_namedtuple([1, 2])
    assert nt1 == [1, 2]

    nt1 = to_namedtuple([[1, 2], [3, 4]])

# Generated at 2022-06-21 12:48:07.375179
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)



# Generated at 2022-06-21 12:48:26.284983
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) == 1

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2}
    namespaced = SimpleNamespace(**dic)
    assert to_namedtuple(namespaced) == NamedTuple(a=1, b=2)

    dic = {'a': 1}
    namespaced = SimpleNamespace(**dic)
    assert to_namedtuple(namespaced) == NamedTuple(a=1)

    dic = {'a': 1}
    namespaced = SimpleNamespace(**dic)
    assert to_namedtuple(namespaced).a == 1


# Generated at 2022-06-21 12:48:36.184864
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections.abc import Mapping
    from flutils.namedtupleutils import to_namedtuple
    from typing import NamedTuple, Union
    from types import SimpleNamespace

    # Create a bunch of objects to use
    test_list = ['b', 'c', 'd']
    test_tuple = ('a', 'b', 'c')
    test_dict = {'one': 1, 'two': 2}
    test_dict2 = {'one': 1, 'two': (2, 'three')}
    test_ordered_dict = {'one': 1, 'two': (2, 'three')}
    test_simple_namespace = SimpleNamespace(one=1, two=(2, 'three'))

# Generated at 2022-06-21 12:48:47.844482
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Setup
    from collections import namedtuple
    from collections import OrderedDict

    # Exercise
    #  test_to_namedtuple_dict
    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert dic['a'] == nt.a
    assert dic['b'] == nt.b
    assert dic['c'] == nt.c
    assert len(dic) == 3
    assert len(nt._fields) == 3
    assert len(nt) == 3

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert dic['a'] == nt.a
    assert dic['b'] == n

# Generated at 2022-06-21 12:48:56.772569
# Unit test for function to_namedtuple
def test_to_namedtuple():  # pragma: no cover
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from pprint import pprint
    odic = OrderedDict([
        ('zig', 'zag'),
        ('right', 'wrong'),
        ('', 'blank'),
        ('list', [1, 2, 3]),
        ('tup', (1, 2, 3)),
        ('dict', {'a': 1, 'b': 2, 'c': 3}),
        ('dod', OrderedDict([
            ('a', 1),
            ('b', 2),
            ('c', 3),
        ])),
        ('bob', SimpleNamespace(
            a='zig',
            b='zag',
            c='zab',
        )),
    ])

    result = to_namedt

# Generated at 2022-06-21 12:49:05.828950
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest


    class TestToNamedTuple(unittest.TestCase):
        """Unit tests for function to_namedtuple"""

        def setUp(self) -> None:
            self.getname = lambda obj: obj.__class__.__name__
            self.getval = lambda obj: getattr(obj, 'value')

        def test_to_namedtuple_mapping(self):
            """to_namedtuple: Mapping"""
            dic = {
                'a': 1,
                'b': 2,
                'c': {
                    'd': 3,
                    'e': 4
                }
            }
            nt = to_namedtuple(dic)
            name = nt.__class__.__name__

# Generated at 2022-06-21 12:49:17.367112
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from sys import version as pv
    from re import (
        compile as rcompile,
        MULTILINE,
    )
    from types import ModuleType
    from flutils.namedtupleutils import to_namedtuple
    class TestTools(Mapping, Sequence):
        def __init__(self, *items):
            self.items = tuple(items)
        def __getitem__(self, item):
            return self.items[item]
        def __iter__(self):
            return iter(self.items)
        def __len__(self):
            return len(self.items)

# Generated at 2022-06-21 12:49:28.017301
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import date
    from collections import OrderedDict
    dic = OrderedDict({'a': 1, 'b': 2})
    dttuple = to_namedtuple(dic)
    assert dttuple.a == 1
    assert dttuple.b == 2
    dic = {'a': 1, 'b': 2}
    dttuple = to_namedtuple(dic)
    assert dttuple.a == 1
    assert dttuple.b == 2
    dic = {'_a': 1, 'b': 2}
    dttuple = to_namedtuple(dic)
    assert not hasattr(dttuple, '_a')
    assert dttuple.b == 2

# Generated at 2022-06-21 12:49:40.891931
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from flutils.namedtupleutils import to_namedtuple

    # noinspection PyAbstractClass,PyUnusedLocal
    class _Test(TestCase):
        def setUp(self):
            self.maxDiff = None
        def assertNamedTuple(
                self,
                obj,
                props: Tuple[str, ...]
        ):
            self.assertIsInstance(obj, namedtuple('NamedTuple', props))
        def assertNamedTupleValues(
                self,
                obj: namedtuple,
                *args
        ):
            self.assertIsInstance(obj.__dict__, Mapping)
            self.assertEqual(
                args,
                tuple(obj.__dict__.values())
            )

# Generated at 2022-06-21 12:49:43.881664
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-21 12:49:55.361164
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    assert to_namedtuple([dic]) == [to_namedtuple(dic)]

    assert to_namedtuple(('a', 1)) == ('a', 1)

    assert to_namedtuple(('a', {'a': 1})) == (
        'a',
        namedtuple('NamedTuple', 'a')(a=1)
    )

    assert to_namedtuple([('a', {'a': 1})]) == ['a', {'a': 1}]


# Generated at 2022-06-21 12:50:20.974174
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    dic = {'a': 1, 'b': 2}
    # noinspection PyUnresolvedReferences
    assert to_namedtuple(dic).a == 1
    dic = OrderedDict(a=1, b=2)
    assert list(dic.keys()) == ['a', 'b']
    # noinspection PyUnresolvedReferences
    assert list(to_namedtuple(dic)._fields) == ['a', 'b']
    dic = OrderedDict(b=2, a=1)
    assert list(dic.keys()) == ['b', 'a']
    # noinspection PyUnresolvedReferences
    assert list(to_namedtuple(dic)._fields) == ['b', 'a']


# Generated at 2022-06-21 12:50:25.188643
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """  """
    dic = {'a': 1, 'b': 2}
    actual = to_namedtuple(dic)
    expected = namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    assert actual == expected



# Generated at 2022-06-21 12:50:32.859986
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    ord_dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(ord_dic)
    assert out.a == 1
    assert out.b == 2

    test_list = [1, 2]
    out = to_namedtuple(test_list)
    assert out == [1, 2]

    test_list = [1, 2]
    out = to_namedtuple(test_list)
    assert out == [1, 2]

    test_tuple = (1, 2)
    out = to_namedtuple(test_tuple)
    assert out

# Generated at 2022-06-21 12:50:44.609775
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # pylint: disable=unused-variable,redefined-outer-name,too-many-locals,
    # pylint: disable=exec-used,protected-access,unsubscriptable-object,
    # pylint: disable=maybe-no-member
    from typing import Any, Dict
    from collections.abc import Mapping
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.essentials import flatten_mapping
    import pytest


# Generated at 2022-06-21 12:50:54.103508
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': 5,
            'g': {
                'h': 6,
                'i': 7
            }
        }
    }
    named = to_namedtuple(d)
    assert named.a == 1
    assert named.b == 2
    assert named.c.d == 3
    assert named.c.e == 4
    assert named.c.f == 5
    assert named.c.g.h == 6
    assert named.c.g.i == 7

    tup = (named, 1, 2, 3)
    named_tup = to_namedtuple(tup)
    assert named_tup[0].a == 1


# Generated at 2022-06-21 12:51:03.022016
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple((1,)) == (1,)
    assert to_namedtuple(dict(a=1)) == NamedTuple(a=1)
    assert to_namedtuple(OrderedDict(a=1)) == NamedTuple(a=1)
    assert to_namedtuple(SimpleNamespace(a=1)) == NamedTuple(a=1)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:51:14.154895
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test that a list or tuple can be converted to a namedtuple.
    """

    assert to_namedtuple([])

    assert to_namedtuple(())

    assert to_namedtuple([[]])

    assert to_namedtuple([(), ()])

    # type: ignore[arg-type]
    assert to_namedtuple(SimpleNamespace(a=[]))

    # type: ignore[arg-type]
    assert to_namedtuple(SimpleNamespace(a=()))

    # type: ignore[arg-type]
    assert to_namedtuple(SimpleNamespace(a=SimpleNamespace(b=1)))

    # type: ignore[arg-type]
    assert to_namedtuple(SimpleNamespace(a=1, b=2))

    # type: ignore[arg-type]

# Generated at 2022-06-21 12:51:23.592398
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    TestNamedTuple = namedtuple('TestNamedTuple', 'a b c d e')
    testdic = OrderedDict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5})
    testsnamespace = SimpleNamespace(a=1, b=2, c=3, d=4, e=5)

    # Testing OrderedDict
    testnt = TestNamedTuple(1, 2, 3, 4, 5)
    assert to_namedtuple(testdic) == testnt

    # Testing SimpleNamespace
    testnt = TestNamedTuple(1, 2, 3, 4, 5)

# Generated at 2022-06-21 12:51:28.129996
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)


if __name__ == '__main__':
    pass

# Generated at 2022-06-21 12:51:37.474519
# Unit test for function to_namedtuple
def test_to_namedtuple():
    odic = OrderedDict([('a', 1), ('b', 2), ('c', 3), ('d', 4)])
    odic2 = OrderedDict([('z', 22), ('y', 23), ('x', 24), ('w', 25)])
    odic3 = OrderedDict([('r', 32), ('s', 33), ('t', 34), ('u', 35)])
    dics = {'a1': odic, 'a2': odic2, 'a3': odic3}
    ns = SimpleNamespace(**dics)
    dns = SimpleNamespace(d=ns)
    result = dns
    out = to_namedtuple(result)
    # print(out)
    assert isinstance(out.d, NamedTuple)

# Generated at 2022-06-21 12:52:10.623527
# Unit test for function to_namedtuple
def test_to_namedtuple(): # noqa: D103
    dic = {'a': 1, 'b': 2}
    actl = to_namedtuple(dic)
    assert actl.a == 1
    assert actl.b == 2
    with pytest.raises(TypeError) as excinfo:
        to_namedtuple(1)
    assert "Can convert only 'list', 'tuple', 'dict' to a NamedTuple" in str(excinfo.value)
    assert "got: (int) 1" in str(excinfo.value)
    from flutils.jsonutils import loads
    from json import dumps
    json = dumps(dic)
    actl = to_namedtuple(loads(json))
    assert actl.a == 1
    assert actl.b == 2
    lst = [1, 2]
   

# Generated at 2022-06-21 12:52:21.892845
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import operator
    import sys
    import unittest

    try:
        from collections import UserDict
    except ImportError:
        from collections.abc import UserDict

    class _ToNamedTupleTests(unittest.TestCase):
        def test_all_to_namedtuple(self):
            self.assertEqual(
                to_namedtuple({'a': 1, 'b': 2}),
                namedtuple('NamedTuple', 'a b')(1, 2)
            )
            self.assertEqual(
                to_namedtuple({'a': 1, 3: {'b': 'c'}, 'd': [1, 2, 3]}),
                namedtuple('NamedTuple', 'a d')(1, [1, 2, 3])
            )

# Generated at 2022-06-21 12:52:29.797650
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2, 'c': 3}
    dic = to_namedtuple(dic)
    assert dic == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)
    assert dic.a == 1
    assert dic.b == 2
    assert dic.c == 3
    dic = dict(zip(('a', 'b', 'c'), (4, 5, 6)))
    dic = to_namedtuple(dic)
    assert dic == namedtuple('NamedTuple', 'a b c')(a=4, b=5, c=6)
    assert dic.a == 4
    assert dic.b == 5
    assert dic.c == 6
    dic = Ord

# Generated at 2022-06-21 12:52:37.449056
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple

    # ToDo: test conversion of mapping to namedtuple.
    # ToDo: test nested conversions with dicts and lists.
    # ToDo: test an OrderedDict
    # ToDo: test a MappingProxyType
    # ToDo: test a UserDict
    # ToDo: test a ChainMap
    # ToDo: test a dict view
    # ToDo: test a dict keys view
    # ToDo: test a dict values view
    # ToDo: test a dict items view
    # ToDo: test a defaultdict
    # ToDo: test a UserList
    # ToDo: test a UserString
    # ToDo: test a Deque
    # ToDo: test a FrozenSet


# Generated at 2022-06-21 12:52:42.425269
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import defaultdict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    obj0 = {
        '_a': 1,
        'a': 2,
        'b': {'b': 2, 'c': {'a': 1, 'b': 2}},
        'c': 'c',
    }
    obj1 = {'a': 1, 'b': 2}
    obj2 = [1, 2, 3, 4]
    obj3 = ['a', 'b']
    obj4 = (1, 2, 3, 4)
    obj5 = ('a', 'b')
    obj6 = (1, 2, 3, 4, ('a', 'b'))
    obj7 = ('a', {'a': 1, 'b': 2})

# Generated at 2022-06-21 12:52:53.941326
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    # Test SimpleNamespace conversion
    sns = SimpleNamespace(
        attr1=SimpleNamespace(a=1, b=2),
        attr2='attr2value',
        attr3=[1, 2, 3],
        attr4=OrderedDict((('a', 1), ('b', 2), ('c', [1, 2, 3]))),
        attr5=None,
        attr6=dict(a=1, b=2),
    )
    nt = to_namedtuple(sns)

# Generated at 2022-06-21 12:53:03.116800
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple(()), tuple)
    assert isinstance(to_namedtuple([]), list)
    assert isinstance(to_namedtuple({}), tuple)
    assert isinstance(to_namedtuple(OrderedDict()), tuple)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    assert to_namedtuple(OrderedDict(a=1, b=2)) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)

# Generated at 2022-06-21 12:53:14.473618
# Unit test for function to_namedtuple
def test_to_namedtuple():

    obj = [
        {
            'a': 1,
            'b': {
                'c': 2,
                'd': [
                    {
                        'e': 3,
                        'f': {
                            'g': 4,
                        },
                    },
                ],
            },
        },
        {
            'h': 5,
        },
    ]

    result = NamedTuple(
        a=1,
        b=NamedTuple(
            c=2,
            d=(
                NamedTuple(
                    e=3,
                    f=NamedTuple(
                        g=4,
                    ),
                ),
            ),
        ),
    )

    assert result == to_namedtuple(obj)[0]

    result = NamedTuple(
        h=5,
    )

    assert result

# Generated at 2022-06-21 12:53:23.087494
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''
    Unit tests for function to_namedtuple.
    '''

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple({'b': 2}) == namedtuple('NamedTuple', 'b')(2)
    assert to_namedtuple({'a': 1, 'b': 2}) == \
        namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'b': 2, 'a': 1}) == \
        namedtuple('NamedTuple', 'a b')(1, 2)

# Generated at 2022-06-21 12:53:34.302140
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:54:32.875110
# Unit test for function to_namedtuple
def test_to_namedtuple():
    orig = dict(foo=1, bar=2)
    out = to_namedtuple(orig)
    assert hasattr(out, 'foo')
    assert hasattr(out, 'bar')
    assert out.foo == 1
    assert out.bar == 2
    assert isinstance(out, namedtuple)

    orig = dict(foo=dict(a=1, b=2))
    out = to_namedtuple(orig)
    assert hasattr(out, 'foo')
    assert hasattr(out.foo, 'a')
    assert hasattr(out.foo, 'b')
    assert out.foo.a == 1
    assert out.foo.b == 2
    assert isinstance(out.foo, namedtuple)

    orig = dict(foo=dict(a=1, b=2), bar=True)


# Generated at 2022-06-21 12:54:42.181038
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Setup
    from textwrap import dedent as _dedent

    # Test invalid type
    with pytest.raises(TypeError):
        to_namedtuple(None)

    # Test various types

# Generated at 2022-06-21 12:54:47.307368
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(None) == None
    assert to_namedtuple(0) == 0
    assert to_namedtuple(1) == 1
    assert to_namedtuple('') == ''
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(()) == ()
    assert to_namedtuple((1,)) == (1,)
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple([]) == []
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple({}) == NamedTuple()

# Generated at 2022-06-21 12:54:52.766076
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    dic = {'a': 1, 'b': 2}
    # Act
    out = to_namedtuple(dic)
    # Assert
    assert out.a == 1
    assert out.b == 2
    assert out == namedtuple('NamedTuple', 'a b')(1, 2)

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:54:59.377370
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from flutils.namedtupleutils import to_namedtuple

    foo_dict = {'a': 1, 'b': 2, 'c': 3}
    obj = to_namedtuple(foo_dict)
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3
    assert len(obj) == 3
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3

    foo_dict = {'A': 1, 'B': 2, 'C': 3}
    obj = to_namedtuple(foo_dict)
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3
    assert len(obj) == 3
    assert obj.A == 1
    assert obj.B == 2