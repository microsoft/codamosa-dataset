

# Generated at 2022-06-21 12:45:16.677136
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == dic['a'] and out.b == dic['b']
    assert out == (1, 2)
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == dic['a'] and out.b == dic['b']
    assert out == (1, 2)
    dic = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    out = to_namedtuple(dic)

# Generated at 2022-06-21 12:45:27.799447
# Unit test for function to_namedtuple
def test_to_namedtuple():
    m = {'a': 1, 'b': 2, 'c': 3}
    ret = to_namedtuple(m)
    assert ret.a == 1
    assert ret.b == 2
    assert ret.c == 3
    m = {'_a': 1, '_b': 2, '_c': 3}
    ret = to_namedtuple(m)
    assert not hasattr(ret, 'a')
    assert not hasattr(ret, 'b')
    assert not hasattr(ret, 'c')
    m = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    m = OrderedDict(m)
    ret = to_namedtuple(m)
    assert ret[0] == 1
    assert m['a'] == 1
    assert ret[1]

# Generated at 2022-06-21 12:45:38.730180
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'x': [1, 2, 3]}) == \
        namedtuple('NamedTuple', 'x')([1, 2, 3])
    assert to_namedtuple({'x': 1, 'y': 2, 'z': 3}) == \
        namedtuple('NamedTuple', 'x y z')(1, 2, 3)
    assert to_namedtuple(OrderedDict([('x', 1), ('y', 2), ('z', 3)])) == \
        namedtuple('NamedTuple', 'x y z')(1, 2, 3)
    assert to_namedtuple({'x': 1, 'Y': 2, 'z': 3}) == \
        namedtuple('NamedTuple', 'x z')(1, 3)
    assert to_named

# Generated at 2022-06-21 12:45:43.151633
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple.
    """
    import pytest
    from _test.namedtupleutils import _test_to_namedtuple
    _test_to_namedtuple()
    with pytest.raises(TypeError):
        _ = to_namedtuple(1)

# Generated at 2022-06-21 12:45:53.839080
# Unit test for function to_namedtuple
def test_to_namedtuple():   # noqa: WPS438
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    obj = {'a': 1, '__b': 2}
    assert to_namedtuple(obj) == namedtuple('NamedTuple', 'a')(a=1)
    obj = {'a': 1, 'b_': 2}
    assert to_namedtuple(obj) == namedtuple('NamedTuple', 'a')(a=1)
    obj = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-21 12:46:04.805439
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class C:
        def __getitem__(self, item):
            pass

    obj1 = [1, 2, 3, 4]

    obj2 = to_namedtuple(obj1)
    assert obj1 == obj2
    assert isinstance(obj2, list)

    obj1 = (1, 2, 3, 4)

    obj2 = to_namedtuple(obj1)
    assert obj1 == obj2
    assert isinstance(obj2, tuple)

    obj3 = to_namedtuple(C())
    assert isinstance(obj3, tuple)

    obj1 = {'a': 1, 'b': 2}
    obj2 = to_namedtuple(obj1)
    assert hasattr(obj2, 'a')
    assert hasattr(obj2, 'b')

    obj3 = to_named

# Generated at 2022-06-21 12:46:17.754300
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyShadowingNames
    def _test(obj: Any, base_type: str) -> None:
        assert type(obj).__name__ == 'NamedTuple'
        assert obj.a == 1
        assert obj.b == 2
        if base_type == 'dict':
            assert obj == {'a': 1, 'b': 2}

    obj = {'a': 1, 'b': 2}
    _test(to_namedtuple(obj), 'dict')
    # noinspection PyTypeChecker
    obj: List[Any] = [{'a': 1, 'b': 2}, (1, 2), [1, 2]]
    obj = [obj, obj]
    out = to_namedtuple(obj)
    assert type(out).__name__ == 'list'



# Generated at 2022-06-21 12:46:29.997540
# Unit test for function to_namedtuple
def test_to_namedtuple():

    class obj(object):
        pass

    assert None == to_namedtuple(obj())

    class attr(object):
        def __init__(self, val):
            self.val = val

    expected_tuple = namedtuple('NamedTuple', ['val'])
    assert expected_tuple(1) == to_namedtuple(attr(1))

    expected_list = [expected_tuple(1)]
    assert expected_list == to_namedtuple([attr(1)])

    assert {'a': 1} == to_namedtuple({'a': 1})

    assert to_namedtuple({'a': 1}) == to_namedtuple(OrderedDict([('a', 1)]))


# Generated at 2022-06-21 12:46:34.499843
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 5}) == namedtuple('NamedTuple', 'a')(5)
    assert to_namedtuple({'a': 5, 'b': 6}) == namedtuple('NamedTuple', 'a,b')(5, 6)

    dic = {
        'a': 5,
        'b': {
            'x': 100,
            'y': 200,
    }}
    expected = namedtuple('NamedTuple', 'a,b')(
        5,
        namedtuple('NamedTuple', 'y,x')(
            200,
            100,
        )
    )
    assert to_namedtuple(dic) == expected

    dic = OrderedDict()
    dic['a'] = 5

# Generated at 2022-06-21 12:46:47.120659
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == dic['a']
    assert nt.b == dic['b']
    assert nt == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == dic['a']
    assert nt.b == dic['b']
    assert nt == NamedTuple(a=1, b=2)

    dic = {'_a': 1, 'b': 2}

# Generated at 2022-06-21 12:47:02.246507
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic: Dict = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out == NamedTuple(a=1, b=2)

    namedtup = NamedTuple(**dic)
    out = to_namedtuple(namedtup)
    assert out.a == 1
    assert out.b == 2
    assert out == NamedTuple(a=1, b=2)

    ns = SimpleNamespace(**dic)
    out = to_namedtuple(ns)
    assert out.a == 1
    assert out.b == 2
    assert out == NamedTuple(a=1, b=2)

    lis = [1, ns]
    out = to_named

# Generated at 2022-06-21 12:47:10.932827
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple

    tup = namedtuple('Tup', ['a', 'b'])
    seq = [1, 2, 3]
    dic = {'a': 1, 'b': 2}
    ntup = tup(4, 5)
    odic = OrderedDict([('a', 3), ('b', 4), ('c', 5)])
    lst = [1, 2, dic, tup(3, 4), odic]
    ns = SimpleNamespace()
    ns.a = seq
    ns.b = dic
    ns.c = tup
    ns.d = ntup
    ns.e = lst
    lst_out = to_namedtuple(lst)
    seq_

# Generated at 2022-06-21 12:47:22.917781
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import randint
    from random import shuffle
    from string import ascii_letters, ascii_uppercase
    from testfixtures import compare
    def _get_rand_char() -> str:
        rand = randint(0, len(ascii_letters) - 1)
        return ascii_letters[rand]
    def _get_rand_digit() -> int:
        return randint(1, 10)
    def _get_rand_chars() -> str:
        num = randint(1, 5)
        chars = [_get_rand_char() for _ in range(num)]
        return ''.join(chars)
    def _get_rand_num() -> int:
        return randint(1, 10)

# Generated at 2022-06-21 12:47:33.182913
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]) == [
        NamedTuple(a=1, b=2), NamedTuple(c=3, d=4)
    ]
    assert to_namedtuple((
        {'a': 1, 'b': 2},
        {'c': 3, 'd': 4}
    )) == (
        NamedTuple(a=1, b=2),
        NamedTuple(c=3, d=4)
    )

# Generated at 2022-06-21 12:47:42.999077
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import random
    import string
    import unittest

    from unittest import TestCase

    from flutils.namedtupleutils import to_namedtuple

    # Let's make a function for validating types...
    def _isinstance(arg: Any, arg_type: Any):
        try:
            assert isinstance(arg, arg_type)
        except AssertionError:
            raise TypeError(
                "Expected: %r -- Got: %r" % (arg_type.__name__, type(arg).__name__)
            )


    # ...and a function for validating attributes...

# Generated at 2022-06-21 12:47:54.327470
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from typing import (
        List,
        Dict,
    )
    from types import SimpleNamespace
    from flutils.testutils import (
        RaisingAssertions,
    )

    _global = RaisingAssertions()

    def _test(
            test_obj: Union[NamedTuple, List, Tuple, OrderedDict, SimpleNamespace],
            expected_obj: Union[NamedTuple, List, Tuple],
            obj_type: str,
    ) -> None:
        name = '%s: %r' % (obj_type, test_obj)
        _print = RaisingAssertions(name)
        _print(test_obj, expected_obj)

# Generated at 2022-06-21 12:48:02.991400
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    dic = {'a': 1, 'b': 2}
    lst = [dic, SimpleNamespace(**dic)]

    # Action
    tup = to_namedtuple(lst)

    # Assert
    assert isinstance(tup, tuple)
    assert len(tup) == 2

    assert isinstance(tup[0], NamedTuple)
    assert len(tup[0]) == 2
    assert type(tup[0][0]) == int
    assert tup[0][0] == 1

    assert isinstance(tup[1], NamedTuple)
    assert len(tup[1]) == 2
    assert type(tup[1][0]) == int
    assert tup[1][0] == 1

# Generated at 2022-06-21 12:48:06.298023
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(
        to_namedtuple({'foo': 'bar', 'baz': 'quux'}),
        NamedTuple
    )


# Make sure it errors out on non-namedtuples

# Generated at 2022-06-21 12:48:16.214687
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""

    def convert(obj: Any) -> NamedTuple:
        return to_namedtuple(obj)

    class Test:
        # noinspection PyUnusedLocal,PyMissingConstructor
        def __init__(self, **kwargs: Any) -> None:
            pass
        def __getattr__(self, item: str) -> Any:
            return item

    # type: NamedTuple
    assert convert({'a': 1, 'b': 2}) == to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))

    # type: NamedTuple
    assert convert({'a': 1, 'b': 2}) == to_namedtuple(SimpleNamespace(**{'a': 1, 'b': 2}))

    # type: NamedT

# Generated at 2022-06-21 12:48:18.818577
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.tests.namedtupleutils import test_to_namedtuple
    test_to_namedtuple()

# Generated at 2022-06-21 12:48:31.287083
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    import operator as op
    
    # Error checking
    with pytest.raises(TypeError):
        to_namedtuple(None)
    with pytest.raises(TypeError):
        to_namedtuple(op)
    with pytest.raises(TypeError):
        to_namedtuple([None, op])

    # Empty dictionary should return an empty tuple
    assert to_namedtuple({}) == ()        
    
    # List should return a tuple
    empty_list = to_namedtuple([])
    assert type(empty_list) == tuple
    assert empty_list == ()
    
    # Tuple should not be changed
    tup = to_namedtuple((5,))
    assert type(tup) == tuple
    assert tup == (5,)
    
    #

# Generated at 2022-06-21 12:48:39.209694
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple(('a', 'b')) == ('a', 'b')

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    od = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(od) == NamedTuple(a=1, b=2)

    od = OrderedDict([('a', 1), ('b', 2), ('1', 3)])
    assert to_namedtuple(od) == NamedTuple(a=1, b=2, _1=3)

# Generated at 2022-06-21 12:48:51.198538
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    """ Testing to_namedtuple. """
    import sys
    import typing

    def _assert_namedtuple(
            name: str,
            dictionary: Mapping,
            nt: typing.Type[NamedTuple],
    ) -> None:
        """ Assert the given namedtuple. """
        for key, val in dictionary.items():
            if hasattr(key, 'capitalize'):
                key = cast(str, key)
                if key.startswith('_'):
                    continue
            assert hasattr(nt, key), \
                "Expected '%s' to have attribute '%s' but it doesn't" \
                % (name, key)
            ntval = getattr(nt, key)

# Generated at 2022-06-21 12:49:02.838529
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {
        'a': 1,
        'b': 2
    }
    result = to_namedtuple(obj)
    assert isinstance(result, NamedTuple)
    assert result.a == 1
    assert result.b == 2

    obj = {
        'a': {
            'b': 2,
            'c': 3
        },
        'd': 4
    }
    result = to_namedtuple(obj)
    assert isinstance(result, NamedTuple)
    assert isinstance(result.a, NamedTuple)
    assert result.a.b == 2
    assert result.a.c == 3
    assert result.d == 4


# Generated at 2022-06-21 12:49:15.240326
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.typesutils import is_namedtuple
    from unittest import TestCase

    class Test(TestCase):
        def test_nonetype(self):
            with self.assertRaises(TypeError):
                to_namedtuple(None)

        def test_namedtuple(self):
            NamedTuple = namedtuple('NamedTuple', ('a',))
            obj = {'a': 1}
            out = to_namedtuple(obj)
            self.assertEqual(out.a, 1)
            self.assertIsInstance(out, NamedTuple)

            obj = NamedTuple(a=1)
            out = to_namedtuple(obj)
            self.assertEqual

# Generated at 2022-06-21 12:49:26.473044
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    with pytest.raises(TypeError) as excinfo:
        to_namedtuple(1)
    assert "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (int) 1" in str(excinfo.value)

    assert to_namedtuple(dict(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)

    assert to_namedtuple(dict(a=1, b=2, _id=3)) == namedtuple('NamedTuple', ['a', 'b', '_id'])(a=1, b=2, _id=3)


# Generated at 2022-06-21 12:49:39.825806
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 3,
        'c': {
            'a': 1,
            'b': 2,
            'c': [
                {
                    'a': 1,
                    'b': 2,
                    'c': 3,
                    'd': [
                        1,
                        2,
                        3,
                        {
                            'a': 1,
                            'b': 2,
                            'c': 3,
                        }
                    ],
                },
            ],
        },
        'd': 5,
    }

# Generated at 2022-06-21 12:49:51.930184
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for function to_namedtuple """
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testhelpers import make_tempdirs
    from flutils.validators import validate

    from importlib import resources
    with resources.path('flutils.testdata', 'test_namedtupleutils.py') as fpath:
        with open(fpath, 'r') as fp:
            data = fp.read()

# Generated at 2022-06-21 12:50:01.255587
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:50:09.709786
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for function to_namedtuple."""
    import pytest

    def _assert_is_namedtuple(obj: Any, name: str = 'NamedTuple'):
        assert hasattr(obj, '_fields')
        assert isinstance(obj._fields, tuple)
        assert obj.__class__.__name__ == name

    def _assert_all_namedtuples(obj: Any, name: str = 'NamedTuple'):
        _assert_is_namedtuple(obj, name)
        for item in obj:
            _assert_is_namedtuple(item, name)

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    _assert_is_namedtuple(out)

# Generated at 2022-06-21 12:50:27.808677
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import defaultdict
    dic = {'a': 1, 'b': 2}
    nt1 = to_namedtuple(dic)
    assert nt1.a == 1
    assert nt1.b == 2
    dic2 = {'a': 1, 'b': 2, 'c': {'a': 3, 'b': 4}}
    nt2 = to_namedtuple(dic2)
    assert nt2.a == 1
    assert nt2.b == 2
    assert nt2.c.a == 3

    dic3 = {'a': 1, 'b': 2, 'c': {'0a': 3, 'b': 4}}
    nt3 = to_namedtuple(dic3)
    assert nt3.a == 1
    assert nt

# Generated at 2022-06-21 12:50:38.625009
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import logging
    import sys
    import unittest
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testutils import TestBase

    logger = logging.getLogger(__name__)
    if logger.level == 0:
        # noinspection PyArgumentList
        logger.setLevel(logging.INFO)
    logger.addHandler(logging.NullHandler())

    class TestNamedTupleUtils(TestBase):
        """Unit tests for to_namedtuple function."""

        def setUp(self):
            super().setUp()

        def test_to_namedtuple(self):
            """Test to_namedtuple function."""
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)

# Generated at 2022-06-21 12:50:39.916054
# Unit test for function to_namedtuple
def test_to_namedtuple():
    raise NotImplementedError()

# Generated at 2022-06-21 12:50:51.196199
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test for function to_namedtuple()."""
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert isinstance(result, namedtuple('NamedTuple', 'a b')), \
        'Failed converting dict to namedtuple; got: %s' % result

    dic = OrderedDict((('a', 1), ('b', 2)))
    result = to_namedtuple(dic)
    assert isinstance(result, namedtuple('NamedTuple', 'a b')), \
        'Failed converting OrderedDict to namedtuple; got: %s' % result

    lis = [1, 2, 3]

# Generated at 2022-06-21 12:51:03.338878
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    dic1 = {'a': 1, 'b': 2}
    dic2 = {'a': 1, 'b': 2}
    dic3 = {'a': 1, 'b': 2}
    dic4 = {'a': 1, 'b': 2}
    dic5 = {'a': 1, 'b': 2}
    dic6 = {'a': 1, 'b': 2}
    list1 = [dic1, dic2, dic3]
    list2 = [dic4, dic5, dic6]
    tuple1 = (dic1, dic2, dic3)
    tuple2 = (dic4, dic5, dic6)


# Generated at 2022-06-21 12:51:06.135447
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=True)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:51:16.598293
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import os
    import json
    import pytest

    def _run_test(data: Union[dict, list, tuple], output: NamedTuple):
        actual = to_namedtuple(data)
        assert isinstance(actual, NamedTuple)
        assert len(actual) == len(output)
        assert actual == output

    test_inputs = json.loads(os.environ['TEST_NAMED_TUPLE'])
    for test in test_inputs:
        data = test['input']
        output = test['output']
        if isinstance(data, (dict, list)):
            data = json.loads(data)
        else:
            data = eval(data)
        yield _run_test, data, output


if __name__ == '__main__':
    import os
    import py

# Generated at 2022-06-21 12:51:22.704067
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import typing
    import pytest

    def test_bad_type():
        t = {'a': 1, 'b': 2.0}
        with pytest.raises(TypeError) as excinfo:
            to_namedtuple(t)
        assert excinfo.type is TypeError
        assert "... to a NamedTuple; " in str(excinfo.value)
        assert "dict" in str(excinfo.value)

    def test_bad_type_list():
        t = ['a', 1, 'b', 2.0]
        with pytest.raises(TypeError) as excinfo:
            to_namedtuple(t)
        assert excinfo.type is TypeError
        assert "... to a NamedTuple;" in str(excinfo.value)
        assert "list" in str(excinfo.value)



# Generated at 2022-06-21 12:51:26.205465
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple("foo") == "foo"
    assert to_namedtuple("foo") == "foo"
    return

test_to_namedtuple()

# Generated at 2022-06-21 12:51:36.089646
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    BLAH = {
        '_keyword': 'blah',
        'val': {'a': 1, 'b': 2},
        'more': {
            'asd': 'asd',
            'd': {'key': 'value'},
        },
        'start': True,
    }

    TESTCASE1 = (
        {
            '_keyword': 'blah',
            'val': {'a': 1, 'b': 2},
            'more': {
                'asd': 'asd',
                'd': {'key': 'value'},
            },
            'start': True,
        },
        ('_keyword', 'val', 'more', 'start'),
    )


# Generated at 2022-06-21 12:51:58.312529
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    namedtuple_ = to_namedtuple({'en': 'EN'})
    assert isinstance(namedtuple_, NamedTuple)

    namedtuple_ = to_namedtuple({'en': 'EN', 'fr': 'FR', 'ru': 'RU'})
    assert isinstance(namedtuple_, NamedTuple)
    assert namedtuple_.en == 'EN'
    assert namedtuple_.fr == 'FR'
    assert namedtuple_.ru == 'RU'

    namedtuple_ = to_namedtuple(
        OrderedDict((
                    ('en', 'EN'),
                    ('fr', 'FR'),
                    ('ru', 'RU'),
                ))
    )

# Generated at 2022-06-21 12:52:08.598121
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from flutils.namedtupleutils import to_namedtuple
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    expected = namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    assert out == expected

    dic = SimpleNamespace(a=1, b=2)
    out = to_namedtuple(dic)
    expected = namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    assert out == expected


# Generated at 2022-06-21 12:52:13.269364
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """

    .. testsetup::

        from flutils.namedtupleutils import to_namedtuple


    .. doctest::

        >>> dic = {'a': 1, 'b': 2}
        >>> to_namedtuple(dic)
        NamedTuple(a=1, b=2)

    """



# Generated at 2022-06-21 12:52:24.347806
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple

    tp = type(
        to_namedtuple({})
    )
    tp2 = type(
        to_namedtuple(SimpleNamespace())
    )
    assert tp is tp2

    # noinspection PyTypeChecker
    assert type(
        to_namedtuple({'a': 1, 'b': 2})
    ) is to_namedtuple._to_namedtuple.registry[Mapping]

    # noinspection PyTypeChecker
    assert type(
        to_namedtuple([])
    ) is to_namedtuple._to_namedtuple.registry[list]

    # noinspection PyTypeChecker

# Generated at 2022-06-21 12:52:35.012610
# Unit test for function to_namedtuple
def test_to_namedtuple():
    nt0 = to_namedtuple([{'a': {'b': {'c': 42}}, 'd': [{'e': 1}, {'f': 2}]}])
    assert nt0[0] == NamedTuple(a=NamedTuple(b=NamedTuple(c=42)), d=[NamedTuple(e=1), NamedTuple(f=2)])

    nt1 = to_namedtuple({'a': {'b': {'c': 42}}, 'd': [{'e': 1}, {'f': 2}]})
    assert nt1.a == NamedTuple(b=NamedTuple(c=42))
    assert nt1.d == [NamedTuple(e=1), NamedTuple(f=2)]

# Generated at 2022-06-21 12:52:46.913028
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, tuple)
    assert 'a' in out._fields
    assert 'b' in out._fields
    assert out.a == 1
    assert out.b == 2
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert isinstance(out, list)
    assert len(out) == 3
    assert out[0] == 1
    assert out[1] == 2
    assert out[2] == 3
    dic = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2}}
    out = to_namedtuple(dic)
    assert isinstance(out, tuple)


# Generated at 2022-06-21 12:52:57.988962
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    od = OrderedDict()
    dic = {'a': 1, 'b': 2}
    od['a'] = 1
    od['b'] = 2
    od['c'] = 3
    ns = SimpleNamespace()
    ns.a = 1
    ns.b = 2
    ns.c = 3
    tp = (1, 2,)
    lis = [1, 2]

    assert to_namedtuple(dic) == to_namedtuple(od)
    assert to_namedtuple(dic) == to_namedtuple(ns)
    assert to_namedtuple(tp) == to_namedtuple(lis)


if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-21 12:53:09.522404
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from itertools import combinations

    dic = {
        'b': 1,
        'c': 2,
        'a': {
            'd': 3,
            'e': 4,
        },
    }

    for n in range(0, len(dic) + 1):
        for indices in combinations(range(0, len(dic)), n):
            for i in indices:
                key = list(dic)[i]
                dic[key] = to_namedtuple(dic[key])
            dic = to_namedtuple(dic)
            assert isinstance(dic.a.d, int)
            assert isinstance(dic.a.e, int)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:53:20.505656
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import List

    # 1: Convert dictionary to NamedTuple
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert 'a' in dir(out)
    assert 'b' in dir(out)
    assert out.a == 1
    assert out.b == 2

    # 2: Convert dictionary to NamedTuple (remove leading underscore key)
    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)


# Generated at 2022-06-21 12:53:28.301369
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for function to_namedtuple.
    """
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        def test_to_namedtuple_empty_mapping(self):
            """ Unit test for to_namedtuple.
            """
            from collections import namedtuple
            from types import SimpleNamespace

            NamedTuple = namedtuple('NamedTuple', '')
            test = {}
            expected = NamedTuple()

            out = to_namedtuple(test)

            self.assertEqual(out, expected)

        def test_to_namedtuple_empty_namespace(self):
            """ Unit test for to_namedtuple.
            """
            from collections import namedtuple
            from types import SimpleNamespace

            NamedTuple = namedtuple

# Generated at 2022-06-21 12:53:54.923798
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('_', ['a', 'b'])(a=1, b=2)

# Generated at 2022-06-21 12:54:02.152814
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    obj = OrderedDict({'b': 2, 'a': 1})
    assert to_namedtuple(obj) == NamedTuple(b=2, a=1)
    assert to_namedtuple([1, 2, 'a']) == [1, 2, 'a']
    assert to_namedtuple([1, 2, {'a': 1, 'b': 2}]) == [1, 2, NamedTuple(a=1, b=2)]
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]

# Generated at 2022-06-21 12:54:11.716347
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace

    # Test with a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    for item in out:
        assert isinstance(item, namedtuple)

    # Test with a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    for item in out:
        assert isinstance(item, namedtuple)

    # Test with a dict
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert isinstance(out, namedtuple)

    # Test

# Generated at 2022-06-21 12:54:22.774177
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    from flutils.collectionsutils import to_list
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-21 12:54:32.458406
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyProtectedMember
    import _testcapi
    obj = _testcapi.make_named_tuple('NamedTuple', 'a b c', (1, 2, 3))
    assert isinstance(obj, SimpleNamespace)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3
    nt = to_namedtuple(obj)
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3
    obj = _testcapi.make_named_tuple('NamedTuple', '', ())
    assert isinstance(obj, SimpleNamespace)
    assert not hasattr(obj, 'a')
    assert not hasattr(obj, 'b')
   

# Generated at 2022-06-21 12:54:42.126037
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple as nt
    from types import SimpleNamespace as ns
    from flutils.namedtupleutils import to_namedtuple as tnt

    class Foo:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __repr__(self):
            return repr(self.__dict__)

    def _test(orig, expected):
        """
        :type orig: dict, tuple, list, namedtuple, SimpleNamespace
        :type expected: dict, tuple, list, namedtuple, SimpleNamespace
        """
        if isinstance(orig, dict):
            assert isinstance(tnt(orig), nt)
            assert isinstance(expected, dict)

# Generated at 2022-06-21 12:54:45.355093
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple([]) == []
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple(1) == 1



# Generated at 2022-06-21 12:54:52.487985
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = OrderedDict([('a', 1), ('b', 'a'), ('c', {'b': 3}), ('d', 'str'),
                       ('e', ['a', 2, {'b': 'x'}])])
    results = to_namedtuple(dic)
    exp = [1, 'a', NamedTuple(b=3), 'str', ['a', 2, NamedTuple(b='x')]]
    assert results == exp
    print('Test Passed')

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:54:58.365994
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    dic = {'a': 1, 'b': 2}
    to_namedtuple(dic)
    odict = OrderedDict(dic)
    to_namedtuple(odict)
    lis = [1, 2, 3]
    to_namedtuple(lis)
    tup = (1, 2, 3)
    to_namedtuple(tup)
    item = 1
    with pytest.raises(TypeError):
        to_namedtuple(item)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])