

# Generated at 2022-06-21 12:45:09.034653
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import datetime as dt
    test_list = [
        {'a': 1, 'b': 2},
        {'a': 1, 'c': 3},
        {'b': 2, 'c': 3},
    ]
    test_dt = dt.datetime.now()

# Generated at 2022-06-21 12:45:19.364276
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    obj = {'a': 1, 'b': 2, '_c': 3}
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(obj) == expected
    obj = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(obj) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)
    obj = {'a': 1, 'b': 2, 'c': 3, '_c': 4}
    assert to_namedtuple(obj) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)
    obj

# Generated at 2022-06-21 12:45:30.369182
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a_list = [
        [1, 2],
        [3, 4]
    ]
    a_list_out = to_namedtuple(a_list)
    assert isinstance(a_list_out[0], tuple)
    assert a_list_out[0] == (1, 2)

    a_tuple = (
        [1, 2],
        [3, 4]
    )
    a_tuple_out = to_namedtuple(a_tuple)
    assert isinstance(a_tuple_out[0], tuple)
    assert a_tuple_out[0] == (1, 2)

    a_dict = {'a': 1, 'b': 2}
    a_dict_out = to_namedtuple(a_dict)

# Generated at 2022-06-21 12:45:37.261330
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    with_underscore = {'a': 1, 'b': 2, '_c': 3}
    named = SimpleNamespace(a=1, b=2, _c=3)
    order = OrderedDict(a=1, b=2, _c=3)
    tuple_ = ('a', 1, 'b', 2, '_c', 3)
    list_ = ['a', 1, 'b', 2, '_c', 3]
    nested_list = ['a', 1, ['b', 2]]
    complex_dict = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2}, 'd': [1, 2, 3]}

    out = to_namedtuple(dic)
    assert isinstance

# Generated at 2022-06-21 12:45:46.709862
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert nt.a == 1
    assert hasattr(nt, 'b')
    assert nt.b == 2

    dic = {'a': 1, 'b': {'c': 3}}
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert nt.a == 1
    assert hasattr(nt, 'b')
    assert hasattr(nt.b, 'c')
    assert nt.b.c == 3

    dic = OrderedDict([('a', 1), ('b', 2)])
    nt

# Generated at 2022-06-21 12:45:52.752191
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyProtectedMember
    import inspect
    import sys
    import unittest.mock as mock

    from flutils.namedtupleutils import _to_namedtuple, to_namedtuple

    # noinspection PyProtectedMember
    from flutils.namedtupleutils import _AllowedTypes as _AllowedTypes
    from flutils.namedtupleutils import _to_namedtuple as _to_namedtuple_orig

    # Create the namespace for the imported module
    module_name = inspect.currentframe().f_code.co_name
    import_name = inspect.currentframe().f_code.co_filename.replace('.py', '')
    namespace = sys.modules[module_name]
    namespace.__name__ = import_name

    # noinspection PyProtectedMember

# Generated at 2022-06-21 12:46:04.205586
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest


# Generated at 2022-06-21 12:46:16.189341
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2, 'c': {'d': {'e': 1, 'f': 2}}}
    res = to_namedtuple(dic)
    assert res.a == 1
    assert res.b == 2
    assert res.c.d.e == 1
    assert res.c.d.f == 2
    assert isinstance(res, NamedTuple)
    assert isinstance(res.c, NamedTuple)
    assert isinstance(res.c.d, NamedTuple)
    assert res.keys() == ['a', 'b', 'c']
    assert res.c.keys() == ['d']


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:46:25.128632
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import types
    import pytest

    dic = {'a': 1, 'b': 2}

    x = to_namedtuple(dic)
    assert x.a == 1
    assert x.b == 2

    # noinspection PyTypeChecker
    dic = OrderedDict([
        ('a', [1, 2]),
        ('b', [3, 4]),
        ('c', {'d': 'd'})
    ])

    # noinspection PyTypeChecker
    x = to_namedtuple(dic)
    assert x.a[0] == 1
    assert x.a[1] == 2
    assert x.b[0] == 3
    assert x.b[1] == 4

# Generated at 2022-06-21 12:46:26.209171
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:46:33.463878
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert isinstance(obj, NamedTuple)
    assert isinstance(obj.a, int)
    assert isinstance(obj.b, int)


if __name__ == '__main__':
    from flutils.scripts.utils import run_doctest
    run_doctest()

# Generated at 2022-06-21 12:46:46.311698
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(tuple([{'a': 1, 'b': 2}])) == (
        NamedTuple(a=1, b=2),
    )
    assert to_namedtuple(list([{'a': 1, 'b': 2}])) == [
        NamedTuple(a=1, b=2),
    ]

# Generated at 2022-06-21 12:46:58.059513
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    assert to_namedtuple(list()) == []
    assert to_namedtuple(tuple()) == ()

    dic = dict(a=1, b=2)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', sorted(dic))(*dic.values())
    assert to_namedtuple(OrderedDict(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(*dic.values())
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == namedtuple('NamedTuple', sorted(dic))(*dic.values())


# Generated at 2022-06-21 12:47:05.124939
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest.mock
    dic = {'a': 1, 'b': 2}
    exp = 'flutils.namedtupleutils._to_namedtuple(dict)'
    with unittest.mock.patch(exp) as mock_c:
        _ = to_namedtuple(dic)
        mock_c.assert_called_once()
    _ = to_namedtuple(dic)



# Generated at 2022-06-21 12:47:16.217312
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    tup = (4, 5, 6)
    nt: NamedTuple = to_namedtuple(tup)
    assert nt._fields == ('_0', '_1', '_2')
    assert nt._0 == 4
    assert nt._1 == 5
    assert nt._2 == 6

    dic = OrderedDict([('d', 3), ('a', 1), ('b', 2)])
    nt = to_namedtuple(dic)
    assert nt._fields == ('a', 'b', 'd')
    assert nt.a == 1
    assert nt.b == 2
    assert nt.d == 3


# Generated at 2022-06-21 12:47:20.517535
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import date
    from decimal import Decimal
    from flutils.namedtupleutils import to_namedtuple
    from flutils.randomutils import generate_random_codename
    from dataclasses import dataclass
    from typing import Optional

    @dataclass
    class Person:
        name: str
        age: int
        dob: Optional[date] = None

    @dataclass
    class Instructor:
        name: str
        age: int
        dob: Optional[date] = None
        students: Optional[List[Person]] = None

    @dataclass
    class Classroom:
        course: str
        instructor: Instructor
        students: List[Person]
        cost: Decimal

    # Make dataclasses
    person1 = Person('Alice', 24)

# Generated at 2022-06-21 12:47:30.198988
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple('') == ''
    assert to_namedtuple('abc') == 'abc'
    assert to_namedtuple('abc1') == 'abc1'

    obj = tuple(['a', 'b', 'c'])
    assert to_namedtuple(obj) == obj

    obj = list('abc')
    assert to_namedtuple(obj) == obj

    assert to_namedtuple({}) == None

    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)

    obj = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2, c=3)


# Generated at 2022-06-21 12:47:39.678872
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple([]) == []
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple(NamedTuple()) == NamedTuple()
    assert to_namedtuple(NamedTuple(a=1, b=2)) == NamedTuple

# Generated at 2022-06-21 12:47:48.908827
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2}, another=3) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict({'a': 1, 'b': 2})) == NamedTuple(a=1, b=2)
    assert to_named

# Generated at 2022-06-21 12:48:00.730131
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': {}, 'b': 2}) == NamedTuple(a=NamedTuple(), b=2)
    assert to_namedtuple({'a': {'b': {'c': 3}}, 'd': 4}) == NamedTuple(a=NamedTuple(b=NamedTuple(c=3)), d=4)
    assert to_namedtuple({'a': [1, 2, 3], 'b': 4}) == NamedTuple(a=[1, 2, 3], b=4)
    assert to_namedtuple({'a': (1, 2, 3), 'b': 4}) == NamedTuple(a=(1, 2, 3), b=4)

# Generated at 2022-06-21 12:48:16.134670
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'a': 1, 'b': {'c': 3, 'd': 4, 5: 6}}) == namedtuple('NamedTuple', 'a b')(1, namedtuple('NamedTuple', 'c d 5')(3, 4, 6))
    assert to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4, 5: 6}]) == [namedtuple('NamedTuple', 'a b')(1, 2), namedtuple('NamedTuple', 'c d 5')(3, 4, 6)]

# Generated at 2022-06-21 12:48:27.555771
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections.abc import (
        Mapping,
        Sequence,
    )
    from typing import (
        Any,
        Dict,
        List,
        Tuple,
        Union,
    )
    # noinspection PyProtectedMember,PyUnusedLocal
    def _test_obj(obj: Any, expected: Any) -> None:
        actual = to_namedtuple(obj)
        exp_cnt = len(expected)
        act_cnt = len(actual)
        assert act_cnt == exp_cnt, (obj, actual, expected)
        idx = 0
        while idx < exp_cnt:
            exp_item = expected[idx]
            act_item = actual[idx]

# Generated at 2022-06-21 12:48:37.242252
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': [1, 2], 'c': 'abc'}
    ntdic = to_namedtuple(dic)
    assert ntdic == NamedTuple(a=1, b=(1, 2), c='abc')
    assert isinstance(ntdic.b, tuple)

    odic = OrderedDict ([('a', 1), ('b', 2), ('c', 3)])
    ntoc = to_namedtuple(odic)
    assert ntoc == NamedTuple(a=1, b=2, c=3)


# Generated at 2022-06-21 12:48:49.529131
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    def test_to_namedtuple_inner(
            obj: Union[List, Tuple, Mapping],
            expected: Union[List, Tuple, Mapping]
    ):
        # noinspection PyUnresolvedReferences
        res = to_namedtuple(obj)
        assert res == expected


# Generated at 2022-06-21 12:49:01.553037
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2


# Generated at 2022-06-21 12:49:12.738652
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2.0}) == namedtuple('NamedTuple', 'a b')(a=1, b=2.0)
    assert to_namedtuple({'a': 1, 'b': 2.0, 'c': 'c'}) == namedtuple('NamedTuple', 'a b c')(a=1, b=2.0, c='c')

# Generated at 2022-06-21 12:49:20.880421
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    with pytest.raises(SyntaxError):
        validate_identifier('a.b.c')
    dic = {'a.b.c': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.b == 2
    dic = {'a': 1, '_b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert not hasattr(obj, '_b')
    dic = {'a': 1, '_b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-21 12:49:30.098147
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import (
        datetime,
        timezone,
    )
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from flutils.tests import cases
    from flutils.timestringutils import (
        epoch_to_datetime,
        epoch_to_timestamp
    )


# Generated at 2022-06-21 12:49:42.080770
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test given nothing
    with pytest.raises(TypeError):
        to_namedtuple(None)

    # Test given an integer
    with pytest.raises(TypeError):
        to_namedtuple(0)

    # Test with an empty dictionary
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()

    # Test with an ordered dictionary
    odic = OrderedDict()
    odic['a'] = 1
    odic['b'] = 2
    odic['c'] = 3
    assert to_namedtuple(odic) == namedtuple('NamedTuple', 'a b c')(1, 2, 3)

    # Test with a regular dictionary

# Generated at 2022-06-21 12:49:42.875716
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-21 12:49:59.871878
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class Test(unittest.TestCase):
        def setUp(self) -> None:
            self.dic = {
                'a': 1,
                'b': 2,
                'c': [3, 4, 5],
                'd': {
                    'd1': 6,
                    'd2': 7,
                }
            }
            self.mapping = {
                'a': 1,
                'b': 2,
                'c': [3, 4, 5],
                'd': {
                    'd1': 6,
                    'd2': 7,
                    '_d3': 8,
                    '$d4': 9,
                }
            }


# Generated at 2022-06-21 12:50:08.729912
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    val = to_namedtuple(dic)
    assert isinstance(val, NamedTuple)
    assert val.a == 1
    assert val.b == 2
    orddic = OrderedDict(dic)
    val1 = to_namedtuple(orddic)
    assert isinstance(val1, NamedTuple)
    assert val1.a == 1
    assert val1.b == 2
    assert list(val1._fields) == ['a', 'b']
    val2 = to_namedtuple(list(orddic.keys()))
    assert isinstance(val2, NamedTuple)
    assert len(val2._fields) == 2
    assert val2[0] == 'a'

# Generated at 2022-06-21 12:50:11.382765
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # coverage: exclude
    """Unit test for function to_namedtuple."""
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 12:50:24.359890
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict
    )
    from types import (
        SimpleNamespace
    )
    from pprint import pformat as pf

    from flutils.namedtupleutils import (
        to_namedtuple
    )

    from flutils.testingutils import (
        AssertCallableIsEqual,
        AssertTypedDict
    )

    def get_type(obj):
        return type(obj).__name__

    # noinspection PyShadowingNames
    def assert_nt_equal(nt1: NamedTuple, nt2: NamedTuple):
        # noinspection PyArgumentList
        err = AssertCallableIsEqual(
            nt1,
            nt2,
            lambda got, exp: got._fields == exp._fields
        )

# Generated at 2022-06-21 12:50:32.410731
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:50:44.305224
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    test_name: str = 'to_namedtuple'

    lst: List[Any] = [
        [1, 2, 3],
        'a',
    ]
    tup: Tuple[Any, ...] = (
        (1, 2, 3),
        'a',
        {'a': 1},
        OrderedDict({'b': 2}),
        SimpleNamespace(c=3),
    )
    dic = {'one': 1, 'two': 2}
    odic = OrderedDict({'one': 1, 'two': 2})
    snd = SimpleNamespace(one=1, two=2)

# Generated at 2022-06-21 12:50:53.909214
# Unit test for function to_namedtuple
def test_to_namedtuple():

    class TestClass:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

        def __str__(self):
            return f"TestClass(a={self.a!r}, b={self.b!r})"

    list_data = [1, 2, 3, 4, 5]
    assert to_namedtuple(list_data) == list_data

    tuple_data = (1, 2, 3, 4, 5)
    assert to_namedtuple(tuple_data) == tuple_data

    test_namedtuple = namedtuple('test_namedtuple', ['a', 'b', 'c'])
    namedtuple_data = test_namedtuple(1, 2, 3)

# Generated at 2022-06-21 12:51:06.241498
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple({'a': 1, 'b': 2, '_c': {}.keys(), 'c': {}.values()}) == \
           NamedTuple(a=1, b=2, c=())
    assert to_namedtuple({'a': 1, 'b': 2, '_c': {}}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'_a': 1, 'b': 2}) == NamedTuple

# Generated at 2022-06-21 12:51:16.674061
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    seq = (1, 2, 3)
    assert to_namedtuple(seq) == NamedTuple(a=1, b=2, c=3)

    test_obj = SimpleNamespace(**dic)
    assert to_namedtuple(test_obj) == NamedTuple(a=1, b=2)

    test_obj = SimpleNamespace(**{'a': 1})
    assert to_namedtuple(test_obj) == NamedTuple(a=1)

    test_obj = [dic, dic]

# Generated at 2022-06-21 12:51:22.765310
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import patch
    from types import SimpleNamespace

    PatchType = SimpleNamespace(spec=['called'], called=False)
    patch_dict = PatchType()
    patch_sequence = PatchType()
    patch_simple_namespace = PatchType()

    # noinspection DuplicatedCode
    def mock_none(*args, **kwargs):
        # noinspection PyUnresolvedReferences
        patch_dict.called = True

    # noinspection DuplicatedCode
    def mock_list(*args, **kwargs):
        # noinspection PyUnresolvedReferences
        patch_sequence.called = True

    # noinspection DuplicatedCode
    def mock_simple_namespace(*args, **kwargs):
        # noinspection PyUnresolvedReferences
        patch_simple_namespace.called = True

# Generated at 2022-06-21 12:51:39.415048
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace as SN

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(a=1)
    assert (
        to_namedtuple({'a': 1, 'b': 2})
        == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    )

    assert to_namedtuple({'c': 1, 'b': 2, 'a': 3}) == namedtuple(
        'NamedTuple', 'a b c'
    )(a=3, b=2, c=1)


# Generated at 2022-06-21 12:51:45.660419
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == (1, 2)
    dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    assert to_namedtuple(dic) == (1, 3, 4)
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple((1, [2, 3, 4], {'d': 5})) == (1, 2, 3, 4, 5)

# Generated at 2022-06-21 12:51:57.171195
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test conversion of object types to a namedtuple."""
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    try:
        x = nt.a
    except AttributeError:
        raise AssertionError("NamedTuple attribute 'a' missing")
    try:
        x = nt.b
    except AttributeError:
        raise AssertionError("NamedTuple attribute 'b' missing")
    try:
        x = nt.c
    except AttributeError:
        pass
    else:
        raise AssertionError("NamedTuple attribute 'c' should not exist")
    try:
        x = nt.d
    except AttributeError:
        pass


# Generated at 2022-06-21 12:52:03.167588
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit tests for the to_namedtuple function"""
    from collections import namedtuple
    from pprint import pprint

    test_data = {"target": "test", "proto": "http", "port": 80, "host": "test.test.test"}
    expected_out = namedtuple('NamedTuple', ('host', 'port', 'proto', 'target'))(host="test.test.test",
                                                                                 port=80,
                                                                                 proto="http",
                                                                                 target="test")
    out = to_namedtuple(test_data)
    assert out == expected_out

# Generated at 2022-06-21 12:52:11.208018
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple([dic]) == [namedtuple('NamedTuple', ['a', 'b'])(1, 2)]
    assert to_namedtuple((dic,)) == (namedtuple('NamedTuple', ['a', 'b'])(1, 2),)
    dic = {'a': 1, '__b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ['a'])(1)
    dic = {'a': 1, 'b': {'c': 3, 'd': {'_e': 5}}}
    assert to_named

# Generated at 2022-06-21 12:52:22.370650
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    def _to_tuple(obj: Any) -> Tuple[Any, ...]:
        if hasattr(obj, 'capitalize'):
            obj = cast(str, obj)
            raise TypeError(
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                "got: (%r) %s" % (type(obj).__name__, obj)
            )
        if not isinstance(obj, (list, tuple)):
            raise TypeError(
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                "got: (%r) %s" % (type(obj).__name__, obj)
            )
        return tuple(obj)


# Generated at 2022-06-21 12:52:27.597279
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert len(nt) == 2
    assert nt.a == 1
    assert nt.b == 2
    assert getattr(nt, '_c', None) is None


# Generated at 2022-06-21 12:52:37.942001
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple function for various types."""
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', ['a'])(1)
    assert to_namedtuple({'b': 2}) == namedtuple('NamedTuple', ['b'])(2)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple(
        'NamedTuple',
        ['a', 'b']
    )(1, 2)

# Generated at 2022-06-21 12:52:45.982125
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dict(a=1, b=2)) == NamedTuple(a=1, b=2)



# Generated at 2022-06-21 12:52:50.353357
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class SampleClass:
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.a = 1
            self.b = 2

    # noinspection PyTypeChecker
    obj_list: list = [
        {'a': 1, 'b': 2},
        SampleClass(),
        1.0,
        'test',
        ['a1', 'a2'],
        None,
        (1, 2, 3),
        {'a': 1, 'b': 2},
        SampleClass(),
    ]
    # noinspection PyTypeChecker

# Generated at 2022-06-21 12:53:11.961388
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Unit test for function to_namedtuple'''

    import collections
    import types
    import random
    import string
    import sys

    from flutils.namedtupleutils import to_namedtuple

    PY3 = sys.version_info[0] == 3

    if PY3:
        from typing import Any


    def randomword(size: int) -> str:
        '''Generate a random word.'''

        return ''.join(random.choice(string.ascii_lowercase) for i in range(size))


    def flatten(d: Any, parent_key: str='', sep: str='.') -> Any:
        '''Flatten a dictionary.'''

        items = []

# Generated at 2022-06-21 12:53:22.097014
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    ntpl = to_namedtuple(dic)
    assert ntpl.a == 1
    assert ntpl.b == 2

    dic = {'a': 1, 'B': 2}
    ntpl = to_namedtuple(dic)
    assert hasattr(ntpl, 'a') is True
    assert hasattr(ntpl, 'B') is False
    assert ntpl.a == 1
    assert ntpl[0] == 1

    ntpl = to_namedtuple(ntpl)
    assert ntpl.a == 1

    dic = {'a': 1, 'b': 2}
    odic = OrderedDict(dic)
    ntpl = to_namedtuple(odic)


# Generated at 2022-06-21 12:53:30.585319
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # [{'a': 1}]
    nested_list = [
        {
            'a': 1
        }
    ]
    # {'a': 1, 'b': 2}
    nested_dict = {
        'a': 1,
        'b': 2
    }
    assert isinstance(to_namedtuple(nested_list), list)
    assert isinstance(to_namedtuple(nested_dict), NamedTuple)
    assert isinstance(to_namedtuple(nested_list)[0], NamedTuple)

# Generated at 2022-06-21 12:53:37.740044
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'c': 3, 'b': 2, 'a': 1}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('b', 2), ('a', 1)])) == NamedTuple(b=2, a=1)


# Generated at 2022-06-21 12:53:39.901267
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 12:53:41.237792
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass


# Generated at 2022-06-21 12:53:46.667545
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tup = to_namedtuple([('a', 1), ('b', 2), ('c', 3)])
    assert isinstance(tup, tuple)
    assert tup[0] == 1
    assert tup[1] == 2
    assert tup[2] == 3
    assert tup.a == 1
    assert tup.b == 2
    assert tup.c == 3
    tup = to_namedtuple((['a', 1], ['b', 2], ['c', 3]))
    assert isinstance(tup, tuple)
    assert tup[0] == 1
    assert tup[1] == 2
    assert tup[2] == 3
    assert tup.a == 1
    assert tup.b == 2
    assert tup.c == 3
    tup = to_namedtuple

# Generated at 2022-06-21 12:53:54.041726
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # pylint: disable=line-too-long
    # noinspection PyUnusedLocal,PyShadowingNames
    def _assert_result(objs: List[_AllowedTypes]) -> None:
        for obj in objs:
            # noinspection PyUnresolvedReferences
            assert isinstance(obj, _AllowedTypes)
            # noinspection PyUnresolvedReferences
            assert isinstance(to_namedtuple(obj), NamedTuple)
    # noinspection PyUnusedLocal,PyShadowingNames
    def _assert_non_result(objs: List[_AllowedTypes]) -> None:
        for obj in objs:
            # noinspection PyUnresolvedReferences
            assert isinstance(obj, _AllowedTypes)
            # noinspection PyUnresolvedReferences

# Generated at 2022-06-21 12:54:01.506218
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    def check_to_namedtuple(in_obj, out_obj):
        obj = to_namedtuple(in_obj)
        in_obj_type = type(in_obj)
        out_obj_type = type(out_obj)
        assert in_obj_type == out_obj_type
        assert obj == out_obj

    # noinspection PyUnusedLocal
    def check_to_namedtuple_exception(in_obj, out_obj):
        # noinspection PyProtectedMember,PyArgumentList
        try:
            to_namedtuple(in_obj)
        except Exception as e:
            assert type(e) == out_obj._type
            assert e.msg == out_obj._msg

        # noinspection PyUnusedLocal,Py

# Generated at 2022-06-21 12:54:11.113800
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lst = [{'a': 1, 'b': 2}, {'a': 1, 'b': 'a'}]
    assert to_namedtuple(lst) == [
        namedtuple('NamedTuple', 'a b')(a=1, b=2),
        namedtuple('NamedTuple', 'a b')(a=1, b='a'),
    ]

    tup = (
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 'a'},
    )
    assert to_namedtuple(tup) == (
        namedtuple('NamedTuple', 'a b')(a=1, b=2),
        namedtuple('NamedTuple', 'a b')(a=1, b='a'),
    )

   

# Generated at 2022-06-21 12:54:25.227239
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from flutils.validators import (
        is_namedtuple,
    )

    assert is_namedtuple(to_namedtuple([]))
    assert is_namedtuple(to_namedtuple({}))
    assert is_namedtuple(to_namedtuple(()))
    assert is_namedtuple(to_namedtuple({'a': 1, 'b': 2, 'c': 3}))
    assert is_namedtuple(
        to_namedtuple({'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5, 'f': 6}})
    )

# Generated at 2022-06-21 12:54:34.034239
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    obj = to_namedtuple([1, 'a', {'A', 'B', 'C'}])
    assert obj == [1, 'a', {'A', 'B', 'C'}]

    obj = to_namedtuple((1, 'a', {'A', 'B', 'C'}))
    assert obj == (1, 'a', {'A', 'B', 'C'})

    obj = to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}])
    assert obj == [NamedTuple(a=1, b=2), NamedTuple(c=3, d=4)]

    obj = to_namedtuple({'a': 1, 'b': 2})


# Generated at 2022-06-21 12:54:42.687365
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from unittest.mock import patch
    from types import SimpleNamespace

    with patch('flutils.namedtupleutils._to_namedtuple') as mock_to_nt:
        # noinspection PyProtectedMember
        mock_to_nt._started = False
        mock_to_nt.side_effect = lambda x: x
        assert to_namedtuple({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
        mock_to_nt._started = True
        mock_to_nt.side_effect = lambda x, _: x
        assert to_namedtuple({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

# Generated at 2022-06-21 12:54:53.515566
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dct = {
        'a': [1, 2, 3],
        'b': [4, 5, 6],
        'c': [7, 8, 9],
    }
    nt = to_namedtuple(dct)
    assert nt.a == [1, 2, 3]
    assert nt.b == [4, 5, 6]
    assert nt.c == [7, 8, 9]

    dct = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    nt = to_namedtuple(dct)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3


# Generated at 2022-06-21 12:54:56.173531
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic()) == dic()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:55:01.358964
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = OrderedDict([
        ('a', 1),
        ('b', 2),
    ])
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert out == [1, 2, 3]

    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert out == (1, 2, 3)

    obj = {'1': 2, 'b': 3}
    out = to_namedtuple(obj)
    assert out.b