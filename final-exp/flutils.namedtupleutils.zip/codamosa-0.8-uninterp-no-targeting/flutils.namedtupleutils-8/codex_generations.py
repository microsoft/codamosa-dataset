

# Generated at 2022-06-21 12:45:20.244028
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the function :func:`flutils.namedtupleutils.to_namedtuple`."""
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == namedtuple('NamedTuple', 'a b')(1, 2)
    assert out.a == 1

    out = to_namedtuple({'a': 1})
    assert out == namedtuple('NamedTuple', 'a')(1)

    out = to_namedtuple({'a': {'b': 1, 'c': 2}, 'd': 'c'})  # type: ignore[arg-type]

# Generated at 2022-06-21 12:45:31.289134
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': {'c': 3}, 'b': 2}) == NamedTuple(a=NamedTuple(c=3), b=2)
    assert to_namedtuple({1: 1, 2: 2}) == NamedTuple(_1=1, _2=2)
    assert to_namedtuple({'a': 1, 'b': 2, 1: 'one'}) == NamedTuple(a=1, b=2, _1='one')

# Generated at 2022-06-21 12:45:34.328865
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # TODO: Add more comprehensive test
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)


if __name__ == '__main__':
    # Unit test for function to_namedtuple
    test_to_namedtuple()

# Generated at 2022-06-21 12:45:45.231068
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    # noinspection PyTypeChecker
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        NamedTuple(a=1, b=2)
    assert to_namedtuple(NamedTuple(a=1, b=2)) == NamedTuple(a=1, b=2)

# Generated at 2022-06-21 12:45:55.164337
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    """Test function to_namedtuple."""
    import os
    import unittest
    try:
        from collections import OrderedDict
    except ImportError:  # pragma: no cover
        from ordereddict import OrderedDict

    class TestToNamedtuple(unittest.TestCase):

        def test_to_namedtuple(self):
            # type: () -> None
            """Test function to_namedtuple."""
            # noinspection PyTypeChecker
            from flutils.miscutils import ResultTuple

            data = {
                'a': 1,
                'b': 2,
                'c': None,
                '_c': 3,
                '__d': 4
            }

# Generated at 2022-06-21 12:46:05.788239
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # test: dict
    dic = {'a': 1, 'b': 2}
    ntuple = to_namedtuple(dic)
    assert isinstance(ntuple, namedtuple('NamedTuple', 'a b'))
    assert ntuple.a == 1
    assert ntuple.b == 2

    # test: OrderedDict
    odic = OrderedDict({'a': 1, 'b': 2})
    odic['c'] = 3
    ntuple = to_namedtuple(odic)
    assert isinstance(ntuple, namedtuple('NamedTuple', 'a b c'))
    assert ntuple.a == 1


# Generated at 2022-06-21 12:46:18.340866
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    named_tup = to_namedtuple({"a": 1, "b": 2})
    assert named_tup.a == 1
    assert named_tup.b == 2

    ord_dic = OrderedDict({"a": 1, "b": 2, "c": 3})
    named_tup = to_namedtuple(ord_dic)
    assert named_tup.a == 1
    assert named_tup.b == 2
    assert named_tup.c == 3

    sn = SimpleNamespace(**{"a": 1, "b": 2})
    named_tup = to_namedtuple(sn)
    assert named_tup.a == 1
    assert named_tup.b == 2

    named_t

# Generated at 2022-06-21 12:46:26.403778
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple(a=1) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple([]) == []
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple(()) == ()
    assert to_namedtuple(('a', 'b')) == ('a', 'b')
    assert to_namedtuple([[]]) == [[]]
    assert to_namedtuple([[], []]) == [[], []]
    assert to_namedtuple([[], [], '']) == [[], [], '']

# Generated at 2022-06-21 12:46:38.997361
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.misc import (
        merge_dicts,
    )
    from collections import (
        OrderedDict,
    )
    from types import (
        SimpleNamespace,
    )
    from typing import (
        Any,
        Dict,
        List,
        NamedTuple,
        Type,
        Union,
        cast,
    )


# Generated at 2022-06-21 12:46:49.859365
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Basic operation test
    dic = {'a': 1, 'b': 2, 'c': 3}
    args = to_namedtuple(dic)
    assert tuple(args) == (1, 2, 3)

    # Assignment test
    args = to_namedtuple(dic)
    args.a = 100
    assert args.a == 100

    # Mixed type test
    dic = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    out = to_namedtuple(dic)
    assert out.b == 2
    assert out.c.d == 4

    # Empty test
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == namedt

# Generated at 2022-06-21 12:47:05.025612
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.constants import (
        SYSTEM_CODES,
    )

    def run_test(in_obj: Any, *, should_be: Any) -> None:
        out = to_namedtuple(in_obj)
        assert out == should_be

    # List
    in_obj = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    should_be = [
        NamedTuple(a=1, b=2),
        NamedTuple(c=3, d=4),
    ]
    run_test(in_obj, should_be=should_be)

    # Tuple
    in_obj = (
        {'a': 1, 'b': 2},
        {'c': 3, 'd': 4},
    )
   

# Generated at 2022-06-21 12:47:16.005020
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Validates the to_namedtuple function."""

    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple(OrderedDict(a=1, b=2, c=3)) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(dict(a=1, b=2, c=3)) == NamedTuple(a=1, b=2, c=3)

    assert to_namedtuple([]) == NamedTuple()
    assert to_namedtuple([1]) == NamedTuple(1)
    assert to_namedtuple([1, SimpleNamespace(a=1, b=2)]) == NamedTuple(1, NamedTuple(a=1, b=2))

# Generated at 2022-06-21 12:47:26.647266
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('\n\n### In function to_namedtuple')
    dic: dict = {'a': 1, 'b': 2}
    print(f'dic = {dic}')
    print(f"to_namedtuple(dic) = {to_namedtuple(dic)}")
    dic: dict = {'a': 1, 'b': {'c': 3}}
    print(f'dic = {dic}')
    print(f"to_namedtuple(dic) = {to_namedtuple(dic)}")
    dic: dict = {'a': 1, 'b': {'c': 3}, 'd': {'e': 5, 'f': 6}}
    print(f'dic = {dic}')

# Generated at 2022-06-21 12:47:37.542472
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test a list, tuple, dict, OrderedDict, and a SimpleNamespace.
    l: List[Mapping] = [
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
        {'a': 5, 'b': 6},
    ]
    t = (
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
        {'a': 5, 'b': 6},
    )
    d = {'a': 1, 'b': 2}
    o = OrderedDict()
    o['a'] = 1
    o['b'] = 2
    ns = SimpleNamespace()
    ns.a = 1
    ns.b = 2

# Generated at 2022-06-21 12:47:47.251664
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {
        'd0': {
            'd1': {
                'd2': [
                    1,
                    2,
                    3,
                    {
                        '4': 4,
                        '5': 5,
                    }
                ]
            }
        },
        'd3': {
            'a': 1,
            'b': 2
        },
        'd4': {
            'd5': {
                'd6': {
                    'a': 1,
                    'b': 2,
                    'c': 3
                }
            }
        },
        'd7': {
            1: 'a',
            2: 'b',
            3: 'c',
        }
    }
    od = OrderedDict(sorted(d.items(), key=lambda t: t[0]))

# Generated at 2022-06-21 12:47:53.320237
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import doctest

    doctest.testmod()

    assert hasattr(test_to_namedtuple, '__doc__')
    assert to_namedtuple.__doc__


# Make script executable.

if __name__ == "__main__":
    raise SystemExit(test_to_namedtuple())

# Generated at 2022-06-21 12:48:02.676621
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    # Testing the happy path
    o = {'a': 1, 'b': 2}
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    actual = to_namedtuple(o)
    assert actual == expected
    # Testing that we don't change the input
    o = {'a': 1, 'b': 2}
    to_namedtuple(o)
    assert o == {'a': 1, 'b': 2}
    # Testing that we don't change the input for keys that cannot be valid
    # identifiers
    o = {'a': 1, 'b': 2, 'c$': 3}
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    actual = to_namedtuple

# Generated at 2022-06-21 12:48:13.233227
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from flutils import Profile

    p = Profile(location='here')
    nt = to_namedtuple(p)
    assert isinstance(nt, namedtuple)
    assert nt.location == 'here'

    d = OrderedDict(a=1, b=2)
    nt = to_namedtuple(d)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

    d = dict(a=1, b=2)
    nt = to_namedtuple(d)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2


# Generated at 2022-06-21 12:48:25.892242
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from datetime import date
    from typing import NamedTuple
    d = {'date': date(2020, 5, 3), 'yesterday': '2020-05-02',
         'tomorrow': '2020-05-04'}
    sub_d = {'today': '2020-05-03'}
    d.update({'subdict': sub_d})
    nt_expected = namedtuple('Expected', ['date', 'tomorrow', 'yesterday',
                                          'subdict'])
    nt_subdict = namedtuple('Subdict', ['today'])

# Generated at 2022-06-21 12:48:35.881755
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase

    from flutils.loader import load_yaml

    from flutils.namedtupleutils import (
        to_namedtuple,
    )

    TEST_DATA = load_yaml(__file__, 'test_data', 'test_to_namedtuple.yml')

    class TestToNamedtuple(TestCase):
        maxDiff = None

        def test_to_namedtuple(
                self):
            expected = TEST_DATA['expected']
            data = TEST_DATA['data']
            self.assertEqual(expected, to_namedtuple(data))

    # noinspection SpellCheckingInspection

# Generated at 2022-06-21 12:48:51.286315
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from datetime import datetime
    from types import SimpleNamespace
    from unittest import TestCase

    from flutils.namedtupleutils import to_namedtuple

    class TestToNamedTuple(TestCase):
        """Unit tests for the function to_namedtuple."""

        def test_args_empty(self):
            self.assertRaises(
                TypeError,
                to_namedtuple,
                '',
            )

        def test_dicts(self):
            """Test converting to a NamedTuple."""
            dic = {'a': 1, 'b': 2}
            output = to_namedtuple(dic)
            self.assertTrue(isinstance(output, tuple))
            self.assertEqual(output.a, dic['a'])

# Generated at 2022-06-21 12:49:02.920359
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple(('a', 'b')) == ('a', 'b')
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(ordereddict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple((SimpleNamespace(a=1, b=2),)) == (NamedTuple(a=1, b=2),)

# Generated at 2022-06-21 12:49:15.240889
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    with pytest.raises(TypeError) as excinfo:
        to_namedtuple(123)
    assert "Can convert only 'list', 'tuple', 'dict' to a NamedTuple;" in str(excinfo)

    with pytest.raises(TypeError) as excinfo:
        to_namedtuple('123')
    assert "Can convert only 'list', 'tuple', 'dict' to a NamedTuple;" in str(excinfo)

    with pytest.raises(AttributeError) as excinfo:
        to_namedtuple(None)
    assert "Can convert only 'list', 'tuple', 'dict' to a NamedTuple;" in str(excinfo)

    assert to_namedtuple([]) == []

    assert to_namedtuple(()) == ()


# Generated at 2022-06-21 12:49:17.904788
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=True)

# Run test on execution of file
if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:49:28.130719
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def assert_namedtuples(expected: NamedTuple, actual: NamedTuple):
        assert expected.__class__ == actual.__class__
        assert expected._fields == actual._fields
        for i in range(len(expected)):
            assert getattr(expected, expected._fields[i]) == \
                getattr(actual, actual._fields[i])

    # dict with all proper identifiers
    expected = namedtuple('NamedTuple', ('a', 'b', 'c'))(1, 2, 3)
    dic = {'a': 1, 'b': 2, 'c': 3}
    actual = to_namedtuple(dic)
    assert_namedtuples(expected, actual)

    # dict with improper identifiers

# Generated at 2022-06-21 12:49:40.977393
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test that to_namedtuple works as expected."""
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from collections import OrderedDict
    from typing import NamedTuple
    # dict
    dic = dict(a=1, b=2, c=3)
    named = namedtuple('NamedTuple', 'a b c')
    # noinspection PyTypeChecker
    assert to_namedtuple(dic) == named(a=1, b=2, c=3)
    # OrderedDict
    dic = OrderedDict(a=1, b=2, c=3)
    named = namedtuple('NamedTuple', 'a b c')
    # noinspection PyTypeChecker

# Generated at 2022-06-21 12:49:53.112714
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for :func:`to_namedtuple`.

    This test checks a dictionary that has a dictionary as a value.
    """
    from pprint import pprint
    from collections import OrderedDict
    from flutils.jsonutils import object_hook as json_hook

    # Create some test data
    out: List[str] = []
    out.append('''{
        "b": "2",
        "a": {
            "b": "2",
            "a": "1"
        }
    }''')


# Generated at 2022-06-21 12:50:01.934785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyShadowingNames
    def assertEqual(obj: Any, prev: Any) -> None:
        out = to_namedtuple(obj)
        assert repr(prev) == repr(out), "%r != %r" % (prev, out)

    # noinspection PyTypeChecker
    # noinspection PyShadowingNames
    def assertType(obj: Any, typ: Any) -> None:
        out = to_namedtuple(obj)
        assert isinstance(out, typ), "%r is not an instance of %r" % (
            out, typ
        )

    # noinspection PyTypeChecker
    # noinspection PyShadowingNames
    def assertValue(obj: Any, attr: str, val: Any) -> None:
        out = to_namedtuple(obj)

# Generated at 2022-06-21 12:50:08.311598
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from flutils.textutils import to_snakecase
    from types import SimpleNamespace
    from typing import Dict, List, Tuple
    from flutils.validators import validate_identifier

    # Test valid input types
    dic: OrderedDict = OrderedDict(
        _dict={
            'a': 1,
            'b': 2,
            '_c': 3,
            'a_': 4,
            'c_': 5,
            '_d': 6,
            '_e': 7
        }
    )
    assert isinstance(dic, Mapping)
    named = to_namedtuple(dic)
    assert isinstance(named, namedtuple)

# Generated at 2022-06-21 12:50:21.667112
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test of the namedtupleutils.to_namedtuple function.

    The function will only be run if the module is called directly.

    :rtype: None
    """

# Generated at 2022-06-21 12:50:37.917105
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the function to_namedtuple"""

    # Test a dictionary
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(*(1, 2))

    # Test a string
    assert to_namedtuple('a') == 'a'

    # Test a list
    _list = [1, 'a']
    assert to_namedtuple(_list) == [1, 'a']

    # Test a tuple
    _tuple = (1, 'a')
    assert to_namedtuple(_tuple) == (1, 'a')

    # Test a list of dictionaries
    _list = [dic, dic, dic]

# Generated at 2022-06-21 12:50:49.781163
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from typing import NamedTuple


# Generated at 2022-06-21 12:51:01.245546
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import (
        Mock,
        call,
        patch,
    )
    from .testutils import (
        MockNamedTuple,
        MockNamedTupleEmpty,
        MockNamedTupleSubClass,
    )
    from collections import OrderedDict
    import types
    import sys
    _original_implementation = to_namedtuple

    dic = Mock(spec_set=dict)
    dic.keys.return_value = 'abc'
    vals = iter(['a', 'b', 'c'])
    dic.__iter__.return_value = vals
    dic.__getitem__.side_effect = lambda key: {
        'a': 1,
        'b': 2,
        'c': 3,
    }[key]

   

# Generated at 2022-06-21 12:51:02.704161
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    print(to_namedtuple(dic))
    assert isinstance(to_namedtuple(dic), NamedTuple)

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:51:13.892363
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    """Test for function to_namedtuple."""

    dic = dict(a=1, b=2)
    nt = to_namedtuple(dic)
    nt.a == 1
    nt.b == 2

    dic2 = dict(a=1, b=2, _c=3)
    nt2 = to_namedtuple(dic2)
    nt2.a == 1
    nt2.b == 2

    dic3 = dict(a=1, b=2, _c=3, e_f=4)
    nt3 = to_namedtuple(dic3)
    nt3.a == 1
    nt3.b == 2

    lst = [1, 2, 3, 4]
    assert to

# Generated at 2022-06-21 12:51:21.317910
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple with unittest.
    """
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        """Test class to_namedtuple with unittest.
        """

        def test_not_allowed(self):
            with self.assertRaises(TypeError):
                to_namedtuple(1)

        def test_dict(self):
            val = 1
            dic = {'a': val}
            out = to_namedtuple(dic)
            self.assertEqual(out.a, val, msg=dic)
            dic = {'1': val}
            out = to_namedtuple(dic)
            self.assertIsInstance(out, NamedTuple, msg=dic)


# Generated at 2022-06-21 12:51:33.180064
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import mock
    import sys

    @singledispatch
    def _to_namedtuple(obj: Any, _started: bool = False) -> Any:
        if _started is False:
            raise TypeError(
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                "got: (%r) %s" % (type(obj).__name__, obj)
            )
        return obj

    # noinspection PyUnusedFunction,Mypy
    @_to_namedtuple.register(Mapping)
    def _(
            obj: Mapping,
            _started: bool = False
    ) -> Union[NamedTuple, Tuple]:
        keys = []

# Generated at 2022-06-21 12:51:40.954359
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint

    # For the moment, perform the test in debug mode
    # which will output tests that fail and the data that
    # caused the failure
    debug = True
    # noinspection PyShadowingNames
    def assert_in(things, thing):
        if thing not in things and debug:
            for thingy in things:
                pprint(thingy)
            pprint(thing)
            raise AssertionError('{} not in {}'.format(thing, things))
        return True

    # First test a single dictionary
    test_dict = {'a': 1, 'b': 'string', 'c': [1, 2], 'd': {'e': 'F'}}
    test_str = 'string'

# Generated at 2022-06-21 12:51:47.495697
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    def assert_namedtuple(
            obj: Union[dict, list, tuple, SimpleNamespace],
            expected: Union[dict, list, tuple, SimpleNamespace],
    ):
        res = to_namedtuple(obj)
        assert res == expected

    # List
    assert_namedtuple(
        [1, [2, 3]],
        NamedTuple(a=1, b=NamedTuple(a=2, b=3))
    )

    # Tuple
    assert_namedtuple(
        (1, (2, 3)),
        NamedTuple(a=1, b=NamedTuple(a=2, b=3))
    )

    # Mapping

# Generated at 2022-06-21 12:51:58.391484
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple

    # noinspection PyUnresolvedReferences
    assert to_namedtuple({'a': 1, 'b': 2}) == \
        namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    # noinspection PyUnresolvedReferences
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    # noinspection PyUnresolvedReferences
    assert to_namedtuple(OrderedDict([('b', 2), ('a', 1)])) == \
        namedtuple('NamedTuple', ['b', 'a'])(b=2, a=1)

    # noinspection

# Generated at 2022-06-21 12:52:19.530637
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.logging_helper
    flutils.logging_helper.LoggingHelper.setup_logging()

    dic = {'a': 1, 'b': 2}
    named = to_namedtuple(dic)
    assert named.a == 1

    dic = {'0': 1, 'b': 2}
    named = to_namedtuple(dic)
    assert '0' not in named._fields
    assert 'b' in named._fields

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8, 'i': 9, 'j': 10}
    ordered = OrderedDict(dic)
    named = to_namedtuple(dic)


# Generated at 2022-06-21 12:52:28.480347
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import defaultdict, OrderedDict
    from typing import Dict, List, NamedTuple

    def test_dic(
            dic: Dict[str, Any],
            truth: List[Tuple[str, Any]]
    ) -> None:
        lg.debug(dic)
        # noinspection PyTypeChecker
        nt = to_namedtuple(dic)
        lg.debug(nt)
        # noinspection PyTypeChecker
        assert isinstance(nt, NamedTuple)
        # noinspection PyTypeChecker
        assert len(nt) == len(truth)
        # noinspection PyTypeChecker
        assert list(nt._fields) == [t[0] for t in truth]
        for t in truth:
            attr = t[0]
            val

# Generated at 2022-06-21 12:52:37.052296
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from operator import attrgetter
    from flutils.namedtupleutils import to_namedtuple
    testDict = {'a': 1, 'c': 3, 'b': 2}
    testList = [1, 2, 3]
    to_namedtupleTest = namedtuple(
        'to_namedtupleTest',
        list(sorted(testDict.keys()))
    )
    assert to_namedtuple(testDict) == to_namedtupleTest(1, 2, 3)
    assert to_namedtuple(testList) == [1, 2, 3]



# Generated at 2022-06-21 12:52:47.992861
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict

    with pytest.raises(TypeError) as err:
        to_namedtuple(None)
    assert (
        str(err.value) == "Can convert only 'list', 'tuple', 'dict' to a "
                          "NamedTuple; got: (NoneType) None"
    )

    with pytest.raises(TypeError) as err:
        to_namedtuple(1)
    assert (
        str(err.value) == "Can convert only 'list', 'tuple', 'dict' to a "
                          "NamedTuple; got: (int) 1"
    )
    with pytest.raises(TypeError) as err:
        to_namedtuple('1')

# Generated at 2022-06-21 12:52:59.402349
# Unit test for function to_namedtuple
def test_to_namedtuple():
    s = SimpleNamespace(a=1, b=2)
    nt = to_namedtuple(s)
    assert nt.a == 1
    assert nt.b == 2
    assert nt._fields == ('a', 'b')
    #
    d = OrderedDict(a=1, b=2)
    nt = to_namedtuple(d)
    assert nt.a == 1
    assert nt.b == 2
    assert nt._fields == ('a', 'b')
    l = [1, 2, 3]
    nt = to_namedtuple(l)
    assert nt == l
    assert nt is not l
    tup = (1, 2, 3)
    nt = to_namedtuple(tup)
    assert nt == tup


# Generated at 2022-06-21 12:53:10.686338
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Test to_namedtuple function. """
    class _Dict(dict):
        pass

    class _OrderedDict(OrderedDict):
        pass

    class _List(list):
        pass

    class _DictSub(_Dict):
        pass

    class _OrderedDictSub(_OrderedDict):
        pass

    class _ListSub(_List):
        pass

    class _SimpleNamespaceSub(SimpleNamespace):
        pass

    class _NamedTupleSub(namedtuple('_NamedTupleSub', 'a b c d')):
        pass


# Generated at 2022-06-21 12:53:21.390207
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    def recurse(obj):
        if isinstance(obj, SimpleNamespace):
            return to_namedtuple(obj)
        if isinstance(obj, dict):
            for key, val in obj.items():
                obj[key] = recurse(val)
            return obj
        if isinstance(obj, (list, tuple)):
            return [recurse(item) for item in obj]
        return obj

    def validate_dic(dic):
        assert isinstance(dic, dict)
        for key, val in dic.items():
            assert isinstance(key, str)
            assert isinstance(val, dict)


# Generated at 2022-06-21 12:53:29.033580
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test case using None
    with pytest.raises(TypeError):
        to_namedtuple(None)

    # Test case using integer
    with pytest.raises(TypeError):
        to_namedtuple(8)

    # Test case using float
    with pytest.raises(TypeError):
        to_namedtuple(8.2)

    # Test case using simple list
    list1 = [1, 2]
    list2 = to_namedtuple(list1)
    assert list1 == list2

    # Test case using nested list
    list1 = [1, [2, 3]]
    list2 = to_namedtuple(list1)
    assert list1 == list2

    # Test case using tuple
    tup1 = (1, 2)
    tup2 = to_namedt

# Generated at 2022-06-21 12:53:36.839072
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out: NamedTuple = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    # Test with OrderedDict
    from collections import OrderedDict
    dic = OrderedDict(a=1, b=2)
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    # Test with SimpleNamespace
    from types import SimpleNamespace
    dic = SimpleNamespace(a=1, b=2)
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    # Test with a list
    lst = [dic, dic, dic]
   

# Generated at 2022-06-21 12:53:43.032772
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Sequence
    from typing import NamedTuple
    from types import SimpleNamespace

    dic = OrderedDict(
        [
            ('a', 1),
            ('b', OrderedDict([('c', 2), ('d', 3)])),
            ('e', SimpleNamespace(f=4, g=5))
        ]
    )
    out = to_namedtuple(dic)
    assert type(out) is NamedTuple
    assert len(out) == 5
    assert out.a == dic['a']
    assert out.b.c == dic['b']['c']
    assert out.b.d == dic['b']['d']

# Generated at 2022-06-21 12:54:11.306963
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections

    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2

    dic = {'a': 1, 'b': 2, 'c': {'d': 3}}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c.d == 3

    dic = {'a': 1, 'c': {'d': 3}, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c.d == 3


# Generated at 2022-06-21 12:54:22.670847
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Tests for to_namedtuple()."""

    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict


# Generated at 2022-06-21 12:54:32.342056
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    from typing import Callable

    no_change = [
        'test',
        1,
        None,
        True,
        False,
        datetime.now()
    ]

    for item in no_change:
        assert to_namedtuple(item) == item

    raw_data = [
        {
            'name': 'test',
            'type': 'text',
            'value': 'test',
            'value_serialized': None,
            'value_json': {},
            'value_type': None
        },
        {
            'name': 'test',
            'type': 'text',
            'value': 'test',
            'value_serialized': None,
            'value_json': {},
            'value_type': None
        }
    ]



# Generated at 2022-06-21 12:54:42.096503
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the function to_namedtuple.
    """
    # Test conversions
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2}}
    expected = namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=to_namedtuple(
        {'a': 1, 'b': 2}))
    assert to_namedtuple(dic) == expected

    # Test sequences
    lis = [{'a': 1, 'b': 2}, {'a': 2, 'b': 4}]
   

# Generated at 2022-06-21 12:54:53.398879
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': {'b': 1}, 'c': {'d': 2}}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert isinstance(nt.a, NamedTuple)
    assert isinstance(nt.c, NamedTuple)
    assert nt.a.b == 1
    assert nt.c.d == 2

    dic = {'a': [1, 2, 3], 'b': [4, 5]}
    nt = to_namedtuple(dic)
   

# Generated at 2022-06-21 12:54:59.610056
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    class Foo(NamedTuple):
        a: int
        b: int

    class Bar:
        a: int
        b: int

    tup = Foo(a=1, b=2)
    assert to_namedtuple(tup) == tup

    bar = Bar()
    bar.a = 1
    bar.b = 2
    assert to_namedtuple(tup) == to_namedtuple(bar)
    
    # now let's test namespaces:
    from types import SimpleNamespace
    a = to_namedtuple(SimpleNamespace(a=1, b=2))

# Generated at 2022-06-21 12:55:08.981896
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Dict, List, Optional
    from collections import namedtuple
    from collections.abc import Mapping, Sequence


    D = Dict[str, Any]
    M = Mapping[str, Any]
    S = Sequence[Any]


    def test(
            func: Callable[[Any], Any],
            tests: List[Tuple[Any, Any]],
            desc: Optional[str] = None
    ):
        for given, expected in tests:
            msg = '%r -> %r, got %r' % (given, expected, func(given))
            assert func(given) == expected, msg
        if desc:
            print(desc)

