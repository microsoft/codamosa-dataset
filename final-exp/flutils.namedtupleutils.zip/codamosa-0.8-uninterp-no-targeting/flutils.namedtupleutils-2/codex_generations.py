

# Generated at 2022-06-21 12:45:17.674180
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    dic = {
        'a': 1,
        'b': 2,
        'c': 'dog'
    }
    # noinspection PyTypeChecker
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 'dog'
    dic = OrderedDict(
        a=1,
        b=2,
        c='dog'
    )
    # noinspection PyTypeChecker
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 'dog'
    assert out[0]

# Generated at 2022-06-21 12:45:19.760822
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple(0) == 0


# Generated at 2022-06-21 12:45:30.606517
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class ToNamedTupleTest(unittest.TestCase):

        def test_to_namedtuple_list(self):
            obj = [1]
            out = to_namedtuple(obj)
            self.assertEqual(out[0], 1)

        def test_to_namedtuple_tuple(self):
            obj = (1,)
            out = to_namedtuple(obj)
            self.assertEqual(out[0], 1)

        def test_to_namedtuple_dict(self):
            obj = {'a': 1, 'b': 2}
            out = to_namedtuple(obj)
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)


# Generated at 2022-06-21 12:45:37.405494
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Testing list
    lst = ['a', {'b': 2, 'a': 1}]
    lst[1]['c'] = 3
    lst2 = to_namedtuple(lst)
    assert lst2[0] == 'a'
    assert lst2[1].a == 1
    assert lst2[1].b == 2

    # Testing tuple
    tup = ('a', {'b': 2, 'a': 1})
    tup2 = to_namedtuple(tup)
    assert tup2[0] == 'a'
    assert tup2[1].a == 1
    assert tup2[1].b == 2

    # Testing dict
    dic = {'a': 1, 'b': 2}

# Generated at 2022-06-21 12:45:46.795560
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == to_namedtuple(
        {},
    ) == to_namedtuple(
        tuple(),
    ) == to_namedtuple(
        OrderedDict(),
    ) == to_namedtuple(
        SimpleNamespace(),
    ) == NamedTuple()

# Generated at 2022-06-21 12:45:52.835357
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    import pytest
    from flutils.validators.miscellaneous import validate_number
    from flutils.validators.types import validate_types

    # Test a list
    data = [{'a': 1}, {'b': 2}, {'c': 3}]
    out = to_namedtuple(data)
    assert isinstance(out, list)
    assert all([isinstance(item, collections.namedtuple) for item in out])
    for item in out:
        assert isinstance(item, collections.namedtuple)
        for key in item._fields:
            assert key in ['a', 'b', 'c']
            assert validate_number(getattr(item, key))

    # Test a tuple
    data = ({'a': 1}, {'b': 2}, {'c': 3})
    out

# Generated at 2022-06-21 12:46:04.240683
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a']) == ['a']
    data = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
    }
    assert isinstance(to_namedtuple(data), NamedTuple)
    assert to_namedtuple(data) == NamedTuple(a=1, b=2, c=3, d=4)
    data = OrderedDict()
    data['c'] = 3
    data['d'] = 4
    data['a'] = 1
    data['b'] = 2
    assert isinstance(to_namedtuple(data), NamedTuple)
    assert to_namedtuple(data) == NamedTuple(c=3, d=4, a=1, b=2)
    data = SimpleNames

# Generated at 2022-06-21 12:46:17.063342
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import os
    import sys
    import pytest

    sys.path.insert(0, os.path.abspath('src/flutils'))

    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import to_namedtuple

    def test_base_exceptions():
        with pytest.raises(TypeError):
            to_namedtuple(2)
        with pytest.raises(TypeError):
            to_namedtuple(['a', 'b'], 1, 2)
        with pytest.raises(TypeError):
            to_namedtuple(2, 'a')
        with pytest.raises(TypeError):
            to_namedtuple(4.0)

    def test_type_list():
        tup = to_namedtuple([])

# Generated at 2022-06-21 12:46:25.693345
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from inspect import signature
    from pprint import pprint
    import types
    import unittest

    # noinspection PyPep8Naming,Mypy
    class Test_to_namedtuple(unittest.TestCase):
        longMessage = True

        @classmethod
        def setUpClass(cls) -> None:
            cls.expected_doc = "Convert particular objects into a namedtuple."
            cls.func = to_namedtuple
            cls.func_name = cls.func.__name__

            cls.dic = {
                'a': 1,
                'b': 2,
                '_c': '\'c\''
            }

# Generated at 2022-06-21 12:46:38.165409
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a']) == ['a']
    assert to_namedtuple(('a')) == ('a')
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple(OrderedDict([('a', 1)])) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple({'__a': 1}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'_a': 1}) == namedtuple('NamedTuple', '_a')(1)
    assert to_namedtuple({'a_': 1}) == namedtuple('NamedTuple', 'a_')(1)
    assert to_namedtuple

# Generated at 2022-06-21 12:46:50.791190
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from textwrap import dedent
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testutils import (
        assert_equal,
    )

    dic = {
        'one': 1,
        'two': 2,
        'three': 3,
    }
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert_equal(
        nt,
        'NamedTuple(one=1, three=3, two=2)'
    )
    assert_equal(
        nt._asdict(),
        {
            'one': 1,
            'two': 2,
            'three': 3,
        }
    )
    assert_equal(
        nt.one,
        1
    )

    assert_

# Generated at 2022-06-21 12:46:52.901077
# Unit test for function to_namedtuple
def test_to_namedtuple():
    c = dict(a=1, b=2, c=3)
    d = list(sorted(c.keys()))
    assert to_namedtuple(c) == cast(NamedTuple, namedtuple('NamedTuple', d)(*c.values()))

# Generated at 2022-06-21 12:47:05.221609
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from typing import cast
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test empty dictionary
    dic = {}
    out = to_namedtuple(dic)
    assert isinstance(out, tuple)
    assert len(out) == 0
    assert not out._fields
    assert not out._asdict()

    # Test dictionary
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, tuple)
    assert len(out) == 2
    assert out._fields == ('a', 'b')
    assert out._asdict() == {'a': 1, 'b': 2}

    # Test dictionary with keys that are not identifiers

# Generated at 2022-06-21 12:47:16.498780
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:47:26.935357
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(
        dic
    ) == NamedTuple(
        a=1,
        b=2,
    )
    assert to_namedtuple(
        {'a': {'b': 1, 'c': 2}}
    ) == NamedTuple(
        a=NamedTuple(
            b=1,
            c=2,
        ),
    )
    assert to_namedtuple(
        {'a': [1, {'b': 2}]}
    ) == NamedTuple(
        a=(
            1,
            NamedTuple(
                b=2,
            ),
        ),
    )

# Generated at 2022-06-21 12:47:36.266677
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert dir(out)[0] == 'a'
    assert dir(out)[1] == 'b'
    assert isinstance(out, tuple)
    out2 = to_namedtuple([dic])
    assert isinstance(out2, list)
    assert out2[0].a == 1
    assert out2[0].b == 2
    assert hasattr(out2[0], 'a')
    assert hasattr(out2[0], 'b')
    assert dir(out2[0])[0] == 'a'

# Generated at 2022-06-21 12:47:45.994850
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import patch
    from . import namedtupleutils_test as testmod
    
    testmod.testmod(
        namedtupleutils,
        excluded=['_to_namedtuple', 'also_namedtuple']
    )
    testmod.testmod(testmod)
    with patch('flutils.namedtupleutils.validate_identifier') as mock_validate_:
        testmod.test_to_namedtuple_error_validate()
        mock_validate_.assert_called_once()
        mock_validate_.reset_mock()
        mock_validate_.side_effect = SyntaxError
        testmod.test_to_namedtuple_underscore()
        assert mock_validate_.call_count == 2
        mock_validate_.reset_mock()


# Generated at 2022-06-21 12:47:58.357666
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    _dic1 = dict(a=1, b=2)
    nam1 = to_namedtuple(_dic1)
    assert nam1.a == 1
    assert nam1.b == 2

    _dic2 = dict(x=1, y=2, z=3)
    nam2 = to_namedtuple(_dic2)
    assert nam2.x == 1
    assert nam2.y == 2
    assert nam2.z == 3

    _dic3 = dict(a=1, b=2, x='x', y='y', z='z')
    nam3 = to_namedtuple(_dic3)
    assert nam3.a == 1
    assert nam3.b == 2


# Generated at 2022-06-21 12:48:09.667432
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    assert to_namedtuple('abc') == 'abc'
    assert to_namedtuple(123) == 123
    test_data = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    test_tuple: NamedTuple = to_namedtuple(test_data)
    assert isinstance(test_tuple, namedtuple)
    assert test_tuple.a == 1
    assert test_tuple.b == 2
    assert test_tuple.c == 3

# Generated at 2022-06-21 12:48:18.610949
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils
    old = flutils.namedtupleutils.to_namedtuple

    namedtuple = flutils.namedtupleutils.to_namedtuple

    def test_dictionary(dic, expected):
        assert namedtuple(dic) == expected

    def test_namedtuple(obj, expected):
        assert namedtuple(obj) == expected

    def test_simple_namespace(obj, expected):
        assert namedtuple(obj) == expected

    def test_sequence(seq, expected):
        assert namedtuple(seq) == expected

    *_, end = test_sequence

    test_dictionary(
        dic={'a': 1, 'b': 2},
        expected=NamedTuple(a=1, b=2),
    )

    test_dictionary

# Generated at 2022-06-21 12:48:38.050920
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import warnings

    warnings.simplefilter('ignore', DeprecationWarning)

    # noinspection PyUnresolvedReferences,PyCompatibility
    import builtins

    # noinspection PyUnresolvedReferences,PyCompatibility
    import future.backports.datetime

    dic = {
        'a': 1,
        'b': {
            'a': 1,
            'b': 2,
            'c': [1, 2, 3],
        },
        'c': [1, 2, 3, {
            'a': 1,
            'b': 2,
        }],
        'd': ('a', 1, 2, '3'),
    }
    dic2 = OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-21 12:48:47.010735
# Unit test for function to_namedtuple
def test_to_namedtuple():
    nested = {
        'a': {
            'b': 1,
            'c': 2,
            'd': {
                'e': 1,
                'f': 3
            },
            'g': 4
        },
        'h': {
            'i': 5,
            'j': 6
        },
        'k': {
            'l': 7
        }
    }
    nt = to_namedtuple(nested)
    assert nt.a.d.e == 1
    assert nt.k.l == 7



# Generated at 2022-06-21 12:48:56.324670
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase

    from flutils.namedtupleutils import to_namedtuple

    tn_type = namedtuple('NamedTuple', '')

    class TestToNamedTuple(TestCase):

        def test_to_namedtuple_empty(self):
            expected = tn_type()
            result = to_namedtuple({})
            self.assertEqual(result, expected)

        def test_to_namedtuple_simple_dic(self):
            expected = tn_type(a=1)
            result = to_namedtuple({'a': 1})
            self.assertEqual(result, expected)

        def test_to_namedtuple_ordered_dic(self):
            _tn = namedtuple('_tn', 'a b')
            test_dict

# Generated at 2022-06-21 12:49:05.592319
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from time import time
    from string import ascii_lowercase
    from random import choices
    from collections import ChainMap
    from flutils.namedtupleutils import _to_namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.miscutils import dict_dig
    from flutils.miscutils import dict_dig_set
    from flutils.miscutils import dict_dig_update
    from flutils.miscutils import dict_from_keys

    def test_logic(obj: Any, type_strs: Any = None) -> bool:
        """
        Args:
            obj:
            type_strs:

        Returns:

        """
        if isinstance(obj, dict):
            obj_ = to_namedtuple(obj)
            dict_str = 'dict'


# Generated at 2022-06-21 12:49:17.259335
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # convert dict to namedtuple
    d = dict(a = 1, b = 2, c = 3, d = 4)
    n = to_namedtuple(d)
    assert len(n) == 4
    assert n.a == 1 and n.b == 2 and n.c == 3 and n.d == 4

    # convert dict to namedtuple with a dict value
    d = dict(a = 1, b = 2, c = dict(d = 3, e = 4))
    n = to_namedtuple(d)
    assert hasattr(n.c, 'd') and hasattr(n.c, 'e')

    # convert dict to namedtuple with a list value
    d = dict(a = 1, b = 2, c = list(range(10)))
    n = to_namedtuple(d)

# Generated at 2022-06-21 12:49:27.647297
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = {'a': 1, 'b': 2, 'c': 3, 'd': 4, '_e': 5, 'f': 6}
    ans = to_namedtuple(data)
    assert ans == namedtuple('NamedTuple', ['a', 'b', 'c', 'd', 'f'])(1, 2, 3, 4, 6)
    data = [1, 2, 3, 4, 5, {'_a': 6, 'b': 7}]
    ans = to_namedtuple(data)
    assert ans == [1, 2, 3, 4, 5, namedtuple('NamedTuple', ['b'])(7)]


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:49:40.580606
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert (
        to_namedtuple({'a': 1, 'b': {'c': 3}, '_d': 4})
        == NamedTuple(a=1, b={'c': 3})
    )
    assert (
        to_namedtuple({'_a': 1, 'b': {'c': 3}})
        == NamedTuple(b={'c': 3})
    )

# Generated at 2022-06-21 12:49:52.699324
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2}}) == \
           NamedTuple(a=1, b=2, c=NamedTuple(a=1, b=2))
    d1 = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    assert to_namedtuple(d1) == NamedTuple(a=1, b=2, c=3)
    d1 = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-21 12:50:01.681329
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing function to_namedtuple...', end='')
    a = dict(
        a=1,
        b=[
            [dict(c=3)],
            [1, 2, 3],
            4,
        ],
        E=dict(
            d=dict(
                e=2,
            ),
        ),
        bdict=dict(
            dict(
                d=dict(
                    dd=dict(
                        dict(ddd=dict(dddd=dict(1))),
                    ),
                ),
            ),
        ),
    )
    # before = a.copy()
    # print(before)
    a_ = to_namedtuple(a)
    # print(a_)

# Generated at 2022-06-21 12:50:09.741214
# Unit test for function to_namedtuple
def test_to_namedtuple():

    test_dict = {"a": 1, "b": 2}
    assert to_namedtuple(test_dict) == namedtuple("NamedTuple", "a b")(a=1, b=2)
    assert to_namedtuple(test_dict).a == 1
    assert to_namedtuple(test_dict).b == 2

    test_dict = OrderedDict({"b": 2, "a": 1})
    assert to_namedtuple(test_dict) == namedtuple("NamedTuple", "b a")(b=2, a=1)
    assert to_namedtuple(test_dict).a == 1
    assert to_namedtuple(test_dict).b == 2

    test_dict = {"a": 1, "b": 2, "_c": 3}
    assert to_named

# Generated at 2022-06-21 12:50:24.916545
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {   'a': 1, 
            'b': 2
    }

    t = ('a', 'b')

    d2 = {  'a': {'b': 2},
            'c': 3
    }

    t2 = ('a', 'b')

    d3 = {  'a': {'a': 2}, 
            'b': 2
    }

    d4 = {'a': {'b': {'c': 3}, 'd': 4},
            'b': 2
    }

    d5 = {'a': {'b': {'c': 3}, 'd': 4, 'e': 5},
            'b': 2
    }  


# Generated at 2022-06-21 12:50:32.739952
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(list('abc')) == list('abc')
    lst = [list('abc'), list('def')]
    assert to_namedtuple(lst) == lst
    assert to_namedtuple(tuple('abc')) == tuple('abc')
    tup = (tuple('abc'), tuple('def'))
    assert to_namedtuple(tup) == tup
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic = {'a': 1, '_b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a')(a=1)
   

# Generated at 2022-06-21 12:50:44.455499
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import Mapping, Sequence
    from typing import Any, Union
    import unittest

    # noinspection PyPep8Naming
    class _to_namedtuple_TestCase(unittest.TestCase):
        """Unit test for :func:`to_namedtuple <flutils.namedtupleutils.to_namedtuple>`."""

        def test_to_namedtuple_dict(self):
            """Test :func:`to_namedtuple <flutils.namedtupleutils.to_namedtuple>`."""
            dic = {'a': 1, 'b': 2}
            nt = to_namedtuple(dic)
            self.assertIsInstance(nt, namedtuple)
            self.assertIsInstance(nt, tuple)

# Generated at 2022-06-21 12:50:54.021402
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple

    # noinspection PyUnusedLocal
    def _test(
            obj: Union[Sequence, Mapping, SimpleNamespace, namedtuple],
            expected: Union[NamedTuple, List, Sequence]
    ):
        assert to_namedtuple(obj) == expected

    dic = {'a': 1, 'b': 2}
    result = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    _test(dic, result)

    result = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)

# Generated at 2022-06-21 12:50:58.074362
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit testing for to_namedtuple
    """
    dict = {'a': 1, 'b': 2}
    assert to_namedtuple(dict) == NamedTuple(a=1, b=2)

# Generated at 2022-06-21 12:51:09.827093
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import datetime
    from collections import OrderedDict
    from types import SimpleNamespace
    tup = (1, 2, [3, 4], {'a': 5, 'b': 6}, (7, 8))
    lst = [1, 2, [3, 4], {'a': 5, 'b': 6}, (7, 8)]
    dic = {'a': 1, 'b': 2}
    odict = OrderedDict(a=1, b=2)
    sn = SimpleNamespace(a=1, b=2)
    nt = namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    rstup: Tuple[Any, ...] = to_namedtuple(tup)

# Generated at 2022-06-21 12:51:18.977611
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(('a', 'b')) == ('a', 'b')
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == to_namedtuple(dic)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    assert to_namedtuple(dic) == to_namedtuple(dic)
    dic = {1: 1, 2: 2, 3: 3, '4': 4, True: 5, False: 6, 'a': 'a', True: True}
    assert to_namedtuple(dic) == to_namedtuple(dic)

# Generated at 2022-06-21 12:51:31.175693
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import PrettyPrinter as PP
    import pytest
    pp = PP()

    # Test conversion of a simple list and tuple
    lst = [{'a': 1}]
    tup = tuple(lst)
    expected = (NamedTuple(a=1),)
    actual = to_namedtuple(tup)
    assert actual == expected, pp.pformat((actual, expected))
    actual = to_namedtuple(lst)
    assert actual == expected
    actual = to_namedtuple(tup[0])
    assert actual == expected[0]
    actual = to_namedtuple(lst[0])
    assert actual == expected[0]

    # Test converting a list of dictionaries to a list of namedtuples

# Generated at 2022-06-21 12:51:38.910025
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from typing import Dict, List

    assert to_namedtuple({
        'a': 1,
        'b': 2,
        '_c': 3,
    }) == NamedTuple(a=1, b=2)

    assert to_namedtuple([
        {
            'a': 1,
            'b': 2,
            '_c': 3,
        },
        {
            'a': 1,
            'b': 2,
            '_c': 3,
        },
        {
            'a': 1,
            'b': 2,
            '_c': 3,
        },
    ]) == [
        NamedTuple(a=1, b=2),
        NamedTuple(a=1, b=2),
        NamedTuple(a=1, b=2),
    ]



# Generated at 2022-06-21 12:51:46.076274
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from flutils.validators import validate_identifier
    import types

    # Test with no args
    # noinspection PyTypeChecker
    with pytest.raises(TypeError):
        to_namedtuple()

    # Test with non-existent namedtuple
    with pytest.raises(ValueError):
        to_namedtuple(None)

    # Test with list
    lst = [1, 2, 3]
    lst_namedtuple = to_namedtuple(lst)
    assert isinstance(lst_namedtuple, list)
    for i in range(3):
        assert lst_namedtuple[i] == lst[i]

    # Test with tuple


# Generated at 2022-06-21 12:52:08.635472
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d: dict = {'a': None, 'b': 1, 'c': None, 'd': 2}
    t = to_namedtuple(d)
    assert t.a is None
    assert t.b == 1
    assert t.c is None
    assert t.d == 2

# Generated at 2022-06-21 12:52:19.781985
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    import os
    import pickle
    from flutils.namedtupleutils import to_namedtuple
    from flutils.pathutils import (
        get_temp_file_path,
        get_temp_folder_path,
    )

    from flutils.pickleutils import (
        dump_pickle,
        load_pickle,
    )

    temp = get_temp_folder_path(
        prefix='flutils_test_',
        suffix='_namedtupleutils'
    )
    if not os.path.isdir(temp):
        os.makedirs(temp)

    temp_file = get_temp_file_path(
        parent=temp,
        prefix='flutils_test_',
        suffix='.pkl'
    )


# Generated at 2022-06-21 12:52:28.683882
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import (
        Dict,
        List,
    )
    from collections import OrderedDict

    def verify(out: Dict[str, Any], known: Dict[str, Any]) -> None:
        assert out._fields == known._fields
        for attr in out._fields:
            if hasattr(known, attr):
                assert getattr(out, attr) == getattr(known, attr)

    def verify_list(out: List[Any], known: List[Any]) -> None:
        assert len(out) == len(known)
        for i, item in enumerate(out):
            assert item == known[i]

    # Exception testing
    with pytest.raises(TypeError):
        to_namedtuple('1')  # type: ignore[arg-type]

# Generated at 2022-06-21 12:52:37.043910
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dtype = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': [3, 4, 5]}
    rtype = to_namedtuple(dtype)
    assert type(rtype) == namedtuple('NamedTuple', 'a b e')
    assert type(rtype.b) == namedtuple('NamedTuple', 'c d')
    assert type(rtype.e) == tuple
    assert rtype.a == 1
    assert rtype.e[2] == 5

    dtype = [1, 2, 3]
    rtype = to_namedtuple(dtype)
    assert type(rtype) == list
    assert rtype[2] == 3

    dtype = (1, 2, 3)

# Generated at 2022-06-21 12:52:47.992821
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (  # noqa
        to_namedtuple,
    )
    # noinspection PyUnusedLocal
    from collections import (  # noqa
        namedtuple,
    )
    from types import (  # noqa
        SimpleNamespace,
    )

    # Basic types
    obj = {'a': 1, 'b': 2, 'c': 3}
    expected = namedtuple('NamedTuple', 'a b c')(1, 2, 3)
    assert to_namedtuple(obj) == expected
    obj = (1, 2, 3)
    expected = (1, 2, 3)
    assert to_namedtuple(obj) == expected
    obj = [1, 2, 3]
    expected = [1, 2, 3]
    assert to_

# Generated at 2022-06-21 12:52:59.401388
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:53:01.456979
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == (1, 2)

# Generated at 2022-06-21 12:53:11.930604
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple 
    from collections import namedtuple
    from types import SimpleNamespace
    from collections import OrderedDict

    assert to_namedtuple([1,2,3]) == [1,2,3]
    assert to_namedtuple(tuple([1,2,3])) == tuple([1,2,3])
    assert to_namedtuple(OrderedDict((('c', 1), ('b', 2), ('a', 3)))) == \
           namedtuple('NamedTuple', 'a b c')(a=3, b=2, c=1)

# Generated at 2022-06-21 12:53:22.064516
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    class SampleObject(object):
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    class SampleNamedTuple(NamedTuple):
        a: int
        b: int
        c: int

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3

    ord_dic = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    out = to_namedtuple(ord_dic)
    assert out.a == 1
    assert out.b == 2

# Generated at 2022-06-21 12:53:29.596908
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest.mock as mock

    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    # noinspection PyUnusedFunction,Mypy
    @singledispatch
    def func(obj: Any) -> bool:
        raise NotImplementedError(obj)

    # noinspection PyUnusedFunction,Mypy
    @func.register(Mapping)
    def _(*args, **kwargs) -> bool:
        return True

    assert func(obj) is True

    ret = func(obj)
    assert ret is True

    with mock.patch('flutils.namedtupleutils._to_namedtuple') as m:
        m

# Generated at 2022-06-21 12:54:13.619779
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple,
        Flattener,
    )
    from collections import OrderedDict

    class Nested(object):
        def __init__(self, name: str, age: int, height: float) -> None:
            self.name = name
            self.age = age
            self.height = height

        def __repr__(self) -> str:
            return "Nested(%r, %r, %r) %s" % (
                self.name, self.age, self.height, super().__repr__()
            )


# Generated at 2022-06-21 12:54:23.645646
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def test_run():
        """Unit test for function to_namedtuple."""
        from collections import OrderedDict
        from types import SimpleNamespace

        from flutils.namedtupleutils import to_namedtuple

        # pylint: disable=unused-variable

        class Person(tuple):
            """Person tuple."""

            __slots__ = []
            _fields = ('first_name', 'last_name', 'age')

            def __new__(
                    cls, first_name: str, last_name: str, age: int
            ) -> 'Person':
                return tuple.__new__(cls, (first_name, last_name, age))

            @property
            def first_name(self):
                """Get first name."""
                return self[0]


# Generated at 2022-06-21 12:54:32.909354
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def ut_obj(obj):
        got = to_namedtuple(obj)
        print('IN:', obj, type(obj))
        print('OUT:', got, type(got))
        print('\n')
    dic = {'a': 1, 'b': 2}
    ut_obj(dic)
    lst = [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]
    ut_obj(lst)
    no_name = [{'a': 1, 'b': 2}, [{'a': 1, 'b': 2}]]
    ut_obj(no_name)
    one_name = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    ut_obj(one_name)
   

# Generated at 2022-06-21 12:54:39.022536
# Unit test for function to_namedtuple
def test_to_namedtuple():

    d_in, s_in, o_in = {'a': 1, 'b': 2}, (1, 2, 3), 'a'

    assert to_namedtuple(d_in) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(s_in) == s_in
    assert to_namedtuple(o_in) == o_in

# Generated at 2022-06-21 12:54:49.547519
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert to_namedtuple([['a', 'b', 'c'], ['a', 'b']]) == \
        [['a', 'b', 'c'], ['a', 'b']]
    assert to_namedtuple([['a', 'b', 'c'], OrderedDict({'a': 'b', 'c': 'd'})]) == \
        [['a', 'b', 'c'], OrderedDict({'a': 'b', 'c': 'd'})]
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'b': 2, 'a': 1}) == Named

# Generated at 2022-06-21 12:54:57.332374
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == \
        namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2, '_c': 3}, 'a']) == \
        [namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2), 'a']

# Generated at 2022-06-21 12:54:58.632161
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b_': 2}) == to_namedtuple({'a': 1, 'b_': 2})

# Generated at 2022-06-21 12:55:08.347155
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        Counter,
        namedtuple,
    )
    from collections.abc import (
        Mapping,
        Sequence,
    )
    from types import SimpleNamespace
    from typing import (
        Any,
        Dict,
        List,
        Tuple,
        Union,
    )
    from unittest import TestCase
    from unittest.mock import Mock
    from uuid import uuid4
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    _AllowedTypes = Union[
        List,
        Mapping,
        SimpleNamespace,
        Tuple,
    ]

    class _to_namedtupleTests(TestCase):
        """Tests for function to_namedtuple."""