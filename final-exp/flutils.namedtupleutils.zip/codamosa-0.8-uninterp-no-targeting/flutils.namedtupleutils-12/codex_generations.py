

# Generated at 2022-06-21 12:45:18.902001
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import unittest
    from flutils.collections import use_frozendict

    dic = {
        'c': 1,
        'b': 2,
        'e': 3,
        'a': 4,
    }
    # noinspection PyUnresolvedReferences
    expected = namedtuple('NamedTuple', 'a b c e')(4, 2, 1, 3)
    assert to_namedtuple(dic) == expected
    assert to_namedtuple(
        use_frozendict(dic)
    ) == expected


# Generated at 2022-06-21 12:45:29.796243
# Unit test for function to_namedtuple
def test_to_namedtuple():
    t1: dict = dict(a=1, b=2, c=3)
    assert to_namedtuple(t1) == namedtuple('NamedTuple', ('a', 'b', 'c'))(a=1, b=2, c=3)
    t2: dict = dict(a=dict(x=11, y=22), b=2, c=3)
    assert to_namedtuple(t2) == namedtuple('NamedTuple', ('a', 'b', 'c'))(a=namedtuple('NamedTuple', ('x', 'y'))(x=11, y=22), b=2, c=3)
    t3: dict = dict(a=dict(x=11, y=22), b=2, _c=3)
    assert to_namedt

# Generated at 2022-06-21 12:45:36.947539
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # TypeError
    with pytest.raises(TypeError):
        to_namedtuple(object())

    # List
    assert to_namedtuple([]) == []
    assert to_namedtuple(['a']) == ['a']
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple([True]) == [True]
    assert to_namedtuple([object()]) == [object()]

    dic1 = {'a': 1, 'b': 2}
    dic2 = {'a': 1, 'b': 2, 'c': 3}
    dic3 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

    # Dictionary
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()

# Generated at 2022-06-21 12:45:42.736709
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from utils.testing.utils import get_test_data
    from flutils.pytestutils import process_doc_function
    process_doc_function(
        get_test_data(),
        to_namedtuple,
        origin=None,
        prefix=False,
        default_expected_val=None,
        default_expected_type=None,
        default_test_type=True
    )



# Generated at 2022-06-21 12:45:53.445017
# Unit test for function to_namedtuple
def test_to_namedtuple():

    class MyNamedTuple(NamedTuple):
        a: int
        b: str

    class MySimpleNamespace(SimpleNamespace):
        a: int
        b: str

    assert to_namedtuple([{'a': 1, 'b': 2, '_c': 3}, {'a': 2, 'b': 3}]) == [
        NamedTuple(a=1, b=2),
        NamedTuple(a=2, b=3),
    ]
    assert to_namedtuple(([{'a': 1, 'b': 2, '_c': 3}], {'b': 3, 'a': 2})) == (
        (NamedTuple(a=1, b=2),),
        NamedTuple(a=2, b=3),
    )
    assert to_namedt

# Generated at 2022-06-21 12:46:04.455862
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:46:09.830080
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    dic = {'a': 1, 'b': 2}

    # Act
    result = to_namedtuple(dic)

    # Assert
    assert result[0] == 1


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:46:21.239933
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for function to_namedtuple."""

# Generated at 2022-06-21 12:46:23.978195
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()



# Generated at 2022-06-21 12:46:36.705446
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dictionary = {'a': 1, 'b': 2, 'c': 3}
    answer = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dictionary) == answer
    dictionary = {'a': 1, 'b': 2, 'c': 3}
    answer = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dictionary) == answer
    dictionary = {1: 2, 3: 4}
    answer = {1: 2, 3: 4}
    assert to_namedtuple(dictionary) == answer
    dictionary = {'a': 1, 'b': 2, 'c': 3}
    answer = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dictionary)

# Generated at 2022-06-21 12:46:49.607497
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic2 = {'d': 1, 'c': 2}
    assert to_namedtuple(dic2) == namedtuple('NamedTuple', 'c d')(c=2, d=1)

    dic3 = {'a': 1, 'b': dic}
    assert to_namedtuple(dic3) == namedtuple('NamedTuple', 'a b')(a=1, b=namedtuple('NamedTuple', 'a b')(a=1, b=2))

    dic4 = {'a': 1, 'b': dic3}

# Generated at 2022-06-21 12:47:02.035694
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic['c'] = 3
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic['_d'] = 4
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    assert to_namedtuple(dic.keys()) == ('a', 'b', 'c', '_d')

    assert to_namedtuple({'_a': 1}) == NamedTuple()

    dic = OrderedDict

# Generated at 2022-06-21 12:47:10.839192
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'_a': 1}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'_a': 1, '_b': 2}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == namedtuple('NamedTuple', 'a b')(1, 2)

# Generated at 2022-06-21 12:47:22.871978
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import List, Tuple


    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic['a_b'] = 3

# Generated at 2022-06-21 12:47:33.137766
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from copy import deepcopy
    from collections import defaultdict
    from typing import Dict
    from flutils.validators import is_valid_identifier

    def is_namedtuple(obj):
        return hasattr(obj, '_fields')

    assert is_namedtuple(to_namedtuple(defaultdict(dict))) is False
    assert is_namedtuple(to_namedtuple(dict())) is True
    assert is_namedtuple(to_namedtuple(dict(a=1, b=2))) is True
    assert is_namedtuple(to_namedtuple(OrderedDict(a=1, b=2))) is True
    assert is_namedtuple(to_namedtuple(SimpleNamespace(a=1, b=2))) is True

# Generated at 2022-06-21 12:47:42.951441
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2, 'c2': 3}
    out = to_namedtuple(obj)
    assert list(out._fields) == ['a', 'b', 'c2']
    assert out.a == 1
    assert out.b == 2
    assert out.c2 == 3

    obj = {'a': 1, 'b': 2, 'c2': {'a': 1, 'b': 2, 'c2': 3}, 'd': 4}
    out = to_namedtuple(obj)
    assert list(out._fields) == ['a', 'b', 'c2', 'd']
    assert out.a == 1
    assert out.b == 2
    assert out.d == 4

# Generated at 2022-06-21 12:47:54.275236
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test converting a list to NamedTuple."""
    names = ['a', 'b', 'c']
    values = [2, 3, 4]
    dic = dict(zip(names, values))
    dic2 = {'d': 5, 'e': 6}
    dic['f'] = dic2
    seq = [1, 2, dic]
    nt = to_namedtuple(seq)
    assert nt[2].f.d == 5

    # Test converting a tuple to NamedTuple
    names = ('a', 'b', 'c')
    values = (2, 3, 4)
    dic = dict(zip(names, values))
    dic2 = {'d': 5, 'e': 6}
    dic['f'] = dic2

# Generated at 2022-06-21 12:48:03.211574
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert type(to_namedtuple({})) is namedtuple('NamedTuple', '')
    assert type(to_namedtuple({'x': 1})) is namedtuple('NamedTuple', 'x')
    assert type(to_namedtuple({'x': 1, 'y': 2})) is namedtuple('NamedTuple', 'x y')
    assert type(to_namedtuple({'x': 1, 'y': 2, 'z': 3})) is namedtuple('NamedTuple', 'x y z')
    assert type(to_namedtuple({'x': 1, 'y': 2, 'z': 3, 'w': 4})) is namedtuple('NamedTuple', 'x y z w')

# Generated at 2022-06-21 12:48:13.735716
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(
        [
            {'a': 1, 'b': 2},
            {'a': 3, 'c': 4},
            {'d': 5, 'e': 6},
        ]
    ) == [
        namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2),
        namedtuple('NamedTuple', ['a', 'c'])(a=3, c=4),
        namedtuple('NamedTuple', ['d', 'e'])(d=5, e=6),
    ]


# Generated at 2022-06-21 12:48:20.945629
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def assert_outcome(obj):
        assert isinstance(obj, NamedTuple)
        assert obj.a == 1
        assert obj.b == 2
        assert obj.c == 3

    dic = dict(a=1, b=2, c=3)
    assert_outcome(to_namedtuple(dic))

    odic = OrderedDict(a=1, b=2, c=3)
    assert_outcome(to_namedtuple(odic))

    ns = SimpleNamespace(a=1, b=2, c=3)
    assert_outcome(to_namedtuple(ns))

    lis = [1, 2, 3]
    lis_nt = to_namedtuple(lis)
    assert lis == lis_nt

# Generated at 2022-06-21 12:48:33.692588
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2, 'c': [3, 4], 'd': [{'f': 5}, {'g': 6}], 'e': None}
    obj: NamedTuple = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == (3, 4)
    assert obj.d == ((NamedTuple(f=5),), (NamedTuple(g=6),))
    assert obj.e is None
    assert obj._asdict() == {'a': 1, 'b': 2, 'c': (3, 4),
        'd': ((NamedTuple(f=5),), (NamedTuple(g=6),)), 'e': None}
    from collections import OrderedDict
    d

# Generated at 2022-06-21 12:48:40.563274
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(tuple([1, 2, 3])) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict((('a', 1), ('b', 2)))) == NamedTuple(a=1, b=2)
    assert to_namedtuple(
        {'a': {'a2': 2}, 'b': [1, 2], '_c': {'c2': 2}}
    ) == NamedTuple(a=NamedTuple(a2=2), b=[1, 2])

# Generated at 2022-06-21 12:48:52.254202
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    x = {'a': 1, 'b': 2}
    assert to_namedtuple(x) == NamedTuple(a=1, b=2)
    y = OrderedDict(x.items())
    assert to_namedtuple(y) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(**x)) == NamedTuple(a=1, b=2)
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(tuple([1, 2, 3])) == (1, 2, 3)
    x = {'a': 1, 'b': 2}
    y = [1, 2, 3]

# Generated at 2022-06-21 12:49:03.655352
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
 
    lst = [dic, dic]
    assert to_namedtuple(lst) == lst
    assert not to_namedtuple(lst) == dic
 
    tup = tuple(lst)
    assert to_namedtuple(tup) == tup
    assert not to_namedtuple(tup) == dic
    assert not to_namedtuple(tup) == lst
 

# Generated at 2022-06-21 12:49:16.030967
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Any
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections import namedtuple
    from flutils.testutils import (
        AssertCallableReturnsValue,
        AssertCallableReturnsNone
    )
    from flutils.validators import validate_identifier
    
    # Basic usage:
    namedTuple = to_namedtuple({'a': 1, 'b': 2, 'c': 3})
    assert isinstance(namedTuple, namedtuple('NamedTuple', ['a', 'b', 'c']))
    assert namedTuple.a == 1
    assert namedTuple.b == 2
    assert namedTuple.c == 3
    
    # With OrderedDict:

# Generated at 2022-06-21 12:49:20.011363
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(
        name='to_namedtuple',
        verbose=True
    )


# Allow user to run this directly.
if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:49:27.517690
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections.abc
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), tuple)
    # noinspection PyUnresolvedReferences
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), collections.abc.Mapping)
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), namedtuple('NamedTuple', ['a', 'b']))
    assert to_namedtuple({'a': 1, 'b': 2}).a == 1


# Generated at 2022-06-21 12:49:40.441692
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # pylint: disable=missing-function-docstring
    # pylint: disable=expression-not-assigned
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name

    from flutils.namedtupleutils import to_namedtuple

    import collections

    test_data = collections.OrderedDict(
        [
            ('a', {'b': 1, 'c': [2, 3], 'd': ('e', 'f'), 'g': {'h': 4, 'i': 5}}),
            ('j', {'m': {'n': 6}}),
            ('o', {'p': {'q': 7}}),
            ('r', {'s': {'t': 8}}),
        ]
    )

    obj = to_namedtuple

# Generated at 2022-06-21 12:49:44.791465
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    """Unit test for function to_namedtuple.

    This ensures the function is documented.
    """
    import doctest  # type: ignore
    err, _ = doctest.testmod()
    assert err == 0

# Generated at 2022-06-21 12:49:56.142414
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert isinstance(to_namedtuple(dic), namedtuple('NamedTuple', 'a b'))
    #
    dic = {'_a': 1}
    assert to_namedtuple(dic) == NamedTuple(a=1)
    assert isinstance(to_namedtuple(dic), namedtuple('NamedTuple', 'a'))
    #
    dic = {'a': 1, 'b': 2, 3: 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

# Generated at 2022-06-21 12:50:06.200529
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    d = {'a': 1, 'b': 2}
    out = to_namedtuple(d)
    assert out == (1, 2)
    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out == (1, 2, 3)
    dic2 = OrderedDict()
    dic2['c'] = 1
    dic2['b'] = 2
    dic2['a'] = 3
    out = to_namedtuple(dic2)
    assert out == (1, 2, 3)
    d = dict(a=1, b=2, c=3)
    out = to_named

# Generated at 2022-06-21 12:50:19.512862
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    """
    This function tests the function to_namedtuple.
    """
    import sys
    import unittest

    class ToNamedTupleTestCase(unittest.TestCase):

        def test_namedtuple(self):
            """
            This function tests that a namedtuple stays the same.
            """
            ntuple = namedtuple('NamedTuple', ['a', 'b', 'c'])
            a, b, c = 1, 2, 3
            t = ntuple(a, b, c)
            res = to_namedtuple(t)
            self.assertNotEqual(t, res)  # type: ignore[arg-type]
            self.assertEqual(a, res.a)

# Generated at 2022-06-21 12:50:29.678483
# Unit test for function to_namedtuple
def test_to_namedtuple():

    def _assert_type(val, val_type):
        assert isinstance(val, val_type)

    # Test: TypeError when non-list, non-tuple, non-dict is given
    try:
        to_namedtuple('hello')
        assert False
    except TypeError:
        assert True

    # Test: empty list
    out = to_namedtuple([])
    _assert_type(out, list)
    assert len(out) == 0

    # Test: list with one item
    out = to_namedtuple(['world'])
    _assert_type(out, list)
    assert len(out) == 1
    assert out[0] == 'world'

    # Test: empty tuple
    out = to_namedtuple(())
    _assert_type(out, tuple)

# Generated at 2022-06-21 12:50:31.094644
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-21 12:50:42.785283
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    dictionary = OrderedDict([('order', 1), ('name', 'name'), ('age', 10)])
    assert to_namedtuple(dictionary) == \
            namedtuple('NamedTuple', 'age name order')(10, 'name', 1)

    dictionary = {'order': 1, 'name': 'name', 'age': 10}
    assert to_namedtuple(dictionary) == \
            namedtuple('NamedTuple', 'age name order')(10, 'name', 1)

    dictionary = {'name': 'name', '_notvalidid': '_notvalidid', 'name': 'name'}
    assert to_namedtuple(dictionary) == \
            namedtuple('NamedTuple', 'name')('name')



# Generated at 2022-06-21 12:50:52.994710
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic = {'a': 1, 'c': 3, 'b': 2}
    
    out = to_namedtuple(dic)
    
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert hasattr(out, 'c')
    
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3
    
    assert out[0] == 1
    assert out[1] == 2
    assert out[2] == 3
    
    assert out[0] == out.a
    assert out[1] == out.b
    assert out[2] == out.c
    
    tup = (1, 2, 3)
    
    out = to_namedtuple(tup)


# Generated at 2022-06-21 12:51:05.167690
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pformat
    from typing import Dict, Union

    d: Dict[str, Union[int, Dict[str, int]]] = {
        'a': 1,
        'b': {
            'b1': 11,
            'b2': 22,
            'b3': 33,
        },
        'c': {
            'c1': {
                'c11': 111,
                'c12': 222,
            },
            'c2': {
                'c21': 321,
                'c22': 322,
            },
            'c3': {
                'c31': 331,
                'c32': 332,
            },
        },
    }
    # noinspection PyShadowingNames

# Generated at 2022-06-21 12:51:15.891731
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'key': 1,
        'key2': {
            'b': 2,
        },
    }

    assert to_namedtuple(dic) == namedtuple(
        'NamedTuple',
        ('key', 'key2')
    )(1, namedtuple('NamedTuple', ('b',))(2))
    assert (
        to_namedtuple([dic]) == [
            namedtuple('NamedTuple', ('key', 'key2'))(
                1, namedtuple('NamedTuple', ('b',))(2)
            )
        ]
    )

# Generated at 2022-06-21 12:51:26.562789
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.utils import to_json
    from flutils.tests.data.dtos import (
        dto,
        dto_list,
        dto_nested,
        dto_nested_list,
        dto_od,
        dto_od_list,
    )
    from flutils.tests.data.dtos.dtos import (
        DTO,
        DTOList,
        DTOOrderedDict,
        DTOOrderedDictList,
        DTOSimpleNamespace,
        DTOSimpleNamespaceList,
    )
    import json

    single = to_namedtuple(dto)
    dto_json = to_json(dto)
    single_json = to_json(single)
    assert json.loads(dto_json) == json

# Generated at 2022-06-21 12:51:36.308167
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from flutils.namespacedictutils import NamespaceDict

    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)

    obj = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    assert to_namedtuple(obj) == \
        namedtuple('NamedTuple', ['a', 'b', 'c'])(1, 2,
                                                  namedtuple('NamedTuple', ['d', 'e'])(3, 4))


# Generated at 2022-06-21 12:51:48.380895
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    from .testutils import TestCase

    from typing import Any

    class TestToNamedtuple(TestCase):
        def test_dict(self):
            dic = OrderedDict()
            dic['a'] = 1
            dic['b'] = 2
            dic['1y'] = 0
            arg = dic

            result = to_namedtuple(arg)

            self.assertIsInstance(result, namedtuple)
            self.assertEqual(result.a, 1)
            self.assertEqual(result.b, 2)
            with self.assertRaises(AttributeError):
                getattr(result, '1y')

        def test_dict_recurse(self):
            arg = {'a': 1, 'b': {'1': 0}}

           

# Generated at 2022-06-21 12:51:58.959857
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': {
            'b': {
                'c': 1,
                'd': 2,
                'e': {
                    'f': {
                        'g': {
                            'h': 1,
                            'i': 2,
                        },
                    },
                },
            },
        },
        'x': {
            'y': {
                'z': 1,
            },
        },
        'y': {
            'z': 2,
        },
        'z': 1,
    }
    rval = to_namedtuple(dic)
    assert hasattr(rval, 'a')
    assert hasattr(rval, 'z')
    assert hasattr(rval.a, 'b')
    assert hasattr(rval.a.b, 'c')

# Generated at 2022-06-21 12:52:02.960602
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class Person:

        def __init__(self, first_name: str, last_name: str):
            self.first_name = first_name
            self.last_name = last_name

    class Family:

        def __init__(self, members: List[Person]):
            self.members = members

    # noinspection PyProtectedMember
    def _check(got: Any, want: Any, _expect: Any = None):
        for attr in want._fields:
            want_attr = getattr(want, attr)
            got_attr = getattr(got, attr)
            # noinspection PyTypeChecker
            want_attr = want_attr or ()
            if len(want_attr) > 1:
                _check(got_attr, want_attr[:2])

# Generated at 2022-06-21 12:52:08.516733
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:52:19.780530
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    def _test(
            dic: Dict[str, Any],
            ntpl: NamedTuple,
            *,
            ordered: bool = False
    ) -> None:
        dic['__order'] = ntpl._fields
        odic = collections.OrderedDict(dic)
        ntpl_1 = to_namedtuple(odic)
        ntpl_2 = to_namedtuple(odic.copy())
        ntpl_3 = to_namedtuple(ntpl)
        assert ntpl_1 == ntpl_2 == ntpl_3
        # noinspection PyUnresolvedReferences
        sn = SimpleNamespace(**dic)
        ntpl_4 = to_namedtuple(sn)

# Generated at 2022-06-21 12:52:28.673224
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple as _m_to_namedtuple
    from flutils.testing.helpers import BasicTestCase

    class TestToNamedTuple(BasicTestCase):
        def test_to_namedtuple(self):
            obj = {'a': 1, 'b': 2}
            expected = BasicTestCase.NamedTuple(a=1, b=2)

            self.assertEqual(_m_to_namedtuple(obj), expected)
            self.assertEqual(to_namedtuple(obj), expected)

            obj = OrderedDict(a=1, b=2)

# Generated at 2022-06-21 12:52:37.507636
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    ntup = to_namedtuple(dic)
    assert ntup == NamedTuple(a=1, b=2)
    ntup = to_namedtuple([dic, dic])
    assert ntup == [NamedTuple(a=1, b=2), NamedTuple(a=1, b=2)]
    dic = {'a': {'c': 1}, 'b': 2}
    ntup = to_namedtuple(dic)
    assert ntup == NamedTuple(a=NamedTuple(c=1), b=2)

# Generated at 2022-06-21 12:52:48.444316
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # start tests
    # noinspection PyUnusedLocal
    def test_identifier(raise_val: bool = False) -> None:
        start = {
            'a': 1,
            'b': 2,
            'c': (1, 2),
        }
        start['d'] = start
        ans = to_namedtuple(start)
        assert repr(ans) == "NamedTuple(a=1, b=2, c=(1, 2), d=NamedTuple(a=1, " \
               "b=2, c=(1, 2), d=...))"
        if raise_val is False:
            # noinspection PyUnresolvedReferences
            foo = ans.a  # type: ignore[attr-defined]
            assert foo == 1
            # noinspection PyUnresolvedReferences


# Generated at 2022-06-21 12:52:59.750756
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test conversion to namedtuple"""
    # noinspection PyUnresolvedReferences
    from flutils.testutils import BasicTestCase

    class TestCase(BasicTestCase):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, do_assert=False, **kwargs)

        def test_to_namedtuple_basic(self):
            # Should fail for a non-convertible type
            obj = 1
            self.assertRaisesRegex(
                TypeError,
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                "got: \(.*\) 1",
                to_namedtuple,
                obj
            )


# Generated at 2022-06-21 12:53:05.646653
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    val = {'a': 1, 'b': 2}
    expt = '(a=1, b=2)'
    with pytest.raises(TypeError):
        out = to_namedtuple('a')
    out = to_namedtuple(val)
    assert expt == str(out)



# Generated at 2022-06-21 12:53:28.026965
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pprint
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-21 12:53:32.063205
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2]) == [1, 2]


if __name__ == "__main__":
    print('\n\n' + '=' * 80)
    print('Unit test for function to_namedtuple')
    print('=' * 80)
    test_to_namedtuple()

# Generated at 2022-06-21 12:53:38.330773
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple as _to_namedtuple
    from collections import (
        OrderedDict,
        namedtuple,
    )  # noqa: N812
    from types import SimpleNamespace

    NamedTuple = namedtuple('NamedTuple', '')
    Data = namedtuple('Data', 'a b c')
    obj = [1, 2, 3]
    obj = _to_namedtuple(obj)
    assert isinstance(obj, list)
    assert isinstance(obj[0], int) and obj[0] == 1
    assert isinstance(obj[1], int) and obj[1] == 2
    assert isinstance(obj[2], int) and obj[2] == 3
   

# Generated at 2022-06-21 12:53:48.929451
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    assert to_namedtuple('Foo') == 'Foo'
    assert to_namedtuple(1) == 1

    with pytest.raises(TypeError):
        to_namedtuple({1: 1})

    dic = {'a': 1, 'b': 2}
    nt1 = to_namedtuple(dic)
    assert nt1 == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    nt2 = to_namedtuple(OrderedDict(a=1, b=2))
    assert nt2 == namedtuple('NamedTuple', 'a b')(a=1, b=2)


# Generated at 2022-06-21 12:53:57.793870
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # 'from' import statement above
    assert callable(to_namedtuple)
    assert to_namedtuple.__name__ == 'to_namedtuple'
    assert to_namedtuple.__doc__

# Generated at 2022-06-21 12:54:03.959131
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple."""
    from collections import namedtuple
    from copy import deepcopy
    from datetime import date
    from decimal import Decimal
    from flutils.tests.data import (
        nontup_dict,
        nontup_list,
        nontup_odict,
        nontup_set,
        nontup_sn,
        nontup_sp,
        nontup_tup,
        tup_dict,
        tup_list,
        tup_odict,
        tup_sn,
        tup_sp,
        tup_tup,
    )
    # Make sure TypeError is raised for the wrong type

# Generated at 2022-06-21 12:54:12.902172
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    namedtup = to_namedtuple(dic)
    assert namedtup is not None
    assert namedtup.a == 1
    assert namedtup.b == 2
    assert namedtup == NamedTuple(a=1, b=2)

    lst = [1, 2, 3]
    namedtup = to_namedtuple(lst)
    assert namedtup is not None
    assert namedtup == [1, 2, 3]

    tup = (1, 2, 3)
    namedtup = to_namedtuple(tup)
    assert namedtup is not None
    assert namedtup == (1, 2, 3)

    tup = (1, 2, dic)
    namedtup = to_

# Generated at 2022-06-21 12:54:23.459919
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import OrderedDict

    from flutils.miscutils import to_simple_named_tuple

    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1}
    make = namedtuple('make', 'a')
    make_out = make(a=1)
    assert to_namedtuple(dic) == make_out

    dic = {'a': 1, 'b': 2}
    make = namedtuple('make', 'a b')
    make_out = make(a=1, b=2)
    assert to_namedtuple(dic) == make_out

    dic = {'b': 2, 'a': 1}
    make = namedtuple('make', 'a b')

# Generated at 2022-06-21 12:54:32.839763
# Unit test for function to_namedtuple
def test_to_namedtuple():
    names = [
        'NamedTuple', 'SimpleNamespace'
    ]

    # namedtuple
    in_ = namedtuple('NamedTuple', ['a', 'b'])
    assert in_.a == 0
    assert in_.b == 0
    out = to_namedtuple(in_)
    assert out.a == 0
    assert out.b == 0
    assert in_ == out
    assert type(in_).__name__ in names

    # simple_namespace
    in_ = SimpleNamespace(a=0, b=0)
    out = to_namedtuple(in_)
    assert out.a == 0
    assert out.b == 0
    assert in_.a == out.a
    assert in_.b == out.b
    assert type(out).__name__ in names

   

# Generated at 2022-06-21 12:54:42.156848
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    dic1 = {'a': 1, 'b': 2}
    nt1 = to_namedtuple(dic1)
    assert nt1.a == 1
    assert nt1.b == 2
    nt2 = to_namedtuple(OrderedDict([('c', 3), ('d', 4)]))
    assert nt2.c == 3
    assert nt2.d == 4