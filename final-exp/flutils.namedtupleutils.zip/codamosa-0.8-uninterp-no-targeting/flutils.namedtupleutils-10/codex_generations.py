

# Generated at 2022-06-21 12:45:17.011837
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _test_to_namedtuple(actual, expected):
        assert actual == expected


    _test_to_namedtuple(
        to_namedtuple([{'a': 1, 'b': 2, 'c': 3}, {'a': 4, 'b': 5, 'c': 6}]),
        [NamedTuple(a=1, b=2, c=3), NamedTuple(a=4, b=5, c=6)]
    )

# Generated at 2022-06-21 12:45:28.200554
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    # list
    assert to_namedtuple(list()) == list()
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple([1.0, 2.0, 3.0]) == [1.0, 2.0, 3.0]
    assert to_namedtuple([[1], [2], [3]]) == [[1], [2], [3]]
    assert to_namedtuple([[1, 2], [2, 3]]) == [[1, 2], [2, 3]]
    assert to_namedtuple(['one', 'two', 'three']) == ['one', 'two', 'three']
    # tuple
    assert to_namedtuple(tuple()) == tuple()

# Generated at 2022-06-21 12:45:35.911809
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', ('a', ))(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == namedtuple('NamedTuple', ('a', 'b', 'c'))(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, '_b': 2, 'c': 3}) == namedtuple('NamedTuple', ('a', 'c'))(a=1, c=3)

# Generated at 2022-06-21 12:45:45.944012
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'_a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(b=2)
    dic = {'a': 1, 'b_': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1)
    dic = {1: 1, 2: 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {1: 1, 2: 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

# Generated at 2022-06-21 12:45:49.936080
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from pprint import pformat
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import doctest
    print(doctest.testmod(verbose=True))

# Generated at 2022-06-21 12:45:57.196244
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'a.b': 3}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'a_b': 3}) == NamedTuple(a=1, a_b=3, b=2)
    assert to_namedtuple(dict(a=1, b=2, a_b=3)) == NamedTuple(a=1, a_b=3, b=2)
    assert to_namedtuple(dict(a=1, b=2, )) == NamedTuple(a=1, b=2)
    assert to_namedt

# Generated at 2022-06-21 12:46:06.651860
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import (
        Dict,
        List,
        Mapping,
        OrderedDict,
        Tuple,
        Union,
    )

    from flutils.namedtupleutils import (
        NamedTuple,
        to_namedtuple,
    )

    from flutils.validators import validate_identifier

    # noinspection PyTypeChecker
    from flutils.typing import (  # type: ignore[attr-defined]
        DictType,
        ListType,
        MappingType,
        OrderedDictType,
        TupleType,
        UnionType,
    )

    def z_to_namedtuple_type():
        """type: (...) -> NamedTuple"""


# Generated at 2022-06-21 12:46:12.628389
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2,
    }
    namedtuple_ = to_namedtuple(dic)
    assert namedtuple_.a == 1
    assert namedtuple_.b == 2


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:46:22.820185
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from math import isclose
    from unittest import TestCase
    from .namespaceutils import to_namespace
    from .pydictutils import normal_dict

    class _TestToNamedTuple(TestCase):

        def setUp(self):
            self.good = {
                'a': 1,
                'b': 2,
                'c': '3',
                'd': [4, 5, 6],
                'e': (7, 8),
                'f': {
                    'g': 9,
                    'h': 10,
                }
            }
            self.result = normal_dict(self.good)
            self.result.update({'_x': 'X'})
            self.result.update({'x': 'X'})
            self.result.update({'X': 'x'})


# Generated at 2022-06-21 12:46:25.429876
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    return True

# Generated at 2022-06-21 12:46:41.755209
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    obj = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(obj)
    assert nt.a == obj['a']
    assert nt.b == obj['b']
    assert nt.c == obj['c']
    assert f'{nt}' == "NamedTuple(a=1, b=2, c=3)"
    print(f'\n{nt}')

    obj = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
    ])
    nt = to_namedtuple(obj)
    assert nt.a == obj['a']

# Generated at 2022-06-21 12:46:45.115809
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-21 12:46:56.973876
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import os
    import re
    import sys
    import unittest

    from collections import OrderedDict

    def create_ordered_dict(dic: dict) -> OrderedDict:
        out: OrderedDict = OrderedDict()
        for key, val in dic.items():
            out[key] = val
        return out

    class ToNamedTupleTest(unittest.TestCase):
        func = staticmethod(to_namedtuple)

        maxDiff, __slots__ = None, ()


# Generated at 2022-06-21 12:47:08.367300
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Sequence
    from datetime import date, datetime
    from decimal import Decimal
    from enum import Enum
    from flutils.datautils import Date
    from flutils.jsonutils import json_hook
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from typing import List, NamedTuple, Union, Tuple
    import unittest
    import json

    class JSON(NamedTuple):
        obj: Union[str, int, float, bool, None]

    class JSONTest(unittest.TestCase):
        def test_to_namedtuple_1(self):
            test: JSON = JSON('test')
            out = to_namedtuple(test)
            self.assertEqual(test, out)

# Generated at 2022-06-21 12:47:21.082669
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'c': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, c=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    odic = OrderedDict(a=1, b=2, c=3)
    assert to_namedtuple(odic) == NamedTuple(a=1, b=2, c=3)

   

# Generated at 2022-06-21 12:47:26.764344
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == dic['a']
    assert nt.b == dic['b']


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:47:36.099107
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:47:45.827671
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils._testing import assert_type

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_type(out, NamedTuple, exact=False)
    assert_type(out.a, int)
    assert_type(out.b, int)

    dic2 = OrderedDict(
        [
            ('a', 1),
            ('b', 2),
        ]
    )
    out = to_namedtuple(dic2)
    assert_type(out, NamedTuple, exact=False)
    assert_type(out.a, int)
    assert_type(out._asdict(), dict)


# Generated at 2022-06-21 12:47:58.169361
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple."""
    # tests for the functional form of to_namedtuple
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'b': 1, 'a': 2}) == namedtuple('NamedTuple', 'a b')(2, 1)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}) == namedtuple('NamedTuple', 'a b c')(1, 2, {'d': 3, 'e': 4})

# Generated at 2022-06-21 12:48:09.577680
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from py.test import raises
    from flutils.namedtupleutils import to_namedtuple
    from datetime import date
    from collections import OrderedDict
    from types import SimpleNamespace

    with raises(TypeError) as exc_info:
        to_namedtuple(date.today())
    assert str(exc_info.value) == "Can convert only 'list', 'tuple', 'dict' " \
                                  "to a NamedTuple; got: (%r) " \
                                  "<class 'datetime.date'> 2017-12-20"

# Generated at 2022-06-21 12:48:18.910098
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'x': 1, 'y': 2, 'z': (1, 2, 3)}
    out = to_namedtuple(obj)
    assert out.x == 1
    assert out.y == 2
    assert out.z == (1, 2, 3)
    obj = [1, 2, 3, 4]
    out = to_namedtuple(obj)
    assert out == [1, 2, 3, 4]
    obj = (1, 2, 3, 4)
    out = to_namedtuple(obj)
    assert out == (1, 2, 3, 4)

# Generated at 2022-06-21 12:48:23.426753
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple as _
    import pytest

    # Happy path
    obj = {'a': 1, 'b': 2}
    got = to_namedtuple(obj)
    assert got == _(obj)
    assert got.a == 1
    assert got.b == 2

    # Happy path with underscore
    obj = {'a_': 1, 'b_': 2}
    got = to_namedtuple(obj)
    assert got == _(obj)
    assert got.a_ == 1
    assert got.b_ == 2
    assert got == _(obj)

    # Happy path with underscore for method name
    obj = {'a__': 1, 'b__': 2}

# Generated at 2022-06-21 12:48:33.736602
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest.mock as mock

    from flutils.namedtupleutils import _to_namedtuple

    _mock = mock.MagicMock()

    assert _to_namedtuple(None) == _mock
    assert _to_namedtuple(1) == _mock
    assert _to_namedtuple(1.0) == _mock
    assert _to_namedtuple(1 + 2j) == _mock
    assert _to_namedtuple(NotImplemented) == _mock
    assert _to_namedtuple(Ellipsis) == _mock
    assert _to_namedtuple(bytes()) == _mock
    assert _to_namedtuple(bytearray()) == _mock
    assert _to_namedtuple(memoryview(b'')) == _m

# Generated at 2022-06-21 12:48:35.844582
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    result = to_namedtuple(obj)
    assert result.a == 1
    assert result.b == 2

# Generated at 2022-06-21 12:48:47.341492
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2

    dic = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    nt = to_namedtuple(dic)
    assert isinstance(nt, list)
    assert isinstance(nt[0], NamedTuple)

# Generated at 2022-06-21 12:48:56.536802
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import os
    import pathlib
    from pprint import pprint
    from typing import Any
    from flutils.collections import (
        DictList,
        DictMapping,
        DictSet,
        DictTuple,
        DictView,
    )
    from flutils.namedtupleutils import (
        NamedTupleList,
        NamedTupleMapping,
        NamedTupleSet,
        NamedTupleTuple,
        NamedTupleView,
        to_namedtuple,
    )

    def _print_and_compare(obj: Any) -> None:
        pprint(obj)
        if isinstance(obj, DictList):
            obj = NamedTupleList(to_namedtuple(obj))

# Generated at 2022-06-21 12:49:01.407234
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b', 'c']) == ('a', 'b', 'c')
    assert to_namedtuple(dict(a=1, b=2, c=3)) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)



# Generated at 2022-06-21 12:49:04.895535
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = {
        'a': 1,
        'b': 2,
    }

    nt = to_namedtuple(data)

    assert type(nt) is namedtuple('NamedTuple', 'a b')
    assert nt.a == 1
    assert nt.b == 2

# Generated at 2022-06-21 12:49:17.110501
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils as namedtupleutils
    dic = {
        'a': 1,
        'b': {
            'a': 1,
            'b': 2
        },
        'c': {
            'a': 1,
            'c': 3
        }
    }
    dic_to_namedtuple = namedtupleutils.to_namedtuple(dic)
    assert dic_to_namedtuple.a == 1
    assert dic_to_namedtuple.b.a == 1
    assert dic_to_namedtuple.b.b == 2
    assert dic_to_namedtuple.c.a == 1
    assert dic_to_namedtuple.c.c == 3


# Generated at 2022-06-21 12:49:27.855468
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from textwrap import dedent
    from pprint import pformat

    # Simple namedtuple
    nt1 = to_namedtuple({'a': 1, 'b': 2, 'c': 3})
    assert str(nt1) == "NamedTuple(a=1, b=2, c=3)"

    # OrderedDict to NamedTuple
    nt2 = to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)]))
    assert str(nt2) == "NamedTuple(a=1, b=2, c=3)"

    # list with simple NamedTuple
    nt3 = to_namedtuple([{'a': 1, 'b': 2}, {'c': 3}])

# Generated at 2022-06-21 12:49:43.179687
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    # noinspection PyShadowingNames
    def _test_to_namedtuple_expected(
            obj: Any,
            expected: Any,
            return_type: Any,
            is_copy: bool = True
    ):
        if is_copy:
            obj = copy.deepcopy(obj)
        result = to_namedtuple(obj)
        assert isinstance(result, return_type)
        assert result == expected

    # noinspection PyShadowingNames
    def _test_to_namedtuple_fails(obj: Any):
        with pytest.raises(TypeError):
            to_namedtuple(obj)

    src_dic = {'a': 1, 'b': 2}

# Generated at 2022-06-21 12:49:54.842851
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from untp import __version__
    from untp.decorators import class_function_test
    from untp.utils import (
        get_test_modules,
        run_test_module,
    )
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from flutils.validators import validate_identifier
    # Set up test runner
    test_modules = get_test_modules(__file__)
    test_module = test_modules[0]
    target_module = test_module.__name__.rsplit('.', 1)[0]
    # Tests

# Generated at 2022-06-21 12:50:03.069828
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest
    # List
    data = [1]
    result = to_namedtuple(data)
    assert result == ([1],)
    # OrderedDict
    data = OrderedDict(a=1, b=2, c=3)
    result = to_namedtuple(data)
    assert result == (1, 2, 3)
    # NamedTuple
    Example2 = namedtuple('Example2', 'a b')
    data = Example2(a=1, b=2)
    result = to_namedtuple(data)
    assert result == (1, 2)
    # Sequence
    data = (1, 2, 3)
    result = to_namedtuple(data)

# Generated at 2022-06-21 12:50:08.995534
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple

    a = dict(a=1, b=2)
    assert to_namedtuple(a) == to_namedtuple(OrderedDict(a))

    a = dict(z=1, b=2)
    assert to_namedtuple(a) == to_namedtuple(OrderedDict(a))

    a = dict(b=1, a=2)
    assert to_namedtuple(a) == to_namedtuple(OrderedDict(a))

    a = dict(_b=1, a=2)
    assert to_namedtuple(a) == to_namedtuple(OrderedDict(a))

    a = dict(b=1, _a=2)
    assert to

# Generated at 2022-06-21 12:50:22.365881
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from flutils.validators import validate_identifier

    ntuple_a = namedtuple('NamedTuple', 'a')
    ntuple_b = namedtuple('NamedTuple', 'b')
    ntuple_c = namedtuple('NamedTuple', 'c')

    obj = [ntuple_a(1), ntuple_b(2), ntuple_c(3)]
    assert to_namedtuple(obj) == [NamedTuple(a=1), NamedTuple(b=2), NamedTuple(c=3)]

    obj = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2, c=3)

# Generated at 2022-06-21 12:50:30.188503
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple(dict(a=1)), NamedTuple)
    assert isinstance(to_namedtuple(OrderedDict(a=1)), NamedTuple)
    assert isinstance(to_namedtuple(SimpleNamespace(b=1)), NamedTuple)
    assert isinstance(to_namedtuple(tuple(a=1)), NamedTuple)
    assert isinstance(to_namedtuple(list(a=1)), NamedTuple)
    assert isinstance(to_namedtuple(set(a=1)), NamedTuple)
    assert isinstance(to_namedtuple(frozenset(a=1)), NamedTuple)

# Generated at 2022-06-21 12:50:41.670525
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection DuplicatedCode
    def assert_raises_type_error(obj):
        try:
            to_namedtuple(obj)
        except TypeError:
            return
        raise AssertionError('no exception raised; expected a TypeError')

    assert_raises_type_error(list)
    assert_raises_type_error(dict)
    assert_raises_type_error(namedtuple('Foo', 'bar'))
    assert_raises_type_error(5)
    assert_raises_type_error('')
    assert_raises_type_error(SimpleNamespace)
    assert_raises_type_error('foobar')
    assert_raises_type_error(True)
    assert_raises_type_error(False)
    assert_raises_type

# Generated at 2022-06-21 12:50:42.835954
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:50:47.832640
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(
        optionflags=doctest.ELLIPSIS,
        extraglobs={'OrderedDict': OrderedDict, 'SimpleNamespace': SimpleNamespace}
    )

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:50:55.543163
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Test :func:`flutils.namedtupleutils.to_namedtuple`'''
    # standard tuple
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    # standard list
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    # standard dict
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    # standard OrderedDict
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    # standard Namespace

# Generated at 2022-06-21 12:51:10.192564
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def assert_namedtuple(obj: _AllowedTypes) -> None:
        out = to_namedtuple(obj)
        assert isinstance(out, NamedTuple)

    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple)
    assert out == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    obj = dict(a=1, b=2)
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple)
    assert out == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    obj = OrderedDict(a=1, b=2)
    out = to_namedtuple

# Generated at 2022-06-21 12:51:19.226743
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import patch
    # noinspection PyProtectedMember
    from flutils.namedtupleutils import _to_namedtuple

    class TestCase(NamedTuple):
        pass

    obj = TestCase()
    out = _to_namedtuple(obj, _started=True)
    assert obj == out

    obj = TestCase(foo=None)
    out = _to_namedtuple(obj, _started=True)
    assert obj == out

    obj = TestCase(foo=1)
    out = _to_namedtuple(obj, _started=True)
    assert obj == out

    obj = OrderedDict(a=1, b=2, c=3)
    out = _to_namedtuple(obj, _started=True)

# Generated at 2022-06-21 12:51:31.450800
# Unit test for function to_namedtuple
def test_to_namedtuple():
    r"""Test the to_namedtuple function."""
    # Simple dictionary
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    # Dictionaries in list
    dic1 = {'a': 1, 'b': 2}
    dic2 = {'a': 3, 'b': 4}
    lst = [dic1, dic2]
    out: List[NamedTuple] = to_namedtuple(lst)
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[1].a == 3
    assert out[1].b == 4
    # Simple tuple
    tup = ('a', 'b')
    out

# Generated at 2022-06-21 12:51:39.312210
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testingutils import TestData

    # Arrange
    test_data = TestData()

    # Act

    # Assert
    tup = (1, (2, 3), {'a': 'b', 'c': 'd'}, ['e', 'f'])
    out = to_namedtuple(tup)
    test_data.append_value(
        expected=tuple,
        actual=type(out)
    )
    assert test_data.is_all_true()

    # Arrange
    test_data = TestData()

    # Act

# Generated at 2022-06-21 12:51:47.984159
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(('x', 1, [1, 2, 3], {'y': 42, 'z': 33})) == \
        namedtuple('NamedTuple',
                   ['x', 'y', 'z'])('x', 1, [1, 2, {'y': 42, 'z': 33}])
    assert to_namedtuple([
        'x', 1, ['y', 2, {'z': 3, 'b': 6, 'c': 7}]
    ]) == [
        'x', 1, ['y', 2, {'z': 3, 'b': 6, 'c': 7}]
    ]

# Generated at 2022-06-21 12:51:58.737486
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for function to_namedtuple."""

    import copy
    import unittest
    import uuid

    from flutils.namedtupleutils import to_namedtuple

    class ToNamedTupleTestCase(unittest.TestCase):
        """Unit tests for function to_namedtuple."""

        def test_convert_dict(self):
            """Test converting a dictionary to a namedtuple."""
            obj = {
                'a': 1,
                'b': 2,
            }
            nt_obj = to_namedtuple(obj)
            self.assertIsInstance(nt_obj, namedtuple('A', 'a b'))
            self.assertEqual(nt_obj.a, 1)
            self.assertEqual(nt_obj.b, 2)

# Generated at 2022-06-21 12:52:09.002440
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class _Obj:
        val: int
    obj = _Obj()
    obj.val = 1
    assert to_namedtuple(obj) == ()
    obj = _Obj()
    obj.val = 1
    np = to_namedtuple(obj)
    # This is the only way to access the value;
    # The value is not available as an attribute on the NamedTuple.
    assert np[0] == 1
    obj = _Obj()
    obj.val = 1
    np = to_namedtuple({'a': obj, 'b': [obj]})
    assert np.a == np.b[0]
    assert np.a == NamedTuple()
    obj = _Obj()
    obj.val = 1
    np = to_namedtuple([{'a': obj}])

# Generated at 2022-06-21 12:52:20.195440
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == cast(NamedTuple, obj)

    obj = [1, 2]
    assert to_namedtuple(obj) == cast(List, obj)

    obj = {
        'a': 1,
        'b': {'c': 1, 'd': 2}
    }
    for val in obj.values():
        assert isinstance(val, dict)
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple)
    assert isinstance(out.b, NamedTuple)
    assert isinstance(out.b.c, int)
    assert isinstance(out.b.d, int)

    obj = OrderedDict([('a', 1), ('b', 2)])


# Generated at 2022-06-21 12:52:28.860845
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(to_namedtuple(dic)) == (1, 2)
    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    odict = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(odict) == NamedTuple(a=1, b=2)
    odict = OrderedDict([('a', 1), ('c', 3)])
    odict['b'] = 2
    assert to_namedtuple(odict)

# Generated at 2022-06-21 12:52:37.121713
# Unit test for function to_namedtuple
def test_to_namedtuple():
    nt = to_namedtuple(['Book', '1', 'Python Books', '100.00', '12'])
    assert isinstance(nt, list)
    assert isinstance(nt[0], str)
    assert isinstance(nt[1], str)
    assert isinstance(nt[2], str)
    assert isinstance(nt[3], str)
    assert isinstance(nt[4], str)
    assert nt[0] == 'Book'
    assert nt[1] == '1'
    assert nt[2] == 'Python Books'
    assert nt[3] == '100.00'
    assert nt[4] == '12'

    nt = to_namedtuple(('Book', '1', 'Python Books', '100.00', '12'))

# Generated at 2022-06-21 12:52:54.252935
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test basic conversion to NamedTuple
    dic = {'a': 1, 'b': 2}
    nt: NamedTuple = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert hasattr(nt, 'a')
    assert nt.a == 1
    assert hasattr(nt, 'b')
    assert nt.b == 2

    # Test conversion of a list
    li = [{'a': 1}, {'b': 2}]
    nt = to_namedtuple(li)
    assert isinstance(nt, list)
    assert isinstance(nt[0], NamedTuple)
    assert isinstance(nt[1], NamedTuple)
    assert nt[0].a == 1
    assert nt[1].b == 2

    # Test conversion

# Generated at 2022-06-21 12:53:03.273458
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.typesutils import Unset

    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        NamedTuple(a=1, b=2)

# Generated at 2022-06-21 12:53:06.886111
# Unit test for function to_namedtuple
def test_to_namedtuple():
    try:
        to_namedtuple(1)
    except TypeError:
        pass
    else:
        raise AssertionError("to_namedtuple did not raise a TypeError")


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:53:18.661251
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2.0}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2.0)

    lst = [dic]
    assert to_namedtuple(lst) == [namedtuple('NamedTuple', 'a b')(a=1, b=2)]

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-21 12:53:22.295877
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    output = to_namedtuple(dic)
    assert isinstance(output, NamedTuple)
    assert output.a == 1
    assert output.b == 2


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:53:33.426269
# Unit test for function to_namedtuple
def test_to_namedtuple():

    class _BuildDict(dict):
        """Special class used to test namedtuple recursion."""

        _fields = ('a', 'b', 'c', 'd')

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            for f in self._fields:
                if f not in self and f == 'b':
                    self[f] = {'m': 3}
                elif f not in self:
                    self[f] = 1

        def __getattr__(self, item):
            return self[item]

        def __setattr__(self, key, value):
            self[key] = value

        def __delattr__(self, item):
            return self.pop(item)


# Generated at 2022-06-21 12:53:39.496974
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert len(obj) == 2
    str(obj)
    repr(obj)
    dic = {'a': 1, 'b': 2, '__this': 3, '_that': 4, 'this': 5}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert len(obj) == 2
    od = OrderedDict()
    od['c'] = 3
    od['a'] = 1
    od['b'] = 2
    od['__this'] = 4
    od['_that'] = 5
    obj = to_namedtuple(od)

# Generated at 2022-06-21 12:53:49.830692
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pprint
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-21 12:53:58.452842
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    d = OrderedDict()
    d['b'] = 2
    d['a'] = 1
    d['c'] = 3

    d2 = OrderedDict()
    d2['d'] = 'four'
    d2['e'] = 'five'
    d2['f'] = 'six'

    d3 = OrderedDict()
    d3['g'] = d2
    d3['h'] = d

    d4 = OrderedDict()
    d4['i'] = d3

    l = [1, 2, 3, 4, d3, 5, 6]
    l2 = ['a', 'b', 'c']
    l3 = [l, l2]
    l4 = l3

    l5 = [d, d2, d3]

# Generated at 2022-06-21 12:54:04.211926
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from collections.abc import Mapping

    class TestToNamedTuple(unittest.TestCase):

        def test_to_namedtuple_tuple(self):
            data = ('a', 'b', ('c', 'd', {'e': 1, 'f': 2}))
            rtn = to_namedtuple(data)
            assert isinstance(rtn, tuple)
            assert isinstance(rtn[0], str)
            assert rtn[0] == 'a'
            assert isinstance(rtn[1], str)
            assert rtn[1] == 'b'
            assert isinstance(rtn[2], tuple)

# Generated at 2022-06-21 12:54:20.252688
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=NamedTuple(c=3, d=4))

# Generated at 2022-06-21 12:54:30.012752
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple({1: 2, 3: 4}) == NamedTuple(**{'1': 2, '3': 4})
    assert to_namedtuple(OrderedDict([(1, 2), (3, 4)])) == NamedTuple(
        **{'1': 2, '3': 4}
    )
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

# Generated at 2022-06-21 12:54:36.385612
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import Mock
    from collections import (
        OrderedDict,
    )
    od = OrderedDict()
    od['z'] = {'a': 1, 'b': 2}
    od['x'] = {'b': 2, 'a': 1}
    od['v'] = {'b': 2, 'a': 1}
    od['d'] = 'b'
    od['c'] = {'a': 1, 'b': 2}
    od['b'] = 'a'
    od['a'] = {'b': 2, 'a': 1}
    od['y'] = object()
    od['w'] = 'x'
    od['e'] = {'a': 1, 'b': 2}
    od['f'] = 'd'

# Generated at 2022-06-21 12:54:43.609132
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import collections
    import sys
    import types
    import pprint
    import uuid
    import copy
    import pprint
    import collections.abc
    import itertools
    import datetime
    import typing
    from types import SimpleNamespace

    dict_1 = dict(a=1, b=2)
    dict_2 = dict(b=3, c=4)
    dict_3 = dict(b=2, c=4, d=5)
    dict_4 = dict(d=4, e=4)
    dict_6 = dict(a=1, b=2, c=4)

    OrderedDict_1 = collections.OrderedDict(a=1, b=2)

# Generated at 2022-06-21 12:54:53.963136
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:55:05.436007
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    class A(namedtuple('A', 'a b')):
        __slots__ = ()
    class B(namedtuple('B', 'a b')):
        __slots__ = ()
    class C(namedtuple('C', 'a b')):
        __slots__ = ()
    class D(namedtuple('D', 'a b')):
        __slots__ = ()
    class E(namedtuple('E', 'a b')):
        __slots__ = ()
    class F(namedtuple('F', 'a b')):
        __slots__ = ()
    class G(namedtuple('G', 'a b')):
        __slots__ = ()
    class H(namedtuple('H', 'a b')):
        __slots__ = ()