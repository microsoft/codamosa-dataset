

# Generated at 2022-06-21 12:45:19.277524
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple.
    """
    obj = {'a': 1, 'b': 2}
    tup = to_namedtuple(obj)
    assert tup == NamedTuple(a=1, b=2)
    assert tup.a == 1
    assert tup.b == 2

    obj = {'a': 1, 'b': 2, 'c': {'d': 3}}
    tup = to_namedtuple(obj)
    assert tup == NamedTuple(a=1, b=2, c=NamedTuple(d=3))
    assert tup.a == 1
    assert tup.b == 2
    assert tup.c == NamedTuple(d=3)
    assert tup.c.d == 3


# Generated at 2022-06-21 12:45:30.288872
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    import os
    import sys
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        def setUp(self):
            with open(sys.argv[0]) as fd:
                txt = fd.read()
                txt = txt.replace(' \\', ' ')
                txt = txt.replace('\n        ', ' ')
                txt = txt.replace('        ', ' ')
                txt = txt.replace('    ', ' ')
                txt = txt.replace('  ', ' ')
                txt = txt.replace(') ', ')')
                txt = txt.replace('\n', ' ')
                txt = txt.replace('\r', ' ')
                txt = txt

# Generated at 2022-06-21 12:45:37.212273
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for function to_namedtuple.
    """
    from copy import deepcopy

    # noinspection DuplicatedCode
    def _diff_dict(
            d1: Mapping[str, Any],
            d2: Mapping[str, Any]
    ) -> bool:
        if len(d1) != len(d2):
            return True
        for k1, v1 in d1.items():
            if k1 not in d2:
                return True
            v2 = d2[k1]
            if v1 != v2:
                return True
        return False

    # noinspection DuplicatedCode

# Generated at 2022-06-21 12:45:46.686404
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections import namedtuple
    from types import SimpleNamespace
    from typing import List, Tuple

    SimpleTuple = namedtuple('SimpleTuple', 'a b c')
    SimpleList = [((1,), {'a': 2}, 3), (1, {'a': 2}, 3), (1, 2, SimpleTuple(3, 4, 5))]
    SimpleNT = (1, {'a': 2}, 3)
    SimpleOD = OrderedDict([(1, 2), ('a', {'b': 3})])
    SimpleDic = {'a': 1, 'b': 2}
    SimpleSN = SimpleNamespace(a=1, b=2)
    out_list: List[SimpleTuple] = to_namedtuple(SimpleList)

# Generated at 2022-06-21 12:45:52.778255
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class UnitTests(unittest.TestCase):
        def test_to_namedtuple(self) -> None:
            # simple
            obj = {'a': 1, 'b': 2}
            out = to_namedtuple(obj)
            self.assertIsInstance(out, namedtuple('NamedTuple', 'a b'))
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)
            # noinspection PyPep8
            self.assertEqual(
                repr(out),
                "NamedTuple(a=1, b=2)"
            )
            self.assertEqual(
                str(out),
                "(1, 2)"
            )
            # mixed

# Generated at 2022-06-21 12:46:04.204566
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # make sure no exception is raised for being called with an instance
    # of a subclass of Mapping
    from collections import ChainMap
    from flutils.helpers.generalutils import DotDict
    from flutils.helpers.specialobjects import SimpleFrozendict

    obj = dict(a=1, b=2)
    assert to_namedtuple(obj) == namedtuple('NamedTuple', 'a b')(1, 2)
    obj = OrderedDict(a=1, b=2)
    assert to_namedtuple(obj) == namedtuple('NamedTuple', 'a b')(1, 2)
    obj = SimpleNamespace(a=1, b=2)

# Generated at 2022-06-21 12:46:17.062843
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_obj = {
        'a': 1,
        'b': 2,
        'c': [{'d': 3, 'e': 4}],
        'f': {'g': 5},
        'h': 'i',
        'j': 3,
        'k': 4,
        '_l': 5,
        'm_m': 6,
        'm.m': 7,
        'n.m': {'nested': {'nested_nested': 8}},
        'odd[]': 9,
        'odd.list': [{'sublist': 9}],
    }
    result = to_namedtuple(test_obj)
    assert isinstance(result, NamedTuple)

# Generated at 2022-06-21 12:46:25.666280
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 'A', 'c': 3.0}]) == \
        [NamedTuple(a=1, b=2), NamedTuple(a='A', c=3.0)]
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': [{'c': 2, 'd': 3}]}) == \
        NamedTuple(a=1, b=[NamedTuple(c=2, d=3)])

# Generated at 2022-06-21 12:46:38.233092
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = OrderedDict()
    dic['b'] = 2
    dic['a'] = 1
    assert to_namedtuple(dic) == NamedTuple(b=2, a=1)

    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    dic['c'] = dic

# Generated at 2022-06-21 12:46:49.338279
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import unittest

    class Test_To_NamedTuple(unittest.TestCase):

        maxDiff = None


# Generated at 2022-06-21 12:47:04.594050
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:47:14.368591
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import collections
    # Test Tuple and List conversions
    test_data = [{'a': 1, 'b': 2}, [1, 2, 3], (1, 2, 3)]
    test_res = [
        collections.namedtuple('NamedTuple', ['a', 'b'])(1, 2),
        [1, 2, 3],
        (1, 2, 3),
    ]
    assert [to_namedtuple(x) for x in test_data] == test_res
    # Test Dict conversion
    assert to_namedtuple({'a': 1, 'b': 2}) == \
        collections.namedtuple('NamedTuple', ['a', 'b'])(1, 2)



# Generated at 2022-06-21 12:47:25.825916
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import operator

    class TestToNamedTuple(unittest.TestCase):

        def test_to_namedtuple_dict(self):
            dic = {
                'a': 1,
                'c': 3,
                'b': 2
            }
            obj = to_namedtuple(dic)
            self.assertTrue(
                operator.eq(
                    obj,
                    namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)
                )
            )

        def test_to_namedtuple_dict_name_invalid(self):
            dic = {
                'a_': 1,
                'c': 3,
                'b': 2
            }
            obj = to_namedtuple(dic)


# Generated at 2022-06-21 12:47:36.813669
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert isinstance(to_namedtuple(dic), NamedTuple)
    assert to_namedtuple(dic).a == 1
    assert to_namedtuple(dic).b == 2
    assert to_namedtuple({})._fields == ()

    dic = {'a': 1, 'b': 2, '3': 3}
    assert isinstance(to_namedtuple(dic), NamedTuple)
    assert to_namedtuple(dic).a == 1
    assert to_namedtuple(dic).b == 2
    assert to_namedtuple(dic)._fields == ('a', 'b')

    namedt = namedtuple('NamedTuple', 'a b')

# Generated at 2022-06-21 12:47:43.806824
# Unit test for function to_namedtuple
def test_to_namedtuple():
    if __name__ == '__main__':
        from flutils.namedtupleutils import to_namedtuple
        from collections import OrderedDict

        # noinspection PyUnresolvedReferences
        # noinspection PyTypeChecker
        t = to_namedtuple({'a': [1, 2, 3], 'b': [4, 5, 6]})
        assert t.a[1] == 2
        assert t.b[0] == 4

        # noinspection PyUnresolvedReferences
        # noinspection PyTypeChecker
        t = to_namedtuple([[1, 2, 3], [4, 5, 6]])
        r = to_namedtuple([])
        assert t == r

        # noinspection PyUnresolvedReferences
        # noinspection PyTypeChecker
        t = to

# Generated at 2022-06-21 12:47:55.361177
# Unit test for function to_namedtuple
def test_to_namedtuple():
    #  'list'
    actual = to_namedtuple(['a', 'b', 'c'])
    assert len(actual) == 3
    assert actual[0] == 'a'
    assert actual[1] == 'b'
    assert actual[2] == 'c'
    actual = to_namedtuple([{'a': 1}, {'b': 2}, {'c': 3}])
    assert len(actual) == 3
    assert actual[0] == NamedTuple(a=1)
    assert actual[1] == NamedTuple(b=2)
    assert actual[2] == NamedTuple(c=3)
    actual = to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}])
    assert len(actual) == 2

# Generated at 2022-06-21 12:48:06.850843
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from unittest.mock import patch
    import pytest  # type: ignore[no-redef]


# Generated at 2022-06-21 12:48:13.200277
# Unit test for function to_namedtuple
def test_to_namedtuple():
    input_dict = {
        'a': 1,
        'b': 2,
        'c': {
            'x': 0,
            'y': OrderedDict([
                ('a', 10),
                ('b', 20),
                ('c', 30),
            ]),
            'z': [
                1,
                [
                    {
                        'c': 33,
                    },
                    SimpleNamespace(
                        a=10,
                        b=20,
                        c=30,
                    ),
                ],
            ],
        },
    }

    output_dict = to_namedtuple(input_dict)

    assert output_dict

    assert output_dict.a == 1
    assert output_dict.b == 2
    assert output_dict.c.x == 0
    assert output_dict.c.y.a

# Generated at 2022-06-21 12:48:20.682420
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple([[], {}]) == [NamedTuple(()), NamedTuple()]
    assert to_namedtuple([{'a': 1}]) == [NamedTuple(a=1)]
    # assert to_namedtuple([{'a': 1}, {'b': 2}]) == [NamedTuple(a=1), NamedTuple(b=2)]
    assert to_namedtuple(()) == NamedTuple(())
    assert to_namedtuple((1, 2)) == NamedTuple(1, 2)
    assert to_namedtuple(({}, {})) == NamedTuple(NamedTuple(), NamedTuple())
    assert to_namedtuple

# Generated at 2022-06-21 12:48:30.096959
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _test01_in = {'a': 1, 'b': 2}
    _test01_out = to_namedtuple(_test01_in)
    assert isinstance(_test01_out, NamedTuple)
    assert _test01_out.a == 1
    assert _test01_out.b == 2


    _test02_in = OrderedDict((('b', 2), ('a', 1)))
    _test02_out = to_namedtuple(_test02_in)
    assert isinstance(_test02_out, NamedTuple)
    assert _test02_out == to_namedtuple(_test01_in)


    _test03_in = [1, 2, 3]
    _test03_out = to_namedtuple(_test03_in)

# Generated at 2022-06-21 12:48:40.114927
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from unittest.mock import patch

    class _TestToNamedTuple(TestCase):
        def setUp(self):
            self.data = {}
            self.data['list'] = [
                {'a': 1, 'b': 2},
                {'a': 3, 'b': 4},
            ]
            self.data['tuple'] = (
                {'a': 1, 'b': 2},
                {'a': 3, 'b': 4},
            )
            self.data['dict'] = {'a': 1, 'b': 2}
            self.data['odict'] = OrderedDict(self.data['dict'])
            self.data['namedtuple'] = namedtuple('Example', ['a', 'b'])(1, 2)
           

# Generated at 2022-06-21 12:48:45.461554
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print(to_namedtuple(
        {'a': 1, 'b': 1, 'a': 1, 'c': 'd', 'd': ['a', {'x': 'y'}], 'e': 5}
    ))

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:48:50.435427
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]


test_to_namedtuple()


# Generated at 2022-06-21 12:49:02.447381
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    ntuple = to_namedtuple(dic)
    assert ntuple.a == 1 and ntuple.b == 2
    assert isinstance(ntuple, NamedTuple)

    dic['c'] = {'d': 4, 'e': 5}
    ntuple = to_namedtuple(dic)
    assert ntuple.c.d == 4 and ntuple.c.e == 5
    assert isinstance(ntuple.c, NamedTuple)

    dic['f'] = [{'g': 7, 'h': 8}, [9, 10]]
    ntuple = to_namedtuple(dic)
    assert ntuple.f[0].g == 7 and ntuple.f[0].h == 8


# Generated at 2022-06-21 12:49:14.609928
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    dic = {'a': 1, 'b': 2, 'c': 'c'}
    out = to_namedtuple(dic)
    assert hasattr(out, 'a')
    assert out.a == dic['a']
    assert hasattr(out, 'b')
    assert out.b == dic['b']
    assert hasattr(out, 'c')
    assert out.c == dic['c']
    assert len(out._fields) == 3
    out = to_namedtuple(out)
    assert hasattr(out, 'a')
    assert out.a == dic['a']
    assert hasattr(out, 'b')
    assert out.b == dic['b']
    assert hasattr(out, 'c')

# Generated at 2022-06-21 12:49:21.001354
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple.

    It is recommended that calling this function be placed in a "if
    __name__ == '__main__':" block.  This enables it to be called when the
    module is run as a main program instead of as an imported module.
    """

    import doctest

    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-21 12:49:26.070480
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple

    in_ = [{'a': 1, 'b': 2}, {'b': 3, 'c': 4}, {'a': -1, 'b': 0, 'c': -2}]
    out = _to_namedtuple(in_)
    for i in out:
        assert isinstance(i, namedtuple)
        assert i.a is not None
        assert i.b is not None
        assert i.c is not None
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[0].c is None
    assert out[1].a is None
    assert out[1].b == 3
    assert out[1].c == 4
    assert out[2].a == -1
    assert out[2].b == 0
    assert out

# Generated at 2022-06-21 12:49:31.974944
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt: NamedTuple = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:49:43.102103
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    dic = {'a': 1, 'b': 2}
    named_tup = to_namedtuple(dic)
    assert named_tup.a == 1
    assert named_tup.b == 2
    assert named_tup == (1, 2)
    lst = [{'a': 1, 'b': 2}, {'b': 2, 'a': 1}]
    named_tup = to_namedtuple(lst)
    assert named_tup[0].a == 1
    assert named_tup[0].b == 2
    assert named_tup[1].a == 1
    assert named_tup[1].b == 2
    assert named_tup == ((1, 2), (1, 2))
    ord_

# Generated at 2022-06-21 12:49:54.738510
# Unit test for function to_namedtuple
def test_to_namedtuple():
    nested_test_dic = {
        'outer': {
            'inner': {
                'inner2': 1,
                'inner3': 2
            },
            'inner4': 3,
            'inner5': 4
        },
        'outer6': 5,
        'outer7': [1, 2, 3]
    }
    nt = to_namedtuple(nested_test_dic)
    assert nt.outer.inner.inner2 == 1
    assert nt.outer.inner.inner3 == 2
    assert nt.outer.inner4 == 3
    assert nt.outer.inner5 == 4
    assert nt.outer6 == 5
    assert nt.outer7[1] == 2

    nt = to_namedtuple([nested_test_dic])
    assert nt

# Generated at 2022-06-21 12:50:05.107322
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple."""
    import unittest
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace



# Generated at 2022-06-21 12:50:11.733695
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from dataclasses import dataclass
    from typing import List

    dt = to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}])
    assert len(dt) == 2
    assert dt[0].a == 1
    assert dt[0].b == 2
    assert dt[1].a == 3
    assert dt[1].b == 4

    dt = to_namedtuple({'a': 1, 'b': 2})
    assert dt.a == 1
    assert dt.b == 2

    dt = to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert 'a' in dt
    assert 'b' in dt
    assert dt.a == 1
    assert d

# Generated at 2022-06-21 12:50:24.686630
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    def assert_namedtuple(
            obj,
            attrs: List[str],
            values: List,
            as_dict: bool = False
    ):
        """Assert a given object is a namedtuple with specific values & attributes.

        Args:
            obj: The object to be validated.
            attrs: The attributes the given ``obj`` should contain.
            values: The values the given attributes should contain.
            as_dict: If ``True`` <returned>.to_dict() will be used; else
                the values will be accessed by ``getattr(returned, attr)``.

        :rtype: ``namedtuple``
        """

# Generated at 2022-06-21 12:50:32.603830
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)

    dic = {'a': 1, 'b': 2, 'c': 'a'}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b', 'c'))(1, 2, 'a')


# Generated at 2022-06-21 12:50:35.487380
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1



# Generated at 2022-06-21 12:50:47.633921
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test for: def to_namedtuple(obj: _AllowedTypes)
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), NamedTuple)
    assert isinstance(to_namedtuple(OrderedDict({'a': 1, 'b': 2})), NamedTuple)
    assert isinstance(to_namedtuple(SimpleNamespace(a=1, b=2)), NamedTuple)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'c': 3, 'd': 4, 'a': 1, 'b': 2}) == \
            NamedTuple(a=1, b=2, c=3, d=4)
    assert to_named

# Generated at 2022-06-21 12:50:55.470907
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple((1, 2, 3,)) == (1, 2, 3,)
    assert to_namedtuple({'a': 1, 'b': {'x': 'y'}}) == NamedTuple(a=1, b=NamedTuple(x='y'))
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)

# Generated at 2022-06-21 12:51:07.783351
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    ntup = to_namedtuple(dic)
    assert ntup == (1, 2)
    assert ntup.a == 1
    assert ntup.b == 2

    dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    ntup = to_namedtuple(dic)
    assert ntup == (1, (3, 4))
    assert ntup.a == 1
    assert ntup.b == (3, 4)
    assert ntup.b.c == 3
    assert ntup.b.d == 4


# Generated at 2022-06-21 12:51:13.977739
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections.abc
    import datetime
    import decimal
    import typing
    from flutils.miscutils import repr_helper

    assert to_namedtuple(None) == None
    assert to_namedtuple('abc') == 'abc'
    assert to_namedtuple(123) == 123
    assert to_namedtuple(True) == True
    assert to_namedtuple(123.456) == 123.456
    assert to_namedtuple(datetime.datetime.now().time()) == datetime.datetime.now().time()
    assert to_namedtuple(datetime.datetime.now()) == datetime.datetime.now()
    assert to_namedtuple(datetime.date.today()) == datetime.date.today()

# Generated at 2022-06-21 12:51:16.421877
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out[0] == 1
    assert out[1] == 2



# Generated at 2022-06-21 12:51:24.827977
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    named = to_namedtuple(dic)
    assert named.a == 1
    assert named.b == 2



# Generated at 2022-06-21 12:51:35.313529
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections.abc import Mapping
    
    import unittest
    
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import (
        SyntaxError,
        ValidationError,
        validate_identifier,
    )
    
    class ToNamedtupleTester(unittest.TestCase):
        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            nt1 = to_namedtuple(dic)
            self.assertEqual(nt1, namedtuple('NamedTuple', 'a b')(1, 2))
            dic['c'] = 3
            nt2 = to_namedtuple(dic)

# Generated at 2022-06-21 12:51:43.627635
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime, timedelta
    from types import (
        FrameType,
        TracebackType,
    )

    # Setup
    simple_dic = {
        'a': 1,
        'b': 2,
        'c': 3,
        '_d': 4,
    }
    complex_dic = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 2,
            'e': 4,
            '_f': 5,
        },
        '_g': 10,
    }

# Generated at 2022-06-21 12:51:55.138533
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    dic = {'a': 1, 'b': 2}
    results = to_namedtuple(dic)
    assert results == namedtuple('namedtuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 1: 34}
    results = to_namedtuple(dic)
    assert results == namedtuple('namedtuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'cb': 20, 'ba': 21}
    results = to_namedtuple(dic)

# Generated at 2022-06-21 12:52:03.014498
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple

    # test name cannot start with underscore
    dic = {'a': 1, '_b': 2}
    obj = to_namedtuple(dic)
    obj = cast(namedtuple, obj)
    assert obj.a == 1
    assert not hasattr(obj, '_b')

    # test can handle OrderedDict
    from collections import OrderedDict
    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    dic['_c'] = 3
    obj = to_namedtuple(dic)
    obj = cast(namedtuple, obj)
    assert obj.a == 1
    assert obj.b == 2
    assert not hasattr

# Generated at 2022-06-21 12:52:11.096826
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier


    # error with an unsupported type
    try:
        to_namedtuple(1)
    except Exception as e:
        assert(type(e).__name__ == 'TypeError')

    # simple list
    assert(to_namedtuple([1, 2, 3]) == [1, 2, 3])

    # simple tuple
    assert(to_namedtuple((1, 2, 3)) == (1, 2, 3))

    # simple string
    assert(to_namedtuple('abc') == 'abc')

    # simple dict

# Generated at 2022-06-21 12:52:22.262673
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import datetime

    def _test_w_iter(
            dct: Union[dict, OrderedDict, list, tuple],
            ret_type: type,
            dct_type: type = dict,
    ):
        out = to_namedtuple(dct)
        assert isinstance(out, ret_type)
        assert len(out) == len(dct)
        assert isinstance(out._asdict(), dct_type)
        for key in out._fields:
            assert getattr(out, key, None) == dct[key]

    def _test_w_dct(dct: Union[dict, OrderedDict]):
        out = to_namedtuple(dct)
        assert out._asdict() == dct

# Generated at 2022-06-21 12:52:30.006305
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert out.a == 1
    assert out.b == 2

    obj = {1: 'a', 'b': 2, '_': 3}
    out = to_namedtuple(obj)
    assert not hasattr(out, '1')
    assert not hasattr(out, '_')
    assert hasattr(out, 'b')
    assert out.b == 2

    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert out == [1, 2, 3]

    obj = [1, 2, [1, 2]]

# Generated at 2022-06-21 12:52:35.115153
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    r = to_namedtuple(dic)
    assert r == NamedTuple(a=1, b=2)

if __name__ == "__main__":
    dic = {'a': 1, 'b': 2}
    r = to_namedtuple(dic)
    print(type(r))
    print(r)
    test_to_namedtuple()

# Generated at 2022-06-21 12:52:46.963294
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2

    dic = {'a': 1, 'b': 2}
    odic = OrderedDict(dic)
    ntuple = to_namedtuple(odic)
    assert ntuple.a == 1
    assert ntuple.b == 2

    dic = {'a': 1, 'b': 2}
    ns = SimpleNamespace(**dic)
    ntuple = to_namedtuple(ns)
    assert ntuple.a == 1
    assert ntuple.b == 2

    dic = OrderedDict({'a': 1, 'b': 2})

# Generated at 2022-06-21 12:53:04.966955
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Basic usage
    t = (1, 2)
    n = to_namedtuple(t)
    assert isinstance(n, tuple)
    assert isinstance(n[0], int)
    assert isinstance(n[1], int)
    assert n[0] == 1
    assert n[1] == 2

    # Bad type
    with pytest.raises(TypeError):
        n = to_namedtuple(None)

    # Nested
    t = [[(1, 2), (3, 4)], [(5, 6), (7, 8)]]
    n = to_namedtuple(t)
    assert isinstance(n, list)
    assert isinstance(n[0], list)
    assert isinstance(n[0][0], tuple)

# Generated at 2022-06-21 12:53:13.084166
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 11,
        'b': 22,
        'c': {
            'a': 111,
            'b': 222,
            'c': {
                'a': 1111,
                'b': 2222,
            },
        },
        'd': [
            'e',
            {
                'a': 1111,
                'b': 2222,
            },
        ],
    }
    print(dic)
    tup = to_namedtuple(dic)
    print(type(tup), tup)

# Generated at 2022-06-21 12:53:22.552982
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    import collections

    assert to_namedtuple({}) == collections.namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == collections.namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple({'a': 1, 'b': 2}) == collections.namedtuple('NamedTuple', 'a b')(1, 2)

    _test = collections.OrderedDict([
        ('a', 1),
        ('b', 2),
    ])
    assert to_namedtuple(_test) == collections.namedtuple('NamedTuple', 'a b')(1, 2)

    _test = collections.OrderedDict([
        ('b', 2),
        ('a', 1),
    ])
    assert to

# Generated at 2022-06-21 12:53:33.663493
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint

    # Define some initial data
    data = dict(
        list_val=[dict(a=1, b=2), dict(c=3, d=4)],
        tuple_val=(dict(e=5, f=6), dict(g=7, h=8)),
        dict_val={'i': 9, 'j': 10},
        a=99,
        b=100
    )

    # Convert to NamedTuple
    data_nt = to_namedtuple(data)

    # Print it out
    print('NamedTuple:')
    pprint(data_nt)
    print()

    # Find item in a list

# Generated at 2022-06-21 12:53:37.640193
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Docstring for test_to_namedtuple
    """
    # Setup input
    dic = {'a': 100, 'b': 'hello', 'c': [1, 2, 3]}
    # Verify function works
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(
        a=100, b='hello', c=[1, 2, 3])


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:53:48.858031
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit tests for to_namedtuple.

    Returns:
        None

    """
    import pytest
    res = to_namedtuple(
        {'a': 1, 'b': 2}
    )
    assert isinstance(res, NamedTuple)

    res = to_namedtuple(
        {'a': 'aa', 'b': 2}
    )
    assert isinstance(res, NamedTuple)
    assert len(res) == 2
    assert res[0] == 'aa'
    assert res.a == 'aa'

    res = to_namedtuple(
        dict(((i, i) for i in range(100)))
    )
    assert isinstance(res, NamedTuple)
    assert len(res) == 100

# Generated at 2022-06-21 12:53:57.685579
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    obj = {'a': 1, 'b': 2}
    ot = to_namedtuple(obj)
    assert ot.a == 1
    assert ot.b == 2

    obj = OrderedDict(a=1, b=2)
    ot = to_namedtuple(obj)
    assert ot.a == 1
    assert ot.b == 2

    obj = [{'a': 1, 'b': 2}, [{'n': 1, 'm': 2}, [{'x': 1}, {'y': 3}]]]
    ot = to_namedtuple(obj)
    assert ot[0].a == 1
    assert ot[0].b == 2
    assert ot[1][0].n == 1

# Generated at 2022-06-21 12:54:03.912893
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from flutils.namedtupleutils import to_namedtuple
    obj = {"a": 1, "b": 2}
    result = to_namedtuple(obj)
    assert result.a == 1
    assert result.b == 2

    obj = (1, 2, 3)
    result = to_namedtuple(obj)
    assert result == (1, 2, 3)

    obj = {'a': [1, 2], 'b': (2, 3)}
    result = to_namedtuple(obj)
    assert result.a[0] == 1
    assert result.a[1] == 2
    assert result.b[0] == 2
    assert result.b[1] == 3

    obj = {'a': [1, 2], 'b': (2, 3)}
    result = to_namedtuple

# Generated at 2022-06-21 12:54:12.872133
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) \
           == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

# Generated at 2022-06-21 12:54:23.459965
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2
    obj = {'a': 1, 'b': 2, 'c': [1, 2, 3]}
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2
    assert out.c == [1, 2, 3]
    obj = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2
    assert out.c.d == 3
    assert out.c.e == 4

# Generated at 2022-06-21 12:54:56.509414
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from .test_namedtupleutils import test_to_namedtuple
    test_to_namedtuple(to_namedtuple)

# Generated at 2022-06-21 12:54:58.632196
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass
    # assert False, 'Not implemented.'

# Generated at 2022-06-21 12:55:04.966882
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = DictionaryWithAttrs(a=1, b=2)
    b = DictionaryWithAttrs(c=[1, 2, 3])
    c = DictionaryWithAttrs(d=DictionaryWithAttrs(x=1))
    d = a + b + c
    assert 'a' in d._fields
    assert 'c' in d._fields
    assert 'x' in d.d._fields

