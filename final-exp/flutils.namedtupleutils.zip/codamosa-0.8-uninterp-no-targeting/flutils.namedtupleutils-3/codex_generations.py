

# Generated at 2022-06-21 12:45:15.784155
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple(dict()) == NamedTuple()
    assert to_namedtuple(dict(x=1)) == NamedTuple(x=1)
    assert to_namedtuple(dict(x=dict(y=1))) == NamedTuple(x=NamedTuple(y=1))
    assert to_namedtuple(dict(x=1, y=2)) == NamedTuple(x=1, y=2)
    assert to_namedtuple(dict(x=1, y=2, z=3)) == NamedTuple(x=1, y=2, z=3)

# Generated at 2022-06-21 12:45:26.417640
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    named = to_namedtuple(dic)
    assert hasattr(named, 'a')
    assert hasattr(named, 'b')
    assert named.a == 1
    assert named.b == 2

    alist = [{'a': 1, 'b': 2}, [{'a': 1, 'b': 2}, [{'a': 1, 'b': 2}]]]
    named = to_namedtuple(alist)
    assert hasattr(named[0], 'a')
    assert hasattr(named[0], 'b')
    assert hasattr(named[1][0], 'a')
    assert hasattr(named[1][0], 'b')
    assert hasattr(named[1][1][0], 'a')
    assert hasattr

# Generated at 2022-06-21 12:45:37.143962
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj._fields == ('a', 'b')

    ordered_dic = OrderedDict([('a', 1), ('b', 2)])
    obj = to_namedtuple(ordered_dic)
    assert obj._fields == ('a', 'b')

    lst = [1, 2]
    obj = to_namedtuple(lst)
    assert obj == [1, 2]

    tup = (1, 2)
    obj = to_namedtuple(tup)
    assert obj == (1, 2)

    namespace = SimpleNamespace(a=1, b=2)
    obj = to_namedtuple(namespace)

# Generated at 2022-06-21 12:45:46.651072
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import patch

    assert to_namedtuple('abc') == 'abc'

    with patch('flutils.namedtupleutils._to_namedtuple') as mock_to_namedtuple:
        to_namedtuple('abc')
        assert mock_to_namedtuple.call_count == 1

    assert to_namedtuple(None) is None

    assert to_namedtuple(['abc', 'def']) == ['abc', 'def']

    assert to_namedtuple(('abc', 'def')) == ('abc', 'def')

    expected = (1, 2, 3)
    assert to_namedtuple(expected) == expected

    assert to_namedtuple(SimpleNamespace(a=1, b=2, c=3)) == (1, 2, 3)


# Generated at 2022-06-21 12:45:55.924408
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import sys
    if sys.version_info < (3, 7):
        from collections import OrderedDict
        from types import SimpleNamespace
    else:
        from collections.abc import OrderedDict
        from types import SimpleNamespace
    import types
    import unittest


    class TestToNamedtuple(unittest.TestCase):
        def test__to_namedtuple__dict(self):
            dic = {'a': 1, 'b': 2}
            with self.assertRaises(TypeError):
                res = to_namedtuple(dic)
            ordered = OrderedDict(dic)
            res = to_namedtuple(ordered)

# Generated at 2022-06-21 12:46:06.277944
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = [
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
    ]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[1].a == 3
    assert out[1].b == 4

    # Test with an OrderedDict
    from collections import OrderedDict
    obj = OrderedDict(
        [
            ('a', 1),
            ('b', 2),
        ]
    )
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    # Test with a SimpleNamespace

# Generated at 2022-06-21 12:46:18.721537
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing function to_namedtuple')

    dict_ = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2, 'c': [{'a': 1, 'b': 2}]}}
    from flutils.namedtupleutils import to_namedtuple
    nt_dict_ = to_namedtuple(dict_)

    assert nt_dict_.a == 1
    assert nt_dict_.b == 2
    assert nt_dict_.c.a == 1
    assert nt_dict_.c.b == 2
    assert nt_dict_.c.c[0].a == 1
    assert nt_dict_.c.c[0].b == 2

    print('Function to_namedtuple: pass')



# Generated at 2022-06-21 12:46:31.437308
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import patch

    dic = {'a': 1, 'b': 2}
    actual = to_namedtuple(dic)

    expected = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)

    assert actual == expected

    actual = to_namedtuple([dic, dic, dic])

    expected = [namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2),
                namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2),
                namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)]

    assert actual == expected


# Generated at 2022-06-21 12:46:44.479364
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Arrange
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple

    class A(NamedTuple):
        a: int

    class B(NamedTuple):
        a: int
        b: int

    class C(NamedTuple):
        a: int
        b: int
        c: int

    class D(NamedTuple):
        a: int
        b: int
        c: int
        d: int

    class NoClass:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4

    class Untyped:
        pass

    SimpleNamespaceA = SimpleNamespace(a=1)
    SimpleNames

# Generated at 2022-06-21 12:46:52.352628
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict, namedtuple
    from types import SimpleNamespace
    from unittest import TestCase

    from flutils.miscutils import recur_update

    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    recur_update(dic, c=3)

    class TestObj(object):
        def __init__(self):
            self.a = 1
            self.b = 2

        def do_nothing(self) -> int:
            return self.a + self.b

    obj = TestObj()

    class TestMeta(type):
        def __new__(metacls, name: str, bases: tuple, namespace: dict) \
                -> 'TestMeta':
            namespace['c'] = 3

# Generated at 2022-06-21 12:47:07.309182
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = dict(a=1, b=2, c=3)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(1, 2, 3)

    dic = dict(b=2, a=1, c=3)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(1, 2, 3)


# Generated at 2022-06-21 12:47:20.231549
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # If a list is passed, the type should be a list
    obj_list = [1]
    assert isinstance(to_namedtuple(obj_list), list)
    obj_list.append(2)
    assert isinstance(to_namedtuple(obj_list), list)
    # If a tuple is passed, the type should be a tuple
    obj_tuple = (1, 2)
    assert isinstance(to_namedtuple(obj_tuple), tuple)
    obj_tuple = (1, 2, obj_list)
    assert isinstance(to_namedtuple(obj_tuple), tuple)
    # If a dict is passed, the type should be a NamedTuple
    obj_dict = {'a': 1, 'b': 2}

# Generated at 2022-06-21 12:47:26.498977
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # This is to test the Mypy fix for 'to_namedtuple'
    # noinspection Mypy
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple(set) == set
    assert to_namedtuple(5) == 5
    assert to_namedtuple(True) == True
    assert to_namedtuple('str') == 'str'
    assert to_namedtuple(1.1) == 1.1

# Generated at 2022-06-21 12:47:37.457226
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils import namedtupleutils
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    import types
    import pytest # type: ignore

    # To avoid "unused import" lint error
    assert namedtupleutils
    assert namedtuple
    assert pytest

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)

    ordered_dic = OrderedDict(dic)
    assert to_namedtuple(ordered_dic) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)


# Generated at 2022-06-21 12:47:47.168942
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    import json

    d: OrderedDict = OrderedDict()
    d['a'] = {'e': 1, 'f': 2}
    d['b'] = 2
    d['c'] = [1, 2, 3, {'g': 7, 'h': 8}, 9]
    d['d'] = (1, 2, 3, 4)

    out = to_namedtuple(d)
    assert out.a == (1, 2)
    out = json.loads(json.dumps(out, indent=4, sort_keys=True))
    assert out['a']['e'] == 1
    assert out['a']['f'] == 2
    assert out['b'] == 2

# Generated at 2022-06-21 12:47:59.519881
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    # Simple mapping
    d1 = {'a': 1, 'b': 2, 'c': 3}
    nt1 = to_namedtuple(d1)
    assert nt1.a == 1
    assert nt1.b == 2
    assert nt1.c == 3

    # Simple mapping with private keys
    d2 = {'a': 1, '_b': 2, 'c': 3}
    nt2 = to_namedtuple(d2)
    assert nt2.a == 1
    assert nt2.c == 3

    # Simple sequence
    s1 = [0, (1, 2), {'a': 1, 'b': 2, 'c': 3}, [4, 5, 6]]

# Generated at 2022-06-21 12:48:09.328212
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {
        'a': 1,
        'b': 2,
        'c': {'x': 3, 'y': 4}
    }
    nt = to_namedtuple(d)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c.x == 3
    assert nt.c.y == 4
    d = to_namedtuple(d)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c.x == 3
    assert nt.c.y == 4
    assert isinstance(nt, namedtuple)
    assert isinstance(nt.c, namedtuple)


# Generated at 2022-06-21 12:48:18.366275
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import (
        transform_to_namedtuple,
        transform_to_namedtuple_dict,
        transform_to_namedtuple_list,
        transform_to_namedtuple_named_tuple,
        transform_to_namedtuple_simple_namespace,
    )

    assert _to_namedtuple is transform_to_namedtuple
    assert _to_namedtuple.dispatch(Mapping) is transform_to_namedtuple_dict
    assert _to_namedtuple.dispatch(SimpleNamespace) \
        is transform_to_namedtuple_simple_namespace
    assert _to_namedtuple.dispatch(Sequence) is transform_to_namedtuple_list

# Generated at 2022-06-21 12:48:28.948984
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import Dict, List, Tuple, Union

    from flutils.namedtupleutils import to_namedtuple

    # Create some test data
    dic1: Dict[str, Union[List[int], Dict[str, int]]] = {
        'a': [1, 2, 3],
        'b': dict(a=1, b=2),
    }
    dic2: Dict[str, Union[List[int], 'Test']] = {
        'a': [1, 2, 3],
        'b': 3,
    }
    test = 'test'
    a_lst = [1, 2, 3]

# Generated at 2022-06-21 12:48:37.864375
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    # noinspection SpellCheckingInspection
    b = to_namedtuple(dic)
    assert isinstance(b, NamedTuple)
    assert b.a == dic['a']
    assert b.b == dic['b']
    assert b == (1, 2)
    assert b.a == 1
    assert b[0] == 1
    assert type(b) == NamedTuple

    c = {'a':1, 'b':{'c':3}}
    d = to_namedtuple(c)
    assert d.a == 1
    assert d.b.c == 3

    e = {'a':1, 'b':{'c':3}}
    f = to_namedtuple(e)
    assert f.a

# Generated at 2022-06-21 12:48:56.859133
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    output = to_namedtuple(dic)
    assert isinstance(output, tuple)
    assert 'a' in output._fields
    assert 'b' in output._fields
    assert output[0] == 1
    assert output[1] == 2
    assert output[0] is output.a
    assert output[1] is output.b
    assert output == (output.a, output.b)
    assert output == (1, 2)
    assert output == {'a': 1, 'b': 2}
    assert output == dict(output)
    assert output == OrderedDict(output)
    output = to_namedtuple(OrderedDict(output))
    assert output == (output.a, output.b)

# Generated at 2022-06-21 12:49:05.854589
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _emtpy = SimpleNamespace()
    _emtpy.__dict__: dict
    assert to_namedtuple(_emtpy) == NamedTuple()
    _dic = SimpleNamespace()
    _dic.__dict__ = {'a': 1, 'b': 2}
    _dic.__dict__: dict
    assert to_namedtuple(_dic) == NamedTuple(a=1, b=2)
    _dic = SimpleNamespace()
    _dic.__dict__ = {'a': 1, 'b': 2}
    _dic.__dict__: dict
    assert to_namedtuple(_dic) == NamedTuple(a=1, b=2)
    _dic = SimpleNamespace()

# Generated at 2022-06-21 12:49:17.401067
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class Example:
        a: int = 1
        b: str = 'bob'

    obj = Example()

    assert to_namedtuple(obj) == namedtuple('NamedTuple', ['a', 'b'])(
        a=1, b='bob')

    obj = SimpleNamespace(a=1, b='bob')

    assert to_namedtuple(obj) == namedtuple('NamedTuple', ['a', 'b'])(
        a=1, b='bob')

    obj = {'a': 1, 'b': 2}

    assert to_namedtuple(obj) == namedtuple('NamedTuple', ['a', 'b'])(
        a=1, b=2)

    obj = OrderedDict()
    obj['a'] = 1

# Generated at 2022-06-21 12:49:28.017458
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing function to_namedtuple ...')
    import re
    import random
    from collections import (
        OrderedDict,
    )
    from copy import deepcopy
    from types import (
        SimpleNamespace,
    )
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import to_namedtuple

    # ----------------------------------------------------------------------
    # ---------- test empty input
    # ----------------------------------------------------------------------

# Generated at 2022-06-21 12:49:40.892143
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _res = to_namedtuple({'a': 1, 'b': [2, 3], 'c': {'d': 4}})
    assert _res.a == 1
    assert _res.b[0] == 2
    assert _res.b[1] == 3
    assert _res.c.d == 4

    _res = to_namedtuple(OrderedDict((('a', 1), ('b', 2))))
    assert _res.a == 1
    assert _res.b == 2

    _res = to_namedtuple(SimpleNamespace(a=1, b=2))
    assert _res.a == 1
    assert _res.b == 2

    _res = to_namedtuple([1, 2, 3, 4])
    assert tuple(_res) == (1, 2, 3, 4)


# Generated at 2022-06-21 12:49:47.512831
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _dic = {'a': 1, 'b': 2}
    _ntpl = to_namedtuple(_dic)
    assert _ntpl.a == 1
    assert _ntpl.b == 2

    _dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    _ntpl = to_namedtuple(_dic)
    assert _ntpl.a == 1
    assert _ntpl.b.c == 3
    assert _ntpl.b.d == 4

    _dic = {'a': 1, 'b': (2, 3)}
    _ntpl = to_namedtuple(_dic)
    assert _ntpl.a == 1
    assert _ntpl.b == (2, 3)


# Generated at 2022-06-21 12:49:58.271013
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    class TestToNamedTuple(unittest.TestCase):
        def test_to_namedtuple(self):
            arg = {'a': 1, 'b': 2}
            exp = {'a': 1, 'b': 2}
            got = to_namedtuple(exp)
            self.assertEqual(
                got,
                arg,
                'Did not get expected got %s; expected %s' %
                (got, arg)
            )
            arg = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
            exp = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
            got = to_namedtuple(exp)

# Generated at 2022-06-21 12:50:07.434071
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Sequence
    from numbers import Number

    from flutils.misc import Null

    _args = list(range(4))
    _arg = _args[0]

    def _get_rnd_ident(
            _cnt: int = 3,
            _max_cnt: int = 6
    ) -> str:
        from random import randint

        if _cnt > _max_cnt:
            _cnt = _max_cnt
        if not isinstance(_cnt, int) or _cnt <= 0:
            _cnt = 3
        _rnd_chr: str = ''
        _prev_chr: str = ''

# Generated at 2022-06-21 12:50:21.028402
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-21 12:50:30.416579
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test function to_namedtuple
    list_dic = [{'b': 4, 'a': 3}, {'c': 2, 'd': 1}]
    assert to_namedtuple(list_dic) == [
        NamedTuple(a=3, b=4),
        NamedTuple(d=1, c=2),
    ]

    from collections import OrderedDict
    ordered_dic = OrderedDict([
        ('b', 4),
        ('a', 3),
    ])
    assert to_namedtuple(ordered_dic) == NamedTuple(b=4, a=3)

    import json

# Generated at 2022-06-21 12:50:52.302184
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest
    
    obj = [1, 2]
    with pytest.raises(TypeError) as err:
        to_namedtuple(obj)
    assert 'Can convert only' in str(err.value)
    
    obj = tuple([1, 2])
    with pytest.raises(TypeError) as err:
        to_namedtuple(obj)
    assert 'Can convert only' in str(err.value)
    
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    
    obj = {'a': 1, 'b': 2, '_c': 3}
    assert to

# Generated at 2022-06-21 12:51:04.593766
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for functions to_namedtuple
    """
    test_dict = {'a': 1, 'b': 2}
    test_named_tuple = to_namedtuple(test_dict)
    assert test_named_tuple.a == 1
    assert test_named_tuple.b == 2

    test_obj = {'a': 1, 'b': None, 'd': []}
    test_named_tuple = to_namedtuple(test_obj)
    assert test_named_tuple.a == 1
    assert test_named_tuple.b is None
    assert test_named_tuple.d == []


# Generated at 2022-06-21 12:51:15.445710
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # dict
    dic = {'a': 1, 'b': 2}
    dic = to_namedtuple(dic)
    assert isinstance(dic, NamedTuple)
    assert isinstance(dic, tuple)

    # dict with values
    dic = {'a': {'b': 2}}
    dic = to_namedtuple(dic)
    assert isinstance(dic, NamedTuple)
    assert isinstance(dic, tuple)
    assert dic.a.b == 2

    # OrderedDict with values
    dic = OrderedDict(a=1, b=2, c=3)
    dic = to_namedtuple(dic)
    assert isinstance(dic, NamedTuple)
    assert isinstance(dic, tuple)

# Generated at 2022-06-21 12:51:26.052991
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    import pytest
    pytest.importorskip("flutils", minversion="3.2.0")

    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import NamedTuple

    # Test to_namedtuple with a dictionary
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    # Test to_namedtuple with a list
    lst = [{'a': 1, 'b': 2}]
    out = to_namedtuple(lst)

# Generated at 2022-06-21 12:51:35.989297
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple',('a','b'))(a=1,b=2)
    assert to_namedtuple({'b': 2, 'a': 1}).a == 1
    assert to_namedtuple({'b': 2, 'a': 1}).b == 2
    assert to_namedtuple({'a': {'a': 1, 'b': 2}, 'b': 2}) == namedtuple('NamedTuple',('a','b'))(a = namedtuple('NamedTuple',('a','b'))(a=1,b=2),b=2)

# Generated at 2022-06-21 12:51:42.758331
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from pprint import pprint

    examples = OrderedDict()
    examples['dict'] = {
        'a': 1,
        'b': 'text',
        'c': {
            'd': 4,
            'e': 'text',
            'f': [
                'g',
                'text',
            ],
        },
    }
    examples['list'] = [
        1,
        'text',
        [
            4,
            'text',
            [
                'g',
                'text',
            ],
        ],
    ]

# Generated at 2022-06-21 12:51:48.391134
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Prevent 'tuple' object is not callable -- MyPy only
    def _test_namedtuple(
            obj: Sequence,
            expected: Union[List[Any], Tuple[Any, Any], NamedTuple, str],
            expected_type: str,
            args: Tuple = None
    ) -> None:
        if args is None:
            args = (obj,)
        result = to_namedtuple(*args)
        if expected_type == 'None':
            result_type = 'None'
            assert result is None, result
        else:
            result_type = result.__class__.__name__
            assert result_type == expected_type, result_type
        if expected_type == 'tuple':
            assert isinstance(result, tuple)
            assert result == expected

# Generated at 2022-06-21 12:51:58.959697
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from typing import Any

    def _assert_valid(obj: Any):
        from flutils.validators import validate_namedtuple

        validate_namedtuple(obj)

        assert isinstance(obj, SimpleNamespace)
        assert hasattr(obj, 'attr1')
        assert hasattr(obj, 'attr2')
        assert hasattr(obj, 'attr3')
        assert isinstance(obj.attr1, int)
        assert isinstance(obj.attr2, int)
        assert isinstance(obj.attr3, int)
        assert obj.attr1 == 1
        assert obj.attr2 == 2
        assert obj.attr3 == 3

        if hasattr(obj, 'attr_dict'):
            assert isinstance(obj.attr_dict, SimpleNamespace)

# Generated at 2022-06-21 12:52:09.071843
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    l_tuple = (1, 2, 3)
    assert to_namedtuple(l_tuple) == l_tuple
    l_dic = {'a': 1, 'b': 2}
    namedtuple_dic = to_namedtuple(l_dic)
    assert namedtuple_dic.a == 1
    assert namedtuple_dic.b == 2
    l_list = [1, 2, 3]
    assert to_namedtuple(l_list) == l_list
    l_ordered_dic = OrderedDict(
        [
            ('a', 1),
            ('b', 2),
            ('c', 3),
        ]
    )
    namedtuple_ordered_dic = to_namedtuple(l_ordered_dic)

# Generated at 2022-06-21 12:52:20.372254
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:52:54.350329
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from .test_data import (
        DATA_NESTED,
        DATA_NESTED_EXPECTED,
        DATA_ORDERED,
        DATA_ORDERED_EXPECTED,
        DATA_PLAIN,
        DATA_PLAIN_EXPECTED,
        DATA_PLAIN_LIST,
        DATA_PLAIN_LIST_EXPECTED,
        DATA_SIMPLE,
        DATA_SIMPLE_EXPECTED,
    )
    # Test plain dictionary
    result = to_namedtuple(DATA_PLAIN)
    assert result == DATA_PLAIN_EXPECTED

    # Test ordered dictionary
    result = to_namedtuple(DATA_ORDERED)
    assert result == DATA_ORDERED_EXPECTED

    # Test simple namespace

# Generated at 2022-06-21 12:53:03.323549
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function: to_namedtuple
    
    Args:
        None
    
    Returns:
        None
    
    Raises:
        AssertionError if there is a failure.
    """
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    s = SimpleNamespace(a=1, b=2)
    t = to_namedtuple(s)
    assert hasattr(t, 'a') and hasattr(t, 'b')
    assert t.a == s.a and t.b == s.b

    d = {}
    d['a'] = 1
    d['b'] = 2
    t = to_namedtuple(d)
    assert hasattr(t, 'a') and hasattr(t, 'b')

# Generated at 2022-06-21 12:53:06.600676
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'c': 3, 'a': 1, 'b': 2}
    nt = to_namedtuple(d)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3

# Generated at 2022-06-21 12:53:18.329771
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for function to_namedtuple """
    assert to_namedtuple(None) == None
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.5) == 1.5
    assert to_namedtuple(2.5e3) == 2.5e3
    assert to_namedtuple(3+4j) == 3+4j
    assert to_namedtuple(True) == True
    assert to_namedtuple(None) == None
    assert to_namedtuple('test') == 'test'
    assert to_namedtuple(bytes()) == bytes()
    assert to_namedtuple(bytearray()) == bytearray()
    assert to_namedtuple(range(10)) == tuple(range(10))

# Generated at 2022-06-21 12:53:26.767974
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'b a')(2, 1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple(OrderedDict((('a', 1), ('b', 2)))) == namedtuple('namedtuple', 'a b')(1, 2)
    a = namedtuple('namedtuple', 'a b')(1, 2)

# Generated at 2022-06-21 12:53:35.614679
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections.abc import Mapping
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from pathlib import Path
    import pytest
    from importlib import import_module
    from _pytest.config import ExitCode
    from mypy_extensions import TypedDict

    from flutils.config import ConfigDict, ConfigList
    from flutils.namedtupleutils import (
        to_namedtuple,
        _to_namedtuple,
    )

    test_module = Path(__file__).absolute().parent / 'test_namedtupleutils.py'
    test_module = str(test_module.resolve())

    # ---------------------------
    # to_namedtuple function
    # ---------------------------


# Generated at 2022-06-21 12:53:47.483091
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('to_namedtuple')
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    dic = {'a': {'b': 1, 'c': 2}, 'd': 'hello'}
    obj = to_namedtuple(dic)
    assert obj.a.b == 1
    assert obj.a.c == 2
    assert obj.d == 'hello'
    dic = {'a': {'b': 1, 'c': [2, 3]}, 'd': 'hello'}
    obj = to_namedtuple(dic)
    assert obj.a.b == 1
    assert obj.a.c == (2, 3)

# Generated at 2022-06-21 12:53:54.573427
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections import namedtuple
    from types import SimpleNamespace
    import pytest

    def test():
        """Unit test for function to_namedtuple"""
        dic = {'a': 1, 'b': 2}
        assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
        assert to_namedtuple(OrderedDict(dic)) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
        assert to_namedtuple(1) == 1
        assert to_namedtuple('str') == 'str'

# Generated at 2022-06-21 12:53:58.420212
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = {
        'a': 1,
        'b': 2,
    }
    nt = to_namedtuple(data)
    assert nt == SimpleNamespace(a=1, b=2)


if __name__ == '__main__':
    # Unit test this module
    print(__file__)
    test_to_namedtuple()

# Generated at 2022-06-21 12:54:04.190838
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from time import time
    from time import sleep
    from time import perf_counter
    from time import process_time

    from flutils.namedtupleutils import to_namedtuple
    from flutils.timing import Timer

    from collections import defaultdict
    from collections import deque
    from collections import namedtuple

    import gc

    # noinspection PyPep8,PyUnresolvedReferences
    import pytest  # type: ignore

    # noinspection PyPep8

    def _test_namedtuple(obj: _AllowedTypes):
        gc.collect()
        # print(obj)

        t = Timer()
        t.start()
        out = to_namedtuple(obj)
        t.stop()

        # print(out)

        # noinspection PyUnusedLocal

# Generated at 2022-06-21 12:54:57.973286
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import OrderedDict

    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = OrderedDict({'a': 1, 'b': 2})
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'None': None}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'_a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(b=2)
