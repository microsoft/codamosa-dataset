

# Generated at 2022-06-21 12:45:08.898248
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # List:
    v = to_namedtuple([1, 2, 3, 4, 5])
    assert isinstance(v, list)
    assert isinstance(v[0], int)
    assert isinstance(v[1], int)
    assert isinstance(v[2], int)
    assert isinstance(v[3], int)
    assert isinstance(v[4], int)
    # Tuple:
    v = to_namedtuple((1, 2, 3, 4, 5))
    assert isinstance(v, tuple)
    assert isinstance(v[0], int)
    assert isinstance(v[1], int)
    assert isinstance(v[2], int)
    assert isinstance(v[3], int)
    assert isinstance(v[4], int)
    # SimpleNamespace:
   

# Generated at 2022-06-21 12:45:14.020127
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    # Test only 'list', 'tuple', 'dict' can be converted
    def test_err_only_list_tuple_dict_can_be_converted():
        for obj in (OrderedDict(), SimpleNamespace(), [1, 2], (1, 2), {1, 2}, {1: 2, 3: 4}):
            with pytest.raises(TypeError):
                to_namedtuple(obj)
    # Test only 'list', 'tuple', 'dict' can be converted deeper

# Generated at 2022-06-21 12:45:23.310885
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for :func:`flutils.namedtupleutils.to_namedtuple`."""

    import unittest
    import unittest.mock

    class TestToNamedTuple(unittest.TestCase):
        """Tests for :func:`flutils.namedtupleutils.to_namedtuple`."""

        def setUp(self):
            """Runs at the start of every method."""

# Generated at 2022-06-21 12:45:33.595721
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()

    dic = {'a': 1, 'b': 2}
    x = to_namedtuple(dic)
    assert x.a == 1
    assert x.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    x = to_namedtuple(dic)
    assert x.a == 1
    assert x.b == 2

    dic = {'a': {'b': 2}}
    x = to_namedtuple(dic)
    assert x.a.b == 2

    dic = {'a': [{'b': 2}, {'c': 3}]}
    x = to_namedtuple(dic)

# Generated at 2022-06-21 12:45:44.693539
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple(dict()) == NamedTuple()
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(tuple([1, 2, 3])) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == [1, 2, 3]
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

# Generated at 2022-06-21 12:45:54.781002
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(dict()) == namedtuple('NamedTuple', '')(),\
        'Empty dict case failed'
    assert to_namedtuple(dict(a=1, b=2)) == namedtuple('NamedTuple', 'a b')(1, 2),\
        'Ordinary dict case failed'
    assert to_namedtuple(OrderedDict(a=1, b=2)) == namedtuple('NamedTuple', 'a b')(1, 2),\
        'Ordered dict case failed'
    assert to_namedtuple(OrderedDict(b=1, a=2)) == namedtuple('NamedTuple', 'b a')(1, 2),\
        'Ordered dict case failed'

# Generated at 2022-06-21 12:46:05.520680
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict, namedtuple
    from types import SimpleNamespace
    from typing import NamedTuple

    a = SimpleNamespace()
    a.b = 1


# Generated at 2022-06-21 12:46:18.100557
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    tup: Tuple[int, str, float] = (10, 'foo', 4.56)
    lis: List[int] = [1, 2, 3, 4, 5]
    dic: Dict[str, int] = {'a': 1, 'b': 2, 'c': 3}
    ord_dic: OrderedDict = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    ns: SimpleNamespace = SimpleNamespace(a=1, b=2, c=3)


# Generated at 2022-06-21 12:46:30.696408
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import attr

    @attr.s(frozen=True, slots=True)
    class Inner(object):
        d = attr.ib(type=int)
        e = attr.ib(type=int)

    @attr.s(frozen=True, slots=True)
    class Outter(object):
        a = attr.ib(type=int)
        b = attr.ib(type=int)
        c = attr.ib(type=Inner)

    test_dict = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
        },
    }

    test_odict = OrderedDict(test_dict)

    test_list = [1, 2, 3, 4, 5]

   

# Generated at 2022-06-21 12:46:43.729531
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.testutils import (
        AnyStringIO,
        ConfigLogging,
        Printer,
    )

    # Create an object that cannot be converted to a namedtuple
    class Dummy(object):
        pass
    obj = Dummy()
    obj.attr = 1
    with AnyStringIO() as buf, ConfigLogging(stream=buf):
        _ = to_namedtuple(obj)
    out = buf.getvalue()
    assert out.startswith('ERROR')

    # Normal namedtuples
    with AnyStringIO() as buf, ConfigLogging(stream=buf):
        _ = to_namedtuple(1)
    out = buf.getvalue()
    assert out.startswith('ERROR')
    with AnyStringIO() as buf, ConfigLogging(stream=buf):
        _ = to

# Generated at 2022-06-21 12:46:57.335879
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple(None) == namedtuple('NamedTuple', '')
    assert to_namedtuple(False) == namedtuple('NamedTuple', '')
    assert to_namedtuple(True) == namedtuple('NamedTuple', '')

    assert to_namedtuple(1) == namedtuple('NamedTuple', '')
    assert to_namedtuple(1.1) == namedtuple('NamedTuple', '')
    assert to_namedtuple('str') == 'str'
    assert to_namedtuple(1j) == namedtuple('NamedTuple', '')

    # Test bytes
    assert to_namedtuple(b'') == namedtuple('NamedTuple', '')

    # Test byte arrays

# Generated at 2022-06-21 12:47:08.600198
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils

    aNamedTuple = flutils.namedtupleutils.to_namedtuple(
        {'a': 1, 'b': 1}
    )
    assert hasattr(aNamedTuple, '_fields')
    assert hasattr(aNamedTuple, 'a')
    assert hasattr(aNamedTuple, 'b')
    assert not hasattr(aNamedTuple, 'c')

    aOrderedDict = OrderedDict([('a', 1), ('b', 2)])
    aNamedTuple = flutils.namedtupleutils.to_namedtuple(aOrderedDict)
    assert hasattr(aNamedTuple, '_fields')
    assert hasattr(aNamedTuple, 'a')

# Generated at 2022-06-21 12:47:12.103251
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)



# Generated at 2022-06-21 12:47:23.856783
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.textutils import random_string
    #from flutils.namedtupleutils import to_namedtuple
    try:
        from collections.abc import Mapping
    except ImportError:
        from collections import Mapping

    from random import choice
    from string import ascii_letters, digits
    from typing import Literal, Union
    from unittest import TestCase

    from flutils.collectionsutils import (
        rgetattr,
        rsetattr,
    )

    From = Union[Mapping, Sequence, SimpleNamespace]
    To = Union[List, Tuple, NamedTuple]
    Types = Literal['dict', 'list', 'namespace', 'ordered_dict', 'tuple']

    class ConvertTestCase(TestCase):
        def setUp(self):
            super().setUp()
            letters

# Generated at 2022-06-21 12:47:34.126846
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from decimal import Decimal
    from stringcase import snakecase
    class V(NamedTuple):
        a: int
        b: int
    dic = {
        'a_b': 1,
        'c_d': 2,
        'e_f': {
            'i_j': V(3, 4)
        }
    }
    dic2 = OrderedDict(dic)
    # noinspection PyArgumentList
    nt = namedtuple('NamedTuple', tuple(sorted(dic.keys())))

# Generated at 2022-06-21 12:47:44.004602
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test a dictionary without a nesting
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    # Test a dictionary with a nesting
    dic = {'a': {'b': 1, 'c': 2}, 'd': 3}
    out = to_namedtuple(dic)
    assert out.a.b == 1
    assert out.a.c == 2
    assert out.d == 3

    # Test a dictionary with a nesting with invalid keys
    dic = {'a': {'b': 1, 'c': 2}, '2d': 3}
    out = to_namedtuple(dic)
    assert out.a.b == 1
    assert out.a.c == 2

# Generated at 2022-06-21 12:47:55.571263
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.tests.extended_tools as ext

    from collections import (
        namedtuple,
        OrderedDict,
    )

    from types import SimpleNamespace
    from flutils.tests.extended_types import (
        ExtendedDict,
        ExtendedOrderedDict,
        PrependedList,
        PrependedTuple,
        PrependedDict,
        PrependedOrderedDict,
        PrependedNamedTuple,
        PrependedSimpleNamespace,
    )

    from flutils.tests import dyn_import, parametrize

    module = dyn_import('collections.abc')
    MappingClass = module.Mapping

    # The NamedTuple for a dictionary, that has keys and values
    # that can be converted to a NamedTuple.
    # Represented as a dictionary
    t

# Generated at 2022-06-21 12:48:07.233918
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    # dict
    d1 = {'a': 1, 'b': 2, 'c': 3}
    t1 = to_namedtuple(d1)
    assert t1.a == 1
    assert t1.b == 2
    assert t1.c == 3

    # OrderedDict
    od1 = OrderedDict()
    od1['a'] = 1
    od1['b'] = 2
    od1['c'] = 3
    t1 = to_namedtuple(od1)
    assert t1.a == 1
    assert t1.b == 2
    assert t1.c == 3

    # dict nested
    d2 = {'a': 1, 'b': {'d': 4, 'e': 5}, 'c': 3}

# Generated at 2022-06-21 12:48:16.955978
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple."""
    from collections import OrderedDict
    from flutils.miscutils import (
        AttrDict,
        FrozenDict,
        FrozenOrderedDict,
    )
    from flutils.namedtupleutils import to_namedtuple
    import pytest

    d = {
        'b': 'B', 'a': 'A',
        'c': {'d': 'D', 'e': {'f': 'F', 'g': 'G'}},
    }
    od = OrderedDict([('b', 'B'), ('a', 'A'),
                      ('c', OrderedDict([('d', 'D'),
                                         ('e', OrderedDict([('f', 'F'),
                                                            ('g', 'G')]))]))
                      ])

# Generated at 2022-06-21 12:48:28.119343
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest


    # noinspection PyUnusedLocal
    class TestToNamedTuple(unittest.TestCase):

        def test_to_namedtuple(self):
            import itertools


            class TestClass:
                pass


# Generated at 2022-06-21 12:48:39.859724
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == (1, 2)
    dic = {'b': 2, 'a': 1}
    assert to_namedtuple(dic) == (1, 2)
    dic = {'a': {'b': 2, 'c': 3}, 'b': 2}
    assert str(to_namedtuple(dic)) == "{'a': (2, 3), 'b': 2}"

# Generated at 2022-06-21 12:48:51.795950
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple, OrderedDict
    from types import SimpleNamespace

    nt1 = namedtuple('nt1', ['a', 'b'])
    nt1_obj = nt1(1, 2)
    nt2 = namedtuple('nt2', ['a', 'b', 'c'])
    nt2_obj = nt2(2, 3, 4)
    nt2_obj_2 = nt2(2, 3, 4)


# Generated at 2022-06-21 12:48:55.412692
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest

    doctest.testmod(verbose=True)


if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-21 12:49:05.165171
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple, OrderedDict, Counter
    from flutils.coreutils import identity
    from flutils.namedtupleutils import to_namedtuple
    from . import assertutils
    from . import test_args

# Generated at 2022-06-21 12:49:17.187267
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple([1, 2, {'a': 1, 'b': 2, '_c': 3}]) == [1, 2, namedtuple('NamedTuple', 'a b')(a=1, b=2)]

# Generated at 2022-06-21 12:49:27.938066
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    from copy import deepcopy
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import (
        validate_date,
        validate_datetime,
        validate_datetime_format,
        validate_identifier,
        validate_integer,
        validate_time,
        validate_type,
    )
    from flutils.validators.exceptions import ValidationError

    assert hasattr(to_namedtuple, 'dispatch')

    # Make sure the register decorator is working
    try:
        to_namedtuple(None)
    except TypeError:
        pass

# Generated at 2022-06-21 12:49:40.806184
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test for function to_namedtuple
    """
    assert to_namedtuple(None) is None

    assert to_namedtuple(0) == 0
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.1) == 1.1
    assert to_namedtuple(True) is True
    assert to_namedtuple(False) is False

    dic1 = {'a': 1, 'b': 2}
    assert to_namedtuple(dic1) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic2 = {'a': 1, 'b': {'c': 3, 'd': 4}}

# Generated at 2022-06-21 12:49:52.951501
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class Test_to_namedtuple(unittest.TestCase):
        """Test function to_namedtuple."""

        # noinspection PyPep8Naming
        def setUp(self):
            """Setup class attributes."""
            self.dic = {
                'a': 1,
                'b': {
                    'c': 2,
                    'd': [
                        3,
                        4,
                        5,
                    ],
                },
            }
            self.named = namedtuple('Named', ('a', 'b'))
            _dic = dict(self.dic)
            _dic['b'] = dict(_dic['b'])
            _dic['b']['d'] = tuple(_dic['b']['d'])
            self.named_

# Generated at 2022-06-21 12:50:01.846621
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''
    Unit test for function to_namedtuple
    '''


# Generated at 2022-06-21 12:50:08.233579
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import randint
    from datetime import datetime, timedelta
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_namedtuple
    import pytest

    class CustomClass(object):
        pass

    obj1 = to_namedtuple('A string')
    assert obj1 == 'A string'

    obj2 = to_namedtuple(CustomClass())
    assert isinstance(obj2, CustomClass)
    with pytest.raises(TypeError):
        to_namedtuple(CustomClass())

    obj3 = to_namedtuple([
        'A string',
        ['A list'],
        {'A': 'dict'},
        CustomClass(),
        42,
        None,
    ])
    assert obj3

# Generated at 2022-06-21 12:50:24.921037
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Allowed
    assert to_namedtuple({'a': 1})
    assert to_namedtuple([])
    assert to_namedtuple(())
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 4: 5}])
    # Not allowed
    with pytest.raises(TypeError):
        to_namedtuple(SimpleNamespace())
    with pytest.raises(TypeError):
        to_namedtuple('a')
    with pytest.raises(TypeError):
        to_namedtuple(1)
    with pytest.raises(TypeError):
        to_namedtuple(1.1)
    with pytest.raises(TypeError):
        to_namedtuple(to_namedtuple)

# Generated at 2022-06-21 12:50:32.737698
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from operator import itemgetter
    from types import SimpleNamespace
    from typing import List, NamedTuple, Tuple, Union

    from flutils.validators import validate_identifier

    from flutils.namedtupleutils import to_namedtuple

    # This function only "sort of" tests the function.  It doesn't test for
    # duplicate keys in dictionaries, so it only tests for
    # "sort of" unexpected behavior.

    dic = {'a': 1, 'b': 2, '_c': 3, 'd_': 4, 'e': 5, 'f': 6}
    namedtup = to_namedtuple(dic)
    sort = sorted(dic.keys(), key=itemgetter(0))

# Generated at 2022-06-21 12:50:44.456992
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function ``to_namedtuple``."""
    import pytest

# Generated at 2022-06-21 12:50:54.039036
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(SimpleNamespace(
        a=1,
        b=2,
        c=SimpleNamespace(
            a=1,
            b=2
        )
    )) == NamedTuple(a=1, b=2, c=NamedTuple(a=1, b=2))
    assert to_namedtuple(dict(
        a=1,
        b=2,
        c=dict(
            a=1,
            b=2
        )
    )) == NamedTuple(a=1, b=2, c=NamedTuple(a=1, b=2))

# Generated at 2022-06-21 12:51:06.348845
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _test_to_namedtuple(
            dic: Any,
            expect: Any,
            func: Any = None
    ) -> None:
        if not func:
            func = to_namedtuple
        result = func(dic)
        assert result == expect
        assert repr(result) == repr(expect)
        assert isinstance(result, type(expect))
        assert result != dic
        assert repr(result) != repr(dic)
        assert not isinstance(result, type(dic))

    # _test_to_namedtuple({}, {})
    # _test_to_namedtuple({}, {})
    # _test_to_namedtuple([], [])
    # _test_to_namedtuple([], [])


# Generated at 2022-06-21 12:51:16.749545
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    class Test(unittest.TestCase):
        def test_to_namedtuple(self):
            """Test to_namedtuple function."""
            data = {
                'a': 1,
                'b': 2,
                'c': {
                    'e': 4,
                    'f': 5,
                },
                'd': (
                    1,
                    2,
                    3
                ),
            }
            ntup = to_namedtuple(data)
            self.assertTrue(
                isinstance(ntup, namedtuple)
            )
            self.assertEqual(
                ntup.a,
                1
            )
            self.assertEqual(
                ntup.b,
                2
            )

# Generated at 2022-06-21 12:51:27.851254
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import NamedTupleHolder

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTupleHolder)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': [1, 2, 3], 'b': {'a': 1, 'b': 2}}
    nt = to_namedtuple(dic)
    assert nt.b.a == 1

    dic = OrderedDict(a=1, b=2, c=3)
    nt = to_namedtuple(dic)
    assert list(nt._fields) == ['a', 'b', 'c']


# Generated at 2022-06-21 12:51:37.166652
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    from os import environ

    print('Testing to_namedtuple')
    print('- Dict')
    dic = {'a': 1, 'b': 2}
    print('    Test class is namedtuple. ', end='')
    assert(isinstance(to_namedtuple(dic), namedtuple))
    print('Passed.')
    print('    Test length is two. ', end='')
    assert(len(to_namedtuple(dic)) == 2)
    print('Passed.')
    print('    Test value of a is 1. ', end='')
    assert(to_namedtuple(dic).a == 1)
    print('Passed.')
    print('    Test value of b is 2. ', end='')

# Generated at 2022-06-21 12:51:43.486283
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # test: no attrs
    nt0 = to_namedtuple({})
    assert nt0._fields == ()
    # test: one attr
    nt1 = to_namedtuple({'a': 'b'})
    assert nt1._fields == ('a', )
    assert nt1.a == 'b'
    # test: two attrs
    nt2 = to_namedtuple({'a': 'b', 'c': 'd'})
    assert nt2._fields == ('a', 'c')
    assert nt2.a == 'b'
    assert nt2.c == 'd'
    # test: one attr: non-identifier key
    nt3 = to_namedtuple({'a b': 'b'})
    assert nt3._fields == ()


# Generated at 2022-06-21 12:51:54.966705
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import Mock
    from .test_validators import ValidatorTestCase

    class TestCase(ValidatorTestCase):
        def setUp(self):
            self.mock_validator = Mock(
                spec=NamedTuple,
                foo=1,
                bar=2,
                baz=3,
                _fields=('foo', 'bar', 'baz')
            )

        def test_to_namedtuple_dict_sequence(self):
            @to_namedtuple.register(dict)
            def _(obj: Mapping) -> Tuple[Tuple, ...]:
                return tuple((k, v) for k, v in obj.items())

            obj = {'foo': 1, 'bar': 2, 'baz': 3}

# Generated at 2022-06-21 12:52:25.870141
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest


# Generated at 2022-06-21 12:52:35.625475
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(OrderedDict([('b', 2), ('a', 1), ('c', 3)])) == NamedTuple(b=2, a=1, c=3)
    assert to_namedtuple({'_a': 1, 'b': 2, 'c': 3}) == NamedTuple(b=2, c=3)

# Generated at 2022-06-21 12:52:40.972824
# Unit test for function to_namedtuple
def test_to_namedtuple():
    raw = {
        'foo': 1,
        'bar': {
            'foobar': 2
        }
    }
    t1 = to_namedtuple(raw)
    assert t1.foo == raw['foo']
    assert t1.bar.foobar == raw['bar']['foobar']

# Generated at 2022-06-21 12:52:52.445766
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_item = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    namedtuple_item = to_namedtuple(test_item)
    assert namedtuple_item == namedtuple('NamedTuple', ['a', 'b', 'c', 'd', 'e'])(1, 2, 3, 4, 5)
    assert isinstance(namedtuple_item, tuple)
    test_item = OrderedDict([('a', 1), ('b', 2), ('e', 5), ('d', 4), ('c', 3)])
    namedtuple_item = to_namedtuple(test_item)
    assert namedtuple_item == namedtuple('NamedTuple', 'a b e d c')(1, 2, 5, 4, 3)


# Generated at 2022-06-21 12:53:02.236332
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    """Tests for function to_namedtuple"""

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt == namedtuple('NamedTuple', 'a b')(1, 2)
    assert type(nt) is namedtuple('NamedTuple', 'a b')
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': {'b': 1}, 'c': 2}
    nt = to_namedtuple(dic)
    assert nt == namedtuple('NamedTuple', 'a c')(
        namedtuple('NamedTuple', 'b')(1),
        2,
    )

# Generated at 2022-06-21 12:53:12.269527
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test cases for to_namedtuple function.
    """

    import pytest
    from flutils.namedtupleutils import to_namedtuple

    # ----------------------
    # missing required args
    # ----------------------
    with pytest.raises(TypeError):
        to_namedtuple()

    # ----------------------
    # invalid obj arg value
    # ----------------------
    with pytest.raises(TypeError):
        to_namedtuple(
            1
        )

    with pytest.raises(TypeError):
        to_namedtuple(
            1.1
        )

    with pytest.raises(TypeError):
        to_namedtuple(
            None
        )

    with pytest.raises(TypeError):
        to_namedtuple(
            True
        )

   

# Generated at 2022-06-21 12:53:22.290862
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import OrderedDict, namedtuple

    from flutils.testhelpers import unit_test

    dic = {
        'a': 1,
        'b': 2,
        'c': {
            'ca': 1,
            'cb': 2,
            'cc': 'cc',
        },
        'd': [1, 2, 3, {'da': 'da'}],
    }
    expected = namedtuple('NamedTuple', ('a', 'b', 'c', 'd'))

# Generated at 2022-06-21 12:53:30.089676
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    d = {'a': 1, 'b': 2}
    result = to_namedtuple(d)
    assert type(result) == namedtuple('NamedTuple', 'a b')._type
    assert result.a == 1, 'The key a should have a value of 1, but it doesn\'t'
    assert result.b == 2, 'The key b should have a value of 2, but it doesn\'t'


# Generated at 2022-06-21 12:53:37.470259
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    dic_to_nt = to_namedtuple(dic)
    assert isinstance(dic_to_nt, namedtuple)
    assert dic_to_nt.a == 1
    assert dic_to_nt.b == 2
    list_to_nt = to_namedtuple([dic, dic])
    assert isinstance(list_to_nt, list)
    assert isinstance(list_to_nt[0], namedtuple)
    assert isinstance(list_to_nt[1], namedtuple)
    assert list_to_nt[0].a == 1
    assert list_to_nt[0].b == 2
    assert list_to_nt[1].a == 1

# Generated at 2022-06-21 12:53:43.608492
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for function to_namedtuple """
    # noinspection PyProtectedMember
    from flutils.namedtupleutils import _to_namedtuple
    d = {'a': 1, 'b': 2}
    a = _to_namedtuple(d)
    assert a.a == 1
    assert a.b == 2
    d = {'a': {'aa': 1}, 'b': 2}
    a = _to_namedtuple(d)
    assert a.a.aa == 1
    assert a.b == 2
    a = _to_namedtuple([{'a': 1}, {'b': 2}])
    # assert a[0].a == 1
    # assert a[1].b == 2
    assert a == ([{'a': 1}, {'b': 2}],)

# Generated at 2022-06-21 12:54:04.249212
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import json

    def compare_namedtuple(obj1: object, obj2: object) -> bool:
        try:
            json1 = json.loads(json.dumps(obj1))
        except:
            json1 = json.dumps(obj1)
        try:
            json2 = json.loads(json.dumps(obj2))
        except:
            json2 = json.dumps(obj2)
        if json1 == json2:
            return True
        return False

    assert compare_namedtuple(to_namedtuple([1, 2, 3]), [1, 2, 3])
    assert compare_namedtuple(to_namedtuple((1, 2, 3)), (1, 2, 3))

# Generated at 2022-06-21 12:54:07.646296
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt_dic = to_namedtuple(dic)
    assert nt_dic.a == 1
    assert nt_dic.b == 2


# Generated at 2022-06-21 12:54:14.504628
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'hello': 'world', 'answer': 42}
    nt = to_namedtuple(d)
    assert nt.hello == 'world'
    assert nt.answer == 42
    l1 = [1, 2, 3, d]
    l2 = to_namedtuple(l1)
    for i in range(3):
        assert l1[i] == l2[i]
    assert l2[3].hello == 'world'
    assert l2[3].answer == 42
    t1 = (1, 2, 3, d)
    t2 = to_namedtuple(t1)
    assert t1[0] == t2[0]
    assert t1[1] == t2[1]
    assert t1[2] == t2[2]

# Generated at 2022-06-21 12:54:24.131953
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:54:33.223763
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': {'aa': 1, 'ab': 2},
        'b': [{'ba': 'a', 'bb': 'b'}, {'bc': 'c', 'bd': 'd'}]
    }
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(
        a=namedtuple('NamedTuple', 'aa ab')(aa=1, ab=2),
        b=[
            namedtuple('NamedTuple', 'ba bb')(ba='a', bb='b'),
            namedtuple('NamedTuple', 'bc bd')(bc='c', bd='d'),
        ]
    )

# Generated at 2022-06-21 12:54:42.372030
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.types import Unspecified
    from typing import Any, Sequence


    # noinspection SpellCheckingInspection

# Generated at 2022-06-21 12:54:47.453253
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=NamedTuple(c=3, d=4))
    test_nt = [NamedTuple(a=1, b=NamedTuple(c=3, d=4))]
    assert to_namedtuple(test_nt) == [NamedTuple(a=1, b=NamedTuple(c=3, d=4))]
    odic = OrderedDict(dic)
    assert to_namedtuple(odic) == NamedTuple(a=1, b=NamedTuple(c=3, d=4))
    assert isinstance(to_namedtuple(odic), NamedTuple)


# Generated at 2022-06-21 12:54:52.926805
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple('abc') == 'abc'
    assert to_namedtuple(123) == 123
    assert to_namedtuple(['abc', 123]) == ['abc', 123]
    assert to_namedtuple(['abc', 123.0]) == ['abc', 123.0]
    assert to_namedtuple(['abc', [123, {'a': 1, 'b': [1, 2]}]]) == ['abc', [123, NamedTuple(a=1, b=[1, 2])]]
    assert to_namedtuple([123, ['abc', {'a': 1, 'b': [1, 2]}]]) == [123, ['abc', NamedTuple(a=1, b=[1, 2])]]

# Generated at 2022-06-21 12:54:59.473574
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(dict(a=1, b=2)) == \
           namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple([dict(a=1, b=2), dict(a=3, b=4)]) == \
           [namedtuple('NamedTuple', 'a b')(a=1, b=2),
            namedtuple('NamedTuple', 'a b')(a=3, b=4)]