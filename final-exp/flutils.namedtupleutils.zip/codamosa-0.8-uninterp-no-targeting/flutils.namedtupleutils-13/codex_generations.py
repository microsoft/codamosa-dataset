

# Generated at 2022-06-21 12:45:17.172772
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    dic_out = to_namedtuple(dic)
    assert isinstance(dic_out, NamedTuple)
    assert dic_out.a == 1
    assert dic_out.b == 2
    assert dic_out == dic

    lst = [0, 1, 2, 3]
    lst_out = to_namedtuple(lst)
    assert isinstance(lst_out, list)
    assert lst_out == lst

    lst = []
    lst_out = to_namedtuple(lst)
    assert isinstance(lst_out, list)
    assert lst_out == lst

    tpl = (1, 2, 3, 4)
    tpl_out = to_

# Generated at 2022-06-21 12:45:28.288758
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict, namedtuple
    from types import SimpleNamespace

    OrderedDic = namedtuple('OrderedDic', 'one, two')

    obj = {
        'a': 1,
        'b': 2,
        'c': [1, 2, 3, {'a': 4}],
        3: 4,
        'OrderedDic': OrderedDic(1, 2),
        'namespc': SimpleNamespace(a=1, b=2, c=3),
        'str': 'str',
        'tup': (1, 2, 3),
    }
    obj['OrderedDict'] = OrderedDict(obj)
    obj['OrderedDict']['OrderedDict'] = obj['OrderedDict']


# Generated at 2022-06-21 12:45:35.999368
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections

    data = {
        'key': 'value',
        'key2': {'nested': 'value'},
        'key3': [{'very': 'nested'}],
        'key4': {'odd': {'and': 'deeply', 'nested': 5}},
        'key5': (1, 'two', {'three': 3}),
        'key6': 'simple',
        'key7': (3,),
    }


# Generated at 2022-06-21 12:45:45.980436
# Unit test for function to_namedtuple
def test_to_namedtuple():
    p = [
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
        {'a': 5, 'b': 6},
    ]
    try:
        to_namedtuple(p)
    except SyntaxError:
        pass
    else:
        raise AssertionError
    expected = [
        (1, 2),
        (3, 4),
        (5, 6),
    ]
    actual = to_namedtuple(p)
    assert expected == actual
    expected = [p[1]]
    actual = to_namedtuple(expected)
    assert expected == actual
    expected = (p[1],)
    actual = to_namedtuple(expected)
    assert expected == actual

# Generated at 2022-06-21 12:45:47.468055
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:45:56.240021
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for function to_namedtuple
    """
    from random import randint
    from random import sample as rnd_sample
    from string import ascii_lowercase
    from string import ascii_uppercase

    from flutils.dictutils import sortseq
    from flutils.namedtupleutils import NamedTuple
    from flutils.namedtupleutils import to_namedtuple

    # Make sure it works with a dictionary
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

    # Make sure it works with SimpleNamespace
    class Simple(SimpleNamespace):
        def __eq__(self, other) -> bool:
            return self is other
    assert to_namedtuple(Simple(a=1, b=2)) == Named

# Generated at 2022-06-21 12:46:06.441151
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    print('testing to_namedtuple')
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    print('output:', out)
    assert(out.a == dic['a'])
    assert(out.b == dic['b'])
    get_key = lambda x: x[0]
    out = to_namedtuple(OrderedDict(sorted(dic.items(), key=get_key)))
    print('output:', out)
    assert(out[0] == dic['a'])
    assert(out[1] == dic['b'])
    assert(isinstance(out, namedtuple('NamedTuple', ['a', 'b'])))

# Generated at 2022-06-21 12:46:18.810561
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""

    dic = {'a': 1, 'b': 2}
    nt: NamedTuple = to_namedtuple(dic)

    assert isinstance(nt, NamedTuple)
    assert isinstance(nt, dict) is False
    assert isinstance(nt, OrderedDict) is False
    assert isinstance(nt, Sequence) is False
    assert isinstance(nt, SimpleNamespace) is False
    assert isinstance(nt, Mapping) is True

    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert len(nt) == 2
    assert nt.a == 1
    assert nt.b == 2
    try:
        assert nt['a'] == 1
    except TypeError:
        pass
   

# Generated at 2022-06-21 12:46:27.491907
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'inv': [
            {'base': {'name': 'tacos', 'slot': 1}, 'count': 2},
            {'base': {'name': 'burritos', 'slot': 2}, 'count': 3}
        ]
    }
    out = to_namedtuple(dic)  # type: ignore
    assert isinstance(out, NamedTuple)
    assert out.inv[0].count == 2
    assert out.inv[1].count == 3

# Generated at 2022-06-21 12:46:39.736952
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple({'b': 2, 'a': 1}) == to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == to_namedtuple(OrderedDict([('b', 2), ('a', 1)])) == to_namedtuple(SimpleNamespace(a=1, b=2)) == to_namedtuple(SimpleNamespace(b=2, a=1))
    assert to_namedtuple([1, 2, 3]) == to_namedtuple((1, 2, 3))
    assert to_namedtuple([1, 2, 3]) == to_namedtuple(to_namedtuple([1, 2, 3]))

# Generated at 2022-06-21 12:46:56.193681
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a']) == ['a']
    assert to_namedtuple(('a',)) == ('a',)
    x = to_namedtuple({'a': 'b'})
    assert x.a == 'b'
    x = to_namedtuple(OrderedDict((('c', 'd'), ('a', 'b'))))
    assert x.c == 'd'
    x = to_namedtuple(SimpleNamespace(a='b'))
    assert x.a == 'b'
    x = to_namedtuple({'a': 'b', 'cd': OrderedDict((('c', 'd'), ('e', 'f')))})
    assert x.cd.c == 'd'

# Generated at 2022-06-21 12:47:07.722960
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict1 = {
        'attr1': 1,
        'attr2': 2,
    }
    dict2 = {
        'attr3': 3,
        'attr4': 4,
    }
    dict3 = {
        'attr5': 5,
        'attr6': 6,
    }
    dict4 = {
        'attr7': 7,
        'attr8': 8,
    }
    assert to_namedtuple(dict1) == namedtuple('NamedTuple', 'attr1 attr2')(1, 2)
    assert to_namedtuple(dict1).__dict__ == dict1
    assert to_namedtuple(dict1).attr1 == 1
    assert to_namedtuple(dict1).attr2 == 2
    assert to_namedtuple(dict1) != namedtuple

# Generated at 2022-06-21 12:47:20.769802
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    from .testdata import (
        DICTONARY,
        DICTONARY_MISC,
        DICTONARY_MIXED,
        DICTONARY_NESTED,
    )
    assert to_namedtuple(DICTONARY) == \
        namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(DICTONARY_MISC) == \
        namedtuple('NamedTuple', 'a b')(a=1, b=2)

# Generated at 2022-06-21 12:47:30.401041
# Unit test for function to_namedtuple
def test_to_namedtuple():  # pragma: no cover
    from collections import OrderedDict, namedtuple
    from types import SimpleNamespace
    from pprint import pprint

    # Simple Dict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    nt.a, nt.b
    assert nt.a == 1
    assert nt.b == 2

    # Dict with a Dict
    dic = {'a': 1, 'b': {'b1': 2, 'b2': 3}}
    nt = to_namedtuple(dic)
    nt.a, nt.b.b1, nt.b.b2
    assert nt.a == 1
    assert nt.b.b1 == 2

# Generated at 2022-06-21 12:47:39.824758
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict, namedtuple
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    res = to_namedtuple(dic)
    assert isinstance(res, namedtuple)
    assert res.a == 1
    assert res.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    res = to_namedtuple(dic)
    assert isinstance(res, namedtuple)
    assert res.a == 1
    assert res.b == 2

    dic = OrderedDict({'a': 1, 'b': 2})
    assert to_namedtuple(dic) == (1, 2)

    dic = SimpleNamespace(a=1, b=2)
    res = to

# Generated at 2022-06-21 12:47:48.997897
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.tests import get_test_data
    from collections import OrderedDict
    from typing import Dict
    from pprint import pprint

    tests = get_test_data('unit/to_namedtuple.json')
    for test in tests:
        obj = test['obj']
        expected = test['expected']

        # noinspection PyBroadException
        try:
            obj = to_namedtuple(obj)
            assert obj == expected, 'Mismatch'
        except Exception as err:
            expected_exc = test.get('expected_exc', None)
            assert repr(err) == repr(expected_exc), \
                'Mismatch; got: %r' % repr(err)


# Generated at 2022-06-21 12:48:00.770550
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Simple example
    dic = {'a': 1, 'b': 2}
    expected = to_namedtuple(dic)
    result = NamedTuple(a=1, b=2)
    assert expected == result

    # More complicated example
    dic = {'a': {'b': {'c': 3}}, 'd': [4, 5]}
    expected = to_namedtuple(dic)
    result = NamedTuple(a=NamedTuple(b=NamedTuple(c=3)), d=[4, 5])
    assert expected == result

    # OrderedDict example
    od = OrderedDict([('a', 1), ('b', 2)])
    expected = to_namedtuple(od)
    result = NamedTuple(a=1, b=2)

# Generated at 2022-06-21 12:48:11.504852
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from types import MappingProxyType
    from unittest import mock

    from flutils.namedtupleutils import to_namedtuple
    from flutils.testutils import TestBase

    from typing import (  # noqa: F401; pylint: disable=unused-import
        Dict,
        List,
    )

    class Test(TestBase):
        """Unit test for function to_namedtuple."""

        def test_to_namedtuple(self) -> None:
            """Unit test for function to_namedtuple."""
            # noinspection PyUnusedLocal
            def _check_type(tp: type) -> None:
                """Unit test for function to_namedtuple."""
                with self.subTest(expected=tp):
                    self

# Generated at 2022-06-21 12:48:19.814593
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import ChainMap

    def assert_same_attrs(left: NamedTuple, right: NamedTuple) -> None:
        """Assert that both objects have the same attributes.

        This does not compare the values of the attributes.  It only checks
        to see if the attributes are the same.

        Args:
            left:  The left operand that is to be compared.
            right: The right operand that is to be compared.

        Raises:
            AssertionError: When the attributes are not the same.
        """
        left: NamedTuple = cast(NamedTuple, left)
        right: NamedTuple = cast(NamedTuple, right)
        l_attrs = list(left._fields)
        r_attrs = list

# Generated at 2022-06-21 12:48:24.031083
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = {'a': 1, 'b': 2}
    assert isinstance(to_namedtuple(data), namedtuple)


if __name__ == '__main__':
    print(to_namedtuple({'a': 1, 'b': 2}))

# Generated at 2022-06-21 12:48:36.949060
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import random
    import string

    def _random_word():
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for _ in range(10))

    a = _random_word()
    b = _random_word()
    c = _random_word()
    d = _random_word()
    e = _random_word()

    aa = SimpleNamespace()
    aa.a = a
    aa.b = b
    aa.c = c
    aa.d = d
    aa.e = e

    bb = SimpleNamespace()
    bb.a = a
    bb.b = b
    bb.c = c
    bb.d = d
    bb.e = e

    cc = SimpleNamespace()


# Generated at 2022-06-21 12:48:42.269858
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyShadowingNames
    def namedtuple(name: str, args: List[str]) -> namedtuple:
        class _namedtuple(namedtuple):
            def __str__(self):
                return '%s(%s)' % (name, ', '.join(
                    f'{arg}={val if isinstance(val, str) else repr(val)}'
                    for arg, val in zip(args, self)
                ))

            __repr__ = __str__
        return _namedtuple

    def test_args(name: str, args: List[str], obj: Any, want: str) -> None:
        klass: namedtuple = namedtuple(name, args)
        got: NamedTuple = to_namedtuple(obj)

# Generated at 2022-06-21 12:48:53.169424
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    data = {'a': 1, 'c': 2, 'b': 3}
    result = to_namedtuple(data)
    assert result == NamedTuple(a=1, b=3, c=2)

    data = [
        {'a': 1, 'c': 2, 'b': 3},
        {'d': 4}
    ]
    result = to_namedtuple(data)
    assert result[0] == NamedTuple(a=1, b=3, c=2)
    assert result[1] == NamedTuple(d=4)

    od = OrderedDict(data)
    result = to_namedtuple(od)
    assert result[0] == NamedTuple(a=1, c=2, b=3)
    assert result[1] == Named

# Generated at 2022-06-21 12:49:04.260072
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pytest import raises
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': {'d': 3}}) == namedtuple('NamedTuple', 'a b c')(1, 2, namedtuple('NamedTuple', 'd')(3))
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', {'d': 3})],)) == namedtuple('NamedTuple', 'a b c')(1, 2, namedtuple('NamedTuple', 'd')(3))

# Generated at 2022-06-21 12:49:16.372479
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from tests.fixtures import (
        dic,
        dic_list,
        dic_odict,
        dic_sn,
        dic_tuple,
    )
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from tests.testutils import (
        is_namedtuple,
        values_are_NamedTuple,
    )

    # Test dic
    # Test returned type
    out_dic = to_namedtuple(dic)
    assert is_namedtuple(out_dic)
    # Test correct values
    assert out_dic.a == 'a'
    assert out_dic.b == 'b'

    # Test dic_list

# Generated at 2022-06-21 12:49:27.213249
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    class C(NamedTuple):
        a: int
        b: int
    x = SimpleNamespace()
    x.foo = SimpleNamespace()
    x.foo.y = [1, 2, 3]
    data = OrderedDict([('foo', OrderedDict([('y', x.foo.y)]))])
    data2 = dict(data)
    data3 = dict(zip(list('abcd'), (3, 4, 5, 6)))
    data4 = [SimpleNamespace(a=1, b=2)]
    data5 = [C(a=1, b=2)]
    data6 = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]


# Generated at 2022-06-21 12:49:40.303601
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': [2, 3]}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b[0] == 2
    assert out.b[1] == 3

    dic = {'a': 1, 'b': {'c': 3}}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b.c == 3

    dic = {'a': 1, 'b': {'c': [3, 4]}}
    out = to_namedtuple(dic)

# Generated at 2022-06-21 12:49:44.619663
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    from flutils.namedtupleutils import to_namedtuple, _to_namedtuple

    from types import SimpleNamespace

    @singledispatch
    def _sanity_check_to_namedtuple(obj: Any) -> Any:
        return obj


# Generated at 2022-06-21 12:49:45.282996
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-21 12:49:56.555751
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from dataclasses import dataclass
    from flutils.namedtupleutils import to_namedtuple
    from numbers import Number
    from types import SimpleNamespace
    from typing import NamedTuple


# Generated at 2022-06-21 12:50:09.555763
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class _T(NamedTuple):
        k1: Any
        k2: Any
        k3: Any

    from unittest import TestCase


# Generated at 2022-06-21 12:50:22.837653
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    with pytest.raises(TypeError):
        to_namedtuple(1)
    with pytest.raises(TypeError):
        to_namedtuple('foo')
    with pytest.raises(TypeError):
        to_namedtuple(None)

    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple(
        'NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, '_': 3}) == namedtuple(
        'NamedTuple', 'a b')(a=1, b=2)
   

# Generated at 2022-06-21 12:50:31.501466
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    class testclass(object):
        pass

    assert(str(to_namedtuple(testclass())) == "NamedTuple()")

    assert(str(to_namedtuple([])) == "[]")

    assert(str(to_namedtuple(())) == "()")

    assert(str(to_namedtuple([{'a': 1, 'b': 2}])) == "[NamedTuple(a=1, b=2)]")

    assert(str(to_namedtuple({'a': 1, 'b': 2})) == "NamedTuple(a=1, b=2)")


# Generated at 2022-06-21 12:50:43.249082
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic['foo'] = 'bar'
    assert to_namedtuple(dic) != namedtuple('NamedTuple', 'a b')(a=1, b=2)
    ord = OrderedDict([('c', 3), ('d', 4)])
    assert to_namedtuple(ord) == namedtuple('NamedTuple', 'c d')(c=3, d=4)

# Generated at 2022-06-21 12:50:53.322535
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2
    dic = {'a': 1, 2: 'b'}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert getattr(nt, '2') == 'b'
    dic = {'_a': 1, '_b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert hasattr(nt, '_a') is False
   

# Generated at 2022-06-21 12:51:05.611764
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.validators import validate_identifier
    assert to_namedtuple({'a': 1, 'b': 2}) == \
        namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    assert to_namedtuple({'_a': 1,
                          'camelCase': 2}) == \
        namedtuple('NamedTuple', ('camelCase',))(camelCase=2)
    assert to_namedtuple({'camelCase': 2, '_a': 1}) == \
        namedtuple('NamedTuple', ('camelCase',))(camelCase=2)

# Generated at 2022-06-21 12:51:16.205877
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert result == namedtuple('NamedTuple', ['a', 'b'])(1, 2)

    dic = OrderedDict((('a', 1), ('b', 2)))
    result = to_namedtuple(dic)
    assert result == namedtuple('NamedTuple', ['a', 'b'])(1, 2)

    name_tup = namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    result = to_namedtuple(name_tup)
    assert result == namedtuple('NamedTuple', ['a', 'b'])(1, 2)


# Generated at 2022-06-21 12:51:27.028711
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    ###########################################################################
    # OrderedDict
    ###########################################################################
    # OrderedDict but no keys to convert
    dic = OrderedDict((('a', 1), ('b', 2)))
    nt: NamedTuple = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    # OrderedDict with keys to convert
    dic = OrderedDict((('a', 1), ('_b', 2)))
    nt: NamedTuple = to_namedtuple(dic)
    assert nt.a == 1
    assert hasattr(nt, '_b') is False

    #################################################################

# Generated at 2022-06-21 12:51:33.848038
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert nt.a == 1
    assert nt.b == 2
    assert nt.__doc__ == 'NamedTuple(a=1, b=2)'

# Generated at 2022-06-21 12:51:41.441288
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test namedtuple
    tup1 = namedtuple('tup1', ['a', 'b'])
    tup = tup1(a=1, b=2)
    assert to_namedtuple(tup) == tup

    # Test one level of OrderedDict
    od = OrderedDict([
        ('a', 1),
        ('b', 2),
    ])
    assert to_namedtuple(od) == tup1(a=1, b=2)

    # Test one level of SimpleNamespace
    sn = SimpleNamespace(a=1, b=2)
    assert to_namedtuple(sn) == tup1(a=1, b=2)

    # Test one level of dict
    dic = {'b': 2, 'a': 1}
    assert to_

# Generated at 2022-06-21 12:51:57.496714
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert hasattr(nt, '_fields')
    assert nt._fields == ('a', 'b')
    assert 'a' in nt._fields
    assert 'b' in nt._fields



# Generated at 2022-06-21 12:52:07.398781
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    from collections import OrderedDict

    a = OrderedDict((('a', 1), ('b', 2)))
    assert to_namedtuple(a) == to_namedtuple({'a': 1, 'b': 2})
    b = to_namedtuple([a])
    assert to_namedtuple(b) == b

    b = to_namedtuple({'a': 1, 'b': 2})
    a = cast(NamedTuple, b)
    msg = 'AttributeError: \'NamedTuple\' object has no attribute \'a\''
    try:
        assert a.a == 1
    except AttributeError as e:
        assert str(e) == msg


# Generated at 2022-06-21 12:52:19.085325
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    import unittest

    import pkg_resources

    from flutils.loggingutils import set_log_level

    set_log_level(logger_name='flutils', level='CRITICAL')

    class ToNamedTuple(unittest.TestCase):
        """Unit tests for function to_namedtuple"""

        def test_to_namedtuple(self):
            """Test for function to_namedtuple: valid inputs"""
            from collections import OrderedDict

            from flutils.namedtupleutils import to_namedtuple

            list_: List[Any] = [{'b': 2}, {'a': 1}]
            list_ = to_namedtuple(list_)
            self.assertEqual(len(list_), 2)

           

# Generated at 2022-06-21 12:52:28.203736
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert nt.a == 1
    assert hasattr(nt, 'b')
    assert nt.b == 2
    assert hasattr(nt, 'c')
    assert nt.c == 3
    assert isinstance(nt, tuple)
    assert len(nt) == 3

    dic = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert nt.a == 1
    assert hasattr(nt, 'b')
    assert nt.b == 2

# Generated at 2022-06-21 12:52:38.796375
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    def check(obj):
        out = to_namedtuple(obj)
        assert isinstance(out, NamedTuple)

    def check_raises(obj):
        with pytest.raises(TypeError):
            to_namedtuple(obj)

    check({})
    check_raises([])
    check_raises(0)
    check_raises(0.0)

    ns = SimpleNamespace()
    ns.a = 1
    ns.b = [2]
    ns.c = SimpleNamespace()
    ns.c.d = 3
    check(ns)

    a = dict(a=1, b=2)
    a['c'] = a
    a['d'] = [a]

# Generated at 2022-06-21 12:52:45.927956
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    dic2 = {'a': 1, 'b': {'c': 2}}
    nt = to_namedtuple(dic)
    assert str(nt) == 'NamedTuple(a=1, b=2)'
    nt2 = to_namedtuple(dic2)
    assert str(nt2) == 'NamedTuple(a=1, b=NamedTuple(c=2))'

# Generated at 2022-06-21 12:52:57.327022
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping, Sequence
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from typing import Dict, List, Optional, Tuple

    # Allowed to convert
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert to_namedtuple(OrderedDict([('a', 'b'), ('c', 'd')])) == (
        'OrderedDict([(\'a\', \'b\'), (\'c\', \'d\')])'
    )

# Generated at 2022-06-21 12:53:04.655412
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection SpellCheckingInspection
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple(OrderedDict([('c', 3), ('d', 4)])) == namedtuple('NamedTuple', ['c', 'd'])(3, 4)
    # noinspection SpellCheckingInspection
    assert to_namedtuple([{'e': 5, 'f': 6}, {'g': 7, 'h': 8}]) == [namedtuple('NamedTuple', ['e', 'f'])(5, 6), namedtuple('NamedTuple', ['g', 'h'])(7, 8)]

# Generated at 2022-06-21 12:53:07.604310
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Setup
    obj = [1, 2, 3]

    # Exercise
    result = to_namedtuple(obj)

    # Verify
    assert result == [1, 2, 3]



# Generated at 2022-06-21 12:53:19.234951
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple, OrderedDict

    # Test to_namedtuple()
    dic = {'a': 1, 'b': 2}
    # noinspection PyTypeChecker
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert out.a == 1
    assert out.b == 2

    ord_dic = OrderedDict()
    ord_dic['a'] = 1
    ord_dic['b'] = 2
    assert isinstance(to_namedtuple(ord_dic), namedtuple)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert out.a == 1

# Generated at 2022-06-21 12:53:43.442604
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(None) == NamedTuple()
    assert to_namedtuple('None') == 'None'

# Generated at 2022-06-21 12:53:53.219616
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert len(obj) == 2

    dic = OrderedDict({'b': 2, 'a': 1})
    obj = to_namedtuple(dic)
    assert obj.b == 2
    assert obj.a == 1
    assert len(obj) == 2

    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c.d == 3
    assert obj.c.e == 4

# Generated at 2022-06-21 12:54:00.578956
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from copy import deepcopy
    import inspect
    import json
    import re
    import sys
    import types
    from types import SimpleNamespace
    import unittest
    from unittest.mock import Mock
    import uuid

    # noinspection PyPep8Naming,PyUnusedLocal,SpellCheckingInspection
    def _setup_data(
            nesting_level: int = 0,
            length: int = 3,
            singular: bool = False
    ) -> dict:
        if nesting_level > 5:
            return None
        _dict = dict()

# Generated at 2022-06-21 12:54:01.234025
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:54:10.737365
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing function to_namedtuple...', end='')

    application = {
        'name': {
            'first': 'James',
            'middle': 'Boswell',
            'last': 'Jones'
        },
        'age': 24,
        'gender': 'male'
    }
    application = to_namedtuple(application)
    assert repr(application) == "NamedTuple(age=24, gender='male', name=NamedTuple(first='James', last='Jones', middle='Boswell'))"

    application = to_namedtuple(application)
    assert repr(application) == "NamedTuple(age=24, gender='male', name=NamedTuple(first='James', last='Jones', middle='Boswell'))"


# Generated at 2022-06-21 12:54:22.279282
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # simple case
    dic = {'a': 1, 'b': 2}
    out: NamedTuple = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    # double conversion
    dic = {'a': 1, 'b': 2}
    out: NamedTuple = to_namedtuple(dic)
    out = to_namedtuple(out)
    assert out.a == 1
    assert out.b == 2

    # lists
    dic = {'a': 1, 'b': 2}
    out: List[NamedTuple] = to_namedtuple([dic])
    assert out[0].a == 1
    assert out[0].b == 2

    # SimpleNamespace
    # From source code of types.py
    #

# Generated at 2022-06-21 12:54:23.040129
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 12:54:32.764217
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class O(SimpleNamespace):
        c: int = 123

        def __repr__(self):
            return '<%s>' % type(self).__name__

    d = {'a': 1, 'b': O()}
    o = SimpleNamespace()
    o.d = {'a': 1, 'b': O()}
    o.l = ['a', 'b', O()]
    o.t = ('a', 'b', O())
    # noinspection PyTypeChecker
    result: Union[Mapping, Sequence] = to_namedtuple(o)
    assert isinstance(result, dict)
    assert set(result.keys()) == set(['d', 'l', 't'])
    assert result.d == {'a': 1, 'b': O()}

# Generated at 2022-06-21 12:54:42.157601
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == cast(NamedTuple, NamedTuple(a=1, b=2))
    dic = {'_a': 1, '_b': 2}
    assert to_namedtuple(dic) == cast(NamedTuple, NamedTuple())
    dic = {'a': {'a': 1, 'b': 2}, 'b': 2}
    assert to_namedtuple(dic) == cast(NamedTuple, NamedTuple(a=NamedTuple(a=1, b=2), b=2))
    lis = [1, 'a', 2]
    assert to_namedtuple(lis) == cast(List, [1, 'a', 2])

# Generated at 2022-06-21 12:54:47.281705
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        ChainMap,
        Counter,
        defaultdict,
        deque,
        UserDict,
        UserList,
        UserString,
    )
    from typing import Dict, Set

    from _pytest.warnings import warns
    from flutils.miscutils import Struct

    def test_it():
        d = {'a': 1}
        assert to_namedtuple(d) == namedtuple('NamedTuple', 'a')(1)
        l = [{'a': 1}, {'b': 2}]
        assert to_namedtuple(l) == [namedtuple('NamedTuple', 'a')(1),
                                    namedtuple('NamedTuple', 'b')(2)]
        t = ({'a': 1}, {'b': 2})
       