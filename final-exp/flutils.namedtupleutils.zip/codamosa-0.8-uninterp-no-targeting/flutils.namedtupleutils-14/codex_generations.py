

# Generated at 2022-06-21 12:45:16.185078
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import (
        choice,
        randint,
    )
    from string import ascii_lowercase
    from collections import (
        OrderedDict,
    )
    from types import (
        SimpleNamespace,
    )
    # Setup
    count = 10
    min_length = 3
    max_length = 10
    min_dict_count = 0
    max_dict_count = 5
    min_list_count = 0
    max_list_count = 5

    def make_str(length: int) -> str:
        return ''.join(choice(ascii_lowercase) for _ in range(length))

    def make_dict() -> dict:
        dic = {}
        total = randint(0, count)

# Generated at 2022-06-21 12:45:26.966823
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    nt = to_namedtuple(obj)
    assert nt.a == 1
    assert nt.b == 2
    assert nt[0] == 1
    assert nt[1] == 2
    assert nt == (1, 2)
    assert list(nt) == [1, 2]
    assert nt._fields == ('a', 'b')

    obj = {'a': 1, 'b': 2, 'c_d': 3}
    nt = to_namedtuple(obj)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c_d == 3
    assert nt[0] == 1
    assert nt[1] == 2
    assert nt[2] == 3
   

# Generated at 2022-06-21 12:45:37.667735
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({
        "foo": 1,
        "bar": "baz",
        "nested": {
            "a": 5,
            "b": "c",
        }
    }
    )
    assert to_namedtuple(
        [
            {
                "foo": 1,
                "bar": "baz",
                "nested": {
                    "a": 5,
                    "b": "c",
                }
            },
            {
                "foo": 2,
                "bar": "qux",
                "nested": {
                    "a": 10,
                    "b": "d",
                }
            },
        ]
    )

# Generated at 2022-06-21 12:45:46.930999
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)
    dic = OrderedDict({'a': 1, 'b': 2})
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)
    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(1, 2, 3)
    dic = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': 5}
    assert to_namedtuple(dic) == \
        named

# Generated at 2022-06-21 12:45:55.996532
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    # noinspection PyProtectedMember
    class TestToNamedTuple(unittest.TestCase):
        def test_list(self):
            nt: namedtuple = to_namedtuple(['a', 'b', 1])
            self.assertEqual(nt._fields, tuple(range(len(nt))))

        def test_dict(self):
            nt: namedtuple = to_namedtuple({'a': 1, 'b': 2})
            self.assertEqual(nt._fields, ('a', 'b'))

        def test_namedtuple(self):
            obj = namedtuple('obj', 'a b c')
            nt: namedtuple = to_namedtuple(obj(1, 2, 3))

# Generated at 2022-06-21 12:46:06.330120
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple({}) == tuple()
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

# Generated at 2022-06-21 12:46:18.765260
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Tests for non-allowed types
    obj: Any
    with pytest.raises(TypeError) as te:
        obj = to_namedtuple(None)
    assert obj is None
    with pytest.raises(TypeError) as te:
        obj = to_namedtuple('test')
    assert obj is None
    with pytest.raises(TypeError) as te:
        obj = to_namedtuple(123)
    assert obj is None
    with pytest.raises(TypeError) as te:
        obj = to_namedtuple(123.4)
    assert obj is None
    with pytest.raises(TypeError) as te:
        obj = to_namedtuple(set([1, 2, 3]))
    assert obj is None

# Generated at 2022-06-21 12:46:31.487729
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import json
    import os.path as osp
    import tempfile as tmpf

    class TestToNamedTuple(unittest.TestCase):

        def test_to_namedtuple(self):
            with open(self.json_file) as fhd:
                file_dt = json.load(fhd)
            first_obj = file_dt['first_obj']
            result_first_obj = to_namedtuple(first_obj)
            self.assertIsInstance(result_first_obj, namedtuple)
            self.assertEqual(first_obj, result_first_obj)
            self.assertEqual(first_obj, result_first_obj._asdict())
            self.assertTrue(hasattr(result_first_obj, 'foo'))


# Generated at 2022-06-21 12:46:44.536557
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple"""
    class Foo:
        """Class Foo"""
        def __init__(self, x: int, y: int) -> None:
            self.x = x
            self.y = y

    foo = Foo(1, 2)
    assert not hasattr(foo, '_fields')
    assert not hasattr(foo, '_asdict')

    obj = {'a': {'b': {'c': 1}}, 'd': 2}
    with pytest.raises(TypeError):
        to_namedtuple(foo)
    with pytest.raises(TypeError):
        to_namedtuple('Hello World!')
    with pytest.raises(TypeError):
        to_namedtuple(obj)


# Generated at 2022-06-21 12:46:52.373573
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
        >>> test_to_namedtuple()
        '''Test to_namedtuple'''
    """
    print("""
    '''Test to_namedtuple'''
    """)
    # Set up a test dictionary
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8, 'i': 9}
    # Convert the dictionary into a namedtuple
    test_nt = to_namedtuple(dic)
    # Test the results
    assert test_nt.a == 1
    assert test_nt.b == 2
    print(""" NamedTuple('%s'): %s""" % (test_nt._fields, test_nt))
    assert test_nt.c == 3


# Generated at 2022-06-21 12:47:08.486891
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tup: Tuple[int, ...] = (1, 2, 3)
    obj_tup = to_namedtuple([1, 2, 3])
    obj_tup2 = to_namedtuple(tup)
    assert isinstance(obj_tup, list)
    assert isinstance(obj_tup2, tuple)
    assert obj_tup == [1, 2, 3]
    assert obj_tup2 == (1, 2, 3)
    obj_dic = to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(obj_dic, NamedTuple)
    assert obj_dic == NamedTuple(a=1, b=2)
    obj_dic2 = to_namedtuple({'c': 3, 'd': 4})
    assert obj

# Generated at 2022-06-21 12:47:21.200877
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out == NamedTuple(a=1, b=2)

    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert out == lst

    lst = [1, 2, 3, dic]
    out = to_namedtuple(lst)
    assert out[3].a == 1
    assert out[3].b == 2
    assert out == [1, 2, 3, NamedTuple(a=1, b=2)]

    t = (1, 2, 3, dic)
    out = to_namedtuple(t)
    assert out[3].a

# Generated at 2022-06-21 12:47:31.268901
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    #
    # Raises TypeError if given a string.
    #
    try:
        to_namedtuple('a string')
    except TypeError:
        pass
    else:
        assert False

    #
    # Returns the given object if it is not a list, tuple or dict.
    #
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.1) == 1.1
    assert to_namedtuple(None) is None
    assert to_namedtuple('str') == 'str'

    #
    # Returns the given object if it is not a list, tuple or dict.
    #
    lst = [1, 2, 3]
    lst_nt = to_namedtuple(lst)
   

# Generated at 2022-06-21 12:47:41.031767
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for namedtupleutils.to_namedtuple"""

    # Simple test
    obj = {
        'a': 1,
        'b': '2'
    }

    nt = to_namedtuple(obj)
    assert nt.a == 1
    assert nt.b == '2'

    # Test for dict of dict
    obj = {
        'a': 1,
        'b': '2',
        'c': {
            'd': '3',
            'e': 4,
        },
        'f': ['5', 6],
    }

    nt = to_namedtuple(obj)
    assert nt.a == 1
    assert nt.b == '2'
    assert nt.c.d == '3'
    assert nt.c.e == 4

# Generated at 2022-06-21 12:47:49.651606
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the to_namedtuple function."""
    def check(
            name: str,
            obj: _AllowedTypes,
            expected: Union[List, NamedTuple, SimpleNamespace, Tuple]
    ) -> None:
        """Check the conversion."""
        actual = to_namedtuple(obj)
        try:
            assert actual == expected
        except AssertionError:
            raise AssertionError(
                f"{name}: expected: {expected} actual: {actual}"
            )

    #: 100000 loops, best of 3: 3.81 usec per loop
    #: 100000 loops, best of 3: 4.1 usec per loop
    #: 100000 loops, best of 3: 4.1 usec per loop
    #: 100000 loops, best of 3: 3.84 usec per loop

# Generated at 2022-06-21 12:48:01.120723
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    obj = [1, 2, {'a': 1, 'b': 2}]
    out = to_namedtuple(obj)
    assert out == [1, 2, {'a': 1, 'b': 2}]

    obj = [1, 2, {'a': 1, 'b': 2}]
    out = to_namedtuple(obj, _started=True)
    assert out == [1, 2, NamedTuple(a=1, b=2)]

    obj = (1, 2, {'a': 1, 'b': 2})
    out = to_namedtuple(obj)

# Generated at 2022-06-21 12:48:10.778205
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert isinstance(obj, namedtuple('a', dic.keys()))
    try:
        to_namedtuple(obj)
    except TypeError as err:
        assert str(err) == (
            "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
            "got: (NamedTuple) NamedTuple(a=1, b=2)"
        )


if __name__ == '__main__':
    # Unit test code
    test_to_namedtuple()

# Generated at 2022-06-21 12:48:17.442892
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    tup = ('a', 'b')
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(tup) == ('a', 'b')
    assert to_namedtuple([tup]) == [('a', 'b')]
    assert to_namedtuple((dic,)) == (namedtuple('NamedTuple', 'a b')(a=1, b=2),)

# Generated at 2022-06-21 12:48:28.440828
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b.c == 3
    assert out.b.d == 4


# Generated at 2022-06-21 12:48:37.631875
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {}
    assert to_namedtuple(d) == namedtuple('NamedTuple', '')()
    d = OrderedDict()
    assert to_namedtuple(d) == namedtuple('NamedTuple', '')()
    d = {'a': 1, 'b': 2}
    assert to_namedtuple(d) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    d = OrderedDict()
    d['a'] = 1
    d['b'] = 2
    assert to_namedtuple(d) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    d = {'A': 1, 'B': 2}
    assert to_namedtuple(d) == namedtuple

# Generated at 2022-06-21 12:48:51.151062
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    # namedtupleinput
    dic: dict = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('_', 'a b')(1, 2)
    dic: dict = {'a': 1, 'b': [1, 2, 3]}
    assert to_namedtuple(dic) == namedtuple('_', 'a b')(1, [1, 2, 3])
    dic: dict = {'a': 1, 'b': [1, {'c': 1, 'd': 2}, 3]}

# Generated at 2022-06-21 12:49:02.795383
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    nt = to_namedtuple({'a': 1, 'b': 2})
    assert nt.a == 1
    assert nt.b == 2
    nt = to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert nt.a == 1
    assert nt.b == 2
    nt = to_namedtuple(SimpleNamespace(a=1, b=2))
    assert nt.a == 1
    assert nt.b == 2

# Generated at 2022-06-21 12:49:15.240421
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.testutils import TestCase
    t = TestCase()
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    t.assert_namespace(out, a=1, b=2)
    odic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(odic)
    t.assert_namespace(out, a=1, b=2)
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    t.assert_exact_len(out, 3)
    t.assert_exact_type(out, List[int])
    t.assert_exact(out, [1, 2, 3])

# Generated at 2022-06-21 12:49:26.473014
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_type
    from typing import (
        Dict,
        List,
    )

    # Invalid types...

# Generated at 2022-06-21 12:49:39.826020
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils._testing.mock import (
        abc_mapping,
        abc_mapping_orderdict,
        abc_mapping_simplenamespace,
        abc_sequence_list,
        abc_sequence_tuple,
        abc_nontuple_str,
        abc_nontuple_int,
        abc_nontuple_bool,
        abc_nontuple_float,
        abc_nontuple_complex,
        abc_nontuple_bytearray,
    )
    from flutils.validators import validate_identifier

    try:
        validate_identifier('abc')
    except SyntaxError:
        raise Assertion

# Generated at 2022-06-21 12:49:51.929703
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) == 1
    import logging
    from flutils.namedtupleutils import to_namedtuple
    from flutils.logutils import set_tracer
    set_tracer(logging.DEBUG)
    x = dict(a=1, b=dict(c=3, d=4))
    assert to_namedtuple(x) == to_namedtuple(dict(a=1, b=dict(c=3, d=4)))
    assert to_namedtuple(tuple(x.keys())) == tuple(x.keys())
    assert to_namedtuple(tuple(x.values())) == to_namedtuple(
        [1, to_namedtuple(dict(c=3, d=4))]
    )

# Generated at 2022-06-21 12:50:02.076297
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    class Test:
        ...
    lst = [Test()]
    # noinspection PyTypeChecker,Mypy
    with pytest.raises(TypeError) as excinfo:
        _ = to_namedtuple(lst)
    assert str(excinfo.value) == (
        "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: "
        "(%r) [<class '__main__.test_to_namedtuple.<locals>.Test'>]")
    # noinspection PyTypeChecker,Mypy
    with pytest.raises(TypeError) as excinfo:
        _ = to_namedtuple(Test())

# Generated at 2022-06-21 12:50:08.431724
# Unit test for function to_namedtuple
def test_to_namedtuple():
    key = 'key'
    dic: dict = {key: 'val'}
    ret: NamedTuple = to_namedtuple(dic)
    assert key in ret._fields
    assert hasattr(ret, key)
    assert getattr(ret, key) == 'val'
    dic = {'key1': 'val1', 'key2': 'val2', 'key3': 'val3'}
    ret: NamedTuple = to_namedtuple(dic)
    for key in dic.keys():
        assert key in ret._fields
        assert hasattr(ret, key)
        assert getattr(ret, key) == dic[key]
    dic = {'key1': 'val1', 'key2': 'val2', 'key3': dic}
    ret: NamedTuple = to

# Generated at 2022-06-21 12:50:10.629609
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _test_to_namedtuple(None)
    _test_to_namedtuple()



# Generated at 2022-06-21 12:50:11.283990
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True

# Generated at 2022-06-21 12:50:18.276576
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:50:29.031594
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.assertutils import assert_raises_str
    
    from collections import (
        OrderedDict,
    )
    from collections.abc import Mapping
    from numbers import Number
    from string import ascii_letters
    
    from flutils import (
        namedtupleutils,
    )
    from flutils.namedtupleutils import namedtuple as np_namedtuple
    
    # Allow underscores in identifiers:
    def _make_namedtuple(name, fields):
        np_namedtuple(name, fields, allow_underscore=True)
    
    # Allow underscores in identifiers by default
    namedtupleutils._make_namedtuple = _make_namedtuple
    
    # Test bad types

# Generated at 2022-06-21 12:50:40.326836
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([{'a': 1, 'b': 2}, 'c']) == [NamedTuple(a=1, b=2), 'c']
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(['a', 1, {'b': 2}]) == ['a', 1, NamedTuple(b=2)]
    assert to_namedtuple(('a', {'b': 2})) == ('a', NamedTuple(b=2))

# Generated at 2022-06-21 12:50:51.531841
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) == 1
    assert 'NamedTuple' not in str(type(to_namedtuple(1)))
    assert to_namedtuple('hello') == 'hello'
    assert 'NamedTuple' not in str(type(to_namedtuple('hello')))

    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)


# Generated at 2022-06-21 12:51:03.655856
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from inspect import signature
    from collections import OrderedDict
    from typing import Dict, List

    dic: Dict[str, Any] = {
        'a': 1,
        'b': OrderedDict([
            ('b1', 2),
            ('b2', {'b21': 3, 'b22': 4}),
        ]),
        'c': [
            5,
            {'c1': 6, 'c2': [7, 8]},
            [9, 10, 11],
        ],
        'd': {'d1': 12, 'd2': 13},
    }
    out: 'NamedTuple' = to_namedtuple(dic)

    assert out.a == dic['a']

    b = out.b

# Generated at 2022-06-21 12:51:14.698389
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit tests for function to_namedtuple
    """
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': {'c': 2}}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(
        a=1, b=namedtuple('NamedTuple', 'c')(c=2)
    )

    lst = [{'a': 1}, {'b': 2}]

# Generated at 2022-06-21 12:51:24.826734
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namespacedict import NamespaceDict
    import operator

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)

    if not hasattr(nt, 'a'):
        raise AssertionError()
    if not hasattr(nt, 'b'):
        raise AssertionError()
    if operator.getitem(nt, 'a') != 1:
        raise AssertionError()
    if operator.getitem(nt, 'b') != 2:
        raise AssertionError()
    if nt.a != 1:
        raise AssertionError()
    if nt.b != 2:
        raise AssertionError()


# Generated at 2022-06-21 12:51:34.406087
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:51:41.874031
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace as ns
    import dis

    # noinspection PyPep8Naming,PyPep8Naming
    class C(object):
        pass

    # noinspection PyUnusedLocal
    def test_nested_dict(nested_dict):
        """
        Tests the `to_namedtuple` function with a nested dictionary object.

        Args:
            nested_dict: A nested dictionary object.

        Returns:
            The converted object.
        """
        # noinspection PyTypeChecker
        NamedTuple = to_namedtuple(nested_dict)
        return NamedTuple

    # noinspection PyUnusedLocal

# Generated at 2022-06-21 12:51:46.101934
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''
    Unit test for function to_namedtuple
    '''
    from flutils.testutils import make_namedtuple
    for obj, obj_as_namedtuple in make_namedtuple.tests(
            func=to_namedtuple
    ):
        assert type(obj_as_namedtuple) is make_namedtuple.tuple_type


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:52:00.555495
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj_type_error = ['abc', 0x23, True, (1, 's'), [3, 4, 5]]
    for item in obj_type_error:
        with pytest.raises(TypeError):
            to_namedtuple(item)
    obj_type_error = [{True, None, 1}, set([1, 2, 3])]
    for item in obj_type_error:
        with pytest.raises(TypeError):
            to_namedtuple(item)

    obj = dict(a=1, b=2)
    result = to_namedtuple(obj)
    assert isinstance(result, NamedTuple)
    assert isinstance(result.a, int) and isinstance(result.b, int)


# Generated at 2022-06-21 12:52:09.740138
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2.0}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2.0)
    assert to_namedtuple({'a': 1, 'b': 2.1}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2.1)
    assert to_namedtuple({'a': 1, 'b': 2.0}).b == 2.0
    assert to_namedtuple({'a': 1, 'b': 2.1}).b == 2.1
    assert to_named

# Generated at 2022-06-21 12:52:20.937702
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        _get_namedtuple_attrs,
        to_namedtuple
    )

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert _get_namedtuple_attrs(nt) == ['a', 'b']
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, '_b': 2}
    nt = to_namedtuple(dic)
    assert _get_namedtuple_attrs(nt) == ['a']
    assert nt.a == 1

    nt = to_namedtuple({})
    assert _get_namedtuple_attrs(nt) == []


# Generated at 2022-06-21 12:52:29.329463
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple(
        'NamedTuple', 'a b'
    )(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == namedtuple(
        'NamedTuple', 'a b'
    )(1, 2)
    assert to_namedtuple({'A': 1, 'b': 2, 'C': 3}) == namedtuple(
        'NamedTuple', 'A C b'
    )(1, 3, 2)

# Generated at 2022-06-21 12:52:37.285680
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    data: Union[List[Any], Tuple[Any, ...], NamedTuple, str, Mapping, SimpleNamespace] = [
        {'a': 1, 'b': 2},
        {'a': 2, 'b': 3},
        {'nested': {'a': 3, 'b': 4}},
    ]
    expected: List[Any] = [
        NamedTuple(a=1, b=2),
        NamedTuple(a=2, b=3),
        NamedTuple(nested=NamedTuple(a=3, b=4)),
    ]

    actual = to_namedtuple(data)
    assert expected == actual

# Generated at 2022-06-21 12:52:48.196523
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testutils import assert_dicts_and_namedtuples_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    dic_expected = {'a': 1, 'b': 2}
    obj_expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert_dicts_and_namedtuples_equal(dic_expected, obj_expected, out)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd_': 4, '_': 5, '': 6}
    out = to_namedtuple(dic)
    d

# Generated at 2022-06-21 12:52:59.574498
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""

# Generated at 2022-06-21 12:53:10.685591
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import (
        Any,
        cast,
        Dict,
        List,
        NamedTuple,
        Optional,
    )

    def _check_type(
            val: Any,
            val_type: Optional[type] = None
    ) -> None:
        val_type = val_type or type(val)
        assert isinstance(val, val_type)

    def _check_typed(
            val: Any,
            val_type: Optional[type] = None
    ) -> None:
        _check_type(val, val_type)
        if isinstance(val, (dict, list, tuple)) and val:
            _check_type(next(iter(val)), type(val))


# Generated at 2022-06-21 12:53:21.392312
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        """Unit test suite for to_namedtuple."""

        def test_to_namedtuple(self):
            from collections import OrderedDict

            class ToNamedTupleUnitTest(unittest.TestCase):
                """Unit test suite for to_namedtuple."""

                def test_to_namedtuple(self):
                    """Test for to_namedtuple."""
                    from flutils.namedtupleutils import to_namedtuple

                    out = to_namedtuple(
                        {
                            'a': 1,
                            'b': {
                                'c': 2,
                                'd': 3,
                            }
                        }
                    )
                    self.assertEqual(out.a, 1)

# Generated at 2022-06-21 12:53:32.866561
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Testing function to_namedtuple()
    """
    import copy
    
    dic = {"a": 1, "b": 2}
    nt = to_namedtuple(dic)
    assert hasattr(nt, "a")
    assert nt.a == 1
    assert "a" in nt._fields
    assert nt[0] == 1
    assert nt[1] == 2
    assert dic == {"a": 1, "b": 2}
    
    dic = {"a": 1, "_b": 2}
    nt = to_namedtuple(dic)
    assert not hasattr(nt, "a")
    assert not hasattr(nt, "_b")
    assert "_b" not in nt._fields
    assert nt[0] == 1

# Generated at 2022-06-21 12:53:52.808952
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pformat
    from types import SimpleNamespace
    from typing import Dict

    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(b=2, a=1)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2, _b=3)) == NamedTuple(a=1)
    assert to

# Generated at 2022-06-21 12:54:00.254076
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = dict(a=1, b=2)
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple('NamedTuple', 'a b')) is True
    assert out.a == 1
    assert out.b == 2

    dic = dict(a=1, b=[dict(c=3, d=[4, 6]), 7])
    out = to_namedtuple(dic)
    assert 'c' in dir(out.b[0])
    assert out.b[0].c == 3
    assert out.b[0].d[0] == 4
    assert out.b[1] == 7

    dic = dict(a=1, b=2)
    out = to_namedtuple(dic)
    assert out.a == 1

# Generated at 2022-06-21 12:54:09.421386
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    from collections import defaultdict
    from pprint import pprint

    def pp(*args, **kwargs):
        print()
        pprint(*args, **kwargs)
        print()

    def _encode(_d: Any):
        import simplejson as json
        return json.dumps(_d, use_decimal=True, ignore_nan=True)


# Generated at 2022-06-21 12:54:16.264716
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import types

    # Sample dictionary.
    d = dict(a = 1, b = 2)

    # Sanity check for expected output.
    assert isinstance(to_namedtuple(d), types.SimpleNamespace)
    assert d.a == 1
    assert d.b == 2

    # Check the test function itself!
    assert test_to_namedtuple() == 'None'

# Generated at 2022-06-21 12:54:24.831618
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple({'c': 1, 'b': 2}) == namedtuple('NamedTuple', ['b', 'c'])(2, 1)
    assert to_namedtuple(OrderedDict([('c', 1), ('b', 2)])) == namedtuple('NamedTuple', ['c', 'b'])(1, 2)
    assert to_namedtuple(OrderedDict([('c', 1), ('b', 2)])) == namedtuple('NamedTuple', ['c', 'b'])(1, 2)

# Generated at 2022-06-21 12:54:33.758695
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple(OrderedDict()) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == namedtuple

# Generated at 2022-06-21 12:54:37.617748
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert(nt.a == 1)

# Generated at 2022-06-21 12:54:46.635845
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('test', ['a', 'b'])(1, 2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]) == [
        namedtuple('test', ['a', 'b'])(1, 2),
        namedtuple('test', ['c', 'd'])(3, 4)
    ]
    assert to_namedtuple(dict(a=1, b=2)) == namedtuple('test', ['a', 'b'])(1, 2)

# Generated at 2022-06-21 12:54:55.730268
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'n': 0, 'a': 1, 'b': 2, '_c': 3}
    item = to_namedtuple(dic)
    assert isinstance(item, NamedTuple)
    assert item == NamedTuple(a=1, b=2, n=0)

    dic = OrderedDict([('a', 1), ('b', 2), ('n', 0), ('_c', 3)])
    item = to_namedtuple(dic)
    assert isinstance(item, NamedTuple)
    assert item == NamedTuple(a=1, b=2, n=0)

    tup = (1, 2, 3)
    item = to_namedtuple(tup)
    assert isinstance(item, tuple)
    assert item == (1, 2, 3)

   

# Generated at 2022-06-21 12:55:05.870806
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    test_dic = {"a": 1, "b": 2}
    test_namedtuple = to_namedtuple(test_dic)
    assert test_namedtuple == NamedTuple(a=1, b=2)

    test_list = [{"a": 1, "b": 2}, {"c": 3, "d": 4}]
    test_namedtuple_list = to_namedtuple(test_list)
    assert test_namedtuple_list == [NamedTuple(a=1, b=2), NamedTuple(c=3, d=4)]