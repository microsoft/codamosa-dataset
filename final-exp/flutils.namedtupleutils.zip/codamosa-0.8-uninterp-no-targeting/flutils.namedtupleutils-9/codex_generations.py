

# Generated at 2022-06-21 12:45:13.642735
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    dic = {'a': 1, 'b': 2}
    res = to_namedtuple(dic)
    assert res == NamedTuple(a=1,b=2)
    with pytest.raises(TypeError):
        to_namedtuple('test')
    with pytest.raises(TypeError):
        to_namedtuple(1)
    with pytest.raises(TypeError):
        to_namedtuple(1.0)
    with pytest.raises(TypeError):
        to_namedtuple(True)
    with pytest.raises(TypeError):
        to_namedtuple(None)

# Generated at 2022-06-21 12:45:21.464015
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from pprint import pprint
    import flutils.namedtupleutils as ntu

    dic = {'a': 1, 'b': 2}
    assert ntu.to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    tup = (1, 2)
    assert ntu.to_namedtuple(tup) == namedtuple('NamedTuple', '_1 _2')(_1=1, _2=2)

    lst = [1, 2, 3]
    assert ntu.to_namedtuple(lst) == namedtuple('NamedTuple', '_1 _2 _3')(_1=1, _2=2, _3=3)
    assert n

# Generated at 2022-06-21 12:45:32.285177
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )

    from flutils.to_stringutils import to_string
    from flutils.to_stringutils import to_string_dict

    from flutils.validators import validate_identifier

    def test(
            obj: Union[
                List, Tuple, Mapping, SimpleNamespace, NamedTuple, Sequence
            ],
            expected: Union[str, List[str]],
            allow_private: bool = False,
            indent: int = 2,
            sort_keys: bool = False
    ) -> None:
        out = to_namedtuple(obj)
        assert expected == to_string(out, allow_private=allow_private,
                                     indent=indent, sort_keys=sort_keys)


# Generated at 2022-06-21 12:45:43.671176
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.miscutils import (
        ReflectiveContainer,
    )

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == namedtuple('NamedTuple', 'a, b')(a=1, b=2)

    dic2 = {'c': 3, 'd': 4}
    dic3 = {'e': 5, 'f': 6}
    dic4 = {'g': 7, 'h': 8}
    dic5 = {'i': 9, 'j': 10}
    dic6 = {'k': 11, 'l': 12}

# Generated at 2022-06-21 12:45:54.258565
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from unittest.mock import MagicMock
    from unittest.mock import Mock

    from flutils.miscutils import is_namedtuple
    from flutils.validators import validate_identifier

    data = []
    data.append((
        {'a': {'b': {'c': 1}, 'd': 2, 'e': 3}},
        namedtuple('NamedTuple', 'a')(a=namedtuple('NamedTuple', 'b d e')(
            b=namedtuple('NamedTuple', 'c')(c=1),
            d=2,
            e=3))
    ))

# Generated at 2022-06-21 12:46:05.158306
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    def _test_to_namedtuple(
        obj: Any,
        _started: bool = False
    ) -> Any:
        if _started is False:
            raise TypeError(
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                "got: (%r) %s" % (type(obj).__name__, obj)
            )
        return obj

    # noinspection PyUnusedLocal
    # noinspection PyShadowingBuiltins
    @_test_to_namedtuple.register(Mapping)
    def _(
        obj: Mapping,
        _started: bool = False
    ) -> Union[NamedTuple, Tuple]:
        keys = []

# Generated at 2022-06-21 12:46:17.754451
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils import DynamicNamedTuple
    

# Generated at 2022-06-21 12:46:29.998071
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    import pytest
    import random
    import string

    def _randlst(size: int, maxlen: int):
        lst = []
        for _ in range(size):
            lst.append(
                ''.join(random.choices(
                    string.ascii_lowercase, k=random.randint(1, maxlen)
                ))
            )
        return lst

    def _randdic(nkeys: int, startkey: int, maxsize: int):
        dic = {}
        for i in range(nkeys):
            key = ''.join(random.choices(
                string.ascii_lowercase, k=random.randint(1, maxsize)
            ))
            if i + startkey:
                key

# Generated at 2022-06-21 12:46:43.060529
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple({'a': 1, 'b': 2}) == SimpleNamespace(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == SimpleNamespace(a=1, b=2, c=3)
    assert to_namedtuple(['a', 1, 'b']) == ['a', 1, 'b']
    assert to_namedtuple(['a', 1, 'b', 2]) == ['a', 1, 'b', 2]
    assert to_namedtuple(('a', 1, 'b')) == ('a', 1, 'b')

# Generated at 2022-06-21 12:46:51.648686
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestNamedTupleUtils(unittest.TestCase):
        """Test the namedtupleutils module."""

        maxDiff = None

        def test_to_namedtuple(self):
            """Test the to_namedtuple function."""

            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            exp = namedtuple('NamedTuple', ['a', 'b'])(1, 2)
            self.assertEqual(out, exp)

            # Test with ordered dict.
            dic = OrderedDict((('b', 2), ('c', 3), ('a', 1)))
            out = to_namedtuple(dic)

# Generated at 2022-06-21 12:47:06.460402
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        namedtuple,
    )
    from types import SimpleNamespace

    def _get_vals():
        return [
            {'a': 1, 'b': 2},
            (1, 2),
            [1, 2],
            SimpleNamespace(a=1, b=2)
        ]

    make = namedtuple('NamedTuple', 'a b')
    names = make(
        a=1,
        b=2
    )
    # noinspection PyTypeChecker
    res = [names]
    for idx, item in enumerate(_get_vals()):
        assert to_namedtuple(item) == res[idx]

    # Ensure to_namedtuple doesn't modify lists or tuples
    for item in _get_vals():
        tmp = to_namedt

# Generated at 2022-06-21 12:47:18.809118
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import collections
    import types
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == collections.namedtuple('namedtuple', ('a', 'b'))(1, 2)
    dic = {'a': 'a', 'b': 2, 'c': 3, '_d': 'd'}
    assert to_namedtuple(dic) == collections.namedtuple('namedtuple', ('a', 'b', 'c'))('a', 2, 3)
    assert to_namedtuple(dic) != collections.namedtuple('namedtuple', ('a', 'b', 'c', '_d'))('a', 2, 3, 'd')
    assert to_namedtuple

# Generated at 2022-06-21 12:47:28.998659
# Unit test for function to_namedtuple
def test_to_namedtuple():
    if __name__ == '__main__':
        from sys import exit, path as syspath
        from os import path as ospath
        mypath = ospath.abspath(ospath.dirname(__file__))
        syspath.insert(0, mypath)
        sysflag = False
        if mypath not in syspath:
            print(
                'ERROR: test_to_namedtuple: path %s not in system search path'
                % mypath
            )
            sysflag = True
        import doctest
        if sysflag is False:
            doctest.testmod(
                optionflags=doctest.ELLIPSIS
                | doctest.IGNORE_EXCEPTION_DETAIL
                | doctest.NORMALIZE_WHITESPACE
            )

# Generated at 2022-06-21 12:47:38.672581
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    """Unit tests for function to_namedtuple."""
    assert to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]) == [
        NamedTuple(a=1, b=2),
        NamedTuple(c=3, d=4),
    ]
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        NamedTuple(a=1, b=2)
    assert to_namedtuple(
        {'a': 1, '_b': 2},
    ) == NamedTuple(a=1)
    assert to_

# Generated at 2022-06-21 12:47:44.881520
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    make = namedtuple('NamedTuple', 'a b')
    # noinspection PyTypeChecker,PyArgumentList
    val: NamedTuple = make(1, 2)
    assert to_namedtuple(obj) == val

    class Obj(object):

        def __init__(self, a: int, b: int = 2) -> None:
            self.a = a
            self.b = b

    obj = Obj(1)
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert out == [1, 2, 3]

    obj = (1, 2, 3)


# Generated at 2022-06-21 12:47:56.881563
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == to_namedtuple({}) == to_namedtuple({})
    assert to_namedtuple('') == to_namedtuple('') == to_namedtuple('')
    assert to_namedtuple(()) == to_namedtuple(()) == to_namedtuple(())
    assert to_namedtuple([]) == to_namedtuple([]) == to_namedtuple([])
    assert to_namedtuple({}) == to_namedtuple({})
    assert to_namedtuple('') == to_namedtuple('')
    assert to_namedtuple(()) == to_namedtuple(())
    assert to_namedtuple([]) == to_namedtuple([])

# Generated at 2022-06-21 12:48:08.490249
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils_test.helpers import assert_namedtuple

    data = {
        'one': 1,
        'two': 2,
        'three': 3,
    }
    actual = to_namedtuple(data)
    expected = data
    assert_namedtuple(expected, actual)

    data = {
        'one': 1,
        'two': 2,
        'three': {
            'one': 1,
            'two': 2,
            'three': 3,
        },
    }
    actual = to_namedtuple(data)
    expected = data
    assert_namedtuple(expected, actual)


# Generated at 2022-06-21 12:48:17.773163
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    with pytest.raises(TypeError):
        to_namedtuple(None)
    assert to_namedtuple(False) == False
    assert to_namedtuple(True) == True
    assert to_namedtuple('') == ''
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple('a b') == 'a b'
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.1) == 1.1
    assert to_namedtuple(1 + 0j) == 1 + 0j
    assert to_namedtuple(0 + 0j) == 0 + 0j
    assert to_namedtuple(b'a') == b'a'

# Generated at 2022-06-21 12:48:27.674371
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    import pprint
    from typing import Dict

    dic: Dict[str, Any] = {
        'a': 1,
        'b': 2,
        'c': 'x',
        'd': ['x', 'y', 'z'],
        'e': {'f': {'g': 'h'}},
        'i': OrderedDict([('f', 'g')]),
    }
    nt = to_namedtuple(dic)
    pprint.pprint(nt.__dict__)
    pprint.pprint(nt.e.f.g)
    print(nt.e.f.g)


# Generated at 2022-06-21 12:48:37.278321
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {
        'a': 1,
        'b': 2,
        'c': 'hello'
    }
    dic_out = to_namedtuple(dic)
    assert dic_out.a == 1
    assert dic_out.b == 2
    assert dic_out.c == 'hello'

    dic_start_with_underscore = {
        '_a': 1,
        'b': 2,
        'c': 'hello',
    }
    dic_out = to_namedtuple(dic_start_with_underscore)
    assert dic_out.b == 2
    assert dic_out.c == 'hello'

# Generated at 2022-06-21 12:48:52.608598
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class NamedTuple1(NamedTuple):
        col1: int
        col2: str

    class NamedTuple2(NamedTuple):
        col1: int
        col2: str

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': 3.0}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3.0)
    dic = {'a': 1, 'b': 2, 'c': NamedTuple(x=100, y=200)}

# Generated at 2022-06-21 12:49:03.924414
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        namedtuple,
        OrderedDict
    )
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import (
        is_namedtuple,
        is_sequence,
    )
    from types import SimpleNamespace
    #
    # Testing dict to NamedTuple
    #
    # Simple dict
    name = 'SimpleNamespace'
    obj = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5,
    }
    out = to_namedtuple(obj)
    expected = namedtuple(name, 'a b c d e')
    assert is_namedtuple(out)
    assert out.__class__.__name__ == name
   

# Generated at 2022-06-21 12:49:16.154887
# Unit test for function to_namedtuple
def test_to_namedtuple():

    Good_Types = (list, tuple, dict, OrderedDict, SimpleNamespace)
    Good_Objs = (
        {'a': 1, 'b': '2'},
        OrderedDict(a=1, b=2),
        SimpleNamespace(a=1, b='2'),
    )
    Bad_Types = (str, int, float)
    Bad_Objs = (1, 1.1)
    for typ in Bad_Types:
        with pytest.raises(TypeError):
            to_namedtuple(typ())
    for obj in Bad_Objs:
        with pytest.raises(TypeError):
            to_namedtuple(obj)
    for typ in Good_Types:
        for obj in Good_Objs:
            to_namedtuple(typ(obj))

# Generated at 2022-06-21 12:49:27.034579
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace

    #: :type: collections.namedtuple._field_defaults_map
    make = namedtuple('NamedTuple', 'a b c d')  # type: ignore[misc]
    nt_dic = {'a': None, 'b': 1, 'c': 'two', 'd': 3.14}
    nt_arg = ('one', 2, 'three', 4.13)
    #: :type: NamedTuple[Any, ...]
    nt_obj = make(*nt_arg)

    # noinspection PyTypeChecker,PyArgumentList
    res_nt_obj1: NamedTuple = to_namedtuple(nt_dic)
    # no

# Generated at 2022-06-21 12:49:40.241038
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 'cannot be used'}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 'cannot be used', 'C': 'can be used'}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1

# Generated at 2022-06-21 12:49:52.481577
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([{'a': 1}, {'a': 2}]) == [NamedTuple(a=1), NamedTuple(a=2)]
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 2, 'b': 3}]) == [NamedTuple(a=1, b=2), NamedTuple(a=2, b=3)]
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 2, 'b': 3, 'c': 4}]) == [NamedTuple(a=1, b=2),
                                                                           NamedTuple(a=2, b=3, c=4)]

# Generated at 2022-06-21 12:50:01.538217
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 'val1'}) == to_namedtuple({'a': 'val1'})
    assert to_namedtuple({'a': 'val1', 'b': 'val2'}) == to_namedtuple({'a': 'val1', 'b': 'val2'})
    assert to_namedtuple({'a': 'val1', 'b': 'val2'}) == to_namedtuple({'b': 'val2', 'a': 'val1'})
    assert to_namedtuple({'a': 'val1', 'b': 'val2'}) != to_namedtuple({'a': 'val1', 'b': 'val-2'})
    assert to_namedtuple({'a': 'val1', 'b': 'val2'}) != to_namedt

# Generated at 2022-06-21 12:50:09.617999
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test conversion of different types to named tuples."""
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    dic = OrderedDict(dic)
    nt = to_namedtuple(dic)
    assert nt[0] == 1
    assert nt[1] == 2
    assert nt[-1] == 2
    assert nt.a == 1
    assert nt.b == 2
    nt = to_namedtuple(('a', 1, 'b', 2))
    assert nt[0] == 'a'
    assert nt[1] == 1
    assert nt[2] == 'b'

# Generated at 2022-06-21 12:50:22.942285
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_dic = {'a': 1, 'b': 2}
    test_list = [test_dic, test_dic]
    test_tuple = (test_dic, test_dic)
    test_tuple_nested = (test_dic, test_list)
    named_test_dic = to_namedtuple(test_dic)
    named_test_dic_b = to_namedtuple(named_test_dic)
    named_test_list = to_namedtuple(test_list)
    namned_test_list_b = to_namedtuple(named_test_list)
    named_test_tuple = to_namedtuple(test_tuple)

# Generated at 2022-06-21 12:50:26.975746
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections.abc import Sequence
    from types import SimpleNamespace
    from typing import Union

    AllowedTypes = Union[
        list,
        tuple,
        dict,
        OrderedDict,
        SimpleNamespace,
    ]
    NotAllowedTypes = Union[
        int,
        float,
        str,
    ]

    # noinspection PyTypeChecker

# Generated at 2022-06-21 12:50:42.118472
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from datetime import datetime
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_username
    from flutils.datautils import DecimalEncoder
    import json
    import decimal

    # Testing to_namedtuple converting objects to NamedTuple.
    # Setting up input.

# Generated at 2022-06-21 12:50:52.501218
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:51:04.657169
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class ToNamedtupleTestCase(unittest.TestCase):
        def test_to_namedtuple(self):
            import datetime
            from time import time
            from random import randint
            from collections import OrderedDict
            from types import SimpleNamespace

            # noinspection PyTypeChecker
            today = datetime.datetime.today()  # type: datetime.date
            date_time: float = float(time())
            rand_int: int = randint(0, 9999)

# Generated at 2022-06-21 12:51:15.489579
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == \
        NamedTuple(a=1, b=2, c=3, d=4)

    assert to_namedtuple({'a': 1, 'b': 2}) == \
        to_namedtuple(NamedTuple(a=1, b=2))


# Generated at 2022-06-21 12:51:26.105040
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json

    test_data = '''
    {
        "data": {
            "name": "The person's name.",
            "age": 12,
            "is_employed": false,
            "salary": {
                "amount": "2000.00",
                "currency": "USD"
            },
            "list_of_values": [
                {
                    "name": "The first name.",
                    "amount": 2000.00
                },
                {
                    "name": "The second name.",
                    "amount": 3000.00
                }
            ],
            "address": {
                "street": "123 Main",
                "city": "Anytown",
                "state": "NY"
            }
        }
    }
    '''

    class Salary(NamedTuple):
        amount: str
        currency

# Generated at 2022-06-21 12:51:36.021882
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    assert 'to_namedtuple' in globals()

    mydict = OrderedDict([('c', 1), ('a', 2), ('b', 3)])
    namedtup = to_namedtuple(mydict)
    assert namedtup == namedtuple('NamedTuple', ('c', 'a', 'b'))(1, 2, 3)

    mydict = {'c': 1, 'a': 2, 'b': 3}
    namedtup = to_namedtuple(mydict)
    assert namedtup == namedtuple('NamedTuple', ('a', 'b', 'c'))(2, 3, 1)


# Generated at 2022-06-21 12:51:41.302640
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert not hasattr(out, 'c')
    assert isinstance(out, NamedTuple) is True
    assert isinstance(out, tuple) is True
    assert isinstance(out, Mapping) is False

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-21 12:51:47.719535
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple('foo') == 'foo'

    lst = [
        1,
        "foo",
        {
            "a": 1,
            "b": [2, 3],
            "c": {
                "d": {
                    "e": [4, 5],
                    "f": 6
                }
            }
        },
        (7, 8),
        {
            "g": [9, 10],
            "h": 11
        },
        (
            12,
            {
                "i": 13,
                "j": [14, 15]
            }
        )
    ]

# Generated at 2022-06-21 12:51:58.511628
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2, 'C': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.C == 3

    class Foo():
        a = 1
        b = 2

    out = to_namedtuple(Foo)
    assert isinstance(out, NamedTuple)
    assert out.a == 1

    from collections import OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2), ('C', 3)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.C == 3


# Generated at 2022-06-21 12:52:00.680418
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) == 1



# Generated at 2022-06-21 12:52:13.473856
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from unittest.mock import patch

    from flutils.namedtupleutils import (
        _to_namedtuple,
        to_namedtuple,
    )

    class Tests(TestCase):
        @staticmethod
        def test_to_namedtuple_bad_type_fails() -> None:
            with patch('sys.exit'):
                no_exit = True
                try:
                    # noinspection PyTypeChecker
                    to_namedtuple(2.5)  # type: ignore[no-any-return]
                except SystemExit:
                    no_exit = False
                assert not no_exit

        # noinspection PyUnreachableCode

# Generated at 2022-06-21 12:52:24.522239
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    # Test for invalid input
    for t in [
        float,
        int,
        object,
        set,
        str
    ]:
        try:
            to_namedtuple(t())
        except TypeError:
            continue
        raise AssertionError(
            "Expected a TypeError to be raised, but didn't: '{}'".format(t)
        )
    try:
        to_namedtuple(None)
    except TypeError:
        pass
    else:
        raise AssertionError(
            "Expected a TypeError to be raised, but didn't"
        )

    # Test for basic list and tuple types

# Generated at 2022-06-21 12:52:35.116032
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple

    def _nested_dict(
            level: int = 3,
            number: int = 1,
            key_prefix: str = '',
            value_prefix: str = ''
    ) -> OrderedDict[str, Union[int, OrderedDict[str, Any]]]:
        data: OrderedDict[str, Union[int, OrderedDict[str, Any]]] = OrderedDict()
        for i in range(level):
            key = "%s%d" % (key_prefix, i)
            data[key] = number
            number += 1
        if level > 0:
            next_lvl = level - 1
            next_prefix = "%s_" % key_prefix
            next_val_prefix = "%s_" % value_prefix

# Generated at 2022-06-21 12:52:46.963086
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    dic = {'a': 1, 'b': {'c': 3, 'd': 4, 'e': [5, 6, 7]}}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b.c == 3
    assert out.b.d == 4
    assert out.b.e[2] == 7

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': [2, 3, 4]}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b[1] == 3

    lis

# Generated at 2022-06-21 12:52:58.387304
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class A(NamedTuple):
        dic: dict
        lis: list
        tup: tuple
        str1: str
        str2: str

    class B(A):
        pass

    dic = {
        'dic': {'b': 2, 'a': 1},
        'lis': [{'b': 2, 'a': 1}, [2, 1, 0]],
        'tup': ({'b': 2, 'a': 1}, (1, 2, 3)),
        'str1': 'string',
        'str2': 'string',
    }
    dic = OrderedDict(dic)
    lis: List[dict] = [dic.copy(), dic.copy()]
    ns = SimpleNamespace(**dic)

# Generated at 2022-06-21 12:53:10.023933
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Basic usage
    dic = {'a': 1, 'b': 2}
    ntup = to_namedtuple(dic)
    assert len(ntup) == 2
    assert ntup.a == 1

    # Test with OrderedDict
    from collections import OrderedDict
    odic = OrderedDict()
    odic['a'] = 1
    odic['b'] = 2
    ntup = to_namedtuple(odic)
    assert ntup.a == 1
    assert ntup.b == 2

    # Test with some items of invalid names
    dic['c.'] = 3
    ntup = to_namedtuple(dic)
    assert ntup.b == 2
    assert hasattr(ntup, 'c.') is False
    assert len

# Generated at 2022-06-21 12:53:20.900588
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_obj = {
        'a': 1,
        'b': 2,
        'c': {
            'ca': 11,
            'cb': 22,
            'cc': OrderedDict(
                (
                    ('cca', 111),
                    ('ccb', 222)
                )
            ),
            'cd': [
                'cd1',
                'cd2'
            ]
        },
        'd': SimpleNamespace(
            da=1,
            db=2,
            dc=3
        ),
        'e': [
            SimpleNamespace(
                ea=1,
                eb=2,
                ec=3
            ),
            {'b': 2}
        ]
    }

# Generated at 2022-06-21 12:53:27.376456
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    dic = {'z': 3, 'b': 2, 'a': 1}
    exp = cast(NamedTuple, namedtuple('NamedTuple', 'a b z')(1, 2, 3))
    # Act
    act = to_namedtuple(dic)
    # Assert
    assert exp == act



# Generated at 2022-06-21 12:53:35.959481
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from typing import Dict
    from flutils.validators import (
        validate_identifier,
    )
    from flutils.miscutils import gen_random
    dic = gen_random.gen_random_dictionary()
    # noinspection PyTypeChecker
    dic: Dict[str, Any] = dic  # type: ignore[assignment]
    ident: str = '_ident'
    while validate_identifier(ident) is True:
        ident = gen_random.gen_random_string(1, 1)
    dic[ident] = '_ident'
    odic = OrderedDict(dic)
    nt = to_namedtuple(odic)
    del dic

# Generated at 2022-06-21 12:53:47.769419
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert obj == (1, 2)
    assert obj == (1, 2)
    assert obj == (1, 2)
    assert obj == (1, 2)
    assert obj == (1, 2)
    assert obj == (1, 2)
    assert obj == (1, 2)
    assert obj == (1, 2)
    assert obj == (1, 2)
    assert obj == (1, 2)
    assert obj == (1, 2)
    assert obj == (1, 2)
    assert obj == (1, 2)

# Generated at 2022-06-21 12:54:09.420762
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert to_namedtuple(('a', 'b', 'c', {'d': 1, 'e': 2})) == (
        'a', 'b', 'c', NamedTuple(d=1, e=2)
    )
    assert to_namedtuple(('a', 'b', 'c', {'d': 1, 'e': 2}, (3, 4, 5))) == (
        'a', 'b', 'c', NamedTuple(d=1, e=2), (3, 4, 5)
    )

# Generated at 2022-06-21 12:54:21.546546
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import sentinel, patch
    from types import SimpleNamespace
    from collections import (
        OrderedDict,
        namedtuple,
    )
    # noinspection PyArgumentList
    FakeNamedTuple = namedtuple('NamedTuple', ('a', 'b'))
    fake_namedtuple = FakeNamedTuple(
        sentinel.a1,
        sentinel.b1,
    )
    dic = OrderedDict()
    dic['a'] = sentinel.a1
    dic['b'] = sentinel.b1
    ord_dic = OrderedDict()
    ord_dic['a'] = sentinel.a1
    ord_dic['b'] = sentinel.b1

# Generated at 2022-06-21 12:54:31.580151
# Unit test for function to_namedtuple

# Generated at 2022-06-21 12:54:41.509958
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    # noinspection PyUnresolvedReferences,PyProtectedMember
    c = namedtuple('NamedTuple', 'a b c')
    args = [
        c(1, 2, 3), c(1, 2, 3), c(1, 2, 3), c(1, 2, 3), c(1, 2, 3), c(1, 2, 3),
    ]


# Generated at 2022-06-21 12:54:52.766271
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    # A simple string
    obj = 'string'
    try:
        to_namedtuple(obj)
        assert False, 'Should not have gotten here. %s' % obj
    except TypeError:
        pass

    # A dictionary
    obj = {'a': 1, 'b': 2}
    converted = to_namedtuple(obj)
    assert converted.a == 1
    assert converted.b == 2
    # Make sure not a string.
    assert not isinstance(converted, str)

    # A list
    obj = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    converted = to_namedtuple(obj)
    assert isinstance(converted, list)

# Generated at 2022-06-21 12:55:03.041499
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import defaultdict
    from typing import Dict, List
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import is_namedtuple

    assert to_namedtuple(None) == None
    assert to_namedtuple(True) == True
    assert to_namedtuple(False) == False
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.1) == 1.1
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(b'a') == b'a'