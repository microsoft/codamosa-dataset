

# Generated at 2022-06-17 19:07:30.546317
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not,
        assert_is,
        assert_raises,
    )

    # Test with a dictionary
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_is_instance(out, tuple)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    # Test with an OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    out

# Generated at 2022-06-17 19:07:40.254714
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    class MyNamedTuple2(NamedTuple):
        a: int
        b: int

    class MyNamedTuple3(NamedTuple):
        a: int
        b: int

    class MyNamedTuple4(NamedTuple):
        a: int
        b: int

    class MyNamedTuple5(NamedTuple):
        a: int
        b: int

    class MyNamedTuple6(NamedTuple):
        a: int
        b: int


# Generated at 2022-06-17 19:07:50.824406
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class Foo(NamedTuple):
        a: int
        b: int

    class Bar(NamedTuple):
        a: int
        b: int

    class Baz(NamedTuple):
        a: int
        b: int

    class Qux(NamedTuple):
        a: int
        b: int

    class Quux(NamedTuple):
        a: int
        b: int

    class Corge(NamedTuple):
        a: int
        b: int

    class Grault(NamedTuple):
        a: int
        b: int


# Generated at 2022-06-17 19:08:01.262424
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test with a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    # Test with a OrderedDict
    odic = OrderedDict(a=1, b=2)
    assert to_namedtuple(odic) == odic

    # Test with a

# Generated at 2022-06-17 19:08:11.161008
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(1, 2, 3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c d')(1, 2, 3, 4)

   

# Generated at 2022-06-17 19:08:21.019793
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd_': 4}

# Generated at 2022-06-17 19:08:29.053591
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import types

    # Test with a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test with a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == to_namedtuple(dic)

    # Test with an OrderedDict
    odic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(odic) == to_

# Generated at 2022-06-17 19:08:39.104863
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier

    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple(OrderedDict()) == NamedTuple()
    assert to_namedtuple(SimpleNamespace()) == NamedTuple()

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)

# Generated at 2022-06-17 19:08:49.955181
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, '_c': 3, 'd_': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, '_c': 3, 'd_': 4, 'e': 5}

# Generated at 2022-06-17 19:08:59.979731
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out.c, 3)


# Generated at 2022-06-17 19:09:11.363540
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    import pytest
    from flutils.validators import validate_identifier

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    class TestNamedTuple2(NamedTuple):
        a: int
        b: int

    class TestNamedTuple3(NamedTuple):
        a: int
        b: int

    class TestNamedTuple4(NamedTuple):
        a: int
        b: int

    class TestNamedTuple5(NamedTuple):
        a: int
        b: int


# Generated at 2022-06-17 19:09:22.029911
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:09:31.681367
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:09:41.973712
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_raises
    from flutils.testing import assert_raises_regex
    from flutils.testing import assert_raises_type
    from flutils.testing import assert_raises_value
    from flutils.testing import assert_raises_with_msg
    from flutils.testing import assert_raises_with_msg_regex
    from flutils.testing import assert_raises_with_msg_type
    from flutils.testing import assert_raises_with_msg_value
    from flutils.testing import assert_warns
    from flutils.testing import assert_warns_regex


# Generated at 2022-06-17 19:09:55.374346
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == My

# Generated at 2022-06-17 19:10:06.654575
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) != {'b': 2, 'a': 1}

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) != {'b': 2, 'a': 1, 'c': 3}

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple

# Generated at 2022-06-17 19:10:17.517334
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    def _test_to_namedtuple(
            obj: Any,
            expected: Any,
            _started: bool = False
    ) -> None:
        out = to_namedtuple(obj)
        assert out == expected

    def _test_to_namedtuple_raises(
            obj: Any,
            _started: bool = False
    ) -> None:
        with pytest.raises(TypeError):
            to_namedtuple(obj)


# Generated at 2022-06-17 19:10:27.951586
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Test an OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])


# Generated at 2022-06-17 19:10:38.560813
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-17 19:10:48.870608
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # Test with a list
    lst = [
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
        {'a': 5, 'b': 6},
    ]
    out = to_namedtuple(lst)
    assert isinstance(out, list)
    assert len(out) == 3
    assert isinstance(out[0], NamedTuple)
    assert out[0].a == 1
    assert out[0].b == 2
    assert isinstance(out[1], NamedTuple)
    assert out[1].a == 3
    assert out[1].b == 4

# Generated at 2022-06-17 19:11:03.274448
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

# Generated at 2022-06-17 19:11:14.941307
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:11:23.233785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    class TestNamedTuple2(NamedTuple):
        c: int
        d: int

    class TestNamedTuple3(NamedTuple):
        e: int
        f: int

    class TestNamedTuple4(NamedTuple):
        g: int
        h: int

    class TestNamedTuple5(NamedTuple):
        i: int
        j: int

    class TestNamedTuple6(NamedTuple):
        k: int
        l: int


# Generated at 2022-06-17 19:11:34.227901
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):

        def test_to_namedtuple(self):
            from collections import OrderedDict
            from types import SimpleNamespace
            from flutils.namedtupleutils import to_namedtuple

            dic = {'a': 1, 'b': 2}
            self.assertEqual(to_namedtuple(dic), namedtuple('NamedTuple', 'a b')(a=1, b=2))

            dic = OrderedDict([('a', 1), ('b', 2)])
            self.assertEqual(to_namedtuple(dic), namedtuple('NamedTuple', 'a b')(a=1, b=2))


# Generated at 2022-06-17 19:11:41.876581
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_raises_message
    from flutils.testing import assert_raises_type
    from flutils.testing import assert_raises_value
    from flutils.testing import assert_raises_regex
    from flutils.testing import assert_raises_regexp
    from flutils.testing import assert_raises_re
    from flutils.testing import assert_raises_r
    from flutils.testing import assert_raises_exc
    from flutils.testing import assert_raises_exception
    from flutils.testing import assert_raises_e
    from flutils.testing import assert_

# Generated at 2022-06-17 19:11:55.479101
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: str

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamed

# Generated at 2022-06-17 19:12:04.817118
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:12:14.460791
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic

# Generated at 2022-06-17 19:12:24.618483
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3


# Generated at 2022-06-17 19:12:33.182004
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_raises_message,
        assert_raises_type,
    )

    # noinspection PyUnusedLocal

# Generated at 2022-06-17 19:12:47.687970
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    # Test with a list
    test_list = [
        {'a': 1, 'b': 2},
        {'c': 3, 'd': 4},
    ]
    out = to_namedtuple(test_list)
    assert isinstance(out, list)
    assert isinstance(out[0], NamedTuple)
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[1].c == 3
    assert out[1].d == 4

    # Test with a tuple

# Generated at 2022-06-17 19:12:54.283825
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert n

# Generated at 2022-06-17 19:12:59.924553
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:13:08.353902
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    d

# Generated at 2022-06-17 19:13:18.450448
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-17 19:13:28.466330
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out.a

# Generated at 2022-06-17 19:13:36.354571
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testutils import assert_raises_message

    # Test with a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert out == lst

    # Test with a tuple
    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert out == tup

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    # Test with an OrderedD

# Generated at 2022-06-17 19:13:45.132572
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple([1, 2, {'a': 1, 'b': 2}]) == [1, 2, NamedTuple(a=1, b=2)]
    assert to_namedtuple([1, 2, {'a': 1, 'b': 2, '_c': 3}]) == [1, 2, NamedTuple(a=1, b=2)]

# Generated at 2022-06-17 19:13:56.825107
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:14:06.979575
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:14:26.147530
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'b': 2, 'a': 1}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1

# Generated at 2022-06-17 19:14:36.818510
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    assert_equal(to_namedtuple([]), [])
    assert_equal(to_namedtuple(()), ())
    assert_equal(to_namedtuple({}), NamedTuple())
    assert_equal(to_namedtuple(OrderedDict()), NamedTuple())
    assert_equal(to_namedtuple(SimpleNamespace()), NamedTuple())

    assert_equal(to_namedtuple([1, 2, 3]), [1, 2, 3])
    assert_equal(to_namedtuple((1, 2, 3)), (1, 2, 3))


# Generated at 2022-06-17 19:14:45.024354
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)


# Generated at 2022-06-17 19:14:54.505173
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}

# Generated at 2022-06-17 19:15:01.976819
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert n

# Generated at 2022-06-17 19:15:12.016586
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not,
        assert_is,
        assert_raises,
    )

    # Test with a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_is_instance(out, list)
    assert_equal(out, lst)
    assert_is_not(out, lst)

    # Test with a tuple
    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert_is_

# Generated at 2022-06-17 19:15:23.244018
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}


# Generated at 2022-06-17 19:15:32.738603
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_raises
    from flutils.testing import assert_raises_regex
    from flutils.testing import assert_raises_type
    from flutils.testing import assert_raises_value
    from flutils.testing import assert_raises_with_msg
    from flutils.testing import assert_raises_with_msg_regex
    from flutils.testing import assert_raises_with_msg_type
    from flutils.testing import assert_raises_with_msg_value
    from flutils.testing import assert_raises_with_msg_regex_type

# Generated at 2022-06-17 19:15:39.694679
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.tests.helpers import (
        assert_equal,
        assert_is_instance,
        assert_is_not,
        assert_is,
        assert_raises,
    )

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_is_instance(out, namedtuple)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
   

# Generated at 2022-06-17 19:15:50.012601
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert to_named

# Generated at 2022-06-17 19:16:16.714709
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    import pytest

    class Test(NamedTuple):
        a: int
        b: int

    class Test2(NamedTuple):
        a: int
        b: int

    class Test3(NamedTuple):
        a: int
        b: int

    class Test4(NamedTuple):
        a: int
        b: int

    class Test5(NamedTuple):
        a: int
        b: int

    class Test6(NamedTuple):
        a: int
        b: int

    class Test7(NamedTuple):
        a: int
        b: int


# Generated at 2022-06-17 19:16:23.792066
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import pytest

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:16:33.937187
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == dic

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == dic

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    assert to_namedtuple(dic) == dic


# Generated at 2022-06-17 19:16:44.186218
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out._c, 3)


# Generated at 2022-06-17 19:16:56.607672
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert isinstance(out, list)
    assert out == lst

    # Test with a tuple
    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert isinstance(out, tuple)
    assert out == tup

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, tuple)
    assert out.a == 1
   

# Generated at 2022-06-17 19:17:06.273774
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:17:15.703722
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-17 19:17:24.338296
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)
