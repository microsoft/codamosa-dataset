

# Generated at 2022-06-17 19:07:27.397268
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier

    # Test with a dictionary
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Test with an OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Test with a SimpleNamespace
    obj = SimpleNamespace(a=1, b=2)
    assert to_

# Generated at 2022-06-17 19:07:36.232413
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace

    # Test namedtuple
    nt = namedtuple('NamedTuple', 'a b c')
    nt = nt(a=1, b=2, c=3)
    assert to_namedtuple(nt) == nt

    # Test list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test dict
    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:07:45.451760
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3


# Generated at 2022-06-17 19:07:56.625198
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))
    assert to_named

# Generated at 2022-06-17 19:08:04.563251
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test for dict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

    # Test for OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

    # Test for SimpleNamespace
    dic = Simple

# Generated at 2022-06-17 19:08:05.728033
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-17 19:08:16.399808
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}


# Generated at 2022-06-17 19:08:27.261108
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == My

# Generated at 2022-06-17 19:08:36.968911
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}

# Generated at 2022-06-17 19:08:48.697636
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not,
        assert_is,
        assert_raises,
        assert_true,
    )

    # Test with a list
    lst = [1, 2, 3, 4]
    out = to_namedtuple(lst)
    assert_is_instance(out, list)
    assert_is_not(out, lst)
    assert_equal(out, lst)

    lst = [1, 2, 3, 4, {'a': 1, 'b': 2}]

# Generated at 2022-06-17 19:09:02.198949
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.namedtupleutils import to_namedtuple

    # Test a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert out == obj

    # Test a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    assert out == obj

    # Test a dict
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    # Test an OrderedD

# Generated at 2022-06-17 19:09:11.400509
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        AssertRaisesContext,
        assert_raises_message,
    )
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        AssertRaisesContext,
        assert_raises_message,
    )

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2


# Generated at 2022-06-17 19:09:22.113891
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import _to_namedtuple

    # Test for dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    # Test for OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    # Test for SimpleNamespace
    obj = SimpleNamespace(a=1, b=2)
    out

# Generated at 2022-06-17 19:09:31.732651
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    # Test the basic types
    assert_equal(to_namedtuple(1), 1)
    assert_equal(to_namedtuple(1.1), 1.1)
    assert_equal(to_namedtuple(True), True)
    assert_equal(to_namedtuple(False), False)
    assert_equal(to_namedtuple(None), None)
    assert_equal(to_namedtuple(''), '')
    assert_equal(to_namedtuple('a'), 'a')

# Generated at 2022-06-17 19:09:42.020237
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}


# Generated at 2022-06-17 19:09:55.400907
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': 4}

# Generated at 2022-06-17 19:10:06.656551
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:10:17.587704
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert not hasattr(out, '_c')

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': {'e': 4, 'f': 5}}
    out = to_namedtuple

# Generated at 2022-06-17 19:10:21.982850
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    test_dict = {'a': 1, 'b': 2}
    test_odict = OrderedDict(test_dict)
    test_list = [1, 2]
    test_tuple = (1, 2)
    test_namedtuple = TestNamedTuple(a=1, b=2)
    test_namespace = SimpleNamespace(a=1, b=2)

    assert to_namedtuple(test_dict) == TestNamedTuple(a=1, b=2)

# Generated at 2022-06-17 19:10:29.716642
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple(OrderedDict()) == NamedTuple()
    assert to_namedtuple(SimpleNamespace()) == NamedTuple()

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)

# Generated at 2022-06-17 19:10:37.743422
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic

# Generated at 2022-06-17 19:10:48.450599
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    import pytest

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    with pytest.raises(AttributeError):
        out.c

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': 4}
    out = to_namedtuple(dic)
    assert out.a == 1


# Generated at 2022-06-17 19:10:58.273351
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:11:02.716278
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_isinstance,
        assert_not_equal,
        assert_raises,
    )

    # Test a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_equal(out, lst)
    assert_not_equal(id(out), id(lst))
    assert_isinstance(out, list)

    # Test a tuple
    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert_equal(out, tup)


# Generated at 2022-06-17 19:11:14.465125
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:11:22.686985
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')


# Generated at 2022-06-17 19:11:32.142759
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import List, NamedTuple, Tuple

    # Test _to_namedtuple
    # Test _to_namedtuple with a list
    assert _to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert _to_namedtuple([1, 2, 3], _started=True) == [1, 2, 3]
    assert _to_namedtuple([1, 2, 3], _started=False) == [1, 2, 3]
    assert _to_namedtuple([1, 2, 3], _started=True) == [1, 2, 3]

# Generated at 2022-06-17 19:11:42.532479
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

# Generated at 2022-06-17 19:11:55.730467
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == Test

# Generated at 2022-06-17 19:12:06.142985
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from types import SimpleNamespace
    import pytest

    def _test_to_namedtuple(obj: Any, expected: Any) -> None:
        out = to_namedtuple(obj)
        assert out == expected

    def test_to_namedtuple_dict() -> None:
        dic = {'a': 1, 'b': 2}
        expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
        _test_to_namedtuple(dic, expected)


# Generated at 2022-06-17 19:12:15.497906
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}

# Generated at 2022-06-17 19:12:25.317032
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=NamedTuple(d=3, e=4))
    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [1, 2, 3]}

# Generated at 2022-06-17 19:12:33.497159
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:12:42.381814
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    # Test with a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert out == obj

    # Test with a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    assert out == obj

    # Test with a dict
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    # Test with

# Generated at 2022-06-17 19:12:53.610216
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.tests.helpers import (
        assert_equal,
        assert_not_equal,
        assert_raises,
        assert_true,
    )

    # noinspection PyUnusedLocal
    def _assert_equal(
            obj: Any,
            expected: Any,
            msg: str = ''
    ) -> None:
        assert_equal(
            to_namedtuple(obj),
            expected,
            msg=msg
        )

    # noinspection PyUnusedLocal

# Generated at 2022-06-17 19:13:04.768218
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}

# Generated at 2022-06-17 19:13:15.667777
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2, c=3))

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:13:24.458472
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # Test with a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test with a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Test with an OrderedDict
    odic = OrderedDict([('a', 1), ('b', 2)])

# Generated at 2022-06-17 19:13:33.722448
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class _TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == _TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == _TestNamedTuple(a=1, b=2)

    dic = {'b': 2, 'a': 1}

# Generated at 2022-06-17 19:13:43.986245
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out.c, 3)


# Generated at 2022-06-17 19:13:57.806005
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == dic

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == dic

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == dic


# Generated at 2022-06-17 19:14:08.778400
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:14:16.740750
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:14:26.901127
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:14:37.376658
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    class MyNamedTuple2(NamedTuple):
        a: int
        b: int
        c: int

    class MyNamedTuple3(NamedTuple):
        a: int
        b: int
        c: int
        d: int

    class MyNamedTuple4(NamedTuple):
        a: int
        b: int
        c: int
        d: int
        e: int

    class MyNamedTuple5(NamedTuple):
        a: int
        b: int
        c: int

# Generated at 2022-06-17 19:14:47.281506
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    assert_equal(to_namedtuple(dic), namedtuple('NamedTuple', 'a b')(a=1, b=2))

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert_equal(to_namedtuple(dic), namedtuple('NamedTuple', 'a b')(a=1, b=2))

    dic = {'a': 1, 'b': 2, '_c': 3}

# Generated at 2022-06-17 19:14:57.049624
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    # Test a list
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple([1, 'a', 2, 'b', 3, 'c']) == [1, 'a', 2, 'b', 3, 'c']
    assert to_namedtuple([1, 'a', 2, 'b', 3, 'c']) == (1, 'a', 2, 'b', 3, 'c')

# Generated at 2022-06-17 19:15:04.393896
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)
    assert_equal(nt.c, 3)


# Generated at 2022-06-17 19:15:14.461040
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a list
    obj = [
        {'a': 1, 'b': 2},
        {'c': 3, 'd': 4},
    ]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert len(out) == 2
    assert isinstance(out[0], NamedTuple)
    assert isinstance(out[1], NamedTuple)
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[1].c == 3
    assert out[1].d == 4

    # Test a tuple

# Generated at 2022-06-17 19:15:24.906974
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')


# Generated at 2022-06-17 19:15:44.008656
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == My

# Generated at 2022-06-17 19:15:53.238179
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == dic

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == dic

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == d

# Generated at 2022-06-17 19:16:01.698619
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    import pytest

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    def test_dict():
        dic = {'a': 1, 'b': 2}
        out = to_namedtuple(dic)
        assert out.a == 1
        assert out.b == 2

    def test_ordered_dict():
        dic = OrderedDict([('a', 1), ('b', 2)])
        out = to_namedtuple(dic)
        assert out.a == 1
        assert out.b == 2


# Generated at 2022-06-17 19:16:11.414998
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

# Generated at 2022-06-17 19:16:19.662718
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:16:31.245647
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out._c, 3)


# Generated at 2022-06-17 19:16:42.598333
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    import pytest

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    # noinspection PyTypeChecker

# Generated at 2022-06-17 19:16:55.912252
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    import pytest

    # Test with a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert out == obj

    # Test with a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert out == obj

    # Test with a dict
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert out == obj

    # Test with an OrderedDict
    obj = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(obj)
    assert out == obj

   

# Generated at 2022-06-17 19:17:02.324577
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # noinspection PyTypeChecker
    dic: dict = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    # noinspection PyTypeChecker
    dic: dict = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    try:
        out.c
    except AttributeError:
        pass

# Generated at 2022-06-17 19:17:12.830249
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.tests.helpers import (
        assert_equal,
        assert_isinstance,
        assert_not_equal,
        assert_raises,
        assert_true,
    )

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_isinstance(out, namedtuple)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert_is