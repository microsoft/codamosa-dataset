

# Generated at 2022-06-17 19:07:26.770398
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test for dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedt

# Generated at 2022-06-17 19:07:36.101322
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test a dictionary
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    # Test a dictionary with a list
    dic = {'a': 1, 'b': [1, 2, 3]}
    assert to_namedtuple(dic) == dic

    # Test a dictionary

# Generated at 2022-06-17 19:07:45.337057
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert n

# Generated at 2022-06-17 19:07:52.901757
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == My

# Generated at 2022-06-17 19:08:02.725226
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test a dictionary
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    # Test a dictionary with a list
    dic = {'a': 1, 'b': [1, 2, 3]}
    assert to_namedtuple(dic) == dic

    # Test a dictionary

# Generated at 2022-06-17 19:08:14.339718
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier


# Generated at 2022-06-17 19:08:22.128013
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace
    from typing import NamedTuple, Tuple, Union

    _AllowedTypes = Union[
        Mapping,
        NamedTuple,
        SimpleNamespace,
        Tuple,
    ]

    def _test_to_namedtuple(
            obj: _AllowedTypes,
            expected: _AllowedTypes
    ) -> None:
        out = to_namedtuple(obj)
        assert out == expected

    def _test_to_namedtuple_raises(
            obj: _AllowedTypes,
            expected: _AllowedTypes
    ) -> None:
        with pytest.raises(TypeError):
            to

# Generated at 2022-06-17 19:08:31.628480
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        BaseTestCase,
        run_tests,
    )

    class TestToNamedTuple(BaseTestCase):

        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)
            self.assertEqual(out, (1, 2))
            self.assertEqual(out, (1, 2))
            self.assertEqual(out, (1, 2))

# Generated at 2022-06-17 19:08:40.055676
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: str
        c: float

    test_dict = {'a': 1, 'b': '2', 'c': 3.0}
    test_list = [1, '2', 3.0]
    test_tuple = (1, '2', 3.0)
    test_ordered_dict = OrderedDict([('a', 1), ('b', '2'), ('c', 3.0)])
    test_simple_namespace = SimpleNamespace(a=1, b='2', c=3.0)
    test_named_tuple = TestNamedT

# Generated at 2022-06-17 19:08:45.949302
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert n

# Generated at 2022-06-17 19:09:00.830577
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_raises_message

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
   

# Generated at 2022-06-17 19:09:06.390873
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not,
        assert_is,
        assert_raises,
    )

    # Test with a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_is_instance(out, list)
    assert_is_not(out, lst)
    assert_equal(out, lst)

    # Test with a tuple
    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert_is_

# Generated at 2022-06-17 19:09:16.206415
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, 'c_': 3}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

   

# Generated at 2022-06-17 19:09:27.299960
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    # Test for dict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)
    assert_equal(nt, (1, 2))

    # Test for OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    nt = to_namedtuple(dic)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)
   

# Generated at 2022-06-17 19:09:33.929850
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import pytest

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', 'a b'))
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', 'a b'))
    assert nt.a == 1
    assert nt.b == 2

# Generated at 2022-06-17 19:09:43.693115
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple(None) is None
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple(True) is True
    assert to_namedtuple(False) is False
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(b'a') == b'a'
    assert to_namedtuple(bytearray(b'a')) == bytearray(b'a')
    assert to_namedtuple(frozenset([1, 2])) == frozenset

# Generated at 2022-06-17 19:09:55.782279
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(1, 2, 3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c d')(1, 2, 3, 4)


# Generated at 2022-06-17 19:10:06.699785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    assert to_namedtuple([]) == []
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple([1, 2, 3, 'a', 'b', 'c']) == [1, 2, 3, 'a', 'b', 'c']
    assert to_namedtuple([1, 2, 3, 'a', 'b', 'c', [1, 2, 3]]) == \
        [1, 2, 3, 'a', 'b', 'c', [1, 2, 3]]

# Generated at 2022-06-17 19:10:17.557441
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # noinspection PyTypeChecker
    dic: dict = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', 'a b'))
    assert nt.a == 1
    assert nt.b == 2

    # noinspection PyTypeChecker
    dic: dict = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', 'a b'))
   

# Generated at 2022-06-17 19:10:27.989559
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}
    nt = to_namedtuple(dic)
    assert nt.a == 1
   

# Generated at 2022-06-17 19:10:42.560396
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic

# Generated at 2022-06-17 19:10:51.711753
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from collections import OrderedDict
    from types import SimpleNamespace

    class TestToNamedTuple(unittest.TestCase):
        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)
            self.assertEqual(out, (1, 2))
            self.assertEqual(out, (out.a, out.b))

            dic = {'a': 1, 'b': 2, '_c': 3}
            out = to_namedtuple(dic)
            self.assertEqual(out.a, 1)
            self.assertEqual

# Generated at 2022-06-17 19:11:03.156826
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier

    def _test_to_namedtuple(obj, expected):
        assert to_namedtuple(obj) == expected

    # Test dict
    dic = {'a': 1, 'b': 2}
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    _test_to_namedtuple(dic, expected)

    # Test OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    _test_to_

# Generated at 2022-06-17 19:11:14.827216
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.namedtupleutils import to_namedtuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:11:26.233242
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from collections import namedtuple
    from flutils.validators import validate_identifier

    # Test a dictionary
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple)
    assert out.a == 1
    assert out.b == 2

    # Test a dictionary with a key that is not a valid identifier
    dic = {'a': 1, 'b': 2, 'c-d': 3}
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple)
    assert out.a == 1
    assert out.b == 2

# Generated at 2022-06-17 19:11:36.919917
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}

# Generated at 2022-06-17 19:11:43.234976
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': 4}

# Generated at 2022-06-17 19:11:53.088624
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3


# Generated at 2022-06-17 19:12:03.956080
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier

    class TestNamedTuple(NamedTuple):
        a: int
        b: int
        c: int

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)

    dic = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)


# Generated at 2022-06-17 19:12:13.999350
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:12:31.661760
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    assert to_namedtuple(dic) == My

# Generated at 2022-06-17 19:12:41.126890
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == Test

# Generated at 2022-06-17 19:12:52.654853
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # Test with a dictionary
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    # Test with an OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    # Test with a SimpleNamespace
    obj = SimpleNamespace(a=1, b=2)
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

   

# Generated at 2022-06-17 19:13:04.102432
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import pytest

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    out = to_namedtuple(dic)

# Generated at 2022-06-17 19:13:11.885585
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testutils import (
        assert_equal,
        assert_isinstance,
        assert_raises,
    )

    # Test for list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_equal(out, lst)
    assert_isinstance(out, list)
    assert_equal(out, lst)
    assert_equal(out, [1, 2, 3])
    assert_equal(out, [1, 2, 3])

    # Test for tuple
    tup = (1, 2, 3)
    out = to_namedtuple

# Generated at 2022-06-17 19:13:20.300424
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}


# Generated at 2022-06-17 19:13:30.239623
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic

# Generated at 2022-06-17 19:13:41.891152
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace
    from typing import (
        Any,
        List,
        NamedTuple,
        Tuple,
        Union,
    )
    from flutils.validators import validate_identifier

    _AllowedTypes = Union[
        List,
        Mapping,
        NamedTuple,
        SimpleNamespace,
        Tuple,
    ]


# Generated at 2022-06-17 19:13:51.574898
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:14:00.075401
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert_equal(nt, NamedTuple(a=1, b=2))
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert_equal(nt, NamedTuple(a=1, b=2))
    assert_equal(nt.a, 1)


# Generated at 2022-06-17 19:14:26.004999
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    import pytest

    # Test dict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    # Test OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    # Test SimpleNamespace
    sn = SimpleNamespace(a=1, b=2)
    nt = to_namedtuple(sn)
    assert nt.a == 1

# Generated at 2022-06-17 19:14:36.720244
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)


# Generated at 2022-06-17 19:14:47.248429
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_is_instance,
        assert_is_none,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_raises,
        assert_raises_regex,
        assert_true,
        assert_false,
    )
    from flutils.miscutils import (
        get_func_name,
        get_func_lineno,
    )
    from flutils.namedtupleutils import (
        to_namedtuple,
    )

# Generated at 2022-06-17 19:14:57.024176
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd_': 4}

# Generated at 2022-06-17 19:15:03.730227
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_raises_message

    # Test for a list
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) != to_namedtuple(OrderedDict(dic))
    assert to_namedtuple(dic) != to_namedtuple(SimpleNamespace(**dic))

# Generated at 2022-06-17 19:15:12.780224
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from types import SimpleNamespace
    import pytest
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    class TestNamedTuple2(NamedTuple):
        a: int
        b: int
        c: int

    class TestNamedTuple3(NamedTuple):
        a: int
        b: int
        c: int
        d: int

    class TestNamedTuple4(NamedTuple):
        a: int
        b: int
        c: int
        d: int
        e: int


# Generated at 2022-06-17 19:15:23.864243
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import pytest

    # Test that a list is returned when given a list
    lst = [1, 2, 3]
    assert isinstance(to_namedtuple(lst), list)

    # Test that a tuple is returned when given a tuple
    tup = (1, 2, 3)
    assert isinstance(to_namedtuple(tup), tuple)

    # Test that a NamedTuple is returned when given a dict
    dic = {'a': 1, 'b': 2}
    assert isinstance(to_namedtuple(dic), tuple)

    # Test that a NamedTuple is returned when given an OrderedD

# Generated at 2022-06-17 19:15:33.035210
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from typing import NamedTuple
    from unittest import TestCase

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    class TestNamedTuple2(NamedTuple):
        a: int
        b: int

    class TestNamedTuple3(NamedTuple):
        a: int
        b: int

    class TestNamedTuple4(NamedTuple):
        a: int
        b: int

    class TestNamedTuple5(NamedTuple):
        a: int
        b: int

    class TestNamedTuple6(NamedTuple):
        a: int
        b: int



# Generated at 2022-06-17 19:15:43.794875
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    lst = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    out = to_namedtuple(lst)
    assert isinstance(out, list)
    assert isinstance(out[0], NamedTuple)
    assert isinstance(out[1], NamedTuple)
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[1].a == 3
    assert out[1].b == 4

    # Test with a tuple

# Generated at 2022-06-17 19:15:57.254960
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.tests.helpers import (
        assert_equal,
        assert_isinstance,
        assert_not_equal,
        assert_raises,
        assert_true,
    )

    # Test with a list
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_isinstance(out, namedtuple)
    assert_true(hasattr(out, 'a'))
    assert_true(hasattr(out, 'b'))
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

   

# Generated at 2022-06-17 19:16:35.131277
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest
    from collections import OrderedDict
    from types import SimpleNamespace

    # Test for a dictionary
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out == (1, 2)

    # Test for a dictionary with an invalid key

# Generated at 2022-06-17 19:16:42.305031
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    assert to_namedtuple(None) is None
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple('abc') == 'abc'
    assert to_namedtuple(True) is True
    assert to_namedtuple(False) is False
    assert to_namedtuple(b'abc') == b'abc'
    assert to_namedtuple(bytearray(b'abc')) == bytearray(b'abc')
    assert to_namedtuple(memoryview(b'abc')) == memoryview(b'abc')
    assert to_namedtuple(set())

# Generated at 2022-06-17 19:16:55.740904
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:17:05.708172
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from typing import NamedTuple
    from unittest import TestCase

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    class TestNamedTuple2(NamedTuple):
        a: int
        b: int

    class TestNamedTuple3(NamedTuple):
        a: int
        b: int

    class TestNamedTuple4(NamedTuple):
        a: int
        b: int

    class TestNamedTuple5(NamedTuple):
        a: int
        b: int

    class TestNamedTuple6(NamedTuple):
        a: int
        b: int



# Generated at 2022-06-17 19:17:15.282522
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_is_instance,
        assert_raises,
        assert_raises_regex,
    )
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testingutils import (
        assert_is_instance,
        assert_raises,
        assert_raises_regex,
    )
    from flutils.validators import validate_identifier

    # Test with a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_is_instance(out, list)