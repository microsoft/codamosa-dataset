

# Generated at 2022-06-17 19:07:26.732582
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace
    from typing import List, Tuple, Union
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # noinspection PyUnusedLocal

# Generated at 2022-06-17 19:07:36.071693
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_isinstance,
        assert_not_equal,
        assert_raises,
        assert_true,
    )

    # Test a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_isinstance(out, list)
    assert_equal(out, lst)
    assert_not_equal(out, lst)
    assert_true(out is not lst)

    # Test a tuple
    tup = (1, 2, 3)

# Generated at 2022-06-17 19:07:45.297956
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == My

# Generated at 2022-06-17 19:07:52.869809
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)
    with pytest.raises(AttributeError):
        nt._c


# Generated at 2022-06-17 19:08:02.693362
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class Test(NamedTuple):
        a: int
        b: int

    class Test2(NamedTuple):
        a: int
        b: int

    class Test3(NamedTuple):
        a: int
        b: int

    class Test4(NamedTuple):
        a: int
        b: int

    class Test5(NamedTuple):
        a: int
        b: int

    class Test6(NamedTuple):
        a: int
        b: int

    class Test7(NamedTuple):
        a: int
        b: int


# Generated at 2022-06-17 19:08:14.551565
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    nt = to_namedtuple(dic)
    assert n

# Generated at 2022-06-17 19:08:23.882916
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple(None) == ()
    assert to_namedtuple('') == ''
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple(True) is True
    assert to_namedtuple(False) is False
    assert to_namedtuple(b'a') == b'a'
    assert to_namedtuple(bytearray(b'a')) == bytearray(b'a')
    assert to_namedtuple(range(1)) == range(1)
    assert to_namedt

# Generated at 2022-06-17 19:08:35.222333
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:08:42.292468
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.tests.helpers import (
        assert_equal,
        assert_isinstance,
        assert_raises,
        assert_true,
    )

    # Test with a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert_isinstance(out, list)
    assert_equal(out, obj)

    # Test with a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert_isinstance(out, tuple)
    assert_equal(out, obj)

    # Test with a dict

# Generated at 2022-06-17 19:08:55.241624
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)

# Generated at 2022-06-17 19:09:09.487325
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')


# Generated at 2022-06-17 19:09:19.738317
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(SimpleNamespace(a=1, b=2))
    assert to_namedtuple([1, 2, 3]) == to_namedtuple((1, 2, 3))
    assert to_namedtuple([1, 2, 3]) == to_namedtuple([1, 2, 3])
    assert to_namedtuple([1, 2, 3]) == to_namedtuple((1, 2, 3))

# Generated at 2022-06-17 19:09:30.769239
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out.c, 3)


# Generated at 2022-06-17 19:09:41.247634
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test dict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    # Test OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    # Test SimpleNamespace
    sn = SimpleNamespace(a=1, b=2)
    nt = to_namedtuple(sn)
    assert n

# Generated at 2022-06-17 19:09:51.647082
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple(None) is None
    assert to_namedtuple(True) is True
    assert to_namedtuple(False) is False
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple(1j) == 1j
    assert to_namedtuple(b'bytes') == b'bytes'
    assert to_namedtuple(bytearray(b'bytearray')) == bytearray(b'bytearray')

# Generated at 2022-06-17 19:10:00.627809
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == namedtuple('NamedTuple', 'a b c d')(a=1, b=2, c=3, d=4)

# Generated at 2022-06-17 19:10:09.729056
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'b a')(b=2, a=1)
    assert to_namedtuple(dic) != namedtuple('NamedTuple', 'a b')(a=2, b=1)
    assert to_namedtuple(dic) != namedtuple('NamedTuple', 'b a')(b=1, a=2)
    assert to_namedtuple(dic) != namedtuple('NamedTuple', 'a b')(a=1, b=1)

# Generated at 2022-06-17 19:10:18.820284
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:10:28.450782
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == My

# Generated at 2022-06-17 19:10:38.956264
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    # Test for dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    # Test for OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    # Test for SimpleNamespace

# Generated at 2022-06-17 19:10:51.445854
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace
    from flutils.validators import validate_identifier

    # Test with a list
    lst = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    out = to_namedtuple(lst)
    assert isinstance(out, list)
    assert isinstance(out[0], namedtuple)
    assert isinstance(out[1], namedtuple)
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[1].c == 3
    assert out[1].d == 4

    # Test with a tuple

# Generated at 2022-06-17 19:11:03.157376
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    class TestNamedTuple(NamedTuple):
        a: int
        b: int
        c: int

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert_equal(out, TestNamedTuple(a=1, b=2, c=3))

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}
    out = to_namedtuple(dic)

# Generated at 2022-06-17 19:11:14.828063
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c_': 3}

# Generated at 2022-06-17 19:11:23.148313
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    import pytest

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    class TestNamedTuple2(NamedTuple):
        a: int
        b: int

    class TestNamedTuple3(NamedTuple):
        a: int
        b: int

    class TestNamedTuple4(NamedTuple):
        a: int
        b: int

    class TestNamedTuple5(NamedTuple):
        a: int
        b: int

    class TestNamedTuple6(NamedTuple):
        a: int
        b: int


# Generated at 2022-06-17 19:11:34.142766
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a dictionary
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

    # Test with a dictionary with a key that is not a valid identifier
    dic = {'a': 1, 'b': 2, 'c-d': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

# Generated at 2022-06-17 19:11:41.827906
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class Test(NamedTuple):
        a: int
        b: int

    class Test2(NamedTuple):
        a: int
        b: int

    class Test3(NamedTuple):
        a: int
        b: int

    class Test4(NamedTuple):
        a: int
        b: int

    class Test5(NamedTuple):
        a: int
        b: int

    class Test6(NamedTuple):
        a: int
        b: int

    class Test7(NamedTuple):
        a: int
        b: int


# Generated at 2022-06-17 19:11:51.957202
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from typing import NamedTuple
    from unittest import TestCase

    class Test(NamedTuple):
        a: int
        b: int

    class Test2(NamedTuple):
        a: int
        b: int

    class Test3(NamedTuple):
        a: int
        b: int

    class Test4(NamedTuple):
        a: int
        b: int

    class Test5(NamedTuple):
        a: int
        b: int

    class Test6(NamedTuple):
        a: int
        b: int


# Generated at 2022-06-17 19:12:02.157927
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:12:11.826821
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:12:22.730571
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert n

# Generated at 2022-06-17 19:12:34.041079
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    od = OrderedDict()
    od['a'] = 1
    od['b'] = 2
    nt = to_namedtuple(od)
    assert nt.a == 1
    assert nt.b == 2

    sn = SimpleNamespace()
    sn.a = 1
    sn.b = 2
    nt = to_namedtuple(sn)
    assert nt.a == 1
    assert nt.b == 2


# Generated at 2022-06-17 19:12:43.165976
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b d')(a=1, b=2, d=4)


# Generated at 2022-06-17 19:12:54.642091
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_raises

    # Test a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert out == obj

    # Test a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert out == obj

    # Test a dict
    obj = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(obj)
    assert out == obj

    # Test a dict with a list

# Generated at 2022-06-17 19:13:05.412478
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == namedtuple('NamedTuple', 'a b c d')(a=1, b=2, c=3, d=4)

# Generated at 2022-06-17 19:13:16.581500
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd_': 4}

# Generated at 2022-06-17 19:13:25.353133
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:13:34.952915
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal
    from flutils.testing import assert_raises

    # Test for a list
    lst = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    out = to_namedtuple(lst)
    assert_equal(out[0].a, 1)
    assert_equal(out[0].b, 2)
    assert_equal(out[1].c, 3)
    assert_equal(out[1].d, 4)

    # Test for a tuple

# Generated at 2022-06-17 19:13:44.618134
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == namedtuple('NamedTuple', 'a b c d')(a=1, b=2, c=3, d=4)

# Generated at 2022-06-17 19:13:56.701089
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

# Generated at 2022-06-17 19:14:04.138829
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:14:26.989982
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]

# Generated at 2022-06-17 19:14:37.436856
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int
        c: int

    class TestNamedTuple2(NamedTuple):
        a: int
        b: int
        c: int

    class TestNamedTuple3(NamedTuple):
        a: int
        b: int
        c: int

    class TestNamedTuple4(NamedTuple):
        a: int
        b: int
        c: int

    class TestNamedTuple5(NamedTuple):
        a: int
        b: int
        c: int


# Generated at 2022-06-17 19:14:47.345604
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    # noinspection PyPep8Naming
    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
   

# Generated at 2022-06-17 19:14:56.894513
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out, (1, 2))

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out, (1, 2))


# Generated at 2022-06-17 19:15:04.304462
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Test OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Test SimpleNamespace
    obj = SimpleNamespace(a=1, b=2)
    assert to_namedtuple(obj)

# Generated at 2022-06-17 19:15:13.107363
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    # noinspection PyPep8Naming
    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'b': 2, 'a': 1}
    assert to_namedtuple(dic) == TestNamed

# Generated at 2022-06-17 19:15:23.929903
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_is_instance,
        assert_raises,
    )

    # Test for a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_is_instance(out, list)
    assert_equal(out, lst)

    # Test for a tuple
    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert_is_instance(out, tuple)
    assert_equal(out, tup)

    # Test for a dictionary
    d

# Generated at 2022-06-17 19:15:33.107255
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import _to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == _to_namedtuple(dic)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == _to_namedtuple(dic)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == _to_namedtuple(dic)


# Generated at 2022-06-17 19:15:43.856154
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic

# Generated at 2022-06-17 19:15:57.252891
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a list
    obj = [1, 2, 3]
    assert to_namedtuple(obj) == obj

    # Test a tuple
    obj = (1, 2, 3)
    assert to_namedtuple(obj) == obj

    # Test a dictionary
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == to_namedtuple(obj)

    # Test an OrderedDict
    obj = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(obj) == to_namedtuple(obj)

    # Test

# Generated at 2022-06-17 19:16:33.286530
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    # Test that a dictionary is converted to a namedtuple
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out, NamedTuple(a=1, b=2))

    # Test that an ordered dictionary is converted to a namedtuple
    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert_equal(out, NamedTuple(a=1, b=2))

    # Test that a simple namespace is converted to

# Generated at 2022-06-17 19:16:43.663094
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to

# Generated at 2022-06-17 19:16:56.388546
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from collections.abc import Mapping
    from types import SimpleNamespace
    from typing import List, Tuple, Union
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from flutils.namedtupleutils import _AllowedTypes
    from flutils.namedtupleutils import test_to_namedtuple
    from flutils.namedtupleutils import test_to_namedtuple_exceptions
    from flutils.namedtupleutils import test_to_namedtuple_exceptions_2
    from flutils.namedtupleutils import test_to_namedtuple_exceptions_3
   

# Generated at 2022-06-17 19:17:06.162084
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}

# Generated at 2022-06-17 19:17:15.593185
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}