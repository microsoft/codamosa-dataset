

# Generated at 2022-06-17 19:07:30.936708
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:07:41.061043
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3


# Generated at 2022-06-17 19:07:51.330354
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_isinstance,
        assert_raises,
    )

    # Test with a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_equal(out, lst)
    assert_isinstance(out, list)

    # Test with a tuple
    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert_equal(out, tup)
    assert_isinstance(out, tuple)

    # Test with a dict

# Generated at 2022-06-17 19:07:59.237721
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import pytest

    # Test for invalid type
    with pytest.raises(TypeError):
        to_namedtuple(1)

    # Test for empty list
    lst = []
    out = to_namedtuple(lst)
    assert isinstance(out, list)
    assert len(out) == 0

    # Test for empty tuple
    tup = ()
    out = to_namedtuple(tup)
    assert isinstance(out, tuple)
    assert len(out) == 0

    # Test for empty dict
    dic = {}
    out = to_namedtuple(dic)

# Generated at 2022-06-17 19:08:06.223381
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:08:16.814914
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from types import SimpleNamespace
    import pytest
    import sys

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    with pytest.raises(AttributeError):
        nt._c

    dic = {'a': 1, 'b': 2, 'c_': 3}

# Generated at 2022-06-17 19:08:27.395972
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple((1, 2, {'a': 1, 'b': 2})) == (1, 2, NamedTuple(a=1, b=2))
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-17 19:08:37.081034
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)


# Generated at 2022-06-17 19:08:48.810065
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}

# Generated at 2022-06-17 19:08:59.454932
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, d=4)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': 4, 'e_': 5}

# Generated at 2022-06-17 19:09:13.058440
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_raises

    # Test for invalid types

# Generated at 2022-06-17 19:09:21.582280
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3


# Generated at 2022-06-17 19:09:31.480894
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:09:41.463315
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}

# Generated at 2022-06-17 19:09:51.688018
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(hasattr(out, '_c'), False)


# Generated at 2022-06-17 19:09:58.409292
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(
        a=1, b=2, c=3
    )

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:10:05.004192
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert out == obj

    # Test with a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    assert out == obj

    # Test with a dictionary
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    assert out.a == 1
    assert out.b == 2

   

# Generated at 2022-06-17 19:10:09.079999
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:10:18.349999
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(hasattr(out, '_c'), False)


# Generated at 2022-06-17 19:10:25.968714
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-17 19:10:39.376352
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    with pytest.raises(AttributeError):
        nt._c

    dic = {'a': 1, 'b': 2, '_c': 3, 'c': 4}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

# Generated at 2022-06-17 19:10:49.486842
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from flutils.namedtupleutils import _AllowedTypes
    from typing import (
        Any,
        List,
        NamedTuple,
        Tuple,
        Union,
    )
    from unittest import TestCase
    from unittest.mock import patch

    class TestToNamedTuple(TestCase):
        """Unit tests for function to_namedtuple."""

        def test_to_namedtuple_dict(self):
            """Test to_namedtuple with a dict."""

# Generated at 2022-06-17 19:11:01.150744
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd_': 4}

# Generated at 2022-06-17 19:11:12.912362
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    nt = to_namedtuple(dic)
    assert n

# Generated at 2022-06-17 19:11:18.871448
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # noinspection PyTypeChecker
    dic: dict = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

    # noinspection PyTypeChecker
    dic: dict = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

# Generated at 2022-06-17 19:11:28.863084
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from types import SimpleNamespace
    import pytest

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}
    assert to_namedtuple(dic) == named

# Generated at 2022-06-17 19:11:39.041772
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.namedtupleutils import to_namedtuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    class MyNamedTuple2(NamedTuple):
        a: int
        b: int
        c: int

    class MyNamedTuple3(NamedTuple):
        a: int
        b: int
        c: int
        d: int

    class MyNamedTuple4(NamedTuple):
        a: int
        b: int
        c: int
        d: int
        e: int

    class MyNamedTuple5(NamedTuple):
        a: int
        b: int
        c: int

# Generated at 2022-06-17 19:11:47.374522
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == NamedTuple(a=1, b=2, c=3, d=4)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == NamedTuple(a=1, b=2, c=3, d=4, e=5)

# Generated at 2022-06-17 19:11:57.408227
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    assert_equal(
        to_namedtuple({'a': 1, 'b': 2}),
        namedtuple('NamedTuple', 'a b')(a=1, b=2)
    )
    assert_equal(
        to_namedtuple({'a': 1, 'b': 2, '_c': 3}),
        namedtuple('NamedTuple', 'a b')(a=1, b=2)
    )

# Generated at 2022-06-17 19:12:05.408361
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_isinstance,
        assert_not_equal,
        assert_not_in,
        assert_raises,
        assert_true,
    )

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert_isinstance(nt, namedtuple)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)
    assert_equal(nt, (1, 2))

# Generated at 2022-06-17 19:12:22.573385
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)

# Generated at 2022-06-17 19:12:30.860686
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import assert_equal

    dic = {'a': 1, 'b': 2}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:12:40.497957
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class Test(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == Test(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == Test(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == Test(a=1, b=2, c=3)

    dic = OrderedD

# Generated at 2022-06-17 19:12:48.816069
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'b': 2, 'a': 1}

# Generated at 2022-06-17 19:12:57.270285
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out._c, 3)


# Generated at 2022-06-17 19:13:07.063208
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:13:17.816961
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace

    # Test with a dictionary
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)
    assert nt.a == 1
    assert nt.b == 2

    # Test with a list
    lst = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    nt_lst = to_namedtuple(lst)
    assert isinstance(nt_lst, list)
    assert isinstance(nt_lst[0], namedtuple)
    assert isinstance(nt_lst[1], namedtuple)


# Generated at 2022-06-17 19:13:31.553096
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_isinstance,
        assert_raises,
    )

    # Test for non-convertible types
    assert_raises(
        TypeError,
        to_namedtuple,
        'a'
    )
    assert_raises(
        TypeError,
        to_namedtuple,
        1
    )
    assert_raises(
        TypeError,
        to_namedtuple,
        1.0
    )
    assert_raises(
        TypeError,
        to_namedtuple,
        True
    )
   

# Generated at 2022-06-17 19:13:42.515264
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-17 19:13:55.723344
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:14:09.808716
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    lst = [
        {'a': 1, 'b': 2},
        {'c': 3, 'd': 4},
    ]
    out = to_namedtuple(lst)
    assert isinstance(out, list)
    assert isinstance(out[0], NamedTuple)
    assert isinstance(out[1], NamedTuple)
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[1].c == 3
    assert out[1].d == 4

    # Test with a tuple

# Generated at 2022-06-17 19:14:17.581217
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_raises_message

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert not hasattr(out, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:14:27.246708
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # Test a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Test an OrderedDict
    odic = OrderedDict({'a': 1, 'b': 2})
    assert to_namedtuple(odic) == namedtuple

# Generated at 2022-06-17 19:14:37.517766
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:14:47.406961
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_is,
        assert_is_instance,
        assert_is_not,
        assert_is_not_instance,
        assert_raises,
        assert_raises_regex,
        assert_true,
    )

    # Test: to_namedtuple
    # Case: TypeError
    # 1. Test: to_namedtuple
    #    Case: TypeError
    #    1. Test: to_namedtuple
    #        Case: TypeError
    #        1. Test: to_namedtuple
    #            Case: TypeError


# Generated at 2022-06-17 19:14:57.072568
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1

# Generated at 2022-06-17 19:15:03.750174
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == My

# Generated at 2022-06-17 19:15:08.416845
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:15:14.973640
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}

# Generated at 2022-06-17 19:15:25.776094
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b

# Generated at 2022-06-17 19:15:44.278913
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:15:53.454022
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:16:01.827033
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-17 19:16:11.443862
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == SimpleNamespace(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == SimpleNamespace(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == SimpleNamespace(a=1, b=2, c=3)


# Generated at 2022-06-17 19:16:15.973675
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out, (1, 2))
    assert_equal(out, (out.a, out.b))

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
   

# Generated at 2022-06-17 19:16:23.294448
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    # Test a dict with a list
    dic = {'a': 1, 'b': [1, 2, 3]}
    assert to_namedtuple(dic) == dic

    # Test a dict

# Generated at 2022-06-17 19:16:33.650243
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:16:43.965218
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:16:56.529487
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

# Generated at 2022-06-17 19:17:06.245948
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'c': 4}