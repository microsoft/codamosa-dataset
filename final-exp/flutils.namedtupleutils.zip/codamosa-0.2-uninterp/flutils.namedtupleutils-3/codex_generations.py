

# Generated at 2022-06-17 19:07:30.018548
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert out == obj

    # Test a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert out == obj

    # Test a dict
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert out == obj

    # Test a dict with a list
    obj = {'a': 1, 'b': [1, 2, 3]}
    out = to_namedtuple(obj)
    assert out

# Generated at 2022-06-17 19:07:39.691128
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:07:50.441821
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

# Generated at 2022-06-17 19:08:00.966721
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out.c, 3)


# Generated at 2022-06-17 19:08:07.315831
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from typing import NamedTuple
    import pytest

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    class TestNamedTuple2(NamedTuple):
        a: int
        b: int

    class TestNamedTuple3(NamedTuple):
        a: int
        b: int

    class TestNamedTuple4(NamedTuple):
        a: int
        b: int

    class TestNamedTuple5(NamedTuple):
        a: int
        b: int


# Generated at 2022-06-17 19:08:17.368081
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-17 19:08:27.485785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from collections import namedtuple
    from collections.abc import Mapping
    from typing import NamedTuple, Tuple, Union
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from collections import namedtuple
    from collections.abc import Mapping
    from typing import NamedTuple, Tuple, Union
    from types import SimpleNames

# Generated at 2022-06-17 19:08:38.057024
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal, assert_isinstance

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_isinstance(out, namedtuple)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert_isinstance(out, namedtuple)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

# Generated at 2022-06-17 19:08:49.674490
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd_': 4}

# Generated at 2022-06-17 19:08:59.859392
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import (
        assert_equal,
        assert_isinstance,
        assert_not_equal,
        assert_raises,
    )

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert_isinstance(nt, namedtuple)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)

# Generated at 2022-06-17 19:09:11.746885
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert not hasattr(out, '_c')

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': 4}
    out = to_namedtuple(dic)

# Generated at 2022-06-17 19:09:21.172741
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:09:31.460308
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == (1, 2, 3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == (1, 2, 3, 4)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

# Generated at 2022-06-17 19:09:41.686410
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert out == obj

    # Test a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    assert out == obj

    # Test a dict
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    assert out.a == 1
    assert out.b == 2

    # Test a

# Generated at 2022-06-17 19:09:47.958722
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    # Test dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    # Test OrderedDict
    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    # Test SimpleNamespace
    obj = Simple

# Generated at 2022-06-17 19:09:57.288222
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    def _test_to_namedtuple(obj: Any, expected: Any) -> None:
        actual = to_namedtuple(obj)
        assert actual == expected
        assert type(actual) == type(expected)

    def test_to_namedtuple_list() -> None:
        _test_to_namedtuple(
            [1, 2, 3],
            [1, 2, 3]
        )

# Generated at 2022-06-17 19:10:09.068376
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)

# Generated at 2022-06-17 19:10:18.342540
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not,
        assert_not_equal,
    )

    # Test with a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_is_instance(out, list)
    assert_equal(out, lst)

    # Test with a tuple
    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert_is_instance(out, tuple)
    assert_equal(out, tup)



# Generated at 2022-06-17 19:10:25.967913
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):

        def test_to_namedtuple(self):
            from collections import OrderedDict
            from types import SimpleNamespace
            from flutils.namedtupleutils import to_namedtuple

            dic = {'a': 1, 'b': 2}
            nt = to_namedtuple(dic)
            self.assertEqual(nt.a, 1)
            self.assertEqual(nt.b, 2)

            dic = OrderedDict([('a', 1), ('b', 2)])
            nt = to_namedtuple(dic)
            self.assertEqual(nt.a, 1)
            self.assertEqual(nt.b, 2)


# Generated at 2022-06-17 19:10:35.206182
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == namedtuple('NamedTuple', 'a b c d')(a=1, b=2, c=3, d=4)

# Generated at 2022-06-17 19:10:46.417053
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import pytest

    # Test with a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert out == obj

    # Test with a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    assert out == obj

    # Test with a dict
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    assert out.a == 1

# Generated at 2022-06-17 19:10:54.155385
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(hasattr(out, '_c'), False)


# Generated at 2022-06-17 19:11:03.732492
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2, c=3))

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:11:15.231930
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_raises

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to

# Generated at 2022-06-17 19:11:23.553592
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:11:34.544877
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    # Test a dict with a list
    dic = {'a': 1, 'b': [1, 2, 3]}
    assert to_namedtuple(dic) == dic

    # Test a dict

# Generated at 2022-06-17 19:11:42.043297
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'c': 4}

# Generated at 2022-06-17 19:11:55.536443
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    class TestNestedNamedTuple(NamedTuple):
        a: int
        b: TestNamedTuple

    class TestNestedNamedTuple2(NamedTuple):
        a: int
        b: TestNestedNamedTuple

    class TestNestedNamedTuple3(NamedTuple):
        a: int
        b: TestNestedNamedTuple2

    class TestNestedNamedTuple4(NamedTuple):
        a: int
        b: TestNestedNamedTuple3


# Generated at 2022-06-17 19:12:04.843613
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:12:13.652988
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == to_namedtuple(dic)

    # Test a dict with a list
    dic = {'a': 1, 'b': [1, 2, 3]}
    assert to_namedtuple(dic) == to

# Generated at 2022-06-17 19:12:33.146029
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-17 19:12:42.013516
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from types import SimpleNamespace

    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)

# Generated at 2022-06-17 19:12:53.311623
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}

# Generated at 2022-06-17 19:13:04.513768
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:13:15.431499
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    nt = to_namedtuple(dic)
    assert n

# Generated at 2022-06-17 19:13:24.284733
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == NamedTuple(a=1, b=2, c=3, d=4)
    assert to_named

# Generated at 2022-06-17 19:13:33.581885
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'b': 2, 'a': 1}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)



# Generated at 2022-06-17 19:13:43.892795
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test with a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    # Test with an OrderedDict
    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2

# Generated at 2022-06-17 19:13:56.396847
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

# Generated at 2022-06-17 19:14:03.920815
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    assert to_namedtuple(dic) == Test

# Generated at 2022-06-17 19:14:42.507258
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt == (1, 2)
    assert nt == (nt.a, nt.b)

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt == (1, 2)

# Generated at 2022-06-17 19:14:55.409770
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    # Test with a list
    lst = [1, 2, 3, 4]
    out = to_namedtuple(lst)
    assert_equal(out, lst)

    # Test with a tuple
    tup = (1, 2, 3, 4)
    out = to_namedtuple(tup)
    assert_equal(out, tup)

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out, dic)

    # Test with an

# Generated at 2022-06-17 19:15:02.560543
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a list
    lst = [
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
    ]
    out = to_namedtuple(lst)
    assert isinstance(out, list)
    assert len(out) == 3
    assert isinstance(out[0], NamedTuple)
    assert out[0].a == 1
    assert out[0].b == 2

    # Test a tuple

# Generated at 2022-06-17 19:15:12.133910
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': 4}

# Generated at 2022-06-17 19:15:23.434373
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    class MyNamedTuple2(NamedTuple):
        a: int
        b: int

    class MyNamedTuple3(NamedTuple):
        a: int
        b: int

    class MyNamedTuple4(NamedTuple):
        a: int
        b: int

    class MyNamedTuple5(NamedTuple):
        a: int
        b: int

    class MyNamedTuple6(NamedTuple):
        a: int
        b: int


# Generated at 2022-06-17 19:15:32.860213
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    import pytest

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    with pytest.raises(AttributeError):
        out.c

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': {'e': 4, 'f': 5}}
    out = to_namedtuple(dic)

# Generated at 2022-06-17 19:15:43.594998
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert not hasattr(out, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1

# Generated at 2022-06-17 19:15:57.229222
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.tests.helpers import (
        assert_equal,
        assert_is_instance,
        assert_is_not,
        assert_is,
        assert_raises,
    )

    # Test with a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_is_instance(out, list)
    assert_is_not(out, lst)
    assert_equal(out, lst)

    # Test with a tuple
    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert_

# Generated at 2022-06-17 19:16:08.977006
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == My

# Generated at 2022-06-17 19:16:19.823891
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    nt = to_namedtuple(dic)
    assert nt.a == 1

# Generated at 2022-06-17 19:17:12.782690
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    # Test for list
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple([1, 2, {'a': 1, 'b': 2}]) == [1, 2, NamedTuple(a=1, b=2)]
    assert to_namedtuple([1, 2, {'a': 1, 'b': 2, '_c': 3}]) == [1, 2, NamedTuple(a=1, b=2)]

# Generated at 2022-06-17 19:17:21.385067
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple(1) == 1
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple(('a', 'b')) == ('a', 'b')
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))