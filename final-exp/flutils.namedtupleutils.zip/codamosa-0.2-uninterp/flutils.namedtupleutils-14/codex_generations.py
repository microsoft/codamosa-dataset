

# Generated at 2022-06-17 19:07:30.368432
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from collections.abc import Mapping
    from types import SimpleNamespace

    # Test a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert out == obj

    # Test a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    assert out == obj

    # Test a dict
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert isinstance(out, namedtuple)
    assert out.a == 1
    assert out.b == 2

    # Test a dict with a

# Generated at 2022-06-17 19:07:40.069394
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd_': 4}

# Generated at 2022-06-17 19:07:50.652820
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': 4}

# Generated at 2022-06-17 19:08:01.154003
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == Test

# Generated at 2022-06-17 19:08:07.417162
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test for dict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    # Test for OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    # Test for SimpleNamespace
    ns = SimpleNamespace(a=1, b=2)
    nt = to_namedtuple(ns)


# Generated at 2022-06-17 19:08:14.035283
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c_': 3}

# Generated at 2022-06-17 19:08:22.014310
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import pytest

    # Test for invalid types
    with pytest.raises(TypeError):
        to_namedtuple(1)
    with pytest.raises(TypeError):
        to_namedtuple(1.0)
    with pytest.raises(TypeError):
        to_namedtuple(True)
    with pytest.raises(TypeError):
        to_namedtuple(None)

    # Test for invalid identifiers
    with pytest.raises(SyntaxError):
        validate_identifier('1')
    with pytest.raises(SyntaxError):
        validate_identifier('1a')

# Generated at 2022-06-17 19:08:31.531481
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test with a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    # Test with an OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == dic

   

# Generated at 2022-06-17 19:08:39.972020
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    import pytest

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    class TestNamedTuple2(NamedTuple):
        c: int
        d: int

    class TestNamedTuple3(NamedTuple):
        e: int
        f: int

    class TestNamedTuple4(NamedTuple):
        g: int
        h: int

    class TestNamedTuple5(NamedTuple):
        i: int
        j: int

    class TestNamedTuple6(NamedTuple):
        k: int
        l: int


# Generated at 2022-06-17 19:08:45.848774
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt == (1, 2)
    assert nt == (nt.a, nt.b)
    assert nt == (nt[0], nt[1])
    assert nt[0] == 1
    assert nt[1] == 2
    assert nt == (1, 2)
    assert nt == (nt.a, nt.b)
    assert nt == (nt[0], nt[1])
    assert nt[0] == 1
    assert nt[1] == 2

# Generated at 2022-06-17 19:08:56.947990
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    # Test for non-convertable types
    with assert_equal(TypeError):
        to_namedtuple(1)
    with assert_equal(TypeError):
        to_namedtuple(1.0)
    with assert_equal(TypeError):
        to_namedtuple(True)
    with assert_equal(TypeError):
        to_namedtuple(None)
    with assert_equal(TypeError):
        to_namedtuple(set())
    with assert_equal(TypeError):
        to_namedtuple(frozenset())

    # Test for convertable

# Generated at 2022-06-17 19:09:08.568785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing.helpers import raises

    # Test dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Test OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Test SimpleNamespace

# Generated at 2022-06-17 19:09:19.069159
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    # Test a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Test an OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_named

# Generated at 2022-06-17 19:09:25.742944
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out, NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert_equal(out, NamedTuple(a=1, b=2, c=3))

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:09:33.284980
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert n

# Generated at 2022-06-17 19:09:43.293735
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:09:55.684297
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    # Test with a list
    lst = [1, 2, 3]
    assert_equal(to_namedtuple(lst), lst)
    lst = [1, 2, {'a': 1, 'b': 2}]
    assert_equal(to_namedtuple(lst), [1, 2, NamedTuple(a=1, b=2)])
    lst = [1, 2, {'a': 1, 'b': 2}, {'a': 1, 'b': 2}]

# Generated at 2022-06-17 19:10:06.698571
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_isinstance,
        assert_raises,
        assert_true,
    )

    # Test that the function raises a TypeError if given an invalid type
    assert_raises(
        TypeError,
        to_namedtuple,
        'a string'
    )

    # Test that the function returns a NamedTuple if given a dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_isinstance(out, namedtuple)
    assert_equal(out.a, 1)

# Generated at 2022-06-17 19:10:17.558158
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a dictionary
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', 'a b'))
    assert nt.a == 1
    assert nt.b == 2

    # Test a dictionary with a list
    dic = {'a': 1, 'b': [1, 2, 3]}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', 'a b'))
    assert nt.a == 1

# Generated at 2022-06-17 19:10:28.000423
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:10:39.560203
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt == (1, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3
    assert nt == (1, 2, 3)


# Generated at 2022-06-17 19:10:49.640363
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple(('a', 'b')) == ('a', 'b')

# Generated at 2022-06-17 19:10:58.585130
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) != dic
    assert to_namedtuple(dic) != to_namedtuple(dic)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_named

# Generated at 2022-06-17 19:11:06.358591
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    import pytest

    class _TestNamedTuple(NamedTuple):
        a: int
        b: int

    class _TestNamedTuple2(NamedTuple):
        a: int
        b: int

    class _TestNamedTuple3(NamedTuple):
        a: int
        b: int

    class _TestNamedTuple4(NamedTuple):
        a: int
        b: int

    class _TestNamedTuple5(NamedTuple):
        a: int
        b: int

    class _TestNamedTuple6(NamedTuple):
        a: int

# Generated at 2022-06-17 19:11:16.479609
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(dict(a=1, b=2)) == TestNamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict(a=1, b=2)) == TestNamedTuple(a=1, b=2)

# Generated at 2022-06-17 19:11:26.891964
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:11:37.891616
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:11:48.655619
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    assert to_namedtuple(dic) == dic
    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]}
    assert to_namedtuple(dic) == dic

# Generated at 2022-06-17 19:11:57.797842
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from typing import NamedTuple
    from unittest import TestCase

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    class TestNamedTuple2(NamedTuple):
        a: int
        b: int

    class TestNamedTuple3(NamedTuple):
        a: int
        b: int

    class TestNamedTuple4(NamedTuple):
        a: int
        b: int

    class TestNamedTuple5(NamedTuple):
        a: int
        b: int


# Generated at 2022-06-17 19:12:07.860650
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # Test with a list
    lst = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    out = to_namedtuple(lst)
    assert isinstance(out, list)
    assert len(out) == 2
    assert isinstance(out[0], NamedTuple)
    assert isinstance(out[1], NamedTuple)
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[1].c == 3
    assert out[1].d == 4

    # Test with a tuple

# Generated at 2022-06-17 19:12:16.535370
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier

    class TestNamedTuple(NamedTuple):
        a: int
        b: str
        c: float

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3.0}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3.0)


# Generated at 2022-06-17 19:12:26.101871
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:12:33.936987
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_isinstance,
        assert_not_equal,
        assert_raises,
        assert_true,
    )

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_isinstance(out, namedtuple)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out, (1, 2))
    assert_equal(out, (out.a, out.b))


# Generated at 2022-06-17 19:12:45.275999
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3


# Generated at 2022-06-17 19:12:46.156805
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-17 19:12:56.449323
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    import pytest

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-17 19:13:05.894250
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace
    from typing import NamedTuple, Tuple, Union

    _AllowedTypes = Union[
        Mapping,
        NamedTuple,
        SimpleNamespace,
        Tuple,
    ]

    def _to_namedtuple(obj: _AllowedTypes) -> Union[NamedTuple, Tuple]:
        return to_namedtuple(obj)

    def test_to_namedtuple_dict():
        dic = {'a': 1, 'b': 2}
        out = _to_namedtuple(dic)
        assert out.a == 1
        assert out.b == 2


# Generated at 2022-06-17 19:13:17.232463
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier

    # Test: dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    # Test: OrderedDict
    from collections import OrderedDict
    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1

# Generated at 2022-06-17 19:13:22.379240
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)

# Generated at 2022-06-17 19:13:33.371428
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    import pytest

    # Test that a list is converted to a list
    data = [1, 2, 3]
    out = to_namedtuple(data)
    assert isinstance(out, list)
    assert out == data

    # Test that a tuple is converted to a tuple
    data = (1, 2, 3)
    out = to_namedtuple(data)
    assert isinstance(out, tuple)
    assert out == data

    # Test that a dict is converted to a namedtuple
    data = {'a': 1, 'b': 2}
    out = to_namedtuple(data)
    assert isinstance(out, tuple)
    assert out.a == 1


# Generated at 2022-06-17 19:13:45.713934
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    lst = [1, 2, 3, 4]
    assert to_namedtuple(lst) == lst

    # Test with a tuple
    tup = (1, 2, 3, 4)
    assert to_namedtuple(tup) == tup

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Test with an OrderedDict

# Generated at 2022-06-17 19:13:54.899070
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))

# Generated at 2022-06-17 19:14:05.868000
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    assert_equal(
        to_namedtuple([1, 2, 3]),
        [1, 2, 3]
    )
    assert_equal(
        to_namedtuple((1, 2, 3)),
        (1, 2, 3)
    )
    assert_equal(
        to_namedtuple({'a': 1, 'b': 2}),
        NamedTuple(a=1, b=2)
    )

# Generated at 2022-06-17 19:14:15.182500
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_raises
    from flutils.namedtupleutils import _to_namedtuple

    # Test _to_namedtuple
    # noinspection PyUnusedLocal
    def test_to_namedtuple_func(
            obj: Any,
            _started: bool = False
    ) -> Any:
        return _to_namedtuple(obj, _started)

    # Test _to_namedtuple.register(Mapping)
    # noinspection PyUnusedLocal

# Generated at 2022-06-17 19:14:26.248308
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test with a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    # Test with a dict with a list
    dic = {'a': 1, 'b': [1, 2, 3]}
    assert to_namedtuple(dic) == dic

   

# Generated at 2022-06-17 19:14:36.913189
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a dictionary
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert nt.a == 1
    assert nt.b == 2

    # Test with an OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert nt.a == 1


# Generated at 2022-06-17 19:14:42.545362
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}
    nt = to_namedtuple(dic)
    assert nt.a == 1
   

# Generated at 2022-06-17 19:14:55.409693
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) != NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(dic) != NamedTuple(a=1, b=3)
    assert to_namedtuple(dic) != NamedTuple(a=1)
    assert to_namedtuple(dic) != NamedTuple(b=2)
    assert to_namedtuple(dic) != NamedTuple()
    assert to_namedtuple(dic) != NamedTuple(a=1, b=2, c=3)

# Generated at 2022-06-17 19:15:00.244337
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from types import SimpleNamespace
    from typing import NamedTuple

    # noinspection PyTypeChecker
    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)


# Generated at 2022-06-17 19:15:10.850152
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int
        c: int

    assert to_namedtuple(TestNamedTuple(1, 2, 3)) == TestNamedTuple(1, 2, 3)

    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) == \
        TestNamedTuple(1, 2, 3)

    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) == \
        TestNamedTuple(1, 2, 3)

    assert to

# Generated at 2022-06-17 19:15:25.809237
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    d

# Generated at 2022-06-17 19:15:33.875239
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not,
        assert_is,
        assert_raises,
    )

    # Test with a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_is_instance(out, list)
    assert_is_not(out, lst)
    assert_equal(out, lst)

    # Test with a tuple
    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert_is_

# Generated at 2022-06-17 19:15:44.471315
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:15:53.594446
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace
    from typing import NamedTuple, Union

    _AllowedTypes = Union[
        List,
        Mapping,
        NamedTuple,
        SimpleNamespace,
        Tuple,
    ]


# Generated at 2022-06-17 19:16:01.897994
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_isinstance,
        assert_raises,
        assert_true,
    )

    # Test dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_isinstance(out, namedtuple('NamedTuple', 'a b'))
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_true(hasattr(out, 'a'))
    assert_true(hasattr(out, 'b'))
    assert_

# Generated at 2022-06-17 19:16:11.546785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    class MyNamedTuple2(NamedTuple):
        a: int
        b: int
        c: int

    class MyNamedTuple3(NamedTuple):
        a: int
        b: int
        c: int
        d: int

    class MyNamedTuple4(NamedTuple):
        a: int
        b: int
        c: int
        d: int
        e: int

# Generated at 2022-06-17 19:16:21.447266
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', 'a b'))
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', 'a b'))
    assert nt.a == 1
    assert nt.b == 2

# Generated at 2022-06-17 19:16:32.779627
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import pytest

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple('NamedTuple', 'a b'))
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple('NamedTuple', 'a b'))
    assert out.a == 1
    assert out.b == 2

# Generated at 2022-06-17 19:16:43.271978
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert not hasattr(out, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3

    d

# Generated at 2022-06-17 19:16:56.225830
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # Test for list
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test for tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test for dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    # Test for OrderedDict
    odic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(odic) == odic

    # Test for SimpleNamespace

# Generated at 2022-06-17 19:17:15.080880
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:17:22.365176
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c_': 3}