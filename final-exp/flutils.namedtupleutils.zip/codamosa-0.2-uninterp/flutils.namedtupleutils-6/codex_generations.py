

# Generated at 2022-06-17 19:07:29.169111
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == TestNamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == TestNamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == Test

# Generated at 2022-06-17 19:07:38.701392
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # noinspection PyUnusedLocal
    def _test_to_namedtuple(
            obj: Any,
            expected: Any,
            _started: bool = False
    ) -> None:
        out = to_namedtuple(obj)
        assert out == expected

    # noinspection PyUnusedLocal
    def _test_to_namedtuple_raises(
            obj: Any,
            expected: Any,
            _started: bool = False
    ) -> None:
        try:
            to_namedtuple(obj)
        except Exception as e:
            assert isinstance(e, expected)

# Generated at 2022-06-17 19:07:50.118989
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert out == lst
    lst = [1, 2, {'a': 1, 'b': 2}]
    out = to_namedtuple(lst)
    assert out == lst
    lst = [1, 2, {'a': 1, 'b': 2}]
    out = to_namedtuple(lst)
    assert out == lst
    lst = [1, 2, {'a': 1, 'b': 2}]

# Generated at 2022-06-17 19:08:00.889320
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test that a list is returned unchanged
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == lst

    # Test that a tuple is returned unchanged
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup

    # Test that a string is returned unchanged
    str_ = 'abc'
    assert to_namedtuple(str_) == str_

    # Test that a dict is converted to a namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    # Test that

# Generated at 2022-06-17 19:08:07.270784
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c_': 3}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, '_d': 4}) == NamedTuple(a=1, b=2, c=3)
    assert to

# Generated at 2022-06-17 19:08:17.325002
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import to_namedtuple as tnt
    from collections import OrderedDict
    from collections import namedtuple
    from types import SimpleNamespace
    from typing import NamedTuple
    from typing import Tuple
    from typing import Union

    # noinspection PyTypeChecker
    dic: dict = {'a': 1, 'b': 2}
    # noinspection PyTypeChecker
    odic: OrderedDict = OrderedDict(a=1, b=2)
    # noinspection PyTypeChecker
    nt: NamedTuple = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    # noinspection PyTypeChecker
    sn: SimpleNamespace

# Generated at 2022-06-17 19:08:27.486831
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    lst = [1, 2, 3]
    nt = to_namedtuple(lst)
    assert isinstance(nt, list)
    assert nt == lst

    # Test with a tuple
    tup = (1, 2, 3)
    nt = to_namedtuple(tup)
    assert isinstance(nt, tuple)
    assert nt == tup

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple)

# Generated at 2022-06-17 19:08:38.057408
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == Test

# Generated at 2022-06-17 19:08:49.678115
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_function_returns_expected_result

    # Test for a list
    obj = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    expected = [
        NamedTuple(a=1, b=2),
        NamedTuple(c=3, d=4)
    ]
    assert_function_returns_expected_result(to_namedtuple, obj, expected)

    # Test for a tuple
    obj = ({'a': 1, 'b': 2}, {'c': 3, 'd': 4})

# Generated at 2022-06-17 19:08:59.859103
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)


# Generated at 2022-06-17 19:09:12.163370
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == SimpleNamespace(a=1, b=2)

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == SimpleNamespace(a=1, b=2)

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == SimpleNamespace(a=1, b=2)

    dic = {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:09:22.894772
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert not hasattr(out, '_c')


# Generated at 2022-06-17 19:09:32.127173
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'b': 2, 'a': 1}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)



# Generated at 2022-06-17 19:09:42.361008
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test for dict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    # Test for OrderedDict
    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    # Test for SimpleNamespace
    sn = SimpleNamespace()
    sn.a = 1
    sn.b = 2


# Generated at 2022-06-17 19:09:55.451532
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out.c, 3)


# Generated at 2022-06-17 19:10:06.654392
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import pytest

    # noinspection PyTypeChecker

# Generated at 2022-06-17 19:10:17.552234
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:10:27.990988
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_raises_message

    # Test for invalid types

# Generated at 2022-06-17 19:10:38.601123
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    # Test that a list is returned unchanged
    lst = [1, 2, 3]
    assert_equal(to_namedtuple(lst), lst)

    # Test that a tuple is returned unchanged
    tup = (1, 2, 3)
    assert_equal(to_namedtuple(tup), tup)

    # Test that a string is returned unchanged
    s = 'abc'
    assert_equal(to_namedtuple(s), s)

    # Test that a dict is converted to a namedtuple
    dic = {'a': 1, 'b': 2}

# Generated at 2022-06-17 19:10:48.874914
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:11:02.513008
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import _to_namedtuple

    # noinspection PyUnresolvedReferences
    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b

# Generated at 2022-06-17 19:11:14.281322
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'd_': 4}

# Generated at 2022-06-17 19:11:25.536378
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple

    def _test_to_namedtuple(obj: Any, expected: Any):
        out = to_namedtuple(obj)
        assert out == expected

    def _test_to_namedtuple_exception(obj: Any, expected: Any):
        try:
            out = to_namedtuple(obj)
        except Exception as e:
            assert type(e) == expected
        else:
            assert False, 'Expected exception: %s' % expected


# Generated at 2022-06-17 19:11:36.299204
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_isinstance,
        assert_raises,
    )

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_isinstance(out, namedtuple)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert_isinstance(out, namedtuple)

# Generated at 2022-06-17 19:11:47.769206
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:11:57.536296
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test for a list
    test_list = [
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
    ]
    out = to_namedtuple(test_list)
    assert isinstance(out, list)
    assert len(out) == 2
    assert isinstance(out[0], NamedTuple)
    assert out[0].a == 1
    assert out[0].b == 2
    assert isinstance(out[1], NamedTuple)
    assert out[1].a == 3
    assert out[1].b == 4

    # Test for a tuple
    test_tuple

# Generated at 2022-06-17 19:12:07.678177
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import (
        assert_equal,
        assert_isinstance,
        assert_raises,
    )

    # Test with a dictionary
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert_isinstance(nt, namedtuple)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)

    # Test with an OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    nt = to_namedtuple(dic)

# Generated at 2022-06-17 19:12:16.044728
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}

# Generated at 2022-06-17 19:12:25.717663
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:12:33.717911
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from collections.abc import Mapping
    from types import SimpleNamespace
    from typing import List, Tuple, Union

    _AllowedTypes = Union[List, Mapping, namedtuple, SimpleNamespace, Tuple]


# Generated at 2022-06-17 19:12:47.042441
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    obj = [1, 2, 3]
    assert to_namedtuple(obj) == obj

    # Test with a tuple
    obj = (1, 2, 3)
    assert to_namedtuple(obj) == obj

    # Test with a dict
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == obj

    # Test with a OrderedDict
    obj = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(obj) == obj

# Generated at 2022-06-17 19:12:53.803949
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3


# Generated at 2022-06-17 19:13:04.907186
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
   

# Generated at 2022-06-17 19:13:15.830143
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class Test(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1


# Generated at 2022-06-17 19:13:24.541987
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_error

    # Test for invalid input
    assert_error(
        TypeError,
        to_namedtuple,
        'abc'
    )
    assert_error(
        TypeError,
        to_namedtuple,
        123
    )
    assert_error(
        TypeError,
        to_namedtuple,
        123.456
    )
    assert_error(
        TypeError,
        to_namedtuple,
        True
    )
    assert_error(
        TypeError,
        to_namedtuple,
        False
    )

# Generated at 2022-06-17 19:13:33.791761
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import _AllowedTypes
    from flutils.namedtupleutils import _to_namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _AllowedTypes
    from flutils.namedtupleutils import _to_namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _AllowedTypes
    from flutils.namedtupleutils import _to_namedtuple


# Generated at 2022-06-17 19:13:44.017676
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_isinstance,
        assert_raises,
    )

    # Test a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_equal(out, lst)
    assert_isinstance(out, list)

    # Test a tuple
    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert_equal(out, tup)
    assert_isinstance(out, tuple)

    # Test a dict

# Generated at 2022-06-17 19:13:56.453683
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import _to_namedtuple

    # Test with a list
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple([1, 2, 3, {'a': 1, 'b': 2}]) == [1, 2, 3, NamedTuple(a=1, b=2)]
    assert to_namedtuple([1, 2, 3, {'a': 1, 'b': 2, '_c': 3}]) == [1, 2, 3, NamedTuple(a=1, b=2)]
    assert to_namedt

# Generated at 2022-06-17 19:14:06.847313
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test namedtuple
    nt = to_namedtuple({'a': 1, 'b': 2})
    assert nt.a == 1
    assert nt.b == 2

    # Test OrderedDict
    nt = to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert nt.a == 1
    assert nt.b == 2

    # Test SimpleNamespace
    nt = to_namedtuple(SimpleNamespace(a=1, b=2))
    assert nt.a == 1
    assert nt.b == 2

    # Test list
   

# Generated at 2022-06-17 19:14:15.605991
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    d

# Generated at 2022-06-17 19:14:28.824033
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int
        c: int

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)

    dic = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)


# Generated at 2022-06-17 19:14:34.843589
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    import pytest

    # Test a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert out == obj

    # Test a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert out == obj

    # Test a dict
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    # Test an OrderedDict
    obj = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(obj)
   

# Generated at 2022-06-17 19:14:44.026310
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out.a

# Generated at 2022-06-17 19:14:50.976283
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == NamedTuple(a=1, b=2, c=3, d=4)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == NamedTuple(a=1, b=2, c=3, d=4, e=5)

# Generated at 2022-06-17 19:15:01.754451
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)
    assert_equal(nt._c, 3)


# Generated at 2022-06-17 19:15:11.810313
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test for dict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', 'a b'))
    assert nt.a == 1
    assert nt.b == 2

    # Test for OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', 'a b'))
    assert nt.a == 1

# Generated at 2022-06-17 19:15:16.751412
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == _to_namedtuple(dic)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == _to_namedtuple(dic)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(1, 2, 3)

   

# Generated at 2022-06-17 19:15:26.265872
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    import pytest

    class MyNamedTuple(NamedTuple):
        a: int
        b: str

    class MyNamedTuple2(NamedTuple):
        a: int
        b: str

    class MyNamedTuple3(NamedTuple):
        a: int
        b: str

    class MyNamedTuple4(NamedTuple):
        a: int
        b: str

    class MyNamedTuple5(NamedTuple):
        a: int
        b: str

    class MyNamedTuple6(NamedTuple):
        a: int
        b: str


# Generated at 2022-06-17 19:15:34.074333
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out

# Generated at 2022-06-17 19:15:44.595904
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # Test a list
    lst = [1, 2, 3, 4]
    out = to_namedtuple(lst)
    assert out == lst

    # Test a tuple
    tup = (1, 2, 3, 4)
    out = to_namedtuple(tup)
    assert out == tup

    # Test a dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    # Test an OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_

# Generated at 2022-06-17 19:16:02.667758
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.namedtupleutils import to_namedtuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:16:11.845689
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_isinstance,
        assert_not_equal,
        assert_raises,
        assert_true,
    )

    # Test: dict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert_isinstance(nt, namedtuple)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)
    assert_equal(nt, (1, 2))
    assert_equal(nt._fields, ('a', 'b'))
    assert_

# Generated at 2022-06-17 19:16:21.679338
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)

# Generated at 2022-06-17 19:16:32.951582
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # noinspection PyUnusedLocal
    def _test_to_namedtuple(
            obj: Any,
            expected: Any,
            _started: bool = False
    ) -> None:
        actual = to_namedtuple(obj)
        assert actual == expected

    # noinspection PyUnusedLocal
    def _test_to_namedtuple_raises(
            obj: Any,
            expected: Any,
            _started: bool = False
    ) -> None:
        try:
            to_namedtuple(obj)
        except Exception as e:
            assert isinstance(e, expected)

# Generated at 2022-06-17 19:16:43.429341
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.tests.helpers import UnitTestCase

    class TestCase(UnitTestCase):
        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)
            self.assertEqual(out, (1, 2))

            dic = {'a': 1, 'b': 2, 'c': 3}
            out = to_namedtuple(dic)

# Generated at 2022-06-17 19:16:56.319310
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == namedtuple('NamedTuple', 'a b c d')(a=1, b=2, c=3, d=4)

# Generated at 2022-06-17 19:17:06.101945
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    # Test: Mapping
    dic = {'a': 1, 'b': 2}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}

# Generated at 2022-06-17 19:17:11.952296
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-17 19:17:20.935695
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}