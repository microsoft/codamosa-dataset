

# Generated at 2022-06-17 19:07:30.178615
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = OrderedDict([('b', 2), ('a', 1)])

# Generated at 2022-06-17 19:07:39.880421
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))
    assert to_named

# Generated at 2022-06-17 19:07:50.478282
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic


# Generated at 2022-06-17 19:08:01.004731
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')

    dic = {'a': 1, 'b': 2, '_c': 3, '_d': 4}

# Generated at 2022-06-17 19:08:07.337937
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    import pytest

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    class MyNamedTuple2(NamedTuple):
        a: int
        b: int

    class MyNamedTuple3(NamedTuple):
        a: int
        b: int

    class MyNamedTuple4(NamedTuple):
        a: int
        b: int

    class MyNamedTuple5(NamedTuple):
        a: int
        b: int

    class MyNamedTuple6(NamedTuple):
        a: int
        b: int


# Generated at 2022-06-17 19:08:17.365847
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple(None) is None
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple(True) is True
    assert to_namedtuple(False) is False
    assert to_namedtuple('') == ''
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple('a b') == 'a b'
    assert to_namedtuple('a_b') == 'a_b'
    assert to_namedtuple('a-b') == 'a-b'
   

# Generated at 2022-06-17 19:08:27.485717
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_is_instance,
        assert_is_not,
        assert_is,
        assert_raises,
    )

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_is_instance(out, namedtuple)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert_is

# Generated at 2022-06-17 19:08:38.057563
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # Test for OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)

    # Test for dict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)

    # Test for SimpleNamespace
    obj = SimpleNamespace(a=1, b=2)

# Generated at 2022-06-17 19:08:49.672827
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert_equal(to_namedtuple(dic), NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}

# Generated at 2022-06-17 19:08:59.858717
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class A(NamedTuple):
        a: int
        b: int

    class B(NamedTuple):
        a: int
        b: int

    class C(NamedTuple):
        a: int
        b: int

    class D(NamedTuple):
        a: int
        b: int

    class E(NamedTuple):
        a: int
        b: int

    class F(NamedTuple):
        a: int
        b: int

    class G(NamedTuple):
        a: int
        b: int

    class H(NamedTuple):
        a: int

# Generated at 2022-06-17 19:09:12.028217
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=NamedTuple(d=3, e=4))

    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=NamedTuple(d=3, e=4), f=[5, 6, 7])



# Generated at 2022-06-17 19:09:21.249353
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from types import SimpleNamespace

    # Test with a list
    lst = [1, 2, 3, 4]
    out = to_namedtuple(lst)
    assert isinstance(out, list)
    assert out == lst

    # Test with a tuple
    tup = (1, 2, 3, 4)
    out = to_namedtuple(tup)
    assert isinstance(out, tuple)
    assert out == tup

    # Test with a dictionary
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, tuple)


# Generated at 2022-06-17 19:09:31.228960
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-17 19:09:41.567290
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}


# Generated at 2022-06-17 19:09:51.688009
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from collections import OrderedDict
    from types import SimpleNamespace

    class TestToNamedTuple(unittest.TestCase):

        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)
            self.assertEqual(out, (1, 2))

            dic = {'a': 1, 'b': 2, 'c': 3}
            out = to_namedtuple(dic)
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)

# Generated at 2022-06-17 19:10:00.653618
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    dic = {'a': 1, 'b': 2, '_c': 3}

# Generated at 2022-06-17 19:10:09.758548
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_is_instance,
        assert_is_none,
        assert_is_not_none,
        assert_is_not,
        assert_is,
        assert_raises,
    )

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert_is_instance(nt, namedtuple)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)


# Generated at 2022-06-17 19:10:18.820451
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from flutils.namedtupleutils import _to_namedtuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    class TestNamedTuple2(NamedTuple):
        a: int
        b: int

    class TestNamedTuple3(NamedTuple):
        a: int
        b: int

    class TestNamedTuple4(NamedTuple):
        a: int
        b: int

    class TestNamedTuple5(NamedTuple):
        a: int
        b: int

    class TestNamedTuple6(NamedTuple):
        a

# Generated at 2022-06-17 19:10:26.369294
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'c': 4}

# Generated at 2022-06-17 19:10:35.384649
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test for a list
    obj = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert isinstance(out[0], NamedTuple)
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[1].a == 3
    assert out[1].b == 4

    # Test for a tuple
    obj = ({'a': 1, 'b': 2}, {'a': 3, 'b': 4})
    out = to_namedtuple(obj)


# Generated at 2022-06-17 19:10:49.246016
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    assert to_namedtuple(dic) == Test

# Generated at 2022-06-17 19:10:58.560769
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == My

# Generated at 2022-06-17 19:11:09.214160
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert n

# Generated at 2022-06-17 19:11:17.701465
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)

    dic

# Generated at 2022-06-17 19:11:27.491623
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace
    from typing import List, Tuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3, 'c': 4}

# Generated at 2022-06-17 19:11:38.225645
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:11:48.900136
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out, (1, 2))

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_equal(out, (1, 2))


# Generated at 2022-06-17 19:11:54.612713
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    # Test with a list
    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert_equal(out, lst)

    # Test with a tuple
    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert_equal(out, tup)

    # Test with a dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)

# Generated at 2022-06-17 19:12:05.186885
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(OrderedDict(dic))
    assert to_namedtuple(dic) == to_namedtuple(SimpleNamespace(**dic))
    assert to_namedtuple(dic) == to_namedtuple(SimpleNamespace(**OrderedDict(dic)))
    assert to_namedtuple(dic) == to_

# Generated at 2022-06-17 19:12:14.681113
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:12:30.033435
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:12:35.168435
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) == to

# Generated at 2022-06-17 19:12:45.750627
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    with pytest.raises(AttributeError):
        nt._c

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:12:56.222880
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple(True) is True
    assert to_namedtuple(False) is False
    assert to_namedtuple(None) is None
    assert to_namedtuple('') == ''
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple('a b') == 'a b'
    assert to_namedtuple('a_b') == 'a_b'
    assert to_namedtuple('a-b') == 'a-b'
   

# Generated at 2022-06-17 19:13:05.839499
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == My

# Generated at 2022-06-17 19:13:17.197593
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    # noinspection PyPep8Naming
    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:13:25.150075
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)


# Generated at 2022-06-17 19:13:34.053337
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    assert to_namedtuple(dic) == MyNamedTuple(a=1, b=2)

    dic = {'b': 2, 'a': 1}

# Generated at 2022-06-17 19:13:44.165518
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.miscutils import (
        get_random_string,
        get_random_int,
    )
    from flutils.testutils import (
        random_string,
        random_int,
        random_bool,
    )
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-17 19:13:56.513197
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:14:18.432761
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    import pytest

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:14:27.612051
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testingutils import (
        assert_equal,
        assert_isinstance,
        assert_raises,
    )

    # Test with a list
    obj = [
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
    ]
    out = to_namedtuple(obj)
    assert_isinstance(out, list)
    assert_equal(len(out), 2)
    assert_isinstance(out[0], NamedTuple)
    assert_isinstance(out[1], NamedTuple)
    assert_equal(out[0].a, 1)


# Generated at 2022-06-17 19:14:37.544103
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    import pytest

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:14:47.444061
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3


# Generated at 2022-06-17 19:14:57.096554
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_raises_message

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple('NamedTuple', 'a b'))
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple('NamedTuple', 'a b'))
    assert out.a == 1
    assert out.b == 2

# Generated at 2022-06-17 19:15:03.776505
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        def test_to_namedtuple(self):
            from collections import namedtuple
            from types import SimpleNamespace

            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertIsInstance(out, namedtuple)
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)

            dic = {'a': 1, 'b': 2, '_c': 3}
            out = to_namedtuple(dic)
            self.assertIsInstance(out, namedtuple)
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)

# Generated at 2022-06-17 19:15:12.809269
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # noinspection PyTypeChecker

# Generated at 2022-06-17 19:15:23.864496
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:15:33.035681
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}

# Generated at 2022-06-17 19:15:43.794935
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:16:23.125033
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from flutils.testing import assert_equal

    # Test: dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    # Test: OrderedDict
    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)

    # Test: SimpleNamespace

# Generated at 2022-06-17 19:16:33.532069
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == SimpleNamespace(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == SimpleNamespace(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == SimpleNamespace(a=1, b=2, c=3)


# Generated at 2022-06-17 19:16:43.890911
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c d')(a=1, b=2, c=3, d=4)

# Generated at 2022-06-17 19:16:56.504829
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple

# Generated at 2022-06-17 19:17:06.220541
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test with a list
    obj = [1, 2, 3]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert out == obj

    # Test with a tuple
    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    assert out == obj

    # Test with a dict
    obj = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    assert out.a == 1

# Generated at 2022-06-17 19:17:15.250857
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from typing import NamedTuple

    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == TestNamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 19:17:22.442529
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple(OrderedDict()) == NamedTuple()
    assert to_namedtuple(SimpleNamespace()) == NamedTuple()

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)