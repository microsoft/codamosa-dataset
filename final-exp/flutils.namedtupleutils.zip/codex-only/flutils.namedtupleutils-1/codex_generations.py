

# Generated at 2022-06-23 18:06:15.530798
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    test_dict_1 = {'a': 1, 'b': 2, '_c': 3}
    test_dict_2 = {'a': 1, 'b': 2, 'c': 3}
    test_list = [test_dict_1, test_dict_2]
    test_tuple = (test_dict_1, test_dict_2)

    pprint(to_namedtuple(test_dict_1))
    pprint(to_namedtuple(test_dict_2))
    pprint(to_namedtuple(test_list))
    pprint(to_namedtuple(test_tuple))

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:06:19.345506
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(
        name='to_namedtuple',
        optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS
    )

# Generated at 2022-06-23 18:06:29.223998
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    d1 = dict(a=1, b=2, c=3, d=4)
    d2 = dict(x=1, y=2, z=3)
    d3 = dict(m=d2, n=d1)
    d4 = dict(p=d3, q=d3)
    d5 = dict(r=d4, s=d1, t=d2)
    d6 = dict(u=d2, v=d5)
    d7 = dict(w=d6, x=d4, y=d5, z=d1)
    d8 = dict(a=d7, b=d6, c=d5, d=d4, e=d3, f=d2, g=d1)
    nt8 = to_

# Generated at 2022-06-23 18:06:39.661287
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test function to_namedtuple
    """
    import pytest
    from collections import (
        OrderedDict
    )
    from types import SimpleNamespace
    from flutils.validators import ValidatorError
    from flutils.namedtupleutils import to_namedtuple

    test_error_dict: dict = {'1': 1}
    with pytest.raises(ValidatorError):
        to_namedtuple(test_error_dict)

    test_dict: dict = {'a': 1, 'b': 2}
    test_result: NamedTuple = to_namedtuple(test_dict)
    assert test_result == test_dict
    assert isinstance(test_result, NamedTuple)

    test_tuple = (1, 2)
    test_result = to_namedtuple

# Generated at 2022-06-23 18:06:48.836655
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import NamedTuple, List, Tuple


    in_dic: Mapping[str, Any] = {
        'a': 1,
        'b': 2,
        'c': {'d': 3},
        'e': {'_f': 4},
        '_g': 7,
        'g': 5,
    }

    Out = NamedTuple('Out', [
        ('a', int),
        ('b', int),
        ('c', NamedTuple('c', [('d', int)])),
        ('e', NamedTuple('e', [])),
        ('g', int),
    ])

    exp = Out(
        a=1,
        b=2,
        c=Out.c(d=3),
        e=Out.e(),
        g=5,
    )

# Generated at 2022-06-23 18:06:53.798799
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a':1}) == namedtuple('NamedTuple', ['a'])(1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)


    dic = {'id': '1234', 'user': {'name': 'tom', 'org': 'fl', 'address': {'city': 'burlington', 'state': 'vt', 'zip': '05401'}}}
    _nt = to_namedtuple(dic)

    assert _nt.id == '1234'

# Generated at 2022-06-23 18:07:00.916276
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class Foo:
        pass

    dic: dict = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1

    odic = OrderedDict(dic)
    nt = to_namedtuple(odic)
    assert tuple(nt._fields) == ('a', 'b')

    lis: list = [dic, odic]
    nt = to_namedtuple(lis)
    assert nt[0].a == 1

    tup: tuple = tuple(lis)
    nt = to_namedtuple(tup)
    assert nt[0].a == 1

    ns = SimpleNamespace()
    ns.a = 1
    ns.b = 2
    nt = to_namedtuple(ns)

# Generated at 2022-06-23 18:07:12.626483
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = { 'a': 1, 'b': 2 }
    dic2 = ('a', 1)
    dic3 = { 'a': 1, 'b': 2, 'c': 3 }
    dic4 = ('a', 1, ('b', 2))
    dic5 = ('a', 1, ('b', 2, ('c', 3)))
    dic6 = { 'a': 1, 'b': 2, '_c': 3 }
    dic7 = { 'a': 1, 'b': 2, 'c': 3, '_d': 4 }
    dic8 = { 'a': 1, 'b': 2, '_c': 3, 'd': 4 }
    ret1 = to_namedtuple(dic)
    ret2 = to_namedtuple(dic2)
    ret3 = to

# Generated at 2022-06-23 18:07:24.647253
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.iterutils import to_tuple
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace
    from typing import Union
    from collections import namedtuple

    TestClass = namedtuple('TestClass', ('a', 'b', 'c', 'd'))

    TestToNamedTuple = TestClass(
        a=1,
        b=TestClass(a=3, b=42),
        c=[1, 2, 3],
        d=OrderedDict([('a', 'b'), ('c', 'd')]),
    )

    # noinspection PyTypeChecker

# Generated at 2022-06-23 18:07:32.362301
# Unit test for function to_namedtuple
def test_to_namedtuple():

    def _convert(obj: Any) -> Any:
        """Convert the given object."""
        return to_namedtuple(obj)

    assert _convert({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)


# Generated at 2022-06-23 18:07:34.582528
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = [1, 2, {'a': 1}]
    expected = ([1, 2, NamedTuple(a=1)])
    assert to_namedtuple(obj) == expected

# Generated at 2022-06-23 18:07:47.205423
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    dic2 = {'c': {'d': 3}}
    dic3 = {'f': {'g': {'h': 4}}}
    dic4 = {'i': {'j': {'k': {'l': 5}}}}
    dic5 = {'i': {'j': {'k': {'m': 6}}}}
    dic6 = {'p': {'q': {'r': {'s': {'t': {'u': {'v': 7}}}}}}}
    dic7 = {'p': {'q': {'r': {'s': {'t': [4, 4, 4]}}}}}

# Generated at 2022-06-23 18:07:58.254802
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.validators import validate_identifier
    from types import SimpleNamespace
    obj = SimpleNamespace()

    # noinspection PyUnusedLocal
    def _an_identifier_function() -> None:
        pass

    setattr(obj, '_an_identifier_function', _an_identifier_function)
    assert validate_identifier('_an_identifier_function', allow_underscore=True)
    assert not validate_identifier('_an_identifier_function', allow_underscore=False)

    # noinspection PyUnusedLocal
    def _an_identifier_method(self) -> None:
        pass

    setattr(obj, '_an_identifier_method', _an_identifier_method)

# Generated at 2022-06-23 18:08:05.028326
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase

    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-23 18:08:11.638001
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    from unittest.mock import patch
    from unittest import TestCase

    with patch(BUILTINS + '.type') as mocked_type:
        mocked_type.return_value = 'int'
        assert to_namedtuple(None) == 'int'

    obj = [1, 2, 3]
    assert to_namedtuple(obj) == obj

    obj = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    assert to_namedtuple(obj) == [
        NamedTuple(a=1, b=2),
        NamedTuple(c=3, d=4)
    ]


# Generated at 2022-06-23 18:08:24.565845
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Functional test for to_namedtuple function."""
    import pytest

    # If a value is a non-iterable that is not a string or dictionary,
    # it should raise a TypeError exception.
    with pytest.raises(TypeError):
        to_namedtuple(1)
    with pytest.raises(TypeError):
        to_namedtuple(False)
    with pytest.raises(TypeError):
        to_namedtuple(10.1)

    # A string is a non-iterable, but not a dictionary; therefore,
    # it should not raise a TypeError exception.
    assert (to_namedtuple('string') == 'string')

    # Any values that can be properly converted to a namedtuple
    # should be converted.

# Generated at 2022-06-23 18:08:31.714573
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from flutils.testutils import GenericObj

    class TestToNamedTuple(unittest.TestCase):

        def test_to_namedtuple_dict(self):
            dic = {'a': 1, 'b': 2}
            expect = GenericObj(a=1, b=2)
            actual = to_namedtuple(dic)
            self.assertEqual(expect, actual)

        def test_to_namedtuple_ordered_dict(self):
            from collections import OrderedDict

            dic = OrderedDict([('a', 1), ('b', 2)])
            expect = GenericObj(a=1, b=2)
            actual = to_namedtuple(dic)
            self.assertEqual(expect, actual)


# Generated at 2022-06-23 18:08:44.329500
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([{'a': 1, 'b': 2}, {'x': 3}]) == [
        NamedTuple(a=1, b=2),
        NamedTuple(x=3)
    ]
    assert to_namedtuple({'a': 1, 'b': 2}) == \
        NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == \
        NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == \
        NamedTuple(a=1, b=2, c=3, d=4)

# Generated at 2022-06-23 18:08:46.518465
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test function to_namedtuple
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:08:55.931258
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lst = [1, 2, 3, 4]
    assert to_namedtuple(lst) == [1, 2, 3, 4]
    lst = [{'a': 1}, {'b': 2}]
    assert to_namedtuple(lst) == [NamedTuple(a=1), NamedTuple(b=2)]
    lst = [{'a': 1}, {'b': 2}, {'c': 3, 'd': 4}]
    assert to_namedtuple(lst) == [NamedTuple(a=1), NamedTuple(b=2), NamedTuple(c=3, d=4)]
    tup = tuple(lst)

# Generated at 2022-06-23 18:09:03.845203
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from types import SimpleNamespace
    simple_dict = {'c': 1, 'b': 2, 'a': 3}
    named_tup = namedtuple('NamedTuple', sorted(simple_dict))(**simple_dict)
    assert to_namedtuple(simple_dict) == named_tup
    assert to_namedtuple(OrderedDict(simple_dict)) == named_tup
    assert to_namedtuple(named_tup) == named_tup
    assert to_namedtuple(SimpleNamespace(**simple_dict)) == named_tup

# Generated at 2022-06-23 18:09:14.054975
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    import pytest
    from flutils.namedtupleutils import to_namedtuple

    def is_namedtuple(n):
        from collections import namedtuple
        return isinstance(n, namedtuple)

    x = ['a', 1, {'a': 'b', 'c': 'd'}, ('e', 'f', 'g'), {'h': 'i'}]
    y = to_namedtuple(x)
    for n, a in enumerate(zip(y, x)):
        with pytest.raises(TypeError):
            if isinstance(a[0], list):
                assert is_namedtuple(a[0][2])
            else:
                assert is_namedtuple(a[0])
        assert a[0] == a[1]



# Generated at 2022-06-23 18:09:22.477469
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json

    mapping = {'A': 1, 'B': 2, 'C': 3, 'D': 4}
    assert json.dumps(mapping) == json.dumps(to_namedtuple(mapping))

    ordered_mapping = OrderedDict(mapping)
    assert json.dumps(ordered_mapping) == json.dumps(to_namedtuple(ordered_mapping))

    simple_object = SimpleNamespace(**mapping)
    assert json.dumps(mapping) == json.dumps(to_namedtuple(simple_object))

# Generated at 2022-06-23 18:09:34.235487
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    tup = to_namedtuple(dic)
    assert tup.a == 1
    assert tup.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    tup = to_namedtuple(dic)
    assert not hasattr(tup, '_c')

    dic = OrderedDict([('a', 1), ('b', 2), ('_c', 3)])
    tup = to_namedtuple(dic)
    assert tup[0] == 1
    assert tup[1] == 2
    assert tup[2] == 3


# Generated at 2022-06-23 18:09:41.924336
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from pprint import pprint

    from flutils.namedtupleutils import to_namedtuple

    def test_result(result: Any, expect: Any) -> bool:
        try:
            pprint(result)
        except Exception:
            pass
        assert result == expect

    expect = 'foo'
    result = to_namedtuple(expect)
    test_result(result, expect)

    expect = ['foo', 'bar']
    result = to_namedtuple(expect)
    test_result(result, expect)

    expect = ('foo', 'bar')
    result = to_namedtuple(expect)
    test_result(result, expect)

    expect = [('foo', 'bar')]
    result = to_namedtuple(expect)
    test

# Generated at 2022-06-23 18:09:51.428786
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Tests the to_namedtuple function
    """

    try:
        to_namedtuple(1)
    except TypeError as e:
        assert(e.args[0] == "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (int) 1")
    else:
        assert(False)

    data = to_namedtuple({'A': 1, 'b': 2})
    assert(data.A == 1)
    assert(data.b == 2)

    data = to_namedtuple({'A': 1, 'b': 2, 'c': {'d': 3}})
    assert(data.A == 1)
    assert(data.b == 2)
    assert(data.c.d == 3)


# Generated at 2022-06-23 18:09:56.702690
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple

    test_dict = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2, 'c': 3}, 'd': [1, 2, 3]}
    test_namedtuple = _to_namedtuple(test_dict)
    assert isinstance(test_namedtuple, namedtuple)
    assert test_namedtuple.a == 1
    assert test_namedtuple.b == 2
    assert isinstance(test_namedtuple.c, namedtuple)
    assert test_namedtuple.c.a == 1
    assert test_namedtuple.c.b == 2
   

# Generated at 2022-06-23 18:10:08.132235
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2,
        'c': {'d': 3, 'e': 4, 'f': 5},
        'g': (1, 2, 3),
        'h': [1, 2, 3]
    }
    obj = SimpleNamespace(**dic)
    expected = 'NamedTuple(a=1, b=2, c=NamedTuple(d=3, e=4, f=5), ' \
               'g=Tuple(1, 2, 3), h=[1, 2, 3])'
    out = to_namedtuple(obj)
    assert out == eval(expected)


if __name__ == '__main__':
    print(test_to_namedtuple())

# Generated at 2022-06-23 18:10:19.117060
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import json
    from unittest.mock import MagicMock
    from flutils.namedtupleutils import to_namedtuple as tnt
    from flutils.namedtupleutils import NamedTuple as _NamedTuple

    if sys.version_info < (3, 7):
        from collections import OrderedDict
    else:
        from typing import OrderedDict

    with open('tests/test_requirements.json') as f:
        requirements = json.load(f)

    data = requirements['test_to_namedtuple']

    assert data is not None

    # Test various combinations of OrderedDict and dict
    #
    # This is due to Ordered dict's internal ordering being changed
    # in Python 3.7 (Issue #26227).
    #
    # Addresses Issue #11

# Generated at 2022-06-23 18:10:30.286327
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == tuple()
    assert to_namedtuple([]) == []
    assert to_namedtuple((None,)) == (None,)
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': {'b': 2}}) == NamedTuple(a=NamedTuple(b=2))
    assert to_namedtuple({'a': {'b': '3'}}) == NamedTuple(a=NamedTuple(b='3'))

    with pytest.raises(TypeError):
        to_namedtuple('')

    with pytest.raises(TypeError):
        to_namedtuple(1)

# Generated at 2022-06-23 18:10:35.219595
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    obj = {'a': 1, 'b': 2}
    res = to_namedtuple(obj)
    assert 'NamedTuple' in str(type(res))


if __name__ == "__main__":
    pass

# Generated at 2022-06-23 18:10:44.006116
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    make = namedtuple('NamedTuple', tuple(sorted(dic.keys())))
    # noinspection PyTypeChecker
    expected = make(1, 2)
    res = to_namedtuple(dic)
    assert res == expected
    assert res.a == 1
    assert res.b == 2

    dic = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    make = namedtuple('NamedTuple', tuple(sorted(dic.keys())))
    d2 = dic['c']  # type: Dict
    make2 = namedtuple('NamedTuple', tuple(sorted(d2.keys())))
    # noinspection PyTypeChecker

# Generated at 2022-06-23 18:10:54.535948
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from pprint import pprint

    test_dic = {'a': 1, 'b': 2}
    test_od = OrderedDict(test_dic)
    test_od['c'] = 3
    test_od['d'] = to_namedtuple({'e': 5, 'f': 6})
    test_od['g'] = [{'h': 7}]
    test_od['i'] = to_namedtuple(test_od['d'])
    test_od['j'] = to_namedtuple(test_od['i'])
    make_tuple = namedtuple('TestTuple', ['t1', 't2'])

# Generated at 2022-06-23 18:11:05.644618
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for :obj:`flutils.namedtupleutils.to_namedtuple`."""
    from collections import OrderedDict
    from types import SimpleNamespace
    import pytest

    # Convert a list of ints to a tuple
    obj = [0, 1, 2, 3]
    expected = (0, 1, 2, 3)
    actual = to_namedtuple(obj)
    assert actual == expected

    # Convert a list of lists to a tuple
    obj = [[0, 1], [2, 3]]
    expected = ((0, 1), (2, 3))
    actual = to_namedtuple(obj)
    assert actual == expected

    # Convert a dict to a NamedTuple
    obj = {'a': 1, 'b': 2}

# Generated at 2022-06-23 18:11:14.154126
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime

    # Mapping
    dic = {
        'a': 1,
        'b': 2,
    }
    assert to_namedtuple(dic).a == 1
    assert to_namedtuple(dic).b == 2

    # Mapping with identifers that conflict with built-in identifiers
    dic = {
        'and': 1,
        'class': datetime.now(),
    }

# Generated at 2022-06-23 18:11:24.128006
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # TypeError raised
    m = 1
    with pytest.raises(TypeError):
        to_namedtuple(m)

    # Convert a dict to a namedtuple
    d = {'a': 1, 'b': 2}
    nt = to_namedtuple(d)
    assert nt.a == 1
    assert nt.b == 2

    # Convert a sequence to namedtuple(s)
    t = (1, 2, 3)
    t2 = to_namedtuple(t)
    assert t[0] == t2[0]
    assert t[1] == t2[1]
    assert t[2] == t2[2]

    l = [1, 2, 3]
    l2 = to_namedtuple(l)
    assert l[0] == l2

# Generated at 2022-06-23 18:11:33.204254
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dct = {
        'foo': {
            'bar': 'baz',
            'func': {
                'data': 'info'
            }
        }
    }
    tpl = to_namedtuple(dct)
    assert tpl.foo.bar == 'baz'
    assert tpl.foo.func.data == 'info'

    dct = {'a': 1, 'b': 2}
    tpl = to_namedtuple(dct)
    assert tpl.a == 1
    assert tpl.b == dct['b']

    dct = OrderedDict(a=1, b=2)
    tpl = to_namedtuple(dct)
    assert tpl[0] == 1  # type: ignore[index]
    assert tpl[1] == 2 

# Generated at 2022-06-23 18:11:43.918746
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple',
                                                         'a b')(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == \
        namedtuple('NamedTuple', 'a b c d')(1, 2, 3, 4)
    assert to_namedtuple({'a': 1, 'b': 2}, {'c': 3, 'd': 4}) == \
        namedtuple('NamedTuple', 'a b c d')(1, 2, 3, 4)
    assert to_namedtuple({'a': 1, 'b': 2}, {'c': 3, 'd': 4}) == \
        (1, 2, 3, 4)

# Generated at 2022-06-23 18:11:49.117687
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    tup = (1, 2, 3)
    listt = [2, 3, 4]
    print(to_namedtuple(dic) == dic)
    print(to_namedtuple(tup) == tup)
    print(to_namedtuple(listt) == listt)

test_to_namedtuple()

# Generated at 2022-06-23 18:11:59.232752
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from pprint import pprint
    from flutils.namedtupleutils import to_namedtuple

    # Standard Dictionary
    dic = {'a': 1, 'b': 2}
    # OrderedDict
    odic = OrderedDict({'a': 1, 'b': OrderedDict({'b': 2, 'a': 1}), 'c': 3})
    # List
    li = [{'a': 1, 'b': 2}, {'a': 2, 'b': 3}]
    # Tuple
    tup = ({'a': 1, 'b': 2}, {'a': 2, 'b': 3})

    # -------
    # Standard Dictionary (`dict`)
    # -------
    print('Standard Dictionary (`dict`)')

# Generated at 2022-06-23 18:12:11.675183
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pytest import raises
    from unittest.mock import Mock
    from collections import ordereddict
    from types import SimpleNamespace
    # Assert a list returns a list with namedtuple attributes
    obj: list = [{'a': 1, 'b': 2}, 'string', {'c': [{'d': 4}]}]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert isinstance(out[0], namedtuple)
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[1] == 'string'
    assert isinstance(out[2], namedtuple)
    assert out[2].c[0].d == 4
    # Assert a tuple returns a tuple with namedtuple attributes

# Generated at 2022-06-23 18:12:20.973908
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    obj = [{'a': 1}, {'b': 1}]
    assert to_namedtuple(obj) == [NamedTuple(a=1), NamedTuple(b=1)]
    assert to_namedtuple(tuple(obj)) == (NamedTuple(a=1), NamedTuple(b=1))
    assert to_namedtuple({'a': 1, 'b': 1}) == NamedTuple(a=1, b=1)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 1)])) \
        == NamedTuple(a=1, b=1)

# Generated at 2022-06-23 18:12:29.769933
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _Started = SimpleNamespace(started=True)
    _Unstarted = SimpleNamespace(started=False)

    with pytest.raises(TypeError):
        _to_namedtuple(None, _Started)
    with pytest.raises(TypeError):
        _to_namedtuple(None, _Unstarted)
    with pytest.raises(TypeError):
        _to_namedtuple(None)

    _to_namedtuple([])
    _to_namedtuple(tuple(), _Started)
    _to_namedtuple(tuple(), _Unstarted)
    _to_namedtuple(tuple())

    _to_namedtuple(dict(), _Started)
    _to_namedtuple(dict(), _Unstarted)
    _to_namedtuple(dict())

# Generated at 2022-06-23 18:12:38.816945
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:12:50.804809
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """."""
    from functools import reduce
    import operator as opr
    dic = {
        'a': 1,
        'b': 2,
        'c': {'d': 3, 'e': 4},
        'f': [5, 6, 7.0, {'g': 8}],
    }
    dic_expected = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', (NamedTuple(d=3, e=4))),
        ('f', [5, 6, 7.0, (NamedTuple(g=8))]),
    ])
    output: OrderedDict[str, Any] = OrderedDict(to_namedtuple(dic))

    assert dic != output
    assert dic_expected == output
   

# Generated at 2022-06-23 18:13:01.582914
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pathlib
    import importlib
    import unittest
    import sys
    import flutils.namedtupleutils
    ut_path = pathlib.Path(flutils.namedtupleutils.__file__)
    ut_path = ut_path.parent.parent / 'ut' / 'test_namedtupleutils.py'
    ut = importlib.import_module(name='.ut.test_namedtupleutils', package='flutils')
    suite = unittest.TestLoader().loadTestsFromModule(ut)
    runner = unittest.TextTestRunner(stream=sys.stdout, verbosity=2)
    result = runner.run(suite)
    assert result.wasSuccessful()

# Generated at 2022-06-23 18:13:12.037346
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == type(NamedTuple(a=1, b=2))

    dic = {'a': 1, 'b': 2, 'c': ({'d': 3}, [1, 2, 3])}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=(NamedTuple(d=3), [1, 2, 3]))

    tuple_1 = (1, 2, 3)
    assert to_namedtuple(tuple_1) == (1, 2, 3)

# Generated at 2022-06-23 18:13:19.117612
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections as cl

    # convert list --> list
    assert to_namedtuple([1, 2]) == [1, 2]

    # convert tuple --> tuple
    assert to_namedtuple((1, 2)) == (1, 2)

    # convert dict --> dict
    assert to_namedtuple(dict(a=1, b=2)) == cl.namedtuple(
        'NamedTuple', ['a', 'b'])(a=1, b=2)

    # convert OrderedDict --> dict
    assert to_namedtuple(cl.OrderedDict(a=1, b=2)) == cl.namedtuple(
        'NamedTuple', ['a', 'b'])(a=1, b=2)

    # convert dict --> dict nested

# Generated at 2022-06-23 18:13:27.549693
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from collections import OrderedDict
    from types import SimpleNamespace

    # Basic conversions
    lst = [1, 2, 3]
    tpl = tuple(lst)
    dic = {'a': 1, 'b': 2}
    od = OrderedDict(dic)
    ntupl = SimpleNamespace(a=1, b=2)
    assert to_namedtuple(lst) == lst
    assert to_namedtuple(tpl) == tpl
    assert to_namedtuple(dic) == cast(NamedTuple, dic)
    assert to_namedtuple(od) == cast(NamedTuple, od)

# Generated at 2022-06-23 18:13:35.180877
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils
    from flutils.namedtupleutils import to_namedtuple

    assert flutils.namedtupleutils.to_namedtuple == to_namedtuple

    assert to_namedtuple(None) is None

    assert to_namedtuple('abc') == 'abc'

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    odic = OrderedDict(a=1, b=2)
    nt = to_namedtuple(odic)
    assert nt.a == 1
    assert nt.b == 2


# Generated at 2022-06-23 18:13:44.812681
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple

    class MyNamedTuple(namedtuple('MyNamedTuple', ['one'])):
        pass


# Generated at 2022-06-23 18:13:50.738263
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    assert(to_namedtuple({}) == NamedTuple())
    assert(to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2))
    assert(
        to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
        == NamedTuple(a=1, b=2)
    )
    assert(to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)])

# Generated at 2022-06-23 18:14:03.305560
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == obj
    obj = {'a': 1, 'b': {'c': 3, 'd': 4}}
    assert to_namedtuple(obj) == obj
    obj = [1, 2, 3]
    assert to_namedtuple(obj) == obj
    obj = (1, 2, 3)
    assert to_namedtuple(obj) == obj
    obj = [1, 2, 3]
    assert to_namedtuple(obj) == obj
    obj = [1, 2, 3]
    assert to_namedtuple(obj) == obj


# Generated at 2022-06-23 18:14:13.278402
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from string import ascii_uppercase
    from unittest import TestCase
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import SyntaxError, validate_identifier

    class MockNamedTuple(NamedTuple):
        _fields: List[str]

    class TestToNamedTuple(TestCase):

        def test_to_namedtuple(self):
            """
            Ensure it raises a TypeError when given type is not list, tuple, or
            dict
            """
            with self.assertRaises(TypeError):
                to_namedtuple(1)


# Generated at 2022-06-23 18:14:16.719288
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {"foo": 2, "bar": 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ['foo', 'bar'])(2, 3)


# Generated at 2022-06-23 18:14:29.060396
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from flutils.namedtupleutils import _
    assert to_namedtuple == _
    assert _to_namedtuple == _
    assert _to_namedtuple(1) is 1
    assert _to_namedtuple(1, True) is 1
    assert _to_namedtuple('_A', True).capitalize() == '_A'
    assert _to_namedtuple('_A', False) is '_A'
    assert _to_namedtuple((1, 2)) == (1, 2)
    assert _to_namedtuple([1, 2]) == [1, 2]

# Generated at 2022-06-23 18:14:36.690047
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    print(to_namedtuple(dic))
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)

    class Foo(NamedTuple):
        a: int
        b: int

    assert to_namedtuple(Foo(1, 2)) == namedtuple('NamedTuple', 'a b')(1, 2)

# Generated at 2022-06-23 18:14:40.746930
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.tests import assert_functions_equivalent
    assert_functions_equivalent(to_namedtuple, _to_namedtuple)

# Generated at 2022-06-23 18:14:53.051941
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, '_b': 2, 'B': 3, '-c': 4, 'C': 5}
    assert to_namedtuple(dic) == NamedTuple(a=1, B=3, C=5)

    class _A:
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def __hash__(self):
            return hash((self.a, self.b))
        def __eq__(self, other):
            return (self.a, self.b) == (other.a, other.b)

# Generated at 2022-06-23 18:15:02.412798
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        namedtuple,
        OrderedDict,
    )
    from types import SimpleNamespace

    class _Dummy(namedtuple('_Dummy', 'a, b')):
        pass

    assert _Dummy(1, 2) == to_namedtuple({'a': 1, 'b': 2})
    assert _Dummy(1, 2) == to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert _Dummy(1, 2) == to_namedtuple({'b': 2, 'a': 1})
    assert _Dummy(1, 2) == to_namedtuple(SimpleNamespace(a=1, b=2))

    # Ensure complex objects
    inner = _Dummy(3, 4)
    assert inner == to_named

# Generated at 2022-06-23 18:15:15.018260
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert out.a == 1
    assert out.b == 2
    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert out.a == 1
    assert out.b == 2
    dic = {'a': 1, '_invalid_': 2}
    out = to_namedtuple(dic)
    assert isinstance

# Generated at 2022-06-23 18:15:25.767634
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _test_to_namedtuple(obj: _AllowedTypes, expected: Any):
        # noinspection PyTypeChecker
        assert to_namedtuple(obj) == expected  # type: ignore[comparison-overlap]


    # noinspection PyTypeChecker
    _test_to_namedtuple(
        {
            'a': 1,
            'b': {'c': [{'d': 2}, {'d': 3}, {'d': 4}]},
            'e': 5
        },
        NamedTuple(a=1, b=NamedTuple(c=(
            NamedTuple(d=2),
            NamedTuple(d=3),
            NamedTuple(d=4))), e=5)
    )


# Generated at 2022-06-23 18:15:36.675361
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # For coverage
    # pylint: disable=unused-variable

    dic = {'a': 1, 'b': 2}
    named = to_namedtuple(dic)
    assert named.a == 1

    dic = {'a': 1, 'b': 2, 15: '15'}
    named = to_namedtuple(dic)
    assert named.a == 1

    dic = {'a': 1, 'b': '2'}
    named = to_namedtuple(dic)
    assert named.b == '2'

    dic = {'a': 1, 'b': '2', '_x': '3'}
    named = to_namedtuple(dic)
    assert hasattr(named, '_x')


# Generated at 2022-06-23 18:15:47.705274
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    def test(obj):
        ntuple = to_namedtuple(obj)
        print(ntuple)
        print(ntuple.__dict__)
        print(ntuple._fields)
        print(obj)

    test(dict(a=1, b=2))
    test(OrderedDict(a=1, b=2))
    test(SimpleNamespace(a=1, b=2))
    test(SimpleNamespace(b=2, a=1))
    test(SimpleNamespace(a=dict(c=1)))
    test(SimpleNamespace(a=OrderedDict(c=1)))
    test(SimpleNamespace(a=SimpleNamespace(c=1)))

# Generated at 2022-06-23 18:15:51.131957
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == (1, 2)

# Generated at 2022-06-23 18:15:59.949874
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection SpellCheckingInspection
    obj = {'key1': 1, 'key2': [{'_key3': 3, '_key4': 4}, {'_key': 5}], 'key6': 6}
    assert to_namedtuple(obj) == namedtuple('NamedTuple', 'key1 key2 key6')(
        1,
        namedtuple('NamedTuple', 'key3 key4')(
            3,
            4,
        ),
        6,
    )
    # noinspection SpellCheckingInspection
    obj = {'_key1': 1, '_key2': [{'key3': 3, 'key4': 4}, {'key': 5}], '_key6': 6}

# Generated at 2022-06-23 18:16:00.969949
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:16:09.129098
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    od = OrderedDict({'a': 1, 'b': 2, 'c': 3})
    assert to_namedtuple(od) == NamedTuple(a=1, b=2, c=3)
    od = {'ab': 1, '_a': 3, 'a': 2, 'b': 4}
    assert to_namedtuple(od)