

# Generated at 2022-06-23 18:06:23.944657
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def test_val(val):
        # noinspection PyUnusedLocal
        def test_obj_to_namedtuple(obj):
            obj_str = repr(obj)
            obj_out = repr(to_namedtuple(obj))
            print(f'\n{obj_str}\n{obj_out}\n')
        for key, val2 in val.items():
            if isinstance(val2, dict):
                setattr(val, key, test_val(val2))
        return val
    x = test_val({
        'a': {
            'b': {
                'c': [
                    {'d': 1},
                    {'e': 2},
                    {'f': 3},
                ],
            },
        },
    })
    obj = x.a.b.c  # type

# Generated at 2022-06-23 18:06:34.485022
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from flutils.constants import TEST_STRING
    from flutils.py23utils import PY2

    sns = SimpleNamespace
    snt = namedtuple('NamedTuple', '')
    dic = {TEST_STRING: 1, 'b': 2}
    odic = OrderedDict(sorted(dic.items(), key=lambda x: x[0], reverse=True))
    out = to_namedtuple(dic)
    assert hasattr(out, 'a')
    assert out.a == dic[TEST_STRING]
    out = to_namedtuple(odic)
    assert 'b' in out._fields
    assert out.b == dic['b']


# Generated at 2022-06-23 18:06:41.496001
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None

    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('A', ('a', 'b'))(1, 2)
    assert to_namedtuple({'a': 1, 'b': 'c'}) == namedtuple('A', ('a', 'b'))(1, 'c')
    assert to_namedtuple({'a': 1, 'b': [{'d': 4, 'e': 5}, {'f': 6, 'g': 7}]}) == \
           namedtuple('A', ('a', 'b'))(1, [namedtuple('D', ('d', 'e'))(4, 5),
                                          namedtuple('F', ('f', 'g'))(6, 7)])

# Generated at 2022-06-23 18:06:52.861403
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()

    expected = namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == expected

    expected = namedtuple('NamedTuple', ('b', 'a'))(1, 2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == expected

    expected = namedtuple('NamedTuple', ('a', 'b', 'c'))(1, 2, 3)
    assert to_namedtuple(OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
    ])) == expected

    assert to_namedtuple

# Generated at 2022-06-23 18:07:01.229970
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from . import TestCaseUtils

    class TestToNamedtuple(TestCase, TestCaseUtils):

        def test_to_namedtuple(self):
            from collections import OrderedDict

            dic = OrderedDict()
            dic['a'] = 1
            dic['b'] = 2
            dic['c'] = dic.copy()
            out = to_namedtuple(dic)
            self.assertIsInstance(out, namedtuple('NamedTuple', 'a b c'))
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)
            self.assertEqual(out.c, out)

            dic = OrderedDict()
            dic['a'] = 1
           

# Generated at 2022-06-23 18:07:08.304985
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    import unittest
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple as _NamedTuple

    class A(_NamedTuple):
        b: int

    class B(_NamedTuple):
        c: int

    class C(_NamedTuple):
        d: int

    class D(_NamedTuple):
        e: int

    a: A = A(b=1)
    b: B = B(c=2)
    c: C = C(d=3)
    d: D = D(e=4)

    test_data = list()
    data1 = [a, b]

# Generated at 2022-06-23 18:07:18.272801
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(dict(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(OrderedDict(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)

# Generated at 2022-06-23 18:07:29.933962
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import math
    import cmath
    def isclose(a, b, rel_tol=1e-09, abs_tol=0.0):
        return abs(a-b) <= max(rel_tol * max(abs(a), abs(b)), abs_tol)
    assert isclose(to_namedtuple([[math.pi, math.pi/2], [math.pi/3, math.pi/4]])._0._0, 3.141592653589793)
    assert isclose(to_namedtuple([[math.pi, math.pi/2], [math.pi/3, math.pi/4]])._0._1, 1.5707963267948966)

# Generated at 2022-06-23 18:07:42.430655
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Lists
    data = ['a', 'b', 'c']
    out = to_namedtuple(data)
    assert type(out) == list
    assert out == ['a', 'b', 'c']
    data = ['a', {'b': 'c'}, 'd', ['e', ['f', 'g']]]
    out = to_namedtuple(data)
    assert type(out) == list
    assert out == ['a', namedtuple('NamedTuple', ['b'])('c'), 'd',
                   ['e', ['f', 'g']]]
    data = ('a', 'b', 'c')
    out = to_namedtuple(data)
    assert type(out) == tuple
    assert out == ('a', 'b', 'c')

# Generated at 2022-06-23 18:07:51.597200
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple.
    """
    dct = {'a': 1, 'b': 2}
    nt = to_namedtuple(dct)
    assert isinstance(nt, NamedTuple)
    assert len(nt) == 2
    assert nt[0] == 1
    assert nt.a == 1
    assert nt.b == 2

    tup = (1, 2, 3)
    nt = to_namedtuple(tup)
    assert isinstance(nt, tuple)
    assert nt == tup

    lst = [1, 2, 3]
    nt = to_namedtuple(lst)
    assert isinstance(nt, list)
    assert nt == lst

    from collections import OrderedDict
    dct = OrderedD

# Generated at 2022-06-23 18:07:52.445663
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-23 18:08:01.312093
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (
        'NamedTuple(a=1, b=2)'
    )
    assert to_namedtuple(dic) != (
        'NamedTuple(a=2, b=2)'
    )
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == (
        '(1, 2, 3)'
    )
    assert to_namedtuple(tup) != (
        '(1, 3, 3)'
    )
    list1 = [1, 2, 3]
    assert to_namedtuple(list1) == (
        '[1, 2, 3]'
    )

# Generated at 2022-06-23 18:08:12.142020
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pathlib import Path
    from flutils.pathutils import file2path
    import json

    import pytest

    # Helper Functions
    def get_sample_data(filename: str) -> Union[List, Tuple, Mapping]:
        filepath = Path(str(file2path(__file__)))
        filepath /= 'test_data'
        filepath /= filename
        with open(str(filepath)) as fp:
            return json.load(fp)

    def _recursive_ns(obj: Any) -> bool:
        if isinstance(obj, (list, tuple)):
            for item in obj:
                if isinstance(item, (list, tuple, Mapping)):
                    if _recursive_ns(item) is True:
                        continue
                return False

# Generated at 2022-06-23 18:08:24.981081
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.tests.common import (
        TestList,
        TestMapping,
        TestOrderedMapping,
        TestOrderedTuple,
        TestSequence,
        TestSimpleNamespace,
        TestTuple,
    )

    # Test sequences and mappings
    lst = list(TestList)
    assert isinstance(to_namedtuple(lst), list)
    assert all(isinstance(x, NamedTuple) for x in to_namedtuple(lst))
    assert to_namedtuple(lst) == TestList

    odt = TestOrderedTuple()
    assert isinstance(to_namedtuple(odt), tuple)
    assert all(isinstance(x, NamedTuple) for x in to_namedtuple(odt))

# Generated at 2022-06-23 18:08:30.799758
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple('')
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == NamedTuple('')
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple(NamedTuple(a=1)) == NamedTuple(a=1)
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple(('a', 1, 'b', 2)) == NamedTuple(a=1, b=2)
    assert to_named

# Generated at 2022-06-23 18:08:43.731421
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == [
        NamedTuple(a=1, b=2),
        NamedTuple(a=3, b=4),
    ]
    assert str(to_namedtuple({'a': 1, 'b': 2})) == 'NamedTuple(a=1, b=2)'
    assert str(to_namedtuple((1, 2))) == 'NamedTuple(1, 2)'
    assert str(to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))) == 'NamedTuple(a=1, b=2)'

# Generated at 2022-06-23 18:08:54.312997
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from collections import (
        namedtuple,
        OrderedDict,
    )
    from types import SimpleNamespace

    from flutils.namedtupleutils import to_namedtuple

    class Test_to_namedtuple(unittest.TestCase):

        def test_tuple(self):
            dt = namedtuple('NamedTuple', 'a b c')
            tpl = (1, 2, 3)
            obj = (1, 2, dt(1, 2, 3), 4)
            out = to_namedtuple(obj)
            self.assertEqual(out, (1, 2, dt(a=1, b=2, c=3), 4))
            self.assertEqual(type(out), tuple)

# Generated at 2022-06-23 18:08:58.065847
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2, 'c': {'D': 3, 'E.F': 4}}
    expected = OrderedDict()
    expected['a'] = 1
    expected['b'] = 2
    expected['c'] = OrderedDict()
    expected['c']['D'] = 3
    expected['c']['E'] = OrderedDict()
    expected['c']['E']['F'] = 4
    assert to_namedtuple(dic) == expected

# Generated at 2022-06-23 18:09:09.380554
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    d1 = {'a': 1, 'b': 2}
    n1: NamedTuple = to_namedtuple(d1)
    assert n1.a == 1
    assert n1.b == 2
    d2 = {'c': 3, 'd': 4}
    n2: NamedTuple = to_namedtuple(d2)
    assert n2.c == 3
    assert n2.d == 4
    d3 = {'e': n1, 'f': n2}
    n3: NamedTuple = to_namedtuple(d3)
    assert n3.e.a == 1
    assert n3.e.b == 2
    assert n3.f.c == 3
    assert n3.f.d == 4

# Generated at 2022-06-23 18:09:15.391017
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    div = OrderedDict([('class', 'top'), ('style', 'width:100%')])
    table = OrderedDict([('a', 1), ('b', 2), ('div', div)])
    s = OrderedDict([('a', 1), ('b', 2), ('table', table)])
    struct = to_namedtuple(s)
    assert struct.table.div.style == 'width:100%'


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:09:25.413237
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    li = [1, 2, 3]
    assert to_namedtuple(li) == [1, 2, 3]
    tu = (1, 2, 3)
    assert to_namedtuple(tu) == (1, 2, 3)
    dic = {'a': {'b': 1}, 'c': {'d': 2}, 'e': [1, 2, 3]}
    assert to_namedtuple(dic)

# Generated at 2022-06-23 18:09:35.233960
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from pyutils.namedtupleutils import namedtuple_decorator


# Generated at 2022-06-23 18:09:46.324264
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from itertools import product
    from collections import OrderedDict
    from collections.abc import Iterable
    from types import SimpleNamespace
    from typing import List, Tuple, List
    from unittest.mock import MagicMock
    from unittest.mock import call
    import pytest
    mock = MagicMock()
    to_namedtuple = _to_namedtuple(mock)
    for tup in product((True, False), repeat=2):
        mock.reset_mock()
        (is_iterable, is_mapping) = tup
        obj = [] if is_iterable else {}
        if not is_iterable:
            cast_obj = obj
        else:
            cast_obj = cast(List, obj)
        if is_mapping:
            cast_obj = cast

# Generated at 2022-06-23 18:09:55.268221
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
        },
        'f': [5, 6, 7],
    }
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert type(nt.c) == namedtuple('NamedTuple', 'd e')
    assert nt.c.d == 3
    assert nt.c.e == 4
    assert type(nt.f) == list
    assert type(nt.f[0]) == int
    assert type(nt.f[1]) == int
    assert type(nt.f[2]) == int
    assert nt.f[0] == 5

# Generated at 2022-06-23 18:10:07.076540
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from types import SimpleNamespace

    d = {'a': 1, 'b': 2}
    make = namedtuple('NamedTuple', 'a b')
    res = make(1, 2)
    assert to_namedtuple(d) == res

    sns = SimpleNamespace(**d)
    assert to_namedtuple(sns) == res

    lst = [d, d]
    assert to_namedtuple(lst) == [res, res]

    lst = (d, d)
    assert to_namedtuple(lst) == (res, res)

    lst = lst, lst
    assert to_namedtuple(lst) == ((res, res), (res, res))

    d['_m'] = 3
    assert to_

# Generated at 2022-06-23 18:10:14.446614
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.testhelpers import unittest
    from flutils.namedtupleutils import to_namedtuple

    class Test(unittest.TestCase):
        def test_to_namedtuple(self):
            dic = OrderedDict(a=1, b=[2, 3], c=dict(d=4, e=5, f=6))
            tup = to_namedtuple(dic)
            self.assertEqual(repr(tup), "NamedTuple(a=1, b=[2, 3], c=NamedTuple(d=4, e=5, f=6))")
            self.assertEqual(tup.a, 1)
            self.assertEqual(tup.b, [2, 3])

# Generated at 2022-06-23 18:10:25.835328
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import randint

    from flutils.namedtupleutils import to_namedtuple

    def _make_res(obj: Any) -> Tuple[Any, ...]:
        return obj, type(obj), obj._fields

    def _get_fields(obj: Any) -> Tuple[str, ...]:
        return tuple(sorted(obj._fields))

    def _make_lst_of_dics(n: int) -> List:
        return [
            OrderedDict([
                ('age', randint(10, 99)),
                ('name', Name.NAME_LIST[randint(0, len(Name.NAME_LIST) - 1)])
            ]) for _ in range(n)
        ]


# Generated at 2022-06-23 18:10:26.533217
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-23 18:10:37.173070
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import time
    from flutils.namedtupleutils import to_namedtuple

    dic = {
        'a': 11,
        'b': Counted('b'),
        '_c': Counted('d', 0),
        'e': Counted('f', 1),
        'c': Counted('g', 1),
        'f': {
            'h': Counted('h'),
            '_i': Counted('h', 0),
            'j': Counted('h', 1),
            'i': Counted('h', 1)
        },
    }

    out = to_namedtuple(dic)

    assert isinstance(out, namedtuple('NamedTuple', 'a b c e f'))
    assert out.a == 11
    assert type(out.b) == Counted

# Generated at 2022-06-23 18:10:49.408004
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import sys
    import pytest
    from typing import Any, Dict

    class TestToNamedTuple(unittest.TestCase):
        """Test for function to_namedtuple."""

        def test_to_namedtuple_with_dict(self):
            """Test function to_namedtuple with a dict."""
            obj = {'a': 1, 'b': 2}
            # noinspection PyTypeChecker
            expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
            actual = to_namedtuple(obj)
            self.assertEqual(expected, actual)


# Generated at 2022-06-23 18:10:58.537915
# Unit test for function to_namedtuple
def test_to_namedtuple():

    def _run(obj: _AllowedTypes, expected: Any) -> bool:
        out = to_namedtuple(obj)
        match = (out == expected)
        if not match:
            print(
                "Expected: (%r) %s" %
                (type(expected).__name__, expected)
            )
            print(
                "Received: (%r) %s" %
                (type(out).__name__, out)
            )
        return match


# Generated at 2022-06-23 18:11:04.234371
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from dataclasses import dataclass
    from types import SimpleNamespace
    try:
        from collections.abc import Mapping
    except ImportError:
        from collections import Mapping
    from flutils.miscutils import to_namedtuple

    # test a tuple
    my_tup = to_namedtuple(('a', 'b', 'c'))
    assert isinstance(my_tup, tuple)
    assert my_tup == ('a', 'b', 'c')
    assert my_tup[0] == 'a'
    assert my_tup[1] == 'b'
    assert my_tup[2] == 'c'

    # test a tuple with a list

# Generated at 2022-06-23 18:11:13.173589
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = dict(a=1, b=2, c=3, d=4)
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3
    assert out.d == 4

    dic = dict(a='a', b='b', c='c', d='d')
    out = to_namedtuple(dic)
    assert out.a == 'a'
    assert out.b == 'b'
    assert out.c == 'c'

# Generated at 2022-06-23 18:11:23.566872
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for function to_namedtuple() """
    from flutils.namedtupleutils import to_namedtuple
    tpl = (0, 0, 1, 1)
    result = to_namedtuple(tpl)
    assert isinstance(result, tuple)
    assert result == (0, 0, 1, 1)
    tpl = (0, (0, 1), 1, 1)
    result = to_namedtuple(tpl)
    assert isinstance(result, tuple)
    assert result == (0, (0, 1), 1, 1)
    tpl = (0, (0, (1,)), 1, 1)
    result = to_namedtuple(tpl)
    assert isinstance(result, tuple)
    assert result == (0, (0, (1,)), 1, 1)


# Generated at 2022-06-23 18:11:32.877830
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections.abc import MutableMapping
    from operator import attrgetter
    from flutils.namedtupleutils import _to_namedtuple
    from flutils.validators import validate_identifier
    import pytest

    rval = _to_namedtuple(tuple())
    assert rval == tuple()

    rval = _to_namedtuple(list())
    assert rval == list()

    dic = {'a': 1, 'b': 2}
    out = _to_namedtuple(dic)
    assert validate_identifier(out.__class__.__name__)
    assert out == dic

    dic = OrderedDict(a=1, b=2)
    out = _to_namedtuple(dic)
    assert validate_

# Generated at 2022-06-23 18:11:42.852255
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.tests.namedtuple_testdata import (
        namedtuple_test_data,
    )
    from flutils.namedtupleutils import to_namedtuple

    for testcase in namedtuple_test_data():

        print('\n%s' % testcase.explanation)
        print('Input: %r' % testcase.input)
        print('Result: %r' % testcase.result)
        if testcase.exception is not None:
            print('Expected exception: %s' % testcase.exception)
        else:
            print('Expected: %r' % testcase.output)

        if testcase.exception is not None:
            with pytest.raises(testcase.exception):
                assert to_namedtuple(testcase.input) == testcase

# Generated at 2022-06-23 18:11:54.341406
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:12:01.345389
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import is_namedtuple

    assert is_namedtuple(to_namedtuple([1, 2, 3])) is False
    assert is_namedtuple(to_namedtuple((1, 2, 3))) is False
    assert is_namedtuple(to_namedtuple(OrderedDict([('a', 1), ('b', 2)])))
    assert is_namedtuple(to_namedtuple({'a': 1, 'b': 2}))
    assert is_namedtuple(to_namedtuple({'__': 1, 'a': 2}))

# Generated at 2022-06-23 18:12:13.178429
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Example 1: Converts mapping to a NamedTuple by default.
    obj = {'a': 1, 'b': 2}
    nt = to_namedtuple(obj)
    assert nt.a == 1
    assert nt.b == 2

    # Example 2: Converts OrderedDict to a NamedTuple sorted in original order.
    import collections
    obj = collections.OrderedDict((('a', 1), ('b', 2)))
    nt = to_namedtuple(obj)
    assert nt.a == 1
    assert nt.b == 2
    assert nt[0] == 1
    assert nt[1] == 2
    assert nt[-1] == 2
    assert nt[-2] == 1

    # Example 3: Converts list of tuple to a NamedTuple


# Generated at 2022-06-23 18:12:24.222196
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit tests for to_namedtuple()
    """
    import pytest
    from typing import (
        Any as _Any,
        Dict as _Dict,
        List as _List,
        NamedTuple as _NamedTuple,
        Optional as _Optional,
        Tuple as _Tuple,
        Union as _Union,
    )
    from collections import (
        OrderedDict as _OrderedDict,
    )


# Generated at 2022-06-23 18:12:29.576861
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    with pytest.raises(TypeError):
        assert to_namedtuple({}) == 'foo'
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)

# Generated at 2022-06-23 18:12:37.344688
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from .namedtupleutils import to_namedtuple as tnt
    assert tnt([1, 2]) == [1, 2]
    assert tnt((1, 2)) == (1, 2)
    assert tnt({'a': 1, 'b': 1}) == tnt(a=1, b=1)
    d = tnt({'a': tnt(b=1, c=2, d=3)})
    assert d.a.b == 1
    assert d.a.c == 2
    assert d.a.d == 3
    assert d.a == tnt(b=1, c=2, d=3)

# Generated at 2022-06-23 18:12:46.573979
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    dic = {'a': 1, 'b': 2}
    nto = to_namedtuple(dic)
    assert nto == cast(NamedTuple, nto)(a=1, b=2)
    nto2 = to_namedtuple(nto)
    assert nto is nto2
    dic = {1: 'a', 2: 'b'}
    nto = to_namedtuple(dic)
    assert nto == cast(NamedTuple, nto)(_1='a', _2='b')
    nto2 = to_namedtuple(nto)
    assert nto is nto2
    dic = {'a': 1, 'b': 2, '_c': 3}

# Generated at 2022-06-23 18:12:56.303838
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple."""

    import datetime
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-23 18:13:06.442105
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple

    def assert_contains(
            dct: Mapping,
            key: str,
            val: Any
    ) -> None:
        for k, v in dct.items():
            if k == key:
                assert v == val
                return
        assert 0, "Key (%r) not found in dictionary: %r" % (key, dct)

    # Test an empty dict
    assert to_namedtuple({}) == NamedTuple()

    # Test a dictionary with two keys
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:13:16.084840
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('tuple', ('a', 'b'))(a=1, b=2)


    class MyClass:
        my_attr = 'foo'
    dic = {'a': 1, 'b': 2, 'c': MyClass}
    assert to_namedtuple(dic) == namedtuple('tuple', ('a', 'b'))(a=1, b=2)


    dic = OrderedDict()
    dic['b'] = 2
    dic['a'] = 1

# Generated at 2022-06-23 18:13:26.676032
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pathlib
    import sys
    import unittest

    from flutils.logutils import (
        BraceStyleAdapter,
        init_logging,
    )
    import flutils.namedtupleutils as flnt

    if str is not bytes:
        # noinspection PyShadowingBuiltins
        str = str

    TEST_BASE_PATH = \
        pathlib.Path(sys.modules['__main__'].__file__).parent / 'test_data'
    TEST_INI_PATH = TEST_BASE_PATH / 'logging.ini'
    init_logging(config_path=TEST_INI_PATH)
    logger = BraceStyleAdapter(__name__)

    class ToNamedTupleTestCase(unittest.TestCase):

        def setUp(self):
            pass



# Generated at 2022-06-23 18:13:39.188498
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'b a')(2, 1)

    odic = OrderedDict(a=1, b=2)
    assert to_namedtuple(odic) == namedtuple('NamedTuple', 'a b')(1, 2)

    dic = {'a': SimpleNamespace(b=1)}

# Generated at 2022-06-23 18:13:49.597338
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print("Testing to_namedtuple")
    dic: dict = {'a': 1, 'b': 2, '_c': 3, 'd': {'e': 5, '_f': 6, 'g': 7}}
    wanted = NamedTuple(a=1, b=2, d=NamedTuple(e=5, g=7))
    wanted_dict = wanted._asdict()
    got = to_namedtuple(dic)
    got_dict = got._asdict()
    assert wanted_dict == got_dict
    print("Passed the unit test")

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:13:55.931393
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import datetime

    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple(([{'a': 1, 'b': 2}])) == (NamedTuple(a=1, b=2),)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': [{'d': 3}]}) == \
        NamedTuple(a=1, b=2, c=[NamedTuple(d=3)])

# Generated at 2022-06-23 18:14:07.708863
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:14:09.520545
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit-test function to_namedtuple."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:14:12.338810
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:14:18.189279
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import io
    import sys

    # noinspection PyAbstractClass
    class TestToNamedTuple(unittest.TestCase):
        def setUp(self) -> None:
            # noinspection PyTypeChecker
            self.obj: OrderedDict[str, Any] = OrderedDict()
            self.obj['str'] = 'string'
            self.obj['int'] = 10
            self.obj['float'] = 3.14
            self.obj['list'] = [1, 'one']
            self.obj['tuple'] = (1, 'one')
            self.obj['dict'] = {'one': 1, 'two': 2}

# Generated at 2022-06-23 18:14:29.428434
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert not hasattr(nt, 'dic')
    dic = {'a': 1, 'b': 2, 'c': dic}
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert hasattr(nt, 'c')
    assert not hasattr(nt, 'dic')
    nt_c = cast(NamedTuple, nt.c)
    assert hasattr(nt_c, 'a')
    assert hasattr(nt_c, 'b')

# Generated at 2022-06-23 18:14:34.110040
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt_dic = to_namedtuple(dic)
    assert nt_dic.a==1
    assert nt_dic.b==2

# Generated at 2022-06-23 18:14:42.815369
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from flutils.namedtupleutils import to_namedtuple
    from typing import Any, Dict

    dic: Dict[str, Any] = {
        'item1': 'test',
        'item2': 3,
        'item3': {
            'test': 'testtest',
        }
    }

    nt: NamedTuple = to_namedtuple(dic)
    print(repr(nt))
    print(nt)
    print(f"nt.item1: {nt.item1}")
    print(f"nt.item2: {nt.item2}")
    print(f"nt.item3.test: {nt.item3.test}")
    
    # Preserve order of dictionary (python: >= 3.6)
    from collections import OrderedDict
    dic

# Generated at 2022-06-23 18:14:53.966109
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test for the function to_namedtuple."""

    from unittest import TestCase
    from typing import Tuple


    class TestToNamedTuple(TestCase):
        """Class for testing to_namedtuple."""


        def test_to_namedtuple(self):
            """Test for function to_namedtuple."""
            from collections import (
                OrderedDict,
            )
            from flutils.namedtupleutils import to_namedtuple


            # check the error that is returned
            with self.assertRaises(TypeError) as cm:
                to_namedtuple(1)

# Generated at 2022-06-23 18:15:03.152619
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from functools import partial

    import pytest
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-23 18:15:15.511803
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for function to_namedtuple

    Output:
        None
    """
    import pytest
    dic = {'a': 1, 'b': 2}
    li = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    tu = tuple(li)
    od = OrderedDict(li)
    ns = SimpleNamespace(a=1, b=2)

    # noinspection DuplicatedCode
    # Mapping
    with pytest.raises(TypeError):
        _to_namedtuple(dic, _started=False)
    dic_out = _to_namedtuple(dic, _started=True)
    assert dic_out.a == 1
    assert dic_out.b == 2

    # noinspection Dupl

# Generated at 2022-06-23 18:15:26.141251
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple

# Generated at 2022-06-23 18:15:36.162090
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'foo': 'bar',
        'a': {
            'b': {
                'a': 1,
                'b': 2
            }
        }
    }
    # noinspection PyTypeChecker
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.foo == 'bar'
    assert isinstance(out.a, NamedTuple)
    assert isinstance(out.a.b, NamedTuple)
    assert out.a.b.a == 1
    assert out.a.b.b == 2


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:15:47.583119
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import os
    import pytest
    import flutils.namedtupleutils
    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import to_namedtuple
    dirpath = os.path.dirname(flutils.namedtupleutils.__file__)
    filepath = os.path.join(dirpath, 'tests/test_data/to_namedtuple.py')
    with open(filepath, 'rb') as fh:
        code = compile(fh.read(), filepath, 'exec')
        py_ver = sys.version_info.major
        ns: dict = {}
        exec(code, ns)
        func = ns['test']
    func()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:15:58.821047
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class FooBar(NamedTuple):
        foo: int = 1
        bar: int = 2

    class Baz(NamedTuple):
        val: int = 3

    assert to_namedtuple({"a": 1, "b": 2}) == FooBar(a=1, b=2)

    assert to_namedtuple(OrderedDict(a=1, b=2)) == FooBar(a=1, b=2)

    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == FooBar(a=1, b=2)


# Generated at 2022-06-23 18:16:07.971163
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == to_namedtuple(to_namedtuple([]))
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(('a', 'b'))\
        == to_namedtuple(to_namedtuple(dict(a=1, b=2)))
    assert to_namedtuple({'a': [], 'b': 2}) == to_namedtuple(('a', 'b'))\
        == to_namedtuple(to_namedtuple(dict(a=[], b=2)))

# Generated at 2022-06-23 18:16:17.246850
# Unit test for function to_namedtuple
def test_to_namedtuple():
    o = OrderedDict({'a': 1, 'b': 2, 'c': 3})
    nt = to_namedtuple(o)

    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3
    assert isinstance(nt, NamedTuple)

    o = OrderedDict({'d': 1, 'a': 2, 'b': 3})
    nt = to_namedtuple(o)
    assert nt.d == 1
    assert nt.a == 2
    assert nt.b == 3

    nt = to_namedtuple(nt)
    assert nt.d == 1
    assert nt.a == 2
    assert nt.b == 3

    dic = {'b': 2, 'a': 1}
    nt