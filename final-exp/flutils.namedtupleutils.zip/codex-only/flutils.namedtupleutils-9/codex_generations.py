

# Generated at 2022-06-23 18:06:17.814776
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from pprint import pprint

    from collections import OrderedDict
    from types import SimpleNamespace

    _AllowedTypes = Union[
        List,
        Mapping,
        NamedTuple,
        SimpleNamespace,
        Tuple,
    ]


# Generated at 2022-06-23 18:06:28.506982
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from pprint import pprint
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic2 = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic2) == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic3 = {'a': 1, 'b': {'d': 2.2, 'e': 3.1}, 'c': 'string'}

# Generated at 2022-06-23 18:06:37.667468
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import collections
    import datetime
    from decimal import Decimal
    from types import SimpleNamespace

    d = collections.OrderedDict
    nt = collections.namedtuple
    od = collections.OrderedDict

    assert to_namedtuple(None) is None
    assert to_namedtuple(True) is True
    assert to_namedtuple(4) == 4
    assert to_namedtuple(4.5) == 4.5
    assert to_namedtuple(Decimal('4.5')) == Decimal('4.5')
    assert to_namedtuple('x') == 'x'
    assert to_namedtuple('abc def') == 'abc def'

    assert to_namedtuple(['x', 'y', 'z']) == ['x', 'y', 'z']
    assert to

# Generated at 2022-06-23 18:06:44.164654
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    """Unit test for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import test_to_namedtuple

    obj = {
        'a': 1,
        'b': 2
    }
    obj = to_namedtuple(obj)
    assert getattr(obj, 'a') == 1
    assert getattr(obj, 'b') == 2
    assert getattr(obj, '__dict__') == {'a': 1, 'b': 2}

    obj = {
        'a_': 1,
        '_b': 2
    }
    obj = to_namedtuple(obj)
    assert getattr(obj, 'a_') == 1

# Generated at 2022-06-23 18:06:54.816064
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple 
    import pytest

    with pytest.raises(TypeError):
        to_namedtuple(1)

    assert to_namedtuple(
        OrderedDict([
            ('a', 1),
            ('b', 2),
            ('c', OrderedDict([
                ('A', 1),
                ('B', 2),
                ('C', 3),
            ])),
        ])
    ) == namedtuple('NamedTuple', 'a b c')(
        a=1,
        b=2,
        c=namedtuple('NamedTuple', 'A B C')(
            A=1,
            B=2,
            C=3,
        ),
    )

# Generated at 2022-06-23 18:06:57.696437
# Unit test for function to_namedtuple
def test_to_namedtuple():
    examples = [
        (dict(a=1, b=2), namedtuple('NamedTuple', ['a', 'b'])(1, 2)),
    ]

    for args, expectation in examples:
        assert to_namedtuple(args) == expectation

# Generated at 2022-06-23 18:07:03.028242
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    lst = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    tpl = (
        {'a': {'b': 1, 'c': 2}},
        {'a': {'b': 2, 'c': 3}},
    )
    val = to_namedtuple(dic)
    assert val == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    val = to_namedtuple(lst)

# Generated at 2022-06-23 18:07:09.678995
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # From function docstring.
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

    # From docstring above.
    d = {'a': 1, 'b': 2}
    x = to_namedtuple(d)
    assert x[0] == 1
    assert x[1] == 2
    assert x.a == 1
    assert x.b == 2

    # Make sure it doesn't change the original.
    d = {'a': 1, 'b': 2}
    x = to_namedtuple(d)
    assert d['a'] == 1
    assert d['b'] == 2
    assert 'a' not in d.__dict__
    assert 'b' not in d.__dict__
    assert 'a' in x

# Generated at 2022-06-23 18:07:20.276311
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = {
        'x': '',
        'y': 0,
        'z': [],
        'w': {},
    }
    out = to_namedtuple(data)
    assert isinstance(out, NamedTuple)
    assert out.x == data['x']
    assert out.y == data['y']
    assert out.z is data['z']
    assert out.w is data['w']

    data = OrderedDict()
    data['x'] = ''
    data['y'] = 0
    data['z'] = []
    data['w'] = {}
    out = to_namedtuple(data)
    assert isinstance(out, NamedTuple)
    assert out.x == data['x']
    assert out.y == data['y']

# Generated at 2022-06-23 18:07:31.762994
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    import namedtuplelib
    dic: Mapping[str, Any] = {'a': 1, 'b': 2}
    newdic: NamedTuple = to_namedtuple(dic)
    assert newdic.a == 1
    assert newdic.b == 2
    assert newdic == namedtuplelib.NamedTuple(a=1, b=2)
    jsn = '{"a": 1, "b": 2}'
    newdic = to_namedtuple(json.loads(jsn))
    assert newdic == namedtuplelib.NamedTuple(a=1, b=2)
    lst: List[Mapping[str, Any]] = [{'a': 1}, {'b': 2}]

# Generated at 2022-06-23 18:07:38.251009
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert hasattr(result, 'a')
    assert hasattr(result, 'b')
    assert result.a == dic['a']
    assert result.b == dic['b']

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:07:48.924733
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    expected = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert out == expected

    dic = {'a': 1, 'b': 2, 3: [1, 2]}
    out = to_namedtuple(dic)
    expected = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert out == expected

    dic = {'a': [1, 2, 3], 'b': 2}
    out = to_namedtuple(dic)
    expected = namedtuple('NamedTuple', ['a', 'b'])(a=[1, 2, 3], b=2)


# Generated at 2022-06-23 18:07:59.871667
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from product import Product
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from product import ProductABC
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier

    # Simple Dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert type(out) == namedtuple('NamedTuple', ('a', 'b'))
    assert out.a == 1
    assert out.b == 2

    # Nested Dict
    dic = {'a': 1, 'b': {'c': 3}}
    out = to_namedtuple(dic)
    assert type(out) == namedtuple('NamedTuple', ('a', 'b'))


# Generated at 2022-06-23 18:08:11.836467
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == to_namedtuple(dict()) == NamedTuple(**{})
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(
        OrderedDict(a=1, b=2)
    ) == NamedTuple(a=1, b=2)
    assert to_namedtuple(
        OrderedDict(b=2, a=1)
    ) == NamedTuple(b=2, a=1)

# Generated at 2022-06-23 18:08:24.775689
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.tests.pytest_helpers import func_tester, pytest_func_collect

    tests = []
    # noinspection PyTypeChecker,PyDictCreation,Mypy
    tests.append((
        {'a': 1, 'b': 2},
        NamedTuple(a=1, b=2),
    ))
    # noinspection PyTypeChecker,PyDictCreation
    tests.append((
        OrderedDict({'a': 1, 'b': 2, 'c': 3}),
        NamedTuple(a=1, b=2, c=3),
    ))
    # noinspection PyTypeChecker,PyDictCreation

# Generated at 2022-06-23 18:08:31.850254
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections import namedtuple as _namedtuple
    from flutils.namedtupleutils import (
        to_namedtuple,
    )

    def namedtuple(*args, **kwargs) -> _namedtuple:
        if len(args) == 1:
            if isinstance(args[0], list):
                return _namedtuple(
                    'NamedTuple', args[0], **kwargs
                )
        return _namedtuple('NamedTuple', *args, **kwargs)


# Generated at 2022-06-23 18:08:44.372858
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for to_namedtuple."""

    from collections import (
        namedtuple,
    )
    from operator import (
        attrgetter,
    )

    dic = {'a': 1, 'b': 2}
    # noinspection PyTypeChecker
    expected = namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    assert dic == vars(expected)
    assert dic == eattrs(expected)
    assert isinstance(dic, dict)

    result = to_namedtuple(dic)
    assert result == expected
    assert dic == vars(result)
    assert dic == eattrs(result)
    assert isinstance(result, namedtuple)


# Generated at 2022-06-23 18:08:54.855109
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Sequence
    from types import SimpleNamespace

    # Should raise an error for incorrect type
    with pytest.raises(TypeError, match='Can convert only'):
        to_namedtuple(1)

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('_', 'a b')(1, 2)

    dic = {'ab': 1, 'ba': 2}
    assert to_namedtuple(dic) == namedtuple('_', 'ab ba')(1, 2)

    dic = {'__a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('_', 'b')(2)


# Generated at 2022-06-23 18:09:06.007299
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    dic = {'a': 1, 'b': 2}
    dic2 = {'a': 1, 'c': 2}
    dic_list = [dic, dic2]
    dic_list2 = [
        {'d': 1, 'e': 2},
        {'f': 1, 'g': 2},
    ]
    dic_list3 = [
        dic_list2,
        dic_list,
    ]
    dic_list4 = [
        dic_list3,
        dic_list,
    ]
    dic_list5 = [
        OrderedDict(dic_list4),
        OrderedDict(dic_list4),
    ]

# Generated at 2022-06-23 18:09:15.834064
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': {'c': 3}}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert isinstance(nt.b, NamedTuple)
    assert nt.a == 1
    assert nt.b.c == 3


# Generated at 2022-06-23 18:09:21.446910
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:09:29.076678
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint


    class Item:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            for key, val in zip(args[::2], args[1::2]):
                setattr(self, key, val)
            for key, val in kwargs.items():
                setattr(self, key, val)


    def test(func_name: str, obj: Any) -> None:
        print('====================\nTesting: %s\n====================' %
              func_name)


        obj = to_namedtuple(obj)
        pprint(obj)
        print('Type:', type(obj))


    print('\n============================\nTesting OrderedDict\n============================')

# Generated at 2022-06-23 18:09:40.113870
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for flutils.namedtupleutils.to_namedtuple()."""
    from copy import deepcopy
    from random import choice
    from string import ascii_letters, digits
    from typing import Tuple, Union

    # noinspection SpellCheckingInspection
    # noinspection PyUnusedLocal
    def obj_as_str(
            obj: Union[dict, list, tuple, SimpleNamespace],
            spaces: int = 0
    ) -> str:
        """Convert object to string equivalent value."""
        from flutils.systemutils import get_py_version
        from flutils.namedtupleutils import to_namedtuple
        from flutils.validators import is_namedtuple
        from typing import List, Union

        out: List[str] = []

# Generated at 2022-06-23 18:09:48.383103
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections.abc import Mapping, Sequence
    from types import SimpleNamespace

# Generated at 2022-06-23 18:09:57.326434
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # standard dictionary
    obj = {'a': 1, 'b': 2, '_c': 3, 'd': {'a': 'a', 'b': 'b'}}
    new = to_namedtuple(obj)
    assert isinstance(new, NamedTuple)
    assert new.a == 1
    assert new.b == 2
    assert hasattr(new, '_c') is False
    assert new.d.a == 'a'
    assert new.d.b == 'b'

    # simple namespaces
    obj = SimpleNamespace(a=1, b=2, _c=3, d=SimpleNamespace(a='a', b='b'))
    new = to_namedtuple(obj)
    assert isinstance(new, NamedTuple)
    assert new.a == 1

# Generated at 2022-06-23 18:10:01.863220
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    unittest.TestCase().assertEqual(obj.a, 1)
    unittest.TestCase().assertEqual(obj.b, 2)
    dic = {'a': 1, 'b': 2, 'c': 3}
    obj = to_namedtuple(dic)
    unittest.TestCase().assertEqual(obj.a, 1)
    unittest.TestCase().assertEqual(obj.b, 2)
    unittest.TestCase().assertEqual(obj.c, 3)
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    unittest.Test

# Generated at 2022-06-23 18:10:12.217401
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 'a', {'b': 1}]) == [1, 'a', NamedTuple(b=1)]
    assert to_namedtuple(([], {})) == ([], ())
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': {}}) == NamedTuple(a=1, b=())
    assert to_namedtuple({'a': 1, 'b': {'c': 1}}) == NamedTuple(a=1, b=NamedTuple(c=1))
    assert to_namedtuple({'b': 1, 'a': 2}) == NamedTuple(a=2, b=1)

# Generated at 2022-06-23 18:10:22.889233
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Tests the function to_namedtuple."""

    class _Custom(SimpleNamespace):
        def __init__(self, **kwargs: Any) -> None:
            super().__init__(**kwargs)

    d = {'a': 1, 'b': 2}
    out = to_namedtuple(d)
    assert isinstance(out, NamedTuple)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert getattr(out, 'a') == 1
    assert getattr(out, 'b') == 2

    d = OrderedDict((
        ('c', 3),
        ('d', 4),
    ))
    out = to_namedtuple(d)
    assert isinstance(out, NamedTuple)

# Generated at 2022-06-23 18:10:28.747070
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    dic = to_namedtuple(dic)
    assert dic.a == 1
    assert str(dic) == 'NamedTuple(a=1, b=2)'
    dic = OrderedDict([('b', 2), ('a', 1)])
    dic = to_namedtuple(dic)
    assert str(dic) == 'NamedTuple(b=2, a=1)'
    dic = [{'a': 1, 'b': 2}]
    dic = to_namedtuple(dic)
    assert len(dic) == 1
    assert dic[0].a == 1
    dic = (OrderedDict([('b', 2), ('a', 1)]), 'c')
   

# Generated at 2022-06-23 18:10:34.690693
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections import namedtuple
    from types import SimpleNamespace
    from typing import (
        Any,
        Mapping,
        NamedTuple,
        Sequence,
        Union,
    )

    Simple = SimpleNamespace

    _AllowedTypes = Union[
        Sequence,
        Mapping,
        NamedTuple,
        SimpleNamespace,
    ]


# Generated at 2022-06-23 18:10:43.142324
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    def _check(
            obj: Union[List, Tuple, Mapping, NamedTuple, SimpleNamespace],
            recurse: bool = True
    ) -> bool:
        out = to_namedtuple(obj)
        if hasattr(out, 'capitalize'):
            return True
        if isinstance(out, (
                List,
                Mapping,
                SimpleNamespace,
                )):
            raise Exception(
                '%s should be converted to a namedtuple; '
                'got: %s' % (type(obj).__name__, type(out).__name__)
            )
        if isinstance(out, Tuple):
            for item in out:
                if recurse is True:
                    if not _check(item, recurse=False):
                        return False
            return

# Generated at 2022-06-23 18:10:53.907093
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:11:05.466364
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
        UserDict,
    )
    from types import SimpleNamespace

    dic1 = OrderedDict(
        [
            ('a', 1),
            ('b', 2),
        ]
    )

    dic2 = OrderedDict(
        (
            ('c', 3),
            ('d', 4),
        )
    )
    dic2['b'] = dic1
    dic3 = {
        'c': dic2,
        'e': 5,
    }

    dic4 = OrderedDict(dic3)
    dic4.update(
        {
            'f': 6,
            'g': 7,
        }
    )


# Generated at 2022-06-23 18:11:14.005465
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Dict, List, Tuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # Test for TypeError
    dic: Dict[str, str] = {'a': 1}
    nested_dic: Dict[str, Dict[str, str]] = {'b': dic}
    assert to_namedtuple(nested_dic)

    tup: Tuple[str, int] = ('a', 1)
    nested_tup: Tuple[str, Tuple[str, int]] = ('b', tup)
    assert to_namedtuple(nested_tup)

    list_: List[str] = ['a']
    nested_list: List[List[str]] = [list_]
    assert to_namedtuple(nested_list)

# Generated at 2022-06-23 18:11:24.067295
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.testutils import no_raise
    d = {'a': 1, 'b': {'c': 2, 'd': 3}}
    od = OrderedDict(d)
    # def _test(obj, expected):

    # noinspection PyTypeChecker
    for obj in (d, od, SimpleNamespace(**d)):  # type: ignore[arg-type]
        expected = 'NamedTuple(a=1, b=NamedTuple(c=2, d=3))'

    # noinspection PyUnresolvedReferences,PyTypeChecker
    # def test_to_namedtuple():
    #     from collections import OrderedDict
    #     from flutils.testutils import no_raise
    #     d = {'a': 1,

# Generated at 2022-06-23 18:11:33.175995
# Unit test for function to_namedtuple
def test_to_namedtuple():
    item = {'a': 1, 'b': 2}
    assert to_namedtuple(item) == NamedTuple(a=1, b=2)
    item = {'A': 1, 'B': 2}
    assert to_namedtuple(item) == NamedTuple(A=1, B=2)
    item = {'1': 1, '2': 2}
    assert to_namedtuple(item) == NamedTuple()
    item = {'a': 1, 'B': 2}
    assert to_namedtuple(item) == NamedTuple(a=1)
    item = {'a': 1, '_B': 2}
    assert to_namedtuple(item) == NamedTuple(a=1)
    item = [{'a': 10}, {'b': 15}]
   

# Generated at 2022-06-23 18:11:42.885990
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = [
        1,
        {
            'a': 1,
            'b': 2
        },
    ]

    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert out[0] == 1
    assert isinstance(out[1], NamedTuple)
    assert isinstance(out[1].a, int)
    assert isinstance(out[1].b, int)

    obj = (1, 2, 3)
    out = to_namedtuple(obj)
    assert isinstance(out, tuple)
    assert out == obj

    obj = {
        'a': 1,
        'b': 2
    }
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple)
    assert isinstance(out.a, int)

# Generated at 2022-06-23 18:11:52.052998
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(['a', OrderedDict([('b', 1), ('c', 2)])]) == ['a', NamedTuple(b=1, c=2)]
    assert to_namedtuple(['a', {'b': 1, 'c': 2}]) == ['a', NamedTuple(c=2, b=1)]
    assert to_namedtuple(('a', {'b': 1, 'c': 2})) == ('a', NamedTuple(c=2, b=1))
    assert to_

# Generated at 2022-06-23 18:11:56.212889
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    from typing import OrderedDict

    from collections import namedtuple
    from datetime import date, datetime

    from pytz import timezone

    from flutils.namedtupleutils import to_namedtuple

    TZone = timezone('US/Eastern')

    Body = namedtuple('Body', 'item')
    Body_NamedTuple = namedtuple('Body_NamedTuple', 'item')

    Person = namedtuple(
        'Person',
        'first_name, last_name, age, sex, married, id, '
        'birthdate, birthdatetime, birthdatetime_utc, '
        'birthdatetime_tz, body'
    )

# Generated at 2022-06-23 18:12:08.538572
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest

# Generated at 2022-06-23 18:12:19.256218
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj.a == 1
    assert obj.b == 2
    assert repr(obj) == "NamedTuple(a=1, b=2)"
    dic = {'a': 1, 'b': 2, 'c': 3}
    obj = to_namedtuple(dic)
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3
    assert repr(obj) == "NamedTuple(a=1, b=2, c=3)"
    lst

# Generated at 2022-06-23 18:12:28.958291
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert hasattr(dic, 'a')
    assert hasattr(out, 'a')
    assert out.a == dic['a']
    assert out.b == dic['b']
    assert not hasattr(out, 'c')
    assert not hasattr(dic, 'c')
    dic['c'] = 3
    out = to_namedtuple(dic)
    assert hasattr(out, 'c')
    assert out.c == dic['c']
    assert not hasattr(out, 'd')
    assert not hasattr(dic, 'd')
    dic['d'] = dic
    out = to_namedtuple(dic)

# Generated at 2022-06-23 18:12:35.688722
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': {'a': 1, 'b': 2},
        'c': [{'a': 1}, {'b': 2}, {'c': 3}],
        'd': (1, 2, 3),
    }
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.c[1].b == 2


if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-23 18:12:48.009536
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    # import logging
    # log = logging.getLogger(__name__)

    data = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': {
                    'h': 5,
                    'i': 6,
                },
                'j': 7,
                'k': 8,
                'l': [{
                    'm': 9,
                }],
            },
        },
        'n': [{
            'o': 10,
            'p': 11,
            'q': [{
                'r': 12,
                's': 13,
            }],
        }],
    }
    res0 = NamedT

# Generated at 2022-06-23 18:12:57.224487
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    from flutils.namedtupleutils import AttrDict
    from flutils.collectutils import OrderedAttrDict

    dic = {
        'a': 1,
        'b': 2,
        'c': {
            'aa': 11,
            'bb': 22,
            'cc': 33,
        }
    }
    nt_dic = to_namedtuple(dic)
    print('from dict:')
    pprint(nt_dic)


# Generated at 2022-06-23 18:13:08.089030
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, {'a': {'b': 3}})) == (1,
                                                  to_namedtuple(
                                                      {'a': {'b': 3}}))
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple((('a', 1), ('b', 2)))
    assert to_namedtuple({'a': 1, '_b': 2}) == to_namedtuple((('a', 1),))

# Generated at 2022-06-23 18:13:18.211457
# Unit test for function to_namedtuple
def test_to_namedtuple():
    items = [
        dict(a=1, b=2),
        dict(b=1, a=2),
        dict(c=1, b=2, a=3),
        dict(c=1, b=2, a=3, d=4),
        dict(b=1, a=2, d=4),
        dict(a=2, d=4, b=1),
    ]
    for item in items:
        assert isinstance(to_namedtuple(item), NamedTuple)
        assert to_namedtuple(item)._fields == ('a', 'b', 'c', 'd')


# Generated at 2022-06-23 18:13:27.270071
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyPackageRequirements,PyPep8
    import pytest
    # noinspection PyProtectedMember,PyPep8
    from collections.abc import Mapping
    # noinspection PyUnresolvedReferences
    from namedtupleutils import to_namedtuple, _to_namedtuple

    # noinspection PyUnresolvedReferences
    def _check_not_to_namedtuple(obj, err):
        if isinstance(err, tuple):
            expected_err, expected_err_type = err
        else:
            expected_err_type = Exception
            expected_err = err
        with pytest.raises(expected_err_type) as excinfo:
            to_namedtuple(obj)
        assert excinfo.value.args[0] == expected_err


# Generated at 2022-06-23 18:13:39.355477
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import datetime
    # noinspection Mypy
    from collections.abc import Iterable
    # noinspection Mypy
    from collections.abc import MutableMapping

    assert isinstance(to_namedtuple([]), list)
    assert isinstance(to_namedtuple(()), tuple)
    assert isinstance(to_namedtuple((1, 2, 3)), tuple)
    assert isinstance(to_namedtuple((1, 2, 3)), Iterable)
    assert isinstance(to_namedtuple({}), NamedTuple)
    assert isinstance(to_namedtuple({"a": 1, "b": 2}), NamedTuple)
    assert isinstance(to_namedtuple(dict(a=1, b=2)), NamedTuple)

# Generated at 2022-06-23 18:13:51.259000
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    from collections import OrderedDict
    from types import SimpleNamespace

    def _cmp_tuple(tup1, tup2):
        if tup1 is None and tup2 is None:
            return True
        if tup1 is None or tup2 is None:
            return False
        return tup1 == tup2

    def _cmp_list(lst1, lst2):
        if lst1 is None and lst2 is None:
            return True
        if lst1 is None or lst2 is None:
            return False
        if len(lst1) != len(lst2):
            return False
        for i, item in enumerate(lst1):
            otitem = lst2[i]

# Generated at 2022-06-23 18:13:54.832557
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    named = to_namedtuple(dic)
    assert named.a == 1
    assert named.b == 2

# Generated at 2022-06-23 18:14:06.837624
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from typing import List, NamedTuple, Optional
    from unittest.mock import patch
    import unittest
    import doctest

    class TestNamedTuple(NamedTuple):

        """A test type using NamedTuple.

        Attributes:
            foo (str): The foo attribute.
            bar (Optional[str]): The bar attribute.
        """

        foo: str
        bar: Optional[str]

    class Test(unittest.TestCase):

        """Tests for the 'to_namedtuple' function."""

        def test_not_started(self):
            """Test TypeError when untested value."""

# Generated at 2022-06-23 18:14:16.301818
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    dic = {'b': 2, 'a': 1}
    dic2 = {'b': 3, 'h': 5}
    head = to_namedtuple(dic)
    assert hasattr(head, 'b')
    assert head.a == 1
    assert head.b == 2

    dic['d'] = dic2
    head = to_namedtuple(dic)
    assert hasattr(head, 'd')
    assert hasattr(head.d, 'b')
    assert hasattr(head.d, 'h')
    assert head.d.b == 3
    assert head.d.h == 5

    order = OrderedDict()

# Generated at 2022-06-23 18:14:18.250071
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Just run it to ensure it does not error
    pass

# Generated at 2022-06-23 18:14:20.402422
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple

    dic: dict = {'a': 1, 'b': 2}
    nt: NamedTuple = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2



# Generated at 2022-06-23 18:14:30.240462
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from collections import namedtuple

    class ToNamedTupleTests(unittest.TestCase):
        def test_raises(self):
            msg = "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (%r) %s"
            self.assertRaisesRegex(
                TypeError,
                msg % ('int', 1),
                to_namedtuple, 1
            )
            self.assertRaisesRegex(
                TypeError,
                msg % ('bytes', bytes(10)),
                to_namedtuple, bytes(10)
            )

# Generated at 2022-06-23 18:14:41.404968
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    """
    >>> from flutils.namedtupleutils import to_namedtuple
    >>> nt = to_namedtuple((1, {'a': 2, 'b': 3}, 4))
    >>> nt
    (1, NamedTuple(a=2, b=3), 4)
    >>> nt[1].a
    2
    >>> nt[1].b
    3
    >>> nt[1]
    NamedTuple(a=2, b=3)
    >>> nt[1].a
    2
    >>> nt[1].b
    3
    >>> nt[1].c
    Traceback (most recent call last):
      ...
    AttributeError: 'NamedTuple' object has no attribute 'c'
    """


# Generated at 2022-06-23 18:14:53.095371
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == namedtuple('NamedTuple', ('a', 'b'))(**{'a': 1, 'b': 2})
    assert to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]) == [namedtuple('NamedTuple', ('a', 'b'))(**{'a': 1, 'b': 2}), namedtuple('NamedTuple', ('c', 'd'))(**{'c': 3, 'd': 4})]

# Generated at 2022-06-23 18:14:58.862510
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test for function to_namedtuple"""
    from collections import OrderedDict
    import sys
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    obj = {'a': 1, 'b': 2}
    copy = to_namedtuple(obj)
    assert hasattr(copy, 'a') and copy.a == 1
    assert hasattr(copy, 'b') and copy.b == 2

    obj = OrderedDict([('a', 1), ('c', 3)])
    copy = to_namedtuple(obj)
    assert hasattr(copy, 'a') and copy.a == 1
    assert hasattr(copy, 'c') and copy.c == 3


# Generated at 2022-06-23 18:15:05.110914
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic: Mapping = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic['_c'] = NamedTuple(d=5, e=6)
    dic['_d'] = [1, 2, 3]
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=NamedTuple(d=5, e=6), d=[1, 2, 3])

    dic['_d'].append([4, 5, 6])
    dic['_d'][3].append(7)

# Generated at 2022-06-23 18:15:17.227232
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    """Unit test for function to_namedtuple."""
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    # noinspection PyUnusedLocal
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)  # type: ignore[misc]
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', 'a b')(1, 2)  # type: ignore[misc]
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple((1,)) == (1,)

# Generated at 2022-06-23 18:15:27.154089
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from typing import (
        NamedTuple,
        Tuple,
        List,
    )

    from flutils.namedtupleutils import (
        convert_to_namedtuple,
    )

    NamedTupleExample = NamedTuple('NamedTupleExample', [('a', int), ('b', int)])
    val: List[Tuple[int, int]] = [
        (1, 2),
        (3, 4),
    ]
    # noinspection PyTypeChecker
    val = convert_to_namedtuple(val)  # type: ignore[no-untyped-call]
    assert val[0] == (1, 2)
    assert val[1] == (3, 4)

    val = (1, 2)
    # noinspection PyTypeChecker
   

# Generated at 2022-06-23 18:15:37.767401
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple({
        'a': 1,
        'b': 2,
        'c': 3,
    }) == to_namedtuple({
        'c': 3,
        'b': 2,
        'a': 1,
    }) == to_namedtuple(OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
    ])) == to_namedtuple(SimpleNamespace(**{
        'a': 1,
        'b': 2,
        'c': 3,
    })) == to_namedtuple(SimpleNamespace(**OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
    ])))

# Generated at 2022-06-23 18:15:48.372792
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.testingutils import make_test_string
    obj: OrderedDict = OrderedDict()
    obj['a'] = 1
    obj['b'] = 2
    out = to_namedtuple(obj)
    assert out == namedtuple('NamedTuple', 'a b')(1, 2)
    obj = SimpleNamespace(a=1, b=2)
    out = to_namedtuple(obj)
    assert out == namedtuple('NamedTuple', 'a b')(1, 2)
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert out == namedtuple('NamedTuple', 'a b')(1, 2)
    obj = {'1a': 1, 'b': 2}

# Generated at 2022-06-23 18:15:59.316162
# Unit test for function to_namedtuple
def test_to_namedtuple():
    ''' Test for function to_namedtuple
    '''
    from collections import (
        OrderedDict,
    )
    from types import SimpleNamespace
    from unittest import TestCase
    from typing import (
        NamedTuple,
    )

    # noinspection PyUnusedFunction
    class TestNamedTuple(NamedTuple):
        a: int
        b: int

    dic = {'a': 1, 'b': 2}
    odic = OrderedDict(dic)
    tup = 1, 2
    lst = [1, 2, 3]
    ldic = [dic, dic, dic, dic, dic, dic, dic, dic, dic]

# Generated at 2022-06-23 18:16:08.297829
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple({}) == to_namedtuple({})

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == to_namedtuple({'a': 1, 'b': 2})

    dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    assert to_namedtuple(dic) == to_namedtuple({'a': 1, 'b': {'c': 3, 'd': 4}})

    dic = OrderedDict(a=1, b=2, c=3)

# Generated at 2022-06-23 18:16:17.545442
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test the function to_namedtuple function
    # Print header
    # print(f"{'Matrix':<15}{'NumPy':^15}{'SciPy':>15}")
    # for x in range(10):
    #     print(f'{x:<15}{x**2:^15}{x**3:>15}')

    print(f"\n{'Test':<15}{'Expected':^15}{'Result':>15}\n")

    # Test for NamedTuple
    print(f"{'Convert to NamedTuple':<15}{'NamedTuple(a=1, b=2.0)':^15}", end='')
    dic = {'a': 1, 'b': 2.0}
    result = to_namedtuple(dic)
   