

# Generated at 2022-06-23 18:06:08.841527
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:06:17.033325
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from tests.testutils import (
        _,
        assert_equal,
        assert_in,
        assert_isinstance,
        assert_not_in,
        assert_sequence_equal,
    )
    from flutils.namedtupleutils import to_namedtuple
    from flutils.iterutils import flatten

    obj = {'a': 1, 'b': 2, 'c': [5, 6, 7], 'd': {'e': 10, 'f': 11}}
    out = to_namedtuple(obj)
    assert_isinstance(out, namedtuple('NamedTuple', 'a b c d'))
    assert_equal(out.a, 1)
    assert_equal(out.b, 2)
    assert_isinstance(out.c, list)

# Generated at 2022-06-23 18:06:27.378448
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3, 'C': 4}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3  # noqa: E800
    assert nt.C == 4

    dic = {'a': 1, 'b': 2, 'c': 3, 'C': 4, 'd': {'a': 1, 'b': 2, 'c': 3}}
    nt = to_namedtuple(dic)
    assert nt.a == 1


# Generated at 2022-06-23 18:06:37.626348
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test for conversion of NamedTuple to dict"""

    from flutils.namedtupleutils import to_namedtuple as _to_namedtuple

    def _assert(obj: _AllowedTypes,
                output: Any,
                ret_type: type) -> None:
        assert ret_type(output) == _to_namedtuple(obj)

    _assert([{'a': 1, 'b': 2}, {'a': 1, 'b': 2}], [], list)  # list
    _assert(([{'a': 1, 'b': 2}, {'a': 1, 'b': 2}],), [], tuple)  # tuple
    _assert({'a': 1, 'b': 2}, {'a': 1, 'b': 2}, Mapping)  # dict

# Generated at 2022-06-23 18:06:47.456142
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:06:50.091458
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _ = to_namedtuple         # noqa: F841
    _ = simple_to_namedtuple  # noqa: F841
    raise NotImplementedError



# Generated at 2022-06-23 18:06:59.458857
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple([OrderedDict([('a', 1), ('b', 2)])]) == [namedtuple('NamedTuple', 'a b')(1, 2)]

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:07:11.119723
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import Dict, NamedTuple, Optional, Tuple
    from types import SimpleNamespace

    @singledispatch
    def test_function(obj: Any) -> bool:
        raise AssertionError("Should never get here")

    @test_function.register(dict)
    def _(obj: Dict[str, Any]) -> bool:
        assert isinstance(obj, dict)
        return True

    @test_function.register(list)
    def _(obj: List[Any]) -> bool:
        assert isinstance(obj, list)
        return True

    @test_function.register(tuple)
    def _(obj: Tuple[Any, ...]) -> bool:
        assert isinstance(obj, tuple)
        return True


# Generated at 2022-06-23 18:07:22.413631
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import is_namedtuple
    from types import SimpleNamespace
    from typing import List, Tuple
    from unittest import TestCase
    from unittest.mock import patch

    class TestToNamedTuple(TestCase):
        def test_called_with_no_args(self):
            t = to_namedtuple()
            self.assertIsNone(t)

        def test_called_with_simple_value(self):
            t = to_namedtuple(1)
            self.assertEqual(t, 1)


# Generated at 2022-06-23 18:07:32.600987
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.grammarutils import get_parts_of_speech
    from flutils.miscutils import sanitize_identifier
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testutils import BaseTest

    class Test(BaseTest):

        def test_to_namedtuple(self):
            out = get_parts_of_speech('take a walk')
            out = to_namedtuple(out)
            # noinspection PyUnresolvedReferences

# Generated at 2022-06-23 18:07:44.908715
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the to_namedtuple function."""
    from flutils.show import (
        show_func_attrs,
    )
    from flutils.typesutils import test_types_mapping
    from flutils.validators import is_namedtuple
    f = to_namedtuple
    print(f)
    dic = {'a': 1, 'b': 2}
    show_func_attrs(is_namedtuple, dic)
    r = to_namedtuple(dic)
    show_func_attrs(is_namedtuple, r)
    print(r)
    assert r.a == 1
    assert r.b == 2
    od = OrderedDict(  # type: ignore[assignment]
        a=1,
        b=2,
    )
    r

# Generated at 2022-06-23 18:07:53.386208
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': {'b': {'c': {'d': 1}}}, 'e': 2, 'f': 3}
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'e')
    assert hasattr(nt, 'f')
    assert hasattr(nt.a, 'b')
    assert hasattr(nt.a.b, 'c')
    assert hasattr(nt.a.b.c, 'd')
    assert nt.a.b.c.d == 1
    assert nt.e == 2
    assert nt.f == 3
    complex_nt = nt.a.b.c
    assert complex_nt._fields == ('d', )
    assert len(complex_nt) == 1

# Generated at 2022-06-23 18:08:02.426790
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function ``to_namedtuple``."""
    import numbers
    import unittest
    import datetime
    import re

    class TestToNamedTuple(unittest.TestCase):
        """Test the function ``to_namedtuple``."""

        # noinspection PyPep8Naming
        def test_SimpleMapping(self):
            """Test the function ``to_namedtuple`` on a mapping."""
            dic = dict(
                foo='bar',
                bar='foo',
                _fox=True,
                _dog=False,
            )
            # noinspection PyTypeChecker
            namedtuple_obj: NamedTuple = to_namedtuple(dic)
            # noinspection PyTypeChecker

# Generated at 2022-06-23 18:08:11.529465
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()

    result = to_namedtuple({'a': 1, 'b': 2})
    expected = namedtuple('NamedTuple', ['a', 'b'])(1, 2)

    assert result == expected
    assert result.__class__ == expected.__class__

    result = to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}])
    expected = [
        namedtuple('NamedTuple', ['a', 'b'])(1, 2),
        namedtuple('NamedTuple', ['a', 'b'])(3, 4),
    ]

    assert result

# Generated at 2022-06-23 18:08:24.437304
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    from types import SimpleNamespace

    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == (1, 2)

    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple({'a': (1, 2)}) == (1, 2)

    dic = {'a': 1, 'b': {'c': 3}}
    assert to_namedtuple(dic)

# Generated at 2022-06-23 18:08:31.630267
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic: OrderedDict[str, Any] = OrderedDict((
        ('a', 1),
        ('_b', 2),
        ('c', {'d': 3, '_e': 4}),
        ('_f', {'g': 5, 'h': 6}),
        ('_i', {'j': 7, 'k': 8}),
        ('l', [1, 2, 3]),
        ('m', [{'n': 10, 'o': 11}, {'p': 12, '_q': 13}]),
        ('r', (1, 2)),
        ('s', (3, {'t': 15, '_u': 16})),
    ))

# Generated at 2022-06-23 18:08:44.329764
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def assert_expected(obj, exp):
        got = to_namedtuple(obj)
        assert got == exp

    # dict
    dic = {'a': 1, 'b': 2}
    exp = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert_expected(dic, exp)

    # dict with dicts
    dic = {'a': {'b': 2}}
    exp = namedtuple('NamedTuple', 'a')(a=namedtuple('NamedTuple', 'b')(b=2))
    assert_expected(dic, exp)

    # dict with bad keys
    dic = {'a+': 1, 'b': 2}
    exp = namedtuple('NamedTuple', 'b')(b=2)

# Generated at 2022-06-23 18:08:54.820126
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(
        {
            'a': 1,
            'b': 2,
            'c': 3
        }
    ) == NamedTuple(a=1, b=2, c=3)
    dic = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    dic[''] = 'garbage'
    dic['@'] = 'garbage'
    dic['a-b'] = 'garbage'
    dic['1a'] = 1
    dic['"a"'] = 'garbage'
    dic['a,b'] = 'garbage'
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

# Generated at 2022-06-23 18:09:02.792356
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(['a', 1, ('b', 2)]) == ['a', 1, namedtuple('NamedTuple', ['b'])(b=2)]
    assert to_namedtuple(('a', 1, {'b': 2})) == (
        'a', 1, namedtuple('NamedTuple', ['b'])(b=2))
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)

# Generated at 2022-06-23 18:09:11.417207
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _test(obj: Any) -> Any:
        return to_namedtuple(obj)

    assert _test([1, {'a': 1, 'b': 2}, 3]) == [1, NamedTuple(a=1, b=2), 3]
    assert _test({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert _test((1, {'a': 1, 'b': 2}, 3)) == (1, NamedTuple(a=1, b=2), 3)
    obj = _test(OrderedDict(a=1, b=2))
    assert obj.a == 1
    assert obj.b == 2
    assert obj == (1, 2)
    assert obj == [1, 2]

    import attr
    from dataclasses import dat

# Generated at 2022-06-23 18:09:23.335175
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple

    dic = OrderedDict([
        ('a', 1),
        ('b', 2),
    ])
    t = to_namedtuple(dic)
    assert t.a == 1
    assert t.b == 2
    assert t.a != dic['a']
    assert t.b != dic['b']

    dic = {
        'aa': 1,
        'ab': 2,
        'ba': 3,
        'bb': 4,
    }
    t = to_namedtuple(dic)
    assert t.aa == 1
    assert t.ab == 2
    assert t.ba == 3
    assert t.bb == 4
    assert t.aa != dic['aa']


# Generated at 2022-06-23 18:09:34.869875
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic['c'] = 3
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3

    dic['d'] = (1, 2, 3)
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3
    assert nt.d == (1, 2, 3)

    dic['e']

# Generated at 2022-06-23 18:09:45.869415
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    import pytest

    # dictionary
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    # ordereddict
    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    # namespace
    out = to_namedtuple(SimpleNamespace(a=1, b=2))
    assert out.a == 1
    assert out.b == 2

    with pytest.raises(SyntaxError):
        # not an identifier
        to_namedtuple({1: 1})

    # list
    out = to

# Generated at 2022-06-23 18:09:54.790085
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    namedtuple = to_namedtuple(dic)
    assert namedtuple.a == 1
    assert namedtuple.b == 2

    lst = [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]
    namedtuples = to_namedtuple(lst)
    assert namedtuples[0].a == 1
    assert namedtuples[0].b == 2
    assert namedtuples[1].a == 1
    assert namedtuples[1].b == 2

    tup = (list(dic), lst)
    namedtuples = to_namedt

# Generated at 2022-06-23 18:10:06.502242
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import logging
    import unittest
    from collections import OrderedDict
    from types import SimpleNamespace

    _LOG: logging.Logger = logging.getLogger()
    _LOG.addHandler(logging.NullHandler())

    class TestNamedTupleUtils(unittest.TestCase):
        """Test method to_namedtuple().
        """

        def test_to_namedtuple_typeerror(self):
            with self.assertRaises(TypeError) as ctx:
                to_namedtuple('Test')
            self.assertEqual(
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                "got: (%r) %s",
                str(ctx.exception)
            )

# Generated at 2022-06-23 18:10:18.258629
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    dic = OrderedDict([
        ('x', OrderedDict([
            ('a', 1),
            ('b', 2),
        ])),
        ('y', OrderedDict([
            ('c', 3),
            ('d', 4),
        ])),
        ('z', '5'),
    ])
    nt = to_namedtuple(dic)

    assert hasattr(nt, 'x')
    assert hasattr(nt, 'y')
    assert hasattr(nt, 'z')
    assert nt.z == '5'

    ntx = nt.x
    assert hasattr(ntx, 'a')
    assert hasattr(ntx, 'b')
    assert ntx.a

# Generated at 2022-06-23 18:10:30.014228
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import unittest

    class TestToNamedTuple(unittest.TestCase):

        def test_bad_types(self):
            with self.assertRaises(TypeError):
                to_namedtuple(None)

            with self.assertRaises(TypeError):
                to_namedtuple(5.5)

            with self.assertRaises(TypeError):
                to_namedtuple('foo')

            with self.assertRaises(TypeError):
                to_namedtuple(b'bar')

            with self.assertRaises(TypeError):
                to_namedtuple(True)


# Generated at 2022-06-23 18:10:40.089568
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic).a == dic['a'] == 1
    assert to_namedtuple(dic).b == dic['b'] == 2
    tup = ('a', 'b')
    assert to_namedtuple(tup) == to_namedtuple(tup)
    assert to_namedtuple(tup)[0] == tup[0] == 'a'
    assert to_namedtuple(tup)[1] == tup[1] == 'b'
    tup = (1, 2)

# Generated at 2022-06-23 18:10:51.473309
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyPep8Naming
    def test_object():
        dic = {
            'a': {'b': 'c'},
            'd': 1,
            'e': [{'f': 'g'}],
            '_h': 'i',
            'j': 10,
            'k': 'l',
        }
        obj = to_namedtuple(dic)
        obj2 = to_namedtuple(obj)
        assert obj == obj2
        assert obj.a.b == 'c'
        assert obj.d == 1
        assert obj.e[0].f == 'g'
        with pytest.raises(AttributeError):
            obj._h
        assert obj.j == 10
        assert obj.k == 'l'
        assert obj.__doc__ is None



# Generated at 2022-06-23 18:11:03.833321
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.typingutils import NamedTupleDict

    def _test(
            name: str,
            got: Any,
            expected: Any = None
    ):
        if expected is None:
            expected = got
        msg = 't/n: %s\n- GOT       :%s\n- EXPECTED  :%s' % (
            name, got, expected
        )
        assert got == expected, msg

    dic = {'a': 1, 'b': 2, '_c': 3, 'd_': 4, 'e-f': 5}
    exp = NamedTupleDict(a=1, b=2)

    _test('dict', to_namedtuple(dic), exp)

# Generated at 2022-06-23 18:11:12.866077
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple

    obj = {'a': 1, 'b': 2}
    result: NamedTuple = to_namedtuple(obj)
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert result == expected

    obj = [1, 2, 3]
    result = to_namedtuple(obj)
    expected = [1, 2, 3]
    assert result == expected

    obj = {'a': 1, 'b': 2, 'c': [1, 2, 3]}
    result: NamedTuple = to_namedtuple(obj)

# Generated at 2022-06-23 18:11:23.352769
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from validators import url

    urlstr = 'http://foo.com'
    urlobj = url(urlstr)

    result = to_namedtuple({'a': 1, 'b': 2})
    assert result.a == 1
    assert result.b == 2

    # Order of keys
    d = OrderedDict()
    d['key1'] = 1
    d['key2'] = 2
    d['key3'] = 3
    d['key4'] = 4
    result = to_namedtuple(d)
    assert result.key1 == 1
    assert result.key2 == 2
    assert result.key3 == 3
    assert result.key4 == 4

    #

# Generated at 2022-06-23 18:11:32.938744
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Basic
    assert to_namedtuple(
        {'a': 1}
    ) == namedtuple('NamedTuple', ['a'])(a=1)

    assert to_namedtuple(
        {'ab': 1}
    ) == namedtuple('NamedTuple', ['ab'])(ab=1)


# Generated at 2022-06-23 18:11:43.876785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for ``to_namedtuple``."""
    from types import SimpleNamespace
    import pytest
    from pytest import mark

    from flutils.namedtupleutils import to_namedtuple

    # Setup test data
    _dict = {'a': 1, 'b': 2, 'c_1': 3}
    _odict = OrderedDict(_dict)
    _tup = (1, 2, 3, 4)
    _list = list(_tup)
    _ns = SimpleNamespace(a=1, b=2, c=3)
    _nt = namedtuple('NamedTuple', 'a b c')
    _named = _nt(1, 2, 3)
    _named_dict = {'a': 1, 'b': 2, 'c': 3}

    NamedTuple

# Generated at 2022-06-23 18:11:48.771681
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'i': 3, 'j': 4, 'k': 5}
    nt_dic = to_namedtuple(dic)

    print(type(nt_dic))
    print(nt_dic)
    print(nt_dic.i)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:11:59.137399
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from tests.utils import TestCase

    class Test(TestCase):
        def test_list(self):
            dic = {'a': 1, 'b': 2}
            dic_tuple = dict(a=1, b=2)
            order_dic = OrderedDict(a=1, b=2)
            simple_namespace = SimpleNamespace(a=1, b=2)
            lst = [dic, dic_tuple, order_dic, simple_namespace]
            new_lst = to_namedtuple(lst)
            msg = ("Unable to create NamedTuple from %s" % lst)
            self.assertIsInstance(new_lst, list, msg=msg)

# Generated at 2022-06-23 18:12:11.545867
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2,
    }
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out._asdict() == dic
    dic = OrderedDict(a=1, b=2)
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out._asdict() == dic
    out = to_namedtuple(out)
    assert out.a == 1
    assert out.b == 2
    assert out._asdict() == dic
    ns = SimpleNamespace(a=1, b=2)
    out = to_namedtuple(ns)
    assert out.a == 1
    assert out

# Generated at 2022-06-23 18:12:20.849833
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import itertools
    import random
    import string

    ascii_letters = [chr(x) for x in range(32, 127)]
    letters = ''.join(ascii_letters)
    letters = ''.join(sorted(set(letters)))
    letters = ''.join(
        filter(
            lambda x: not x.isalpha() and x not in string.ascii_letters,
            letters
        )
    )

    def random_string(length: int = None) -> str:
        if length is not None:
            return ''.join(random.sample(letters, length))
        return ''.join(random.sample(letters, random.randint(1, 10)))

    def random_identifier() -> str:
        letters = string.ascii_letters

# Generated at 2022-06-23 18:12:29.689789
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class C(dict):
        pass


    class D(dict):
        def keys(self):
            for k in super().keys():
                yield k.upper()


    class E(Mapping):
        def __init__(self, data: dict) -> None:
            self._data = data

        def __len__(self) -> int:
            return len(self._data)

        def __getitem__(self, k):
            return self._data[k]

        def __iter__(self):
            return iter(self._data)

        def keys(self):
            for k in self._data.keys():
                yield k.upper()


    class F(Mapping):
        _data = dict(a=1, B=2, c=3)


# Generated at 2022-06-23 18:12:32.362663
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-23 18:12:39.782247
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) ==  namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) ==  namedtuple('NamedTuple', 'a b')(a=1, b=2)
    ordered_dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(ordered_dic) ==  namedtuple('NamedTuple', 'a b')(a=1, b=2)
    lst = [1, 2]
    assert to_namedtuple(lst) == [1, 2]

# Generated at 2022-06-23 18:12:51.625669
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([{}]) == [NamedTuple(**{})]
    assert to_namedtuple([{'a': 1}]) == [NamedTuple(**{'a': 1})]
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(**{'a': 1, 'b': 2})]
    assert to_namedtuple([{'a': 1, 'b': 2, 'c': 3}]) == [NamedTuple(**{'a': 1, 'b': 2, 'c': 3})]
    assert to_namedtuple([{'a': 1, 'Bb': 2, 'c': 3}]) == [NamedTuple(**{'a': 1, 'c': 3})]

    assert to_namedt

# Generated at 2022-06-23 18:12:58.717663
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils as namedtupleutils

    dic = {'a': 1, 'b': 2}
    assert namedtupleutils.to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)

    dic = {'a': 1, 'b': 2, '3': 3}
    assert namedtupleutils.to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)

    dic = {'a': 1, 'b': 2, '': 3}
    assert namedtupleutils.to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)



# Generated at 2022-06-23 18:13:10.164168
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    # Function is tested in doctest.
    to_namedtuple.__test__ = False  # type: ignore

    # noinspection PyPep8Naming,PyShadowingNames
    def test(obj: Any, expected: Any) -> None:
        out = to_namedtuple(obj)
        assert out == expected
        if not isinstance(obj, dict):
            assert isinstance(out, obj.__class__)

    test([], [])
    test([{'a': 1, 'b': 2}, {'c': 3}], [NamedTuple(a=1, b=2), NamedTuple(c=3)])
    test([1, 2, 3], [1, 2, 3])

    test({}, NamedTuple())
   

# Generated at 2022-06-23 18:13:19.386473
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]
    assert to_namedtuple([{'a': [1, 2], 'b': 2}, {'a': 3, 'b': 4}]) == [NamedTuple(a=[1, 2], b=2), NamedTuple(a=3, b=4)]

# Generated at 2022-06-23 18:13:24.857130
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data1 = {
        'a': 1,
        'b': 2
    }
    data2 = [
        1,
        {'a': 1, 'b': 2},
        3
    ]
    data3 = [
        1,
        {'a': [
            {'b': 'a'},
            {'c': 'b'},
            'd'
        ]},
        3
    ]
    data4 = {
        'a': 1,
        'b': '_b'
    }
    data5 = {
        'a': 1,
        '_b': 2
    }
    data6 = [
        1,
        {'a': 1, 'b': 2, 'c': 3},
        3,
        'a'
    ]

# Generated at 2022-06-23 18:13:32.388798
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    # test known input types
    good_inputs = [
        ([1, 2, {'a': 1}], list),
        (OrderedDict([('a', 1), ('b', 2)]), OrderedDict),
        ({'a': 1, 'b': 2}, dict),
        ((1, 2, {'a': 1}), tuple),
    ]
    for val, val_type in good_inputs:
        nt_obj = to_namedtuple(val)
        assert isinstance(nt_obj, NamedTuple)
        assert isinstance(val, val_type)
        assert nt_obj.a == val['a']
        if hasattr(val, 'b'):
            assert nt_obj.b == val['b']

# Generated at 2022-06-23 18:13:34.277977
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # TODO: Add unit tests, particularly for failing cases.
    pass

# Generated at 2022-06-23 18:13:43.206949
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import random, randrange
    from string import ascii_letters
    from typing import Dict

    def make_random(
            n: int = 1,
            sep: str = '',
    ) -> str:
        return sep.join((ascii_letters[randrange(0, 26)]
                         for i in range(n)))

    def convert_it(to_c: Any) -> None:
        if isinstance(to_c, (Dict, OrderedDict, SimpleNamespace)):
            to_c.__dict__
        elif isinstance(to_c, (tuple, frozenset, list)):
            list(to_c)
        else:
            to_c


# Generated at 2022-06-23 18:13:53.386454
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj_dict = {'a': 1, 'b': 2}
    obj_dict_dup = {'a': 1, 'a': 2}
    obj_dict_key_not_valid = {'a': 1, '_b': 2}
    obj_dict_key_valid = {'a': 1, '_a': 2}
    obj_dict_dup_key_not_valid = {'a': 1, '_a': 2, '_a': 3}

    obj_list = [obj_dict, obj_dict_key_not_valid, obj_dict_key_valid,
                obj_dict_dup_key_not_valid]

    order_dict = OrderedDict([('a', 1), ('b', 2)])

# Generated at 2022-06-23 18:13:59.197612
# Unit test for function to_namedtuple
def test_to_namedtuple():
    
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple

    ###INPUTS###
    # Example 1
    dic = {'a': 1, 'b': 2}
    # Example 2
    lst = [{'a': 1, 'b': 2}, {'a': 1}]
    # Example 3
    lst_name = ['Eric', 'Bill', 'Bob']
    # Example 4
    dic2 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    # Example 5
    dic3 = {'a': 1, 'b': 2, 'c': dic2}
    # Example 6

# Generated at 2022-06-23 18:14:07.135536
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': [1, 2, 3]}) == namedtuple('NamedTuple', 'a')(a=[1, 2, 3])
    assert to_namedtuple({'a': {'a': 1, 'b': 2}}) == namedtuple('NamedTuple', 'a')(a=namedtuple('NamedTuple', 'a b')(a=1, b=2))

# Generated at 2022-06-23 18:14:09.442564
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:14:17.733248
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple((1, 2, 'a', ['b', (3, [4, 5])], 6)) == (1, 2, 'a', ['b', (3, [4, 5])], 6)
    assert to_namedtuple((1, 2, 'a', OrderedDict([('b', 2)]), 6))

# Generated at 2022-06-23 18:14:29.367441
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest
    from typing import Dict
    from collections import (
        OrderedDict,
        namedtuple,
    )
    NewNamedTuple = namedtuple('NewNamedTuple', 'a b c d')
    _AllowedTypes = Union[
        Dict[str, Any],
        List[int],
        OrderedDict[str, Any],
        NewNamedTuple,
        Tuple[int, int, int],
    ]
    _obj: _AllowedTypes
    def test_dict():
        _obj = OrderedDict(a=1, b=2, c=3)
        assert to_namedtuple(_obj) == NewNamedTuple(a=1, b=2, c=3)


# Generated at 2022-06-23 18:14:35.648748
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(
        [OrderedDict({'a': 'one', 'b': 'two'})]
    )[0]._fields == ('a', 'b')
    assert to_namedtuple(
        [{'a': 'one', 'b': 'two'}]
    )[0]._fields == ('a', 'b')
    assert to_namedtuple(
        [{'b': 'two', 'a': 'one'}]
    )[0]._fields == ('b', 'a')
    assert to_namedtuple(
        [{'b': 'two', 'a': 'one', '_c': 'three'}]
    )[0]._fields == ('b', 'a')

# Generated at 2022-06-23 18:14:43.873853
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic1 = {'a': 1, 'b': 2}
    dic2 = {'d': 3, 'c': 4}
    lst1 = [dic1, dic2]
    lst2 = [dic1, dic2, lst1]

    assert to_namedtuple(dic1) == namedtuple('test', sorted(dic1.keys()))(
        **dic1
    )
    assert to_namedtuple(dic2) == namedtuple('test', sorted(dic2.keys()))(
        **dic2
    )


# Generated at 2022-06-23 18:14:54.474498
# Unit test for function to_namedtuple
def test_to_namedtuple():
    ans = 'NamedTuple(a=1, b=2, c=NamedTuple(d=NamedTuple(e=5)))'
    dic = {'a': 1, 'b': 2, 'c': {'d': {'e': 5}}}
    assert ans == repr(to_namedtuple(dic))
    ans = (1, 2, 3)
    assert ans == to_namedtuple(ans)
    ans = (1, NamedTuple(a=1, b=2), 3)
    assert ans == to_namedtuple(ans)
    ans = (1, [2.0, 2, 1], 3)
    assert ans == to_namedtuple(ans)
    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2


# Generated at 2022-06-23 18:15:03.516141
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dict_nm = to_namedtuple({'a': 1, 'b': 2})
    assert dict_nm.a == 1
    assert dict_nm.b == 2

    dict_t = to_namedtuple(OrderedDict((('a', 1), ('b', 2))))
    assert dict_t.a == 1
    assert dict_t.b == 2

    list_dict_nm = to_namedtuple([
        {'a': 1, 'b': 2},
        {'c': 3, 'd': 4},
    ])
    assert list_dict_nm[0].a == 1
    assert list_dict_nm[0].b == 2
    assert list_dict_nm[1].c == 3
    assert list_dict_nm[1].d == 4

    list_dict_nm_2 = to_

# Generated at 2022-06-23 18:15:15.887048
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # pylint: disable=no-member

    assert to_namedtuple(dict(a=1, b=2, c3=3)) == namedtuple('NamedTuple', 'a b c3')(a=1, b=2, c3=3)
    assert to_namedtuple(OrderedDict((('a', 1), ('b', 2), ('c3', 3)))) == namedtuple('NamedTuple', 'a b c3')(a=1, b=2, c3=3)
    assert to_namedtuple(SimpleNamespace(a=1, b=2, c3=3)) == namedtuple('NamedTuple', 'a b c3')(a=1, b=2, c3=3)

# Generated at 2022-06-23 18:15:21.524023
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from copy import copy
    from flutils.namedtupleutils import to_namedtuple
    d1 = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    d2 = {
        '1': 'one',
        '2': 'two',
        '3': 'three',
    }
    d3 = {
        'abc': 'abc',
        'def': 'def',
        'ghi': 'ghi',
    }
    a = [d1, d2, d3]
    a_copy = copy(a)
    d1_copy = copy(d1)
    d2_copy = copy(d2)
    d3_copy = copy(d3)
    nt = to_namedtuple(a)
    assert len(nt)

# Generated at 2022-06-23 18:15:30.209686
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1, 'b': 2}) == \
        namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2, 2: 1}) == \
        namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple({2: 1}) == namedtuple('NamedTuple', '')()

# Generated at 2022-06-23 18:15:38.917526
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple


    class Complex(NamedTuple):
        a: int
        b: int
        c: int


    class Complex2(NamedTuple):
        a: int


    class Complex3(NamedTuple):
        a: int
        b: int


    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == Complex3(a=1, b=2)
    li = [1, 2, 3]
    assert to_namedtuple(li) == tuple(li)
    named = Complex(a=1, b=2, c=3)
    assert to_namedtuple(named) == named
    ordered_dic = OrderedDict

# Generated at 2022-06-23 18:15:49.098736
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyTypeChecker
    class ClassDict(dict):
        pass
    obj = to_namedtuple({'a': 1, 'b': 2})
    assert obj.a == 1
    assert obj.b == 2
    obj = to_namedtuple({'a': 1, 'b': 2, 'c': ClassDict({'d': 3, 'e': 4})})    # noqa: E501
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c.d == 3
    assert obj.c.e == 4
    obj = to_namedtuple([1, 2, 3])
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3

# Generated at 2022-06-23 18:15:56.239350
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        '': [1, 2, 3],
        'a': [4, 5, 6],
        'b': [7, 8, 9],
    }
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert isinstance(out.a, list)
    assert isinstance(out.b[0], int)



# Generated at 2022-06-23 18:15:58.707390
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest # type: ignore[import]
    doctest.testmod(optionflags=doctest.IGNORE_EXCEPTION_DETAIL)

# Generated at 2022-06-23 18:16:07.869567
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    from types import MappingProxyType

    dic = {'a': 1, 'b': 2}
    named_tuple = to_namedtuple(dic)
    assert named_tuple == cast(NamedTuple, namedtuple('NamedTuple', 'a b')(1, 2))
    assert named_tuple.a == 1
    assert named_tuple.b == 2
    dic = {'a': 1, 'b': 2, '_c': 3}
    named_tuple = to_namedtuple(dic)
    assert named_tuple == cast(NamedTuple, namedtuple('NamedTuple', 'a b')(1, 2))
    assert named_tuple.a == 1
    assert named_tuple.b == 2