

# Generated at 2022-06-23 18:06:13.712042
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lst = [1, 2, 3, 4]
    tup = tuple(lst)
    ntuple = namedtuple('ntuple', 'a b c d')(*tup)
    dct = {'a': 1, 'b': 2}
    assert to_namedtuple(lst) == lst
    assert to_namedtuple(tup) == tup
    assert to_namedtuple(ntuple) == ntuple
    assert to_namedtuple(dct) == ntuple



# Generated at 2022-06-23 18:06:20.821974
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pformat
    from types import SimpleNamespace
    from unittest.mock import Mock

    # noinspection PyPep8,PyTypeChecker
    dic: Mapping = {'a': 1, 'b': 2, 'c': {'c1': 11, 'c2': 12}, 'd': [1, 2]}
    expected = SimpleNamespace
    expected.a = 1
    expected.b = 2
    expected.c = SimpleNamespace
    expected.c.c1 = 11
    expected.c.c2 = 12
    expected.d = [1, 2]
    result = to_namedtuple(dic)
    assert result == expected
    assert pformat(result) == pformat(expected)
    assert result.__dict__ == expected.__dict__

# Generated at 2022-06-23 18:06:29.920468
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple

    nt = namedtuple('NamedTuple', 'a b c d e f')
    nt2 = namedtuple('NamedTuple2', 'a b c d e f')

    dic = {'a': 1, 'b': 2, 'c': 3}
    ord_dic = OrderedDict(dic)
    dic_in_dic = {'a': dic, 'b': 2}
    out: NamedTuple = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3

    out = to_namedtuple(ord_dic)
   

# Generated at 2022-06-23 18:06:40.794652
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=NamedTuple(d=4, e=5))

    dic = OrderedDict(a=1, b=2, c=3)
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    sns = SimpleNamespace(a=1, b=2)
    assert to

# Generated at 2022-06-23 18:06:52.573618
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'number': 2, 'decimal': 2.0, 'string': 's', 'tuple': (1, 2, 3)}
    dic['dic'] = {'A': 'a', 'B': 'b'}
    dic['list'] = [1, 2, 3]
    dic['namespace'] = SimpleNamespace(a=1, b=2)
    dic['list'].append(SimpleNamespace(a=1, b=2))

    dic['dic']['namespace'] = SimpleNamespace(a=1, b=2)

    out = to_namedtuple(dic)
    assert out.number == dic['number']
    assert out.decimal == dic['decimal']
    assert out.string == dic['string']
    assert out.t

# Generated at 2022-06-23 18:07:01.980149
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    
    d = {'a':1, 'b':2}
    assert to_namedtuple(d) == ('a', 'b')
    
    l = ['a', 'b']
    assert to_namedtuple(l) == l
    
    t = ('a', 'b')
    assert to_namedtuple(t) == t
    
    od = OrderedDict(a=1, b=2, c=3)
    assert to_namedtuple(od) == ('a', 'b', 'c')
    
    ns = SimpleNamespace(a=1, b=2, c=3)
    assert to_namedtuple(ns) == ('a', 'b', 'c')
    

# Generated at 2022-06-23 18:07:13.385575
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyShadowingBuiltins
    dic = {'a': 1, 'b': 2}

    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) != NamedTuple(b=2, a=1)

    dic = OrderedDict(a=1, b=2, c=3)
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    # noinspection PyUnresolvedReferences
    assert to_namedtuple(tuple(dic.keys())) == NamedTuple('a', 'b', 'c')


# Generated at 2022-06-23 18:07:17.749222
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple"""
    assert to_namedtuple(a=1, b=2) == NamedTuple(a=1, b=2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict((('a', 1), ('b', 2)))) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:07:29.581739
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from copy import copy
    from collections import namedtuple
    from types import SimpleNamespace
    from typing import List


    def _v(a, b):
        """Helper to compare tuples"""
        assert a == b


    def _nv(a, b):
        """Helper to compare named tuples"""
        assert a == b
        assert a._fields == b._fields


    # noinspection PyStatementEffect
    _v(
        to_namedtuple({}),
        NamedTuple()
    )
    _v(
        to_namedtuple({'a': 1, 'b': 2}),
        NamedTuple(a=1, b=2)
    )

# Generated at 2022-06-23 18:07:31.417366
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:07:42.874221
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple([1, {'b': 2, 'c': 'three'}]) == [1, namedtuple('NamedTuple', 'b c')(b=2, c='three')]
    assert to_namedtuple([1, {'b': 2, 'c': 'three'}]) == [1, namedtuple('NamedTuple', 'b c')(b=2, c='three')]
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

# Generated at 2022-06-23 18:07:52.264984
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(OrderedDict([('b', 2), ('a', 1)])) == \
        namedtuple('NamedTuple', 'b a')(b=2, a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == \
        namedtuple('NamedTuple', 'a b')(a=1, b=2)

# Generated at 2022-06-23 18:08:00.536890
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == (1, 2)
    assert to_namedtuple([{'a': 1}, {'b': 2}]) == [(1,), (2,)]
    assert to_namedtuple([{'a': 1}, {'b': 2}]) == [(1,), (2,)]
    assert to_namedtuple({'a': {'b': {'c': 1, 'd': 2}}}) == (1, 2)
    assert to_namedtuple({'a': SimpleNamespace(a=1, b=2)}) == (1, 2)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:08:11.988618
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections.abc import Mapping, Sequence

    dic = {'a': 1, 'b': 2}
    assert isinstance(dic, Mapping)
    assert isinstance(to_namedtuple(dic), namedtuple)

    # noinspection PyTypeChecker
    lst = [1, 2]
    assert isinstance(lst, Sequence)
    assert isinstance(to_namedtuple(lst), list)
    assert isinstance(to_namedtuple(lst)[0], namedtuple)
    assert isinstance(to_namedtuple(lst)[1], namedtuple)

    # noinspection PyTypeChecker
    tup = (1, 2)
    assert isinstance(tup, Sequence)
    assert isinstance

# Generated at 2022-06-23 18:08:24.947928
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple

    # Test function name
    assert to_namedtuple.__name__ == 'to_namedtuple'

    # Test to_namedtuple with a dict.
    dic = {'a': 1, 'b': 2}
    make_empty = namedtuple('NamedTuple', '')
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) != make_empty()
    dic_str = {'a': 'a', 'b': 'b'}
    assert to_namedtuple(dic_str) == NamedTuple(a='a', b='b')

    # Test to_namedtuple with objects that cannot be converted.


# Generated at 2022-06-23 18:08:30.289340
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple((1, 2, 3)) == NamedTuple(_1=1, _2=2, _3=3)
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(NamedTuple(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedt

# Generated at 2022-06-23 18:08:43.188684
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    from flutils.namedtupleutils import to_namedtuple
    obj = {
        'a': 1,
        'b': 2,
        'c': {
            'foo': {
                'bar': 'baz'
            }
        }
    }
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2
    assert out.c.foo.bar == 'baz'

# Generated at 2022-06-23 18:08:53.847946
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple({1: 2}) == NamedTuple(**{1: 2})
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 1: 3}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([(1, 2), ('a', 1)])) == NamedTuple(a=1)
    assert to_namedtuple(OrderedDict([('a', 1), (1, 2)])) == NamedTuple(a=1)
    assert to_namedtuple(['a', 1, {'b': 2}])

# Generated at 2022-06-23 18:09:02.277407
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import collections
    import json

    class ToNamedTupleTest(unittest.TestCase):
        def test_list(self):
            data = [1, 2]
            expected = [1, 2]
            actual = to_namedtuple(data)
            self.assertEqual(expected, actual)

        def test_dict(self):
            data = {'a': 1, 'b': 2}
            expected = collections.namedtuple('NamedTuple', 'a b')(a=1, b=2)
            actual = to_namedtuple(data)
            self.assertEqual(expected, actual)

        def test_simple_namespace(self):
            data = collections.SimpleNamespace(a=1, b=2)

# Generated at 2022-06-23 18:09:11.259211
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from types import SimpleNamespace
    from collections import OrderedDict
    from flutils.miscutils import deep_update_dict
    from flutils.validators import is_string

    # noinspection PyUnusedLocal
    def test_to_namedtuple_helper(new_obj, cur_obj, key, update_name=None):
        if not update_name:
            update_name = key
        if is_string(new_obj[key]):
            new_obj[key] = {
                'address': '1234',
                'city': 'TestTown'
            }
        else:
            new_obj[key]['address'] = '1234'
            new_obj[key]['city'] = 'TestTown'

# Generated at 2022-06-23 18:09:23.218564
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # SimpleNamespace works.
    from types import SimpleNamespace as SN
    dic = {'a': 1, 'b': 2}
    sn = SN(**dic)
    nt = to_namedtuple(sn)
    assert nt == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Dictionary works.
    nt = to_namedtuple(dic)
    assert nt == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # Dictionary works (with alphabetical sorted attributes).
    dic = {'b': 2, 'a': 1}
    nt = to_namedtuple(dic)

# Generated at 2022-06-23 18:09:34.808792
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lst = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    tpl = tuple(lst)
    dct = dict(lst)
    nms = SimpleNamespace(**dct)
    ord_dct = OrderedDict(lst)
    nt1 = namedtuple('NamedTuple', 'a b')
    nt2 = namedtuple('NamedTuple', 'c d')
    nts = [nt1(1, 2), nt2(3, 4)]
    out_list: List[NamedTuple] = to_namedtuple(lst)
    assert isinstance(out_list, list)
    assert isinstance(out_list[0], NamedTuple)

# Generated at 2022-06-23 18:09:42.135359
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # pylint: disable=invalid-name
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    dic_keys = list(sorted(dic.keys()))
    obj = to_namedtuple(dic)

    # to_namedtuple is a namedtuple
    assert isinstance(obj, NamedTuple)
    # to_namedtuple namedtuple keys are in alphabetical order
    assert obj._fields == dic_keys
    # to_namedtuple namedtuple values are the same as the original
    assert len(obj) == len(dic_keys)
    for key in dic_keys:
        assert getattr(obj, key) == dic[key]

    # Tests for a list

# Generated at 2022-06-23 18:09:46.643506
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    import random
    import string
    import timeit

    from flutils.randomutils import get_random_alphanumeric
    from flutils.timing import Timing
    from flutils.typesutils import is_simple_type

    # Each test will be run 10 times.
    timings = Timing()
    tests = 10

    # Make sure it errors appropriately
    try:
        to_namedtuple(1)
    except TypeError:
        pass
    else:
        raise AssertionError('`to_namedtuple` did not raise an error.')

    # Make sure it handles empty dicts
    exp_empty = namedtuple('NamedTuple', '')()
    no_empty = to_namedtuple({})
    assert exp_empty == no_empty

# Generated at 2022-06-23 18:09:52.489765
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    nt1 = namedtuple('nt1', 'a, b', defaults=(None, None))()
    dic = {'a': 1, 'b': 2}
    nt2 = to_namedtuple(dic)
    nt1.a = nt2.a
    nt1.b = nt2.b
    assert nt1 == nt2
    lst1 = to_namedtuple(['a', 'b', 'c', 'd'])
    assert lst1 == ['a', 'b', 'c', 'd']
    lst2 = to_namedtuple(['a', 'b', {'a': 'b', 'c': 'd'}, 'd'])
    assert l

# Generated at 2022-06-23 18:09:54.087309
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'a':1, 'b':2}
    
    out = to_namedtuple(d)

    assert out.a == 1
    assert out.b == 2

# Unit test the import

# Generated at 2022-06-23 18:10:05.629975
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import collections
    import types
    # noinspection PyTypeChecker
    obj: Any = [
        {'id': 100, 'name': 'A'},
        {'id': 101, 'name': 'B'},
        {'id': 102, 'name': 'C'},
    ]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert len(out) == 3
    for item in out:
        assert isinstance(item, collections.namedtuple)
        assert hasattr(item, 'id')
        assert hasattr(item, 'name')
        assert item.id is not None
        assert item.name is not None
    # noinspection PyTypeChecker

# Generated at 2022-06-23 18:10:13.741666
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == NamedTuple()
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == NamedTuple(1, 2, 3)
    assert to_namedtuple([{}]) == [NamedTuple()]
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 'b'}) == NamedTuple(a='b')
    assert to_namedtuple([{'a': 1}]) == [NamedTuple(a=1)]

# Generated at 2022-06-23 18:10:24.931805
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(dict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(list(dict(a=1, b=2).items())) == [('a', 1), ('b', 2)]
    assert to_namedtuple(tuple(dict(a=1, b=2).items())) == (('a', 1), ('b', 2))
    assert to_namedtuple(list(([1, 2], [3, 4]))) == [(1, 2), (3, 4)]

# Generated at 2022-06-23 18:10:31.332760
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    from collections import (
        OrderedDict,
    )

    from flutils.namedtupleutils import to_namedtuple

    # Test with a Mapping
    d1: Mapping[str, Any] = {
        'now': datetime.now(),
        '_val': None,
    }
    out1: NamedTuple = to_namedtuple(d1)
    assert isinstance(out1, namedtuple)
    assert hasattr(out1, 'now')
    assert hasattr(out1, '_val') is False

    d2 = {
        'k1': None,
        'k2': d1,
    }
    out2: NamedTuple = to_namedtuple(d2)
    assert isinstance(out2, namedtuple)
   

# Generated at 2022-06-23 18:10:35.859044
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import patch
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections.abc import Sequence
    from types import SimpleNamespace
    from typing import Dict
    from typing import List
    from typing import Union
    from flutils.namedtupleutils import to_namedtuple

    # noinspection PyUnusedFunction,PyTypeChecker
    def _make_obj_hierarchy() -> Union[Dict[str, Any], SimpleNamespace]:
        dic: Dict[str, Any] = {}
        dic['_name'] = 'namedtuple'
        dic['simple_name'] = 'simple'
        dic['lst'] = [1, 2, 3]

# Generated at 2022-06-23 18:10:46.429484
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test that the code supports the type of objects given.
    def _test_to_namedtuple(obj: Any, exp_type: Any = None) -> bool:
        """
        Test to_namedtuple() for the given object for both given and
        returned object types.
        """
        if exp_type is None:
            exp_type = obj
        new_obj = to_namedtuple(obj)
        return isinstance(new_obj, exp_type.__class__)

    # Given object type and expected type:
    #    (obj, exp_type)

# Generated at 2022-06-23 18:10:55.964764
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:11:06.727175
# Unit test for function to_namedtuple
def test_to_namedtuple():  # pragma: no cover
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections import namedtuple
    import json

    T = namedtuple('T', 'one two three')
    t = T(one=10, two=20, three=30)
    assert hasattr(t, 'one') is True
    assert hasattr(t, 'two') is True
    assert hasattr(t, 'three') is True

    attr_names = ['one', 'two', 'three']
    dic = OrderedDict()
    for attr in attr_names:
        dic[attr] = getattr(t, attr)
    assert isinstance(dic, Mapping)
    out = to_namedtuple(dic)
    assert out is not None
    assert out == t

# Generated at 2022-06-23 18:11:15.036924
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([{'a': 1, 'b': 2}, {'b': 2, 'a': 1}]) == [NamedTuple(a=1, b=2), NamedTuple(a=1, b=2)]
    assert to_namedtuple([{'a': 1, 'b': 2}, {'b': 2, 'a': 1}, {'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2), NamedTuple(a=1, b=2), NamedTuple(a=1, b=2)]
    assert to_namedtuple(({'a': 1, 'b': 2}, {'b': 2, 'a': 1})) == (NamedTuple(a=1, b=2), NamedTuple(a=1, b=2))

# Generated at 2022-06-23 18:11:24.652729
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = {'a': 1, 'b': 2}
    assert to_namedtuple(a) == NamedTuple(a=1, b=2)

    a = {'a': 1, 'b': {'x': 1, 'y': 2}}
    assert to_namedtuple(a) == NamedTuple(a=1, b=NamedTuple(x=1, y=2))

    a = OrderedDict({'a': 1, 'b': {'x': 1, 'y': 2}})
    assert to_namedtuple(a) == NamedTuple(a=1, b=NamedTuple(x=1, y=2))

    a = SimpleNamespace(a=1, b=2)

# Generated at 2022-06-23 18:11:35.048611
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    import flutils.namedtupleutils

    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import _to_namedtuple, to_namedtuple

    class A(collections.UserDict):
        def __init__(self, *args, **kwargs):
            self.__dict__ = self
            super().__init__(*args, **kwargs)

    class B:
        def __init__(self, *args, **kwargs):
            for key, val in kwargs.items():
                setattr(self, key, val)

        def keys(self) -> List[Any]:
            return list(self.__dict__.keys())

    class C:
        def keys(self) -> List[Any]:
            return list(self.__dict__.keys())



# Generated at 2022-06-23 18:11:45.525446
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from flutils.namedtupleutils import to_namedtuple as tt

    assert tt(1) == 1
    assert tt('1') == '1'

    dic = {'a': 1, 'c': 2, 'b': 3}
    ans = tt(dic)
    assert ans[0] == 1
    assert ans[1] == 3
    assert ans[2] == 2
    assert isinstance(ans, namedtuple)
    assert list(ans._fields) == ['a', 'b', 'c']

    dic = OrderedDict()
    dic['a'] = 1
    dic['c'] = 2
    dic['b'] = 3
    ans = tt(dic)
    assert ans[0] == 1
    assert ans[1] == 2

# Generated at 2022-06-23 18:11:57.011633
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        """Test function to_namedtuple."""
        # pylint: disable=too-many-public-methods

        def test_not_list_or_tuple_or_dict(self):
            """Test when not list, tuple or dict is given."""
            test_input = 'this is a test'
            with self.assertRaises(TypeError):
                to_namedtuple(test_input)

        def test_list_no_namedtuple(self):
            """Test that no NamedTuples in list."""
            test_input = ['test1', 'test2']
            expected_output = ['test1', 'test2']
            actual_output = to_namedtuple(test_input)

# Generated at 2022-06-23 18:12:08.809912
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    from typing import Dict, List

    from flutils.namedtupleutils import to_namedtuple
    
    dic = {
        'foo': 'bar',
        'baz': {'one': 1, 'two': 2, 'three': 3},
        'quux': ['quux1', 'quux2', 'quux3'],
        'quuz': ('quuz1', 'quuz2', 'quuz3'),
    }
    print('\nConvert dict to namedtuple')
    named_tuple: NamedTuple = to_namedtuple(dic)
    pprint(named_tuple)
    print(type(named_tuple))
    print('\nnamespace.baz')
    pprint(type(named_tuple.baz))


# Generated at 2022-06-23 18:12:17.126256
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pprint



# Generated at 2022-06-23 18:12:23.776870
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections

    class O(object):
        def __init__(self):
            self.a = 1
            self.b = 2

    dic = {'a': 1, 'b': 2}
    odic = collections.OrderedDict(dic)
    sns = collections.SimpleNamespace()
    sns.a = 1
    sns.b = 2
    o = O()
    l = [1, 2]
    t = (1, 2)
    s = 'asdf'
    nt = collections.namedtuple('NamedTuple', ('a', 'b'))(1, 2)

    ndic = to_namedtuple(dic)
    assert ndic.a == 1
    assert ndic.b == 2
    assert ndic[0] == 1
   

# Generated at 2022-06-23 18:12:35.605357
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test conversion of various objects to a NamedTuple"""
    # noinspection PyUnusedLocal
    def dump_obj(obj):
        """Helper function to display the given object"""
        import json
        msg = json.dumps(obj.__repr__(), sort_keys=True, indent=2)
        return msg

    # noinspection PyPep8Naming
    def test_dict_to_namedtuple(in_dic, expected, id_=None):
        """Test conversion of a dictionary to a NamedTuple"""
        got = to_namedtuple(in_dic)
        try:
            assert got == expected
        except AssertionError as ex:
            err = 'Failure'

# Generated at 2022-06-23 18:12:47.927228
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    class _Test(NamedTuple):
        a: int
        b: int

    dic: OrderedDict = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    out = to_namedtuple(dic)
    assert isinstance(out, _Test)
    assert out.a == 1
    assert out.b == 2

    dic['c'] = 'hello'
    out = to_namedtuple(dic)
    assert isinstance(out, _Test)
    assert out.a == 1
    assert out.b == 2

# Generated at 2022-06-23 18:12:57.194376
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    lst = [
        {'a': 1, 'b': 2},
        {'c': 3, 'd': 4},
        {'c': 3, 'd': 4},
    ]
    assert to_namedtuple(lst) == [
        NamedTuple(a=1, b=2),
        NamedTuple(c=3, d=4),
        NamedTuple(c=3, d=4),
    ]
    t = (
        {'a': 1, 'b': 2},
        {'c': 3, 'd': 4},
        {'c': 3, 'd': 4},
    )
    assert to_

# Generated at 2022-06-23 18:13:08.063875
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:13:18.172852
# Unit test for function to_namedtuple
def test_to_namedtuple():
    names = ["alice", "bob"]
    ages = [1, 2]
    cars = ["s", "m"]
    lst = [names, ages, cars]
    lst_output = to_namedtuple(lst)
    assert(lst_output[0].__class__) == NamedTuple
    assert(lst_output[1].__class__) == NamedTuple
    assert(lst_output[2].__class__) == NamedTuple

    names = ["alice", "bob"]
    ages = [1, 2]
    tup = (names, ages)
    tup_output = to_namedtuple(tup)
    assert(tup_output[0].__class__) == NamedTuple
    assert(tup_output[1].__class__) == NamedT

# Generated at 2022-06-23 18:13:27.247331
# Unit test for function to_namedtuple
def test_to_namedtuple():

    x = [{'a': 1, 'b': 2}, [1,2,3], 'a', True]
    ans = [(1, 2), (1, 2, 3), 'a', True]
    assert tuple(to_namedtuple(x)) == ans

    dic = {'a': 1, 'b': 2}
    ans = NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == ans

    tup = (1, 2)
    ans = (1, 2)
    assert to_namedtuple(tup) == ans

    x = [{'a': [1,2,3], 'b': {'c': 4, 'd':{'e': 5, 'f': 6}}}, 'g', [7], True]

# Generated at 2022-06-23 18:13:39.357298
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    """Unit test for function to_namedtuple."""
    from collections import OrderedDict
    from types import SimpleNamespace
    import pytest

    # test with None
    with pytest.raises(TypeError):
        to_namedtuple(None)

    # test with integer
    with pytest.raises(TypeError):
        to_namedtuple(1)

    # test with string
    with pytest.raises(TypeError):
        to_namedtuple('a')

    # test with OrderedDict
    od = OrderedDict(a=1, b=2, c=3)
    result = to_namedtuple(od)
    assert hasattr(result, 'a')
    assert hasattr(result, 'b')

# Generated at 2022-06-23 18:13:51.258535
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    class TestCase(NamedTuple):
        obj: Any
        expected: Any
        desc: str

# Generated at 2022-06-23 18:13:52.208074
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _test_to_namedtuple()


# Generated at 2022-06-23 18:14:05.110476
# Unit test for function to_namedtuple
def test_to_namedtuple():
    vals = list(map(chr, range(97, 123)))
    dic = dict(zip(vals, vals))
    actl = to_namedtuple(dic)
    assert isinstance(actl, NamedTuple)
    assert actl.a == 'a'
    assert actl.z == 'z'
    tup = tuple((i, i) for i in vals)
    actl = to_namedtuple(tup)
    assert isinstance(actl, NamedTuple)
    assert actl.a == 'a'
    assert actl.z == 'z'
    l = list(zip(vals, vals))
    actl = to_namedtuple(l)
    assert isinstance(actl, list)
    assert actl[0].a == 'a'

# Generated at 2022-06-23 18:14:15.176855
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'b': 3, 'c': 4}]) == [
        namedtuple('NamedTuple', ['a', 'b'])(1, 2),
        namedtuple('NamedTuple', ['b', 'c'])(3, 4)
    ]
    assert to_namedtuple(OrderedDict({'a': 1, 'b': 2})) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)

# Generated at 2022-06-23 18:14:27.730886
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import NamedTuple
    from collections import OrderedDict
    from xml.etree import ElementTree
    from datetime import datetime

    # Testing list
    result_list: List[NamedTuple] = to_namedtuple(
        [
            OrderedDict(
                [
                    ('b', 2),
                    ('a', 1),
                    ('c', 3)
                ]
            ),
            OrderedDict(
                [
                    ('a', 'a'),
                    ('b', 'b'),
                    ('c', 'c')
                ]
            )
        ]
    )
    assert isinstance(result_list, list)
    assert len(result_list) == 2

    assert result_list[0].a == 1
    assert result_list[0].b == 2

# Generated at 2022-06-23 18:14:33.529910
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'a': 1, 'b': 2}
    assert to_namedtuple(d).a == 1
    assert to_namedtuple(d).b == 2

    d = {'a': {'c': 1}, 'b': 2}
    # noinspection PyTypeChecker
    assert to_namedtuple(d).a.c == 1
    assert to_namedtuple(d).b == 2

    d = {'a': {'c': {'d': 5}}, 'b': 2}
    # noinspection PyTypeChecker
    assert to_namedtuple(d).a.c.d == 5
    assert to_namedtuple(d).b == 2

    l = [1, 2, {'a': 3, 'b': 4}]

# Generated at 2022-06-23 18:14:41.178124
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.tests._testinglibraries.flutils_testresults import (
        assert_convert_type,
    )
    assert_convert_type(
        func=to_namedtuple,
        get_input=lambda: {
            'a': 1,
            'b': {'c': 3, 'd': 4}
        },
        get_expected=lambda: NamedTuple(a=1, b=NamedTuple(c=3, d=4))
    )

# Generated at 2022-06-23 18:14:53.096174
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    od = OrderedDict()
    od['a'] = 1
    od['b'] = 2
    od['c'] = OrderedDict()
    od['c']['d'] = 3
    od['c']['e'] = 4
    od['f'] = 5
    od['g'] = 6
    od['h'] = 7
    sn = SimpleNamespace(a=1, b=2, c=SimpleNamespace(d=3, e=4), f=5, g=6, h=7)
    out = to_namedtuple(sn)
    assert out.a == 1
    assert out.b == 2
    assert out.c.d == 3
    assert out.c.e == 4
    assert out.f == 5

# Generated at 2022-06-23 18:15:00.203550
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from functools import partial
    from inspect import Signature
    from typing import FrozenSet
    from flutils.namedtupleutils import to_namedtuple as tnt
    from flutils.validators import validate_identifier

    def _test_to_namedtuple(
            obj: Any,
            expected: Any
    ) -> None:
        out = tnt(obj)
        assert isinstance(out, type(expected))
        if isinstance(obj, (tuple, list)):
            exp = list(expected)
            for i, val in enumerate(out):
                assert val == exp[i]
            if isinstance(obj, tuple):
                out = tuple(out)

# Generated at 2022-06-23 18:15:12.634151
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace
    import uuid
    dic = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': {
            'e': 'f'
        }
    }
    new_dic = to_namedtuple(dic)
    assert isinstance(new_dic, namedtuple)
    assert new_dic.a == 1
    assert new_dic.c == 3
    assert new_dic.d.e == 'f'
    list_dic = [dic, dic, dic]
    new_list_dic = to_namedtuple(list_dic)

# Generated at 2022-06-23 18:15:23.996039
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'a': 1, 'b': 2}
    out = to_namedtuple(d)
    assert out.a == 1
    assert out.b == 2

    d = {'a': 1, 'b': 2}
    od = OrderedDict(d)
    out = to_namedtuple(od)
    assert out.a == 1
    assert out.b == 2

    d = {'b': 2, 'a': 1}
    out = to_namedtuple(d)
    assert out.a == 1
    assert out.b == 2

    lst = ['a', 1, 'b', 2, 'c', 3]
    out = to_namedtuple(lst)
    assert out == ('a', 1, 'b', 2, 'c', 3)


# Generated at 2022-06-23 18:15:31.394981
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import pytest
    from typing import List, Tuple

    #
    # Test: Mapping
    #

    dic = {
        'a': 1,
        'b': 2.0,
        'c': [3.0, 4.0],
        'd': ('x', 'y'),
        'e': {'e1': 5, 'e2': 6},
    }
    args, expected_args = dic.copy(), dic.copy()
    args['e'] = to_namedtuple(args['e'])
    expected_args['e'] = expected_args['e'].copy()
    expected_args['e'] = namedtuple('NamedTuple', sorted(
        expected_args['e'].keys()),
    )(**expected_args['e'])
    nt = to_

# Generated at 2022-06-23 18:15:42.316739
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    assert str(to_namedtuple([OrderedDict({'a': 1, 'b': 2})])) == \
        "[NamedTuple(a=1, b=2)]"
    assert str(to_namedtuple([OrderedDict({'a': 1, 'b': 2}),
                              OrderedDict({'a': 3, 'b': 4})])) == \
        '[NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]'
    assert to_namedtuple({'a': 1, 'b': 2}) == \
        namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)

# Generated at 2022-06-23 18:15:47.138350
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import patch
    from unittest import TestCase

    from . import to_namedtuple

    with patch('collections.namedtuple') as mocked:
        to_namedtuple({})
        mocked.assert_called_once()
    with patch('collections.namedtuple') as mocked:
        to_namedtuple([])
        mocked.assert_not_called()
    with patch('collections.namedtuple') as mocked:
        to_namedtuple(())
        mocked.assert_not_called()
    with patch('collections.namedtuple') as mocked:
        to_namedtuple('')
        mocked.assert_not_called()

    class NamedTuple(NamedTuple):
        __slots__ = ()


# Generated at 2022-06-23 18:15:58.400335
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    # Test converting a list
    x = to_namedtuple([1, 2, 3, 4, 5])
    assert type(x) == list
    assert x == [1, 2, 3, 4, 5]
    x = to_namedtuple(("a", "b", "c", "d", "e"))
    assert type(x) == tuple
    assert x == ("a", "b", "c", "d", "e")
    # Test converting a dict
    x = to_namedtuple({"a": 1, "b": 2})
    assert type(x) == namedtuple("NamedTuple", "a b")
    assert x.a == 1
    assert x.b == 2
    # Test converting an OrderedDict

# Generated at 2022-06-23 18:16:07.631138
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    # noinspection PyTypeChecker
    assert to_namedtuple([]) == []
    # noinspection PyTypeChecker
    assert to_namedtuple(([],),) == ([],)
    # noinspection PyTypeChecker
    assert to_namedtuple({}) == NamedTuple()()
    # noinspection PyTypeChecker
    assert to_namedtuple([{}]) == [NamedTuple()()]
    # noinspection PyTypeChecker
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    # noinspection PyTypeChecker
    assert to_namedtuple({'a': 1, '_b': 1}) == NamedTuple(a=1)
    # noinspection

# Generated at 2022-06-23 18:16:17.017954
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) == 1
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == \
        NamedTuple(a=1, b=2, c=3, d=4)
    assert to_namedtuple({'a': 1, 'b': 2, '3': 3, '4': 4}) == \
        NamedTuple(a=1, b=2)