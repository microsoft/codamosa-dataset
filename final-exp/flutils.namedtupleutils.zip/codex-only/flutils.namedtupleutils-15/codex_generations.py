

# Generated at 2022-06-23 18:06:21.008997
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    # Convert a list
    out = to_namedtuple(['foo', 1, 'bar', 2])
    assert out == ['foo', 1, 'bar', 2]
    assert isinstance(out, list)
    out = to_namedtuple(('foo', 1, 'bar', 2))
    assert out == ('foo', 1, 'bar', 2)
    assert isinstance(out, tuple)

    # Convert a dict
    ## Simple dict
    out = to_namedtuple({'a': 1, 'b': 2})

# Generated at 2022-06-23 18:06:30.007304
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    named = to_namedtuple(dic)
    assert named.a == 1
    assert named.b == 2
    dic = {'a': {'b': 1, 'c': 2}, 'd': 3}
    named = to_namedtuple(dic)
    assert named.a.b == 1
    assert named.a.c == 2
    assert named.d == 3
    dic = {'a': {'b': 1, 'c': 2}, 'd': [3, 4, 5]}
    named = to_namedtuple(dic)
    assert named.a.b == 1
    assert named.a.c == 2
    assert named.d[0] == 3
    assert named.d[1] == 4
    assert named

# Generated at 2022-06-23 18:06:31.106238
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=3)

# Generated at 2022-06-23 18:06:42.712033
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import random

# Generated at 2022-06-23 18:06:53.789580
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.scripts.typeshed import nt


# Generated at 2022-06-23 18:06:55.431319
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:07:03.782258
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from pytest import raises

    # Test base case with a dictionary.
    dic = {'a': 1}
    assert to_namedtuple(dic) == NamedTuple(a=1)

    # Test base case with an empty dictionary.
    dic = {}
    assert to_namedtuple(dic) == NamedTuple()

    # Test base case with an OrderedDict.
    dic = OrderedDict({'a': 1})
    assert to_namedtuple(dic) == NamedTuple(a=1)

    # Test base case with an empty OrderedDict.
    dic = OrderedDict({})
    assert to_namedtuple(dic) == NamedTuple()



# Generated at 2022-06-23 18:07:10.259742
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import _to_namedtuple
    import sys

    if sys.platform.startswith('win'):
        assert not hasattr(sys, 'frozen')
        assert 'site-packages' in sys.executable.lower()
        assert 'flutils' in sys.path[0].lower()
        assert 'site-packages' in sys.path[0].lower()
        assert 'flutils' in sys.prefix.lower()

    class testclass:
        pass

    test_list: List[Any] = [
        SimpleNamespace(x='x', y='y'),
        'string',
        testclass,
        1,
        2.0,
        3j,
        True,
        None,
    ]
    test_tuple: Tuple

# Generated at 2022-06-23 18:07:16.139137
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import datetime as dt
    from flutils.namedtupleutils import to_namedtuple

    now = dt.datetime.now()

    dic = OrderedDict(
        id=1,
        name='john',
        dict=dict(name='jane', age=21),
        list=['jeff', 'mike', 'jack'],
        now=now,
        tuple=tuple(range(4))
    )
    nt = to_namedtuple(dic)
    assert dic['id'] == nt.id
    assert dic['name'] == nt.name
    assert dic['dict']['name'] == nt.dict.name
    assert dic['dict']['age'] == nt.dict.age
    assert dic['list'][0] == n

# Generated at 2022-06-23 18:07:27.848867
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    with pytest.raises(TypeError):
        _ = to_namedtuple('')

    assert isinstance(to_namedtuple([]), list)

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    for key, val in dic.items():
        assert getattr(nt, key) == val
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': {'c': 2, 'd': 3}}
    nt = to_namedtuple(dic)
    assert nt.b.c == 2
    assert nt.b.d == 3

    dic = {'a': 1, 'B': 2}
    nt = to

# Generated at 2022-06-23 18:07:35.511953
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.tests.helpers.testutils import (
        BaseTestCases,
        CaseData,
        CaseDataTuple,
        CaseDataList,
    )

    from typing import Callable

    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-23 18:07:39.233381
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-23 18:07:49.468699
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pprint
    dic = {'a': 1, 'b': 2}
    ret = to_namedtuple(dic)
    print(ret)
    assert ret == namedtuple('a', 'b')(a=1, b=2)
    dic = {  # type: ignore[dict-item]
        "a": 1,
        "b": 2,
        "in": [{"c": 3, "d": 4}]
    }
    ret = to_namedtuple(dic)
    print(pprint.pformat(ret))

# Generated at 2022-06-23 18:07:59.952322
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple

    # if obj is not a valid type.
    with pytest.raises(TypeError):
        to_namedtuple(set())
        to_namedtuple(1)

    # if obj is a dict
    assert to_namedtuple({'a': 1, 'b': 2}) == \
        to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    # if obj is an OrderedDict
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    # if obj is not a valid dict key

# Generated at 2022-06-23 18:08:11.916601
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    dic=OrderedDict([('a',1),('b',{'c':2})])
    assert to_namedtuple(dic) == OrderedDict([('a',1),('b',OrderedDict([('c',2)]))])
    dic = OrderedDict(b="d", a=1, c=2)
    assert to_namedtuple(dic) == OrderedDict(a=1, b="d", c=2)
    dic = OrderedDict([("a", 1), ("b", 2)])
    assert to_namedtuple(dic) == OrderedDict(a=1, b=2)
    dic = dict(b="d", a=1, c=2)

# Generated at 2022-06-23 18:08:24.860530
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import collections

    class _TestToNamedTuple(unittest.TestCase):
        '''
        Test class to_namedtuple
        '''
        def setUp(self):
            self.dic = {'a': 1, 'b': 2, 'c': {'c_1': 3, 'c_2': 4}}
            self.ordered_dic = collections.OrderedDict([('d', 5), ('e', 6)])
            self.ordered_dic['c'] = self.dic['c']
            self.list_0 = [self.dic, self.ordered_dic]
            self.tuple_0 = tuple(self.list_0)

# Generated at 2022-06-23 18:08:30.677724
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest

    values = {
        'a': 1,
        'b': 2,
        'c': 'three',
    }
    result = to_namedtuple(values)
    assert isinstance(result, namedtuple)
    assert 'NamedTuple' in result.__class__.__name__
    assert hasattr(result, 'a')
    assert hasattr(result, 'b')
    assert hasattr(result, 'c')

    values = ('a', 1, 'b', 2, 'c', 3)
    result = to_namedtuple(values)
    assert isinstance(result, namedtuple)
    assert 'NamedTuple' in result.__class__.__name__
    assert hasattr(result, 'a')

# Generated at 2022-06-23 18:08:43.645067
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import NamedTuple, Dict, List
    import json

    class Person(NamedTuple):
        name: str
        age: int
        height: float
        fav_colors: List

    class Empl(NamedTuple):
        name: str
        age: int
        height: float
        fav_colors: List[str]
        dog: Dict

    dictobj: Dict[str, Any] = {
        'name': 'Alice',
        'age': 32,
        'height': 72.345,
        'fav_colors': ['green', 'red', 'blue', 'purple'],
        'dog': {
            'name': 'Spot',
            'breed': 'Pomeranian'
        }
    }

    x = OrderedDict()
    x['name']

# Generated at 2022-06-23 18:08:48.911547
# Unit test for function to_namedtuple
def test_to_namedtuple():
    expected = {"a":1,"b":2,"c":"value"}
    actual = to_namedtuple(expected)
    assert expected['a'] == actual.a
    assert expected['b'] == actual.b
    assert expected['c'] == actual.c

test_to_namedtuple()

# Generated at 2022-06-23 18:08:56.830655
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple({'a': {'b': 1}}) == NamedTuple(a=NamedTuple(b=1))
    assert to_namedtuple([NamedTuple(a=1)]) == [NamedTuple(a=1)]
    assert to_namedtuple(ordereddict({'a': 1, 'b': 2})) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:09:08.310176
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )

    from types import SimpleNamespace

    from pydantic import (
        ValidationError,
    )

    from flutils.pydanticmodels import validate_schema

    from flutils.namedtupleutils import (
        NamedTuple,
        to_namedtuple,
    )

    from tests.test_namedtupleutils import (
        TestSchema,
    )
    from . import common

    class TestSchema(TestSchema):

        def __init__(
                self,
                *,
                data: Union[
                    List[Union[float, Mapping[str, float]]],
                    Mapping[str, float]
                ]
        ) -> None:

            self.data = data


# Generated at 2022-06-23 18:09:16.754395
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Check the to_namedtuple function."""
    import pytest


    dic = {'a': 1, 'b': 2}
    named_dic = namedtuple('NamedTuple', 'a b')
    assert _to_namedtuple(dic) == named_dic(a=1, b=2)

    with pytest.raises(TypeError):
        _to_namedtuple('a')

    dic = {'a': 1, 'b': 2, '_c': 3}
    named_dic = namedtuple('NamedTuple', 'a b')
    assert _to_namedtuple(dic) == named_dic(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'C': 3}
    named_d

# Generated at 2022-06-23 18:09:26.145687
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from types import SimpleNamespace
    import pytest

    # Test OrderedDict
    dic = OrderedDict(
        (
            ('a', 1),
            ('b', 10),
            ('c', 100),
        )
    )
    out = to_namedtuple(dic)
    assert out == namedtuple('NamedTuple', 'a b c')(a=1, b=10, c=100)

    # Test dict
    dic = {
        'a': 1,
        'b': 10,
        'c': 100,
    }
    out = to_namedtuple(dic)


# Generated at 2022-06-23 18:09:28.905978
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    expect = "NamedTuple(a=1, b=2)"
    actual = str(to_namedtuple(dic))
    assert expect == actual



# Generated at 2022-06-23 18:09:39.964055
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.validators import validate_dict
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Mapping

    # noinspection PyShadowingNames
    def check_obj(obj) -> bool:
        from flutils.namedtupleutils import _to_namedtuple
        out = _to_namedtuple(obj)
        return isinstance(out, Mapping)

    def make_obj(obj, expect_exception=False):
        if isinstance(obj, dict):
            if expect_exception:
                with pytest.raises(TypeError):
                    check_obj(obj)
            else:
                # noinspection PyArgumentList
                check_obj(obj)


# Generated at 2022-06-23 18:09:48.285638
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple"""
    # noinspection PyTypeChecker
    assert to_namedtuple({'a': 'b', 'c': {'d': 'e'}}) == \
           NamedTuple(a='b', c=NamedTuple(d='e'))
    # noinspection PyTypeChecker
    assert to_namedtuple([{'a': 'b', 'c': {'d': 'e'}}]) == \
           [NamedTuple(a='b', c=NamedTuple(d='e'))]


if __name__ == '__main__':
    print(test_to_namedtuple.__doc__)
    print(test_to_namedtuple())
    # a = to_namedtuple([{'a': 'b', 'c': {'

# Generated at 2022-06-23 18:09:57.300366
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Performs unit tests on function to_namedtuple
    """
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from types import SimpleNamespace
    my_dict = {
        'one': 1,
        'two': 2,
    }
    my_ordered_dict = OrderedDict(
        (
            (
                'one',
                1,
            ),
            (
                'two',
                2,
            ),
        )
    )
    my_namespace = SimpleNamespace(**my_dict)
    make = namedtuple('NamedTuple', 'one two')
    my_ntup = make(1, 2)

# Generated at 2022-06-23 18:10:09.073797
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import _to_namedtuple, to_namedtuple
    assert _to_namedtuple('test') == to_namedtuple('test')
    assert _to_namedtuple(1234) == to_namedtuple(1234)
    assert _to_namedtuple(1.234) == to_namedtuple(1.234)

    assert _to_namedtuple({'test': 1234}) == to_namedtuple({'test': 1234})
    assert _to_namedtuple({'test': [1234, 5678]}) == to_namedtuple({'test': [1234, 5678]})

# Generated at 2022-06-23 18:10:19.950257
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Simple test
    dic = {'a': 1, 'b': 2}
    namedtuple_dic = to_namedtuple(dic)
    assert namedtuple_dic.a == 1 and namedtuple_dic.b == 2

    # Test with a nested dict
    ndic = {'a': {'c': 1}}
    nndic = to_namedtuple(ndic)
    assert nndic.a.c == 1

    # Test with implicit nested dict
    ndic = {'a': {'c': 1}, 'b': {}, 'c': {'d': 1, 'e': 2}}
    nndic = to_namedtuple(ndic)
    assert nndic.c.d == 1 and nndic.c.e == 2

    # Test with a

# Generated at 2022-06-23 18:10:32.112549
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(None) is None
    try:
        to_namedtuple('foo')
    except TypeError:
        assert True
    else:
        assert False
    try:
        to_namedtuple(5)
    except TypeError:
        assert True
    else:
        assert False
    try:
        to_namedtuple(to_namedtuple)
    except TypeError:
        assert True
    else:
        assert False
    assert to_namedtuple(False) is False
    assert to_namedtuple(True) is True
    assert to_namedtuple(5.5) == 5.5
    assert to_namedtuple(5.5) == 5.5

# Generated at 2022-06-23 18:10:41.314704
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    namedtuple_obj = to_namedtuple(dic)
    assert namedtuple_obj.a == 1
    assert namedtuple_obj.b == 2
    assert namedtuple_obj[0] == 1
    assert namedtuple_obj[1] == 2
    namedtuple_obj = to_namedtuple(namedtuple_obj)
    assert namedtuple_obj.a == 1
    assert namedtuple_obj.b == 2
    assert namedtuple_obj[0] == 1
    assert namedtuple_obj[1] == 2
    namedtuple_obj = to_namedtuple(
        [dic, dic])
    assert namedtuple_obj[0].a == 1

# Generated at 2022-06-23 18:10:52.577758
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from pprint import pformat
    from flutils.namedtupleutils import to_namedtuple
    from flutils.typings import AttrDict

    is_nt_type = lambda obj: isinstance(obj, (tuple, list, dict))
    is_nt_item = lambda obj: isinstance(obj, (tuple, list, dict, AttrDict))
    # Test: obj is a list
    for obj in [
        (1, 2, 3),
        [1, 2, 3],
        [{'a': 1, 'b': 2}, 3]
    ]:
        nt = to_namedtuple(obj)
        assert is_nt_type(nt)

# Generated at 2022-06-23 18:10:58.004355
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_data = {
        "key": {
            "sub_key": [
                {
                    "sub_sub_key": 1,
                },
                {
                    "sub_sub_key": 2,
                },
                {
                    "sub_sub_key": 3,
                },
            ],
        },
    }

    output = to_namedtuple(test_data)
    print (output)
    assert str(output) == "NamedTuple(key=NamedTuple(sub_key=(NamedTuple(sub_sub_key=1), NamedTuple(sub_sub_key=2), NamedTuple(sub_sub_key=3))))"

# Generated at 2022-06-23 18:11:03.700723
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        '_a': 1,
        'b': 2,
    }
    out = to_namedtuple(dic)
    assert out._fields == ('b',)
    assert out.b == 2
    dic = {
        'a': 1,
        'b': 2,
    }
    out = to_namedtuple(dic)
    assert out._fields == ('a', 'b')
    assert out.a == 1
    assert out.b == 2
    dic = {
        'a': 1,
        '_b': 2,
    }
    out = to_namedtuple(dic)
    assert out._fields == ('a',)
    assert out.a == 1
    dic = [1, 2, 3]

# Generated at 2022-06-23 18:11:12.758571
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_obj_1 = OrderedDict([
        ('a', 1),
        ('b', 2)
    ])
    test_obj_1_out = to_namedtuple(test_obj_1)
    assert test_obj_1_out.a == 1
    assert test_obj_1_out.b == 2
    assert test_obj_1.__class__.__name__ == test_obj_1_out.__class__.__name__
    # noinspection PyUnresolvedReferences
    assert test_obj_1_out._fields == ('a', 'b')

    test_obj_2 = {
        'a': 1,
        'b': 2
    }
    test_obj_2_out = to_namedtuple(test_obj_2)

# Generated at 2022-06-23 18:11:23.281017
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple

    _list: List[Union[Mapping, str]] = [{
        'a': {
            'b': 1,
            'c': 2,
            'd': {
                'e': 1,
                'f': 2,
                'g': 3,
            }
        },
        'b': [
            {
                'a': 1,
                'b': 2,
                'c': 3,
            },
            {
                'a': 1,
                'b': 2,
                'c': 3,
            }
        ]
    }, 'f']
    nt_list = to_namedtuple(_list)
    assert isinstance(nt_list, list)


# Generated at 2022-06-23 18:11:28.067561
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple([NamedTuple(a=1, b=2)]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple((NamedTuple(a=1, b=2),)) == (NamedTuple(a=1, b=2),)

# Generated at 2022-06-23 18:11:39.721710
# Unit test for function to_namedtuple
def test_to_namedtuple():
    "Tests for function to_namedtuple."

    import flutils.namedtupleutils
    import flutils.tests.namedtupleutils_testing as mod_testing

    # Unit test: test_to_namedtuple
    obj = {'a': 1, 'b': 2}
    expected = mod_testing.NamedTuple(a=1, b=2)
    actual = flutils.namedtupleutils.to_namedtuple(obj)
    assert actual == expected

    obj = {'_a': 1, 'b': 2, '1': 3}
    expected = mod_testing.NamedTuple(b=2, _1=3)
    actual = flutils.namedtupleutils.to_namedtuple(obj)
    assert actual == expected


# Generated at 2022-06-23 18:11:50.367805
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from typing import NamedTuple
    from types import SimpleNamespace

    from flutils.validators import validate_identifier

    from typing import List, Tuple


    class TestObj(NamedTuple):
        a: int
        b: int


    class TestObj2(NamedTuple):
        a: int
        b: TestObj


    dic: Mapping[str, int] = {'a': 1, 'b': 2}
    odict: OrderedDict[str, int] = OrderedDict([
        ('a', 1),
        ('b', 2),
    ])
    lst: List[int] = [1, 2]

# Generated at 2022-06-23 18:11:56.669099
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    expected = [1, namedtuple('NamedTuple', 'a b')(a=1, b=2)]
    actual = to_namedtuple([1, dic])
    assert actual == expected
    actual = to_namedtuple(expected)
    assert actual == expected
    expected = namedtuple('NamedTuple', 'a b')(1, 'namedtuple')
    actual = to_namedtuple(expected)
    with pytest.raises(TypeError):
        to_namedtuple(1)

# Generated at 2022-06-23 18:12:08.734919
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Dict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    # List
    list_ = [1, 2, 3]
    out = to_namedtuple(list_)
    assert out == [1, 2, 3]
    # Tuple
    tuple_ = (1, 2, 3)
    out = to_namedtuple(tuple_)
    assert out == (1, 2, 3)
    # NamedTuple
    make = namedtuple('NamedTuple', 'a b')
    in_ = make(1, 2)
    out = to_namedtuple(in_)
    assert out.a == 1
    assert out.b == 2
    #

# Generated at 2022-06-23 18:12:19.373864
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == ()
    assert to_namedtuple(OrderedDict({'a': 1, 'b': 2})) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict({'a': 1, 'b': 2})) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict({'b': 2, 'a': 1})) == NamedTuple(b=2, a=1)
    assert to_namedtuple(OrderedDict({None: 2, 'a': 1})) == NamedTuple(a=1)
    assert to_namedtuple({'1': 1, '2': 2}) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:12:29.023814
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple('abc') == 'abc'
    assert to_namedtuple(123.45) == 123.45
    assert to_namedtuple(True) is True
    assert to_namedtuple(False) is False
    assert to_namedtuple(None) is None
    # Test that a NamedTuple can be created from a simple tuple
    assert to_namedtuple(('a', 'b', 'c')) == \
           cast(NamedTuple, namedtuple('NamedTuple', 'a b c')('a', 'b', 'c'))
    # Test that a simple list can be converted to a NamedTuple

# Generated at 2022-06-23 18:12:38.412324
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import Mock
    from collections import OrderedDict

    # noinspection PyUnusedLocal
    def dummy(*args, **kwargs):
        ...

    # noinspection PyUnusedLocal
    def dummy2(*args, **kwargs):
        ...

    # noinspection PyUnusedLocal
    def dummy3(*args, **kwargs):
        ...


# Generated at 2022-06-23 18:12:50.481342
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyShadowingNames
    def _nt(**kwargs: Any) -> NamedTuple:
        return namedtuple('NamedTuple', kwargs.keys())(**kwargs)

    assert to_namedtuple({}) == _nt()
    assert to_namedtuple({'a': 1}) == _nt(a=1)
    assert to_namedtuple({'b': 2, 'a': 1}) == _nt(a=1, b=2)
    assert to_namedtuple({'$b': 2, 'a': 1}) == _nt(a=1)
    assert to_namedtuple({'b': 2, 'a': 1, '_c': 3}) == _nt(a=1, b=2)

# Generated at 2022-06-23 18:12:52.790891
# Unit test for function to_namedtuple
def test_to_namedtuple():
    namedtupleutils.to_namedtuple([1,2,3])
    namedtupleutils.to_namedtuple({'a':1,'b':2,'c':3})

# Generated at 2022-06-23 18:13:04.186963
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Successful conversion
    list_ = to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}])
    assert list_ == [NamedTuple(a=1, b=2), NamedTuple(c=3, d=4)]
    assert isinstance(list_, list)
    assert isinstance(list_[0], NamedTuple)
    assert isinstance(list_[1], NamedTuple)
    dic = to_namedtuple({'a': 1, 'b': 2})
    assert dic == NamedTuple(a=1, b=2)
    assert isinstance(dic, NamedTuple)
    assert dic.a == 1
    assert dic.b == 2

# Generated at 2022-06-23 18:13:14.521646
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testingutils import (
        TestCase,
        unittest,
    )
    from pprint import pprint

    class TestToNamedTuple(TestCase):

        def test_to_namedtuple_simple_dict(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertNotEqual(type(out), type(dic))
            self.assertEqual(out.a, dic['a'])
            self.assertEqual(out.b, dic['b'])

            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)

# Generated at 2022-06-23 18:13:20.114108
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple(('a', 'b')) == ('a', 'b')
    assert to_namedtuple(['a', {'b': 'c'}]) == ['a', NamedTuple(b='c')]
    assert to_namedtuple(('a', {'b': 'c'})) == ('a', NamedTuple(b='c'))
    assert to_namedtuple({'a': 'b'}) == NamedTuple(a='b')
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:13:30.879913
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    class Point(NamedTuple):
        x: int
        y: int

    class Line(NamedTuple):
        a: Point
        b: Point

    ln = Line(Point(1, 2), Point(3, 4))
    ln_new = to_namedtuple(ln)
    assert ln_new is not ln

    p0 = ln.a
    p0_new = ln_new.a
    assert p0 is not p0_new

    p1 = ln.b
    p1_new = ln_new.b
    assert p1 is not p1_new

    assert p0 == p0_new
    assert p1 == p1_new

    assert ln_new == ln

# Generated at 2022-06-23 18:13:41.674337
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')(*[])
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(*[1])
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(*[1, 2])
    assert to_namedtuple([]) == []
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple([1, 2]) == [1, 2]

# Generated at 2022-06-23 18:13:52.888831
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple('') == ''
    assert (
        to_namedtuple(
            [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
        ) ==
        [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]
    )
    assert to_namedtuple({}) == NamedTuple('')
    assert (
        to_namedtuple(
            {'a': 1, 'b': 2}
        ) ==
        NamedTuple(a=1, b=2)
    )

# Generated at 2022-06-23 18:14:05.274600
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)

    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)

    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3

    dic = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(dic)

    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

# Generated at 2022-06-23 18:14:15.330751
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    t = to_namedtuple([{'a': 1, 'b': 0, 'c': {'d': {'e': 1, 'f': 0}}},
                       {'a': 1, 'b': 1}, {'a': 1, 'b': 0, 'c': {'d': {'e': 0}}},
                       {'a': 0, 'b': 0}, {'a': 0, 'b': 1},
                       {'a': 0, 'b': 0, 'c': {'d': {'e': 1}}}])
    assert t[0].c.d.e == 1 and t[0].c.d.f == 0 and t[1].b == 1 and t[2].c.d.e == 0 and t[5].c.d.e == 1

# Generated at 2022-06-23 18:14:27.858168
# Unit test for function to_namedtuple
def test_to_namedtuple():
    namedtuple_dic = OrderedDict(
        (('t', (1, 2)), ('a', 'b'))
    )
    namedtuple_list = namedtuple('List', ['a', 'b'])
    namedtuple_item = namedtuple('Item', ['x', 'y'])
    namedtuple_item_list = [
        namedtuple_item(1, 2), namedtuple_item(3, 4),
        namedtuple_item(5, 'str1')
    ]
    namedtuple_item_tup = (
        namedtuple_item(1, 2), namedtuple_item(3, 4),
        namedtuple_item(5, 'str2')
    )


# Generated at 2022-06-23 18:14:34.389621
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    obj = to_namedtuple(obj)
    assert obj.a == 1
    assert obj.b == 2
    obj = {'a': 1, 'b': 2, 'longer_attr': {'c': 3, 'd': 4}}
    obj = to_namedtuple(obj)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.longer_attr.c == 3
    assert obj.longer_attr.d == 4
    obj = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    obj = to_namedtuple(obj)
    assert obj.a == 1
    assert obj.b == 2
    assert obj.c == 3
    assert obj.d == 4
   

# Generated at 2022-06-23 18:14:45.973873
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_dict = {'a1': 1, 'b2': 2, 'name1': 'bob', '_name2': 'boy'}
    test_dict2 = {'_name2': 'boy', 'name1': 'bob', 'a1': 1, 'b2': 2}
    test_dict3 = {'a1': 1, 'b2': 2, 'name1': 'bob', '_name2': 'boy', 'a3': {'subdict': 'sub_name1'}}

    print(to_namedtuple(test_dict))
    assert to_namedtuple(test_dict) == ('boy', 'bob', 1, 2)
    assert to_namedtuple(test_dict2) == ('boy', 'bob', 1, 2)


# Generated at 2022-06-23 18:14:57.074613
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from ipdb import set_trace
    from pprint import pformat
    import pytest
    from typing import Any, List, Union

    # noinspection PyProtectedMember
    from flutils.namedtupleutils import _to_namedtuple

    def lmap(fn: callable, l: List[Any]) -> List[Any]:
        # List map
        return [
            fn(item)
            for item in l
        ]

    @singledispatch
    def diff(obj1: Any, obj2: Any) -> None:
        raise TypeError(
            "Don't know how to compare type: (%s) %s" % (
                type(obj1).__name__, type(obj2).__name__
            )
        )


# Generated at 2022-06-23 18:15:03.638826
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import os
    import unittest
    import pathlib

    from flutils.namedtupleutils import to_namedtuple
    from flutils.pathutils import get_directory, is_child_dir

    from .siteinfo import (
        MY_TESTS_DIRECTORY,
        THIS_DIRECTORY,
    )

    class TestToNamedTuple(unittest.TestCase):
        def setUp(self):
            self.mytests = MY_TESTS_DIRECTORY
            self.mytests_nt = to_namedtuple(self.mytests)
            self.parent = get_directory(self.mytests)
            self.parent_nt = to_namedtuple(self.parent)


# Generated at 2022-06-23 18:15:15.980351
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from pprint import pprint

    class MyNamedTuple(NamedTuple):
        """Dummy named tuple."""

        a: int
        b: int

    MyNamedTuple_orig = MyNamedTuple
    MyNamedTuple_orig.__name__ = 'MyNamedTuple'

    pprint(to_namedtuple({}))
    pprint(to_namedtuple({'a': 1, 'b': 2}))
    pprint(to_namedtuple(
        {'a': 1, 'b': 2, '_ab': 3, 'Abc': 4, 'abc': 5}
    ))
    pprint(to_namedtuple([]) == [])
    pprint(to_namedtuple(()))

# Generated at 2022-06-23 18:15:25.988359
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test namedtuple conversion
    NamedTupleTest = namedtuple('NamedTupleTest', 'a,b,c')
    val = NamedTupleTest('a', 'b', 'c')
    out = to_namedtuple(val)
    assert isinstance(out, NamedTupleTest)
    assert out == val

    # Test conversion with nested NamedTuple
    val = dict(a=1, b=dict(x=2, y=dict(z=3)))
    out = to_namedtuple(val)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert isinstance(out.b, NamedTuple)
    assert out.b.x == 2
    assert isinstance(out.b.y, NamedTuple)
    assert out.b.y.z == 3

# Generated at 2022-06-23 18:15:36.882540
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # pylint: disable=missing-function-docstring, no-member

    from collections import OrderedDict

    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple((1, 2))
    assert to_namedtuple(OrderedDict((('a', 1), ('b', 2)))) == to_namedtuple((1, 2))
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == to_namedtuple((1, 2))

# Generated at 2022-06-23 18:15:47.825326
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import SyntaxError

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)

    dic = SimpleNamespace()
    dic.a = 1
    dic.b = 2

# Generated at 2022-06-23 18:15:57.884929
# Unit test for function to_namedtuple
def test_to_namedtuple():
    ''' Test to_namedtuple()'''
    class Car(NamedTuple):
        make: str
        model: str
        year: int

    test_list = [1, Car('Ford', 'Explorer', 2020), Car('Chevrolet', 'Camaro', 2020), 3]
    expected = [1, Car(make='Ford', model='Explorer', year=2020), Car(make='Chevrolet', model='Camaro', year=2020), 3]
    assert(to_namedtuple(test_list) == expected)
    print('to_namedtuple() passed')

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:16:07.268553
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(
        {'a': 1, 'b': 2, '__c': 'c'}
    ) == NamedTuple(a=1, b=2)
    assert to_namedtuple(
        {'a': {'a': 1, 'b': 2}, 'b': 'b'}
    ) == NamedTuple(a=NamedTuple(a=1, b=2), b='b')
    assert to_namedtuple(
        OrderedDict( [('a', 1), ('b', 2)] )
    ) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:16:14.487017
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == NamedTuple(a=1, b=2)
    nt = NamedTuple(a=1, b=2)
    out = to_namedtuple(nt)
    assert out == nt
    ns = SimpleNamespace(a=1, b=2)
    out = to_namedtuple(ns)
    assert out == nt