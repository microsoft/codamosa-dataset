

# Generated at 2022-06-23 18:06:18.734011
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import itertools
    import operator

    class ToNamedTupleTest(unittest.TestCase):
        dic = {'a': 1, 'b': 2, 'c': 3}
        dic_namedtuple = namedtuple('NamedTuple', sorted(dic.keys()))(**dic)
        dic_ordered = OrderedDict(dic)
        dic_ordered_namedtuple = namedtuple('NamedTuple', dic.keys())(**dic)
        dic_ns = SimpleNamespace(**dic)
        dic_ns_namedtuple = namedtuple('NamedTuple', sorted(dic.keys()))(**dic)

        def test_to_namedtuple_is_a_function(self):
            self

# Generated at 2022-06-23 18:06:23.481607
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    dic_values = [1, 2]
    assert dic == dict(to_namedtuple(dic))
    assert dic_values == list(to_namedtuple(dic_values))

# Generated at 2022-06-23 18:06:24.769191
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-23 18:06:34.789752
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:06:41.679031
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testutils import TestData
    from collections import namedtuple
    from collections.abc import Mapping
    from typing import Union, List, Tuple
    import datetime
    import pytest
    _AllowedTypes = Union[
        List,
        Mapping,
        namedtuple,
        Tuple,
    ]
    _AllowedValues = Union[
        datetime.datetime,
        float,
        List,
        Mapping,
        namedtuple,
        int,
        str,
        Tuple,
        TestData,
    ]

# Generated at 2022-06-23 18:06:49.401194
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)
    assert to_namedtuple(tuple(dic)) == (1, 2)



# Generated at 2022-06-23 18:06:58.274519
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2,
        '__c': 3
    }
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2
    assert not hasattr(out, '__c')
    assert vars(out) == {'a': 1, 'b': 2}

    import collections.abc as _cabc
    assert isinstance(out, _cabc.Mapping)
    assert not isinstance(out, _cabc.MutableMapping)

    dic = {
        'a': 1,
        'b': 2,
        '_c': 4  # The _c in the input dictionary gets ignored.
    }

# Generated at 2022-06-23 18:07:09.856983
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(None) == NamedTuple()
    assert to_namedtuple(()) == NamedTuple()
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple(OrderedDict()) == NamedTuple()
    assert to_namedtuple(SimpleNamespace()) == NamedTuple()
    assert to_namedtuple([]) == []
    assert to_namedtuple('') == ''
    assert to_namedtuple('abc') == 'abc'
    assert to_namedtuple((1,)) == (1, )
    assert to_namedtuple([1, ]) == [1, ]
    assert to_namedtuple(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert to_namedtuple

# Generated at 2022-06-23 18:07:15.748609
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2}
    dic = to_namedtuple(dic)
    assert dic.a == 1
    assert dic.b == 2

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    dic = to_namedtuple(dic)
    assert dic.a == 1
    assert dic.b == 2
    assert isinstance(dic, OrderedDict)

    odict = OrderedDict()
    odict['a'] = 1
    odict['b'] = 2
    odict = to_namedtuple(odict)
    assert odict[0] == 1
    assert odict[1] == 2
    assert odict.a == 1
    assert odict.b

# Generated at 2022-06-23 18:07:24.245704
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple function."""

    data = {
        'a': 'a',
        'b': 'b',
        'c.d': 'c.d',
    }
    nt = to_namedtuple(data)

    assert nt.a == 'a'
    assert nt.b == 'b'
    assert nt.c_d == 'c.d'


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:07:32.361389
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    a_dic = dict({'name': 'foo', 'age': 20, 'occupation': 'developer'})
    a_dic_namedtuple = to_namedtuple(a_dic)
    assert a_dic_namedtuple == NamedTuple(age=20, name='foo', occupation='developer')

    a_list = [1, 2, 3, 4]
    a_list_namedtuple = to_namedtuple(a_list)
    assert a_list_namedtuple == [1, 2, 3, 4]

    an_od = OrderedDict([('name', 'foo'), ('age', 20), ('occupation', 'developer')])

# Generated at 2022-06-23 18:07:44.620191
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import validate_identifier
    import pytest

# Generated at 2022-06-23 18:07:53.056336
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {
        'a': 1,
        'b': 2
    }
    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        to_namedtuple('bad')
    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        to_namedtuple(123)
    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        to_namedtuple(1.23)
    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        to_namedtuple(b'bad')

# Generated at 2022-06-23 18:08:01.597329
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple

    class TestToNamedTuple(unittest.TestCase):
        def test_dict_to_namedtuple(self):
            test_data = [
                {'a': 1, 'b': 2},
            ]
            expected = [
                namedtuple('NamedTuple', 'a b')(a=1, b=2),
            ]
            for input_data, expected_data in zip(test_data, expected):
                output_data = to_namedtuple(input_data)
                self.assertEqual(output_data, expected_data)


# Generated at 2022-06-23 18:08:12.142080
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import Mock

    def validate_identifier(
            ident: str, *, allow_underscore: bool = False
    ) -> None:
        """Mock a validator."""
        if ident.startswith('_'):
            if allow_underscore is False:
                raise SyntaxError('Underscores are disallowed.')
        if not ident.isidentifier():
            raise SyntaxError('Not a proper identifier.')
        return

    # all the calls to this mock should be ok, so don't bother doing anything
    m = Mock()
    m.side_effect = validate_identifier
    # noinspection PyUnresolvedReferences
    old_identifier = to_namedtuple.registry._cache['validate_identifier']
    # noinspection PyUnresolvedReferences
   

# Generated at 2022-06-23 18:08:24.981680
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 4, 'b': 2, 'c': 3, 'd': 1, 'e': 5, 'f': 6}
    ordered_dic = OrderedDict(dic)
    obj = SimpleNamespace(**dic)

    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c d e f')(
        a=4, b=2, c=3, d=1, e=5, f=6
    )
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'b c d e f a')(
        b=2, c=3, d=1, e=5, f=6, a=4
    )

# Generated at 2022-06-23 18:08:30.327603
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = OrderedDict(a=1, b=2)
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, 'c_': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1

# Generated at 2022-06-23 18:08:33.027935
# Unit test for function to_namedtuple
def test_to_namedtuple():

    if __name__ == '__main__':
        import doctest
        doctest.testmod()

# Generated at 2022-06-23 18:08:44.880024
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from flutils.testutils import (
        assert_equal,
        assert_false,
        assert_true,
    )
    NamedTuple = namedtuple('NamedTuple', 'a b')
    val = NamedTuple(a=1, b=2)
    nt = to_namedtuple(val)
    assert_true(isinstance(nt, NamedTuple))
    assert_equal(nt, val)

    val = OrderedDict(b=2, a=1)
    nt = to_namedtuple(val)
    assert_true(isinstance(nt, NamedTuple))
    assert_equal(tuple(nt), (1, 2))

    val = {'b': 2, 'a': 1}

# Generated at 2022-06-23 18:08:55.170534
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': [1.1, 1.2],
        'c':
            {
            'a': 2,
            'b': [2.1, 2.2],
            'c': {
                'a': 3
            }
        }
    }
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert len(out.b) == 2
    assert isinstance(out.b, Tuple)
    assert out.b[0] == 1.1
    assert isinstance(out.c, NamedTuple)
    assert out.c.a == 2
    assert len(out.c.b) == 2
    assert isinstance(out.c.b, Tuple)


# Generated at 2022-06-23 18:09:02.947737
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from abc import ABC
    from collections import Counter, deque
    from collections import OrderedDict as ODict
    from datetime import datetime
    from datetime import timezone
    from datetime import timedelta
    from decimal import Decimal
    from fractions import Fraction
    from io import BytesIO
    from io import StringIO
    from pathlib import Path
    from tempfile import NamedTemporaryFile
    from typing import Any
    from typing import List
    from typing import Mapping
    from typing import Optional
    from typing import Set
    from typing import Tuple
    from typing import Union
    from uuid import UUID
    import enum
    import sys
    import xml.etree.ElementTree as ET
    #: Any type that can be converted to a Named Tuple

# Generated at 2022-06-23 18:09:13.578698
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Tests if to_namedtuple works on a dictionary
    test_dictionary_1 = {"a": 1, "b": 2}
    test_dictionary_2 = {"a": 1, "b": 2, "c": "three"}
    test_to_namedtuple_1 = to_namedtuple(test_dictionary_1)
    test_to_namedtuple_2 = to_namedtuple(test_dictionary_2)
    assert test_to_namedtuple_1.a == 1
    assert test_to_namedtuple_1.b == 2
    assert test_to_namedtuple_2.a == 1
    assert test_to_namedtuple_2.b == 2
    assert test_to_namedtuple_2.c == "three"

    # Tests if to_namedtuple

# Generated at 2022-06-23 18:09:24.314668
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Create some objects
    attrs = [
        'a', 'b', 'c', 'd', 'e', 'f', 'g',
        'h', 'i', 'j', 'k', 'l', 'm', 'n'
    ]
    nums = list(range(len(attrs)))
    dic = OrderedDict([(attr, num) for attr, num in zip(attrs, nums)])

    # Convert our objects to a NamedTuple
    nt = to_namedtuple(dic)
    nt_attrs = list(nt._fields)
    assert len(nt_attrs) == len(dic)
    for a, n in zip(nt_attrs, nums):
        assert getattr(nt, a) == n

    # Ensure that the order was preserved
   

# Generated at 2022-06-23 18:09:35.031248
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from flutils.namedtupleutils import to_namedtuple


    class TestToNamedTuple(unittest.TestCase):

        def test_ordered_dict(self):
            from collections import OrderedDict
            from typing import OrderedDict as OrderedDictType
            from collections import namedtuple


            dic: OrderedDictType[str, int] = OrderedDict()
            dic['a'] = 1
            dic['b'] = 2
            dic['c'] = 3
            nt = namedtuple('NamedTuple', 'a b c')
            new_nt = to_namedtuple(dic)
            self.assertIsInstance(new_nt, nt)
            self.assertEqual(new_nt.a, 1)
            self

# Generated at 2022-06-23 18:09:46.099396
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict((('a', 1), ('b', 2)))) == \
        NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)

    assert to_namedtuple({'a': 1, 'b': {'c': 3}}) == \
        NamedTuple(a=1, b=NamedTuple(c=3))

# Generated at 2022-06-23 18:09:55.065444
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Valid inputs
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'B': 2}) == namedtuple('NamedTuple', 'B a')(a=1, B=2)
    assert to_namedtuple(namedtuple('NamedTuple', 'B a')(a=1, B=2)) == namedtuple('NamedTuple', 'B a')(a=1, B=2)
    assert to_namedtuple(OrderedDict([('B', 2), ('a', 1)])) == namedtuple('NamedTuple', 'B a')(B=2, a=1)

    # Non-

# Generated at 2022-06-23 18:10:06.848668
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from unittest import mock
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple

    class TestNamedTupleUtils(unittest.TestCase):

        def test_to_namedtuple(self):
            obj = {'a': 1, 'b': 2}
            res = to_namedtuple(obj)
            self.assertEqual(res, namedtuple('NamedTuple', 'a b')(a=1, b=2))

        def test_to_namedtuple_list(self):
            obj = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
            res = to_namedtuple(obj)

# Generated at 2022-06-23 18:10:18.448413
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import copy

    def nt(tup):
        return namedtuple('NamedTuple', tup._fields)(*tup)

    # Basic types
    assert to_namedtuple('abc') == 'abc'
    assert to_namedtuple(12) == 12
    assert to_namedtuple(True) == True
    assert to_namedtuple(None) == None
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]

    assert to_namedtuple({'a': 1, 'b': 2}) == nt(namedtuple('NT', 'a b')(1, 2))
    assert to_namedtuple({'b': 2, 'a': 1}) == nt(namedtuple('NT', 'a b')(1, 2))
    assert to_namedtuple

# Generated at 2022-06-23 18:10:30.243932
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(42) == 42
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple(1.0 + 0j) == 1.0 + 0j
    test_dict = {'a': 1, 'b': 2}
    nt = to_namedtuple(test_dict)
    assert nt == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert nt.a == 1
    assert nt.b == 2
    test_odict = OrderedDict(test_dict)
    nt = to_namedtuple(test_odict)
    assert nt == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert nt.a == 1
    assert n

# Generated at 2022-06-23 18:10:40.264739
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    nt0 = to_namedtuple([{'a': 1, 'b': 2}, {'a': 2, 'b': 3}])
    assert isinstance(nt0, list)
    assert isinstance(nt0[0], collections.namedtuple)
    nt1 = to_namedtuple(([{'a': 1, 'b': 2}, {'a': 2, 'b': 3}],))
    assert isinstance(nt1, tuple)
    assert isinstance(nt1[0], list)
    assert isinstance(nt1[0][0], collections.namedtuple)
    nt2 = to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert isinstance(nt2, collections.namedtuple)
    assert nt2 == collections.named

# Generated at 2022-06-23 18:10:51.649785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from types import SimpleNamespace

    from flutils.namedtupleutils import to_namedtuple

    MyTuple = namedtuple('MyTuple', 'foo bar')
    obj = MyTuple(foo=1, bar='baz')

    out = to_namedtuple(obj)

    assert isinstance(out, MyTuple)

    obj = [1, ('a', 2), 3]  # type: ignore[list-item]
    obj_want = [1, ('a', 2), 3]

    out = to_namedtuple(obj)

    assert out == obj_want

    obj = {
        'foo': 1,
        'bar': 'baz'
    }

    out = to_namedtuple(obj)

    assert isinstance(out, namedtuple)



# Generated at 2022-06-23 18:11:01.698815
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'b a')(2, 1)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]) == [namedtuple('NamedTuple', 'a b')(1, 2),
                                                                  namedtuple('NamedTuple', 'c d')(3, 4)]

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:11:11.526727
# Unit test for function to_namedtuple
def test_to_namedtuple():  
    dic = {'a': 1, 'b': 2}
    dic_to_namedtuple_expected_result = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dic) == dic_to_namedtuple_expected_result

    lst = ['a', 1, 'b', 2]
    lst_to_namedtuple_expected_result = ['a', 1, 'b', 2]
    assert to_namedtuple(lst) == lst_to_namedtuple_expected_result

    tup = ('a', 1, 'b', 2)
    tup_to_namedtuple_expected_result = ('a', 1, 'b', 2)
    assert to_namedtuple(tup) == tup_

# Generated at 2022-06-23 18:11:22.816512
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == to_namedtuple(SimpleNamespace()) == to_namedtuple(dict())
    assert to_namedtuple({'a': 1}) == to_namedtuple(SimpleNamespace(a=1)) == to_namedtuple(dict(a=1))
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(SimpleNamespace(a=1, b=2)) == to_namedtuple(dict(a=1, b=2))
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(dict(a=1, b=2))
    assert to_namedtuple(dict(a=1, b=2)) == to_namedtuple(dict(b=2, a=1))


# Generated at 2022-06-23 18:11:32.744458
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the to_namedtuple function
    """
    from flutils.tests.testutils.mktestclass import mktestclass
    from flutils.tests.testutils.randtest import (
        generate_random_sequence,
        generate_random_mapping
    )

    def test(obj):
        """Inner function for test
        """
        named_obj = to_namedtuple(obj)
        assert isinstance(named_obj, NamedTuple)
        assert obj != named_obj  # noqa
        while True:
            try:
                iter(obj)
            except TypeError:
                try:
                    iter(named_obj)
                except TypeError:
                    break
            else:
                assert isinstance(named_obj, (tuple, list))
                assert isinstance(obj, (tuple, list))

# Generated at 2022-06-23 18:11:43.528433
# Unit test for function to_namedtuple
def test_to_namedtuple():  # noqa: D202
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    test = {'a': 1, 'b': 2}
    result = to_namedtuple(test)
    assert result.a == 1
    assert result.b == 2

    test = [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]
    result = to_namedtuple(test)
    assert isinstance(result, list)
    assert isinstance(result[0], namedtuple)
    assert result[0].a == 1
    assert result[0].b == 2

    test = (1, 2, 3)
    result = to_namedtuple(test)
   

# Generated at 2022-06-23 18:11:52.271286
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from copy import copy
    from flutils.namedtupleutils import to_namedtuple
    from typing import NamedTuple
    import pytest

    # Given a dictionary
    dic = {True: 1, False: 2}
    # When to_namedtuple is called
    out = to_namedtuple(dic)
    # Then a NamedTuple is returned
    assert isinstance(out, NamedTuple) is True
    # And the fields are (False, True)
    assert out._fields == ('False', 'True')
    # And the values are (2, 1)

# Generated at 2022-06-23 18:11:58.137290
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert set(nt._fields) == {'a', 'b'}
    assert nt.a == 1
    assert nt.b == 2
    assert nt == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    ordered_dic = OrderedDict(a=1, b=2)
    nt = to_namedtuple(ordered_dic)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert set(nt._fields) == {'a', 'b'}

# Generated at 2022-06-23 18:12:09.932211
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testutils import assert_value_equal

    dic = {'a': 1, 'b': 2}
    odict = OrderedDict({'a': 1, 'b': 2})
    atuple = (1, 2)
    alist = [1, 2]
    sns = SimpleNamespace(a=1, b=2)
    nt_1 = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    nt_2 = namedtuple('NamedTuple', ['a'])(a=1)
    nt_3 = namedtuple('NamedTuple', ['b', 'a'])(b=1, a=2)
   

# Generated at 2022-06-23 18:12:20.155773
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(dict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(['f', 1, 2]) == ['f', 1, 2]
    assert to_namedtuple(OrderedDict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict((('a', 1), ('b', 2)))) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict({'a': 1, 'b': 2})) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:12:29.265031
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    def validate_namedtuple(obj):
        if not isinstance(obj, tuple) and not isinstance(obj, list):
            return False
        if isinstance(obj, collections.namedtuple):
            return True
        if hasattr(obj, 'capitalize'):
            if obj.isidentifier():
                return False
        for item in obj:
            if not validate_namedtuple(item):
                return False
        return True

    assert isinstance(to_namedtuple([{'a': 1, 'b': 2}]), list)
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), collections.namedtuple)
    assert hasattr(to_namedtuple({'a': 1, 'b': 2}), 'a')

# Generated at 2022-06-23 18:12:38.534608
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == cast(NamedTuple, dic)
    out = to_namedtuple(OrderedDict({'a': 1, 'b': 2}))
    assert out == cast(NamedTuple, OrderedDict({'a': 1, 'b': 2}))
    out = to_namedtuple([1, 2])
    assert out == [1, 2]
    out = to_namedtuple((1, 2))
    assert out == (1, 2)
    out = to_namedtuple('abc')
    assert out == 'abc'
    out = to_namedtuple([{'a': 1}, {'a': 2}])

# Generated at 2022-06-23 18:12:43.960848
# Unit test for function to_namedtuple
def test_to_namedtuple():

    data = {
        '_test': 'test',
        'test': 'test',
        'test2': 'test2'
    }
    result = to_namedtuple(data)
    assert result._fields == ('test', 'test2')
    assert result.test == 'test'
    assert result.test2 == 'test2'

# Generated at 2022-06-23 18:12:49.226939
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    # Test tuple
    key_val = (('a', 1), ('b', 2))
    out = to_namedtuple(key_val)
    expected = namedtuple('Tuple', ['a' , 'b'])(1, 2)
    assert out.a == expected.a
    assert out.b == expected.b
    # Test list
    key_val = [('a', 1), ('b', 2)]
    out = to_namedtuple(key_val)
    expected = namedtuple('List', ['a' , 'b'])(1, 2)
    assert out[0].a == expected.a
    assert out[0].b == expected.b
    # Test dictionary
    key_val = {'a': 1, 'b': 2}


# Generated at 2022-06-23 18:12:57.679241
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(((1, 2), (1, 2))) == ((1, 2), (1, 2))
    assert to_namedtuple(tuple([{'a': 1, 'b': 2}])) == \
        (NamedTuple(a=1, b=2),)
    assert to_namedtuple(tuple([{'b': 2, 'a': 1}])) == \
        (NamedTuple(a=1, b=2),)
    assert to_namedtuple(tuple([{'b': 2, 'a': 1}, [1, 2]])) == \
        (NamedTuple(a=1, b=2), [1, 2])

# Generated at 2022-06-23 18:13:08.258793
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    # noinspection PyProtectedMember
    assert to_namedtuple(dic) == to_namedtuple._to_namedtuple(dic)
    # noinspection PyProtectedMember
    assert type(to_namedtuple(dic)) is type(
        to_namedtuple._to_namedtuple(dic))
    assert hasattr(to_namedtuple(dic), '__dict__')
    assert hasattr(to_namedtuple(dic), '__slots__')
    assert hasattr(to_namedtuple(dic), '_asdict')
    assert hasattr(to_namedtuple(dic), '_fields')
    lst = [dic, dic]
    # noinspection PyProtectedMember

# Generated at 2022-06-23 18:13:18.250085
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    assert to_namedtuple(dict()) == NamedTuple()
    assert to_namedtuple(dict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dict(a=dict(x=1, y=2), b=2)) == NamedTuple(a=NamedTuple(x=1, y=2), b=2)
    assert to_namedtuple(OrderedDict(a=dict(x=1, y=2), b=2)) == NamedTuple(a=NamedTuple(x=1, y=2), b=2), to_namedtuple(OrderedDict(a=dict(x=1, y=2), b=2))

# Generated at 2022-06-23 18:13:27.292541
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from types import SimpleNamespace
    import flutils.namedtupleutils as namedtupleutils

    class TestCase(TestCase):
        def setUp(self):
            self.ns = SimpleNamespace()
            self.od = OrderedDict()
            self.tup = namedtuple('Tup', '')
            self.tup2 = namedtuple('Tup', 'a b')
            self.lst = []
            self.dic = {}
            self.obj = object()

        def test_dict(self):
            dic = {'a': 1, 'b': 2}
            tup = namedtupleutils.to_namedtuple(dic)

# Generated at 2022-06-23 18:13:33.368870
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = {'a':1, 'b':2}
    b = to_namedtuple(a)
    assert a == b._asdict()
    assert b.a == 1
    assert b.b == 2

    a = {'a':1, 'b':[1, 2, 3]}
    b = to_namedtuple(a)
    assert b.a == 1
    assert b.b == [1, 2, 3]

    a = {'a':1, 'b':{'c':3, 'd':4}}
    b = to_namedtuple(a)
    assert b.a == 1
    assert b.b.c == 3
    assert b.b.d == 4

    a = (1, 2, 3)
    b = to_namedtuple(a)
    assert b == a

# Generated at 2022-06-23 18:13:42.574087
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from datetime import date

# Generated at 2022-06-23 18:13:53.159304
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    od: OrderedDict = OrderedDict({'x': 1, 'z': 3, 'a': '4'})
    assert isinstance(od, Mapping)
    assert to_namedtuple(od) == namedtuple('NamedTuple', 'x z a')(1, 3, '4')

    ad = {'x': 5, 'z': 7, 'a': '8'}
    assert isinstance(ad, Mapping)
    assert to_namedtuple(ad) == namedtuple('NamedTuple', 'a x z')('8', 5, 7)

    ol: List[int] = [1, 2, 3, 4]
    assert ol == to_namedtuple(ol)


# Generated at 2022-06-23 18:14:03.744676
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from flutils.namedtupleutils import to_namedtuple
    from copy import copy

    dic: dict  = {'a': 1, 'b': 2}
    obj: SimpleNamespace  = SimpleNamespace(**dic)
    assert to_namedtuple(dic) == to_namedtuple(obj)
    assert to_namedtuple(dic) == obj
    assert to_namedtuple(obj) == obj
    assert to_namedtuple(dic) == {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == {'a': 1, 'b': 2}



# Generated at 2022-06-23 18:14:13.511368
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt1 = to_namedtuple(dic)
    assert repr(nt1) == "NamedTuple(a=1, b=2)"
    od = OrderedDict([('a', 1), ('b', 2)])
    nt2 = to_namedtuple(od)
    assert repr(nt2) == "NamedTuple(a=1, b=2)"
    lst = [{'a': 1, 'b': 2}]
    nt3 = to_namedtuple(lst)
    assert repr(nt3) == "[NamedTuple(a=1, b=2)]"
    sn = SimpleNamespace(a=1, b=2)
    nt4 = to_namedtuple(sn)
   

# Generated at 2022-06-23 18:14:26.697627
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2}
    print(to_namedtuple(dic))
    obj = namedtuple('test', 'a b')
    print(to_namedtuple(obj(a=1, b=2)))
    ord_dic = OrderedDict(a=1, b=2)
    print(to_namedtuple(ord_dic))
    lst = [1, 2, 3, 4]
    print(to_namedtuple(lst))
    tup = (1, 2, 3, 4)
    print(to_namedtuple(tup))
    lst_of_dics = [dic, dic]
    print(to_namedtuple(lst_of_dics))

# Generated at 2022-06-23 18:14:33.529427
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import unittest.mock
    from flutils.namedtupleutils import to_namedtuple

    class TestToNamedTuple(unittest.TestCase):
        def test_to_namedtuple_bad_input(self):
            with self.assertRaises(TypeError):
                to_namedtuple(99)
            with self.assertRaises(TypeError):
                to_namedtuple('')
            with self.assertRaises(TypeError):
                to_namedtuple(True)

        def test_to_namedtuple_namespace(self):
            # noinspection PyTypeChecker
            obj: SimpleNamespace = SimpleNamespace()
            obj.attr1 = 'val1'
            obj.attr2 = 'val2'

# Generated at 2022-06-23 18:14:44.240392
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'x': 1, 'y': 2}) == NamedTuple(x=1, y=2)
    assert to_namedtuple({'a': 1, 'b': 2}) != NamedTuple(b=2, a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) != NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) != NamedTuple(b=2)

# Generated at 2022-06-23 18:14:54.588932
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    import types
    assert to_namedtuple([]) == []
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({}) == cast(NamedTuple, ())
    assert to_namedtuple({'a': 1, 'b': 2}) == cast(NamedTuple, (1, 2))
    assert to_namedtuple({'b': 2, 'a': 1}) == cast(NamedTuple, (1, 2))
    assert to_namedtuple(OrderedDict({'a': 1, 'b': 2})) == cast(NamedTuple, (1, 2))
    assert to_namedtuple

# Generated at 2022-06-23 18:15:03.596059
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(d) == (1, 2, 3)
    o = OrderedDict(a=1, b=2, c=3)
    assert to_namedtuple(o) == (1, 2, 3)
    l = [1, 2, 3]
    assert to_namedtuple(l) == [1, 2, 3]
    t = (1, 2, 3)
    assert to_namedtuple(t) == (1, 2, 3)

# Generated at 2022-06-23 18:15:15.933699
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tup = namedtuple('NamedTuple', 'key val')
    some_tup = tup(key='key', val=123)
    assert isinstance(to_namedtuple(some_tup), tup)
    assert to_namedtuple(some_tup).key == 'key'
    assert to_namedtuple(some_tup).val == 123
    val = (some_tup, some_tup)
    assert isinstance(to_namedtuple(val), tuple)
    assert len(to_namedtuple(val)) == 2
    assert isinstance(to_namedtuple(val)[0], tup)
    assert to_namedtuple(val)[0].key == 'key'
    assert to_namedtuple(val)[0].val == 123

# Generated at 2022-06-23 18:15:25.946593
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils
    flutils.namedtupleutils.to_namedtuple(dict(c=None, a=1, b=2, d=None))
    from flutils.namedtupleutils import to_namedtuple
    to_namedtuple(dict(a=1, b=2))
    to_namedtuple(dict(a=1, b=2)).a
    to_namedtuple(dict(a=1, b=2)).b
    to_namedtuple(dict(c=None, a=1, b=2, d=None))
    to_namedtuple(dict(c=None, a=1, b=2, d=None)).c
    to_namedtuple(dict(c=None, a=1, b=2, d=None)).a
    to_

# Generated at 2022-06-23 18:15:32.392834
# Unit test for function to_namedtuple
def test_to_namedtuple():
    "Unit test for function to_namedtuple"

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, '__c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'_a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(b=2)

    dic = {1: 1, 3: 3, 2: 2}
    assert to_namedtuple(dic) == NamedTuple()

    dic = OrderedDict()
    dic['a'] = 1
    dic['b']

# Generated at 2022-06-23 18:15:42.405392
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyTypeChecker
    dic: Any = {'a': 1, 'b': 2}
    res = to_namedtuple(dic)
    assert res.a == 1
    assert res.b == 2
    # noinspection PyTypeChecker
    dic: Any = {'a': 1, 'b': {'x': 1, 'y': 2, 'z': 3}}
    res = to_namedtuple(dic)
    assert res.a == 1
    assert res.b.x == 1
    assert res.b.y == 2
    assert res.b.z == 3
    # noinspection PyTypeChecker
    li: Any = [1, 2, 3]
    res = to_namedtuple(li)
    assert res[0] == 1

# Generated at 2022-06-23 18:15:48.904401
# Unit test for function to_namedtuple
def test_to_namedtuple():
    out = to_namedtuple(1)
    assert out == 1
    out = to_namedtuple('a')
    assert out == 'a'
    out = to_namedtuple(True)
    assert out is True
    out = to_namedtuple(1.1)
    assert out == 1.1

    # If it's a list or tuple, convert the list or tuple's items to NamedTuple
    out = to_namedtuple(['a'])
    assert out == ('a', )

    # If it's a list or tuple, convert the list or tuple's items to NamedTuple
    out = to_namedtuple(['a', 1, False, b'ab'])
    targ = ('a', 1, False, b'ab')
    assert out == targ

    # If it's a list or tuple, convert

# Generated at 2022-06-23 18:15:59.606913
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''
    Test to_namedtuple function
    '''
    # Simple single level list
    list_to_convert = [1, [1, 2], {'a': 1, 'b': 2}, 'a', 'b']

    converted_list = to_namedtuple(list_to_convert)

    assert isinstance(converted_list, list)
    assert converted_list[0] == 1
    assert converted_list[1] == [1, 2]
    assert converted_list[2].a == 1
    assert converted_list[2].b == 2

    # Multi level list

# Generated at 2022-06-23 18:16:05.664979
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyTypeChecker
    dic = {
        'a': 1,
        'b': 2,
        'c': {
            'a': 1,
            'b': 2,
            'c': {
                'a': 1,
                'b': 2,
            },
            'd': 3,
            'e': {
                'a': 1,
                'b': 2,
                'c': 3,
                'd': 4,
            },
        },
        'd': 3,
        'e': {
            'a': 1,
            'b': 2,
            'c': 3,
            'd': 4,
        },
    }
    from collections import OrderedDict
    nt_dic = to_namedtuple(dic)

# Generated at 2022-06-23 18:16:15.869879
# Unit test for function to_namedtuple
def test_to_namedtuple():  # pragma: no cover
    from flutils.namedtupleutils import (
        NamedTuple,
        to_namedtuple,
    )
    ret = to_namedtuple({'a': 1, 'b': 2})
    assert type(ret) is NamedTuple  # noqa
    assert ret == NamedTuple(a=1, b=2)

    # only allow order of dictionary to determine order of items
    ret = to_namedtuple({'a': 1, 'b': 2, 'c': 3}.items())
    assert ret == NamedTuple(('a', 1), ('b', 2), ('c', 3))

    # recurse the values
    ret = to_namedtuple({'a': 1, 'b': {'b1': 11, 'b2': 22}})