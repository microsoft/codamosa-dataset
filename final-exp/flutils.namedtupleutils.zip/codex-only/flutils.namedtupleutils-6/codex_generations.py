

# Generated at 2022-06-23 18:06:18.282889
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import sys
    import collections.abc
    import typing
    class TestFunc(unittest.TestCase):
        def test_to_namedtuple(self):
            import flutils.namedtupleutils
            self.assertIs(
                flutils.namedtupleutils.to_namedtuple,
                flutils.namedtupleutils._to_namedtuple
            )
        def test_sanity(self):
            import flutils.namedtupleutils
            self.assertEqual(
                flutils.namedtupleutils.to_namedtuple({'a': 1, 'b': 2}),
                collections.namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
            )

# Generated at 2022-06-23 18:06:25.187665
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for function to_namedtuple
    """
    ins = [{'a': 1}, {'a': 1, 'b': 2}, {'b': 2, 'a': 1}, {'A': 1, 'B': 2}, {'0': 1, '1': 2}]

# Generated at 2022-06-23 18:06:31.632539
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from types import SimpleNamespace


# Generated at 2022-06-23 18:06:40.121656
# Unit test for function to_namedtuple
def test_to_namedtuple():  # pragma: no cover
    """Test the to_namedtuple function."""
    import typing
    import os
    import sys
    import logging
    # Import flutils so we can do some of the tests
    # flutils_path = os.path.dirname(flutils.__file__)
    # sys.path.append(flutils_path)
    import flutils.namedtupleutils as namedtupleutils
    import flutils.systemutils as systemutils

    # Allow for testing code
    systemutils.set_test_mode()

    # Configure logging
    systemutils.setup_loggers(
        default_path='logging.yaml',
        env_key='LOG_CFG',
        loggers=[(__name__, logging.DEBUG)],
    )


# Generated at 2022-06-23 18:06:48.985010
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == obj
    assert to_namedtuple(
        [
            {'a': 1, 'b': 2},
            {'a': 3, 'b': 4},
        ]
    ) == (
        (1, 2),
        (3, 4),
    )
    assert to_namedtuple(
        (
            {'a': 1, 'b': 2},
            {'a': 3, 'b': 4},
        )
    ) == (
        (1, 2),
        (3, 4),
    )

# Generated at 2022-06-23 18:06:57.978788
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from math import pi
    from os import cpu_count
    from platform import machine
    from platform import system
    from platform import uname
    from socket import gethostname
    from subprocess import check_output
    import sys

    # Example that includes recursion
    # noinspection PyUnusedLocal
    def _get_user_info() -> dict:
        """Get system and user information.

        Output:
            The function returns a ``dict`` with the user's
            system and user information.
        """

        plat = dict(
            name=system(),
            arch=machine(),
            release=uname().release,
            platform=sys.platform,
            python=dict(
                run=sys.executable,
                version=sys.version,
                version_info=sys.version_info,
            ),
        )

# Generated at 2022-06-23 18:07:09.819749
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert(
        to_namedtuple(
            {'a': 1, 'b': 2}
        )
        ==
        namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    )

    assert(
        to_namedtuple(
            OrderedDict(
                (
                    ('a', 1),
                    ('b', 2),
                )
            )
        )
        ==
        namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    )


# Generated at 2022-06-23 18:07:13.516775
# Unit test for function to_namedtuple
def test_to_namedtuple():  # pylint: disable=redefined-outer-name

    import pytest
    from copy import deepcopy
    from flutils.namedtupleutils import to_namedtuple

    def _to_namedtuple(obj: _AllowedTypes) -> Union[NamedTuple, Tuple, List]:
        return to_namedtuple(obj)

    # pylint: disable=unused-variable

    # noinspection PyShadowingNames,PyUnusedLocal

# Generated at 2022-06-23 18:07:17.913588
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.miscutils import DebugType
    from flutils.testingutils import print_test_header

    print_test_header(__file__, 'test_to_namedtuple')

    # Empty list.
    data = []
    dt = DebugType(data)
    assert isinstance(data, list)
    res = to_namedtuple(data)
    assert isinstance(res, list)
    assert DebugType(res) == dt

    # List with only items that can be converted.
    data = [1, 2, 3]
    dt = DebugType(data)
    assert isinstance(data, list)
    res = to_namedtuple(data)
    assert isinstance(res, list)
    assert DebugType(res) == dt

# Generated at 2022-06-23 18:07:29.745507
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from typing import Dict, List
    from hypothesis import given
    from hypothesis.strategies import (
        binary,
        booleans,
        composite,
        data,
        dictionaries,
        floats,
        integers,
        just,
        lists,
        none,
        one_of,
        recursive,
        sampled_from,
        text,
    )

    def to_data(obj: Any) -> Dict[str, Any]:
        if isinstance(obj, namedtuple):  # type: ignore[arg-type]
            out = obj._asdict()
        elif isinstance(obj, List):
            out = []
            for item in obj:
                out

# Generated at 2022-06-23 18:07:36.493240
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection SpellCheckingInspection
    dic = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': {'a': 1, 'b': 2},
        'e': {
            'a': 1,
            'b': 2,
            'c': [1, 2, 3],
        },
        'f': (1, 2, 3),
        'g': (1, 2, 3, 4, 5),
        'h': [1, 2, 3],
        'i': [1, 2, 3, 4, 5],
        'j': 'hello',
    }
    # noinspection DuplicatedCode

# Generated at 2022-06-23 18:07:40.648079
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out['a'] == 1
    assert out['b'] == 2
    assert out.a == 1
    assert out.b == 2

# Generated at 2022-06-23 18:07:50.502688
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import defaultdict, OrderedDict
    from flutils.namedtupleutils import to_namedtuple

    mapping1 = {'a': 1, 'b': {'b1': 11, 'b2': 22}, 'c': 3}
    mapping2 = {'a': 1, 'bb': {'b1': 11, 'b2': 22}, 'c': 3}
    mapping3 = {'a': 1, 'bbb': {'b1': 11, 'b2': 22}, 'c': 3}

    nt1 = to_namedtuple(mapping1)
    nt2 = to_namedtuple(mapping2)
    nt3 = to_namedtuple(mapping3)

    assert nt1.a == 1
    assert nt2.a == 1

# Generated at 2022-06-23 18:08:00.643680
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""

    class OrderedNamedTuple(OrderedDict):
        """An OrderedDict that will throw a TypeError if you try to set an
        item that isn't in the '_fields' list.
        """

        def __init__(
                self,
                fields: List[str],
                **kwargs
        ):
            super().__init__()
            self._fields = fields
            for field in fields:
                self[field] = None
            for key, val in kwargs.items():
                try:
                    self[key] = val
                except KeyError:
                    raise


# Generated at 2022-06-23 18:08:11.994594
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from collections import namedtuple

    T1 = namedtuple('T1', ('a', 'b'))

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == T1(a=1, b=2)

    ord_dic = OrderedDict(
        [
            ('a', 1),
            ('b', 2)
        ]
    )
    assert to_namedtuple(ord_dic) == T1(a=1, b=2)

    s = SimpleNamespace()
    s.a = 1
    s.b = 2
    assert to_namedtuple(s) == T1(a=1, b=2)


# Generated at 2022-06-23 18:08:24.942112
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from collections.abc import Mapping


# Generated at 2022-06-23 18:08:30.775353
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit tests for function to_namedtuple
    """
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Sequence
    from datetime import date
    from flutils.validators import validate_identifier
    from types import SimpleNamespace

    def assert_namedtuple(
            obj: Any,
            expected: Any,
            message: str = ''
    ) -> None:
        """ Assert a NamedTuple
        """
        from flutils.namedtupleutils import _to_namedtuple
        if not isinstance(expected, Sequence):
            expected = (expected,)
        got: Any = _to_namedtuple(obj)
        if isinstance(expected, str):
            assert isinstance(got, str), message

# Generated at 2022-06-23 18:08:43.730934
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import random
    import string

    dic = {
        'a': 1,
        'b': 2,
        '__c': 3,
        'c_': 4
    }
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = OrderedDict(sorted(dic.items()))
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': {'a': 1, 'b': 2},
        'e': [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    }

   

# Generated at 2022-06-23 18:08:54.313129
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test for function to_namedtuple

    This is meant to be ran from the root directory by using:
        $ python -m flutils.namedtupleutils.test_to_namedtuple
    """
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedt

# Generated at 2022-06-23 18:09:02.547012
# Unit test for function to_namedtuple
def test_to_namedtuple(): # pragma: no cover
    from flutils.namedtupleutils import to_namedtuple
    from typing import Dict


    # Dict to NamedTuple
    test_dict = {
        'a': 'a',
        'b': 1,
        'c': {
            'd': 'd',
            'e': 2,
            'f': {
                'g': 'g',
                'h': 3,
            },
        },
    }
    # noinspection PyTypeChecker
    res: Dict[str, Any] = to_namedtuple(test_dict)
    assert res.a == 'a'
    assert res.b == 1
    assert res.c.d == 'd'
    assert res.c.e == 2
    assert res.c.f.g == 'g'
   

# Generated at 2022-06-23 18:09:11.310471
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({1: {1: 1, 2: 2}, 2: {3: 3, 4: 4}}) == \
           NamedTuple(**{1: NamedTuple(**{1: 1, 2: 2}), 2: NamedTuple(**{3: 3, 4: 4})})
    assert to_namedtuple({1: {1: 1, 2: 2}, 2: 2}) == NamedTuple(**{1: NamedTuple(**{1: 1, 2: 2}), 2: 2})
    assert to_namedtuple({1: {1: 1, 2: 2}, 2: 2}) == NamedTuple(**{1: NamedTuple(**{1: 1, 2: 2}), 2: 2})
    # Unlike the test above, this dict has items that could not be converted.
   

# Generated at 2022-06-23 18:09:23.296999
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from unittest.mock import patch
    from unittest import TestCase

    class TestToNamedTuple(TestCase):

        def test_1_dict_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            nt = to_namedtuple(dic)
            self.assertIsInstance(nt, namedtuple('NamedTuple', 'a b'))
            self.assertEqual(nt.a, 1)
            self.assertEqual(nt.b, 2)


# Generated at 2022-06-23 18:09:34.869830
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt1 = to_namedtuple(dic)
    assert type(nt1) == namedtuple('NamedTuple', ['a', 'b'])
    assert nt1.a == 1
    assert nt1.b == 2
    d = {'a': {'aa': 1}, 'b': 2}
    nt2 = to_namedtuple(d)
    assert type(nt2.a) == namedtuple('NamedTuple', ['aa'])
    assert nt2.a.aa == 1
    assert nt2.b == 2
    d = OrderedDict([('a', {'aa': 1}), ('b', 2)])
    nt3 = to_namedtuple(d)

# Generated at 2022-06-23 18:09:45.870223
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Ensure that functions works as expected."""
    from pprint import pprint
    from typing import Dict
    from flutils.namedtupleutils import to_namedtuple as _to_namedtuple

    dic = {
        'key1': 1,
        'key2': 2,
        'key3': 3,
    }
    assert hasattr(_to_namedtuple(dic), 'key1')
    assert hasattr(_to_namedtuple(dic), 'key2')
    assert hasattr(_to_namedtuple(dic), 'key3')
    assert hasattr(_to_namedtuple(dic), '__slots__')
    assert _to_namedtuple(dic).key1 == 1
    assert _to_namedtuple(dic).key2 == 2
    assert _to

# Generated at 2022-06-23 18:09:54.831375
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from flutils.typesutils import AttrAccessibleDict
    from flutils.typesutils import AttrAccessibleList
    from flutils.typesutils import AttrAccessibleTuple
    from flutils.validators import validate_identifier

    assert to_namedtuple([]) == ()
    assert to_namedtuple([1, 2, 3]) == (1, 2, 3)
    assert to_namedtuple([1, 2, 3]) == list((1, 2, 3))
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple((1, 2, 3)) == tuple((1, 2, 3))
    assert to

# Generated at 2022-06-23 18:10:06.553331
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import ChainMap
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.miscutils import NestedNamespace

    assert isinstance(to_namedtuple([]), list)
    assert isinstance(to_namedtuple(()), tuple)
    assert isinstance(to_namedtuple({}), namedtuple('NamedTuple', ''))

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', ['a', 'b']))
    assert nt.a == 1
    assert nt.b == 2
    assert nt == dic


# Generated at 2022-06-23 18:10:17.314061
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase

    from typing import Tuple

    from flutils.namedtupleutils import to_namedtuple

    class Test(TestCase):
        def test_to_namedtuple(self):
            data = {'one': 1, 'two': 2, 'three': 3}
            data = to_namedtuple(data)
            self.assertEqual(data.one, 1)
            self.assertEqual(data.two, 2)
            self.assertEqual(data.three, 3)
            self.assertTrue(isinstance(data, Tuple))


if __name__ == '__main__':
    # Unit test this module.
    test_to_namedtuple()

# Generated at 2022-06-23 18:10:25.797072
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class ToNamedTupleTests(unittest.TestCase):
        def test_to_namedtuple(self) -> None:
            dic = {'a': 1, 'b': 2}
            self.assertEqual(
                to_namedtuple(dic),
                namedtuple('NamedTuple', ('a', 'b'))(1, 2)
            )

    unittest.main(argv=['first-arg-is-ignored'], exit=False)


# Generated at 2022-06-23 18:10:35.730108
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)


if __name__ == '__main__':
    print(to_namedtuple([{'a': 1, 'b': 2}]))
    print(to_namedtuple({'a': 1, 'b': 2}))
    print(to_namedtuple(namedtuple('NamedTuple', 'a b')(a=1, b=2)))
    print(to_namedtuple(SimpleNamespace(a=1, b=2)))

# Generated at 2022-06-23 18:10:46.167437
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = {'a': 1, 'b': 2}
    assert to_namedtuple(a) == NamedTuple(a=1, b=2)
    b = {'a': 1, 'b': {'c': 3}}
    assert to_namedtuple(b) == NamedTuple(a=1, b=NamedTuple(c=3))
    c = [1, 2, 3, 4, 5]
    assert to_namedtuple(c) == [1, 2, 3, 4, 5]
    d = (1, 2, 3, 4, 5)
    assert to_namedtuple(d) == (1, 2, 3, 4, 5)
    e = [{'a': 1, 'b': {'c': 3}}]

# Generated at 2022-06-23 18:10:55.838145
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = {
        'an_attribute': 'a value'
    }
    expected = NamedTuple(an_attribute='a value')
    actual = to_namedtuple(data)
    assert expected == actual

# Generated at 2022-06-23 18:11:06.638579
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    dic = {'a': 1, 'b': 2}
    dic_od = OrderedDict(dic)
    dic_sn = SimpleNamespace(a=1, b=2)
    assert to_namedtuple(dic) == to_namedtuple(dic_od) == to_namedtuple(dic_sn)
    assert to_namedtuple(dic_od) == to_namedtuple(dic_sn)
    assert to_namedtuple(dic_sn) == to_namedtuple(dic_od)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:11:12.610363
# Unit test for function to_namedtuple
def test_to_namedtuple():
    namedtuple_utils = to_namedtuple({'a': 1, 'b': 2})
    assert namedtuple_utils.a == 1, "Expected Output: 1; Actual Output: " + str(namedtuple_utils.a)
    assert namedtuple_utils.b == 2, "Expected Output: 2; Actual Output: " + str(namedtuple_utils.b)
    print("to_namedtuple: All tests passed.")

if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-23 18:11:23.207376
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''
    Unit test for function to_namedtuple
    '''
    from collections import namedtuple

    a1 = namedtuple('A1', 'x y')(1, 2)
    a2 = namedtuple('A2', 'x y')(10, 20)

    b1 = namedtuple('B1', 'a1 a2')(a1, a2)
    b2 = namedtuple('B2', 'a1 a2')(a1, a2)

    c1 = namedtuple('C1', 'b1 b2')(b1, b2)
    c2 = namedtuple('C2', 'b1 b2')(b1, b2)

    d1 = namedtuple('D1', 'c1 c2')(c1, c2)
    d2 = named

# Generated at 2022-06-23 18:11:32.781177
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Unit test for function to_namedtuple'''
    from unittest import TestCase

    from collections import namedtuple, OrderedDict

    from flutils.namedtupleutils import to_namedtuple

    def _to_list(obj):
        '''Helper function to return list of keys'''
        return list(getattr(obj, '_fields', ()))

    class Test(TestCase):
        '''Class of unit tests for function to_namedtuple'''

        def test_ordered_dict_input(self):
            '''``OrderedDict`` input'''
            data = OrderedDict(a=1, b=2, c=3, d=4)
            out = to_namedtuple(data)
            self.assertEqual(out.a, 1)
            self.assertE

# Generated at 2022-06-23 18:11:42.817766
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Needed to test the first clause of the return statement
    tup = (0, 1, 2)
    assert to_namedtuple(tup) == (0, 1, 2)
    assert to_namedtuple(tup) is not tup  # testing shallowness
    assert to_namedtuple(tup) == tup

    lst = [0, 1, 2]
    assert to_namedtuple(lst) == [0, 1, 2]
    assert to_namedtuple(lst) is not lst  # testing shallowness
    assert to_namedtuple(lst) == lst

    ntup = namedtuple('NamedTuple', 'a b c')(0, 1, 2)
    assert to_namedtuple(ntup) == ntup


# Generated at 2022-06-23 18:11:54.341301
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(None) == to_namedtuple({})
    assert to_namedtuple(1234) == to_namedtuple({})
    assert to_namedtuple('') == to_namedtuple({})
    assert type(to_namedtuple('')) == type(to_namedtuple({}))
    dic = {'a': 1, 'b': 2}
    val = to_namedtuple(dic)
    assert val.a == 1
    assert val.b == 2
    assert val == to_namedtuple(OrderedDict(dic))
    assert type(val) == type(to_namedtuple(dic))
    assert type(val) == type(to_namedtuple(OrderedDict(dic)))
    # noinspection PyTypeChecker


# Generated at 2022-06-23 18:11:55.686122
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(None) == None
    return

# Generated at 2022-06-23 18:12:01.937746
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest
    from collections import OrderedDict
    from types import SimpleNamespace
    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    dic['c'] = 3
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3

    dic = OrderedDict()

# Generated at 2022-06-23 18:12:13.454410
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Tests for ``to_namedtuple``."""
    from collections import OrderedDict
    from copy import copy
    from os import path
    import tempfile
    import json

    # A function that tests the return type is a NamedTuple
    def is_namedtuple_instance(obj: Any,
                               name: str) -> Tuple[bool, str]:
        from collections import namedtuple

        # If type is NamedTuple return True; otherwise False
        if isinstance(obj, namedtuple(name)):
            return True, ''

        return False, ("Type: (%r) %s not of NamedTuple: (%r) %s" %
                       (type(obj).__name__, obj, name, obj))

    dic = {'a': 1, 'b': 2}

# Generated at 2022-06-23 18:12:24.382000
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""

    import unittest

    class TestToNamedTuple(unittest.TestCase):
        """Unit test class for to_namedtuple"""

        maxDiff = None

        def setUp(self) -> None:
            """Set up for each test"""
            self.dic = {
                'a': '1',
                'b': {
                    'c': 99,
                    'd': 4,
                },
                'e': [
                    'x',
                    'y',
                    {
                        'z': 'Z',
                    },
                ],
                'f': '4',
            }
            self.list = [
                {
                    'a': 'A',
                    'b': 'B',
                },
                'test',
            ]
            self.t

# Generated at 2022-06-23 18:12:35.729449
# Unit test for function to_namedtuple
def test_to_namedtuple():

    named = to_namedtuple({'a': 1, 'b': 2})
    assert named == namedtuple('NamedTuple', ['a', 'b'])(1, 2)

    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]) == [
        namedtuple('NamedTuple', ['a', 'b'])(1, 2),
        namedtuple('NamedTuple', ['a', 'b'])(1, 2),
    ]


# Generated at 2022-06-23 18:12:48.131212
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # string
    assert to_namedtuple('hello') == 'hello'
    # list of strings becomes str
    assert to_namedtuple(['hello']) == ('hello',)
    # tuple of strings becomes str
    assert to_namedtuple(('hello',)) == ('hello',)
    # tuple of int becomes str
    assert to_namedtuple((123,)) == ('123',)

    # :obj:`list` of int data becomes :obj:`NamedTuple <collections.namedtuple>`
    assert to_namedtuple([123]) == NamedTuple('123')
    # :obj:`list` of int data becomes :obj:`NamedTuple <collections.namedtuple>`
    assert to_namedtuple([(1,)]) == (NamedTuple(1),)
    #

# Generated at 2022-06-23 18:12:57.311790
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pytest import raises
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    make_nt = namedtuple('NamedTuple', 'a b c')
    make_nt_sub = namedtuple('NamedTupleSub', 'a b c d e')
    make_nt_sub_sub = namedtuple('NamedTupleSubSub', 'a b c d e f g')

    nt = make_nt(1, 2, 3)
    nested = make_nt_sub(1, 2, 3, 4, make_nt(1, 2, 3))

# Generated at 2022-06-23 18:13:08.722965
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections.abc import Mapping
    from collections import OrderedDict
    from typing import Dict
    dic: Dict[str, Any] = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5,
                'h': 6
            },
            'i': [7, 8, 9],
            'j': [10, 11, {'k': 12}]
        }
    }
    namedtuple_dic = to_namedtuple(dic)
    assert isinstance(namedtuple_dic, NamedTuple)
    assert isinstance(namedtuple_dic.c, NamedTuple)

# Generated at 2022-06-23 18:13:18.515214
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import re
    py_code = """from collections import OrderedDict
from namedtupleutils import to_namedtuple
from typing import Union
from types import SimpleNamespace
from typing import NamedTuple

"""
    my_dict = OrderedDict()
    py_code += 'my_dict = OrderedDict()'
    py_code += '\n'
    made_dict = ''
    for i in range(3):
        for j in range(3):
            for k in range(3):
                for l in range(3):
                    my_key = f"{'_' if i == 1 else ''}a{i}{j}{k}{l}"
                    my_val = f"val{i}{j}{k}{l}"
                    my_dict[my_key] = my_val

# Generated at 2022-06-23 18:13:27.397265
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple('hello') == 'hello'
    assert to_namedtuple(['hello']) == ['hello']
    assert to_namedtuple(('hello')) == ('hello', )
    assert to_namedtuple({'hello': 'world'}) == namedtuple('NamedTuple', 'hello')(hello='world')
    assert to_namedtuple({'hello': {'world': ['test']}}) == namedtuple('NamedTuple', 'hello')(hello=namedtuple('NamedTuple', 'world')(world=('test', )))
    # assert to_namedtuple({'hello': {'world': 'testing'}}) == {'hello': {'world': 'testing'}}
    assert to_namedtuple({'hello': {'world': 'testing'}}) == namedtuple

# Generated at 2022-06-23 18:13:35.178776
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert isinstance(to_namedtuple([]), list)
    assert isinstance(to_namedtuple(()), tuple)
    assert isinstance(to_namedtuple({}), namedtuple('NamedTuple', ''))
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), namedtuple('NamedTuple', 'a b'))

    dic1 = {'a': 0, 'b': 1, 'c': {'d': 2, 'e': 3}, 'f': 4, 'g': [5, 6]}
    tup1 = to_namedtuple(dic1)
    assert isinstance(tup1, namedtuple('NamedTuple', 'a b c f g'))
    assert tup1.a == 0

# Generated at 2022-06-23 18:13:43.518189
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')

    assert to_namedtuple({'a': 'a', 'b': 'b', 'c': 'c'}) == \
        NamedTuple(a='a', b='b', c='c')
    assert to_namedtuple(OrderedDict((('a', 'a'), ('b', 'b'), ('c', 'c')))) == \
        NamedTuple(a='a', b='b', c='c')

# Generated at 2022-06-23 18:13:53.546557
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace


# Generated at 2022-06-23 18:14:05.632517
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Iterable
    from collections import namedtuple
    TestNT = namedtuple('TestNT', ('a', 'b', 'c'))
    TestNT2 = namedtuple('TestNT', ('a', 'b', 'c'))

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == TestNT(a=1, b=2, c=3)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) == \
        TestNT(a=1, b=2, c=3)

# Generated at 2022-06-23 18:14:06.882948
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:14:16.332737
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:14:28.835392
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestValues(unittest.TestCase):
        def test_to_namedtuple(self):
            self.assertRaises(
                TypeError,
                to_namedtuple, 'no_conver_string'
            )
            self.assertRaises(
                TypeError,
                to_namedtuple, 'no_conver_string', _started=True
            )
            self.assertRaises(
                TypeError,
                to_namedtuple, (1, 2, 3, 4, 5, 6)
            )
            self.assertRaises(
                TypeError,
                to_namedtuple, (1, 2, 3, 4, 5, 6), _started=True
            )

# Generated at 2022-06-23 18:14:32.030407
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:14:42.160366
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 2, 'b': 1}]) == [NamedTuple(a=1, b=2), NamedTuple(a=2, b=1)]
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 2, 'b': 1}]) == [NamedTuple(a=1, b=2), NamedTuple(a=2, b=1)]

# Generated at 2022-06-23 18:14:53.474840
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    _ = to_namedtuple(dic)
    assert _.a == 1
    assert _.b == 2

    dic = {'a': 1, 'b': [1, 2]}
    _ = to_namedtuple(dic)
    assert _.a == 1
    assert _.b == (1, 2)

    dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    _ = to_namedtuple(dic)
    assert _.a == 1
    assert _.b.c == 3
    assert _.b.d == 4

    dic = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': [5, 6]}

# Generated at 2022-06-23 18:14:54.032367
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-23 18:15:03.181941
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.validators import is_proper_identifier
    from types import SimpleNamespace
    T = to_namedtuple
    with pytest.raises(TypeError):
        T(1)
    with pytest.raises(TypeError):
        T(1.2)
    assert T({}) == namedtuple('NamedTuple', '')()
    dic = {'a': 1, 'b': 2}
    assert T(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert T(dic)[0] == 1
    assert T(dic)[1] == 2
    assert T(dic).a == 1
    assert T(dic).b == 2

# Generated at 2022-06-23 18:15:15.558035
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import namedtuple
    import os
    import sys
    import datetime
    import flutils

    # Test for function _to_namedtuple
    def test_to_namedtuple_helper():

        # Change the path
        # from os.path import dirname
        # sys.path.insert(0, dirname(dirname(dirname(dirname(__file__)))))
        # os.chdir(os.path.dirname(__file__))

        assert os. path.exists(
            os.path.join(os.path.dirname(__file__), 'flutils', '__init__.py')
        )

        # noinspection PyUnresolvedReferences
        import flutils.namedtupleutils
        from flutils.namedtupleutils import _to_namedtuple

        # Test

# Generated at 2022-06-23 18:15:17.383775
# Unit test for function to_namedtuple
def test_to_namedtuple():

    """Run doctest unit tests for namedtupleutils.to_namedtuple"""

    # noinspection PyShadowingBuiltins
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 18:15:27.890459
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.objectutils import get_args
    from flutils.validators import validate_identifier

    # Test with a string
    arg_list = get_args(to_namedtuple)
    arg_list[0] = 'string'
    try:
        to_namedtuple(*arg_list)
        assert False, 'Should have raised a TypeError with a str'
    except TypeError as err:
        assert str(err) == "Can convert only 'list', 'tuple', 'dict' to a " \
                           "NamedTuple; got: (str) string"

    # Test with a list
    arg_list[0] = ['string']
    rval = to_namedtuple(*arg_list)
    assert rval == ('string',)

    # Test with a tuple

# Generated at 2022-06-23 18:15:38.039825
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from typing import List, Tuple, Union

    _AllowedTypes = Union[
        List,
        Mapping,
        Tuple,
        SimpleNamespace,
    ]


# Generated at 2022-06-23 18:15:48.556770
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple([1, 2, {'a': 1}]) == [1, 2, namedtuple('NamedTuple', ['a'])(a=1)]
    assert to_namedtuple((1, 2, {'a': 1})) == (1, 2, namedtuple('NamedTuple', ['a'])(a=1))
    assert to_namedtuple([1, 2, {'a': 1, 'b': 2}]) == [1, 2, namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)]

# Generated at 2022-06-23 18:15:59.433869
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    output: NamedTuple = to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(output, NamedTuple)
    assert output.a == 1
    assert output.b == 2

    output: NamedTuple = to_namedtuple({'a': 1, 'b': {'c': 1, 'd': 2}})
    assert isinstance(output, NamedTuple)
    assert output.a == 1
    assert isinstance(output.b, NamedTuple)
    assert output.b.c == 1
    assert output.b.d == 2

    output: NamedTuple = to_namedtuple({'a': 1, 'b': {'c': {'d': 1, 'e': 2}}})

# Generated at 2022-06-23 18:16:08.326382
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b']) == ('a', 'b')
    assert to_namedtuple(['a', 'b']).__class__.__name__ == 'NamedTuple'
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2}).__class__.__name__ == 'NamedTuple'
    assert to_namedtuple({'a': 1, 'b': {'x': 1}}) == NamedTuple(
        a=1, b=NamedTuple(x=1)
    )

# Generated at 2022-06-23 18:16:17.548726
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test for function ``to_namedtuple``.

    :raises:
        :exc:`AssertionError` if the test fails.
    """

    def run_test(args):
        """
        Run a single test (helper function).

        :param args:
            The keyword arguments to the test function.

        :returns:
            The output of the test.
        """

        exp = args.pop('output')
        msg = args.pop('msg', '')
        act = to_namedtuple(**args)
        assert act == exp, msg + '\nGiven: %r\nExpected: %r\nActual: %r\n' % (args, exp, act)
