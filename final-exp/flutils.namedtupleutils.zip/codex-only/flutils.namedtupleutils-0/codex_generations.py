

# Generated at 2022-06-23 18:06:24.141644
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import Any, Callable, List

    def _get_type(obj: Any) -> str:
        return type(obj).__name__

    basic = OrderedDict(
        (
            ('a', 1),
            ('b', 2),
            ('c', 3),
            ('d', 4),
            ('e', 5),
            ('f', 6)
        ),
    )

    ntr = to_namedtuple(basic)
    assert _get_type(ntr) == 'NamedTuple'
    assert ntr.a == 1
    assert ntr.b == 2
    assert ntr.c == 3
    assert ntr.d == 4
    assert ntr.e == 5
    assert ntr.f == 6

    basic['g'] = '7'

# Generated at 2022-06-23 18:06:34.569704
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {
        '_a': 1, 'b': 2, '__c': 3,
        'd': [4, 5, 6]
    }
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'b d')(2, [4, 5, 6])
    dic = {
        '_a': 1,
        'b': OrderedDict(
            [
                ('c', 3), ('d', OrderedDict([('e', 5), ('f', [6, 7])])),
            ]
        )
    }

# Generated at 2022-06-23 18:06:41.548367
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test to_namedtuple
    import unittest.mock

    # Test case: If a given object is of ``list`` or ``tuple``, each item in the
    #            given object is recursively converted to a ``NamedTuple``.
    obj = []
    expected_result = []
    actual_result = to_namedtuple(obj)
    assert actual_result == expected_result

    obj = [1, 2, 3]
    expected_result = [1, 2, 3]
    actual_result = to_namedtuple(obj)
    assert actual_result == expected_result

    obj = tuple(obj)
    expected_result = tuple(obj)
    actual_result = to_namedtuple(obj)
    assert actual_result == expected_result


# Generated at 2022-06-23 18:06:53.070451
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import types

    assert (
        to_namedtuple({'a': 1, 'b': 2})
        ==
        namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    )
    assert (
        to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
        ==
        namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    )

# Generated at 2022-06-23 18:07:01.954065
# Unit test for function to_namedtuple
def test_to_namedtuple():
    try:
        _to_namedtuple(0)
    except TypeError:
        pass
    else:
        raise RuntimeError(
            "Should have raised TypeError: 'int' cannot be converted to a "
            "NamedTuple; got: 0"
        )
    try:
        _to_namedtuple(0.0)
    except TypeError:
        pass
    else:
        raise RuntimeError(
            "Should have raised TypeError: 'float' cannot be converted to a "
            "NamedTuple; got: 0.0"
        )
    try:
        _to_namedtuple(None)
    except TypeError:
        pass

# Generated at 2022-06-23 18:07:13.385101
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import (
        _to_namedtuple,
        to_namedtuple,
    )
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert out.a == obj['a']
    assert out.b == obj['b']

    obj = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(obj)
    assert out.a == obj['a']
    assert out.b == obj['b']
    assert not hasattr(out, '_c')

    obj = {3: 1, 5: 2, 7: 3}
    out = to_namedtuple(obj)
    assert not hasattr(out, '3')
    assert not has

# Generated at 2022-06-23 18:07:18.806449
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from string import ascii_letters
    from random import choices

    def check_except(func, exc_type, exc_msg):
        try:
            func()
        except BaseException as err:
            assert isinstance(err, exc_type)
            assert err.args == (exc_msg,)


    dic = {'a': 1, 'b': 2}
    ex = to_namedtuple(dic)
    assert ex.a == 1
    assert ex.b == 2

    check_except(lambda: to_namedtuple(list(dic)), TypeError,
                 "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                 "got: (list) %s" % list(dic))

    check

# Generated at 2022-06-23 18:07:30.315437
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from io import StringIO
    from pprint import pprint, pformat
    from textwrap import dedent

    @to_namedtuple.register(bytes)
    def _(obj, _started=False):
        return obj.decode('utf8')

    @to_namedtuple.register(int)
    def _(obj, _started=False):
        return obj

    @to_namedtuple.register(float)
    def _(obj, _started=False):
        return obj

    @to_namedtuple.register(complex)
    def _(obj, _started=False):
        return obj

    @to_namedtuple.register(range)
    def _(obj, _started=False):
        return list(obj)

    # noinspection PyUnresolvedReferences,PyProtectedMember
    obj

# Generated at 2022-06-23 18:07:42.485827
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 'a.1', 'b': 'b.1'}) == NamedTuple(a='a.1', b='b.1')

    assert to_namedtuple({'A_': 1, 'b_': 2}) == NamedTuple(b=2)

    assert to_namedtuple(OrderedDict([('b', 2), ('a', 1)])) == NamedTuple(b=2, a=1)

    assert to_namedtuple(OrderedDict({'b': 2, 'a': 1})) == NamedTuple(b=2, a=1)

    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)

    assert to_namedtuple(b'bytes') == NamedTuple

# Generated at 2022-06-23 18:07:51.623626
# Unit test for function to_namedtuple
def test_to_namedtuple(): # noqa: D102
    lst = [{'a': 1}, {'a': 2}]
    assert to_namedtuple(lst) == [NamedTuple(a=1), NamedTuple(a=2)]
    assert to_namedtuple(lst) is not lst

    dic = {'a': 1}
    assert to_namedtuple(dic) == NamedTuple(a=1)
    assert to_namedtuple(dic) is not dic

    dic = {'a': {'b': 1}, 'c': 2}
    assert to_namedtuple(dic) == NamedTuple(a=NamedTuple(b=1), c=2)
    assert to_namedtuple(dic) is not dic

    # noinspection PyTypeChecker
   

# Generated at 2022-06-23 18:08:00.866343
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    import unittest

    class ToNamedTupleTestCase(unittest.TestCase):
        """Tests for to_namedtuple."""

        def test_tuple(self):
            """Test tuple."""
            # Setup
            in_tup = (1, 2)
            in_tup_namedtuple = namedtuple(
                'in_tup_namedtuple',
                ' '.join(str(i) for i in range(len(in_tup)))
            )(*in_tup)
            out_tup = in_tup_namedtuple(*in_tup)

            # Exercise
            result = to_namedtuple(in_tup)

            # Verify

# Generated at 2022-06-23 18:08:08.034603
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert result.a == 1
    assert result.b == 2
    assert result == (1, 2)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:08:14.518052
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.tests.load_tests import load_tests
    file = __file__.split('.')[0]
    module = f'{file}.test_to_namedtuple'
    tests = load_tests(module)
    if tests is None:
        raise RuntimeError(f'No tests found for {module}')

    for test in tests:
        data = test['data']
        obj = test['obj']
        msg = test['msg']
        expected = test['expected']
        result = None

        try:
            result = to_namedtuple(obj)
        except Exception as exc:
            result = None
            if not isinstance(expected, Exception):
                raise
       

# Generated at 2022-06-23 18:08:19.296826
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import doctest
    unittest.TestCase.maxDiff = None
    suite = unittest.TestSuite()
    suite.addTest(doctest.DocTestSuite(to_namedtuple))
    return suite

# Generated at 2022-06-23 18:08:28.550219
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    named_tuple = to_namedtuple(dic)
    assert isinstance(named_tuple, NamedTuple) 
    assert named_tuple.a == 1 
    assert named_tuple.b == 2 

    ord_dic = OrderedDict({'a': 1, 'b': 2})
    named_tuple = to_namedtuple(ord_dic)
    assert isinstance(named_tuple, NamedTuple) 
    assert named_tuple.a == 1 
    assert named_tuple.b == 2 

    dic = {'a': 1, 'b': 2}
    named_tuple = to_namedtuple(SimpleNamespace(**dic))

# Generated at 2022-06-23 18:08:41.336091
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test for the to_namedtuple function.
    """
    from flutils.miscutils import make_temp_directory
    from flutils.namedtupleutils import (
        is_namedtuple,
        traverse
    )
    from typing import Dict, Tuple
    from pathlib import Path
    from os.path import (
        dirname,
        join,
    )
    from os import remove
    from json import dump
    from tempfile import NamedTemporaryFile
    from unittest.mock import patch
    from unittest import TestCase
    from ruamel.yaml import Loader, YAML
    from ruamel.yaml.dumper import SafeDumper
    from ruamel.yaml.comments import CommentedMap
    from ruamel.yaml.comments import CommentedSeq

# Generated at 2022-06-23 18:08:49.858527
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic: dict = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert nt.a == 1
    assert nt.b == 2

    dic = {}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)

    dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert nt.a == 1
   

# Generated at 2022-06-23 18:08:51.362617
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 18:09:01.674426
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.testingutils import RandomData
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    rd = RandomData()

    # tuple
    data = (1, 2, 3, 4, 5)
    # noinspection PyTypeChecker
    out: tuple = to_namedtuple(data)
    assert isinstance(out, tuple)
    assert out == data
    data = (rd.random_dict(), rd.random_dict(), rd.random_dict())
    # noinspection PyTypeChecker
    out: tuple = to_namedtuple(data)
    assert isinstance(out, tuple)
    assert isinstance(out[0], tuple)

# Generated at 2022-06-23 18:09:11.144366
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(OrderedDict(
        (x, x * 2) for x in range(3)
    )) == to_namedtuple(['red', 'green', None]) == to_namedtuple(
        [(9, 8, 7), (6, 5, 4), (3, 2, 1)]
    ) == to_namedtuple(
        # noinspection PyUnresolvedReferences
        SimpleNamespace(**dict(
            (x, x * 2) for x in range(3)
        ))
    ) == to_namedtuple(dict(
        (x, x * 2) for x in range(3)
    )) == SimpleNamespace(
        a=0,
        b=2,
        c=4,
    )

# Generated at 2022-06-23 18:09:21.716968
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Tests function to_namedtuple
    """
    assert 1 == to_namedtuple({'a': 1})['a']
    assert 2 == to_namedtuple({'b': 1, 'a': 2})['a']
    assert 1 == to_namedtuple({'b': 1, 'a': 2}.items(), _started=True)[1][1]
    assert 2 == to_namedtuple((1, 2))[1]
    assert 2 == to_namedtuple((1, {'b': 1, 'a': 2}))[1]['a']
    assert [2] == to_namedtuple([(1, {'b': 1, 'a': 2})])[0][1]['a']

# Generated at 2022-06-23 18:09:33.856277
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils

    assert to_namedtuple({'a': 1, 'b': 2}) == flutils.NamedTuple(a=1, b=2)
    assert to_namedtuple(dict(a=1, b=2)) == flutils.NamedTuple(a=1, b=2)
    assert to_namedtuple([dict(a=1, b=2), dict(c=3, d=4)]) == [
        flutils.NamedTuple(a=1, b=2),
        flutils.NamedTuple(c=3, d=4)
    ]

# Generated at 2022-06-23 18:09:41.736597
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple

    def _test_to_namedtuple(
            obj: Any,
            expected: Any
    ):
        # type: (...) -> None
        assert to_namedtuple(obj) == expected

    _test_to_namedtuple(
        {'a': 1, 'b': 2},
        to_namedtuple({'a': 1, 'b': 2}),
    )
    _test_to_namedtuple(
        OrderedDict((('a', 1), ('b', 2))),
        to_namedtuple(OrderedDict((('a', 1), ('b', 2)))),
    )

    # dict
    dic = {'a': 1, 'b': 2}
    expected = to

# Generated at 2022-06-23 18:09:49.349383
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic_mixed = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    assert to_namedtuple(dic_mixed) == namedtuple('NamedTuple', 'a b c')(a=1, b=2,
                                        c=namedtuple('NamedTuple', 'd e')(d=3, e=4))

    dic_multi = {'a': 1, 'b': [{'c': 3, 'd': 4}, {'c': 5, 'd': 6}]}

# Generated at 2022-06-23 18:09:57.505367
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {
        'b': {'c': 2, 'd': 3},
        'a': 1,
    }
    assert to_namedtuple(d) == namedtuple('NamedTuple', ['a', 'b'])(1, namedtuple('NamedTuple', ['c', 'd'])(2, 3))
    o = OrderedDict()
    o['a'] = 1
    o['b'] = {'c': 2, 'd': 3}
    assert to_namedtuple(o) == namedtuple('NamedTuple', ['a', 'b'])(1, namedtuple('NamedTuple', ['c', 'd'])(2, 3))
    SN = SimpleNamespace()
    SN.a = 1
    SN.b = {'c': 2, 'd': 3}
   

# Generated at 2022-06-23 18:10:02.008837
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import random, string
    def gen_string(length):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(length))

    # test to_namedtuple on dictionary with only strings, numbers and other dictionaries as values
    dic = {'an_int': 1, 'float': 3.14, 'string': 'hello', 'another_dic': {'an_int': 1, 'float': 3.14, 'string': 'hello'}}
    nt_dic = to_namedtuple(dic)
    assert nt_dic.an_int == 1
    assert nt_dic.float == 3.14
    assert nt_dic.string == 'hello'

# Generated at 2022-06-23 18:10:12.674480
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from typing import NamedTuple
    from datetime import datetime
    from flutils.namedtupleutils import to_namedtuple

    pn_Test = namedtuple('Test', 'something else')
    pn_Test.__doc__ = "A test namedtuple."

    # pn_TestFields = namedtuple('TestFields', '__field1 __field2')
    # pn_TestFields.__doc__ = \
    #     "A test namedtuple with private identifiers as it's fields."
    #
    # pn_TestFieldsTmp = namedtuple('TestFieldsTmp', '_field1 _field2')
    # pn_TestFieldsTmp.__doc__ = \
    #     "A test namedtuple with private identifiers as it's

# Generated at 2022-06-23 18:10:23.673124
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    if sys.version_info < (3, 7):
        from collections import OrderedDict
        from types import SimpleNamespace
        import pytest
        from flutils.namedtupleutils import to_namedtuple

        def test_simple_dict():
            d = dict(a=1, b=2)
            out = to_namedtuple(d)
            assert out.a == 1
            assert out.b == 2


# Generated at 2022-06-23 18:10:34.863172
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # `Mapping`
    data = {'a': 1, 'b': 2}
    assert to_namedtuple(data) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    data = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(data) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    # `Sequence`
    data = ['a', 'b']
    assert to_namedtuple(data) == ['a', 'b']
    data = ('a', 'b')
    assert to_namedtuple(data) == ('a', 'b')
    d1 = namedtuple('NamedTuple', 'a b')(a=1, b=2)

# Generated at 2022-06-23 18:10:43.248992
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == ('a', 'b')
    assert to_namedtuple({'_a': 1}) == ()
    assert to_namedtuple({'3a': 1}) == ()
    assert to_namedtuple({'a': 1, 'b': 2, 'c': [{'c': 3}]}) == (
        'a',
        'b',
        'c',
    )
    assert to_namedtuple([1, 2]) == (1, 2)
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple(OrderedDict([('3', 3), ('a', 1), ('b', 2)])) == (
        '3',
        'a',
        'b',
    )


# Generated at 2022-06-23 18:10:53.984281
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    nt = to_namedtuple(obj)
    # noinspection PyUnresolvedReferences
    assert nt.a == 1
    # noinspection PyUnresolvedReferences
    assert nt.b == 2

    obj = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    nt = to_namedtuple(obj)
    # noinspection PyUnresolvedReferences
    assert nt[0].a == 1
    # noinspection PyUnresolvedReferences
    assert nt[0].b == 2
    # noinspection PyUnresolvedReferences
    assert nt[1].a == 3
    # noinspection PyUnresolvedReferences
    assert nt[1].b == 4

    obj

# Generated at 2022-06-23 18:11:05.466098
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None

    dic = {'a': 1, 'b': 2}
    expect = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dic) == expect

    dic = {'a': 1, 'b': 2, 'n': None}
    expect = namedtuple('NamedTuple', 'a b n')(a=1, b=2, n=None)
    assert to_namedtuple(dic) == expect

    dic = {'a': 1, 'b': 2, 'n': None, 'm': 'moo'}
    expect = namedtuple('NamedTuple', 'a b m n')(a=1, b=2, m='moo', n=None)
    assert to

# Generated at 2022-06-23 18:11:10.192827
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == to_namedtuple(())
    assert to_namedtuple({}) == to_namedtuple('')
    assert to_namedtuple({}) == to_namedtuple([])
    assert to_namedtuple({}) == to_namedtuple({'a': 1})
    assert to_namedtuple({'a': 1}) == to_namedtuple({'a': 1})
    assert to_namedtuple({'a': 1}) == to_namedtuple({'a': 1, 'b': 2})
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(
        {'a': 1, 'b': 2}
    )

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple

# Generated at 2022-06-23 18:11:18.769653
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from typing import NamedTuple

    class TestCase(NamedTuple):
        _test: str = 'test_data'

    test_cases = [
        {'test_dict': {'test_key': 'test_value'}},
        [{'test_dict_list': [{'test_dict_list_nested': [{'test_dict_list_nested2': 'test_list_dict'}]}]}],
        TestCase(),
        [TestCase()],
    ]

# Generated at 2022-06-23 18:11:31.518696
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import OrderedDict

    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from flutils.objects import C
    from flutils.testing.helpers import (
        random_kwargs,
        random_sequence,
    )

    def check(obj):
        assert isinstance(obj, tuple)
        assert len(obj._fields) == 2
        assert isinstance(obj.a, list)
        assert isinstance(obj.b, tuple)
        assert obj[0] is obj.a
        assert obj[1] is obj.b
        assert obj.a == [1, 2, 3]
        assert obj.b == (4, 5, 6)

    obj = to_namedtuple(('a', 'b'))
    check(obj)

    obj = to_

# Generated at 2022-06-23 18:11:42.247739
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert result == namedtuple('NamedTuple', 'a, b')(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': {'d': 4}}
    result = to_namedtuple(dic)
    assert result == namedtuple('NamedTuple', 'a, b, c')(
        a=1, b=2, c=namedtuple('NamedTuple', 'd')(d=4)
    )
    dic = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 'foo'}}
    result

# Generated at 2022-06-23 18:11:48.586262
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import date, time
    from time import time as time_
    from decimal import Decimal
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from operator import attrgetter
    import json

    data = {
        'Boolean': True,
        'Integer': 123,
        'Float': -1.23,
        'String': 'abc',
        'Date': date(2018, 1, 1),
        'Time': time(1, 2, 3),
        'Decimal': Decimal(1.23456789),
        'List': [0, 1, 2],
        'Dict': {'a': 1, 'b': 2},
        'OrderedDict': OrderedDict((('a', 1), ('b', 2))),
    }


# Generated at 2022-06-23 18:11:53.752861
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    from flutils.tests.pytestutils import run_all_tests
    run_all_tests(__file__, globals())


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:12:01.042945
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a_type = SimpleNamespace(a=1, b=2, c=3)
    out1 = to_namedtuple(a_type)
    out2 = to_namedtuple(a_type.__dict__)
    out3 = to_namedtuple(OrderedDict(a=1, b=2, c=3))
    assert out1 == out2 == out3

    a_type = SimpleNamespace(a=1, b=2, c=3, d=4)
    out1 = to_namedtuple(a_type)
    out2 = to_namedtuple(a_type.__dict__)
    out3 = to_namedtuple(OrderedDict(a=1, b=2, c=3, d=4))
    assert out1 == out2 == out3

   

# Generated at 2022-06-23 18:12:13.006430
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        namedtuple,
        OrderedDict,
    )
    from unittest import TestCase

    class TestToNamedTuple(TestCase):
        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            res = to_namedtuple(dic)
            self.assertTrue(isinstance(res, namedtuple))
            self.assertEqual(res.a, 1)
            self.assertEqual(res.b, 2)
            self.assertTrue(hasattr(res, 'a'))
            self.assertTrue(hasattr(res, 'b'))
            self.assertFalse(hasattr(res, 'dic'))


# Generated at 2022-06-23 18:12:23.936924
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == cast(NamedTuple, namedtuple('NamedTuple', 'a b')(a=1, b=2))
    assert to_namedtuple([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert to_namedtuple([1, 2, [3, 4], 5]) == [1, 2, [3, 4], 5]
    assert to_namedtuple([1, 2, {'a': 3, 'b': 4}, 5]) == [1, 2, cast(NamedTuple, namedtuple('NamedTuple', 'a b')(a=3, b=4)), 5]

# Generated at 2022-06-23 18:12:35.688881
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils as namedtupleutils
    obj1 = {'a': 1, 'b': {'a': 1, 'b': 2}, 'c': [1, 2, 3]}
    obj1_out = namedtupleutils.to_namedtuple(obj1)
    assert type(obj1_out).__name__ == 'NamedTuple'
    assert obj1_out.a == 1
    assert obj1_out.b.a == 1
    assert obj1_out.b.b == 2
    assert obj1_out.c[0] == 1
    assert obj1_out.c[1] == 2
    assert obj1_out.c[2] == 3


# Generated at 2022-06-23 18:12:48.009035
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest  # type: ignore[import]
    from collections import namedtuple
    from collections.abc import Mapping
    from flutils.validators import validate_identifier
    from types import SimpleNamespace


# Generated at 2022-06-23 18:12:54.807894
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {
        'a': 'Hello',
        'b': SimpleNamespace(
            c='World'
        ),
        'c': {
            'd': '!',
            'e': [1, 2, 3]
        }
    }
    nt = to_namedtuple(obj)
    assert nt.a == 'Hello'
    assert nt.b.c == 'World'
    assert nt.c.d == '!'
    assert nt.c.e == [1, 2, 3]



# Generated at 2022-06-23 18:12:58.475724
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest

    doctest.testmod(verbose=True)

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:13:08.499116
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == tuple()
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    dic = {1: 'one', 'a': {'2': 3}}
    out = namedtuple('NamedTuple', ['a'])(
        a=namedtuple('NamedTuple', ['2'])(3),
    )
    assert to_namedtuple(dic) == out
    dic = {1: 'one', 'a': [1, 2, 3]}

# Generated at 2022-06-23 18:13:17.157453
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b c d')(
        a=1, b=2, c=3, d=4
    )
    dic = {'a': {'b': 2, 'c': 3}}

# Generated at 2022-06-23 18:13:27.799810
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test :func:`~flutils.namedtupleutils.to_namedtuple`.

    Returns:
        None

    """
    from flutils.namedtupleutils import to_namedtuple
    from flutils.datautils import to_ordereddict


# Generated at 2022-06-23 18:13:39.438292
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Test for function to_namedtuple. """
    from unittest.mock import patch
    from flutils.namedtupleutils import to_namedtuple
    from .namedtupleutils_test_data import data as namedtuple_test_data

    for test in namedtuple_test_data:
        idx = namedtuple_test_data.index(test) + 1
        msg = "test_to_namedtuple: test %d" % idx
        with patch('flutils.namedtupleutils._to_namedtuple') as _to_namedtuple:
            with patch.dict(locals(), {'_to_namedtuple': _to_namedtuple}):
                with patch.dict(globals(), {'_to_namedtuple': _to_namedtuple}):
                    to_

# Generated at 2022-06-23 18:13:51.373598
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Dict
    from flutils.functionalutils import compose
    from flutils.namedtupleutils import to_namedtuple
    from flutils.represent import as_namedtuple
    from flutils.represent import as_tuple
    from flutils.validators import validate_identifier
    import pytest

    dic = {'a': 1, 'b': 2}
    # noinspection PyUnresolvedReferences
    assert to_namedtuple(dic) == as_namedtuple(dic)

    dic = {'a': 1, 'b': 2, 'c': 3}
    # noinspection PyUnresolvedReferences
    assert to_namedtuple(dic) == as_namedtuple(dic)


# Generated at 2022-06-23 18:14:04.386014
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Make sure the module can be called from the command line
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import __doc__ as dut
    assert dut
    assert to_namedtuple

    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple([{'a': 1, 'b': {'c': 3, 'd': 4}}]) == [NamedTuple(a=1, b=NamedTuple(c=3, d=4))]
    assert to_namedtuple([1, 2, 3])

# Generated at 2022-06-23 18:14:14.504273
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testing import target_test_values
    from flutils.namedtupleutils import _to_namedtuple
    assert to_namedtuple(target_test_values['single_dict']) == \
        _to_namedtuple(target_test_values['single_dict'])
    assert to_namedtuple(target_test_values['dict_with_dot_str']) == \
        _to_namedtuple(target_test_values['dict_with_dot_str'])
    assert to_namedtuple(target_test_values['dict_with_dot_attr']) == \
        _to_namedtuple(target_test_values['dict_with_dot_attr'])

# Generated at 2022-06-23 18:14:27.141085
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import Mock

    class MockObj:
        @staticmethod
        def __getitem__(key: Any) -> Any:
            return key

        @staticmethod
        def __getattr__(attr: Any) -> Any:
            return attr

    mockobj = MockObj()
    # Make sure a non-allowed type (Unicode) fails
    unicode_str = 'this is a unicode string'
    assert isinstance(unicode_str, str)
    assert not isinstance(unicode_str, str)
    with pytest.raises(TypeError) as excinfo:
        to_namedtuple(unicode_str)

# Generated at 2022-06-23 18:14:33.884288
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import date, datetime
    from numbers import Number

    dic = {
        'a': 1,
        'b': 2,
        'c': 'three',
        'd': {'e': 4},
        'date': date.today(),
        'datetime': datetime.now(),
    }
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert isinstance(nt.a, int)
    assert isinstance(nt.b, int)
    assert isinstance(nt.c, str)
    assert isinstance(nt.d, NamedTuple)
    assert isinstance(nt.date, date)
    assert isinstance(nt.datetime, datetime)

    nt = to_namedtuple((1, 2, 3))

# Generated at 2022-06-23 18:14:39.247057
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # from flutils.namedtupleutils import to_namedtuple
    # dic = {'a': 1, 'b': 2}
    # assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    pass

if __name__ == '__main__':
    # test_to_namedtuple()
    pass

# Generated at 2022-06-23 18:14:42.176896
# Unit test for function to_namedtuple
def test_to_namedtuple():
  assert to_namedtuple([['a', 1], ['b', 2]]) == [NamedTuple(a=1, b=2)]

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:14:53.475957
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.validators import validate_identifier

    assert not hasattr(to_namedtuple, 'register')
    assert to_namedtuple.dispatch(dict) is not None
    assert to_namedtuple.dispatch(OrderedDict) is not None
    assert to_namedtuple.dispatch(list) is not None
    assert to_namedtuple.dispatch(tuple) is not None
    assert to_namedtuple.dispatch(SimpleNamespace) is not None
    assert to_namedtuple.dispatch(str) is None
    class TestClass(object):
        pass
    assert to_namedtuple.dispatch(TestClass) is None
    assert to_namedtuple.dispatch(1) is None


# Generated at 2022-06-23 18:15:02.764698
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):

        def test_list(self):
            dic = {'a': 1, 'b': 2}
            obj = to_namedtuple(dic)
            self.assertIsNot(obj, dic)
            self.assertIsInstance(obj, NamedTuple)
            self.assertEqual(obj.a, 1)
            self.assertEqual(obj.b, 2)
            self.assertEqual(obj, (1, 2))

        def test_dict(self):
            tup = 1, 2
            obj = to_namedtuple(tup)
            self.assertIsNot(obj, tup)
            self.assertIsInstance(obj, NamedTuple)

# Generated at 2022-06-23 18:15:15.161238
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils as NT

    # noinspection SpellCheckingInspection
    dic = {'a': 1, 'b': 2}
    expect = NT.NamedTuple(a=1, b=2)
    assert NT.to_namedtuple(dic) == expect
    dic = {'a': 1, 'b': 2}
    expect = NT.NamedTuple(a=1, b=2)
    assert NT.to_namedtuple(dic) == expect
    dic = {'a': 1, 'b': 2}
    expect = NT.NamedTuple(a=1, b=2)
    assert NT.to_namedtuple(dic) == expect
    dic = {'a': 1, 'b': 2}
    expect = NT.Named

# Generated at 2022-06-23 18:15:16.874510
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:15:26.763613
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    dic2 = {'c': 3, 'd': {'e': 4, 'f': 5}}
    dic3 = {'g': 6, 'h': (4, 5)}
    dic4 = {'i': 7, 'j': [4, 5]}
    dic5 = {'k': 8, 'l': [{'m': 9, 'n': 10}, 'string', (11, 5)]}
    list_dics = [dic, dic2, dic3, dic4, dic5]
    list_dics2 = [dic, dic2, dic3, dic4, dic5, 'string']

# Generated at 2022-06-23 18:15:37.535070
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.textutils import expandtabs
    from flutils.timingutils import StopWatch
    from flutils.pyutils import get_srcdir

    srcdir = get_srcdir()
    from os.path import (
        abspath,
        join,
    )
    source = abspath(join(srcdir, __file__))
    with StopWatch("to_namedtuple()"):
        print("{:_^79}".format("Original Source"))
        print(expandtabs(source, tabsize=8))
        tmplist = []
        with open(source, 'r') as f:
            for line in f:
                line = line.rstrip()
                tmplist.append(line)
    tmptuple = tuple(tmplist)

# Generated at 2022-06-23 18:15:41.067835
# Unit test for function to_namedtuple
def test_to_namedtuple():

    print(
        to_namedtuple(
            {'a': {'b': {'c': 1, 'd': 2}}, 'e': [3, 4]}
        )
    )

# Generated at 2022-06-23 18:15:50.293058
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple."""
    import collections
    import json
    from flutils.namedtupleutils import (
        convert_namedtuple,
        to_namedtuple,
    )
    import os.path as path
    from flutils.toolbox import decode, try_decode
    from flutils.testutils import (
        get_test_data_path,
        get_test_file,
    )

    pth = get_test_data_path('namedtupleutils')
    with open(get_test_file(pth, 'people.json'), 'rb') as fin:
        data = try_decode(fin.read())

    people = json.loads(data)
    people_nt = to_namedtuple(people)

    assert len(people) == len(people_nt)
   

# Generated at 2022-06-23 18:15:59.189930
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.typingutils import NamedTupleIterable
    from collections import (
        OrderedDict,
        namedtuple,
    )

    # noinspection PyShadowingNames
    class TestNamedTuple(namedtuple('TestNamedTuple', 'a b c d')):
        """ Test namedtuple class. """

    # noinspection PyShadowingNames
    class TestSimpleNamespace(SimpleNamespace):
        """ Test SimpleNamespace class. """


# Generated at 2022-06-23 18:16:01.653741
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import re
    import doctest

    doctest.testmod(re.compile(r'to_namedtuple'), extraglobs={})

# Generated at 2022-06-23 18:16:09.543428
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pytest import raises
    from flutils.namedtupleutils import test_obj as obj
    with raises(TypeError):
        # noinspection PyTypeChecker
        to_namedtuple(obj)

    obj_list = [obj, obj]
    assert to_namedtuple(obj_list) == obj_list

    obj_tuple = tuple(obj_list)
    assert to_namedtuple(obj_tuple) == obj_tuple

    obj_dict = {'a': 1, 'b': '2', '3': 3, '4': obj}
    obj_nt = to_namedtuple(obj_dict)
    assert obj_nt.a == 1
    assert obj_nt.b == '2'
    assert obj_nt.__dict__['3'] == 3
    assert obj_nt.__

# Generated at 2022-06-23 18:16:18.046257
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    import datetime as dt
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertEqual(list(out._fields), ['a', 'b'])
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)
            self.assertEqual(out, (1, 2))

        def test_to_namedtuple_odict(self):
            odic = OrderedDict()
            odic