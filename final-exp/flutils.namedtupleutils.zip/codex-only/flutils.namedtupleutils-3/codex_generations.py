

# Generated at 2022-06-23 18:06:15.920921
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == (1, 2)


if __name__ == '__main__':
    from inspect import signature

    print(to_namedtuple.__annotations__['obj'])
    print(to_namedtuple.__annotations__['_started'])
    print(signature(to_namedtuple))

    test_to_namedtuple()

# Generated at 2022-06-23 18:06:26.909756
# Unit test for function to_namedtuple
def test_to_namedtuple():
   """
    Test function to_namedtuple.
    """

# Generated at 2022-06-23 18:06:30.241413
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = to_namedtuple({'a': 1, 'b': 2})
    print(a)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:06:41.129419
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from types import SimpleNamespace
    from unittest import TestCase
    from unittest.mock import patch

    patch('NamedTuple.__new__').start()
    _NamedTuple = patch('collections.NamedTuple').start()
    patch('NamedTuple.__init__').start()
    patch('NamedTuple.__dict__').start()
    patch('NamedTuple._make').start()
    patch('NamedTuple._asdict').start()
    patch('NamedTuple._replace').start()
    patch('NamedTuple._fields').start()
    patch('NamedTuple.__getnewargs__').start()

    class A(TestCase):
        def test_list(self):
            self.mock = {'a': 1, 'c': 3}
           

# Generated at 2022-06-23 18:06:43.600021
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()



# Generated at 2022-06-23 18:06:54.474365
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    """Unit test for function to_namedtuple."""
    # noinspection PyUnresolvedReferences
    import pytest
    import datetime
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-23 18:07:01.308676
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    import pytest
    from flutils.jsonutils import ensure_json_serializable


# Generated at 2022-06-23 18:07:06.873482
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': {'c': 2}
    }
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b.c == 2

# Generated at 2022-06-23 18:07:16.611911
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import (
        validate_identifier,
        validate_identifiers,
    )
    from types import SimpleNamespace
    from collections import OrderedDict
    # NamedTuple
    data = {'a': 1, 'b': 2}
    nt01 = to_namedtuple(data)
    nt02 = namedtuple('NamedTuple', sorted(data.keys()))(**data)
    assert nt01 == nt02
    dic01 = OrderedDict(a=1, b=2, c=3)
    nt01 = to_namedtuple(dic01)
    nt02 = namedtuple('NamedTuple', sorted(dic01.keys()))(**dic01)

# Generated at 2022-06-23 18:07:28.301391
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b':2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b':2, 'c':{'d':3, 'e':4}}) == NamedTuple(a=1, b=2, c=NamedTuple(d=3, e=4))
    assert to_namedtuple([1, {'a': 1, 'b':2}, 3, 4]) == [1, NamedTuple(a=1, b=2), 3, 4]
    assert to_namedtuple([{'a': 1, 'b':2}, 3, 4]) == [NamedTuple(a=1, b=2), 3, 4]

# Generated at 2022-06-23 18:07:35.770624
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    import unittest
    import collections
    import typing

    class CustomType(object):
        def __init__(self, val):
            self.val = val

        def __repr__(self):
            return repr(self.val)

    class Test(unittest.TestCase):
        def test_toflutils_namedtuple(self):
            a = {'b': 1, 'c': 2, 1: 3, 'a': 'b'}
            b = to_namedtuple(a)
            self.assertEqual(
                json.dumps(a, sort_keys=True),
                json.dumps(b, sort_keys=True)
            )
            self.assertIsInstance(b, collections.namedtuple('NamedTuple', 'a b c 1'))
            self

# Generated at 2022-06-23 18:07:47.834773
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    import inspect

    import pytest

    class Test(TestCase):

        def test_to_namedtuple(self):
            obj1 = {'a': 1, 'b': 2, 'c': 3}
            obj2 = [1, 2, 3]
            obj3 = (1, 2, 3)
            obj4 = [{'a': 1}, {'b': 2}, {'c': 3}]
            obj5 = ({'a': 1}, {'b': 2}, {'c': 3})
            obj6 = {'a': {'b': {'c': 1}}}

# Generated at 2022-06-23 18:07:58.845397
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''
    Unit test to cover all possible executions
    of to_namedtuple()

    Returns:
        None
    '''
    #pylint: disable=bad-whitespace,too-many-locals,too-many-branches,
    #              no-member,unused-import,too-many-arguments
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import NamedTuple
    from flutils.stringutils import str2bool
    from pprint import pprint

    from unittest import TestCase
    from unittest.mock import patch, mock_open

    #pylint: disable=invalid-name,protected-access

# Generated at 2022-06-23 18:08:01.432543
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert True is hasattr(obj, 'a')
    assert True is hasattr(obj, 'b')
    assert obj.a == 1
    assert obj.b == 2

# Generated at 2022-06-23 18:08:11.476919
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2,
        'nested': {
            'a': 1,
            'b': 2,
            'nested': {
                'a': 1,
                'b': 2,
            }
        }
    }
    # noinspection PyTypeChecker
    expected = NamedTuple(
        a=1,
        b=2,
        nested=NamedTuple(
            a=1,
            b=2,
            nested=NamedTuple(
                a=1,
                b=2
            )
        )
    )
    out = to_namedtuple(dic)
    assert expected == out


if __name__ == '__main__':
    test_to_namedtuple()

# flutils: namedt

# Generated at 2022-06-23 18:08:24.392101
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:08:26.382210
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:08:31.927910
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Unit test for function to_namedtuple')

    import unittest

    class TestToNamedTuple(unittest.TestCase):
        def test_to_namedtuple_dict(self):
            dic = {'a': 1, 'b': 2}
            self.assertEqual(to_namedtuple(dic), namedtuple('NamedTuple', 'a b')(1, 2))
            self.assertEqual(to_namedtuple(dic), namedtuple('NamedTuple', 'b a')(1, 2))
            odic = OrderedDict(dic)
            self.assertEqual(to_namedtuple(odic), namedtuple('NamedTuple', 'a b')(1, 2))
            dic[1] = 1
            self.assertE

# Generated at 2022-06-23 18:08:44.371561
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    namedt = to_namedtuple(dic)

    assert namedt.a == 1
    assert namedt.b == 2
    assert namedt.c.d == 3
    assert namedt.c.e == 4

    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    namedt = to_namedtuple(dic)

    assert namedt.a == 1
    assert namedt.b == 2
    assert namedt.c.d == 3
    assert namedt.c.e == 4

    obj = SimpleNamespace()
    obj.a = 1
    obj.b = 2
    obj.c = SimpleNamespace()

# Generated at 2022-06-23 18:08:54.854319
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # test empty OrderedDict
    t1 = to_namedtuple(OrderedDict())
    assert t1 == NamedTuple()
    assert isinstance(t1, NamedTuple)

    # test empty List
    t2 = to_namedtuple([])
    assert t2 == []
    assert type(t2) is list

    # test empty Tuple
    t3 = to_namedtuple(tuple())
    assert t3 == tuple()
    assert type(t3) is tuple

    # test empty Dict
    t4 = to_namedtuple({})
    assert t4 == NamedTuple()
    assert isinstance(t4, NamedTuple)

    # test empty SimpleNamespace
    t5 = to_namedtuple(SimpleNamespace())
    assert t5 == NamedTuple()

# Generated at 2022-06-23 18:08:59.701081
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple([[]]) == ([],)
    assert to_namedtuple([1]) == (1,)
    assert to_namedtuple((1,)) == (1,)
    assert to_namedtuple([{}]) == (NamedTuple(),)

    assert to_namedtuple([{'b': 1}, {'a': 1, 'b': 2}]) == (
        NamedTuple(b=1),
        NamedTuple(a=1, b=2)
    )
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)

# Generated at 2022-06-23 18:09:09.964871
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # This unit test will be invoked by pytest.
    from flutils.namedtupleutils import to_namedtuple

    # Customizing this function to test the function
    def customizing_to_namedtuple(x):
        from collections import namedtuple
        
        # obj can be an object, list, dict, tuple, or namedtuple.
        # if the given type is a list or a tuple, each item will be
        # recursively converted to a namedtuple provided the items
        # can be converted. Items that cannot be converted will still
        # exist in the returned object.
        # if the given type is a list the return value will be a new
        # list. this means the items are not changed in the given obj.
        # if the given type is a dict, keys that can be proper
        # identifiers will become attributes on the returned

# Generated at 2022-06-23 18:09:18.938763
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple()."""

    # noinspection PyUnresolvedReferences
    from unittest.mock import patch

    from flutils.namedtupleutils import to_namedtuple

    _verror = (
        "Can convert only "
        "'list', 'tuple', 'dict' to a NamedTuple; "
    )
    _verror += (
        "got: (%r) %s" % (type('test').__name__, 'test')
    )

    with patch('types.SimpleNamespace') as _ns:
        _ns.return_value.__dict__.get.return_value = 'value'
        _ns.return_value.__dict__ = 'dic'
        with patch('flutils.namedtupleutils._to_namedtuple') as _nt:
            _

# Generated at 2022-06-23 18:09:25.961438
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test function to_namedtuple
    """
    from collections import OrderedDict

    d = {'first': [1, 2], 'second': [3, 4]}
    for dt in [d, OrderedDict(d.items()), SimpleNamespace(**d)]:
        dt_tuple = to_namedtuple(dt)
        assert hasattr(dt_tuple, 'first')
        assert hasattr(dt_tuple, 'second')
        assert dt_tuple.first == (1, 2)
        assert dt_tuple.second == (3, 4)

        d = {'first': [1, 2], 'second': {'n':3}}
        for dt in [d, OrderedDict(d.items()), SimpleNamespace(**d)]:
            dt

# Generated at 2022-06-23 18:09:31.880133
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pathlib import Path
    from typing import (
        Dict,
        List,
        Tuple,
        Type,
    )

    from panflute import (
        Error,
        horizontalrule,
        lineblock,
        lineblockitem,
        list,
        listitem,
        orderedlist,
        para,
        rawblock,
        string,
        table,
        tablecell,
        tablerow,
    )
    from panflute.docutils.utils import (
        block,
        docutils_escape_latex,
        inline,
        string_to_docutils,
    )

    from flutils.docutils import (
        convert_docutils_container,
        docutils_to_panflute,
        get_docutils_container,
    )

# Generated at 2022-06-23 18:09:40.648839
# Unit test for function to_namedtuple
def test_to_namedtuple():
    v = {'a': 1, 'b': {'c': 3, 'd': 4}}
    # v = {'a': 1, 'b': [{'c': 3, 'd': 4}, {'e': 5, 'f': 6}]}
    # v = 'hello world'
    # v = {1:2, 3:4}
    # v = {'a': 1, 'b': 'hello world'}
    v = [{'a': 1, 'b': 2, 'c': 3}, {'d': 4, 'e': 5, 'f': 6}]
    # v = [1, 2, 3, 4]
    v = ['a', 'b', 'c', 'd']
    # v = {'a': (1, 2, 3), 'b': 'cde'}
    # v

# Generated at 2022-06-23 18:09:48.766259
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # test Mapping
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'a': 1, '_b': 2}) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple({'a': 1, '_b': 2, 'c': 3}) == namedtuple('NamedTuple', 'a c')(1, 3)
    assert to_namedtuple('1') == '1'

    # test Sequence
    assert to_namedtuple(tuple()) == tuple()

# Generated at 2022-06-23 18:09:52.579786
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    named = to_namedtuple(dic)
    assert isinstance(named, NamedTuple)
    assert isinstance(named.a, int)
    assert isinstance(named.b, int)

# Generated at 2022-06-23 18:10:02.893908
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple as _to_namedtuple
    from collections import namedtuple
    from copy import copy, deepcopy

    # Recurse into the point of a basic test
    def _recurse(
            *objs: Any,
            start: bool = False
    ) -> Any:
        if start is False:
            return
        obj = objs[0]
        if hasattr(obj, '__iter__') or hasattr(obj, 'items'):
            return to_namedtuple(obj)
        return obj

    # Test to ensure the depth of the recursion
    def _test_recursion_depth(*objs: Any, start: bool = False) -> Any:
        if start is False:
            return
        obj = objs[0]

# Generated at 2022-06-23 18:10:12.924580
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils import namedtupleutils
    from flutils.testingutils import unit_test
    from flutils.testingutils import unittest

    # noinspection PyUnusedLocal
    class Test(unittest.TestCase):
        # noinspection PyUnusedLocal
        def test_to_namedtuple_str(self):
            self.assertRaises(
                TypeError,
                namedtupleutils.to_namedtuple,
                'A string'
            )

        # noinspection PyUnusedLocal
        def test_to_namedtuple_int(self):
            self.assertRaises(
                TypeError,
                namedtupleutils.to_namedtuple,
                10
            )

        # noinspection PyUnusedLocal

# Generated at 2022-06-23 18:10:23.927985
# Unit test for function to_namedtuple
def test_to_namedtuple():
    n1 = SimpleNamespace(
        a=True,
        b=False,
        c=(
            SimpleNamespace(
                x=1,
                y=2,
                z=3,
            ),
            SimpleNamespace(
                x=1,
                y=2,
                z=3,
            ),
        ),
    )

# Generated at 2022-06-23 18:10:30.716784
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import typing as _typing
    import flutils.namedtupleutils as _namedtupleutils

    def _to_namedtuple(obj, _started: bool = False):
        return _namedtupleutils._to_namedtuple(obj, _started)

    lst = [1, 2, 3]
    assert isinstance(_to_namedtuple(lst), _typing.List)
    assert isinstance(_to_namedtuple(lst)[1], int)

    lst = (1, 2, 3)
    assert isinstance(_to_namedtuple(lst), _typing.Tuple)
    assert isinstance(_to_namedtuple(lst)[1], int)

    class NamedTuple(_typing.NamedTuple):
        a: int
        b: int


# Generated at 2022-06-23 18:10:40.580158
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    try:
        from flutils.namedtupleutils import _to_namedtuple
    except ImportError:
        pass
    try:
        from flutils.namedtupleutils import _started
    except ImportError:
        pass
    def test_to_namedtuple_1():
        dic = {'a': 1, 'b': 2}
        out = to_namedtuple(dic)
        assert out.a == 1
        assert out.b == 2
        assert out[0] == 1
        assert out[1] == 2
    def test_to_namedtuple_2():
        dic = {'a': 1, 'b': 2}
        out = to_namedtuple(dic)
       

# Generated at 2022-06-23 18:10:50.448892
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    obj = {
        'a': {
            'b': {
                'c': 3
            }
        },
        'b': 2,
    }

    with pytest.raises(TypeError):
        _ = to_namedtuple('abc')

    out = to_namedtuple(obj)
    assert out == namedtuple('NamedTuple', 'a b')(a=namedtuple('NamedTuple', 'b')(b=namedtuple('NamedTuple', 'c')(c=3)), b=2)


if __name__ == '__main__':
    print(to_namedtuple.__doc__)

# Generated at 2022-06-23 18:10:58.613184
# Unit test for function to_namedtuple
def test_to_namedtuple():
    out = to_namedtuple([1, 2, 3])
    assert isinstance(out, list)
    out = to_namedtuple(tuple([1, 2, 3]))
    assert isinstance(out, tuple)

    class MakeNamedTuple(NamedTuple):
        a: int = 0
        b: int = 1
        c: int = 2

    out = to_namedtuple(MakeNamedTuple())
    assert isinstance(out, MakeNamedTuple)
    assert out.a == 0
    assert out.b == 1
    assert out.c == 2

    out = to_namedtuple(MakeNamedTuple(1, 2, 3))
    assert isinstance(out, MakeNamedTuple)
    assert out.a == 1
    assert out.b == 2

# Generated at 2022-06-23 18:11:08.662630
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from types import SimpleNamespace
    dic = dict(a=1, b=2)
    nt = namedtuple('nt', 'a b')(a=1, b=2)
    assert to_namedtuple(dic) == nt
    lst = [1, 2, 3]
    lst_out = [1, 2, 3]
    assert to_namedtuple(lst) == lst_out
    mydic = dict(a=1, b=dict(c=3, d=4))
    mynt = namedtuple('mynt', 'a b')(a=1, b=namedtuple('nt', 'c d')(c=3, d=4))
    assert to_namedtuple(mydic) == mynt
    mytup

# Generated at 2022-06-23 18:11:13.617601
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert hasattr(to_namedtuple(1), '__annotations__'), "Function should be annotated; got: %s" % to_namedtuple(1).__annotations__
    assert hasattr(to_namedtuple(1), '__call__'), "Function should be callable; got: %s" % to_namedtuple(1).__call__
    assert hasattr(to_namedtuple(1), '__doc__'), "Function doesn't have a docstring; got: %s" % to_namedtuple(1).__doc__
    assert hasattr(to_namedtuple(1), '__init__'), "Function should be instantiable; got: %s" % to_namedtuple(1).__init__

# Generated at 2022-06-23 18:11:23.842749
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) == \
        NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(SimpleNamespace(a=1, b=2, c=3)) == \
        NamedTuple(a=1, b=2, c=3)



# Generated at 2022-06-23 18:11:33.029164
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""

    # import packages
    import os
    import shutil
    import sys
    import tempfile
    import unittest

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # import file
    try:
        import flutils.namedtupleutils
    except ImportError:
        import tests.flutils.namedtupleutils as flutils_namedtupleutils
        # noinspection PyUnresolvedReferences
        sys.modules['flutils.namedtupleutils'] = flutils_namedtupleutils
        import flutils.namedtupleutils

    # noinspection SpellCheckingInspection
    class TestToNamedTuple(unittest.TestCase):
        """Test cases for function to_namedtuple."""

# Generated at 2022-06-23 18:11:43.918738
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """pytest for to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple

    with pytest.raises(TypeError):
        to_namedtuple(1)

    with pytest.raises(TypeError):
        to_namedtuple('a')

    with pytest.raises(TypeError):
        to_namedtuple('')

    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)


# Generated at 2022-06-23 18:11:52.516936
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    out = to_namedtuple([dic])
    assert out[0].a == 1
    assert out[0].b == 2
    out = to_namedtuple([[dic]])
    assert out[0][0].a == 1
    assert out[0][0].b == 2
    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    out = to_namedtuple(dic.items())
    assert out[0].a == 1
    assert out[0].b

# Generated at 2022-06-23 18:11:57.129573
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing function to_namedtuple')
    a = {'a': 1, 'b': 2}
    nt = to_namedtuple(a)
    assert nt == SimpleNamespace(a=1, b=2)
    print(type(nt))


if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-23 18:12:08.811429
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    def _simple_test(obj, expected):
        msg = 'Expected %s but got %s' % (expected, obj)
        assert obj == expected, msg

    _simple_test(to_namedtuple({'k': 'v'}),
                 namedtuple('NamedTuple', 'k')(k='v'))
    _simple_test(to_namedtuple({'k': 'v', 'k2': 'v2'}),
                 namedtuple('NamedTuple', 'k k2')(k='v', k2='v2'))

# Generated at 2022-06-23 18:12:19.412041
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    import collections
    from flutils.validators import is_val_an_identifier

    class _TestCase(TestCase):
        def test_dict(self):
            dic = {'a': 1, 'b': 2}
            ret = to_namedtuple(dic)
            self.assertEqual(ret, collections.namedtuple('NamedTuple', 'a b')(a=1, b=2))

            dic = {'a': 1, '_b': 2}
            ret = to_namedtuple(dic)
            self.assertEqual(ret, collections.namedtuple('NamedTuple', 'a')(a=1))

            dic = {'a': 1, 'b': 2, 'c': 3}
            ret = to_namedt

# Generated at 2022-06-23 18:12:29.055397
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2}
    assert (
            to_namedtuple(dic) ==
            namedtuple('NamedTuple', 'a b')(a=1, b=2)
    )

    dic = {'a': {'x': 1, 'y': 2}, 'b': 2}

# Generated at 2022-06-23 18:12:38.430087
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from copy import copy

    from pytest import raises

    from flutils.namedtupleutils import _to_namedtuple


# Generated at 2022-06-23 18:12:50.531772
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from types import SimpleNamespace
    from collections import namedtuple, OrderedDict
    from unittest import TestCase

    class Test(TestCase):
        def test_simple(self):
            dic = OrderedDict([
                ('a', 1),
                ('b', 2),
            ])
            expected = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
            actual = to_namedtuple(dic)
            self.assertEqual(expected, actual)

        def test_nested(self):
            obj = SimpleNamespace(
                a=1,
                b=SimpleNamespace(
                    c=3,
                ),
                d=dict(
                    e=5,
                ),
            )

# Generated at 2022-06-23 18:13:03.174419
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = OrderedDict([('c', 3), ('z', 26)])
    assert to_namedtuple(dic) == NamedTuple(c=3, z=26)

    dic = {'a': 1, 'b': 2}
    obj = SimpleNamespace(**dic)
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)

    # obj = {'a': 1, 'b': 2}
    # obj = [1, 2, 3, 4, obj]
    # assert to_namedtuple(obj) == [1, 2, 3, 4, NamedTuple(a=1

# Generated at 2022-06-23 18:13:13.531117
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import List

    # Arrange
    d = {'a': 1, 'b': 2}

    # Act
    result = to_namedtuple(d)

    # Assert
    assert result.a == 1
    assert result.b == 2

    # Act
    d = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]  # type: List[dict]
    result = to_namedtuple(d)

    # Assert
    assert len(result) == 2
    assert isinstance(result[0], namedtuple)
    assert isinstance(result[1], namedtuple)
    assert result[0].a == 1
    assert result[0].b == 2
    assert result[1].a == 3
    assert result[1].b == 4

    #

# Generated at 2022-06-23 18:13:22.869274
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['one', 2, {'key': 'value'}]) == \
        ['one', 2, NamedTuple(key='value')]

    od = OrderedDict()
    od['a'] = 1
    od['b'] = ['one', 2, {'key': 'value'}]
    od['c'] = 'three'
    assert to_namedtuple(od) == \
        NamedTuple(a=1, b=[NamedTuple(key='value'), 2, 'one'], c='three')

    from collections import namedtuple
    class Item(namedtuple('Item', 'a,b,c')):
        def __pow__(self, other):
            return self.a * other.b * 3

    dic = {'a': 1, 'b': 2}

# Generated at 2022-06-23 18:13:31.644858
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple(SimpleNamespace(a=1)), tuple)
    assert to_namedtuple(SimpleNamespace(a=1)) == namedtuple('', '')()
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == namedtuple('', 'a b')(1, 2)
    assert to_namedtuple(OrderedDict((('b', 2), ('a', 1)))) == namedtuple('', 'b a')(2, 1)
    assert to_namedtuple(dict(a=1, b=2)) == namedtuple('', 'a b')(1, 2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert isinstance(to_namedtuple((1, 2)), tuple)
    assert to_named

# Generated at 2022-06-23 18:13:39.186521
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    from collections import OrderedDict
    from pprint import pprint
    from collections import OrderedDict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt == nt
    assert hasattr(nt, 'a') is True
    assert nt.a == 1
    assert hasattr(nt, 'b') is True
    assert nt.b == 2
    assert hasattr(nt, 'c') is False

    dic = {'b': 2, 'a': 1}
    nt = to_namedtuple(dic)
    assert nt == nt
    assert hasattr(nt, 'a') is True
    assert nt.a == 1
    assert hasattr(nt, 'b')

# Generated at 2022-06-23 18:13:51.056294
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from flutils.collections import sortdict
    from typing import NamedTuple
    from flutils.validators import is_namedtuple
    # Can convert simple dict to NamedTuple
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert is_namedtuple(nt)
    assert getattr(nt, 'a') == 1
    assert getattr(nt, 'b') == 2
    # Can convert OrderedDict to NamedTuple
    dic = OrderedDict()
    dic['b'] = 2
    dic['a'] = 1

# Generated at 2022-06-23 18:13:57.598759
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'c': 1, 'b': 2, 'a': 3}
    out = to_namedtuple(dic)
    assert getattr(out, 'a') == 3
    assert getattr(out, 'b') == 2
    assert getattr(out, 'c') == 1
    assert hasattr(out, 'a')



# Generated at 2022-06-23 18:14:08.920898
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    class TestNamedTuple(NamedTuple):
        a: int
        b: int
    dic = OrderedDict(a=1, d=3, b=2, c=4)
    lst = [1, 2, 3, 4, 5]
    tup = (1, 2, 3, 4, 5)
    test_list = [dic, lst, tup]
    test_tuple = (dic, lst, tup)
    test_dict = {'dic1': dic, 'lst1': lst, 'tup1': tup}
    test_namedtuple = TestNamedTuple(a=1, b=2)
    test_obj = SimpleNamespace(**test_dict)


# Generated at 2022-06-23 18:14:17.450387
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c_': 3}) == NamedTuple(a=1, b=2, c_=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'C': 3}) == NamedTuple(a=1, b=2, C=3)
    assert to_namedtuple(('a', 1)) == NamedTuple(a=1)

# Generated at 2022-06-23 18:14:29.304395
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == (1, 2)
    assert to_namedtuple(OrderedDict({'a': 1, 'b': 2})) == (1, 2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == (1, 2)
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple([1, [1, 2], 'a']) == [1, [1, 2], 'a']

# Generated at 2022-06-23 18:14:40.680071
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import Dict, NamedTuple, Tuple
    from unittest import TestCase

    from flutils.validators import _check_type

    class SimpleTuple(NamedTuple):
        a: int
        b: str
        c: Tuple[NamedTuple, ...]

    class SimpleNT(NamedTuple):
        d: int
        e: str

    class TestToNT(TestCase):

        def test_basic(self):
            dic = {'a': 1, 'b': 'two', 'c': [{'d': 4}]}
            exp = SimpleTuple(a=1, b='two', c=(SimpleNT(d=4),))

# Generated at 2022-06-23 18:14:53.050919
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections.abc import Mapping, Sequence
    from collections import namedtuple, OrderedDict
    from flutils.tests.pytest_utils import random_integers, random_strings
    from types import SimpleNamespace

    def _test_to_namedtuple(obj, obj_type):

        if isinstance(obj, (list, tuple)):
            nt_obj = to_namedtuple(obj)
            assert isinstance(nt_obj, (list, tuple))
            assert isinstance(nt_obj, obj_type)
            for item in nt_obj:
                _test_to_namedtuple(item, obj_type)
            return

        elif isinstance(obj, Mapping):
            nt_obj = to_namedtuple(obj)

# Generated at 2022-06-23 18:15:00.167169
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    d = OrderedDict([('a', 1), ('b', 2), ('c', 3), ('d', 4), ('e', 5)])
    assert to_namedtuple(d) == NamedTuple(a=1, b=2, c=3, d=4, e=5)
    assert to_namedtuple([d, d]) == [NamedTuple(a=1, b=2, c=3, d=4, e=5),
                                     NamedTuple(a=1, b=2, c=3, d=4, e=5)]

# Generated at 2022-06-23 18:15:04.493720
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': 5, 'f': 6}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == NamedTuple(c=3, d=4)
    assert out.e == 5
    assert out.f == 6


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:15:16.697592
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from collections import OrderedDict

    a = 1
    obj = {
        'a': a,
        'b': {
            'test': 'a',
            'test_': 2,
            2: 'test',
        },
        'c': None,
        'd': 'test'
    }
    result = to_namedtuple(obj)
    assert result.a == a
    assert result.b.test == 'a'
    assert result.b.test_ == 2
    assert result.b.__dict__[2] == 'test'
    assert result.b.__dict__[2] == 'test'
    assert result.c is None
    assert result.d == 'test'

# Generated at 2022-06-23 18:15:21.449568
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the to_namedtuple function."""

    a = {'a': 1, 'b': 2}
    assert to_namedtuple(a) == NamedTuple(a=1, b=2)

    b = [{'a': 1, 'b': 2}, [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]]
    assert to_namedtuple(b) == [NamedTuple(a=1, b=2), (NamedTuple(a=1, b=2), NamedTuple(c=3, d=4))]


if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-23 18:15:22.485315
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-23 18:15:30.528628
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections.abc import Mapping
    from collections import OrderedDict
    NamedTuple = to_namedtuple(OrderedDict())
    assert isinstance(NamedTuple, type)
    assert NamedTuple.__name__ == 'NamedTuple'
    assert hasattr(NamedTuple, '_fields')
    assert NamedTuple._fields == ()

    dic = {}
    NamedTuple = to_namedtuple(dic)
    assert isinstance(NamedTuple, type)
    assert NamedTuple.__name__ == 'NamedTuple'
    assert hasattr(NamedTuple, '_fields')
    assert NamedTuple._fields == ()

    dic = {'a': 1}
    NamedTuple = to_namedtuple(dic)

# Generated at 2022-06-23 18:15:39.069848
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    from collections import OrderedDict
    def _assert_eq_and_type(
            left: Any,
            right: Any,
            right_type: Any = NamedTuple,
            right_name: str = 'right'
    ) -> None:
        """Assert the left and right values are equal and the right side is
        the type given.
        """
        assert left == right, (
            "got left: (%r) %s\n"
            "expected: %s" % (
                type(left).__name__, left, right
            )
        )

# Generated at 2022-06-23 18:15:40.646437
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:15:50.094380
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    dic_n = to_namedtuple(dic)
    assert dic_n.a == 1
    assert dic_n.b == 2
    assert dic_n[0] == dic_n.a
    assert dic_n[1] == dic_n.b
    assert dic_n['a'] == dic_n.a
    assert dic_n['b'] == dic_n.b
    assert dic['a'] == dic_n['a']
    assert dic['b'] == dic_n['b']
    assert dic['a'] == dic_n.a
    assert dic['b'] == dic_n.b

# Generated at 2022-06-23 18:15:59.737244
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    t1 = to_namedtuple(dic)
    assert t1.a == 1
    assert t1.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    t1 = to_namedtuple(dic)
    assert t1.a == 1
    assert t1.b == 2

    dic = {'a': 1, 'b': 2}
    t1 = to_namedtuple(dic)
    assert t1.a == 1
    assert t1.b == 2

    class C:
        a: int
        b: int
        def __init__(self): self.a = 1; self.b = 2
    c = C()
    t1 = to_namedtuple

# Generated at 2022-06-23 18:16:05.782996
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3, 'd_': 4}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c_': 3, 'd_': 4}) == NamedT

# Generated at 2022-06-23 18:16:15.270800
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == SimpleNamespace(a=1, b=2)
    assert to_namedtuple(dict(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]