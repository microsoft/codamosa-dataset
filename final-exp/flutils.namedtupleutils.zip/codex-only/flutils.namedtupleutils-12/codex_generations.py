

# Generated at 2022-06-23 18:06:24.152780
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Dict, Optional
    Dictionary = Dict[str, Optional[int]]

    data = {
        'a': {
            'b': 1,
            'c': 2,
            'd': 3,
        },
        'e': {
            'f': 4,
            'g': 5,
            'h': 6,
        },
    }

    def _check(out: Dictionary):
        assert isinstance(out, dict)
        assert len(out) == 2
        assert sorted(out.keys()) == ['a', 'e']
        assert isinstance(out['a'], dict)
        assert len(out['a']) == 3
        assert sorted(out['a'].keys()) == ['b', 'c', 'd']
        assert out['a']['b'] == 1

# Generated at 2022-06-23 18:06:30.535347
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections.abc import Mapping, Sequence
    from collections import namedtuple as nt
    from flutils.namedtupleutils import to_namedtuple
    from flutils.miscutils import is_namedtuple
    from flutils.validators import is_identifier

    # ensure returns the same type
    assert isinstance(to_namedtuple([]), list)
    assert isinstance(to_namedtuple(()), tuple)
    assert isinstance(to_namedtuple({}), NamedTuple)

    # ensure returns the same value
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple({}) == NamedTuple()

    # ensure supports list
    assert is_namedtuple(to_namedtuple([1]))
    assert is_named

# Generated at 2022-06-23 18:06:41.457375
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([[[{'a': 1}]]]) == [
        [
            [
                NamedTuple(a=1)
            ]
        ]
    ]
    assert to_namedtuple('one') == 'one'
    # noinspection PyTypeChecker
    assert to_namedtuple(namedtuple('NamedTuple', ('a', 'b'))(1, 2)) == \
        NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:06:52.861411
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': '', 'b': 2}
    expect = namedtuple('NamedTuple', ['a', 'b'])('', 2)
    got = to_namedtuple(dic)
    assert got == expect

    lst = [dic]
    expect = (expect,)
    got = to_namedtuple(lst)
    assert got == expect

    lst = [[dic, dic], [dic]]
    expect = ((expect, expect), expect)
    got = to_namedtuple(lst)
    assert got == expect

    dic = {'a': '', 'b': 2, '__c': 3}
    expect = namedtuple('NamedTuple', ['a', 'b'])('', 2)

# Generated at 2022-06-23 18:07:00.738006
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import OrderedDict
    from collections.abc import Sequence
    from flutils.namedtupleutils import to_namedtuple

    # First, convert a dictionary
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    b = namedtuple('NamedTuple', 'c d')(c=3, d=4)


# Generated at 2022-06-23 18:07:08.095774
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple({'a': [1, 2, 3]}) == NamedTuple(a=[1, 2, 3])
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3, 'd': 4}) == NamedTuple(a=1, b=2, d=4)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple

# Generated at 2022-06-23 18:07:17.960785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert type(obj).__name__ == 'NamedTuple'

    lst = [1, 2]
    obj = to_namedtuple(lst)
    assert obj[0] == 1
    assert obj[1] == 2
    assert type(obj[0]) == int
    assert type(obj[1]) == int
    assert type(obj).__name__ == 'list'


# Generated at 2022-06-23 18:07:29.783927
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import cast
    from collections import OrderedDict
    from collections import namedtuple

    test_obj = OrderedDict([('a', 1), ('b', 2)])
    test_obj2: NamedTuple = to_namedtuple(test_obj)
    assert cast(NamedTuple, test_obj2) == namedtuple('NamedTuple', 'a b')(1, 2)
    test_obj = SimpleNamespace(a=1, b=2)
    test_obj2: NamedTuple = to_namedtuple(test_obj)
    assert cast(NamedTuple, test_obj2) == namedtuple('NamedTuple', 'a b')(1, 2)


# Generated at 2022-06-23 18:07:42.339372
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a_dict: Mapping = {'a': 1, 'b': 2}

    a_list: Sequence = [a_dict, a_dict]
    a_tuple: Sequence = (a_dict, a_dict)

    a_namedtuple = namedtuple('NamedTuple', 'a b')
    a_namedtuple_list: Sequence = [a_namedtuple(1, 2), a_namedtuple(3, 4)]
    a_namedtuple_tuple: Sequence = (a_namedtuple(1, 2), a_namedtuple(3, 4))

    a_ordereddict = OrderedDict(a=1, b=2)

    a_simplenamespace = SimpleNamespace(a=1, b=2)

    a_int = 1

    # test Sequence (list)

# Generated at 2022-06-23 18:07:51.550726
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test simple values
    assert to_namedtuple(None) is None
    assert to_namedtuple(True) is True
    assert to_namedtuple(0) == 0
    assert to_namedtuple(0.0) == 0.0
    # Test simple dict
    to_namedtuple({})
    to_namedtuple({'a': 1})
    to_namedtuple({1: 'a'})
    to_namedtuple({'a': 1, 'b': {'c': 2}})
    to_namedtuple({'a': 1, 'b': {'c': 2},
                   'd': {'e': 3, 'f': {'g': 4}}})

# Generated at 2022-06-23 18:08:00.836344
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lst = [{'a': 1, 'b': 2}]
    tup = (1, [{'a': 1, 'b': 2}], {'a': 1, 'b': 2})
    dic = OrderedDict({'a': 1, 'b': 2})
    out = to_namedtuple(tup)
    assert out == (1, (NamedTuple(a=1, b=2),), NamedTuple(a=1, b=2))
    assert isinstance(out, tuple)
    assert isinstance(out[1], tuple)
    assert isinstance(out[1][0], NamedTuple)
    assert isinstance(out[2], NamedTuple)
    nt = NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:08:12.050110
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    def ut(
            _in: Any,
            _out: Any,
            exp: Union[NamedTuple, Tuple, List]
    ) -> Tuple[Any, NamedTuple, Tuple, List]:
        out = to_namedtuple(_in)
        assert out == exp, out
        return _in, _out, exp, out
    # noinspection PyRedundantParentheses

# Generated at 2022-06-23 18:08:24.980937
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import defaultdict, OrderedDict
    from flutils.datautils import full_range
    from typing import List, Tuple

    # list/tuple
    assert to_namedtuple([]) == []
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == [
        NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)
    ]

# Generated at 2022-06-23 18:08:30.326768
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert (to_namedtuple({'a': 1, 'b': 2}) ==
            to_namedtuple(OrderedDict([('a', 1), ('b', 2)])))

    assert (to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) ==
            [to_namedtuple(OrderedDict([('a', 1), ('b', 2)])),
             to_namedtuple(OrderedDict([('a', 3), ('b', 4)]))])

    assert (to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) ==
            to_namedtuple(SimpleNamespace(a=1, b=2)))


# Generated at 2022-06-23 18:08:43.293429
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    def func():
        pass


# Generated at 2022-06-23 18:08:53.926204
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    odic = OrderedDict(a=1, b=2, c=3)
    assert to_namedtuple(odic) == NamedTuple(a=1, b=2, c=3)

    lis = ['a', 'b', 'c']
    assert to_namedtuple(lis) == ['a', 'b', 'c']

    tup = ('a', 'b', 'c')
    assert to_namedtuple(tup) == ('a', 'b', 'c')

    nt = NamedTuple(a=1, b=2, c=3)
    nt_namedtuple = to_namedtuple(nt)

# Generated at 2022-06-23 18:08:58.762406
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)


if __name__ == '__main__':
    dic = {'a': 1, 'b': 2}
    print(to_namedtuple(dic))

# Generated at 2022-06-23 18:09:09.569905
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from typing import Dict
    from flutils.validators import (
        is_identifier,
        is_str,
    )
    from flutils.anyutils import (
        is_ordereddict,
        is_tuple,
    )
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        """Test :func:`to_namedtuple <flutils.namedtupleutils.to_namedtuple>`."""

        def setUp(self) -> None:
            self.namedtuples: Dict[str, NamedTuple] = {}
            vals = []

# Generated at 2022-06-23 18:09:17.518776
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import json

    test_data = [
        {'a': 1, 'b': 2},
        {'a': 1, 'b': {'c': 3, 'd': 4}},
        [1, 2, 3, 4],
        [[1, 2], [3, 4]],
        [1, 2, {'c': 3, 'd': 4}],
        {'a': 1, 'b': [3, 4]}
    ]


# Generated at 2022-06-23 18:09:25.784572
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1}, {'b': 2}]) == [NamedTuple(a=1), NamedTuple(b=2)]
    assert to_namedtuple(tuple({'a': 1, 'b': 2})) == ({'a': 1, 'b': 2},)
    assert to_namedtuple(list(OrderedDict([('a', 1), ('b', 2)]))) == [NamedTuple(a=1, b=2)]

# Generated at 2022-06-23 18:09:35.327396
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyShadowingNames
    def dm(ret):
        # Return the display marker
        marker = '.'
        # noinspection PyUnresolvedReferences,PyProtectedMember
        if not ret.__wrapped__:
            marker = 'F'
        return marker
    def nt(obj):
        return to_namedtuple(obj)    # noqa: F821

    # noinspection PyUnusedLocal
    def f(obj, ret):
        msg = f"{dm(ret)} {ret.__prefix__} {ret.__reason__[0]} {ret.__reason__[1]}"
        # noinspection PyShadowingNames
        assert ret == ret.__expected__, msg

    # List
    a = [[{'a': 1}, {'b': 2}]]

# Generated at 2022-06-23 18:09:46.357755
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(OrderedDict(a=1, b=2)) == to_namedtuple({'a': 1, 'b': 2})
    assert to_namedtuple(OrderedDict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == to_namedtuple({'a': 1, 'b': 2})
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == to_namedtuple(SimpleNamespace(a=1, b=2))

# Generated at 2022-06-23 18:09:55.307928
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Counter

    from pprint import pprint

    from flutils.namedtupleutils import to_namedtuple

    dic = {
        'a': 1,
        'b': 'c',
        'd': {'e': 1, 'f': 'g'},
        'h': [{'i': 0, 'j': 1}, {'i': 1, 'j': 0}],
        'k': Counter({'l': 1})
    }
    expected_output = {
        'a': 1,
        'b': 'c',
        'd': NamedTuple(e=1, f='g'),
        'h': [NamedTuple(i=0, j=1), NamedTuple(i=1, j=0)],
        'k': NamedTuple(l=1)
    }

# Generated at 2022-06-23 18:10:07.120834
# Unit test for function to_namedtuple
def test_to_namedtuple():
    expected_output = NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2}
    output = to_namedtuple(dic)
    assert output == expected_output

    expected_output = NamedTuple(a=NamedTuple(a=1, b=2), b=NamedTuple(a=1, b=2))
    dic = {'a': {'a': 1, 'b': 2}, 'b': {'a': 1, 'b': 2}}
    output = to_namedtuple(dic)
    assert output == expected_output

    expected_output = (NamedTuple(a=1, b=2), NamedTuple(a=1, b=2))

# Generated at 2022-06-23 18:10:18.682532
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pytest import raises
    from flutils.validators.tests.validate_identifier import (  # type: ignore
        test_validate_identifier as val_id
    )

    # noinspection PyUnresolvedReferences
    val_id(to_namedtuple)  # type: ignore[attr-defined]

    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', 'a b')(1, 2)

# Generated at 2022-06-23 18:10:30.517191
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from itertools import count
    from collections import namedtuple as nt

    def _check_nt(obj, **kw):
        for key, val in kw.items():
            assert getattr(obj, key) == val

    def _check_ordered_nt(obj, **kw):
        for key, val in zip(obj._fields, obj):
            _check_nt(obj, **{key: val})

    # noinspection PyTypeChecker

# Generated at 2022-06-23 18:10:40.457609
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out == (1, 2)

    dic = {'1a': 1, 'a': 2}
    out = to_namedtuple(dic)
    assert out.a == 2
    assert out == (2,)

    dic = {'_a': 1, 'a': 2}
    out = to_namedtuple(dic)
    assert out.a == 2
    assert out == (2,)

    dic = {'_a': 1, 'a': [1, 2]}

# Generated at 2022-06-23 18:10:51.821181
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({"a": "b", "c": "d"}) == NamedTuple(a="b", c="d")
    assert to_namedtuple(OrderedDict([("a", "b"), ("c", "d")])) == NamedTuple(a="b", c="d")
    assert to_namedtuple(["a", OrderedDict([("b", "c"), ("d", "e")])]) == ["a", NamedTuple(b="c", d="e")]

# Generated at 2022-06-23 18:11:03.539273
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import __doc__ as doc
    import inspect
    import re

    # noinspection PyUnusedLocal
    def assert_roundtrip(obj: Any) -> None:
        """Assert that to_namedtuple(to_namedtuple(obj)) == obj."""
        assert to_namedtuple(to_namedtuple(obj)) == obj

    def assert_raises(exception: type, call: Any, *args: Any,
                      **kwargs: Any) -> None:
        """Assert that calling a function will raise an exception."""
        try:
            call(*args, **kwargs)
        except exception:
            pass
        else:
            raise Assert

# Generated at 2022-06-23 18:11:12.610250
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import os
    import json
    import unittest

    if sys.version_info.major < 3:
        # noinspection PyCompatibility
        from collections import OrderedDict

    if sys.version_info.major == 2:
        # noinspection PyCompatibility
        from flutils.namedtupleutils import (  # noqa: F401
            _to_namedtuple,
            to_namedtuple,
        )
        from flutils.namedtupleutils import (  # noqa: F401,F811
            _AllowedTypes,
        )
        from flutils.namedtupleutils import (  # noqa: F401,F811
            _to_namedtuple,
        )
    from flutils.namedtupleutils import (
        PredefinedAttributes,
    )



# Generated at 2022-06-23 18:11:23.207972
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Runs unit test for `flutils.namedtupleutils.to_namedtuple` function."""
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    dic = {
        'a': 1,
        'b': 2
    }
    assert 'a' in to_namedtuple(dic)
    assert 'b' in to_namedtuple(dic)

    ord_dic = OrderedDict(a=1, b=2)
    assert 'a' in to_namedtuple(ord_dic)
    assert 'b' in to_namedtuple(ord_dic)
    assert to_namedtuple(ord_dic).__dict__['_fields'] == ('a', 'b')


# Generated at 2022-06-23 18:11:32.781012
# Unit test for function to_namedtuple
def test_to_namedtuple():

    def assert_is_namedtuple(objs):
        for obj in objs:
            assert isinstance(obj, namedtuple('NamedTuple', ''))

    def assert_is_not_namedtuple(objs):
        for obj in objs:
            assert not isinstance(obj, namedtuple('NamedTuple', ''))

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_is_namedtuple((out,))

    item = SimpleNamespace(a=1, b=2)
    out = to_namedtuple(item)
    assert_is_namedtuple((out,))

    item = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(item)

# Generated at 2022-06-23 18:11:36.932759
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.tests.helpers import UnitCase

    # noinspection PyUnresolvedReferences
    class _TestCase(UnitCase):
        def test_to_namedtuple(self):
            self.assertRaises(TypeError, to_namedtuple, 123)
            self.assertRaises(TypeError, to_namedtuple, 123.45)

# Generated at 2022-06-23 18:11:44.947636
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from types import SimpleNamespace
    from unittest import TestCase
    from unittest.mock import Mock, patch

    from flutils.namespace import Namespace
    from flutils.validators import validate_identifier, ValidationFailure


# Generated at 2022-06-23 18:11:56.397136
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:12:08.733803
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    res = to_namedtuple(dic)
    assert isinstance(res, NamedTuple)
    assert res.a == 1
    assert res.b == 2
    assert res == (1, 2)

    dic = {'a': 1, 'b': 2, 'c': 'abc'}
    res = to_namedtuple(dic)
    assert isinstance(res, NamedTuple)
    assert res.a == 1
    assert res.b == 2
    assert res.c == 'abc'
    assert res == (1, 2, 'abc')

    dic = {'a': 1, 'b': 2, 'c': 'abc', '_d': 4}
    res = to_namedtuple(dic)
    assert isinstance

# Generated at 2022-06-23 18:12:12.427329
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = {'a': 1, 'b': 2}
    answer = to_namedtuple(data)
    assert answer.b == 2

# Generated at 2022-06-23 18:12:18.086675
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    import random

    from flutils.testutils import (
        random_string,
        TestFileContents,
    )

    def _random_mapping(
            depth: int,
            max_depth: int
    ) -> Mapping[str, Any]:
        if max_depth < depth:
            return {}
        out = {}
        for _ in range(random.randint(0, 4)):
            key = random_string(10)
            val = _random_value(depth + 1, max_depth)
            out[key] = val
        return out

    def _random_value(
            depth: int,
            max_depth: int
    ) -> Any:
        funcs = [
            _random_mapping,
            # _random_sequence,
        ]

# Generated at 2022-06-23 18:12:28.278017
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    def test_NamedTuple(obj):
        out = to_namedtuple(obj)
        assert isinstance(out, NamedTuple)

    def test_List(obj):
        out = to_namedtuple(obj)
        assert isinstance(out, list)
        for item in out:
            assert isinstance(item, (int, NamedTuple))

    def test_Tuple(obj):
        out = to_namedtuple(obj)
        assert isinstance(out, tuple)
        for item in out:
            assert isinstance(item, (int, NamedTuple))

    def test_allowed(obj):
        with pytest.raises(TypeError):
            to_namedtuple(obj)

    # Test a dict

# Generated at 2022-06-23 18:12:37.936251
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    from collections import OrderedDict
    from types import SimpleNamespace

    class TestToNamedTuple(unittest.TestCase):
        def test_to_namedtuple_regular_dict(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertTrue(isinstance(out, NamedTuple))
            self.assertEqual(
                out,
                NamedTuple(a=1, b=2)
            )

        def test_to_namedtuple_different_types(self):
            dic = {'a': 1, 'b': 2, 'c': '3', 'd': 4.5, 'e': True}
            out = to_namedtuple(dic)

# Generated at 2022-06-23 18:12:50.029549
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'a': 1, 'b': {'c': 3, 'd': 4}}) == namedtuple('NamedTuple', 'a b')(1, namedtuple('NamedTuple', 'c d')(3, 4))
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == namedtuple('NamedTuple', 'a b')(1, 2)

# Generated at 2022-06-23 18:13:01.689069
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the function :func:`to_namedtuple`."""
    from collections import OrderedDict
    from datetime import time
    from decimal import Decimal
    from flutils.namedtupleutils import to_namedtuple
    from fractions import Fraction
    from types import MappingProxyType

    num = 5
    assert num == to_namedtuple(num)

    f = Fraction(2, 3)
    assert f == to_namedtuple(f)

    d = Decimal(3.14159265)
    assert d == to_namedtuple(d)

    t = time(15, 45, 12)
    assert t == to_namedtuple(t)

    s = 'warbles'
    assert s == to_namedtuple(s)


# Generated at 2022-06-23 18:13:12.083088
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import copy

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')

    dic = {'a': 1, '__b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert not hasattr(nt, '__b')
    assert not hasattr(nt, '__b')

    dic = {'a': 1, 'b_': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert not hasattr(nt, 'b_')

# Generated at 2022-06-23 18:13:20.210455
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import datetime
    import re

    assert hasattr(to_namedtuple({'a': 1, 'b': 2}), 'a')
    assert hasattr(to_namedtuple({'a': 1, 'b': 2}), 'b')

    from flutils.numberutils import is_number
    from decimal import Decimal
    for item in '123', 123, Decimal('123'):
        assert is_number(item) is True
        out = to_namedtuple({'a': item})
        assert is_number(out.a) is True

    assert to_namedtuple({'a': [1, 'a']}).a[0] == 1
    assert to_namedtuple({'a': [1, 'a']}).a[1] == 'a'

# Generated at 2022-06-23 18:13:30.966866
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Sequence
    my_dict = dict(a=1, b=2)
    result = to_namedtuple(my_dict)
    assert isinstance(result, tuple)
    assert hasattr(result, 'a')
    assert hasattr(result, 'b')
    assert result.a == 1
    assert result.b == 2
    result = to_namedtuple(my_dict)
    assert isinstance(result, tuple)
    assert hasattr(result, 'a')
    assert hasattr(result, 'b')
    assert result.a == 1
    assert result.b == 2
    my_list = [1, 2]
    result = to_namedtuple(my_list)
    assert isinstance(result, list)

# Generated at 2022-06-23 18:13:41.677670
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple({'b': 2, 'a': 1})
    assert to_namedtuple((1, 2)) == to_namedtuple(((1, 2)))
    assert to_namedtuple([{'a': 1}, {'b': 2}]) == \
        to_namedtuple([{'b': 2}, {'a': 1}])
    assert to_namedtuple([{'a': 1}, ['b', 2]]) == \
        to_namedtuple([['b', 2], {'a': 1}])

# Generated at 2022-06-23 18:13:47.107967
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Test to_namedtuple()

        ..note::
            Several tests taken from the use of ``to_namedtuple``
            in ``flutils.decorators.deprecated``.
    """
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    lis = [dic, dic]
    result = [NamedTuple(a=1, b=2), NamedTuple(a=1, b=2)]
    assert to_namedtuple(lis) == result

    tpl = (dic, dic)
    result = (NamedTuple(a=1, b=2), NamedTuple(a=1, b=2))

# Generated at 2022-06-23 18:13:55.293271
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(NamedTuple(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(1) == 1
    assert to_

# Generated at 2022-06-23 18:14:07.173357
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Initialize variables
    data = {
        'a': 1,
        'c': 2,
        'b': {'a': 1, 'c': 2, 'b': {'a': 1, 'c': 2, 'b': 2}},
        'd': [1,2,3],
        'e': [{'a': 1}, {'b': 2}],
        'f': {'a': 1, 'b': [{'a': 1, 'c': 2}, {'a': 1}, {'b': {'a': 1, 'c': 2}}]}
    }

    # Convert data to namedtuple
    nt_data: NamedTuple = to_namedtuple(data)

    # Verify namedtuple
    assert(nt_data.a == data['a'])

# Generated at 2022-06-23 18:14:15.115723
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple',
                                                         'a, b')(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple',
                                                         'a, b')(a=1, b=2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple((1, 2)) != [1, 2]

# Generated at 2022-06-23 18:14:27.648540
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from flutils.inflection import (
        camelize,
        underscore,
    )
    from flutils.collections import (
        ordereddict,
    )
    from collections import (
        namedtuple,
    )

    assert to_namedtuple([{}]) == []

    val = to_namedtuple([{'a': 1, 'b': 2}])
    assert isinstance(val, list)
    assert len(val) == 1
    assert val[0].a == 1
    assert val[0].b == 2

    # Test order or namedtuple
    val = to_namedtuple({'a': 1, 'b': 2})
    assert val[0] == 1
    assert val[1] == 2

# Generated at 2022-06-23 18:14:34.209059
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple(('a', 'b')) == ('a', 'b')
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2}}) ==\
           NamedTuple(a=1, b=2, c=NamedTuple(a=1, b=2))


if __name__ == '__main__':
    import doctest

# Generated at 2022-06-23 18:14:42.862987
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # List
    obj = ['a', 'b', 1, 2]
    assert to_namedtuple(obj) == ['a', 'b', 1, 2]

    # Tuple
    obj = ('a', 'b', 1, 2)
    assert to_namedtuple(obj) == ('a', 'b', 1, 2)

    # Dict
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)

    # OrderedDict
    obj = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)

    # SimpleNamespace

# Generated at 2022-06-23 18:14:54.007412
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 'a', 'b': 'b'}) == NamedTuple(a='a', b='b')
    assert to_namedtuple({'a_b': 'a_b'}) == NamedTuple(a_b='a_b')
    assert to_namedtuple({'a b': 'a b'}) == NamedTuple()

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert dic == {'a': 1, 'b': 2}



# Generated at 2022-06-23 18:15:03.182286
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _assert_called(name: str, *args: Any, **kwargs: Any) -> None:
        dic_args = dict(zip(name, args))
        dic_args.update(kwargs)
        expected = dict(**dic_args)
        out = to_namedtuple(dic_args)
        for key in expected.keys():
            assert hasattr(out, key)
            val = getattr(out, key)
            assert val == dic_args[key]

    def _assert_called_r(name: str, *args: Any, **kwargs: Any) -> None:
        dic_args = dict(zip(name, args))
        dic_args.update(kwargs)
        expected = dict(**dic_args)

# Generated at 2022-06-23 18:15:15.558480
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple.
    """
    import pytest
    from flutils.namedtupleutils import (
        _to_namedtuple,
        to_namedtuple,
    )

    # Simple
    assert _to_namedtuple(1) == 1
    assert _to_namedtuple(tuple('abc')) == tuple('abc')
    assert _to_namedtuple('abc') == 'abc'
    assert _to_namedtuple(3.14) == 3.14
    assert isinstance(_to_namedtuple(SimpleNamespace()), NamedTuple)
    assert _to_namedtuple(list('abc')) == list('abc')
    assert _to_namedtuple(tuple('abc')) == tuple('abc')

# Generated at 2022-06-23 18:15:22.797989
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test for function to_namedtuple.
    """
    def testit(obj):
        if isinstance(obj, (str, bytes, bytearray, memoryview)):
            return obj
        return to_namedtuple(obj)

    assert testit(['hello', 1, '2', 3.0, (4, 5, 6)]) == ['hello', 1, '2', 3.0, (4, 5, 6)]
    assert testit(('hello', 1, '2', 3.0, (4, 5, 6))) == ('hello', 1, '2', 3.0, (4, 5, 6))
    assert testit({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:15:30.691398
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    class Fake(Mapping):
        def __init__(self) -> None:
            self.__dict__ = {'a': 1, 'b': 2}

        def __getitem__(self, key) -> int:
            return self.__dict__[key]

        def __len__(self) -> int:
            return len(self.__dict__)

        def __iter__(self) -> iter:
            return iter(self.__dict__)

        def __contains__(self, item) -> bool:
            return item in self.__dict__

    assert isinstance(to_namedtuple(Fake()), NamedTuple)

    test = dict(a=1, b=2)

# Generated at 2022-06-23 18:15:42.317249
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    from flutils.py23utils import iteritems, range_func
    from collections import OrderedDict
    from types import SimpleNamespace


# Generated at 2022-06-23 18:15:51.020166
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing to_namedtuple... ', end='')

# Generated at 2022-06-23 18:15:59.906026
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    import json

    dic = {
        'a': 'value1',
        'b': 'value2'
    }
    obj = to_namedtuple(dic)
    assert obj.a == 'value1'
    assert obj.b == 'value2'
    lst = [1, 2, 3, 4, dic]
    obj = to_namedtuple(lst)
    assert len(obj) == 5
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3
    assert obj[3] == 4
    assert obj[4].a == 'value1'
    assert obj[4].b == 'value2'

# Generated at 2022-06-23 18:16:02.363667
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)


# Generated at 2022-06-23 18:16:09.961145
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    dic = {'a': 1, 'b': 2}
    result = namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple(dic) == result
    lst = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    result = [result, namedtuple('NamedTuple', ['c', 'd'])(3, 4)]
    assert to_namedtuple(lst) == result
    odic = OrderedDict([('a', 1), ('b', 2)])
    result = namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple(odic) == result

# Generated at 2022-06-23 18:16:19.181164
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.namespace = SimpleNamespace
            self.nested_namespace = SimpleNamespace
            self.nested_namespace.a = 1
            self.nested_namespace.b = 2
            self.namespace.a = self.nested_namespace
            self.namespace.b = self.nested_namespace
            self.namespace.c = 3

        def runTest(self):
            namespace = to_namedtuple(self.namespace)
            self.assertEqual(namespace.a.a, 1)
            self.assertEqual(namespace.b.a, 1)
            self.assertEqual(namespace.c, 3)

    test = Test()
    test.set