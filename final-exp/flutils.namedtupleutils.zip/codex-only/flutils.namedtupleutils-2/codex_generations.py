

# Generated at 2022-06-23 18:06:18.522989
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple({'name': 'Fred'}) == \
           cast(NamedTuple, namedtuple('NamedTuple', ['name'])('Fred'))
    assert to_namedtuple(dict(name='Fred')) == \
           cast(NamedTuple, namedtuple('NamedTuple', ['name'])('Fred'))
    assert to_namedtuple(OrderedDict([('name', 'Fred')])) == \
           cast(NamedTuple, namedtuple('NamedTuple', ['name'])('Fred'))

# Generated at 2022-06-23 18:06:28.709640
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {"a": 1, "b": 2}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)

    obj = [{"a": 1, "b": 2}, {'c': 3, 'd': 4}]
    assert to_namedtuple(obj) == [NamedTuple(a=1, b=2), NamedTuple(c=3, d=4)]

    obj = {"a": 1, "b": 2, '4': 4}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2, _4=4)

    obj = {"a": 1, "b": 2, '_c': 3}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)


# Generated at 2022-06-23 18:06:37.844818
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    """Unit test for function to_namedtuple
    """
    import pytest

    assert to_namedtuple([]) == []
    assert to_namedtuple(tuple()) == ()
    assert to_namedtuple({}) is not None
    assert to_namedtuple(OrderedDict({})) is not None
    with pytest.raises(TypeError):
        to_namedtuple(None)
    assert(str(to_namedtuple(
        {'a': [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}], 'b': 2}
    )) == 'NamedTuple(a=(NamedTuple(a=1, b=2), NamedTuple(c=3, d=4)), b=2)')

# Generated at 2022-06-23 18:06:44.303117
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)]
    assert to_namedtuple((1, {'a': 1, 'b': 2})) == (1, namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2))

# Generated at 2022-06-23 18:06:54.967471
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections.abc import Mapping

    dic = {
        'a': 1,
        'b': 2,
    }
    named = to_namedtuple(dic)
    assert isinstance(named, namedtuple('NamedTuple', 'a b'))
    assert named.a == 1
    assert named.b == 2
    assert named[0] == 1
    assert named[1] == 2

    lst = [1, 2, 3]
    lst2  = to_namedtuple(lst)
    assert isinstance(lst2, list)
    for idx in range(len(lst)):
        assert lst[idx] == lst2[idx]

    tuple_in = (1, 2, 3)
    tuple_out = to_namedt

# Generated at 2022-06-23 18:07:01.649781
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': {'_a': 1, 'b': 2}, '_b': 2, 'c': 3}
    x = to_namedtuple(obj)
    assert x.a == namedtuple('NamedTuple', ('b',))(2,)
    assert x == namedtuple('NamedTuple', ('a', 'c'))(
        namedtuple('NamedTuple', ('b',))(2,), 3
    )

    obj = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(obj) == namedtuple('NamedTuple', ('a', 'b', 'c'))(1, 2, 3)

    obj = {'a': 1, 'B': 2, 'c': 3}
    assert to_namedtuple(obj)

# Generated at 2022-06-23 18:07:13.139745
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = OrderedDict([('a', 1), ('b', 2)])
    Tuple = to_namedtuple(dic)
    assert Tuple.a == 1
    assert Tuple.b == 2

    dic = {'a': 1, 'b': 2}
    Tuple = to_namedtuple(dic)
    assert Tuple.a == 1
    assert Tuple.b == 2

    dic = SimpleNamespace(a=1, b=2)
    Tuple = to_namedtuple(dic)
    assert Tuple.a == 1
    assert Tuple.b == 2

    dic = SimpleNamespace(a=1, b=2)
    dic = to_namedtuple(dic)

# Generated at 2022-06-23 18:07:25.182657
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.datautils import deep_eq
    from typing import List, Mapping, Sequence

    assert deep_eq(
        to_namedtuple({'a': 1, 'b': 2, '_c': 3, 'D': 4}),
        namedtuple('NamedTuple', 'a b')(a=1, b=2)
    )
    assert deep_eq(
        to_namedtuple(OrderedDict((('b', 1), ('a', 2)))),
        namedtuple('NamedTuple', 'b a')(b=1, a=2)
    )

# Generated at 2022-06-23 18:07:30.017910
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2]) == (1, 2)
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', [1]), ('b', [2])])) == namedtuple('NamedTuple', 'a b')(a=[1], b=[2])
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dict([('a', [1]), ('b', [2])]))

# Generated at 2022-06-23 18:07:34.026418
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection SpellCheckingInspection
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2

# Generated at 2022-06-23 18:07:46.627743
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase

    # noinspection PyTypeChecker
    class TestObj(TestCase):

        def test_to_namedtuple(self):
            from flutils.namedtupleutils import to_namedtuple
            from collections import OrderedDict

            obj1 = {
                'a': 1,
                'b': 2,
                'c': [
                    {
                        'd': 3,
                        'e': 4,
                    },
                    {
                        'f': 5,
                        'g': 6,
                    }
                ],
                'h': OrderedDict([
                    ('i', 7),
                    ('j', 8),
                ])
            }
            obj2 = to_namedtuple(obj1)
            self.assertIsInstance(obj2, tuple)

# Generated at 2022-06-23 18:07:57.932158
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert hasattr(nt, '_fields')
    assert hasattr(nt, '_asdict')
    assert nt._fields == ('a', 'b')
    assert nt._asdict() == {'a': 1, 'b': 2}
    assert not hasattr(nt, '_a')
    assert not hasattr(nt, '__b')
    assert not hasattr(nt, '_')
    assert not hasattr(nt, '_1')


# Generated at 2022-06-23 18:08:09.241471
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import typing
    import pytest
    from collections import namedtuple
    from collections.abc import Mapping

    Data = namedtuple('Data', 'a b c d')
    Obj = SimpleNamespace
    dic = {'a': 1, 'b': 2, 'd': 4}
    dic_nested = {'a': 1, 'b': 2, 'c': dic}
    lst = [dic, dic_nested]
    obj = Obj()
    obj.a = dic
    obj.b = dic_nested
    obj_data = Obj()
    obj_data.a = 1
    obj_data.b = 2
    obj_data.c = dic
    obj_data.d = 4
    str_ = 'test'
    tup = tuple(dic.values())

# Generated at 2022-06-23 18:08:22.025865
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple

    dic: dict = {'a': 1, 'b': 2}
    nt: namedtuple = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    lst: list = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    nt_lst: list = to_namedtuple(lst)
    assert isinstance(nt_lst, list)
    assert len(nt_lst) == len(lst)
    assert nt_lst[0].a == 1
    assert nt_lst[0].b == 2
    assert nt_lst[1].c == 3
    assert nt_lst[1].d == 4

    t

# Generated at 2022-06-23 18:08:30.208851
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    val = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(val) == NamedTuple(a=1, b=2)

    for val in (
            [1, 2],
            (1, 2),
            SimpleNamespace(a=1, b=2)
    ):
        assert to_namedtuple(val) == NamedTuple(a=1, b=2)

    val = {'a': 1, 'b': 2}
    assert to_namedtuple(val) == NamedTuple(a=1, b=2)

    val = OrderedDict([('a', OrderedDict([('b', OrderedDict([('c', 1)]))]))])
    assert to_

# Generated at 2022-06-23 18:08:42.580504
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test for function to_namedtuple.
    """
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple

    dic: dict = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': '5',
        'f': 6,
    }
    expected0: NamedTuple = namedtuple('NamedTuple', 'a b c d e f')(1, 2, 3, 4, '5', 6)

    actual: NamedTuple = to_namedtuple(dic)

    assert actual == expected0


# Generated at 2022-06-23 18:08:46.744702
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    from flutils.namedtupleutils import to_namedtuple
    from flutils.collectionsutils import deepupdate
    lst = [1, 2, 3]
    lst = to_namedtuple(lst)
    ls = [1, 2, 3]
    assert lst == ls
    lst = [1, 2, 3, {'a': 1, 'b': 2, 'c': {'d': 4}}]
    lst = to_namedtuple(lst)
    lst = cast(List[Union[int, NamedTuple]], lst)
    ls = [1, 2, 3, NamedTuple(a=1,  b=2, c=NamedTuple(d=4))]
    assert lst == ls
    tup

# Generated at 2022-06-23 18:08:48.878025
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:08:56.809348
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(((1,), (2,))) == ((1,), (2,))
    assert to_namedtuple([[1], [2]]) == [[1], [2]]

# Generated at 2022-06-23 18:09:08.270328
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 'a', 'b': 'b'}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a='a', b='b')

    dic = {'a': 1, 'b': [1, 'a']}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=[1, 'a'])


# Generated at 2022-06-23 18:09:16.726484
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

    lst = [{}, {'a': 1}, {'a': 1, 'b': 2}]
    out = [NamedTuple(), NamedTuple(a=1), NamedTuple(a=1, b=2)]
    assert to_namedtuple(lst) == out

    tpl = ({}, {'a': 1}, {'a': 1, 'b': 2})
    out = (NamedTuple(), NamedTuple(a=1), NamedTuple(a=1, b=2))
    assert to_named

# Generated at 2022-06-23 18:09:26.109899
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from testutils.test_case import ExtendedTestCase
    from testutils.string_tools import random_string

    class TestToNamedTuple(ExtendedTestCase):
        def __init__(self, *args):
            super().__init__(*args)
            self.identifiers = []
            while len(self.identifiers) < 9:
                self.identifiers.extend(
                    [random_string(rndint(3, 12), rndchr())
                     for _ in range(rndint(3, 8))]
                )
            self.identifiers = rndgen.shuffle(self.identifiers)
            self.identifiers.extend([None, False, ''])

        def test_to_namedtuple_dict(self):
            from collections import OrderedD

# Generated at 2022-06-23 18:09:31.880573
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dct = {'b': 'B', 'a': 'A', 'c': 'C'}
    x = to_namedtuple(dct)
    print(x)
    print(f"x.a = {x.a}")

    dct = {'b': {'a': 'A', 'b': 'B'}, 'a': 'A', 'c': 'C'}
    x = to_namedtuple(dct)
    print(x)
    print(f"x.a = {x.a}")
    print(f"x.b = {x.b}")
    print(f"x.b.a = {x.b.a}")
    print(f"x.b.b = {x.b.b}")


# Generated at 2022-06-23 18:09:40.710264
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test for to_namedtuple()
    """
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from typing import (
        NamedTuple,
    )
    import collections

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == collections.namedtuple('NamedTuple', 'a b')(1, 2)

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    assert (to_namedtuple(dic) ==
            collections.namedtuple('NamedTuple', 'a b')(1, 2))

    dic = {'1': 1, '2': 2}

# Generated at 2022-06-23 18:09:48.792053
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test the to_namedtuple function.
    """
    # result = test_function(function, *args, **kwargs)
    # self.assertEqual(expected, result)
    result = to_namedtuple({'a': 1, 'b': 2}) 
    expected = \
    namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert result == expected
    result = to_namedtuple({'a': {'c': 1, 'b': 2}}) 
    expected = \
    namedtuple('NamedTuple', 'a')(a=namedtuple('NamedTuple', 'b c')(b=2, c=1))
    assert result == expected

# Generated at 2022-06-23 18:09:57.351318
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    obj = OrderedDict()
    obj['a'] = 1
    obj['b'] = 2
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    obj = dict(a=1, b=2)
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    obj = dict(a=1, bb=2)
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.bb == 2


# Generated at 2022-06-23 18:10:01.884061
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple for type NamedTuple."""
    # Test for different objects that should be converted to a NamedTuple object
    dic = {'a': 1, 'b': 2}
    dic_namedtup = to_namedtuple(dic)
    assert isinstance(dic_namedtup, NamedTuple)
    assert dic_namedtup.a == 1
    assert dic_namedtup.b == 2

    dic_list = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    dic_list_namedtup = to_namedtuple(dic_list)
    assert isinstance(dic_list_namedtup, list)

# Generated at 2022-06-23 18:10:12.248325
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from dataclasses import dataclass
    from typing import List, Set, Union
    from functools import reduce
    import operator as op
    from flutils.dotdict import DotDict
    from flutils.pyutils.iteration import flatten

    @dataclass
    class Node:
        name: str
        parent: str
        children: List[str]

    @dataclass
    class DeepNode:
        name: str
        parent: Union['DeepNode', 'str']
        children: Set[Union['DeepNode', 'str']]

    @dataclass
    class DeepDeepNode:
        name: str
        parent: Union['DeepDeepNode', 'DeepNode', 'str']
        children: Set[Union['DeepDeepNode', 'DeepNode', 'str']]


# Generated at 2022-06-23 18:10:22.889992
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys

    # Check all types initially raise an error
    for input_, expected in [
        (None, TypeError),
        (42, TypeError),
        (45.0, TypeError),
        (True, TypeError),
        (False, TypeError),
        (bytearray(), TypeError),
        (complex(), TypeError),
        (frozenset(), TypeError),
        (memoryview(), TypeError),
        (range(0), TypeError),
        (slice(None, None), TypeError),
        (sys.exc_info(), TypeError),
    ]:
        try:
            to_namedtuple(input_)
        except Exception as e:
            if isinstance(e, expected):
                continue
            raise

# Generated at 2022-06-23 18:10:28.747189
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': {'b': {'c': {'d': {'e': {'f': {'g': 1}}}}}}}
    nt = to_namedtuple(dic)
    assert nt.a.b.c.d.e.f.g == 1

    dic = {'a': {'b': {'c': {'d': [1, 2, 3, 4]}}}}
    nt = to_namedtuple(dic)
    assert isinstance(nt.a.b.c.d, tuple)

# Generated at 2022-06-23 18:10:37.834056
# Unit test for function to_namedtuple
def test_to_namedtuple():
    try:
        assert to_namedtuple('random string')
    except TypeError as e:
        print(e)
        print('test_to_namedtuple() passed')
    else:
        print('test_to_namedtuple() failed')


# Generated at 2022-06-23 18:10:43.358683
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace
    import pytest
    from copy import copy

    yaml_config = {
        'section_1': {
            'a': 1,
            'b': 2,
            'c': 3,
        },
        'section_2': {
            'd': 4,
            'e': 5,
            'f': 6,
        },
    }

    # Test to_namedtuple as a function
    def test_to_namedtuple_as_a_function():
        # Test with a SimpleNamespace
        obj = SimpleNamespace(
            **yaml_config['section_1']
        )

# Generated at 2022-06-23 18:10:54.094121
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test tuple of dictionaries
    obj = (
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
    )
    out: Union[List, Tuple] = to_namedtuple(obj)
    assert isinstance(out, tuple)
    for item in out:
        assert isinstance(item, NamedTuple)
        assert hasattr(item, 'a')
        assert hasattr(item, 'b')
        assert item.a == 1
        assert item.b == 2

    # Test list of dictionaries
    obj = [
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
    ]
    out: Union[List, Tuple] = to_namedtuple(obj)

# Generated at 2022-06-23 18:10:59.967580
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    Result = namedtuple('Result', 'integer float string list')
    tmp = to_namedtuple({'integer': 2, 'float': 3.456, 'string': 'string'})
    assert tmp.integer == 2
    assert tmp.float == 3.456
    assert tmp.string == 'string'

    tmp = to_namedtuple(
        {'integer': 2, 'float': 3.456, 'string': 'string', 'list': [1, 2]}
    )
    assert tmp.integer == 2
    assert tmp.float == 3.456
    assert tmp.string == 'string'
    assert tmp.list == [1, 2]


# Generated at 2022-06-23 18:11:05.035804
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class OD(OrderedDict):
        def __init__(self, **kwargs):
            OrderedDict.__init__(self)
            # noinspection PyArgumentList
            for key, val in kwargs.items():
                # noinspection PyArgumentList
                OrderedDict.__setitem__(self, key, val)

    d = {
        'c': 3,
        'a': 1,
        'b': 2,
        'd': 4
    }

    od: OD = OD(
        c=3,
        a=1,
        b=2,
        d=4
    )
    s = SimpleNamespace(
        c=3,
        a=1,
        b=2,
        d=4
    )

# Generated at 2022-06-23 18:11:13.704813
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import NamedTuple
    tuple_ = to_namedtuple([1, 2, 3])
    assert isinstance(tuple_, tuple)
    assert isinstance(tuple_[0], int)
    assert isinstance(tuple_[1], int)
    assert isinstance(tuple_[2], int)
    assert tuple_ == (1, 2, 3)
    od = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    tuple_ = to_namedtuple(od)
    assert isinstance(tuple_, tuple)
    assert isinstance(tuple_[0], int)
    assert isinstance(tuple_[1], int)
    assert isinstance(tuple_[2], int)

# Generated at 2022-06-23 18:11:23.877420
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyPackageRequirements,PyUnresolvedReferences
    import pytest

    # Values that should pass.

# Generated at 2022-06-23 18:11:28.641550
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Setup
    _dict = {'a': 1, 'b': 2}
    _namedtuple = namedtuple('NamedTuple', 'a b c')

    # Expected
    _expected = _namedtuple(1, 2)

    # Test
    assert to_namedtuple(_dict) == _expected



# Generated at 2022-06-23 18:11:39.803096
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(dict()) == to_namedtuple(OrderedDict()) == to_namedtuple(SimpleNamespace()) == namedtuple('NamedTuple', '')()
    assert to_namedtuple(dict(a=1)) == to_namedtuple(OrderedDict([('a', 1)])) == to_namedtuple(SimpleNamespace(a=1)) == namedtuple('NamedTuple', ['a'])(1)
    assert to_namedtuple(dict(a=1, b=2)) == to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == to_namedtuple(SimpleNamespace(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedt

# Generated at 2022-06-23 18:11:44.812559
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple([{}]) == [NamedTuple()]
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)


# Run unit tests if this is the main method
if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:11:56.224271
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    new_dic = to_namedtuple(dic)
    assert new_dic.a == dic['a']
    assert new_dic.b == dic['b']

    a_list = [{'a': 1, 'b': 2}]
    new_list = to_namedtuple(a_list)
    assert a_list[0]['a'] == new_list[0].a
    assert a_list[0]['b'] == new_list[0].b

    a_list = [2, 3, {'a': 1, 'b': 2}]
    new_list = to_namedtuple(a_list)
    assert a_list[0] == new_list[0]

# Generated at 2022-06-23 18:12:08.578845
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': {'c': 2}}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b.c == 2
    dic['_a'] = 3
    nt = to_namedtuple(dic)
    assert len(nt._fields) == 2
    assert nt.a == 1
    assert nt.b.c == 2
    dic = {'a': 1, '_a': 2}
    nt = to_namedtuple(dic)
    assert '_a' not in nt._fields
    assert nt.a == 1
    dic = {'c': 1, '_a': 2}
    nt = to_namedtuple(dic)
    assert '_a'

# Generated at 2022-06-23 18:12:19.295998
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = {
        'name': 'Bob',
        'age': 31,
        'children': ['Bob', 'Bobette'],
        'info': {
            'height': 1.91,
            'weight': 80,
        }
    }

    data_nt = to_namedtuple(data)
    assert data_nt.name == 'Bob'
    assert data_nt.age == 31
    assert data_nt.children == ['Bob', 'Bobette']
    assert data_nt.info.height == 1.91
    assert data_nt.info.weight == 80

    from collections import OrderedDict
    data_od = OrderedDict(name='Bob', age=31,
                          children=['Bob', 'Bobette'],
                          info={'height': 1.91, 'weight': 80})
    data

# Generated at 2022-06-23 18:12:28.991033
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj_dict: Mapping[str, Any] = {'a': 1, 'b': 2}
    obj_dict_2: Mapping[str, Any] = {'a': True, 'b': ('c', 'd', 'e')}
    obj_dict_3: Mapping[str, Any] = {'a': False, 'b': (True, 'd', True)}
    obj_list = [obj_dict, obj_dict_2, obj_dict_3]
    obj_sn = SimpleNamespace(**obj_dict)
    obj_sn_list = [obj_sn, obj_dict_2, obj_dict_3]
    obj_sn_list_2 = [obj_sn, obj_sn_list, obj_dict_3]
    obj_od = OrderedDict(**obj_dict)


# Generated at 2022-06-23 18:12:32.879123
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_dict = {'a': 1, 'b': 2}
    assert to_namedtuple(test_dict) == (1, 2)

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:12:35.229520
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic= {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:12:47.538658
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    dic = {'a': 1, 'b': 2}
    out: type(dic) = to_namedtuple(dic)
    assert len(out) == 2
    assert out.a == 1
    assert out.b == 2
    assert out['a'] == 1
    assert out['b'] == 2
    with pytest.raises(AttributeError):
        getattr(out, 'c')

    dic = {'a': 1, 'b': 2}
    out: type(dic) = to_namedtuple(dic)
    assert len(out) == 2
    assert out.a == 1
    assert out.b == 2
    assert out['a'] == 1
    assert out['b'] == 2

# Generated at 2022-06-23 18:12:56.975352
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from types import (
        SimpleNamespace,
    )
    from flutils.pprintutils import pformat_items
    from flutils.namedtupleutils import (
        to_namedtuple,
    )

    _AllowedTypes = Union[
        List,
        Mapping,
        NamedTuple,
        SimpleNamespace,
        Tuple,
    ]


    # noinspection SpellCheckingInspection
    class _OrderedDict(OrderedDict):
        """Hack in order to work with MyPy."""
        # noinspection PyUnusedLocal,PyMethodMayBeStatic
        def __getitem__(self, key: Any) -> Any:
            return super(_OrderedDict, self).__getitem__(key)

        #

# Generated at 2022-06-23 18:13:07.737093
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'__str__': 1, 'b': 2}) == NamedTuple(b=2)
    assert to_namedtuple({'a.1': 1, 'b': 2}) == NamedTuple(b=2)
    assert to_namedtuple({'1': 1, 'b': 2}) == NamedTuple(b=2)

# Generated at 2022-06-23 18:13:17.916185
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    import types
    import unittest
    from flutils.validators import (
        validate_identifier,
    )

    # Valid string
    with self.subTest(msg="Valid string"):
        actual: Union[str, NamedTuple] = to_namedtuple('foo')
        self.assertEqual(actual, 'foo')

    # Valid List
    with self.subTest(msg="Valid List"):
        actual: Union[NamedTuple, List[int], str] = to_namedtuple([0,1,2,3])
        expected: List[int] = [0,1,2,3]
        self.assertEqual(actual, expected)

    # Valid Tuple

# Generated at 2022-06-23 18:13:27.144558
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import unittest
    import sys
    import os

    from collections import OrderedDict

    PACKAGE_PARENT = '..'
    SCRIPT_DIR = os.path.dirname(os.path.realpath(os.path.join(os.getcwd(), os.path.expanduser(__file__))))
    sys.path.append(os.path.normpath(os.path.join(SCRIPT_DIR, PACKAGE_PARENT)))

    from flutils.validators import validate_identifier

    class TestStringMethods(unittest.TestCase):

        def test_to_namedtuple_dict(self):
            dic = {'a': 1, 'b': 2}  # type: OrderedDict
            otd = OrderedDict({'a': 1, 'b': 2})
            n

# Generated at 2022-06-23 18:13:39.355372
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    """Unit test for function to_namedtuple"""
    # pylint: disable=too-many-branches,too-many-statements,too-many-locals
    from flutils.textutils import random_string
    from flutils.validators import is_identifier, is_valid_identifier

    def is_namedtuple(obj: Any) -> bool:
        # type: (Any) -> bool
        """Check if object is a namedtuple.

        Args:
            obj: The object to be checked.

        Returns:
            :obj:`True` if the object is a namedtuple; :obj:`False` otherwise.
        """
        if hasattr(obj, '_fields'):
            return True
        return False


# Generated at 2022-06-23 18:13:51.258153
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Sequence
    from typing import Any
    import types
    from flutils.validators import validate_identifier

    assert isinstance(to_namedtuple([]), list)
    assert isinstance(to_namedtuple(()), tuple)
    assert isinstance(to_namedtuple(''), str)
    assert isinstance(to_namedtuple({1: 2}), tuple)
    assert isinstance(to_namedtuple(OrderedDict()), tuple)
    assert isinstance(to_namedtuple(OrderedDict()), tuple)
    assert isinstance(to_namedtuple({'a': 1}), tuple)

# Generated at 2022-06-23 18:14:04.259190
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    n1 = namedtuple('n1', 'a b c')(1, 2, 3)
    n2 = namedtuple('n2', 'a b c d')(1, 2, 3, 4)
    n3 = namedtuple('n3', 'a b c')(1, 2, 3)
    assert to_namedtuple(n1) == n1
    assert to_namedtuple(n2) == n2
    assert to_namedtuple(n3) == n3
    assert to_namedtuple({'a':1, 'b':2}) == n1
    assert to_namedtuple({'a':1, 'b':2, 'd':4}) == n2

# Generated at 2022-06-23 18:14:14.386834
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(('a', 'b', 'c')) == NamedTuple(a='a', b='b', c='c')
    assert to_namedtuple(OrderedDict()) == NamedTuple()
    assert to_namedtuple(OrderedDict([('a', 1)])) == NamedTuple(a=1)

    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to

# Generated at 2022-06-23 18:14:20.624829
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from doctest import testmod
    from flutils.namedtupleutils import to_namedtuple
    docs = [to_namedtuple]
    results = testmod(docs)
    num_failures = results.failed
    assert not num_failures


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:14:30.355005
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    tup = to_namedtuple(dic)
    assert tup.a == 1

    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    tup = to_namedtuple(dic)
    assert tup.a == 1

    dic = {'c': 1, 'b': 2}
    tup = to_namedtuple(dic)
    assert tup.b == 2

    dic = SimpleNamespace(c=1, b=2)
    tup = to_namedtuple(dic)
    assert tup.b == 2
    assert tup.c == 1


# Generated at 2022-06-23 18:14:41.509160
# Unit test for function to_namedtuple
def test_to_namedtuple():
    expected = [
        'NamedTuple(',
        '    a=(',
        '        A(',
        '            a1=1,',
        '            a2=2,',
        '        ),',
        '        B(',
        '            b1=1,',
        '            b2=2,',
        '        ),',
        '    ),',
        '    b=1,',
        '    c=2,',
        '    d=3,',
        ')',
    ]

# Generated at 2022-06-23 18:14:51.304600
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from operator import attrgetter
    from typing import NamedTuple

    class MyNT(NamedTuple):
        id: int = 5
        name: str = 'id'


    d = {'a': 1, 'b': 2, 'c': 3}
    expected = MyNT(id=1, name='b')
    actual = to_namedtuple(d)
    assert expected == actual
    assert type(actual) == MyNT

    assert isinstance(actual, MyNT)

    d = OrderedDict({'a': 1, 'b': 2, 'c': 3})
    actual = to_namedtuple(d)
    assert expected == actual
    assert attrgetter('c', 'b', 'a')(actual) == (3, 2, 1)


# Generated at 2022-06-23 18:14:59.012160
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    from decimal import Decimal
    from typing import List, Optional, TypeVar, Union
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupledefs import BaseTest
    from flutils.namedtupledefs import NamedTupleDefs

    T = TypeVar('T', bound=BaseTest)  # noqa: N816

    def sort_results(objs: List[T],
                     key_func: Optional[callable] = None,
                     key_attr: Optional[str] = None) -> List[T]:
        """Helper to sort a list of objects by a particular attribute or given
        function and return the sorted list."""

# Generated at 2022-06-23 18:15:05.212265
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'_a': 1, 'b': 2}) == NamedTuple(b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == NamedTuple(a=1, b=2, c=3, d=4)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:15:17.221256
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Ensure to_namedtuple returns expected results."""
    # setup--------------------------
    namedtuple_class = namedtuple('NamedTuple', ['a', 'b'])
    namedtuple_instance = namedtuple_class(a=1, b=2)
    # test---------------------------
    # to_namedtuple(OrderedDict)
    odic: OrderedDict = OrderedDict()
    odic_keys = ['a', 'b']
    for key in odic_keys:
        odic[key] = key
    odic_ret = to_namedtuple(odic)
    assert odic_ret == namedtuple_instance
    # to_namedtuple(Mapping)
    m_ret = to_namedtuple(dict(a='a', b='b'))

# Generated at 2022-06-23 18:15:27.129729
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """"""
    import flutils.namedtupleutils as tntu
    # Test that non-allowed types raise an error
    dic = {'a':1, 'b':2}
    exp = tntu.NamedTuple(a=1, b=2)
    assert tntu.to_namedtuple(dic) == exp
    assert tntu.to_namedtuple(exp) == exp
    assert tntu.to_namedtuple([1, 2, dic]) == [1,2,tntu.NamedTuple(a=1, b=2)]
    assert tntu.to_namedtuple((1, 2, dic)) == (1, 2, tntu.NamedTuple(a=1, b=2))
    assert tntu.to_namedt

# Generated at 2022-06-23 18:15:37.737754
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = {'foo': 100, 'bar': [0, 1, 2, 3, 4], 'baz': {'bat': 'qux'}}
    expected = namedtuple('Expected', 'bar baz foo')(
        bar=[0, 1, 2, 3, 4],
        baz=namedtuple('Expected', 'bat')(bat='qux'),
        foo=100,
    )
    assert to_namedtuple(data) == expected
    nt_list = to_namedtuple([data,])
    assert isinstance(nt_list, list)
    assert isinstance(nt_list[0], NamedTuple)
    assert len(nt_list) == 1
    data = [data,]
    expected = [expected,]
    assert to_namedtuple(data) == expected
    assert to

# Generated at 2022-06-23 18:15:47.372123
# Unit test for function to_namedtuple
def test_to_namedtuple():

    a = OrderedDict([(1, 2), (3, 4)])
    b = to_namedtuple(a)

    assert b == (2, 4)

    a = {1: 2, 3: 4}
    b = to_namedtuple(a)

    assert b == (2, 4)

    a = SimpleNamespace(a=1, b=2, c=3)
    b = to_namedtuple(a)

    assert b == (1, 2, 3)

    a = {1: 2, 3: SimpleNamespace(a=1, b=2)}
    b = to_namedtuple(a)

    assert b == (2, (1, 2))


# Generated at 2022-06-23 18:15:58.614008
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.miscutils import str_representation
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testutils import make_temporary_directory, StrRepr

    str_representation['to_namedtuple'] = StrRepr(
        'flutils.namedtupleutils.to_namedtuple',
        'to_namedtuple',
        'flutils.namedtupleutils'
    )
    str_representation['_to_namedtuple'] = StrRepr(
        'flutils.namedtupleutils._to_namedtuple',
        '_to_namedtuple',
        'flutils.namedtupleutils'
    )


# Generated at 2022-06-23 18:16:07.803449
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # to_namedtuple - TypeError
    try:
        to_namedtuple(5)
    except TypeError as err:
        assert str(err) == (
            "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
            "got: (%r) 5"
        )

    # to_namedtuple - dict
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert nt == ('b', 2)

    # to_namedtuple - OrderedDict
    ord_dic = OrderedDict(dic)
    nt = to_namedtuple(ord_dic)
    assert isinstance(nt, NamedTuple)

# Generated at 2022-06-23 18:16:17.134872
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print("Testing to_namedtuple...")
    dic = {'a': 1, 'b': 2}
    named = to_namedtuple(dic)
    assert hasattr(named, 'a')
    assert hasattr(named, 'b')
    assert named.a == 1
    assert named.b == 2
    dic = {'a': {'b': 1, 'c': 2}, 'd': 3}
    named = to_namedtuple(dic)
    assert hasattr(named, 'a')
    assert hasattr(named, 'd')
    assert named.d == 3
    assert hasattr(named.a, 'b')
    assert hasattr(named.a, 'c')
    assert named.a.b == 1
    assert named.a.c == 2