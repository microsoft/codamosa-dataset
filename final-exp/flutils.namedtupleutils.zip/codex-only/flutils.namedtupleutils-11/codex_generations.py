

# Generated at 2022-06-23 18:06:19.504615
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        """Unit test for function to_namedtuple"""

        def test_sn_1(self):
            snt = SimpleNamespace(
                a=SimpleNamespace(a=1, b=2, c=3),
                b=SimpleNamespace(d=4, e=5, f=6)
            )
            nt = to_namedtuple(snt)
            self.assertEqual(dir(nt), ['a', 'b'])
            self.assertEqual(dir(getattr(nt, 'a')), ['a', 'b', 'c'])
            self.assertEqual(dir(getattr(nt, 'b')), ['d', 'e', 'f'])


# Generated at 2022-06-23 18:06:29.337590
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pytest import raises
    from collections import OrderedDict
    from collections.abc import Sequence
    from types import SimpleNamespace

    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']

    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')

    assert to_namedtuple(OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
    ])) == OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
    ])


# Generated at 2022-06-23 18:06:38.523869
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = OrderedDict(a=1, b=2)
    assert to_namedtuple(dic) == dic
    assert dic == OrderedDict(a=1, b=2)

    lst = [OrderedDict(a=1, b=2), OrderedDict(a=2, b=3)]
    assert to_namedtuple(lst) == lst
    assert lst == [OrderedDict(a=1, b=2), OrderedDict(a=2, b=3)]

    lst = [dict(a=1, b=2), dict(a=2, b=3)]
    assert to_namedtuple(lst) == [NamedTuple(a=1, b=2), NamedTuple(a=2, b=3)]

    t

# Generated at 2022-06-23 18:06:47.985759
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from typing import (
        Dict,
        List,
        NamedTuple,
        Tuple,
    )
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-23 18:06:53.312507
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    dic = SimpleNamespace(
        a=OrderedDict(
            x=1,
            y=2,
        ),
        b=OrderedDict(
            z=3,
            w=4,
        ),
    )
    expected = SimpleNamespace(
        a=SimpleNamespace(
            x=1,
            y=2,
        ),
        b=SimpleNamespace(
            w=4,
            z=3,
        ),
    )
    assert to_namedtuple(dic) == expected

# Generated at 2022-06-23 18:07:00.763915
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        def test_no_args(self):
            # type: () -> None
            """Test with no arguments passed to the function.

            Test that an error is raised when no arguments are given to the
            function.

            """
            with self.assertRaises(TypeError):
                to_namedtuple()

        def test_invalid_arg_type(self):
            # type: () -> None
            """Test a non-convertible type is given.

            Test that an error is raised when the given argument is not of
            a valid type to be converted to a NamedTuple.

            """
            with self.assertRaises(TypeError):
                to_namedtuple(b"0xFF")


# Generated at 2022-06-23 18:07:12.503677
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def test_helper(
            obj: Any,
            exp_attrs: List[Any],
            exp_vals: List[Any]
    ) -> None:
        """Test :func:`~flutils.namedtupleutils.to_namedtuple`."""
        actual = to_namedtuple(obj)
        if hasattr(obj, '_fields'):
            obj = cast(NamedTuple, obj)
            for exp_attr, exp_val in zip(exp_attrs, exp_vals):
                if hasattr(exp_val, 'capitalize'):
                    attr = getattr(actual, exp_attr)
                    assert attr is exp_val.replace('ORIG', 'ACTL')
                else:
                    attr = getattr(actual, exp_attr)

# Generated at 2022-06-23 18:07:17.793858
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == (1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2}, 3]) == ([NamedTuple(a=1, b=2), 3],)

# Generated at 2022-06-23 18:07:22.011332
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    expected = "NamedTuple(a=1, b=2)"
    assert repr(to_namedtuple(obj)) == expected

# Generated at 2022-06-23 18:07:32.369044
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import unittest.mock
    import unittest.mock as um

    um.patch.object(__name__ + '.validate_identifier', return_value=True).start()

    d1 = {'a': 1, 'b': 2}
    # noinspection PyUnresolvedReferences
    assert to_namedtuple(d1) == d1

    d2 = {'a': 1, 'b': 2}
    d2['_a'] = 3
    # noinspection PyUnresolvedReferences
    assert to_namedtuple(d2) == d2

    l1 = [1, 2, 3]
    l1t = tuple(l1)
    # noinspection PyUnresolvedReferences
    assert to_namedtuple(l1) == l1
    # noinspection PyUnresolved

# Generated at 2022-06-23 18:07:44.678033
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test list/tuple conversion
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple([{'a': 1}]) == [NamedTuple(a=1)]
    assert to_namedtuple(([{'a': 1}],)) == (NamedTuple(a=1),)
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple(([{'a': 1, 'b': 2}],)) == (NamedTuple(a=1, b=2),)

    # Test OrderedDict conversion

# Generated at 2022-06-23 18:07:53.094977
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json

    def conv(in_: Any) -> Any:
        return to_namedtuple(in_)

    def _assert_equal(left: Any, right: Any) -> None:
        """Test if the two items are equal (recursively).

        The items are recursively compared.  This means if a dictionary
        contains another dictionary, they will be compared recursively.

        Args:
            left: The left item to compare.
            right: The right item to compare.
        """
        # noinspection PyProtectedMember
        if hasattr(left, '_fields'):
            assert hasattr(right, '_fields')
            assert left._fields == right._fields

# Generated at 2022-06-23 18:07:57.470356
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(
        [
            'a',
            'b',
            {'c': 3, 'd': 4},
        ]
    ) == [
        'a',
        'b',
        NamedTuple(c=3, d=4),
    ]



# Generated at 2022-06-23 18:08:00.810171
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    expected_result = {'a': 1, 'b': 2}
    assert result == expected_result


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:08:12.019316
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Simple unit test for to_namedtuple"""

    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    nt1 = to_namedtuple(dic)
    assert nt1.a == dic['a']
    assert nt1.b == dic['b']
    assert (nt1.a, nt1.b) == (dic['a'], dic['b'])

    nested_dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    nt2 = to_namedtuple(nested_dic)
    assert nt2.a == nested_dic['a']
    assert nt

# Generated at 2022-06-23 18:08:24.941734
# Unit test for function to_namedtuple
def test_to_namedtuple():

    o = [
        {'a': {'b': 1}, 'b': {'a': 2}},
        {1: {'a': 1}},
    ]

    out = to_namedtuple(o)

    assert isinstance(out, list)
    assert len(out) == 2

    expected = [
        {'a': {'b': 1}, 'b': {'a': 2}},
        {1: {'a': 1}},
    ]

    for i, item in enumerate(out):
        assert isinstance(item, dict)

        assert dict(item) == expected[i]

    o = (
        {'a': {'b': 1}, 'b': {'a': 2}},
        {1: {'a': 1}},
    )

    out = to_namedtuple

# Generated at 2022-06-23 18:08:30.244135
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    tup = (1, 2)
    lst = [1, 2]
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dic) == to_namedtuple(OrderedDict(dic))
    assert to_namedtuple(dic) == to_namedtuple(SimpleNamespace(**dic))
    assert to_namedtuple(tup) == to_namedtuple(list(tup))
    assert to_namedtuple(tup) == NamedTuple(1, 2)
    assert to_namedtuple(lst) == NamedTuple(1, 2)

# Generated at 2022-06-23 18:08:42.995947
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test to_namedtuple
    # Most of the tests are handled by test_namedtupleutils_convert
    # This is just a few extra tests for to_namedtuple
    # There's a small duplication of tests.  But it's better to keep it
    # this way.

    from collections import OrderedDict
    from types import SimpleNamespace

    # Test some bad types
    exc_data = [
        1234,
        False,
        'abc',
        None,
        set(),
        frozenset(),
        type(None),
    ]
    for item in exc_data:
        with pytest.raises(TypeError):
            # noinspection PyTypeChecker
            to_namedtuple(item)

    # Test list
    obj = [{'a': 1}]
    assert to_

# Generated at 2022-06-23 18:08:53.770495
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    list_obj = [{'a': 1}, {'b': 2}, {'c': 3}]
    named_obj = to_namedtuple(list_obj)
    assert isinstance(named_obj, list)
    for obj in named_obj:
        assert isinstance(obj, NamedTuple)
    assert named_obj[0] == cast(NamedTuple, named_obj[0])
    assert named_obj[0].a == list_obj[0]['a']
    assert named_obj[1] == cast(NamedTuple, named_obj[1])
    assert named_obj[1].b == list_obj[1]['b']
    assert named_obj[2] == cast(NamedTuple, named_obj[2])

# Generated at 2022-06-23 18:09:02.222583
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for namedtupleutils.to_namedtuple"""
    from unittest import TestCase

    class TestToNamedTuple(TestCase):
        def test_empty_tuple(self):
            obj = ()
            nt = to_namedtuple(obj)
            self.assertEqual(0, len(nt))

        def test_empty_list(self):
            obj = []
            nt = to_namedtuple(obj)
            self.assertEqual(0, len(nt))

        def test_empty_dict(self):
            obj = {}
            nt = to_namedtuple(obj)
            self.assertEqual(0, len(nt))

        def test_empty_simple_namespace(self):
            obj = SimpleNamespace()
            nt = to_namedt

# Generated at 2022-06-23 18:09:11.257415
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Tests to_namedtuple function.
    """

    # Testing a dictionary
    dic = {'a': 1, 'b': 2}
    new_dic = to_namedtuple(dic)
    assert isinstance(new_dic, namedtuple)
    assert new_dic.a == 1
    assert new_dic.b == 2

    # Testing a OrderedDict
    from collections import OrderedDict
    od = OrderedDict(a=1,b=2)
    new_od = to_namedtuple(od)
    assert new_od.a == 1
    assert new_od.b == 2

    # Testing a namespaces
    from types import SimpleNamespace
    n = SimpleNamespace(a=1, b=2)
    new_ns = to_named

# Generated at 2022-06-23 18:09:23.219103
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    dic = {'a': {'b': 2}, 'd': None}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert isinstance(out.a, NamedTuple)
    assert isinstance(out.d, type(None))
    assert out.a.b == 2
    assert out.d is None

    dic = {'a': {'b': dic}, 'd': None}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)

# Generated at 2022-06-23 18:09:34.809749
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:09:45.797128
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Sequence
    from types import SimpleNamespace
    from nt import NT

    class SomeClass(object):
        a = 1
        b = 2

    dic: Mapping = {'a': 1, 'b': 2, 'c': '3'}
    out = to_namedtuple(dic)
    assert isinstance(out, NT)

    dic = {'a': 1, 'b': 2, '3': 'C'}
    out = to_namedtuple(dic)
    assert isinstance(out, NT)

    obj = SimpleNamespace(a=1, b=2, c='3')
    out = to_namedtuple(obj)
    assert isinstance(out, NT)


# Generated at 2022-06-23 18:09:54.710348
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # List of dictionaries
    list_of_dicts = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    output_dicts = to_namedtuple(list_of_dicts)
    dict_type = type(output_dicts[0])
    assert isinstance(output_dicts[0], dict_type)
    assert output_dicts[0][0] == 1
    assert output_dicts[0][1] == 2
    assert output_dicts[1][0] == 3
    assert output_dicts[1][1] == 4

    # Dict of tuples

# Generated at 2022-06-23 18:10:06.395728
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators.funcs import is_namedtuple

    dic = {'a': 1, 'b': 2}
    assert is_namedtuple(to_namedtuple(dic))

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert is_namedtuple(to_namedtuple(dic))

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}
    assert is_namedtuple(to_namedtuple(dic))


# Generated at 2022-06-23 18:10:18.257658
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'A': 'a'}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'A': 1, 'b': 2}) == NamedTuple(b=2)
    assert to_namedtuple({1: 1, 'b': 2}) == NamedTuple(b=2)
    assert to_namedtuple({'1': 1, 'b': 2}) == NamedTuple(b=2)
    assert to_namedtuple({'_1': 1, 'b': 2}) == NamedTuple(b=2)

# Generated at 2022-06-23 18:10:30.013498
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""

    from collections import deque

    from hypothesis.strategies import (
        builds,
        composite,
        dictionaries,
        fixed_dictionaries,
        floats,
        integers,
        lists,
        none,
        one_of,
        recursive,
        sampled_from,
        sets,
        text,
        tuples,
    )
    from hypothesis.stateful import (
        Bundle,
        RuleBasedStateMachine,
        rule,
    )
    from hypothesis.strategies import (
        SearchStrategy,
    )
    from mypy_extensions import TypedDict
    from mypy_extensions import TypedList

    import pytest


# Generated at 2022-06-23 18:10:35.034726
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    od = OrderedDict()
    od['a'] = 1
    od['b'] = 2
    assert to_namedtuple(od).a == 1
    assert to_namedtuple(od).b == 2
    assert to_namedtuple(od) == cast(NamedTuple, od)
    assert to_namedtuple(list(od)).a == 1
    assert to_namedtuple(list(od)).b == 2
    assert to_namedtuple(list(od)) == cast(NamedTuple, od)
    assert to_namedtuple(tuple(od)).a == 1
    assert to_namedtuple(tuple(od)).b == 2
    assert to

# Generated at 2022-06-23 18:10:43.380149
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(tuple()) == tuple()
    assert type(to_namedtuple(tuple())) == tuple
    assert type(to_namedtuple([])) == list
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert type(to_namedtuple([1, 2, 3])[0]) == int
    assert type(to_namedtuple([1, 2, 3])[1]) == int
    assert type(to_namedtuple([1, 2, 3])[2]) == int
    assert to_namedtuple([1, 2, 3])[0] == 1
    assert to_namedtuple([1, 2, 3])[1] == 2

# Generated at 2022-06-23 18:10:54.095342
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyTypeChecker
    dic: Mapping = {'a': 1, 'b': 2, '_c': 3, '4': 4}
    # noinspection PyTypeChecker
    keys: List[str] = ['a', 'b', '_c', '4']

    # noinspection PyTypeChecker
    ordered_dic: OrderedDict = OrderedDict.fromkeys(keys)
    ordered_dic.update(dic)

    # noinspection PyTypeChecker
    ordered_namespace: SimpleNamespace = SimpleNamespace(**ordered_dic)

    # noinspection PyTypeChecker
    ordered_tuple: NamedTuple = cast(NamedTuple, tuple(ordered_dic.values()))

    # noinspection PyTypeChecker
    ordered_list

# Generated at 2022-06-23 18:11:00.525282
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')

# Generated at 2022-06-23 18:11:04.517624
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections.abc import Sequence
    def sort_as_identifier(value):
        return [v for v in sorted(value, key=lambda i: (i.replace('_', '') if i.startswith('_') else i))]
    def test_to_namedtuple_iterable(dic, value, cls):
        out = to_namedtuple(dic)
        assert sort_as_identifier(value) == sort_as_identifier(out._fields)
        assert len(value) == len(out._fields)
        assert cls(a=1, b=2) == out
    def test_to_namedtuple_mapping(dic, value, keep_order, cls):
        out = to_namedtuple(dic)
        assert sort_

# Generated at 2022-06-23 18:11:13.336052
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import Mock
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils._namedtupleutils import _to_namedtuple
    from typing import List
    from random import shuffle
    from collections import (
        OrderedDict,
    )
    from collections.abc import Mapping
    from unittest.mock import Mock

    dic_1: Mapping[str, Any] = {'a': 1, 'b': 2}
    expected = [
        Mock(
            a=1,
            b=2,
        ),
        (1, 2)
    ]
    out = to_namedtuple(dic_1)
    assert isinstance(out, OrderedDict)
    assert out in expected
    out = _to_namedt

# Generated at 2022-06-23 18:11:23.670689
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    out: NamedTuple = to_namedtuple(dic)
    assert out.a == dic['a']
    assert out.b == dic['b']

    lst = [dic, dic.copy()]
    out = to_namedtuple(lst)
    assert len(out) == 2
    assert out[0].a == out[1].a
    assert out[0].b == out[1].b
    assert out[0].a == dic['a']
    assert out[0].b == dic['b']


# Generated at 2022-06-23 18:11:32.944291
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test the function to_namedtuple is callable
    assert callable(to_namedtuple)
    # Test the function to_namedtuple raises TypeError with invalid type
    with pytest.raises(TypeError):
        to_namedtuple(1)
    # Test the function to_namedtuple raises SyntaxError with invalid key
    with pytest.raises(SyntaxError):
        to_namedtuple({1: 1})
    # Test the function to_namedtuple raises SyntaxError with invalid key
    with pytest.raises(SyntaxError):
        to_namedtuple({'a b': 1})
    # Test the function to_namedtuple returns a namedtuple with valid dict

# Generated at 2022-06-23 18:11:43.876080
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_dict = {'a': 1, 'b': 2}
    result = to_namedtuple(test_dict)
    assert result.a == 1
    assert result.b == 2

    test_dict = {'a': 1, 'b': [1, 2, 3], 'c': {'d': 4, 'e': 5}}
    result = to_namedtuple(test_dict)
    assert result.a == 1
    assert result.b[0] == 1
    assert result.c.d == 4
    assert result.c.e == 5

    test_dict = {'a': 1, 'b': [1, 2, 3, {'c': 5, 'd': 6}]}
    result = to_namedtuple(test_dict)
    assert result.a == 1

# Generated at 2022-06-23 18:11:49.080192
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': [{'b': 2}]}
    expected = namedtuple('NamedTuple', ['a'])(
        a=[_to_namedtuple({'b': 2})]
    )
    result = to_namedtuple(dic)
    if result != expected:
        raise AssertionError('Expected: %s, got: %s' % (expected, result))



# Generated at 2022-06-23 18:11:59.232745
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils
    obj = {'a': 1, 'b': 2}
    assert flutils.namedtupleutils.to_namedtuple(obj) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    obj = dict()
    obj['a'] = []
    assert flutils.namedtupleutils.to_namedtuple(obj) == namedtuple('NamedTuple', ['a'])(a=[])
    obj = dict()
    obj['a'] = dict()
    obj['a']['b'] = dict()
    obj['a']['b']['c'] = dict()
    obj['a']['b']['c']['d'] = 1
    assert flutils.namedtupleutils.to_namedtuple

# Generated at 2022-06-23 18:12:11.663374
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Dict
    from collections import OrderedDict
    dic: Dict[str, Any] = {
        'a': 1,
        'b': 2,
        'c': {'d': 4, 'e': 5},
    }
    nt: NamedTuple = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c.d == 4
    assert nt.c.e == 5
    dic = OrderedDict(
        [
            ('a', 1),
            ('b', 2),
            ('c', {'d': 4, 'e': 5}),
        ]
    )
    nt = to_namedtuple(dic)
    assert nt.a == 1

# Generated at 2022-06-23 18:12:14.551241
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)


# Generated at 2022-06-23 18:12:25.844830
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Base cases
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({"a": 1, "b": 2, "c": 3}) == \
        NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({"a": 1, "b": 2, "c": 3}) != \
        (1, 2, 3)
    assert to_namedtuple({"a": 1, "b": 2, "c": 3}) != \
        {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-23 18:12:36.898125
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from datetime import datetime
    import random
    import string

    class TestToNamedTuple(TestCase):
        def test_to_namedtuple(self):
            data = {
                'a': 1,
                'b': '2',
                'c': {'d': 4}
            }
            obj = to_namedtuple(data)
            self.assertEqual(obj.a, 1)
            self.assertEqual(obj.b, '2')
            self.assertEqual(obj.c.d, 4)
            self.assertEqual(obj, NamedTuple(a=1, b='2', c=NamedTuple(d=4)))
            self.assertEqual(obj.c, NamedTuple(d=4))


# Generated at 2022-06-23 18:12:42.170416
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({"a": 1, "b": 2}) == (1, 2)


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS, verbose=True)

# Generated at 2022-06-23 18:12:53.099203
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _dic = {'a': 1, 'b': 2}
    _exp = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    _res = to_namedtuple(_dic)
    assert _exp == _res

    _ord = OrderedDict()
    _ord['b'] = 2
    _ord['a'] = 1
    _res = to_namedtuple(_ord)
    assert _exp == _res

    _sn = SimpleNamespace(a=1, b=2)
    _res = to_namedtuple(_sn)
    assert _exp == _res

    _lst = list(_dic.keys())
    _res = to_namedtuple(_lst)
    assert _exp != _res
    assert isinstance(_res, list)

# Generated at 2022-06-23 18:13:04.378074
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import sentinel
    from collections import namedtuple
    from collections.abc import Sequence

    mock_iterable = [{'a': 1}, {'b': 2}]

    mock_namedtuple = namedtuple('MockNamedTuple', ['a', 'b'])

    mock_nested_dict = {'a': {'b': {'c': 5}}}

    mock_nested_namedtuple = namedtuple('MockNestedNamedTuple', 'a')

    mock_nested_namedtuple.a = mock_namedtuple(1, 2)

    def test_iterables() -> None:
        mock_list = [{'a': 1}, {'b': 2}, sentinel.NOT_DICT]


# Generated at 2022-06-23 18:13:14.737361
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)

    dic = {'a': 1, 'b': [2, 3]}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=[2, 3])

    dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=namedtuple('NamedTuple', ('c', 'd'))(c=3, d=4))



# Generated at 2022-06-23 18:13:16.251142
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:13:20.974052
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dict_ = {'a': 1, 'b': 2}
    expected = OrderedDict([('a', 1), ('b', 2)])
    assert expected == to_namedtuple(dict_)._asdict()

    dict_ = {'a': 1, 'b': {'c': 3, 'd': 4}}
    expected = OrderedDict([('a', 1), ('b', OrderedDict([('c', 3), ('d', 4)]))])
    assert expected == to_namedtuple(dict_)._asdict()

    ord_dic = OrderedDict()
    ord_dic['a'] = 1
    ord_dic['b'] = 2
    expected = OrderedDict([('a', 1), ('b', 2)])
    assert expected == to

# Generated at 2022-06-23 18:13:31.476110
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from collections import OrderedDict

    # Simple example:
    dic = {'a': 1, 'b': 2}
    # noinspection SpellCheckingInspection,PyCallByClass,PyTypeChecker
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    # Nested example:
    dic = OrderedDict([('a', OrderedDict([('b', OrderedDict([('c', 3)]))]))])
    # noinspection SpellCheckingInspection,PyCallByClass,PyTypeChecker
    nt = to_namedtuple(dic)
    assert nt.a.b.c == 3

    #

# Generated at 2022-06-23 18:13:41.875463
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import Sequence
    from collections.abc import Sequence as SequenceABC

    # noinspection PyUnusedLocal
    nt_repr = 'NamedTuple(a=1, b=2)'
    nt_repr_sort = 'NamedTuple(a=1, b=2)'
    nt_repr_empty = 'NamedTuple()'
    nt_repr_list = 'NamedTuple(a=[1, 2])'
    nt_repr_dict = 'NamedTuple(a=NamedTuple(b=1, c=2))'
    d1 = {'a': 1, 'b': 2}
    d2 = {'b': 2, 'a': 1}
    od1 = OrderedDict(d1)

# Generated at 2022-06-23 18:13:52.888455
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    # Sequence tests
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    # Mapping tests
    test_dict = {'a': 1, 'b': 2}
    assert to_namedtuple(test_dict) == NamedTuple(a=1, b=2)
    test_odict = OrderedDict(a=1, b=2)
    assert to_namedtuple(test_odict) == NamedTuple(a=1, b=2)
    # SimpleNamespace
    test_

# Generated at 2022-06-23 18:14:05.272970
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from flutils.validators import validate_syntax
    from unittest import TestCase
    from unittest.mock import (
        call,
        MagicMock,
        patch,
    )

    from flutils.namedtupleutils import to_namedtuple


    @singledispatch
    def convert_to_namedtuple(obj):
        raise TypeError("No default handler")

    # noinspection PyUnusedFunction,PyShadowingNames,Mypy
    @convert_to_namedtuple.register(Mapping)
    def _(obj):
        keys = []
        for key in obj.keys():
            if hasattr(key, 'capitalize'):
                key = cast(str, key)

# Generated at 2022-06-23 18:14:15.330523
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    import unittest

    class _TestToNamedTuple(unittest.TestCase):
        def test__to_namedtuple(self):
            def assert_nt_returned(
                    data,
                    expected_fields,
                    expected_values,
                    msg=None
            ):
                with self.subTest(data=data):
                    if type(data) is dict:
                        data_type = 'dict'
                    else:
                        data_type = type(data).__name__
                    nonlocal msg
                    if not msg:
                        msg = 'data arg: {!r}'.format(data_type)
                    fields, values = assert_nt_returned.get_fields_values(
                        data,
                        expected_fields,
                        expected_values,
                        msg
                    )
                    self.assertCount

# Generated at 2022-06-23 18:14:27.184163
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    import json
    from flutils.namedtupleutils import to_namedtuple

    dct = {"Name": "Ed", "City": "Seattle",
           "Cake": None, "Age": 55, "Cars": [{"Model": "BMW 230", "mpg": 27.5}, 
                                             {"Model": "Ford Edge", "mpg": 24.1}]}

    # Act
    nt = to_namedtuple(dct)

    # Assert
    assert nt.Name == dct["Name"]
    assert json.dumps(dct, sort_keys=True) ==\
        json.dumps(dict(nt._asdict()), sort_keys=True)


# Generated at 2022-06-23 18:14:33.248569
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    import operator
    import types
    import pytest

    # Test immutable types
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple('hello') == 'hello'
    assert to_namedtuple(True) is True
    assert to_namedtuple(False) is False
    assert to_namedtuple(None) is None

    # Test simple tuple, list
    data = (1, (2, 3))
    res = to_namedtuple(data)
    assert isinstance(res, collections.namedtuple('NamedTuple', '0 1'))
    assert res._fields == ('0', '1')
    assert res[0] == 1

# Generated at 2022-06-23 18:14:42.425539
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.miscutils import randstr
    from flutils.testutils import raises

    # Test None
    assert_true = (to_namedtuple(None) is None)
    assert assert_true

    # Test dict Input
    dict_in = {'a': 1, 'b': 2, 'c': {'d': 1, 'e': 2}}
    dict_out = to_namedtuple(dict_in)
    assert dict_out.a == dict_in['a']
    assert dict_out.b == dict_in['b']
    assert dict_out.c.d == dict_in['c']['d']
    assert dict_out.c.e == dict_in['c']['e']

    # Test int Input
    assert to_namedtuple(1) == 1

    # Test str Input

# Generated at 2022-06-23 18:14:53.680209
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from tests.tools import assert_items_equal
    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import to_namedtuple
    assert_items_equal(
        to_namedtuple(['a', 'b', 'c']),
        ('a', 'b', 'c')
    )
    assert_items_equal(
        to_namedtuple([1, 2]),
        (1, 2)
    )
    assert_items_equal(
        to_namedtuple({'a': 1, 'b': 2}),
        NamedTuple(a=1, b=2)
    )

# Generated at 2022-06-23 18:15:02.945871
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(OrderedDict()) == NamedTuple(())
    assert to_namedtuple(dict()) == NamedTuple(())
    assert to_namedtuple(tuple()) == NamedTuple(())
    assert to_namedtuple(SimpleNamespace()) == NamedTuple(())
    assert to_namedtuple(list()) == []
    assert to_namedtuple('') == ''
    assert to_namedtuple(123) == 123

# Generated at 2022-06-23 18:15:15.356569
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    d = {'a': 1, 'b': 2}
    x = to_namedtuple(d)
    assert x.a == 1
    assert x.b == 2
    o = OrderedDict(d)
    assert to_namedtuple(o) == x
    s = SimpleNamespace(**d)
    assert to_namedtuple(s) == x
    n = namedtuple('n', 'a b')(*d.values())
    assert to_namedtuple(n) == x
    d2 = {'c': 3}
    n2 = namedtuple('n', 'c')(c=3)
    d3 = {**d, **d2}
    d4 = OrderedDict(d3)

# Generated at 2022-06-23 18:15:25.978652
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(()) == ()
    assert to_namedtuple([]) == []
    assert to_namedtuple({}) == ()

    assert to_namedtuple((1,)) == (1,)
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple({1: 1}) == (1,)

    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple({1: 1, 2: 2}) == (1, 2)

    assert to_namedtuple({1: {1: 1}}) == (1,)
    assert to_namedtuple({1: {1: 1, 2: 2}}) == (1, 2)
    assert to_namedt

# Generated at 2022-06-23 18:15:36.883245
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import NamedTuple

    assert to_namedtuple(None) is None
    assert to_namedtuple(True) is True
    assert to_namedtuple(False) is False
    assert to_namedtuple(b'Bytes') == b'Bytes'
    assert to_namedtuple(1) == 1
    assert to_namedtuple(0) == 0
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple(0.0) == 0.0
    assert to_namedtuple('str') == 'str'
    assert to_namedtuple('') == ''

    c = namedtuple('c', ['a', 'b', 'c'])(1, 2, 3)
    d = to_namedtuple(c)
    e

# Generated at 2022-06-23 18:15:41.870506
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple((('a', 1), ('b', 2))) == namedtuple('NamedTuple', 'a b')(1, 2)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:15:50.832734
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Test the to_namedtuple function'''
    assert to_namedtuple(
        {'a': 1, 'b': {'c': 3, 'd': 4}}
    ) == NamedTuple(a=1, b=NamedTuple(c=3, d=4))
    assert to_namedtuple(
        {'b': {'c': 3, 'd': 4}, 'a': 1}
    ) == NamedTuple(a=1, b=NamedTuple(c=3, d=4))
    assert to_namedtuple(
        OrderedDict([('b', {'c': 3, 'd': 4}), ('a', 1)])
    ) == NamedTuple(b=NamedTuple(c=3, d=4), a=1)
    assert to_named

# Generated at 2022-06-23 18:15:59.835799
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the ``to_namedtuple`` function.
    """
    class MyClass:
        pass
    class MySubClass(MyClass):
        pass

# Generated at 2022-06-23 18:16:08.428332
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test = {'a': 1, 'b': 2}
    out = to_namedtuple(test)
    assert out.a == 1
    assert out.b == 2
    assert out.__getattribute__('a') == 1
    assert out.__getattribute__('b') == 2
    test = {'a': 1, 'b': 2, '_c': 3}
    out = to_namedtuple(test)
    assert out.a == 1
    assert out.b == 2
    assert out.__getattribute__('a') == 1
    assert out.__getattribute__('b') == 2
    test = {'a': 1, 'b': 2, 'c_': 3}
    out = to_namedtuple(test)
    assert out.a == 1
    assert out.b == 2