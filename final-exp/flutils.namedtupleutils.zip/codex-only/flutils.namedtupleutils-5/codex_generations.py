

# Generated at 2022-06-23 18:06:16.550494
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from random import sample
    from string import (
        ascii_letters,
        digits,
    )
    from types import SimpleNamespace
    from unittest.mock import patch
    from flutils.namedtupleutils import to_namedtuple

    chars = ascii_letters + digits
    arg_len = 5
    all_keys = sample(chars, arg_len)
    values = list(range(1, arg_len + 1))
    all_vals = {}
    for key, val in zip(all_keys, values):
        all_vals[key] = val
    named_tuple = namedtuple('namedtuple_test', all_keys)

# Generated at 2022-06-23 18:06:25.006976
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == (1, 2)

    dic = {'a': 1, 'b': {'c': 2}}
    assert to_namedtuple(dic) == (1, (2,))

    dic = {'1': 1, '2': 2}
    assert to_namedtuple(dic) == (1, 2)

    dic = {'a': [{'b': 1, 'c': 2}]}
    assert to_namedtuple(dic) == (((1, 2),),)



# Generated at 2022-06-23 18:06:35.005104
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == \
        namedtuple('NamedTuple', ['a', 'b', 'c'])(1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == \
        namedtuple('NamedTuple', ['b', 'a', 'c'])(2, 1, 3)

# Generated at 2022-06-23 18:06:41.827842
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from copy import copy
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    dic_orig = copy(dic)
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', 'a b'))
    assert isinstance(nt, NamedTuple)
    assert dic_orig == dic
    assert len(dic) == 2
    assert len(dic_orig) == 2
    assert dic == {'a': 1, 'b': 2}
    assert nt == (1, 2)
    assert nt.a == 1
    assert nt.b == 2


# Generated at 2022-06-23 18:06:49.648042
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    # noinspection PyShadowingBuiltins
    list = [
        "one",
        {
            "a": 1,
            "b": 2,
        },
        [
            "one",
            "two",
            {
                "a": 1,
                "b": 2,
            },
        ],
    ]

    with pytest.raises(TypeError) as err:
        _to_namedtuple(list)
    assert "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (str) one" in str(err.value)

    out = to_namedtuple(list)
    assert isinstance(out, list)
    assert out[0] == "one"

# Generated at 2022-06-23 18:06:58.445937
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import Mapping, Sequence
    from collections.abc import Sequence as SequenceABC
    from types import SimpleNamespace
    from typing import (
        Any,
        Container,
        Dict,
        Iterable,
    )
    from flutils.typingutils import has_dunder_iter
    from flutils.validators import (
        validate_dict,
        validate_list,
        validate_tuple,
    )
    from .testutils import (
        dummy_decorator,
        instance_exists,
    )

    # noinspection PyUnusedLocal,PyShadowingBuiltins
    def to_namedtuple(
            obj: Any,
            _started: bool = False
    ) -> Any:
        return _to_namedtuple(obj, _started=_started)

    # noinspection PyRed

# Generated at 2022-06-23 18:07:09.896599
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)

    dic = {'a': 1, 'b': [2, 3]}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, [2, 3])

    dic = {'a': 1, 'b': [{2: 3}]}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(
        1,
        [namedtuple('NamedTuple', '2')(3)],
    )

   

# Generated at 2022-06-23 18:07:13.160611
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == dic['a']
    assert out.b == dic['b']


if __name__ == '__main__':
    exit(test_to_namedtuple())

# Generated at 2022-06-23 18:07:25.238779
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(tuple([1, 2, 3])) == (1, 2, 3)
    assert to_namedtuple(OrderedDict([('z', 1), ('a', 2), ('b', 3)])) == NamedTuple(z=1, a=2, b=3)
    assert to_namedtuple(OrderedDict([('z', 1), ('a', 2), ('b', 3)])) != NamedTuple(a=1, b=2, c=3)

# Generated at 2022-06-23 18:07:33.958387
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _test_to_namedtuple(
            obj: dict,
            result: namedtuple,
            **kwargs
    ) -> None:
        assert to_namedtuple(obj, **kwargs) == result

    _test_to_namedtuple(
        {'a': 1, 'b': 2},
        namedtuple('NamedTuple', 'a b')(a=1, b=2)
    )
    _test_to_namedtuple(
        {'a': 1, 'b': 2, 'c': {'d': 4}},
        namedtuple('NamedTuple', 'a b c')(
            a=1, b=2, c=namedtuple('NamedTuple', 'd')(d=4)
        )
    )
    _test_to_namedt

# Generated at 2022-06-23 18:07:46.582705
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple(OrderedDict()) == NamedTuple()
    assert to_namedtuple(SimpleNamespace()) == NamedTuple()
    assert to_namedtuple(dict(a=10, b=20)) == NamedTuple(a=10, b=20)
    assert to_namedtuple(OrderedDict(a=10, b=20)) == NamedTuple(a=10, b=20)
    assert to_namedtuple(
        SimpleNamespace(a=10, b=20)
    ) == NamedTuple(a=10, b=20)
    assert to_namedtuple((1, 2)) == tuple([1, 2])
    assert to_namedtuple([1, 2]) == [1, 2]

# Generated at 2022-06-23 18:07:57.920718
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    dic = {'_a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == (1, 2)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.b == 2

    dic = {'a': {'b': 2, 2: 1}, 2: 'a'}
    out = to_namedtuple(dic)


# Generated at 2022-06-23 18:08:04.799101
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out[0] == 1
    assert out[1] == 2

    class MyClass(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    obj = MyClass('c', 'd')
    pytest.raises(TypeError, to_namedtuple, obj)

    dic = {'a': 1, 'b': {'c': 'd'}}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b.c == 'd'


# Generated at 2022-06-23 18:08:13.281578
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    # noinspection SpellCheckingInspection

# Generated at 2022-06-23 18:08:25.587712
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # undocumented option: _started
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple(True) is True
    assert to_namedtuple("") == ""
    assert to_namedtuple("a") == "a"
    assert to_namedtuple("a" * 1000) == "a" * 1000
    assert to_namedtuple(b"") == b""
    assert to_namedtuple(b"a") == b"a"
    assert to_namedtuple(b"a" * 1000) == b"a" * 1000
    assert to_namedtuple(1j) == 1j
    assert to_namedtuple(complex(1, 1)) == complex(1, 1)

# Generated at 2022-06-23 18:08:36.639441
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from copy import deepcopy
    from collections import defaultdict
    import pickle
    from flutils.namedtupleutils import to_namedtuple
    from unittest import TestCase

    def is_namedtuple(val: Any) -> bool:
        return hasattr(val, '_fields')

    def get_values(
            val: Union[Mapping, Sequence, NamedTuple, SimpleNamespace]
    ) -> List[Any]:
        if isinstance(val, Mapping):
            return [val[key] for key in sorted(list(val.keys()))]
        if isinstance(val, Sequence):
            val = cast(Sequence, val)
            return list(val)
        if hasattr(val, '_fields'):
            val = cast(NamedTuple, val)

# Generated at 2022-06-23 18:08:49.007333
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    d1 = SimpleNamespace(
        a=1,
        b=2
    )
    out = to_namedtuple(d1)
    assert out.a == 1
    assert out.b == 2

    d2 = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(d2)
    assert out.a == 1
    assert out.b == 2

    d3 = {'a': 1, 'b': 2}
    out = to_namedtuple(d3)
    assert out.a == 1
    assert out.b == 2

    d4 = {'b': 2, 'a': 1}
    out = to_namedtuple(d4)
    assert out.a == 1

# Generated at 2022-06-23 18:08:56.883531
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(d, NamedTuple) and d == (1, 2)
    d = to_namedtuple({'a': {'b': 2}, 'b': 2})
    assert isinstance(d, NamedTuple) and d.a == (2,) and d.b == 2
    d = to_namedtuple({'a': 1, '_b': 2})
    assert isinstance(d, NamedTuple) and d == (1,)
    d = to_namedtuple({'a': 1, 'b': {'c': 3}})
    assert isinstance(d.b, NamedTuple) and d.b == (3,)
    d = to_namedtuple([1, 2])
    assert isinstance(d, list)

# Generated at 2022-06-23 18:09:04.726252
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pprint
    assert to_namedtuple([]) == []
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'b': 1}) == NamedTuple(b=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 1, 'a': 2}) == NamedTuple(a=2, b=1)
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple

# Generated at 2022-06-23 18:09:12.088505
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Test operation of function to_namedtuple
    '''
    out = to_namedtuple((('First Name', 'Raul'), ('Last Name', 'Herrera')))
    assert type(out) == namedtuple('NamedTuple',
                                   'First Name Last Name')().__class__
    assert out.First_Name == 'Raul'
    assert out.Last_Name == 'Herrera'
    out = to_namedtuple([['First Name', 'Raul'], ['Last Name', 'Herrera']])
    assert type(out) == list
    assert out[0] == ['First Name', 'Raul']
    assert out[1] == ['Last Name', 'Herrera']
    out = to_namedtuple({'First Name': 'Raul', 'Last Name': 'Herrera'})
   

# Generated at 2022-06-23 18:09:23.525881
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # List[NamedTuple]
    l = [
        [{'A': 1}, {'A': 2}, {'A': 3}],
    ]
    assert to_namedtuple(l) == [
        (NamedTuple(A=1), NamedTuple(A=2), NamedTuple(A=3))
    ]

    # Dict[NamedTuple]
    d = {
        1: {'a': 1, 'b': 2},
        2: {'a': 1, 'b': 2},
    }
    assert to_namedtuple(d) == {
        1: NamedTuple(a=1, b=2),
        2: NamedTuple(a=1, b=2)
    }

    # Tuple[NamedTuple]

# Generated at 2022-06-23 18:09:34.954830
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from functools import reduce

    def multiply_series(*args: Any) -> NamedTuple:
        return NamedTuple(product=reduce(lambda x, y: x * y, args, 1))

    def multiply_series_plain(*args: Any) -> List[Any]:
        return [reduce(lambda x, y: x * y, args, 1)]

    def multiply_series_plain2(*args: Any) -> List[Any]:
        return reduce(lambda x, y: x * y, args, 1)

    def assert_matches(expected: Any, obtained: Any) -> None:
        assert expected == obtained, (expected, obtained)
        assert isinstance(expected, type(obtained)), (expected, obtained)


# Generated at 2022-06-23 18:09:45.986481
# Unit test for function to_namedtuple
def test_to_namedtuple():

    lst = [
        {'a': 1, 'b': 2},
        {'c': 3, 'd': 4},
    ]
    res = to_namedtuple(lst)
    assert res[1].d == 4

    named = to_namedtuple(res[0])
    assert named.b == 2

    dic = {'a': 1, 'b': 2}
    named = to_namedtuple(dic)
    assert named.b == 2

    res = to_namedtuple(named)
    assert res.b == 2

    orig = {'a': {'b': 2}}
    named = to_namedtuple(orig)
    assert isinstance(named.a, NamedTuple)
    assert named.a.b == 2

    orig = SimpleNamespace()
    orig.c

# Generated at 2022-06-23 18:09:54.946391
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # 1. Sequence to NamedTuple
    seq = [{'nested_a': 1, 'nested_b': 2}, {'nested_c': 3, 'nested_d': 4}]
    exp_seq_nt = [NamedTuple(nested_a=1, nested_b=2), NamedTuple(nested_c=3, nested_d=4)]
    print(3, to_namedtuple(seq))
    assert to_namedtuple(seq) == exp_seq_nt

    # 2. Sequence to NamedTuple
    msg = "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (%r) %s"

# Generated at 2022-06-23 18:10:06.708314
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple([]) == []
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(('1', '2')) == ('1', '2')
    assert to_namedtuple(('1', '2')) == ('1', '2')

# Generated at 2022-06-23 18:10:14.266352
# Unit test for function to_namedtuple
def test_to_namedtuple():

    class MyClass:

        def __init__(self, one, two):
            self.one = one
            self.two = two

    pytest.importorskip('dataclasses')
    d = MyClass(1, 2)
    with pytest.raises(TypeError):
        to_namedtuple(d)

    class MyClass:

        def __init__(self, one, two):
            self.one = one
            self.two = two

    d = MyClass(1, 2)
    with pytest.raises(TypeError):
        to_namedtuple(d)

    dic = OrderedDict([('one', 1), ('two', 2)])
    dic = to_namedtuple(dic)

# Generated at 2022-06-23 18:10:25.652313
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    n1: NamedTuple = to_namedtuple({})
    assert len(n1) == 0
    assert list(n1._fields) == []
    assert n1 == NamedTuple()

    n2: NamedTuple = to_namedtuple({'a': 1, 'b': 2})
    assert n2[0] == 1
    assert n2[1] == 2
    assert n2.a == 1
    assert n2.b == 2

    n3: NamedTuple = to_namedtuple([1, 2])
    assert n3[0] == 1
    assert n3[1] == 2

    n4: NamedTuple = to_namedtuple((1, 2))
    assert n4[0] == 1
    assert n4[1]

# Generated at 2022-06-23 18:10:31.924703
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2

    dic = {'b': 2, 'a': 1}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2

    dic = OrderedDict([('a', 1), ('b', 2)])
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2

    dic = {'a': 1, 'b': {'c': 3, 'd': 4}}
    obj = to_namedtuple(dic)
    assert obj.a == 1

# Generated at 2022-06-23 18:10:37.446743
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)


if __name__ == '__main__':
    test_to_namedtuple()
    print('All tests for "to_namedtuple" passed.')

# Generated at 2022-06-23 18:10:39.200197
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=False)

# Generated at 2022-06-23 18:10:50.884976
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    lst = [
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2, 'c': 3},
        {'a': 1, 'b': 2, 'c': 3, 'd': 4},
    ]
    out = to_namedtuple(lst)
    assert out[0].a == 1
    assert out[1].c == 3
    assert out[2].d == 4
    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.c == 3
    out = to_namedtuple(out)
   

# Generated at 2022-06-23 18:10:52.590097
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) == 1

# Generated at 2022-06-23 18:11:04.215926
# Unit test for function to_namedtuple
def test_to_namedtuple():  # pragma: no cover
    """Test the ``to_namedtuple`` function."""

    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import to_namedtuple

    from collections import OrderedDict

    from typing import List


    def _assert_is_namedtuple(obj, expected):
        """Assert the given object is an instance of NamedTuple."""
        from collections import NamedTuple

        assert isinstance(obj, NamedTuple)
        for attr in obj._fields:
            assert hasattr(obj, attr)
            assert getattr(obj, attr) == expected[attr]


    def test_to_namedtuple_with_dict():
        """Test the ``to_namedtuple`` function with a dictionary."""
        expected = OrderedDict()
       

# Generated at 2022-06-23 18:11:13.173105
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)

    dic = dict(a=1, b=2)
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = dict(a=1, b=2)
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = OrderedDict(a=1, b=2)
    out = to_namedtuple(dic)
    assert out[0] == 1

    dic = OrderedDict(b=2, a=1)
    out = to_namedt

# Generated at 2022-06-23 18:11:21.324881
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    import doctest
    import flutils.namedtupleutils
    doctest.testmod(flutils.namedtupleutils)
    print(to_namedtuple({'a': 1, 'b': 2}))
    print(to_namedtuple(OrderedDict([('a', 1), ('b', 2)])))
    print(to_namedtuple([{'a': 1, 'b': 2}, 2, 3, 4]))


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:11:32.231060
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    namedtuple_obj = to_namedtuple(dic)
    assert namedtuple_obj.a == 1
    assert namedtuple_obj.b == 2
    assert namedtuple_obj[0] == 1
    assert namedtuple_obj[1] == 2
    assert namedtuple_obj[-2] == 1
    assert namedtuple_obj[-1] == 2

    tup = (1, 2)
    namedtuple_obj = to_namedtuple(tup)
    assert namedtuple_obj.a == 1
    assert namedtuple_obj.b == 2
    assert namedtuple_obj[0] == 1
    assert namedtuple_obj[1] == 2
    assert namedtuple_obj[-2]

# Generated at 2022-06-23 18:11:42.709634
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    from flutils.namedtupleutils import to_namedtuple

    tst_lst = [{1: 2}, {3, 4}, 5, 6]
    tst_dic = {'a': [1, 2], 'b': 3}
    tst_dic2 = {'a': {'b': 1, 'c': 2}, 'd': 3}
    tst_dic3 = {'a': {'b': {'c': {'d': 1, 'e': 2}}, 'f': 3}}
    tst_dic4 = {'a': {'b': {'c': {'d': 1, 'e': [1, 2, 3]}}, 'f': 3}}

# Generated at 2022-06-23 18:11:51.940058
# Unit test for function to_namedtuple
def test_to_namedtuple():
    
    from collections import namedtuple
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    import pytest
    from flutils.namedtupleutils import to_namedtuple

    obj = {'a': 1, 'b': 2}
    result = to_namedtuple(obj)
    expected = obj
    assert result == expected


    obj = SimpleNamespace(a=1, b=2)
    result = to_namedtuple(obj)
    expected = obj.__dict__
    assert result == expected


    obj = {'a': 1, 'b': 2}
    result = to_namedtuple(obj)
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert result == expected


    obj = Ord

# Generated at 2022-06-23 18:12:00.357909
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):

        def test_to_named_tuple_list_tuple(self):
            data = [
                {'a': 1, 'b': 2},
                {'a': 1, 'b': 2},
                [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}],
            ]
            out = to_namedtuple(data)
            self.assertEqual(
                out,
                [
                    NamedTuple(a=1, b=2),
                    NamedTuple(a=1, b=2),
                    [NamedTuple(a=1, b=2), NamedTuple(a=1, b=2)],
                ]
            )


# Generated at 2022-06-23 18:12:12.393180
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Test function to_namedtuple.

    Test to_namedtuple to_namedtuple function with a variety of objects.
    """

    import pytest

    class SimpleClass(object):
        """ A brief class for namedtuple testing. """

        def __init__(self):
            self.attr1 = 1
            self.attr2 = 'abc'


    SC = SimpleClass()
    SC_list = [{'a': 1, 'b': 2}, {'a': 2, 'b': 3}]

# Generated at 2022-06-23 18:12:18.065660
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': {'c': 2}, 'd': 'abc', 'e': [1, 2, 3]}
    obj = SimpleNamespace(
        dic
    )
    nt = to_namedtuple(obj)
    assert nt.a == 1
    assert nt.b.c == 2
    assert nt.d == 'abc'
    assert isinstance(nt.e, tuple)
    assert isinstance(nt.e[0], int)
    assert isinstance(nt.e[1], int)
    assert isinstance(nt.e[2], int)
    assert isinstance(nt.b, NamedTuple)


# Generated at 2022-06-23 18:12:28.278406
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tst = SimpleNamespace(
        a=1,
        b=2,
        c=3,
    )
    exp = NamedTuple(a=1, b=2, c=3)
    obs = to_namedtuple(tst)
    assert obs == exp

    tst = OrderedDict(
        a=1,
        b=2,
        c=3,
    )
    exp = NamedTuple(a=1, b=2, c=3)
    obs = to_namedtuple(tst)
    assert obs == exp

    tst = [1, 2, 3, 4]
    exp = [1, 2, 3, 4]
    obs = to_namedtuple(tst)
    assert obs == exp


# Generated at 2022-06-23 18:12:37.936585
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple(None) is None
    assert to_namedtuple(False) is False
    assert to_namedtuple("") == ""

    assert to_namedtuple(42) == 42
    assert to_namedtuple(42.0) == 42.0
    assert to_namedtuple(42j) == 42j

    assert to_namedtuple(b'abc') == b'abc'
    assert to_namedtuple(bytes(range(256))) == bytes(range(256))
    assert to_namedtuple(bytearray('bytearray', 'utf8')) == bytearray(
        'bytearray', 'utf8')

    assert to_namedtuple(range(10)) == (0, 1, 2, 3, 4, 5, 6, 7, 8, 9)

# Generated at 2022-06-23 18:12:47.173835
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    ordic = OrderedDict()
    ordic['x'] = 1
    ordic['y'] = 2
    assert to_namedtuple(ordic) == namedtuple('NamedTuple', 'x y')(x=1, y=2)

    list = [1, 2]
    assert to_namedtuple(list) == [1, 2]

    tup = (1, 2)
    assert to_namedtuple(tup) == (1, 2)

    sn = SimpleNamespace()
    sn.x = 1
    sn.y = 2

# Generated at 2022-06-23 18:12:56.702045
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    """Unit test"""
    import unittest.mock as mock

    with mock.patch('builtins.print') as m_print:

        # noinspection PyShadowingNames,PyUnusedLocal
        def side_effect(*args: Any, **kwargs: Any) -> None:
            return

        m_print.side_effect = side_effect

        with mock.patch('flutils.namedtupleutils.validate_identifier',
                        return_value=None) as m_validate_identifier:
            # noinspection PyShadowingNames
            d = {'a': 1, 'b': {'c': 3}, ('d',): 4}

            # noinspection PyTypeChecker
            res = to_namedtuple(d)  # type: NamedTuple
           

# Generated at 2022-06-23 18:13:07.823164
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import (
        to_namedtuple,
    )

    # Mapping
    # =======
    dic = {
        'a': 1,
        'b': 2,
    }
    out = to_namedtuple(dic)
    assert isinstance(out, dict) is False
    assert isinstance(out, NamedTuple)
    assert getattr(out, 'a') == 1
    assert getattr(out, 'b') == 2

    # SimpleNamespace
    # ===============
    class MockSimpleNamespace:
        pass

    obj = MockSimpleNamespace()
    obj.__dict__ = dic
    out = to_namedtuple(obj)
    assert isinstance(out, dict) is False

# Generated at 2022-06-23 18:13:17.990878
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import copy

    class Test_(unittest.TestCase):

        def test_to_namedtuple_dict(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertNotEqual(id(dic), id(out))
            self.assertEqual(id(dic['a']), id(out.a))
            self.assertEqual(id(dic['b']), id(out.b))
            self.assertIsInstance(out, namedtuple)

        def test_to_namedtuple_dict_unused_key(self):
            dic = {'a': 1, 'b': 2, 'c': 3}
            out = to_namedtuple(dic)

# Generated at 2022-06-23 18:13:27.172827
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    '''
    Test the to_namedtuple function
    '''
    try:
        _to_namedtuple(None)
    except TypeError:
        pass
    else:
        assert False, 'Should have got a TypeError'
    new_val = to_namedtuple({})
    assert isinstance(new_val, NamedTuple)
    new_val = to_namedtuple({'a': 1})
    assert isinstance(new_val, NamedTuple)
    assert new_val.a == 1
    new_val = to_namedtuple([1])
    assert isinstance(new_val, list)
    new_val = to_namedtuple((1,))
    assert isinstance(new_val, tuple)

# Generated at 2022-06-23 18:13:39.359745
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    assert to_namedtuple(4) == 4
    assert to_namedtuple(float('nan')) == float('nan')
    assert to_namedtuple(float('inf')) == float('inf')
    assert to_namedtuple(float('-inf')) == float('-inf')
    assert to_namedtuple('hi') == 'hi'
    assert to_namedtuple('') == ''
    assert to_namedtuple(tuple()) == tuple()
    assert to_namedtuple(list()) == []
    assert to_namedtuple(dict()) == NamedTuple()
    assert to_namedtuple(dict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(('a', 'b'))

# Generated at 2022-06-23 18:13:51.258557
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    import json
    import pathlib
    import types
    from pprint import pformat
    from flutils.namedtupleutils import (
        NamedTuple,
        to_namedtuple,
    )
    from flutils.pyutils import to_json
    from flutils.stringutils import to_identifier
    from flutils.validators import (
        validate_date,
        validate_time,
    )
    from testfixtures import (
        compare,
        ShouldRaise,
    )

    BASE_PATH = pathlib.Path(__file__).parent.parent.parent

# Generated at 2022-06-23 18:14:04.257661
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_namedtuple

    good_dic = {'a': 1, 'b': 2}
    good_ntu = to_namedtuple(good_dic)
    assert validate_namedtuple(good_ntu)

    bad_dic = {'a': 1, 'b': 2, 'c': 'a b'}
    with pytest.raises(TypeError) as exc:
        to_namedtuple(bad_dic)

# Generated at 2022-06-23 18:14:14.383050
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from typing import Tuple
    from unittest import TestCase

    from flutils.namedtupleutils import to_namedtuple

    class TestData(TestCase):
        def setUp(self):
            self.tuple0 = (1,)
            self.tuple1 = (1, 2)
            self.tuple_multi = (1, (1, 2, 3), (1, {'a': 1, 'b': 2}), 3)
            self.tuple_multi_mixed = (1, (1, 2, 3), (1, {'a': 1, 'b': 2}),
                                      (1, {'a': 1, 'b': 2}), 3)
            self.list0 = [1]
            self.list1 = [1, 2]

# Generated at 2022-06-23 18:14:27.010827
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:14:33.796773
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic = {'a': 1, 'b': [{'c': 3, 'd': 4}], 'e': 5, 'f': 6}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b e f')(a=1, b=[namedtuple('NamedTuple', 'c d')(c=3, d=4)], e=5, f=6)
    lst = [[1, 2], 3, 4, 5, 6]

# Generated at 2022-06-23 18:14:41.334202
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    # 1. Test with a list
    lst: List[int] = [1, 2, 3]
    named_lst: List[NamedTuple] = to_namedtuple(lst)
    assert named_lst == [1, 2, 3]
    assert type(named_lst) == list
    assert type(named_lst[0]) == int
    assert type(named_lst[1]) == int
    assert type(named_lst[2]) == int

    # 2. Test with a tuple
    tup: Tuple[int, ...] = (1, 2, 3)
    named_tup: Tuple[NamedTuple, ...] = to_namedtuple(tup)

# Generated at 2022-06-23 18:14:53.094947
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj1 = {'a': 1, 'b': 2}
    out1 = to_namedtuple(obj1)
    assert out1.a == 1
    assert out1.b == 2

    obj2 = {'a': 1, 'b': 2}
    obj2['c'] = {'d': 3, 'e': 4}
    out2 = to_namedtuple(obj2)
    assert out2.a == 1
    assert out2.b == 2
    assert out2.c.d == 3
    assert out2.c.e == 4

    obj3 = {'a': 1, 'b': 2}
    obj3['c'] = [1, 2, {'d': 3, 'e': 4}, 5, 6]
    out3 = to_namedtuple(obj3)
    assert out3

# Generated at 2022-06-23 18:15:02.447101
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pytest import raises

    with raises(TypeError, match=r"Can convert only 'list', 'tuple', 'dict' to a NamedTuple;"):
        out = to_namedtuple(5)
    with raises(TypeError, match=r"Can convert only 'list', 'tuple', 'dict' to a NamedTuple;"):
        out = to_namedtuple('5')

    dic = {'a': 1, 'b': 2}
    ntup = to_namedtuple(dic)
    assert ntup[0] == 1
    assert ntup[1] == 2
    assert ntup.a == 1
    assert ntup.b == 2
    assert ntup.__class__.__name__ == 'NamedTuple'


# Generated at 2022-06-23 18:15:15.060815
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from unittest.mock import patch
    from flutils.namedtupleutils import to_namedtuple


    class TestToNamedtuple(TestCase):

        def test_dict_to_namedtuple(self):
            """Test that a dict is converted to a NamedTuple."""
            dct = {'a': 1, 'b': 2}
            namedtuple_ = to_namedtuple(dct)
            self.assertEqual(namedtuple_.a, 1)
            self.assertEqual(namedtuple_.b, 2)

        def test_dict_to_namedtuple_sorted_keys(self):
            """Test that a dict is converted to a NamedTuple with keys sorted
            alphabetically."""

# Generated at 2022-06-23 18:15:20.846851
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.tests.pytest_utils import validate_pass_fail
    from flutils.namedtupleutils import (
        to_namedtuple,
        _to_namedtuple,
    )
    from collections import namedtuple
    from typing import (
        NamedTuple as NamedTupleT,
        Tuple as TupleT,
        List as ListT,
        Union
    )
    from datetime import date
    from decimal import Decimal
    from types import SimpleNamespace as SimpleNamespaceT
    from typing import Mapping as MappingT, Sequence as SequenceT
    from flutils.miscutils import _Undefined, UNDEFINED
    from flutils.namedtupleutils import NamedTuple
    VALIDATE_PASS_FAIL = validate_pass_fail()
    UNDEFINED = UNDEFINED


# Generated at 2022-06-23 18:15:23.101903
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=True,
                    optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-23 18:15:30.709847
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3
    assert nt.d == 4
    assert nt.e == 5

    dic = {'1': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    nt = to_namedtuple(dic)
    assert nt.b == 2
    assert nt.c == 3
    assert nt.d == 4
    assert nt.e == 5

# Generated at 2022-06-23 18:15:42.317893
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from io import StringIO
    from unittest.mock import patch
    from flutils.namedtupleutils import to_namedtuple

    dic_out = to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(dic_out, namedtuple)
    assert hasattr(dic_out, 'a')
    assert hasattr(dic_out, 'b')
    assert dic_out.a == 1
    assert dic_out.b == 2
    dic_out = to_namedtuple({'1a': 1, 'b': 2})
    assert isinstance(dic_out, namedtuple)
    assert hasattr(dic_out, 'b')
    assert dic_out.b == 2

# Generated at 2022-06-23 18:15:48.837181
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple((2, 3, 4)) == (2, 3, 4)
    assert to_namedtuple(dict(a=1, b=2, c=3)) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(dict(a=1, b=2, c='x')) == NamedTuple(a=1, b=2, c='x')
    assert to_namedtuple(dict(a=1, b=2, c=dict(x='x', y='y'))) \
           == NamedTuple(a=1, b=2, c=NamedTuple(x='x', y='y'))
    assert to_

# Generated at 2022-06-23 18:15:59.605751
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple((1, 2, 3, (1, 2, 3))) == (1, 2, 3, (1, 2, 3))
    assert to_namedtuple({"a": 1, "b": 2, "c": 3}) == namedtuple(
        'NamedTuple', 'a b c')(a=1, b=2, c=3)
    assert to_namedtuple({"a": 1, "b": 2, "c": 3, "_d": 4}) == namedtuple(
        'NamedTuple', 'a b c')(a=1, b=2, c=3)
   

# Generated at 2022-06-23 18:16:03.250904
# Unit test for function to_namedtuple
def test_to_namedtuple():

    d = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': 5}
    nt = to_namedtuple(d)

    assert nt.a == 1
    assert nt.b.c == 3
    assert nt.b.d == 4
    assert nt.e == 5

# Generated at 2022-06-23 18:16:14.368891
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    dic = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
        ('d', 4),
    ])
    dic2 = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
        ('d', 4),
    ])
    dic3 = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
        ('d', 4),
    ])
    dic = {'a': 1, 'b': 2}
    dic2 = {'a': 1, 'b': 2}
    dic3 = {'a': 1, 'b': 2}