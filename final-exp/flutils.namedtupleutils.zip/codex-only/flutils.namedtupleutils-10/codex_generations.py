

# Generated at 2022-06-23 18:06:16.817174
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lis = [1, 2, 3]
    lis2 = [lis, lis, lis]
    lis3 = [lis2, lis2, lis2]
    out = to_namedtuple(lis3)
    assert out[0] == (1, 2, 3)
    assert out[1] == (1, 2, 3)
    assert out[2] == (1, 2, 3)

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    dic = {'123': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out[0] == (1, 2)


# Generated at 2022-06-23 18:06:27.330244
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from typing import NamedTuple
    from types import SimpleNamespace

    # Test 1: basic `dict`
    test1 = to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(test1, NamedTuple)
    assert len(test1._fields) == 2
    assert test1.a == 1
    assert test1.b == 2

    # Test 2: no `dict` keys can be turned into a valid identifier
    test2 = to_namedtuple({'a.b': 1, 'b': 2})
    assert isinstance(test2, NamedTuple)
    assert len(test2._fields) == 0

    # Test 3: no `dict` keys can be turned into a valid identifier,

# Generated at 2022-06-23 18:06:33.684460
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from flutils.namedtupleutils import to_namedtuple

    class TestToNamedTuple(unittest.TestCase):
        """Unit test class for function to_namedtuple."""

        def test_ok_dict(self):
            """Test the to_namedtuple function with a dictionary."""
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertIsInstance(out, namedtuple('NamedTuple', 'a b'))

        def test_ok_odict(self):
            """Test the to_namedtuple function with a OrderedDict."""
            from collections import OrderedDict
            odict = OrderedDict((('a', 1), ('b', 2)))
            out = to_

# Generated at 2022-06-23 18:06:41.013151
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest.mock
    obj = SimpleNamespace(a=1, b=2)
    assert to_namedtuple(obj) == to_namedtuple(obj.__dict__)
    obj = SimpleNamespace(a=obj)
    assert to_namedtuple(obj) == to_namedtuple(obj.__dict__)
    obj = SimpleNamespace(
        a=SimpleNamespace(b=SimpleNamespace(c=SimpleNamespace(d=1)))
    )
    with unittest.mock.patch(
            'flutils.namedtupleutils._to_namedtuple',
            unittest.mock.Mock(side_effect=_to_namedtuple)
    ) as mock_to_namedtuple:
        to_namedtuple(obj)
        assert mock_to

# Generated at 2022-06-23 18:06:53.070147
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple((1,)) == namedtuple('NamedTuple', '_1')(1)
    assert to_namedtuple(((1,),)) == namedtuple('NamedTuple', '_1')((1,))
    assert to_namedtuple(((1, 2),)) == namedtuple('NamedTuple', '_1')((1, 2))
    assert to_namedtuple((((1, 2, 3),),)) == namedtuple('NamedTuple', '_1')(
        ((1, 2, 3),)
    )

    assert to_namedtuple(['a']) == ['a']
    assert to_namedtuple(('a',)) == namedtuple('NamedTuple', '_1')('a')

# Generated at 2022-06-23 18:07:01.942916
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test basic function
    dic = dict(a=1, b=2)
    tup = to_namedtuple(dic)
    print(f"{tup}")
    assert tup.a == 1, f"{tup}"
    assert tup.b == 2, f"{tup}"

    # Test list
    lst = [dict(a=1, b=2)]
    tup = to_namedtuple(lst)
    assert tup[0].a == 1, f"{tup}"
    assert tup[0].b == 2, f"{tup}"
    assert isinstance(tup, list), f"{type(tup)}"

    # Test tuple
    tpl = (dict(a=1, b=2),)
    tup = to_namedt

# Generated at 2022-06-23 18:07:13.385371
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 3: 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 3: 3, '_': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    lis = [1, 2, 3]
    assert to_namedtuple(lis) == [1, 2, 3]
    lis = [1, 2, 3, {'a': 1, 'b': 2}]

# Generated at 2022-06-23 18:07:25.496835
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    import os
    import pprint
    import random
    import string
    import unittest

    from flutils.orderedmapping import OrderedMapping

    test_dir = os.path.dirname(__file__)
    file_path = os.path.join(test_dir, 'namedtuple.json')
    with open(file_path, 'r') as io:
        data = json.load(io)

    print(pprint.pformat(data))
    dic = to_namedtuple(data)
    print(pprint.pformat(dic))
    assert dic.a.b.a == 1
    assert dic.a.b.b.c.a == 7
    assert dic.a.b.b.c.b == 8
    assert dic.a.b

# Generated at 2022-06-23 18:07:31.897771
# Unit test for function to_namedtuple
def test_to_namedtuple():
    line_no: int = 0

    def _test_statement(obj: Any) -> None:
        global line_no
        line_no += 1
        try:
            out = to_namedtuple(obj)
        except Exception as ex:
            print('%s: %s = to_namedtuple(%s)' % (line_no, ex, obj))
            raise
        else:
            print('%s: %s = to_namedtuple(%s)' % (line_no, out, obj))

    _test_statement(dict(a=1, b=2))
    _test_statement([1, 2])
    _test_statement(OrderedDict(a=1, b=2))
    _test_statement(SimpleNamespace(a=1, b=2))

# Generated at 2022-06-23 18:07:43.524493
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # First test to make sure the function works as it should,
    # and produces an error if given a type it can't handle.

    from collections import Counter
    from typing import Dict, List, NamedTuple
    from collections.abc import Mapping, Sequence
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace

    c = Counter({'a': 1, 'b': 2, 'c': 3})
    try:
        val = to_namedtuple(c)
    except TypeError:
        val = None
    assert val is None

    nt1 = SimpleNamespace()
    nt1.a = 1
    nt1.b = 2
    nt1.c = 3
    nt2 = SimpleNamespace()
    nt2.d = 4
    nt1

# Generated at 2022-06-23 18:07:52.618194
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    dic = {'a': 1, 'b': 2}
    nt1 = to_namedtuple(dic)
    assert nt1.a == 1
    assert nt1.b == 2
    dic = {'a': 1, 'b': 2, 3: 3}
    nt1 = to_namedtuple(dic)
    assert hasattr(nt1, 'a')
    assert hasattr(nt1, 'b')
    assert isinstance(nt1, OrderedDict)
    assert not isinstance(nt1, NamedTuple)
    dic = OrderedDict([(1, 1), (2, 2)])
    nt1 = to_namedtuple(dic)
    assert hasattr(nt1, '1')
    assert hasattr

# Generated at 2022-06-23 18:08:01.418051
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    import sys

    # noinspection PyPep8
    d2 = {'a': 1, 'b': 2, 'c': 3}
    expected = NamedTuple(a=1, b=2, c=3)
    actual = to_namedtuple(d2)
    assert actual == expected, (
        "Actual: %s\nExpected: %s" % (actual, expected)
    )

    # noinspection PyPep8
    d3 = {'a': 1, 'b': {'c': 3}, 'd': {'e': {'f': 5}, 'g': 6}}
    expected = NamedTuple(a=1, b=NamedTuple(c=3), d=NamedTuple(e=NamedTuple(f=5), g=6))
   

# Generated at 2022-06-23 18:08:11.452408
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import date
    from flutils.collectionsutils import to_odict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import is_identifier, valid_identifier

    dic = {
        'id': 1594,
        'name': 'test',
        'created': date(2020, 3, 20),
        'modified': date(2020, 3, 20),
        '_parent_id': 123,
        'parent_id': 456,
    }

    from collections import ChainMap

    def get_key(mdic: Mapping, key: str, default: Any = None) -> Any:

        odic = to_odict(mdic)
        out = default

# Generated at 2022-06-23 18:08:24.346978
# Unit test for function to_namedtuple
def test_to_namedtuple():
    cls_dict = dict(a=1, b=2, c=3)

    # dict
    result = to_namedtuple(cls_dict)
    expected = namedtuple('NamedTuple', 'a, b, c')(1, 2, 3)
    assert result == expected

    # dict with non-identifier keys

# Generated at 2022-06-23 18:08:36.378637
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    class C(NamedTuple):
        a: int
        b: int = 1
    dic = {'a': 1, 'b': 2}
    odic = OrderedDict((('b', 1), ('a', 2)))
    odic_bad = OrderedDict((('b', 1), ('a', 2), ('2a', 3)))  # bad key
    odic_bad2 = OrderedDict((('b', 1), ('a', 2), ('A', 3)))  # bad key
    lis = [1, 2, 3, 4]
    lis_bad = [1, 2, C(a=1), C(a=2)]
    tup = (1, 2, 3, 4)

# Generated at 2022-06-23 18:08:40.271186
# Unit test for function to_namedtuple
def test_to_namedtuple():
    src = {'a': 1, 'b': 2}
    dst = to_namedtuple(src)
    assert isinstance(dst, NamedTuple)
    assert dst.a == 1
    assert dst.b == 2


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:08:51.904270
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def get_obj(obj: Any, fields: bool = False) -> Union[dict, SimpleNamespace]:
        if fields is False:
            return obj.__dict__
        return SimpleNamespace(**obj.__dict__)

    # namedtuple
    obj = namedtuple('NamedTuple', 'a b c d e')(1, 2, 3, 4, 5)
    out = to_namedtuple(obj)
    assert out == obj
    assert get_obj(out) == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    assert get_obj(out) == get_obj(obj)

    # list
    obj = [1, 2, 3, 4, 5]
    out = to_namedtuple(obj)
    assert out == obj


# Generated at 2022-06-23 18:09:01.741442
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import randint
    from collections import deque
    from collections import defaultdict
    from collections import Counter
    from flutils.testutils import random_string

    def _get_nest_dictionary(
            max_depth: int,
            max_keys: int,
            max_values: int
    ) -> Mapping[str, Any]:
        out: Dict[str, Any] = {}
        num_keys = randint(1, max_keys)
        for _ in range(num_keys):
            key = random_string(length=randint(1, max_values), uppercase=True)
            try:
                validate_identifier(key, allow_underscore=False)
            except SyntaxError:
                continue
            value = randint(0, max_values)

# Generated at 2022-06-23 18:09:11.210842
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from itertools import chain

    from numpy import (
        ndarray,
    )
    from numpy.testing import (
        assert_array_equal,
    )
    from pandas import (
        Categorical,
        CategoricalDtype,
        DataFrame,
        Series,
    )
    from pd.testing import (
        assert_frame_equal,
        assert_series_equal,
    )
    from pytest import (
        approx,
        raises,
    )

# Generated at 2022-06-23 18:09:23.137653
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from collections import OrderedDict
    from types import SimpleNamespace

    # noinspection PyUnresolvedReferences
    class ToNamedTupleTests(TestCase):
        def test_list_of_list_of_tuples_of_dict(self):  # type: ignore[no-untyped-call]
            # noinspection PyTypeChecker,PyUnresolvedReferences
            """Convert list of list of tuples of dict."""

# Generated at 2022-06-23 18:09:29.062372
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert len(nt) == 2
    assert nt.a == dic['a']
    assert nt.b == dic['b']

# Generated at 2022-06-23 18:09:40.113962
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils as utils
    from flutils.objects import DictObject
    from flutils.namedtupleutils import (
        get_namedtuple,
        is_namedtuple,
        to_dict,
        to_dictobj,
        to_json,
        to_list,
        to_tuple,
    )
    import pytest

    a: utils.namedtuple = utils.to_namedtuple({"a": 1, "b": 2})
    b: utils.namedtuple = utils.to_namedtuple({"b": 2, "a": 1})
    assert a == b
    assert a.a == 1
    assert a.b == 2


# Generated at 2022-06-23 18:09:49.633239
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2, 1: 3}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), (1, 3)])) \
        == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'c': 3}, 'a']) \
        == [NamedTuple(a=1, b=2), NamedTuple(c=3), 'a']
    assert to_namedtuple(({'a': 1, 'b': 2}, {'c': 3}, 'a')) \
        == (NamedTuple(a=1, b=2), NamedTuple(c=3), 'a')

# Generated at 2022-06-23 18:09:53.949728
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert hasattr(out, 'a') is True
    assert hasattr(out, 'b') is True


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:10:05.465131
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import flutils.namedtupleutils as namedtupleutils
    import flutils.validators as validators
    import collections

    # Check that it rejects invalid types
    def should_reject_invalid_type(obj):
        try:
            namedtupleutils.to_namedtuple(obj)
        except TypeError:
            pass
        else:
            raise AssertionError(obj)

    should_reject_invalid_type('str')
    should_reject_invalid_type(None)
    should_reject_invalid_type(b'')
    should_reject_invalid_type(1)
    should_reject_invalid_type(1.0)
    should_reject_invalid_type(int)
    should_reject_invalid_type(list)
    should

# Generated at 2022-06-23 18:10:17.670114
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)
    lis = [1, 2, 3]
    assert to_namedtuple(lis) == [1, 2, 3]
    tup = (4, 5, 6)
    assert to_namedtuple(tup) == (4, 5, 6)
    from dataclasses import dataclass
    from typing import List
    @dataclass
    class A:
        a: int
        b: int
        c: List[int]

# Generated at 2022-06-23 18:10:29.304207
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:10:39.544457
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Dict, Tuple
    _in: Dict[str, Any] = {'a': 1, 'b': {'c': 2, 'd': 3}}
    _in: Dict[str, Any] = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': [1, 2]}
    _in: Dict[str, Any] = {'a': 1, 'b': ('c', 2, 'd', 3), 'e': [1, 2]}
    _in: Tuple[Any, Any] = (  # type: ignore[misc]
        {'a': 1, 'b': {'c': 2, 'd': 3}},
        {'a': 1, 'b': {'c': 2, 'd': 3}},
    )
    # noins

# Generated at 2022-06-23 18:10:51.334232
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def test(_in, _out):
        # Check the output, when calling the function
        out = to_namedtuple(_in)
        # Check the output against expected output
        assert out == _out, (out, _out)

    # Test a dict
    test(
        {'a': 1, 'b': 2},
        NamedTuple(a=1, b=2)
    )
    test(
        OrderedDict([('a', 1), ('c', 2), ('b', 3)]),
        NamedTuple(a=1, c=2, b=3)
    )

# Generated at 2022-06-23 18:11:03.261165
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

# Generated at 2022-06-23 18:11:08.092657
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    dic = {'a': 1, 'b': 2}
    expected_result = collections.namedtuple('NamedTuple', 'a b')
    test_result = to_namedtuple(dic)

    assert test_result == expected_result(1, 2)
    assert dic == {'a': 1, 'b': 2}

# Generated at 2022-06-23 18:11:13.513224
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import json

    class ToNamedTupleTest(unittest.TestCase):
        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            nt = to_namedtuple(dic)
            self.assertEqual(nt, namedtuple('NamedTuple', 'a b')(a=1, b=2))
            self.assertEqual(nt.a, 1)
            self.assertEqual(nt.b, 2)

            dic = {'__a': 1, '_b': 2}
            nt = to_namedtuple(dic)
            self.assertEqual(nt, namedtuple('NamedTuple', 'b')(b=2))


# Generated at 2022-06-23 18:11:19.968830
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2,
    }
    re = to_namedtuple(dic)
    at_obe = re.a
    assert at_obe == 1
    at_b = re.b
    assert at_b == 2
    assert re._asdict() == {
        'a': 1,
        'b': 2,
    }

test_to_namedtuple()

# Generated at 2022-06-23 18:11:31.545494
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for ``to_namedtuple``"""
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'a': {'b': 1}, 'c': 2}) == namedtuple('NamedTuple', 'a c')(
        namedtuple('NamedTuple', 'b')(1), 2)

# Generated at 2022-06-23 18:11:42.247856
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for to_namedtuple."""
    from collections import namedtuple
    from collections.abc import Mapping
    from collections import OrderedDict
    from types import SimpleNamespace
    import operator

    MyNamedTuple = namedtuple('MyNamedTuple', 'a')
    nt0 = MyNamedTuple(a=0)
    nt1 = MyNamedTuple(a=1)
    nt2 = MyNamedTuple(a=2)
    nt3 = MyNamedTuple(a=3)

    nt_list = [nt0, nt1, nt2, nt3]
    nt_tuple = (nt0, nt1, nt2, nt3)


# Generated at 2022-06-23 18:11:51.652601
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.testutils import BaseTestCase
    from collections import namedtuple
    from types import SimpleNamespace

    # pylint: disable=no-method-argument,too-few-public-methods
    class TestCase(BaseTestCase):
        def setUp(self) -> None:
            super(TestCase, self).setUp()
            self.to_namedtuple = to_namedtuple

        def test_mapping(self) -> None:
            self.assertRaises(TypeError, self.to_namedtuple, 'a string')
            self.assertRaises(TypeError, self.to_namedtuple, {1: 2})
            self.assertEqual(self.to_namedtuple({}), namedtuple('NamedTuple', '')())
           

# Generated at 2022-06-23 18:12:00.279637
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    import pprint
    from unittest import TestCase

    # noinspection PyMethodMayBeStatic
    class Test(TestCase):
        maxDiff = None

        def test_to_namedtuple(self):
            dic = OrderedDict()
            dic['a'] = 'use_filter'
            dic[1] = {'cc': 'dd', 'ee': 'ff'}
            dic['c'] = ['gg', 'hh']
            dic['d'] = {'key_one': 'val_one', 'key_two': 'val_two'}
            dic['e'] = {'keys_one': 'vals_one', 'keys_two': 'vals_two'}

# Generated at 2022-06-23 18:12:12.355885
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2, '_c': 3}
    namedtupleobj = to_namedtuple(dic)
    assert namedtupleobj[0] == 1
    assert namedtupleobj.a == 1
    assert hasattr(namedtupleobj, 'c') is False
    s_namedtupleobj = SimpleNamespace(a=1, b=2, _c=3)
    namedtupleobj = to_namedtuple(s_namedtupleobj)
    assert namedtupleobj[0] == 1
    assert namedtupleobj.a == 1
    assert hasattr(namedtupleobj, 'c') is False


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    print('Tested.')

# Generated at 2022-06-23 18:12:21.344228
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    assert repr(to_namedtuple([1, 2, 3])) == repr([1, 2, 3])
    assert repr(to_namedtuple((1, 2, 3))) == repr((1, 2, 3))
    assert repr(to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)]))) ==\
        repr(namedtuple('NamedTuple', ('a', 'b', 'c'))(1, 2, 3))
    assert repr(to_namedtuple({'a': 1, 'b': 2, 'c': 3})) ==\
        repr(namedtuple('NamedTuple', ('a', 'b', 'c'))(1, 2, 3))

# Generated at 2022-06-23 18:12:29.949089
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from inspect import signature
    import sys

    if sys.version_info.minor < 8:
        # The module literal-eval is only needed a python 3.8.0 or later.
        import literal_eval
        _to_namedtuple.register(type(literal_eval.literal_eval('')), _to_namedtuple)

    assert str(signature(to_namedtuple)) == '(obj) -> NamedTuple'
    assert to_namedtuple(1.1) == 1.1
    assert to_namedtuple('test') == 'test'


# Generated at 2022-06-23 18:12:38.895833
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from dataclasses import dataclass
    from flutils.namedtupleutils import to_namedtuple
    import pytest

    # Test that certain types can't be converted
    @dataclass
    class Test:
        test = 1

    types_tuple = (
        1,
        b'bytes',
        bytearray(),
        range(1),
        Test(),
    )
    for item in types_tuple:
        with pytest.raises(TypeError):
            to_namedtuple(item)

    # Test the various returns types
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple({'a': 1}) == namedt

# Generated at 2022-06-23 18:12:43.538960
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {1: 10, 2: 20}
    res = to_namedtuple(dic)
    assert res == None
    dic = {'a': 1, 'b': 2}
    res = to_namedtuple(dic)
    assert res == None

# Generated at 2022-06-23 18:12:44.883879
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert not hasattr(to_namedtuple, 'register')


# Generated at 2022-06-23 18:12:55.063200
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict
    )
    from itertools import product
    from collections import (
        namedtuple,
        deque,
    )
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-23 18:13:07.106925
# Unit test for function to_namedtuple
def test_to_namedtuple():
    named = to_namedtuple({'foo': {'bar': {'stuff': 1}}})
    assert isinstance(named, NamedTuple)
    assert isinstance(named.foo, NamedTuple)
    assert named.foo.bar.stuff == 1
    named = to_namedtuple({'stuff': {'bar': {'foo': 1}}})
    assert isinstance(named, NamedTuple)
    assert isinstance(named.stuff, NamedTuple)
    assert named.stuff.bar.foo == 1
    named = to_namedtuple({'bar': {'foo': {'stuff': 1}}})
    assert isinstance(named, NamedTuple)
    assert isinstance(named.bar, NamedTuple)
    assert named.bar.foo.stuff == 1

# Generated at 2022-06-23 18:13:16.141733
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def assert_tuple(obj, msg):
        print(obj)
        assert isinstance(obj, NamedTuple)
        assert getattr(obj, 'a', None) is None
        assert getattr(obj, 'b', None) is None
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert_tuple(out, "Can convert a dictionary to NamedTuple")
    dic = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(dic)
    assert_tuple(out, "Can convert a OrderedDict to NamedTuple")
    out = to_namedtuple(SimpleNamespace(a=1, b=2))

# Generated at 2022-06-23 18:13:26.680217
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils import assertstyled

    this_tuple = namedtuple(
        'NamedTuple', 'a b'
    )  # type: NamedTuple
    self = SimpleNamespace(
        this_list=[1, 2, 3],
        this_tuple=this_tuple(a=1, b=2),
        this_dict={
            'a': 1,
            'b': 2,
        },
        this_int=1,
    )

    expected = SimpleNamespace(
        this_list=[1, 2, 3],
        this_tuple=this_tuple(a=1, b=2),
        this_dict=this_tuple(a=1, b=2),
        this_int=1,
    )

    result = to_namedtuple(self)

   

# Generated at 2022-06-23 18:13:39.184150
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import NamedTuple, Set
    from pprint import pformat

    # TODO (type hinting w/o circular import):
    #    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import to_namedtuple

    # noinspection PyProtectedMember,PyTypeChecker
    NamedTupleTester = NamedTuple('NamedTupleTester', [
        'val1',
        'val2',
        'val3',
        'val4',
        'val5',
        'val6',
    ])  # type: ignore[misc]

    def _sort_dict(dic: dict) -> OrderedDict:
        out = OrderedDict()  # type: OrderedDict

# Generated at 2022-06-23 18:13:42.535157
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

if __name__ == "__main__":
    # Run the unit tests
    test_to_namedtuple()

# Generated at 2022-06-23 18:13:53.161155
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    dic = {"a": 1, "b": 2}
    res = to_namedtuple(dic)
    assert res[0] == dic["a"]
    assert res[1] == dic["b"]
    assert res[0] == dic["a"]
    assert res[1] == dic["b"]
    assert res.a == dic["a"]
    assert res.b == dic["b"]

    ordic = OrderedDict({"a": 1, "b": 2})
    res = to_namedtuple(ordic)
    assert res[0] == ordic["a"]
    assert res[1] == ordic["b"]
    assert res.a == ordic["a"]
    assert res.b == ordic["b"]


# Generated at 2022-06-23 18:13:54.669770
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:14:06.688512
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import decimal
    import json

    import jsonschema

    from flutils.namedtupleutils import to_namedtuple

    class _NamedTupleTestCase(unittest.TestCase):
        """
        Testing converting values to a NamedTuple.

        Attribuets:
            data (dict): A dictionary with the structure:
                {
                    'description': <str>,
                    'items': <list>
                        A list of items of the same type.
                    'type': <str>,
                }

        """

        def test_type(self):
            """
            Test converting a dictionary by type.

            """
            for item in self.items:
                nt: Union[NamedTuple, Tuple] = to_namedtuple(item)

# Generated at 2022-06-23 18:14:16.206263
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(
        {'a': 1, 'b': 2}
    ) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(
        [{'a': 1, 'b': 2}, {'a': 2, 'b': 3}]
    ) == [
        namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2),
        namedtuple('NamedTuple', ['a', 'b'])(a=2, b=3)
    ]
    assert to_namedtuple(
        {'A': 1, 'B': 2}
    ) == namedtuple('NamedTuple', ['A', 'B'])(A=1, B=2)

# Generated at 2022-06-23 18:14:28.682603
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import Counter
    from datetime import datetime
    from flutils.namedtupleutils import _to_namedtuple, to_namedtuple
    from flutils.testutils import random_string
    from numbers import Real
    from typing import Optional
    import pytest

    obj = {
        'a': 1,
        'b': 'two',
        'c': Counter(['a', 'b', 'c']),
        'd': [1, 2, 3],
        'e': None,
        'f': datetime.now(),
        'g': {'a': 1, 'b': 2},
        'h': range(10),
        'i': '   ',
    }
    obj2 = {
        'j': 1,
    }

# Generated at 2022-06-23 18:14:33.978173
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    expected = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    actual = to_namedtuple(dic)
    assert actual == expected

    dic = {'_a': 1, 'b': 2}
    expected = namedtuple('NamedTuple', ['b'])(b=2)
    actual = to_namedtuple(dic)
    assert actual == expected

    dic = OrderedDict([('a', 1), ('b', 2)])

# Generated at 2022-06-23 18:14:42.740396
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    assert to_namedtuple('') == ''
    assert to_namedtuple([]) == tuple()
    assert to_namedtuple(()) == tuple()
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple(OrderedDict()) == namedtuple('NamedTuple', '')()
    assert to_namedtuple(SimpleNamespace()) == namedtuple('NamedTuple', '')()
    assert to_namedtuple(True) is True
    assert to_namedtuple(False) is False
    assert to_namedtuple(42) == 42
    assert to_namedtuple(3.14) == 3.14
    assert to_namedtuple('') == ''
   

# Generated at 2022-06-23 18:14:53.925752
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    array = {
        '__dict__': {'a': 1},
        'client': 'client_value',
        'name': 'name_value',
        'set_size': 'set_size_value',
        'test_size': 'test_size_value',
        '_low': '_low_value',
        '__low': '__low_value',
    }
    desired = namedtuple('NamedTuple', ('client', 'name', 'set_size', 'test_size'))(
        client='client_value',
        name='name_value',
        set_size='set_size_value',
        test_size='test_size_value',
    )

# Generated at 2022-06-23 18:15:00.849055
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test :meth:`to_namedtuple`."""
    dic = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': [5, 6, 7]}
    nt = to_namedtuple(dic)
    assert type(nt) is namedtuple('NamedTuple', '')
    assert nt.a == 1
    assert type(nt.b) is namedtuple('NamedTuple', '')
    assert nt.b.c == 3
    assert type(nt.e) is tuple
    assert type(nt.e[0]) is int
    assert nt.e[0] == 5
    assert type(nt.e[1]) is int
    assert nt.e[1] == 6
    assert type(nt.e[2]) is int

# Generated at 2022-06-23 18:15:13.785630
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for Mapping
    obj = {'a': 1, 'b': 2}
    actual = to_namedtuple(obj)
    assert actual == NamedTuple(a=1, b=2)

    obj = {'a': {"_a": 'a'}}
    actual = to_namedtuple(obj)
    assert actual == NamedTuple(a=NamedTuple(_a='a'))

    obj = {'_a': {"_b": 'b'}}
    actual = to_namedtuple(obj)
    assert actual == NamedTuple(_a=NamedTuple(_b='b'))

    obj = {'a': {"_b": 'b'}}
    actual = to_namedtuple(obj)
    assert actual == NamedTuple(a=NamedTuple(_b='b'))



# Generated at 2022-06-23 18:15:24.907876
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for function to_namedtuple."""
    from collections import namedtuple
    import pytest

    _simplevalues = [
        'some',
        'string',
        1,
        2,
    ]

    d_simple = {
        'some': 'string',
        'someint': 1,
    }

    d_simple2 = {
        'some': 'string',
        'someint': 1,
        'somelist': ['some', 'list', 'value'],
    }


# Generated at 2022-06-23 18:15:31.900131
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        defaultdict,
        OrderedDict,
    )
    from datetime import datetime
    from pprint import pprint
    from types import SimpleNamespace

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(('a', 'b', 'c')) == ['a', 'b', 'c']
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple((1, 'a')) == (1, 'a')
    assert to_namedtuple(OrderedDict(zip('abc', [1, 2, 3]))) ==\
        NamedTuple(a=1, b=2, c=3)

# Generated at 2022-06-23 18:15:39.331129
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {1: {'a': 1, 'b': 2}, 2: {'a': 1, 'b': 2}}

# Generated at 2022-06-23 18:15:49.355543
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _dic = {
        'a': 1,
        'b': {
            'c': 2,
            'd': 3
        }
    }
    assert to_namedtuple(_dic) == NamedTuple(a=1, b=NamedTuple(c=2, d=3))
    assert to_namedtuple(_dic.items()) == NamedTuple(a=1, b=NamedTuple(c=2, d=3))
    _dic_od = OrderedDict({'a': 1, 'b': {'c': 2, 'd': 3}})
    assert to_namedtuple(_dic_od) == NamedTuple(a=1, b=NamedTuple(c=2, d=3))

# Generated at 2022-06-23 18:15:54.372227
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from collections import OrderedDict
    from types import SimpleNamespace
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    # Test Mapping
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple)
    assert out.a == 1
    assert out.b == 2
    # Test OrderedDict
    dic = OrderedDict([('one', 1), ('two', 2), ('three', 3)])
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple)
    assert out.one == 1
    assert out.two == 2

# Generated at 2022-06-23 18:16:04.925040
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple

    test_input = {
        'a': 1,
        'b': 2
    }
    actual = to_namedtuple(test_input)
    assert hasattr(actual, 'a')
    assert hasattr(actual, 'b')
    assert actual.a == 1
    assert actual.b == 2

    test_input = [1, 2, 3, 4]
    actual = to_namedtuple(test_input)
    assert isinstance(actual, tuple)
    assert all(isinstance(x, int) for x in actual)

    test_input = [1, 2, 3, 4]
    actual = to_namedtuple(test_input)
    assert isinstance(actual, tuple)

# Generated at 2022-06-23 18:16:06.360554
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-23 18:16:16.247857
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) == 1
    assert to_namedtuple((1, 2, 'a')) == (1, 2, 'a')
    assert to_namedtuple([1, 2, 'a']) == [1, 2, 'a']
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)