

# Generated at 2022-06-23 18:06:17.942612
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple([1, [2, 3]]) == [1, [2, 3]]
    assert to_namedtuple([1, [2, {'3': 4}]]) == [1, [2, NamedTuple(**{'3': 4})]]
    assert to_namedtuple({'1': '2'}) == NamedTuple(**{'1': '2'})
    assert to_namedtuple('1') == '1'
    assert to_namedtuple(1) == 1
    assert to_namedtuple({1: '2'}) == NamedTuple(**{1: '2'})

# Generated at 2022-06-23 18:06:27.971995
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == [
        NamedTuple(a=1, b=2),
        NamedTuple(a=3, b=4),
    ]
    assert to_namedtuple({'a': [1, 2]}) == NamedTuple(a=[1, 2])
    assert to_namedtuple({'a': {'b': 1, 'c': 2}}) == NamedTuple(a=NamedTuple(b=1, c=2))

# Generated at 2022-06-23 18:06:30.035806
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple

# Generated at 2022-06-23 18:06:40.932512
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import types
    assert isinstance(_to_namedtuple({'a': 1, 'b': 2}), namedtuple)
    assert isinstance(_to_namedtuple(SimpleNamespace(a=1, b=2)), namedtuple)
    assert _to_namedtuple(SimpleNamespace(a=1, b=2)) == _to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(_to_namedtuple(OrderedDict([('a', 1), ('b', 2)])), namedtuple)
    assert isinstance(_to_namedtuple(dict([('a', 1), ('b', 2)])), namedtuple)
    assert isinstance(_to_namedtuple((1, 2, 3)), tuple)

# Generated at 2022-06-23 18:06:52.656079
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple([[1, 2, 3], [4, 5, 6]]) == [[1, 2, 3], [4, 5, 6]]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:07:00.601834
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase

    class Test(TestCase):
        def test_ordered_dict_to_namedtuple(self):
            """Test functionality for ordered dictionaries."""
            from collections import OrderedDict

            dic = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
            expect = 'NamedTuple(a=1, b=2, c=3)'
            observe = to_namedtuple(dic)
            self.assertEqual(expect, str(observe))

        def test_list_to_namedtuple(self):
            """Test conversion of a list to a NamedTuple."""
            lis = [1, 2, 3, 4]

# Generated at 2022-06-23 18:07:08.026194
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple

    # Test various things.
    with pytest.raises(TypeError):
        to_namedtuple([[]])
    assert to_namedtuple({'one': 1, 'two': 2}) == namedtuple('NamedTuple', ('one', 'two'))(one=1, two=2)

# Generated at 2022-06-23 18:07:17.881122
# Unit test for function to_namedtuple
def test_to_namedtuple():

    def test(obj, expected):
        result = to_namedtuple(obj)
        assert result == expected

    # test list
    test(
        obj=[{'a': 1, 'b': {'x': 11, 'y': 12}}],
        expected=[NamedTuple(a=1, b=NamedTuple(x=11, y=12))],
    )

    # test tuple
    test(
        obj=(1, {'a': 1, 'b': {'x': 11, 'y': 12}}),
        expected=(1, NamedTuple(a=1, b=NamedTuple(x=11, y=12))),
    )

    # test tuple

# Generated at 2022-06-23 18:07:29.695525
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(None) is None
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple('1') == '1'
    assert to_namedtuple('1.0') == '1.0'
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple(['1']) == ['1']
    assert to_namedtuple((1,)) == (1,)
    assert to_namedtuple(('1',)) == ('1',)
    assert to_namedtuple(tuple()) == tuple()
    assert to_namedtuple(list()) == list()
    assert to_namedtuple({}) == to_namedtuple(OrderedDict()) == NamedTuple()


# Generated at 2022-06-23 18:07:36.483750
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': {
            'b': 4,
            'c': 3,
            'd': 2,
            'e': 1,
            'f': 0,
            'g': {'h': 8, 'i': 7, 'j': 6, 'k': 5},
        },
        'l': [],
        'm': (1, 2, 3, 4, 5),
        'n': {'o': 1, 'p': 2, 'q': 3},
    }
    # Create a namedtuple from the dictionary
    nt = to_namedtuple(dic)
    assert nt.a.b == 4
    assert nt.a.c == 3
    assert nt.a.d == 2
    assert nt.a.e == 1

# Generated at 2022-06-23 18:07:47.918062
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    # Test a None value
    assert to_namedtuple(None) is None

    # Test a list
    in_ = [1, 2, 3]
    out = to_namedtuple(in_)
    assert out == [1, 2, 3]
    assert isinstance(out, list)

    # Test a tuple
    in_ = (1, 2, 3)
    out = to_namedtuple(in_)
    assert out == (1, 2, 3)
    assert isinstance(out, tuple)

    # Test a dictionary
    in_ = {'a': 1, 'b': 2}
    out = to_namedtuple(in_)
    assert out == NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:07:58.955606
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    import logging
    import unittest
    import datetime
    # noinspection PyUnresolvedReferences
    from tests.context import to_namedtuple

    class TestToNamedtuple(unittest.TestCase):
        def test_bad_arg_type(self):
            # Arrange
            # noinspection PyTypeChecker
            obj: str = 'foo'
            # Act
            with self.assertRaises(TypeError) as cm:
                to_namedtuple(obj)
            # Assert
            err = cm.exception
            self.assertEqual(
                str(err),
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                "got: ('str') foo"
            )

# Generated at 2022-06-23 18:08:05.453045
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    """Test to_namedtuple function."""

    # noinspection PyStatementEffect
    """
    Test converting a list of values.
    """
    obj = [1, {'a': 1, 'b': 2}, 3]
    # noinspection Mypy
    expected = [1, NamedTuple(a=1, b=2), 3]  # type: List[Any]
    actual = to_namedtuple(obj)
    assert len(expected) == len(actual)
    for exp, act in zip(expected, actual):
        if hasattr(exp, '_fields'):
            assert exp == act
    assert actual[0] == exp[0]
    assert actual[2] == exp[2]

    # noinspection PyStatementEffect

# Generated at 2022-06-23 18:08:11.892043
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import List, Tuple

    from nose.tools import nottest

    from flutils.namedtupleutils import (
        to_namedtuple,
    )

    if hasattr(test_to_namedtuple, '__test__'):
        setattr(test_to_namedtuple, '__test__', False)
    vals = [[1, 2], [3, 4]]
    tup = to_namedtuple(vals)
    msg = 'Failed to convert tuple: %r to list' % vals
    assert isinstance(tup, list), msg

    tup = to_namedtuple(vals[0])
    msg = 'Failed to convert tuple: %r to tuple' % vals[0]
    assert isinstance(tup, tuple), msg

   

# Generated at 2022-06-23 18:08:24.819401
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = [1, 2, 3]
    new_obj = to_namedtuple(obj)
    assert new_obj == obj

    obj = (1, 2, 3)
    new_obj = to_namedtuple(obj)
    assert new_obj == obj

    obj = {'a': 1, 'b': 2}
    new_obj = to_namedtuple(obj)
    assert new_obj.a == obj['a']
    assert new_obj.b == obj['b']

    obj = {'a': 1, 'b': 2, '_c': 3}
    new_obj = to_namedtuple(obj)
    assert new_obj.a == obj['a']
    assert new_obj.b == obj['b']
    with pytest.raises(AttributeError):
        new_obj._

# Generated at 2022-06-23 18:08:31.875840
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:08:36.110127
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:08:48.535963
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    dct = {'a': 1, 'b': 2}
    nt = namedtuple('nt', 'a b')
    assert nt(a=1, b=2) == to_namedtuple(dct)
    assert nt(a=1, b=2) == to_namedtuple(namedtuple('nt', 'a b')
                                         (a=1, b=2))
    assert nt(a=1, b=2) == to_namedtuple(nt(a=1, b=2))
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(dct, _started=True) == nt(a=1, b=2)

# Generated at 2022-06-23 18:08:56.615221
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _nested_item(dct: dict) -> NamedTuple:
        return to_namedtuple(dct)

    dct_camel = {
        'oneA': 1,
        'twoB': 2,
        'threeC': 3,
    }
    dct_snake = {
        'one_a': 1,
        'two_b': 2,
        'three_c': 3,
    }
    dct_nest = {
        'one_a': 1,
        'two_b': 2,
        'three_c': 3,
        'four': _nested_item({'A': 1, 'B': 2, 'C': 3, 'D': 'four'}),
    }

    obj = to_namedtuple(dct_snake)

# Generated at 2022-06-23 18:09:04.475879
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyTypeChecker
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:09:11.961794
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = OrderedDict({'a': 1, 'b': 2, 'c': 3})
    nt = to_namedtuple(d)
    assert nt.a == 1 and nt.b == 2 and nt.c == 3
    nt2 = to_namedtuple(namedtuple('NamedTuple', 'a b')(1, 2))
    assert nt2.a == 1 and nt2.b == 2
    nt3 = to_namedtuple(SimpleNamespace(a=1, b=2))
    assert nt3.a == 1 and nt3.b == 2
    nt4 = to_namedtuple({'a': 1, 'b': 2, '_c': 3})
    assert nt4.a == 1 and nt4.b == 2
    nt

# Generated at 2022-06-23 18:09:23.410612
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    """
    Test to_namedtuple in the flutils package.
    """
    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import to_namedtuple

    # Test to_namedtuple
    test_dict = {
        'a': 1,
        'b': 'A',
    }
    named_tuple = to_namedtuple(test_dict)
    assert hasattr(named_tuple, 'a')
    assert not hasattr(named_tuple, 'b')
    assert hasattr(named_tuple, 'B')
    assert named_tuple.a == 1
    assert named_tuple.B == 'A'
    assert named_tuple[0] == 1

# Generated at 2022-06-23 18:09:34.954127
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-23 18:09:45.986832
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.textutils import indented
    from typing import Optional
    import pytest

    with pytest.raises(TypeError):
        _ = indented('a', indent=4)
        print(_)  # pragma: no cover

    # noinspection PyCallingNonCallable
    _ = indented.__dispatch__('a')
    print(_)  # pragma: no cover

    def _test_lister(
            obj: Optional[Sequence] = None,
            exception: Optional[Exception] = None
    ) -> None:
        if exception is not None:
            # noinspection PyTypeChecker
            with pytest.raises(exception):
                _ = to_namedtuple(obj)
                print(_)  # pragma: no cover
            return

# Generated at 2022-06-23 18:09:54.946707
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""

    with pytest.raises(TypeError):
        assert to_namedtuple(1) == 1

    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()

    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple({'_a': 1, '_b': 2}) == namedtuple('NamedTuple', '_a _b')(_a=1, _b=2)
    assert to_namedtuple({'A': 1, 'b': 2}) == namedtuple('NamedTuple', 'b')(b=2)

    assert to_namedtuple

# Generated at 2022-06-23 18:10:06.756702
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple([[1, 2], 1, 2, 3]) == [[1, 2], 1, 2, 3]
    assert to_namedtuple([[1, 2], [3, 4]]) == [[1, 2], [3, 4]]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(((1, 2), 1, 2, 3)) == ((1, 2), 1, 2, 3)
    assert to_namedtuple(((1, 2), (3, 4))) == ((1, 2), (3, 4))

# Generated at 2022-06-23 18:10:18.334684
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    # Dictionary
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    nt = to_namedtuple(OrderedDict(a=1, b=2))
    assert nt.a == 1
    assert nt.b == 2
    nt = to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))
    assert nt.a == 1
    assert nt.b == 2
    # List

# Generated at 2022-06-23 18:10:30.104512
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Create a dict with a dict
    dic = {
        'a': 1,
        'b': 2,
        'c': {
            'ca': 1,
            'cb': 2,
            'cc': 3,
        },
        'd': {
            'da': 1,
            'db': 2,
            'dc': {
                'dca': 1,
                'dcb': 2,
                'dcc': 3,
            },
        },
    }
    # Convert the dict to a namedtuple
    out = to_namedtuple(dic)

    assert isinstance(out, NamedTuple)

    # The output class should have a, b, and c
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')

# Generated at 2022-06-23 18:10:40.158496
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic: Mapping[str, Any] = {
        'a': 1,
        'b': 2,
        'c': {
            'd': (1, 2, 3),
            'e': [4, 5, 6],
            'f': 'foo',
        },
        'g': {
            'h': {
                'i': 9,
                'j': 10,
            },
        },
    }
    obj = to_namedtuple(dic)
    assert obj.c[1] == 2
    assert obj.c.d[0] == 1
    assert obj.c.e[0] == 4
    assert obj.c.e[2] == 6
    assert obj.g.h.i == 9
    assert obj.g.h.j == 10
    obj: NamedTuple = to

# Generated at 2022-06-23 18:10:51.517280
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json

# Generated at 2022-06-23 18:11:03.835127
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == \
        cast(NamedTuple, (1, 2, 3))
    assert to_namedtuple({'a': {'b': 1, 'c': 2, 'd': 3}, 'e': 4}) == \
        cast(NamedTuple, (NamedTuple(b=1, c=2, d=3), 4))

# Generated at 2022-06-23 18:11:11.667795
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert isinstance(obj, tuple)
    assert obj.a == 1
    assert obj.b == 2

    dic = {
        'a': 1,
        'b': {'c': 3, 'd': 4},
    }
    obj = to_namedtuple(dic)
    assert isinstance(obj, tuple)
    assert obj.a == 1
    assert obj.b.c == 3
    assert obj.b.d == 4

    dic = {
        'a': 1,
        'b': [{'c': 3}, {'d': 4}],
    }
    obj = to_namedtuple(dic)
    assert isinstance(obj, tuple)
    assert obj

# Generated at 2022-06-23 18:11:22.815877
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections.abc import Mapping, Sequence
    from collections import namedtuple

    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert isinstance(to_namedtuple(['a', 'b']), list)
    assert to_namedtuple(('a', 'b')) == ('a', 'b')
    assert isinstance(to_namedtuple(('a', 'b')), tuple)

    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)


# Generated at 2022-06-23 18:11:24.921433
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    print(to_namedtuple(dic))


# Generated at 2022-06-23 18:11:33.570801
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import types
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert type(out) == types.SimpleNamespace
    assert out.a == 1
    assert out.b == 2
    oto = to_namedtuple(out)
    assert type(oto) == tuple
    assert oto[0] == 1
    assert oto[1] == 2
    a = to_namedtuple([1, 2, 3, {'a': 1, 'b': 2}])
    assert type(a) == list
    assert type(a[-1]) == types.SimpleNamespace
    assert a[-1].a == 1
    assert a[-1].b == 2

# Generated at 2022-06-23 18:11:43.176597
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple(((1,), {'a': 1, 'b': 2})) == (
        (1,),
        NamedTuple(a=1, b=2)
    )
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == (
        NamedTuple(a=1, b=2)
    )
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to

# Generated at 2022-06-23 18:11:45.511392
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for function to_namedtuple."""
    raise Exception('Not implemented.')

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-23 18:11:57.011472
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Dict, List, NamedTuple, Set, Tuple
    from collections import defaultdict
    from collections.abc import Sequence
    from types import SimpleNamespace

    class A(NamedTuple):
        a: int
        b: str
        c: Dict[int, str]

    class B(NamedTuple):
        a: List[int]
        b: Set[int]

    class C(NamedTuple):
        a: A
        b: Sequence
        c: SimpleNamespace

    class D(NamedTuple):
        a: List[A]
        b: Tuple[str, ...]
        c: Dict[str, A]


# Generated at 2022-06-23 18:12:08.809883
# Unit test for function to_namedtuple
def test_to_namedtuple():
    items = [1, 2]
    dic = {'a': 1, 'b': 2}
    nt = namedtuple('test', 'a b')(1, 2)
    ordered = OrderedDict(a=1, b=2)
    namespace = SimpleNamespace(a=1, b=2)

    assert to_namedtuple(items) == [1, 2]
    assert to_namedtuple(tuple(items)) == (1, 2)
    assert isinstance(to_namedtuple(dic), namedtuple)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dic) == to_namedtuple(ordered)

# Generated at 2022-06-23 18:12:17.127342
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import abc

    # noinspection PyUnusedLocal
    def _to_namedtuple(obj: Union[list, dict, abc.Mapping]):
        return to_namedtuple(obj)

    # noinspection PyUnusedLocal
    def _to_namedtuple_expected(obj: Union[list, dict, abc.Mapping]):
        return obj

    # noinspection PyTypeChecker
    args = (
        # list
        ([{'a': 1, 'b': 2}, {'a': 1, 'b': 2}],),
        # dict
        ({'a': 1, 'b': 2},),
    )
    # noinspection PyTypeChecker

# Generated at 2022-06-23 18:12:28.112774
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test namedtupleutils.to_namedtuple"""
    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import to_namedtuple

    dic = {'b': 2, 'a': 1}
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dic) == expected
    assert to_namedtuple(dic).a == 1
    assert to_namedtuple(dic).b == 2

    dic = {'a': 1, 'b': {'c': 3}}
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=namedtuple('NamedTuple', 'c')(c=3))

# Generated at 2022-06-23 18:12:37.850937
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from types import SimpleNamespace
    dic = {'a': 1, 'b': 2}
    make: namedtuple = namedtuple('NamedTuple', 'a b')
    expected = make(1, 2)
    assert to_namedtuple(dic) == expected
    lst: List[Dict[str, int]] = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    out = to_namedtuple(lst)
    expected = [make(1, 2), make(3, 4)]
    assert out == expected
    item: Tuple[Dict[str, int]] = (lst[0],)
    out = to_namedtuple(item)
    expected = (make(1, 2),)
    assert out == expected

# Generated at 2022-06-23 18:12:50.031634
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Convert non-dict, non-list, non-tuple
    assert to_namedtuple(1) is 1
    assert to_namedtuple(True) is True
    assert to_namedtuple(None) is None
    assert to_namedtuple('1') == '1'
    assert to_namedtuple(True) is True

    # Convert list
    lis = [1, 2, 3]
    out = to_namedtuple(lis)
    assert out == [1, 2, 3]
    assert lis == [1, 2, 3]
    assert isinstance(out, list)
    assert isinstance(out[0], int)
    assert out[0] == 1
    assert out[1] == 2
    assert out[2] == 3

    # Convert list that contains another list

# Generated at 2022-06-23 18:12:57.930352
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    test = to_namedtuple(dic)
    assert test.a == 1
    assert test.b == 2

    dic = {'a': None, 'b': None, 'c': None}
    test = to_namedtuple(dic)
    assert test.a is None
    assert test.b is None
    assert test.c is None

    dic = {'a': 1, 'b': {'c': 2}}
    test = to_namedtuple(dic)
    assert test.a == 1
    assert test.b.c == 2

    dic = {'a': 1, 'b': 2, '_c': 3, 'd': {'_e': 4}}
    test = to_namedtuple(dic)


# Generated at 2022-06-23 18:13:09.407548
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _test_to_namedtuple_01()
    _test_to_namedtuple_02()
    _test_to_namedtuple_03()
    _test_to_namedtuple_04()
    _test_to_namedtuple_05()
    _test_to_namedtuple_06()
    _test_to_namedtuple_07()
    _test_to_namedtuple_08()
    _test_to_namedtuple_09()
    _test_to_namedtuple_10()
    _test_to_namedtuple_11()
    _test_to_namedtuple_12()
    _test_to_namedtuple_13()
    _test_to_namedtuple_14()
    _test_to_namedtuple_15()
    _test_

# Generated at 2022-06-23 18:13:18.896416
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    class Test(unittest.TestCase):
        def setUp(self) -> None:
            self.dic = {'a': 1, 'b': 2}
            self.od = OrderedDict()
            self.od['a'] = 1
            self.od['b'] = 2
            self.od['c'] = 3
            self.od['d'] = ({'e': 4, 'f': 5, 'g': 6}, [7, 8, 9])
            self.sn = SimpleNamespace(a=1, b=2)
            self.tup = (1, 2, 3)
            self.li = [1, 2, 3]
            self.dic_li = {'a': [1, 2, 3], 'b': (1, 2, 3)}
            self.obj

# Generated at 2022-06-23 18:13:27.533103
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testutils import is_namedtuple
    from typing import List

    d = dict(a=1, b=2)
    nt = to_namedtuple(d)
    assert is_namedtuple(nt)
    assert nt.a == 1
    assert nt.b == 2
    nt = to_namedtuple([d, d, d])
    assert isinstance(nt, List)
    assert is_namedtuple(nt[0])
    assert nt[0].a == 1
    assert nt[0].b == 2
    assert nt[1].a == 1
    assert nt[1].b == 2
    assert nt[2].a == 1
    assert nt[2].b == 2
   

# Generated at 2022-06-23 18:13:35.178635
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {"a": 1, "b": 2}
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    arr = [1, 2, 3]
    assert to_namedtuple(arr) == arr
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic
    assert to_namedtuple(dic) == dic

# Generated at 2022-06-23 18:13:44.812661
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import types
    from collections import OrderedDict, namedtuple
    def assert_match_type(in_obj, exp_type):
        out_obj = to_namedtuple(in_obj)
        assert type(out_obj) == exp_type
    def assert_equal(in_obj, exp_obj):
        out_obj = to_namedtuple(in_obj)
        assert out_obj == exp_obj
    tuple_namedtuple = namedtuple('B', 'a b c')
    tuple_obj = (1, 2, 3)
    tuple_obj_exp = tuple_namedtuple(1, 2, 3)
    dict_namedtuple = namedtuple('C', 'a b c')
    dict_obj = {'a': 1, 'c': 3, 'b': 2}
    dict

# Generated at 2022-06-23 18:13:50.738127
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(SimpleNamespace(a=1, b=2, c=3)) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(OrderedDict([('c', 1), ('a', 2), ('b', 3)])) == NamedTuple(c=1, a=2, b=3)
    assert to_namedtuple(dict(a=1, b=2, c=3)) == NamedTuple(a=1, b=2, c=3)
    dic = dict(a=1, b=2, _c=3)
    assert to_

# Generated at 2022-06-23 18:14:03.745099
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    import types

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic).a == 1
    assert to_namedtuple(dic).b == 2

    dic = [1, 2, 3]
    assert to_namedtuple(dic)[0] == 1
    assert to_namedtuple(dic)[1] == 2
    assert to_namedtuple(dic)[2] == 3

    dic = [1, 2, 3]
    assert to_namedtuple(dic)[0] == 1
    assert to_namedtuple(dic)[1] == 2
    assert to_namedtuple(dic)[2] == 3

    dic = {'a': 1, 'b': 2}
    assert to_

# Generated at 2022-06-23 18:14:13.400733
# Unit test for function to_namedtuple

# Generated at 2022-06-23 18:14:26.393640
# Unit test for function to_namedtuple
def test_to_namedtuple():
    #pylint: disable=E0611,W0613,R0201
    #Test dict
    obj = dict(a=1)
    assert to_namedtuple(obj) == obj
    obj = dict(a=1, b=2)
    assert to_namedtuple(obj) == obj
    obj = dict(a=1, b=2, c=3)
    assert to_namedtuple(obj) == obj
    obj = dict(a=1, b=2, c=3)
    assert to_namedtuple(obj) == obj
    obj = dict(a1=1, b2=2, c3=3)
    assert to_namedtuple(obj) == obj
    obj = dict(a1=1, b2=2, c3=3, d4=4)

# Generated at 2022-06-23 18:14:33.269974
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None

    from typing import Dict, List, Tuple

    from flutils.namedtupleutils import to_namedtuple

    dic: Dict[str, Any] = {'a': 1, 'b': {'a': 1, 'b': 2}, 'c': [1, 2, 3]}
    nt1 = to_namedtuple(dic)
    # noinspection PyTypeChecker
    assert nt1.a == 1
    # noinspection PyTypeChecker
    assert nt1.b.a == 1
    # noinspection PyTypeChecker
    assert nt1.b.b == 2
    # noinspection PyTypeChecker
    assert nt1.c[0] == 1
    # noinspection PyTypeChecker

# Generated at 2022-06-23 18:14:40.976733
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace

    tup = namedtuple('TestNamedTuple', 'one two three four five')
    s_namespace = SimpleNamespace(one=1, two=2, three=3, four=4, five=5)

    lst = [
        {'one': 1},
        {'one': 1, 'two': 2},
        {'one': 1, 'two': 2, 'three': 3},
        {'one': 1, 'two': 2, 'three': 3, 'four': 4},
        {'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5},
    ]

# Generated at 2022-06-23 18:14:42.091591
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-23 18:14:53.391889
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import Any, List, NamedTuple, Tuple, Union

    # noinspection PyTypeChecker
    _AllowedTypes = Union[
        List,
        OrderedDict,
        SimpleNamespace,
        Tuple,
    ]
    # noinspection PyUnusedLocal
    _NamedTuple = NamedTuple

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)

    assert to_namedtuple({'a': 1, 'b': 2}) == _NamedTuple(a=1, b=2)

# Generated at 2022-06-23 18:15:00.434839
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import seed as rseed
    from random import randrange as rrange
    from random import choice
    from string import ascii_letters as letters
    from string import punctuation as puncs
    from string import digits
    from collections import OrderedDict
    from types import SimpleNamespace
    from copy import copy

    rseed(1)

    # noinspection PyTypeChecker
    dic: Mapping[str, Any] = dict()

    use_ordered = True

    # noinspection PyTypeChecker
    nmlist: List[NamedTuple] = []  # type: ignore
    # noinspection PyTypeChecker
    tplist: List[tuple] = []  # type: ignore
    # noinspection PyTypeChecker
    odlist: List[OrderedDict] = []
    #

# Generated at 2022-06-23 18:15:13.163705
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    ns: SimpleNamespace = SimpleNamespace(a=1, b=2)
    nt: NamedTuple = to_namedtuple(ns)
    assert nt.a == ns.a
    assert nt.b == ns.b
    assert nt[0] == nt.a
    assert nt[1] == nt.b
    with pytest.raises(TypeError):
        to_namedtuple(1)

# Generated at 2022-06-23 18:15:24.385412
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic_orig = {
        'a': {
            'b': 1, 'c': 2,
            'ad': {'ae': 1, 'af': 2},
        },
        'd': 2,
        'e': [1, 2, 3],
        'f': 'str',
        'g': {'h': 1},
    }
    dic_expected = OrderedDict(
        (('f', 'str'), ('d', 2), ('a', OrderedDict(
            (('ad', OrderedDict(
                (('af', 2), ('ae', 1)),
            )), ('c', 2), ('b', 1))
        )), ('g', OrderedDict(
            (('h', 1),)
        )), ('e', [1, 2, 3]))
    )
    d

# Generated at 2022-06-23 18:15:31.622992
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class Test_to_namedtuple(unittest.TestCase):

        def test_to_namedtuple_list_invalid(self):
            with self.assertRaises(TypeError) as err:
                to_namedtuple(list)
            self.assertRegex(
                str(err.exception),
                r"Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                r"got: \(.+\) <class 'list'>"
            )

        def test_to_namedtuple_tuple_invalid(self):
            with self.assertRaises(TypeError) as err:
                to_namedtuple(tuple)

# Generated at 2022-06-23 18:15:37.003867
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils

    assert flutils.namedtupleutils.to_namedtuple({'a': 1, 'b': 2}) == \
        "NamedTuple(a=1, b=2)"


# Generated at 2022-06-23 18:15:47.945268
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from datetime import datetime
    from types import SimpleNamespace
    from pprint import pprint

    def assert_equal(
            obj1: Any,
            obj2: Any,
            print_items: bool = False
    ) -> None:
        assert obj1 == obj2
        if print_items:
            pprint(obj1)
            pprint(obj2)

    assert_equal(
        to_namedtuple({'a': 1, 'b': 2}),
        namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2),
        print_items=True
    )


# Generated at 2022-06-23 18:15:59.036681
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lst = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    out = to_namedtuple(lst)
    assert out[0].a == 1
    assert out[1].d == 4

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    nt_in = namedtuple('NamedTuple', ['a', 'b'], defaults=[1, 2])()
    out = to_namedtuple(nt_in)
    assert out.a == 1
    assert out.b == 2

    od = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(od)


# Generated at 2022-06-23 18:16:08.119595
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {
        'a': {'_a': 1, 'b': 2},
        'b': [1, 2, 3],
        'c': {'a': 1, '_b': 2},
        'd': [{'a': 1}],
        'e': {'a': {1: 2}},
    }
    dic_keys: Tuple[str, ...] = tuple(sorted(dic.keys()))

    expected = namedtuple('NamedTuple', dic_keys)
    out = to_namedtuple(dic)
    assert isinstance(out, expected)
    a: Tuple[int, int] = out.a
    assert a[0] == 1 and a[1] == 2
   

# Generated at 2022-06-23 18:16:09.882872
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a':1, 'b':2}
    out = to_namedtuple(dic)

# Generated at 2022-06-23 18:16:18.199739
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple({'_b': 2, '_a': 1}) == {'_b': 2, '_a': 1}