

# Generated at 2022-06-11 22:15:18.830174
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import os
    abspath = os.path.abspath(__file__)
    dn = os.path.dirname(abspath)
    up = os.path.dirname(dn)
    sys.path.append(up)
    import flutils
    from flutils.namedtupleutils import _to_namedtuple, to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    dic_out = _to_namedtuple(dic)
    assert hasattr(dic_out, 'a')
    assert hasattr(dic_out, 'b')
    assert not hasattr(dic_out, 'c')
    assert dic_out.a == 1

# Generated at 2022-06-11 22:15:31.143634
# Unit test for function to_namedtuple
def test_to_namedtuple():
#     dic = {'a': 1, 'b': {'c': {'d': 2}}}
#     dic = {'a': 1, 'b': 2, 'c': {'d': 2}}
#     dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
#     dic = [1, 2, 3, 4]
#     dic = (1, 2, 3, 4)
#     dic = {'a': 1, 'b': 2, 'c': {'d': 2, 'e': 5}}
    dic = [{'a': 1, 'b': 2, 'c': {'d': 2, 'e': 5}}, 1, 2, 3]

# Generated at 2022-06-11 22:15:38.115517
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test for function to_namedtuple."""
    tup = (
        {'a': 1, 'b': 2},
        [3, 4],
        5,
        {'c': (6, 7, 8), 'd': 9},
        [{'e': 10, 'f': (11, 12)}],
        {'g': {'h': {'i': (13, 14)}}},
        {'j': [{'k': {'l': {'m': 15}}}]},
    )
    obj = to_namedtuple(tup)
    assert isinstance(obj, tuple)
    assert len(obj) == 7
    assert isinstance(obj[0], NamedTuple)
    assert isinstance(obj[1], list)
    assert isinstance(obj[2], int)

# Generated at 2022-06-11 22:15:46.921674
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(dict(a=1, b=2)) == simple_tuple(a=1, b=2)
    assert to_namedtuple(OrderedDict(a=1, b=2)) == simple_tuple(a=1, b=2)
    assert to_namedtuple(OrderedDict(b=2, a=1)) == simple_tuple(b=2, a=1)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == simple_tuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(b=2, a=1)) == simple_tuple(a=1, b=2)
    assert to_namedtuple(dict(a=1, _b=2)) == simple_tuple

# Generated at 2022-06-11 22:15:57.868632
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import sys

    from typing import List, Tuple

    from flutils.namedtupleutils import to_namedtuple

    class Test_to_namedtuple(unittest.TestCase):
        """Unit tests for function flutils.namedtupleutils.to_namedtuple"""

        def test_TypeError(self):
            """Test TypeError is raised on invalid type"""
            args = (True,)
            self.assertRaises(TypeError, to_namedtuple, *args)

        def test_empty_list(self):
            """Test an empty list"""
            args = ([],)
            expected = []
            actual = to_namedtuple(*args)
            self.assertEqual(expected, actual)


# Generated at 2022-06-11 22:16:09.878460
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == to_namedtuple((1, 2, 3)) == [1, 2, 3]
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'_a': 1, 'b': 2}) == NamedTuple(b=2)
    assert to_namedtuple({'__a': 1, 'b': 2}) == NamedTuple(b=2)

# Generated at 2022-06-11 22:16:16.745902
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.validators import validate_identifier

    testset = [
        {'_id': '123', 'name': 'Eve', 'age': 26,
         'spouse': '{}', 'kids': list(), 'pets': {}},

        list(range(8)),

        ('a', 'b', 'c'),

        ('a', ('b', ('c', ('d', 'e')), 'f'), 'g'),

        {'a': 'b', 'c': {'d': 'e', 'f': 'g'}, 'h': {'i': {'j': 'k'}}},

        {'a': 'b', 'c': ('d', 'e'), 'f': {'g': 'h'}, 'i': list(range(5))},
    ]


# Generated at 2022-06-11 22:16:25.717493
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import namedtuple
    from collections.abc import Mapping
    from flutils.namedtupleutils import to_namedtuple

    def check_equality(
            tp: type,
            obj: Union[Mapping, List, Tuple]
    ) -> None:
        assert isinstance(obj, tp)
        if isinstance(obj, namedtuple):
            assert isinstance(obj._fields, tuple)
            assert isinstance(obj._asdict, classmethod)
            if hasattr(obj, '__len__'):
                assert len(obj) == len(obj._fields)
                assert len(obj) == len(obj._asdict())
            for field in obj._fields:
                assert isinstance(field, str)
                assert isinstance(getattr(obj, field), str)
       

# Generated at 2022-06-11 22:16:33.980128
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == cast(NamedTuple, dic)
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(**dic)
    dic = OrderedDict(
        [('a', 1), ('b', 2)]
    )
    exp = OrderedDict(
        [('a', 1), ('b', 2)]
    )
    assert to_namedtuple(dic) == exp
    dic = {'b': 2, 'a': 1}
    exp = OrderedDict(
        [('a', 1), ('b', 2)]
    )
    assert to_namedtuple(dic) == exp
    dic

# Generated at 2022-06-11 22:16:41.701196
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    lst = [dic, dic]
    out = to_namedtuple(lst)
    assert out[0] == dic
    assert out[1] == out[0]

    tup = tuple(lst)
    out = to_namedtuple(tup)
    assert out == tup

    dic = {'': 0, 'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    out = to_namedtuple(dic)
    assert out._asdict() == dic

    lst = [dic, dic]
    out = to_named

# Generated at 2022-06-11 22:16:48.894769
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=True)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:16:57.972773
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    _ = to_namedtuple(dic)
    assert _ == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)


# Include the unit test from the module
if __name__ == "__main__":
    import doctest

    doctest.testmod(
        optionflags=doctest.ELLIPSIS + doctest.NORMALIZE_WHITESPACE +
        doctest.REPORT_NDIFF
    )

# Generated at 2022-06-11 22:17:09.067308
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([OrderedDict([('a', 1), ('b', 2)]), 1]) == [OrderedDict([('a', 1), ('b', 2)]), 1]
    assert to_namedtuple([dict([('a', 1), ('b', 2)]), 1]) == [NamedTuple(a=1, b=2), 1]
    assert to_namedtuple([{'a': 1, 'b': 2}, 1]) == [NamedTuple(a=1, b=2), 1]
    assert to_namedtuple((1, OrderedDict([('a', 1), ('b', 2)]), 1)) == (1, OrderedDict([('a', 1), ('b', 2)]), 1)

# Generated at 2022-06-11 22:17:19.149291
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([]) == []
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': {'a': 1, 'b': 2}}) == NamedTuple(
        a=NamedTuple(a=1, b=2)
    )

# Generated at 2022-06-11 22:17:27.430578
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from collections import namedtuple
    import pytest

    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup
    tup = (1, 2, 3, SimpleNamespace(b='b', a='a', c='c'))
    out = (1, 2, 3, SimpleNamespace(a='a', b='b', c='c'))
    assert to_namedtuple(tup) == out
    d = {'b': 'b', 'a': 'a', 'c': 'c'}
    assert to_namedtuple(d) == SimpleNamespace(a='a', b='b', c='c')
    ord_dict = OrderedDict()

# Generated at 2022-06-11 22:17:37.522283
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(42) == 42
    assert to_namedtuple(None) is None
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert to_namedtuple({'a': 1, 'b': 2}) == ('a', 'b')
    assert to_namedtuple({'a': 1, 'b': 2}).a == 1
    assert to_namedtuple({'a': 1, 'b': 2}).b == 2
    assert to_namedtuple({'a': 1, 'b': 2}) == ('a', 'b')

# Generated at 2022-06-11 22:17:48.075604
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj1 = ({'a': 1, 'b': 2}, {'c': 3, 'd': 4}, {'e': 5, 'f': 6})
    obj2 = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}, {'e': 5, 'f': 6}]
    ans1 = (NamedTuple(a=1, b=2), NamedTuple(c=3, d=4), NamedTuple(e=5, f=6))
    ans2 = [NamedTuple(a=1, b=2), NamedTuple(c=3, d=4), NamedTuple(e=5, f=6)]
    assert to_namedtuple(obj1) == ans1
    assert to_namedtuple(obj2) == ans2

# Generated at 2022-06-11 22:17:52.784041
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {
        'a': 1,
        'b': 2,
        'c': {
            '_d': 4,
            'e': 5
        }
    }
    assert to_namedtuple(d) == NamedTuple(a=1, b=2, c=NamedTuple(e=5))

# Generated at 2022-06-11 22:18:04.635535
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': {'e': 5}, 'f': 6}) == NamedTuple(a=1, b=2, c=3, d=NamedTuple(e=5), f=6)

# Generated at 2022-06-11 22:18:15.663953
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    dic = OrderedDict(
        [('a', 1), ('b', 2), ('c', 3), ('f_o_o', 'bar'), ('_bar', 'foo')]
    )
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b f_o_o c')(1, 2, 'bar', 3)
    assert to_namedtuple(dic.keys()) == (
        'a',
        'b',
        'c',
        'f_o_o',
        '_bar',
    )
    bar = SimpleNamespace(a=1, b=2, c=3)
    assert to_namedtuple(bar.__dict__)

# Generated at 2022-06-11 22:18:32.384353
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic1 = {'a': 1, 'b': 2}
    dic2 = {'b': 2, 'a': 1}

    assert to_namedtuple(dic1) == to_namedtuple(dic2)

    class Obj(object):

        def __init__(self, x, y, *args, **kwargs):
            self.x = x
            self.y = y
            self.__dict__.update(kwargs)
            self.args = args

    obj = Obj(1, 2, 3, 4, 5, 6, a=1, b=2)
    assert to_namedtuple(obj.__dict__) == to_namedtuple(Obj.__dict__)

    ntuple = to_namedtuple(obj)
    assert n

# Generated at 2022-06-11 22:18:44.624282
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    actual = to_namedtuple(dic)
    expected = NamedTuple(a=1, b=2)
    assert actual == expected
    assert actual.a == 1
    assert actual.b == 2
    dic_ = {'a': 1, 'b': {'x': 3, 'y': 4}}
    actual = to_namedtuple(dic_)
    expected = NamedTuple(a=1, b=NamedTuple(x=3, y=4))
    assert actual == expected
    assert actual.b.x == 3
    assert actual.b.y == 4
    dic__ = {'a': 1, 'b': {'x': [5, 6]}}
    actual = to_namedtuple(dic__)


# Generated at 2022-06-11 22:18:54.974516
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestClass(unittest.TestCase):
        def test_dict(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertIsInstance(out, namedtuple('NamedTuple', 'a b'),)
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)

        def test_list(self):
            data = [
                {'a': 1, 'b': 2},
                {'b': 2, 'a': 1}
            ]
            out = to_namedtuple(data)
            self.assertIsInstance(out, list)

# Generated at 2022-06-11 22:19:05.821125
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test with Mapping
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

    # Test with OrderedDict
    assert to_namedtuple(OrderedDict(a=1, b=2)) == NamedTuple(a=1, b=2)

    # Test with SimpleNamespace
    # noinspection Mypy
    ns = SimpleNamespace(a=1, b=2)  # type: ignore[attr-defined]
    # noinspection PyTypeChecker
    assert to_namedtuple(ns) == NamedTuple(a=1, b=2)

    # Test with list
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) \
       

# Generated at 2022-06-11 22:19:16.897666
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    import types
    import sys

    dic = {'a': 1, 'b': 2}
    tup = to_namedtuple(dic)
    assert tup == NamedTuple(a=1, b=2)

    d = {'k': {'a': 1, 'b': 2}, 'k2': 'str'}
    tup = to_namedtuple(d)
    assert tup == NamedTuple(k2='str', k=NamedTuple(a=1, b=2))

    d = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    od = OrderedDict(d)
    tup = to_named

# Generated at 2022-06-11 22:19:17.899064
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:19:28.805388
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import choice
    from string import ascii_letters

    def _random_string() -> str:
        letters = list(ascii_letters)
        out = ''
        for _ in range(50):
            letter = choice(letters)
            out += letter
        return out

    def _random_dict() -> dict:
        import random
        out: dict = {}
        while True:
            key = _random_string()
            key = key.replace(' ', '_')
            if not key in out:
                out[key] = random.randint(0, 100)
            else:
                break
        return out

    def _random_list() -> list:
        out: list = []
        for _ in range(10):
            rand_key = _random_dict()
            rand_key = to_named

# Generated at 2022-06-11 22:19:37.835307
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from dataclasses import dataclass
    from collections import deque
    from typing import Dict, List
    from flutils.conversionutils import (
        to_namedtuple as flto_namedtuple,
    )

    @dataclass
    class TestIn:
        d: Dict[str, int]
        od_d: OrderedDict
        l_d: List[Dict[str, int]]
        sn_d: SimpleNamespace
        dq_d: deque
        l_l: List[List[str]]

    d = {'a': 1, 'b': 2}
    od_d = OrderedDict({'a': 1, 'b': 2})
    l_d = [{'a': 1}, {'b': 2}]

# Generated at 2022-06-11 22:19:47.975060
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple.

    :return:
        ``None``
    """
    from collections import OrderedDict
    from io import StringIO
    from sre_compile import isstring
    from types import SimpleNamespace
    from unittest.mock import Mock, patch
    from unittest import TestCase, main
    import sys
    import types


# Generated at 2022-06-11 22:19:56.221116
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    tuple = ('a', 'b')
    str = ('a', 'b')
    list = ['a', 'b']
    obj = SimpleNamespace(a=1, b=2)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', dic.keys())(*dic.values())
    assert to_namedtuple(tuple) == namedtuple('NamedTuple', tuple)(*tuple)
    assert to_namedtuple(str) == tuple(str)
    assert to_namedtuple(list) == tuple(list)
    assert to_namedtuple(obj) == namedtuple('NamedTuple', obj.__dict__.keys())(*obj.__dict__.values())

# Generated at 2022-06-11 22:20:09.297117
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 22:20:14.090474
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:20:21.127414
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import datetime


    def test_namedtuple_equal(expected, result):
        assert expected == result, "%s != %s" % (expected, result)
        assert len(expected) == len(result), "%d != %d" % (len(expected), len(result))
        assert all(expected[i] == result[i]
                   for i in range(len(expected))), "%r != %r" % (expected, result)
        if expected.__class__.__name__ == "NamedTuple":
            assert type(expected) == type(result), (
                "%r != %r" % (expected.__class__.__name__, result.__class__.__name__))

# Generated at 2022-06-11 22:20:30.135527
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.tests.pytest_helpers import (
        CustomEquality, BaseNamedTuple)

    assert BaseNamedTuple(a=1, b=2) == to_namedtuple({'a':1, 'b':2})
    assert BaseNamedTuple(a=1, b=2) != to_namedtuple({'a':2, 'b':1})
    assert BaseNamedTuple(a=1, b=2) != to_namedtuple({'a':1, 'b':2, 'c':3})

    assert BaseNamedTuple(a=1, b=2) == to_namedtuple({'b': 2, 'a': 1})

# Generated at 2022-06-11 22:20:40.397195
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pytest import raises
    # Test tuple
    tup = (1, 2, {'a': 1, 'b': 2},
           [1, 2, 3, {'c': 3, 'd': 4}, {'e': 5, 'f': 6}],
           SimpleNamespace(foo=1, bar=2, baz={'a': 1, 'b': 2},
                           fiz='one', fuz=['a', 'b', 'c']),
           namedtuple('TestTuple', 'x y z')(1, 2, 3)
           )

# Generated at 2022-06-11 22:20:50.108146
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the to_namedtuple function."""
    from flutils.typingutils import (
        ListOrderedDict,
        ListOrderedDictMeta,
    )
    from flutils.types import ODEntry
    from flutils import (
        namedtupleutils,
        ordereddictutils,
    )

    od = ListOrderedDict()
    od['a'] = 1
    od['b'] = 2
    od['c'] = 3
    od['d'] = 4

    nt = namedtupleutils.to_namedtuple(od)
    assert hasattr(nt, 'a') and hasattr(nt, 'b') and hasattr(nt, 'c') and \
           hasattr(nt, 'd')

    od = ordereddictutils.convert_to_odentry(od)
   

# Generated at 2022-06-11 22:21:00.232251
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.tests import datadir
    import os
    from pathlib import Path
    from flutils.pathutils import get_path

    _dir = datadir.joinpath('namedtupleutils', '_to_namedtuple')
    _dir = Path(str(_dir))
    for pyfile in _dir.glob('*.py'):
        if pyfile.is_file() and pyfile.name.startswith('test_'):
            modname = os.path.splitext(pyfile.name)[0]
            module = get_path(_dir=_dir, modname=modname)
            module.test()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:21:11.990348
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2), NamedTuple(a=1, b=2)]
    assert to_namedtuple((1, 2, 3, 4)) == (1, 2, 3, 4)
    assert to_namedtuple([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)

# Generated at 2022-06-11 22:21:19.406649
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple

    from typing import cast

    from types import SimpleNamespace

    from flutils.validators import validate_identifier

    assert _to_namedtuple(None) == None
    assert _to_namedtuple(1) == 1
    assert _to_namedtuple(1.1) == 1.1
    assert _to_namedtuple(complex(1.1, 2.2)) == complex(1.1, 2.2)
    assert _to_namedtuple('a') == 'a'

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == cast(NamedTuple, dic)


# Generated at 2022-06-11 22:21:28.210688
# Unit test for function to_namedtuple
def test_to_namedtuple():
    in_dic = {
        'a': 1,
        'b': {
            'c': 3,
            'd': {
                'e': 5,
                'f': 6,
            },
            'g': 7,
        },
        'h': 8,
        '_i': 9,
    }

    exp = namedtuple('NamedTuple', ('a', 'b', 'h'))(
        a=1,
        b=NamedTuple(
            c=3,
            d=NamedTuple(
                e=5,
                f=6,
            ),
            g=7,
        ),
        h=8,
    )

    assert to_namedtuple(in_dic) == exp


# Generated at 2022-06-11 22:22:01.908698
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the function to_namedtuple.

    Checks:
        :class:`flutils.namedtupleutils.to_namedtuple`
            Tests the function.

    Remarks:
        See the :class:`flutils.namedtupleutils.to_namedtuple` docstring for
        more details.
    """
    import typing
    from flutils.namedtupleutils import to_namedtuple
    from collections import (
        OrderedDict,
    )
    from types import SimpleNamespace

    test_obj = OrderedDict({
        'a': 1,
        'b': 2,
        'c': 'testval',
        'd': {
            'e': 'e'
        }
    })

    to_nt = to_namedtuple(test_obj)

# Generated at 2022-06-11 22:22:12.020976
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Generic test for function to_namedtuple
    # Mainly for linting, as function testing is difficult

    import pytest
    # noinspection PyProtectedMember
    dic = {'a': 1, 'b': 2}

    with pytest.raises(TypeError):
        with pytest.warns(None) as warning:
            to_namedtuple(dic)
        assert len(warning) == 3

    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert isinstance(nt, tuple)
    assert isinstance(nt, tuple)
    assert 'NamedTuple' in nt._fields
    assert 'a' in nt._fields
    assert 'b' in nt._fields
    assert len(nt._fields) == 3

# Generated at 2022-06-11 22:22:22.938236
# Unit test for function to_namedtuple
def test_to_namedtuple():
    result = to_namedtuple(
        {
            'a': {
                'b': {
                    'c': [
                        1,
                        2,
                        3,
                    ],
                },
            },
        }
    )
    assert result.a.b.c == (1, 2, 3)

    result = to_namedtuple(
        {
            'a': {
                'b': {
                    'c': {
                        'd': {
                            'e': [
                                1,
                                2,
                                3,
                            ],
                        },
                    },
                },
            },
        }
    )
    assert result.a.b.c.d.e == (1, 2, 3)


# Generated at 2022-06-11 22:22:32.589366
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    # Dict
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    # List
    obj = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    out = to_namedtuple(obj)
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[1].a == 3
    assert out[1].b == 4

    # Nested
    obj = {'a': {'a': 1}, 'b': {'a': 2}}
    out = to_namedtuple(obj)
    assert out.a.a == 1
   

# Generated at 2022-06-11 22:22:42.820150
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    test_dict = {'a': 1, 'b': 2}
    test_namedtuple = namedtuple('NamedTuple', 'a b')
    if test_namedtuple(a=1, b=2) != test_namedtuple(**test_dict):
        raise AssertionError(
            "Test's namedtuple does not properly create a namedtuple (1)"
        )
    test_dict = {'a': 1, 'b': 2, '_c': 3}
    test_namedtuple = namedtuple('NamedTuple', 'a b')

# Generated at 2022-06-11 22:22:53.310133
# Unit test for function to_namedtuple
def test_to_namedtuple():
    modname = globals()['__name__']

# Generated at 2022-06-11 22:23:04.524407
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': {'x': 10, 'y': 20}, 'y': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=NamedTuple(x=10, y=20), y=4)

    od = OrderedDict(a=1, b=2, c={'x': 10, 'y': 20}, y=4)
    assert to_namedtuple(od) == NamedTuple(a=1, b=2, c=NamedTuple(x=10, y=20), y=4)

    # 

# Generated at 2022-06-11 22:23:05.486436
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:23:08.898769
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=True, extraglobs={
        'NamedTuple': namedtuple,
    })

# Generated at 2022-06-11 22:23:17.339018
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _test(obj, out):
        assert to_namedtuple(obj) == out

    dic = {'a': 1, 'b': 2}
    out = namedtuple('NamedTuple', 'a,b')(a=1, b=2)
    _test(dic, out)

    dic = {'a': 1, 'b': 2}
    dic2 = OrderedDict()
    dic2['a'] = 44
    dic2['b'] = 55
    dic2['c'] = 66
    dic.update(dic2)
    out = namedtuple('NamedTuple', 'a,b,c')(a=44, b=55, c=66)
    _test(dic, out)

    dic = OrderedDict()
    d

# Generated at 2022-06-11 22:24:17.921729
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    import flutils.namedtupleutils
    assert flutils.namedtupleutils.to_namedtuple([{'c': 'd'}, {'a': 'b'}]) == [NamedTuple(c='d'), NamedTuple(a='b')]
    assert flutils.namedtupleutils.to_namedtuple({'c': {'e': 'f'}, 'a': 'b'}) == NamedTuple(a='b', c=NamedTuple(e='f'))
    assert flutils.namedtupleutils.to_namedtuple({'a': 'b'}) == NamedTuple(a='b')
    assert flutils.namedtupleutils.to_namedtuple([{'a': 'b'}]) == [NamedTuple(a='b')]

# Generated at 2022-06-11 22:24:29.011624
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test to_namedtuple

    Returns
    -------
    None
    """

    from collections import OrderedDict
    from types import SimpleNamespace

    from flutils.namedtupleutils import to_namedtuple

    namedtuple_ = namedtuple('namedtuple', 'a b')
    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    dic['c'] = 3
    dic['d'] = 4
    list_ = ['a', 'b', 'c', 'd']
    namespace = SimpleNamespace()
    namespace.a = 1
    namespace.b = 2
    namespace.c = 3
    namespace.d = 4
    tup = ('a', 'b', 'c', 'd')


# Generated at 2022-06-11 22:24:37.468963
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import unittest

    class ToNamedTupleTest(unittest.TestCase):
        def test_to_namedtuple_dict(self):
            dic = {'a': 1, 'b': 2}
            tup = to_namedtuple(dic)
            self.assertEqual(tup, namedtuple('NamedTuple', 'a b')(a=1, b=2))
            self.assertEqual(tup.a, 1)
            self.assertEqual(tup.b, 2)

        def test_to_namedtuple_dict_short_keys(self):
            dic = {'a': 1, 'b': 2, '_c': 3, '_d': 4}
            tup = to_namedtuple(dic)

# Generated at 2022-06-11 22:24:47.848199
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # These three will raise a TypeError
    # dic = {'a': 1, 'b': 2}
    # assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    # lst = [1, 2]
    # assert to_namedtuple(lst) == [1, 2]
    # assert to_namedtuple(tup) == (1, 2)
    nt = NamedTuple('ABC', 1, 2, 3)
    assert to_namedtuple(nt) == NamedTuple(ABC=NamedTuple(a=1, b=2, c=3))
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(lst) == [1, 2]

# Generated at 2022-06-11 22:24:57.342908
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = SimpleNamespace(**dic)
    assert to_namedtuple(dic) == to_namedtuple(obj)


if __name__ == '__main__':
    lst = [1, 2, 3]
    dic = {'a': 1, 'b': 2}
    obj = SimpleNamespace(**dic)
    d1 = OrderedDict()
    d1['a'] = 1
    d1['b'] = 2
    tup1 = (1, 2, 3)
    tup2 = ('a', 'b', 'c')
    tup3 = ('a', 'b', 'c', {'a': 1, 'b': 2})
    dic1 = {'a': 1, 'b': 2}

# Generated at 2022-06-11 22:25:05.954056
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    from flutils.namedtupleutils import to_namedtuple
