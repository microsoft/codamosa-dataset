

# Generated at 2022-06-11 22:15:14.046887
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Tests to_namedtuple
    """
    # pylint: disable=syntax-error,singleton-comparison,unsubscriptable-object,
    # pylint: disable=no-self-use,protected-access,anomalous-backslash-in-string
    from collections import OrderedDict
    from functools import reduce
    from operator import mul
    from types import SimpleNamespace
    from typing import Tuple

    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    im_a_list = [1, 2, 3, 4]
    im_a_tuple = (1, 2, 3, 4)

# Generated at 2022-06-11 22:15:22.609384
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple, OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.tests.pytest_helpers import (
        cwd_to_tmp,
        dict_like,
        is_equal,
        obj_like,
    )

    # test Mapping to NamedTuple

# Generated at 2022-06-11 22:15:33.300803
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    assert isinstance(to_namedtuple(['a', 'b']), tuple)

    assert to_namedtuple(OrderedDict({'a': 1, 'b': 2})) == \
        namedtuple('NamedTuple', 'a b')(a=1, b=2)

    assert to_namedtuple({'a': 1, 'b': 2}) == \
        namedtuple('NamedTuple', 'a b')(a=1, b=2)


# Generated at 2022-06-11 22:15:45.001512
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    import flutils.namedtupleutils
    assert flutils.namedtupleutils.to_namedtuple.__doc__ is not None
    dic = {'a': 1, 'b': 2}
    assert flutils.namedtupleutils.to_namedtuple(dic) == \
           flutils.namedtupleutils.NamedTuple(a=1, b=2)
    assert flutils.namedtupleutils.to_namedtuple(dic) == \
           flutils.namedtupleutils.NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': 3}
    expected = flutils.namedtupleutils.NamedTuple(a=1, b=2, c=3)
    actual = flutils

# Generated at 2022-06-11 22:15:56.747446
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    output = to_namedtuple(dic)
    assert output.a == 1
    assert output.b == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    output = to_namedtuple(dic)
    assert hasattr(output, 'a')
    assert hasattr(output, 'b')
    assert not hasattr(output, 'c')
    assert not hasattr(output, '_c')

    dic = {'a': 1, 'b': 2, 'c': 3}
    output = to_namedtuple(dic)
    assert hasattr(output, 'a')
    assert hasattr(output, 'b')
    assert hasattr(output, 'c')


# Generated at 2022-06-11 22:16:08.616774
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']

    assert to_namedtuple(['a', 'b', 'c', '1', '2']) == ['a', 'b', 'c', '1', '2']

    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')

    assert to_namedtuple(('a', 'b', 'c', '1', '2')) == ('a', 'b', 'c', '1', '2')


# Generated at 2022-06-11 22:16:11.088377
# Unit test for function to_namedtuple
def test_to_namedtuple():
    namedtuple_ = to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(namedtuple_, NamedTuple)
    assert namedtuple_.a == 1
    assert namedtuple_.b == 2


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:16:22.930884
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test for single item in list
    arr = [1, 2]
    assert to_namedtuple(arr) == [1, 2]

    # Test for multiple items in list
    arr = ['a', 'b', 1, 2]
    assert to_namedtuple(arr) == ['a', 'b', 1, 2]

    # Test for single item in tuple
    arr = (1, 2)
    assert to_namedtuple(arr) == (1, 2)

    # Test for multiple items in tuple
    arr = (1, 2, 'a', 'b')
    assert to_namedtuple(arr) == (1, 2, 'a', 'b')

    # Test for dict
    arr = {'a': 1, 'b': 2}

# Generated at 2022-06-11 22:16:31.425091
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': {'c': 1}, 'x': None}) == \
        namedtuple('NamedTuple', ('a', 'b', 'x'))(1, namedtuple('NamedTuple', ('c',))(1), None)
    assert to_namedtuple([1, 'a', {'x': 10}]) == \
        [1, 'a', namedtuple('NamedTuple', ('x',))(10)]
    assert to_namedtuple((1, 'a', {'x': 10})) == \
        (1, 'a', namedtuple('NamedTuple', ('x',))(10))

# Generated at 2022-06-11 22:16:40.470914
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': {'d': {'e': 5, 'f': 6}}}
    out = to_namedtuple(dic)
    assert out == NamedTuple(a=1, b=2, c=NamedTuple(d=NamedTuple(e=5, f=6)))

    dic = {'a': 1, 'b': 2, 'c': {'d': {'e': 5, 'f': 6, 'g': 8}}}

# Generated at 2022-06-11 22:16:57.094549
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Exceptions
    # noinspection PyTypeChecker
    exc = TypeError(
        "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
        "got: (str) foo"
    )
    assert exc == raises(exc, to_namedtuple, 'foo')

    # Successes
    # noinspection Mypy
    nt = to_namedtuple({'a': 1, 'b': 2})  # type: ignore[arg-type]
    assert nt._fields == ('a', 'b')
    assert nt == (1, 2)

    # noinspection Mypy
    nt = to_namedtuple({'_a': 1, 'b': 2})  # type: ignore[arg-type]
    assert nt._fields == ('b',)

# Generated at 2022-06-11 22:17:09.012785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lst = [
        {'list': [
            {'a': 1, 'b': 2},
            {'a': 2, 'b': 3},
        ]},
        {'list': [
            {'a': 3, 'b': 4},
            {'a': 4, 'b': 5},
        ]},
        {'list': [
            {'a': 5, 'b': 6},
            {'a': 6, 'b': 7},
        ]},
    ]
    dic = {
        'string': 'This is a string',
        'int': 1,
        'float': 1.0,
        'list': lst,
    }

    nt_list = to_namedtuple(lst)
    # print(nt_list)
    # assert False
    nt_d

# Generated at 2022-06-11 22:17:12.865857
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert str(to_namedtuple(dic)) == "NamedTuple(a=1, b=2)"



# Generated at 2022-06-11 22:17:23.525880
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, '__c': 3}) == NamedTuple(a=1, b=2)

    # noinspection PyTypeChecker
    dic = dict(a=1, b=2, __c=3)
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    for key in dic.keys():
        assert hasattr(dic, key)

    # noinspection PyTypeChecker
    dic = OrderedD

# Generated at 2022-06-11 22:17:31.449212
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple([dic]) == [namedtuple('NamedTuple', 'a b')(a=1, b=2)]
    assert to_namedtuple((dic,)) == (namedtuple('NamedTuple', 'a b')(a=1, b=2),)
    ntup = namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)
    # noinspection PyTypeChecker

# Generated at 2022-06-11 22:17:42.295064
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from textwrap import dedent
    from flutils.namedtupleutils import to_namedtuple
    from flutils.basicutils.typetools import is_namedtuple
    from flutils.validators import is_proper_identifier

    ret = to_namedtuple({})
    assert ret == namedtuple('', '')()
    ret = to_namedtuple([])
    assert ret == []
    ret = to_namedtuple(tuple())
    assert ret == ()
    ret = to_namedtuple({'a': 1, 'b': 2})
    assert ret == namedtuple('', 'a b')(1, 2)
    ret = to_namedtuple({'b': 2, 'a': 1})

# Generated at 2022-06-11 22:17:47.179169
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Dict
    from collections import namedtuple

    dic: Dict[str, Any] = {
        'a': 1,
        'b': 2
    }
    expected = \
        namedtuple('NamedTuple', ['a', 'b'])(
            a=1,
            b=2
        )
    assert to_namedtuple(dic) == expected

# Generated at 2022-06-11 22:17:59.175146
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple  # noqa: E402
    from copy import deepcopy  # noqa: E402

    tup1 = {'a': 1}
    tup2 = to_namedtuple(tup1)
    assert isinstance(tup2, NamedTuple)
    assert tup2.a == 1
    assert tup2.__class__.__name__ == 'NamedTuple'
    assert tup2.__doc__ is None
    # assert issubclass(tup2.__class__, NamedTuple)

    tup1 = {'a': 1, 'b': 2}
    tup2 = to_namedtuple(tup1)
    assert isinstance(tup2, NamedTuple)
    assert tup2.a == 1


# Generated at 2022-06-11 22:18:08.170461
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == OrderedDict([('a', 1), ('b', 2)])

    dic = {'a': 'a', 'b': 2}
    assert to_namedtuple(dic) == OrderedDict([('a', 'a'), ('b', 2)])

    dic = {'a': [1, 2, 3], 'b': 2}
    assert to_namedtuple(dic) == OrderedDict([('a', [1, 2, 3]), ('b', 2)])

    dic = {'a': {'b': 11, 'c': 12}, 'b': 2}

# Generated at 2022-06-11 22:18:18.063406
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    t = to_namedtuple(dic)
    assert t.a == 1
    assert t.b == 2
    assert t == (1, 2)
    ol = to_namedtuple([1, 3, 4])
    assert ol == [1, 3, 4]
    ol = to_namedtuple((1, 3, 4))
    assert ol == (1, 3, 4)
    ol = to_namedtuple({'a': 1, 'b': 3})
    assert ol == (1, 3)
    ol = to_namedtuple(OrderedDict(a=1, b=3))
    assert ol == (1, 3)
    ol = to_namedtuple(SimpleNamespace(a=1, b=3))
    assert ol

# Generated at 2022-06-11 22:18:26.538061
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)



# Generated at 2022-06-11 22:18:36.000924
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import os
    import sys
    sys.path.append(os.path.join(os.getcwd(),os.path.pardir))
    from flutils.test.test_namedtupleutils import TestBase
    import unittest
    class Tests(TestBase):
        def test_to_namedtuple(self):
            self.assertNotEqual(
                self.a,
                to_namedtuple(self.a),
                "NamedTuple was not converted to NamedTuple"
            )
            self.assertEqual(
                self.b,
                to_namedtuple(self.b),
                "Tuple was converted to different Tuple"
            )

# Generated at 2022-06-11 22:18:45.775315
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:18:50.412405
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from types import SimpleNamespace

    # testing for list

# Generated at 2022-06-11 22:19:02.856756
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #   1
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    dic: dict = {'a': 1, 'b': 2}
    named = to_namedtuple(dic)
    assert named.a == 1
    assert named.b == 2
    assert str(named) == "NamedTuple(a=1, b=2)"
    assert repr(named) == "NamedTuple(a=1, b=2)"

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    #   2
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    dic: dict = {'a': 1, 'bad': 2}
    named = to_namedtuple(dic)
    assert named.a == 1

# Generated at 2022-06-11 22:19:09.790533
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict

    def check_tuple(
            obj: Union[Tuple, NamedTuple, List],
            expected: Union[Tuple, List[Tuple[int, str]]],
            obj_name: str = ''
    ):
        if not isinstance(obj, (Tuple, List)):
            assert obj_name, 'No obj_name given for this obj: %s' % obj
            expected_name = expected.__class__.__name__
            obj_name = obj.__class__.__name__
            assert obj_name == expected_name, (
                '%r != %r, %r != %r' % (obj_name, expected_name, obj, expected)
            )

# Generated at 2022-06-11 22:19:15.633005
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple()."""

    from flutils.namedtupleutils import to_namedtuple
    from collections import (
        OrderedDict,
    )
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == OrderedDict(
        [('a', 1), ('b', 2), ('c', 3)]
    )

    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == OrderedDict(
        [('a', 1), ('b', 2), ('c', 3)]
    )

    obj = SimpleNamespace(a=1)
    assert to_namedtuple(obj) == to_namedt

# Generated at 2022-06-11 22:19:27.365724
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils._namedtupleutils import _to_namedtuple
    dic = {
        'a': 1,
        'b': 2,
        '_c': 3,
        'c': 4,
        'd': 5,
    }
    nt = _to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 4
    assert nt.d == 5
    assert not hasattr(nt, '_c')
    assert hasattr(nt, '_c') is False

    d = OrderedDict(
        [
            ('a', 1),
            ('b', 2),
            ('c', 3),
            ('d', 4),
        ]
    )
    nt = _to_namedtuple(d)

# Generated at 2022-06-11 22:19:36.866538
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Can convert only 'list', 'tuple', 'dict' to a NamedTuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # * list *
    assert to_namedtuple([{'a': 1, 'b': 2}, 3, {'d': 4, 'e': 5}]) == \
        [NamedTuple(a=1, b=2), 3, NamedTuple(d=4, e=5)]
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple([{'a': 1, 'b': 2}, 3, {'d': 4, 'e': 5}])[0].a == 1

# Generated at 2022-06-11 22:19:44.679844
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a,b')(1, 2)
    assert to_namedtuple({'a': 1, 2: 'b'}) == namedtuple('NamedTuple', 'a,b')(1, 'b')
    assert to_namedtuple({'a': 1, '': ''}) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple({'a': 1, '1x': 1}) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a,b')(1, 2)

# Generated at 2022-06-11 22:19:55.874898
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('foo')

# Generated at 2022-06-11 22:20:03.927203
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class Class:
        a: int = 1
        b: int = 2
        c: int = 3

    dic = {'a': 1, 'b': 2, 'c': 3}
    lst = ['a', 'b', 'c']
    tuple_a = ('a', 'b', 'c')
    tuple_b = (1, 2, 3)
    tup_dict = ({'a': 1, 'b': 2}, {'c': 3, 'd': 4})
    tup_list = ([1, 2, 3], [4, 5, 6])
    tup_tuple = (('a', 1), ('b', 2), ('c', 3))
    tuple_c = (1, {'a': 1, 'b': 2}, [1, 2, 3])

# Generated at 2022-06-11 22:20:16.213484
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace

    _nt1 = namedtuple('_nt1', 'a,b')
    _nt2 = namedtuple('_nt2', 'c,d')
    _nt3 = namedtuple('_nt3', 'e,f')
    _nt4 = namedtuple('_nt4', 'g')
    _nt5 = namedtuple('_nt5', 'a,b')

    inp1 = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}, {'e': 5, 'f': 6}]

# Generated at 2022-06-11 22:20:28.126233
# Unit test for function to_namedtuple
def test_to_namedtuple():

    obj = {'a': 1, 'b': 2}
    result = to_namedtuple(obj)
    assert isinstance(result, NamedTuple)
    assert result.a == 1
    assert result.b == 2

    obj = {'a': 1, 'b': {'c': 2}}
    result = to_namedtuple(obj)
    assert isinstance(result, NamedTuple)
    assert result.a == 1
    assert isinstance(result.b, NamedTuple)
    assert result.b.c == 2

    obj = {'a': 1, '_b': {'c': 2}}
    result = to_namedtuple(obj)
    assert isinstance(result, NamedTuple)
    assert result.a == 1
    assert not hasattr(result, '_b')
    assert not has

# Generated at 2022-06-11 22:20:38.787963
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple

# Generated at 2022-06-11 22:20:49.127132
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert eval(str(to_namedtuple({"a": 1, "b": 2}))) == (1, 2)
    assert eval(str(to_namedtuple({"a": 1, "b": 2, "c": {"d": 3}}))) == (1, 2, (3,))
    assert eval(str(to_namedtuple({"a": 1, "b": 2, "c": {"d": 3, "e": 4}}))) == (1, 2, (3, 4))

# Generated at 2022-06-11 22:21:00.165381
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    d = {
        'a': 1,
        'b': 2,
    }
    assert to_namedtuple(d) == namedtuple('NamedTuple', ['a', 'b'])(
        a=1,
        b=2,
    )
    d1 = {
        'd': {
            'a': 1,
            'b': 2,
        },
    }
    assert to_namedtuple(d1) == namedtuple('NamedTuple', ['d'])(
        d=namedtuple('NamedTuple', ['a', 'b'])(
            a=1,
            b=2,
        ),
    )

# Generated at 2022-06-11 22:21:11.896106
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    import datetime
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'b': 2, 'a': 1}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'b': 2, 'a': 1, 'c': 'abc'}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c='abc')

# Generated at 2022-06-11 22:21:19.810496
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from types import (
        SimpleNamespace,
    )

    from flutils.namedtupleutils import (
        to_namedtuple,
    )

    # Empty dict should return an empty NamedTuple
    assert to_namedtuple({}) == to_namedtuple(OrderedDict()) == to_namedtuple(
        SimpleNamespace()
    ) == to_namedtuple([]) == to_namedtuple(())

    # Test non-identifier keys
    obj_dic_no_ide = OrderedDict()
    obj_dic_no_ide['a1'] = 'a1'
    obj_dic_no_ide['a.b'] = 'a.b'

# Generated at 2022-06-11 22:21:25.114436
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = to_namedtuple([
        [
            {'a': 0},
            {'b': 1}
        ],
        [
            {'c': 3, '_d': 4},
            {'e': 5, 'f': 6}
        ]
    ])
    print(a)

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:21:53.201211
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.stringutils import to_camel_case
    dic = {'a': 1, 'b': 2, '_c': 3}
    namedtuple_obj = to_namedtuple(dic)
    assert namedtuple_obj.a == 1
    assert namedtuple_obj.b == 2
    assert not hasattr(namedtuple_obj, '_c')
    dic = {to_camel_case('a'): 1, to_camel_case('b'): 2}
    namedtuple_obj = to_namedtuple(dic)
    assert namedtuple_obj.a == 1
    assert namedtuple_obj.b == 2
    from collections import OrderedDict
    dic = OrderedDict

# Generated at 2022-06-11 22:21:58.207791
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert isinstance(result, namedtuple)
    return


if __name__ == '__main__':
    # Unit test for function to_namedtuple
    test_to_namedtuple()

# Generated at 2022-06-11 22:22:05.070573
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert isinstance(nt.a, int)
    assert isinstance(nt.b, int)
    assert nt.a == 1
    assert nt.b == 2
    dic = {'a': 1, 'b': [2, 3]}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert isinstance(nt.a, int)
    assert isinstance(nt.b, list)
    assert nt.a == 1
    assert nt.b == [2, 3]

# Generated at 2022-06-11 22:22:13.620129
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    class TestToNamedTuple(unittest.TestCase):
        def test_to_namedtuple_dict(self):
            dic = {'a': 1, 'b': 2}
            nt: namedtuple = to_namedtuple(dic)
            self.assertEqual(dic['a'], nt.a)
            self.assertEqual(dic['b'], nt.b)
            self.assertEqual(namedtuple, type(nt))

            dic = {'a': 1, 'b': 2, 'B': 3}
            nt: namedtuple = to_namedtuple(dic)
            self.assertEqual(dic['a'], nt.a)

# Generated at 2022-06-11 22:22:24.051294
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from .testdata import TESTDATA
    from flutils.namedtupleutils import JsonNamedTupleDecoder
    import json

    data = to_namedtuple(TESTDATA)
    assert isinstance(data, tuple), f'type: {type(data)}'
    assert data.first == 1, f'value: {data.first}'
    assert data.second == 2, f'value: {data.second}'
    assert data.third.first == 1, f'value: {data.third.first}'
    assert data.third.second == 2, f'value: {data.third.second}'
    assert data.fourth.first.first == 1, f'value: {data.fourth.first.first}'

# Generated at 2022-06-11 22:22:33.039000
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""

    from collections import OrderedDict
    from datetime import date
    from decimal import Decimal
    from typing import List, Mapping, NamedTuple, Optional
    from unittest import TestCase

    from flutils.namedtupleutils import to_namedtuple

    from tests._typingutils import (
        JsonType,
        NT1,
    )

    # noinspection SpellCheckingInspection,PyUnresolvedReferences
    class NT(NamedTuple):
        """NamedTuple for testing."""

        a: int
        b: int
        str1: Optional[str]

    # noinspection SpellCheckingInspection,PyUnresolvedReferences
    class NT2(NamedTuple):
        """NamedTuple for testing."""

        a

# Generated at 2022-06-11 22:22:43.591114
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'd': {'a': 1}, 'c': 'text', 'b': 2}
    out = to_namedtuple(dic)
    assert out == namedtuple('NamedTuple', 'a c b d')(1, 'text', 2, namedtuple('NamedTuple', 'a')(1))
    dic = {'a': 1, 'c': 'text', 'b': 2}
    out = to_namedtuple(dic)
    assert out == namedtuple('NamedTuple', 'a b c')(1, 2, 'text')
    dic = {'a': 1, 'd': {'a': 1}, 'g': ['text', 'text'], 'b': 2}
    out = to_namedtuple(dic)

# Generated at 2022-06-11 22:22:53.807006
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    assert to_namedtuple('abc') == 'abc'
    assert to_namedtuple(True) is True
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    assert to_namedtuple([]) == []
    assert to_namedtuple([{}, 'abc']) == [namedtuple('NamedTuple', ''), 'abc']
    assert to_namedtuple([[], 'abc']) == ([], 'abc')
    assert to_namedtuple(([], 'abc')) == ([], 'abc')
    assert to_named

# Generated at 2022-06-11 22:23:04.626023
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    dic = {'a': {'b': 2, 'c': 3}, 'd': 4}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a d')(
        namedtuple('NamedTuple', 'b c')(2, 3), 4)
    dic2 = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic2) == namedtuple('NamedTuple', 'a b')(1, 2)
    odic = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    assert to_namedt

# Generated at 2022-06-11 22:23:15.296478
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyPep8Naming
    class test_object(object):
        a = 1
        b = 2

    assert to_namedtuple([]) == ()
    assert to_namedtuple([1, 2]) == (1, 2)
    assert to_namedtuple([1, 2, [3, 4]]) == (1, 2, (3, 4))
    assert to_namedtuple({}) == ()
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple((1, 2, (3, 4))) == (1, 2, (3, 4))
    assert to_namedtuple({'a': 1, 'b': 2}) == (1, 2)

# Generated at 2022-06-11 22:24:08.125583
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:24:13.395040
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2,
    }
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:24:22.250717
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import Dict, NamedTuple


# Generated at 2022-06-11 22:24:33.014238
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint as pp
    dic = dict(
        list1=[dict(a=1, b=2), dict(a=3, b=4)],
        tup1=(dict(a=1, b=2), dict(a=3, b=4)),
        dic1=dict(a=1, b=2),
        dic2=dict(a=1, b=2, c=dict(a=1, b=2)),
        dic3=dict(a=1, c=dict(a=1, b=2))
    )
    pp(dic)
    print()
    data = to_namedtuple(dic)
    print(data)
    assert isinstance(data, dict)
    print(data.list1[0])

# Generated at 2022-06-11 22:24:36.358003
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_dict = {"key1":"value1", "key2":"value2"}
    test_out = to_namedtuple(test_dict)
    assert(test_out.key1 == "value1")
    assert(test_out.key2 == "value2")

# Generated at 2022-06-11 22:24:47.094503
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'A': 1, 'b': 2}) == namedtuple('NamedTuple', 'b')(b=2)
    assert to_namedtuple({'_': 1, 'b': 2}) == namedtuple('NamedTuple', 'b')(b=2)

    # OrderedDict

# Generated at 2022-06-11 22:24:57.076801
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    __tracebackhide__ = True
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    lis = [1, 2, 3]
    assert to_namedtuple(lis) == [1, 2, 3]

    dic = {'a': 1, 'b': 2}
    nt1 = NamedTuple(a=1, b=2)
    nt2 = to_namedtuple(dic)
    assert nt1 == nt2

    lis = [1, 2, 3]
    assert to_namedtuple(lis) == lis
