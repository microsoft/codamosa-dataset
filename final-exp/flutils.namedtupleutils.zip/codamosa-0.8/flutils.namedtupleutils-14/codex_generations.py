

# Generated at 2022-06-11 22:15:12.446726
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import MagicMock, patch
    from collections import OrderedDict
    import types

    # Patch the validator to always return True
    with patch('flutils.validators.validate_identifier') as mocked_validator:
        mocked_validator.side_effect = lambda x, y=None, z=None: True

        # dict to dict
        rv = to_namedtuple({'a': 1, 'b': 2})
        assert rv == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)

        # list to list
        rv = to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}])

# Generated at 2022-06-11 22:15:21.677073
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.typingutils import assert_is_instance
    from types import SimpleNamespace
    from typing import (
        Dict,
        List,
        NamedTuple,
        Set,
        Tuple,
        Type,
        Union,
    )

    # noinspection PyClassHasNoInit,PyPep8
    class Case(NamedTuple):
        testtype: str
        arg: Any
        result: Any

    # noinspection Mypy,PyPep8

# Generated at 2022-06-11 22:15:32.611725
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'b': (2, ),
        'c': {'d': 4},
        'a': 1,
    }
    out = to_namedtuple(dic)
    assert isinstance(out, namedtuple)
    assert out.a == 1
    assert isinstance(out.b, tuple)
    assert out.b[0] == 2
    assert isinstance(out.c, namedtuple)
    assert out.c.d == 4

    lis = [1, (2, 3,), {'d': 4}, SimpleNamespace(e=5)]
    out = to_namedtuple(lis)
    assert isinstance(out, list)
    assert out[0] == 1
    assert isinstance(out[1], tuple)
    assert out[1] == (2, 3)

# Generated at 2022-06-11 22:15:44.420677
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Unit tests for function :meth:`flutils.namedtupleutils.to_namedtuple`'''
    from pprint import pformat
    from io import StringIO

    def get_test_obj():
        '''Return a namedtuple with the same types as in csv_test_obj'''
        NamedTuple = namedtuple('NamedTuple', ['a', 'b', 'c'])
        Tuple = namedtuple('Tuple', ['a', 'b', 'c'])
        NamedX = namedtuple('NamedX', ['a', 'b', 'c', 'd'])
        return NamedTuple(a=True, b=NamedX(1, 2, 3, [4, 5, 6]), c=Tuple(1, 2, 3))


# Generated at 2022-06-11 22:15:55.992583
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:16:07.029697
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple as NT

    NTD = NT('sample_ntd', 'a b c d')
    NTE = NT('sample_nte', 'a b c d')
    NTF = NT('sample_ntf', '')
    NTG = NT('sample_ntg', 'a b c d')

    good_input = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
    }
    bad_input = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': (4, 5, 6),
    }
    assert NTD(1, 2, 3, 4) == to_namedtuple

# Generated at 2022-06-11 22:16:11.978917
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class TestClass(NamedTuple):
        name: str = 'flutils'
        version: Tuple[int, ...] = (3, 2, 1)

    dic = dict(abc=1, defg=2, hijklm=TestClass())
    ntup = to_namedtuple(dic)

    assert ntup.abc == 1
    assert ntup.defg == 2
    assert ntup.hijklm.name == 'flutils'
    assert ntup.hijklm.version == (3, 2, 1)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:16:23.369794
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from typing import NamedTuple
    from flutils.namedtupleutils import to_namedtuple

    class _TestClass(NamedTuple):
        a: int
        b: str
    test_list: list = [
        {'a': 1, 'b': 2},
        3,
        4,
        SimpleNamespace(a=5, b=6)
    ]
    test_tuple: tuple = (
        {'a': 1, 'b': 2},
        3,
        4,
        SimpleNamespace(a=5, b=6)
    )


# Generated at 2022-06-11 22:16:31.721044
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    def _test(
            dic: Mapping,
            exp: Tuple[NamedTuple, List[Any], Tuple[Any, ...], NamedTuple, str]
    ) -> None:
        act = to_namedtuple(dic)
        if isinstance(dic, OrderedDict):
            exp = OrderedDict(exp)
            assert isinstance(act, OrderedDict)
            assert act == exp
        else:
            assert act == exp

    # Basic test
    test_data = ({'a': 1, 'b': 2}, (NamedTuple(a=1, b=2), [], (), {}, ''))
    _test(test_data[0], test_data[1])

    # Iterable test

# Generated at 2022-06-11 22:16:40.623890
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:16:55.541536
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    d = {'b': 2, 'a': 1}
    out = to_namedtuple(d)
    assert out.a == 1
    assert out.b == 2
    d = {'_b': 2, 'a': 1}
    out = to_namedtuple(d)
    assert out._fields == ('a',)
    assert out.a == 1
    d = {'b': 2, 'a': 1, 'c': 3}
    out = to_namedtuple(d)
    assert out._fields == ('a', 'b', 'c')
    assert out.a == 1
    assert out.b == 2
    assert out

# Generated at 2022-06-11 22:16:56.545012
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:17:03.970069
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple,
    )

    assert to_namedtuple(1) == 1
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple('a0') == 'a0'
    assert to_namedtuple('_a') == '_a'

    obj = {'a': 1, 'b': 2, }
    assert to_namedtuple(obj) == obj
    assert to_namedtuple(obj) == to_namedtuple(obj)

    from collections import OrderedDict


# Generated at 2022-06-11 22:17:11.164744
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # import nose
    # nose.tools.set_trace()
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic).a == 1
    assert to_namedtuple(dic).b == 2
    dic = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4, 'f': 5}
    assert to_namedtuple(dic).a == 1
    assert to_namedtuple(dic).b.c == 2
    assert to_namedtuple(dic).b.d == 3
    assert to_namedtuple(dic).e == 4
    assert to_namedtuple(dic).f == 5

# Generated at 2022-06-11 22:17:20.350793
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    rv = to_namedtuple(dic)
    assert isinstance(rv, NamedTuple)
    assert rv.a == 1
    assert rv.b == 2
    dic = {'_a': 1, 'b': 2}
    rv = to_namedtuple(dic)
    assert isinstance(rv, NamedTuple)
    assert hasattr(rv, 'b')
    assert not hasattr(rv, '_a')
    assert rv.b == 2
    dic = {'a': 1, '_b': 2}
    rv = to_namedtuple(dic)
    assert isinstance(rv, NamedTuple)
    assert hasattr(rv, 'a')

# Generated at 2022-06-11 22:17:28.195183
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import logging

    log = logging.getLogger('test_to_namedtuple')

    def check(val: Any, name: str) -> None:
        log.debug('check(%r, %r)', val, name)

        if isinstance(val, list):
            for i in range(len(val)):
                check(val[i], name + '[%d]' % i)
            return

        if not hasattr(val, '_fields'):
            return

        for key in val._fields:
            try:
                check(getattr(val, key), '%s.%s' % (name, key))
            except AttributeError:
                raise AssertionError(
                    '%s.%s does not have attribute %s.' % (name, key, key)
                )


# Generated at 2022-06-11 22:17:37.557271
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import Dict, Tuple
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import to_namedtuple
    from tests.test_base import TestBase

    def verify_attrs(
            obj: Union[Tuple, NamedTuple],
            expected_attrs: Union[Tuple[str, ...], List[str]]
    ) -> None:
        attrs = []
        for key in expected_attrs:
            key_exists = hasattr(obj, key)
            try:
                validate_identifier(key)
                attrs.append(key_exists)
            except SyntaxError:
                attrs.append(not key_exists)
        assert all(attrs)


# Generated at 2022-06-11 22:17:48.102768
# Unit test for function to_namedtuple
def test_to_namedtuple():

    lis = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    assert to_namedtuple(lis) == lis
    assert to_namedtuple(('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z')) == ('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z')

# Generated at 2022-06-11 22:17:49.398504
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:17:55.884768
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    dic = {'a': 1, 'b': 2}
    dic = to_namedtuple(dic)
    assert dic.a == 1
    assert dic.b == 2
    assert dic._asdict() == {'a': 1, 'b': 2}


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:18:07.925092
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import io
    import sys
    import tempfile
    import unittest

    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import __version__

    try:
        from flutils.packutils.setup import __version__ as version
    except ImportError:
        version = 'unknown'
    try:
        from flutils.packutils.setup import __author__ as author
    except ImportError:
        author = 'unknown'
    try:
        from flutils.packutils.setup import __email__ as email
    except ImportError:
        email = 'unknown'

    class ToNamedTupleTests(unittest.TestCase):
        """Unit tests for namedtupleutils.to_namedtuple()."""

        maxDiff = None


# Generated at 2022-06-11 22:18:17.970837
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import ChainMap
    from collections import defaultdict

    import pytest

    namedtuples = {
        'NamedTuple': namedtuple('NamedTuple', 'a b c'),
        'NamedTuple2': namedtuple('NamedTuple2', 'a b c'),
        'NamedTuple3': namedtuple('NamedTuple3', 'a b c'),
    }

    assert to_namedtuple(namedtuples['NamedTuple']) == namedtuples['NamedTuple']

    assert to_namedtuple([
        namedtuples['NamedTuple'],
        namedtuples['NamedTuple2'],
    ]) == [
        namedtuples['NamedTuple'],
        namedtuples['NamedTuple2'],
    ]

    assert to_

# Generated at 2022-06-11 22:18:26.499844
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators.types import validate_identifier
    from flutils.validators.exceptions import ValidateTypeError, \
        ValidateIdentifierError

    # Invalid type

    # noinspection PyTypeChecker
    def _check_obj_type_error(obj: Any) -> None:
        try:
            to_namedtuple(obj)
        except (SyntaxError, TypeError) as to_namedtuple_err:
            with suppress(ValidateTypeError):
                raise ValidateTypeError(
                    'Invalid type encountered',
                    err=to_namedtuple_err,
                    obj=obj,
                    types=Mapping,
                ) from to_namedtuple_err
            raise
        except Exception as err:
            raise Runtime

# Generated at 2022-06-11 22:18:35.948390
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'1abc': 1, 'abc!': 2}
    assert to_namedtuple(dic) == NamedTuple(abc=2, a=1)

    dic = OrderedDict()
    dic['b'] = 2
    dic['a'] = 1
    assert to_namedtuple(dic) == NamedTuple(b=2, a=1)

    dic = {'one': 1, 'two': 2}
    dic = [dic, dic]
    out = to_namedtuple(dic)
    assert out[0] == out[1]
    assert out[0] == NamedT

# Generated at 2022-06-11 22:18:41.342571
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_obj = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    expected = NamedTuple(a=1, b=2, c=NamedTuple(d=3, e=4))
    assert to_namedtuple(test_obj) == expected

# Generated at 2022-06-11 22:18:52.464529
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from operator import attrgetter
    from types import SimpleNamespace

    dic = dict(a=1, b=2)
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = dict(a=1, b=2, _c=3)
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    with pytest.raises(AttributeError):
        _ = nt._c

    dic = dict(b=2, a=1)
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    dic = OrderedD

# Generated at 2022-06-11 22:19:04.008925
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    """Unit test for function :func:`flutils.namedtupleutils.to_namedtuple`"""
    from typing import List, Optional

    if __name__ == '__main__':
        from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace
    from typing import NamedTuple, Tuple, Type, Union

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    print(type(out), ':', out)
    assert isinstance(out, NamedTuple)
    assert len(out) == 2
    assert isinstance(out.a, int)

# Generated at 2022-06-11 22:19:15.141566
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    # ==================
    # Simple cases
    # ==================
    # Default case
    # noinspection PyTypeChecker
    tup = (1, 2, 3)
    res = to_namedtuple(tup)
    assert res == tup

    # Simple list case
    lst = [1, 2, 3]
    res = to_namedtuple(lst)
    assert res == lst

    # Simple dictionary case
    dic = {'a': 1, 'b': 2}
    res = to_namedtuple(dic)
    assert res.a == 1
    assert res.b == 2

    # ==================
    # Complex Cases
    # ==================
    # Nested Lists
    l

# Generated at 2022-06-11 22:19:26.961791
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # pylint: disable=missing-function-docstring,redefined-outer-name
    import pytest
    # pylint: disable=line-too-long
    my_list = to_namedtuple(['a'])
    my_tuple = to_namedtuple(('a',))
    my_dict = to_namedtuple({'a': 1})
    my_ordered_dict = to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))

# Generated at 2022-06-11 22:19:36.576067
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == NamedTuple()
    assert to_namedtuple([1, 2]) == [1, 2]

# Generated at 2022-06-11 22:19:52.342020
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import sys
    import inspect

    import flutils.namedtupleutils as ntu

    class ToNamedtupleTests(unittest.TestCase):

        # noinspection PyPep8Naming,PyShadowingNames
        def setUp(self):
            self.longMessage = True
            self.maxDiff = None

            # noinspection PyAttributeOutsideInit

# Generated at 2022-06-11 22:19:58.520649
# Unit test for function to_namedtuple
def test_to_namedtuple():
    source = {
        'a': 1,
        'b': {
            'c': 2,
            'd': {
                'e': 3
            }
        }
    }
    expected = {
        'a': 1,
        'b': {
            'c': 2,
            'd': {
                'e': 3
            }
        }
    }
    result = to_namedtuple(source)
    assert result == expected

# Generated at 2022-06-11 22:20:08.938046
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Optional
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple

    TestNamedTuple = namedtuple('TestNamedTuple', ['a', 'b'])
    assert isinstance(to_namedtuple({'a': 'a', 'b': 'b'}), TestNamedTuple)

    TestNamedTuple = namedtuple('TestNamedTuple', [])
    assert isinstance(to_namedtuple({'a': 'a', 'b': 'b'}), TestNamedTuple)

    TestNamedTuple = namedtuple('TestNamedTuple', ['a', 'b'])
    assert isinstance(to_namedtuple({'a': None, 'b': None}), TestNamedTuple)

    TestNamedTuple

# Generated at 2022-06-11 22:20:19.395738
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.py23utils import is_str, is_text
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    import pytest
    expected = \
"""\
NamedTuple(a=1, b=NamedTuple(a=1, b=2), c=NamedTuple(a=1, b=2), integers=[1, 2], letters=('a', 'b'), list=['a', 'b'], strings=['a', ['b']], testdict={'a': 'b'}, testtuple=('a', 'b', 'c'))
"""

# Generated at 2022-06-11 22:20:29.500943
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)

    import collections
    assert to_namedtuple(collections.OrderedDict([('a', 1)])) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple(collections.OrderedDict([('b', 2), ('a', 1)])) == namedtuple('NamedTuple', 'b a')(2, 1)

# Generated at 2022-06-11 22:20:39.984103
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import random
    import string
    import timeit

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert isinstance(nt.a, int)
    assert isinstance(nt.b, int)
    assert nt.a == 1
    assert nt.b == 2

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert isinstance(nt.a, int)
    assert isinstance(nt.b, int)
    assert isinstance(nt.c, int)
    assert nt.a == 1
    assert nt.b == 2
   

# Generated at 2022-06-11 22:20:49.820617
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print(to_namedtuple([1, 2, 3]))
    print(to_namedtuple((1, 2, 3)))
    print(to_namedtuple({1: 1, 2: 2, 3: 3}))
    obj = object()
    print(to_namedtuple({1: obj}))
    try:
        print(to_namedtuple(obj))
    except TypeError as err:
        print(err)
    try:
        print(to_namedtuple('str'))
    except TypeError as err:
        print(err)
    try:
        print(to_namedtuple([]))
    except TypeError as err:
        print(err)
    dic: OrderedDict = OrderedDict()
    dic[3] = 3

# Generated at 2022-06-11 22:21:00.529006
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    assert to_namedtuple({
        'a': 1,
        'b': 2
    }) == to_namedtuple(OrderedDict((
        ('a', 1),
        ('b', 2)
    ))) == to_namedtuple(SimpleNamespace(
        a=1,
        b=2,
    ))
    assert to_namedtuple(
        [1, to_namedtuple({'a': 1, 'b': 2})]
    ) == [1, to_namedtuple({'a': 1, 'b': 2})]

# Generated at 2022-06-11 22:21:12.180780
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import logging
    import sys
    from flutils.logutils import BraceStyleAdapter

    logger = BraceStyleAdapter(logging.getLogger(__name__))

    try:
        to_namedtuple("example")
    except TypeError as err:
        logger.debug("Returned exception: {}", err)
    else:
        logger.error("Should have returned exception")

    try:
        to_namedtuple({'a': 1})
    except TypeError as err:
        logger.error("Returned exception: {}", err)
    else:
        logger.debug("Should have returned exception")

    results = to_namedtuple([1, 2, {'a': 1, 'b': 2}])

# Generated at 2022-06-11 22:21:19.991504
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.tests import moduletester
    import pytest
    from collections import OrderedDict
    t = SimpleNamespace(a=1)
    k = to_namedtuple(t)
    assert k.a == 1
    t.b = 2
    k = to_namedtuple(t)
    assert k.a == 1
    assert k.b == 2
    t = SimpleNamespace(
        a=1,
        b=2,
        c=SimpleNamespace(
            d=3,
            e=4,
            f=5,
        ),
    )
    k = to_namedtuple(t)
    assert k.a == 1
    assert k.b == 2
    assert k.c.d == 3
   

# Generated at 2022-06-11 22:21:37.529813
# Unit test for function to_namedtuple
def test_to_namedtuple():
        l1 = ['a', 'b']
        td = to_namedtuple(l1)
        assert td[0] == 'a'
        l1 = ['a', {'b': 1, 'c': 2}]
        td = to_namedtuple(l1)
        assert td[0] == 'a'
        assert td[1].b == 1
        assert td[1].c == 2
        l1 = ['a', {'b': 1, 'c': 2}]
        td = to_namedtuple(l1)
        assert td[0] == 'a'
        assert td[1].b == 1
        assert td[1].c == 2
        l1 = [{'a': 1, 'b': 2},{'a': 3, 'b': 4}]
        td = to_namedt

# Generated at 2022-06-11 22:21:49.028495
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test conversion of a dictionary
    dictionary = {
        'a': 1,
        'b': 2,
    }
    try:
        result = to_namedtuple(dictionary)
        assert result == namedtuple('NamedTuple', 'a, b')(1, 2), \
            'Returned value is not the same as the test value.'
    except AssertionError as err:
        raise AssertionError(err) from err
    except Exception as err:
        raise AssertionError(
            'Could not convert a dictionary'
        ) from err

    # Test conversion of an ordered dictionary
    dictionary = OrderedDict()
    dictionary['b'] = 2
    dictionary['a'] = 1

# Generated at 2022-06-11 22:21:51.257916
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest

    doctest.testmod(verbose=False)

# Generated at 2022-06-11 22:22:01.727682
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'_a': 1, 'b': 2}
    print(to_namedtuple(dic))

    dic = {'a': 1, 'b': 2}
    print(to_namedtuple(dic))
    dic = {'a': 1, 'c': 2, 'b': 2}
    print(to_namedtuple(dic))
    dic = {'a': 1, 'b': [1, 2, 3]}
    print(to_namedtuple(dic))
    dic = {'a': 1, 'b': {'c': 2}}
    print(to_namedtuple(dic))
    dic = {'a': 1, 'b': {'c': 2, '_d': 3}, 'e': 4}

# Generated at 2022-06-11 22:22:04.578745
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:22:13.431270
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple',
                                                         'a b')(1, 2)
    assert to_namedtuple([{'a': 1, 'b': 2}])[0] == namedtuple('NamedTuple',
                                                               'a b')(1, 2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.1) == 1.1
    assert to_namedtuple(None) is None
    assert to_namedtuple('') == ''
    assert to_namedtuple(True) is True

# Generated at 2022-06-11 22:22:23.911447
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import List, Tuple
    from collections import namedtuple, OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Mapping: Mapping[str, Any]
    # Sequence: List[Any] or Tuple[Any]

    assert to_namedtuple([]) == []
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple([{}]) == [NamedTuple()]

    assert to_namedtuple(()) == ()
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple(({},)) == (NamedTuple(),)


# Generated at 2022-06-11 22:22:32.924678
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple([]) == []

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]

    assert to_namedtuple([[1, 2, 3], [4, 5, 6]]) == [[1, 2, 3], [4, 5, 6]]

    assert to_namedtuple([[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == \
        [[1, 2, 3], [4, 5, 6], [7, 8, 9]]


# Generated at 2022-06-11 22:22:41.326753
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
        },
        'f': [
            {
                'g': 5,
                'h': 6,
            },
            7,
            8,
            9,
        ],
    }
    lis = to_namedtuple(dic)
    assert isinstance(lis, NamedTuple)
    assert isinstance(lis.a, int)
    assert isinstance(lis.b, int)
    assert isinstance(lis.c, NamedTuple)
    assert isinstance(lis.c.d, int)
    assert isinstance(lis.c.e, int)
    assert isinstance(lis.f, List)

# Generated at 2022-06-11 22:22:51.524405
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    tup = to_namedtuple(dic)
    assert tup.a == 1
    assert tup.b == 2
    lst = ['a', 1, dic]
    tup = to_namedtuple(lst)
    assert tup == tuple(lst)
    odic = OrderedDict([('a', 1), ('b', 2)])
    tup = to_namedtuple(odic)
    assert tup.a == 1
    assert tup.b == 2


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:23:09.102743
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.validators import validate_identifier
    from types import SimpleNamespace
    import pytest
    
    def test_nest_as_tuple():
        dic = {'b': 2, 'a': 1}
        ret = to_namedtuple(dic)
        assert ret.a == 1
        assert ret.b == 2
        assert len(ret) == 2
        assert len(ret._fields) == 2
        assert ret._fields == ('a', 'b')
    
    def test_nest_as_tuple_asc_order():
        dic = {'a': 1, 'b': 2}
        ret = to_namedtuple(dic)
        assert ret.a == 1
        assert ret.b == 2

# Generated at 2022-06-11 22:23:17.499367
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(tuple()) == tuple()
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple([{}, {}]) == [NamedTuple(), NamedTuple()]
    assert to_namedtuple((NamedTuple(a=1), NamedTuple(b=2))) == (
        NamedTuple(a=1), NamedTuple(b=2)
    )

# Generated at 2022-06-11 22:23:27.810698
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Function to_namedtuple
    """
    import numpy

    numpy_array = numpy.array([[1, 2], [3, 4]])

# Generated at 2022-06-11 22:23:33.711488
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple


    class TestCases(TestCase):
        def test_dict(self):
            test_dict = {'a': 1, 'b': 2}
            res = to_namedtuple(test_dict)
            self.assertEqual(res.a, 1)
            self.assertEqual(res.b, 2)


        def test_ordered_dict(self):
            from collections import OrderedDict
            test_dict = OrderedDict([
                ('a', 1),
                ('b', 2),
            ])
            res = to_namedtuple(test_dict)
            self.assertEqual(res.a, 1)

# Generated at 2022-06-11 22:23:44.866966
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    import types
    dic = {'a': 1, 'b': 2}
    assert isinstance(to_namedtuple(dic), collections.namedtuple)
    assert to_namedtuple(dic) == collections.namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    lis = [1, 2, 3]
    assert isinstance(to_namedtuple(lis), list)
    assert to_namedtuple(lis) == [1, 2, 3]
    tu = tuple(dic.values())
    assert isinstance(to_namedtuple(tu), tuple)
    assert to_namedtuple(tu) == (1, 2)

# Generated at 2022-06-11 22:23:52.235053
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Cover the 'dict' branch
    out = to_namedtuple({'a': 1, 'b': 2})
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2
    # Cover the 'list' branch
    out = to_namedtuple([1, 2, 3])
    assert isinstance(out, list)
    assert out[0] == 1
    assert out[1] == 2
    assert out[2] == 3
    # Cover the 'tuple' branch
    out = to_namedtuple((1, 2, 3))
    assert isinstance(out, tuple)
    assert out[0] == 1
    assert out[1] == 2
    assert out[2] == 3
    # Cover the no conversion

# Generated at 2022-06-11 22:23:54.242119
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    obj = to_namedtuple(obj)
    assert isinstance(obj, NamedTuple)


# Generated at 2022-06-11 22:24:04.715960
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from itertools import repeat
    from collections import defaultdict
    from collections.abc import Iterable
    from typing import Any, Dict, List, Set, Tuple, Union

    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import is_namedtuple
    from flutils.tests.utils import BaseTestCase

    # noinspection PyUnusedLocal
    class TestNT(NamedTuple):
        a: int
        b: str

    nt_test: NamedTuple = TestNT(a=1, b='abc')
    nt_test_list: List[NamedTuple] = [TestNT(a=1, b='abc'), TestNT(a=2, b='abc')]

# Generated at 2022-06-11 22:24:16.873293
# Unit test for function to_namedtuple
def test_to_namedtuple():
    aList = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    exp = [
        namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2),
        namedtuple('NamedTuple', ('c', 'd'))(c=3, d=4)
    ]
    out = to_namedtuple(aList)
    assert out == exp

    d = OrderedDict()
    d['c'] = 3
    d['a'] = 1
    d['b'] = 2
    d['e'] = 5
    d['f'] = 6

# Generated at 2022-06-11 22:24:25.699089
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == \
        to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(SimpleNamespace(a=1, b=2))
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        to_namedtuple(SimpleNamespace(a=1, b=2))
    assert to_namedtuple([1, 2, 3]) == \
        to_namedtuple((1, 2, 3))
    assert to_namedtuple([1, 2, 3]) != to_namedtuple({'a': 1, 'b': 2})

# Generated at 2022-06-11 22:24:55.686195
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from flutils.validators import validate_identifier

    class TestToNamedTuple(unittest.TestCase):

        def test_to_namedtuple(self):
            tup = to_namedtuple((1, 2, 3))
            self.assertIsInstance(tup, tuple)
            self.assertEqual(len(tup), 3)
            self.assertEqual(tup[0], 1)
            self.assertEqual(tup[1], 2)
            self.assertEqual(tup[2], 3)

            tup = to_namedtuple([1, 2, 3])