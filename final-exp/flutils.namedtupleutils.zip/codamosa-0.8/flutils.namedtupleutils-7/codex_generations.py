

# Generated at 2022-06-11 22:15:07.146966
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=False)



# Generated at 2022-06-11 22:15:18.508105
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert(to_namedtuple(1) == 1)
    assert(to_namedtuple("blah") == "blah")
    assert(to_namedtuple([1, 2, 3]) == [1, 2, 3])
    assert(to_namedtuple((1, 2, 3)) == (1, 2, 3))
    assert(to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2))
    assert(to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2))
    assert(to_namedtuple(OrderedDict((('a', 1), ('b', 2)))) == NamedTuple(a=1, b=2))

# Generated at 2022-06-11 22:15:31.056981
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import List, Tuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple

    # Check that simple dicts are handled properly
    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out == _to_namedtuple(dic)
    assert out.a == dic['a']
    assert out.b == dic['b']
    assert out.c == dic['c']
    assert out == (1, 2, 3)

    # Check that OrderedDict's are properly handled
    dic = OrderedDict({'a': 1, 'b': 2, 'c': 3})
    out

# Generated at 2022-06-11 22:15:43.209843
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic: Mapping = OrderedDict()
    dic['a'] = 'a'
    dic['b'] = OrderedDict()
    dic['c'] = (1, 2)
    dic['d'] = [3, 4]
    dic['e'] = SimpleNamespace(f=5)
    dic['_f'] = '_f'
    dic['g'] = 'g'
    dic['_h'] = '_h'
    dic['i'] = 'i'
    dic['j'] = 'j'
    dic['k'] = SimpleNamespace(l=[6, 7])
    dic['b']['m'] = 'm'
    dic['b']['n'] = 'n'

# Generated at 2022-06-11 22:15:48.918517
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    res = to_namedtuple(dic)
    assert res.a == 1
    assert res.b == 2
    assert res[0] == 1
    assert res[1] == 2

    lst = [1, 2, 3]
    res = to_namedtuple(lst)
    assert res == [1, 2, 3]
    assert res[0] == 1
    assert res[1] == 2
    assert res[2] == 3

    tup = (1, 2, 3)
    res = to_namedtuple(tup)
    assert res == (1, 2, 3)
    assert res[0] == 1
    assert res[1] == 2
    assert res[2] == 3


# Generated at 2022-06-11 22:15:58.692981
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for to_namedtuple."""
    import collections
    import datetime
    import enum
    import uuid
    from flutils.iterutils import cast_tuple

    class MyEnum(enum.Enum):
        one = 1
        two = 2

    class MyTuple(collections.namedtuple('MyTuple', 'string int enum datetime')):
        __slots__ = ()

        @property
        def _fields(self) -> Tuple[str, ...]:
            return cast_tuple(self._field_defaults)


# Generated at 2022-06-11 22:16:10.432139
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Mapping, Sequence
    from types import SimpleNamespace
    from pprint import pprint
    from copy import copy, deepcopy
    import os
    import sys

    script_dir = os.path.dirname(os.path.realpath(__file__))
    script_path = os.path.join(script_dir, "example.cfg")

# Generated at 2022-06-11 22:16:22.824243
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils

    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import __dict__ as dunderdict
    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import _to_namedtuple, to_namedtuple
    from types import MappingProxyType
    from unittest import (
        mock,
        skip,
        TestCase,
    )
    from typing import (
        Any,
        Dict,
        Generator,
        Mapping,
        Sequence,
    )
    from unittest.mock import (
        call,
        MagicMock,
        patch,
        sentinel,
    )
    from flutils.exceptions import (
        FlutilsError,
    )

# Generated at 2022-06-11 22:16:26.599001
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    ntuple = to_namedtuple(dic)
    print(ntuple)
    assert ntuple.a == 1 and ntuple.b == 2


if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-11 22:16:35.816382
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test the function `to_namedtuple`.

    """

    # Test different datatypes
    obj = {'a': 1, 'b': 2}
    result = to_namedtuple(obj)
    expected = NamedTuple(a=1, b=2)
    assert result == expected

    d = {'a': 1, 'b': 2}
    obj = OrderedDict(d)
    result = to_namedtuple(obj)
    expected = NamedTuple(a=1, b=2)
    assert result == expected

    obj = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    result = to_namedtuple(obj)

# Generated at 2022-06-11 22:16:45.373919
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) == 1
    assert to_namedtuple('foo') == 'foo'
    assert to_namedtuple(True) is True
    assert to_namedtuple(['1', '2', '3']) == ['1', '2', '3']

test_to_namedtuple()
 

import sys
sys.path.append('../')
from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-11 22:16:57.100871
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    with pytest.raises(TypeError):
        to_namedtuple(1)
    with pytest.raises(TypeError):
        to_namedtuple(None)
    with pytest.raises(TypeError):
        to_namedtuple('abc')
    with pytest.raises(TypeError):
        to_namedtuple({1: 'abc'})
    with pytest.raises(TypeError):
        to_namedtuple([1, 2, 3])
    with pytest.raises(TypeError):
        to_namedtuple(('a', 'b', 'c'))

    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    out = to

# Generated at 2022-06-11 22:17:09.010893
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils import validate_identifier
    from flutils.namedtupleutils import to_namedtuple

    nt1 = to_namedtuple({'a': 1, 'b': 2})
    assert type(nt1).__name__ == "NamedTuple"
    assert nt1 == (1, 2)
    vars(nt1) == {"a": 1, "b": 2}

    try:
        validate_identifier('1')
    except SyntaxError:
        pass
    nt2 = to_namedtuple({2: 'b', '1': 'a', 'a': 1, 'b': 2})
    assert type(nt2).__name__ == "NamedTuple"
    assert nt2 == ('a', 'b')

# Generated at 2022-06-11 22:17:19.117897
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple

    def _run(obj):
        try:
            out = to_namedtuple(obj)
        except TypeError as e:
            with pytest.raises(TypeError, match=r".+"):
                _to_namedtuple(obj)
            raise e
        return out

    obj = [1, 2, 3]
    assert _run(obj) == obj

    obj = (1, 2, 3)
    assert _run(obj) == obj

    obj = {'a': 1, 'b': 2}
    assert _run(obj) == obj

    obj = SimpleNamespace(a=1, b=2)

# Generated at 2022-06-11 22:17:27.404785
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    dic = {'a': 1, 'b': 2}
    namedtuple_ret = to_namedtuple(dic)
    assert len(namedtuple_ret) == 2
    assert namedtuple_ret.a == 1
    assert namedtuple_ret.b == 2
    with pytest.raises(AttributeError):
        assert namedtuple_ret.c == 1
    dic = {  # dict that includes dicts
        'a': 1,
        'b': 2,
        'c': {'d': 3},
    }
    namedtuple_ret = to_namedtuple(dic)
    assert len(namedtuple_ret) == 3
    assert namedtuple_ret.a == 1
    assert namedtuple_ret.b == 2

# Generated at 2022-06-11 22:17:37.481676
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert type(out) == namedtuple('NamedTuple', ('a', 'b'))
    assert out.a == 1
    assert out.b == 2

    li = [1, 2, 3]
    out = to_namedtuple(li)
    assert type(out) == list
    assert out == li

    tu = (1, 2, 3)
    out = to_namedtuple(tu)
    assert type(out) == tuple
    assert out == tu

    nt = namedtuple('NamedTuple', ['a', 'b'])('x', 'y')
    out = to_namedtuple(nt)

# Generated at 2022-06-11 22:17:48.044039
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a']) == ['a']
    assert to_namedtuple(('a', 'b')) == ('a', 'b')
    assert to_namedtuple(dict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dict(b=2, a=1)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dict(a=1, b=2, _c=3)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dict(b=2, _c=3, a=1)) == NamedTuple(a=1, b=2)

# Generated at 2022-06-11 22:17:59.855734
# Unit test for function to_namedtuple
def test_to_namedtuple():
    '''Test to_namedtuple function'''
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.miscutils import print_message
    from flutils.validators import validate_identifier
    from time import time
    from types import SimpleNamespace
    import collections
    import random


# Generated at 2022-06-11 22:18:08.512280
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    def test_same_sequence(test_obj, seq):
        for i, obj in enumerate(test_obj):
            assert obj == seq[i]


# Generated at 2022-06-11 22:18:15.663387
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert dic == {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)


if __name__ == '__main__':
    print(to_namedtuple.__code__.co_varnames)
    print(to_namedtuple.__code__.co_argcount)
    a = to_namedtuple(dict())

# Generated at 2022-06-11 22:18:27.843693
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    class TestObject(object):
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    def assert_namedtuple(obj: Any, cls: type) -> None:
        assert isinstance(obj, cls)
        assert hasattr(obj, 'a')
        assert getattr(obj, 'a') == 1
        assert hasattr(obj, 'b')
        assert getattr(obj, 'b') == 2

    assert_namedtuple(to_namedtuple(TestObject(1, 2)), NamedTuple)
    assert_namedtuple(to_namedtuple([TestObject(1, 2)]), List)
    assert_namedtuple(to_namedtuple({TestObject(1, 2)}), Set)

# Generated at 2022-06-11 22:18:32.725093
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils  # needed for PyTest coverage
    assert flutils.namedtupleutils.to_namedtuple({}) == \
        flutils.namedtupleutils.to_namedtuple({'a': None, 'b': None}) == \
        flutils.namedtupleutils.to_namedtuple([1]) == \
        flutils.namedtupleutils.to_namedtuple(OrderedDict([('a', 'a')])) == \
        flutils.namedtupleutils.to_namedtuple(
            SimpleNamespace(a='a')) == flutils.namedtupleutils.NamedTuple(
                a=None, b=None)
    assert flutils.namedtupleutils.to_namedtuple([]) == \
        flutils.namedtupleutils.to_named

# Generated at 2022-06-11 22:18:44.658536
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test to_namedtuple()
    # Test 1 - NamedTuple
    test1_actual = to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'c': 4}])
    test1_expected = [NamedTuple(a=1, b=2), NamedTuple(a=3, c=4)]
    assert test1_actual == test1_expected, \
        "Test 1: Expected (%s); but got (%s)" % (test1_expected, test1_actual)

    # Test 2 - NamedTuple
    test2_actual = to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'c': 4, 'd': [5, 6]}])

# Generated at 2022-06-11 22:18:55.009429
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # noinspection PyUnusedLocal
    def _assert(
            exp: Union[List[Any], Tuple[Any, ...], NamedTuple],
            obj: Union[List[Any], Tuple[Any, ...], NamedTuple]
    ) -> None:
        assert isinstance(obj, type(exp))
        if not isinstance(obj, list):
            for attr in exp._fields:
                assert hasattr(obj, attr)
                val = getattr(obj, attr)
                assert isinstance(val, type(getattr(exp, attr)))
                if not isinstance(val, str):
                    _assert(getattr(exp, attr), val)
            if isinstance(obj, NamedTuple):
                assert len(obj._fields) == len(exp._fields)

    dic: OrderedD

# Generated at 2022-06-11 22:19:02.858262
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import Mapping, OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple({}) == to_namedtuple({}).__class__()
    assert to_namedtuple([]) == to_namedtuple([]).__class__()

    pytest.fail('to_namedtuple(4)')


if '__main__' == __name__:
    import doctest

    doctest.testmod()

# Generated at 2022-06-11 22:19:09.790786
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.test.helpers import (
        generate_test_data,
        run_test_data,
    )


# Generated at 2022-06-11 22:19:21.880854
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    import sys

    assert to_namedtuple('abc') == 'abc'
    assert to_namedtuple(1) == 1
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]

    # keyword list conversion
    lst = [{'a': 1, 'b': 2}]
    tup = _to_namedtuple(lst[0])
    assert tup.a == 1
    assert tup.b == 2
    ntup = to_namedtuple(lst)[0]
    assert ntup.a == 1
    assert ntup.b == 2

    # keyword list conversion with tuples

# Generated at 2022-06-11 22:19:32.787225
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Positive testing
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    od = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    assert to_namedtuple(od) == NamedTuple(a=1, b=2, c=3)

    lst = [1, 2, {'a': 1, 'b': 2}, 3]
    assert to_namedtuple(lst) == [1, 2, NamedTuple(a=1, b=2), 3]

    tup = (1, 2, {'a': 1, 'b': 2}, 3)

# Generated at 2022-06-11 22:19:43.907430
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    test_dict = {'a': 1, 'b': 2}
    converted_namedtuple = to_namedtuple(test_dict)
    test_namedtuple = namedtuple("test_namedtuple", 'a b')(a=1, b=2)
    assert isinstance(converted_namedtuple, namedtuple)
    assert converted_namedtuple == test_namedtuple

    test_dict = {'a': 1, 'b': 2, 'c': 3, 'C': 4}
    converted_namedtuple = to_namedtuple(test_dict)
    test_namedtuple = namedtuple("test_namedtuple", 'a b C c')(a=1, b=2, C=4, c=3)

# Generated at 2022-06-11 22:19:54.593933
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import to_dict
    from operator import attrgetter
    dic = {
        '_abc': 1,
        'abc': 1,
        'ABC': 1,
        'abc123': 1,
        '_ABC': 1,
        '1abc': 1,
    }
    obj = to_namedtuple(dic)
    assert hasattr(obj, 'abc')
    assert obj.abc == 1
    assert hasattr(obj, 'abc123')
    assert obj.abc123 == 1
    assert not hasattr(obj, '_abc')
    assert not hasattr(obj, 'ABC')
    assert not hasattr(obj, '_ABC')
    assert not hasattr(obj, '1abc')
   

# Generated at 2022-06-11 22:20:03.295612
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.testhelpers import check_function_output
    check_function_output('namedtupleutils.to_namedtuple', to_namedtuple)
    
    
    
    
    
    





# Generated at 2022-06-11 22:20:15.739428
# Unit test for function to_namedtuple
def test_to_namedtuple():
    sequence = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    obj1 = to_namedtuple(sequence)
    obj2 = to_namedtuple(obj1)
    assert sequence == [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    assert obj1 == [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]
    assert obj2 == [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]
    assert obj1[0].a == 1 and obj1[0].b == 2
    assert obj1[1].a == 3 and obj1[1].b == 4

# Generated at 2022-06-11 22:20:28.020169
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Tests the class to_namedtuple.
    """
    assert to_namedtuple(
        {'a': {'b': {'c': 1, 'd': 2}, 'e': 3}, 'f': 4}
    ) == NamedTuple(
        a=NamedTuple(
            b=NamedTuple(
                c=1,
                d=2,
            ),
            e=3,
        ),
        f=4,
    )

# Generated at 2022-06-11 22:20:38.691175
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'a': 1, 'b': 2}
    make = namedtuple('NamedTuple', d.keys())
    make = make(**d)
    make_expected = to_namedtuple(d)
    assert make == make_expected

    dic = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3)
    ])
    make = namedtuple('NamedTuple', dic.keys())
    make = make(**dic)
    make_expected = to_namedtuple(dic)
    assert make == make_expected

    obj = SimpleNamespace(**d)
    make = namedtuple('NamedTuple', obj.__dict__.keys())
    make = make(**obj.__dict__)
    make_expected = to

# Generated at 2022-06-11 22:20:49.129481
# Unit test for function to_namedtuple
def test_to_namedtuple():
    #function test_to_namedtuple():
    from collections import OrderedDict

# Generated at 2022-06-11 22:21:00.165693
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class _ExampleNamedTuple(NamedTuple):
        a: int
        b: int

    def _assert(aa, bb):
        assert aa.a == 1
        assert aa.b == 2
        assert aa[0] == 1
        assert aa[1] == 2
        assert bb.a == 3
        assert bb.b == 4
        assert bb[0] == 3
        assert bb[1] == 4

    a = _ExampleNamedTuple(a=1, b=2)
    b = {'a': 3, 'b': 4}
    c = ('a', 'b')
    d = to_namedtuple(a)
    _assert(d, to_namedtuple(b))
    _assert(d, to_namedtuple(c))
   

# Generated at 2022-06-11 22:21:11.953783
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for function to_namedtuple"""
    import datetime
    # import sys
    import unittest

    from flutils.namedtupleutils import to_namedtuple

    class Test_to_namedtuple(unittest.TestCase):
        """Unit tests for function to_namedtuple"""

        def test_list_dict(self):  # noqa
            # list -> dict
            dic1 = {'a': 1, 'b': 2}
            dic2 = to_namedtuple(dic1)
            self.assertIsInstance(dic2, namedtuple)
            self.assertEqual(dic2.a, 1)
            self.assertEqual(dic2.b, 2)

            # list -> list
            lst = [dic1, dic1]
           

# Generated at 2022-06-11 22:21:19.841139
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _dic = {'a': 1, 'b': 2}
    _res = to_namedtuple(_dic)
    assert _res == NamedTuple(a=1, b=2)

    _list = [1, 2, 3]
    _res = to_namedtuple(_list)
    assert _res == [1, 2, 3]

    _ntuple = NamedTuple(a=1, b=2)
    _res = to_namedtuple(_ntuple)
    assert _res == NamedTuple(a=1, b=2)

    _ns = SimpleNamespace(a=1, b=2)
    _res = to_namedtuple(_ns)
    assert _res == NamedTuple(a=1, b=2)

    _tuple = (1, 2, 3)
   

# Generated at 2022-06-11 22:21:23.558919
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert True


# Remove flake8 E741 ambiguity
# noinspection PyTypeChecker,PyUnresolvedReferences
if __name__ == '__main__':
    _ = to_namedtuple
    test_to_namedtuple()

# Generated at 2022-06-11 22:21:27.442390
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    new_obj = to_namedtuple(obj)
    print(new_obj)
    print(type(new_obj))
    assert new_obj[0] == 1
    assert new_obj[1] == 2

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:21:46.246575
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic1 = {'a': 1, 'b': {'bb': 2, 'cc': 3}, 'd': 4}

    namedtuple1 = namedtuple('namedtuple1', ['a', 'b', 'd'])
    namedtuple2 = namedtuple('namedtuple2', ['bb', 'cc'])
    exp = namedtuple1(1, namedtuple2(2, 3), 4)

    assert to_namedtuple(dic1) == exp

if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-11 22:21:52.930725
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import os
    import tempfile

    def make_tmp_file(
            contents: str,
            suffix: str = ''
    ) -> str:
        f = tempfile.NamedTemporaryFile(mode='w+t', suffix=suffix)
        f.write(contents)
        f.close()
        return f.name


# Generated at 2022-06-11 22:22:02.873203
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    import types
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert nt.a == 1
    assert hasattr(nt, 'b')
    assert nt.b == 2

    odic = OrderedDict(a=1, b=2)
    nt = to_namedtuple(odic)
    assert hasattr(nt, 'a')
    assert nt.a == 1
    assert hasattr(nt, 'b')
    assert nt.b == 2

    lst = [1, 2, 3]
    lst_nt: List[Tuple] = to_namedtuple

# Generated at 2022-06-11 22:22:12.648743
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from datetime import datetime
    import unittest

    class ToNamedTupleTestCase(unittest.TestCase):
        # pylint: disable=no-else-return
        def assertNamedTupleEqual(
                self,
                fst: NamedTuple,
                snd: NamedTuple,
                msg: str = None
        ):
            if not isinstance(fst, NamedTuple) or not isinstance(snd, NamedTuple):
                self.fail(
                    msg or '%s != %s' % (
                        '%r' % (fst,),
                        '%r' % (snd,)
                    )
                )
            else:
                fst_fields = list(fst._fields)

# Generated at 2022-06-11 22:22:16.099689
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_dict = {'a': 1, 'b': 2}
    assert to_namedtuple(test_dict) == namedtuple('NamedTuple', 'a b')(1, 2)



# Generated at 2022-06-11 22:22:25.175826
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple(('a', 'b', 'c')) == NamedTuple('a', 'b', 'c')
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']

    base1 = {'a': 1, 'b': 2}
    assert to_namedtuple(base1) == NamedTuple(a=1, b=2)

    base2 = SimpleNamespace(a=1, b=2)
    assert to_namedtuple(base2) == NamedTuple(a=1, b=2)

    base3 = (base1, base2)
    assert to_namedtuple(base3) == (NamedTuple(a=1, b=2), NamedTuple(a=1, b=2))


# Generated at 2022-06-11 22:22:33.730958
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import logging
    import uuid
    from decimal import Decimal
    from datetime import date
    from dateutil.relativedelta import relativedelta
    from pytz import timezone as tz
    from unittest import TestCase
    from unittest.mock import Mock
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from flutils.namedtupleutils import _AllowedTypes
    from flutils.objectutils import get_object_properties
    from flutils.dictutils import Dict
    from flutils.datetimeutils import Delorean
    from flutils.datetimeutils import DeloreanDelta

    # noinspection PyUnresolvedReferences

# Generated at 2022-06-11 22:22:41.666769
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple(['a', 'b']) == ('a', 'b')
    assert to_namedtuple(('a', 'b')) == ('a', 'b')
    assert to_namedtuple([1, 2]) == (1, 2)
    assert to_namedtuple((1, 2)) == (1, 2)
    assert (to_namedtuple([OrderedDict(), OrderedDict()]) ==
            (NamedTuple(), NamedTuple()))
    assert (to_namedtuple((OrderedDict(), OrderedDict())) ==
            (NamedTuple(), NamedTuple()))

# Generated at 2022-06-11 22:22:51.871133
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()

    assert to_namedtuple(dict()) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('b', 2), ('a', 1)])) == NamedTuple(b=2, a=1)

    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)

# Generated at 2022-06-11 22:22:58.339907
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils.to_namedtuple import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(OrderedDict(dic)) == \
        namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(**dic)) == \
        namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)

# Generated at 2022-06-11 22:23:27.259012
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = OrderedDict(a=1, b=2)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'1': 1, '2': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', '')()

    dic = {'a': 1, '_c': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a')(a=1)

    obj = SimpleNamespace()

# Generated at 2022-06-11 22:23:35.978271
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test for class 'to_namedtuple'."""
    from flutils.namedtupleutils import (
        to_namedtuple,
    )

    class Obj(object):
        pass

    o = Obj()
    o.t = 1
    o.m = 2
    o.m_t = 3
    o.__t = 4
    o.__m__t = 5

    # noinspection PyTypeChecker

# Generated at 2022-06-11 22:23:41.725175
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2
    assert nt._asdict() == dic
    assert nt._replace(a=3, b=4)._asdict() == {'a': 3, 'b': 4}


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:23:46.555433
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = dict(a=1, b=2)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)

    lst = [1, 2, 3]
    assert to_namedtuple(lst) == [1, 2, 3]

# Generated at 2022-06-11 22:23:52.850619
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2
    }
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2

    dic = {
        'a': 1,
        'b': {
            'c': 2
        }
    }
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b.c == 2

    obj = OrderedDict()
    obj['a'] = 1
    obj['b'] = 2
    obj = to_namedtuple(obj)
    assert obj.a == 1
    assert obj.b == 2

    obj = OrderedDict()
    obj['a'] = 1
    obj['b'] = {
        'c': 2
    }

# Generated at 2022-06-11 22:24:03.856240
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from itertools import count
    from operator import getitem
    from typing import NamedTuple
    from types import SimpleNamespace
    dic = OrderedDict()
    dic['ONE'] = 1
    dic['TWO'] = 2
    dic['THREE'] = 3
    namedtuple_ = to_namedtuple(dic)
    assert isinstance(namedtuple_, NamedTuple)
    for name, val in zip(namedtuple_._fields, namedtuple_):
        assert getitem(dic, name) == val
    dic = {'ONE': 1, 'TWO': 2, 'THREE': 3, 'FOUR': 4}
    namedtuple_ = to_namedtuple(dic)

# Generated at 2022-06-11 22:24:16.191175
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}).a == 1
    assert to_namedtuple({'a': 1, 'b': 2}).b == 2
    assert to_namedtuple({'a': 1, 'b': 2, 'c': [1, 2]}).c[1] == 2
    assert to_namedtuple({'a': 1, 'b': 2,
                          'c': {'d': 3, 'e': 4}}).c.d == 3
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == [1, 2]
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))[0] == 1

# Generated at 2022-06-11 22:24:25.363318
# Unit test for function to_namedtuple
def test_to_namedtuple():
    SimpleNamespace = SimpleNamespace()
    SimpleNamespace.nested_1 = "nested_1"
    SimpleNamespace.nested_2 = dict(a="a", b="b")
    SimpleNamespace.nested_3 = dict(a=dict(a=1), b=dict(b=2))
    SimpleNamespace.nested_4 = dict(a=dict(a=dict(a=dict(a=1))))

    convertDict = dict(SimpleNamespace=SimpleNamespace)
    newNamespace = to_namedtuple(convertDict)

    # now check that newNamespace is the same as expected.
    assert newNamespace.nested_1 == "nested_1"
    assert newNamespace.nested_2.a == "a"
    assert newNamespace.nested_2

# Generated at 2022-06-11 22:24:35.461122
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import os

    def do_test(obj, expect):
        out = to_namedtuple(obj)
        assert out == expect, 'out: (%r) %s;  expect: (%r) %s' % (type(out).__name__, out, type(expect).__name__, expect)

    do_test([1], [1])
    do_test({}, NamedTuple())
    do_test({'a': 1}, NamedTuple(a=1))
    if os.name == 'nt':
        expect = 'NamedTuple(a=1, b=2, c=3, d=4, e=5, f=6)'
    else:
        expect = 'NamedTuple(a=1, b=2, c=3, d=4, e=5)'

# Generated at 2022-06-11 22:24:46.406797
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from typing import (
        Any,
        List,
        NamedTuple,
        Tuple,
        Union,
    )

    _AllowedTypes = Union[
        List,
        Mapping,
        NamedTuple,
        SimpleNamespace,
        Tuple,
    ]
