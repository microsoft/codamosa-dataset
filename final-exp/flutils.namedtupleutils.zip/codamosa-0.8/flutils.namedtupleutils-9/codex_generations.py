

# Generated at 2022-06-11 22:15:13.620466
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:15:22.351257
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple({}) == NamedTuple()

    test_list = [
        'b',
        {'a': 1, 'b': 2},
        OrderedDict((('c', 3), ('a', 1))),
        OrderedDict((('c', 3), ('a', 1))).items(),
        SimpleNamespace(a=1, b=2)
    ]
    expected_list = [
        'b',
        NamedTuple(a=1, b=2),
        NamedTuple(a=1, c=3),
        (('a', 1), ('c', 3)),
        NamedTuple(a=1, b=2),
    ]
   

# Generated at 2022-06-11 22:15:33.102277
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import List, Tuple

    dic = {'a': 1, 'b': 2}
    expected = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == expected
    lst = [dic, dic]
    expected = [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]
    assert to_namedtuple(lst) == expected
    assert isinstance(to_namedtuple(lst), List)
    tup = tuple(lst)
    expected = ({'a': 1, 'b': 2}, {'a': 1, 'b': 2})
    assert to_namedtuple(tup) == expected
    assert isinstance(to_namedtuple(tup), Tuple)

# Generated at 2022-06-11 22:15:44.856860
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    tup = to_namedtuple(dic)
    assert 'a' in repr(tup)
    assert tup.a == dic['a']
    assert tup.b == dic['b']
    assert type(tup) == namedtuple('NamedTuple', 'a b')
    assert tup == namedtuple('NamedTuple', 'a b')(1, 2)

    ordered = OrderedDict(dic)
    tup = to_namedtuple(ordered)
    assert type(tup) == namedtuple('NamedTuple', 'a b')

# Generated at 2022-06-11 22:15:56.552828
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from datetime import datetime
    from decimal import Decimal
    from pprint import pprint

    # To test the type hints we need to cast to the return types.  This is
    # required because the type hints are not true types so mypy can't check
    # them.  But we can cast and mypy will be happy.
    NamedTuple = namedtuple('NamedTuple', 'a, b')
    ns = SimpleNamespace(
        a=5,
        b=10,
    )
    ntuple = to_namedtuple({'a': 5, 'b': 10})
    ntuple = cast(NamedTuple, ntuple)
    assert ntuple.a == 5 and ntuple.b == 10


# Generated at 2022-06-11 22:16:08.419555
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == dic['a']
    assert out.b == dic['b']
    assert out == dic
    ordered = OrderedDict(a=1, b=2)
    out = to_namedtuple(ordered)
    assert out.a == ordered['a']
    assert out.b == ordered['b']
    assert out == ordered
    nested_dic = {'a': 1, 'b': [2, 3]}
    out = to_namedtuple(nested_dic)
    assert out.a == nested_dic['a']
    assert out.b == (2, 3)

# Generated at 2022-06-11 22:16:13.503418
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) is 1
    assert to_namedtuple('') == ''
    assert to_namedtuple('1') == '1'
    assert to_namedtuple('foo_bar') == 'foo_bar'
    assert to_namedtuple('foo-bar') == 'foo-bar'
    assert to_namedtuple('foo.bar') == 'foo.bar'
    assert to_namedtuple('foo bar') == 'foo bar'
    assert to_namedtuple([]) == tuple()
    assert to_namedtuple([1, 2, 3]) == (1, 2, 3)
    assert to_namedtuple(()) == tuple()
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({}) == NamedT

# Generated at 2022-06-11 22:16:24.060335
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import json
    import http.client
    import typing
    import collections
    import urllib.parse
    import xml.etree.ElementTree as Et

    # Check to_namedtuple with a simple dict
    dic = {'a': 1, 'b': 2}
    res1 = to_namedtuple(dic)
    assert isinstance(res1, collections.namedtuple('NamedTuple', res1._fields))
    assert res1.a == 1
    assert res1.b == 2

    # Check to_namedtuple with a complex nested dict
    dic = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': {'f': {'g': 5, 'h': 6}}}
    res1 = to_namedtuple(dic)


# Generated at 2022-06-11 22:16:24.686165
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:16:32.518146
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Data
    dic: dict = {'a': 1, 'b': 2}
    dic2: dict = {'c': 3, 'd': 4}
    dic3: dict = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': 5}
    dic4: dict = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': 5, 'f': dic2}
    dic5: dict = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': 5, 'f': dic2, 'g': dic}

# Generated at 2022-06-11 22:16:49.164246
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dic) == expected

    obj = SimpleNamespace(**dic)
    expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(obj) == expected

    dic = [{'a': 1}, {'b': 2}]
    expected = [
        namedtuple('NamedTuple', 'a')(a=1),
        namedtuple('NamedTuple', 'b')(b=2),
    ]
    assert to_namedtuple(dic) == expected


# Generated at 2022-06-11 22:16:59.566050
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([{'a': 'a'}, {'b': 1}, {'c': [1, 2, 3]}]) \
           == [NamedTuple(a='a'), NamedTuple(b=1),
               NamedTuple(c=[1, 2, 3])]
    assert to_namedtuple([[{}, 1, 2], [3, 4]]) == ([NamedTuple(), 1, 2],
                                                    [3, 4])
    assert to_namedtuple([[{}, 1, 2], [3, 4]]) == ([NamedTuple(), 1, 2],
                                                    [3, 4])

# Generated at 2022-06-11 22:17:09.751886
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from types import SimpleNamespace
    from typing import (
        List,
        Tuple,
        Union,
    )

    from flutils.namedtupleutils import to_namedtuple

    def _namedtuple_to_dict(
            obj: Any,
            _return: List[Union[List, Tuple]] = []
    ) -> List[Union[List, Tuple]]:
        if hasattr(obj, '_fields'):
            obj = cast(namedtuple, obj)
            out = []
            for attr in obj._fields:
                val: Any = getattr(obj, attr)
                val = _namedtuple_to_dict(val, _return)

# Generated at 2022-06-11 22:17:19.564332
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test namedtupleutils.to_namedtuple()."""
    for key, value in _to_namedtuple.registry.items():
        print(key, value)

    dic = {'a': 1, 'b': 2}
    dic = to_namedtuple(dic)
    assert dic.a == 1

    dic = {'b': 2, 'a': 1}
    dic = to_namedtuple(dic)
    assert dic.a == 1

    dic = {'a_1': 1, 'b_2': 2}
    dic = to_namedtuple(dic)
    assert dic.a_1 == 1

    dic = {'B_2': 2, 'A_1': 1}

# Generated at 2022-06-11 22:17:27.836706
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2}) == NamedTuple(b=2)
    assert to_namedtuple({'b': 2, 'a': 1, '_c': '3'}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1, 'c': {}}) == NamedTuple(a=1, b=2, c=NamedTuple())

# Generated at 2022-06-11 22:17:37.292429
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils as uut


    _ = uut.to_namedtuple

    dic = {'a': 1, 'b': 2}
    nt = _(dic)
    print(repr(nt))
    assert repr(nt) == "NamedTuple(a=1, b=2)"

    dic = {'a': 1, 'b': dic, 'c': {'x': 'y'}}
    nt = _(dic)
    print(repr(nt))
    assert repr(nt) == "NamedTuple(a=1, b=NamedTuple(a=1, b=2), c=NamedTuple(x='y'))"


# Generated at 2022-06-11 22:17:47.880179
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lst = [1, [2, 3], {'a': 4, 'b': 5}]
    dic = {'foo': lst}
    odic = OrderedDict(foo=lst, bar='bar')
    tup = (1, [2, 3], {'a': 4, 'b': 5})
    exp = namedtuple('NamedTuple', ['a', 'b'])(a=4, b=5)

    assert to_namedtuple(lst) == [1, [2, 3], exp]
    assert to_namedtuple(dic) == NamedTuple(foo=[1, [2, 3], exp])
    assert to_namedtuple(odic) == NamedTuple(foo=[1, [2, 3], exp], bar='bar')

# Generated at 2022-06-11 22:17:48.585715
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-11 22:18:00.452087
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest

    data: dict = {
        'a': 1,
        'b': 2,
        'c': {'d': 4, 'f': 3, 'e': 5},
        'g': [6, 7, 8],
        'h': 'string',
        'i': (9, 10),
        'j': {'k': {'l': 11, 'm': 12}, 'n': 13, 'o': 14},
        'p': [{'q': 15, 'r': 16}, {'q': 17, 'r': 18}],
    }

# Generated at 2022-06-11 22:18:04.419835
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple([1, 2]), list)
    assert isinstance(to_namedtuple((1, 2)), tuple)
    assert isinstance(to_namedtuple({'a': 1}), NamedTuple)


# vim: set ft=python :

# Generated at 2022-06-11 22:18:15.463794
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2, 'c': 3}
    assert to_namedtuple(dic) == {'a': 1, 'b': 2, 'c': 3}
    assert not to_namedtuple(dic) == {'a': 1, 'b': 2, 'c': 3}

if __name__ == '__main__':
    import sys
    print(to_namedtuple(sys.argv))

# Generated at 2022-06-11 22:18:25.357536
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from collections import (
        OrderedDict,
    )
    from types import SimpleNamespace
    from typing import (
        List,
        Tuple,
    )

    obj = OrderedDict([
        ('a', 1),
        ('b', 2),
    ])
    out: Tuple[int, int] = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2

    obj = {'a': 1, 'b': 2}
    out: Tuple[int, int] = to_namedtuple(obj)
    assert out.a == 1
    assert out.b == 2


# Generated at 2022-06-11 22:18:35.410613
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import Dict, Optional

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(tuple([1, 2, 3])) == (1, 2, 3)
    assert to_namedtuple(OrderedDict([(1, 2), (3, 4)])) == (1, 2, 3, 4)
    assert to_namedtuple(OrderedDict([('a', 'b'), (3, 4)])) == (3, 4, 'a', 'b')
    assert to_namedtuple(OrderedDict([('a', 'b'), (3, [4])])) == (3, [4], 'a', 'b')


# Generated at 2022-06-11 22:18:45.672249
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # string to NamedTuple
    with pytest.raises(TypeError):
        _to_namedtuple('a')

    # list to NamedTuple
    item1 = ['a', 1]
    item2 = ['b', 2]
    value1 = _to_namedtuple(item1)
    value2 = _to_namedtuple(item2)
    out = _to_namedtuple([item1, item2])

    assert isinstance(value1, NamedTuple)
    assert isinstance(value2, NamedTuple)
    assert isinstance(out, list)
    assert value1.a == 'a'
    assert value1.b == 1
    assert value2.a == 'b'
    assert value2.b == 2
    assert out[0] == value1

# Generated at 2022-06-11 22:18:55.476559
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Iterable
    from datetime import datetime
    from operator import attrgetter
    from typing import Dict, List
    from uuid import UUID, uuid4

    # Just a test list.  Created with:
    #   from random import randint as ri
    #   from faker import Faker
    #   from faker.providers import profile
    #   fake = Faker()
    #   fake.add_provider(profile)
    #   print(
    #       [{'a': ri(1, 100), 'b': ri(1, 100), 'c': ri(1, 100), 'd': ri(1, 100),
    #         'e': fake

# Generated at 2022-06-11 22:19:06.005502
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(tuple([1, 2, 3])) == (1, 2, 3)
    assert isinstance(to_namedtuple({'a': 1}), NamedTuple)
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': {'b': 2}}) == NamedTuple(a=NamedTuple(b=2))
    assert to_namedtuple(OrderedDict([('a', 1)])) == NamedTuple(a=1)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        NamedTuple

# Generated at 2022-06-11 22:19:17.013123
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Sequence
    from numbers import Real
    from types import SimpleNamespace
    from typing import NamedTuple, Union

    assert to_namedtuple("Hello") == "Hello"

    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)

    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]

    assert to_namedtuple(OrderedDict([('b', 2), ('a', 1)])) == \
        NamedTuple(a=1, b=2)


# Generated at 2022-06-11 22:19:28.320854
# Unit test for function to_namedtuple
def test_to_namedtuple():
    nt1 = to_namedtuple({
        'one': 1,
        'two': 2,
        'three': {
            'a': 'A',
            'b': 'B',
            'c': 'C',
        },
    })
    assert hasattr(nt1, 'one')
    assert hasattr(nt1, 'two')
    assert hasattr(nt1, 'three')
    assert nt1.one == 1
    assert nt1.two == 2
    assert isinstance(nt1.three, NamedTuple)
    assert hasattr(nt1.three, 'a')
    assert hasattr(nt1.three, 'b')
    assert hasattr(nt1.three, 'c')

    # This just makes sure we can use underscores in the keys
    nt2 = to_namedtuple

# Generated at 2022-06-11 22:19:37.535830
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from unittest.mock import Mock

    my_list = ['a', 1, 'b', 2]
    assert to_namedtuple(my_list) == ['a', 1, 'b', 2]

    my_tuple = ('a', 1, 'b', 2)
    assert to_namedtuple(my_tuple) == ('a', 1, 'b', 2)

    my_dict = {'a': 1, 'b': 2}
    assert to_namedtuple(my_dict) == NamedTuple(a=1, b=2)

    my_ordereddict = OrderedDict(a=1, b=2)
    assert to_namedtuple(my_ordereddict) == NamedTuple(a=1, b=2)

# Generated at 2022-06-11 22:19:40.205529
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

# Generated at 2022-06-11 22:19:49.460405
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:19:52.912972
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    with pytest.raises(TypeError, match="Can convert only 'list', 'tuple', 'dict' to a NamedTuple;"):
        to_namedtuple(1)

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:19:53.404335
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-11 22:20:02.600738
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections.abc import Mapping

    from flutils.miscutils import NamedSimpleNamespace

    import pytest

    a_tuple = [1, 2, 3, {'b': 4, 'a': 5}, ('blue', 'dark', 'green')]
    a_tuple_named_tuple = to_namedtuple(a_tuple)
    assert isinstance(a_tuple_named_tuple, list)
    assert isinstance(a_tuple_named_tuple[0], int)
    assert isinstance(a_tuple_named_tuple[1], int)
    assert isinstance(a_tuple_named_tuple[2], int)
    assert isinstance(a_tuple_named_tuple[3], NamedTuple)

# Generated at 2022-06-11 22:20:15.045571
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyPackageRequirements
    import hypothesis.strategies as st
    from hypothesis import given
    import string

    def _checks(
            names: List[str],
            obj: Union[List, Tuple, Mapping, SimpleNamespace],
            allow_underscore: bool = False
    ) -> None:
        no_underscore = '_' not in names
        if (allow_underscore is False and no_underscore) or \
                (allow_underscore and no_underscore is False):
            # If a underscore is allowed and exists, the
            # returned NamedTuple should omit it for being
            # a valid Identifier.
            #
            # If a underscore is not allowed and does not exist,
            # the NamedTuple should return all the attributes
            # since not one is invalid.
            out = to_named

# Generated at 2022-06-11 22:20:27.790568
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-11 22:20:38.487071
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestClass(unittest.TestCase):
        def test_list_tuple(self):
            test_data = to_namedtuple([1, 2, 3])
            self.assertTrue(isinstance(test_data, (list, tuple)))

            test_data = to_namedtuple((1, 2, 3))
            self.assertTrue(isinstance(test_data, (list, tuple)))
            self.assertTrue(all(
                isinstance(x, int) for x in test_data
            ))

            test_data = to_namedtuple([[1, 2, 3], (4, 5, 6)])
            self.assertTrue(isinstance(test_data, (list, tuple)))

# Generated at 2022-06-11 22:20:49.014370
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from random import randint
    from string import hexdigits
    from time import time
    from time import time_ns

    for _ in range(100):
        num_keys = randint(1, 10)
        keys = [''.join([hexdigits[randint(0, 15)] for _ in range(8)])
                for _ in range(num_keys)]
        vals = [randint(1, 10) for _ in range(num_keys)]
        dic = dict(zip(keys, vals))
        x: namedtuple = to_namedtuple(dic)
        assert len(x) == num_keys
        for key in keys:
            assert getattr(x, key) == dic[key]

    keys = ['']
    vals = ['a']

# Generated at 2022-06-11 22:21:00.096746
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple."""
    # noinspection PyTypeChecker
    lst: List[Any] = [
        {'a': 1, 'b': 2},
        [{'a': 'A', 'b': 'B'}, {'c': 'C', 'd': 'D'}],
        OrderedDict(b=2, a=1),
        SimpleNamespace(c=3, f=6, a=1, e=5, b=2, d=4),
    ]
    out = to_namedtuple(lst)
    assert out[0] == NamedTuple(a=1, b=2)
    assert out[1][0] == NamedTuple(a='A', b='B')

# Generated at 2022-06-11 22:21:11.800547
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'a': 1, 'b': 2}
    n = to_namedtuple(d)
    assert n.a == 1
    assert n.b == 2
    d = OrderedDict({'a': 1, 'b': 2})
    n = to_namedtuple(d)
    assert n.a == 1
    assert n.b == 2
    d = {'d': {'a': 1, 'b': 2}}
    n = to_namedtuple(d)
    assert n.d.a == 1
    assert n.d.b == 2
    l = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    n = to_namedtuple(l)
    assert n[0].a == 1

# Generated at 2022-06-11 22:21:35.567162
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    from time import time

    def to_timestamp(dt: datetime) -> float:
        """Convert a datetime.datetime object to a time.time() timestamp."""

        return time()

    rtn = to_namedtuple({
        'a': 1,
        'b': 2
    })
    assert rtn.a == 1
    assert rtn.b == 2


# Generated at 2022-06-11 22:21:46.538243
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Unit test for function to_namedtuple

    It will fail when the function is modified
    """
    import types
    assert to_namedtuple("something") == "something"
    assert to_namedtuple(("something", "more")) == ("something", "more")
    assert to_namedtuple(["something", "more"]) == ["something", "more"]
    assert to_namedtuple({"something": "more"}) == types.SimpleNamespace(**{"something": "more"})
    assert to_namedtuple({"something": "more", "next": "thing"}) == types.SimpleNamespace(**{"something": "more", "next": "thing"})
    assert to_namedtuple({"_something": "more", "next": "thing", "other": "thing"}) == types.SimpleNamespace

# Generated at 2022-06-11 22:21:53.082510
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = SimpleNamespace(c=1, b=2, a=3, _=4)
    assert obj.c == 1
    assert obj.b == 2
    assert obj.a == 3
    assert obj._ == 4
    out = to_namedtuple(obj)
    assert out == NamedTuple(a=3, b=2, c=1)

    obj = {'c': 1, 'b': 2, 'a': 3, '_': 4}
    out = to_namedtuple(obj)
    assert out == NamedTuple(a=3, b=2, c=1)

    obj = {'c': 1, 'b': 2, 'a': 3, '_': 4, 'a*': 5}
    out = to_namedtuple(obj)

# Generated at 2022-06-11 22:22:02.903765
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from collections import OrderedDict

    dic = OrderedDict(a=1, b=2)
    for obj in [
        dic,
        dict(dic),
        SimpleNamespace(**dic),
        [dic],
        (dic,),
    ]:
        expected = namedtuple('NamedTuple', 'a b')(1, 2)
        result = to_namedtuple(obj)
        assert result == expected
        assert result.a == expected.a
        assert result.b == expected.b
    dic = dict(a=1, b=dict(c=2, d=3))

# Generated at 2022-06-11 22:22:12.678177
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function :func:`to_namedtuple`.

    The test data is from function :func:`to_namedtuple`.
    """
    from flutils.namedtupleutils import to_namedtuple

    # not started yet
    try:
        to_namedtuple('')
    except TypeError as e:
        assert str(e) == (
            "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
            "got: (%r) ''" % type('').__name__  # type: ignore[misc]
        )

    # list

# Generated at 2022-06-11 22:22:23.492863
# Unit test for function to_namedtuple
def test_to_namedtuple():

    items = [
        dict(a=1, b=2, c=3),
        dict(d=1, e=2, f=3),
        dict(g=1, h=2, i=3),
    ]
    namedtups = to_namedtuple(items)
    for item, namedtup in zip(items, namedtups):
        for key, val in item.items():
            assert getattr(namedtup, key) == val

    items = [
        dict(a=1, b=2, c=3),
        dict(d=1, e=2, f=3),
        dict(g=1, h=2, i=3),
    ]
    namedtups = to_namedtuple(items)

# Generated at 2022-06-11 22:22:32.647866
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    import types
    import unittest
    from flutils.namedtupleutils import _to_namedtuple
    from ..flutils_types import NamedTuple  # type: ignore[import]

    class MyTestCase(unittest.TestCase):

        def test_00(self):
            dic = {'a': 1,
                   'b': 2,
                   'c': {'d': 4,
                         'e': 5,
                         'f': [6, 7, 8, 9]}}
            nt = _to_namedtuple(dic)
            self.assertEqual(nt.a, 1)
            self.assertEqual(nt.b, 2)
            self.assertIsInstance(nt.c, NamedTuple)
            self.assertEqual(nt.c.d, 4)

# Generated at 2022-06-11 22:22:37.475569
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': {'b': 1, 'b2': 'test'}}
    assert to_namedtuple(dic) == NamedTuple(a=NamedTuple(b=1, b2='test'))



# Generated at 2022-06-11 22:22:49.296188
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from copy import deepcopy
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import IdentityDict
    from mock import Mock, patch
    from pprint import pformat

    # Test namedtuple to namedtuple
    @singledispatch
    def my_to_namedtuple(obj: Any) -> Any:
        return to_namedtuple(obj)

    @my_to_namedtuple.register(Mapping)
    def _(obj: Mapping) -> NamedTuple:
        return to_namedtuple(obj)

    inp = [0, 1, 2]
    exp = [0, 1, 2]
    assert exp == to_namedtuple(inp)

    inp = (0, 1, 2)
    exp = (0, 1, 2)

# Generated at 2022-06-11 22:22:57.207354
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)
    odic = OrderedDict(dic)
    assert to_namedtuple(odic) == namedtuple('NamedTuple', 'a b')(1, 2)
    nst = SimpleNamespace()
    nst.a = 1
    nst.b = 2
    assert to_namedtuple(nst) == namedtuple('NamedTuple', 'a b')(1, 2)
    tup = ('a', 'b')
    assert to_namedtuple(tup) == ('a', 'b')

    lst = [1, 2]
    assert to_

# Generated at 2022-06-11 22:23:35.873448
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pformat
    from flutils.namedtupleutils import to_namedtuple

    data = [
        {
            'a': 1,
            'c': {
                'k': [
                    {
                        'd': 3,
                    },
                    (
                        4,
                        5,
                    ),
                ],
            },
            'b': 2,
        },
        {
            'e': {
                'f': 6,
                'g': 7,
                'h': 8,
            },
            'i': 9,
        },
        {
            'j': 10,
        },

    ]
    data2 = to_namedtuple(data)
    print(pformat(data))
    print(pformat(data2))
    print(data2[0].a)

# Generated at 2022-06-11 22:23:37.597612
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:23:42.646266
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic)
    od = OrderedDict([('b', 2), ('a', 1)])
    assert to_namedtuple(od)
    # assert to_namedtuple({'_': 1})
    # assert to_namedtuple({'A': 1})

# Generated at 2022-06-11 22:23:51.058869
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    # noinspection PyPackageRequirements,PyUnresolvedReferences
    import pytest
    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import to_namedtuple

    def _to_namedtuple_test() -> None:
        """Test flutils.namedtupleutils.to_namedtuple."""
        dic = {'A': 1, 'B': 2}  # type: dict
        assert to_namedtuple(dic) == namedtuple('NamedTuple', dic.keys())(
            *dic.values())
        dic = {'A': 1, 'B': 2, 'a': 1, 'b': 2}

# Generated at 2022-06-11 22:23:53.256395
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)



# Generated at 2022-06-11 22:24:04.433427
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pprint
    dic = {
        'a': 1,
        'b': 2,
        'c': {
            'aa': 11,
            'bb': 22,
        },
        'd': 3,
        'e': 4,
        'f': 5,
        'g': {'gg': {'aa': 1, 'bb': 2, 'cc': 3}},
        'h': {'zz': {'aa': 1, 'bb': 2, 'cc': 3}},
        'i': {'xx': SimpleNamespace(aa=1, bb=2, cc=3)},
        'j': SimpleNamespace(aa=1, bb=2, cc=3),
    }
    pprint.pprint(dic)
    ntup = to_namedtuple(dic)


# Generated at 2022-06-11 22:24:16.760887
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from itertools import zip_longest
    from flutils.timing import Timer
    from datetime import datetime as dt
    import pytest
    import uuid
    import csv
    import re

    import sys
    sys_py_ver = '%s.%s' % (sys.version_info.major, sys.version_info.minor)

    print('\nTesting to_namedtuple:')
    with Timer() as timer:
        t = to_namedtuple
        namedtuple_from_dict = t({'a': 10, 'b': 20})
        namedtuple_from_odict = t(OrderedDict([('a', 10), ('b', 20)]))

# Generated at 2022-06-11 22:24:25.644987
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from typing import Iterable
    from collections import namedtuple

    TestObj = namedtuple('TestObj', 'a b c')


    class Test_to_namedtuple(unittest.TestCase):

        def test_dict(self):

            test_data = dict(a=1, b=2)
            out = to_namedtuple(test_data)

            self.assertIsInstance(out, namedtuple)
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)

            test_data = dict(a=TestObj(1, 2, 3), b=TestObj(2, 3, 4))
            out = to_namedtuple(test_data)

            self.assertIsInstance(out, namedtuple)

# Generated at 2022-06-11 22:24:35.647740
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from typing import NamedTuple
    import pytest

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, (NamedTuple,))
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3

    dic = {'a1': 1, 'b2': 2, 'c3': 3}
    nt = to_namedtuple(dic)
    assert isinstance(nt, (NamedTuple,))
    assert nt.a_1 == 1
    assert nt.b_2 == 2
    assert nt.c_3 == 3

# Generated at 2022-06-11 22:24:46.495166
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    bad = object()
    assert to_namedtuple([]) == []
    assert to_namedtuple([bad]) == [bad]
    assert to_namedtuple(()) == ()
    assert to_namedtuple((bad,)) == (bad,)
    assert to_namedtuple({}) == NamedTuple(())
    assert to_namedtuple({bad: bad}) == NamedTuple((bad,))
    assert to_namedtuple({'a': bad, 'b': bad}) == NamedTuple(a=bad, b=bad)
    assert to_namedtuple({'a': bad, 'c': bad, 'b': bad}) == NamedTuple(
        a=bad,
        b=bad,
        c=bad,
    )
    assert to