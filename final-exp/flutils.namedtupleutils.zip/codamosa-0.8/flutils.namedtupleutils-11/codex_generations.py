

# Generated at 2022-06-11 22:15:14.333484
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    from random import randrange
    from sys import getrecursionlimit

    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import (
        is_list,
        is_namedtuple,
        is_tuple,
    )

    def _create_simple():
        dic = {'a': 1, 'b': 2}
        return dic

    def _create_recursive(
            depth: int = 1,
    ) -> List:
        if depth > getrecursionlimit():
            return 'recurse'
        depth += 1

# Generated at 2022-06-11 22:15:16.827817
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)



# Generated at 2022-06-11 22:15:23.758568
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict as ODict
    from flutils.importutils import import_string
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-11 22:15:33.986261
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for function to_namedtuple
    """
    from pprint import pprint
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections import namedtuple
    from types import SimpleNamespace
    from typing import (
        Any,
        List,
        NamedTuple,
        Tuple,
        Union,
    )
    from flutils.namedtupleutils import to_namedtuple
    _AllowedTypes = Union[
        List,
        Mapping,
        NamedTuple,
        SimpleNamespace,
        Tuple,
    ]
    pprint(to_namedtuple([]))
    pprint(to_namedtuple(tuple()))
    pprint(to_namedtuple({}))

# Generated at 2022-06-11 22:15:40.356894
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest.mock import MagicMock
    from sys import platform
    from collections import Counter

    class TestObj(object):
        pass

    test_dict = dict(
        a=1,
        b='2',
        c=(3,),
        d=dict(
            e=4,
            f=5,
            g=TestObj(),
        ),
        h=None,
    )
    test_dict_copy = dict(test_dict)
    test_tup = tuple(test_dict.items())
    test_list = list(test_dict.items())
    test_namespace = SimpleNamespace(**test_dict_copy)

# Generated at 2022-06-11 22:15:48.173150
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert dic == to_namedtuple(dic)._asdict()
    assert dic == to_namedtuple(OrderedDict(sorted(dic.items())))._asdict()
    assert dic == to_namedtuple(SimpleNamespace(**dic))._asdict()
    assert dic == to_namedtuple(namedtuple('NamedTuple', sorted(dic.keys()))(**dic))._asdict()
    assert dic == to_namedtuple([(k, v) for k, v in dic.items()])._asdict()
    assert dic == to_namedtuple(tuple(dic.items()))._asdict()
    

# Generated at 2022-06-11 22:15:58.642075
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.validators import validate_namedtuple
    d = {'a': 1, 'b': 2}
    assert isinstance(d, dict)
    assert validate_namedtuple(d) is None
    out = to_namedtuple(d)
    assert isinstance(out, namedtuple('NamedTuple', 'a b'))
    assert out.a == d['a']
    assert out.b == d['b']

    from collections import OrderedDict
    d = OrderedDict([('a', 1), ('b', 2)])
    assert isinstance(d, OrderedDict)
    assert validate_namedtuple(d) is None
    out = to_namedtuple(d)
    assert isinstance(out, namedtuple('NamedTuple', 'a b'))

# Generated at 2022-06-11 22:16:10.389624
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyPackageRequirements
    import pytest
    dic = {'a': 1, 'b': 2}
    exp = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(dic) == exp
    MyClass = namedtuple('NamedTuple', ['a', 'b'])
    dic = {'a': 1, 'b': 2, 'c': 3}
    exp = MyClass(a=1, b=2)
    assert to_namedtuple(dic) == exp
    dic = {'a': 1, 'b': 2, '_c': 3}
    exp = MyClass(a=1, b=2)
    assert to_namedtuple(dic) == exp
    exp = namedt

# Generated at 2022-06-11 22:16:17.011617
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from collections import defaultdict
    import pprint

    class UnitTest(unittest.TestCase):

        def test_to_namedtuple(self):
            """
            """
            # Setup
            dic = {'a': 1, 'b': 2}
            returned = to_namedtuple(dic)
            expected = namedtuple('NamedTuple', 'a b')(*(1, 2))
            self.assertEqual(returned, expected)
            # Teardown

        def test_to_namedtuple_list(self):
            """
            """
            # Setup
            dic = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
            returned = to_namedtuple(dic)

# Generated at 2022-06-11 22:16:26.641357
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    from collections import OrderedDict, namedtuple
    from pprint import pprint
    from types import SimpleNamespace

    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', 'a b')(1, 2)

# Generated at 2022-06-11 22:16:40.565662
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple({}), namedtuple)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', ('b', 'a'))(b=2, a=1)
    assert to_namedtuple({'_a': 1, 'b': 2}) == namedtuple('NamedTuple', ('b',))(b=2)
    assert to_namedtuple({'a': 1, '_b': 2}) == namedtuple('NamedTuple', ('a',))(a=1)

# Generated at 2022-06-11 22:16:52.869826
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase


    class TestToNamedTuple(TestCase):

        # noinspection PyPep8Naming
        @staticmethod
        def _test_to_namedtuple(obj: Any) -> None:
            out = to_namedtuple(obj)
            assert bool(out)
            assert isinstance(out, (list, tuple, NamedTuple))

        def test_to_namedtuple_dict(self):
            data = {'a': 1, 'b': 2}
            self._test_to_namedtuple(data)

        def test_to_namedtuple_list(self):
            data = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
            self._test_to_namedtuple(data)


# Generated at 2022-06-11 22:17:01.908593
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        ChainMap,
        OrderedDict,
    )
    from itertools import chain
    from collections.abc import Iterable

    class _EmptyClass:
        pass

    def make_test_dict(max_depth: int = 5, count: int = 5) -> Mapping:
        multiple_nested = (
            OrderedDict,
            OrderedDict,
            OrderedDict,
            OrderedDict,
            OrderedDict,
            OrderedDict,
            OrderedDict,
            OrderedDict,
            OrderedDict,
            OrderedDict,
            OrderedDict,
            OrderedDict,
            OrderedDict,
            OrderedDict,
            OrderedDict,
        )

# Generated at 2022-06-11 22:17:07.005366
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'b a')(2, 1)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'b a')(2, 1)
    dic2 = {}
    assert to_namedtuple(dic2) == namedtuple('NamedTuple', '')()
    dic2['a'] = to_namedtuple(dic)

# Generated at 2022-06-11 22:17:17.762836
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from sys import version_info
    # noinspection PyCompatibility
    from typing import NamedTuple
    import pytest

    class MyNT(NamedTuple):
        a: int
        b: int

    class FooBar(NamedTuple):
        foo: int
        bar: int
        _: int

    def test_allowable(
        obj: _AllowedTypes
    ) -> Union[List, Tuple, NamedTuple, SimpleNamespace]:
        return to_namedtuple(obj)

    def test_disallowable(
        obj: Any
    ) -> Any:
        with pytest.raises(TypeError):  # type: ignore[no-any-return]
            return to_namedtuple(obj)

    test_allowable([1, 2, 3])

# Generated at 2022-06-11 22:17:26.340982
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple

    class TestClass(NamedTuple):
        a: Any
        b: Any
        _c: Any

    class TestClass2(NamedTuple):
        a: Any
        b: Any
        c: Any

    class TestClass3(NamedTuple):
        a: Any
        b: Any
        c: Any
        d: Any

    class TestClass4(NamedTuple):
        a: Any
        b: Any
        c: Any
        d: Any
        e: Any

    # Basic test
    test_dict = {'a': 1, 'b': 2}
    out = to_namedtuple(test_dict)
    assert out.a == test_dict['a']

# Generated at 2022-06-11 22:17:35.677989
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_dict = {"a": 1, "b": 2}
    test_list = [{"a": 1, "b": 2}, {"c": 3, "d": 4}]
    test_tuple = ({"a": 1, "b": 2}, {"c": 3, "d": 4})
    namedtuple_dict = to_namedtuple(test_dict)
    namedtuple_list = to_namedtuple(test_list)
    namedtuple_tuple = to_namedtuple(test_tuple)
    return namedtuple_dict, namedtuple_list, namedtuple_tuple

if __name__ == "__main__":
    test_to_namedtuple()

# Generated at 2022-06-11 22:17:46.711070
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple((1,)) == (1,)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == SimpleNamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict(zip(('a', 'b'), (1, 2)))) == SimpleNamedTuple(a=1, b=2)

# Generated at 2022-06-11 22:17:58.768849
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class ToNamedTupleTests(unittest.TestCase):
        def _test_object(
                self,
                obj: Any,
                cls: type = NamedTuple,
                do_recurse: bool = True
        ) -> None:
            if do_recurse:
                obj = to_namedtuple(obj)
            else:
                obj = _to_namedtuple(obj)
            self.assertTrue(isinstance(obj, cls),
                            '%s is not %s' % (obj, cls))

        def test_empty_dictionary(self):
            self._test_object({}, NamedTuple)


# Generated at 2022-06-11 22:18:07.952924
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple((1,2,3)) == (1,2,3)
    assert to_namedtuple([1,2,3]) == [1,2,3]
    assert to_namedtuple({'a':1,'b':2}) == NamedTuple(a=1,b=2)
    assert to_namedtuple(OrderedDict({'a':1,'b':2})) == NamedTuple(a=1,b=2)
    assert to_namedtuple(types.SimpleNamespace(a=1,b=2)) == NamedTuple(a=1,b=2)
    assert to_namedtuple({'a':1,'_b':2}) == NamedTuple(a=1)

# Generated at 2022-06-11 22:18:27.824361
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple)
    assert out.a == obj['a']
    obj = OrderedDict([('a', 1), ('b', 2)])
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple)
    assert out.a == obj['a']
    obj = [{'a': 1, 'b': 2}, OrderedDict([('a', 1), ('b', 2)])]
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert out[0].a == obj[0]['a']
    assert out[1].b == obj[1]['b']

# Generated at 2022-06-11 22:18:36.690254
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    ans = to_namedtuple(dic)
    assert isinstance(ans, NamedTuple)
    assert not isinstance(ans, OrderedDict)
    assert ans.a == 1 and ans.b == 2

    odic = OrderedDict(a=1, b=2)
    ans = to_namedtuple(odic)
    assert isinstance(ans, NamedTuple)
    assert ans.a == 1 and ans.b == 2

    namedtuple_tuple = tuple(ans)
    assert isinstance(namedtuple_tuple, tuple)
    assert namedtuple_tuple[0] == 1 and namedtuple_tuple[1] == 2

    simple_

# Generated at 2022-06-11 22:18:45.919793
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    import pytest
    from flutils.namedtupleutils import to_namedtuple, _to_namedtuple

    dict_obj = dict(a=1, b=2)
    result = to_namedtuple(dict_obj)
    assert isinstance(result, NamedTuple)
    assert result.a == 1
    assert result.b == 2

    list_obj = [1, 2, 3]
    result = to_namedtuple(list_obj)
    assert not isinstance(result, NamedTuple)
    assert not isinstance(result, list)
    assert isinstance(result, tuple)
    assert result == (1, 2, 3)

    list_obj = [dict_obj, dict_obj]
    result = to_namedtuple(list_obj)


# Generated at 2022-06-11 22:18:49.934381
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    ret = to_namedtuple(dic)
    assert ret.a == 1
    assert ret.b == 2
    assert hasattr(ret, 'a')
    assert hasattr(ret, 'b')

# Generated at 2022-06-11 22:19:02.388228
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple.

    The test is a simple run through the function.
    """

    import unittest
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import (
        List,
        NamedTuple,
        Tuple,
    )

    from flutils.namedtupleutils import to_namedtuple

    class Tests(unittest.TestCase):
        """Using unittest standard to verify flutils.namedtupleutils."""

        def setUp(self):
            """Create test map for to_namedtuple."""
            self.map = OrderedDict()
            self.map['a'] = 1
            self.map['b'] = 2
            self.map['c'] = OrderedDict()

# Generated at 2022-06-11 22:19:03.270127
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:19:09.953187
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': {'b': 1, 'c': 2},
        'd': 3,
        'e': {'f': {'g': 'h'}},
        'i': [1, 2, [3, 4], 5]
    }
    out = to_namedtuple(dic)
    assert out.a.b == 1
    assert out.a.c == 2
    assert out.d == 3
    assert out.e.f.g == 'h'
    assert out.i[0] == 1
    assert out.i[1] == 2
    assert out.i[2][0] == 3
    assert out.i[2][1] == 4
    assert out.i[3] == 5


if __name__ == "__main__":
    test_to_named

# Generated at 2022-06-11 22:19:21.921851
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2
    }

    dic1 = {
        'a': 1,
        'b': 2,
        'd': 4,
        'c': [2, 3, 4]
    }

    lis = ['a', 'b', 'c']
    lis1 = ['a', 'b', 'c', 'd', 'r', {'a': 1}]

    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    assert to_namedtuple(dic1) == namedtuple('NamedTuple', 'a b c d')(a=1, b=2, c=[2, 3, 4], d=4)

    assert to_namedtuple

# Generated at 2022-06-11 22:19:30.013146
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    # There is a unit test.
    assert hasattr(to_namedtuple, 'registry')
    # Should raise TypeError for unsupported types.
    with pytest.raises(TypeError):
        to_namedtuple(5)

    # Should be able to convert to a NamedTuple from a list.
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    # Should be able to convert to a NamedTuple from a tuple.
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    # Should be able to convert to a NamedTuple from a dict.
    assert to_namedtuple((1, 2)) == (1, 2)

# Generated at 2022-06-11 22:19:38.579899
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # Test empty OrderedDict
    expected = OrderedDict()
    assert to_namedtuple(expected) == expected

    # Test OrderedDict with one item
    expected = OrderedDict([('a', 1)])
    result = to_namedtuple(expected)
    assert result.a == 1

    # Test OrderedDict with several items
    expected = OrderedDict([('a', 1), ('b', 2)])
    result = to_namedtuple(expected)
    assert result.a == 1
    assert result.b == 2

    # Test ordered dict, normal dict, and SimpleNamespace with same items

# Generated at 2022-06-11 22:20:04.022084
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # sort_keys=False
    obj = {'c': 1, 'b': 2, 'a': {'d': 4, 'e': 5}}
    assert to_namedtuple(obj) == NamedTuple(c=1, b=2, a=NamedTuple(d=4, e=5))

    obj = {'c': ['f', {'g': 7, 'h': 8}, 'i'], 'b': 2, 'a': {'d': 4, 'e': 5}}
    assert to_namedtuple(obj) == NamedTuple(
        c=NamedTuple(('f', NamedTuple(g=7, h=8), 'i')),
        b=2,
        a=NamedTuple(d=4, e=5)
    )


# Generated at 2022-06-11 22:20:16.292145
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    from collections import defaultdict
    from datetime import datetime, timezone, timedelta
    import time

    dt = datetime.now(tz=timezone.utc)
    t = dt.timestamp()
    dt = datetime.fromtimestamp(t, tz=timezone.utc)


# Generated at 2022-06-11 22:20:28.125967
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    def test_good_recursive(obj, expected):
        out = to_namedtuple(obj)
        assert out == expected

    def test_bad_recursive(obj):
        with pytest.raises(TypeError):
            to_namedtuple(obj)

    def test_bad_identifier(obj):
        with pytest.raises(SyntaxError):
            to_namedtuple(obj)

    # Good tests
    # ========
    d = {'a': 'a1', 'b': 'b1', 'c': 'c1'}
    obj = [d]
    expected = [namedtuple('NamedTuple', ('a', 'b', 'c'))('a1', 'b1', 'c1')]
    test_good_recursive(obj, expected)

# Generated at 2022-06-11 22:20:38.787816
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Arrange
    inputs = [
        {'a': 1, 'b': 2},
        [{'a': 1, 'b': 2}],
        [0, {'a': 1, 'b': 2}],
        [{'a': 1, 'b': 2}, 0],
        OrderedDict([('a', 1), ('b', 2)]),
        OrderedDict(),
        SimpleNamespace(a=1, b=2),
        SimpleNamespace()
    ]


# Generated at 2022-06-11 22:20:49.128212
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = OrderedDict(
        (
            ('a', 1),
            ('c', 3),
            ('b', 2),
        )
    )
    named = to_namedtuple(dic)
    assert ['a', 'c', 'b'] == list(named._fields)
    assert named.a == 1
    assert named.b == 2
    assert named.c == 3

    dic = dict(
        (
            ('a', 1),
            ('c', 3),
            ('b', 2),
        )
    )
    named = to_namedtuple(dic)
    assert ['a', 'b', 'c'] == list(named._fields)
    assert named.a == 1
    assert named.b == 2
    assert named.c == 3



# Generated at 2022-06-11 22:21:00.198614
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.validators import validate_identifier
    from pytest import raises
    from typing import Any
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from functools import singledispatch
    from types import SimpleNamespace

    ntuple = namedtuple('ntuple', ('a', 'b'))
    ntuple_ntuple = namedtuple('ntuple_ntuple', ('a', 'b'))

    obj1 = {'a': 1, 'b': 2}
    obj2 = ntuple._make(('a', 'b'))
    obj3 = ntuple_ntuple(*ntuple(1, ntuple(2, 3)))
    obj4 = OrderedDict()
    obj4['3'] = '3'

# Generated at 2022-06-11 22:21:03.866598
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Test to_namedtuple function """
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == obj



# Generated at 2022-06-11 22:21:14.205535
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': {'b': 2}, 'c': 4}) == NamedTuple(a=NamedTuple(b=2), c=4)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]



# Generated at 2022-06-11 22:21:23.475129
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:21:30.927376
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import ValidatorError
    from types import SimpleNamespace

    dic1: OrderedDict[str, int] = OrderedDict()
    dic1['a'] = 1
    dic1['b'] = 2
    dic1['c'] = 3
    named1 = to_namedtuple(dic1)
    assert isinstance(named1, tuple)
    assert len(named1) == 3
    assert named1[0] == 1
    assert named1[1] == 2
    assert named1[2] == 3
    assert named1.a == 1
    assert named1.b == 2
    assert named1.c == 3


# Generated at 2022-06-11 22:22:19.032807
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Unit tests for function to_namedtuple
    import unittest

    class TestToNamedtuple(unittest.TestCase):
        def test_tuple(self):
            self.assertEqual(
                to_namedtuple((1, 2)), namedtuple('NamedTuple', 'item0 item1')(item0=1, item1=2)
            )

        def test_list(self):
            self.assertEqual(
                to_namedtuple([1, 2]), [1, 2]
            )


# Generated at 2022-06-11 22:22:26.306940
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for function to_namedtuple """
    dic = {'a': 1, 'b': 2}
    res = to_namedtuple(dic)
    assert res.a == 1
    assert res.b == 2


if __name__ == '__main__':
    print(__doc__)
    print('-' * 80)
    print(to_namedtuple.__doc__)
    print('-' * 80)
    input('Press enter to continue...')
    print('-' * 80)
    dic = {'a': 1, 'b': 2}
    print(dic)
    res = to_namedtuple(dic)
    print(res)
    input('Press enter to continue...')
    print('-' * 80)
    print(res.__doc__)

# Generated at 2022-06-11 22:22:36.567506
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from copy import deepcopy
    from collections import namedtuple
    from collections import OrderedDict
    from typing import Tuple
    from flutils.namedtupleutils import to_namedtuple
    TestData = namedtuple('TestData', 'string nested_list')
    TestData2 = namedtuple('TestData2', 'string nested_list')
    TestData3 = namedtuple('TestData3', 'string nested_list')
    TestData4 = namedtuple('TestData4', 'string nested_list')
    TestData5 = namedtuple('TestData5', 'string nested_list')
    TestData6 = namedtuple('TestData6', 'string nested_list')
    TestData7 = namedtuple('TestData7', 'string nested_list')

# Generated at 2022-06-11 22:22:48.753263
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple([1, 2, 3]) == list([1, 2, 3])
    assert to_namedtuple((1, 2, 3)) == tuple([1, 2, 3])
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

    foo = {
        'a': 1,
        'b': 2,
        'c': [1, 2, 3],
        'd': {
            'a': [1, 2, 3],
            'b': [4, 5, 6],
        },
    }

# Generated at 2022-06-11 22:22:52.779763
# Unit test for function to_namedtuple
def test_to_namedtuple():
    if __name__ == '__main__':  # pragma: no branch
        from flutils.tests import utils
        utils.run_doctest(__file__)
        utils.run_doctest('flutils.namedtupleutils.rst')
    assert True

# Generated at 2022-06-11 22:22:58.833355
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'a': 1, 'b': 2}
    t = to_namedtuple(d)
    assert isinstance(t, NamedTuple)
    assert hasattr(t, 'a')
    assert t.a == 1
    assert hasattr(t, 'b')
    assert t.b == 2

    d = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
        ('d', 4),
        ('e', 5),
    ])
    t = to_namedtuple(d)
    assert isinstance(t, NamedTuple)
    assert hasattr(t, 'a')
    assert t.a == 1
    assert hasattr(t, 'b')
    assert t.b == 2
    assert hasattr(t, 'c')

# Generated at 2022-06-11 22:23:05.869164
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    dic2 = {'a1': {'a11': 1, 'a12': 2}, 'a2': 2}
    dic3 = {'a1': {'b1': {'c1': 1, 'c2': 2}, 'b2': 2}, 'a2': 2}
    dic4 = {'a1': {'b1': [1, 2, 3], 'b2': 2}, 'a2': 2}
    dic5 = {'a1': {'b1': (1, 2, 3), 'b2': 2}, 'a2': 2}

# Generated at 2022-06-11 22:23:15.942477
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from collections.abc import Mapping
    from types import SimpleNamespace
    from typing import Union
    from flutils.namedtupleutils import to_namedtuple
    from itertools import (
        tee,
    )
    from typing import (
        List,
        Tuple,
        TypeVar,
    )

    T = TypeVar('T')

    def pairwise(iterable: Iterable[T]) -> List[Tuple[T, T]]:
        # s -> (s0,s1), (s1,s2), (s2, s3), ...
        a, b = tee(iterable)
        next(b, None)
        return list(zip(a, b))

    # Test the to_namedtuple

# Generated at 2022-06-11 22:23:24.358676
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Dictionaries
    dic = {'a': 1, 'b': 2}
    dic = to_namedtuple(dic)
    expected = namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert dic == expected
    
    dic = {'a': 1, 'b': {'b1': 2, 'b2': 3}}
    dic = to_namedtuple(dic)
    expected = namedtuple('NamedTuple', ['a', 'b'])(1, namedtuple('NamedTuple', ['b1', 'b2'])(2, 3))
    assert dic == expected

    # Lists
    lis = [1, {'b': 2, 'c': 3}]
    lis = to_namedtuple(lis)
   

# Generated at 2022-06-11 22:23:25.146647
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # ToDo: add unit tests
    pass

# Generated at 2022-06-11 22:24:44.903375
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == to_namedtuple(dic) == to_namedtuple(dic) == to_namedtuple(dic) == to_namedtuple(dic) == to_namedtuple(dic)
    # Unit test for function to_namedtuple

# Generated at 2022-06-11 22:24:55.952489
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3, d=4)
    dic = {'a': 1, 'b': 2, 'c': 3, '_d': 4}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)