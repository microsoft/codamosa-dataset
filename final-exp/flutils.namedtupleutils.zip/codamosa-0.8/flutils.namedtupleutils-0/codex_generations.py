

# Generated at 2022-06-11 22:15:12.430418
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):
        def test_basic_list(self):
            dic = {'a': 1, 'b': 2}
            ListWithDic = to_namedtuple([dic])
            self.assertEqual(
                ListWithDic[0],
                to_namedtuple(dic)
            )

        def test_basic_with_nested(self):
            dic = {
                'a': 1,
                'b': {
                    'c': 2
                }
            }
            BasicWithNested = to_namedtuple(dic)
            self.assertEqual(
                BasicWithNested.b,
                to_namedtuple(dic['b'])
            )


# Generated at 2022-06-11 22:15:21.676943
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)

    dic = OrderedDict({'a': 1, 'b': 2})
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)

    ns = SimpleNamespace(**dic)
    out = to_namedtuple(ns)
    assert isinstance(out, NamedTuple)

    dic = {'a': 1, 'b': [{'c': 3}, {'d': 4}]}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)


# Generated at 2022-06-11 22:15:32.612784
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:15:38.817138
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)


if __name__ == '__main__':
    print(to_namedtuple({'a': 1, 'b': 2}))

# Generated at 2022-06-11 22:15:45.447077
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from textwrap import dedent
    from flutils.miscutils import import_helper

    recurssive_literal_types = import_helper(
        'recurssive_literal_types',
        package='flutils',
        submodule='typingutils'
    )
    RL_Type = recurssive_literal_types.RL_Type
    RL_Repr = recurssive_literal_types.RL_Repr

    assert to_namedtuple([]) == ()
    assert to_namedtuple(()) == ()
    assert to_namedtuple((1,)) == (1,)
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)

# Generated at 2022-06-11 22:15:57.225876
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]) == [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]
    assert to_namedtuple('hello').capitalize() == 'Hello'
    assert to_namedtuple({'a': 1, 'b': 2}).b == 2
    assert to_namedtuple(NamedTuple(a=1, b=2)) == NamedTuple(a=1, b=2)

# Generated at 2022-06-11 22:16:09.230010
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from flutils.namedtupleutils import to_namedtuple
    import collections

    assert to_namedtuple({}) == collections.namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1, 'b': 2}) == collections.namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == collections.namedtuple('NamedTuple', ('a', 'b', 'c', 'd', 'e'))(1, 2, 3, 4, 5)
    assert to_namedtuple([]) == []
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple

# Generated at 2022-06-11 22:16:16.430012
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    assert to_namedtuple([0, 1, 2]) == [0, 1, 2]
    assert to_namedtuple((0, 1, 2)) == (0, 1, 2)
    assert to_namedtuple({'a': 0, 'b': 1, 'c': 2}) == \
        namedtuple('NamedTuple', 'a b c')(a=0, b=1, c=2)
    assert to_namedtuple(OrderedDict([('a', 0), ('b', 1), ('c', 2)])) == \
        namedtuple('NamedTuple', 'a b c')(a=0, b=1, c=2)

# Generated at 2022-06-11 22:16:25.567636
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:16:33.072374
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class ToNamedTupleTests(unittest.TestCase):

        def test_mapping(self):
            from collections import OrderedDict
            from collections.abc import Mapping
            from collections import namedtuple

            obj = {'a': 1, 'b': 2}
            res = to_namedtuple(obj)
            self.assertIsInstance(res, namedtuple)
            self.assertIsInstance(res, Mapping)
            self.assertEqual(res.a, 1)
            self.assertEqual(res.b, 2)

            obj = OrderedDict({'a': 1, 'b': 2})
            res = to_namedtuple(obj)
            self.assertIsInstance(res, namedtuple)
            self.assertIsInstance(res, Mapping)

# Generated at 2022-06-11 22:16:38.535247
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == (1, 2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'c': 4}]) == ((1, 2), (3, 4))

# Generated at 2022-06-11 22:16:50.384312
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import sys

    object = None
    # Test with: None
    result = to_namedtuple(object)
    # Test with: None
    assert result == object

    # Test with: bool
    object = True
    result = to_namedtuple(object)
    # Test with: bool
    assert result == object

    # Test with: byte
    object = b'byte'
    result = to_namedtuple(object)
    # Test with: byte
    assert result == object

    # Test with: bytes
    object = bytes(10)
    result = to_namedtuple(object)
    # Test with: bytes
    assert result == object

    # Test with: bytearray
    object = bytearray(10)
    result = to

# Generated at 2022-06-11 22:17:00.400358
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import defaultdict
    from flutils.namedtupleutils import to_namedtuple
    from typing import Iterable
    # Old testing
    assert to_namedtuple(
        {'a': 0, 'b': 1, 'c': 2}
    ) == NamedTuple(a=0, b=1, c=2)
    assert to_namedtuple(
        [{'a': 0, 'b': 1, 'c': 2}]
    ) == [NamedTuple(a=0, b=1, c=2)]

# Generated at 2022-06-11 22:17:10.051925
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': {'c': 3, 'd': 4}}) == NamedTuple(a=1, b=NamedTuple(c=3, d=4))
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3, 1: 4}) == NamedTuple(a=1, b=2, _1=4)
    assert to_namedtuple([1, 2, {'a': 1, 'b': 2}]) == [1, 2, NamedTuple(a=1, b=2)]
    assert to_namedtuple

# Generated at 2022-06-11 22:17:20.131982
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(['a', 2]) == ['a', 2]
    assert to_namedtuple((1, 'a')) == (1, 'a')
    assert to_namedtuple([]) == []
    assert to_namedtuple(('a',)) == ('a',)
    assert to_namedtuple(NamedTuple(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple

# Generated at 2022-06-11 22:17:28.140776
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Tests making of an empty list
    lis = []
    nt_lis: list = to_namedtuple(lis)
    assert type(nt_lis) is list
    assert len(nt_lis) == 0
    assert nt_lis == []

    # Tests making of a list with a single item
    lis = [{'a': 1}]
    nt_lis: list = to_namedtuple(lis)
    assert type(nt_lis) is list
    assert len(nt_lis) == 1
    assert type(nt_lis[0]) is NamedTuple
    assert nt_lis == [NamedTuple(a=1)]

    # Tests making of a list with multiple items
    lis = [{'a': 1}, {'b': 2}]
    nt_lis: list = to

# Generated at 2022-06-11 22:17:37.528438
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    # Print test result
    print('{0}:\n{1}\n{2}\n'.format(
        str(to_namedtuple(dic)), '-' * len(str(to_namedtuple(dic))),
        '\n'.join('{0}: {1}'.format(attr, getattr(to_namedtuple(dic), attr)) for attr in dir(to_namedtuple(dic)) if not attr.startswith('_'))
    ))

    tup = ('b', 1, 2, 3)
    # Print test result

# Generated at 2022-06-11 22:17:48.076841
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2}
    res = to_namedtuple(dic)
    assert res.a == 1
    assert res.b == 2

    dic = OrderedDict(c=1, b=2, a=3)
    res = to_namedtuple(dic)
    assert res._fields == ('c', 'b', 'a')
    assert res.c == 1
    assert res.b == 2
    assert res.a == 3

    import types
    dic = types.SimpleNamespace(c=1, b=2, a=3)
    res = to_namedtuple(dic)
    assert res._fields == ('a', 'b', 'c')
    assert res.a == 3

# Generated at 2022-06-11 22:17:59.950833
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    def _to_nt(obj):
        return to_namedtuple(obj)

    assert _to_nt(1) == 1

    assert _to_nt('str') == 'str'

    assert _to_nt(['a', 'b', 'c']) == ['a', 'b', 'c']

    assert _to_nt(('a', 'b', 'c')) == ('a', 'b', 'c')

    nt_a = namedtuple('a', 'aa bb')
    obj = nt_a(aa='test', bb='test')
    assert _to_nt(obj) == obj

    obj = {'aa': 'test', 'bb': 'test'}
    res = _to_nt(obj)
    assert isinstance(res, namedtuple)

# Generated at 2022-06-11 22:18:06.894278
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    argument = {'a': 1, 'b': 2}
    expected = namedtuple('NamedTuple', 'a b')(1, 2)
    result = to_namedtuple(argument)
    assert result == expected
    argument = [1, 2]
    expected = [namedtuple('NamedTuple', '')(), namedtuple('NamedTuple', '')()]
    result = to_namedtuple(argument)
    assert result == expected
    with pytest.raises(TypeError):
        to_namedtuple('abc')

# Generated at 2022-06-11 22:18:18.752648
# Unit test for function to_namedtuple
def test_to_namedtuple():
 
    # Test a simple dictionary
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    # Test a tuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == (1, 2, 3)

    # Test a multi-layer dictionary
    dic2 = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    assert to_namedtuple(dic2) == NamedTuple(a=1, b=NamedTuple(c=2, d=3), e=4)

    # Test a simple list
    lis = [1, 2, 3]

# Generated at 2022-06-11 22:18:27.803972
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys

    major = sys.version_info[0]
    minor = sys.version_info[1]
    if major != 3 or minor != 7:
        return
    from math import inf

    from unittest import TestCase, main

    from flutils.namedtupleutils import (
        NamedTuple,
        to_ordered_dict,
        to_simple_namespace,
        to_namedtuple,
    )

    class TestNamedtuple(TestCase):
        def setUp(self):
            self.dic = {'a': 1, 'b': 2}

# Generated at 2022-06-11 22:18:36.666195
# Unit test for function to_namedtuple
def test_to_namedtuple():
    #   Arrange
    src_dic = {'a': 1, 'b': 2}
    src_keys = {'a', 'b'}
    src_list = [1, 2, 3]
    src_tuple = (1, 2, 3)
    src_namespace = SimpleNamespace(a=1, b=2)

    #   Act
    tgt_dic = to_namedtuple(src_dic.copy())
    tgt_list = to_namedtuple(src_list.copy())
    tgt_tuple = to_namedtuple(src_tuple)
    tgt_namespace = to_namedtuple(src_namespace)

    #   Assert
    assert isinstance(tgt_dic, NamedTuple)

# Generated at 2022-06-11 22:18:45.917846
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert repr(to_namedtuple({'a': 1, 'b': 2})) == "NamedTuple(a=1, b=2)"
    assert repr(to_namedtuple([{'a': 1, 'b': 2}, {'a': 2, 'b': 1}])) == \
           "NamedTuple(a=1, b=2)"
    assert repr(to_namedtuple({'a': {'b': 1}, 'b': 2})) == \
           "NamedTuple(a=NamedTuple(b=1), b=2)"
    assert repr(to_namedtuple([{'a': 1, 'b': 2}, {'a': 2, 'b': 1}])) == \
           "NamedTuple(a=1, b=2)"

# Generated at 2022-06-11 22:18:55.587053
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from operator import itemgetter

    # test list of mixed values

# Generated at 2022-06-11 22:19:06.114027
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(((0, 1), (1, 2))) == ((0, 1), (1, 2))
    with pytest.raises(TypeError):
        to_namedtuple(1)
    with pytest.raises(TypeError):
        to_namedtuple('a string')

# Generated at 2022-06-11 22:19:17.069350
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import pytest

    def test_to_namedtuple_dict():
        dic = {'a': 1, 'b': 2}
        val = to_namedtuple(dic)
        assert val.a == 1
        assert val.b == 2

    def test_to_namedtuple_list():
        val = to_namedtuple(['apple', 'banana'])
        assert val[0] == 'apple'
        assert val[1] == 'banana'

    def test_to_namedtuple_list_empty():
        val = to_namedtuple([])
        assert val == ()


# Generated at 2022-06-11 22:19:28.354970
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import numpy as np
    from pandas import Series

    dic_list = {
        'list': [
            {'a': 1, 'b': 2},
            {'c': 3, 'd': 4, 'e': 5},
            {'f': 6, 'g': 7, 'h': 8, 'i': 9},
            {'j': 10, 'k': 11, 'l': 12, 'm': 13, 'n': 14},
        ]
    }

    nt_list = to_namedtuple(dic_list)

# Generated at 2022-06-11 22:19:37.568012
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.collectionsutils import (
        normalize_dict_key,
        normalize_str_key,
    )
    from collections import (
        OrderedDict,
    )

    # Test normalize_dict_key
    assert normalize_dict_key('a') == 'a'
    assert normalize_dict_key('A') == 'a'
    assert normalize_dict_key('_a') == '_a'
    assert normalize_dict_key('_A') == '_a'
    assert normalize_dict_key('a_b') == 'a_b'
    assert normalize_dict_key('A_b') == 'a_b'

    # Test normalize_str_key
    assert normalize_str_

# Generated at 2022-06-11 22:19:47.361530
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Test Single-level Conversion
    obj: dict = {'a': 1, 'b': 2}
    nt = to_namedtuple(obj)
    assert nt.a == 1
    assert nt.b == 2

    obj: dict = {'a': 1, 'b': [2, 3]}
    nt = to_namedtuple(obj)
    assert nt.a == 1
    assert nt.b == (2, 3)

    obj: dict = {'a': [1, 2], 'b': [2, 3]}
    nt = to_namedtuple(obj)
    assert nt.a == (1, 2)
    assert nt.b == (2, 3)
    assert type(nt) == namedtuple('NamedTuple', ['a', 'b'])

    #

# Generated at 2022-06-11 22:20:00.173741
# Unit test for function to_namedtuple
def test_to_namedtuple():
    the_list = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    the_dct = {'a': 1, 'b': 2}
    exp_list = [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]
    exp_dct = NamedTuple(a=1, b=2)
    assert to_namedtuple(the_list) == exp_list
    assert to_namedtuple(the_dct) == exp_dct

# Generated at 2022-06-11 22:20:11.942226
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == (1, 2, 3)
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(NamedTuple(a=1, b=2, c=3)) == NamedTuple(a=1, b=2, c=3)

# Generated at 2022-06-11 22:20:20.469555
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    assert to_namedtuple(['c', 'a', 'b']) == ['c', 'a', 'b']
    assert to_namedtuple(('c', 'a', 'b')) == ('c', 'a', 'b')

    dic = {'a': 1, 'b': 2}
    dic_t = to_namedtuple(dic)
    assert dic_t.a == 1
    assert dic_t.b == 2

    dic_o = OrderedDict(a=1, b=2)
    dic_o_t = to_namedtuple(dic_o)
    assert dic_o_t.a == 1
    assert dic_o_t.b == 2


# Generated at 2022-06-11 22:20:29.925397
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test conversion of list
    x = [{'a': 1, 'b': 2}, {'c': 3}]
    y = to_namedtuple(x)
    assert isinstance(y, list)
    assert isinstance(y[0], NamedTuple)
    assert isinstance(y[1], NamedTuple)
    assert y[0].a == 1
    assert y[0].b == 2
    assert y[1].c == 3
    assert len(y) == 2

    # Test conversion of tuple
    x = ({'a': 1, 'b': 2}, {'c': 3})
    y = to_namedtuple(x)
    assert isinstance(y, tuple)
    assert isinstance(y[0], NamedTuple)
    assert isinstance(y[1], NamedTuple)

# Generated at 2022-06-11 22:20:40.256756
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(dict(a=1, b=2)) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(OrderedDict(a=1, b=2)) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dict(a=1, _b=2)) == namedtuple('NamedTuple', 'a')(a=1)

# Generated at 2022-06-11 22:20:50.015412
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    dic = {'a': 1, 'b': namedtuple('NamedTuple', 'c d')(c=3, d=4)}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(
        a=1,
        b=namedtuple('NamedTuple', 'c d')(c=3, d=4)
    )
    nt = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(nt) == nt

# Generated at 2022-06-11 22:21:00.678629
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ """
    import pytest
    from sys import modules

    from flutils.namedtupleutils import to_namedtuple

    globals().update(modules[__name__].__dict__)

    with pytest.raises(TypeError):
        to_namedtuple(3)

    def func1() -> None:
        """ """
        pass

    func2 = func1

    nt1 = namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    nt2 = to_namedtuple(nt1)
    assert nt1 == nt2
    assert nt1.a == nt2.a
    assert nt1.b == nt2.b


# Generated at 2022-06-11 22:21:12.313170
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple({}) == NamedTuple()
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(dic) != to_namedtuple({'a': 1, 'b': 3})
    assert to_namedtuple(dic) != to_namedtuple({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-11 22:21:20.080555
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.testutils import TestClass, TestNamedTuple
    import datetime
    import decimal
    import pathlib
    import uuid

# Generated at 2022-06-11 22:21:28.670114
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import defaultdict
    from datetime import date
    from decimal import Decimal
    from os.path import Path
    from pprint import pformat
    from typing import (
        Dict,
        Set,
    )
    from uuid import UUID

    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-11 22:21:44.739982
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:21:52.552101
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple)
    from collections import (
        OrderedDict)
    from types import (
        SimpleNamespace)

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert hasattr(out, '_fields')
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert out.a == 1
    assert out.b == 2

    dic = {'a': 1, '_b': 2}
    out = to_namedtuple(dic)
    assert hasattr(out, '_fields')
    assert hasattr(out, 'a')
    assert not hasattr(out, '_b')
    assert out.a == 1

   

# Generated at 2022-06-11 22:22:02.790533
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    dic = {'a': 1, 'b': 2}
    nt_dic = to_namedtuple(dic)
    assert isinstance(nt_dic, NamedTuple)
    assert nt_dic.a == 1
    assert nt_dic.b == 2
    assert nt_dic[0] == 1
    assert nt_dic[1] == 2
    assert nt_dic._asdict()['a'] == 1
    assert nt_dic._asdict()['b'] == 2
    assert list(nt_dic) == [1, 2]
    assert isinstance(nt_dic._fields, tuple)
    assert nt_dic._fields[0] == 'a'

# Generated at 2022-06-11 22:22:12.585830
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test dictionary
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)
    obj = {'b': 2, 'a': 1}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)
    obj = OrderedDict([('b', 2), ('a', 1)])
    assert to_namedtuple(obj) == NamedTuple(b=2, a=1)
    obj = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)
    obj = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-11 22:22:23.391025
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-11 22:22:32.614334
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple([]) == []

    assert to_namedtuple({}) == NamedTuple()

    with pytest.raises(TypeError) as err:
        to_namedtuple('a')
    assert err.value.args[0].startswith(
        "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
        "got: (str) 'a'",
    )

    data = []
    assert to_namedtuple(data) == []

    data = ()
    assert to_namedtuple(data) == ()

    data = [1, 2, 3]
    assert to_namedtuple(data) == [1, 2, 3]

    data = (1, 2, 3)
   

# Generated at 2022-06-11 22:22:34.831043
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    from flutils.testingutils import run_doctest

    results = run_doctest(to_namedtuple, ['--verbose'])
    assert results.failures == 0

# Generated at 2022-06-11 22:22:42.186335
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # pylint: disable=C0116
    from flutils.namedtupleutils import to_namedtuple
    from flutils.testhelpers import random_string
    from flutils.textutils import random_text
    # nums = [random.randint(1, 100) for _ in range(10)]
    dic = {}
    for _ in range(3):
        dic[random_string(min_len=1)] = random_text()
    # ls = random.sample(nums, random.randint(0, len(nums)))
    ls = []
    for _ in range(3):
        ls.append(random_string(min_len=1))
    assert to_namedtuple(dic) == to_namedtuple(dic)
    assert to_namedtuple(ls) == to

# Generated at 2022-06-11 22:22:52.944146
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    res = to_namedtuple(dic)
    assert res
    assert isinstance(res, namedtuple('NamedTuple', res._fields))
    assert res.a == 1 and res.b == 2

    lis = [dic, dic, dic]
    res = to_namedtuple(lis)
    assert res
    assert isinstance(res, list)
    for ind, item in enumerate(res):
        assert isinstance(item, list)
        assert isinstance(item[0], namedtuple('NamedTuple', item[0]._fields))
        assert isinstance(item[1], namedtuple('NamedTuple', item[1]._fields))

# Generated at 2022-06-11 22:23:04.258859
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import date, datetime, time
    from decimal import Decimal
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple(
        'abc'
    ) == 'abc'
    assert to_namedtuple(
        []
    ) == ()
    assert to_namedtuple(
        ()
    ) == ()
    assert to_namedtuple(
        {}
    ) == NamedTuple()
    assert to_namedtuple(
        {'a': 1}
    ) == NamedTuple(a=1)
    assert to_namedtuple(
        {'a': 1, 'b': 'def'}
    ) == NamedTuple(a=1, b='def')

# Generated at 2022-06-11 22:23:35.873511
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Need to test on many different types
    dic = {'a': 1, 'b': 2}
    expected = 'NamedTuple(a=1, b=2)'
    assert str(to_namedtuple(dic)) == expected

    dic = {'a': 1, 'B': 2}
    expected = 'NamedTuple(a=1, B=2)'
    assert str(to_namedtuple(dic)) == expected

    dic = OrderedDict([('a', 1), ('b', 2)])
    expected = 'NamedTuple(a=1, b=2)'
    assert str(to_namedtuple(dic)) == expected

    dic = OrderedDict([('a', 1), ('B', 2)])

# Generated at 2022-06-11 22:23:45.621629
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Tests for function to_namedtuple.

    Test Name:
       test_to_namedtuple

    Purpose:
        Test the to_namedtuple function

    Description:
        Test the to_namedtuple function with the following:
            - with a list
            - with a tuple
            - with a dict
            - with an OrderedDict
            - with a SimpleNamespace
            - with non supported types
                - float
                - bool
                - int

    Tags:
        n/a

    Returns:
        None
    """
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    # Test converting list
    dic = {'a': 1, 'b': 2}

# Generated at 2022-06-11 22:23:46.786660
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:23:56.518121
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase, main
    from pprint import pprint

    class TestToNamedTuple(TestCase):

        def test_namedtuple(self):
            from collections import defaultdict, OrderedDict, namedtuple
            from flutils.namedtupleutils import to_namedtuple

            dic = {'a': 1, 'b': 2}
            tup = to_namedtuple(dic)

            self.assertIsInstance(tup, namedtuple)
            self.assertEqual(tup.a, 1)
            self.assertEqual(tup.b, 2)

            tup = to_namedtuple(dic.items())
            self.assertIsInstance(tup, namedtuple)
            self.assertEqual(tup.a, 1)

# Generated at 2022-06-11 22:24:06.040304
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert nt.a == 1
    assert nt.b == 2
    dic = {3: 1, 'a': 2}
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert not hasattr(nt, 3)
    assert nt.a == 2
    dic = {'a': 1, '_b': 2}
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert not hasattr(nt, '_b')
    assert nt.a == 1

# Generated at 2022-06-11 22:24:17.731763
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from typing import Dict, List, Union

    NT = namedtuple('NT', 'a b c')

    def make_nt(
            a: Any = 1,
            b: Any = 1,
            c: Any = 1,
            test: bool = False
    ) -> Union[NT, Dict[str, Any]]:
        if test:
            out = {}
            out['a'] = a
            out['b'] = b
            out['c'] = c
            return out
        return NT(a, b, c)

    def make_od(
            a: Any = 1,
            b: Any = 1,
            c: Any = 1,
            test: bool = False
    ) -> Union[OrderedDict, NT]:
        if test:
            out = OrderedDict()


# Generated at 2022-06-11 22:24:26.225181
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import random
    import string

    def _random_string(length=8):
        letters = [
            c for c in string.ascii_letters + string.digits if c.isalnum()
        ]
        return ''.join(random.choice(letters) for _ in range(length))


# Generated at 2022-06-11 22:24:35.582266
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, '_b': 2}) == namedtuple('NamedTuple', 'a')(a=1)
    assert to_namedtuple({'a': {'a': 1, '_b': 2}, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=namedtuple('NamedTuple', 'a')(a=1), b=2)
    assert to_namedt

# Generated at 2022-06-11 22:24:46.462956
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple({'a': 1, 'b': 2, '1': 3, '_a': 4}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': {'d': 5, 'e': 6}}) ==\
        NamedTuple(a=1, b=2, c=NamedTuple(d=5, e=6))

# Generated at 2022-06-11 22:24:57.053828
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function with all possible inputs."""
    import copy
    import pytest
    dic = {
        'a': 1,
        'b': 2
    }
    dic2 = {
        'a': 1,
        'b': 'b',
    }
    dic3 = {
        '_a': 1,
        'b': 'b',
    }
    dic4 = {
        'Aa': 1,
        'Bb': 'b',
    }
    ordered_dic = OrderedDict()
    ordered_dic['c'] = 3
    ordered_dic['_d'] = 4
    ordered_dic['_e'] = 5
    ordered_dic['_f'] = 6

    tup = (7, 8)
    tup2 = (9, 10)