

# Generated at 2022-06-11 22:15:13.715795
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple,
    )

    from collections import (
        deque,
    )

    from flutils.validators import (
        _validate_identifier_syntax_,
    )

    _validate_identifier_syntax_(
        'abc',
        allow_underscore=True,
    )

    dic = {'_a': 1, 'b': 2, '3': 3}
    out1: NamedTuple = to_namedtuple(dic)
    out2 = {'b': 2}
    assert out1 == out2

    dic = {'a': 1, 'b': 2, 'c': 3}
    out1 = to_namedtuple(dic)

# Generated at 2022-06-11 22:15:17.340246
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ['a', 'b'])(
        a=1, b=2
    )

# Generated at 2022-06-11 22:15:22.468305
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Running {}'.format(os.path.basename(__file__)))

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    print(out)
    assert isinstance(out, NamedTuple)

    dic = {'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2}}
    out = to_namedtuple(dic)
    print(out)
    assert isinstance(out, NamedTuple)
    assert isinstance(out.c, NamedTuple)

    lst = [1, 2, {'a': 1, 'b': 2}, 3]
    out = to_namedtuple(lst)
    print(out)
    assert isinstance(out, list)

# Generated at 2022-06-11 22:15:33.201904
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Tests for function to_namedtuple """
    from unittest import TestCase, TestLoader, TestSuite, TextTestRunner
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # Define class to hold tests
    class ToNamedTupleTests(TestCase):
        """ Tests for function to_namedtuple """

        def test_list(self):
            """ Test to_namedtuple with a list. """
            expect = [1, 2, 3]
            nt_obj: List[int] = to_namedtuple(expect)
            self.assertListEqual(expect, nt_obj)


# Generated at 2022-06-11 22:15:44.930502
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _test(
            obj: _AllowedTypes,
            expected: Union[Tuple[Any, ...], List[Any], NamedTuple, str]
    ) -> None:
        out: Union[Tuple[Any, ...], List[Any], NamedTuple, str]
        out = to_namedtuple(obj)
        assert out == expected

    obj = [
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 2, 'c': None},
        {'d': 0, 'b': 2, 'c': None},
        {'d': 0, 'b': 2, 'c': None, 'e': False},
    ]

# Generated at 2022-06-11 22:15:56.671220
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic1 = dict(a=1, b=2)
    nt1 = to_namedtuple(dic1)
    assert nt1.a == 1
    assert nt1.b == 2

    dic2 = dict(a=1, _b=2)
    nt2 = to_namedtuple(dic2)
    assert nt2.a == 1
    assert not hasattr(nt2, '_b')

    dic3 = dict(_a=1, _b=2)
    nt3 = to_namedtuple(dic3)
    assert not hasattr(nt3, '_a')
    assert not hasattr(nt3, '_b')

    dic4 = dict(c=dict(a=1, b=2), e=5)

# Generated at 2022-06-11 22:16:08.617022
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tests = [
        {
            'given': {'test1': 1, 'test2': 'test'},
            'expected': NamedTuple(test1=1, test2='test'),
        },
        {
            'given': OrderedDict([('test1', 1), ('test2', 'test')]),
            'expected': NamedTuple(test1=1, test2='test'),
        },
        {
            'given': SimpleNamespace(test1=1, test2='test'),
            'expected': NamedTuple(test1=1, test2='test'),
        },
        {
            'given': ('test1', 1, 'test2', 'test'),
            'expected': ('test1', 1, 'test2', 'test'),
        },
    ]
    for test in tests:
        result = to

# Generated at 2022-06-11 22:16:10.728623
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:16:22.896957
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from .namedtupleutils import to_namedtuple


# Generated at 2022-06-11 22:16:29.682903
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    e = Exception()
    assert to_namedtuple(e) is e
    from flutils.namedtupleutils import _to_namedtuple
    _to_namedtuple(object())


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:16:40.852385
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}, {'e': 5, 'f': 6}]
    out = to_namedtuple(obj)
    assert out[0] == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert out[1] == namedtuple('NamedTuple', ['c', 'd'])(c=3, d=4)
    assert out[2] == namedtuple('NamedTuple', ['e', 'f'])(e=5, f=6)
    obj = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(obj)

# Generated at 2022-06-11 22:16:53.186093
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import unittest
    from numbers import Integral
    from collections import (
        Counter,
        defaultdict,
        OrderedDict,
    )
    from types import SimpleNamespace
    from typing import Any, Dict, List, Optional, Union
    from flutils.namedtupleutils import to_namedtuple

    class TestCase(unittest.TestCase):
        """Unit tests for to_namedtuple"""

# Generated at 2022-06-11 22:16:55.083091
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-11 22:16:57.232937
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    namedtupleutils.to_namedtuple(dic)
    return

# Generated at 2022-06-11 22:17:09.011101
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from typing import Any, NamedTuple
    # noinspection PyShadowingBuiltins,PyUnusedLocal
    def foo(tup: NamedTuple):
        pass
    tup = to_namedtuple({'a': 1, 'b': 2})
    foo(tup)
    foo(tup(a=3))

    d = {'a': 1, 'b': 2, '_c': 3, '__d': 4, '__e__': 5}
    tup = to_namedtuple(d)
    assert tup.a == 1
    assert tup.b == 2
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-11 22:17:18.527360
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for to_namedtuple.

    Args:
        None.

    Returns:
        None.

    Raises:
        AssertionError:  If any tests fail.

    """
    import flutils.namedtupleutils as ntu
    result = ntu.to_namedtuple({'a': 1, 'b': 2})
    assert result.a == 1
    assert result.b == 2
    result = ntu.to_namedtuple({'b': 2, 'a': 1})
    assert result.a == 1
    assert result.b == 2
    result = ntu.to_namedtuple([{'a': 1, 'b': 2}, {'b': 2, 'a': 1}])
    assert result[0].a == 1
    assert result[0].b == 2

# Generated at 2022-06-11 22:17:26.929412
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import collections.abc
    from collections import ChainMap
    from unittest import TestCase, main
    from numbers import Integral
    import types
    from sys import version_info
    from typing import (
        Any,
        Callable,
        Dict,
        List,
        Optional,
        Sequence,
        Set,
        Tuple,
        Union,
        cast,
    )
    import random


# Generated at 2022-06-11 22:17:37.087188
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class Test1(NamedTuple):
        a: int
        b: int

    class Test2(SimpleNamespace):
        a = 1
        b = 2

    class Test3(NamedTuple):
        a: int
        b: Test1
        c: Test2

    v = dict(a = 1, b = 2, c = 3)
    v = to_namedtuple(v)
    assert v.a == 1
    assert v.b == 2
    assert v.c == 3
    v = dict(a = 1, b = dict(a = 'a', b = 'b'), c = 3)
    v = to_namedtuple(v)
    assert v.a == 1
    assert v.b.a == 'a'
    assert v.b.b == 'b'

# Generated at 2022-06-11 22:17:39.681992
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()


#####
# EOF

# Generated at 2022-06-11 22:17:49.513747
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    named_tuple = to_namedtuple(dic)
    assert named_tuple.a == 1
    assert named_tuple.b == 2
    lis = [{'a': 1}, {'b': 2}, {'c': 3}]
    named_tuple = to_namedtuple(lis)
    assert named_tuple[0].a == 1
    assert named_tuple[1].b == 2
    assert named_tuple[2].c == 3
    nest_list = [{'a': 1}, [{'b': 2}, {'c': 3}]]
    named_tuple = to_namedtuple(nest_list)
    assert named_tuple[0].a == 1

# Generated at 2022-06-11 22:18:04.463265
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # simple test
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # OrderedDict
    from collections import OrderedDict
    dic = OrderedDict([('b', 2), ('a', 1)])
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'b a')(b=2, a=1)

    # SimpleNamespace
    from types import SimpleNamespace
    namespace = SimpleNamespace(a=1, b=2)
    assert to_namedtuple(namespace) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    # list with a M

# Generated at 2022-06-11 22:18:06.904448
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)

# Generated at 2022-06-11 22:18:17.205216
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace


# Generated at 2022-06-11 22:18:26.168592
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from flutils.namedtupleutils import to_namedtuple

    # Test empty, non-existant and non-convertable
    assert to_namedtuple(None) is None
    assert to_namedtuple('') == ''
    assert to_namedtuple(type) == type

    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple({}) == NamedTuple()

    # Test conversions of simple namedtuples and dictionaries
    assert to_namedtuple(NamedTuple()) == NamedTuple()
    assert to_namedtuple(NamedTuple(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedt

# Generated at 2022-06-11 22:18:35.867159
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from flutils.namedtupleutils import to_namedtuple
    class TestClass(unittest.TestCase):
        def test_a(self):
            self.assertEqual(to_namedtuple({}),
                             to_namedtuple({}))
        def test_b(self):
            self.assertEqual(to_namedtuple({'a':1, 'b':2}),
                             to_namedtuple({'b':2, 'a':1}))
        def test_c(self):
            self.assertEqual(to_namedtuple({'a':1, 'b':2}),
                             to_namedtuple({'a':1, 'b':2}))

# Generated at 2022-06-11 22:18:45.750466
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    od = OrderedDict(zip(('a', 'b'), [1, 2]))
    assert to_namedtuple(od) == NamedTuple(a=1, b=2)
    lst = [1, 2, OrderedDict(zip(('a', 'b', 'c'), [1, 2, 3])), 3, 4]
    exp_lst = [1, 2, NamedTuple(a=1, b=2, c=3), 3, 4]
    assert to_namedtuple(lst) == exp_lst
    tu = tuple(lst)
    exp_tu = tuple(exp_lst)

# Generated at 2022-06-11 22:18:55.505407
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2}
    ntuple = to_namedtuple(dic)
    assert isinstance(ntuple, namedtuple)
    assert len(ntuple) == 2
    assert ntuple.a == 1
    assert ntuple.b == 2

    order_dic = OrderedDict(a=1, b=2)
    ntuple = to_namedtuple(order_dic)
    assert isinstance(ntuple, namedtuple)
    assert len(ntuple) == 2
    assert ntuple.a == 1
    assert ntuple.b == 2


# Generated at 2022-06-11 22:18:57.939736
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:19:07.175091
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Any, Callable

    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from flutils.validators import validate_identifier

    # noinspection PyUnresolvedReferences,PyShadowingNames
    def _assert_is_namedtuple(obj):
        # noinspection PyUnresolvedReferences,PyShadowingNames
        def _assert_not_namedtuple(obj):
            assert not hasattr(obj, '_fields')

        assert hasattr(obj, '_fields')
        assert hasattr(obj, '_replace')
        assert isinstance(obj._fields, tuple)
        assert isinstance(obj._replace, Callable)

        for field in obj._fields:
            assert validate_identifier(field)

        for field in obj._fields:
            assert hasattr

# Generated at 2022-06-11 22:19:18.079392
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyProtectedMember
    data = {
        'a': 'b',
        'c': {
            'd': 'e',
            'f': {
                'g': 'h',
                '_a': 'b',
            }
        },
        '_x': 'y',
        'z': 1,
        '_z': 2,
    }
    out = to_namedtuple(data)
    assert isinstance(out, NamedTuple)  # type: ignore
    assert hasattr(out, 'a')
    assert hasattr(out, 'c')
    assert hasattr(out, 'z')
    assert not hasattr(out, '_x')
    assert not hasattr(out, '_z')
    assert out.a == 'b'

# Generated at 2022-06-11 22:19:34.308636
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    from pprint import pprint
    from flutils.namedtupleutils import to_namedtuple

# Generated at 2022-06-11 22:19:44.138645
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple({}) == namedtuple('', '')()

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)

    dic = {'c': 3, 'b': 2, 'a': 1}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b', 'c'))(1, 2, 3)

    dic = {}
    with pytest.raises(TypeError):
        to_namedtuple(dic)

    dic = {'c': 3, 'b': 2, 'a': 1}

# Generated at 2022-06-11 22:19:54.734283
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(
        {'a': 1, 'b': 2}
    ) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple(
        OrderedDict([('a', 1), ('b', 2)])
    ) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple(
        [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    ) == [namedtuple('NamedTuple', ('a', 'b'))(1, 2), namedtuple('NamedTuple', ('a', 'b'))(3, 4)]

# Generated at 2022-06-11 22:20:03.290430
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    # from flask import json
    from collections import OrderedDict
    from typing import Any

    # The object to be converted is a list of integers
    int_list = [1, 2, 3]
    exp_int_list = [1, 2, 3]
    act_int_list = to_namedtuple(int_list)
    assert exp_int_list == act_int_list

    # The object to be converted is a dictionary
    int_dict = {'a': 1, 'b': 2, 'c': 3}
    exp_int_dict = NamedTuple(a=1, b=2, c=3)
    act_int_dict = to_namedtuple(int_dict)
    assert exp_int_dict == act_int_dict

    # The object to be converted

# Generated at 2022-06-11 22:20:04.334762
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:20:16.519883
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing function to_namedtuple')
    obj = {"foo": 1, "bar": [1, 2, 3]}
    expected = namedtuple('NamedTuple', ('bar', 'foo'))(
        bar=[1, 2, 3],
        foo=1,
    )
    actual = to_namedtuple(obj)
    assert actual == expected
    obj = {'foo': 1, 'bar': {'baz': 2}}
    expected = namedtuple('NamedTuple', ('bar', 'foo'))(
        bar=namedtuple('NamedTuple', ('baz',))(baz=2),
        foo=1,
    )
    actual = to_namedtuple(obj)
    assert actual == expected

# Generated at 2022-06-11 22:20:28.226274
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    # Test the default namedtuple
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    # noinspection PyTypeChecker,PyArgumentList
    assert to_namedtuple(namedtuple('a', 'b')(1)) == namedtuple('a', 'b')(1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'': 1}) == namedtuple('NamedTuple', '')()

# Generated at 2022-06-11 22:20:38.885655
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, '_b': 2}) == NamedTuple(a=1)
    assert to_namedtuple({'a': 1, 'b_': 2}) == NamedTuple(a=1, b_=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        NamedTuple(a=1, b=2)
    ns = SimpleNames

# Generated at 2022-06-11 22:20:41.566480
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(
        extraglobs=dict(
            namedtuple=namedtuple,
            to_namedtuple=to_namedtuple,
        )
    )


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:20:43.665297
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:21:02.346543
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import copy
    from flutils.tests.utils import (
        AssertEmptySequence,
        AssertFullSequence,
    )
    from flutils.validators import (
        is_dict_like,
        is_list_like,
        is_namedtuple,
        is_namespace,
        is_sequence,
    )
    from tests.testcase import (
        ExtendedTestCase,
    )
    from flutils.namedtupleutils import (
        to_namedtuple,
    )


# Generated at 2022-06-11 22:21:08.966352
# Unit test for function to_namedtuple
def test_to_namedtuple():
    run = False
    if run:
        from pprint import pprint
        dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
        pprint(dic)
        print()
        out = to_namedtuple(dic)
        print(out)
        print(out.b)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:21:17.922191
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2

    obj = {
        'a': 1,
        '_b': 2,
        'c': {
            'd': 3,
            'e': {'f': 4},
            'g': [5, 6, 7],
            'h': {
                'i': 8,
                '_j': 9,
                'k': [10, 11, 12],
            },
            'l': [13, {'m': 14, 'n': 15}],
        },
    }
    nt = to_namedtuple(obj)

# Generated at 2022-06-11 22:21:23.786776
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import nose
    import flutils.namedtupleutils as _mod
    obj = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    expected = [_mod.NamedTuple(a=1, b=2), _mod.NamedTuple(c=3, d=4)]
    actual = _mod.to_namedtuple(obj)
    nose.tools.assert_equal(actual, expected)
    obj = (1, 2, 3, 'four', {'f': 5, 'g': 6}, {'h': 7, 'i': 8})
    expected = (1, 2, 3, 'four', _mod.NamedTuple(f=5, g=6), _mod.NamedTuple(h=7, i=8))

# Generated at 2022-06-11 22:21:31.096060
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': {'c': 3}}) == NamedTuple(a=1, b=NamedTuple(c=3))
    assert to_namedtuple(OrderedDict([('b', 1), ('a', 2)])) == NamedTuple(b=1, a=2)

# Generated at 2022-06-11 22:21:39.986740
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    tpl = (1, 2)
    out = to_namedtuple(tpl)
    assert out[0] == 1
    assert out[1] == 2

    lst = [1, 2]
    out = to_namedtuple(lst)
    assert out[0] == 1
    assert out[1] == 2

    dic = {'a': 1, 'b': '#val#'}
    out = to_namedtuple(dic)

# Generated at 2022-06-11 22:21:50.943988
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        ChainMap,
        OrderedDict,
    )
    from types import (
        SimpleNamespace,
    )
    from inspect import signature

    assert signature(to_namedtuple).parameters['obj'].annotation == _AllowedTypes

    # noinspection PyUnusedLocal
    def _asserts_to_namedtuple(obj) -> None:
        assert hasattr(obj, '_fields')
        assert hasattr(obj, '_asdict')
        assert hasattr(obj, '_replace')
        assert hasattr(obj, '__dict__')
        assert hasattr(obj, '__getnewargs__')
        assert hasattr(obj, '__new__')
        assert hasattr(obj, '__repr__')
        assert hasattr(obj, '_source')
       

# Generated at 2022-06-11 22:21:53.692524
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == obj


test_to_namedtuple()

# Generated at 2022-06-11 22:22:03.164219
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    _obj = {'a': 0, 'b': 2}
    _obj_out = to_namedtuple(_obj)

    assert _obj_out == SimpleNamespace(a=0, b=2)

    _obj = [{'a': 0, 'b': 2}, {'c': 3, 'd': 4}]
    _obj_out = to_namedtuple(_obj)

    assert _obj_out == [SimpleNamespace(a=0, b=2), SimpleNamespace(c=3, d=4)]

    _obj = {'a': [{'c': 3, 'd': 4}, {'e': 5, 'f': 6}]}
    _obj_out = to_namedtuple(_obj)


# Generated at 2022-06-11 22:22:06.233450
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    test_data = [
        # test_data format:
        #   ('test-name', call_args, expected_result),
        ('no args given', [], True),
    ]

    @pytest.mark.parametrize('name,args,result', test_data)
    def test_function(name, args, result):
        """Validate :func:`to_namedtuple` function."""
        assert to_namedtuple(name, *args) == result

# Generated at 2022-06-11 22:22:38.759638
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from types import SimpleNamespace as SN
    from collections import OrderedDict
    assert to_namedtuple(OrderedDict([('c', 1), ('a', 2)])) ==\
        to_namedtuple(SN(c=1, a=2)) == to_namedtuple(dict(c=1, a=2))
    assert (to_namedtuple(OrderedDict([('c', 1), ('a', 2)])) !=
            to_namedtuple(dict(a=2, c=1)))
    assert to_namedtuple(dict(c=1, a=2)) == to_namedtuple(dict(a=2, c=1))
    assert to_namedtuple([dict(a=1), dict(a=2)]) == [dict(a=1), dict(a=2)]
   

# Generated at 2022-06-11 22:22:49.708719
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from flutils.validators import validate_identifier

    expected = namedtuple('NamedTuple', 'a b c')
    # noinspection PyTypeChecker,PyArgumentList
    expected = expected(a=1, b=2, c='three')

    dic = {'a': 1, 'b': 2, 'c': 'three'}
    res = to_namedtuple(dic)
    assert res == expected

    dic = {'a': 1, 'b':  2, '_c': 'three'}
    res = to_namedtuple(dic)
    assert res == expected._replace(c=None)


# Generated at 2022-06-11 22:22:57.507660
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    class OrderedDict3(OrderedDict):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.__dict__ = self

    dic = OrderedDict([(1, 'a'), (2, 'b')])
    dic_od = OrderedDict3([(1, 'a'), (2, 'b')])
    dic_od3 = OrderedDict3()
    dic_od3._fl_name = 'Flask'
    dic_od3._fl_version = 1.0
    d

# Generated at 2022-06-11 22:23:05.402433
# Unit test for function to_namedtuple
def test_to_namedtuple():  # pragma: no cover
    from flutils.namedtupleutils import to_namedtuple
    from flutils.collectionsutils import map_dict

    def show_output(input):
        output = to_namedtuple(input)
        print(
            "input\n",
            input,
            "\n\noutput\n",
            output,
            "\n\n",
            sep=""
        )


# Generated at 2022-06-11 22:23:15.746108
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from types import SimpleNamespace

    assert repr(to_namedtuple([])) == 'NamedTuple()'

    assert repr(to_namedtuple(1)) == '1'
    assert repr(to_namedtuple('abc')) == "'abc'"
    assert repr(to_namedtuple((1, 'abc'))) == "('abc', 1)"
    assert repr(to_namedtuple({'a': 1, 'b': 'abc'})) == "NamedTuple(a=1, b='abc')"

    assert repr(to_namedtuple([1, 'abc'])) == "[1, 'abc']"

# Generated at 2022-06-11 22:23:24.291282
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert nt.a == 1
    assert nt.b == 2
    ordered = OrderedDict(a=1, b=2, c=3)
    nt = to_namedtuple(ordered)
    assert isinstance(nt, NamedTuple)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert hasattr(nt, 'c')
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c == 3

# Generated at 2022-06-11 22:23:35.203816
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class Test_to_namedtuple(unittest.TestCase):

        def test_dict(self):
            dic = {
                'a': 1,
                'b': 2,
            }
            out = to_namedtuple(dic)
            self.assertEqual(
                out,
                namedtuple('NamedTuple', 'a b')(a=1, b=2)
            )

        def test_list(self):
            lis = [1, 2, 3]
            out = to_namedtuple(lis)
            self.assertEqual(out, [1, 2, 3])


# Generated at 2022-06-11 22:23:45.349179
# Unit test for function to_namedtuple
def test_to_namedtuple():
    if __name__ == '__main__':
        test_dict = {'a': 1, 'b': 2, '_c': 3, '__d': 4, 'dd': 5}
        test_namedtuple = to_namedtuple(test_dict)
        assert test_namedtuple.a == 1
        assert test_namedtuple.b == 2
        assert not hasattr(test_namedtuple, '_c')
        assert not hasattr(test_namedtuple, '__d')
        assert not hasattr(test_namedtuple, 'dd')

        test_namedtuple = to_namedtuple(SimpleNamespace(**test_dict))
        assert test_namedtuple.a == 1
        assert test_namedtuple.b == 2

# Generated at 2022-06-11 22:23:52.479950
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    tup = to_namedtuple(dic)
    assert tup.a == 1
    assert tup.b == 2
    assert not hasattr(tup, '_fields')
    assert not hasattr(tup, '_asdict')
    assert not hasattr(tup, '_replace')
    assert not hasattr(tup, '_source')
    assert not hasattr(tup, '__dict__')
    assert not hasattr(tup, '__doc__')


if __name__ == '__main__':
    # This code will run the test in this file.'
    import sys
    import doctest

    doctest.ELLIPSIS_MARKER = '-etc-'

# Generated at 2022-06-11 22:23:54.449464
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest.mock as mock


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-11 22:24:49.314065
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pytest import approx

    from flutils.namedtupleutils import to_namedtuple


# Generated at 2022-06-11 22:24:57.959157
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def test_instance(test_obj, *, test_type, test_convert):
        _test_obj = test_convert(test_obj)
        assert isinstance(_test_obj, test_type)
        assert _test_obj == test_obj

    def test_convert(test_obj, *, test_type, test_convert):
        _test_obj = test_convert(test_obj)
        assert not isinstance(_test_obj, test_type)
        assert _test_obj != test_obj

    def make_test_obj(data_type, data):
        if data_type == list:
            return list(data)
        elif data_type == dict:
            return dict(data)
        elif data_type == OrderedDict:
            return OrderedDict(data)
