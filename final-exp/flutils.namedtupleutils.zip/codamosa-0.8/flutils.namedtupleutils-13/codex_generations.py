

# Generated at 2022-06-11 22:15:13.481954
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from typing import Dict

# Generated at 2022-06-11 22:15:22.290290
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    # noinspection PyTypeChecker,PyUnresolvedReferences
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(a=1)

    dic = OrderedDict(a=1)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a')(a=1)

    dic = OrderedDict(b=2, a=1)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'b a')(b=2, a=1)

    dic = Ordered

# Generated at 2022-06-11 22:15:33.069670
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    # test for namedtuple
    expected = namedtuple('NamedTuple', ['a', 'b'])(1, [2, {'c': 3}])
    inpt = {'a': 1, 'b': [2, {'c': 3}]}
    actual = to_namedtuple(inpt)
    assert expected == actual

    expected = namedtuple('NamedTuple', [1, 'a'])(1, [2, {'c': 3}])
    inpt = OrderedDict({1: 1, 'a': [2, {'c': 3}]})
    actual = to_namedtuple(inpt)
    assert expected == actual
    assert isinstance(expected, NamedTuple)


# Generated at 2022-06-11 22:15:44.816710
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic).a == 1
    assert to_namedtuple(dic).b == 2
    dic['c'] = {'d': 4}
    assert to_namedtuple(dic).c.d == 4
    assert to_namedtuple(dic).c.__class__.__name__ == 'NamedTuple'
    dic['c']['e'] = {'f': 6}
    assert to_namedtuple(dic).c.e.f == 6
    dic['c']['g'] = {'h': [1, 2, 3]}
    assert to_namedtuple(dic).c.g.h == [1, 2, 3]

# Generated at 2022-06-11 22:15:56.511317
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # pylint: disable=missing-docstring
    from unittest.mock import Mock
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple

    assert to_namedtuple(None) is None
    assert to_namedtuple('') == ''
    assert to_namedtuple(' ') == ' '
    assert to_namedtuple('hello') == 'hello'
    assert to_namedtuple(2) == 2
    assert to_namedtuple(2.2) == 2.2
    assert to_namedtuple(2 + 2j) == 2 + 2j

    test_dict = {'a': 'a'}
    assert to_namedtuple(test_dict).a == 'a'


# Generated at 2022-06-11 22:16:08.371927
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out == dic
    assert out != {'a': 1, 'b': 2}
    assert out == (1, 2)
    assert out != (2, 1)
    assert out != [1, 2]
    assert out != [2, 1]
    # noinspection PyTypeChecker
    assert out == NamedTuple(a=1, b=2)

    assert out[0] == 1
    assert out[1] == 2
    assert out[a] == 1
    assert out[b] == 2
    assert list(out) == [1, 2]
    assert out == (1, 2)

# Generated at 2022-06-11 22:16:13.483798
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest  # type: ignore[import]
    from flutils.namedtupleutils import to_namedtuple

    with pytest.raises(TypeError):
        to_namedtuple(1)

    nt = to_namedtuple({})
    assert nt == nt()
    nt = to_namedtuple(OrderedDict())
    assert nt == nt()

    nt = to_namedtuple({'a': 1, 'b': 2, 'c': [1, 2, 3]})
    assert nt == nt(a=1, b=2, c=[1, 2, 3])

    nt = to_namedtuple({'a': 1, 'b': 2, 'c': {'a': 1, 'b': 2, 'c': 3}})
    assert nt

# Generated at 2022-06-11 22:16:24.032875
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b']) == ['a', 'b']
    assert to_namedtuple(('a', 'b')) == ('a', 'b')
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple({'_a': 1, 'b': 2}) == namedtuple('NamedTuple', ['b'])(b=2)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)

# Generated at 2022-06-11 22:16:32.053425
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Basic test.
    obj = OrderedDict()
    obj['a'] = 1
    obj['b'] = 2
    dic_1 = OrderedDict()
    dic_1['aa'] = 11
    dic_1['bb'] = 22
    dic_2 = OrderedDict()
    dic_2['aaa'] = 111
    dic_2['bbb'] = 222
    dic_1['cc'] = dic_2
    obj['c'] = dic_1
    actual = to_namedtuple(obj)

# Generated at 2022-06-11 22:16:40.878606
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    # noinspection Mypy
    class TestNamedTuple(unittest.TestCase):
        def test_dict(self):
            # noinspection PyArgumentList
            a = dict(a=1, b=2, c=3)
            b = to_namedtuple(a)
            self.assertIsInstance(b, namedtuple)
            self.assertEqual(b.a, 1)
            self.assertEqual(b.b, 2)
            self.assertEqual(b.c, 3)

        def test_ordered_dict(self):
            # noinspection PyArgumentList
            a = OrderedDict(a=1, b=2, c=3)
            b = to_namedtuple(a)

# Generated at 2022-06-11 22:16:56.637479
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple({}), namedtuple('NamedTuple', ''))
    assert isinstance(to_namedtuple({'a': 1}), namedtuple('NamedTuple', ('a', )))
    assert isinstance(to_namedtuple({'a': 1, 'b': 1}), namedtuple('NamedTuple', ('a', 'b')))
    assert isinstance(to_namedtuple({'a': 1, 'b': 1, 'c': 1}), namedtuple('NamedTuple', ('a', 'b', 'c')))
    assert isinstance(to_namedtuple({'a': 1, 'b': 1, 'c': 1, 'd': 1}), namedtuple('NamedTuple', ('a', 'b', 'c', 'd')))

# Generated at 2022-06-11 22:17:08.597957
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    obj = SimpleNamespace()
    obj.a = 1
    obj.b = 2
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)
    li = [1, 2, 3]
    assert to_namedtuple(li) == [1, 2, 3]
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == NamedTuple(1, 2, 3)
    tup = ('a', 'b', 'c')
    assert to_namedtuple(tup) == ('a', 'b', 'c')

# Generated at 2022-06-11 22:17:18.879157
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None

    from collections import OrderedDict
    from typing import NamedTuple


    class MyNamedTuple(NamedTuple):
        a: int
        b: str
        c: OrderedDict


    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': '2'}) == NamedTuple(a=1, b='2')
    assert to_namedtuple({'b': '2', 'a': 1}) == NamedTuple(a=1, b='2')
    assert to_namedtuple({'a': 1, 'b': '2', '1': 1}) == NamedTuple(a=1, b='2')

    assert to_namedtuple([]) == []

# Generated at 2022-06-11 22:17:27.217374
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert len(obj) == 2

    lis = [dic, dic, dic]
    obj = to_namedtuple(lis)
    for elem in obj:
        assert elem.a == 1
        assert elem.b == 2
        assert len(elem) == 2

    d = dict(a=1, b=2)
    obj = to_namedtuple(d)
    assert obj.a == 1
    assert obj.b == 2
    assert len(obj) == 2

    tup = tuple(lis)
    obj = to_namedtuple(tup)

# Generated at 2022-06-11 22:17:27.845436
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-11 22:17:37.293570
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == namedtuple(
        'NamedTuple', ''
    )()
    assert to_namedtuple({'a': 1}) == namedtuple(
        'NamedTuple', ['a']
    )(1)

    assert to_namedtuple([]) == []
    assert to_namedtuple([1]) == [1]
    assert to_namedtuple([{'a': 1}]) == [namedtuple(
        'NamedTuple', ['a']
    )(1)]

    assert to_namedtuple(tuple()) == tuple()
    assert to_namedtuple((1,)) == (1,)

# Generated at 2022-06-11 22:17:47.911929
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from os import getcwd
    from sys import version_info
    import json
    import unittest
    from flutils.namedtupleutils import __all__ as namedtupleutils_all

    # noinspection PyUnresolvedReferences
    from .test_namedtupleutils import to_namedtuple as test_to_namedtuple

    # Add version information
    # noinspection PyUnresolvedReferences
    from .test_namedtupleutils import (
        __author__,
        __copyright__,
        __email__,
        __license__,
        __summary__,
        __title__,
        __uri__,
        __version__,
    )

    __all__ = namedtupleutils_all


# Generated at 2022-06-11 22:17:59.759300
# Unit test for function to_namedtuple
def test_to_namedtuple():
    for obj in (
            [1, 2, 3],
            {'a': 1, 'b': 2, 'c': 3},
            (1, 2, 3),
            'abc',
            SimpleNamespace(a=1, b=2, c=3),
            OrderedDict(a=1, b=2, c=3),
            namedtuple('TestNamedTuple', ['a', 'b', 'c'])(
                a=1,
                b=2,
                c=3,
            ),
    ):
        assert type(to_namedtuple(obj)) == type(obj)

    assert to_namedtuple('abc') == 'abc'
    assert to_namedtuple(1) == 1
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-11 22:18:08.487535
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import url
    class URL(url.URL):
        __slots__ = ()  # type: ignore[attr-defined]

    class URLWithSlots(url.URL):
        __slots__ = '_name', '_password', '_port', '_query', '_realm', '_url', '_username'
        def __init__(self):
            super(URLWithSlots, self).__init__()

    # noinspection PyTypeChecker
    URLList = [URL(), URLWithSlots()]
    print(URLList)
    print(to_namedtuple(URLList))

    # noinspection PyTypeChecker
    URLList = [
        URL(),
        URLWithSlots(),
        b'',
        bytearray([65, 66, 67]),
    ]


# Generated at 2022-06-11 22:18:18.157139
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [namedtuple('NamedTuple', 'a b')(a=1, b=2)]
    assert to_namedtuple(((1, 2), )) == (1, 2)
    assert to_namedtuple(([1, 2], )) == (1, 2)

# Generated at 2022-06-11 22:18:33.539770
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pformat
    from flutils.miscutils import get_caller_name

    errmsg = 'Failed: %s' % get_caller_name()

    TEST_VAL = {
        'a': {
            'b': 'c',
            'd': 1,
        },
        'e': (
            'f',
            {
                'g': 2,
            },
        ),
        'z': None,
    }

    TEST_OUT = {
        'a': {
            'b': 'c',
            'd': 1,
        },
        'e__0': 'f',
        'e__1__g': 2,
    }

    RESULT = to_namedtuple(TEST_VAL)
    result_str = pformat(RESULT)
    assert result_str

# Generated at 2022-06-11 22:18:45.093767
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a')(a=1)
    dic = {'a': 1, 'b': {'c': 1}}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')\
        (a=1, b=namedtuple('NamedTuple', 'c')(c=1))
    dic = {'a': 1, 'b': {'_c': 1}}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a')(a=1)
    dic = {'a': 1, 'b': {'c': {'_c': 1}}}

# Generated at 2022-06-11 22:18:49.484286
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    _dict = {'a': 1, 'b': 2}
    out1 = to_namedtuple(_dict)
    out2 = to_namedtuple(out1)
    assert out1 == out2

# Generated at 2022-06-11 22:18:57.326667
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = OrderedDict()
    d['a'] = OrderedDict()
    d['a']['b'] = OrderedDict()
    d['a']['b']['c'] = 'abbc'
    nt = to_namedtuple(d)
    assert nt.a.b.c == 'abbc'
    assert nt.a.b == {'c': 'abbc'}
    assert nt.a == {'b': {'c': 'abbc'}}

    d = OrderedDict()
    d['a'] = OrderedDict()
    d['a']['b'] = -1
    nt = to_namedtuple(d)
    assert nt.a.b == -1

    d = OrderedDict()

# Generated at 2022-06-11 22:19:06.947903
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)

    dic = {'b': 2, 'a': 1}
    assert to_namedtuple(dic) == (1, 2)

    dic = {'b': 2, 'a': 1, '_x': 3}
    assert to_namedtuple(dic) == (1, 2)

    dic = {'b': 2, 'a': 1, '_x': 3}
    NT = tuple(sorted(dic.keys()))
    make = namedtuple('NamedTuple', NT)
    assert to_namedt

# Generated at 2022-06-11 22:19:17.794889
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    d1 = {}
    d1_t = to_namedtuple(d1)
    assert isinstance(d1_t, namedtuple)
    assert d1_t._fields == ()
    
    d2 = {'a': 1, 'b': 2}
    d2_t = to_namedtuple(d2)
    assert d2_t == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    
    d3 = {'a': 1, 'b': 2, '_c': 3}
    d3_t = to_namedtuple(d3)
    assert d3_t == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    

# Generated at 2022-06-11 22:19:28.786295
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pformat
    from flutils.namedtupleutils import to_namedtuple
    from flutils.misc import (
        capture_exit,
        capture_stdout,
    )
    from flutils.loadutils import load_json

    def _debug_compare(
            obj: Any,
            namedtuple_obj: Any,
            item: Any,
            _started: bool = False
    ) -> None:
        if not _started and isinstance(obj, (dict, OrderedDict)):
            print('---')
            print('obj:', type(obj).__name__)
            print('ret:', type(namedtuple_obj).__name__)
            print('obj:', pformat(obj))
            print('ret:', pformat(namedtuple_obj))

# Generated at 2022-06-11 22:19:32.373696
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:19:43.692196
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime

    from flutils.tests.helpers import ObjectWithAttributes
    from flutils.tests.helpers import ObjectWithUnderscoreAttributes

    assert isinstance(to_namedtuple({'a': 1}), NamedTuple)
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), NamedTuple)
    assert isinstance(to_namedtuple({'a': datetime.now()}), NamedTuple)
    assert isinstance(to_namedtuple(OrderedDict(a=1)), NamedTuple)
    assert isinstance(to_namedtuple(OrderedDict(a=1, b=2)), NamedTuple)
    assert isinstance(to_namedtuple(OrderedDict(a=datetime.now())),
                      NamedTuple)


# Generated at 2022-06-11 22:19:54.560807
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, '_c_': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c_': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': 2, '1c': 3}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)


# Generated at 2022-06-11 22:20:04.022550
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert to_namedtuple(('a', 'b', 'd')) == ('a', 'b', 'd')
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)

# Generated at 2022-06-11 22:20:16.292534
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(([1, 2, 3], [4, 5, 6])) == ([1, 2, 3], [4, 5, 6])
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(([1, 2, 3], {'a': 1}, {'b': 2})) == (
        [1, 2, 3],
        NamedTuple(a=1),
        NamedTuple(b=2),
    )

# Generated at 2022-06-11 22:20:22.271554
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Basic Types
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': '1', 'b': 2}) == \
        NamedTuple(a='1', b=2)
    # Bad Types
    obj = object()
    with pytest.raises(TypeError):
        to_namedtuple(obj)
    # Non-identifiers
    assert to_namedtuple({'first name': 'John'}) == \
        NamedTuple(first_name='John')
    assert to_namedtuple({'age': 20, 'num-phone': 2}) == \
        NamedTuple(age=20, num_phone=2)
    #

# Generated at 2022-06-11 22:20:30.462327
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    nt1 = to_namedtuple(OrderedDict(a=1, b=2))
    expected = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert nt1 == expected

    nt2 = to_namedtuple(SimpleNamespace(a=1, b=2, c=SimpleNamespace(d=3, e=4)))
    expected = namedtuple('NamedTuple', ['a', 'b', 'c'])(
        a=1,
        b=2,
        c=namedtuple('NamedTuple', ['d', 'e'])(d=3, e=4)
    )
    assert nt2 == expected

    nt3 = to_namedt

# Generated at 2022-06-11 22:20:40.498027
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from collections.abc import MutableMapping
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import _to_namedtuple
    from flutils.namedtupleutils import _AllowedTypes
    from flutils.typingutils import StrMapping
    from types import SimpleNamespace
    from typing import Any, MutableSequence
    # noinspection PyUnusedLocal
    def _check(
            obj: _AllowedTypes,
            exc_type: Any = AssertionError,
            exc_args: Any = None,
    ) -> Any:
        with pytest.raises(exc_type) as err_info:
            out = to_namedtuple(obj)

# Generated at 2022-06-11 22:20:50.135633
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    from decimal import Decimal
    from flutils.miscutils import MultiType
    from flutils.namedtupleutils import NamedTuple
    from types import SimpleNamespace
    import pytest


# Generated at 2022-06-11 22:20:55.034075
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert isinstance(out, NamedTuple)

# Generated at 2022-06-11 22:21:02.457217
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple.
    """
    assert to_namedtuple(dict(a=1)) == namedtuple('NamedTuple', ['a'])(1)
    assert to_namedtuple(dict(a=1, b=2, c=3)) == namedtuple('NamedTuple', ['a', 'b', 'c'])(1, 2, 3)
    assert to_namedtuple(dict(a=1, b=2, c=dict(d=4))) == namedtuple('NamedTuple', ['a', 'b', 'c'])(1, 2, namedtuple('NamedTuple', ['d'])(4))
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple((1, 2)) == (1, 2)
   

# Generated at 2022-06-11 22:21:13.443822
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections import namedtuple
    from types import SimpleNamespace

    a = {'a': 1, 'b': 2}
    a = to_namedtuple(a)
    assert isinstance(a, namedtuple('NamedTuple', 'a b')), (
        "Expected a namedtuple; got: %s" % type(a).__name__
    )
    assert a.b == 2, (
        "Expected 'a.b' to be 2; got: %s" % a.b
    )

    b = [{'a': 1, 'b': 2}]
    b = to_namedtuple(b)

# Generated at 2022-06-11 22:21:20.811512
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _check_objects_equal(obj1: Any, obj2: Any) -> None:
        from itertools import chain
        from flutils.namedtupleutils import to_namedtuple
        from flutils.tests import dummy_object

        def _iter_obj(obj: Any) -> Any:
            if isinstance(obj, dict):
                for key, val in obj.items():
                    yield from _iter_obj(val)
            elif isinstance(obj, list) or isinstance(obj, tuple):
                for item in obj:
                    yield from _iter_obj(item)
            else:
                yield obj


# Generated at 2022-06-11 22:21:35.566252
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for function flutils.namedtupleutils.to_namedtuple."""

    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace

    # Test with empty
    assert to_namedtuple({}) == to_namedtuple([]) == to_namedtuple(()) == \
        to_namedtuple(SimpleNamespace()) == namedtuple('name', '')()

    # Test with simple
    obj = {'a': 'a', 'b': 'b'}
    assert to_namedtuple(obj) == to_namedtuple(('a', 'b')) == \
        to_namedtuple(['a', 'b']) == namedtuple('foo', 'a b')('a', 'b')

    # Test with

# Generated at 2022-06-11 22:21:46.535144
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.utils import Dict
    from pprint import pprint

    def test_asserts(
            obj: Any,
            expected: Any,
    ) -> None:
        assert obj == expected
        assert isinstance(obj, NamedTuple)
        assert obj.__class__.__base__ is tuple
        assert type(obj) is not tuple
        assert obj.__class__.__name__ == 'NamedTuple'
        assert isinstance(obj._asdict(), dict)

    nt_empty = NamedTuple('')
    test_asserts(
        to_namedtuple(nt_empty),
        NamedTuple(''),
    )

    nt_one_attr = NamedTuple('a')

# Generated at 2022-06-11 22:21:53.058447
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # simple test
    dic = {'a': 1, 'b': 2}
    nt, = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

    # test ordering
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == to_namedtuple(OrderedDict(dic))

    # more complex test
    dic = {
        'a': {'b': {
            'c': {
                'd': 1,
                'e': 2,
                'f': 3,
            },
            'g': 4,
        }},
        'h': 5,
        'i': 6,
        'j': {'k': 7},
    }
    nt, = to

# Generated at 2022-06-11 22:22:02.905857
# Unit test for function to_namedtuple
def test_to_namedtuple(): # pragma: no cover
    from flutils.assertutils import assert_equal

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert_equal(nt.a, 1)
    assert_equal(nt.b, 2)

    lst_int = [1, 2, 3, 4]
    lst2 = to_namedtuple(lst_int)
    assert_equal(lst2, lst_int)

    lst_dic = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    lst3 = to_namedtuple(lst_dic)
    assert_equal(lst3[0].a, 1)

# Generated at 2022-06-11 22:22:12.679346
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Convert a dictionary that contains an OrderedDict
    # nested OrderedDict contains another OrderedDict
    # the first OrderedDict has an int value
    # the nested OrderedDict has an OrderedDict value
    # The returned object has items sorted in alphabetical order
    # This is as ordereddict does not sort, when converted to a namedtuple
    # noinspection PyUnusedFunction
    def ordereddict_to_namedtuple(obj):
        mt = namedtuple('__', obj.keys())(*obj.values())
        return mt


# Generated at 2022-06-11 22:22:19.942428
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from pprint import pprint
    lines = open(__file__, 'r').read().splitlines()
    lines = list(map(str.strip, lines))
    pprint(lines)
    nt_lines = to_namedtuple(lines)
    pprint(nt_lines)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:22:30.727743
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple({'b': 2, 'a': 1}) == to_namedtuple(OrderedDict({'a': 1, 'b': 2})) == to_namedtuple(OrderedDict({'b': 2, 'a': 1}))
    assert to_namedtuple(list(range(5))) == (0, 1, 2, 3, 4) == to_namedtuple(tuple(range(5))) == to_namedtuple(SimpleNamespace(**dict(zip(('a', 'b', 'c', 'd', 'e'), range(5)))))

# Generated at 2022-06-11 22:22:39.981615
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(
        {'a': 1, 'b': 2}
    ) == namedtuple('Temp', 'a b')(a=1, b=2)
    assert to_namedtuple(
        {'a': 1, 'b': 2, '_c': 3}
    ) == namedtuple('Temp', 'a b')(a=1, b=2)
    assert to_namedtuple(
        {'a': 1, 'b': {'x': 10, 'y': 20}}
    ) == namedtuple('Temp', 'a b')(
        a=1,
        b=namedtuple('Temp', 'x y')(x=10, y=20)
    )

# Generated at 2022-06-11 22:22:51.524756
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest.mock

    # noinspection PyProtectedMember
    def _mock_type(name: str, bases: Tuple[str, ...]):
        return namedtuple('NamedTuple', bases)  # type: ignore[misc]

    # noinspection PyUnusedLocal
    def _mock_namedtuple(name: str, bases: Tuple[str, ...]):
        # noinspection PyProtectedMember
        return namedtuple('NamedTuple', bases)  # type: ignore[misc]

    # noinspection PyUnusedLocal
    def _mock_not_simple_namespace(name: str, bases: Tuple[str, ...]):
        return bases


# Generated at 2022-06-11 22:22:58.150709
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    # -- basic value in mapping
    sdic = {'a': 1, 'b': 2}
    nt = to_namedtuple(sdic)
    assert type(nt) is namedtuple('NamedTuple', 'a b')
    assert nt.a == 1
    assert nt.b == 2
    # -- sequence with non-identifier identifiers
    sl = [{'a': 1, 'b': 2}, 'c', 'd']
    lnt = to_namedtuple(sl)
    assert type(lnt) is list
    assert lnt[0] == {'a': 1, 'b': 2}
    assert lnt[1] == 'c'
    assert lnt[2] == 'd'
    # -- sequence with identifiers

# Generated at 2022-06-11 22:23:16.925630
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import inspect

    class TestClass(object):
        def __init__(self):
            self.attr = 1

        def method(self):
            return 2

        @classmethod
        def classmethod(cls):
            return 3

        @staticmethod
        def staticmethod():
            return 4


# Generated at 2022-06-11 22:23:19.941763
# Unit test for function to_namedtuple
def test_to_namedtuple():
    x = SimpleNamespace()
    x.a = 1
    x.b = x.a + 1
    x.c = 3
    nt = to_namedtuple(x)
    print(nt)


# Generated at 2022-06-11 22:23:26.603855
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import time
    from collections import defaultdict
    from flutils.namedtupleutils import to_namedtuple, NamedTuple

    t = time(8, 12, 15)
    nt = to_namedtuple(t)
    assert (
        str(nt)
        ==
        "NamedTuple(hour=8, minute=12, second=15, microsecond=0, tzinfo=None)"
    )
    assert type(nt) is NamedTuple

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert str(nt) == "NamedTuple(a=1, b=2)"
    assert type(nt) is NamedTuple

    # test defaultdict
    dd = defaultdict(list)

# Generated at 2022-06-11 22:23:32.551181
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Using simple list
    data = {
        "name": "tests",
        "subrepos": [
            "flutils",
            "flutils.__main__",
            "flutils.configparserutils",
            "flutils.loggingutils"
        ]
    }
    list_input = [data, data, data]

    # Using OrderedDict for list items
    data = OrderedDict({
        "name": "tests",
        "subrepos": [
            "flutils",
            "flutils.__main__",
            "flutils.configparserutils",
            "flutils.loggingutils"
        ]
    })
    list_ordered = [data, data, data]

    # Using dict for list items

# Generated at 2022-06-11 22:23:44.622758
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test that an exception is raised when trying to convert the wrong type
    with pytest.raises(TypeError):
        _ = to_namedtuple(1)
        _ = to_namedtuple(1.0)
        _ = to_namedtuple('a')
        _ = to_namedtuple(True)

    # Test that an exception is raised when trying to convert a forbidden key
    obj = {'a': 1, '3': 2}
    with pytest.raises(SyntaxError):
        _ = to_namedtuple(obj)

    # Test that values are recursively converted
    obj = {'a': {'b': 1, 'c': 2}, 'd': 3}
    expected = (1, 2)
    result = to_namedtuple(obj)
    assert type(result) == namedt

# Generated at 2022-06-11 22:23:52.085992
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pytest import raises

    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    def make_tuple(
            *args: Any,
            **kwargs: Any
    ) -> Tuple[Any, ...]:
        return args

    def make_tuple_identifier(
            *args: Any,
            **kwargs: Any
    ) -> Tuple[Any, ...]:
        items = []
        dic = OrderedDict()
        for idx, item in enumerate(args):
            if isinstance(item, dict):
                for key in item.keys():
                    dic[key] = item[key]
            else:
                items.append(item)
        for key, val in kwargs.items():
            dic[key]

# Generated at 2022-06-11 22:23:58.406223
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:24:02.777176
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'a': 1, 'b': 2}
    assert to_namedtuple(d) == NamedTuple(a=1, b=2)


if __name__ == '__main__':
    print('use as module, not standalone')

# Generated at 2022-06-11 22:24:15.251755
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple({'a': {'b': 2}}) == NamedTuple(a=NamedTuple(b=2))
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': {'b': 2, 'c': 3}}) == NamedTuple(a=NamedTuple(b=2, c=3))

# Generated at 2022-06-11 22:24:24.497005
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('b', 2), ('a', 1)])) == NamedTuple(b=2, a=1)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(b=2, a=1)) == NamedTuple(b=2, a=1)
    assert to_namedtuple([]) == []
    assert to_named

# Generated at 2022-06-11 22:24:56.837429
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import logging
    import unittest

    import pypandoc

    from flutils.logutils import BraceMessage as __

    # noinspection PyArgumentList
    class TestToNamedTuple(unittest.TestCase):
        """Unit tests for function to_namedtuple."""

        l_format = logging.Formatter('%(message)s')

        log = logging.getLogger(__name__)
        if not log.handlers:
            log.setLevel(logging.INFO)
            loghand = logging.StreamHandler()
            loghand.setFormatter(l_format)
            log.addHandler(loghand)
        #  log.propagate = False
