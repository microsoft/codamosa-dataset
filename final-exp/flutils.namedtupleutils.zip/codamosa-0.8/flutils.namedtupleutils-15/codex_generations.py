

# Generated at 2022-06-11 22:15:14.428261
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestCase(unittest.TestCase):
        def assertIsNamedTuple(self, obj):
            self.assertIsInstance(obj, tuple)
            self.assertTrue(hasattr(obj, '_fields'))
            self.assertTrue(isinstance(obj._fields, tuple))

        def test_to_namedtuple_with_dict(self):
            obj = {'a': 1, 'b': 2}
            res = to_namedtuple(obj)
            self.assertIsNamedTuple(res)
            self.assertEqual(res.a, 1)
            self.assertEqual(res.b, 2)

        def test_to_namedtuple_with_dict_and_None(self):
            obj = {'a': 1, 'b': None}


# Generated at 2022-06-11 22:15:22.806413
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {'a': 1, 'b': 2}
    assert to_namedtuple(d) == NamedTuple(a=1, b=2)

    # Function should accept an OrderedDict
    od = OrderedDict()
    od['c'] = 3
    od['d'] = 4
    od['a'] = 5
    assert to_namedtuple(od) == NamedTuple(c=3, d=4, a=5)

    # Function should accept a nested OrderedDict
    od['c'] = {'d': 6, 'f': 7}
    assert to_namedtuple(od) == NamedTuple(c=NamedTuple(d=6, f=7), d=4, a=5)

    # Function should accept a SimpleNamespace
    sn = SimpleNamespace()
   

# Generated at 2022-06-11 22:15:33.430874
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    from random import randint
    from string import ascii_lowercase, digits
    from collections import OrderedDict, ChainMap

    #: Type for a random string to go inside values
    RandomString = str
    RandomList = List[Any]
    RandomDict = Mapping[str, Any]
    RandomValue = Union[RandomString, RandomList, RandomDict]

    #: Type of the random data generated in this function
    RandomData = Union[
        List[RandomList],
        Tuple[RandomList],
        List[RandomDict],
        Tuple[RandomDict],
        RandomDict,
        RandomList,
        RandomString
    ]

    #: NamedTuple type for the converted values

# Generated at 2022-06-11 22:15:45.111118
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest as ut

    class TestToNamedTuple(ut.TestCase):

        # noinspection PyMissingOrEmptyDocstring, PyUnusedLocal,PyMissingTypeHints
        def setUp(self):
            self.maxDiff = None

        def test_1(self):
            tnt: NamedTuple = to_namedtuple({'x': 1, 'y': 2})
            self.assertEqual(tnt.x, 1)
            self.assertEqual(tnt.y, 2)
            tnt.x = 'a'
            self.assertEqual(tnt.x, 'a')

        def test_2(self):
            obj = to_namedtuple({'my_int': 1, 'my_str': 'hello'})

# Generated at 2022-06-11 22:15:56.860445
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import (
        OrderedDict,
    )
    from types import SimpleNamespace

    dic = {
        'a': 1,
        'b': 2,
        '_c': 3,
    }
    namedtuple = to_namedtuple(dic)
    assert namedtuple.a == 1
    assert namedtuple.b == 2
    assert hasattr(namedtuple, '_c') is False

    dic = OrderedDict(zip(('a', 'b', 'c'), (1, 2, 3)))
    namedtuple = to_namedtuple(dic)
    assert namedtuple.a == 1
    assert namedtuple.b == 2
    assert namedtuple.c == 3

    obj = Simple

# Generated at 2022-06-11 22:16:08.782914
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    import numpy as np

    lst = [
        {'a': 1, 'b': 2},
        {'a': 3, 'c': 4}
    ]
    lst_namedtuple = to_namedtuple(lst)
    assert isinstance(lst_namedtuple[0], namedtuple)

    tup = (
        {'a': 1, 'b': 2},
        {'a': 3, 'c': 4}
    )
    tup_namedtuple = to_namedtuple(tup)
    assert isinstance(tup_namedtuple[0], namedtuple)

    dict1 = {'a': 1, 'b': 2}

# Generated at 2022-06-11 22:16:16.166114
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class Foo:
        def __init__(self):
            self.a = 1
            self.b = 2
    foo = Foo()
    # noinspection PyTypeChecker
    assert to_namedtuple({'a': 1, 'b': 2}) == Foo()
    # noinspection PyTypeChecker
    assert to_namedtuple(foo) == Foo()
    # noinspection PyTypeChecker
    assert to_namedtuple(tuple((foo,))) == (Foo(),)
    # noinspection PyTypeChecker
    assert to_namedtuple(tuple(({'a': 1, 'b': 2},))) == (Foo(),)
    # noinspection PyTypeChecker

# Generated at 2022-06-11 22:16:25.457805
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'abc': 1, 'def': 2}
    nt = to_namedtuple(dic)
    assert repr(nt) == "NamedTuple(abc=1, def=2)"
    assert list(nt) == [1, 2]
    dic = OrderedDict([('abc', 1), ('def', 2)])
    nt = to_namedtuple(dic)
    assert repr(nt) == "NamedTuple(abc=1, def=2)"
    assert list(nt) == [1, 2]
    dic = {1: 'a', 4: 'b'}
    nt = to_namedtuple(dic)
    assert repr(nt) == "NamedTuple()"

# Generated at 2022-06-11 22:16:33.025613
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    with pytest.raises(TypeError):
        to_namedtuple(1)

    assert to_namedtuple({}) == NamedTuple()

    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == NamedTuple(a=1, b=2)

    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 10, 'b': 20}]) == (
        NamedTuple(a=1, b=2),
        NamedTuple(a=10, b=20)
    )


# Generated at 2022-06-11 22:16:41.297434
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple([[], []]) == [(), ()]
    assert to_namedtuple([[{'a': 1}], []]) == [NamedTuple(a=1), ()]
    assert to_namedtuple([[], [{'b': 2}]]) == [(), NamedTuple(b=2)]
    assert to_namedtuple([[{'a': 1}], [{'b': 2}]]) == [NamedTuple(a=1), NamedTuple(b=2)]

    assert to_namedtuple(()) == ()
    assert to_namedtuple(((), ())) == ((), ())
    assert to_namedtuple((({"a": 1},), ())) == ((NamedTuple(a=1),), ())


# Generated at 2022-06-11 22:16:59.454171
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    # noinspection SpellCheckingInspection
    dic = {'a': 1, 'b': {'c': 2, 'd': 'D'}, 'e': ['E'], 'f': ('F', 3.2)}
    # noinspection SpellCheckingInspection
    tup = (1, ('A', ('B', ('C', ('D', ('E', ('F', ('G', ('H', 'I')))))))))
    out1 = to_namedtuple(dic)
    assert out1.b.d == 'D'
    assert out1.e[0] == 'E'
    assert out1.f[0] == 'F'
    assert out1.f[1] == 3.2

# Generated at 2022-06-11 22:17:09.752064
# Unit test for function to_namedtuple
def test_to_namedtuple():
    try:
        to_namedtuple(None)
    except TypeError:
        pass
    else:
        assert False, "Expected TypeError"
    assert to_namedtuple([]) == []
    assert to_namedtuple([1, 'a', 2]) == [1, 'a', 2]
    assert to_namedtuple({'0': 1}) == NamedTuple(zero=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': {'b1': 2}}) == NamedTuple(
        a=1,
        b=NamedTuple(b1=2)
    )

# Generated at 2022-06-11 22:17:19.564399
# Unit test for function to_namedtuple
def test_to_namedtuple():
    sns = SimpleNamespace(a=2, _b=3, c_=4, __d__=5)
    nt = to_namedtuple(sns)
    assert nt.a == 2
    assert hasattr(nt, '_b') is False
    assert nt.c_ == 4
    assert nt.__d__ == 5
    assert repr(nt) == 'NamedTuple(a=2, c_=4, __d__=5)'

    od = OrderedDict(a=2, _b=3, c_=4, __d__=5)
    nt = to_namedtuple(od)
    assert nt.a == 2
    assert hasattr(nt, '_b') is False
    assert nt.c_ == 4
    assert nt.__d__

# Generated at 2022-06-11 22:17:27.846932
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    # noinspection PyTypeChecker
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple(
        'NamedTuple', 'a b'
    )(1, 2)
    assert to_namedtuple(
        {'a': 1, 'b': 2}
    ) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple(
        {'b': 2, 'a': 1}
    ) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple(
        {None: 1, 'b': 2}
    ) == namedtuple('NamedTuple', 'b')(2)
   

# Generated at 2022-06-11 22:17:37.282074
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert not hasattr(namedtuple, '_fields')
    dic = OrderedDict([
        ('a', 1),
        ('b', 2),
    ])
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr(nt, 'c')
    assert len(nt) == 2

    dic = {
        'a': 1,
        'b': 2,
    }
    nt = to_namedtuple(dic)
    assert hasattr(nt, 'a')
    assert hasattr(nt, 'b')
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr

# Generated at 2022-06-11 22:17:47.879973
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from unittest.mock import Mock, patch

    # Test function with invalid objects
    invalid_objs: List[Tuple[Any, Any]] = [
        (None, TypeError("Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (r) None")),
        (Mock(spec=[]), TypeError("Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (r) <Mock id='4533757960'>")),
    ]

# Generated at 2022-06-11 22:17:53.961528
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    tup = dic.items()
    lst = list(tup)
    for obj in (dic, tup, lst):
        assert to_namedtuple(obj) == namedtuple('NamedTuple', 'a b')(1, 2)


test_to_namedtuple()

# Generated at 2022-06-11 22:18:01.491901
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.randomutils import random_string
    from flutils.misc import is_sequence
    from flutils.containerutils import (
        get_dict_combinations,
        get_sets_combinations,
    )
    from flutils.objutils import get_object_args
    from collections import OrderedDict  # noqa: E501
    from datetime import datetime, timedelta

    def test_seq(obj: Sequence) -> None:
        out = to_namedtuple(obj)
        assert out != obj
        assert isinstance(out, tuple) or isinstance(out, list)
        assert len(out) == len(obj)
        for idx, item in enumerate(obj):
            assert isinstance(out[idx], item.__class__)
            assert out[idx] == item

# Generated at 2022-06-11 22:18:09.186204
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from inspect import signature, isclass
    from collections import namedtuple

    def _to_namedtuple_test(
            name: str,
            obj: Any,
            original_value: Any = None
    ) -> None:
        # Unit test for function to_namedtuple
        if original_value is not None:
            assert original_value is obj
        new_obj = to_namedtuple(obj)
        if name == 'list':
            assert isinstance(new_obj, list)
        elif name == 'tuple' or name == 'namedtuple':
            assert isinstance(new_obj, tuple)
            assert isclass(new_obj)
            sig = signature(new_obj)
            assert str(sig) == '(*args, **kwargs)'

# Generated at 2022-06-11 22:18:18.358053
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from collections import OrderedDict
    from types import SimpleNamespace

    class TestToNamedTuple(TestCase):

        def test_to_namedtuple_dict(self):
            dic = {'a': 1, 'b': 2}
            expected = namedtuple('NamedTuple', ('a', 'b'))(1, 2)
            self.assertEqual(expected, to_namedtuple(dic))

        def test_to_namedtuple_ordered_dict(self):
            dic = OrderedDict([('b', 2), ('a', 1)])
            expected = namedtuple('NamedTuple', ('b', 'a'))(2, 1)
            self.assertEqual(expected, to_namedtuple(dic))


# Generated at 2022-06-11 22:18:33.348200
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple
    from unittest import TestCase, main

    class Sample(NamedTuple):
        a: int
        b: str
        c: bool

    class Sample2(NamedTuple):
        name: str
        address: str
        phone: str

    class Sample3(NamedTuple):
        people: List[Sample2]

    class MyTestCase(TestCase):
        def test_to_namedtuple(self):
            dic = dict(a=dict(c=3), b=2)
            obj = to_namedtuple(dic)
            self.assertEqual(obj.a.c, 3)
            self.assertEqual(obj.b, 2)

# Generated at 2022-06-11 22:18:44.996584
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    ord_dic = OrderedDict(a=1, b=2)
    out = to_namedtuple(ord_dic)
    assert out.a == 1
    assert out.b == 2

    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()

    ls = [1, 2, 3]
    out = to_namedtuple(ls)
   

# Generated at 2022-06-11 22:18:55.242824
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'name': 'customer0',
        'address': {
            'street': '123 Main St',
            'city': 'Vancouver',
            'state': 'WA',
            'zipcode': 4321,
        },
        'phone': [
            '123-555-1234',
            '456-555-4321',
            '789-555-7890',
        ],
    }
    obj = to_namedtuple(dic)
    assert str(obj.address) == "NamedTuple(city='Vancouver', state='WA', street='123 Main St', zipcode=4321)"
    assert str(obj.phone) == "('123-555-1234', '456-555-4321', '789-555-7890')"

# Generated at 2022-06-11 22:19:05.859434
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from typing import NamedTuple

    nt = namedtuple('Foo', ['a', 'b', 'c', 'd', 'e'])

    lst: List[NamedTuple] = [
        nt(a=1, b=2, c=3, d=4, e=5),
        nt(a=6, b=7, c=8, d=9, e=0),
        nt(a=3, b=3, c=3, d=3, e=3),
        nt(a=0, b=2, c=0, d=2, e=0)
    ]

    foo = to_namedtuple(lst)
    assert isinstance

# Generated at 2022-06-11 22:19:16.897438
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert isinstance(obj, namedtuple('NamedTuple', 'a b'))
    assert obj.a == 1
    assert obj.b == 2

    with pytest.raises(TypeError) as excinfo:
        to_namedtuple('abc')
    assert excinfo.type is TypeError
    assert excinfo.value.args[0] == (
        "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
        "got: (str) abc"
    )

    obj = to_namedtuple([1, 'a', {'c': 1, 'd': 2}])
    assert obj[0] == 1

# Generated at 2022-06-11 22:19:28.250942
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) ==  namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple([{'a': 1}, {'a': 1, 'b': 2}]) == [namedtuple('NamedTuple', 'a')(a=1), namedtuple('NamedTuple', 'a b')(a=1, b=2)]
    assert to_namedtuple({'a': [{'c': 3}, {'c': 4, 'd': 5}]}) == namedtuple('NamedTuple', 'a')(a=[namedtuple('NamedTuple', 'c')(c=3), namedtuple('NamedTuple', 'c d')(c=4, d=5)])


# Generated at 2022-06-11 22:19:37.472658
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    from flutils.miscutils import (
        ignore_error,
    )
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from flutils.typesutils import (
        is_namedtuple,
    )
    from flutils.validateutils import (
        validate_namedtuple,
    )

    dic = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
        },
    }
    nt = to_namedtuple(dic)

    assert validate_namedtuple(nt) is True
    assert nt == (1, 2, namedtuple('NamedTuple', ('d', 'e'))(3, 4))

   

# Generated at 2022-06-11 22:19:47.234665
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    import flutils.namedtupleutils as ntu
    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import _to_namedtuple

    ##########################################################################
    # Test different object types and ensure function returns the right type.
    # Test a string: Should still return the string
    assert isinstance(ntu.to_namedtuple('foo'), str)
    assert isinstance(_to_namedtuple('foo', True), str)

    # Test a list: returns a list
    assert isinstance(ntu.to_namedtuple([1, 2, 3]), list)
    assert isinstance(_to_namedtuple([1, 2, 3], True), list)

    # Test a tuple: returns a tuple

# Generated at 2022-06-11 22:19:56.029754
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt[0] == 1
    assert nt[1] == 2

    dic = OrderedDict({'a': 1, 'b': 2})
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt[0] == 1
    assert nt[1] == 2

    dic = {'a': 1, 'b': 2, '_c': 3}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert not hasattr

# Generated at 2022-06-11 22:20:03.929157
# Unit test for function to_namedtuple
def test_to_namedtuple():
    lst = [{'a': 1, 'b': 2, 'c': {'d': 3}}, {'a': 2, 'b': 3, 'c': {'d': 4}}]
    out = to_namedtuple(lst)
    assert isinstance(out, list)
    assert isinstance(out[0], NamedTuple)
    assert out[0].a == 1
    assert out[0].b == 2
    assert isinstance(out[0].c, NamedTuple)
    assert out[0].c.d == 3
    assert isinstance(out[1], NamedTuple)
    assert out[1].a == 2
    assert out[1].b == 3
    assert isinstance(out[1].c, NamedTuple)
    assert out[1].c.d == 4


# Generated at 2022-06-11 22:20:20.369575
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pympler import asizeof
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple as nt
    from collections import OrderedDict as OD
    import string
    import random

    # Generate random namedtuples
    N = 100
    keys = string.ascii_letters[:26]
    # noinspection PyTypeChecker
    ntdict = {}
    # noinspection PyTypeChecker
    ntdict2 = {}
    # noinspection PyTypeChecker
    ntdlist = []
    # noinspection PyTypeChecker
    ntdlist2 = []
    asize = []
    # noinspection PyTypeChecker
    odlist = []
    for i in range(N):
        # noinspection PyTypeChecker
        ntd

# Generated at 2022-06-11 22:20:29.876268
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 'a', 2, 'b', 3, 'c']) == [1, 'a', 2, 'b', 3, 'c']
    assert to_namedtuple(['a', 1, 'b', '2']) == ['a', 1, 'b', '2']
    assert to_namedtuple(['a', 1, 'b', '2']) == ('a', 1, 'b', '2')
    assert to_namedtuple(('a', 1, 'b', '2')) == ('a', 1, 'b', '2')
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict((('a', 1), ('b', 2)))) == NamedT

# Generated at 2022-06-11 22:20:40.227684
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import math
    import unittest

    from typing import get_type_hints
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple

    class TestSuite(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_to_namedtuple(self):
            test_names = (
                'one',
                'two',
                'three',
                'four',
                'five'
            )
            test_nums = (
                1,
                2,
                3,
                4,
                5
            )
            test_dict = {
                'c': 3,
                'a': 1,
                'b': 2
            }

# Generated at 2022-06-11 22:20:41.922208
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple



# Generated at 2022-06-11 22:20:50.772651
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:20:59.628231
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    from flutils.namedtupleutils import to_namedtuple

    class Tests(unittest.TestCase):
        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            expected = '[(a=1, b=2)]'
            actual = repr(to_namedtuple(dic))
            self.assertEqual(expected, actual)

    return unittest.main(Tests, argv=[''], verbosity=2, exit=False)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:21:10.891920
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    assert _to_namedtuple('abc') == 'abc'
    assert _to_namedtuple(12.3) == 12.3
    assert _to_namedtuple(['a', 'b']) == ['a', 'b']
    assert _to_namedtuple((1, 2)) == (1, 2)
    assert _to_namedtuple(('a', 'b')) == ('a', 'b')
    assert _to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        OrderedDict([('a', 1), ('b', 2)])

# Generated at 2022-06-11 22:21:19.154217
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple)
    assert hasattr(out, 'a')
    assert hasattr(out, 'b')
    assert out.a == 1
    assert out.b == 2
    obj = []
    out = to_namedtuple(obj)
    assert isinstance(out, list)
    assert out == []
    obj = [{'a': 1, 'b': 2}]
    out = to_namedtuple(obj)
    assert isinstance(out[0], NamedTuple)
    assert hasattr(out[0], 'a')
    assert hasattr(out[0], 'b')
    assert out[0].a == 1
    assert out[0].b == 2


# Generated at 2022-06-11 22:21:28.028889
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    dic = {'b': 2, 'a': 1}
    lis = [dic, dic]
    tup = (dic, dic)
    odic = OrderedDict()
    odic['b'] = 2
    odic['a'] = 1
    sna = SimpleNamespace()
    sna.b = 2
    sna.a = 1
    d2 = {'b': 2, 'a': 1, 'dict': dic}
    d3 = {'b': 2, 'a': 1, 'dict': dic, 'dict3': d2}
    l2 = [dic, dic, d2]

# Generated at 2022-06-11 22:21:36.457696
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """This function tests the function to_namedtuple.

    There are (2) tests to run.

    1) Convert a Mapping to a NamedTuple.

    Example:
        >>> test_to_namedtuple()
    """
    # Mapping
    #   List
    #       :obj:`int`
    #       :obj:`float`
    #   Tuple
    #       :obj:`str`
    #       :obj:`bool`
    #       :obj:`bytes`
    #       :obj:`memoryview`
    #   Dict
    #       :obj:`list`
    #           :obj:`list`
    #               :obj:`tuple`
    #                   :obj:`set`
    #                       :obj:`frozenset`
    #   :obj

# Generated at 2022-06-11 22:22:10.853294
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1, 'c': 3, 'b': 2}) == namedtuple('NamedTuple', 'a b c')(1, 2, 3)
    assert to_namedtuple({'a': 1, 'c': 3, 'b': {'d': 4, 'f': 6, 'e': 5}}) == namedtuple('NamedTuple', 'a b c')(1, namedtuple('NamedTuple', 'd e f')(4, 5, 6), 3)

# Generated at 2022-06-11 22:22:21.810315
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple."""
    from collections import (
        ChainMap,
        Counter,
        deque,
        defaultdict,
        namedtuple,
        OrderedDict,
    )
    from collections.abc import (
        Hashable,
        Iterable,
        Iterator,
        KeysView,
        Mapping,
        MappingView,
        MutableMapping,
        MutableSequence,
        Sequence,
        Sized,
        ValuesView,
    )
    from itertools import (
        chain,
        repeat,
        tee,
        zip_longest,
    )
    from types import (
        GeneratorType,
        SimpleNamespace,
    )
    from unittest.mock import MagicMock
    from flutils.validators import is_generator



# Generated at 2022-06-11 22:22:32.442507
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import Dict, List, Tuple, Union
    from collections import OrderedDict
    assert to_namedtuple(
        {
            'a': 1,
            'b': 2,
        }
    ) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)

    assert to_namedtuple(
        OrderedDict(
            {
                'a': 1,
                'b': 2,
            }
        )
    ) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)


# Generated at 2022-06-11 22:22:41.095105
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for to_namedtuple."""
    _ = to_namedtuple
    assert _(['a', 'b']) == ['a', 'b']
    assert _(('a', 'b')) == ('a', 'b')
    assert _(OrderedDict([('a', 'b')])) == NamedTuple(a='b')
    assert _(dict(a='b')) == Namespace(a='b')
    assert _(dict(a=['b', 'c'])) == Namespace(a=('b', 'c'))
    assert _({'a': 'b', 'b': 'c'}) == Namespace(a='b', b='c')
    assert _(SimpleNamespace(a='b', b='c')) == Namespace(a='b', b='c')
    assert _

# Generated at 2022-06-11 22:22:42.151609
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert 'OrderedDict' in __all__

# Generated at 2022-06-11 22:22:47.867703
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert to_namedtuple([OrderedDict([('a', 1), ('b', 2)])]) == \
           [to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))]

# Generated at 2022-06-11 22:22:58.319372
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit tests for function to_namedtuple."""
    import pytest
    import logging
    try:
        logging.basicConfig()
    except ValueError:  # pragma: no cover
        pass
    log = logging.getLogger()
    log.setLevel(logging.DEBUG)

    def __asserts(obj: Any, should: Any) -> None:
        log.debug('%s',
                  '-'*50,
                  '\nNamedTupleUtils - test_to_namedtuple:\n')
        out = to_namedtuple(obj)
        if isinstance(out, NamedTuple):
            log.debug('%s', out._asdict())
            log.debug('%s', 'NamedTuple attributes:')

# Generated at 2022-06-11 22:23:02.875057
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from __init__ import __all__ as all_funcs

    for func in all_funcs:
        print('--- Unit test for: ' + func)
        retval = eval(func + '()')
        print('Returned value: ' + str(retval))
        print('Expected value: ' + str([]))
        assert retval == []

# Generated at 2022-06-11 22:23:09.833942
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections.abc import Sequence
    from types import SimpleNamespace
    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', ['a'])(1)
    assert to_namedtuple({'a': 1, 'b': 2}) == \
            namedtuple('NamedTuple', ['a', 'b'])(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == \
            namedtuple('NamedTuple', ['a', 'b', 'c'])(1, 2, 3)


# Generated at 2022-06-11 22:23:18.065676
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace
    from typing import Tuple
    from pprint import pprint

    A = namedtuple('A', 'a b')
    B = namedtuple('B', 'c')
    C = namedtuple('C', 'd e')
    E = namedtuple('E', 'f')
    G = namedtuple('G', 'g')
    I = namedtuple('I', 'g h')
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8}
    lst = [1, 2, 3, 4, 5, 6, 7, 8]
    tup

# Generated at 2022-06-11 22:23:45.796825
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pformat
    from flutils.testutils import run_doctest

    # Simple usage of to_namedtuple
    doctest = r'''
        >>> from pprint import pformat
        >>> from flutils.namedtupleutils import to_namedtuple
        >>> dic = {'a': 1, 'b': 2}
        >>> to_namedtuple(dic)
        NamedTuple(a=1, b=2)
        >>> out = to_namedtuple(dic)
        >>> out.a
        1
        >>> out.b
        2
    '''
    run_doctest(doctest, {'to_namedtuple': to_namedtuple, 'pformat': pformat})

    # to_namedtuple used on OrderedDict object
    doctest = r

# Generated at 2022-06-11 22:23:52.520236
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import ntpath
    import pathlib
    import tempfile
    from collections import OrderedDict

    assert to_namedtuple(None) is None
    assert to_namedtuple([]) is []
    assert to_namedtuple(()) is ()
    assert to_namedtuple({}) is NamedTuple()
    assert to_namedtuple(OrderedDict()) is NamedTuple()

    # Dictionary
    assert to_namedtuple({'a': 1, 'b': 2}) is NamedTuple(a=1, b=2)
    assert to_namedtuple({'b': 2, 'a': 1}) is NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b/c': 2}) is NamedTuple(a=1, b_c=2)

# Generated at 2022-06-11 22:23:58.627506
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from .datacompy import (
        assert_equal,
        assert_not_equal,
        assert_same_type,
    )
    from .namedtupleutils import (
        _to_namedtuple,
        get_namedtuple_fields,
    )
    import string
    fields = list(string.ascii_lowercase)
    assert_same_type(list, fields)
    dic = OrderedDict()
    for field in fields:
        dic[field] = field
    assert_same_type(OrderedDict, dic)

    out = _to_namedtuple(dic)
    assert_same_type(NamedTuple, out)
    assert_equal(dic, out)
    assert_equal(fields, get_namedtuple_fields(out))

   

# Generated at 2022-06-11 22:24:07.562295
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    out = to_namedtuple(dic)
    # noinspection PyTypeChecker
    assert out == NamedTuple(a=1, b=2, c=3, d=4)

    dic = {'a': 1, 'b': 2, 'c': {'x': 'a', 'y': 'b'}, 'd': 4}
    out = to_namedtuple(dic)
    # noinspection PyTypeChecker

# Generated at 2022-06-11 22:24:18.037550
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple([dic]) == [namedtuple('NamedTuple', ('a', 'b'))(1, 2)]
    assert to_namedtuple(dic) != NamedTuple(a=1, b=2, _c=3)
    assert to_namedtuple(dic) != ({'a': 1, 'b': 2},)
    assert to_namedtuple(dic) != ([{'a': 1, 'b': 2}],)
   

# Generated at 2022-06-11 22:24:29.122008
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    def do_test(obj):
        out = to_namedtuple(obj)
        assert isinstance(out, (list, tuple, NamedTuple))
        # noinspection PyUnresolvedReferences
        if isinstance(out, tuple):
            assert len(obj) == len(out)
            for i, val in enumerate(out):
                if isinstance(val, (list, tuple, NamedTuple)):
                    new_obj = obj[i]
                    assert val is not new_obj
                    for i, j in zip(val, new_obj):
                        assert i == j
                else:
                    assert val == obj[i]
        # noinspection PyUnresolvedReferences

# Generated at 2022-06-11 22:24:37.267800
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, NamedTuple)
    assert nt.a == 1
    assert nt.b == 2
    nt2 = to_namedtuple({'c': 3})
    assert isinstance(nt2, NamedTuple)
    assert nt2.c == 3
    lst = [nt, nt2]
    lst2 = to_namedtuple(lst)
    assert isinstance(lst2, list)
    for item in lst2:
        assert isinstance(item, NamedTuple)
    dic2 = {'a': nt, 'b': nt2}
    nt3 = to_namedtuple(dic2)

# Generated at 2022-06-11 22:24:47.793814
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # flake8: noqa
    class Nt(NamedTuple):
        x: int
        y: int

    class _Test(Nt):
        __slots__ = ()

        @property
        def xy(self) -> Tuple[int, int]:
            return self.x, self.y

    class _OrderedTest(OrderedDict):
        def __init__(self, *args, **kwargs):
            OrderedDict.__init__(self, *args, **kwargs)

    class _TupleTest(Tuple):
        def __new__(cls, *args, **kwargs):
            return Tuple.__new__(cls, *args, **kwargs)


# Generated at 2022-06-11 22:24:57.319218
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Quickly check the conversion of a namedtuple to itself
    Test1 = namedtuple('Test1', 'a b c')
    obj = Test1(1, 2, 3)
    assert to_namedtuple(obj) == obj

    # Quickly check the conversion of a SimpleNamespace to a namedtuple
    Test2 = SimpleNamespace(a=1, b=2, c=3)
    obj = to_namedtuple(Test2)
    assert obj == Test1(1, 2, 3)

    # Check the default conversion of a dict to a namedtuple
    Test3 = {'a': 1, 'b': 2, 'c': 3}
    obj = to_namedtuple(Test3)
    assert obj == Test1(1, 2, 3)

    # Check a dict that is invalid for conversion
   