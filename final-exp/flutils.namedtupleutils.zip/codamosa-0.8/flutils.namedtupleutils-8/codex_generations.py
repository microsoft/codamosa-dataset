

# Generated at 2022-06-11 22:15:11.928482
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils import namedtupleutils

    test_dict = {'a': 1, 'b': 2}
    expected_dict = {'a': 1, 'b': 2}

    test_named_tuple = namedtupleutils.to_namedtuple(test_dict)

    assert hasattr(test_named_tuple, 'a') and test_named_tuple.a == expected_dict['a']
    assert hasattr(test_named_tuple, 'b') and test_named_tuple.b == expected_dict['b']

# Generated at 2022-06-11 22:15:21.303671
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections import namedtuple
    from types import SimpleNamespace
    from unittest.mock import patch
    # noinspection Mypy
    from typing import List, Tuple
    from typing import cast
    from flutils.namedtupleutils import to_namedtuple

    # Test _to_namedtuple
    _o = OrderedDict([('z', 1), ('a', 2)])
    _out = _to_namedtuple(_o)
    assert _out._fields == ('a', 'z')

    # Test to_named_tuple
    _in = {'a': 'z', 'b': 'a'}
    _out = to_namedtuple(_in)
    assert _out._fields == ('a', 'b')



# Generated at 2022-06-11 22:15:32.447251
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    dic = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}

    def p(obj):
        pprint(
            [
                a,
                eval('dir(obj)', globals={}, locals={'obj': obj})
            ]
        )

    # p(obj=dic)
    # p(obj=to_namedtuple(dic))
    # p(obj=to_namedtuple(to_namedtuple(dic)))
    assert(to_namedtuple(to_namedtuple(dic)) == to_namedtuple(dic))
    dic2 = {'d': '5', 'c': to_namedtuple(dic)}
    # p(obj=to_namedtuple(dic

# Generated at 2022-06-11 22:15:44.259879
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    obj = {
        'a': 1,
        'b': 2,
        '1a': 11,
        '_c': 0,
    }
    obj2 = {
        'a': 1,
        'b': 2,
        '1a': 11,
        '_c': 0,
        'd': {'name': 'obj2'},
    }
    obj3 = {
        'a': 1,
        'b': 2,
        '1a': 11,
        '_c': 0,
        'd': {'name': 'obj2'},
        'e': {'a': 1, 'b': 2, '1a': 11, '_c': 0,},
    }


# Generated at 2022-06-11 22:15:55.711187
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)

# Generated at 2022-06-11 22:16:06.785214
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Test to_namedtuple function with a custom class."""
    from flutils.datastructures import FrozenOrderedDict
    class NewOrderedDict(FrozenOrderedDict):
        """ A custom class inheriting from FrozenOrderedDict. """

    assert to_namedtuple({'a':1, 'b':2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(FrozenOrderedDict(a=1, b=2)) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(NewOrderedDict(a=1, b=2)) == namedtuple('NamedTuple', 'a b')(a=1, b=2)


# Generated at 2022-06-11 22:16:15.520755
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print("Testing to_namedtuple")
    lis = [1, 2, 3, 4]
    tup = (1, 2, 3, 4)
    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    dic_empty = {}
    odic = OrderedDict(a=1, b=2, c={'d': 3, 'e': 4})
    odic_empty = OrderedDict()
    odict = dict(a=1, b=2, c={'d': 3, 'e': 4})
    odict_empty = {}
    tpl = (1, 2, 3, 4)
    tpl_empty = ()
    lis_out = to_namedtuple(lis)

# Generated at 2022-06-11 22:16:24.161829
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from flutils.namedtupleutils import to_namedtuple

    obj = [[1, 2, 3], [4, 5, 6]]
    ntl: NamedTuple
    ntl = to_namedtuple(obj)
    assert ntl == [[1, 2, 3], [4, 5, 6]]

    obj = (('a', [1, 2, 3]), ('b', [4, 5, 6]))
    ntl: NamedTuple
    ntl = to_namedtuple(obj)
    assert ntl == (NamedTuple(a=[1, 2, 3], b=[4, 5, 6]),)

    obj = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    ntl: List[NamedTuple]

# Generated at 2022-06-11 22:16:32.142090
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple((1, 2, 3)) == tuple([1, 2, 3])
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == NamedTuple(a=1, b=2)
    assert to_namedtuple(NamedTuple(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': {'c': 3}}) == NamedTuple(a=1, b=NamedTuple(c=3))
    assert to

# Generated at 2022-06-11 22:16:40.960293
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from operator import attrgetter
    from collections import (
        OrderedDict,
        namedtuple
    )

    class Mixed(NamedTuple):
        a: str
        b: int
        c = None
        d: OrderedDict = OrderedDict([
            ('e', 3),
            ('f', 4),
        ])
        _g: int = 5

    _Mixed = to_namedtuple(Mixed)
    assert _Mixed.a is None
    assert _Mixed.b == 0
    assert _Mixed.c is None
    assert _Mixed.d == (_Mixed.d.e, _Mixed.d.f)
    try:
        _Mixed._g
    except AttributeError:
        pass

# Generated at 2022-06-11 22:16:55.728220
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from pprint import pprint
    from collections import OrderedDict
    from types import SimpleNamespace

    dic = {'a': 1, 'b': 2, 'c': 3}
    res = to_namedtuple(dic)
    assert res == namedtuple('NamedTuple', 'a b c')(a=1, b=2, c=3)

    dic['d_1'] = ['a', 'b', 'c']
    res = to_namedtuple(dic)
    assert res == namedtuple('NamedTuple', 'a b c d_1')(a=1, b=2, c=3, d_1=['a', 'b', 'c'])
    assert isinstance(res.d_1, list)


# Generated at 2022-06-11 22:17:03.515847
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    import pytest
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

    dic = OrderedDict([('ad', 'bd'), ('bc', 'dc')])
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out._fields == ('ad', 'bc')
    assert out.ad == 'bd'
    assert out.bc == 'dc'

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_named

# Generated at 2022-06-11 22:17:05.004404
# Unit test for function to_namedtuple
def test_to_namedtuple(): # noqa: D102
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:17:16.267325
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import (
        Sequence,
        Mapping,
    )
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from functools import singledispatch
    from types import SimpleNamespace
    import pytest

    @singledispatch
    def _to_namedtuple(obj):
        raise TypeError(
            "Can convert only 'list', 'dict' to a NamedTuple; "
            "got: (%r) %s" % (type(obj).__name__, obj)
        )

    @_to_namedtuple.register(Mapping)
    def _(obj):
        keys = []
        for key in obj:
            if hasattr(key, 'capitalize'):
                key = str(key)
               

# Generated at 2022-06-11 22:17:25.552237
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert dic == {'a': 1, 'b': 2}
    assert to_namedtuple([1, 2]) == [1, 2]
    assert to_namedtuple(dic.items()) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dic.values()) == [1, 2]

    dic = OrderedDict()
    dic['a'] = 1

# Generated at 2022-06-11 22:17:36.846548
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test for function: to_namedtuple."""
    from typing import List, Optional, Tuple

    from flutils.namedtupleutils import to_namedtuple
    from flutils.tests import make_validate_test, run_validate_tests

    @singledispatch
    def _check(
            obj: Any,
    ) -> None:
        if isinstance(obj, (List, Tuple)):
            for item in cast(Iterable, obj):
                _check(item)
        elif isinstance(obj, SimpleNamespace):
            _check(obj.__dict__)


# Generated at 2022-06-11 22:17:47.562468
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pformat

    data = {
        'a': 1,
        'b': '2',
        'c': {
            'd': [
                'e',
                {'f': 'g'}
            ]
        },
        'h': [
            'i',
            'j',
        ]
    }
    obj = to_namedtuple(data)
    assert obj.a == 1
    assert obj.b == '2'
    assert type(obj.c) == namedtuple('NamedTuple', 'd')().__class__
    assert obj.c.d == ['e', {'f': 'g'}]
    assert obj.h == ['i', 'j']

    print(pformat(obj))


# Generated at 2022-06-11 22:17:59.463090
# Unit test for function to_namedtuple
def test_to_namedtuple():

    obj = {
        'a': 1,
        '_a': 1,
        'a2': {
            'a': 1,
            'b': 2,
        },
        'b': 2,
        'b2': {
            'a': 1,
            'b': 2,
        },
        'c': 3,
        '_c': 3,
        'c2': {
            'a': 1,
            'b': 2,
        },
        'd': 4,
        'd2': {
            'a': 1,
            'b': 2,
        },
    }
    namedtupleobj = to_namedtuple(obj)
    assert isinstance(namedtupleobj, NamedTuple)
    assert isinstance(namedtupleobj.a2, NamedTuple)

# Generated at 2022-06-11 22:18:08.334545
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple(tuple([])) == ()
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict([('1', 1), ('2', 2)])) == \
           NamedTuple(**OrderedDict([('1', 1), ('2', 2)]))
    assert to_namedtuple({'a': {'1': 1, '2': 2}, 'b': 3}) == \
           NamedTuple(a=NamedTuple(**OrderedDict([('1', 1), ('2', 2)])), b=3)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple

# Generated at 2022-06-11 22:18:13.150969
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _IN = {
        'a': 1,
        'b': 2
    }
    _OUT = NamedTuple(a=1, b=2)
    _RES = to_namedtuple(_IN)
    assert _RES == _OUT



# Generated at 2022-06-11 22:18:27.751399
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest


# Generated at 2022-06-11 22:18:36.649089
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyShadowingNames
    def _assert(
            obj: _AllowedTypes,
            expected: _AllowedTypes,
    ) -> None:
        if hasattr(obj, '_fields'):
            obj = list(obj)
        if hasattr(expected, '_fields'):
            expected = list(expected)
        assert to_namedtuple(obj) == expected

    _assert(1, 1)
    _assert('a', 'a')
    _assert({'a': 1}, {'a': 1})
    _assert([], [])
    _assert(tuple(), tuple())
    _assert(
        {'a': 1, '_b': 2},
        namedtuple('NamedTuple', ['a'])(1)
    )

# Generated at 2022-06-11 22:18:45.919175
# Unit test for function to_namedtuple
def test_to_namedtuple():

    def test_raise_TypeError(obj):
        """Unit test to_namedtuple raises TypeError.

        Args:
            obj: The object to be passed to to_namedtuple.

        Actually, the raised error is not a TypeError but the one that
        comes up when an object has no _to_namedtuple.register(type)
        definition.
        """

        # noinspection PyBroadException
        try:
            to_namedtuple(obj)
            raise AssertionError(obj)
        except TypeError as err:
            assert isinstance(err, TypeError)

    test_raise_TypeError(100)
    test_raise_TypeError(None)
    test_raise_TypeError(set())
    test_raise_TypeError(dict())
    test_raise_TypeError(tuple())
   

# Generated at 2022-06-11 22:18:50.533079
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import NamedTuple

    # create the basic test case
    Test = NamedTuple('Test', [('a', int), ('b', str)])
    t = Test(1, 'Hello')

    # test this
    out = to_namedtuple(t)
    assert out.a == 1
    assert out.b == 'Hello'

    # add a tuple
    Test = NamedTuple('Test', [('a', int), ('b', str), ('c', tuple)])
    t = Test(1, 'Hello', (1, 2, 3))

    # test this
    out = to_namedtuple(t)
    assert out.a == 1
    assert out.b == 'Hello'
    assert out.c == (1, 2, 3)

    # make a list of the previous test

# Generated at 2022-06-11 22:19:02.978980
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2,
    }
    res = to_namedtuple(dic)
    assert res.a == dic['a']
    assert res.b == dic['b']
    dic = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
        },
    }
    res = to_namedtuple(dic)
    assert res.a == dic['a']
    assert res.b == dic['b']
    assert res.c.d == dic['c']['d']
    assert res.c.e == dic['c']['e']

# Generated at 2022-06-11 22:19:09.857433
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic1 = {'a': {'c': 1, 'd': 2}, 'b': 3}
    nt1 = to_namedtuple(dic1)
    assert isinstance(nt1, NamedTuple)
    assert nt1 == (NamedTuple(c=1, d=2), 3)
    dic2 = OrderedDict([('a', 1), ('b', 2)])
    nt2 = to_namedtuple(dic2)
    assert isinstance(nt2, NamedTuple)
    assert nt2 == (1, 2)
    sn1 = SimpleNamespace(a=1, b=2)
    nt3 = to_namedtuple(sn1)
    assert isinstance(nt3, NamedTuple)
    assert nt3 == (1, 2)
   

# Generated at 2022-06-11 22:19:15.678517
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from dataclasses import dataclass
    from typing import Optional, Union

    # new_dic is NOT a Mapping.
    @dataclass
    class new_dic:
        a: int = 1
        b: int = 3
        c: Optional[Union[int, str]] = None
        d: Optional[int] = None
        e: str = 'e'
        f: Optional[float] = None

    odic = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 'c'),
        ('d', None),
        ('e', 'e'),
        ('f', None),
    ])
    # noinspection SpellCheckingInspection

# Generated at 2022-06-11 22:19:27.404481
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class ToNamedTupleTests(unittest.TestCase):

        def test_to_namedtuple_raises_syntax_error_given_bad_identifier(self):
            with self.assertRaises(SyntaxError):
                to_namedtuple({'1a': 1})

        def test_to_namedtuple_raises_syntax_error_given_double_underscore(self):
            with self.assertRaises(SyntaxError):
                to_namedtuple({'__a': 1})

        def test_to_namedtuple_raises_syntax_error_given_hyphen(self):
            with self.assertRaises(SyntaxError):
                to_namedtuple({'-a': 1})


# Generated at 2022-06-11 22:19:36.896077
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    dic_expected = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dic) == dic_expected
    lis = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 5, 'b': 6}]
    lis_expected = [dic_expected] * 3
    assert to_namedtuple(lis) == lis_expected
    nam = namedtuple('NamedTuple', 'a b')(a=1, b=2)
    nam_expected = dic_expected
    assert to_namedtuple(nam) == nam_expected

# Generated at 2022-06-11 22:19:44.702827
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple([{'a': {'b': 3}}]) == [NamedTuple(a=NamedTuple(b=3))]
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple([{'a': 1, 'b': [{'c': 'd'}]}]) == [
        NamedTuple(a=1, b=[NamedTuple(c='d')])
    ]

# Generated at 2022-06-11 22:19:56.988769
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    namedtup: NamedTuple = to_namedtuple(dic)
    assert namedtup.a == 1
    assert namedtup.b == 2
    print('to_namedtuple passes all tests')


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:20:04.022424
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:20:16.292875
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils as mod


# Generated at 2022-06-11 22:20:28.160912
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from datetime import datetime
    from json import loads

    from flutils.collectionsutils import DotDict
    from flutils.datautils import (
        JsonSerializable,
        Struct,
    )
    from flutils.log import get_logger
    from flutils.namedtupleutils import (
        NamedTupleSerializable,
        to_namedtuple,
    )


    class NoopSerializable(JsonSerializable):

        def __init__(self, value: Any, **kwargs: Any):
            super().__init__(**kwargs)
            self.value = value


    class JsonSerializableTests(unittest.TestCase):

        def setUp(self):
            self.logger = get_logger(type(self).__name__)
           

# Generated at 2022-06-11 22:20:38.787440
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    class TestClass:
        pass


# Generated at 2022-06-11 22:20:44.115854
# Unit test for function to_namedtuple
def test_to_namedtuple():
    x = to_namedtuple(OrderedDict({'a': 1, 'b': 2}))
    assert x.a == 1
    assert x.b == 2

    x = to_namedtuple(OrderedDict({'b': 2, 'a': 1}))
    assert x.a == 1
    assert x.b == 2

    x = to_namedtuple(SimpleNamespace(a=1, b=2))
    assert x.a == 1
    assert x.b == 2

    x = to_namedtuple(SimpleNamespace(b=2, a=1))
    assert x.a == 1
    assert x.b == 2

    x = to_namedtuple([{'a': 1, 'b': 2}, {'a': 3, 'b': 4}])

# Generated at 2022-06-11 22:20:51.680945
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.py3compat import is_python3

    assert isinstance(
        to_namedtuple([]),
        list
    )
    assert isinstance(
        to_namedtuple(()),
        tuple
    )

    if is_python3:
        assert isinstance(
            to_namedtuple({}),
            dict
        )
    else:
        assert isinstance(
            to_namedtuple({}),
            dict
        )

    assert isinstance(
        to_namedtuple({'a': 1, 'b': 2}),
        namedtuple
    )


# Generated at 2022-06-11 22:21:01.236044
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    obj = {
        'c': 3,
        '_d': 4,
        'f': {
            'g': 5,
            'h': 6,
        },
        'i': [7, 8, 9],
    }
    out = to_namedtuple(obj)
    assert out.c == 3
    assert hasattr(out, '_d') is False
    assert out.f.g == 5
    assert out.f.h == 6
    assert out.i[2] == 9


# Generated at 2022-06-11 22:21:12.754571
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnreachableCode
    if False:
        # noinspection PyUnresolvedReferences
        from flutils.namedtupleutils import *

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    od = OrderedDict(dic)
    assert to_namedtuple(od) == NamedTuple(a=1, b=2)

    nt = namedtuple('nt', dic.keys())(*dic.values())
    assert to_namedtuple(nt) == NamedTuple(a=1, b=2)

    sn = SimpleNamespace(**dic)
    assert to_namedtuple(sn) == NamedTuple(a=1, b=2)



# Generated at 2022-06-11 22:21:20.481023
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    # Test if a single argument is given
    def _single_arg(arg):
        return isinstance(arg, str) is True

    # Test if it has an attribute
    def _has_attr(arg, attr):
        return hasattr(arg, attr) is True

    # Make sure they are numbers
    def _is_num(arg):
        if not isinstance(arg, (float, int, tuple, list)):
            return False
        if isinstance(arg, (tuple, list)):
            for i in arg:
                if not isinstance(i, (float, int)):
                    return False
        return True

    def _is_num_tup(arg):
        if (isinstance(arg, tuple) is False):
            return False

# Generated at 2022-06-11 22:21:46.972795
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    nt = namedtuple('test', 'a b')
    assert to_namedtuple(dic) == nt(a=1, b=2)
    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = namedtuple('test', 'a b c')
    assert to_namedtuple(dic) == nt(a=1, b=2, c=3)
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    nt = namedtuple('test', 'a b d c')

# Generated at 2022-06-11 22:21:53.263255
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {
        'a': 1,
        'b': (1, {'e': [{'h': 9}, {'i': 10}]}, 3),
        'c': {'d': [{'f': 4}, {'g': 5}]}
    }
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b[0] == 1
    assert out.b[1].e[0].h == 9
    assert out.b[1].e[1].i == 10
    assert out.b[2] == 3
    assert out.c.d[0].f == 4
    assert out.c.d[1].g == 5


# Generated at 2022-06-11 22:22:02.982916
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test1 = {'a': 1, 'b': 2}
    test2 = [1, 2, 'a', test1]
    test3 = {'test2': test2}
    test4 = [test1, test2, test3]
    out = to_namedtuple(test4)
    for idx, item in enumerate(out):
        if idx == 0:
            assert item.a == 1
            assert item.b == 2
        elif idx == 1:
            assert item[0] == 1
            assert item[2] == 'a'
            assert item[3].a == 1
            assert item[3].b == 2
        elif idx == 2:
            assert item.test2[0] == 1
            assert item.test2[3].a == 1
            assert item.test2

# Generated at 2022-06-11 22:22:12.680146
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    from pathlib import Path
    from flutils.namedtupleutils import to_namedtuple

    base = Path(__file__).parent.parent
    fp = base.joinpath('tests', 'data', 'dicts', 'sample_dicts.json')
    with fp.open('r') as fh:
        dic = json.load(fh)

    out = to_namedtuple(dic)
    assert isinstance(out, SimpleNamespace)
    assert hasattr(out, 'version') and out.version == '2.0'
    assert hasattr(out, 'contacts')
    assert isinstance(out.contacts, SimpleNamespace)
    assert hasattr(out.contacts, 'primary') and isinstance(
        out.contacts.primary, SimpleNamespace
    )


# Generated at 2022-06-11 22:22:23.498608
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.tests.namedtupleutils import (
        mock_dict_obj1,
        mock_dict_obj2,
        mock_list_namespace_obj,
        mock_list_tuple_obj,
        mock_list_namedtuple_obj,
    )


# Generated at 2022-06-11 22:22:32.646658
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    assert to_namedtuple(1) == 1
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert to_namedtuple(['a']) == ['a']
    assert to_namedtuple(('a',)) == ('a',)
    assert to_namedtuple([[['a']]]) == [[['a']]]
    assert to_namedtuple(((('a',),),)) == ((('a',),),)

# Generated at 2022-06-11 22:22:34.461365
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    return

# Generated at 2022-06-11 22:22:41.990814
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class DummyClass:
        pass
    # noinspection PyTypeChecker
    out: bool = True
    try:
        out = out and to_namedtuple(DummyClass())
    except TypeError:
        pass
    out = out and (to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(1, 2))
    out = out and (to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == namedtuple('NamedTuple', ('a', 'b'))(1, 2))
    out = out and (to_namedtuple({'_a': 1, '_b': 2, '_c': 3}) == namedtuple('NamedTuple', '')())

# Generated at 2022-06-11 22:22:52.818478
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = OrderedDict([
        ('a', {'b': {'c': 1, 'd': 2}, 'e': 'f'}),
        ('g', [1, {'h': 3}, [4, 5], (6, 7, 8)]),
    ])
    assert to_namedtuple(dic) == \
        namedtuple('NamedTuple', 'a g')(
            a=namedtuple('NamedTuple', 'b e')(
                b=namedtuple('NamedTuple', 'c d')(
                    c=1,
                    d=2,
                ),
                e='f',
            ),
            g=[1, namedtuple('NamedTuple', 'h')(
                h=3), [4, 5], (6, 7, 8)],
        )


# Generated at 2022-06-11 22:22:58.854202
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(()) == ()
    assert to_namedtuple([]) == []

    assert to_namedtuple([{}]) == [()]
    assert to_namedtuple([{'a': 1}]) == [NamedTuple(a=1)]
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]

    assert to_namedtuple(([{}])) == ([()],)
    assert to_namedtuple(([{'a': 1}])) == ([NamedTuple(a=1)],)
    assert to_namedtuple(([{'a': 1, 'b': 2}])) == ([NamedTuple(a=1, b=2)],)

    assert to_namedt

# Generated at 2022-06-11 22:23:36.352520
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    assert obj == (1, 2)

    dic = OrderedDict()
    dic['b'] = 2
    dic['a'] = 1
    obj = to_namedtuple(dic)
    assert obj.b == 2
    assert obj.a == 1
    assert obj == (2, 1)

    dic = {'a': 1, 'b': {'c': 2}}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b.c == 2
    assert obj == (1, (2,))


# Generated at 2022-06-11 22:23:45.639753
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(dict(a=1, b=2))
    assert to_namedtuple(dict(a=1, b=2)) == to_namedtuple(OrderedDict(a=1, b=2))
    assert to_namedtuple(dict(a=1, b=2)) == to_namedtuple(SimpleNamespace(a=1, b=2))
    assert to_namedtuple(dict(a=1, _b=2)) == to_namedtuple(SimpleNamespace(a=1, _b=2))
    # noinspection PyTypeChecker

# Generated at 2022-06-11 22:23:52.519906
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier
    from sys import version_info
    from typing import NamedTuple

    obj = [1, 2, 3, 4]
    ret: list = to_namedtuple(obj)
    assert isinstance(ret, list)
    assert ret == obj

    obj = (1, 2, 3, 4)
    ret: tuple = to_namedtuple(obj)
    assert isinstance(ret, tuple)
    assert ret == obj

    dic = {'a': 1, 'b': 2}
    ret: NamedTuple = to_namedtuple(dic)
    assert isinstance(ret, namedtuple)
    assert ret.a == 1
    assert ret.b == 2

# Generated at 2022-06-11 22:23:58.628400
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(
        {'a': {'b': 1}}
    ) == namedtuple('a', ['b'])(b=1)

    assert to_namedtuple(
        {'a': {'b': 1, 'c': 2}}
    ) == namedtuple('a', ['b', 'c'])(b=1, c=2)

    assert to_namedtuple(
        {'a': 1, 'b': 2}
    ) == namedtuple('a', ['a', 'b'])(a=1, b=2)


# Generated at 2022-06-11 22:24:07.562933
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing function to_namedtuple')
    from flutils.namedtupleutils import to_namedtuple

    # Various failure modes
    d = to_namedtuple('test')
    assert d == 'test'
    # noinspection SpellCheckingInspection
    d = to_namedtuple('tes_t')
    assert d == 'tes_t'

    try:
        to_namedtuple(1)
    except TypeError:
        pass
    else:
        assert False

    try:
        to_namedtuple(None)
    except TypeError:
        pass
    else:
        assert False

    try:
        to_namedtuple(object())
    except TypeError:
        pass
    else:
        assert False

    # namedtuple to namedtuple

# Generated at 2022-06-11 22:24:11.925265
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    Test to_namedtuple().
    """
    assert to_namedtuple({'a': 1, 'b': 2}) == (1, 2)

# Generated at 2022-06-11 22:24:20.602711
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from testfixtures import compare

    # Function under test
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2, 'c': 3}

    # Basic function
    actual = to_namedtuple(dic)
    compare(actual, expected=dic)
    compare(type(actual).__name__, 'NamedTuple')
    compare(actual.a, 1)
    compare(actual.b, 2)
    compare(actual.c, 3)

    # Basic function with OrderedDict
    odic = OrderedDict()
    odic['c'] = 3
    odic['b'] = 2
    odic['a'] = 1

    actual = to_namedtuple(odic)

# Generated at 2022-06-11 22:24:31.764400
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    # assert to_namedtuple(()) == ()
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple(OrderedDict()) == NamedTuple()
    assert to_namedtuple(SimpleNamespace()) == NamedTuple()

    val = 'test'
    assert to_namedtuple(val) == val
    assert to_namedtuple(SimpleNamespace(test=val)) == NamedTuple(test=val)
    val = [val]
    assert to_namedtuple(val) == val
    assert to_namedtuple(SimpleNamespace(test=val)) == NamedTuple(test=val)
    val = (val,)
    assert to_namedtuple(val) == val

# Generated at 2022-06-11 22:24:38.436174
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from collections.abc import Sequence
    from types import SimpleNamespace

    assert to_namedtuple({'a': 1, 'b': 'b'}) == namedtuple(
        'NamedTuple', ['a', 'b']
    )(1, 'b')
    assert to_namedtuple({'a': 1, 'b': 'b', '_c': 'c'}) == namedtuple(
        'NamedTuple', ['a', 'b']
    )(1, 'b')
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 'b')])) == namedtuple(
        'NamedTuple', ['a', 'b']
    )(1, 'b')
    assert to_named

# Generated at 2022-06-11 22:24:47.903241
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([[{'a': {'b': 1}}]]) == [NamedTuple(a=NamedTuple(b=1))]
    assert to_namedtuple({'a': {'b': 1}}) == NamedTuple(a=1, b=1)
    assert to_namedtuple([{'a': {'b': 1}}]) == [NamedTuple(a=NamedTuple(b=1))]
    assert to_namedtuple([{'a': {'b': 1}}]) == [NamedTuple(a=NamedTuple(b=1))]
    assert to_namedtuple(tuple([{'a': {'b': 1}}])) == (
        [NamedTuple(a=NamedTuple(b=1))],
    )