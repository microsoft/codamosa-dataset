

# Generated at 2022-06-11 22:15:17.196992
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == NamedTuple(a=1, b=2)  # type: ignore[comparison-overlap]

    dic = {'a': {'c': 1, 'd': 2}, 'b': 2}
    out = to_namedtuple(dic)
    assert out == NamedTuple(a=NamedTuple(c=1, d=2), b=2)  # type: ignore[comparison-overlap]

   

# Generated at 2022-06-11 22:15:22.316894
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    assert to_namedtuple([]) == tuple()
    assert to_namedtuple(tuple()) == tuple()
    assert to_namedtuple(()) == tuple()
    assert to_namedtuple(['a']) == ('a',)
    assert to_namedtuple([1]) == (1,)
    assert to_namedtuple([1, 2]) == (1, 2)
    assert to_namedtuple(['a', 'b']) == ('a', 'b')
    assert to_namedtuple([1, 'b']) == (1, 'b')
    assert to_namedtuple([1, 2, 3]) == (1, 2, 3)

# Generated at 2022-06-11 22:15:33.068818
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tup = (1, 2)
    out = to_namedtuple(tup)
    assert out == (1, 2)

    tup = (1, (2, 3))
    out = to_namedtuple(tup)
    assert out == (1, (2, 3))

    tup = (1, {'a': 2, 'b': 3})
    out = to_namedtuple(tup)
    assert out == (1, NamedTuple(a=2, b=3))

    tup = {'a': 1, 'b': 2}
    out = to_namedtuple(tup)
    assert out == NamedTuple(a=1, b=2)

    tup = {1: 'a', 2: 'b'}
    out = to_namedtuple(tup)

# Generated at 2022-06-11 22:15:44.816942
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    assert to_namedtuple(dict(a=1, b=2)) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple(dict(a=1, b=2, _c=3)) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple(OrderedDict([('b', 2), ('a', 1)])) == namedtuple('NamedTuple', 'b a')(2, 1)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == namedtuple('NamedTuple', 'a b')(1, 2)

# Generated at 2022-06-11 22:15:56.512839
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic={'a': 1, 'b': 2}
    m=to_namedtuple(dic)
    assert m.a,1
    assert m.b,2
    de = OrderedDict()
    de["a"] = 1
    de["b"] = 2
    m2 = to_namedtuple(de)
    assert m2.a,1
    assert m2.b,2
    l=[1,2,3,4]
    m3 = to_namedtuple(l)
    assert m3[0],1
    assert m3[1],2
    assert m3[2],3
    assert m3[3],4
    t=(1,2,3,4)
    m4 = to_namedtuple(t)
    assert m4[0],1
    assert m4

# Generated at 2022-06-11 22:16:08.372451
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import tempfile
    import unittest

    # noinspection PyUnresolvedReferences
    from flutils.namedtupleutils import (
        NamedTuple,
        to_namedtuple,
    )

    class _TestToNamedTuple(unittest.TestCase):
        """Unit tests for function ``to_namedtuple`` in namedtupleutils.py."""

        def test_to_namedtuple_simple(self):
            """Test function to_namedtuple with a simple dictionary."""
            dic = dict(a=1, b=dict(c=3), d=4)
            out = to_namedtuple(dic)

# Generated at 2022-06-11 22:16:15.971206
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple"""
    import copy
    import collections

    def assert_converted(obj, expected):
        """Assert obj converted equals expected.

        If expected is a dictionary, convert it to a
        :obj:`NamedTuple <collections.NamedTuple>`.

        Args:
            obj: The input object for :func:`to_namedtuple`
            expected: The expected output from
                :func:`to_namedtuple`

        Raises:
            AssertionError: If the given ``obj`` is not converted to
                ``expected``.
        """
        if isinstance(expected, collections.abc.Mapping):
            expected = collections.namedtuple(
                'NamedTuple',
                expected.keys(),
            )(*expected.values())
        assert to

# Generated at 2022-06-11 22:16:25.374438
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = OrderedDict()
    obj['a'] = 1
    obj['b'] = {'c': 2}
    obj['d'] = [3, 4]
    obj['e'] = (5, 6)
    obj['g'] = {'h': 7}
    obj['g']['i'] = 8
    obj['g']['j'] = {'k': 9}
    expect = OrderedDict()
    expect['a'] = 1
    expect['b'] = {'c': 2}
    expect['d'] = [3, 4]
    expect['e'] = (5, 6)
    expect['g'] = {'h': 7, 'i': 8, 'j': {'k': 9}}
    nt: namedtuple = to_namedtuple(obj)

# Generated at 2022-06-11 22:16:32.975902
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from flutils.namedtupleutils import to_namedtuple
    from flutils.namedtupleutils import NamedTuple as OriginalNamedTuple
    from collections import OrderedDict

    class NamedTuple(OriginalNamedTuple):
        __slots__ = ()
        _fields: Tuple[str, ...]

        def __repr__(self):
            items = ('%s=%r' % (k, getattr(self, k)) for k in self._fields)
            return '{}({})'.format(self.__class__.__name__, ', '.join(items))

        def __str__(self):
            return repr(self)


    class Test_to_namedtuple(unittest.TestCase):
        """Test to_namedtuple"""

# Generated at 2022-06-11 22:16:41.299269
# Unit test for function to_namedtuple
def test_to_namedtuple():
    name = 'to_namedtuple'
    ta = None


# Generated at 2022-06-11 22:16:55.862952
# Unit test for function to_namedtuple
def test_to_namedtuple():

    # Dictionary
    dic = {'a': 1, 'b': 2}
    expected = NamedTuple(a=1, b=2)
    assert to_namedtuple(dic) == expected

    # OrderedDict
    from collections import OrderedDict
    odic = OrderedDict([('a', 1), ('b', 2)])
    expected = NamedTuple(a=1, b=2)
    assert to_namedtuple(odic) == expected

    # OrderedDict with complicated values
    odic = OrderedDict([('a', 1), ('b', 'xx')])
    expected = NamedTuple(a=1, b='xx')
    assert to_namedtuple(odic) == expected

    # Dictionary with complicated values

# Generated at 2022-06-11 22:17:03.595922
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    od = OrderedDict(tuple(reversed(list(dic.items()))))
    assert to_namedtuple(od) == namedtuple('NamedTuple', 'b a')(b=2, a=1)
    ns = SimpleNamespace(**dic)
    assert to_namedtuple(ns) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dic, True) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple

# Generated at 2022-06-11 22:17:11.020410
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    target = [
        {'a': 1},
        {'b': 2},
        {'c': 3}
    ]
    expected = [
        NamedTuple(a=1),
        NamedTuple(b=2),
        NamedTuple(c=3)
    ]
    actual = to_namedtuple(target)
    assert actual == expected

    target = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3)
    ])
    expected = NamedTuple(a=1, b=2, c=3)
    actual = to_namedtuple(target)
    assert actual == expected


# Generated at 2022-06-11 22:17:20.296472
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}, {1: 2, 'b': 3}]
    b = to_namedtuple(a)
    assert b[0] == NamedTuple(a=1, b=2)
    assert b[1] == NamedTuple(a=1, b=2)
    assert b[2] == {1: 2, 'b': 3}
    assert b == [NamedTuple(a=1, b=2), NamedTuple(a=1, b=2), {1: 2, 'b': 3}]

    c = {'a': {'a': 1}, 'b': 2, 'c': 3}
    d = to_namedtuple(c)

# Generated at 2022-06-11 22:17:28.193964
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple([{}]) == [NamedTuple()]
    assert to_namedtuple(dic={'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)

# Generated at 2022-06-11 22:17:37.557275
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import is_namedtuple

    # Test dictionary
    obj = {'a': 1, 'b': 2}
    out = to_namedtuple(obj)
    assert is_namedtuple(out), 'Should be a namedtuple'
    assert out.a == 1, 'Should be 1'
    assert out.b == 2, 'Should be 2'
    assert out != obj, 'Should not be the same object'

    # Test ordered dictionary
    obj = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    out = to_namedtuple(obj)
    assert out[0] == 1, 'Should be 1'


# Generated at 2022-06-11 22:17:48.113902
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    assert to_namedtuple({}) == NamedTuple()
    out = to_namedtuple({'a': 1})
    assert out.a == 1
    out = to_namedtuple({'a': 1, 'b': 2})
    assert out.a == 1
    assert out.b == 2
    out = to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))
    assert out.a == 1
    assert out.b == 2
    out = to_namedtuple({'1a': 1})
    assert out['1a'] == 1
    out = to_namedtuple({'a_1': 1})
    assert out['a_1'] == 1

# Generated at 2022-06-11 22:18:00.007385
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class Test:
        a: str

        def __init__(self, a: str):
            self.a = a

    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert type(nt) == namedtuple('NamedTuple', 'a b')
    dic = dict(**nt._asdict())
    assert dic['a'] == 1
    assert dic['b'] == 2
    dic = OrderedDict([('a', 1), ('b', 2)])
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2

# Generated at 2022-06-11 22:18:08.581891
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from itertools import chain

    from pytest import raises
    from flutils.namedtupleutils import to_namedtuple

    # Test single conversion
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'Assume': 1, 'b': 2}) == namedtuple('NamedTuple', 'b Assume')(b=2, Assume=1)
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(a=1)
    assert to_namedtuple({'_a': 1}) == namedtuple('NamedTuple', '')()
    assert to_namedt

# Generated at 2022-06-11 22:18:18.214232
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections

    test_dict = {
        'a': 1,
        'b': 2
    }
    expected_dict = collections.namedtuple('NamedTuple', ['a', 'b'])(
        a=1, b=2
    )
    assert to_namedtuple(test_dict) == expected_dict
    test_ordered_dict = collections.OrderedDict()
    test_ordered_dict['a'] = 1
    test_ordered_dict['b'] = 2
    expected_ordered_dict = collections.namedtuple('NamedTuple', ['a', 'b'])(
        a=1, b=2
    )
    assert to_namedtuple(test_ordered_dict) == expected_ordered_dict
    test_list = [{'a': 1, 'b': 2}]
    expected

# Generated at 2022-06-11 22:18:32.651924
# Unit test for function to_namedtuple
def test_to_namedtuple():

    from collections import OrderedDict
    from types import SimpleNamespace

    # the function to_namedtuple is tested by itself

    # the function that is the dispatch function
    # itself is tested in the test_to_namedtuple_dispatch module

    assert to_namedtuple([]) == []

    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple([1, 2, 3]) == (1, 2, 3)
    assert to_namedtuple(tuple([1, 2, 3])) == (1, 2, 3)
    assert to_namedtuple(list([1, 2, 3])) == (1, 2, 3)

    assert to_namedtuple([[1, 2, 3]]) == ([1, 2, 3],)

# Generated at 2022-06-11 22:18:38.960322
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:18:48.886162
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection SpellCheckingInspection
    aa = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5,
                'h': 6,
                'i': {'j': 7}
            }
        },
        '_j': 8
    }
    NamedTuple = to_namedtuple(aa)
    assert isinstance(NamedTuple, namedtuple)
    assert hasattr(NamedTuple, 'a')
    assert hasattr(NamedTuple, 'b')
    assert hasattr(NamedTuple, 'c')
    assert not hasattr(NamedTuple, '_j')

# Generated at 2022-06-11 22:18:56.829870
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import unittest

    from collections import OrderedDict

    from flutils.testingutils import EnhancedTestCase

    class Test_to_namedtuple(EnhancedTestCase):
        def setUp(self) -> None:
            self.module = sys.modules[__name__]

        def test_to_namedtuple(self):
            obj = OrderedDict([
                ('a', 1),
                ('b', 2),
            ])
            rtn = to_namedtuple(obj)
            self.assertEqual(rtn, NamedTuple(a=1, b=2))

        def test_to_namedtuple_empty(self):
            rtn = to_namedtuple({})
            self.assertEqual(rtn, NamedTuple())


# Generated at 2022-06-11 22:19:06.683482
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test a simple NamedTuple
    assert to_namedtuple({'a': 4, 'b': 5, 'c': 6}) == \
        namedtuple('nt', 'a b c')(4, 5, 6)
    # Test a list
    assert to_namedtuple(['a', 'b', 'c']) == ['a', 'b', 'c']
    # Test a tuple
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    # Test a tuple of NamedTuple's
    assert to_namedtuple(
        (1, {'a': 4, 'b': 5, 'c': 6}, 'c')
    ) == (1, namedtuple('nt', 'a b c')(4, 5, 6), 'c')
    # Test a list of NamedT

# Generated at 2022-06-11 22:19:17.442189
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.py3utils import unicode
    def make_test():
        dic = {
            'a': 1,
            'b': {'c': 3},
        }
        return dic

    def do_test(dic):
        dic = {
            'a': 1,
            'b': {'c': 3},
        }
        nt = to_namedtuple(dic)
        assert nt.a == 1
        assert nt.b.c == 3
        nt.a = 5

        nt.b.c = 7
        assert nt.b.c == 7


# Generated at 2022-06-11 22:19:28.576686
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils import namedtupleutils
    from flutils.namedtupleutils import to_namedtuple
    import collections
    import pytest
    assert to_namedtuple([[{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]]) == [
        namedtupleutils.NamedTuple(a=1, b=2),
        namedtupleutils.NamedTuple(a=3, b=4)
    ]
    assert to_namedtuple([[{'a': 1, 'b': [{'a': 2, 'b': 3}]}]]) == [
        namedtupleutils.NamedTuple(a=1, b=[
            namedtupleutils.NamedTuple(a=2, b=3)
        ])
    ]
    assert to_named

# Generated at 2022-06-11 22:19:40.433368
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': {1, 2}}
    assert to_namedtuple(dic) == NamedTuple(a=1, b={1, 2})

    dic = {'a': 1, 'b': '2'}
    assert to_namedtuple(dic) == NamedTuple(a=1, b='2')

    dic = {'a': 1, 'b': [1, 2]}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=[1, 2])


# Generated at 2022-06-11 22:19:52.457906
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    import sys

    if sys.version_info > (3, 8, 0):
        from unittest.mock import Mock
    else:
        from mock import Mock

    from json.decoder import JSONDecodeError

    from ..namedtupleutils import to_namedtuple

    def test(
            to_name_tup: Any,
            expected: Any,
            _json_dumps: Any = Mock(),
            _json_loads: Any = Mock()
    ) -> None:
        # noinspection PyProtectedMember
        _json_loads.return_value = json.loads(json.dumps(to_name_tup))
        _json_dumps.return_value = json.dumps(expected)
        actual = to_namedtuple(to_name_tup)
        expected = json

# Generated at 2022-06-11 22:20:01.805553
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """
    test_to_namedtuple
    """
    # noinspection PyUnusedLocal
    def _test_cnvrt(
            obj: _AllowedTypes,
            should_raise: Union[bool, TypeError],
            expected: Any = None
    ) -> bool:
        """
         test_cnvrt
         """
        if should_raise is False:
            result = to_namedtuple(obj)
            # noinspection PyChainedComparisons
            status = result is not None and result == expected
            assert status, (obj, repr(result))

# Generated at 2022-06-11 22:20:18.973205
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic = OrderedDict([
        ('d', 4),
        ('c', 3),
        ('b', 2),
        ('a', 1),
        ('z', 26),
        ('y', 25),
        ('x', 24),
        ('w', 23),
    ])

    t = to_namedtuple(dic)

    print(t)
    # NamedTuple(a=1, b=2, c=3, d=4, w=23, x=24, y=25, z=26)

    # Directly create a NamedTuple
    make = namedtuple('NamedTuple', dic.keys())

    # Pass in values as arguments
    t2 = make(dic.values())

    print(t2)
    # NamedTuple(d=

# Generated at 2022-06-11 22:20:29.468163
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), NamedTuple)
    assert hasattr(to_namedtuple({'a': 1, 'b': 2}), 'a')
    assert to_namedtuple(OrderedDict((('b', 2), ('a', 1)))) == \
        to_namedtuple(OrderedDict((('b', 2), ('a', 1))))
    assert to_namedtuple(OrderedDict((('b', 2), ('a', 1)))) != \
        to_namedtuple(OrderedDict((('a', 1), ('b', 2))))
    assert isinstance(to_namedtuple(OrderedDict((('b', 2), ('a', 1)))),
                      NamedTuple)

# Generated at 2022-06-11 22:20:34.569875
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    re = to_namedtuple(dic)
    assert hasattr(re, 'a') and hasattr(re, 'b')
    assert re.a == 1, re.a
    assert re.b == 2

# Generated at 2022-06-11 22:20:46.511199
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'num': 7, 'str': 'test'}
    out = to_namedtuple(dic)
    if not hasattr(out, 'num'):
        raise AttributeError("The 'num' was missing from the outcome.")
    if not hasattr(out, 'str'):
        raise AttributeError("The 'str' was missing from the outcome.")
    if out.num != 7:
        raise AssertionError("The 'num' attribute is not the expected value.")
    if out.str != 'test':
        raise AssertionError("The 'str' attribute is not the expected value.")

# Generated at 2022-06-11 22:20:57.963440
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple(
        'NamedTuple', 'a b'
    )(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]) == [
        namedtuple(
            'NamedTuple', 'a b'
        )(a=1, b=2),
        namedtuple(
            'NamedTuple', 'a b'
        )(a=1, b=2)
    ]
    assert isinstance(to_namedtuple([{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]), list)


# Generated at 2022-06-11 22:21:08.027340
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    # Ensure that a simple dictionary is converted to a NamedTuple
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, tuple)
    assert out.a == 1
    assert out.b == 2
    assert out[0] == 1
    assert out[1] == 2
    odict = OrderedDict()
    odict[1] = 2
    out = to_namedtuple(odict)
    assert isinstance(out, tuple)
    assert out[0] == 2

    # Ensure that a list is converted to a NamedTuple
    lst = [1, 2, 3, {'a': 1}]

# Generated at 2022-06-11 22:21:17.230310
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple, OrderedDict
    import types

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)

    assert to_namedtuple(OrderedDict(dic)) == namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)

    obj = {'a': 1, 'b': {'c': 3, 'd': [4, 5]}}
    other = {'c': {'a': 1}, 'd': {'e': 2, 'f': dic}}
    assert to_namedtuple(obj) == named

# Generated at 2022-06-11 22:21:26.418001
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': {'b': {'c': {'d': {'e': 'f'}}}}}

# Generated at 2022-06-11 22:21:35.568579
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from types import SimpleNamespace
    from collections import (
        OrderedDict,
        namedtuple,
    )
    obj = SimpleNamespace(
        a=1,
        b=2,
        c=SimpleNamespace(
            d=3,
            e=4,
        )
    )
    exp = namedtuple(
        'NamedTuple',
        'a b c',
    )(
        a=1,
        b=2,
        c=namedtuple(
            'NamedTuple',
            'd e',
        )(
            d=3,
            e=4,
        )
    )
    assert to_namedtuple(obj) == exp

# Generated at 2022-06-11 22:21:46.536017
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Basic conversions
    dic = {'a': 1, 'b': 2}
    res = to_namedtuple(dic)
    assert res.a == 1
    assert res.b == 2

    lst = [{'a': 1}, {'b': 2}, {'c': 3}]
    res = to_namedtuple(lst)
    assert res[0].a == 1
    assert res[1].b == 2
    assert res[2].c == 3

    lst = [{'a': 1}, {'a': 2, 'b': 2}, {'c': 3}]
    res = to_namedtuple(lst)
    assert res[0].a == 1
    assert res[1].b == 2
    assert res[1].a == 2

# Generated at 2022-06-11 22:22:05.342305
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from flutils.namedtupleutils import to_namedtuple

    # Convert dictionary
    dic: OrderedDict = OrderedDict({
        'a': 1,
        'b': [1, 2],
        'c': 'hello',
        '1': 1,
        '-' : 4
    })
    res = to_namedtuple(dic)
    assert isinstance(res, OrderedDict)
    assert 'a' in res
    assert 'b' in res
    assert 'c' in res
    assert '1' not in res
    assert '-' not in res
    assert 'a' in res._fields
    assert 'b' in res._fields
    assert 'c' in res._fields
    assert '1' not in res._

# Generated at 2022-06-11 22:22:13.705927
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import collections

    class TestToNamedTuple(unittest.TestCase):
        def test_empty_list(self):
            expect = []
            result = to_namedtuple([])
            self.assertListEqual(result, expect)

        def test_empty_tuple(self):
            expect = ()
            result = to_namedtuple(())
            self.assertTupleEqual(result, expect)

        def test_empty_dict(self):
            expect = collections.namedtuple('NamedTuple', '')()
            result = to_namedtuple({})
            self.assertEqual(result, expect)

        def test_empty_ordered_dict(self):
            expect = collections.namedtuple('NamedTuple', '')()
            result = to_namedt

# Generated at 2022-06-11 22:22:24.106053
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    import json

    Person = namedtuple('Person', ['first', 'last', 'age'])
    people = [
        Person(first='Joe', last='Smith', age=42),
        Person(first='Ray', last='Lowe', age=22),
        Person(first='Dave', last='Jones', age=52),
    ]

    test_config = OrderedDict()
    test_config['user'] = 'John'
    test_config['version'] = '1.0.0'
    test_config['date'] = '2019-03-22'
    test_config['host'] = '127.0.0.1'
    test_config['port'] = '1883'
    test_config['people'] = people
    config = to_namedtuple(test_config)


# Generated at 2022-06-11 22:22:33.068243
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyTypeChecker
    def test_obj(obj: Any, expected: Any) -> None:
        assert to_namedtuple(obj) == expected

    test_obj(dict(a=1), NamedTuple(a=1))
    test_obj(dict(a=1, b=2), NamedTuple(a=1, b=2))
    test_obj(dict(a=1, b=2), NamedTuple(a=1, b=2))
    test_obj(dict(b=2, a=1), NamedTuple(a=1, b=2))
    test_obj(dict(A=1, b=2), NamedTuple(b=2, A=1))

# Generated at 2022-06-11 22:22:41.381926
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import _to_namedtuple

    assert _to_namedtuple({'a':1, 'b':2}) == _to_namedtuple(namedtuple('NamedTuple', 'a b')(1, 2))

    assert _to_namedtuple({'a':1, 'b':2, 'c':3}) == namedtuple('NamedTuple', 'a b c')(1, 2, 3)
    assert _to_namedtuple([{'a': 1, 'b': 2, 'c': 3}, {'a': 3, 'b': 4}]) == [namedtuple('NamedTuple', 'a b c')(1, 2, 3),
                                                                            namedtuple('NamedTuple', 'a b')(3, 4)]

# Generated at 2022-06-11 22:22:52.232724
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert(result[0] == 1)
    dic = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    result = to_namedtuple(dic)
    assert(result[0] == 1)
    assert(result.c[0] == 3)
    assert(result.c[1] == 4)
    assert(result.c.d == 3)
    assert(result.c.e == 4)
    dic = {'0': 1, '1': 2, '2': {'0': 3, '1': 4}}
    result = to_namedtuple(dic)
    assert(result[0] == 1)
   

# Generated at 2022-06-11 22:23:04.180816
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from types import SimpleNamespace

    assert isinstance(to_namedtuple([1, 2, 3]), List)
    assert isinstance(to_namedtuple((1, 2, 3)), Tuple)
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), namedtuple)
    assert isinstance(to_namedtuple(OrderedDict({'a': 1, 'b': 2})), namedtuple)
    assert isinstance(to_namedtuple(SimpleNamespace(A=1, B=2)), namedtuple)
    assert to_namedtuple([]) == []
    assert to_namedtuple(()) == ()
    assert to_namedtuple({}) == ()
    assert to_namedtuple(OrderedDict()) == ()
    assert to

# Generated at 2022-06-11 22:23:14.846521
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from typing import NamedTuple

    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert repr(out) == 'NamedTuple(a=1, b=2)'

    lis: List[int] = [1, 2, 3]
    out = to_namedtuple(lis)
    assert out == tuple(lis)

    dic['d'] = dic
    out = to_namedtuple(dic)
    assert repr(out) == 'NamedTuple(a=1, b=2, d=NamedTuple(a=1, b=2, d=NamedTuple(a=...)))'


# Generated at 2022-06-11 22:23:24.128638
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj1 = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    assert to_namedtuple(obj1) == [NamedTuple(a=1, b=2), NamedTuple(a=3, b=4)]
    obj2 = {'a': 1, 'b': 2, 3: 'c', 4: 'd'}
    assert to_namedtuple(obj2) == NamedTuple(a=1, b=2)
    obj3 = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}, {'a': 5, 'b': 6}]

# Generated at 2022-06-11 22:23:35.056230
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.py23_compat import items_py23_compat
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == to_namedtuple(dic)

    obj = SimpleNamespace(**dic)
    assert to_namedtuple(dic) == to_namedtuple(obj)

    obj = OrderedDict(**dic)
    assert to_namedtuple(dic) == to_namedtuple(obj)

    obj = (1, 2)
    assert to_namedtuple(dic) == to_namedtuple(obj)

    obj = [1, 2]
    assert to_namedtuple(dic) == to_namedtuple(obj)

# Generated at 2022-06-11 22:24:05.671425
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)

    assert to_namedtuple({'b': 2, 'a': 1}) == namedtuple('NamedTuple', 'a b')(1, 2)

    assert to_namedtuple({'c': 3, 'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b c')(1, 2, 3)

    assert to_namedtuple({'c': 3, 'a': 1, 'b': 2, '1': 'two'}) == namedtuple('NamedTuple', 'a b c')(1, 2, 3)

# Generated at 2022-06-11 22:24:17.331738
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    expected = namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)

    actual = to_namedtuple(obj)

    assert expected == actual

    obj = {'a': 1, 'b': 2, '_c': 3}
    expected = namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)

    actual = to_namedtuple(obj)

    assert expected == actual

    obj = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4, '_f': 5}}

# Generated at 2022-06-11 22:24:25.941788
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Function to_namedtuple must be tested as this is not a method of
    # a class
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    result = to_namedtuple(dic)
    dic['c'] = 4
    result.d = 3
    assert isinstance(result, NamedTuple)
    assert dic == {'a': 1, 'b': 2, 'c': 4, 'd': 3}
    assert result == NamedTuple(a=1, b=2, d=3, c=4)
    assert result.a == 1
    assert result.b == 2
    assert result.d == 3
    assert result.c == 4

# Generated at 2022-06-11 22:24:35.196156
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    import inspect
    import sys
    import types
    import collections
    import types
    import functools


    # Can convert list
    assert type(to_namedtuple(['a', 'b', 'c'])) == list
    assert type(to_namedtuple(['a', 'b', 'c'])[0]) == str

    # Can convert list of list
    assert type(to_namedtuple([['a', 1], ['b', 2]])) == list
    assert type(to_namedtuple([['a', 1], ['b', 2]])[0]) == tuple
    assert type(to_namedtuple([['a', 1], ['b', 2]])[0][0]) == str

# Generated at 2022-06-11 22:24:46.054066
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.objects import AttrDict

    valid_types = [{}, OrderedDict(), AttrDict(), {'a': 1, 'b': 2},
                   AttrDict({'a': 3, 'b': 4}), [1, 2, 3], (1, 2, 3),
                   [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}],
                   [{'a': 1, 'b': 2}, [1, 2, 3]],
                   {'a': {'b': 3, 'c': 4}},
                   [{'a': {'b': 3, 'c': 4}}]]

    invalid_types = [1, 1.0, '', 'a', object()]


# Generated at 2022-06-11 22:24:56.757667
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def get_inspect_obj(obj):
        # noinspection PyProtectedMember,PyUnresolvedReferences
        s = repr(obj).split('(')[1][:-1]
        if s == '':
            return {}
        s = s.split(', ')
        dic = {}
        for pair in s:
            key, val = pair.split('=')
            val = val[1:-1]
            if val == 'None':
                val = None
            elif val == 'False':
                val = False
            elif val == 'True':
                val = True
            else:
                val = val.split(' ')[1]
            dic[key] = val
        return dic

    assert to_namedtuple({}) == NamedTuple()