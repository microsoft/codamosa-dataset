

# Generated at 2022-06-11 22:15:12.489276
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic = OrderedDict([('a', OrderedDict([('c', 1), ('b', 2)])), ('a_', 1)])
    # noinspection PyTypeChecker
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ['a'])(a=namedtuple('NamedTuple', ['c', 'b'])(c=1, b=2))

    # noinspection PyTypeChecker,PyArgumentList
    dt = namedtuple('NamedTuple', ['a', 'b'], defaults=[1, 2])(1, 2)
    assert to_namedtuple(dt) == dt

    dic = {'a': 1, 'b': 2}
    # noinspection PyTypeChecker,PyArgumentList

# Generated at 2022-06-11 22:15:21.710205
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import unittest

    class ToNamedTupleTestCase(unittest.TestCase):

        maxDiff = None

        # noinspection SpellCheckingInspection,PyShadowingNames
        def test_to_namedtuple(self):
            from flutils.namedtupleutils import to_namedtuple

            d = OrderedDict([
                ('a', 1),
                ('b', 2),
            ])
            # noinspection PyTypeChecker
            NamedTuple = namedtuple('NamedTuple', tuple(d.keys()))
            # noinspection PyTypeChecker,PyArgumentList
            n = NamedTuple(*d.values())  # type: ignore[misc]
            self.assertEqual(
                expected=n,
                actual=to_namedtuple(d),
            )

            t

# Generated at 2022-06-11 22:15:26.352812
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert str(to_namedtuple({'a': 1, 'b': 2})) == "NamedTuple(a=1, b=2)"
    assert str(to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))) == \
        "NamedTuple(a=1, b=2)"
    assert str(to_namedtuple([{'a': 1, 'b': 2}, {'c': 3, 'd': 4}])) == \
        "[NamedTuple(a=1, b=2), NamedTuple(c=3, d=4)]"

# Generated at 2022-06-11 22:15:34.437863
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    class ToNamedtupleTestCase(unittest.TestCase):
        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            namedt = to_namedtuple(dic)
            assert namedt.a == 1
            assert namedt.b == 2
            assert namedt[0] == 1
            assert namedt[1] == 2
            assert namedt.__getitem__(0) == 1
            assert namedt.__getitem__(1) == 2
            assert namedt._fields == ('a', 'b')
            assert namedt._asdict() == dic
    return ToNamedtupleTestCase

# Generated at 2022-06-11 22:15:45.435292
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Test tuple
    tup = ('a', 'b')
    ntup = to_namedtuple(tup)
    assert ntup == tup
    assert ntup == ('a', 'b')

    # Test list
    lst = ['a', 'b']
    ntup = to_namedtuple(lst)
    assert ntup == lst
    assert ntup == ['a', 'b']

    # Test dictionary
    dic = {'a': 1, 'b': 2}
    ntup = to_namedtuple(dic)
    assert ntup.a == 1
    assert ntup.b == 2

    # Test ordered dictionary
    odic = OrderedDict(a=1, b=2)
    ntup = to_namedtuple(odic)

# Generated at 2022-06-11 22:15:57.225576
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import NamedTuple

    class MyNamedTuple(NamedTuple):
        name: str
        value: int

    class MyNestedNamedTuple(NamedTuple):
        number: int
        nested: MyNamedTuple

    nt = MyNamedTuple(name='name', value=1)

    result = to_namedtuple(nt)
    assert result == nt

    nested = MyNestedNamedTuple(number=1, nested=result)
    result = to_namedtuple(nested)
    assert result == nested

    result = to_namedtuple(nested._fields)
    assert result == nested._fields

    result = to_namedtuple({'name': 'name', 'value': 1})
    assert result == nt


# Generated at 2022-06-11 22:15:58.859349
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(report=True, verbose=True)

# Generated at 2022-06-11 22:16:10.520701
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import MutableMapping
    from copy import copy
    from types import SimpleNamespace
    from unittest import TestCase
    from typing import Any, Dict
    from flutils.validators import validate_identifier

    class TestToNamedTupleClass(TestCase):

        def test_simple(self):
            out = to_namedtuple({'a': 1})
            self.assertEqual(out.a, 1)

        def test_ordereddict(self):
            dct = OrderedDict({'a': 1, 'b': 2, 'c': 3})
            out = to_namedtuple(dct)
            self.assertEqual(out.a, 1)
            self.assertEqual(out.b, 2)
            self.assertEqual

# Generated at 2022-06-11 22:16:22.860701
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # type: () -> None
    """Unit tests for function to_namedtuple."""
    import pytest
    from collections import OrderedDict

    # noinspection PyTypeChecker
    out1 = to_namedtuple((1, 2, 3))
    # noinspection PyTypeChecker
    out2 = (1, 2, 3)
    assert out1 == out2

    # noinspection PyTypeChecker
    out1 = to_namedtuple([1, 'a', 3])
    out2 = [1, 'a', 3]
    assert out1 == out2

    # noinspection PyTypeChecker
    out1 = to_namedtuple({'a': 1, 'b': 2})
    out2 = NamedTuple(a=1, b=2)
    assert out1 == out2

   

# Generated at 2022-06-11 22:16:29.861851
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(namedtuple('NamedTuple', 'a b')(a=1, b=2)) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(SimpleNamespace(a=1, b=2)) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

# Generated at 2022-06-11 22:16:38.422596
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    tup = to_namedtuple(dic)
    assert type(tup).__name__ == 'NamedTuple'
    assert hasattr(tup, 'b') and getattr(tup, 'b') == 2
    assert isinstance(tup, tuple)


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:16:50.226898
# Unit test for function to_namedtuple
def test_to_namedtuple():  # pragma: no cover
    import pytest
    noop = lambda x: x

# Generated at 2022-06-11 22:16:52.962726
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnresolvedReferences
    from .test_namedtupleutils import TestToNamedTuple
    TestToNamedTuple.test_to_namedtuple()

# Generated at 2022-06-11 22:17:01.968351
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import ChainMap
    from collections.abc import MutableMapping
    from collections import deque
    from collections import UserDict
    from collections import UserList
    from collections import UserString
    from collections import Counter
    from collections import OrderedDict
    from collections import defaultdict
    from pprint import pprint
    import json

    def pprint_nt(obj: Any) -> None:
        outl = repr(obj)
        outl = outl.replace('NamedTuple', '')
        outl = outl.replace('(', '{').replace(')', '}')
        print(outl)

    # noinspection PyTypeChecker
    print('\nDICT')
    dic = {'a': 1, 'b': 2}
    dic = to_namedtuple(dic)
    pprint_

# Generated at 2022-06-11 22:17:07.065209
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Tests for function to_namedtuple"""
    from unittest import TestCase

    class TestToNamedTuple(TestCase):

        def test_normal(self):
            from collections import OrderedDict
            from typing import NamedTuple

            class A(NamedTuple):
                a: int
                b: int

            class B(NamedTuple):
                a: int
                b: A

            class C(NamedTuple):
                a: A
                b: B

            a = A(1, 2)
            b = B(1, a)
            c = C(a, b)

            z = to_namedtuple(c)
            self.assertIsInstance(z, NamedTuple)
            self.assertEqual(z.a.a, 1)
            self.assertEqual

# Generated at 2022-06-11 22:17:17.798805
# Unit test for function to_namedtuple
def test_to_namedtuple():
    ret = to_namedtuple({
        'a': 1,
        'b': 2,
    })
    assert ret.a == 1
    assert ret.b == 2
    assert ret[0] == 1
    assert ret[1] == 2
    dic1 = {
        'a': 1,
        'b': 2,
        'c': {
            'a': 3,
            'b': 4,
            'c': [5, 6, 7],
        },
    }
    ret = to_namedtuple(dic1)
    assert ret.a == 1
    assert ret.b == 2
    assert ret.c.a == 3
    assert ret.c.b == 4
    assert ret.c.c[0] == 5
    assert ret.c.c[1] == 6
    assert ret

# Generated at 2022-06-11 22:17:26.376886
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    nt_repr = 'NamedTuple(a=1, b=2)'
    assert repr(nt) == nt_repr

    lst = [{'a': 1, 'b': 2}, {'a': 3, 'c': 4}]
    nt = to_namedtuple(lst)
    nt_repr = '[NamedTuple(a=1, b=2), NamedTuple(a=3, c=4)]'
    assert repr(nt) == nt_repr

    t = (dic, lst)
    nt = to_namedtuple(t)

# Generated at 2022-06-11 22:17:36.924811
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test for function to_namedtuple."""
    from pprint import pprint
    from typing import Dict
    from flutils.configobjutils import ConfObj, ConfDict

    class ConfDict2(ConfDict):
        """A ConfDict that allows new attributes."""
        def __init__(self, init_dict: dict = None):
            super().__init__()
            init_dict = {} if init_dict is None else init_dict
            self.update(**init_dict)

        def __getattr__(self, key: str) -> Any:
            try:
                return super().__getattr__(key)
            except AttributeError:
                new_dict = {}
                for key, val in self.items():
                    new_dict[key] = val

# Generated at 2022-06-11 22:17:47.638886
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert type(to_namedtuple({'a': [1, 2, 3]})) == namedtuple('NamedTuple', 'a')
    assert to_namedtuple({'a': [1, 2, 3]}) == namedtuple('NamedTuple', 'a')([1, 2, 3])
    assert type(to_namedtuple({'a': [1, 2, 3], 'b': {'c': [1, 2]}})) == namedtuple('NamedTuple', 'a b')
    assert to_namedtuple({'a': [1, 2, 3], 'b': {'c': [1, 2]}}) == namedtuple('NamedTuple', 'a b')([1, 2, 3], NamedTuple(c=[1, 2]))

# Generated at 2022-06-11 22:17:50.367844
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

# Generated at 2022-06-11 22:18:04.678826
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Function to_namedtuple unit test."""
    dic = {'a': 1, 'b': 2}
    e1 = to_namedtuple(dic)
    assert e1.a == 1
    assert e1.b == 2
    with pytest.raises(TypeError):
        _to_namedtuple(1)
    assert e1 == NamedTuple(a=1, b=2)
    dic = {'a': 1, 'b': {'c': 3}}
    e2 = to_namedtuple(dic)
    assert e2.b.c == 3
    assert e2.a == 1
    lst = [1, 2]
    e3 = to_namedtuple(lst)
    assert e3 == [1, 2]
    odict = OrderedDict

# Generated at 2022-06-11 22:18:15.664268
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple({}), namedtuple('NamedTuple', ''))
    assert to_namedtuple({}) == to_namedtuple(namedtuple('NamedTuple', '')())
    assert to_namedtuple({}) == to_namedtuple(tuple())
    assert to_namedtuple({}) == to_namedtuple(list())
    # noinspection PyTypeChecker
    assert to_namedtuple({}) == to_namedtuple(SimpleNamespace())
    assert to_namedtuple({}) == to_namedtuple(OrderedDict())

    obj = to_namedtuple({'a': 1, 'b': 2, 'c': 3, 'd': 4})

# Generated at 2022-06-11 22:18:25.390677
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    dic2 = OrderedDict({'a': 1, 'b': 2})
    lst = ['a', 'b', 'c']
    tup = ('a', 'b', 'c')
    obj = SimpleNamespace(a=1, b=2)

    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dic2) == NamedTuple(a=1, b=2)
    assert to_namedtuple(lst) == ['a', 'b', 'c']
    assert to_namedtuple(tup) == ('a', 'b', 'c')
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)

# Generated at 2022-06-11 22:18:35.449203
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace

    # Unordered dictionaries
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == namedtuple('NamedTuple', 'a b')(1, 2)

    dic = {'b': 2, 'a': 1}
    out = to_namedtuple(dic)
    assert out == namedtuple('NamedTuple', 'a b')(1, 2)

    class C:
        def __init__(self):
            self.a = 1

    dic = {'b': 2, 'a': C()}
    out = to_namedtuple(dic)

# Generated at 2022-06-11 22:18:45.673927
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == namedtuple('NamedTuple', 'a b')(1, 2)
    obj = {'a': 1, '_b': 2}
    assert to_namedtuple(obj) == namedtuple('NamedTuple', 'a')(1)
    obj = {'a': {'b': {'a': 1, 'b': 2}}}
    ret = to_namedtuple(obj)
    a = ret.a
    assert a == namedtuple('NamedTuple', 'b')(b=namedtuple('NamedTuple', 'a b')(1, 2))

# Generated at 2022-06-11 22:18:47.501442
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:18:56.182211
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(
        [{'a': 1, 'b': 2}]
    ) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple(
        ({'a': 1, 'b': 2},)
    ) == (NamedTuple(a=1, b=2),)
    assert to_namedtuple(
        [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    ) == [NamedTuple(a=1, b=2), NamedTuple(c=3, d=4)]

# Generated at 2022-06-11 22:19:06.285714
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert to_namedtuple({'b': 2, 'a': 1}) == to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert to_namedtuple(1) == 1
    assert to_namedtuple(1.0) == 1.0
    assert to_namedtuple(True) is True
    assert to_namedtuple(False) is False
    assert to_namedtuple(None) is None
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(['a', 'b']) == ['a', 'b']

# Generated at 2022-06-11 22:19:17.176497
# Unit test for function to_namedtuple
def test_to_namedtuple():
    class _Single(NamedTuple):
        some: str
        thing: int

    class _Double(NamedTuple):
        some: str
        thing: Union[_Single, _Single]

    class _Triple(NamedTuple):
        some: str
        thing: Union[_Single, _Double, _Single]

    dic = {}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', '')()
    dic = {'a': 1}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a')(1)
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)
   

# Generated at 2022-06-11 22:19:28.467866
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 1, 'b': 2}
    dic = OrderedDict(dic)
    dic['c'] = 3
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2, c=3)

    dic = {'a': 1, 'b': 2}
    sns = SimpleNamespace(**dic)
    nt = to_namedtuple(sns)
    assert isinstance(nt, NamedTuple)
    assert nt.a == sns.a
    assert nt.b == sns.b
    assert getattr(nt, 'a', None)

# Generated at 2022-06-11 22:19:42.673434
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Basic unit test for function to_namedtuple."""
    alpha = {
        'a': {
            '_b': {
                'c': 'd',
                'e': 'f'
            }
        }
    }
    nt_alpha: NamedTuple = to_namedtuple(alpha)
    assert isinstance(nt_alpha, NamedTuple)
    assert nt_alpha.a._b.c == 'd'
    assert nt_alpha.a._b.e == 'f'


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:19:53.985009
# Unit test for function to_namedtuple
def test_to_namedtuple():
    try:
        assert to_namedtuple("a")
    except TypeError as exc:
        assert 'only' in str(exc)
        assert "('list', 'tuple', 'dict')" in str(exc)

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'b a')(b=2, a=1)

    dic = OrderedDict(a=1, b=2)
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedt

# Generated at 2022-06-11 22:20:02.297158
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_data = (
        OrderedDict(
            [
                ('a', 1),
                ('b', 2),
                ('c',
                 OrderedDict(
                     [
                         ('d', 3),
                         ('e', 4),
                     ]
                 )
                 ),
                ('f', 5),
            ]
        )
    )
    expected_data = (
        namedtuple('NamedTuple',
                   tuple(test_data.keys()))(
            *test_data.values()
        )
    )
    for type_ in SimpleNamespace, OrderedDict, dict:
        assert expected_data == to_namedtuple(type_(test_data))

# Generated at 2022-06-11 22:20:09.252023
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
        },
    }
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 2
    assert nt.c.d == 3
    assert nt.c.e == 4
    assert nt.c.d + nt.c.e == nt.a + nt.b

# Generated at 2022-06-11 22:20:19.568388
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple


# Generated at 2022-06-11 22:20:29.528844
# Unit test for function to_namedtuple
def test_to_namedtuple():

    dicts = [
        {'a': 1, 'b': 2},
        OrderedDict([('a', 1), ('b', 2)]),
    ]

    for d1 in dicts:
        nt1: NamedTuple = to_namedtuple(d1)
        assert nt1.a == 1
        assert nt1.b == 2

        d2 = {'c': {'d': 3}}
        nt2: NamedTuple = to_namedtuple(d2)
        assert nt2.c.d == 3

        nt2 = nt1 + nt2
        assert nt2.a == 1
        assert nt2.b == 2
        assert nt2.c.d == 3

        d3 = [1, d2, 3]
        nt3 = to_

# Generated at 2022-06-11 22:20:40.039251
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from collections import namedtuple
    from types import SimpleNamespace
    from flutils.namedtupleutils import (
        to_namedtuple,
        _to_namedtuple
    )
    from flutils.validators import validate_identifier

    class TesttoNamedTuple(TestCase):
        """Test for the function to_namedtuple."""

        def test_namedtuple(self):
            """Test that a NamedTuple is not converted."""
            items = (1, 2, 3,)
            make = namedtuple('NamedTuple', 'a b c')
            obj = make(*items)
            result = to_namedtuple(obj)
            self.assertEqual(obj, result)


# Generated at 2022-06-11 22:20:49.854055
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils as namedtupleutils
    assert namedtupleutils.to_namedtuple(1) == 1
    assert namedtupleutils.to_namedtuple({}) == namedtupleutils.NamedTuple()
    assert namedtupleutils.to_namedtuple({'a': 1}) == namedtupleutils.NamedTuple(a=1)
    assert namedtupleutils.to_namedtuple({'a': 1, 'b': 2}) == namedtupleutils.NamedTuple(a=1, b=2)
    assert namedtupleutils.to_namedtuple({'a': 1, 'b': 2, 'c': 3}) == namedtupleutils.NamedTuple(a=1, b=2, c=3)


# Generated at 2022-06-11 22:20:59.084971
# Unit test for function to_namedtuple
def test_to_namedtuple():
        # noinspection PyUnresolvedReferences
        from flutils.testingutils import set_up
        from flutils.testingutils import tear_down
        from flutils.testingutils import TestCase
        from flutils.namedtupleutils import to_namedtuple

        set_up()

        class Tests(TestCase):
            def test_to_namedtuple(self):
                obj = {'a': 1, 'b': 2}
                out = to_namedtuple(obj)
                self.assertEqual(1, out.a)
                self.assertEqual(2, out.b)

        Tests()

        tear_down()

# Generated at 2022-06-11 22:20:59.803247
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:21:18.568076
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Need to fix this ...
    assert False

    dic = {'a': 1, 'b': 2}
    dic_dict = {'a': {'c': 3, 'd': 4}, 'b': {'e': 5, 'f': 6}}
    dic_tuple = {'a': (7, 8), 'b': (9, 10)}
    dic_list = {'a': [11, 12], 'b': [13, 14]}
    dic_ann = {'a': namedtuple('e', 'c d')(15, 16), 'b': namedtuple('f', 'e f')(17, 18)}
    dic_sn = {'a': SimpleNamespace(c=19, d=20), 'b': SimpleNamespace(c=21, d=22)}
    dic_

# Generated at 2022-06-11 22:21:27.442969
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    from typing import NamedTuple
    from collections import OrderedDict
    from collections.abc import Mapping
    from types import SimpleNamespace
    import pytest
    from flutils.validators import is_subclass

    alphabet = OrderedDict([
        ('a', 1),
        ('b', 2),
        ('c', 3),
        ('d', 4),
        ('e', 5),
    ])

    unordered = {
        'c': 3,
        'd': 4,
        'a': 1,
        'b': 2,
        'e': 5,
    }

    lst = [1, 2, 3, 4, 5]


# Generated at 2022-06-11 22:21:36.098715
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([]) == []
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple(()) == ()
    assert to_namedtuple(list(range(10))) == list(range(10))
    assert to_namedtuple(tuple(range(10))) == tuple(range(10))
    dic = {'a': 1, 'b': 2, 'c': {'x': 1, 'y': 2}}
    output = to_namedtuple(dic)
    assert type(output).__name__ == 'NamedTuple'
    assert output.a == 1
    assert output.b == 2
    assert type(output.c).__name__ == 'NamedTuple'
    assert output.c.y == 2

# Generated at 2022-06-11 22:21:47.183915
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == NamedTuple(a=1, b=2)

    dic = {'a': 2, 'b': {'c': 3, 'd': 4}, 'e': 5}
    assert to_namedtuple(dic) == NamedTuple(a=2, b=NamedTuple(c=3, d=4), e=5)

    lst = [1, 2, {'a': 3, 'b': 4}, 5, 6]
    assert to_namedtuple(lst) == [
        1, 2, NamedTuple(a=3, b=4), 5, 6
    ]


# Generated at 2022-06-11 22:21:53.875364
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from typing import (
        Dict,
        List,
        NamedTuple,
        Tuple,
        Union,
    )
    from unittest import TestCase
    from unittest.mock import (
        patch,
    )

    _obj1 = {'a': 1, 'b': 2}
    _obj2 = SimpleNamespace(a=1, b=2)
    _obj3 = [{'a': 1, 'b': 2}, {'c': 3}]
    _obj3[0] = SimpleNamespace(a=1, b=2)
    _obj4 = OrderedDict()
    _obj4['a']

# Generated at 2022-06-11 22:22:03.239959
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for function to_namedtuple.
    """
    from flutils.namedtupleutils import to_namedtuple

    assert to_namedtuple({1: 1}) == namedtuple('NamedTuple', '1')(1)
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'b a')(2, 1)

# Generated at 2022-06-11 22:22:07.545021
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': {'b': 1, 'c': 2}}) == NamedTuple(a=NamedTuple(b=1, c=2))
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({3: 1, 'a': 2, '_': 3}) == NamedTuple(a=2)
    assert to_namedtuple({'b': 2, 'a': 1}) == NamedTuple(a=1, b=2)

# Generated at 2022-06-11 22:22:14.447683
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import unittest
    from unittest.mock import patch

    class TestToNamedTuple(unittest.TestCase):

        def setUp(self):
            self._start = sys.gettrace()
            patcher = patch(
                'sys.gettrace',
                new=lambda: True if self._start is None else self._start
            )
            patcher.start()
            self.addCleanup(patcher.stop)

        def tearDown(self):
            pass

        def test_wrong_type(self):
            self.assertRaises(
                TypeError,
                to_namedtuple,
                ['a', 'b', 'c']
            )


# Generated at 2022-06-11 22:22:24.553688
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple([1, 2, 3]), list)
    assert isinstance(to_namedtuple((1, 2, 3)), tuple)
    assert isinstance(to_namedtuple({'a': 1, 'b': 2}), NamedTuple)
    assert isinstance(to_namedtuple({1: 1, 2: 2}), Tuple)
    assert isinstance(to_namedtuple({True: 1, False: 2}), Tuple)
    assert isinstance(to_namedtuple({}), NamedTuple)
    assert isinstance(to_namedtuple(OrderedDict([('a', 1), ('b', 2)])), NamedTuple)
    assert isinstance(to_namedtuple(OrderedDict([(1, 1), (2, 2)])), Tuple)
   

# Generated at 2022-06-11 22:22:33.370309
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {
        'a': 1,
        'b': 2,
        'c': {
            'c1': 2,
            'c2': {
                'c21': 3,
                'c22': 4,
            }
        },
        'd': [3, 4, {'d1': 3}]
    }
    n = to_namedtuple(dic)
    assert isinstance(n, namedtuple)
    assert n.a == 1
    assert n.b == 2
    assert n.c == namedtuple('NamedTuple', ('c1', 'c2'))(2, namedtuple('NamedTuple', ('c21', 'c22'))(3, 4))

# Generated at 2022-06-11 22:23:04.623482
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import pytest

    # noinspection PyMissingOrEmptyDocstring
    class SampleClass:
        a: int
        b: str

        def __init__(self):
            self.a = 0
            self.b = ''

    with pytest.raises(TypeError, match='Can convert only'):
        _to_namedtuple(SampleClass)
    with pytest.raises(TypeError, match='Can convert only'):
        _to_namedtuple(SampleClass())

    with pytest.raises(TypeError, match='Can convert only'):
        _to_namedtuple(1)
    with pytest.raises(TypeError, match='Can convert only'):
        _to_namedtuple(1.1)

# Generated at 2022-06-11 22:23:15.296887
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for to_namedtuple()"""
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out == NamedTuple(a=1, b=2)

    lst = [1, 2, 3]
    out = to_namedtuple(lst)
    assert out == [1, 2, 3]

    tup = (1, 2, 3)
    out = to_namedtuple(tup)
    assert out == (1, 2, 3)

    nt = NamedTuple(a=1, b=2)
    out = to_namedtuple(nt)
    assert out == NamedTuple(a=1, b=2)

    ns = SimpleNamespace(a=1, b=2)
    out = to

# Generated at 2022-06-11 22:23:23.481701
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic = OrderedDict([
        ('a', 1),
        ('b', 'b'),
        ('c', {'d': 3, 'e': 'e'}),
        ('f', [1, 2, 'a', {'a': 'b'}]),
    ])
    mytuple = to_namedtuple(dic)

    assert hasattr(mytuple, 'a')
    assert hasattr(mytuple, 'b')
    assert hasattr(mytuple, 'c')
    assert hasattr(mytuple, 'f')

    assert hasattr(mytuple.c, 'd')
    assert hasattr(mytuple.c, 'e')


# Generated at 2022-06-11 22:23:34.682389
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    import pytest
    from flutils.namedtupleutils import to_namedtuple


    class NT(namedtuple('NT', 'first second third')):

        @property
        def kk(self) -> int:
            return self.first + self.second + self.third

        @property
        def id(self) -> int:
            return id(self)

    def test_convert(
            obj: Union[bool, Tuple[int, ...], List[int], NT, int, float],
            expected_obj: Union[bool, Tuple[int, ...], List[int], NT, int, float]
    ) -> None:
        out = to_namedtuple(obj)
        assert isinstance(out, type(expected_obj))
        assert out == expected_obj

   

# Generated at 2022-06-11 22:23:42.046557
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)


if __name__ == '__main__':
    """
    python -m flutils.namedtupleutils
    """
    from os import path
    from flutils.systemutils import print_pythonpath
    print_pythonpath(path.dirname(path.dirname(path.abspath(__file__))))

    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-11 22:23:50.722405
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from flutils.dictandlist import flatten_dict
    import datetime
    import logging
    import string
    import random
    import sys
    import os

    #
    # test wrong input
    #
    with pytest.raises(TypeError) as ex:
        x = to_namedtuple(string)
    assert str(ex.value) == "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; got: (<class 'type'>) <class 'str'>"
    with pytest.raises(TypeError) as ex:
        x = to_namedtuple(datetime)

# Generated at 2022-06-11 22:23:57.869809
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    d = dict(a=1, b=2)
    n = to_namedtuple(d)
    assert isinstance(n, namedtuple)
    assert n.a == 1

    # sort out ordering
    o = {'a': 1, 'b': 2}
    # sort out order
    o2 = OrderedDict(zip(['b', 'a'], [2, 1]))
    assert n != o2
    n2 = to_namedtuple(o2)
    assert n2 != n
    assert n2 == o2

    # sort out simple namespace
    s = SimpleNamespace(a=1, b=2)
    assert s != d
    n = to_namedtuple(s)
    assert n == d

    # sort out nested dict
    d

# Generated at 2022-06-11 22:24:07.203704
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tup = ('a', 1, 3)
    ntup = to_namedtuple(tup)
    assert isinstance(ntup, NamedTuple) and hasattr(ntup, 'a') and hasattr(ntup, '_2')
    dic = {'a': 1, 'b': 2, 'c': {'d': 3}}
    ndic = to_namedtuple(dic)
    assert isinstance(ndic, NamedTuple) and hasattr(ndic, 'a')
    assert isinstance(ndic.c, NamedTuple) and hasattr(ndic.c, 'd')
    dic = {'a': 1, 'b': 2, 'c': {'d': 3, '_e': 'e'}}
    ndic = to_namedtuple(dic)


# Generated at 2022-06-11 22:24:17.980895
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Running unit test for function to_namedtuple')

    print('Test converting a dictionary to a namedtuple')
    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert result.a == 1
    assert result.b == 2

    print('Test converting a list to a namedtuple')
    lst = [{'a': 1, 'b': 2}]
    result = to_namedtuple(lst)
    assert result[0].a == 1
    assert result[0].b == 2

    print('Test converting a tuple to a namedtuple')
    tup = ({'a': 1, 'b': 2},)
    result = to_namedtuple(tup)
    assert result[0].a == 1

# Generated at 2022-06-11 22:24:29.047309
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from collections.abc import (
        Mapping,
        Sequence,
    )
    from types import SimpleNamespace
    from typing import (
        Any,
        List,
        Mapping,
        NamedTuple,
        Tuple,
        Union,
    )

    _AllowedTypes = Union[
        List,
        Mapping,
        NamedTuple,
        SimpleNamespace,
        Tuple,
    ]

    from flutils.namedtupleutils import to_namedtuple
