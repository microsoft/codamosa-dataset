

# Generated at 2022-06-11 22:15:13.665632
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple({'foo': 123}) == namedtuple('NamedTuple', ['foo'])(foo=123)
    assert to_namedtuple({'foo': 123, 'bar': 456}) == namedtuple('NamedTuple', ['bar', 'foo'])(bar=456, foo=123)


# Generated at 2022-06-11 22:15:22.400122
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Setup...
    # This is a list of invalid identifier.
    invalid = []

    # This is a list of valid identifiers.
    # Note: The list contains a value of 'True', which may be a problem.

# Generated at 2022-06-11 22:15:33.138473
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _assert_type(expected: type, obj: Any):
        out = to_namedtuple(obj)
        assert isinstance(out, expected)
        for attr in out._fields:
            assert not attr.startswith('_')
            val = getattr(out, attr)
            _assert_type(expected, val)
    dic = {'a': 1, 'b': 2}
    od = OrderedDict([('c', 3), ('d', 4)])
    # noinspection PyTypeChecker
    nt = namedtuple('ny', ['e', 'f'])
    list_of_dics = [dic, od, nt(1, 2)]

# Generated at 2022-06-11 22:15:44.858267
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _test(
            _input: Union[
                list,
                dict,
                SimpleNamespace,
                NamedTuple,
                Tuple,
            ],
            _expected: Union[
                list,
                dict,
                SimpleNamespace,
                NamedTuple,
                Tuple,
            ],
    ):
        got = to_namedtuple(_input)
        if isinstance(_input, dict):
            if not isinstance(_input, OrderedDict):
                _expected = dict(sorted(_expected.items()))
        elif isinstance(_input, list):
            _input.sort()
            _expected.sort()
        assert got == _expected
        assert isinstance(got, type(_expected))

    _test(
        _input=[],
        _expected=[]
    )


# Generated at 2022-06-11 22:15:56.554056
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from flutils.validators import validate_identifier

    assert to_namedtuple({}) == namedtuple('NamedTuple', '')()
    assert to_namedtuple({'a': 1}) == namedtuple('NamedTuple', 'a')(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

# Generated at 2022-06-11 22:16:08.418836
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b']) == ['a', 'b']

# Generated at 2022-06-11 22:16:10.298155
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    # noinspection PyUnresolvedReferences
    import flutils.namedtupleutils
    # noinspection PyUnresolvedReferences
    import flutils.validators
    doctest.testmod(flutils.namedtupleutils)

# Generated at 2022-06-11 22:16:16.948133
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from typing import Dict, List, NamedTuple
    import numpy as np

    Number = float

    class Internals(NamedTuple):
        internal_dic: Dict[str, float]
        internal_float: float
        internal_str: str
        internal_list: List[str]
        internal_np: np.ndarray
        internal_array: np.ndarray
        internal_conversion: Dict[str, float]

    # noinspection Mypy
    class NamedTupleLevel1(NamedTuple):  # type: ignore[misc]
        """A NamedTuple to test the to_namedtuple function."""

        level_one_attr: str
        internal: Internals
        level_one_float: Number

    # no

# Generated at 2022-06-11 22:16:25.851397
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
    )
    from contextlib import ExitStack
    from flutils.systemutils import (
        chdir,
        temporary_file_name,
    )
    from pathlib import (
        Path,
    )
    from types import SimpleNamespace
    import yaml

# Generated at 2022-06-11 22:16:26.722155
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # TODO: add unit tests for to_namedtuple
    pass

# Generated at 2022-06-11 22:16:38.234879
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('test_to_namedtuple')
    from typing import NamedTuple
    from collections import OrderedDict
    from types import SimpleNamespace

    # noinspection SpellCheckingInspection
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert type(out) is NamedTuple and out.a == 1 and out.b == 2

    # noinspection SpellCheckingInspection
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert type(out) is NamedTuple and out.a == 1 and out.b == 2

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(OrderedDict(dic))

# Generated at 2022-06-11 22:16:40.421072
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ['a', 'b'])(1, 2)

# Generated at 2022-06-11 22:16:52.630877
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

# Generated at 2022-06-11 22:17:01.765076
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': {'b': 2}}) == NamedTuple(a=NamedTuple(b=2))
    assert to_namedtuple({'a': [{'b': 2}]}) == NamedTuple(a=[NamedTuple(b=2)])
    assert to_namedtuple([{'a': 1}]) == [NamedTuple(a=1)]
    assert to_namedtuple(((1,), (2,))) == (NamedTuple(1), NamedTuple(2))

# Generated at 2022-06-11 22:17:10.381614
# Unit test for function to_namedtuple
def test_to_namedtuple():
    data = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    assert data == to_namedtuple(data)
    data = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': {'a': 1, 'b': 2},
        'e': [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}],
        'f': [{'a': 1, 'b': 2}, 3, 1, "hello", {'c': 3, 'd': 4}],
        'g': SimpleNamespace(h=4, i=5),
    }
    assert data != to_namedtuple(data)
    assert isinstance(to_namedtuple(data), NamedTuple)


# Generated at 2022-06-11 22:17:20.182816
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from pprint import pprint
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(a=1, b=2)

    dic = {'_a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'b')(b=2)

    dic = {'a': 1, '_b': 2}
    assert to_namedtuple(dic)

# Generated at 2022-06-11 22:17:28.181072
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import namedtuple

    # Success tests
    ls = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    out = [
        namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2),
        namedtuple('NamedTuple', ('c', 'd'))(c=3, d=4),
    ]
    assert to_namedtuple(ls) == out

    dic = {'a': 1, 'b': 2}
    out = namedtuple('NamedTuple', ('a', 'b'))(a=1, b=2)
    assert to_namedtuple(dic) == out

    od = OrderedDict(a=1, b=2)
    out

# Generated at 2022-06-11 22:17:37.558747
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from collections import OrderedDict

    class TestToNamedtuple(unittest.TestCase):
        def test_none(self):
            self.assertRaises(
                TypeError,
                to_namedtuple, None
            )

        def test_empty_string(self):
            self.assertRaises(
                TypeError,
                to_namedtuple, ''
            )

        def test_int(self):
            self.assertRaises(
                TypeError,
                to_namedtuple, 5
            )

        def test_float(self):
            self.assertRaises(
                TypeError,
                to_namedtuple, 5.5
            )


# Generated at 2022-06-11 22:17:43.432809
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    (a, b) = out
    assert a == 1
    assert b == 2


if __name__ == '__main__':
    import pytest

    pytest.main(args=[__file__])

# Generated at 2022-06-11 22:17:51.066442
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(OrderedDict(b=2, a=1)) == NamedTuple(b=2, a=1)
    assert to_namedtuple(NotImplemented) == NotImplemented
    assert to_namedtuple(1) == 1

# Generated at 2022-06-11 22:18:04.970544
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    dic = {'a': 1, 'b': 2}
    expected = namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)

    result = to_namedtuple(dic)

    assert result == expected

    dic = {'a': 1, 'b': 2, 'c_c': 3}
    expected = namedtuple('NamedTuple', ['a', 'b', 'c_c'])(a=1, b=2, c_c=3)

    result = to_namedtuple(dic)

    assert result == expected

    lis = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]

# Generated at 2022-06-11 22:18:11.256510
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    dic = {'a': 1, 'b': 2}
    obj = SimpleNamespace(**dic)
    out = to_namedtuple(obj)
    assert isinstance(out, NamedTuple)
    assert out.a == 1
    assert out.b == 2

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:18:19.178295
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:18:27.824998
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from pprint import pprint
    from flutils.namedtupleutils import to_namedtuple

    dic = {'a': 1, 'b': 2}
    pprint(dic)
    out = to_namedtuple(dic)
    pprint(out)

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    pprint(dic)
    out = to_namedtuple(dic)
    pprint(out)

    dic = {'a': {'b': 2, 'c': 3}, 'd': 4}
    pprint(dic)
    out = to_namedtuple(dic)
    pprint(out)


# Generated at 2022-06-11 22:18:32.690928
# Unit test for function to_namedtuple
def test_to_namedtuple():

    import unittest

    class TestToNamedTuple(unittest.TestCase):

        def test_unsupported(self):

            from datetime import date

            date_obj = date.today()

            msg = (
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                "got: (%r) %s" % (type(date_obj).__name__, date_obj)
            )
            with self.assertRaises(TypeError) as cm:
                to_namedtuple(date_obj)
            err = cm.exception
            self.assertEqual(msg, str(err))

        def test_dict(self):

            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)


# Generated at 2022-06-11 22:18:44.624799
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    tup = (1, 2, 3)
    actual = to_namedtuple(tup)
    expected = (1, 2, 3)
    assert actual == expected

    tup = (1, 2, {'a': 1, 'b': 2})
    actual = to_namedtuple(tup)
    expected = (1, 2, NamedTuple(a=1, b=2))
    assert actual == expected

    tup = (1, (1, 2, {'a': 1, 'b': 2}), 3)
    actual = to_namedtuple(tup)

# Generated at 2022-06-11 22:18:54.974441
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    assert isinstance(to_namedtuple(obj), NamedTuple)
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)
    obj = ('a', 1, 'b', 2)
    assert isinstance(to_namedtuple(obj), NamedTuple)
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)
    obj = ['a', 1, 'b', 2]
    assert isinstance(to_namedtuple(obj), list)
    assert to_namedtuple(obj) == ['a', 1, 'b', 2]
    obj = {'a': {'b': {'c': 1}}}

# Generated at 2022-06-11 22:19:05.823385
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections.abc import Mapping
    from flutils.namedtupleutils import to_namedtuple
    from types import SimpleNamespace
    from unittest.mock import Mock
    from unittest import TestCase

    class TestCaseT(TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_to_namedtuple(self):
            @to_namedtuple
            class ntclass(object):
                def __init__(self, a, b, c):
                    self.a = a
                    self.b = b
                    self.c = c
                    self.d = to_namedtuple(Mock(__dict__={'e': 1, 'f': 2}))


# Generated at 2022-06-11 22:19:16.897402
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # test tuple with named tuples
    obj = ((0,0),(1,1),(2,2))
    assert to_namedtuple(obj) == ((0,0),(1,1),(2,2))
    # test list with named tuples
    obj = [(0,0),(1,1),(2,2)]
    assert to_namedtuple(obj) == [(0,0),(1,1),(2,2)]
    # test dict with named tuples
    obj = {'a': 'b', 'b': (1,2)}
    assert to_namedtuple(obj) == NamedTuple(a='b', b=(1,2))
    # test named tuple with names tuples

# Generated at 2022-06-11 22:19:27.672907
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)



# Copyright © 2020 Sam Kennerly
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Generated at 2022-06-11 22:19:44.114352
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    converted = to_namedtuple(dic)
    assert converted == NamedTuple(a=1, b=2), (
        'Failed to convert dictionary.'
    )

    dic = {'a': 1, '_b': 2}
    converted = to_namedtuple(dic)
    assert converted == NamedTuple(a=1), (
        'Failed to convert dictionary with invalid attribute.'
    )

    dic = {'a': 1, 'b': 'hi there'}
    converted = to_namedtuple(dic)
    assert converted == NamedTuple(a=1, b='hi there'), (
        'Failed to convert dictionary with str.'
    )



# Generated at 2022-06-11 22:19:54.707829
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyUnusedLocal
    dic: Mapping = {'a': 1, 'b': 2}
    # noinspection Mypy,PyTypeChecker
    ntpl: NamedTuple = to_namedtuple(dic)
    assert ntpl.a == 1
    assert ntpl.b == 2

    # noinspection PyUnusedLocal
    lst = [{'a': 1, 'b': 2}, {'a': 1, 'b': 2}]
    # noinspection PyTypeChecker,Mypy
    newlst: List = to_namedtuple(lst)
    for x in newlst:
        # noinspection PyTypeChecker,Mypy
        assert x.a == 1
        # noinspection PyTypeChecker,Mypy

# Generated at 2022-06-11 22:20:02.465913
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    my_dict = {
        'a': 1,
        'b': 2,
        'c': [1, 2, 3],
        'd': {'a': 1, 'b': 2, 'c': 3},
        'e': [
            {'a': 1, 'b': 2},
            {'c': 3, 'd': 4},
            [1, 2, 3],
        ],
    }
    ntup = to_namedtuple(my_dict)
    assert hasattr(ntup, 'a')


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:20:14.891133
# Unit test for function to_namedtuple
def test_to_namedtuple():

    def test1(*args, **kwargs):
        """
        Test function.
        """
        assert len(args) == 1
        assert len(kwargs) == 0
        obj = args[0]
        assert 'test' in obj
        assert 'test1' in obj
        assert 'test2' in obj
        assert 'test3' in obj
        assert 'test4' in obj
        assert 'test5' in obj
        assert 'test6' in obj
        assert hasattr(obj.test6, 'test_with_domain')
        assert 'test_with_domain' in obj.test
        assert obj.test2.test3 == 3
        assert obj.test2.test4 == 4
        assert obj.test2.test5 == 5
        assert obj.test_with_domain == 'domain test'

# Generated at 2022-06-11 22:20:27.596896
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    from flutils.namedtupleutils import to_namedtuple
    import json
    import os
    import pathlib
    import platform
    import re
    import sys
    from unittest.mock import patch
    from urllib.request import urlopen
    import warnings

    warnings.filterwarnings("ignore")

    # A dict that is a pyproject.toml

# Generated at 2022-06-11 22:20:38.379086
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': {'a': 1, 'b': 2}, 'b': 2}
    # noinspection PyTypeChecker
    obj: NamedTuple = to_namedtuple(dic)
    assert obj == cast(NamedTuple, obj)
    # noinspection PyTypeChecker
    assert obj.a == NamedTuple(a=1, b=2)
    # noinspection PyTypeChecker
    assert obj.b == 2
    # Test with OrderedDict
    from collections import OrderedDict
    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    # noinspection PyTypeChecker
    obj: NamedTuple = to_namedtuple(dic)
    assert obj == cast(NamedTuple, obj)

# Generated at 2022-06-11 22:20:48.897629
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import namedtuple
    from collections.abc import Mapping
    from functools import singledispatch
    from types import SimpleNamespace
    from typing import (
        Any,
        List,
        Sequence,
        Tuple,
        Union,
    )
    from flutils.exceptions import FlutilsNamedTupleException
    from flutils.namedtupleutils import to_namedtuple
    _AllowedTypes = Union[
        List,
        Mapping,
        SimpleNamespace,
        Tuple
    ]
    from flutils.namedtupleutils import _to_namedtuple
    _AllowedTypes = Union[
        List,
        Mapping,
        SimpleNamespace,
        Tuple
    ]

# Generated at 2022-06-11 22:21:00.025572
# Unit test for function to_namedtuple
def test_to_namedtuple():
    _testing_list = [
        {},
        {'a': 1, 'b': {'c': [{'d': 1, 'e': 2}]}},
        {'a': 1, 'b': {'c': [{'d': 1, 'e': 2}, {'x': 1, 'y': 2}]}},
        OrderedDict((('a', 'b'), ('d', OrderedDict((('x', 'z'), ('f', 'g'))))))
    ]

# Generated at 2022-06-11 22:21:11.709947
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    dicts = ({'a': 1, 'b': 2}, OrderedDict([('a', 1), ('b', 2)]))
    for dct in dicts:
        nt1 = to_namedtuple(dct)
        assert nt1.a == 1
        assert nt1.b == 2
        assert 'a' in nt1._fields
        assert 'b' in nt1._fields
        assert dct == nt1._asdict()

    lst = [1, 2]
    nt2 = to_namedtuple(lst)
    assert list(nt2) == lst
    assert isinstance(nt2, list)

    tup = tuple(lst)

# Generated at 2022-06-11 22:21:19.682829
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from collections import namedtuple

    dic = OrderedDict([('a', 1), ('b', 'two')])
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 'two'

    dic = {'a': 1, 'b': 'two'}
    nt = to_namedtuple(dic)
    assert nt.a == 1
    assert nt.b == 'two'

    lst = [1, 'two']
    nt = to_namedtuple(lst)
    assert nt[0] == 1
    assert nt[1] == 'two'

    dic = {'a': {'b': 3}}

# Generated at 2022-06-11 22:21:40.687573
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # The function to_namedtuple should convert a SimpleNamespace instances
    # to a namedtuple.
    # The function to_namedtuple should convert an OrderedDict to a namedtuple.
    # The function to_namedtuple should convert a dict to a namedtuple.
    # The function to_namedtuple should convert a list or tuple to a namedtuple.
    # The function to_namedtuple should fail if given a str.
    # The function to_namedtuple should fail if given a int.
    # The function to_namedtuple should fail if given a float.
    # The function to_namedtuple should fail if given a complex.
    # The function to_namedtuple should fail if given a set.
    pass


if __name__ == '__main__':
    import doctest

    doctest

# Generated at 2022-06-11 22:21:50.978767
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # Code from function docstring
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == (1, 2)

    obj = {'a': {'b': 2}}
    assert to_namedtuple(obj) == (2,)

    obj = {'a': {'_b': 2}}
    assert to_namedtuple(obj) == (2,)

    obj = {'a': {'b': 2, 'c': 3}}
    assert to_namedtuple(obj) == (2, 3)

    obj = {'a': {'b': 2, 'c': [3, 4]}}
    assert to_namedtuple(obj) == (2, (3, 4))


# Generated at 2022-06-11 22:22:01.501776
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # pytest.skip('Tests are passing; debugging')
    from typing import NamedTuple
    from flutils.namedtupleutils import to_namedtuple
    import random
    import string


# Generated at 2022-06-11 22:22:11.751851
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for the 'to_namedtuple' function.
    """
    import unittest
    import doctest
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from datetime import datetime

    class CustomClass(object):
        """A custom class."""

    class CustomOtherClass(object):
        """A custom class."""

    class CustomClass2(object):
        """A custom class."""

    class CustomOtherClass2(object):
        """A custom class."""

    class TestNamedTuple(unittest.TestCase):
        """Unit tests for the 'to_namedtuple' function."""

        def test_empty(self):
            """Test an empty dictionary.
            """
            dic = {}
           

# Generated at 2022-06-11 22:22:22.644949
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from unittest import TestCase

    class Test(TestCase):
        def test_to_namedtuple(self):
            dic = {'a': 1, 'b': 2}
            out = to_namedtuple(dic)
            self.assertIsInstance(out, namedtuple('NamedTuple', ('a', 'b')))
            self.assertEqual(out.a, dic['a'])
            self.assertEqual(out.b, dic['b'])

            odic = OrderedDict()
            odic['a'] = 1
            odic['b'] = 2
            out = to_namedtuple(odic)

# Generated at 2022-06-11 22:22:32.546679
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.testhelpers import C

    dic = {
        'a': 1,
        'b': 2,
        'c': {'c1': 3, 'c2': 4},
        'd': (5, 6),
        'e': [7, 8]
    }

    lst = [
        dic,
        dic['c'],
        dic['d'],
        dic['e']
    ]

    tup = ('a', 'b', dic, dic['c'], dic['d'])

    dic_expect = C(
        a=1,
        b=2,
        c=C(c1=3, c2=4),
        d=tuple([5, 6]),
        e=list([7, 8]),
    )

    l

# Generated at 2022-06-11 22:22:35.718285
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for function to_namedtuple """
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    # Unit test the module
    test_to_namedtuple()

# Generated at 2022-06-11 22:22:48.209422
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    actual = to_namedtuple(dic)
    expected = namedtuple('NamedTuple', 'a b')(1, 2)
    assert actual == expected
    assert actual.a == 1
    assert actual.b == 2

    dic['_c'] = 3
    actual = to_namedtuple(dic)
    expected = namedtuple('NamedTuple', 'a b')(1, 2)
    assert actual == expected
    assert actual.a == 1
    assert actual.b == 2


# Generated at 2022-06-11 22:22:50.397415
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:22:57.935453
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from typing import NamedTuple
    from functools import singledispatch
    from flutils.namedtupleutils import _to_namedtuple
    _tuple = (1, 2.0, 'three', {'four': 4, 'five': 5.0})
    _namedtuple = _to_namedtuple(_tuple)
    assert isinstance(_namedtuple, namedtuple)
    assert isinstance(_namedtuple, NamedTuple)
    assert len(_namedtuple) == 4
    assert _namedtuple.three == 'three'
    assert _namedtuple.four == {'four': 4, 'five': 5.0}
    assert _namedtuple.five is None
    assert callable(_to_namedtuple)
    assert callable(_to_namedtuple.registry[list])
    assert call

# Generated at 2022-06-11 22:23:32.541636
# Unit test for function to_namedtuple
def test_to_namedtuple():

    class A:
        val = 1
        def f(self):
            return 2

    def g():
        return 3

    class B:
        val = 5
        def f(self):
            return 6

    dic = {
        'a': 1,
        'b': 2,
        'c': '3',
        'd': A(),
        'e': B(),
        'f': g,
    }

    expected = (1, 2, '3', A(), B(), g)
    actual = to_namedtuple(dic)
    assert actual == expected

# Generated at 2022-06-11 22:23:44.623348
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:23:52.086831
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import pytest
    # Cases
    dic = {'a': 1, 'b': 2}
    nd_dic = to_namedtuple(dic)
    assert nd_dic.a == 1
    assert nd_dic.b == 2
    dic = {'a': 1, 'b': [1, {'x': 2}, 3], 'c': 'string'}
    nd_dic = to_namedtuple(dic)
    assert nd_dic.a == 1
    assert isinstance(nd_dic.b, list)
    assert nd_dic.b[0] == 1
    assert nd_dic.b[1].x == 2

# Generated at 2022-06-11 22:23:54.099374
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    print(to_namedtuple(dic))
    #testpassed = True

    #assert testpassed == True

# Generated at 2022-06-11 22:24:04.716106
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': '2a', 3: 3.5, 'four': 4, '_': True}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert out == NamedTuple(a=1, b='2a', four=4)
    
    od = OrderedDict((('b', '2a'), ('a', 1), (3, 3.5), ('four', 4), ('_', True)))
    out = to_namedtuple(od)
    assert isinstance(out, NamedTuple)
    assert out == NamedTuple(b='2a', a=1, four=4)
    
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
   

# Generated at 2022-06-11 22:24:16.873051
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from collections import namedtuple
    
    tup = namedtuple('Tup', 'a b c')
    
    tup_out = to_namedtuple(tup(a=1, b=2, c=3))
    assert tup_out.a == 1

    tup_dict = namedtuple('Tup', 'a b c')(a=tup(a=1, b=2, c=3), b=2, c=3)
    tup_dict_out = to_namedtuple(tup_dict)
    assert tup_dict_out.a.a == 1
    assert tup_dict_out.b == 2
    

# Generated at 2022-06-11 22:24:25.699733
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import OrderedDict
    from types import SimpleNamespace

    # noinspection PyMethodMayBeStatic

# Generated at 2022-06-11 22:24:34.927039
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    obj
    assert 'a' in obj._fields
    assert obj.a == 1
    assert 'b' in obj._fields
    assert obj.b == 2

    odic = OrderedDict((('a', 1), ('b', 2)))
    obj = to_namedtuple(odic)
    assert 'a' in obj._fields
    assert obj.a == 1
    assert 'b' in obj._fields
    assert obj.b == 2
    assert obj._fields.index('a') == 0
    assert obj._fields.index('b') == 1

    obj = to_namedtuple(SimpleNamespace(**dic))
    assert 'a' in obj._fields
    assert obj.a == 1
   

# Generated at 2022-06-11 22:24:40.523997
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(['a', 'b', 'c']) == ('a', 'b', 'c')
    assert to_namedtuple(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert to_namedtuple({'a': 1, 'b': 2}) == ('a', 'b')
    assert to_namedtuple(OrderedDict((('a', 1), ('b', 2)))) == ('a', 'b')
    assert to_namedtuple({'a': 1, 'b': [2, 3]}) == ('a', 'b')
    assert to_namedtuple({'a': 1, 'b': {'c': 3}}) == ('a', 'b')

# Generated at 2022-06-11 22:24:48.220232
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {
        'a': {
            'b': {
                'c': 'd',
                'e': 'f',
                'g': 'h',
            },
            'i': {
                'j': 'k',
                'l': 'm',
                'n': 'o',
            },
        },
        'p': {
            'r': {
                's': 't',
                'u': 'v',
                'w': 'x',
            },
            'y': {
                'z': '1',
                '2': '3',
                '4': '5',
            },
        },
    }
    nt = to_namedtuple(dic)
    assert nt.a.b.c