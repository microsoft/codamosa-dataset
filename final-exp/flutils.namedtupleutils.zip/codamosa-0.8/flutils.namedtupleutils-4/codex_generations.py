

# Generated at 2022-06-11 22:15:15.609945
# Unit test for function to_namedtuple
def test_to_namedtuple():
    t = to_namedtuple({'a': 1, 'b': 2})
    assert t.a == 1
    assert t.b == 2
    assert t == to_namedtuple({'b': 2, 'a': 1})
    a = OrderedDict([('b', 2), ('a', 1)])
    assert t == to_namedtuple(a)
    a = SimpleNamespace(a=1, b=2)
    assert t == to_namedtuple(a)
    a = SimpleNamespace(b=2, a=1)
    assert t == to_namedtuple(a)
    assert t == to_namedtuple([1, 2])
    assert t == to_namedtuple(tuple([1, 2]))

# Generated at 2022-06-11 22:15:23.234562
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    import json

    dic = {
        'a': 1,
        'b': 2,
        '_c': 3,
        'd_': 4,
        'e-f': 5,
        'g ': 6,
    }

    out = to_namedtuple(dic)
    assert json.dumps(out._asdict(), sort_keys=True) == json.dumps({
        'a': 1, 'b': 2, 'e_f': 5, 'g': 6
    }, sort_keys=True)
    assert out.a == 1


# Generated at 2022-06-11 22:15:33.673448
# Unit test for function to_namedtuple
def test_to_namedtuple():
    def _expand_to_list(in_list: List[Any]) -> List[Any]:
        if not in_list:
            return in_list
        out: List[Any] = []
        for _item in in_list:
            if hasattr(_item, '_fields'):
                _item = cast(NamedTuple, _item)
                out.append(_expand_to_list(list(_item)))
            elif hasattr(_item, 'keys'):
                _item = cast(Sequence, _item)
                out.append(_expand_to_list(list(_item)))
            else:
                out.append(_item)
        return out


# Generated at 2022-06-11 22:15:37.939322
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({"hello": "world"}) == namedtuple('NamedTuple', 'hello')(hello='world')

# Generated at 2022-06-11 22:15:46.793440
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert list(result) == ['a', 'b']
    assert result.a == 1
    assert result.b == 2
    result = to_namedtuple([1, 2, 3])
    assert result == [1, 2, 3]
    result = to_namedtuple((1, 2, 3))
    assert result == (1, 2, 3)
    dic = {10: 11, 'a': 2}
    result = to_namedtuple(dic)
    assert list(result) == ['a', '_2']
    assert result.a == 2
    assert result[1]._10 == 11

# Generated at 2022-06-11 22:15:57.736144
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Tests for function to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple

    namespace = SimpleNamespace(
        a=1,
        b=2,
    )
    actual = to_namedtuple(namespace)
    assert isinstance(actual, NamedTuple)
    assert actual.a == 1
    assert actual.b == 2

    assert to_namedtuple([]) == []
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple(()) == ()
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple({'a': 1, 'b': 2}) == Named

# Generated at 2022-06-11 22:16:00.725893
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(dict(a=1, b=2)) == namedtuple('NamedTuple', 'a b')(1, 2)

# Generated at 2022-06-11 22:16:11.726614
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from decimal import Decimal

    dic_of_dics = {
        'a': {'A': 1, 'B': 2, 'C': 3},
        'b': {'A': 4, 'B': 5, 'C': 6},
        'c': {'A': 7, 'B': 8, 'C': 9},
    }
    dt = to_namedtuple(dic_of_dics)
    assert repr(dt) == """\
NamedTuple(a=NamedTuple(A=1, B=2, C=3), b=NamedTuple(A=4, B=5, C=6), c=NamedTuple(\
A=7, B=8, C=9))"""

# Generated at 2022-06-11 22:16:23.236547
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = [[1, 2], [3, 4]]
    res = to_namedtuple(obj)
    assert obj == res
    assert isinstance(res, list)
    assert isinstance(res[0], tuple)
    assert isinstance(res[1], tuple)

    obj = {'a': 1, 'b': 2}
    res = to_namedtuple(obj)
    assert isinstance(res, namedtuple('NamedTuple', 'a b'))
    assert res.a == 1
    assert res.b == 2

    obj = {'a': 1, '_b': 2}
    res = to_namedtuple(obj)
    assert isinstance(res, namedtuple('NamedTuple', 'a'))
    assert res.a == 1


# Generated at 2022-06-11 22:16:31.656550
# Unit test for function to_namedtuple
def test_to_namedtuple():

    example_0 = {'a': 1, 'b': 2}
    assert _to_namedtuple(example_0) == NamedTuple(a=1, b=2)

    example_1 = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5, 'f': 6}}
    assert _to_namedtuple(example_1) == NamedTuple(a=1, b=2, c=NamedTuple(d=4, e=5, f=6))

    example_2 = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4, 'f': 5, 'g': 6}, 'h': 7}

# Generated at 2022-06-11 22:16:41.465287
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    dic_dic = {'a': {'b': 1}, 'c': [1, 2, 3, 4]}
    nt_dic_dic = to_namedtuple(dic_dic)
    test_dic_dic = NamedTuple(a=NamedTuple(b=1), c=[1, 2, 3, 4])
    assert nt_dic_dic == test_dic_dic

    dic_lst_dic = {'a': [{'b': 1, 'c': 2}, {'d': 3, 'e': 4}], 'f': 5}
    nt_dic_lst_dic = to_namedtuple(dic_lst_dic)
    test_dic_lst_dic

# Generated at 2022-06-11 22:16:53.928538
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test the namedtuple converter."""
    from flutils.namedtupleutils import to_namedtuple

    data = {
        'a': {'b': {'c': 'foobar'}},
        'b': {'b': {'c': 'foobar'}},
        'c': {'b': {'c': 'foobar'}},
    }

    # Only namedtupes
    result = to_namedtuple(data)
    assert result.a.b.c == 'foobar'
    assert result.b.b.c == 'foobar'
    assert result.c.b.c == 'foobar'
    assert isinstance(result.a, tuple)
    assert isinstance(result.b, tuple)
    assert isinstance(result.c, tuple)

# Generated at 2022-06-11 22:17:01.195358
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple({'a': 1, 'b': 2, '_c': 3}) == NamedTuple(a=1, b=2)
    assert to_namedtuple([{'a': 1, 'b': 2, '_c': 3}]) == [NamedTuple(a=1, b=2)]

# Generated at 2022-06-11 22:17:10.357289
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test function to_namedtuple"""
    from collections import OrderedDict
    from types import SimpleNamespace

    obj = [1, 'a']
    assert to_namedtuple(obj) == obj
    obj = tuple(obj)
    assert to_namedtuple(obj) == obj
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == OrderedDict([('a', 1), ('b', 2)])
    obj = OrderedDict(obj)
    assert to_namedtuple(obj) == obj
    obj = SimpleNamespace(**obj)
    assert to_namedtuple(obj) == obj

    obj = {'a': 1, 'b': {'x': 2, 'y': 3}}

# Generated at 2022-06-11 22:17:20.183790
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Unit test for `to_namedtuple`."""
    from unittest.mock import MagicMock, call

    from flutils.namedtupleutils import to_namedtuple

    mock_to_namedtuple = MagicMock(
        name='to_namedtuple',
        side_effect=to_namedtuple,
        autospec=True
    )
    mock_to_namedtuple.__get__ = MagicMock(name='__get__', autospec=True)

    dic = {'a': 1, 'b': 2}
    expected = 'NamedTuple(a=1, b=2)'
    out = to_namedtuple(dic)
    assert str(out) == expected


# Generated at 2022-06-11 22:17:28.168563
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        OrderedDict,
        namedtuple,
    )
    from collections.abc import (
        Mapping,
        Sequence,
    )
    from typing import (
        Any,
        Dict,
        List,
        Mapping,
        NamedTuple,
        Sequence,
        Tuple,
        Union,
    )
    from types import SimpleNamespace
    from flutils.tests import test_utils
    from flutils.namedtupleutils import to_namedtuple

    # noinspection PyTypeChecker
    # noinspection PyTypeHints
    _result = test_utils.ResultCollector()  # type: ignore[no-untyped-call]


# Generated at 2022-06-11 22:17:37.527880
# Unit test for function to_namedtuple
def test_to_namedtuple():
    a = [
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
        {'a': 1, 'b': 2},
    ]
    a = to_namedtuple(a)
    assert isinstance(a, list)
    assert isinstance(a[0], NamedTuple)
    assert isinstance(a[1], NamedTuple)
    assert isinstance(a[2], NamedTuple)
    assert a[0].a == a[1].a == a[2].a
    assert a[0].b == a[1].b == a[2].b


# Generated at 2022-06-11 22:17:48.074748
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections
    from flutils.namedtupleutils import to_namedtuple

    # Test tuple
    tup = ('a', 'b', 'c')
    ntup = to_namedtuple(tup)
    assert ntup is tup

    # Test list
    lst = ['a', 'b', 'c']
    nlst = to_namedtuple(lst)
    assert nlst is lst

    class CustomType:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    ct = CustomType('a', 'b', 'c')
    ct_nt = to_namedtuple(ct)
    assert ct_nt is ct

    # Test flat dictionary

# Generated at 2022-06-11 22:17:50.366794
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:18:02.441430
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # NOTE: This is the unittest module from Python 3
    from unittest import TestCase
    from typing import DefaultDict

    from collections import defaultdict
    from flutils.textutils import camel_to_snake, snake_to_camel

    # noinspection PyArgumentList
    class ToNamedTupleTests(TestCase):
        """Test :func:`to_namedtuple`."""


# Generated at 2022-06-11 22:18:11.759565
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert isinstance(to_namedtuple(dict(first_name='John', last_name='Doe'))
                      , NamedTuple)
    assert to_namedtuple(dict(first_name='John', last_name='Doe'))._fields == ('first_name', 'last_name')


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:18:19.403755
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    import random
    import uuid
    import pytest
    from collections import OrderedDict
    import flutils.namedtupleutils as namedtupleutils

    # dicts
    dic = {}
    dic2 = namedtupleutils.to_namedtuple(dic)
    assert len(dic2._fields) == 0
    assert dic2._fields == ()

    dic = dict(a=1)
    dic2 = namedtupleutils.to_namedtuple(dic)
    assert hasattr(dic2, 'a')
    assert dic2.a == 1

    dic = dict(a=1, b=2)
    dic2 = namedtupleutils.to_namedtuple(dic)

# Generated at 2022-06-11 22:18:27.824806
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    import copy

    # Simple test
    dic1 = {'a': 1, 'b': 2}
    nt1 = to_namedtuple(dic1)
    assert isinstance(nt1, NamedTuple)
    assert nt1.a == 1
    assert nt1.b == 2

    # Simple test with OrderedDict
    dic1 = OrderedDict()
    dic1['a'] = 1
    dic1['b'] = 2
    nt1 = to_namedtuple(dic1)
    assert isinstance(nt1, NamedTuple)
    assert nt1.a == 1
    assert nt1.b == 2

    # Simple test with SimpleNamespace
    n1 = SimpleNamespace()
    n1.a = 1
    n

# Generated at 2022-06-11 22:18:36.689769
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    assert to_namedtuple(namedtuple('abc', [])) == namedtuple('abc', [])
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)
    dic = {'A': 1, 'B': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', 'a b')(1, 2)
    dic = {'A': 1, 'B': 2, 'a': 3, 'b': 4}

# Generated at 2022-06-11 22:18:38.344350
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    # noinspection Mypy
    assert isinstance(obj, namedtuple)  # type: ignore[misc]
    assert obj.a == 1
    assert obj.b == 2



# Generated at 2022-06-11 22:18:48.043353
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import datetime
    import re
    import copy
    import flutils.namedtupleutils
    import distutils.version
    assert flutils.__version__ == '0.8.1'
    if distutils.version.LooseVersion(flutils.__version__) >= distutils.version.LooseVersion('0.9.2'):
        from flutils.typing import _AllowedTypes
    else:
        from flutils.typing import _AllowedTypes
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2
    dic = {'a': 1, 'b': 2, 'c': dic}
    obj = to_namedtuple(dic)

# Generated at 2022-06-11 22:18:56.430748
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:19:06.452449
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Tests for function to_namedtuple"""
    from sys import version_info as _version_info  # noqa: F401
    from sys import platform as _platform  # noqa: F401
    from time import time as _time
    from datetime import datetime as _datetime
    from flutils.miscutils import orderless_dict as _orderless_dict

    _orig_python = _version_info
    _orig_platform = _platform
    _orig_time = _time
    _orig_datetime = _datetime
    _orig_orderless_dict = _orderless_dict

    _version_info = SimpleNamespace(major=(2, 7, 14))
    _platform = 'darwin'
    _time = lambda: 0
    _datetime = None

# Generated at 2022-06-11 22:19:17.178308
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert isinstance(out, NamedTuple)
    assert repr(out) == "NamedTuple(a=1, b=2)"
    assert out.a == 1
    assert out[0] == 1

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert isinstance(out, NamedTuple)
    assert isinstance(out, NamedTuple)
    assert repr(out) == "NamedTuple(a=1, b=2)"
    assert out.a == 1
    assert out[0] == 1

    dic = {'a': 1, 'b': 2}

# Generated at 2022-06-11 22:19:28.444791
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import sys
    import pytest
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple
    # Empty List
    assert to_namedtuple([]) == []
    # Empty Tuple
    assert to_namedtuple(()) == ()
    # Empty OrderedDict
    assert to_namedtuple(OrderedDict()) == NamedTuple()
    # Empty dict
    assert to_namedtuple({}) == NamedTuple()
    # Empty SimpleNamespace
    assert to_namedtuple(SimpleNamespace()) == NamedTuple()

    assert to_namedtuple(['a']) == ['a']
    assert to_namedtuple(('a', )) == ('a', )
    assert to_namedtuple({'a': 1}) == Named

# Generated at 2022-06-11 22:19:44.187506
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    tup = (1, 2, 3)
    assert to_namedtuple(tup) == tup
    tup = (1, 2, 3, 'a')
    res = to_namedtuple(tup)
    assert isinstance(res, namedtuple)
    assert res[0] == 1
    assert res[1] == 2
    assert res[2] == 3
    assert res[3] == 'a'
    dic = {'a': 1}
    res = to_namedtuple(dic)
    assert isinstance(res, namedtuple)
    assert res[0] == 1
    tup = (1, 2, 3, (1, 2, ))
    res = to_namedt

# Generated at 2022-06-11 22:19:54.759232
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from types import SimpleNamespace
    from typing import NamedTuple

    # Define the NamedTuple's
    class Bar(NamedTuple):
        a: int
        b: int

    class Foo(NamedTuple):
        x: OrderedDict
        y: Bar
        z: List[int]

    # Define the object to be converted
    dic = OrderedDict([('x', {'a': 1, 'b': 2}),
                       ('y', (1, 2)),
                       ('z', [3, 4])])
    obj = Foo(dic, Bar(3, 4), [5, 6])

    # Convert the object
    out = to_namedtuple(obj)

    # Check

# Generated at 2022-06-11 22:20:02.267174
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import logging
    import sys

    _log = logging.getLogger(__name__)

    log = logging.getLogger(__name__)
    handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter('%(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    log.addHandler(handler)
    log.setLevel(logging.INFO)

    log.debug('Testing function: to_namedtuple')
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    log.info(obj)

# Generated at 2022-06-11 22:20:14.644646
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from unittest import TestCase
    from collections import namedtuple

    class TestToNamedTuple(TestCase):

        def _test_from_dict(self, dic: dict) -> None:
            obj = to_namedtuple(dic)
            self.assertIsInstance(obj, dic.__class__)
            for attr in dic.keys():
                if not attr.isidentifier():
                    continue
                val = getattr(obj, attr)
                self.assertEqual(val, dic[attr])

        def test_from_dict(self) -> None:
            self._test_from_dict({'a': 1, 'b': 2, '_c': 3})
            self._test_from_dict({'a': 1, 'b': 2})


# Generated at 2022-06-11 22:20:21.337877
# Unit test for function to_namedtuple
def test_to_namedtuple():
    # noinspection PyPackageRequirements,PyUnresolvedReferences
    import pytest  # type: ignore[import]

    # pytest tests/testutils/test_namedtupleutils.py -vv


# Generated at 2022-06-11 22:20:30.226444
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from copy import copy
    from typing import Any

    Obj = SimpleNamespace

    dic: OrderedDict = OrderedDict(
        b=2,
        a=1,
    )
    x = to_namedtuple(dic)
    assert isinstance(x, namedtuple)
    assert x.b == 2
    assert x.a == 1

    obj: OrderedDict = OrderedDict(
        b=2,
        a=1,
    )
    assert to_namedtuple(obj).b == 2

    assert to_namedtuple(dic) == to_namedtuple(obj)

    obj = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    x = to_namedtuple

# Generated at 2022-06-11 22:20:40.448345
# Unit test for function to_namedtuple
def test_to_namedtuple():
    d = {
        'a': 1,
        'c': {
            'e': 'some',
            'f': 'some other',
        },
        'd': {
            'e': {
                'f': 'some other',
            },
        },
        'b': 2,
    }
    nt = to_namedtuple(d)
    assert isinstance(nt, NamedTuple)
    assert nt[:2] == (1, 2)
    assert nt.c.e == 'some'
    assert nt.d.e.f == 'some other'
    assert isinstance(nt, NamedTuple)
    assert isinstance(nt.c, NamedTuple)
    assert isinstance(nt.d.e, NamedTuple)
    l = ['a', 'b', 'c']


# Generated at 2022-06-11 22:20:50.108523
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    import types

    dic = {'a': 1, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2
    assert out.c == 3

    dic = {'a': {'c': 1, 'd': 2}, 'b': 2, 'c': 3}
    out = to_namedtuple(dic)
    assert out.a.c == 1
    assert out.a.d == 2
    assert out.b == 2
    assert out.c == 3

    dic = OrderedDict([('a', 'b'), ('b', 2)])
    out = to_namedtuple(dic)
    assert out.a == 'b'

# Generated at 2022-06-11 22:21:00.736425
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Mapping
    from functools import singledispatch
    from types import SimpleNamespace

    obj = object()
    assert isinstance(obj, object)  # For type checking
    try:
        to_namedtuple(obj)
    except TypeError as err:
        assert err.args == (
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                "got: (%r) %s" % (type(obj).__name__, obj),
        )
    else:
        raise AssertionError("Did not raise TypeError")

    obj = 0
    assert isinstance(obj, int)  # For type checking
    try:
        to_namedtuple(obj)
    except TypeError as err:
        assert err

# Generated at 2022-06-11 22:21:12.354222
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import (
        ChainMap,
        Counter,
    )
    from collections.abc import Set
    from datetime import (
        date,
        datetime,
        time,
        timedelta,
    )
    from decimal import Decimal
    from fractions import Fraction
    from io import BytesIO
    import array
    import fractions
    import pathlib
    import re
    import time as time_
    import types
    import typing

    print('\nTesting: to_namedtuple')

    # noinspection PyUnresolvedReferences
    class SomeClass:
        class_attr: str = 'class_attr'

        def __init__(self, inst_attr: str) -> None:
            self.inst_attr: str = inst_attr

    # noinspection PyUnresolvedReferences

# Generated at 2022-06-11 22:21:35.454882
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    import random
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert isinstance(nt, namedtuple('NamedTuple', ('a', 'b')))
    assert nt.a == 1
    assert nt.b == 2
    cpy = nt._replace(a=3, b=4)
    assert isinstance(cpy, namedtuple('NamedTuple', ('a', 'b')))
    assert cpy.a == 3
    assert cpy.b == 4
    assert isinstance(nt._asdict(), dict)
    assert nt._asdict() == {'a': 1, 'b': 2}

# Generated at 2022-06-11 22:21:46.349046
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime
    dic = {
        'a': [1, 2, 3],
        'b': [{'c': 3}, {'c': 1}, {'c': 2}],
        'd': {'c': 1},
        'e': (1, 2, 3),
        'f': tuple([{'c': 3}, {'c': 1}, {'c': 2}]),
        'g': (1, 2, 3, dic['b']),
        'h': {'c': 1},
        'i': datetime(2018, 1, 1),
        'j': datetime.now(),
    }
    out = to_namedtuple(dic)
    out2 = to_namedtuple(out)
    assert out == out2

# Generated at 2022-06-11 22:21:52.982923
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """Test to_namedtuple."""
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict

    dic = dict(a=1, b=2)
    named = to_namedtuple(dic)
    assert named.a == 1
    assert named.b == 2

    dic = OrderedDict(a=1, b=2)
    named = to_namedtuple(dic)
    assert named[0] == 1
    assert named[1] == 2

    dic = dict(a=1, b=2, _c=3)
    named = to_namedtuple(dic)
    assert named.a == 1
    assert named.b == 2
    assert hasattr(named, '_c') is False

    dic = OrderedD

# Generated at 2022-06-11 22:22:02.873018
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    item = [{'a': 1, 'b': 2}]
    out = to_namedtuple(item)
    assert out[0].a == 1
    assert out[0].b == 2

    item = (
        {'a': 1, 'b': 2},
        {'a': 3, 'b': 4},
    )
    out = to_namedtuple(item)
    assert out[0].a == 1
    assert out[0].b == 2
    assert out[1].a == 3
    assert out[1].b == 4


# Generated at 2022-06-11 22:22:12.649509
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import random
    import string
    import unittest

    from collections.abc import Mapping, MutableMapping
    from collections.abc import Sequence, MutableSequence
    from types import SimpleNamespace


    class ToNamedTupleTestCase(unittest.TestCase):

        def test_to_namedtuple(self):
            """Test function to_namedtuple function."""
            dic = dict(a=1, b=2)
            keylist = list(dic.keys())
            random.shuffle(keylist)
            expected = cast(NamedTuple, namedtuple('NamedTuple', keylist))
            expected = expected(**dic)
            result = to_namedtuple(dic)
            self.assertEqual(result, expected)


# Generated at 2022-06-11 22:22:23.460179
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.validators import validate_identifier
    from flutils.namedtupleutils import to_namedtuple
    assert to_namedtuple(['a']) == ['a']
    assert to_namedtuple('a') == 'a'
    assert to_namedtuple(1) == 1
    assert to_namedtuple({'a': 1}) == SimpleNamespace(a=1)
    assert to_namedtuple({'a': 1, 'b': 2}) == SimpleNamespace(a=1, b=2)
    assert to_namedtuple((1,)) == (1,)
    assert to_namedtuple((1, 2)) == (1, 2)
    assert to_namedtuple([1]) == [1]
    assert to

# Generated at 2022-06-11 22:22:32.614817
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint  # noqa
    from flutils.namedtupleutils import to_namedtuple

    dic: dict = {
        'a': 11, 'c': {'d': {'e': 4}, 'f': 5}, 'g': 6,
        'h': {'i': {'j': {'k': {'l': 9, 'm': 10}}}},
    }

    ntup = to_namedtuple(dic)
    assert ntup == namedtuple('NamedTuple', sorted(dic.keys()))(**dic)

    # If keys are not valid identifiers, but values are valid, the
    # values are still used (recursively).


# Generated at 2022-06-11 22:22:42.912219
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Test to_namedtuple function
    """
    # noinspection PyProtectedMember,Mypy
    _to_namedtuple({
        'hello': 1,
        'world': {
            'a': 2,
            'b': {'c': 3}
        }
    })
    # noinspection PyProtectedMember,Mypy
    _to_namedtuple(['hello', 'world'])
    # noinspection PyProtectedMember,Mypy
    _to_namedtuple(['hello', {'world': 'world'}])
    # noinspection PyProtectedMember,Mypy
    _to_namedtuple((1, 2, 'three'))
    # noinspection PyProtectedMember,Mypy
    _to_namedtuple(OrderedDict(hello='world'))
    #

# Generated at 2022-06-11 22:22:46.816117
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple((('a', 1), ('b', 2))) == to_namedtuple([('a', 1), ('b', 2)]) == to_namedtuple({'b': 2, 'a': 1})

# Generated at 2022-06-11 22:22:49.866770
# Unit test for function to_namedtuple
def test_to_namedtuple():
    test_obj = {"a":1,'b':2}
    test_obj1 = to_namedtuple(test_obj)
    assert test_obj1.a == 1
    assert test_obj1.b == 2

# Generated at 2022-06-11 22:23:23.522335
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing function to_namedtuple')
    from flutils.namedtupleutils import to_namedtuple
    from collections import (
        namedtuple,
        OrderedDict
    )
    from types import (
        SimpleNamespace,
    )
    from pprint import pprint  # noqa: F401

    dic = OrderedDict((
        ('c', 3),
        ('a', 1),
        ('b', 2),
        ('d', 4),
    ))

    t = to_namedtuple(dic)
    print('\tOrderedDict')
    pprint(t)

    dic = dict(dic)
    t = to_namedtuple(dic)
    print('\tdict')
    pprint(t)


# Generated at 2022-06-11 22:23:33.351624
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest

    dic = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert result.a == 1
    assert result.b == 2

    result = to_namedtuple(dic)
    assert result.a == 1

    result = to_namedtuple(result)
    assert result.a == 1

    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        to_namedtuple(None)

    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        to_namedtuple(1)

# Generated at 2022-06-11 22:23:44.837652
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import json
    import os
    import sys

    _path = os.path.dirname(os.path.realpath(__file__))
    _path = os.path.join(_path, 'tests')
    _path = os.path.join(_path, 'test_data')
    _path = os.path.join(_path, 'namedtupleutils')

    with open(os.path.join(_path, 'namedtupleutils_data.json')) as fh:
        data = json.load(fh)

    #noinspection SpellCheckingInspection

# Generated at 2022-06-11 22:23:52.212101
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    dic = to_namedtuple(dic)
    assert dic.a == 1
    assert dic.b == 2
    dic = to_namedtuple([{'a': 1}, {'b': 2}])
    assert dic[1].b == 2
    dic = to_namedtuple(({'a': 1, 'b': 2},))
    assert dic[0].b == 2
    dic = to_namedtuple({'a': 1, 'b': [1, 2, 3]})
    assert dic.b[2] == 3

# Generated at 2022-06-11 22:23:58.496275
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from collections.abc import Mapping
    from types import SimpleNamespace

    def _check(
            d: Mapping,
            expected_keys: List[str],
            expected_vals: List[Any]
    ) -> None:
        nt = to_namedtuple(d)
        keys = list(nt._fields)
        vals = [getattr(nt, key) for key in nt._fields]
        assert keys == expected_keys
        assert vals == expected_vals

    # In each test:
    #   - The expected keys are the keys in the original dictionary
    #       that could be used as a namedtuple attribute.
    #   - The expected_vals are the items in the original dictionary
    #       for the expected_keys.


# Generated at 2022-06-11 22:24:07.486190
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    # Basic
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert isinstance(obj, NamedTuple)
    assert obj.a == 1
    assert obj.b == 2

    # OrderedDict
    odic = OrderedDict()
    odic['a'] = 1
    odic['b'] = 2
    obj = to_namedtuple(odic)
    assert isinstance(obj, NamedTuple)
    assert obj.a == 1
    assert obj.b == 2

    # SimpleNamespace
    s = SimpleNamespace(a=1, b=2)
    obj = to_namedtuple(s)
    assert isinstance(obj, NamedTuple)
    assert obj.a == 1


# Generated at 2022-06-11 22:24:18.009945
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert(to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2))
    assert(to_namedtuple({'B': 1, 'a': 2}) == NamedTuple(B=1, a=2))
    assert(to_namedtuple(OrderedDict([('b', 1), ('a', 2)])) == NamedTuple(b=1, a=2))
    assert(to_namedtuple(OrderedDict([('B', 1), ('a', 2)])) == NamedTuple(B=1, a=2))
    assert(to_namedtuple(SimpleNamespace(a=1, b=2)) == NamedTuple(a=1, b=2))

# Generated at 2022-06-11 22:24:29.083632
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing module namedtupleutils.py ...')
    assert to_namedtuple({'a': 1, 'b': 2}) == cast(NamedTuple, NamedTuple(a=1, b=2))
    assert to_namedtuple(OrderedDict(abc=1, cba=2)) == cast(NamedTuple, NamedTuple(abc=1, cba=2))
    assert to_namedtuple({None: None}) == cast(NamedTuple, NamedTuple())
    assert to_namedtuple({'a': {'b': {'c': 3}}}) == cast(NamedTuple, NamedTuple(a=NamedTuple(b=NamedTuple(c=3))))

# Generated at 2022-06-11 22:24:37.244161
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest


# Generated at 2022-06-11 22:24:47.764315
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('TESTING: to_namedtuple\n')
    print('Test1')
    dic = {'a': 1, 'b': 2}
    expected = 'NamedTuple(a=1, b=2)'
    got = str(to_namedtuple(dic))
    assert got == expected
    print(f'  {got}\n')

    print('Test2')
    input = {'a': 1, 'b': 2}
    expected = 'NamedTuple(a=1, b=2)'
    got = str(to_namedtuple(input))
    assert got == expected
    print(f'  {got}\n')

    print('Test3')
    input = (1, 2, 3)
    expected = '(1, 2, 3)'