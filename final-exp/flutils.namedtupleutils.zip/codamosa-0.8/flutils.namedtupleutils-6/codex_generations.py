

# Generated at 2022-06-11 22:15:03.935395
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from types import SimpleNamespace
    from flutils.collections_utils import OrderedSet

    dic = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    dic2 = OrderedDict(a=3, b=2, c=1)
    dic3 = OrderedDict([('a', 3), ('b', 2), ('c', 1)])
    dic4 = OrderedDict([('a', 3), ('b', 2)])
    dic5 = {'a': 1, 'b': 2, 'c': 3}
    dic6 = {'a': 3, 'b': 2, 'c': 1}
    dic7 = {'a': 3, 'b': 2}

# Generated at 2022-06-11 22:15:16.029657
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict

    dic = {'a': 1, 'b': 2, 'c': 3}
    nt = to_namedtuple(dic)
    assert nt is not dic
    assert nt.a == dic['a']
    assert nt.b == dic['b']
    assert nt.c == dic['c']
    assert isinstance(nt, namedtuple)
    assert isinstance(nt, tuple)
    assert isinstance(nt, Mapping)
    assert len(nt) == 3
    assert dic['a'] == 1
    assert dic['b'] == 2
    assert dic['c'] == 3

    dic = {'a': 1, 'b': 2, 'c': 3, 'd': 'bad'}
    nt = to_named

# Generated at 2022-06-11 22:15:23.436664
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import OrderedDict
    from collections import namedtuple
    from functools import singledispatch
    from types import SimpleNamespace

    lst = [1, 2, 3, {'a': 4, 'b': 5, 'c': 6}, 7]
    assert to_namedtuple(lst) == [1, 2, 3, NamedTuple(a=4, b=5, c=6), 7]

    tup = (1, 2, 3, {'a': 4, 'b': 5, 'c': 6}, 7)
    assert to_namedtuple(tup) == (1, 2, 3,
                                  NamedTuple(a=4, b=5, c=6), 7)


# Generated at 2022-06-11 22:15:33.820496
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == cast(NamedTuple, dic)
    odic = OrderedDict()
    odic.update(dic)
    assert to_namedtuple(odic) == cast(NamedTuple, odic)
    ns = SimpleNamespace()
    ns = cast(SimpleNamespace, ns)
    ns.a = 1
    ns.b = 2
    assert to_namedtuple(ns) == cast(NamedTuple, ns.__dict__)
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    lst = [1, 2, 3]
    assert to_namedtuple(lst) == cast(NamedTuple, lst)




# Generated at 2022-06-11 22:15:45.396017
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from unittest import mock

    class TestNamedTupleUtils(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_to_namedtuple_return_type(self):
            dic = {'a': [1, 2, 3]}
            obj = to_namedtuple(dic)
            self.assertIsInstance(obj, namedtuple)
            self.assertIsInstance(obj.a, list)
            self.assertEqual(obj.a, [1, 2, 3])
            dic = {'a': (1, 2, 3)}
            obj = to_namedtuple(dic)
            self.assertIsInstance(obj, namedtuple)

# Generated at 2022-06-11 22:15:57.188983
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic: Mapping[str, Any] = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    exp_dic = NamedTuple(a=1, b=2, c=NamedTuple(d=3, e=4))
    assert to_namedtuple(dic) == exp_dic


if __name__ == '__main__':

    from flutils.namedtupleutils import to_namedtuple
    from flutils.textutils import (
        indent,
        print_json,
    )

    def _test_print_json(obj: Any) -> None:
        print('ORIGINAL')
        print(indent(repr(obj), ' ' * 4))
        print()
        print('JSON')
        print_json(obj)

# Generated at 2022-06-11 22:16:09.183172
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple

    dic_obj = {
        'a': {
            'one': 1,
            'two': 2,
        },
        'b': {
            'one': 1,
            'two': 2,
        },
    }
    test_func = lambda: to_namedtuple(dic_obj)
    expected_results = 'NamedTuple(a=NamedTuple(one=1, two=2), b=NamedTuple(one=1, two=2))'

    assert str(test_func()) == expected_results

    dic_obj['a']['two'] = 'notint'

# Generated at 2022-06-11 22:16:16.422954
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:16:25.579301
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Test for function to_namedtuple.
    """
    from flutils.namedtupleutils import to_namedtuple
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == OrderedDict([('a', 1), ('b', 2)])
    dic['_c'] = 3
    with pytest.raises(SyntaxError):
        to_namedtuple(dic)
    dic['c'] = 4
    out = to_namedtuple(dic)
    assert isinstance(out, OrderedDict)
    assert tuple(out) == tuple(OrderedDict([('a', 1), ('b', 2), ('c', 4)]))
    assert out['a'] == 1
    assert out['b'] == 2

# Generated at 2022-06-11 22:16:33.853957
# Unit test for function to_namedtuple
def test_to_namedtuple():
    yam: str = """
# YAML file contents for testing to_namedtuple
a:
    a1:
        a11: 1
        a12:
            attr: a12 attribute
            items:
            - one

            - two
                c: 1
                d: 2
                e:
                    a: 1
                    b: 2
                f: 3
                g: 4
                h: 5
            - three
        a13:
            b: 1
            c: 2
            d: 3
    a2:
        a21: 1
        a22: 2
    a3: 3
"""
    import sys
    if sys.version_info > (3, 8):
        # noinspection PyUnresolvedReferences
        from importlib.resources import read_text

# Generated at 2022-06-11 22:16:43.900753
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections import deque
    from collections.abc import Iterable
    from decimal import Decimal
    from datetime import datetime
    from flutils.namedtupleutils import to_namedtuple

    dic = {'d': 4, 'b': 2, 'c': 3, 'a': 1}
    ent = to_namedtuple(dic)
    assert ent.a == 1    # not dic['a']
    assert ent.b == 2    # not dic['b']
    assert ent.c == 3    # not dic['c']
    assert ent.d == 4    # not dic['d']
    assert ent._fields == ('a', 'b', 'c', 'd')

    ent = to_namedtuple(OrderedDict(sorted(dic.items())))
   

# Generated at 2022-06-11 22:16:49.969039
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2


if __name__ == '__main__':
    test_to_namedtuple()

# Generated at 2022-06-11 22:16:50.604604
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-11 22:17:00.539066
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.validators import (
        _validate_identifier,
        _validate_integer,
    )

    # Check for invalid type
    for obj in [1, 1.0, True, b'foo']:
        try:
            to_namedtuple(obj)
        except TypeError:
            pass
        else:
            raise AssertionError(
                "Expected TypeError for %r" % (obj,)
            )

    # Check for empty list, tuple, dict
    # noinspection PyPep8Naming
    NamedTuple: Union[NamedTuple, Tuple, List]
    for obj in [[], (), {}, OrderedDict()]:
        out = to_namedtuple(obj)

# Generated at 2022-06-11 22:17:10.133548
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit test for function to_namedtuple """

    import unittest
    import collections

    class TestToNamedTuple(unittest.TestCase):
        """ Test the function to_namedtuple """

        def test_no_type(self):
            """ Test the function with an invalid type """
            with self.assertRaises(TypeError):
                to_namedtuple(1)

        def test_list(self):
            """ Test the function with lists """
            inp = [1, 2, 3]
            out = to_namedtuple(inp)
            self.assertEqual(out, inp)
            self.assertTrue(isinstance(out, list))

            # having items in list that can be converted to a namedtuple

# Generated at 2022-06-11 22:17:20.133683
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple(dict(a=1, b=2)) == NamedTuple(a=1, b=2)
    assert to_namedtuple(dict(a=1, _b=2)) == NamedTuple(a=1)
    assert to_namedtuple(dict(a=1, B=2)) == NamedTuple(a=1, B=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2)])) == \
        NamedTuple(a=1, b=2)

# Generated at 2022-06-11 22:17:21.513672
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:17:28.871989
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = dict(a=1, b=2)
    nt = to_namedtuple(dic)
    assert (nt.a == 1) and (nt.b == 2)

    dic = dict(a=1, b=2, _c=3)
    nt = to_namedtuple(dic)
    assert (nt.a == 1) and (nt.b == 2) and (not hasattr(nt, '_c'))

    dic = OrderedDict(a=1, b=2)
    nt = to_namedtuple(dic)
    assert tuple(nt._fields) == ('a', 'b')
    dic = dict(b=2, a=1)
    nt = to_namedtuple(dic)

# Generated at 2022-06-11 22:17:39.491336
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    nt = to_namedtuple(dic)
    assert nt.a == nt['a'] == 1
    assert nt.b == nt['b'] == 2
    assert isinstance(nt, tuple)
    assert not isinstance(nt, OrderedDict)
    assert not isinstance(nt, dict)


    dic_ = OrderedDict(dic)
    nt_ = to_namedtuple(dic_)
    assert nt_.a == nt_['a'] == 1
    assert nt_.b == nt_['b'] == 2
    assert isinstance(nt_, tuple)
    assert not isinstance(nt_, OrderedDict)
    assert not isinstance(nt_, dict)


    l

# Generated at 2022-06-11 22:17:49.399776
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': {'b': 1, 'c': [{'d': 2}, {'f': 7}]}, 'g': 5}
    expected = {
        '_fields': ('a', 'g'),
        'a': {
            '_fields': ('b', 'c'),
            'b': 1,
            'c': ({'_fields': ('d',), 'd': 2},
                  {'_fields': ('f',), 'f': 7})
        },
        'g': 5
    }
    out = to_namedtuple(dic)
    assert expected == out.__dict__

    dic = {'a': [1, 2, 3, 4], 'b': 5, 'c': 6}

# Generated at 2022-06-11 22:18:03.245053
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == namedtuple('NamedTuple', ('a', 'b'))(1, 2)
    assert to_namedtuple({'a': 1, 'b': 2}) != namedtuple('NamedTuple', ('b', 'a'))(1, 2)
    assert to_namedtuple({'a': {'b': 1, 'c': 2}, 'd': 2}) == namedtuple('NamedTuple', ('a', 'd'))(namedtuple('NamedTuple', ('b', 'c'))(1, 2), 2)

# Generated at 2022-06-11 22:18:04.549092
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import doctest
    doctest.testmod(verbose=True)
    

# Generated at 2022-06-11 22:18:15.624488
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b == 2

    dic = {'a': 1, 'b': {'c': 3, 'd': 4, 'e': 5}}
    obj = to_namedtuple(dic)
    assert obj.a == 1
    assert obj.b.c == 3
    assert obj.b.d == 4
    assert obj.b.e == 5

    from collections import OrderedDict
    odic = OrderedDict([('a', 1), ('b', 2)])
    obj = to_namedtuple(odic)
    assert obj.a == 1
    assert obj.b == 2


# Generated at 2022-06-11 22:18:25.390516
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:18:35.444844
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.ordereddictutils import to_ordereddict
    dt1 = to_namedtuple(
        [
            OrderedDict(
                [
                    ('a', 1),
                    ('b', OrderedDict(
                        [
                            ('c', 2),
                            ('d', OrderedDict(
                                [
                                    ('e', 3),
                                    (1, 4),
                                    (object(), 5),
                                ]
                            )),
                            (6, (7,)),
                        ]
                    )),
                ]
            ),
            SimpleNamespace(a=1),
            {1: 2, 'a': 3},
        ]
    )

# Generated at 2022-06-11 22:18:45.675181
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from pprint import pprint
    from collections import OrderedDict as Odict
    from flutils.namedtupleutils import to_namedtuple

    print('Testing to_namedtuple()')

    items = ['a', 'b', 'c', 'd']
    dic = {k: v for k, v in enumerate(items, 1)}
    obj = to_namedtuple(dic)
    print('Dict to namedtuple')
    pprint(obj)

    items = [
        {'e': 1, 'f': 2, 'g': 3},
        {'e': 4, 'f': 5, 'g': 6},
    ]
    dic = {k: v for k, v in enumerate(items, 1)}
    obj = to_namedtuple(dic)

# Generated at 2022-06-11 22:18:50.334501
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from datetime import datetime

    from flutils.namedtupleutils import to_namedtuple

    import pytest

    # Basic dictionary.
    dic = {'a': 1, 'b': 2}
    obj = to_namedtuple(dic)
    assert type(obj) is namedtuple('NamedTuple', 'a b')  # type: ignore[name-defined]
    assert obj.a == 1
    assert obj.b == 2

    # List with dictionaries.
    dic_simple = {'a': 1, 'b': 2}
    dic_complex = {'a': 1, 'b': {'a': 2, 'b': 3}}
    obj_simple = to_namedtuple(dic_simple)
    obj_complex = to_namedtuple(dic_complex)
   

# Generated at 2022-06-11 22:19:02.812189
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import os,sys
    
    #sys.path.append('../')

    #import namedtupleutils
    #sys.path.pop(-1)
    
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)  # (a=1, b=2)
    assert out[0] == 1 and out[1] ==2
    dic = {'a': 1, 'b': 2, 'c':3,'_d':4}
    out = to_namedtuple(dic) #(a=1, b=2)
    assert out[0] == 1 and out[1] ==2 and out[2] ==3 and len(out) ==3

# Generated at 2022-06-11 22:19:09.767764
# Unit test for function to_namedtuple
def test_to_namedtuple():
    tuple_test = ('a', 'b', 'c')
    assert tuple_test == to_namedtuple(tuple_test)
    assert (1, 2, 3) == to_namedtuple((1, 2, 3))
    assert ['a'] == to_namedtuple(['a'])
    assert ['a'] == to_namedtuple(('a',))
    assert {'a': 1, 'B': 2} == to_namedtuple({'a': 1, 'B': 2})
    assert {'a': 1, 'B': 2} == to_namedtuple(OrderedDict([('a', 1), ('B', 2)]))
    assert {'a': 1, 'B': 2} == to_namedtuple(['a', 1, 'B', 2])

# Generated at 2022-06-11 22:19:21.977215
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:19:35.269037
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = OrderedDict([('a', 1), ('b', 2)])
    result = to_namedtuple(dic)
    assert result.a == 1
    assert result.b == 2

    dic['a'] = {'a': 1, 'b': 2}
    result = to_namedtuple(dic)
    assert result.a.a == 1
    assert result.a.b == 2

    dic['a'] = [{'a': 1, 'b': 2}, {'c': 3, 'd': 4}]
    result = to_namedtuple(dic)
    assert isinstance(result, NamedTuple)
    assert isinstance(result.a, tuple)
    assert isinstance(result.a[0], NamedTuple)

# Generated at 2022-06-11 22:19:44.303761
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple({'a': 1, 'b': 2}) == NamedTuple(a=1, b=2)
    assert to_namedtuple({'a': 1, 'b': 2, 'c': 2, 'd': 3}) == NamedTuple(a=1, b=2, c=2, d=3)
    assert to_namedtuple([{'a': 1, 'b': 2}]) == [NamedTuple(a=1, b=2)]
    assert to_namedtuple({'a': [{'b': 2}]}) == NamedTuple(a=[NamedTuple(b=2)])

# Generated at 2022-06-11 22:19:54.838475
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import copy
    import unittest

    class ToNamedTupleTest(unittest.TestCase):

        def test_to_namedtuple_exceptions(self):
            dic = {'a': 1, 'b': 2}
            self.assertRaises(
                TypeError,
                to_namedtuple,
                obj=dic,
            )

        def test_to_namedtuple_namedtuple(self):
            Dummy = namedtuple('Dummy', ('a', 'b'))
            dic = Dummy(1, 2)
            self.assertRaises(
                TypeError,
                to_namedtuple,
                obj=dic,
            )


# Generated at 2022-06-11 22:20:03.365545
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    named_tuple = to_namedtuple(dic)
    assert named_tuple.b == 2
    assert named_tuple.a == 1
    dic = OrderedDict()
    dic['a'] = 1
    dic['b'] = 2
    named_tuple = to_namedtuple(dic)
    assert named_tuple.a == 1
    assert named_tuple.b == 2
    dic = ['a', 'b']
    named_tuple = to_namedtuple(dic)
    assert named_tuple == ['a', 'b']
    dic = (1, 2)
    named_tuple = to_namedtuple(dic)
    assert named_tuple == (1, 2)

# Generated at 2022-06-11 22:20:08.842268
# Unit test for function to_namedtuple
def test_to_namedtuple():
    print('Testing function to_namedtuple')
    d = {'a': 1, 'b': 2}
    d1 = to_namedtuple(d)
    assert isinstance(d1, namedtuple('NamedTuple', 'a b'))
    assert d1.a == 1
    assert d1.b == 2
    print('   tests passed')



# Generated at 2022-06-11 22:20:19.397455
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.tests.testutils import (
        fail_unordered,
        is_namedtuple,
    )
    from types import SimpleNamespace

    def test_no_args():
        with fail_unordered(
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                "got: (str) Hello world"
        ):
            to_namedtuple('Hello world')

        with fail_unordered(
                "Can convert only 'list', 'tuple', 'dict' to a NamedTuple; "
                "got: (int) 123"
        ):
            to_namedtuple(123)


# Generated at 2022-06-11 22:20:29.503970
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from datetime import datetime

    dic = {
        'title': 'Python',
        'description': 'A programming language that lets you work quickly '
                       'and integrate systems more effectively.',
        'created': datetime(1991, 2, 20),
    }
    obj: NamedTuple = to_namedtuple(dic)
    assert obj.title == 'Python'
    assert obj.description == 'A programming language that lets you work ' \
                              'quickly and integrate systems more effectively.'
    assert obj.created == datetime(1991, 2, 20)

    obj = to_namedtuple(obj)
    assert obj.title == 'Python'

# Generated at 2022-06-11 22:20:33.259567
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

# Generated at 2022-06-11 22:20:41.334845
# Unit test for function to_namedtuple
def test_to_namedtuple():
    result = to_namedtuple({'a': 1, 'b': 2})
    assert 'a' in result
    assert 'b' in result
    assert isinstance(result, namedtuple('NamedTuple', 'a b'))

    result = to_namedtuple([{'a': 1, 'b': 2}, {'a': 1, 'b': 2}])
    assert 'a' in result
    assert 'b' in result
    assert isinstance(result, list)
    for item in result:
        assert isinstance(item, namedtuple('NamedTuple', 'a b'))

    result = to_namedtuple([[{'a': 1, 'b': 2}], {'a': 1, 'b': 2}])
    assert 'a' in result
    assert 'b' in result

# Generated at 2022-06-11 22:20:50.484642
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import OrderedDict
    from collections.abc import Sequence
    from types import SimpleNamespace
    from flutils.namedtupleutils import to_namedtuple

    # noinspection PyMethodMayBeStatic,PyShadowingNames,PyUnusedLocal
    class Test:
        def __init__(self):
            self.a = 1
            self.b = 2


    assert to_namedtuple([1, 2, 3]) == [1, 2, 3]
    assert to_namedtuple((1, 2, 3)) == (1, 2, 3)
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(dict(a=1, b=2))

# Generated at 2022-06-11 22:21:03.750798
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import flutils.namedtupleutils as ntu
    dic = {'a': 1, 'b': 2}
    ntu.to_namedtuple(dic)
    lst = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
    ntu.to_namedtuple(lst)
    dic = {'a': 1, 'b': 2}
    rdo = ntu.to_namedtuple(dic)
    assert rdo.a == 1
    assert rdo.b == 2
    tup = (1, 2, 3)
    rdo = ntu.to_namedtuple(tup)
    assert rdo[0] == 1
    assert rdo[1] == 2
    assert rdo[2] == 3
    lst

# Generated at 2022-06-11 22:21:14.083475
# Unit test for function to_namedtuple
def test_to_namedtuple():
    """ Unit testing for function to_namedtuple.
    """
    import pytest  # type: ignore[import]
    from flutils.namedtupleutils import to_namedtuple

    good_list = [{'a': 1}, {'b': 2}]
    good_tuple = (1, 2)
    good_dict = {'a': 1, 'b': 2}
    good_ordered_dict = OrderedDict(a=1, b=2)
    good_simple_namespace = SimpleNamespace(a=1, b=2)

    bad_list = [1]
    bad_tuple = 1
    bad_dict = {'a': 1, 2: 2}

# Generated at 2022-06-11 22:21:23.304643
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from collections import namedtuple
    from flutils.namedtupleutils import to_namedtuple

    tup = namedtuple('A', ['a', 'b'])(1, 2)
    assert to_namedtuple(tup) == tup

    dic = OrderedDict([('a', 1), ('b', 2)])
    assert to_namedtuple(dic) == tup

    dic = OrderedDict([('b', 2), ('a', 1)])
    assert to_namedtuple(dic) == tup

    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == tup

    dic = {'b': 2, 'a': 1}
    assert to_namedtuple(dic) == tup

    # noins

# Generated at 2022-06-11 22:21:23.845107
# Unit test for function to_namedtuple
def test_to_namedtuple():
    pass

# Generated at 2022-06-11 22:21:31.116203
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import pytest
    from collections.abc import Sequence
    from collections import OrderedDict

    with pytest.raises(TypeError):
        to_namedtuple(1)
    
    dct = {
        'a': 1,
        'b': 2,
        'c': {
            'a': 1,
            'b': 2,
            'c': 3
        },
        'd': {
            'a': {
                'a': 1,
                'b': 2,
                'c': 3
            },
            'b': {
                'a': 1,
                'b': 2,
                'c': 3
            },
            'c': {
                'a': 1,
                'b': 2,
                'c': 3
            }
        }
    }
    
    nt

# Generated at 2022-06-11 22:21:39.985865
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import collections

    # Arrange
    object_map = {
        'dict': {'a': 1, 'b': 2},
        'ordereddict': collections.OrderedDict([
            ('a', 1),
            ('b', 2)
        ]),
        'list': [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}],
        'tuple': ({'a': 1, 'b': 2}, {'a': 3, 'b': 4}),
        'simplenamespace': SimpleNamespace(a=1, b=2),
    }

# Generated at 2022-06-11 22:21:50.944580
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = {'a': 1, 'b': 2}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)

    obj = {'a': 1, 'b': 2, '_c': 3}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)

    obj = {'a': 1, 'b': 2, '_c': 3, 'd_': 4}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2)

    obj = {'a': 1, 'b': 2, '_c': 3, 'd_': 4, 'e': 5}
    assert to_namedtuple(obj) == NamedTuple(a=1, b=2, e=5)

    obj = Ord

# Generated at 2022-06-11 22:22:01.462686
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestToNamedTuple(unittest.TestCase):

        def test_to_namedtuple_list(self):
            lis = [{'a': 1, 'b': 2}]
            tn: List[NamedTuple] = to_namedtuple(lis)
            self.assertIsInstance(tn, list)
            self.assertIsInstance(tn[0], NamedTuple)
            self.assertEqual(tn[0].a, 1)
            self.assertEqual(tn[0].b, 2)

        def test_to_namedtuple_tuple(self):
            tup = ({'a': 1, 'b': 2},)
            tn: Tuple[NamedTuple] = to_namedtuple(tup)
            self.assertIsInstance

# Generated at 2022-06-11 22:22:11.751814
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import to_namedtuple
    from collections import namedtuple
    from types import SimpleNamespace
    from copy import copy
    from typing import Dict, List, Tuple

    dct = {'a': 1, 'b': 2}
    assert to_namedtuple(dct) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert type(to_namedtuple(dct)) == namedtuple('NamedTuple', ['a', 'b'])

    dct = {'_a': 1, 'b': 2}
    assert to_namedtuple(dct) == namedtuple('NamedTuple', ['b'])(b=2)

# Generated at 2022-06-11 22:22:22.645219
# Unit test for function to_namedtuple
def test_to_namedtuple():
    from flutils.namedtupleutils import (
        to_namedtuple,
    )
    from pprint import pformat
    from typing import (
        Any,
        Dict,
        NamedTuple,
    )

    def check_namedtuple(
            obj: Any,
            expected: Dict[str, Any]
    ) -> None:
        with_expected = to_namedtuple(obj)
        actual = f"{with_expected._fields} ({with_expected})"
        expected_ = f"{tuple(sorted(expected.keys()))} ({tuple(sorted(expected.values()))})"
        assert actual == expected_

    check_namedtuple(  # type: ignore[arg-type]
        obj={},
        expected={}
    )


# Generated at 2022-06-11 22:22:42.397253
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(list()) == []
    assert to_namedtuple(tuple()) == ()
    assert to_namedtuple([]) == []
    assert to_namedtuple([[]]) == [[]]
    assert to_namedtuple([{}]) == [NamedTuple()]
    assert to_namedtuple({}) == NamedTuple()
    assert to_namedtuple([{'a': 1}]) == [NamedTuple(a=1)]
    assert to_namedtuple([{'a': 1, 'b': 2}, {'c': 3}]) == [NamedTuple(a=1, b=2), NamedTuple(c=3)]
    assert to_namedtuple({'a': 1}) == NamedTuple(a=1)

# Generated at 2022-06-11 22:22:53.045343
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from collections import (
        namedtuple,
        OrderedDict,
    )
    from itertools import cycle
    from random import choice
    from types import SimpleNamespace

    class _TestNamedTuple(unittest.TestCase):
        _identifiers = ('a', 'b', 'c', 'd', 'e')
        _non_identifiers = ('*', '@', '~=')
        _mixed_identifiers = cycle(chain(_identifiers, _non_identifiers))
        _make_namedtuple = namedtuple('NamedTuple', _identifiers)

        def setUp(self):
            self._obj = self._make_namedtuple(*range(len(self._identifiers)))

        def test_convert(self):
            obj = self._obj
           

# Generated at 2022-06-11 22:23:04.445763
# Unit test for function to_namedtuple
def test_to_namedtuple():
    dic = {'a': 1, 'b': 2}
    assert to_namedtuple(dic) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)) == namedtuple('NamedTuple', ['a', 'b'])(a=1, b=2)
    assert to_namedtuple(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) == namedtuple('NamedTuple', ['a', 'b', 'c'])(a=1, b=2, c=3)

# Generated at 2022-06-11 22:23:15.151318
# Unit test for function to_namedtuple
def test_to_namedtuple():
    'Test function to_namedtuple'
    __tracebackhide__ = True
    expected = NamedTuple(a=1, b=2)
    actual = to_namedtuple({'a': 1, 'b': 2})
    assert actual == expected
    expected = NamedTuple(a=1, b=2)
    actual = to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert actual == expected
    expected = NamedTuple(a=1, b=2)
    actual = to_namedtuple(SimpleNamespace(a=1, b=2))
    assert actual == expected
    expected = NamedTuple(a=NamedTuple(c=3), b=2)

# Generated at 2022-06-11 22:23:24.244897
# Unit test for function to_namedtuple

# Generated at 2022-06-11 22:23:35.145661
# Unit test for function to_namedtuple
def test_to_namedtuple():

    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple([('a', 1), ('b', 2)])
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple((('a', 1), ('b', 2)))
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple({'a': 1, 'b': 2})
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(OrderedDict([('a', 1), ('b', 2)]))
    assert to_namedtuple({'a': 1, 'b': 2}) == to_namedtuple(OrderedDict([('b', 2), ('a', 1)]))
    x = to_named

# Generated at 2022-06-11 22:23:45.323346
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest

    class TestCase(unittest.TestCase):

        def test_list(self):
            from collections import namedtuple
            dic = {'a': 1, 'b': 2}
            make = namedtuple('NamedTuple', 'a b')
            args = [make(**dic), dic]
            out = to_namedtuple(args)
            self.assertEqual(out, args)

        def test_dict(self):
            from collections import namedtuple
            dic = {'a': 1, 'b': 2}
            make = namedtuple('NamedTuple', 'a b')
            out = to_namedtuple(dic)
            args = [make(**dic), dic]
            self.assertEqual(out, args[0])

       

# Generated at 2022-06-11 22:23:49.555752
# Unit test for function to_namedtuple
def test_to_namedtuple():
    with open('tests/fixtures/example_data.json') as infile:
        obj = json.load(infile)
    ntuple = to_namedtuple(obj)
    assert hasattr(ntuple, 'resources')
    assert isinstance(getattr(ntuple, 'resources'), list)
    assert isinstance(ntuple.resources[0], dict)

# Generated at 2022-06-11 22:23:57.575304
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import unittest
    from typing import Optional

    class ToNamedTupleTests(unittest.TestCase):

        def test_to_namedtuple_dict(self):

            def test_dict_with_valid_identifier_key():
                dic: Mapping = {'a': 1, 'b': 2}
                out: NamedTuple = to_namedtuple(dic)
                # noinspection PyProtectedMember
                self.assertTrue(hasattr(out, '_fields'))
                self.assertEqual(out._fields, ('a', 'b'))
                self.assertEqual(out.a, 1)
                self.assertEqual(out.b, 2)


# Generated at 2022-06-11 22:24:06.958951
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(1) == 1
    assert to_namedtuple({1: 2, 3: 4}) == NamedTuple(**{1: 2, 3: 4})
    assert to_namedtuple({1: 2, 3: 4, '_5': 6}) == NamedTuple(**{1: 2, 3: 4})
    assert to_namedtuple({1: 2, 3: 4, '5': 6}) == NamedTuple(**{1: 2, 3: 4})
    assert to_namedtuple({'a': 2, 'b': 4}) == NamedTuple(a=2, b=4)
    assert to_namedtuple({'a': 2, 'b': 4, '_5': 6}) == NamedTuple(a=2, b=4)

# Generated at 2022-06-11 22:24:39.701650
# Unit test for function to_namedtuple
def test_to_namedtuple():
    assert to_namedtuple(
        [OrderedDict(**{'a': 1, 'b': 2}), OrderedDict(**{'x': 3, 'y': 4})]
    ) == (NamedTuple(a=1, b=2), NamedTuple(x=3, y=4))


# Generated at 2022-06-11 22:24:48.002646
# Unit test for function to_namedtuple
def test_to_namedtuple():
    obj = [
        ['a', 'b', 'c'],
        ['d', 'e', 'f'],
    ]
    target = [
        NamedTuple(a='a', b='b', c='c'),
        NamedTuple(a='d', b='e', c='f')
    ]
    assert to_namedtuple(obj) == target
    obj = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    target = NamedTuple(a=1, b=2, c=3)
    assert to_namedtuple(obj) == target
    obj = OrderedDict({
        'a': 1,
        'b': 2,
        'c': 3,
    })

# Generated at 2022-06-11 22:24:57.433094
# Unit test for function to_namedtuple
def test_to_namedtuple():
    import dataclasses

    @dataclasses.dataclass()
    class NamedObject:
        obj_type: str
        obj_data: dict

    dic = {'a': 1, 'b': 2}
    out = to_namedtuple(dic)
    assert out.a == 1
    assert out.b == 2

    mylist = [1, 2]
    out = to_namedtuple(mylist)
    assert out[0] == 1
    assert out[1] == 2

    mytuple = (1, 2)
    out = to_namedtuple(mytuple)
    assert out[0] == 1
    assert out[1] == 2

    mydict = {'a': [1, 2], 'b': 3}
    out = to_namedtuple(mydict)
   