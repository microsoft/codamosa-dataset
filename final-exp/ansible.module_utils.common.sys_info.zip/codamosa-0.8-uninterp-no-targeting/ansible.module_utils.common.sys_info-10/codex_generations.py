

# Generated at 2022-06-20 16:15:28.387637
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Class Hierarchy:
    #
    #   TestSuperClass
    #   |-- TestSubClass1 (platform=Linux, distribution='Ubuntu')
    #   |
    #   |-- TestSubClass2 (platform=Linux, distribution='OtherLinux')
    #   |
    #   |-- TestSubClass3 (platform=Linux, distribution=None)
    #   |
    #   |-- TestSubClass4 (platform=OtherPlatform, distribution=None)
    #       |-- TestSubSubClass1 (platform=OtherPlatform, distribution='Ubuntu')
    #

    class TestSuperClass(object):
        platform = None
        distribution = None

    class TestSubClass1(TestSuperClass):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class TestSubClass2(TestSuperClass):
        platform = 'Linux'

# Generated at 2022-06-20 16:15:39.512662
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class a:
        pass
    class a_b:
        platform = 'a'
        distribution = None
    class a_c:
        platform = 'a'
        distribution = 'c'
    class a_b_d:
        platform = 'a'
        distribution = 'd'
    class b:
        platform = 'b'
        distribution = None
    class b_d:
        platform = 'b'
        distribution = 'd'

    get_all_subclasses(a)
    assert get_platform_subclass(a) == a
    assert get_platform_subclass(a_b) == a_b
    get_all_subclasses(a_b)
    assert get_platform_subclass(a) == a
    assert get_platform_subclass(a_b) == a_b
    get

# Generated at 2022-06-20 16:15:51.463079
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Temporary mock class for below test
    class MockBaseClass:
        distribution = None
        platform = None
        pass

    class MockPlatform:
        distribution = None
        platform = 'MockPlatform'

    class mockPlatform_distroA:
        distribution = 'A'
        platform = 'MockPlatform'

    class mockPlatform_distroB:
        distribution = 'B'
        platform = 'MockPlatform'

    class mockPlatform_distroC:
        distribution = 'C'
        platform = 'MockPlatform'

    class MockLinux_distroA(MockPlatform, mockPlatform_distroA):
        pass

    class MockLinux_distroB(mockPlatform_distroB):
        platform = 'MockLinux'


# Generated at 2022-06-20 16:16:03.360645
# Unit test for function get_distribution
def test_get_distribution():
    import sys
    if sys.version_info[0] < 3:
        from tests.support.mock import patch
    else:
        from unittest.mock import patch

    def _test_get_distribution_version(distro_string):
        with patch('ansible.module_utils.distro._distro_version', return_value=distro_string):
            if distro_string:
                assert get_distribution_version() == distro_string
            else:
                assert get_distribution_version() == ''

    # Test get_distribution_version() with the various supported "distro" strings
    _test_get_distribution_version(u'arch')
    _test_get_distribution_version(u'centos')
    _test_get_distribution_version(u'scientific')

# Generated at 2022-06-20 16:16:15.577539
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from . import module_common
    from . import freebsd_utils

    def _test_platform(platform, expected_version):
        module_common.DEFAULT_SUDO_USER = 'not used for testing'
        module_common.ANSIBLE_VERSION = 'not used for testing'
        module_common.ANSIBLE_GIT_VERSION = 'not used for testing'
        module_common.ANSIBLE_PYTHON_INTERPRETER = 'not used for testing'
        setattr(platform, "system", lambda: platform)
        setattr(platform, "machine", lambda: "i386")
        setattr(platform, "processor", lambda: "i386")
        setattr(platform, "python_version", lambda: "not used for testing")
        setattr(platform, "release", lambda: "not used for testing")
       

# Generated at 2022-06-20 16:16:26.097392
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Example class hierarchy used to test get_platform_subclass.
    '''

    class LinuxOnly(object):
        distribution = None
        platform = "Linux"

    class LinuxSystem(LinuxOnly):
        distribution = None

    class LinuxRedHatSystem(LinuxSystem):
        distribution = u"Redhat"

    class LinuxRedHat7System(LinuxRedHatSystem):
        version = u"7"

    class LinuxRedHat6System(LinuxRedHatSystem):
        version = u"6"

    class LinuxRedHatSystemSELinux(LinuxRedHatSystem):
        selinux = True

    class LinuxRedHat6SystemSELinux(LinuxRedHat6System, LinuxRedHatSystemSELinux):
        pass


# Generated at 2022-06-20 16:16:37.501380
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestPlatForm(object):
        platform = None
        distribution = None
    class TestPlatForm1(TestPlatForm):
        platform = None
        distribution = 'RedHat'
    class TestPlatForm2(TestPlatForm):
        platform = 'Linux'
        distribution = None
    class TestPlatForm3(TestPlatForm):
        platform = 'Linux'
        distribution = 'RedHat'
    class TestPlatForm4(TestPlatForm1):
        platform = 'Linux'
        distribution = 'RedHat'
    class TestPlatForm5(TestPlatForm4):
        platform = 'Linux'
        distribution = 'RedHat'

    distro_string = 'Redhat'
    platform_string = 'Linux'

    assert get_platform_subclass(TestPlatForm).__name__

# Generated at 2022-06-20 16:16:46.674217
# Unit test for function get_distribution
def test_get_distribution():
    # Test id()
    try:
        import distro  # flake8: noqa=F401
    except ImportError:
        # If distro is not installed, this function is not available
        pass
    else:
        distro.id = lambda: 'TestDistro'
        assert get_distribution() == 'TestDistro'

        distro.id = lambda: 'amzn'
        assert get_distribution() == 'Amazon'

        distro.id = lambda: 'amzn2'
        assert get_distribution() == 'Amzn2'



# Generated at 2022-06-20 16:16:53.480297
# Unit test for function get_distribution
def test_get_distribution():
    distro_map = dict(
        Debian='debian',
        Fedora='fedora',
        Linux='linux',
        Ubuntu='ubuntu',
        Amazon='amzn',
        OtherLinux='otherlinux',
        Redhat='rhel',
        SunOS='sunos',
    )
    for expected, distro_id in distro_map.items():
        distro.id = lambda: distro_id
        assert get_distribution() == expected



# Generated at 2022-06-20 16:16:55.075584
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-20 16:17:05.929281
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Function: get_distribution

    Input: None

    Output: String containing the name of the distribution.

    Test:
    >>> test_get_distribution()
    'Ubuntu'
    '''
    return get_distribution()


# Generated at 2022-06-20 16:17:16.100856
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the functionality of get_distribution()
    '''

    import platform

    # Linux
    fake_os = {'id': 'centos', 'version': '7.0', 'codename': 'Core'}
    distro.linux_distribution = lambda **kwargs: fake_os
    distro.id = lambda **kwargs: fake_os['id']
    distro.version = lambda **kwargs: fake_os['version']
    distro.codename = lambda **kwargs: fake_os['codename']
    assert get_distribution() == u'Centos'

    fake_os = {'id': 'debian', 'version': '7.0', 'codename': 'wheezy'}
    distro.linux_distribution = lambda **kwargs: fake_os
    distro.id

# Generated at 2022-06-20 16:17:27.528721
# Unit test for function get_distribution_codename

# Generated at 2022-06-20 16:17:39.233380
# Unit test for function get_distribution_version
def test_get_distribution_version():
    print("testing get_distribution_version function")

    from distutils.version import LooseVersion

    # We may be on CentOS or RedHat.  We want to test both.
    test_version = get_distribution_version()
    if test_version is None:
        return

    import pytest
    pytest.importorskip("rpm")
    if distro.id() == 'rhel':
        distro_version_id = 'centos' + test_version
    else:
        distro_version_id = 'rhel' + test_version

    test_version_string = '.'.join(test_version.split('.')[0:2])

    # Test the logic that lets us use a 2 digit version instead of a 4 digit version

# Generated at 2022-06-20 16:17:43.681483
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distro_name = platform.dist()[0]
    codename = get_distribution_codename()

    # Test Ubuntu 16.04 Xenial code name
    if distro_name == 'Ubuntu':
        assert codename == 'xenial'
    else:
        # Fedora and Centos/RHEL do not have code name
        assert codename is None

# Generated at 2022-06-20 16:17:45.270940
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None



# Generated at 2022-06-20 16:17:47.690297
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == u'Freebsd'



# Generated at 2022-06-20 16:17:50.122918
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is None
    assert get_distribution_version() == ''
    assert get_distribution_version() == '8.1'

# Generated at 2022-06-20 16:18:00.880639
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for get_distribution_codename method
    '''
    # This test is run against a fixture, which is a copy of /etc/os-release and /etc/lsb-release
    # Ubuntu Xenial Xerus has a /etc/lsb-release but no /etc/os-release
    # When this test is run on a system that has /etc/lsb-release and /etc/os-release the test will
    # fail unless /etc/lsb-release is deleted, because the fixture does not include /etc/lsb-release

    # testing for debian stretch
    release_file = 'ansible/module_utils/basic/tests/release_files/debian_stretch'
    distribution = distro.Distribution(release_file=release_file)
    distro_id = distribution.id()
    version

# Generated at 2022-06-20 16:18:01.966132
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-20 16:18:17.591271
# Unit test for function get_distribution
def test_get_distribution():
    import sys
    sys.modules['platform'] = type('platform', (), {'system': lambda: 'Linux'})
    sys.modules['distro'] = type('distro', (), {'id': lambda: 'amzn'})

    assert get_distribution() == 'Amazon'

# Test function get_distribution_version

# Generated at 2022-06-20 16:18:25.277264
# Unit test for function get_distribution
def test_get_distribution():
    '''test get_distribution'''

    class MockModule():
        '''mock module.params'''
        params = {'distribution': None}

    # mock module_utils/distro.py
    # set linux distro name
    LINUX_DISTRO_NAME = 'debian'

    class MockLinuxDistro():
        '''mock Linux distro'''
        def id(self):
            '''mock id'''
            return LINUX_DISTRO_NAME

    old_distro = distro
    distro = MockLinuxDistro()

    # test get_distribution
    import module_utils.basic
    if LINUX_DISTRO_NAME is None:
        module_utils.basic.get_distribution() == 'OtherLinux'

# Generated at 2022-06-20 16:18:29.900894
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    Test case for get_distribution_version function
    """
    assert get_distribution_version() == '2.18.9-3.el7'

# Generated at 2022-06-20 16:18:31.300412
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None


# Generated at 2022-06-20 16:18:40.271833
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test to ensure correct class is returned

    :raises: AssertionError if anything below is not as expected
    '''

    import ansible.module_utils.basic

    from ansible.module_utils.basic import AnsibleModule

    # This class will be different dependent on platform
    class Test(object):
        distribution = get_distribution()
        platform = platform.system()

    # Test the base class first
    subclass = get_platform_subclass(Test)
    assert subclass is Test

    # Test the default subclass
    class TestSubclass(Test):
        platform = "Linux"

    subclass = get_platform_subclass(Test)
    assert subclass is TestSubclass

    # Test subclass matching the os version
    class TestSubclassOs(Test):
        platform = "Linux"
        distribution = get_distribution

# Generated at 2022-06-20 16:18:49.989333
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    This function is a unit test for function get_platform_subclass.

    This function is implemented by class TestGetPlatformSubclass, but it is
    not automatically detected as a unit test.

    The unittest will only execute successfully if the distribution is
    Ubuntu, version 16.04.  This is because the test implementation of
    get_platform_subclass is Ubuntu1604.
    '''
    if platform.system() == 'Linux':
        from ansible.module_utils.common.test_get_platform_subclass import TestGetPlatformSubclass
        test_instance = TestGetPlatformSubclass()
        test_instance.test_get_platform_subclass()

# Generated at 2022-06-20 16:19:01.870516
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class BaseClass(object):
        ''' Base object for the test classes below '''
        platform = 'Linux'
        distribution = None
        distribution_version = None
        distribution_release = None

    class Distribution(BaseClass):
        ''' Parent class for the platform specific class '''
        distribution = 'CentOS'

    class Version(Distribution):
        '''
        Implement CentOS 7
        '''
        distribution_version = '7'

    class Release(Distribution):
        '''
        Support some prerelease versions of CentOS 8
        '''
        distribution_version = '8'
        distribution_release = '0'

    class OtherDistribution(BaseClass):
        '''
        I am a different distribution on the same platform
        '''
        distribution = 'Ubuntu'


    # Distro not specified
    instance = get

# Generated at 2022-06-20 16:19:09.984246
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    with patch('platform.system', return_value='Linux'):
        with patch('ansible.module_utils.distro.id', return_value='Ubuntu'):
            patcher_distro_os_release_info = patch('ansible.module_utils.distro.os_release_info', return_value={'foo': 'bar'})
            with patcher_distro_os_release_info as distro_os_release_info:
                assert get_distribution_codename() is None

                distro_os_release_info.return_value = {'version_codename': 'baz'}
                assert get_distribution_codename() == 'baz'


# Generated at 2022-06-20 16:19:21.380286
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    def UnitTestPlatform(cls):
        distribution = get_distribution()
        if distribution is not None:
            return get_platform_subclass(cls)
        else:
            return cls

    class TestClass:
        platform = 'TestPlatform'
        distribution = None

    class TestClassA(TestClass):
        platform = 'TestPlatform'
        distribution = 'TestDistroA'

    class TestClassB(TestClass):
        platform = 'TestPlatform'
        distribution = 'TestDistroB'

    class TestClassC(TestClass):
        platform = 'TestPlatform2'
        distribution = 'TestDistroA'

    class TestClassD(TestClass):
        platform = 'TestPlatform2'
        distribution = 'TestDistroB'

    class TestClassE(TestClass):
        platform = 'TestPlatform'

# Generated at 2022-06-20 16:19:29.960495
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version.

    :returns: results of test.
    '''
    import pytest


# Generated at 2022-06-20 16:19:55.910977
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() != '' or get_distribution() != None

# Generated at 2022-06-20 16:19:57.063379
# Unit test for function get_distribution_version
def test_get_distribution_version():

    assert get_distribution_version() is not None

# Generated at 2022-06-20 16:20:05.041854
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Klingon'
        distribution = None

    class Klingon(Base):
        platform = 'Klingon'

    class KlingonDebian(Base):
        platform = 'Klingon'
        distribution = 'Debian'

    class KlingonFedora(Base):
        platform = 'Klingon'
        distribution = 'Fedora'

    class Vulcan(Base):
        platform = 'Vulcan'

    class VulcanFedora(Base):
        platform = 'Vulcan'
        distribution = 'Fedora'

    assert KlingonFedora == get_platform_subclass(Base)

    class Base:
        platform = 'Vulcan'

    assert Vulcan == get_platform_subclass(Base)

    class Base:
        platform = 'Klingon'
        distribution = 'Debian'

    assert KlingonDeb

# Generated at 2022-06-20 16:20:09.120544
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for function get_distribution in module_utils.distro_facts.
    '''

    assert get_distribution() is not None


# Generated at 2022-06-20 16:20:18.350123
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'jessie'
    assert get_distribution_codename() == 'bionic'
    assert get_distribution_codename() == 'xenial'
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == 'jessie'
    assert get_distribution_codename() == 'bionic'
    assert get_distribution_codename() == 'xenial'
    assert get_distribution_codename() == 'oxygen'
    assert get_distribution_codename() == 'oxygen'
    assert get_distribution_codename() == 'oxygen'
    assert get_distribution_codename() == 'oxygen'
    assert get_distribution_codename

# Generated at 2022-06-20 16:20:27.605430
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Foo:
        pass

    class FooRedhat(Foo):
        distribution = 'Redhat'
        platform = 'Linux'

    class FooOtherLinux(Foo):
        distribution = 'OtherLinux'
        platform = 'Linux'

    class FooLinux(Foo):
        platform = 'Linux'

    class FooSolaris(Foo):
        platform = 'Solaris'

    class FooOpenBSD(Foo):
        platform = 'OpenBSD'

    class FooFreeBSD(Foo):
        platform = 'FreeBSD'

    class FooWindows(Foo):
        platform = 'Windows'

    class FooDarwin(Foo):
        platform = 'Darwin'

    # get_platform_subclass() returns the most specific subclass that matches platform and distribution
    # when that subclass is available.
    assert FooRedhat == get_

# Generated at 2022-06-20 16:20:29.312921
# Unit test for function get_distribution
def test_get_distribution():
    pdist = platform.linux_distribution()[0]
    assert get_distribution() == pdist.capitalize()

# Generated at 2022-06-20 16:20:34.750718
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """Return the version of the distribution the module is running on."""
    expected = {
        '9': '9.5',
        '6.10': '6.10',
        '6_10': '6.10',
        '6.10-server': '6.10',
        '6.8.7': '6.8.7',
        '6.8.7-server': '6.8.7',
        '8.4': '8.4',
        '8.4-server': '8.4',
        '10': '10',
        '10-server': '10',
    }

    for key, val in expected.items():
        assert get_distribution_version() == val


# Generated at 2022-06-20 16:20:43.772441
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    from ansible.module_utils.basic import Basic

    # Test the subclass for classes that return only one class
    class TestOneClass(Basic):
        platform = 'TestOne'
        distribution = None

    class TestOne(TestOneClass):
        pass

    assert get_platform_subclass(TestOneClass) == TestOneClass

    # Test the subclass for classes that return multiple classes
    class TestMultiClass(Basic):
        platform = 'TestMulti'
        distribution = None

    class TestMulti_subcls(TestMultiClass):
        distribution = 'Test'

    class TestMulti(TestMultiClass):
        pass

    assert get_platform_subclass(TestMultiClass) == TestMulti
    assert get_platform_subclass(TestMulti_subcls) == TestMulti_subcls

    # Test the subclass for classes that don't have

# Generated at 2022-06-20 16:20:45.041015
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == u'xenial'

# Generated at 2022-06-20 16:21:31.068552
# Unit test for function get_distribution
def test_get_distribution():
    """
    Test function get_distribution
    """
    assert get_distribution()

# Generated at 2022-06-20 16:21:39.728842
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the get_distribution_version function with test distributions

    :rtype: None
    :returns: None
    '''
    def test(distro_id, version, version_best, expected_version):
        class FakeDistro:
            def id(*args, **kwargs):
                return distro_id
            def version(*args, **kwargs):
                return version
            def version(best=False, *args, **kwargs):
                return version_best

        tmp_distro = distro
        distro = FakeDistro

        actual_version = get_distribution_version()
        assert actual_version == expected_version, 'Version for %s, version %s expected to be %s, but was %s' % \
            (distro_id, version, expected_version, actual_version)



# Generated at 2022-06-20 16:21:41.180349
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None


# Generated at 2022-06-20 16:21:48.968609
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform_a as platform
    platform.platform_system = lambda: 'Linux'
    platform.get_distribution = lambda: 'Redhat'

    class A1(object):
        platform = 'Linux'
        distribution = 'Redhat'

    class A2(object):
        platform = 'Linux'
        distribution = None

    class A3(object):
        platform = 'Linux'
        distribution = 'Ubuntu'

    assert get_platform_subclass(A1) is A1
    assert get_platform_subclass(A2) is A2
    assert get_platform_subclass(A3) is A2

# Generated at 2022-06-20 16:21:55.706471
# Unit test for function get_distribution
def test_get_distribution():
    assert 'Amazon' == get_distribution()
    assert 'OtherLinux' == get_distribution()
    assert 'OtherLinux' == get_distribution(path='/etc/debian_version')
    assert 'Ubuntu' == get_distribution(path='/etc/lsb-release')
    assert 'Ubuntu' == get_distribution(path='/etc/os-release')
    assert 'Ubuntu' == get_distribution(path='/etc/foo/bar/baz')

# Generated at 2022-06-20 16:22:00.775311
# Unit test for function get_distribution
def test_get_distribution():
    # Some general tests
    assert 'Darwin' == get_distribution()
    assert 'Freebsd' == get_distribution()
    assert 'Openbsd' == get_distribution()
    assert 'Redhat' == get_distribution()
    assert 'Debian' == get_distribution()
    assert 'Ubuntu' == get_distribution()
    assert 'Amazon' == get_distribution()
    assert 'Suse' == get_distribution()
    assert 'OtherLinux' == get_distribution()


# Generated at 2022-06-20 16:22:02.673337
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    try:
        assert get_distribution_codename() == None
    except:
        return 1
    return 0

# Generated at 2022-06-20 16:22:11.681062
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    def get_platform_subclass(cls):
        this_platform = u'Linux'
        distribution = get_distribution()
        subclass = None

        # get the most specific superclass for this platform
        if distribution is not None:
            for sc in get_all_subclasses(cls):
                if sc.distribution is not None and sc.distribution == distribution and sc.platform == this_platform:
                    subclass = sc
        if subclass is None:
            for sc in get_all_subclasses(cls):
                if sc.platform == this_platform and sc.distribution is None:
                    subclass = sc
        if subclass is None:
            subclass = cls
        return subclass

    class Test(Base, object):
        platform = u'Linux'
        distribution = u'Amazon'

   

# Generated at 2022-06-20 16:22:12.965367
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test of the get_distribution_codename function.
    '''
    assert get_distribution_codename() == None

# Generated at 2022-06-20 16:22:26.339457
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import random
    # Make a version string for each version of each distribution we expect to support
    version_strings = {
        'Fedora': ['release 24 (Twenty Four)', 'release 29 (Twenty Nine)'],
        'Debian': ['9.0 ("Stretch")', '8.8 ("Jessie")'],
        'Ubuntu': ['16.04 (Xenial Xerus)', '18.04 (Bionic Beaver)'],
        'CentOS': ['release 7.5.1804 (Core)', 'release 6.10 (Final)'],
    }

    test_data = []
    for distro_name, versions in version_strings.items():
        for version in versions:
            test_data.append({'id': distro_name.lower(), 'version': version, 'codename': version.split()[1]})

    #

# Generated at 2022-06-20 16:23:59.254942
# Unit test for function get_distribution
def test_get_distribution():
    import platform

    (_, _, _, _, _, distro) = platform.dist()
    distribution = get_distribution()

    assert distribution == distro.capitalize()

# Generated at 2022-06-20 16:24:07.182239
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.common._collections_compat import Mapping

    distribution = get_distribution()

    assert isinstance(distribution, (Mapping, type(None))), \
        'The value returned from get_distribution must be a dict or None, instead got %s' % repr(distribution)



# Generated at 2022-06-20 16:24:08.751413
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-20 16:24:16.682909
# Unit test for function get_distribution
def test_get_distribution():
    def assert_get_distribution(expected_name, distro_id=None, version=None,
                                codename=None, lsb_distrib_id=None,
                                lsb_distrib_release=None, lsb_distrib_codename=None,
                                lsb_distrib_description=None,
                                redhat_release=None):
        # Basic tests
        # Set things up so that we get the expected result and only the thing we're testing
        def set_os_release_info(*args, **kwargs):
            return {'id': distro_id, 'version': version}


# Generated at 2022-06-20 16:24:18.062877
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-20 16:24:26.911312
# Unit test for function get_distribution_version
def test_get_distribution_version():
    with patch('ansible.module_utils.distro.id', return_value='Ubuntu'):
        with patch('ansible.module_utils.distro.version', return_value=None):
            assert '' == get_distribution_version()

    with patch('ansible.module_utils.distro.id', return_value='Ubuntu'):
        with patch('ansible.module_utils.distro.version', return_value='1.1'):
            assert '1.1' == get_distribution_version()


# Generated at 2022-06-20 16:24:33.578164
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() in ['Amazon',
                                  'Debian',
                                  'Freebsd',
                                  'Openbsd',
                                  'Linux',
                                  'Macosx',
                                  'Redhat',
                                  'SuSe',
                                  'Windows',
                                  'OtherLinux',
                                  'Unknown'
                                 ]


# Generated at 2022-06-20 16:24:37.824075
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == "bionic"

    # Testing if distribution with capital letters does not fail
    assert get_distribution_codename() == "bionic"

# Generated at 2022-06-20 16:24:44.404215
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test for function get_platform_subclass
    '''

    class TestClass(object):
        '''
        Sample class to test function get_platform_subclass
        '''
        distribution = None
        platform = None

    class Subclass1(TestClass):
        '''
        Subclass of TestClass
        '''
        distribution = None
        platform = 'Linux'

    class Subclass2(TestClass):
        '''
        Subclass of TestClass
        '''
        distribution = 'Linux'
        platform = None

    class Subclass12(Subclass1):
        '''
        Subclass of Subclass1
        '''
        distribution = 'Linux'
        platform = 'Linux'


# Generated at 2022-06-20 16:24:53.928384
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # This function is far too difficult to test, so only test the corner cases
    # and do a sanity check for the most common cases
    distro_name = get_distribution()
    distro_version = get_distribution_version()
    distro_codename = get_distribution_codename()

    # No codename for non-debian distros
    if distro_name != u'Debian':
        assert distro_codename is None

    # No codename for Debian in major release mode
    if distro_name == u'Debian' and not distro_version.endswith(u'-backports'):
        assert distro_codename is None

    # Fedora 28+ has no codename