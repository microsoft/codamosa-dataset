

# Generated at 2022-06-20 16:15:33.039237
# Unit test for function get_platform_subclass

# Generated at 2022-06-20 16:15:37.053205
# Unit test for function get_distribution_version
def test_get_distribution_version():
    version = None
    (dist, major_version, version) = platform.dist()
    if version == '':
        version = None
    assert version == get_distribution_version()

# Generated at 2022-06-20 16:15:49.223545
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Create a fake set of classes to test this function

    class Superclass(object):
        pass

    class Linux(Superclass):
        platform = 'Linux'

    class OtherLinux(Linux):
        distribution = 'OtherLinux'

    class RedhatBased(Linux):
        distribution = 'Redhat'

    class Redhat(RedhatBased):
        pass

    class Centos6(RedhatBased):
        distribution = 'Centos'
        distro_major_version = 6

    class Centos7(RedhatBased):
        distribution = 'Centos'
        distro_major_version = 7

    class Centos(RedhatBased):
        pass

    class Windows(Superclass):
        platform = 'Windows'

    class OSX(Superclass):
        platform = 'Darwin'

    assert get_platform_subclass(Linux)

# Generated at 2022-06-20 16:15:50.121248
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-20 16:15:53.002690
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'
    assert get_distribution() != 'Windows'


# Generated at 2022-06-20 16:16:03.091261
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import unittest

    class MockAnsibleOSReleaseFile(object):
        lines = [
            'NAME=Debian',
            'VERSION="9 (stretch)"',
            'ID=debian',
            'VERSION_ID=9',
            'PRETTY_NAME="Debian GNU/Linux 9 (stretch)"',
            'HOME_URL="https://www.debian.org/"',
        ]

    class MockAnsibleLSBReleaseFile(object):
        lines = [
            'DISTRIB_ID=Ubuntu',
            'DISTRIB_RELEASE=16.04',
            'DISTRIB_CODENAME=xenial',
            'DISTRIB_DESCRIPTION="Ubuntu 16.04.1 LTS"',
        ]


# Generated at 2022-06-20 16:16:06.372818
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for function get_distribution
    '''
    assert get_distribution() == u'Centos'
    assert get_distribution() == get_distribution()



# Generated at 2022-06-20 16:16:16.610137
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test function `get_distribution <#ansible.module_utils.facts.system.get_distribution>`.

    Unit test for the `get_distribution <#ansible.module_utils.facts.system.get_distribution>` function.
    Note that this test will fail if the system's distribution cannot be determined.
    '''

    from ansible.module_utils.facts.system import get_distribution

    # The result to be expected
    expected_result = platform.dist()[0].capitalize()

    # Call the function
    result = get_distribution()

    # Make sure we got the right result
    assert result == expected_result


# Generated at 2022-06-20 16:16:27.291852
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    test_cases = [
        ('CentOS', 'centos7'),
        ('RedHat', 'rhel7'),
        ('Ubuntu', 'xenial'),
        ('Fedora', None),
        ('Windows', None),
    ]
    failed_tests = []
    for test in test_cases:
        test_distro = test[0]
        test_codename = test[1]
        if not get_distribution_codename() == test_codename:
            failed_tests.append(test)
    if len(failed_tests) == 0:
        print('OK\n')
    else:
        print('FAIL\n')
        for test in failed_tests:
            print(test)
    return len(failed_tests)

# Generated at 2022-06-20 16:16:39.584468
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test function to ensure get_platform_subclass call returns correct subclass based on platform

    :returns: Bool whether test was a success

    Function creates a parent class for a user module, plus a subclass for each distribution (Redhat, Debian and Amazon).  It then calls
    get_platform_subclass to determine the most appropriate subclass.

    This is not a unit test in the sense of the test module, but simply a standalone function that should be called
    in a python interpreter to ensure get_platform_subclass returns the correct classes.
    '''

    class User():
        platform = 'Linux'
        distribution = None

        def __init__(self, name, **kwargs):
            self.name = name

    class RedhatUser(User):
        platform = 'Linux'
        distribution = 'Redhat'


# Generated at 2022-06-20 16:16:48.727761
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == u'3.10.0-957.10.1.el7.x86_64'


# Generated at 2022-06-20 16:17:00.699785
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import unittest
    from ansible.module_utils._text import to_bytes

    base = 'test_get_distribution_version_'

# Generated at 2022-06-20 16:17:07.323598
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.facts as facts
    fact_subclass = get_platform_subclass(facts.__class__)
    assert(fact_subclass == getattr(facts, '%s%s' % (platform.system(), get_distribution().capitalize())))

# Generated at 2022-06-20 16:17:08.673861
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution() == 'Amazon'

# Generated at 2022-06-20 16:17:17.837788
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Sample subclasses for testing purposes
    class Base:
        pass

    class BaseLinux(Base):
        platform = "Linux"
        distribution = None

    class DebianSpecific(BaseLinux):
        distribution = "Debian"

    class OtherLinuxSpecific(BaseLinux):
        distribution = "OtherLinux"

    class BaseFreeBSD(Base):
        platform = "FreeBSD"
        distribution = None

    class BaseOpenBSD(Base):
        platform = "OpenBSD"
        distribution = None

    class BaseNetBSD(Base):
        platform = "NetBSD"
        distribution = None

    class BaseBSD(Base):
        platform = "BSD"
        distribution = None

    if platform.system() == "Linux":
        assert get_platform_subclass(Base) is BaseLinux
        assert get_platform_subclass(BaseLinux) is BaseLinux

# Generated at 2022-06-20 16:17:20.711870
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test: get_distribution
    '''

    assert get_distribution() in ('Redhat', 'Centos', 'Fedora')


# Generated at 2022-06-20 16:17:32.386799
# Unit test for function get_distribution

# Generated at 2022-06-20 16:17:38.942363
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Tests that the code correctly parses the distribution it is running on.
    '''
    # returns a 2-tuple of system and node
    system, node, release, version, machine, processor = platform.uname()

    if system == 'AIX':
        assert get_distribution() == 'Aix'
    elif system == 'Linux':
        assert get_distribution() == 'OtherLinux'

    # TODO: Add tests for supported Linux distributions and
    # for other platforms that the code is supported on

# Generated at 2022-06-20 16:17:45.461635
# Unit test for function get_distribution_version
def test_get_distribution_version():

    # Test no version data
    distro.redhat_release_info.version_data = {}
    distro.lsb_release_info.version_data = {}
    distro.os_release_info.version_data = {}


# Generated at 2022-06-20 16:17:49.417480
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    This is a unit test for function get_distribution_version
    '''
    if platform.system() == 'Linux':
        assert get_distribution_version() == distro.version()

# Generated at 2022-06-20 16:18:00.931659
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A():
        platform = ''
        distribution = ''

    class B(A):
        platform = 'darwin'
        distribution = ''

    class C(A):
        platform = 'darwin'
        distribution = 'Elcapitan'

    assert A == get_platform_subclass(A)

    assert B == get_platform_subclass(A)

    assert B == get_platform_subclass(B)

    assert C == get_platform_subclass(B)

# Generated at 2022-06-20 16:18:02.222931
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename == "xenial"

# Generated at 2022-06-20 16:18:08.138876
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo:
        platform = 'Linux'
        distribution = None

    class Bar:
        platform = 'Linux'
        distribution = 'Bar'

    class Baz:
        platform = 'Linux'
        distribution = 'Baz'

    class Buzz:
        platform = 'Windows'
        distribution = 'Buzz'

    class Bop:
        platform = 'Linux'
        distribution = None

    class Rop:
        platform = 'Windows'
        distribution = None

    class Zop:
        platform = 'AIX'
        distribution = None


# Generated at 2022-06-20 16:18:17.635489
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distro_codename_test_vectors = {
        'amazon': '1',
        'centos': '7',
        'debian': 'buzz',
        'fedora': '28',
        'redhat': '7.5',
        'sles': '15',
    }
    for distro, codename in distro_codename_test_vectors.items():
        distribution = get_distribution()
        distribution_codename = get_distribution_codename()
        assert distribution == distro, "Distro check failed for {0}".format(distro)
        assert distribution_codename == codename, "Distro codename check failed for {0}: Check if the version is ok: {1}".format(distro, codename)

# Generated at 2022-06-20 16:18:25.301201
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import unittest
    import platform

    class TestGetDistributionCodename(unittest.TestCase):
        def test_linux_centos_codename(self):
            plat = 'Linux'
            distribution = 'CentOS'
            version = '7'
            codename = get_distribution_codename()
            self.assertIsNone(codename)

        def test_linux_ubuntu_codename(self):
            plat = 'Linux'
            distribution = 'Ubuntu'
            version = '18.04'
            codename = get_distribution_codename()
            self.assertEqual(codename, 'bionic')

        def test_linux_suse_codename(self):
            plat = 'Linux'
            distribution = 'Suse'
            version = '13.1'
            codename = get_

# Generated at 2022-06-20 16:18:37.491915
# Unit test for function get_distribution_version
def test_get_distribution_version():
    platform_system = platform.system
    platform_linux = platform.linux_distribution
    distro_id = distro.id
    distro_version = distro.version
    distro_version_best = distro.version
    distro_os_release_info = distro.os_release_info
    distro_lsb_release_info = distro.lsb_release_info
    distro_codename = distro.codename

    platform.system = lambda: 'Linux'
    distro.id = lambda: 'Centos'
    distro.version = lambda: '7.5'
    distro.version = lambda best: '7.5.1804'
    distro.os_release_info = lambda: '{}'
    distro.lsb_release_info = lambda: '{}'

# Generated at 2022-06-20 16:18:49.194125
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class base(object):
        platform = 'Base'
        distribution = None

    class linux(base):
        platform = 'Linux'

    class centos(linux):
        distribution = 'Centos'

    class ubuntu(linux):
        distribution = 'Ubuntu'

    assert base == get_platform_subclass(base)
    assert linux == get_platform_subclass(linux)

    class centos(linux):
        distribution = 'Centos'

    class amazon(linux):
        distribution = 'Amazon'

    assert base == get_platform_subclass(base)
    assert linux == get_platform_subclass(linux)
    assert centos == get_platform_subclass(centos)

    class my_centos(centos):
        pass


# Generated at 2022-06-20 16:19:00.738396
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass
    class Class_Linux(BaseClass):
        pass
    class Class_Linux_Fedora(Class_Linux):
        pass
    class Class_Linux_Debian(Class_Linux):
        pass
    class Class_Linux_Other(Class_Linux):
        pass
    class Class_FreeBSD(BaseClass):
        pass

    result = get_platform_subclass(BaseClass)
    assert result == BaseClass

    result = get_platform_subclass(Class_Linux)
    assert result == Class_Linux

    result = get_platform_subclass(Class_Linux_Fedora)
    assert result == Class_Linux_Fedora

    result = get_platform_subclass(Class_Linux_Debian)
    assert result == Class_Linux_Debian


# Generated at 2022-06-20 16:19:10.567988
# Unit test for function get_distribution

# Generated at 2022-06-20 16:19:13.574951
# Unit test for function get_distribution
def test_get_distribution():
    def test_sub_get_distribution():
        distribution = get_distribution()
        assert distribution is not None

    test_sub_get_distribution()

# Generated at 2022-06-20 16:19:34.862876
# Unit test for function get_distribution_version
def test_get_distribution_version():
    major_distros = frozenset([
        u'Debian',
        u'Redhat',
        u'SuSE',
        u'Gentoo',
        u'Slackware',
        u'Solaris',
        u'Mandriva',
        u'Frugalware',
        u'Mageia',
        u'FreeBSD',
        u'Arch',
        # u'Antergos',
        # u'L4B',
        u'SlackwareARM',
        u'Slamd64',
        u'BackTrack',
        u'Void',
        u'Puppy',
    ])

    for dist_name in major_distros:
        # test the version for every major distro
        version = get_distribution_version()
        assert version is not None

# Generated at 2022-06-20 16:19:41.395750
# Unit test for function get_distribution
def test_get_distribution():
    # This is a list of supported distributions.  We need to add entries to it
    # as we add support for new distributions.
    supported_distributions = (
        u'Amazon', u'Redhat', u'Oracle', u'Debian', u'Ubuntu', u'Darwin', u'Freebsd', u'Openbsd',
        u'Windows', u'OpenSUSE', u'SLES', u'Centos', u'SUSE', u'Sles', u'OtherLinux',
    )

    # This is the list of distribution specific versions that we want to
    # support.  There is no particular value in being exhaustive.  We're just
    # trying to make sure that we're getting the major version if we can.
    # Please do not interpret this as an indication of desire to support
    # these versions specifically.  It is just a

# Generated at 2022-06-20 16:19:42.921410
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None

# Generated at 2022-06-20 16:19:44.770267
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert isinstance(codename, (str, type(None)))

# Generated at 2022-06-20 16:19:55.325576
# Unit test for function get_distribution
def test_get_distribution():
    # test conda
    def conda_conda_platform(self):
        return "conda"

    def conda_conda_linux_name(self):
        return "conda"

    def conda_conda_os_release_name(self):
        return "conda"

    def conda_conda_lsb_release_name(self):
        return None

    def conda_conda_release_file_name(self):
        return None

    class MockCondaDistro(object):
        @classmethod
        def platform(self):
            return conda_conda_platform(self)

        def linux_distribution(self):
            return (conda_conda_linux_name(self), "0.0.0-placeholder", "placeholder bitstring")


# Generated at 2022-06-20 16:20:04.055942
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test for the get_platform_subclass function

    The test_get_platform_subclass function verifies that the return values of get_platform_subclass
    make sense.
    '''
    class Base:
        distribution = None
        platform = 'Base'

    class SpecificLinux(Base):
        distribution = 'specific'
        platform = 'Linux'

    class GenericLinux(Base):
        platform = 'Linux'

    class BaseLinux(Base):
        pass

    class GenericSpecificLinux(Base):
        distribution = 'specific'

    class GenericAny(Base):
        platform = 'Any'

    class SpecificAny(Base):
        platform = 'Any'
        distribution = 'specific'


# Generated at 2022-06-20 16:20:07.623533
# Unit test for function get_distribution_version
def test_get_distribution_version():

    """
    distribution return for distro.version()
    ubuntu    > 18.04
    centos    > 7.5.1804
    sles      > 12
    amazon    > 2018.03
    alpine    > Not Applicable.
    """

    """
    # Test for distribution, ubuntu
    with mock.patch('ansible.module_utils.distro.id', return_value='ubuntu'):
        assert get_distribution_version() == '18.04'
    """

    """
    Test for distribution, centos
    with mock.patch('ansible.module_utils.distro.id', return_value='centos'):
        assert get_distribution_version() == '7.5'
    """


# Generated at 2022-06-20 16:20:17.533303
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform

    class Base():
        pass

    class BaseB():
        pass

    class BaseC():
        distribution = 'Fedora'
        platform = 'Linux'

    class BaseD():
        distribution = 'Linux'
        platform = 'Linux'

    class BaseE():
        distribution = 'Fedora'
        platform = 'AIX'

    class BaseFooBar(Base):
        distribution = None
        platform = 'FooBar'

    class BaseLinux(Base):
        distribution = None
        platform = 'Linux'

    class BaseDarwin(Base):
        distribution = None
        platform = 'Darwin'

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'RedHat'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        distribution_version = '7'


# Generated at 2022-06-20 16:20:27.166646
# Unit test for function get_distribution
def test_get_distribution():
    '''Unit test for function get_distribution'''

# Generated at 2022-06-20 16:20:31.277953
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    """
    Test get_distribution_codename()
    """
    # Parse the /etc/os-release file and update the variable
    os_release_info = distro.os_release_info()

    # Verify the code name in /etc/os-release
    assert get_distribution_codename() == os_release_info.get('version_codename')

# Generated at 2022-06-20 16:20:53.698269
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    fake_os_release_file = '/tmp/test_ansible_os_release_codename'
    with open(fake_os_release_file, 'w') as f:
        f.write('''OS_RELEASE_ID="test-os-release-id"
OS_RELEASE_VERSION="test-os-release-version"
OS_RELEASE_CODENAME="test-os-release-codename"
OS_RELEASE_ID_LIKE="test-os-release-id-like"
''')
    distro._os_release_file = fake_os_release_file
    assert get_distribution_codename() == u'test-os-release-codename'

# Generated at 2022-06-20 16:20:54.972514
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'



# Generated at 2022-06-20 16:21:03.640814
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict, is_sequence
    from ansible.module_utils.common.text.converters import to_bytes, to_native
    from ansible.module_utils.common.text.converters import to_text, to_bytes

    def _fatal(msg='unexpected error'):
        raise AssertionError(msg)

    distribution_version = get_distribution_version()
    if platform.system() == 'Linux':
        assert distribution_version is not None

        # Debian Stretch has no minor version in os-release

# Generated at 2022-06-20 16:21:13.627684
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """ Unit test for function get_distribution_version """

# Generated at 2022-06-20 16:21:22.479723
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test function get_platform_subclass()
    '''
    from ansible.module_utils import basic

    # Note: We're using load_platform_subclass() as a proxy function to call get_platform_subclass()
    class TestClass0(object):
        '''
        test case 0

        platform = 'Linux'
        distribution  = None
        '''
        platform = 'Linux'
        distribution = None
        def __new__(cls, *args, **kwargs):
            new_cls = basic.load_platform_subclass(TestClass0, args, kwargs)
            return super(TestClass0, new_cls).__new__(new_cls)

# Generated at 2022-06-20 16:21:27.589138
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Run test for function get_distribution_codename
    '''

    assert get_distribution_codename() == None

    # Set the distribution type to Ubuntu
    distro.linux_distribution = lambda: ( 'Ubuntu', '18.04.1', 'bionic' )

    assert get_distribution_codename() == 'bionic'
    # Set the distribution type to Debian
    distro.linux_distribution = lambda: ( 'Debian', '9.7', 'stretch' )

    assert get_distribution_codename() == 'stretch'
    # Set the distribution type to other Linux distro
    distro.linux_distribution = lambda: ( 'OtherLinux', '18.04.1', 'bionic' )

    assert get_distribution_codename() == None

# Generated at 2022-06-20 16:21:29.547525
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename = get_distribution_codename()
    return distribution_codename

# Generated at 2022-06-20 16:21:32.314449
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    original_distro = distro.id
    try:
        distro.id = lambda: 'debian'
        assert get_distribution_codename() == 'buster'
    finally:
        distro.id = original_distro

# Generated at 2022-06-20 16:21:40.006701
# Unit test for function get_distribution
def test_get_distribution():
    # To test get_distribution(), we need to fake out the underlying
    # libdistro code.  We'll do this by saving a copy of PlatformID's
    # cache and then replacing it with a dict that has our test
    # results.
    import distro as libdistro
    real_cache = libdistro.cache
    libdistro.cache = {'id': None, 'version': None, 'pretty_name': None, 'version_parts': None, 'like': None,
                       'debian_codename': None, 'ubuntu_codename': None, 'version_best': None, 'codename': None,
                       'id_like': None, 'arch': None}

# Generated at 2022-06-20 16:21:45.594448
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Return the distribution codename running on.

    :rtype: NativeString or None
    :returns: Name of the distribution codename running on

    This function attempts to determine what distribution codename the code is running
    and return a string representing that value.
    '''
    codename = get_distribution_codename()
    return codename

# Generated at 2022-06-20 16:21:58.569551
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None



# Generated at 2022-06-20 16:22:06.046127
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    test_distribution = None
    test_distribution_codename = None

    class ParentClass:
        pass

    class SubClass1(ParentClass):
        pass

    class SubClass2(ParentClass):
        pass

    class SubClass3(ParentClass):
        platform = "Linux"
        distribution = None
        distribution_version = None
        distribution_codename = None

    class SubClass4(ParentClass):
        platform = "Linux"
        distribution = "None"
        distribution_version = None
        distribution_codename = None

    class SubClass5(ParentClass):
        platform = "Linux"
        distribution = None
        distribution_version = None
        distribution_codename = None

    class SubClass6(ParentClass):
        platform = "Linux"
        distribution = None
        distribution_version = None
        distribution_

# Generated at 2022-06-20 16:22:14.950541
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class PlatformA:
        platform = 'A'
        distribution = None

    class PlatformASubclass(PlatformA):
        platform = 'A'
        distribution = 'one'

    class PlatformAClass2(PlatformA):
        platform = 'A'
        distribution = 'two'

    class PlatformB:
        platform = 'B'
        distribution = None

    class PlatformBSubclass(PlatformB):
        platform = 'B'
        distribution = 'three'

    platform = get_platform_subclass(PlatformBSubclass)
    assert platform == PlatformBSubclass, 'Expected a specific Platform subclass to be returned when distribution is provided'

    platform = get_platform_subclass(PlatformA)
    assert platform == PlatformAClass2, 'Expected a distribution-specific Platform subclass to be returned when multiple match'

    platform = get_platform_

# Generated at 2022-06-20 16:22:21.876539
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Confirm that the get_distribution function actually returns values for known good distributions

    :returns: True if the function returns a value for the distribution it is run on, False otherwise
    '''
    return get_distribution() is not None

# Generated at 2022-06-20 16:22:29.566485
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    Check that the get_distribution_version function returns the expected output
    """

    test_data = {
        'centos': ('6', '6.9', '6.7.1908'),
        'debian': ('wheezy', 'jessie', 'stretch'),
        'ubuntu': ('precise', 'xenial', 'bionic'),
    }

    for distro in test_data.keys():
        for version in test_data[distro]:
            expected = version
            osinfo = {
                'id': distro,
            }

# Generated at 2022-06-20 16:22:40.605509
# Unit test for function get_distribution
def test_get_distribution():
    if platform.system() == 'Linux':
        distribution = get_distribution()
    else:
        distribution = platform.system().capitalize()

    assert distribution
    # Known linux distros are always capitalized
    # OtherLinux is a special case for distro detection
    if platform.system() == 'Linux' and distribution not in ('OtherLinux', ):
        assert distribution.isupper()
    else:
        assert distribution.istitle()

    # Test that we call id() once and only once
    from ansible.module_utils.common._utils import patched_getattr
    mock_id = patched_getattr(distro, 'id')
    mock_id.return_value = 'MockedDistro'
    assert get_distribution() == 'MockedDistro'
    assert mock_id.call_count == 1

    # Test that the

# Generated at 2022-06-20 16:22:50.623422
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class Platform1(Base):
        platform = "A"
        distribution = None

    class Platform2(Base):
        platform = "B"
        distribution = None

    class Distribution1(Base):
        platform = "A"
        distribution = "X"

    class Distribution2(Base):
        platform = "A"
        distribution = "Y"

    class Distribution3(Base):
        platform = "A"
        distribution = "Z"

    # test platform only
    assert get_platform_subclass(Base) is Base
    assert get_platform_subclass(Platform1) is Platform1

    # test distribution only
    assert get_platform_subclass(Platform2) is Base
    assert get_platform_subclass(Distribution1) is Distribution1

    # test platform + distribution
    assert get_

# Generated at 2022-06-20 16:22:59.574916
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        from ansible.module_utils.basic import load_platform_subclass
    except ImportError:
        # ImportError: no module named ansible.module_utils.basic
        # This import will fail on Ansible 2.8 because the symbolic link has
        # not been created yet.  This is a safe place to skip the test.
        return None
    # Test the function is backwards compatible with the old module_utils.basic API
    assert get_platform_subclass(load_platform_subclass('ansible.module_utils.basic', 'User')) == load_platform_subclass('ansible.module_utils.basic', 'User')

# Generated at 2022-06-20 16:23:00.938795
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Centos'


# Generated at 2022-06-20 16:23:02.065559
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None



# Generated at 2022-06-20 16:23:36.011478
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit tests for function get_distribution
    '''
    # create a test class for testing purposes
    class testclass(object):
        def __init__(self, distribution=None, platform=None):
            self.platform = platform
            self.distribution = distribution

    # the expected results for distributions

# Generated at 2022-06-20 16:23:38.201099
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '2.7.15'

# Generated at 2022-06-20 16:23:49.152097
# Unit test for function get_distribution
def test_get_distribution():
    class FakeDistro(object):
        def __init__(self, distro):
            self.distro = distro

        def id(self):
            return self.distro

    class FakePlatform(object):
        def __init__(self, os):
            self.os = os

        def system(self):
            return self.os

    assert get_distribution() == 'Ubuntu'
    distro_debian = FakeDistro('debian')
    platform_linux = FakePlatform('Linux')
    distro_debian.id = distro_debian
    platform_linux.system = platform_linux
    assert get_distribution(distro_debian, platform_linux) == 'Debian'
    distro_fedora = FakeDistro('fedora')
    distro_fedora.id = distro_fedora
    assert get

# Generated at 2022-06-20 16:24:00.679125
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    # Test AMI IDAMJ
    # https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/AMIs.html
    #
    # AMI: amzn-ami-hvm-2017.03.1.20170812-x86_64-gp2
    # Image description: Amazon Linux 2017.03.1 LTS HVM
    # Image owner: aws-marketplace
    # Image architecture: x86_64
    # Image type: machine
    # Image platform details: Linux/UNIX
    # Image kernel release: 4.9.43-22.30.amzn1.x86_64
    # Image ramdisk release: unavailable
    # Image virtualization type: hvm
    # Image root device type: ebs

# Generated at 2022-06-20 16:24:11.706837
# Unit test for function get_distribution_version
def test_get_distribution_version():
    class MockModule(object):
        pass

    class MockDistro(object):
        @staticmethod
        def id():
            return 'Rhel'

        @staticmethod
        def version():
            return None

    cases = [
        ('Rhel', '', None),
        ('CentOS', '7.5', '7'),
        ('Fedora', '28', '28'),
        ('Debian', '8', '8'),
        ('OtherLinux', '1', '1'),
    ]

    for (distro_id, version, expected) in cases:
        setattr(cls, 'id', staticmethod(lambda: distro_id))
        setattr(cls, 'version', staticmethod(lambda: version))

        distribution = get_distribution_version()

        assert isinstance(distribution, str)

        assert distribution

# Generated at 2022-06-20 16:24:21.814971
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic as basic

    class TestClass:
        @staticmethod
        def is_applicable_to(cls):
            return 'TestClass'

        def is_applicable_to_this_platform(cls):
            # This should not be called for this test
            assert False

    class Mixed1:
        platform = 'Linux'

        @staticmethod
        def is_applicable_to(cls):
            return 'Mixed1'

        def is_applicable_to_this_platform(cls):
            # This should not be called for this test
            assert False

    class Mixed2:
        platform = 'Linux'
        distribution = 'Redhat'


# Generated at 2022-06-20 16:24:28.737133
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # input
    expected_output = {
        'ubuntu': 'xenial',
        'redhat': None,
        'centos': None,
        'amazon': None,
    }
    # run test
    output = dict()
    for item in expected_output:
        if (item == 'ubuntu'):
          distro.id = lambda: 'Ubuntu'
        elif (item == 'redhat'):
          distro.id = lambda: 'RedHat'
        elif (item == 'centos'):
          distro.id = lambda: 'CentOS'
        elif (item == 'amazon'):
          distro.id = lambda: 'Amazon'
        output[item] = get_distribution_codename()

    # verify
    assert output == expected_output

# Generated at 2022-06-20 16:24:30.385847
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename is not None

# Generated at 2022-06-20 16:24:32.825984
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename is not None

if __name__ == '__main__':
    test_get_distribution_codename()

# Generated at 2022-06-20 16:24:34.138041
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == "0.4.4"