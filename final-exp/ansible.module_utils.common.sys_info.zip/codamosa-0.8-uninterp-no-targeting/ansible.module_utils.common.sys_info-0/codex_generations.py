

# Generated at 2022-06-20 16:15:22.586500
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distribution_version = get_distribution_version()
    assert type(distribution_version) == str

# Generated at 2022-06-20 16:15:32.313044
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class PlatformSubclass(object):
        platform = "ThisPlatform"
        distribution = None

    class SpecificPlatformSubclass(PlatformSubclass):
        distribution = "ThisDistro"

    class GenericPlatformSubclass(PlatformSubclass):
        distribution = None

    class OtherPlatformSubclass(object):
        platform = "OtherPlatform"
        distribution = None

    class ThisPlatformSubclass(object):
        platform = "ThisPlatform"
        distribution = None

    class ThatPlatformSubclass(object):
        platform = "ThatPlatform"
        distribution = None

    class ThatPlatformOtherDistro(object):
        platform = "ThatPlatform"
        distribution = "ThatDistro"

    class OtherPlatformSpecificDistro(object):
        platform = "OtherPlatform"
        distribution = "OtherDistro"


# Generated at 2022-06-20 16:15:44.297684
# Unit test for function get_distribution
def test_get_distribution():
    # Expected return values on different distributions
    expected = {}
    expected['amzn'] = 'Amazon'
    expected['debian'] = 'Debian'
    expected['oracle'] = 'Oracle'
    expected['redhat'] = 'Redhat'
    expected['ubuntu'] = 'Ubuntu'
    expected['fedora'] = 'Fedora'
    expected['gentoo'] = 'Gentoo'
    expected['suse'] = 'Suse'
    expected['centos'] = 'Centos'
    expected['freebsd'] = 'FreeBSD'

    # Testing other linux distribution
    # Tested on Debian derivative
    assert get_distribution() in ('Debian', 'OtherLinux')

    # Testing other UNIX derivatives
    # Tested on FreeBSD
    assert get_distribution() in ('FreeBSD', 'OtherLinux')

    #

# Generated at 2022-06-20 16:15:45.368573
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-20 16:15:50.183268
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    import os

    class Base(object):
        platform = 'A platform'
        distribution = None

    class Base2(object):
        platform = 'A platform'
        distribution = None
    class SubClass(Base2):
        pass

    class SubClass2(Base):
        distribution = 'A distro'

    class SubClass3(Base):
        distribution = 'A different distro'

    # Test for a subclass without a distribution
    subclass = get_platform_subclass(Base)
    assert subclass.__name__ == 'Base'

    # Test selecting a specific subclass with a distribution that matches the system's
    distribution = get_distribution()
    subclass2 = get_platform_subclass(Base2)

# Generated at 2022-06-20 16:15:53.003009
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    # TODO: implement unit test
    pass

# Generated at 2022-06-20 16:16:04.641172
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    def get_os_release_info(codename=None, version_codename=None):
        return {
            'codename': codename,
            'version_codename': version_codename,
        }

    def get_lsb_release_info(codename=None):
        return {
            'codename': codename,
        }

    def distro_id():
        return 'ubuntu'


# Generated at 2022-06-20 16:16:16.653874
# Unit test for function get_distribution_codename

# Generated at 2022-06-20 16:16:17.609234
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Freebsd'


# Generated at 2022-06-20 16:16:29.146199
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test our ability to choose the correct subclass based on only what we can get from platform and distro.
    The goal is to be able to give the same result as if we were running this code on the platform.
    '''
    class_map = {}

    class Generic(object):
        platform = None
        distribution = None

    class Linux(Generic):
        platform = 'Linux'

        class Debian(Linux):
            distribution = 'Debian'

        class Redhat(Linux):
            distribution = 'Redhat'

    class Darwin(Generic):
        platform = 'Darwin'

    classes = [Generic, Linux, Linux.Debian, Linux.Redhat, Darwin]
    for cls in classes:
        class_map[(cls.platform, cls.distribution)] = cls

    # pylint: disable=invalid

# Generated at 2022-06-20 16:16:36.770702
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-20 16:16:37.722105
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution()



# Generated at 2022-06-20 16:16:49.064812
# Unit test for function get_distribution
def test_get_distribution():
    # Test on Linux (debian, centos, sles, amazon, and gentoo), OS X, and Windows
    assert get_distribution() == 'Debian'

    # Test on Linux (debian, centos, sles, amazon, and gentoo), OS X, and Windows
    assert get_distribution() == 'Debian'
    assert get_distribution() == 'Redhat'
    assert get_distribution() == 'Suse'
    assert get_distribution() == 'Amazon'
    assert get_distribution() == 'Gentoo'
    assert get_distribution() == 'Darwin'
    assert get_distribution() == 'Windows'
    # Test on Linux unsuccessfully (openSUSE and SuSE)
    assert get_distribution() == 'OtherLinux'
    assert get_distribution() == 'OtherLinux'




# Generated at 2022-06-20 16:16:50.351058
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == "Amazon"

# Generated at 2022-06-20 16:17:01.761635
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test for function get_platform_subclass.
    '''
    class TestPlatformBase:
        platform = None
        distribution = None

    # Base class won't be returned
    assert get_platform_subclass(TestPlatformBase) is not TestPlatformBase

    class TestPlatformOne(TestPlatformBase):
        platform = 'Linux'
        distribution = 'Fedora'

    class TestPlatformTwo(TestPlatformBase):
        platform = 'Linux'
        distribution = 'RedHat'

    class TestPlatformThree(TestPlatformBase):
        platform = 'Linux'

    class TestPlatformFour(TestPlatformBase):
        platform = 'Darwin'

    # Test for class TestPlatformOne,
    # Test for class TestPlatformTwo and TestPlatformThree,
    # Test for class TestPlatformFour,

# Generated at 2022-06-20 16:17:13.789408
# Unit test for function get_distribution_version
def test_get_distribution_version():
    test_cases = [
        # test case tuple:
        # -- name: use friendly name for test
        # -- distro id: use this as distro id
        # -- expected: expected result
        ('generic (no distro, no version)', None, None),
        ('amzn (no version)', 'amzn', ''),
        ('rhel (no version)', 'rhel', ''),
        ('centos (version)', 'centos', distro.version()),
        ('amzn (version)', 'amzn', distro.version()),
        ('rhel (version)', 'rhel', distro.version()),
    ]

    saved_distro_id = distro.id()

    for test_case in test_cases:
        setattr(distro, 'id', lambda: test_case[1])

# Generated at 2022-06-20 16:17:26.144811
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    An example unit test for the ``get_platform_subclass`` function.

    The unit test will:

    * Create a base class
    * Create two subclasses for the base class that are both for this platform
    * Create a third subclass of the base class for a different platform
    * Create a fourth subclass of the base class for this platform but a different distribution
    * Ensure that the third subclass is not returned when the current platform is not the same
    * Ensure that the fourth subclass is not returned for this distribution
    * Ensure that the first subclass is returned when we ask for a class for this distribution
    * Ensure that the second subclass is returned when we ask for a class for a different distribution
    '''
    # This is not a good unit test example.  It relies on the machine it is running on.
    # In addition, the test is not automated but has to be

# Generated at 2022-06-20 16:17:29.348303
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial' or get_distribution_codename() == 'bionic'

# Generated at 2022-06-20 16:17:40.465653
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version to make sure that even if
    the distro's version format changes we still get the right value
    '''
    # Check the major version when only the major version is available
    os_release_version = b'2'
    lsb_release_version = b''
    distro_version = b''
    lsb_release_id = b'centos'
    distribution_id = b'centos'
    result_version = get_distribution_version(os_release_version, lsb_release_version, distro_version, lsb_release_id, distribution_id)
    assert result_version == u'2'

    # Check the major version when minor version is available
    os_release_version = b'2'
    lsb_release_version = b''

# Generated at 2022-06-20 16:17:52.067992
# Unit test for function get_distribution_version
def test_get_distribution_version():
    os_release_info = {}
    distro.os_release_info = lambda: os_release_info

    os_release_info['version_best'] = None
    assert get_distribution_version() is None
    os_release_info['version_best'] = ''
    assert get_distribution_version() == ''

    os_release_info['version'] = None
    os_release_info['version_best'] = None
    assert get_distribution_version() is None
    os_release_info['version'] = ''
    os_release_info['version_best'] = ''
    assert get_distribution_version() == ''

    os_release_info['version'] = '1.2.3'
    os_release_info['version_best'] = '1.2.3'
    assert get_distribution

# Generated at 2022-06-20 16:17:59.743568
# Unit test for function get_distribution
def test_get_distribution():
    assert distro.id().capitalize() == 'Redhat'

# Generated at 2022-06-20 16:18:02.432795
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is None
    assert get_distribution_version(platform=u'Linux') is not None
    assert get_distribution_version(platform=u'FreeBSD') is None

# Generated at 2022-06-20 16:18:03.538732
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-20 16:18:13.517416
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from distro import linux_distribution

    distro.linux_distribution = linux_distribution

    # Test Ubuntu (Xenial 16.04)
    distro._distro = Ubuntu1604()
    assert get_distribution_codename() == 'xenial'

    # Test Debian (Stretch 9)
    distro._distro = Debian9()
    assert get_distribution_codename() == 'stretch'

    # Test Fedora (28)
    distro._distro = Fedora28()
    assert get_distribution_codename() is None


# Generated at 2022-06-20 16:18:18.405001
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    This function only supports CentOS, Debian, and RHEL.

    Returns:
        bool: True if get_distribution_version passes, else False
    '''
    try:
        if get_distribution_version() == u'' or get_distribution_version() is None:
            return False
        else:
            return True
    except:
        return False

# Generated at 2022-06-20 16:18:28.046432
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''Unit test for get_distribution_version()'''

    # Red Hat
    dist = {'ID': u'centos', 'ID_LIKE': u'rhel fedora', 'VERSION_ID': u'7', 'PRETTY_NAME': u'CentOS Linux 7 (Core)'}
    distro.util.parse_os_release.cache_clear()
    distro.util.parse_os_release.cache_update(dist)
    version = get_distribution_version()
    assert version == u'7'

    # Debian bug #931197
    dist = {'ID': u'debian', 'ID_LIKE': u'raspbian', 'PRETTY_NAME': u'Raspbian GNU/Linux 10 (buster)', 'VERSION': u'10 (buster)'}

# Generated at 2022-06-20 16:18:32.378051
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Evaluates: get_platform_subclass
    '''
    class Base:
        pass

    class PlatformIndependent(Base):
        pass

    class Linux(Base):
        platform = u'Linux'
        distribution = None

    class LinuxBased(Base):
        platform = u'Linux'
        distribution = u'OtherLinux'

    class NonLinux(Base):
        platform = u'AIX'
        distribution = None

    class LinuxSpecific(Base):
        platform = u'Linux'
        distribution = u'CentOS'

    assert get_platform_subclass(Base) == Base
    assert get_platform_subclass(PlatformIndependent) == PlatformIndependent
    assert get_platform_subclass(NonLinux) == NonLinux
    assert get_platform_subclass(Linux) == Linux

# Generated at 2022-06-20 16:18:39.075932
# Unit test for function get_distribution
def test_get_distribution():
    distributions = {
        'centos': 'Centos',
        'centos linux': 'Centos',
        'ubuntu': 'Ubuntu',
        'ubuntu linux': 'Ubuntu',
        'debian': 'Debian',
        'oracle': 'Oracle',
        'red hat': 'Redhat',
        'redhat': 'Redhat',
        'red hat enterprise linux server': 'Redhat',
        'suse enterprise server': 'Suse',
        'sles': 'Suse',
    }

    for v in distributions:
        distro.id = lambda: v
        assert distribution() == distributions[v]

    distro.id = lambda: 'not_a_distro'
    assert distribution() == 'OtherLinux'

# Generated at 2022-06-20 16:18:46.402972
# Unit test for function get_distribution_version
def test_get_distribution_version():

    # Mocking the _platform_distro function
    _platform_distro_old = distro._platform_distro
    try:

        def _platform_distro():
            return 'amzn', {'version': '1'}

        distro._platform_distro = _platform_distro

        # Testing the get_distribution_version function
        assert(get_distribution_version() == '1')

    finally:
        distro._platform_distro = _platform_distro_old

# Generated at 2022-06-20 16:18:47.848973
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'bionic'

# Generated at 2022-06-20 16:19:09.204142
# Unit test for function get_distribution_version
def test_get_distribution_version():
    class OSRelease:
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    class OSReleaseUnitTest:
        def __init__(self, filename, os_release_info, expected_return):
            '''
            Builds a unit test to check that function get_distribution_version()
            returns the expected value given certain content of the os-release
            file.

            :arg filename: The name of the os-release file.
            :arg os_release_info: The content of the os-release file.
            :arg expected_return: The expected return value.
            '''
            self.filename = filename
            self.os_release_info = os_release_info
            self.expected_return = expected_return


# Generated at 2022-06-20 16:19:20.481185
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import sys
    import types

    if sys.version_info[0] >= 3:
        class TestClass(object):
            platform = None
            distribution = None
            pass
    else:
        class TestClass():
            platform = None
            distribution = None
            pass

    class Linux(TestClass):
        platform = 'Linux'
        distribution = None
        pass

    class POSIX(TestClass):
        platform = ('Linux', 'FreeBSD', 'OpenBSD', 'NetBSD', 'Darwin')
        distribution = None
        pass

    class MacOSX(TestClass):
        platform = 'Darwin'
        distribution = None
        pass

    class Unknown(TestClass):
        pass

    class Linux_Debian(Linux):
        distribution = 'Debian'
        pass

    class Linux_Ubuntu(Linux):
        distribution

# Generated at 2022-06-20 16:19:21.399210
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == u'Redhat'

# Generated at 2022-06-20 16:19:29.998864
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.common._text import to_bytes

    os_release_info = distro.os_release_info()
    lsb_release_info = distro.lsb_release_info()

    distribution_codenames = {
        'centos': to_bytes('Core'),
        'amazon': to_bytes('2'),
        'rhel': to_bytes('Maipo'),
        'debian': to_bytes('jessie'),
        'ubuntu': to_bytes('trusty'),
    }

    for distro_name, expected_codename in distribution_codenames.items():
        distro.distro_identifier = distro_name
        distro.os_release_info = {'version_codename': expected_codename}

# Generated at 2022-06-20 16:19:36.359598
# Unit test for function get_distribution_version
def test_get_distribution_version():
    def _test(distro_id, version, best_version=None, expected_version=None):
        def _get_version():
            v = distro.version()
            return v

        def _get_best_version():
            v = distro.version(best=True)
            return v

        orig_get_version = distro.version
        orig_get_best_version = distro.version

        try:
            distro.id = lambda: distro_id
            distro.version = _get_version
            distro.version = _get_best_version
            _version = get_distribution_version()
            assert _version is expected_version
        finally:
            distro.version = orig_get_version
            distro.version = orig_get_best_version
            distro.id = orig_

# Generated at 2022-06-20 16:19:42.701678
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test function get_distribution
    :return:
    '''
    distro_id = distro.id()
    distribution = get_distribution()


# Generated at 2022-06-20 16:19:50.492716
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BSD:
        platform = 'BSD'
        distribution = None
    class Linux:
        platform = 'Linux'
        distribution = None
    class RedHat(Linux):
        distribution = 'RedHat'
    class CentOS(RedHat):
        distribution = 'CentOS'

    assert get_platform_subclass(BSD) == BSD
    assert get_platform_subclass(Linux) == Linux
    assert get_platform_subclass(RedHat) == RedHat
    assert get_platform_subclass(CentOS) == CentOS

# Generated at 2022-06-20 16:19:57.830512
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Check the behaviour of the get_platform_subclass function.
    Mocked version of the function platform.system() is used.
    """
    def foo_get_platform_subclass_mock_return():
        return 'Linux'

    def foo_get_platform_subclass_distro_mock_return():
        return 'Debian'

    from ansible.module_utils.basic import get_platform_subclass

    from ansible.module_utils import basic
    from ansible.module_utils.basic import get_distribution
    from ansible.module_utils.basic import get_distribution_codename
    from ansible.module_utils.basic import get_distribution_version

    setattr(basic, 'get_distribution', foo_get_platform_subclass_distro_mock_return)
   

# Generated at 2022-06-20 16:20:09.228993
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class SubClassA(BaseClass):
        distribution = 'TestA'
        platform = 'Test'

    class SubClassB(BaseClass):
        distribution = None
        platform = 'Test'

    class SubClassC(BaseClass):
        distribution = 'TestB'
        platform = 'Other'

    class SubClassD(BaseClass):
        distribution = None
        platform = 'Other'

    assert get_platform_subclass(BaseClass) == BaseClass

    class TestPlatform:
        def get_platform(self):
            return 'Test'

        def get_distribution(self):
            return 'TestA'

    class OtherPlatform:
        def get_platform(self):
            return 'Other'

        def get_distribution(self):
            return 'TestB'

    assert get_

# Generated at 2022-06-20 16:20:17.131589
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # TODO: Need to mock platform.system and distro.id

    platform.system = lambda: 'Linux'

    distro.id = lambda: 'Ubuntu'
    distro.version = lambda: '16.04'
    distro.codename = lambda: 'xenial'
    assert get_distribution_codename() == 'xenial'

    # Non-Ubuntu distros should not have an LSB codename
    distro.id = lambda: 'Fedora'
    distro.version = lambda: '28'
    distro.codename = lambda: 'Fedora'
    assert get_distribution_codename() == 'Fedora'

# Generated at 2022-06-20 16:20:43.918902
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None

# Generated at 2022-06-20 16:20:49.247425
# Unit test for function get_distribution
def test_get_distribution():
    result = get_distribution()
    assert result in ('Amzn', 'Amazon', 'Arch', 'Centos', 'Debian', 'Fedora', 'Freebsd', 'Gentoo', 'Linuxmint', 'Macosx', 'Openbsd', 'Otherlinux', 'Redhat', 'Slackware', 'Ubuntu')


# Generated at 2022-06-20 16:20:59.669803
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Function to test get_distribution_codename

    :rtype: boolean
    :returns: True if get_distribution_codename is working properly
    '''
    codename = distro.codename()
    if codename == '':
        if get_distribution_codename():
            return False
    else:
        if get_distribution_codename() != codename:
            return False
    return True

# Generated at 2022-06-20 16:21:01.671439
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    assert get_distribution_codename() == 'focal'


# Generated at 2022-06-20 16:21:05.117432
# Unit test for function get_distribution_version
def test_get_distribution_version():
    if platform.system() == 'Linux':
        assert get_distribution_version() is not None
    else:
        assert get_distribution_version() is None

# Generated at 2022-06-20 16:21:15.176042
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        '''
        Dummy class to allow for subclassing
        '''
        pass

    class UnixBase(Base):
        '''
        Subclass of Base for Unix systems
        '''
        platform = 'Linux'

    class SpecificUnix1(UnixBase):
        '''
        Subclass of UnixBase for a specific Linux platform
        '''
        platform = 'Linux'
        distribution = 'Redhat'

    class SpecificUnix2(UnixBase):
        '''
        Subclass of UnixBase for a different Linux platform
        '''
        platform = 'Linux'
        distribution = 'Amazon'

    class WindowsBase(Base):
        '''
        Subclass of Base for Windows platforms
        '''
        platform = 'Windows'


# Generated at 2022-06-20 16:21:16.673092
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == platform.dist()[1]

# Generated at 2022-06-20 16:21:24.424394
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test to see if the get_distribution_version function returns the
    proper values.
    '''
    tests = (
        (u'centos', u'7.5.1804', u'7.5'),
        (u'debian', u'9.4', u'9.4'),
        (u'ubuntu', u'18.04', u'18.04'),
        (u'fedora', u'28', u'28.0'),
    )

    for (distro_id, distro_version, expected_ansible_version) in tests:
        with patch('ansible.module_utils.distro.id') as distro_id_mock:
            distro_id_mock.return_value = distro_id


# Generated at 2022-06-20 16:21:29.405600
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible.module_utils._text import to_bytes

    distribution_version = get_distribution_version()
    assert distribution_version is not None

    assert (platform.system() == 'Linux') == (distribution_version is not None)

    # Distribution version should be a bytes string
    assert isinstance(distribution_version, to_bytes)

# Generated at 2022-06-20 16:21:30.727749
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Verify function returns expected result.
    '''
    assert get_distribution_version() == ''

# Generated at 2022-06-20 16:22:21.203310
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'RedHat'


# Generated at 2022-06-20 16:22:27.729018
# Unit test for function get_distribution
def test_get_distribution():
    """ Test case for function get_distribution() """

    # test for distribution name
    DISTRIBUTION = get_distribution()
    # distribution name is Redhat or Amazon linux
    if DISTRIBUTION in ('Redhat', 'Amazon'):
        assert DISTRIBUTION == 'Redhat' or DISTRIBUTION == 'Amazon'
    # distribution name is null
    elif DISTRIBUTION is None:
        assert DISTRIBUTION is None
    # distribution name is not Redhat, Amazon or None
    else:
        assert DISTRIBUTION is not None


# Generated at 2022-06-20 16:22:39.264639
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class parent:
        distribution = None
        platform = 'Linux'

    class child1(parent):
        pass

    class child2(parent):
        distribution = 'redhat'

    class child3(parent):
        distribution = 'ubuntu'

    class child4(parent):
        distribution = 'amazon'

    class child5(parent):
        distribution = 'amazon'
        platfrom = 'Linux2'

    class child6(parent):
        distribution = 'amazon'
        platform = 'Linux'

    assert get_platform_subclass(child1) == child1
    assert get_platform_subclass(child2) == child2
    assert get_platform_subclass(child3) == child3
    assert get_platform_subclass(child4) == child4
    assert get_platform_subclass(child5) == child5

# Generated at 2022-06-20 16:22:49.680842
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import unittest

    class TestGetDistributionCodename(unittest.TestCase):

        def setUp(self):
            # Reset the distro detection so that we can test
            # what happens when it has already been run
            distro.init()

        def _codename(self, os_release=None, lsb_release=None,
                      expected_codename=None, os_release_codename=None,
                      lsb_release_codename=None, os_release_version_codename=None):

            codename = None
            if expected_codename:
                codename = expected_codename

            if lsb_release_codename:
                lsb_release_codename = {'codename': lsb_release_codename}
            else:
                lsb_release_codename = {}

            os

# Generated at 2022-06-20 16:22:51.358903
# Unit test for function get_distribution_version
def test_get_distribution_version():
    pass

# Generated at 2022-06-20 16:23:01.252679
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codenames = {}
    # Test id_distro can return None - this happens with some very old distros
    # where the /etc/os-release file does not contain a id_distro field
    distribution_codenames[platform.system()] = get_distribution_codename()

    # Test that id_distro returns a string
    distribution_codenames['Linux'] = get_distribution_codename()

    # Test that id_distro returns None when a non-Linux distro is tested
    distribution_codenames['Darwin'] = get_distribution_codename()
    distribution_codenames['Windows'] = get_distribution_codename()

    # Test that Amazon Linux returns 'amzn'
    distro.id_amzn = lambda: 'amzn'
    distro.codename_amzn

# Generated at 2022-06-20 16:23:13.154288
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    # Imports were moved to this function so the
    # test can be run without having the packages
    # installed on the system
    import platform
    import ansible.module_utils.common._utils

    class BaseClass:
        platform = u'Base'
        distribution = None

    class BaseNonLinuxSubclass(BaseClass):
        platform = platform.system()

    class MatchingLinuxSubclass(BaseNonLinuxSubclass):
        distribution = u'TESTDIST'

    class NonMatchingLinuxSubclass(BaseNonLinuxSubclass):
        distribution = u'NOTCORRECT'

    class LinuxClass(MatchingLinuxSubclass):
        pass

    class NonLinuxClass(BaseNonLinuxSubclass, BaseClass):
        pass


# Generated at 2022-06-20 16:23:14.804884
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename = get_distribution_codename()
    assert distribution_codename is not None

# Generated at 2022-06-20 16:23:16.418412
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None

# Generated at 2022-06-20 16:23:24.584954
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    import unittest

    class Parent():
        pass

    class MacParent(Parent):
        platform = 'Darwin'

    class MacOtherParent(Parent):
        platform = 'Darwin'

    class LinuxParent(Parent):
        platform = 'Linux'

    class LinuxOtherParent(Parent):
        platform = 'Linux'

    class OtherParent(Parent):
        pass

    class MacSubclass(MacParent):
        pass

    class MacOtherSubclass(MacOtherParent):
        pass

    class LinuxSubclass(LinuxParent):
        pass

    class LinuxOtherSubclass(LinuxOtherParent):
        pass

    class OtherSubclass(OtherParent):
        pass


# Generated at 2022-06-20 16:24:17.977053
# Unit test for function get_distribution
def test_get_distribution():
    distribution_name = get_distribution()

    assert distribution_name == distribution_name.capitalize()



# Generated at 2022-06-20 16:24:26.327609
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # test_codename is a stub function to fake a distro.distribution function.
    # it returns a fake version of distro.distribution depending on the arg passed in
    def test_codename(arg):
        if arg == 'id':
            return 'centos' # ensure we test the centos code path
        elif arg == 'centos':
            return 'CentOS' # ensure we test the centos code path
        elif arg == 'version':
            return '7.7.1908' # ensure we test the centos code path
        else:
            return 'xenial' # test the Ubuntu code path

    distro.distribution = test_codename
    codename = get_distribution_codename()
    assert codename == 'centos'

# Generated at 2022-06-20 16:24:37.584916
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class BaseClass(object):
        pass

    class Linux(BaseClass):
        platform = 'Linux'
        distribution = None

    class LinuxRedHat(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class LinuxFedora(BaseClass):
        platform = 'Linux'
        distribution = 'Fedora'

    class Windows(BaseClass):
        platform = 'Windows'
        distribution = None

    platform.system = lambda: 'Linux'
    get_distribution = lambda: 'Redhat'
    assert get_platform_subclass(Linux) == LinuxRedHat
    assert get_platform_subclass(BaseClass) == LinuxRedHat
    assert get_platform_subclass(LinuxFedora) == LinuxFedora
    assert get_platform_subclass(Windows) == BaseClass


# Generated at 2022-06-20 16:24:49.626366
# Unit test for function get_distribution_version

# Generated at 2022-06-20 16:24:50.610120
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-20 16:24:59.328933
# Unit test for function get_distribution_version

# Generated at 2022-06-20 16:25:11.295233
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test that get_platform_subclass() returns the correct class for the platform we're running on.
    '''

    import ansible_test.mock_module
    from ansible_test.mock_module import TestObj

    this_platform = platform.system().lower()

    # Test that the function chooses the most specific subclass possible
    assert(get_platform_subclass(TestObj) == getattr(ansible_test.mock_module, this_platform+'_specific'))

    # Test that it chooses the general platform subclass instead of the distribution subclass if the
    # distribution subclass doesn't exist
    ansible_test.mock_module.distro_specific.distribution = "Redhat"