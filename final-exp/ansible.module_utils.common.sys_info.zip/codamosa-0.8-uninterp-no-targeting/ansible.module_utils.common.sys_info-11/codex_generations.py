

# Generated at 2022-06-20 16:15:27.411436
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class FauxModule:
        def __init__(self):
            pass

    class GenericFauxModule(FauxModule):
        platform = "Generic"
        distribution = None

    class GenericLinuxFauxModule(FauxModule):
        platform = "Linux"
        distribution = None

    class OtherLinuxFauxModule(FauxModule):
        platform = "Linux"
        distribution = "OtherLinux"

    class FedoraFauxModule(FauxModule):
        platform = "Linux"
        distribution = "Fedora"

    class UbuntuFauxModule(FauxModule):
        platform = "Linux"
        distribution = "Ubuntu"

    assert GenericFauxModule == get_platform_subclass(FauxModule)
    assert GenericFauxModule == get_platform_subclass(GenericFauxModule)
    assert GenericLinuxFauxModule == get_

# Generated at 2022-06-20 16:15:38.101339
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # test centos
    distro.id = lambda: 'centos'
    distro.version = lambda: '7.5'
    distro.version = lambda best=True: '7.5.1804'
    assert get_distribution_version() == '7.5'

    # test debian
    distro.id = lambda: 'debian'
    distro.version = lambda: '9'
    distro.version = lambda best=True: '9.5'
    assert get_distribution_version() == '9.5'

    # test ubuntu
    distro.id = lambda: 'ubuntu'
    distro.version = lambda: '16.04'
    distro.version = lambda best=True: '16.04.5'

    # test rhel

# Generated at 2022-06-20 16:15:50.261328
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest

    class FakePlatform(object):
        def __init__(self, distribution, platform):
            self.distribution = distribution
            self.platform = platform

    class BasePlatform(FakePlatform):
        platform = None
        distribution = None

    class OtherLinux(FakePlatform):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class Linux(FakePlatform):
        platform = 'Linux'

    class LinuxDebian(FakePlatform):
        platform = 'Linux'
        distribution = 'Debian'

    class LinuxDebianStretch(FakePlatform):
        platform = 'Linux'
        distribution = 'Debian'
        codename = 'stretch'

    class LinuxDebianBuster(FakePlatform):
        platform = 'Linux'
        distribution = 'Debian'
        codename = 'buster'


# Generated at 2022-06-20 16:16:02.485717
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class ImplBaseClass:
        platform = 'Base'
        distribution = None

    class ImplLinux(ImplBaseClass):
        platform = 'Linux'

    class ImplOtherLinux(ImplBaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class ImplOtherLinux2(ImplBaseClass):
        distribution = 'OtherLinux'

    class ImplSuse(ImplLinux):
        distribution = 'Suse'

    class ImplSuseLinux(ImplLinux):
        distribution = 'SuseLinux'

    class ImplSuse12(ImplSuse):
        d_version = '12'

    class ImplPosix(ImplBaseClass):
        platform = 'posix'

    # test when the wrong base class is passed

# Generated at 2022-06-20 16:16:04.498792
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for function get_distribution()
    '''
    assert get_distribution()

# Generated at 2022-06-20 16:16:16.522548
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class BaseClass(object):
        platform = 'BasePlatform'
        distribution = None

    class PlatformA(BaseClass):
        platform = 'TestPlatformA'
        distribution = None

    class PlatformADistroA(PlatformA):
        platform = 'TestPlatformA'
        distribution = 'TestDistroA'

    class PlatformADistroB(PlatformA):
        platform = 'TestPlatformA'
        distribution = 'TestDistroB'

    class BaseTestPlatformClass(object):
        platform = 'BasePlatform'
        distribution = None

    class TestPlatformAPlatformClass(BaseTestPlatformClass):
        platform = 'TestPlatformA'
        distribution = None

    class TestPlatformADistroBPlatformClass(TestPlatformAPlatformClass):
        platform = 'TestPlatformA'
        distribution = 'TestDistroB'


# Generated at 2022-06-20 16:16:27.814220
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    Test the function get_distribution_version in the platform_utils module.
    This function only works on Linux distributions.
    """
    from ansible_collections.misc.tests.unit.compat.mock import patch
    from ansible.module_utils._text import to_native

    # Debian, Fedora, and Centos are explicitly tested.  Other Linux distributions
    # are included in the "OtherLinux" case.

# Generated at 2022-06-20 16:16:40.244139
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.basic import AnsibleModule

    # Test that a distribution with a codename returns one
    os_release_info_with_code_name = {
        'PRETTY_NAME': '"Debian GNU/Linux 9 (stretch)"',
        'NAME': 'Debian GNU/Linux',
        'ID': 'debian',
        'VERSION_ID': '9',
        'HOME_URL': 'https://www.debian.org/',
        'SUPPORT_URL': 'https://www.debian.org/support',
        'BUG_REPORT_URL': 'https://bugs.debian.org/',
        'VERSION_CODENAME': 'stretch'
    }

    # Test that a distribution without a codename returns None

# Generated at 2022-06-20 16:16:50.997775
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class TestBase:
        pass

    class TestBaseDistro(TestBase):
        distribution = "test1"

    class TestBasePlatform(TestBase):
        platform = "test2"

    class TestBaseDistroPlatform(TestBase):
        distribution = "test3"
        platform = "test4"

    class TestBaseDistroPlatform2(TestBase):
        distribution = "test3"
        platform = "test4"

    class TestBaseDistroPlatform3(TestBase):
        distribution = "test3"
        platform = "test4"

    class TestSub1(TestBaseDistroPlatform):
        pass

    class TestSub2(TestBaseDistroPlatform):
        pass

    assert(get_platform_subclass(TestBase) is TestBase)

# Generated at 2022-06-20 16:16:53.352612
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # return None in case of non-Linux system
    assert get_distribution_version() is None
    assert get_distribution_codename() is None

# Generated at 2022-06-20 16:17:03.466571
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution()

# Generated at 2022-06-20 16:17:05.300561
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None



# Generated at 2022-06-20 16:17:15.579956
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename()
    '''
    # Create dictionary with os-release
    os_release = {
        'name': 'Red Hat Enterprise Linux Server',
        'version': '7.7 (Maipo)',
        'version_id': '7.7',
        'id': 'rhel',
        'id_like': 'fedora',
        'version_codename': 'Maipo',
        'pretty_name': 'Red Hat Enterprise Linux Server 7.7 (Maipo)'
    }

    # Create dictionary with lsb_release

# Generated at 2022-06-20 16:17:26.808863
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test get_platform_subclass
    '''
    # In this test we only need a simple class hierarchy.
    # We can't use any funcs or variables from the module under test.

    class Base(object):
        distribution = None
        platform = "base"

    class RedHat(Base):
        distribution = "redhat"
        platform = "linux"

    class CentOS(RedHat):
        distribution = "centos"

    class FreeBSD(Base):
        distribution = None
        platform = "freebsd"

    class OtherLinux(Base):
        distribution = "otherlinux"
        platform = "linux"

    # Generic classes should stay themselves
    assert get_platform_subclass(Base) is Base
    assert get_platform_subclass(RedHat) is RedHat

# Generated at 2022-06-20 16:17:35.937644
# Unit test for function get_distribution
def test_get_distribution():
    def _test_distro(distro_name, expected_result):
        with distro.LinuxDistribution(''):
            distro.id = lambda: distro_name
            assert get_distribution() == expected_result, "Distribution %s not converted to %s" % (distro_name, expected_result)

    _test_distro('ubuntu', 'Ubuntu')
    _test_distro('debian', 'Debian')
    _test_distro('amzn', 'Amazon')
    _test_distro('rhel', 'Redhat')
    _test_distro('sles', 'Suse')
    _test_distro('opensuse', 'Suse')
    _test_distro('fedora', 'Fedora')
    _test_distro('oracle', 'OracleLinux')
    _test_

# Generated at 2022-06-20 16:17:47.349028
# Unit test for function get_distribution
def test_get_distribution():
    distro_id = distro.id()
    distro_name = get_distribution()

    if distro_id == 'arch':
        assert distro_name == 'Archlinux'
    elif distro_id == 'centos':
        assert distro_name == 'Redhat'
    elif distro_id == 'oracle':
        assert distro_name == 'Redhat'
    elif distro_id == 'fedora':
        assert distro_name == 'Fedora'
    elif distro_id == 'debian':
        assert distro_name == 'Debian'
    elif distro_id == 'ubuntu':
        assert distro_name == 'Debian'
    elif distro_id == 'suse':
        assert distro_name == 'Suse'

# Generated at 2022-06-20 16:17:57.955955
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """Test get_distribution_version

    1. test if None is returned when it is not run on Linux
    2. test if the correct version is returned on Linux

    """

    saved_system = platform.system()

    # Case 1 is not run on Linux
    platform.system = lambda: "Not Linux"
    assert None is get_distribution_version(), "It should not return any value if it is not run on Linux"

    # Case 2 is run on Linux
    platform.system = lambda: "Linux"
    assert "6" == get_distribution_version(), "It should return string 6 if it is run on the CentOS 6"

    platform.system = saved_system

# Generated at 2022-06-20 16:18:02.703719
# Unit test for function get_distribution
def test_get_distribution():
    platform_details = dict(platform.linux_distribution())

    assert distro.id() == get_distribution()
    if platform_details['distname']:
        assert platform_details['distname'].capitalize() == get_distribution()
    elif platform_details['id']:
        assert platform_details['id'].capitalize() == get_distribution()

# Generated at 2022-06-20 16:18:03.539925
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-20 16:18:16.002491
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Check: Return the version of the distribution the code is running on

    :rtype: NativeString or None
    :returns: A string representation of the version of the distribution. If it
    cannot determine the version, it returns an empty string. If this is not run on
    a Linux machine it returns None.
    '''
    version = distro.version()
    distribution = distro.id()
    version_best = distro.version(best=True)

    if version is not None:
        if distribution in needs_best_version:
            if distribution == 'centos':
                version = '.'.join(version_best.split('.')[:2])
            if distribution == 'debian':
                version = version_best

    else:
        version = ''

    return version

# Generated at 2022-06-20 16:18:38.238422
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils import basic

    # test possible return values of function get_distribution
    possible_distribution = ('Linux', 'Freebsd', 'Netbsd', 'Openbsd', 'Darwin', 'Sunos', 'Aix', 'OtherLinux')
    distribution = basic.get_distribution()
    assert distribution in possible_distribution

    # test if 'platform.system()' is properly called
    # monkeypatching platform.system() to return 'Linux'
    platform.system = lambda: 'Linux'
    # test if get_distribution return 'Linux'
    assert basic.get_distribution() == 'Linux'

    # testing for osx
    # monkeypatching platform.system() to return 'Darwin'
    platform.system = lambda: 'Darwin'
    # test if get_distribution return 'Darwin

# Generated at 2022-06-20 16:18:39.417268
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert 'xenial' == get_distribution_codename()

# Generated at 2022-06-20 16:18:50.571489
# Unit test for function get_distribution
def test_get_distribution():
    import platform
    import sys
    platform_mocked = platform.system
    distro_mocked = distro.id
    distro_version = distro.version
    platform.system = lambda: 'Linux'
    distro.id = lambda: 'redhat'
    assert get_distribution() == 'Redhat'
    distro.id = lambda: 'redhatenterpriseserver'
    assert get_distribution() == 'Redhat'
    distro.id = lambda: 'Redhatenterpriseserver'
    assert get_distribution() == 'Redhat'
    distro.id = lambda: 'Redhatenterpriseserver'
    distro.version = lambda: ''
    assert get_distribution() == 'Redhat'
    distro.id = lambda: 'sles'
    distro.version = lambda: ''
   

# Generated at 2022-06-20 16:19:02.383781
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Used to test the get_platform_subclass function with the following class hierarchy
        BaseClassA
          SubClassA_B
          SubClassA_C
          SubClassA_D
              SubSubClassA_D_1
        BaseClassB
          SubClassB_B

    :returns: ``True`` if the test passes, ``False`` otherwise

    '''
    class BaseClassA:
        pass

    class BaseClassB:
        pass

    class SubClassA_B(BaseClassA):
        distribution = u'Debian'
        platform = u'Linux'

    class SubClassA_C(BaseClassA):
        distribution = u'Debian'
        platform = u'Linux'

    class SubClassA_D(BaseClassA):
        distribution = u'Debian'

# Generated at 2022-06-20 16:19:10.329447
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test get_platform_subclass() function
    '''
    import sys

    # Create a base class and two subclasses for Linux
    class Base(object):
        platform = 'Linux'
        distribution = None

    class DistSubclass(Base):
        distribution = 'Amzn'

    class PlatformSubclass(Base):
        distribution = 'OtherLinux'

    # Create a base class and a subclass for FreeBSD
    class FreeBSDBase(object):
        platform = 'FreeBSD'
        distribution = None

    class FreeBSDSubclass(FreeBSDBase):
        pass

    # Test the Linux platform subclass
    my_class = get_platform_subclass(Base)
    assert my_class == DistSubclass, "Didn't get the correct Linux subclass"

    # Test the FreeBSD platform subclass
    my_class = get_platform_subclass

# Generated at 2022-06-20 16:19:12.049250
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == u'xenial'

# Generated at 2022-06-20 16:19:22.821360
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    def mock_distro__version(best=False):
        '''
        Mocking distro.version()
        '''
        if best:
            return "16.04.11"
        else:
            return "4.4.0-31-generic"

    def mock_distro__id():
        '''
        Mocking distro.id()
        '''
        return 'ubuntu'

    def mock_distro__os_release_info():
        '''
        Mocking distro.os_release_info()
        '''
        return {'version_codename': 'xenial'}


# Generated at 2022-06-20 16:19:31.589299
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass()
    '''

    import ansible.module_utils.basic

    class Platform1:
        platform = 'Linux'

    class Platform2(Platform1):
        pass

    class Platform3(Platform2):
        pass

    class Platform4(Platform3):
        platform = 'Darwin'

    class Platform5(Platform1):
        platform = 'FreeBSD'

    class Platform6(Platform2):
        pass

    class Platform7(Platform6):
        platform = 'Darwin'

    class Platform8(Platform7):
        distribution = 'Gentoo'

    class Platform9(Platform8):
        platform = 'Linux'

    class Test:
        pass


# Generated at 2022-06-20 16:19:34.614640
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        pass

    class B(A):
        platform = platform.system()

    class C(B):
        distribution = get_distribution()

    class D(C):
        pass

    result = get_platform_subclass(A)

    assert result is D

# Generated at 2022-06-20 16:19:40.387218
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    Basic test case for function get_distribution_version.
    """
    platform_string = platform.system()

    if platform_string == 'Linux':
        if distro.id().lower() == 'debian':
            # Debian OS
            assert get_distribution_version() == distro.debian_version()
        elif distro.id().lower() == 'redhat':
            # Redhat OS
            assert get_distribution_version() == distro.redhat_version()
        else:
            assert get_distribution_version() == ''
    else:
        assert get_distribution_version() is None

# Generated at 2022-06-20 16:19:53.295532
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # check for valid return type
    assert isinstance(get_platform_subclass(type(None)), type)



# Generated at 2022-06-20 16:20:02.299799
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # test for correct loading of subclass for Linux
    class Test1:
        platform = 'Linux'
        distribution = None

    class Test1Linux(Test1):
        platform = 'Linux'
        distribution = None

    class Test1Debian(Test1):
        platform = 'Linux'
        distribution = 'Debian'

    class Test1Redhat(Test1):
        platform = 'Linux'
        distribution = 'Redhat'

    assert get_platform_subclass(Test1) == Test1Linux
    platform.system = lambda: 'Linux'
    assert get_platform_subclass(Test1) == Test1Linux
    distribution = get_distribution
    distribution = lambda: 'Debian'
    assert get_platform_subclass(Test1) == Test1Debian
    distribution = lambda: 'Redhat'
    assert get_platform

# Generated at 2022-06-20 16:20:14.750075
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest
    import unittest.mock

    # get_platform_subclass needs to know the distribution we are running.  Mock it.
    with unittest.mock.patch('ansible.module_utils.common._utils.get_distribution') as get_distribution:


        # If the class we are trying to find a subclass for has no subclasses, we'll get the original class back
        class Simple(object):
            pass

        class Subclassed(object):
            pass

        class Subsubclassed(Subclassed):
            pass

        assert Simple is get_platform_subclass(Simple)

        # If the class we are looking for has a subclass, get_platform_subclass will return the subclass
        assert Subclassed is get_platform_subclass(Subsubclassed)

        # If we have multiple sub

# Generated at 2022-06-20 16:20:25.877486
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test main function
    '''
    import distro
    distro = distro.LinuxDistribution()
    distro.lsb_release_attr = lambda x: None  # pylint: disable=unnecessary-lambda
    distro.linux_distribution = lambda: ('', '', '')
    assert get_distribution_version() == ''
    distro.linux_distribution = lambda: ('debian', '1', '2')
    assert get_distribution_version() == '1'
    distro.linux_distribution = lambda: ('coreos', '1', '2')
    assert get_distribution_version() == ''
    distro.lsb_release_attr = lambda x: x  # pylint: disable=unnecessary-lambda

# Generated at 2022-06-20 16:20:29.505457
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    import platform
    if platform.system() == 'Linux':
        assert get_distribution_version() is not None

# Generated at 2022-06-20 16:20:31.396338
# Unit test for function get_distribution_version
def test_get_distribution_version():
    this_platform = platform.system()
    if this_platform == 'Linux':
        version = get_distribution_version()
        assert version, 'Could not determine version of Linux distro'

# Generated at 2022-06-20 16:20:41.629031
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform

    class Base:
        '''
        Minimal base class that returns values for platform and distribution
        '''
        platform = None
        distribution = None

    class Platform(Base):
        platform = platform.system()
        distribution = None

    class PlatformDistribution(Base):
        platform = platform.system()
        distribution = get_distribution()

    class PlatformNotDistribution(Base):
        platform = platform.system()
        distribution = 'Not' + get_distribution()

    class OtherPlatform(Base):
        platform = platform.system() + 'not'
        distribution = get_distribution()

    class OtherPlatformDistribution(Base):
        platform = platform.system() + 'not'
        distribution = 'Not' + get_distribution()

    class OtherPlatformNotDistribution(Base):
        platform = platform.system()

# Generated at 2022-06-20 16:20:53.245973
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import sys
    import imp
    import os
    import sys

    global_namespace = {}
    local_namespace = {}

    # create a temp module
    test_module_name = 'ansible_collections.ansible.test_utils.test_get_platform_subclass.tmp'
    (fp, pathname, description) = imp.find_module(test_module_name)
    test_module = imp.load_module(test_module_name, fp, pathname, description)

    sys.modules[test_module_name] = test_module
    os.environ['ANSIBLE_MODULE_UTILS'] = 'ansible_collections.ansible.test_utils'

# Generated at 2022-06-20 16:21:00.105010
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import six

    @six.add_metaclass(PlatformParameters)
    class BaseClass(object):
        pass

    @six.add_metaclass(PlatformParameters)
    class ClassA(BaseClass):
        platform = 'A'

    @six.add_metaclass(PlatformParameters)
    class ClassA1(ClassA):
        platform = 'A'
        distribution = '1'

    @six.add_metaclass(PlatformParameters)
    class ClassA2(ClassA):
        platform = 'A'
        distribution = '2'

    @six.add_metaclass(PlatformParameters)
    class ClassB(BaseClass):
        platform = 'B'

    assert BaseClass == get_platform_subclass(BaseClass)
    assert ClassA1 == get_platform_subclass(BaseClass)
   

# Generated at 2022-06-20 16:21:10.609653
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for get_distribution_version
    '''
    # Test with a real Ubuntu release
    class FakeModule:
        '''
        A quick class to fake the module object when running tests.
        '''
        def __init__(self, ident, version):
            self.params = {'ident': ident, 'version': version}

    module = FakeModule('ubuntu', '16.04')
    assert get_distribution_version() == '16.04'

    # Now test the function with an LSB version of the distro data
    module.params = {'ident': 'TestOS', 'version': '1.0'}
    assert get_distribution_version() == '1.0'

    # If we don't have a version, it should return an empty string

# Generated at 2022-06-20 16:21:32.313775
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Base:
        pass
    class Base2(Base):
        pass
    class Base3(Base2):
        pass

    class LinuxBase(Base3):
        platform = "Linux"
    class LinuxBase2(LinuxBase):
        pass

    class LinuxUbuntuBase(LinuxBase2):
        distribution = "Ubuntu"
    class LinuxUbuntuBionic(LinuxUbuntuBase):
        pass
    class LinuxUbuntuFocal(LinuxUbuntuBase):
        pass

    class LinuxRedHatBase(LinuxBase2):
        distribution = "Redhat"
    class LinuxRedHat8(LinuxRedHatBase):
        pass

    class WindowsBase(Base3):
        platform = "Windows"

    class WindowsServer2019(WindowsBase):
        pass
    class WindowsServer2019Core(WindowsServer2019):
        pass

    # Gets the most

# Generated at 2022-06-20 16:21:34.280504
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = distro.codename()
    assert get_distribution_codename() == codename

# Generated at 2022-06-20 16:21:46.299390
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # case 1: codename in version_codename
    os_release_info = {'version_codename': 'stretch'}
    assert get_distribution_codename(os_release_info) == 'stretch'

    # case 2: codename in ubuntu_codename
    os_release_info = {'ubuntu_codename': 'xenial'}
    assert get_distribution_codename(os_release_info) == 'xenial'

    # case 3: codename in codename
    os_release_info = {'codename': 'squeeze'}
    assert get_distribution_codename(os_release_info) == 'squeeze'

    # case 4: codename not in os_release_info
    os_release_info = {}
    assert get_distribution_codename

# Generated at 2022-06-20 16:21:47.568580
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == u'8.1'

# Generated at 2022-06-20 16:21:48.804681
# Unit test for function get_distribution
def test_get_distribution():
    pass

# Generated at 2022-06-20 16:21:50.000315
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-20 16:21:52.881654
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distro_codename = get_distribution_codename()
    assert distro_codename is not None, "distribution codename is None"

# Generated at 2022-06-20 16:22:00.750634
# Unit test for function get_distribution
def test_get_distribution():
    # Test some generic platforms
    assert get_distribution() == 'Freebsd'
    assert get_distribution_version() is None
    assert get_distribution_codename() is  None

    # Test RHEL 6, 7 and 8
    assert get_distribution() == 'Redhat'
    assert get_distribution_version() == '6.9'
    assert get_distribution_codename() is  None
    assert get_distribution() == 'Redhat'
    assert get_distribution_version() == '7.7'
    assert get_distribution_codename() is  None
    assert get_distribution() == 'Redhat'
    assert get_distribution_version() == '8.2'
    assert get_distribution_codename() is  None

    # Test CentOS 7 and 8
    assert get_

# Generated at 2022-06-20 16:22:05.129820
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Ensures the version returned is correct for the version of the distro
    '''
    import pytest

    version = get_distribution_version()

    # Ensure we get a string
    assert(isinstance(version, str))

    if platform.system() == 'Linux':
        # dot releases are ignored as they are not guaranteed to be consistent
        distribution = get_distribution()
        codename = get_distribution_codename()

        if codename is not None:
            # Check that the codename is in the version
            assert(codename in version)

        if distribution == 'Amazon':
            # Amazon AMI versions are 4 digits
            assert(len(version) == 4)
        elif distribution == 'Debian':
            # Debian versions are 3 digits
            assert(len(version) == 3)
        # An exception

# Generated at 2022-06-20 16:22:14.059848
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''unit test for function get_platform_subclass'''
    # pylint: disable=missing-docstring,too-few-public-methods,no-init
    class A(object):
        '''Base class'''
        platform = None
        distribution = None

    class B(A):
        '''Platform specific class'''
        platform = 'B'

    class C(A):
        '''Linux specific class'''
        platform = platform.system()

    class D(A):
        '''Distribution specific class'''
        platform = platform.system()
        distribution = get_distribution()

    class E(C):
        '''Platform and Distribution specific class'''
        distribution = get_distribution()

    class F(A):
        '''Empty distribution class'''
        platform = 'F'
       

# Generated at 2022-06-20 16:22:26.947596
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Call the function
    codename = get_distribution_codename()

    # If function call, assert that codename is None
    if codename is None:
        assert platform.system() != 'Linux'

    # If codename is returned, assert it is a string
    if codename is not None:
        assert isinstance(codename, str)

# Generated at 2022-06-20 16:22:28.806217
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None

# Generated at 2022-06-20 16:22:29.787678
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version()

# Generated at 2022-06-20 16:22:40.825443
# Unit test for function get_distribution
def test_get_distribution():

    # Test for all Generic Linux
    assert get_distribution() == 'OtherLinux'
    assert get_distribution_version() == None
    assert get_distribution_codename() == None

    # Test for all Redhat Based Linux Distro
    distro.id = lambda: 'rhel'
    distro.version = lambda: '6.9'
    distro.os_release_info = lambda: {'version_codename': 'Final'}
    assert get_distribution() == 'Redhat'
    assert get_distribution_version() == '6.9'
    assert get_distribution_codename() == 'Final'

    # Test for all Debian Based Linux Distro
    distro.id = lambda: 'debian'
    distro.version = lambda: '8.0'
    distro.os_release_info

# Generated at 2022-06-20 16:22:50.533800
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        platform = None
        distribution = None
    class B(A):
        platform = 'Linux'
    class C(B):
        distribution = 'Centos'
    class D(C):
        """Some distribution-specific centos class"""
        pass
    class E(B):
        distribution = 'Redhat'
    class F(B):
        """Some generic linux class"""
        pass

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == B
    assert get_platform_subclass(C) == C
    assert get_platform_subclass(D) == D
    assert get_platform_subclass(E) == E
    assert get_platform_subclass(F) == F


# Generated at 2022-06-20 16:22:54.912748
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == u'xenial'
    assert get_distribution_codename() is not None
    assert get_distribution_codename() != u''


# Generated at 2022-06-20 16:23:03.592558
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BSD:
        platform = 'BSD'
        distribution = None
    class Linux:
        platform = 'Linux'
        distribution = None
    class OpenBSD:
        platform = 'BSD'
        distribution = 'OpenBSD'
    class RedHat:
        platform = 'Linux'
        distribution = 'RedHat'
    class Fedora:
        platform = 'Linux'
        distribution = 'Fedora'
    class Solaris:
        platform = 'SunOS'
        distribution = None
    class Minix:
        platform = 'Minix'
        distribution = None

    original_system = platform.system
    original_distro = get_distribution
    original_name = get_distribution_version

# Generated at 2022-06-20 16:23:13.613369
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Parent:
        platform = "foo"
        distribution = None

    class ChildA(Parent):
        platform = "bar"

    class ChildB(Parent):
        platform = "bar"
        distribution = "Redhat"

    class GrandChild(ChildB):
        distribution = "Redhat"

    assert get_platform_subclass(Parent) == Parent
    assert get_platform_subclass(ChildA) == ChildA
    assert get_platform_subclass(ChildB) == ChildB
    assert get_platform_subclass(GrandChild) == ChildB
    assert get_platform_subclass(ChildB) == ChildB



# Generated at 2022-06-20 16:23:23.284573
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import unittest

    class TestGetDistributionVersion(unittest.TestCase):
        def test_get_distribution_version(self):
            # Set distro info
            distro.id = lambda: None
            distro.version = lambda: None
            distro.version = lambda best=False: '' if best==False else '1.2.3-4'
            distro.id = lambda: 'centos'
            self.assertEqual(get_distribution_version(), '1.2')
            distro.id = lambda: 'debian'
            self.assertEqual(get_distribution_version(), '1.2.3-4')

    unittest.main()


# Generated at 2022-06-20 16:23:34.505345
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for get_distribution_version

    :returns: True if test succeeded, False if test failed

    It is hard to test ``get_distribution_version()`` because you cannot run code on
    a distribution before that distribution is released.  This code tests the code
    that determines the version from ``/etc/os-release``.  This requires a Linux system that
    has ``/etc/os-release`` properly populated.  This is the case for most modern distributions.
    '''
    if platform.system() == 'Linux':
        # parse /etc/os-release
        os_release_info = distro.os_release_info()

        # Get version from /etc/os-release.  We expect this to work in most cases
        # https://github.com/nir0s/distro/pull/230
       

# Generated at 2022-06-20 16:24:01.506405
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the function get_platform_subclass.  It will run on every platform
    to see whether match return works.
    '''
    import os
    import sys

    from ansible.module_utils.basic import AnsibleModule
    # If running within Ansible, defer to the same module_utils used by Ansible modules
    # We do this because the version of distro installed on the test system may not
    # work on the same version of the host where the test is running.
    if os.getenv('ANSIBLE_TESTING', '0') == '1':
        from ansible.module_utils.basic import get_platform_subclass as get_platform_subclass_real
    else:
        get_platform_subclass_real = get_platform_subclass

    class BaseClass():
        platform = 'Linux'


# Generated at 2022-06-20 16:24:02.694219
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    assert get_distribution_codename() is None

# Generated at 2022-06-20 16:24:07.064200
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() in ['Linux', 'Freebsd', 'Openbsd', 'Netbsd', 'Darwin', 'Sunos', 'Aix', 'Hp-Ux', 'OtherLinux', 'Windows']

# Generated at 2022-06-20 16:24:17.248693
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        platform = 'A'
    class B(A):
        pass
    class C(A):
        distribution = 'C'
    class D(A):
        distribution = 'D'
    class E(A):
        pass
    class F(E):
        distribution = 'F'
    class G(E):
        platform = 'G'
        distribution = 'G'

    class X(A):
        platform = 'X'
        distribution = 'X'
    class X1(X):
        pass  # inherit platform = 'X'
    class X2(X):
        platform = 'X2'  # change platform, inherit distribution = 'X'
    class X3(X):
        distribution = 'X3'  # inherit platform = 'X', change distribution

# Generated at 2022-06-20 16:24:18.720443
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'


# Generated at 2022-06-20 16:24:27.231141
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Ubuntu with codename in /etc/os-release
    os_release_info = {'id': 'ubuntu', 'name': 'Ubuntu', 'pretty_name': 'Ubuntu 18.04.4 LTS', 'version': '18.04.4 LTS (Bionic Beaver)', 'version_id': '18.04', 'version_codename': 'bionic', 'version_codename_info': {'pretty_name': 'Bionic Beaver', 'package_name': 'ubuntu-release-18.04'}}
    distro._os_release_info = os_release_info
    assert get_distribution_codename() == 'bionic'

    # Ubuntu with codename in LSB but not /etc/os-release

# Generated at 2022-06-20 16:24:29.878629
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == "Amazon"

# Generated at 2022-06-20 16:24:39.668689
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass

    This unit test documentation is intentionally sparse.  This function is extensively tested in
    unit tests for modules that use it.
    '''
    class FakeParent(object):
        platform = platform.system()
        distribution = get_distribution()

        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(FakeParent)
            return super(FakeParent, new_cls).__new__(new_cls)

    class FakeSubclass1(FakeParent):
        platform = 'Darwin'

    class FakeSubclass2(FakeParent):
        platform = platform.system()
        distribution = get_distribution()

    class FakeSubclass3(FakeParent):
        platform = 'Darwin'

# Generated at 2022-06-20 16:24:47.248029
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test function get_distribution()
    '''
    assert get_distribution() in (
        'Amazon',
        'Debian',
        'Freebsd',
        'Arch',
        'Fedora',
        'Gentoo',
        'Linuxmint',
        'Oel',
        'Openbsd',
        'Redhat',
        'Suselinux',
        'Ubuntu',
        'Windows',
    ), "Test function get_distribution()"


# Generated at 2022-06-20 16:24:49.436004
# Unit test for function get_distribution
def test_get_distribution():
    (dist, ver) = platform.linux_distribution()

    assert get_distribution() == dist.capitalize()

