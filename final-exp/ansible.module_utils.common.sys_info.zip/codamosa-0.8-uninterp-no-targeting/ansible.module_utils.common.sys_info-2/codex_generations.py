

# Generated at 2022-06-20 16:15:27.166948
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version

    :rtype: NativeString or None
    :returns: A string representation of the version of the distribution. If it
    cannot determine the version, it returns an empty string. If this is not run on
    a Linux machine it returns None.
    '''
    distribution_id = distro.id()

    if distribution_id == 'debian':
        assert get_distribution_version() == '9.9'

    elif distribution_id == 'ubuntu':
        assert get_distribution_version() == '18.04'

    elif distribution_id == 'centos':
        assert get_distribution_version() == '7.5'

    else:
        assert get_distribution_version() == None

# Generated at 2022-06-20 16:15:37.824971
# Unit test for function get_distribution
def test_get_distribution():
    # Build a list of all (distro,version) tuples that should test as the given distro
    distro_dict = {}
    distro_dict['Redhat'] = ['7.5', '7.4', '7.3', '7.2', '7.1', '7.0', '6.10', '6.9', '6.8', '6.7', '6.6', '6.5', '6.4', '6.3', '6.2', '6.1', '6.0', '5.11', '5.10', '5.9', '5.8', '5.7', '5.6', '5.5', '5.4']

# Generated at 2022-06-20 16:15:39.602895
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distribution_version = get_distribution_version()
    assert(distribution_version is not None)

# Generated at 2022-06-20 16:15:50.216877
# Unit test for function get_distribution
def test_get_distribution():
    """
    Test to make sure get_distribution works as we expect
    """
    assert get_distribution() == 'Debian'
    assert get_distribution() == 'Ubuntu'
    assert get_distribution() == 'Redhat'
    assert get_distribution() == 'Fedora'
    assert get_distribution() == 'Amazon'
    assert get_distribution() == 'Otherlinux'
    assert get_distribution() == 'Darwin'
    assert get_distribution() == 'Freebsd'
    assert get_distribution() == 'Openbsd'
    assert get_distribution() == 'Netbsd'
    assert get_distribution() == 'Sunos'

# Generated at 2022-06-20 16:16:02.403596
# Unit test for function get_distribution
def test_get_distribution():
    # In order for this to work, this file has to be imported as main
    # and we have to check the value of __name__
    if __name__ == '__main__':
        # These tests need the OS to be set to a specific value so we'll
        # temporarily patch the platform module
        import platform
        import mock

        @mock.patch.object(platform, 'system', return_value='Linux')
        @mock.patch.object(distro, 'id', return_value=None)
        def test_distribution_empty(mock_id, mock_system):
            result = get_distribution()
            assert result == 'OtherLinux'


# Generated at 2022-06-20 16:16:14.728065
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class dummy_class():
        '''
        Class to use to test this function. It is called dummy_class because it is
        a dummy class and should not be used for anything else.
        '''
        __doc__ = "default_class"
        platform = None
        distribution = None

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class sub_class1(dummy_class):
        '''
        Class to use to test this function. It is called sub_class1 because it is
        a dummy class and should not be used for anything else.
        '''
        __doc__ = "sub_class1"
        platform = 'SomePlatform'
        distribution = None


# Generated at 2022-06-20 16:16:22.333082
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class User:
        platform = 'Linux'
        distribution = 'RedHat'

        def __repr__(self):
            return 'User'

    class UserUbuntu(User):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class UserUbuntuTrusty(UserUbuntu):
        distribution_version = 'trusty'

    class UserFreeBSD(User):
        platform = 'FreeBSD'

    class UserAir(User):
        platform = 'Darwin'
        distribution = 'MacAir'

    assert get_platform_subclass(User) == User
    assert get_platform_subclass(UserUbuntu) == UserUbuntu
    assert get_platform_subclass(UserFreeBSD) == UserFreeBSD
    assert get_platform_subclass(UserAir) == UserAir

    # Ubuntu

# Generated at 2022-06-20 16:16:23.767771
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == platform.dist()[1]

# Generated at 2022-06-20 16:16:32.642850
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function ``get_distribution_version()``
    '''

    DISTROS = {
        u'amzn': u'',
        u'arch': u'',
        u'centos': u'.'.join(distro.version(best=True).split(u'.')[:2]),
        u'debian': distro.version(best=True),
        u'fedora': u'',
        u'opensuse': u'',
        u'rhel': u'.'.join(distro.version(best=True).split(u'.')[:2]),
        u'slackware': u'',
        u'ubuntu': distro.version(best=True),
    }


# Generated at 2022-06-20 16:16:34.043477
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'bionic'

# Generated at 2022-06-20 16:16:49.892716
# Unit test for function get_distribution
def test_get_distribution():
    """
    Verify return value of get_distribution is correct.
    """
    # Redhat Linux
    distro.id = lambda: 'redhat'
    assert 'Redhat' == get_distribution()
    # CentOS Linux
    distro.id = lambda: 'centos'
    assert 'Centos' == get_distribution()
    # Amazon Linux
    distro.id = lambda: 'amzn'
    assert 'Amazon' == get_distribution()
    # Ubuntu Linux
    distro.id = lambda: 'ubuntu'
    assert 'Ubuntu' == get_distribution()
    # Debian Linux
    distro.id = lambda: 'debian'
    assert 'Debian' == get_distribution()
    # SLES 12
    distro.id = lambda: 'sles'
    assert 'Suse' == get

# Generated at 2022-06-20 16:16:56.969838
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import mock
    import platform

    with mock.patch('platform.system', create=True):
        platform.system.return_value = 'Linux'

        with mock.patch('ansible.module_utils.common._utils.distro.os_release_info', create=True):
            distro.os_release_info.return_value = {'VERSION_CODENAME': "bionic"}
            assert get_distribution_codename() == "bionic"

        with mock.patch('ansible.module_utils.common._utils.distro.os_release_info', create=True):
            distro.os_release_info.return_value = {}


# Generated at 2022-06-20 16:16:59.939081
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    # On an Ubuntu machine
    assert get_distribution_codename() == 'bionic'

    # On a Fedora machine
    assert get_distribution_codename() == 'TwentyEight'


# Generated at 2022-06-20 16:17:13.670706
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''Unit test for the function get_distribution_codename'''

    distro_id = distro.id()
    distro_codename = distro.codename().lower()
    ubuntu_codename = None
    version_codename = None

    # When distribution is not Ubuntu, the value of ubuntu_codename is None
    if distro_id != 'Ubuntu':
        ubuntu_codename = None
    elif distro_id == 'Ubuntu':
        # When distribution is Ubuntu, the value of ubuntu_codename is the same as distro_codename
        ubuntu_codename = distro_codename

    # The values of version_codename and distro_codename are None for distros not supported by distro
    # library

# Generated at 2022-06-20 16:17:25.730657
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class class_1():
        platform = None
        distribution = None

    class class_2():
        platform = None
        distribution = 'Linux'

    class class_3():
        platform = None
        distribution = 'CentOS'

    class class_4():
        platform = 'Linux'
        distribution = None

    class class_5():
        platform = 'Linux'
        distribution = 'CentOS'

    class class_6():
        platform = 'Linux'
        distribution = 'Redhat'

    class class_7():
        platform = 'Linux'
        distribution = 'ubuntu'

    class_1_subclass = get_platform_subclass(class_1)
    class_2_subclass = get_platform_subclass(class_2)
    class_3_subclass = get_platform_subclass(class_3)

# Generated at 2022-06-20 16:17:35.756858
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Check if function get_distribution_codename returns values that meet expectation
    '''

# Generated at 2022-06-20 16:17:44.028633
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Check if get_distribution_codename() returns codename of the distribution or None
    '''
    # save the original distro information in case we're mocking it
    orig_distro_id, orig_distro_version, orig_distro_version_best, orig_distro_codename = (distro.id(), distro.version(), distro.version(best=True), distro.codename())

    # Ubuntu
    distro.id = lambda: 'ubuntu'
    distro.version = lambda: '6.06'
    distro.codename = lambda: 'dapper'
    assert get_distribution_codename() == 'dapper'

    # Fedora
    distro.id = lambda: 'fedora'
    distro.version = lambda: '17'

# Generated at 2022-06-20 16:17:54.390583
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # The purpose of the test is to check that the get_platform_subclass function actually gets the
    # desired platform. For example the first test case should return LinuxUser as subclass.

    class TargetClass(object):
        platform = None
        distribution = None

    class LinuxUser(TargetClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class LinuxRedhatUser(LinuxUser):
        distribution = 'Redhat'

    class LinuxRedhat7User(LinuxRedhatUser):
        version = '7'

    class DarwinUser(TargetClass):
        platform = 'Darwin'

    class LinuxOtherLinuxUser(LinuxUser):
        distribution = 'OtherLinux'

    class LinuxOtherLinux7User(LinuxOtherLinuxUser):
        version = '7'


# Generated at 2022-06-20 16:18:03.602818
# Unit test for function get_platform_subclass

# Generated at 2022-06-20 16:18:16.410078
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for get_distribution_codename(self)
    '''
    # Test Ubuntu codenames
    # Test all known Ubuntu releases up to Disco.
    # https://en.wikipedia.org/wiki/List_of_Ubuntu_releases
    test_codenames = {
        'vivid': 'Vivid Vervet',
        'wily': 'Wily Werewolf',
        'xenial': 'Xenial Xerus',
        'yakkety': 'Yakkety Yak',
        'zesty': 'Zesty Zapus',
        'artful': 'Artful Aardvark',
        'bionic': 'Bionic Beaver',
        'cosmic': 'Cosmic Cuttlefish',
        'disco': 'Disco Dingo',
    }


# Generated at 2022-06-20 16:18:29.285858
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class superclass(object):
        platform = "Linux"
        distribution = None

    class superclass_two(superclass):
        platform = "Linux"
        distribution = None

    class superclass_three(superclass_two):
        pass

    class RedHat(superclass_three):
        platform = "Linux"
        distribution = "Redhat"

    class RedHat_five(RedHat):
        distribution = "Redhat"
        platform = "Linux"
        pass

    class RedHat_six(RedHat):
        distribution = "Redhat"
        platform = "Linux"
        pass

    class TumbleWeed(superclass):
        platform = "Linux"
        distribution = "TumbleWeed"

    class TumbleWeed_five(TumbleWeed):
        platform = "Linux"

# Generated at 2022-06-20 16:18:30.556397
# Unit test for function get_distribution_version
def test_get_distribution_version():
    print('get_distribution_version(): %s' % get_distribution_version())
    assert get_distribution_version() is not None


# Generated at 2022-06-20 16:18:31.548541
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Amazon'

# Generated at 2022-06-20 16:18:40.445705
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    old_distro_id = distro.id
    old_distro_codename = distro.codename

    try:
        # Test distro.id() == 'ubuntu'
        distro.id = lambda: 'ubuntu'
        distro.codename = lambda: 'xenial'
        assert get_distribution_codename() == 'xenial'

        # Test distro.id() == 'debian'
        distro.id = lambda: 'debian'
        distro.codename = lambda: 'stretch'
        assert get_distribution_codename() == 'stretch'

        # Test distro.id() == 'amzn'
        distro.id = lambda: 'amzn'
        assert get_distribution_codename() is None

    finally:
        distro.id = old_distro_

# Generated at 2022-06-20 16:18:51.589562
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distro_id = distro.id()
    distro_version = distro.version()
    best_version = distro.version(best=True)

    # Test for the distributions with None version
    if distro.id() in frozenset((u'alpine', u'clear', u'funtoo', u'mandrake', u'gentoo', u'mageia', u'openmandriva', u'redhat-based', u'slackware', u'slr', u'void', u'zenwalk')):
        assert get_distribution_version() == u''

    # Test for the distinguished versions of Amazon, CentOS, Debian, and Ubuntu
    # https://github.com/ansible/ansible/issues/50141#issuecomment-445083195
    if distro.id() == u'amzn':
        assert get

# Generated at 2022-06-20 16:18:52.504776
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-20 16:19:01.971925
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    The correct class should be returned based on the platform and distro this is running on
    '''
    import sys

    # Test class hierarchy
    #
    #                      Base
    #                       |
    #         +-------------+----------+
    #         |             |          |
    #     RedhatLinux   OtherLinux    MacOSX
    #         |
    #         |
    #       CentOS

    class Base:
        platform = 'Generic'
        distribution = None

    class RedhatLinux:
        platform = 'Linux'
        distribution = 'Redhat'

    class OtherLinux:
        platform = 'Linux'
        distribution = 'OtherLinux'

    class MacOSX:
        platform = 'Darwin'
        distribution = None

    class CentOS(RedhatLinux):
        distribution = 'CentOS'


# Generated at 2022-06-20 16:19:07.758749
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    expected = 'xenial'
    result = get_distribution_codename()
    assert result == expected

"""
- name: Get the distribution information
  set_fact:
    distribution: "{{ ansible_distribution|default(get_distribution()) }}"
    distribution_version: "{{ ansible_distribution_version|default(get_distribution_version()) }}"
    distribution_codename: "{{ ansible_distribution_codename|default(get_distribution_codename()) }}"
"""

# Generated at 2022-06-20 16:19:18.976103
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for get_platform_subclass()
    '''
    class Base(object):
        pass

    class Platform(Base):
        platform = 'Linux'

    class Distribution(Platform):
        distribution = 'Redhat'

    class Specific(Distribution):
        pass

    # Basic Linux
    assert Platform == get_platform_subclass(Base)

    # Something specific to a distribution
    assert Base != get_platform_subclass(Platform)
    assert Platform != get_platform_subclass(Platform)

    # Make sure it returns the most specific subclass
    assert Base != get_platform_subclass(Distribution)
    assert Platform != get_platform_subclass(Distribution)
    assert Distribution == get_platform_subclass(Distribution)

    # Make sure it returns the most specific subclass
    assert Base != get_platform

# Generated at 2022-06-20 16:19:21.119823
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    return (
        get_distribution_codename(),
        get_distribution()
    )

# Generated at 2022-06-20 16:19:32.745247
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-20 16:19:39.024610
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distribution_versions = {
        'centos': '7.6.1810',
        'coreos': '1688.4.1',
        'debian': '9.6',
        'fedora': '29',
        'opensuse': '42.3',
        'redhat': '6.7',
        'ubuntu': '14.04',
        'freebsd': '11.0-STABLE',
        'openbsd': '6.3',
        'arch': '',
    }
    output = get_distribution_version()
    assert output == distribution_versions[get_distribution().lower()]

# Generated at 2022-06-20 16:19:40.357205
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    code_name = get_distribution_codename()
    assert isinstance(code_name, str) or code_name is None


# Generated at 2022-06-20 16:19:41.317319
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == "7.0"


# Generated at 2022-06-20 16:19:52.982448
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # No codename
    assert get_distribution_codename() is None

    # Fedora 28 lacks code name
    os_release_info = distro.os_release_info()
    os_release_info['version_codename'] = None
    os_release_info['ubuntu_codename'] = None
    assert get_distribution_codename() is None

    # Ubuntu Xenial Xerus does not use version_codename
    os_release_info['version_codename'] = None
    os_release_info['ubuntu_codename'] = u'xenial'
    assert get_distribution_codename() == u'xenial'

    os_release_info.clear()

    # CentOS uses version_codename
    os_release_info['name'] = 'CentOS Linux'

# Generated at 2022-06-20 16:20:04.431135
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo:
        platform = 'Linux'
        distribution = None

    class Bar(Foo):
        distribution = 'OtherLinux'

    class Baz(Foo):
        distribution = 'OtherOtherLinux'

    class NotThisOne(Bar):
        distribution = 'OtherOtherLinux'

    class NotOther(Bar):
        platform = 'Other'

    class Other(Bar):
        distribution = None

    # We're not on linux
    if platform.system() != 'Linux':
        assert get_platform_subclass(Foo) is Foo
        assert get_platform_subclass(Bar) is Foo
        assert get_platform_subclass(Baz) is Foo

    # We're on Linux but we're a distro that's not supported by any subclasses
    elif get_distribution() == 'OtherLinux':
        assert get_platform_

# Generated at 2022-06-20 16:20:05.523133
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Darwin'

# Generated at 2022-06-20 16:20:17.025724
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    centos_id = 'centos'
    centos_version = '6.10'
    centos_codename = ''

    ubuntu_id = 'ubuntu'
    ubuntu_version = '18.10'
    ubuntu_codename = 'cosmic'
    ubuntu_18_04 = '18.04'
    ubuntu_bionic = 'bionic'
    ubuntu_16_04 = '16.04'
    ubuntu_xenial = 'xenial'

    debian_id = 'debian'
    debian_version = '9.7'
    debian_codename = 'stretch'

    fedora_id = 'fedora'
    fedora_version = '28'
    fedora_codename = ''

    # CentOS codename should be empty

# Generated at 2022-06-20 16:20:26.143595
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils import basic

    # Test None
    basic.get_distribution_codename = lambda: None  # pylint: disable=unnecessary-lambda
    assert basic.get_distribution_codename() is None

    # Test empty string
    basic.get_distribution_codename = lambda: u''  # pylint: disable=unnecessary-lambda
    assert basic.get_distribution_codename() is None

    # Test valid name
    basic.get_distribution_codename = lambda: u'cosmic'  # pylint: disable=unnecessary-lambda
    assert basic.get_distribution_codename() == u'cosmic'

# Generated at 2022-06-20 16:20:30.155976
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Valid codename returns codename
    assert get_distribution_codename() == distro.codename(), "Test should return {}".format(distro.codename())

    # Invalid codename returns None
    assert get_distribution_codename() is None, "Test should return None"

# Generated at 2022-06-20 16:20:59.510240
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass

    :rtype: None
    :returns: Nothing. Asserts errors if there are problems with the
        function.
    '''

    # All this must be done in one module so the figures are readily
    # available
    import unittest

    class BaseClass(object):
        platform = None
        distribution = None

        def __init__(self, *args, **kwargs):
            # Common init code would go here.  This is just to
            # prove it's called
            self.args = args
            self.kwargs = kwargs

    class GenericDistroClass(BaseClass):
        distribution = 'Generic'

    class GenericPlatformClass(BaseClass):
        platform = 'Generic'


# Generated at 2022-06-20 16:21:06.182263
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # Create a class structure to test against
    #
    # class A
    #     class B
    #         class D
    #             does not match
    #         class C
    #             does not match
    #         class E
    #             distribution=None, platform="Linux"
    #             does not match
    #         class F
    #             distribution="Linux", platform="Linux"
    #             matches

    class A:
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(B):
        pass

    class E(B):
        distribution = None
        platform = "Linux"

    class F(B):
        distribution = "Linux"
        platform = "Linux"

    # Test a leaf class matching
    assert get_platform_subclass(D) == D

   

# Generated at 2022-06-20 16:21:16.214823
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distros = {
        None: None,
        'amzn': '1',
        'debian': '9.4',
        'fedora': '28',
        'oracle': '7.4',
        'redhat': '7.5',
        'ubuntu': '16.04',
    }

    for distro_id, version in distros.items():
        def mock_distro_id(release_id=None):
            if release_id:
                # Python 3.2 and 3.3 have a bug where they pass in the release_id argument
                #   https://github.com/ansible/ansible/pull/44047
                return distro_id
            return distro_id, None


# Generated at 2022-06-20 16:21:22.263217
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename = get_distribution_codename()
    if distribution_codename is None:
        assert get_distribution() is None, "`get_distribution()` is not a Linux distribution"
    else:
        assert get_distribution() is not None, "`get_distribution()` is a Linux distribution"

# Generated at 2022-06-20 16:21:32.735035
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test if the function get_distribution_version returns the best version for debian, centos and sles.
    '''

    def _set_distro_info(distro, id, version):
        return {
            'distro': distro,
            'id': id,
            'version': version,
            'version_best': version + '.' + version
        }

    mock_distro = distro.LinuxDistribution()
    mock_distro.info = [
        _set_distro_info(distro.debian, 'debian', '7.0'),
        _set_distro_info(distro.centos, 'centos', '7'),
        _set_distro_info(distro.sles, 'sles', '11'),
    ]

# Generated at 2022-06-20 16:21:34.396907
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-20 16:21:46.314518
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Be sure to test the most common distro codenames
    class TestCodename:
        def __init__(self):
            self.codename = None
            self.ubuntu_codename = None

    test_codename = TestCodename()

    distro.codename = lambda: 'stretch'
    assert (get_distribution_codename() == 'stretch')

    distro.codename = lambda: 'generic'
    distro.id = lambda: 'unknown'
    assert (get_distribution_codename() is None)

    distro.codename = lambda: ''
    distro.id = lambda: 'ubuntu'
    distro.lsb_release_info = lambda: {'codename': 'xenial'}
    assert (get_distribution_codename() == 'xenial')

    dist

# Generated at 2022-06-20 16:21:51.747634
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the function get_platform_subclass
    '''
    class Base:
        pass

    class Implementation(Base):
        pass

    class OtherImplementation(Base):
        distribution = 'testcase'
        platform = 'test_platform'

    assert get_platform_subclass(Base) == Base
    assert get_platform_subclass(Implementation) == Implementation
    assert get_platform_subclass(OtherImplementation) == Base

# Generated at 2022-06-20 16:21:54.220722
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test get_distribution_codename function
    '''
    assert get_distribution_codename() == 'bionic'

# Generated at 2022-06-20 16:22:05.205667
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible_test
    import ansible.modules.system.user

    # Test 1: platform == 'Linux', distribution=='RedHat', subclass.platform=None, subclass.distribution='RedHat'
    this_platform = 'Linux'
    distribution = 'RedHat'
    distribution_version = '7.2'

    class this_class():
        def __init__(self):
            self.platform = None
            self.distribution = 'RedHat'
    this_class = this_class()
    this_class.platform = None
    this_class.distribution = 'RedHat'
    assert get_platform_subclass(this_class) == ansible.modules.system.user.User

    # Test 2: platform=='Linux', distribution=='RedHat', subclass.platform='Linux', subclass.distribution='RedHat'


# Generated at 2022-06-20 16:22:48.456874
# Unit test for function get_distribution
def test_get_distribution():
    print(get_distribution())

# Generated at 2022-06-20 16:22:56.787859
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    codename = get_distribution_codename()
    if codename is not None:
        assert type(codename) == unicode, "Expected unicode but found type: %s" % (type(codename))
    else:
        assert platform.system() != 'Linux', "Expected codename on Linux but function returned None"

# Generated at 2022-06-20 16:23:04.992359
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest

    class Base(object):
        platform = "Generic"
        distribution = None

    class DebianSub(Base):
        platform = "Linux"
        distribution = "Debian"

    class RedhatSub(Base):
        platform = "Linux"
        distribution = "Redhat"

    class OtherLinuxSub(Base):
        platform = "Linux"
        distribution = None

    class OtherPlatformSub(Base):
        platform = "OtherPlatform"
        distribution = None

    class TestGetPlatformSubclass(unittest.TestCase):
        '''
        make sure the right class gets picked up
        '''

        def test_default(self):
            desired = Base
            obtained = get_platform_subclass(Base)
            self.assertEqual(desired, obtained)


# Generated at 2022-06-20 16:23:07.620732
# Unit test for function get_distribution
def test_get_distribution():
    # NOTE: This cannot really be tested outside of a specific Linux
    # distribution. So we just check that the function returns something
    assert get_distribution()



# Generated at 2022-06-20 16:23:17.834547
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Returns a class that is the result of finding a subclass using get_platform_subclass
    '''
    import sys
    # Need to use the class defined in this test
    from ansible.module_utils.basic import test_get_platform_subclass as cls

    subclass = get_platform_subclass(cls)
    # Make sure the class name is correct.  We have to try because depending on the distribution
    # we're running on we may or may not be able to import RedHatUser.  And if there's an error
    # python may leave the class set to RedHatUser anyways.  (That's what happens when you use
    # importlib.import_module() instead of the imp module.)

# Generated at 2022-06-20 16:23:30.665386
# Unit test for function get_distribution
def test_get_distribution():

    # CentOS 6.x
    with open('/etc/redhat-release') as f:
        redhat_releases = f.readlines()
        redhat_releases[0] = 'CentOS release 6.3 (Final)\n'
        redhat_releases[0] = 'CentOS release 6.5 (Final)\n'

    # CentOS 7.x
    with open('/etc/centos-release') as f:
        centos_releases = f.readlines()
        centos_releases[0] = 'CentOS Linux release 7.0.1406 (Core)\n'
        centos_releases[0] = 'CentOS Linux release 7.2.1511 (Core)\n'

    # Debian 6.x

# Generated at 2022-06-20 16:23:36.397060
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    class FakeDistro:
        def __new__(cls, *args):
            return FakeDistro

        @staticmethod
        def id(*args):
            return 'Linux'

        @staticmethod
        def codename(*args):
            return 'foo'

    old_distro = distro.linux_distribution
    distro.linux_distribution = FakeDistro
    try:
        assert get_distribution_codename() == 'foo'
    finally:
        distro.linux_distribution = old_distro

# Generated at 2022-06-20 16:23:48.468427
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import ansible.module_utils.common._utils as utils

    # test centos
    centos = utils.DistroSupport()
    centos.lsb_release_info = {}
    centos.os_release_info = {"version": '6.8', "version_id": '6.8', "id": 'centos',
                              "version_codename": 'Final'}
    centos.id = lambda: 'centos'
    centos.version = lambda: '6.8'
    centos.version_best = lambda: '6.8'

    utils.distro = centos
    assert get_distribution_version() == '6.8'

    # test debian
    debian = utils.DistroSupport()
    debian.lsb_release_info = {}
    debian.os_release

# Generated at 2022-06-20 16:24:00.604568
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from . import LinuxDistribution
    from . import SunOSDistribution
    from . import SunOSPlatform
    from . import LinuxPlatform
    from . import OtherLinuxPlatform

    class FakeModule:
        def __init__(self, platform=None, distribution=None):
            self.params = dict(
                platform=platform,
                distribution=distribution
            )

    #
    # Test Linux distros on Linux platform
    #
    # This test case is an unsupported platform/distro combination
    m = FakeModule(platform='Linux', distribution='OtherLinux')
    os_distro = get_platform_subclass(LinuxDistribution)
    assert os_distro(m) is None

    # Debian
    m = FakeModule(platform='Linux', distribution='Debian')
    os_distro = get_platform_subclass(LinuxDistribution)

# Generated at 2022-06-20 16:24:11.698651
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    # Test for Ubuntu Xenial Xerus
    os_release_info = {'version_codename': 'xenial'}
    distro._os_release_info = lambda: os_release_info
    codename = get_distribution_codename()
    assert codename == 'xenial'

    # Test for Ubuntu Bionic Beaver
    os_release_info = {'version_codename': 'bionic'}
    distro._os_release_info = lambda: os_release_info
    codename = get_distribution_codename()
    assert codename == 'bionic'

    # Test for Debian 10 'buster'
    os_release_info = {'version_codename': 'buster'}
    distro._os_release_info = lambda: os_release_info
    codename = get_distribution_

# Generated at 2022-06-20 16:25:02.946945
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Tests for the ``get_distribution`` function.
    '''

# Generated at 2022-06-20 16:25:15.357604
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Main:
        platform = None
        distribution = None

    class OtherPlatform(Main):
        platform = 'OtherPlatform'
        distribution = None

    class LinuxOS(Main):
        platform = 'Linux'
        distribution = 'LinuxOS'

    class Linux(Main):
        platform = 'Linux'
        distribution = None

    class Redhat(Linux):
        platform = 'Linux'
        distribution = 'Redhat'

    assert get_platform_subclass(Main) is Main
    assert get_platform_subclass(OtherPlatform) is OtherPlatform
    assert get_platform_subclass(LinuxOS) is LinuxOS
    assert get_platform_subclass(Redhat) is Redhat

    platform.system = lambda: 'OtherPlatform'
    assert get_platform_subclass(Main) is Main