

# Generated at 2022-06-20 16:15:27.481852
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class Platform_A(BaseClass):
        platform = 'A'

    class Platform_AB(BaseClass):
        platform = 'A'
        distribution = 'B'

    class Platform_AC(BaseClass):
        platform = 'A'
        distribution = 'C'

    class Platform_Ax(BaseClass):
        platform = 'A'
        distribution = None

    class Platform_BC(Platform_AB):
        distribution = 'C'

    class Platform_C(BaseClass):
        platform = 'C'

    class Platform_B(BaseClass):
        platform = 'B'


# Generated at 2022-06-20 16:15:38.191802
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # The test class hierarchy is this:
    # PlatformA -> Debian -> DebianStretch
    #           -> Ubuntu  -> UbuntuBionic

    class PlatformA:
        platform = 'Linux'
        distribution = None

    class Debian(PlatformA):
        distribution = 'Debian'

    class Ubuntu(PlatformA):
        distribution = 'Ubuntu'

    class DebianStretch(Debian):
        distribution = 'Debian'
        version = '9.0'

    class UbuntuBionic(Ubuntu):
        distribution = 'Ubuntu'
        version = '18.04'

    platform = 'Linux'

    cls = get_platform_subclass(PlatformA)
    assert cls == PlatformA

    def reset_platform():
        Debian.distribution = 'Debian'
        Ubuntu.distribution = 'Ubuntu'

    # Get the platform class

# Generated at 2022-06-20 16:15:50.347044
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the function against a variety of distros/versions
    '''
    assert get_distribution_version() is not None  # We can handle None.  Just don't crash.
    assert get_distribution_version() == ''       # Unknown distro should be empty string
    assert get_distribution_version('') == ''
    assert get_distribution_version(None) == ''
    assert get_distribution_version('bogus') == ''
    assert get_distribution_version(7) == ''

    assert get_distribution_version('centos') == '7.4'
    assert get_distribution_version('centos', '7.4.1708') == '7.4'
    assert get_distribution_version('centos', '7.5.1804') == '7.5'


# Generated at 2022-06-20 16:16:02.529006
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    def check_codename(expected, os_release):
        distro.open_mock.return_value.read.return_value = os_release
        codename = get_distribution_codename()
        distro.open_mock.assert_called_once_with('/etc/os-release')
        assert expected == codename

    def check_codename_open_fail(expected, open_fail_errno=2, open_fail_strerror=None):
        distro.open_mock.side_effect = IOError(open_fail_errno, open_fail_strerror)
        codename = get_distribution_codename()
        distro.open_mock.assert_called_once_with('/etc/os-release')
        assert expected == codename


# Generated at 2022-06-20 16:16:14.875591
# Unit test for function get_distribution
def test_get_distribution():
    import sys
    # Force the distro.id() to return None which causes the function to
    # return a default value
    saved_id = distro.id
    distro.id = lambda: None

# Generated at 2022-06-20 16:16:22.404025
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class the_class(object):
        platform = "Solaris"
        distribution = "SunOS"
        def __init__(self, *args, **kwargs):
            pass

    class a_class(the_class):
        platform = "Solaris"
        distribution = "SunOS"

    class b_class(the_class):
        platform = "Solaris"
        distribution = None

    class c_class(the_class):
        platform = None
        distribution = "SunOS"

    assert get_platform_subclass(the_class) == the_class
    assert get_platform_subclass(a_class) == a_class
    assert get_platform_subclass(b_class) == b_class
    assert get_platform_subclass(c_class) == the_class

    # Restore platform and distribution since we

# Generated at 2022-06-20 16:16:31.682628
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test for function get_platform_subclass
    '''

    class A:
        platform = None
        distribution = None

    class AH(A):
        platform = 'HPUX'
        distribution = None

    class AL(A):
        platform = 'Linux'
        distribution = None

    class AC(AL):
        distribution = 'CentOS'

    class AO(AL):
        distribution = 'OtherLinux'

    class AHPUX(AH):
        pass

    class ACC(AC):
        pass

    class AOC(AO):
        pass

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(AL) == AL
    assert get_platform_subclass(AH) == AH
    assert get_platform_subclass(AC) == AC
    assert get_

# Generated at 2022-06-20 16:16:32.610782
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() != None

# Generated at 2022-06-20 16:16:44.536709
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the results of get_distribution

    This is a simple test to ensure that get_distribution is returning expected
    results on different platforms.
    '''
    test_data = (
        (u'FreeBSD', u'FreeBSD'),
        (u'Linux', u'Amazon'),
        (u'Linux', u'Centos'),
        (u'Linux', u'Darwin'),
        (u'Linux', u'Debian'),
        (u'Linux', u'Fedora'),
        (u'Linux', u'RedHat'),
        (u'Linux', u'Ubuntu'),
        (u'Linux', u'UnknownLinux'),
        (u'OpenBSD', u'OpenBSD'),
        (u'SunOS', u'SunOS'),
        (u'Windows', u'Windows'),
    )


# Generated at 2022-06-20 16:16:55.664260
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distro_list = { '' : None,
                    'Alpine' : None,
                    'CentOS' : None,
                    'Fedora' : None,
                    'Debian' : 'buster',
                    'openSUSE' : None,
                    'Oracle Linux' : None,
                    'RedHat' : None,
                    'Ubuntu' : 'xenial',
                    'Arch' : None,
                    'FreeBSD' : None
                    }

    for d in distro_list:
        assert distro_list[d] == get_distribution_codename(d), "Distro {} not matching expected value {}".format(d, distro_list[d])

# Generated at 2022-06-20 16:17:13.745173
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Get a subclass of this ambiguous class
    class Ambiguous(object):
        platform = 'Linux'
    assert get_platform_subclass(Ambiguous).name == 'Ambiguous'

    # Get a specific subclass
    class Debian(Ambiguous):
        distribution = 'Debian'
    class Redhat(Ambiguous):
        distribution = 'Redhat'
    assert get_platform_subclass(Ambiguous).name == 'Ambiguous'
    assert get_platform_subclass(Ambiguous, {'ansible_os_family': 'Redhat'}).name == 'Redhat'
    assert get_platform_subclass(Ambiguous, {'ansible_os_family': 'Debian'}).name == 'Debian'

# Generated at 2022-06-20 16:17:26.146412
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''

    class CommonModule:
        platform = None
        distribution = None
        distribution_version = None

    class BsdModule(CommonModule):
        platform = 'FreeBSD'

    class LinuxModule(CommonModule):
        platform = 'Linux'

    class LinuxRedHatModule(LinuxModule):
        distribution = 'Redhat'

    class LinuxRedHat7Module(LinuxRedHatModule):
        distribution_version = '7'

    class LinuxRedHat6Module(LinuxRedHatModule):
        distribution_version = '6'

    class LinuxSuseModule(LinuxModule):
        distribution = 'Suse'

    class LinuxSuse12Module(LinuxSuseModule):
        distribution_version = '12'


# Generated at 2022-06-20 16:17:35.837431
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename
    '''
    codename = get_distribution_codename()
    assert codename != None
    if platform.system() == 'Linux':
        if distro.id() == u'ubuntu':
            assert codename in [u'xenial', u'bionic', u'saucy', u'trusty', u'vivid', u'utopic', u'artful', u'jessie', u'wheezy', u'lucid', u'yakkety', u'zesty']
        elif distro.id() == u'fedora':
            assert codename == u''

# Generated at 2022-06-20 16:17:47.314188
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    class distro_mockup():
        def id(self):
            return 'Ubuntu'
        def codename(self):
            return 'artful'
        def version(self, best=False):
            return '17.10'
        def os_release_info(self):
            return {'version_codename': 'artful', 'ubuntu_codename': 'artful'}
        def lsb_release_info(self):
            return {'codename': 'artful'}
    distro_original = distro.linux_distribution
    distro.linux_distribution = distro_mockup

    distribution_codename = get_distribution_codename()
    assert distribution_codename == 'artful'

    distro.linux_distribution = distro_original


# Generated at 2022-06-20 16:18:00.062443
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    def _set_lsb_release_info(codename):
        distro._lsb_release_info = {'codename': codename}

    def _reset_lsb_release_info():
        del distro._lsb_release_info

    def _set_os_release_info(codename):
        distro._os_release_info = {'version_codename': codename}
        distro._os_release_name = 'CoreOS'

    def _set_os_release_info_ubuntu(codename):
        distro._os_release_info = {
            'version_codename': codename,
            'ubuntu_codename': codename
        }

    def _reset_os_release_info():
        distro._os_release_info = {}


# Generated at 2022-06-20 16:18:02.391590
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test function get_distribution from ansible.module_utils.common._utils
    '''
    assert get_distribution() == 'Amazon'



# Generated at 2022-06-20 16:18:14.704230
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import mock

    mocks = {}

    # Case 1:  Ubuntu
    mocks['distro.id'] = mock.Mock(return_value='Ubuntu')
    mocks['distro.version'] = mock.Mock(return_value=None)
    mocks['distro.version.best'] = mock.Mock(return_value='18.04')
    mocks['distro.os_release_info'] = mock.Mock(return_value={'version_codename': 'bionic'})
    mocks['distro.lsb_release_info'] = mock.Mock(return_value={'codename': 'bionic'})
    mocks['platform.system'] = mock.Mock(return_value='Linux')


# Generated at 2022-06-20 16:18:23.659222
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Tests get_platform_subclass() function
    '''
    class Base:
        platform = 'Base'

    class LinuxBase(Base):
        platform = 'Linux'
        distribution = None

    class LinuxA(LinuxBase):
        distribution = 'LinuxA'
        codename = None

    class LinuxB(LinuxBase):
        distribution = 'LinuxB'
        codename = None

    class LinuxC(LinuxBase):
        distribution = 'LinuxC'
        codename = None
        codename = 'SpecificC'

    class LinuxD(LinuxBase):
        distribution = 'LinuxD'
        codename = 'SpecificD'

    class LinuxE(LinuxBase):
        distribution = 'LinuxD'
        codename = 'SpecificE'

    class BSD:
        platform = 'BSD'


# Generated at 2022-06-20 16:18:29.752074
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the return value of get_distribution().
    '''
    import ansible.module_utils.basic

    module_utils_basic_get_distribution = getattr(ansible.module_utils.basic, '_get_distribution')
    module_utils_basic_get_distribution.func_globals['distro'] = FakeDistroModule()

    distributions = (
        'Fedora',
        'Centos',
        'Redhat',
        'Ubuntu',
        'Debian',
        'Suse',
        'Amazon',
        'OtherLinux',
    )

    old_distribution = module_utils_basic_get_distribution()
    for distribution in distributions:
        FakeDistroModule.distribution = distribution
        this_distribution = module_utils_basic_get_distribution()

# Generated at 2022-06-20 16:18:39.320278
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    class SuperClass(AnsibleModule):
        """Superclass for this set of tests"""
        platform = 'Linux'
        distribution = None

    class OtherLinux(SuperClass):
        """Subclass for a Linux with a distribution we don't care about"""
        distribution = 'OtherLinux'

    class TestCentOS(SuperClass):
        """Subclass for CentOS"""
        distribution = 'CentOS'

    class TestRhel(TestCentOS):
        """Subclass for RedHat Enterprise Linux"""
        distribution = 'Redhat'

    class TestAmzn(SuperClass):
        """Subclass for Amazon"""
        platform = 'Linux'
        distribution = 'Amazon'

    class TestDebian(SuperClass):
        """Subclass for Debian"""

# Generated at 2022-06-20 16:18:48.038569
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit testing function get_distribution()
    '''
    # Unit test to ensure that non-linux platforms do not error out
    assert get_distribution() is None



# Generated at 2022-06-20 16:18:55.705797
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the function get_platform_subclass()
    '''
    import ansible.module_utils.basic

    class Test_A(ansible.module_utils.basic.AnsibleModule):
        platform = 'Linux'
        distribution = 'Redhat'

    class Test_B(ansible.module_utils.basic.AnsibleModule):
        platform = 'Linux'

    assert Test_A == get_platform_subclass(Test_A)
    assert Test_B == get_platform_subclass(Test_B)

    class Test_C(Test_A):
        distribution = 'Amazon'

    assert Test_C == get_platform_subclass(Test_A)

# Generated at 2022-06-20 16:19:03.390304
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    create an instance of class distro and test get_distribution_version function
    '''
    distro_instance = distro()
    distribution = distro_instance.id().capitalize()
    dist_version = distro_instance.version()
    dist_major,dist_minor,dist_custom = distro_instance.split_version()
    dist_major_minor = dist_major + '.' + dist_minor
    assert distribution == 'Rhel'
    assert dist_version == '9'
    assert get_distribution_version() == '7.6'
    assert dist_major_minor == '7.6'

# Generated at 2022-06-20 16:19:11.014311
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Make sure we can get distribution name in different platforms
    '''
    import types
    import tempfile
    import shutil
    import os

    # CentOS

# Generated at 2022-06-20 16:19:22.219364
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Create a base class as a simple replacement of object
    class object:
        pass
    # Create a base class we will replace
    class base(object):
        platform = 'foo'
        distribution = 'bar'
    # Create a subclass for this platform
    class linux(base):
        platform = 'Linux'
    # Create a subclass for a different platform
    class windows(base):
        platform = 'Windows'
    # Create a subclass for this platform that is more specific than the previous
    class redhat(linux):
        distribution = 'Redhat'
    # Force the distribution to be set to redhat
    class test_get_platform_subclass:
        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(base)

# Generated at 2022-06-20 16:19:31.050115
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    class TestClass():
        this_os = ""
        this_distribution = None

        def __init__(self):
            self.this_os = platform.system()
            self.this_distribution = get_distribution()

        def __repr__(self):
            return "%s(%s, %s)" % (self.__class__.__name__, self.this_os, self.this_distribution)

    class TestClassLinux(TestClass):
        platform = "Linux"

    class TestClassLinuxSuse(TestClassLinux):
        distribution = "Suse"

    class TestClassLinuxRedhat(TestClassLinux):
        distribution = "Redhat"

    class TestClassLinuxGeneric(TestClassLinux):
        distribution = None


# Generated at 2022-06-20 16:19:32.186375
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-20 16:19:39.915007
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible_collections.ansible.community.plugins.module_utils._text import to_native
    from ansible.module_utils.six import PY3, binary_type

    distro_id = platform.dist()[0]

    # distro_id is used for setting distro.id() for tests
    if PY3 and isinstance(distro_id, str):
        # This is a Python 3 instance and distro_id is unicode
        # To get the byte string to behave like it would in Python 2
        # we need to encode it.
        distro_id = distro_id.encode('utf-8')

# Generated at 2022-06-20 16:19:40.881627
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert type(codename) is str

# Generated at 2022-06-20 16:19:52.554131
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Return the version of the distribution the code is running on
    # rtype: NativeString or None
    # returns: A string representation of the version of the distribution. If it cannot determine the
    # version, it returns an empty string.
    # This test_get_distribution_version() function should test that.
    # The function being tested is get_distribution_version() in module_utils.basic.
    # This is the test_get_distribution_version() function.
    # It tests get_distribution_version() in module_utils.basic.
    # If the test passes it returns 0.
    # If the test fails it returns 1.
    # The test fails if it detects an error in get_distribution_version().
    # The test fails if the version is not as expected.
    result = get_distribution_version()

# Generated at 2022-06-20 16:20:14.176241
# Unit test for function get_distribution
def test_get_distribution():
    platform_system = platform.system()

    # Known-good data.
    expected = {
        'Amazon': 'Amazon',
        'CentOS': 'Redhat',
        'Debian': 'Debian',
        'Fedora': 'Fedora',
        'FreeBSD': 'FreeBSD',
        'Ubuntu': 'Ubuntu',
    }

    # Test whatever platform we're on, because that's what matters in real life.
    actual = get_distribution()
    assert expected[platform_system] == actual, (
        "Expected %s, got %s." % (expected[platform_system], actual)
    )



# Generated at 2022-06-20 16:20:16.539683
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Used by the unit tests to validate the get_distribution() method
    '''
    return get_distribution()

# Generated at 2022-06-20 16:20:27.028157
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    ''' Test get_platform_subclass function '''
    class Foo(object):
        platform = distribution = None

    class FooLinux(Foo):
        platform = distribution = 'Linux'

    class FooDebian(FooLinux):
        distribution = 'Debian'

    class FooAmzn(FooLinux):
        distribution = 'Amzn'

    class FooWindows(Foo):
        platform = 'Windows'
        distribution = None

    # Test the base case where we are on the base class
    assert get_platform_subclass(Foo) is Foo

    # Test a case where the platform matches completely
    assert get_platform_subclass(FooDebian) is FooDebian

    # Test a case where the platform matches but not the distribution
    # Ansible only uses the major version of the distribution so 7 is valid for RedHat 7.

# Generated at 2022-06-20 16:20:34.009082
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import unittest
    import platform

    class TestDistroCodeName(unittest.TestCase):
        '''
        Tests for get_distribution_codename()
        '''
        def setUp(self):
            # Reset platform to known values
            platform.system = lambda: 'Linux'
            platform.linux_distribution = lambda full_distribution_name: ['', '', '']

        def test_distro_returns_codename(self):
            # Testing distro.os_release_info() return a codename for the distro
            distro.os_release_info = lambda: [{'version_codename': 'bionic'}]
            self.assertEqual(get_distribution_codename(), 'bionic')

# Generated at 2022-06-20 16:20:43.424656
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test function to ensure that get_platform_subclass() works as expected
    :return: None
    '''
    # class name, distro(if any), subclass

# Generated at 2022-06-20 16:20:44.813691
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    #TODO: write some unit tests that exercise this code
    assert True

# Generated at 2022-06-20 16:20:55.593593
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test get_distribution_version() for different linux distributions
    '''
    if platform.system() == 'Linux':
        version = get_distribution_version()
        distribution = get_distribution()
        if distribution == 'Debian':
            if version[0] == '9':
                assert version in ('9', '9.9')
            if version[0] == '8':
                assert version in ('8', '8.11')
            if version[0] == '7':
                assert version in ('7', '7.11')
            if version[0] == '10':
                assert version in ('10', '10.2')
        elif distribution == 'Ubuntu':
            if version[0] == '9':
                assert version in ('9', '9.10')

# Generated at 2022-06-20 16:21:03.965667
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Superclass:
        pass
    class PlatformA(Superclass):
        platform = 'A'
        distribution = None
    class PlatformB(Superclass):
        platform = 'B'
        distribution = None
    class PlatformADistribution1(PlatformA):
        distribution = 'Distro1'
    class PlatformADistribution2(PlatformA):
        distribution = 'Distro2'

    class Test(Superclass):
        pass

    test_instance = Test()

    for platform, distro, expected_class in (
            ('A', None, PlatformA),
            ('B', None, PlatformB),
            ('A', 'Distro1', PlatformADistribution1),
            ('A', 'Distro2', PlatformADistribution2),
    ):
        test_instance.platform = platform
        test_instance.distribution = distro

# Generated at 2022-06-20 16:21:09.933557
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Root(object):
        pass
    class Win(Root):
        platform = 'Windows'
    class WinLinux(Root):
        platform = 'Windows'
        distribution = 'Linux'
    class Linux(Root):
        platform = 'Linux'
    class LinuxRedhat(Root):
        platform = 'Linux'
        distribution = 'Redhat'
    class LinuxOther(Root):
        platform = 'Linux'
        distribution = 'OtherLinux'
    class LinuxRedhat6(LinuxRedhat):
        distribution_version = '6'
    class LinuxPlusPlus(Root):
        platform = 'Linux'
        distribution = 'Linux'
        distribution_version = '26'
    class LinuxPlusPlus27(LinuxPlusPlus):
        distribution_version = '27'

    assert get_platform_subclass(WinLinux) == WinLinux

# Generated at 2022-06-20 16:21:19.834954
# Unit test for function get_distribution
def test_get_distribution():
    import platform
    import unittest

    class TestGetDistribution(unittest.TestCase):
        '''
        Tests to see whether the get_distribution function returns the correct values
        '''
        def setUp(self):
            '''
            Save the original platform.dist and platform.system values
            '''
            self.original_dist = platform.dist
            self.original_system = platform.system

        def tearDown(self):
            '''
            Restore original platform.dist and platform.system values
            '''
            platform.dist = self.original_dist
            platform.system = self.original_system

        def test_platform_dist(self):
            '''
            Test get_distribution with platform.dist returning a value
            '''

# Generated at 2022-06-20 16:21:39.756431
# Unit test for function get_distribution_version
def test_get_distribution_version():
    class VersionFixture:
        def __init__(self, name, version, best_version):
            self.name = name
            self.version = version
            self.best_version = best_version
        def __call__(self):
            return self.version
        def id(self):
            return self.name
        def version(self, best=False):
            if best:
                return self.best_version
            return self.version

    centos = VersionFixture(u'centos', u'7.1810', u'7.1810.20200114')
    debian = VersionFixture(u'debian', u'10.2', u'10.2')
    ubuntu = VersionFixture(u'ubuntu', u'16.04', u'16.04')

# Generated at 2022-06-20 16:21:41.225602
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Fedora'


# Generated at 2022-06-20 16:21:50.348892
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class BaseClass1:
        pass

    class BaseClass2:
        pass

    class SubClass11(BaseClass1):
        pass

    class SubClass21(BaseClass2):
        pass

    # Test simple case w/o any subclassing
    assert get_platform_subclass(BaseClass1) is BaseClass1

    # Test multiple inheritance
    assert get_platform_subclass(SubClass11) is SubClass11
    assert get_platform_subclass(SubClass21) is SubClass21

    # Test multiple inheritance with a single platform subclass
    class SubClass111(BaseClass1):
        pass

    class SubClass112(BaseClass1):
        pass

    class SubClass113(SubClass111):
        pass

    class SubClass114(SubClass112):
        pass


# Generated at 2022-06-20 16:21:51.366921
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'

# Generated at 2022-06-20 16:22:00.217947
# Unit test for function get_distribution_version

# Generated at 2022-06-20 16:22:01.304820
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == u"Darwin"


# Generated at 2022-06-20 16:22:10.577152
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import sys
    import os
    import tempfile

    saved_distro = distro.__version__
    saved_file = distro.file
    saved_id = distro.id

    def cleanup():
        distro.__version__ = saved_distro
        distro.file = saved_file
        distro.id = saved_id


# Generated at 2022-06-20 16:22:20.041699
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test get_distribution function

    :returns: None

    This function test function get_distribution.
    It doesn't use a test framework for simplicity but would be easy to port
    to unittest if you prefer.
    '''
    from ansible.module_utils.common._collections_compat import MutableMapping


# Generated at 2022-06-20 16:22:21.735127
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename('Linux') is None



# Generated at 2022-06-20 16:22:27.615201
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test function that returns the name of the distribution the module is running on.

    :rtype: NativeString or None
    :returns: Name of the distribution the module is running on

    This function attempts to determine what distribution the code is running
    on and return a string representing that value. If the platform is Linux
    and the distribution cannot be determined, it returns ``OtherLinux``.
    '''
    assert get_distribution() == 'MacosX'



# Generated at 2022-06-20 16:23:01.222668
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class base(object):
        platform = 'Linux'

    class BSD(base):
        platform = 'BSD'

    class FreeBSD(BSD):
        distribution = 'FreeBSD'
        distribution_version = '11.2'

    class Linux(base):
        distribution = 'Linux'

    class OtherLinux(Linux):
        pass

    class FedoraLinux(Linux):
        distribution = 'Fedora'

    class UbuntuLinux(Linux):
        distribution = 'Ubuntu'
        distribution_version = '16.04'

    class AmznLinux(Linux):
        distribution = 'Amazon'

    assert get_platform_subclass(base).__name__ == 'base'
    assert get_platform_subclass(BSD).__name__ == 'FreeBSD'

# Generated at 2022-06-20 16:23:03.434957
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distribution_version = get_distribution_version()
    assert distribution_version is not None, "Failed to get version for current distribution"

# Generated at 2022-06-20 16:23:04.228553
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() != None

# Generated at 2022-06-20 16:23:04.923749
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == None

# Generated at 2022-06-20 16:23:10.811622
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import os
    import tempfile
    import shutil
    import subprocess

    class FakeFile(object):
        def __init__(self, path, content):
            self.path = path
            self.content = content
            self.closed = False

        def __enter__(self):
            return self

        def write(self, *args, **kwargs):
            assert not self.closed
            with open(self.path, 'w') as f:
                f.write(self.content)

        def close(self):
            self.closed = True

        def __exit__(self, type, value, traceback):
            pass

    class FakeStdout(object):
        def __init__(self):
            self.content = u''

        def __enter__(self):
            return self


# Generated at 2022-06-20 16:23:23.499323
# Unit test for function get_distribution
def test_get_distribution():
    import platform

    def _mock_distro_id(distribution):
        old_distro_id = distro.id

        def mocked_distro_id():
            """
            Return the name of the distribution the module is running on.

            :rtype: NativeString or None
            :returns: Name of the distribution the module is running on

            This function attempts to determine what distribution the code is
            running on and return a string representing that value. If the
            platform is Linux and the distribution cannot be determined, it
            returns ``OtherLinux``.
            """
            return distribution

        distro.id = mocked_distro_id
        return old_distro_id

    def _mock_system(system):
        old_system = platform.system
        platform.system = lambda: system
        return old_system

    old_dist

# Generated at 2022-06-20 16:23:27.673414
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Verify function get_distribution_version
    '''
    distribution_version = get_distribution_version()
    # If it cannot determine the version, it returns an empty string.
    assert distribution_version is not None

# Generated at 2022-06-20 16:23:37.638939
# Unit test for function get_distribution_codename

# Generated at 2022-06-20 16:23:48.721769
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the get_platform_subclass function
    '''
    class TestClass(object):
        '''
        base class for testing get_platform_subclass
        '''
        platform = None
        distribution = None

    class TestSubclassA(TestClass):
        '''
        platform specific subclass of TestClass
        '''
        distribution = 'redhat'
        platform = 'darwin'

    class TestSubclassB(TestClass):
        '''
        platform specific subclass of TestClass
        '''
        distribution = 'redhat'
        platform = 'redhat'

    class TestSubclassC(TestClass):
        '''
        platform specific subclass of TestClass
        '''
        platform = 'darwin'

    platform = platform.system()
    distribution = get_distribution()


# Generated at 2022-06-20 16:23:51.748286
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Centos', "Current distribution is not CentOS"


# Generated at 2022-06-20 16:24:25.853840
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class base_cls():
        pass

    class base_cls_linux(base_cls):
        platform = 'Linux'

    class base_cls_centos(base_cls_linux):
        distribution = 'Centos'

    class base_cls_noversion(base_cls_centos):
        version = None

    class base_cls_version(base_cls_centos):
        version = '7'

    class base_cls_unsupported(base_cls_centos):
        supported = False

    class base_cls_specific_version(base_cls_centos):
        version = '7'
        supported = True

    class base_cls_supported_version(base_cls_centos):
        version = '8'
        supported = True


# Generated at 2022-06-20 16:24:37.163950
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Subclass:
        platform = None
        distribution = None

    class SubclassOtherLinux(Subclass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class SubclassRedhat(Subclass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubclassAmazon(Subclass):
        platform = 'Linux'
        distribution = 'Amazon'

    class SubclassLinux(Subclass):
        platform = 'Linux'
        distribution = None

    class SubclassBSD(Subclass):
        platform = 'BSD'
        distribution = None

    class SubclassGeneric(Subclass):
        platform = None
        distribution = None

    class Test:
        pass
    Test.__bases__ = (SubclassOtherLinux, SubclassRedhat, SubclassAmazon, SubclassLinux, SubclassBSD, SubclassGeneric)

# Generated at 2022-06-20 16:24:37.927997
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() != None

# Generated at 2022-06-20 16:24:45.262262
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() in (u'Freebsd', u'Linux', u'Darwin', u'Sunos')
    assert 'bsd' in get_distribution().lower()
    assert 'linux' in get_distribution().lower()
    assert 'darwin' in get_distribution().lower()
    assert 'sunos' in get_distribution().lower()


# Generated at 2022-06-20 16:24:54.750446
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    if platform.system() == 'Linux':
        assert get_platform_subclass(AnsiballzDistro) == AnsiballzDistro
        assert get_platform_subclass(AnsiballzPlatform) == AnsiballzDistro
        assert get_platform_subclass(AnsiballzPlatformRedhat) == AnsiballzDistroRedhat
        assert get_platform_subclass(AnsiballzPlatformRedhat7) == AnsiballzDistroRedhat7
        assert get_platform_subclass(AnsiballzPlatformOtherLinux) == AnsiballzOtherLinux
    elif platform.system() == 'FreeBSD':
        assert get_platform_subclass(AnsiballzPlatformFreeBSD) == AnsiballzFreeBSD

# Generated at 2022-06-20 16:25:04.544010
# Unit test for function get_distribution
def test_get_distribution():
    '''
    find which distribution we are running on
    '''
    # Ubuntu 14.04
    distro.id = lambda: 'Ubuntu'
    assert 'Ubuntu' == get_distribution(), get_distribution()
    # Ubuntu 16.04
    distro.id = lambda: 'ubuntu'
    assert 'Ubuntu' == get_distribution(), get_distribution()
    # RHEL 6
    distro.id = lambda: 'rhel'
    assert 'Redhat' == get_distribution(), get_distribution()
    # CentOS 7
    distro.id = lambda: 'centos'
    assert 'Centos' == get_distribution(), get_distribution()
    # Arch Linux
    distro.id = lambda: 'arch'
    assert 'Arch' == get_distribution(), get_distribution()


# Generated at 2022-06-20 16:25:16.681312
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestBasic:
        platform = "nonlinux"
        distribution = None

    class TestPlatform(TestBasic):
        platform = platform.system()

    class TestDistro(TestBasic):
        platform = "Linux"
        distribution = get_distribution()

    class TestAll(TestBasic):
        platform = platform.system()
        distribution = get_distribution()

    class TestOther(TestBasic):
        platform = "foobared"
        distribution = "Something Else"

    assert get_platform_subclass(TestBasic) == TestBasic
    assert get_platform_subclass(TestPlatform) == TestPlatform
    if get_distribution() == "Linux":
        # On Linux, the distribution should take precedence
        assert get_platform_subclass(TestDistro) == TestDistro
        assert get_platform_subclass(TestAll)