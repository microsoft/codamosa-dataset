

# Generated at 2022-06-20 16:15:28.399333
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class AclModule:
        platform = 'Linux'
        distribution = None

    class AclModuleAmazonLinux(AclModule):
        platform = 'Linux'
        distribution = 'Amazon'

    class AclModuleRedHat(AclModule):
        platform = 'Linux'
        distribution = 'RedHat'

    class AclModuleRHEL7(AclModuleRedHat):
        distribution = 'RedHat'
        distribution_version = '7'

    class AclModuleFreeBSD(AclModule):
        platform = 'FreeBSD'

    get_distribution_orig = get_distribution
    get_distribution_version_orig = get_distribution_version


# Generated at 2022-06-20 16:15:39.466273
# Unit test for function get_distribution_version
def test_get_distribution_version():

    # Test for Red Hat Linux
    old_version = distro.version
    distro.version = lambda: "7.5"
    assert get_distribution_version() == "7.5"
    distro.version = old_version

    # Test for Debian Linux
    old_version = distro.version
    distro.version = lambda: "1.2"
    old_best = distro.version_best
    distro.version_best = lambda: "1.2.3"
    assert get_distribution_version() == "1.2.3"
    distro.version_best = old_best
    distro.version = old_version

    # Test for non-Linux platforms
    old_system = platform.system
    platform.system = lambda: "Windows"
    assert get_distribution_version() is None

# Generated at 2022-06-20 16:15:48.629786
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version()

    Function get_distribution_version() returns a string representation of the version of the distribution
    the code is running on. If it cannot determine the version, it returns an empty string. If this is not run on
    a Linux machine it returns None.

    Test case 1: function returns a string representation of the version of the distribution

    Test case 2: function returns an empty string
    '''

    assert get_distribution_version()
    assert get_distribution_version() == u'18.04'

# Generated at 2022-06-20 16:15:53.003266
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the platform.get_distribution_version() function.
    '''
    version = get_distribution_version()
    # This is a very simple test, but it should fail when someone
    # accidentally changes the return value of get_distribution_version()
    # to a tuple (which happened).
    assert isinstance(version, basestring)

# Generated at 2022-06-20 16:16:03.801196
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    #####################
    # Module Subclasses #
    #####################
    class LinuxTestClass(object):
        platform = 'Linux'
        distribution = None
        codename = None

    class LinuxRedhatTestClass(LinuxTestClass):
        distribution = 'Redhat'

    class LinuxRedhat7TestClass(LinuxRedhatTestClass):
        codename = 'Redhat7'

    class SunOSTestClass(object):
        platform = 'SunOS'
        distribution = None

    class OtherTestClass(object):
        platform = 'Other'
        distribution = None

    #################
    # Test Platform #
    #################
    class TestUser(object):
        platform = 'Linux'
        distribution = None

    # Test loading of platform subclass
    assert get_platform_subclass(TestUser) is LinuxTestClass

    # Test loading of

# Generated at 2022-06-20 16:16:09.638150
# Unit test for function get_distribution
def test_get_distribution():
    ''' Unit test for function get_distribution '''
    import sys
    if sys.platform.startswith('win'):
        platform_str = 'Windows'
    elif sys.platform.startswith('darwin'):
        platform_str = 'MacOS'
    else:
        platform_str = 'Linux'

    assert get_distribution() == platform_str



# Generated at 2022-06-20 16:16:19.783241
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    This function tests the get_distribution_codename() function.
    '''
    test_cases = (
        (
            'Cumulus Linux 3.7.8',
            '',
        ),
        (
            'Debian GNU Debian GNU/Linux 9.11 (stretch)',
            'stretch',
        ),
        (
            'Ubuntu 16.04.6 LTS',
            'xenial',
        ),
        (
            'CentOS Linux release 7.6.1810 (Core)',
            '',
        ),
    )
    for (os_name, os_codename) in test_cases:
        distro.id = lambda: os_name.split()[0].lower()
        if distro.id() == 'ubuntu':
            distro.lsb_release_

# Generated at 2022-06-20 16:16:24.978100
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function which is used to identify the distribution
    the code is running on.

    :rtype: NativeString or None
    :returns: Name of the distribution the module is running on
    '''
    distribution = get_distribution()
    assert distribution



# Generated at 2022-06-20 16:16:31.405275
# Unit test for function get_distribution_version
def test_get_distribution_version():
    class TestDistro():
        def id(self):
            return 'Test'

        def version(self, best=False):
            if best:
                return '1.2.3'

            return '1'

        def codename(self):
            return 'B'

        def os_release_info(self):
            return {}

    assert get_distribution_version() == ''

    old_distro = distro
    try:
        distro = TestDistro()

        assert get_distribution_version() == '1'
    finally:
        distro = old_distro


# Generated at 2022-06-20 16:16:34.738846
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert distribution in ('Amazon', 'Redhat', 'Centos', 'Debian', 'Ubuntu', 'Suse', 'Freebsd', 'OpenSUSE', 'Macosx', 'OtherLinux')

# Generated at 2022-06-20 16:16:50.932182
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Basic unit tests for get_platform_subclass.  Should remain with this module
    so that it is easy to test the code against multiple distributions.
    '''
    import platform
    import unittest

    class GenericA:
        platform = 'any'
        distribution = None

    class GenericB:
        platform = 'any'
        distribution = None

    class LinuxA:
        platform = 'Linux'
        distribution = None

    class LinuxB:
        platform = 'Linux'
        distribution = None

    class LinuxDistroA(LinuxB):
        distribution = 'LinuxDistro'

    class LinuxDistroB(LinuxA):
        distribution = 'LinuxDistro'


# Generated at 2022-06-20 16:16:53.308186
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test get_distribution_codename
    codename = get_distribution_codename()
    assert codename == "bionic"


# Generated at 2022-06-20 16:17:03.686239
# Unit test for function get_distribution
def test_get_distribution():
    # Check that we correctly determine the distribution of some systems
    assert get_distribution() == 'Freebsd'
    assert get_distribution() == 'Linuxmint'
    assert get_distribution() == 'Darwin'
    assert get_distribution() == 'Openbsd'
    assert get_distribution() == 'Mageia'
    assert get_distribution() == 'Fedora'
    assert get_distribution() == 'Netbsd'
    assert get_distribution() == 'Ubuntu'
    assert get_distribution() == 'Redhat'
    assert get_distribution() == 'Debian'
    assert get_distribution() == 'Sunos'
    assert get_distribution() == 'Arch'
    assert get_distribution() == 'Gentoo'
    assert get_distribution() == 'Slackware'

# Generated at 2022-06-20 16:17:05.949655
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename is not None, "The codename should not be None"

# Generated at 2022-06-20 16:17:16.137511
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    This function will be used to unittest the function 'get_platform_subclass'
    """
    # No platform specified
    class Platform1:
        distribution = None
        platform = None

    class Platform2(Platform1):
        platform = 'Linux'

    class Platform3(Platform2):
        distribution = 'Debian'

    class Platform4(Platform2):
        distribution = 'Amzn'

    # Testing 2 good test cases when we have a distribution set.
    assert Platform3 is get_platform_subclass(Platform1)
    assert Platform4 is get_platform_subclass(Platform1)

    # No distribution specified
    class Platform5(Platform1):
        platform = 'Linux'

    class Platform6(Platform5):
        distribution = 'Debian'


# Generated at 2022-06-20 16:17:23.257688
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version()
    '''
    # Check if Redhat/CentOS
    import ansible.module_utils.facts.system.distribution as distributionmod
    distributionmod.distro = ansible.module_utils.facts.system.distribution
    if distro.id() in ['redhat', 'centos']:
        return_distr_ver = get_distribution_version()
        assert return_distr_ver.split('.')[0] == distro.version().split('.')[0]
    # Check if Ubuntu/Debian
    if distro.id() in ['ubuntu', 'debian']:
        return_distr_ver = get_distribution_version()
        assert return_distr_ver.split('.')[0] == distro.version().split('.')[0]

# Generated at 2022-06-20 16:17:34.380689
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version().

    This function is built with the assumption that the unit test will run on the
    platform that we want to test.  If we test this on an older Ubuntu, it will
    return the old version of the code and not new functionality.
    '''
    #
    # Test Ubuntu
    #
    old_syntax = (
        ('18.04', 'bionic'),
        ('17.10', 'artful'),
        ('17.04', 'zesty'),
        ('16.04', 'xenial'),
        ('14.04', 'trusty'),
    )

# Generated at 2022-06-20 16:17:43.343534
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the get_distribution_version function.

    :returns: A boolean indicating whether the tests passed or not
    '''
    passed = True

    # At least one of [version, version_best] must be defined in
    # ansible/module_utils/distro.py
    # This test case will fail if this assumption is wrong
    # TODO: make the version test more robust to the version method
    # changing
    version = distro.version()
    if version is None:
        version = distro.version(best=True)
    if version is None:
        print("test_get_distribution_version: FAIL")

# Generated at 2022-06-20 16:17:54.000390
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test cases to verify the get_distribution_version() function.

    Args:
        None

    Returns:
        None

    '''
    # There are two parts to each test case.  The first two elements of the tuple are
    # os_release_info and lsb_release_info.  The values in these dictionaries would be
    # found on a system when running distro.lsb_release_info() and distro.os_release_info().

    # The third element of the tuple is the expected return value.


# Generated at 2022-06-20 16:18:03.476244
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test function get_distribution
    '''
    import platform
    import subprocess


# Generated at 2022-06-20 16:18:18.937909
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    #  Assume we have three subclasses Dist1Class, Dist2Class, and GenericClass
    #  where Dist2Class inherits from Dist1Class, and Dist1Class inherits from GenericClass.
    #  And assume that 'Linux' is the platform.

    class TestClass:
        platform = 'Linux'
        distribution = None

    class TestClass2:
        platform = 'BSD'
        distribution = None

    class Dist1Class(TestClass):
        platform = 'Linux'
        distribution = 'Dist1'

    class Dist2Class(Dist1Class):
        platform = 'Linux'
        distribution = 'Dist2'

    class GenericClass(TestClass):
        platform = 'Linux'
        distribution = None

    # If the distribution matches and the platform is superclass or subclass, choose subclass

# Generated at 2022-06-20 16:18:19.497756
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None

# Generated at 2022-06-20 16:18:26.745434
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # This class is intentionally not defined here.  It is defined in the tests.
    from ansible.module_utils.basic import TestClass

    # When looking for subclasses of TestClass, get_platform_subclass() will return the subclass
    # defined in the test.
    assert get_platform_subclass(TestClass) is not TestClass

    # When looking for subclasses of object get_platform_subclass() returns object
    assert get_platform_subclass(object) is object

# Generated at 2022-06-20 16:18:28.999756
# Unit test for function get_distribution
def test_get_distribution():
    return get_distribution()

# Generated at 2022-06-20 16:18:38.959519
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Validate the get_distribution function against a few select Linux distros.
    These tests are not done for other platforms because asking for the
    distribution for, say, Darwin will never return a result.
    '''
    from ansible.module_utils.common._utils import TestAnsibleModule

    module = TestAnsibleModule()
    module_args = dict()

    original_id = distro.id
    original_version = distro.version
    original_codename = distro.codename
    original_os_release_info = distro.os_release_info
    original_lsb_release_info = distro.lsb_release_info


# Generated at 2022-06-20 16:18:39.825517
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-20 16:18:43.496971
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
     Unit test to check the method get_distribution_version() which is used
     to fetch the version of the distribution
    '''
    assert get_distribution_version() == '7'


# Generated at 2022-06-20 16:18:53.603703
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.distro import (
        ArchLinuxDistribution,
        DebianDistribution,
        FedoraDistribution,
        LinuxDistribution,
        RedHatDistribution,
        UnknownDistribution,
    )
    from ansible.module_utils import basic
    import os
    import sys
    import textwrap
    import tempfile

    original_os_release_path = LinuxDistribution._OS_RELEASE_PATH
    os_release_path = os.path.join(tempfile.gettempdir(), 'os-release')

# Generated at 2022-06-20 16:18:58.333803
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution = get_distribution().lower()
    codename = get_distribution_version()
    # codename must be a string if it exists
    if codename is not None:
        assert isinstance(codename, str)
    # Debian codename must match version
    if distribution in ['debian', 'ubuntu']:
        assert codename == distribution

# Generated at 2022-06-20 16:19:05.485999
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        pass

    # Simple class test
    class B(A):
        pass

    class C(B):
        pass

    b = get_platform_subclass(A)
    assert b is B

    # Multiple inheritance test
    class D(A):
        pass

    class E(A):
        pass

    class F(D, E):
        pass

    class G(F):
        pass

    d = get_platform_subclass(A)
    assert d is G

    # Multiple inheritance with more than two levels of hierarchy test
    class H(D):
        pass

    class I(E):
        pass

    class J(H, I):
        pass

    class K(J):
        pass

    k = get_platform_subclass(A)
    assert k is K

    # Multiple

# Generated at 2022-06-20 16:19:12.339100
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == distro.version()


# Generated at 2022-06-20 16:19:14.441614
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Centos'


# Generated at 2022-06-20 16:19:15.994041
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == platform.dist()[0].capitalize()

# Generated at 2022-06-20 16:19:24.541996
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Extract the function we want to test
    function = get_distribution_codename

    # Test results
    assert function() is None
    os_release_info = {
        'name': u'Amazon Linux AMI',
        'version': u'2018.03',
    }
    distro._os_release_info = lambda: os_release_info
    # Add the function to distro so we can test it in distro's unit tests
    setattr(distro, 'codename', function)
    assert function() is None
    os_release_info['version_codename'] = u'deadbeef'
    assert function() == u'deadbeef'
    # Clean up
    delattr(distro, 'codename')
    distro._os_release_info = None

# Generated at 2022-06-20 16:19:33.386602
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''

    system_cache_result = {
        'Linux': 'CentOS Linux release 8.0.1905 (Core)',
        'Windows': None,
        'Darwin': 'Darwin Mac-mini'
    }

    for (k, v) in system_cache_result.items():
        distro.lsb_release = \
            lambda: system_cache_result.get(platform.system())
        assert get_distribution_codename() == 'None'

# Generated at 2022-06-20 16:19:40.760486
# Unit test for function get_distribution_version

# Generated at 2022-06-20 16:19:42.921568
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == u'8'
    assert get_distribution_version() == '8'

# Generated at 2022-06-20 16:19:54.142838
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    # pylint: disable=unused-variable, expression-not-assigned
    # Test with a fake class setup to mimic each of the Linux distributions
    TestDistro = type(str('TestDistro'), (object,), {'id': lambda s: 'centos'})
    assert get_distribution_version(distro=TestDistro()) == '5.11'
    TestDistro = type(str('TestDistro'), (object,), {'id': lambda s: 'debian'})
    assert get_distribution_version(distro=TestDistro()) == '7.11'
    TestDistro = type(str('TestDistro'), (object,), {'id': lambda s: 'fedora'})
    assert get_distribution_version

# Generated at 2022-06-20 16:19:57.063839
# Unit test for function get_distribution_version
def test_get_distribution_version():
    check_distribution_version = get_distribution_version()

    # Check if the function returns value
    assert(check_distribution_version is not None)

# Generated at 2022-06-20 16:20:05.053356
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class base:
        platform = None
        distribution = None

    class linux(base):
        platform = 'Linux'

    class centos(linux):
        distribution = 'Redhat'

    class amazon(centos):
        distribution = 'Amazon'

    class centos_6(centos):
        distribution_release = '6.10'

    class centos_7(centos):
        distribution_release = '7.5'

    class debian(linux):
        distribution = 'Debian'

    class ubuntu(debian):
        distribution = 'Ubuntu'

    class ubuntu_xenial(ubuntu):
        distribution_release = '16.04'

    class ubuntu_bionic(ubuntu):
        distribution_release = '18.04'


# Generated at 2022-06-20 16:20:18.876600
# Unit test for function get_distribution
def test_get_distribution():
    import mock

    # Testing distro.id() returns None
    with mock.patch('ansible.module_utils.distro.id') as mock_id:
        mock_id.return_value = None
        result = get_distribution()
    assert result is None, "Function get_distribution returned '%s' instead of None when distro.id() returned None" % result

    # Testing distro.id() returns ''
    with mock.patch('ansible.module_utils.distro.id') as mock_id:
        mock_id.return_value = ''
        result = get_distribution()
    assert result == 'OtherLinux', "Function get_distribution returned '%s' instead of 'OtherLinux' when distro.id() returned ''" % result

    # Testing distro.id() returns 'amzn'

# Generated at 2022-06-20 16:20:27.848436
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for get_distribution_codename
    '''

    def mock_distro_id(self):
        '''
        A mock function to replace get_distribution_codename's call to ``distro.id()``
        '''
        return 'MockLinux'

    def mock_os_release_info(self):
        '''
        A mock function to replace get_distribution_codename's call to ``distro.os_release_info()``
        '''
        return {'version_codename': 'mockcodename'}

    def mock_lsb_release_info(self):
        '''
        A mock function to replace get_distribution_codename's call to ``distro.lsb_release_info()``
        '''

# Generated at 2022-06-20 16:20:28.877447
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-20 16:20:30.005102
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == distro.version()


# Generated at 2022-06-20 16:20:35.474011
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.distro import _get_distribution_info

# Generated at 2022-06-20 16:20:37.103760
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Fedora'



# Generated at 2022-06-20 16:20:44.763775
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform

    import distro as mod_distro
    import pytest

    from ansible.module_utils.common._utils import get_all_subclasses

    class TestBase():
        pass

    class TestSubclass(TestBase):
        platform = platform.system()
        distribution = None

    class TestSubclass2(TestBase):
        platform = platform.system()
        distribution = None

        @classmethod
        def os_release_info(self):
            return mod_distro.os_release_info()

        @classmethod
        def lsb_release_info(self):
            return mod_distro.lsb_release_info()

        @classmethod
        def id(self):
            return mod_distro.id()


# Generated at 2022-06-20 16:20:52.427010
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    # This can't be tested in unit tests yet as it requires actual
    # platform information and Python mocking seems to not be able
    # to override that aspect of the ansible.module_utils.distro.
    #  https://bugs.python.org/issue23078
    #  https://github.com/ansible/molecule/issues/226
    #  https://github.com/ansible/ansible-modules-core/issues/4282
    pass

# Generated at 2022-06-20 16:21:01.026635
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import os
    import subprocess
    import sys

    def test_code_name(test_os, code_name, reason):
        os_release = os.path.join(test_os, 'etc/os-release')
        lsb_release = os.path.join(test_os, 'etc/lsb-release')
        os.environ['PATH'] = '/usr/bin:/bin:/usr/sbin:/sbin'
        os.environ['LANG'] = 'C'
        os.environ['LC_ALL'] = 'C'
        os.environ['HOME'] = '/home/test'
        os.environ['USER'] = 'test'
        os.environ['LANGUAGE'] = 'en_US'
        os.environ['_'] = '/usr/bin/python'
        os

# Generated at 2022-06-20 16:21:04.915679
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert distribution is not None, 'get_distribution() returned None'
    assert isinstance(distribution, NativeString), 'get_distribution() did not return string'



# Generated at 2022-06-20 16:21:20.048197
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        platform = 'Linux'
        distribution = None

    class Aa(A):
        platform = 'Linux'
        distribution = 'Redhat'

    class Ab(A):
        platform = 'Linux'
        distribution = 'Redhat'

    class Abc(Ab):
        platform = 'Linux'
        distribution = 'Redhat'

    class Ac(A):
        platform = 'Linux'
        distribution = 'Redhat'

    class B(object):
        platform = 'Linux'
        distribution = None

    class Ba(B):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class Bb(B):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class C(object):
        platform = 'Linux'
        distribution = None


# Generated at 2022-06-20 16:21:30.101932
# Unit test for function get_distribution
def test_get_distribution():
    from distutils.version import LooseVersion

    from ansible.module_utils.six.moves import mock

    import sys

    mock_platform_system = mock.MagicMock(name='platform.system', return_value='Linux')

    with mock.patch.object(platform, 'system', mock_platform_system):
        # Test normal distributions
        with mock.patch.object(distro, 'id', mock.Mock(side_effect=['debian', 'rhel', 'fedora'])):
            assert get_distribution() == 'Debian'
            assert get_distribution() == 'Redhat'
            assert get_distribution() == 'Fedora'

        # Test Amazon Linux
        with mock.patch.object(distro, 'id', mock.Mock(side_effect=['amzn'])):
            assert get_

# Generated at 2022-06-20 16:21:31.917176
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename = get_distribution_codename()
    assert(distribution_codename == 'xenial' or distribution_codename is None)

# Generated at 2022-06-20 16:21:38.851075
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    get_distribution_codename returns Fedora's code name or None if not a Linux distro

    :returns: True if function works as expected
    '''
    codename = get_distribution_codename()
    return codename is None or codename in ('Bravo', 'Cairo', 'Carthage', 'Daisy', 'Dennis', 'Enigma',
                                            'Fermi', 'Heisenbug', 'Infinity', 'Lovelock', 'Laughlin', 'Moonshine',
                                            'Narcissus', 'Rawhide', 'Spherical Cow', 'Twenty Two', 'Verne',
                                            'Werewolf', 'Zod')

# Generated at 2022-06-20 16:21:48.968753
# Unit test for function get_distribution
def test_get_distribution():
    '''This is a unit test for the get_distribution() function'''
    need_unit_test = platform.system() == 'Linux'

    if need_unit_test:
        # Create a function that returns a simplified name for the distribution it's running on.
        # This is just to get the expected values for the test variable below.
        distribution_name = platform.linux_distribution()[0].capitalize()

        if distribution_name == 'Redhat':
            distribution_name = 'RedHat'
        elif distribution_name == 'Fedora':
            distribution_name = 'Fedora'
        elif distribution_name == 'Amazon':
            distribution_name = 'Amazon'
        elif not distribution_name:  # this is actually the case where the distro is unknown
            distribution_name = 'OtherLinux'

        # make sure we

# Generated at 2022-06-20 16:21:58.798473
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible.module_utils.facts.system.distribution import Distribution
    import os

    if os.path.exists('/etc/os-release'):
        with open('/etc/os-release', 'r') as f:
            os_release = f.read()
    else:
        os_release = ''

    if os.path.exists('/etc/lsb-release'):
        with open('/etc/lsb-release', 'r') as f:
            lsb_release = f.read()
    else:
        lsb_release = ''

    distro_id = distro.id()

    if distro_id in ('centos', 'debian'):
        distro_version_best = distro.version(best=True)
        distro_version_string = distro.version_

# Generated at 2022-06-20 16:22:06.261538
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform

    class BaseClass:
        platform = None
        distribution = None

    class BSD(BaseClass):
        platform = 'BSD'

    class Linux(BaseClass):
        platform = 'Linux'

    class Redhat(Linux):
        distribution = 'Redhat'

    class Debian(Linux):
        distribution = 'Debian'

    # Test on BSD
    if platform.system() == 'BSD':
        assert get_platform_subclass(BaseClass) is BSD

    # Test on Linux
    if platform.system() == 'Linux':
        assert get_platform_subclass(BaseClass) is Linux
        assert get_platform_subclass(Linux) is Linux
        assert get_platform_subclass(BSD) is BaseClass
        assert get_platform_subclass(Redhat) is Redhat
        assert get_platform_

# Generated at 2022-06-20 16:22:07.131901
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is None

# Generated at 2022-06-20 16:22:15.771165
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7'
    assert get_distribution_version() == '7.2.1511'
    assert get_distribution_version() == '2.6.32-696.1.1.el6.x86_64'
    assert get_distribution_version() == '1.0.1'
    assert get_distribution_version() == 'xenial'
    assert get_distribution_version() == '2.6.32-696.1.1.el6.x86_64'
    assert get_distribution_version() == '20160316'
    assert get_distribution_version() == '14.0.1'
    assert get_distribution_version() == '12.0.4'

# Generated at 2022-06-20 16:22:24.779169
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY3, string_types

    # Create a mock version of the distro module that returns the specified codename
    class MockDistro():
        def __init__(self, codename):
            self.codename = codename
            self.os_release_info = lambda: {'version_codename': self.codename}
            self.id = lambda: 'ubuntu'
            self.lsb_release_info = lambda: {'codename': 'other_codename'}

    codename = get_distribution_codename()

# Generated at 2022-06-20 16:22:46.493818
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test get_platform_subclass
    '''

    # Create a base class and create some subclasses to test with
    class Base:
        platform = 'BasePlatform'
        distribution = None

    class Platform1(Base):
        platform = 'Platform1'
        distribution = None

    class Platform2(Platform1):
        platform = 'Platform2'
        distribution = None

    class Platform2Dist1(Platform2):
        platform = 'Platform2'
        distribution = 'Dist1'

    class Platform2Dist2(Platform2):
        platform = 'Platform2'
        distribution = 'Dist2'

    class Platform2Dist2Dist3(Platform2Dist2):
        platform = 'Platform2'
        distribution = 'Dist2'


# Generated at 2022-06-20 16:22:55.851314
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        pass

    class OtherLinux(A):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class Linux(A):
        platform = 'Linux'
        distribution = None

    class Other(A):
        platform = 'Other'
        distribution = None

    class OtherUnknown(A):
        platform = 'Other'
        distribution = 'Unknown'

    class OtherUbuntu(A):
        platform = 'Other'
        distribution = 'Ubuntu'

    class Ubuntu(A):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class OtherDebian(A):
        platform = 'Other'
        distribution = 'Debian'

    class Debian(A):
        platform = 'Linux'
        distribution = 'Debian'


# Generated at 2022-06-20 16:23:05.234159
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class LinuxOnly:
        platform = 'Linux'
        distribution = None

    class OtherLinux(LinuxOnly):
        distribution = 'OtherLinux'

    class Debian(LinuxOnly):
        distribution = 'Debian'

    class DebianOne(Debian):
        distribution_release = '1'

    class DebianTwo(Debian):
        distribution_release = '2'

    class DebianThree(Debian):
        distribution_release = '3'

    def check_results(distribution, distribution_release, expected_class):
        class LinuxTester:
            distribution = None
            platform = 'Linux'
            @classmethod
            def get_distribution(cls):
                return distribution
            @classmethod
            def get_distribution_version(cls):
                return distribution_release

# Generated at 2022-06-20 16:23:16.849648
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # test dict of pair of results and functions
    test_params = {
        None: lambda: get_distribution_version(),
        '8': lambda: get_distribution_version(),
        '7.5': lambda: get_distribution_version(),
        '7.1.1503': lambda: get_distribution_version('7.1.1503'),
        '14.04': lambda: get_distribution_version('14.04'),
        '4.19.0-8-cloud-amd64': lambda: get_distribution_version('4.19.0-8-cloud-amd64'),
    }
    # test dict of pair of results and functions

# Generated at 2022-06-20 16:23:17.533182
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-20 16:23:24.760125
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass

    This unit test for ``get_platform_subclass()`` provides an example of how to use the
    function.  A subclass is defined for Linux, then the test selects the appropriate subclass
    and confirms that the classes are equivalent
    '''

    class SubclassBase:
        pass

    # Define a class for Linux.  This is a very generic class that can be used on any Linux
    # distribution while still avoiding false positives on other platforms.  It is recommended
    # that you make your subclasses more specific though.
    class SubclassLinux(SubclassBase):
        platform = 'Linux'
        distribution = None

    class TestClass:
        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(TestClass)
           

# Generated at 2022-06-20 16:23:35.269080
# Unit test for function get_distribution

# Generated at 2022-06-20 16:23:47.537092
# Unit test for function get_platform_subclass

# Generated at 2022-06-20 16:23:51.988229
# Unit test for function get_distribution_version
def test_get_distribution_version():
    "Return the version of the distribution the code is running on"
    version = get_distribution_version()
    assert version is not None

# Generated at 2022-06-20 16:23:59.443394
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Check that we get the right codename for Ubuntu LTS releases
    if get_distribution() == 'Ubuntu':
        assert get_distribution_codename() in ('trusty', 'xenial', 'bionic')

    # Check that we get the right codename for Debian stable
    if get_distribution() == 'Debian':
        assert get_distribution_codename() == 'stretch'

    # Check that we get the right codename for RHEL/CentOS 7
    if get_distribution() == 'Redhat':
        assert get_distribution_codename() == 'Maipo'

    # Check that we get the right codename for Fedora 28
    if get_distribution() == 'Fedora':
        assert get_distribution_codename() == 'TwentyEight'

    # Check that we get the right codename for

# Generated at 2022-06-20 16:24:22.162734
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None


# Generated at 2022-06-20 16:24:29.296904
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        distribution = 'Redhat'
    class D(C):
        pass
    class E(B):
        platform = 'Linux'
    class F(C):
        platform = 'Linux'
    class G(B):
        platform = 'Linux'
        distribution = 'Redhat'
    class H(C):
        platform = 'Linux'
        distribution = 'Redhat'

    # no distribution
    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == B
    assert get_platform_subclass(C) == C
    assert get_platform_subclass(D) == D
    assert get_platform_subclass(E) == E

# Generated at 2022-06-20 16:24:39.321375
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Verify get_distribution() returns what we expect on various platforms
    '''
    real_platform = platform.system()

# Generated at 2022-06-20 16:24:50.692943
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test case for Fedora
    distro.id = lambda: 'fedora'
    distro.version = lambda: '28'
    assert get_distribution_version() == '28'

    # Test case for Redhat
    distro.id = lambda: 'redhat'
    distro.version = lambda: '7.5'
    assert get_distribution_version() == '7.5'

    # Test case for CentOS
    distro.id = lambda: 'centos'
    distro.version = lambda: '7.5.1804'
    distro.version = lambda best: '7.5.1804'
    assert get_distribution_version() == '7.5'

    # Test case for Debian
    distro.id = lambda: 'debian'
    distro.version = lambda: '9'


# Generated at 2022-06-20 16:24:55.025167
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Superclass:
        platform = 'Generic Platform'
        distribution = None

    class Bsd(Superclass):
        platform = 'BSD'
        distribution = None

    class Debian(Superclass):
        platform = 'Linux'
        distribution = 'Debian'

    class Ubuntu(Superclass):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class UbuntuMaverick(Superclass):
        platform = 'Linux'
        distribution = 'Ubuntu'
        codename = 'maverick'

    class UbuntuLucid(Superclass):
        platform = 'Linux'
        distribution = 'Ubuntu'
        codename = 'lucid'

    class Redhat6(Superclass):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '6'


# Generated at 2022-06-20 16:25:04.902715
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # This function is quite difficult to test because it depends on the platform
    # it runs on so we test it on the platforms it will most often run on
    # We need to make aliases to the classes we're instantiating because if we use
    # the actual class name in aws_ec2 the aws_ec2 import will happen before we
    # can mock out the platform.system call.  We only need class names anyway.
    class Foo:
        distribution = None
        platform = 'Linux'

    class Bar(Foo):
        pass

    class Baz(Foo):
        distribution = 'Fedora'

    class Bat(Baz):
        distribution = 'Redhat'

    class Bam(Foo):
        distribution = 'Centos'

    class Ban(Bam):
        distribution = 'Redhat'


# Generated at 2022-06-20 16:25:11.618480
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unittest for function get_distribution_codename
    '''
    import platform
    platform_system = platform.system()
    if platform_system == 'Linux':
        assert get_distribution_codename() is not None
    else:
        # not Linux
        assert get_distribution_codename() is None