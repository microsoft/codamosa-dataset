

# Generated at 2022-06-20 16:15:29.611513
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    #
    # This first block uses a fake module to test get_platform_subclass.
    # This is run in the Python 2.7 runtime.
    #

    #
    # This simulates a module class on an unsupported platform
    #
    class FakeModule:

        platform = 'foo_OS'
        distribution = None

        class my_fake_interface:
            pass

    class FakeModule_Windows(FakeModule):
        platform = 'Windows'

        class my_fake_interface_windows:
            pass

    class FakeModule_OtherLinux(FakeModule):
        class my_fake_interface_otherlinux:
            pass

    class FakeModule_Darwin(FakeModule):
        class my_fake_interface_darwin:
            pass


# Generated at 2022-06-20 16:15:36.746596
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    class module_mock:
        def __init__(self, name, codename):
            self.name = name
            self.codename = codename
            self.return_value = None

        def command(self, name, codename):
            return self.return_value

        def run_command(self, name, codename):
            return self.return_value

    mock = module_mock('', '')

    # When the code name is not provided
    mock.return_value = (0, '', '')
    assert get_distribution_codename() is None

    # When lsb_release is not available
    mock.return_value = (1, '', '')
    assert get_distribution_codename() is None

    # When the codename is available

# Generated at 2022-06-20 16:15:38.052671
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is None # On tests, the distro.py cache is not updated

# Generated at 2022-06-20 16:15:39.467002
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == "xenial"

# Generated at 2022-06-20 16:15:53.003183
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test for function get_distribution_codename

    This also tests for get_distribution_version and get_distribution
    '''

    distro_codename = get_distribution_codename()
    distro_version = get_distribution_version()
    distro_name = get_distribution()

    if platform.system() == 'Linux':

        # This file is not in Fedora 28, therefore we will just skip this test on Fedora 28
        if not distro.id() == 'fedora':
            if distro_codename != distro.codename():
                raise AssertionError('get_distribution_codename returned: %s, expected: %s'
                                     % (distro_codename, distro.codename()))

        if distro_version != distro.version():
            raise Ass

# Generated at 2022-06-20 16:16:02.041109
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # If distro.id() returns an empty string, get_distribution_version should return an empty string
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    # If distro.id() returns an empty string, get_distribution_version should return an empty string
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    # If distro.id() returns an empty string, get_distribution_version should return an empty string
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''

# Generated at 2022-06-20 16:16:04.778924
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test that get_distribution_codename finds codename.
    '''
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-20 16:16:06.320439
# Unit test for function get_distribution

# Generated at 2022-06-20 16:16:09.272705
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    expected_result = 'xenial'
    test_result = get_distribution_codename()
    assert test_result == expected_result

# Generated at 2022-06-20 16:16:14.923940
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.distro_codenames import codenames

    for distro in codenames.keys():
        if codenames[distro]:
            for codename in codenames[distro]:
                assert get_distribution_codename() == codename
        else:
            assert get_distribution_codename() == None

# Generated at 2022-06-20 16:16:37.772162
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    distribution = get_distribution()

    class A:
        platform = 'Linux'
        distribution = distribution
        def __init__(self, *args):
            self.args = args
    class B:
        platform = 'Linux'
        distribution = None
        def __init__(self, *args):
            self.args = args
    class C:
        platform = 'Linux'
        distribution = distribution.upper()
        def __init__(self, *args):
            self.args = args
    class D:
        platform = 'Linux'
        distribution = None
        def __init__(self, *args):
            self.args = args
    class E:
        platform = 'Darwin'
        distribution = None
        def __init__(self, *args):
            self.args = args

# Generated at 2022-06-20 16:16:40.988601
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()

    if codename == None:
        print("Not a Linux distro")
    else:
        print("Codename: " + codename)

# Generated at 2022-06-20 16:16:51.413979
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils import basic

    # normal case
    assert get_distribution_codename() is None

    # test for the Ubuntu 18.04 LTS codename
    old_system = platform.system
    platform.system = lambda: 'Linux'

# Generated at 2022-06-20 16:16:53.033579
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert distribution != 'OtherLinux'

# Generated at 2022-06-20 16:17:03.506779
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Unittest requires that this code runs on Python 2.7 or later
    # We can't use unittest.skipUnless() because that isn't available
    # on 2.6
    import sys
    if not (2, 7) <= sys.version_info < (3,):
        raise unittest.SkipTest("Need Python 2.7 to run this test")

    import unittest

    class Base(object):
        platform = 'Base'

    class Base2(object):
        platform = 'Base2'

    class Linux(Base):
        platform = 'Linux'
        distribution = None

    class Linux2(Base2):
        platform = 'Linux'
        distribution = None

    class LinuxDistro(Linux):
        distribution = 'BaseLinuxDistro'


# Generated at 2022-06-20 16:17:14.293700
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    ''' test_get_platform_subclass
    '''
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_platform_subclass
    from ansible.module_utils.basic import load_platform_subclass  # Deprecated

    class SomeClass():
        platform = None
        distribution = None

    # return parent class if no child classes
    assert SomeClass == get_platform_subclass(SomeClass)

    # return parent class if no child classes
    assert SomeClass == load_platform_subclass(SomeClass, None, None)

    # return parent class if no child classes
    assert SomeClass == get_platform_subclass(SomeClass)

    # return the first child class in the class tree

# Generated at 2022-06-20 16:17:26.145347
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # A test class hierarchy
    class Base():
        pass

    class LinuxBase(Base):
        platform = 'Linux'

    class BSDBase(Base):
        platform = 'BSD'

    class DebianBase(LinuxBase):
        distribution = 'Debian'

    class SuSEBase(LinuxBase):
        distribution = 'SuSE'

    class FedoraBase(LinuxBase):
        distribution = 'Fedora'

    class OtherLinuxBase(LinuxBase):
        distribution = None

    class OpenBSDBase(BSDBase):
        distribution = 'OpenBSD'

    class FreeBSDBase(BSDBase):
        distribution = 'FreeBSD'

    class NetBSDBase(BSDBase):
        distribution = 'NetBSD'

    class OtherBSDBase(BSDBase):
        distribution = None

    class SuSEBase2(SuSEBase):
        pass


# Generated at 2022-06-20 16:17:32.585043
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Function that returns the name of the distribution the module is running on
    '''
    from ansible.module_utils import six_subclass_name
    from ansible.module_utils.common._collections_compat import Hashable
    assert get_distribution() is not None
    assert isinstance(get_distribution(), six_subclass_name)
    assert isinstance(get_distribution(), Hashable)

# Generated at 2022-06-20 16:17:42.821559
# Unit test for function get_distribution_codename

# Generated at 2022-06-20 16:17:53.807449
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    #####################################################
    # Use this section to test the function and verify it works
    # Print out the function result to stdout and see if it returns 'User'
    #####################################################
    class Platform:
        platform = ''
        distribution = ''
    class PlatformBsd(Platform):
         platform = 'bsd'
    class PlatformLinux(Platform):
        platform = 'linux'
    class PlatformLinuxRedhat(Platform):
        platform = 'linux'
        distribution = 'redhat'
    class PlatformLinuxSuse(Platform):
        platform = 'linux'
        distribution = 'suse'
    class PlatformLinuxOther(Platform):
        platform = 'linux'
        distribution = 'other'
    class PlatformLinuxRedhatAndy(Platform):
        platform = 'linux'
        distribution = 'redhat'

# Generated at 2022-06-20 16:18:24.038498
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # Define a class to be used in this test
    class SuperClass(object):
        platform = ""
        distribution = ""
        def __init__(self, module):
            self.module = module

    # Define a subclass of SuperClass
    class FedoraUser(SuperClass):
        platform = "Linux"
        distribution = "Fedora"
        def __init__(self, module):
            super(FedoraUser, self).__init__(module)

    # Define another subclass of SuperClass
    class FreeBSDUser(SuperClass):
        platform = "FreeBSD"
        distribution = None
        def __init__(self, module):
            super(FreeBSDUser, self).__init__(module)

    # Define another subclass of SuperClass
    class LinuxUser(SuperClass):
        platform = "Linux"
        distribution = None

# Generated at 2022-06-20 16:18:25.504160
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distribution_version = get_distribution_version()
    assert distribution_version is not None

# Generated at 2022-06-20 16:18:27.781242
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '8'

# Generated at 2022-06-20 16:18:30.296548
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None

# Generated at 2022-06-20 16:18:34.082869
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() in ('Redhat', 'Fedora', 'Centos', 'Oracle', 'Amazon', 'Debian', 'Ubuntu', 'Macosx', 'Freebsd', 'Aix', 'OtherLinux')



# Generated at 2022-06-20 16:18:41.553465
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common.utils import get_platform_subclass
    class Base:
        """Base class"""
        platform = 'Base'
        distribution = None

        def __init__(self):
            self.args = "Base"

    class PlatformBase(Base):
        """Platform specific base class"""
        platform = 'TestPlatform'
        distribution = None

    class PlatformDistroBase(PlatformBase):
        """Platform and distro specific base class"""
        platform = 'TestPlatform'
        distribution = 'TestDistro'

    class GenuinePlatformBase(PlatformBase):
        """Platform specific base class"""
        platform = 'Linux'
        distribution = None

    class GenuineDistroBase(GenuinePlatformBase):
        """Platform specific base class"""
        platform = 'Linux'
        distribution = 'TestDistro'

   

# Generated at 2022-06-20 16:18:43.814485
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == get_distribution_version()


# Generated at 2022-06-20 16:18:53.801755
# Unit test for function get_distribution
def test_get_distribution():
    # case when it is linux
    def linux(dist_name):
        dist_name = dist_name.capitalize()
        orig_distro_id = distro.id  # save the original for restoring later
        orig_distro_capitalize = distro.capitalize

        def fake_id(**kwargs):
            return dist_name

        def fake_capitalize(**kwargs):
            return dist_name

        distro.id = fake_id
        distro.capitalize = fake_capitalize

        try:
            assert distro.id() == fake_id()
            assert distro.capitalize() == fake_capitalize()
            assert get_distribution() == dist_name
        finally:
            distro.id = orig_distro_id  # restore the original
            distro.capitalize = orig_dist

# Generated at 2022-06-20 16:19:05.983839
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # pylint: disable=unused-variable

    class SubClassA(object):
        '''
        Sub-class to test get_platform_subclass()
        '''
        platform = 'Linux'
        distribution = 'Centos'

    class SubClassB(object):
        '''
        Sub-class to test get_platform_subclass()
        '''
        platform = 'SunOS'
        distribution = 'Solaris'

    class SubClassC(object):
        '''
        Sub-class to test get_platform_subclass()
        '''
        platform = 'Linux'
        distribution = None

    class MyClass(object):
        '''
        Base class for testing get_platform_subclass()
        '''

    assert get_platform_subclass(MyClass) == MyClass
    assert get_platform

# Generated at 2022-06-20 16:19:07.250336
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == distro.version()

# Generated at 2022-06-20 16:19:35.832940
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo(object):
        pass

    class FooRedhat(Foo):
        platform = 'Linux'
        distribution = 'Redhat'

    class FooDebian(Foo):
        platform = 'Linux'
        distribution = 'Debian'

    class FooUbuntu(Foo):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class FooOther(Foo):
        platform = 'Linux'
        distribution = None

    class FooWindows(Foo):
        platform = 'Windows'

    class FooUnix(Foo):
        platform = 'Unix'

    assert get_platform_subclass(Foo) == Foo

    # Test Linux distros
    assert get_platform_subclass(FooRedhat) == FooRedhat
    assert get_platform_subclass(FooDebian) == FooDebian
   

# Generated at 2022-06-20 16:19:38.355093
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic

    distribution = get_distribution()
    cls = ansible.module_utils.basic.AnsibleModule

    subclass = get_platform_subclass(cls)

    assert issubclass(subclass, cls) == True

# Generated at 2022-06-20 16:19:39.340446
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == None


# Generated at 2022-06-20 16:19:50.054319
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import ansible.module_utils.distro_facts

    # Return correct version for main Linux distributions
    assert ansible.module_utils.distro_facts.get_distribution_version() == '7'
    assert ansible.module_utils.distro_facts.get_distribution_version() == '6.10'
    assert ansible.module_utils.distro_facts.get_distribution_version() == '16.04'

    # Return empty string if version cannot be determined
    assert ansible.module_utils.distro_facts.get_distribution_version() == u''
    assert ansible.module_utils.distro_facts.get_distribution_version() == u''
    assert ansible.module_utils.distro_facts.get_distribution_version() == u''

    # Raise Attribute error if

# Generated at 2022-06-20 16:19:51.185327
# Unit test for function get_distribution_version
def test_get_distribution_version():
    get_distribution_version()


# Generated at 2022-06-20 16:19:56.922854
# Unit test for function get_distribution
def test_get_distribution():
    ret1 = get_distribution()
    ret2 = get_distribution_version()
    ret3 = get_distribution_codename()

# Generated at 2022-06-20 16:20:00.028710
# Unit test for function get_distribution
def test_get_distribution():
    """
    Tests that the get_distribution function properly returns the
    distribution of linux
    """
    assert distro.id() == get_distribution()


# Unit tests for function get_distribution_version

# Generated at 2022-06-20 16:20:06.948490
# Unit test for function get_distribution_version
def test_get_distribution_version():
    class Distribution:
        @property
        def version(self):
            return "1.0"

        @property
        def id(self):
            return "centos"

    def return_distro(release_file=None, search_string=None, fallback=None):
        return Distribution()
    try:
        old_distro = distro.distro
        distro.distro = return_distro
        assert get_distribution_version() == "1.0"
    finally:
        distro.distro = old_distro

    class Distribution:
        @property
        def version(self):
            return "1.0"

        @property
        def id(self):
            return "ubuntu"


# Generated at 2022-06-20 16:20:14.343340
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the function get_distribution_codename for different platforms
    '''
    # Test Ubuntu or Debian distributions
    assert get_distribution_codename() == u'bionic'

    # Test Fedora distribution
    assert get_distribution_codename() == u'28'

    # Test other Linux distribution
    assert get_distribution_codename() is None

    # Test non Linux distribution
    # (get_distribution_codename is None for a non Linux distribution)

# Generated at 2022-06-20 16:20:19.356503
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert (distribution == "Redhat" or
            distribution == "Debian" or
            distribution == "Freebsd" or
            distribution == "Sunos" or
            distribution == "Suse" or
            distribution == "Windows" or
            distribution == "Darwin")



# Generated at 2022-06-20 16:21:11.551351
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        platform = 'Bogus'
        distribution = None

    class B(A):
        platform = 'Bogus'
        distribution = 'Bogus'

    class C(A):
        platform = platform.system()
        distribution = None

    class D(A):
        platform = platform.system()
        distribution = get_distribution()

    class E(A):
        platform = platform.system()
        distribution = 'Not The Right Distribution'

    class F(A):
        platform = 'Linux'
        distribution = 'Not The Right Distribution'

    class G(F):
        platform = 'Not The Right Platform'
        distribution = get_distribution()


# Generated at 2022-06-20 16:21:13.057024
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for get_distribution_version
    '''
    version = get_distribution_version()
    assert version is not None

# Generated at 2022-06-20 16:21:22.075005
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    verify that get_distribution_version() returns correct platform version

    :returns: True if test passed, False otherwise
    '''
    on_linux = False
    platform_version = '10.0'
    distro = 'windows'
    distro_version = None
    distro_best_version = '10.0.17763.503'

    if platform.system() == 'Windows':
        on_linux = True
        platform_version = platform.win32_ver()[1]
        distro = 'centos'
        distro_version = None
        distro_best_version = '8.0.1905'

    elif platform.system() == 'Linux':
        on_linux = True


# Generated at 2022-06-20 16:21:24.987197
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '18.04.4' or get_distribution_version() == '7.8'

# Generated at 2022-06-20 16:21:36.184293
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    def get_module_distribution(module):
        return module.distribution

    def get_module_platform(module):
        return module.platform

    class Base:
        """This is the base class we're going to search from."""

    class OtherPlatform(Base):
        platform = "Not Linux"

    class OtherLinux(Base):
        platform = "Linux"
        distribution = "OtherLinux"

    class Debian(Base):
        platform = "Linux"
        distribution = "Debian"

    class Ubuntu(Base):
        platform = "Linux"
        distribution = "Ubuntu"

    # Don't instantiate anything here, we're just testing class based inheritance
    assert get_platform_subclass(Base) is Base
    assert get_module_platform(get_platform_subclass(Base)) is "Linux"
    assert get_module_

# Generated at 2022-06-20 16:21:39.585354
# Unit test for function get_distribution
def test_get_distribution():
    '''
    unit test function to test function get_distribution
    '''
    distribution = get_distribution()
    assert type(distribution) is str

# unit test for function get_distribution_version

# Generated at 2022-06-20 16:21:43.936013
# Unit test for function get_distribution_version
def test_get_distribution_version():
    if platform.system() == "Linux":
        codename = get_distribution_codename()
        if codename:
            return True
        else:
            return "No codename found"
    else:
        return "Not a Linux distro"

# Generated at 2022-06-20 16:21:48.361764
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test get_distribution function

    :returns: None
    '''
    assert get_distribution() == get_distribution_version()


# Generated at 2022-06-20 16:21:50.108756
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-20 16:21:53.012510
# Unit test for function get_distribution
def test_get_distribution():
    distro_name = get_distribution()
    assert distro_name is not None
    assert type(distro_name) is str


# Generated at 2022-06-20 16:23:18.642929
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Todo: write these unit tests as soon as we use a subclass
    pass

# Generated at 2022-06-20 16:23:31.617863
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test CentOS
    if platform.system() == 'Linux':
        distro.id = lambda: 'centos'
        distro.version = lambda: '7.5.1804'
        distro.version.__doc__ = distro._distro.linux_distribution.__doc__
        distro.version.__doc__ = distro._distro.linux_distribution.__doc__
        distro.version.__doc__ = distro._distro.linux_distribution.__doc__
        assert get_distribution_version() == '7'

        distro.id = lambda: u'centos'
        distro.version = lambda: u'8.1.1911'
        distro.version.__doc__ = distro._distro.linux_distribution.__doc__
        distro.version.__

# Generated at 2022-06-20 16:23:33.468472
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is None


# Generated at 2022-06-20 16:23:35.677380
# Unit test for function get_distribution
def test_get_distribution():
    # Required for python 2.6
    assert 'Linux' in platform.system()

    # Assume the tests are run on a known system
    assert get_distribution() == 'Rhel'



# Generated at 2022-06-20 16:23:40.698927
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    if platform.system() == 'Linux':
        assert get_distribution_version(), 'get_distribution_version should return a version string'
    else:
        assert get_distribution_version() is None, 'get_distribution_version should return None on non-Linux platforms'

# Generated at 2022-06-20 16:23:50.748934
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Returns the correct class on supported platforms

    :rtype: bool
    :returns: True if test passed, False otherwise.
    """
    try:
        from ansible.modules.system import getent
    except ImportError:
        # If the module imports failed we will error out from other Unit tests.
        # No need to add to the noise.
        return True

    # Unsupported platform should return the base class
    assert(get_platform_subclass(getent.Getent) is getent.Getent)

    # Supported platform should return the subclass for the running platform
    assert(get_platform_subclass(getent.Getent) is not getent.Getent)

    from ansible.module_utils.common.os.getent import GetentBase

# Generated at 2022-06-20 16:23:52.340860
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-20 16:23:54.040823
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat', "Received %s" % get_distribution()


# Generated at 2022-06-20 16:24:03.294343
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class Subclass1(Base):
        platform = "Test1"
        distribution = "Test1"

    class Subclass2(Base):
        platform = "Test1"
        distribution = "Test2"

    class Subclass3(Base):
        platform = "Test2"
        distribution = "Test1"

    class Subclass4(Base):
        platform = "Test3"
        distribution = "Test1"

    assert get_platform_subclass(Base) == Base
    assert get_platform_subclass(Base) == Base

    assert get_platform_subclass(Subclass1) == Subclass1
    assert get_platform_subclass(Subclass2) == Subclass2
    assert get_platform_subclass(Subclass3) == Subclass3

# Generated at 2022-06-20 16:24:08.224824
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test for OS X
    assert(get_distribution_version() is None)
    # Test for Ubuntu
    assert(get_distribution_version() == '16.04')
    # Test for CentOS
    assert(get_distribution_version() == '7')