

# Generated at 2022-06-20 16:15:23.364448
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert distribution == 'Darwin'

# Generated at 2022-06-20 16:15:29.021404
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename
    '''
    distribution_codename = get_distribution_codename()
    assert distribution_codename is None

    distribution_codename = get_distribution_codename()
    assert distribution_codename is None

    distribution_codename = get_distribution_codename()
    assert distribution_codename is None

# Generated at 2022-06-20 16:15:35.846934
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    def my_distro_id(*args, **kwargs):
        return "ubuntu"

    def my_os_release_info(*args, **kwargs):
        return {"version_codename": "my_codename"}

    def my_lsb_release_info(*args, **kwargs):
        return {"codename": "my_codename"}

    import ansible.module_utils.distro
    ansible.module_utils.distro.distro.id = my_distro_id
    ansible.module_utils.distro.distro.os_release_info = my_os_release_info
    ansible.module_utils.distro.distro.lsb_release_i

# Generated at 2022-06-20 16:15:47.684826
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = 'Linux'

    class SubClass(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass2(SubClass):
        platform = 'Linux'
        distribution = 'Redhat'

    # Check if it returns the most specific subclass
    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(SubClass) == SubClass
    assert get_platform_subclass(SubClass2) == SubClass2

    # Check if it returns the correct subclass for the platform
    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(SubClass) == SubClass
    assert get_platform_subclass(SubClass2) == SubClass2

    # Check if it returns the correct subclass for the platform


# Generated at 2022-06-20 16:15:48.992587
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() != None


# Generated at 2022-06-20 16:15:51.310674
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''

    assert get_distribution_codename() == 'xenial'


# Generated at 2022-06-20 16:16:03.185643
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    # mocks for distro module
    def distro_mock_codename():
        return 'jessie'
    def distro_mock_os_release_info():
        return {'version_codename':'wheezy'}
    def distro_mock_lsb_release_info():
        return {'distrib_codename':'wheezy'}
    def distro_mock_id():
        return 'debian'

    # patch distro module
    old_codename = distro.codename
    old_os_release_info = distro.os_release_info
    old_lsb_release_info = distro.lsb_release_info
    old_id = distro.id

    distro.codename = distro_mock_codename
    distro.os_

# Generated at 2022-06-20 16:16:15.442498
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    names = {
        "bionic": "Ubuntu Bionic 18.04",
        "xenial": "Ubuntu Xenial 16.04",
        "stretch": "Debian Stretch 9.13",
        "jessie": "Debian Jessie 8.11",
        "ga": "CoreOS GA",
        "beta": "CoreOS Beta",
        "alpha": "CoreOS Alpha",
        "paydirt": "Chapecó Linux",
        "buster": "Debian Buster 10.5",
    }

# Generated at 2022-06-20 16:16:26.096133
# Unit test for function get_distribution
def test_get_distribution():
    class MockDistro(object):
        @staticmethod
        def id():
            return 'Redhat'

    saved_distro = distro.linux_distribution
    # 'id' of Linux distribution is Redhat
    distro.linux_distribution = MockDistro
    assert get_distribution() == 'Redhat'
    distro.linux_distribution = saved_distro

    class MockDistro1(object):
        @staticmethod
        def id():
            return 'Arch'

    saved_distro1 = distro.linux_distribution
    # 'id' of Linux distribution is Arch
    distro.linux_distribution = MockDistro1
    assert get_distribution() == 'Arch'
    distro.linux_distribution = saved_distro1


# Generated at 2022-06-20 16:16:37.501612
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Use this class as a base class for all platform specific classes
    class BaseClass:
        pass

    # Class to test different combinations of platforms and linux distributions
    class TestClass(BaseClass):
        pass

    # Now define some classes to test different platform types
    class TestClassLinux(TestClass):
        platform = 'Linux'

    class TestClassLinuxDistroA(TestClassLinux):
        distribution = 'DistroA'

    class TestClassLinuxDistroB(TestClassLinux):
        distribution = 'DistroB'

    class TestClassLinuxDistroBVersion1(TestClassLinuxDistroB):
        version = '1'

    class TestClassLinuxDistroBVersion2(TestClassLinuxDistroB):
        version = '2'

    class TestClassLinuxDistroC(TestClassLinux):
        distribution = 'DistroC'



# Generated at 2022-06-20 16:17:01.116457
# Unit test for function get_distribution
def test_get_distribution():
    try:
        # this system has an lsb_release
        distribution = distro.name(pretty=False).lower()
        distribution = distribution.capitalize()

        if distribution == 'amzn':
            distribution = 'Amazon'
        elif distribution == 'rhel':
            distribution = 'Redhat'
        elif distribution == 'fedora':
            distribution = 'Fedora'
        elif distribution == 'oraclelinux':
            distribution = 'OracleLinux'
        elif distribution == 'sles':
            distribution = 'Suse'
        elif distribution == 'debian':
            distribution = 'Debian'

        assert get_distribution() == distribution
    except AssertionError:
        # this system does not have an lsb_release.  Fail
        raise AssertionError('Could not get the distribution name')

# Generated at 2022-06-20 16:17:08.963263
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        platform = 'Posix'

    class B(A):
        distribution = 'Linux'

    class C(B):
        distribution = 'Ubuntu'

    class D(A):
        pass

    subclass = get_platform_subclass(A)
    assert subclass == D

    subclass = get_platform_subclass(B)
    assert subclass == C

# Generated at 2022-06-20 16:17:18.081908
# Unit test for function get_distribution
def test_get_distribution():
    ''' Test the get_distribution function
    '''
    # RHEL
    assert get_distribution() == 'Redhat'
    # CentOS
    assert get_distribution() == 'Centos'
    # Fedora
    assert get_distribution() == 'Fedora'
    # Arch
    assert get_distribution() == 'Arch'
    # openSUSE
    assert get_distribution() == 'Opensus'
    # Gentoo
    assert get_distribution() == 'Gentoo'
    # AIX
    assert get_distribution() == 'Aix'
    # Oracle
    assert get_distribution() == 'Oracle'
    # Alpine
    assert get_distribution() == 'Alpine'
    # SUSE
    assert get_distribution() == 'Suse'
    # SLES
    assert get_

# Generated at 2022-06-20 16:17:30.350830
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Import modules to test
    import basic
    import sys

    # Create a test object
    class test_class(basic.AnsibleModule):
        def __init__(self, args, kwargs):
            super(test_class, self).__init__(args, kwargs)
            self.platform = platform.system()
            self.distribution = get_distribution()

    def test_subclass(cls):
        # Do nothing
        pass

    # Call function get_platform_subclass()
    test_platform_subclass = get_platform_subclass(test_class)
    assert test_platform_subclass == test_class

    # Define new subclass of test_class
    class test_class_subclass(test_class):
        def __init__(self, args, kwargs):
            super

# Generated at 2022-06-20 16:17:40.497591
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    class Distribution(object):
        platform = ''
        distribution = ''
        codename = None

        def __init__(self, platform, distribution, codename=None):
            self.platform = platform
            self.distribution = distribution
            self.codename = codename

    class A(object):
        pass

    class B(A):
        platform = 'Linux'
        distribution = None

    class C(B):
        platform = 'Linux'

    class D(C):
        distribution = 'Redhat'

    class E(D):
        codename = 'asdf'

    class F(E):
        codename = 'qwer'


# Generated at 2022-06-20 16:17:43.161732
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test is run on AWS Linux
    codename = get_distribution_codename()
    assert(codename == 'amzn1')

# Generated at 2022-06-20 16:17:48.916618
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test to make sure we're returning the right types of distributions based on the platform
    '''
    assert get_distribution() in [u'Darwin', u'Freebsd', u'Netbsd', u'Openbsd', u'Linux', u'Sunos', u'Aix', u'Hpux']



# Generated at 2022-06-20 16:17:56.682205
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distributions = dict(
        ubuntu_18_04='18.04',
        centos_7='7',
        rhel_7='7.5',
        debian_9='9',
        amazon='2018.03',
        fedora_28='28',
        fedora_29='29',
        sles_15='15',
    )

    for distro_info, expected in distributions.items():
        distribution, version = distro_info.split('_')

        with patch('distro.id', return_value=distribution):
            if distribution == 'amazon':
                with patch('distro.version', return_value=None):
                    with patch('distro.os_release_info', return_value={"VERSION": "2018.03"}):
                        actual = get_distribution_version()

# Generated at 2022-06-20 16:17:57.638376
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-20 16:18:07.709283
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import os
    import stat
    import tempfile

    # Create a base class to use
    class base(object):
        pass

    # Create a subclass of the base class for testing
    class test_class(base):
        platform = 'Linux'
        distribution = 'redhat'

    # Create a subclass of the base class for testing
    class test_class_linux(base):
        platform = 'Linux'
        distribution = None

    # Create a subclass of the base class for testing
    class test_class_other(base):
        platform = 'Windows'
        distribution = None

    # Create a temporary file for testing
    test_file_handle, test_file = tempfile.mkstemp()
    test_file_stat = os.stat(test_file)
    os.close(test_file_handle)

# Generated at 2022-06-20 16:18:23.856158
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Check the get_distribution_version function for expected results

    This test is run on Linux container and the result is checked
    '''
    assert get_distribution_version()

# Generated at 2022-06-20 16:18:36.379192
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        distribution = None
        platform = 'Generic'

    class B(A):
        pass

    class C(A):
        distribution = 'GenericLinux'
        platform = 'Linux'

    class D(C):
        pass

    class E(C):
        distribution = 'GenericLinux2'
        platform = 'Linux'

    # Set subclasses so we can get back to them again
    A.subclasses = tuple(sorted(get_all_subclasses(A), key=lambda x: x.__name__))
    C.subclasses = tuple(sorted(get_all_subclasses(C), key=lambda x: x.__name__))

    # Check the empty case
    assert A == get_platform_subclass(A)

    # Test that we skip classes that don't match the platform

# Generated at 2022-06-20 16:18:37.461135
# Unit test for function get_distribution
def test_get_distribution():

    assert(get_distribution() == u'Redhat')

# Generated at 2022-06-20 16:18:49.193284
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Do basic tests for get_distribution()
    '''
    platform_to_distribution = {
        "Linux": {
            ("Redhat", (7, 4)): "RedHat",
            (None, None): "OtherLinux",
        },
        "OpenBSD": {
            (None, None): None
        },
        "FreeBSD": {
            (None, None): None
        },
        "Darwin": {
            ("Darwin", (16, 5)): "Macosx",
        },
        "SunOS": {
            (None, None): None
        },
    }

    expected = platform_to_distribution[platform.system()]


# Generated at 2022-06-20 16:19:00.737798
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # child classes
    class parent(object):
        platform = 'Linux'

    class child_1(parent):
        distribution = 'Redhat'

    class child_2(parent):
        distribution = 'Debian'

    class child_3(parent):
        distribution = 'OtherLinux'

    class child_4(parent):
        distribution = 'Redhat'
        platform = 'FreeBSD'

    class child_5(parent):
        distribution = None

    class child_6(parent):
        pass

    # set up for test
    this_platform = 'Linux'
    distribution = 'Redhat'

    # set of expected results
    expect_child_1 = True
    expect_child_2 = False
    expect_child_3 = True
    expect_child_4 = False
    expect_child_5 = True
    expect

# Generated at 2022-06-20 16:19:09.477642
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class GenericPlatformClass:
        platform = None
        distribution = None

    class RedHat(GenericPlatformClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class Debian(GenericPlatformClass):
        platform = 'Linux'
        distribution = 'Debian'

    class NotImplemented(GenericPlatformClass):
        platform = 'FreeBSD'
        distribution = 'FreeBSD'

    class Windows(GenericPlatformClass):
        platform = 'Windows'
        distribution = None

    class Darwin(GenericPlatformClass):
        platform = 'Darwin'
        distribution = None

    class AndroidClass(GenericPlatformClass):
        platform = 'Linux'
        distribution = 'Android'

    class ArchLinux(GenericPlatformClass):
        platform = 'Linux'
        distribution = 'Arch'


    assert get_platform_subclass(GenericPlatformClass)

# Generated at 2022-06-20 16:19:12.482684
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    if platform.system() == 'Linux':
        codename = get_distribution_codename()
        assert codename is not None
    else:
        assert get_distribution_codename() == None

# Generated at 2022-06-20 16:19:23.175514
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # Mock class to test get_platform_subclass
    class ParentMockClass:
        platform = 'ABC'
        distribution = None


    class MockClass1(ParentMockClass):
        platform = 'ABC'
        distribution = 'XYZ'

    class MockClass2(ParentMockClass):
        platform = 'ABC'
        distribution = None

    class MockClass3(ParentMockClass):
        platform = 'DEF'
        distribution = 'XYZ'

    class MockClass4(ParentMockClass):
        platform = 'ABC'
        distribution = None

    # get_platform_subclass should return the most specific subclass.
    assert get_platform_subclass(ParentMockClass) == MockClass4

    # If distribution is None, it should return the first class that meets the criteria.

# Generated at 2022-06-20 16:19:30.558351
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Run all of the tests for the get_distribution function.

    This function runs all of the tests for the get_distribution function.
    '''
    # Test Amazon Linux
    distro_info = {
        'distribution': 'Amazon',
        'version': '',
    }
    assert distro_info['distribution'] == get_distribution()
    assert distro_info['version'] == get_distribution_version()
    distro_info = {
        'distribution': 'Amazon',
        'version': '1',
    }
    assert distro_info['distribution'] == get_distribution()
    assert distro_info['version'] == get_distribution_version()

    # Test CentOS

# Generated at 2022-06-20 16:19:32.305731
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version works correctly
    '''
    assert get_distribution_version() is not None



# Generated at 2022-06-20 16:19:58.640792
# Unit test for function get_distribution
def test_get_distribution():
    distro = get_distribution()
    assert distro=='Raspbian'
    distro = get_distribution_version()
    distro = get_distribution_codename()
    print(distro)

test_get_distribution()

# Generated at 2022-06-20 16:20:09.705420
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Note: This test MUST be run on a Linux system and your system release must be in distro.VERSION_CODENAMES for
    #  the test to pass!
    this_platform = platform.system()
    distribution = get_distribution()
    codename = get_distribution_codename()

    class BaseClass:
        platform = None
        distribution = None
        codename = None

    class TestA(BaseClass):
        platform = None
        distribution = 'Redhat'
        codename = None

    class TestB(BaseClass):
        platform = 'Linux'
        distribution = None
        codename = 'unknown'

    class TestC(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'
        codename = 'unknown'

    class TestD(BaseClass):
        platform = 'Linux'


# Generated at 2022-06-20 16:20:19.787336
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the function get_distribution_version
    '''
    distro_list = ['ubuntu', 'debian', 'centos', 'fedora', 'opensuse', 'mageia', 'redhat', 'amazon', 'alpine', 'arch']
    distro_list_2 = ['ubuntu', 'debian']
    distro_list_3 = ['centos', 'fedora', 'opensuse', 'mageia', 'redhat', 'amazon']
    distro_list_4 = ['alpine', 'arch']
    for distro in distro_list:
        if distro in distro_list_2:
            value = get_distribution_version(distro, 'best')
            assert isinstance(value, str)
        elif distro in distro_list_3:
            value = get_distribution_version

# Generated at 2022-06-20 16:20:32.712559
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for function get_distribution
    '''
    import platform
    import sys

    from ansible.module_utils.common._utils import AnsibleModule

    def test_distribution(distribution, version, codename):
        '''
        test that get_distribution() returns the correct distribution when
        run on a Linux system

        :arg distribution: Name of the distribution to test
        '''
        platform_distro_name = distribution
        if platform_distro_name == 'Fedora':
            platform_distro_name = 'Fedora_Unknown'
        if platform_distro_name == 'RedHat':
            platform_distro_name = 'Redhat'
        if platform_distro_name == 'CentOS':
            platform_distro_name = 'Centos'

# Generated at 2022-06-20 16:20:35.368524
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == None

if __name__ == '__main__':
    test_get_distribution_version()

# Generated at 2022-06-20 16:20:44.097576
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible.module_utils.common._utils import get_all_subclasses
    from ansible.module_utils.basic import *
    version = get_distribution_version()
    distribution = get_distribution()
    assert distribution.lower() in ['amzn', 'redhat', 'otherlinux', 'debian', 'suse', 'ubuntu', 'centos']
    if distribution.lower() in [u'centos', u'debian']:
        assert version.lower().split(u'.')[0].isnumeric()
    elif distribution.lower() in [u'amzn', u'redhat', u'otherlinux']:
        assert version.lower().split(u'.')[0].isnumeric()
    elif distribution.lower() in [u'centos', u'debian']:
        assert version.lower().split

# Generated at 2022-06-20 16:20:54.921850
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Tests the function ``get_distribution()``.

    The function ``get_distribution()`` is tested by:
    1.  Calling the function when it is not possible to determine the distribution
    2.  Calling the function for multiple distributions for testing.
    '''

    # setup return values to be used in mocking distro.id()
    return_values = (
        "%s",
        "%s%s",
        "%s%s%s",
        "not-linux",
        None,
    )

    # test when distro.id() returns None
    test_distro = "GenericLinux"
    distro_mock = MagicMock(return_value=None)

# Generated at 2022-06-20 16:21:03.610619
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test that get_platform_subclass selects the right subclass
    '''
    class Base(object):
        ''' Base class to test get_platform_subclass() '''
        distribution = None
        platform = None

        def __init__(self, a, b):
            self.a = a
            self.b = b

    class BaseLinux(Base):
        ''' Base class for Linux '''
        platform = 'Linux'

    class BaseLinuxDistro(BaseLinux):
        ''' Base class for Linux with distribution '''
        def __init__(self, *args, **kwargs):
            self.distribution = get_distribution()
            super(BaseLinuxDistro, self).__init__(*args, **kwargs)

    class ChildLinux(BaseLinux):
        ''' Child class for Linux '''



# Generated at 2022-06-20 16:21:09.677008
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the function get_distribution_version
    '''

# Generated at 2022-06-20 16:21:18.202996
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # unknown distribution
    assert get_distribution_version() == u''

    # centos
    distro.id = lambda: u'centos'
    distro.version = lambda: u'7.3'
    distro.version_best = lambda: u'7.3.1611'
    assert get_distribution_version() == u'7.3'

    # debian
    distro.id = lambda: u'debian'
    distro.version = lambda: u'9'
    distro.version_best = lambda: u'9.0.0'
    assert get_distribution_version() == u'9.0.0'


# Generated at 2022-06-20 16:22:04.991569
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None



# Generated at 2022-06-20 16:22:05.765340
# Unit test for function get_distribution
def test_get_distribution():
    distro.id = lambda: 'centos'
    assert get_distribution() == 'Centos'


# Generated at 2022-06-20 16:22:14.686435
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils

    # To verify that we get a subclass for the platform we're on we'll use the
    # module_utils.basic.AnsibleModule provided by Ansible.
    # We'll make a subclass for each Linux distribution and a generic one for
    # Linux.
    class AnsibleModule(ansible.module_utils.basic.AnsibleModule):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class AnsibleModuleDebian(ansible.module_utils.basic.AnsibleModule):
        platform = 'Linux'
        distribution = 'Debian'

    class AnsibleModuleLinux(ansible.module_utils.basic.AnsibleModule):
        platform = 'Linux'
        distribution = None


# Generated at 2022-06-20 16:22:25.736327
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    verify results of function get_distribution_version

    :rtype: boolean
    :returns: True on success and False on failure
    """

    expected_debian_version = '9.11'
    expected_rhel_version = '7.7'

    # Tested on system with Debian 9.11 and RedHat 7.7
    # A system running something other than Debian or RedHat will fail this test.
    if get_distribution_version() not in [expected_debian_version, expected_rhel_version]:
        return False

    return True


# Generated at 2022-06-20 16:22:37.304158
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Ensure that get_platform_subclass works as intended

    This function serves two purposes:

        - Ensures that the function get_platform_subclass() works as documented
        - Provides examples to the developer of how to use get_platform_subclass()

    .. note:: If you're writing a new module, this is the file where you should start reading the
        source code.
    '''

    # Create BasePlatform, a simple class hierarchy with multiple platforms and multiple distributions
    class BasePlatform:
        distribution = None
        platform = None

    class LinuxBase(BasePlatform):
        platform = 'Linux'

    class LinuxDist1(LinuxBase):
        distribution = 'Dist1'

    class OtherLinuxDist(LinuxBase):
        distribution = 'OtherLinux'

    class LinuxDist2(LinuxBase):
        distribution = 'Dist2'


# Generated at 2022-06-20 16:22:38.990071
# Unit test for function get_distribution
def test_get_distribution():
    # get_distribution should return 'Ubuntu'
    assert get_distribution() == 'Ubuntu'

# Generated at 2022-06-20 16:22:49.464153
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic
    # get_platform_subclass should return the superclass of the platform if
    # one is not explicitly defined.
    assert(get_platform_subclass(ansible.module_utils.basic.AnsibleModule) == ansible.module_utils.basic.AnsibleModule)
    # get_platform_subclass should return the superclass if it defines both
    # platform and distribution
    class AnsibleModuleBoth:
        distribution = get_distribution()
        platform = platform.system()
    assert(get_platform_subclass(AnsibleModuleBoth) == AnsibleModuleBoth)
    # get_platform_subclass should return the superclass if it defines
    # just platform
    class AnsibleModulePlatform:
        distribution = None
        platform = platform.system()

# Generated at 2022-06-20 16:22:53.147912
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """Test for function get_distribution_version"""
    assert get_distribution_version() == '2.7.7'

# Generated at 2022-06-20 16:22:58.299931
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    if platform.system() != 'Linux':
        raise AssertionError('get_distribution_codename test must be run on Linux')

    actual = get_distribution_codename()
    if actual is None:
        raise AssertionError('get_distribution_codename should never return None')

    if actual == '':
        raise AssertionError('get_distribution_codename should never return empty string')



# Generated at 2022-06-20 16:22:59.168237
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() != None

# Generated at 2022-06-20 16:24:31.983262
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert isinstance(distribution, str)



# Generated at 2022-06-20 16:24:41.222163
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Sanity checks for the get_platform_subclass function
    '''
    # This is just a dummy class we can use to test that the function is
    # finding the right subclass.  It is similar to the User class in
    # the Ansible distribution.
    class Dummy:
        platform = None
        distribution = None
        def __init__(self, *args, **kwargs):
            pass

    class SubclassPlatform(Dummy):
        platform = 'Not Linux'

    class SubclassDistribution(Dummy):
        distribution = 'Linux'

    class SubclassPlatformDistribution(Dummy):
        platform = 'Linux'
        distribution = 'SuSE'

    # Test that we find None if the class doesn't have any subclasses
    assert get_platform_subclass(Dummy) == Dummy

    # Test

# Generated at 2022-06-20 16:24:51.510567
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import sys

    class Distro(object):
        def __init__(self, version, version_best, version_parts=None):
            self.version = version
            self.version_best = version_best
            self.version_parts = version_parts

    def test_distro(version, version_best=None, version_parts=None):
        if version_best is None:
            version_best = version
        if version_parts is None:
            version_parts = version.split(u'.')

        # This changes the distro.version() and distro.version_best()
        # to return the values in our version, version_best and version_parts
        # variables.  It keeps the rest of the distro module as it was in
        # the distributions we are testing.

# Generated at 2022-06-20 16:24:52.835523
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == "13.2"

# Generated at 2022-06-20 16:24:54.142455
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None


# Generated at 2022-06-20 16:24:56.060859
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat', "get_distribution() is testing for Redhat rather than for centos"

# Generated at 2022-06-20 16:25:00.226863
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    ''' If we are running under Linux, on a supported distribution, check we return
        the correct code name.  If unsupported, return None.
    '''
    if platform.system() == 'Linux':
        return get_distribution_codename() == distro.codename()
    else:
        return get_distribution_codename() == None

# Generated at 2022-06-20 16:25:05.971417
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None, \
        "Codename for %s should be None" % (platform.system())

    if platform.system() == 'Linux':
        # This is the correct codename for Ubuntu Trusty Tahr
        assert get_distribution_codename() == 'trusty', \
            "Codename for Ubuntu %s should be 'trusty'" % (get_distribution_version())



# Generated at 2022-06-20 16:25:18.353859
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # CentOS 7.3.1611
    centos_os_release_dict = {
        "NAME": "CentOS Linux",
        "VERSION": "7 (Core)",
        "ID": "centos",
        "ID_LIKE": "rhel fedora",
        "VERSION_ID": "7",
        "PRETTY_NAME": "CentOS Linux 7 (Core)",
        "ANSI_COLOR": "0;31",
        "CPE_NAME": "cpe:/o:centos:centos:7",
        "HOME_URL": "https://www.centos.org/",
        "BUG_REPORT_URL": "https://bugs.centos.org/",
    }
    assert_version = "7.3.1611"
    distribution = "CentOS"
