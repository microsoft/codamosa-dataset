

# Generated at 2022-06-22 22:01:44.010226
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-22 22:01:45.914017
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is None


# Unit tests for get_distribution_version

# Generated at 2022-06-22 22:01:47.813993
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() in ('Freebsd', 'Linux', 'Openbsd')

# Generated at 2022-06-22 22:01:49.270738
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'

# Generated at 2022-06-22 22:01:51.979814
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test that get_distribution_version() gives us the version
    '''
    assert get_distribution_version()

# Generated at 2022-06-22 22:01:53.234250
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-22 22:02:00.796808
# Unit test for function get_distribution
def test_get_distribution():
    test_distros = {
        'centos': 'Centos',
        'debian': 'Debian',
        'fedora': 'Fedora',
        'mandrake': 'Mandrake',
        'mageia': 'Mageia',
        'mandriva': 'Mandrake',
        'mint': 'Mint',
        'opensuse': 'Suse',
        'sles': 'Suse',
        'suse': 'Suse',
        'ubuntu': 'Ubuntu',
        'redhat': 'Redhat',
        'amzn': 'Amazon',
        'rhel': 'Redhat',
    }
    for test_distro, expected_distro in test_distros.items():
        assert get_distribution() == expected_distro

# Generated at 2022-06-22 22:02:04.269060
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    get_distribution_codename function return valid codename from linux distro
    '''

    distro_id = 'LinuxMint'
    codename = 'tara'

    os_release_info = {
        'version_codename': codename
    }

    assert distro.get_distribution_codename(os_release_info, distro_id) == codename

# Generated at 2022-06-22 22:02:16.557236
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Platform:
        platform = "Linux"

    class PlatformChild(Platform):
            platform = "Linux"

    class PlatformGrandChild(PlatformChild):
            platform = "Linux"

    class PlatformDistro(Platform):
        platform = "Linux"
        distribution = "CentOS"

    class PlatformDistroChild(PlatformDistro):
        platform = "Linux"
        distribution = "CentOS"

    assert get_platform_subclass(Platform) == Platform
    assert get_platform_subclass(PlatformChild) == PlatformChild
    assert get_platform_subclass(PlatformGrandChild) == PlatformGrandChild
    assert get_platform_subclass(PlatformDistro) == PlatformDistro
    assert get_platform_subclass(PlatformDistroChild) == PlatformDistroChild


# Generated at 2022-06-22 22:02:27.906233
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'

    class BaseLinux(Base):
        platform = 'Linux'

    class RHELSubclass(BaseLinux):
        distribution = 'RedHat'

    class OtherLinuxSubclass(BaseLinux):
        distribution = 'OtherLinux'

    class WindowsSubclass(Base):
        platform = 'Windows'
        distribution = None

    class SolarisSubclass(Base):
        platform = 'Solaris'
        distribution = None

    class SpecializedSolarisSubclass(SolarisSubclass):
        distribution = 'Oracle'

    # Generic Debian Linux
    assert get_platform_subclass(BaseLinux) is BaseLinux
    # Generic Windows
    assert get_platform_subclass(WindowsSubclass) is WindowsSubclass
    # Generic Solaris
    assert get_platform_subclass(SolarisSubclass) is Solaris

# Generated at 2022-06-22 22:02:37.819680
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible_collections.testns.testcoll.plugins.module_utils import os_family_impl

    class Myclass(object):
        pass

    class LinuxImpl(os_family_impl.Debian):
        _distribution = "Linux"
        _platform = "Linux"

    class LinuxOtherImpl(os_family_impl.Debian):
        _distribution = None
        _platform = "Linux"

    class SuseImpl(os_family_impl.Debian):
        _distribution = "Suse"
        _platform = "Linux"

    class RhImpl(os_family_impl.Debian):
        _distribution = "Redhat"
        _platform = "Linux"

    class CentosImpl(os_family_impl.Debian):
        _distribution = "Centos"

# Generated at 2022-06-22 22:02:45.370323
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.common.collections import ImmutableDict

    # Red Hat / CentOS
    redhat_codename = get_distribution_codename()
    assert redhat_codename == None

    # Debian
    debian_codename = get_distribution_codename()
    assert debian_codename == None

    # Ubuntu
    ubuntu_codename = get_distribution_codename()
    assert ubuntu_codename == None

    # Fedora
    fedora_codename = get_distribution_codename()
    assert fedora_codename == None

# Generated at 2022-06-22 22:02:47.869560
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial' or get_distribution_codename() is None


# Generated at 2022-06-22 22:02:59.781048
# Unit test for function get_distribution_codename

# Generated at 2022-06-22 22:03:05.530317
# Unit test for function get_distribution
def test_get_distribution():
    # Test case 1: the distro is not Linux
    distribution = get_distribution()
    if platform.system() == 'Linux':
        assert distribution == 'Amazon' or distribution == 'Centos' or distribution == 'Debian' or distribution == 'Fedora' or distribution == 'Redhat' or distribution == 'Ubuntu' or distribution == 'OtherLinux'
    else:
        assert distribution == None


# Generated at 2022-06-22 22:03:16.868213
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = "PlatformA"
    class BaseA:
        platform = "PlatformA"
    class BaseB:
        platform = "PlatformB"
    class BaseA1(BaseA):
        pass
    class BaseA11(BaseA1):
        pass
    class BaseA12(BaseA1):
        pass
    class BaseB1(BaseB):
        pass
    class BaseB2(BaseB):
        pass
    class A(Base):
        pass
    class A1(A):
        pass
    class A11(A1):
        pass
    class A12(A1):
        pass
    class A2(A):
        pass
    class A21(A2):
        pass
    class A211(A21):
        pass
    class A212(A21):
        pass

# Generated at 2022-06-22 22:03:27.998419
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Test get_platform_subclass function
    """
    class BaseClass:
        platform = 'Darwin'
        distribution = None
    class OtherBaseClass(BaseClass):
        pass

    class OtherPlatformClass:
        platform = 'Linux'
        distribution = None
    class OtherOtherPlatformClass(OtherPlatformClass):
        pass

    class SpecificPlatformClass(OtherPlatformClass):
        platform = 'Linux'
        distribution = 'OtherLinux'
    class MoreSpecificPlatformClass(SpecificPlatformClass):
        distribution = 'CentOS'
    class MostSpecificPlatformClass(MoreSpecificPlatformClass):
        distribution = 'CentOS'
        version = '7'

    class UnixLikePlatformClass:
        platform = 'AIX'
        distribution = None
    class OtherUnixLikePlatformClass(UnixLikePlatformClass):
        pass


# Generated at 2022-06-22 22:03:28.966863
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-22 22:03:36.795196
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test to check the value returned by get_distribution_codename
    is as expected.

    :returns: True if get_distribution_codename returns the expected value else False.
    '''

    test_distribution_codename = get_distribution_codename()

    if test_distribution_codename == 'xenial':
        return True
    else:
        return False

# Generated at 2022-06-22 22:03:40.126767
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Centos'
    assert get_distribution_version() == '7.4.1708'
    assert get_distribution_codename() == 'Core'


# Generated at 2022-06-22 22:03:49.801451
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    class BaseClass(object):
        pass

    class OtherLinux(BaseClass):
        platform = 'Linux'
        distribution = None

    class OtherLinuxDistro(BaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class ThisLinuxDistro(BaseClass):
        platform = 'Linux'
        distribution = 'CentOS'

    class ThisLinuxDistroSubclass(BaseClass):
        platform = 'Linux'
        distribution = 'CentOS'

    class OtherPlatformClass(BaseClass):
        platform = 'Other'
        distribution = None

    # Make these available to the globals() dict
    global BaseClass, OtherLinux, OtherLinuxDistro, ThisLinuxDistro, ThisLinuxDistroSub

# Generated at 2022-06-22 22:04:00.339121
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import platform
    from ansible.module_utils.common.os import get_distribution, get_distribution_version

    this_platform = platform.system()
    distribution = get_distribution()
    version = None

    if distribution is not None:
        if this_platform == 'Linux':
            if distribution == 'Amazon':
                version = '2'
            elif distribution == 'Debian':
                version = '10'
            elif distribution == 'Redhat':
                version = '7.6'
            elif distribution == 'Ubuntu':
                version = '18.04'
            elif distribution == 'Alpine':
                version = '3.9'
            else:
                version = '0'
        elif this_platform == 'Darwin':
            version = '10.9.5'

# Generated at 2022-06-22 22:04:12.166830
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest2 as unittest

    class BaseClass(object):
        platform = 'Linux'
        distribution = None

    class BaseSubClass(BaseClass):
        pass

    class PlatformSubClass(BaseClass):
        platform = 'Linux'
        distribution = 'Centos'

    class OtherPlatformSubClass(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class PlatformOtherDistributionSubClass(BaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class NonLinuxSubClass(BaseClass):
        platform = 'FreeBSD'
        distribution = None

    # Test case: BaseClass
    class TestBaseClass(unittest.TestCase):
        """Test for the base class"""


# Generated at 2022-06-22 22:04:23.628795
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.common.user

    # Test normal path when subclass is found
    assert ansible.module_utils.common.user.UserLinux.__name__ == get_platform_subclass(ansible.module_utils.common.user.User).__name__
    assert ansible.module_utils.common.user.UserLinux.__name__ == get_platform_subclass(ansible.module_utils.common.user.UserLinux).__name__

    # Test no subclass found path
    assert ansible.module_utils.common.user.User.__name__ == get_platform_subclass(ansible.module_utils.common.user.User).__name__

# Generated at 2022-06-22 22:04:34.259864
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the get_distribution_version function.
    '''
    distributions = (
        (u'centos', u'7.6.1810'),
        (u'debian', u'9.12'),
        (u'fedora', u'28'),
        (u'ubuntu', u'16.04'),
    )

    for (distro_id, distro_version) in distributions:

        with patch('ansible.module_utils.distro.id', return_value=distro_id),\
                patch('ansible.module_utils.distro.version', return_value=distro_version):
            version = get_distribution_version()
            assert version == distro_version

# Generated at 2022-06-22 22:04:36.468548
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert distribution is not None, "distribution cannot be None"


# Generated at 2022-06-22 22:04:48.684034
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseLinux:
        platform = 'Linux'
        distribution = None

    class RedHat(BaseLinux):
        distribution = 'RedHat'

    class Centos(RedHat):
        distribution = 'Centos'

    class Debian(BaseLinux):
        distribution = 'Debian'

    class Ubuntu(Debian):
        distribution = 'Ubuntu'

    class UbuntuXenial(Ubuntu):
        distribution_version = '16.04'

    class Amzn(RedHat):
        distribution = 'Amzn'

    class User:
        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(User)
            return super(cls, new_cls).__new__(new_cls)

    assert get_platform_subclass(User) == User


# Generated at 2022-06-22 22:04:59.110560
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Ansible doesn't run the code inside this function.  You can run these tests against your code
    using the pytest library.  It needs to be installed with ``pip install pytest``.  You can
    then run tests with the ``pytest`` command.
    '''


# Generated at 2022-06-22 22:05:03.224949
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test for a regression bug in get_distribution_version where it would return
    None for versions with only one number.
    '''
    assert get_distribution_version() is not None

# Generated at 2022-06-22 22:05:04.149127
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-22 22:05:13.742591
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    test function get_platform_subclass
    '''
    class Base(object):
        '''
        base class
        '''
        pass

    class Test(object):
        '''
        Test class
        '''
        platform = 'Linux'
        distribution = None

    class Test1(Test):
        '''
        Test class 1
        '''
        platform = 'Linux'
        distribution = 'Redhat'

    class Test2(Test):
        '''
        Test class 2
        '''
        platform = 'Linux'
        distribution = 'Debian'

    class Test3(Test):
        '''
        Test class 3
        '''
        platform = 'Linux'
        distribution = 'Redhat'
        version = '6.1'


# Generated at 2022-06-22 22:05:23.652171
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # Some non-platform-specific class
    class A:
        pass

    # Platform Non-specific subclass of A
    class B(A):
        pass

    # Distro-specific subclass of B
    class C(B):
        distribution = 'Ubuntu'
    class D(B):
        distribution = 'Centos'


    # Distro-specific subclass of A
    class E(A):
        distribution = 'Ubuntu'

    # Platform-specific subclass of A
    class F(A):
        platform = 'Darwin'

    # Tests

    # Test generic class
    assert A == get_platform_subclass(A)

    # Basic subclass test
    assert B == get_platform_subclass(B)

    # Test choosing between distro subclasses
    assert C == get_platform_subclass(C)
    assert C

# Generated at 2022-06-22 22:05:28.462842
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test for function get_distribution_codename

    :returns: None
    '''
    assert get_distribution_codename() == None
    assert get_distribution_codename() == 'bionic'
    assert get_distribution_codename() == 'bionic'

# Generated at 2022-06-22 22:05:30.186708
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'


# Generated at 2022-06-22 22:05:39.676163
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base(object):
        pass
    class Subclass(Base):
        platform = 'Linux'
    class OtherLinux(Base):
        platform = 'Linux'
        distribution = 'OtherLinux'
    class OtherSubclass(Base):
        platform = 'Windows'
    class OtherSubclassNoPlatform(Base):
        pass

    assert get_platform_subclass(Base) is Base
    assert get_platform_subclass(Subclass) is Subclass
    assert get_platform_subclass(OtherLinux) is OtherLinux
    assert get_platform_subclass(OtherSubclass) is OtherSubclass
    assert get_platform_subclass(OtherSubclassNoPlatform) is OtherSubclassNoPlatform


# Generated at 2022-06-22 22:05:44.873685
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        platform = 'FreeBSD'
        distribution = 'FreeBSD'

    class B(A):
        pass

    class C(B):
        platform = 'Darwin'

    assert get_platform_subclass(A) is A
    assert get_platform_subclass(B) is B
    assert get_platform_subclass(C) is C

# Generated at 2022-06-22 22:05:53.069862
# Unit test for function get_distribution
def test_get_distribution():
    distributions = (
        'Redhat',
        'Amazon',
        'OtherLinux',
        'Ubuntu',
        'Debian',
        'Archlinux',
        'Alpine',
        'Fedora',
        'Centos',
        'Suselinux',
        'OpenSUSE',
        'Freebsd',
        'Openbsd',
        'Solaris',
        'Macosx',
        'Netbsd',
        'Smartos',
    )
    assert get_distribution() in distributions


# Generated at 2022-06-22 22:05:54.429370
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert distribution



# Generated at 2022-06-22 22:05:57.803728
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Used to test the get_distribution function
    '''
    assert get_distribution() == 'Redhat'
    assert get_distribution_version() == '7.6'
    assert get_distribution_codename() == 'Maipo'

# Generated at 2022-06-22 22:06:01.250729
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distribution_version = get_distribution_version()
    if distribution_version is None:
        assert True
    else:
        assert distribution_version.__class__.__name__ == 'str'


# Generated at 2022-06-22 22:06:02.218670
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Darwin'

# Generated at 2022-06-22 22:06:07.654268
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    :rtype: Tuple[NativeString, NativeString]
    :returns: Tuple of codename and boolean result of test
    '''
    codename = get_distribution_codename()
    if codename is None:
        codename = 'None'

    return (codename, codename == 'xenial')

# Generated at 2022-06-22 22:06:17.896118
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # a class with a linux subclass, a linux subclass with a subclass for distro fedora, and a generic subclass
    class Test1(object):
        platform = None
        distribution = None

    class Test1Linux(Test1):
        platform = 'Linux'
        distribution = None

    class Test1LinuxFedora(Test1Linux):
        distribution = 'Fedora'

    class Test1Generic(Test1):
        platform = 'Generic'

    class Test2(object):
        platform = None
        distribution = None

    class Test2Linux(Test2):
        platform = 'Linux'
        distribution = None

    class Test2Generic(Test2):
        platform = 'Generic'

    assert get_platform_subclass(Test1) == Test1LinuxFedora, 'get_platform_subclass() did not return the most specific subclass'

# Generated at 2022-06-22 22:06:18.812671
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '10.0'

# Generated at 2022-06-22 22:06:24.585986
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()

    if 'AMAZON' in platform.platform():
        assert distribution == 'Amazon'

    elif 'Ubuntu' in platform.platform():
        assert distribution == 'Ubuntu'

    elif 'blackPanther' in platform.platform():
        assert distribution == 'Blackpanther'

    elif 'centos' in platform.platform():
        assert distribution == 'Centos'

# Generated at 2022-06-22 22:06:36.520049
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class SuperSuperClass(object):
        distribution = None
        platform = "Linux"

    class SuperClass(SuperSuperClass):
        distribution = None
        platform = "Linux"

    class ThisPlatform(SuperClass):
        distribution = None
        platform = "Linux"

    class ThisDistribution(SuperClass):
        distribution = "Linux"
        platform = None

    class BadSubclass(SuperClass):
        distribution = "Windows"
        platform = "Linux"

    class PerfectClass(SuperClass):
        distribution = "Linux"
        platform = "Linux"

    class PerfectClass2(SuperClass):
        distribution = "Linux"
        platform = "Linux"

    class PerfectClass3(SuperClass):
        distribution = "Linux"
        platform = "Linux"

    class SubClass(SuperClass):
        distribution = None
        platform = None

# Generated at 2022-06-22 22:06:46.221343
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test get_distribution_codename to make sure it returns the correct
    codename for known distributions

    :returns: True if the test passes. Otherwise an exception is raised.
    '''
    import os
    import sys

    class FakeDistro(distro.LinuxDistribution):
        def __init__(self, *args, **kwargs):
            # We have to turn __init__ into a no-op so we can manipulate
            # the _distro_cache dict and make our own values
            pass


# Generated at 2022-06-22 22:06:47.584541
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-22 22:06:51.079885
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test get_distribution function
    '''
    assert get_distribution() == u'OtherLinux'
    assert get_distribution_codename() is None


# Generated at 2022-06-22 22:07:02.960163
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    def test(expected_codename, platform_system, distro_id, os_release):
        assert distro.get_distribution_codename(platform_system, distro_id, os_release) == expected_codename

    test(None, u'Linux', u'', {})
    test(u'jessie', u'Linux', u'Debian', {u'VERSION_ID': u'8', u'VERSION': u'8 (jessie)', u'NAME': u'Debian GNU/Linux'})
    test(None, u'Linux', u'Debian', {u'VERSION_ID': u'8', u'VERSION': u'8 (jessie)', })
    test(u'jessie', u'Linux', u'Debian', {u'VERSION_ID': u'8', })
    test

# Generated at 2022-06-22 22:07:07.479111
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test to get the codename of the distribution
    '''

    codename = get_distribution_codename()

    if codename is not None:
        print("The codename is: %s" % codename)
    else:
        print("Not able to get the codename for this distribution")

# Generated at 2022-06-22 22:07:15.817100
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    # Fedora
    assert 'Twenty Six' == get_distribution_codename()

    # Ubuntu
    assert 'xenial' == get_distribution_codename()

    # Debian
    assert 'stretch' == get_distribution_codename()

    # CentOS
    assert 'Final' == get_distribution_codename()

    # RHEL
    assert get_distribution_codename() == 'Final'

    # Oracle
    assert 'Final' == get_distribution_codename()

    # Suse
    assert 'Leap' == get_distribution_codename()

    # AIX
    assert get_distribution_codename() == None

# Generated at 2022-06-22 22:07:25.279937
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    from ansible.module_utils.basic import get_distribution_codename

    class MockDistro:
        ''' Class to mock distro methods for unit test '''
        @staticmethod
        def id():
            '''
            Mock method to return distro name
            '''
            return 'ubuntu'

        @staticmethod
        def os_release_info():
            '''
            Mock method to return distro name
            '''
            return {'version_codename': 'xenial'}

        @staticmethod
        def lsb_release_info():
            '''
            Mock method to return distro name
            '''
            return {'codename': 'xenial'}


# Generated at 2022-06-22 22:07:26.862152
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None


# Generated at 2022-06-22 22:07:31.623482
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Linux:
        platform = 'Linux'
        distribution = None

    class OtherLinux(Linux):
        distribution = 'OtherLinux'

    class RedHat(Linux):
        distribution = 'Redhat'

    class Fedora(RedHat):
        distribution_version = 'Fedora'

    class CentOS(RedHat):
        distribution_version = 'CentOS'

    class Solaris:
        platform = 'SunOS'
        distribution = None

    class LinuxUser(Linux):
        pass

    class OtherLinuxUser(OtherLinux):
        pass

    class RedHatUser(RedHat):
        pass

    class FedoraUser(Fedora):
        pass

    class CentOSUser(CentOS):
        pass

    class SolarisUser(Solaris):
        pass

    #
    # Test for getting Linux / Redhat / whatever
    #
    assert get

# Generated at 2022-06-22 22:07:33.310192
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename == None or isinstance(codename, unicode)

# Generated at 2022-06-22 22:07:46.569561
# Unit test for function get_distribution_codename

# Generated at 2022-06-22 22:07:47.872809
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() != None  # the OS variable should never be None

# Generated at 2022-06-22 22:07:59.352219
# Unit test for function get_distribution_version
def test_get_distribution_version():

    old_platform = platform.system()
    old_distro_id = distro.id()
    old_distro_version = distro.version()
    old_distro_version_best = distro.version(best=True)
    old_os_release_info = distro.os_release_info()
    old_lsb_release_info = distro.lsb_release_info()

    class FakeDistroModule:  # pylint: disable=too-few-public-methods
        def __init__(self, id_, version_, version_best_):
            self.id_ = id_
            self.version_ = version_
            self.version_best_ = version_best_

        def id(self):
            return self.id_


# Generated at 2022-06-22 22:08:11.013384
# Unit test for function get_distribution
def test_get_distribution():
    import unittest
    import os
    class GetDistributionTestCase(unittest.TestCase):

        def setUp(self):
            os.environ['FAKE_UNAME'] = 'Linux'
            os.environ['FAKE_LSB_RELEASE'] = '[Ubuntu:12.04:precise]'

# Generated at 2022-06-22 22:08:14.153591
# Unit test for function get_distribution_version
def test_get_distribution_version():

    if platform.system() == 'Linux':
        assert(get_distribution_version() is not None)
    else:
        assert(get_distribution_version() is None)

# Generated at 2022-06-22 22:08:23.391976
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    class MockDistro:
        @classmethod
        def id(cls):
            return 'testdist'

        @classmethod
        def codename(cls):
            return 'testcodename'

        @classmethod
        def os_release_info(cls):
            return {
                'version_codename': 'testosrelease',
                'ubuntu_codename': 'testubuntu'
            }

        @classmethod
        def lsb_release_info(cls):
            return {
                'codename': 'testlsbrelease'
            }

    orig_distro = distro

# Generated at 2022-06-22 22:08:35.140897
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    class Base:
        platform = None
        distribution = None

        def __init__(self, module):
            self.module = module

    class Linux1(Base):
        platform = 'Linux'
        distribution = None

    class Linux2(Base):
        platform = 'Linux'
        distribution = None

    class Linux3(Base):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class Linux4(Base):
        platform = 'Linux'
        distribution = 'Redhat'

    class Linux5(Base):
        platform = 'Linux'
        distribution = 'Fedora'

    class Linux6(Base):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class Linux7(Base):
        platform = 'Linux'

# Generated at 2022-06-22 22:08:44.618224
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    UnitTest for function get_distribution_version from module_utils.distro.
    It test the following cases:
        - test for centos_linux with best=True
        - test for centos_linux with best=False
        - test for debian linux
        - test for ubuntu
    :rtype: bool
    '''

    # test for centos_linux with best=True
    distro.id = lambda: u'centos'
    distro.version = lambda best=True: u'7.5.1804'
    distro.version_best = distro.version
    if '7.5' != get_distribution_version():
        return False
    # test for centos_linux with best=False
    distro.version = lambda best=True: u'7.5.1804'
   

# Generated at 2022-06-22 22:08:56.529013
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test a CentOS 7 host
    dist_v_test = u'7.2.1511'
    distro.id = lambda: u'centos'
    distro.version = lambda best=True: dist_v_test
    assert(dist_v_test == get_distribution_version())

    # Test a Debian 8 host
    dist_v_test = u'8'
    distro.id = lambda: u'debian'
    distro.version = lambda: dist_v_test
    distro.version_best = lambda: dist_v_test
    assert(dist_v_test == get_distribution_version())

    # Test a Debian 8 host with a newer version of distro
    dist_v_test_1 = u'8'
    dist_v_test_2 = u'8.11'


# Generated at 2022-06-22 22:09:07.429778
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        """
        Example base class
        """
        platform = 'Windows'
        distribution = None

    class B(A):
        """
        Subclass for windows
        """
        distribution = 'Windows'

    class C(A):
        """
        Subclass for all platforms
        """
        platform = None
        distribution = None

    class D(A):
        """
        Subclass for all platforms except windows
        """
        platform = None
        distribution = 'OtherLinux'

    assert get_platform_subclass(A) == C, 'Expected get_platform_subclass(A) == C, got %s' % get_platform_subclass(A)

# Generated at 2022-06-22 22:09:13.399498
# Unit test for function get_distribution_version
def test_get_distribution_version():
    def test_distro_version(distro_id, version):
        assert get_distribution_version(distro_id, version)[0] == version

    def test_distro_version_best(distro_id, version, version_best):
        assert get_distribution_version(distro_id, version, version_best)[0] == version_best

    test_distro_version('Ubuntu', '16.04')
    test_distro_version('CentOS Linux', '7.5.1804')

    test_distro_version_best('Ubuntu', '16.04.3 LTS', '16.04')
    test_distro_version_best('CentOS Linux', '7.5.1804', '7.5')

# Generated at 2022-06-22 22:09:23.636504
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic
    class A:
        platform = 'A'
        distribution = None
    class B(A):
        platform = None
        distribution = 'B'
    class C(B):
        platform = 'C'
        distribution = None
    class D(C):
        platform = 'C'
        distribution = 'D'
    class E(C):
        platform = None
        distribution = 'E'
    class F(E):
        platform = 'F'
        distribution = None
    class G(F):
        platform = 'F'
        distribution = 'G'
    # Test that each platform goes to the correct subclass
    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == B
    assert get_platform_subclass(C) == C

# Generated at 2022-06-22 22:09:24.498451
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'OtherLinux'

# Generated at 2022-06-22 22:09:31.350635
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test passing parameters as None
    assert get_platform_subclass(None) is None

    # Test successful lookup
    class A:
        platform = 'Linux'
        distribution = 'Redhat'

    class B(A):
        pass

    assert B == get_platform_subclass(A)

    # Test successful lookup for class A
    assert A == get_platform_subclass(A)

    # Test successful lookup for the highest inherited platform class
    class C(B):
        pass

    assert C == get_platform_subclass(A)

    # Test unsuccessful lookup
    class D:
        platform = 'Linux'
        distribution = 'Redhat'

    class E(D):
        pass

    assert D == get_platform_subclass(E)

# Generated at 2022-06-22 22:09:38.528634
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Assert that get_distribution_version() returns what we expect

    This is a separate function from the test for the same name in ``lib_utils`` so that we
    can import this function directly.  That way we avoid import loops between the ``system``
    and ``common`` modules.
    '''
    # FIXME: Need to find a mock that can set the distro to return the data we expect.  When we
    # do so, we should run this test against a variety of platforms.
    assert get_distribution_version() in ('', None)

# Generated at 2022-06-22 22:09:42.655165
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the return of the function get_distribution_version()
    :returns: true if the function works as expected
    '''
    # Test for Linux systems (case: Debian)
    assert get_distribution_version() == '8'
    # Test for Mac OS systems (case: Mojave)
    assert get_distribution_version() == None

# Generated at 2022-06-22 22:09:54.094533
# Unit test for function get_distribution_version

# Generated at 2022-06-22 22:09:58.786313
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test CentOS
    assert get_distribution_version() == "7.6.1810"

    # Test Debian
    assert get_distribution_version() == "9"

    # Test Ubuntu
    assert get_distribution_version() == "16.04"

# Generated at 2022-06-22 22:10:07.545682
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Implentation of a fake module
    class FooModule():
        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(FooModule)
            return super(FooModule, new_cls).__new__(new_cls)

    class FooModuleGeneric():
        platform = 'Generic'

    class FooModuleLinux(FooModuleGeneric):
        platform = 'Linux'

    class FooModuleCentos(FooModuleLinux):
        distribution = 'Centos'

    class FooModuleWindows(FooModuleGeneric):
        platform = 'Windows'

    # Testing with the fake module
    assert(FooModule().__class__ == FooModuleGeneric)
    assert(FooModuleLinux().__class__ == FooModuleLinux)

# Generated at 2022-06-22 22:10:11.496657
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() in ['Linux', 'Freebsd', 'Openbsd', 'Netbsd', 'Darwin', 'Sunos', 'Aix']
    assert get_distribution_version() == platform.release()

# Generated at 2022-06-22 22:10:13.011710
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-22 22:10:24.768568
# Unit test for function get_distribution
def test_get_distribution():
    try:
        distro_mock = __import__('distro_mock')
    except ImportError:
        distro_mock = None

    if distro_mock:
        # Make sure we get the expected result with various Linux distributions
        distro_mock.distro_mock = ['redhat', 'centos', 'fedora', 'debian', 'ubuntu', 'mint', 'amazon', 'arch', 'mageia', 'meego', 'opensuse']
        for distro in distro_mock.distro_mock:
            distro_mock.id = distro
            distribution = get_distribution()
            assert distribution.lower() == distro or (distribution.lower() == 'otherlinux' and distro in ['arch', 'mageia', 'meego', 'opensuse'])

        # Test

# Generated at 2022-06-22 22:10:27.071473
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == u'trusty'

# Generated at 2022-06-22 22:10:29.100948
# Unit test for function get_distribution
def test_get_distribution():
    # distribution should have a None value on OS other than Linux
    assert get_distribution() is None


# Generated at 2022-06-22 22:10:42.250423
# Unit test for function get_distribution
def test_get_distribution():
    import platform

    def reset_platform_system(sys):
        # This code is to solve a chicken-egg-problem with mocking platform.system().
        # We need to mock platform.system() because we don't want to run this test on a
        # system that returns something unexpected.  But we don't know what platform.system()
        # returns until we run this test.  So we have to put in a special case for the test.
        # And we can't put in a special case for the test until we know what platform.system()
        # returns.  So we have to solve the chicken-egg-problem.

        platform.linux_distribution = orig_linux_distribution
        platform.system = orig_system

        if sys == 'Linux':
            platform.linux_distribution = lambda: ('', '', '')
        else:
            platform.system

# Generated at 2022-06-22 22:10:54.979135
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class A:
        pass
    class B(A):
        pass
    class C(B):
        pass

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == B
    assert get_platform_subclass(C) == C

    class D(B):
        pass
    class E(B):
        pass
    class F(B):
        pass

    assert get_platform_subclass(D) == D
    assert get_platform_subclass(E) == E
    assert get_platform_subclass(F) == F

    class G(E):
        pass
    class H(E):
        pass

    assert get_platform_subclass(G) == G
    assert get

# Generated at 2022-06-22 22:11:01.328360
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    dist_info = {
        "name": "Amazon Linux AMI",
        "version_codename": None,
        "id": "amzn",
        "version": "2018.03",
        "version_id": "2018.03",
        "pretty_name": "Amazon Linux AMI 2018.03",
        "ubuntu_codename": None
    }

    distro.info = lambda: dist_info
    assert get_distribution_codename() is None
    # negative testing
    assert get_distribution_codename() is not "fuchsia"

# Generated at 2022-06-22 22:11:04.659499
# Unit test for function get_distribution_version
def test_get_distribution_version():
    try:
        import distro
        distro_version = distro.version()
    except ImportError:
        distro_version = None
    version = get_distribution_version()
    assert version == distro_version

# Generated at 2022-06-22 22:11:11.281935
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Basic sanity test for function ``get_platform_subclass``

    This test is not exhaustive.  We're really looking for the the function to operate
    rather than testing if it will select the right subclass.  We let the unit tests for
    the subclasses test that they are selected correctly.
    '''

    # TODO: Once the test code is ported to use the new unit test structure we can just
    # set these up inside the class.  We include them here so that we don't have to
    # change all the uses of this test in existing modules until after the port.
    for sc in get_all_subclasses(Basic):
        sc.platform = 'This Platform does not exist'
        sc.distribution = None

    # TEST 1: Should always return the base class when there's no subclass
    assert get_platform_subclass(Basic)

# Generated at 2022-06-22 22:11:13.232432
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == ''

# Generated at 2022-06-22 22:11:21.189244
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class BaseClass(object):
        platform = 'BasePlatform'
        distribution = None

    class Platform1(BaseClass):
        platform = 'Platform1'

    class Platform2(BaseClass):
        platform = 'Platform2'

    class Distribution1(Platform1):
        distribution = 'Distribution1'

    class Distribution2(Platform1):
        distribution = 'Distribution2'

    class Distribution3(Platform2):
        distribution = 'Distribution3'

    class Distribution4(Platform2):
        distribution = 'Distribution4'

    class Distribution5(Platform2):
        distribution = 'Distribution5'

    class Distribution5_5(Distribution5):
        distribution = 'Distribution5.5'


# Generated at 2022-06-22 22:11:33.987060
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Verify that get_platform_subclass can select appropriate subclasses
    '''

    class Base:
        pass

    class PlatformBase(Base):
        platform = "Linux"
        distribution = None

    class PlatformSubclass(PlatformBase):
        distribution = "Fedora"

    class DistroBase(Base):
        platform = None
        distribution = "Fedora"

    class DistroSubclass(DistroBase):
        platform = "Linux"

    assert get_platform_subclass(Base).__name__ == "Base"
    assert get_platform_subclass(PlatformBase).__name__ == "PlatformBase"
    assert get_platform_subclass(PlatformSubclass).__name__ == "PlatformSubclass"
    assert get_platform_subclass(DistroBase).__name__ == "DistroBase"
    assert get

# Generated at 2022-06-22 22:11:34.690380
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-22 22:11:43.912299
# Unit test for function get_distribution_version
def test_get_distribution_version():
    platform_distro_map = {
        u'alpine': u'3.8',
        u'centos': u'7.8.2003',
        u'debian': u'9',
        u'fedora': u'32',
        u'oracle': u'7.5',
        u'suse': u'15',
        u'ubuntu': u'16.04',
        u'unknown': u'0.0',
    }
