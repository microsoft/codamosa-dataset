

# Generated at 2022-06-22 22:01:44.052190
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == u'7.5'


# Generated at 2022-06-22 22:01:55.149962
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Test if get_platform_subclass returns the correct value
    """
    class PlatformTest(object):
        platform = None
        distribution = None
    class UnixTest1(PlatformTest):
        platform = 'Unix'
        distribution = 'SunOS'
    class UnixTest2(PlatformTest):
        platform = 'Unix'
    class LinuxTest1(PlatformTest):
        platform = 'Linux'
        distribution = 'Debian'
    class LinuxTest2(PlatformTest):
        platform = 'Linux'
        distribution = 'Redhat'
    class LinuxTest3(PlatformTest):
        platform = 'Linux'

    assert get_platform_subclass(PlatformTest) == PlatformTest
    assert get_platform_subclass(UnixTest1) == UnixTest1
    assert get_platform_subclass(UnixTest2) == UnixTest2


# Generated at 2022-06-22 22:01:58.246176
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Simple unittest for function get_distribution_codename.
    '''
    codename = get_distribution_codename()
    print("Codename of host's distro is %s" % codename)


# Generated at 2022-06-22 22:02:06.008968
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test to ensure get_platform_subclass behaves as expected
    '''

    # Create a series of classes with the same class structure as the User module
    class Test:
        platform = 'Linux'
        distribution = 'CentOS'

        def __init__(self, *args, **kwargs):
            pass

    class TestLinux(Test):
        platform = 'Linux'

    class TestCentOS(Test):
        distribution = 'CentOS'

    class TestLinuxCentOS(Test):
        platform = 'Linux'
        distribution = 'CentOS'

    # Throw an exception if the expected class is not returned
    if get_platform_subclass(Test) is not Test:
        raise Exception('get_platform_subclass(Test) should return Test')


# Generated at 2022-06-22 22:02:18.088480
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Platform-independent base class
    class BaseClass:
        pass

    # Platform-specific subclass
    class SubClass1(BaseClass):
        platform = 'Linux'

    # Platform-specific subclass
    class SubClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass3(BaseClass):
        platform = 'Linux'
        distribution = 'CentOS'

    class SubClass4(BaseClass):
        platform = 'Linux'
        distribution = 'Fedora'

    # Test for linux subclass
    assert get_platform_subclass(BaseClass) == SubClass1

    # Test for linux Redhat subclass
    assert get_platform_subclass(BaseClass) == SubClass2

    # Test for linux CentOS subclass
    assert get_platform_subclass(BaseClass) == SubClass3

   

# Generated at 2022-06-22 22:02:19.857403
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    try:
        codename = get_distribution_codename()
        return True
    except Exception:
        return False

# Generated at 2022-06-22 22:02:21.305729
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-22 22:02:32.680397
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Only run unit test if supported on this platform
    if platform.system() in ('Linux', 'Darwin'):
        # Base class
        class Foo:
            platform = 'Other'
            distribution = None
        # Subclasses with varying specificity on platform and distribution
        class Linux(Foo):
            platform = 'Linux'
        class RHEL(Linux):
            distribution = 'Redhat'
        class RHEL7(RHEL):
            distribution_version = '7'
        class GenericLinux(Linux):
            pass
        class Darwin(Foo):
            platform = 'Darwin'
        class MacOSX(Darwin):
            distribution = 'Darwin'
        class MacOSX_10_13(MacOSX):
            distribution_version = '17.2.0'
        class GenericDarwin(Darwin):
            pass
       

# Generated at 2022-06-22 22:02:41.611002
# Unit test for function get_distribution_version
def test_get_distribution_version():
    versions = {
        'OtherLinux': '',
        'Amazon': '2016.09',
        'Suse': '42.2',
        'Ubuntu': '16.04',
        'CentOS': '7.4',
        'Debian': '9.4',
        'Redhat': '7.0',
        'Fedora': '30',
        'FreeBSD': None,
    }

    for platform in versions:
        distro.id = lambda: platform
        if platform == 'Suse':
            distro.version = lambda best=True: '42.2-1'
        elif platform == 'Debian':
            distro.version = lambda best=False: '9.4'
            distro.os_release_info = lambda: {'version_id': '9.4'}

# Generated at 2022-06-22 22:02:52.887358
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    """
    When the test is run from the ansible project root the
    etc/ansible/facts.d/ subfolder is not on the python path and is
    not imported.  This test imports the module for us so that we can
    test it locally.
    """
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.system.distribution

    facts = ansible.module_utils.facts.system.distribution.Distribution(
        module=None,
        collect_default=False,
        ansible_facts={},
        ansible_check_mode=False,
        ansible_module=None
    )

    assert facts.get_distribution_codename() is None

# Generated at 2022-06-22 22:02:59.887076
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codenames = {
        'debian8' : u'jessie',
        'debian9' : u'stretch',
        'centos7' : u'Core',
        'fedora28' : u'TwentyEight',
        'xenial' : u'xenial',
    }

    for test_distro, expected_codename in codenames.items():
        assert expected_codename == get_distribution_codename()

# Generated at 2022-06-22 22:03:11.306756
# Unit test for function get_platform_subclass

# Generated at 2022-06-22 22:03:21.216496
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # set code name for all support Linux distributions
    distribution_code_names = {
        # Ubuntu
        'Ubuntu': 'focal',
        # Redhat
        'RedHat': 'Generic',
        # Debian
        'Debian': 'buster',
        # SUSE
        'SuSE': 'Tumbleweed',
        # SLES
        'SLES': '15-SP1',
        # Oracle
        'Oracle': '6.10',
        # Scientific
        'Scientific': '7.0',
        # ALT
        'ALT': '',
        # Amazon
        'Amazon': '4',
        # Fedora
        'Fedora': '33',
    }
    for distribution, code_name in distribution_code_names.items():
        _distribution = get_distribution_codename()
        assert _distribution

# Generated at 2022-06-22 22:03:29.804412
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # your class must be named Foo (otherwise the test will fail)
    class Foo(object):
        platform = None
        distribution = None

    # create child classes without specifying platform and distribution
    class Bar(Foo):
        pass

    class FooLinux(Foo):
        platform = 'Linux'

    class FooLinuxUnkown(Foo):
        platform = 'Linux'
        distribution = None

    class FooLinuxDebian(Foo):
        platform = 'Linux'
        distribution = 'Debian'

    # save the name of each of the classes in a dict, which we will use to test the results
    tests = {c.__name__: c for c in (Bar, FooLinux, FooLinuxUnkown, FooLinuxDebian)}

    # set the platform we want to test
    PLATFORM_TEST = 'Linux'


# Generated at 2022-06-22 22:03:42.856285
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_distribution, ansible_distribution_version, ansible_distribution_release, ansible_distribution_major_version, ansible_distribution_version_full

    # Fake linux distribution to test in this test
    ansible_distribution = 'Test'
    ansible_distribution_version = '3'
    ansible_distribution_release = 'Beta'
    ansible_distribution_major_version = '3'
    ansible_distribution_version_full = '3.0.0'
    ansible_distribution_version = 3

    ansible_module = AnsibleModule(argument_spec={})

    # Test when platform class does not implement specific distribution

# Generated at 2022-06-22 22:03:52.533934
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distro_id = 'Ubuntu'

    # Set the codename to a known value
    codename = 'trusty'

    # Mock distro.id() and distro.codename()
    distro.id = lambda: distro_id
    distro.codename = lambda: codename

    # Call function
    result = get_distribution_codename()

    # Check the result
    assert result == codename

    # Set the codename to an unexpected value
    codename = 'unknown'

    # Mock distro.id() and distro.codename()
    distro.id = lambda: distro_id
    distro.codename = lambda: codename

    # Call function
    result = get_distribution_codename()

    # Check the result
    assert result == 'trusty'

    # Set the cod

# Generated at 2022-06-22 22:04:03.502627
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    This function unit-tests the get_platform_subclass function.
    '''
    # This is the test class hierarchy
    class Parent:
        platform = None
        distribution = None
    class AmznChild(Parent):
        platform = 'Linux'
        distribution = 'Amazon'
    class AmznLinuxChild(AmznChild):
        platform = 'Linux'
    class DebianChild(Parent):
        platform = 'Linux'
        distribution = 'Debian'
    class DebianLinuxChild(DebianChild):
        platform = 'Linux'
    class FooChild(Parent):
        platform = 'Foo'
        distribution = 'Bar'
    class CommonChild(Parent):
        platform = 'Linux'
        distribution = None

    # Stub out platform and distro so we know what the baseline is

# Generated at 2022-06-22 22:04:14.439624
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        distribution = None
        platform = 'Linux'

    class B(A):
        distribution = 'Fedora'
        platform = 'Linux'

    class C(A):
        distribution = 'RedHat'
        platform = 'Linux'

    class D:
        distribution = None
        platform = 'Darwin'

    class E(D):
        distribution = 'Mac'
        platform = 'Darwin'

    class F:
        pass

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == B
    assert get_platform_subclass(C) == A
    assert get_platform_subclass(D) == D
    assert get_platform_subclass(E) == E

    old_system = platform.system
    old_id = distro.id

   

# Generated at 2022-06-22 22:04:25.860062
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import os

    def set_os_release_info(codename):
        os.environ['OS_RELEASE_ID'] = 'debian'
        os.environ['OS_RELEASE_NAME'] = 'Debian'
        os.environ['OS_RELEASE_PRETTY_NAME'] = 'Debian GNU/Linux 9 (stretch)'
        os.environ['OS_RELEASE_VERSION'] = '9'
        os.environ['OS_RELEASE_VERSION_ID'] = '9'
        os.environ['OS_RELEASE_VERSION_CODENAME'] = codename

    # None
    set_os_release_info(None)
    assert get_distribution_codename() is None

    # Debian
    set_os_release_info('stretch')
    assert get_distribution_cod

# Generated at 2022-06-22 22:04:36.799705
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import sys
    import platform
    import unittest
    import ansible.module_utils.facts.system.distribution

    def mock_lsb_release_info(self):
        return {'codename': 'codename mock'}

    def mock_codename(self):
        return None

    class TestDistribution(unittest.TestCase):

        def setUp(self):
            self.sys_platform = sys.platform
            self.platform_linux_distribution = platform.linux_distribution
            self.platform_system = platform.system
            self.distro_id = ansible.module_utils.facts.system.distribution.distro.id
            self.distro_version = ansible.module_utils.facts.system.distribution.distro.version

# Generated at 2022-06-22 22:04:40.075230
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test to make sure get_distribution_codename returns the correct codename
    '''
    codename = get_distribution_codename()
    assert codename == "neon"

# Generated at 2022-06-22 22:04:52.409184
# Unit test for function get_distribution
def test_get_distribution():
    import collections
    import platform

    if platform.system() != "Linux":
        # Until https://github.com/nir0s/distro/issues/219 is fixed, this test will fail.
        return
    lsb_results = subprocess.run(['lsb_release', '-a'], stdout=subprocess.PIPE).stdout.decode('utf-8').splitlines()
    lsb_release_info = collections.OrderedDict([
        (x.split(":")[0], x.split(":")[1].strip())
        for x in lsb_results if x.count(":") == 1
    ])


# Generated at 2022-06-22 22:04:59.833766
# Unit test for function get_distribution
def test_get_distribution():
    platform = get_distribution()
    assert platform in ('Macosx', 'Sunos', 'Freebsd', 'Netbsd', 'Openbsd', 'Windows', 'Linux', 'Aix', 'Freebsd', 'Darwin', 'Hpux11', 'Hpux10', 'Sunos', 'Suse', 'Dragonfly', 'Arch', 'Devuan', 'Gentoo', 'Redhat', 'Oraclelinux', 'Fedora', 'Sles', 'Alpine', 'Mint', 'Debian', 'Ubuntu', 'Ansible', 'Raspbian', 'Clearlinux', 'Amazon')


# Generated at 2022-06-22 22:05:10.953138
# Unit test for function get_distribution_version

# Generated at 2022-06-22 22:05:21.932331
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Foo(object):
        platform = None
        distribution = None

    class Bar(Foo):
        platform = "Linux"
        distribution = None

    class Baz(Foo):
        platform = "Linux"
        distribution = "OtherLinux"

    class Qux(Foo):
        platform = "Linux"
        distribution = "Redhat"

    class Quux(Foo):
        platform = "Linux"
        distribution = "Redhat"

    assert get_platform_subclass(Foo) == Foo
    assert get_platform_subclass(Bar) == Bar
    assert get_platform_subclass(Baz) == Baz
    assert get_platform_subclass(Qux) == Qux

    old_platform_system = platform.system
    old_distro_id = distro.id


# Generated at 2022-06-22 22:05:33.406122
# Unit test for function get_distribution
def test_get_distribution():
    run_function = lambda x: get_distribution()
    fail_function = lambda x: get_distribution()
    fail_function.__name__ = "get_distribution"

    #
    # Distribution tests
    #

# Generated at 2022-06-22 22:05:41.082150
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    class distro_patch:
        def id(self):
            return 'Debian'

        def os_release_info(self):
            return {'VERSION_ID': '9.9', 'VERSION_CODENAME': 'stretch/sid'}

        def lsb_release_info(self):
            return None

        def codename(self):
            return ''

    c = get_distribution_codename()
    assert c is None
    distro.distro = distro_patch()
    c = get_distribution_codename()
    assert c == 'stretch/sid'

# Generated at 2022-06-22 22:05:42.919537
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert(get_distribution_codename() == 'stretch')

# Generated at 2022-06-22 22:05:44.677998
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None



# Generated at 2022-06-22 22:05:55.897874
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    This function is not part of get_platform_subclass, but since it is a method that has been
    migrated to the module_utils.common.platform.py library, it does need to be tested.
    '''
    from distutils.version import LooseVersion

    from ansible.module_utils.common._collections_compat import Mapping

    # Test Ubuntu LTS versions
    assert get_distribution_version() is not None
    ubuntu_versions = dict([(u'xenial', u'16.04'), (u'bionic', u'18.04'), (u'disco', u'19.04'), (u'eoan', u'19.10')])

# Generated at 2022-06-22 22:06:06.622962
# Unit test for function get_distribution
def test_get_distribution():
    # Set platform for Linux based distributions
    platform.system = lambda: 'Linux'

    # Set distro.id to various distribution identifiers
    # See https://en.wikipedia.org/wiki/List_of_Linux_distributions
    # arch (as archlinux)
    distro.id = lambda: 'arch'
    assert get_distribution() == 'Archlinux'

    # centos (as centos)
    distro.id = lambda: 'centos'
    assert get_distribution() == 'Centos'

    # debian (as debian)
    distro.id = lambda: 'debian'
    assert get_distribution() == 'Debian'

    # fedora (as fedora)
    distro.id = lambda: 'fedora'
    assert get_distribution() == 'Fedora'

    # freebsd

# Generated at 2022-06-22 22:06:17.472150
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''Returns a dict with platform, version pairs'''
    platforms = dict(
        centos = dict(
            version = '6.5',
        ),
        ubuntu = dict(
            version = '12.04',
        ),
        debian = dict(
            version = '7.0',
        ),
        freebsd = dict(
            version = '10.1',
        ),
        openbsd = dict(
            version = '5.5',
        ),
        netbsd = dict(
            version = '6.1',
        ),
        fedora = dict(
            version = '20',
        ),
        rhel = dict(
            version = '7.3',
        ),
        amazon = dict(
            version = '2018.03',
        ),
    )

# Generated at 2022-06-22 22:06:18.973397
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'

# Generated at 2022-06-22 22:06:30.010497
# Unit test for function get_distribution
def test_get_distribution():
    class LinuxDistroMeta(type):
        def __str__(cls):
            return cls.__name__

    class LinuxDistro(object):
        __metaclass__ = LinuxDistroMeta

        platform = 'Linux'
        distribution = None

    class LinuxDistroSubclass(LinuxDistro):
        distribution = None

    class AmazonLinux(LinuxDistro):
        distribution = 'Amazon'

    class AmazonLinux2(LinuxDistro):
        distribution = 'Amazon'

    class AmazonLinux3(LinuxDistro):
        distribution = 'Amazon'

    class Debian(LinuxDistro):
        distribution = 'Debian'

    class Kali(Debian):
        distribution = 'Kali'

    class Raspbian(Debian):
        distribution = 'Raspbian'


# Generated at 2022-06-22 22:06:42.145457
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # TODO:  Break this into individual test cases
    # TODO:  Figure out a way to set `cls.platform` for each class
    # TODO:  Figure out a way to set `cls.distribution` for each class


    class PlatformSuperclass:
        platform = None
        distribution = None

    class Linux(PlatformSuperclass):
        platform = 'Linux'
        distribution = None
        pass

    class Redhat(Linux):
        distribution = 'Redhat'
        pass

    class BSD(PlatformSuperclass):
        platform = 'BSD'
        distribution = None
        pass

    class AIX(PlatformSuperclass):
        platform = 'AIX'
        distribution = None
        pass

    class Minix(PlatformSuperclass):
        platform = 'Minix'
        distribution = None
        pass


# Generated at 2022-06-22 22:06:48.820028
# Unit test for function get_distribution
def test_get_distribution():
    original = __import__('distro')
    mocks = [
        ('LSB_VERSION', None),
        ('ID', 'ubuntu'),
        ('VERSION_ID', '12.04')
    ]
    attributes = {}
    for (attr, value) in mocks:
        target_attr = getattr(original, attr)
        attributes[attr] = target_attr
        setattr(original, attr, value)
    try:
        distribution = get_distribution()
        assert distribution == 'Ubuntu'
    finally:
        for (attr, value) in attributes.items():
            setattr(original, attr, value)

# Generated at 2022-06-22 22:06:51.614737
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    if codename is None:
        assert platform.system() != 'Linux'
    else:
        assert isinstance(codename, str)

# Generated at 2022-06-22 22:07:03.487180
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo_Linux:
        platform = 'Linux'
        distribution = None

    class Foo_Linux_RedHat:
        platform = 'Linux'
        distribution = 'RedHat'

    class Foo_Linux_OtherLinux:
        platform = 'Linux'
        distribution = 'OtherLinux'

    class Foo_FreeBSD:
        platform = 'FreeBSD'
        distribution = None

    # Save original platform and distribution values
    orig_platform = platform.system()
    orig_distribution = get_distribution()

    # Test all valid combinations of platform, distribution and subclasses
    for platform in ['Linux', 'FreeBSD']:
        # Test platform with no distribution and no desination specific subclass
        platform.system = lambda: platform
        get_distribution = lambda: None
        result = get_platform_subclass(Foo_Linux)

# Generated at 2022-06-22 22:07:13.789838
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # This is a mocked out platform that's intended to be used in the unit tests
    class TestPlatform:
        platform = 'Test'
        distribution = None

    # This is a mocked out distribution that's intended to be used in the unit tests
    class TestDistro:
        platform = 'Test'
        distribution = 'TestDistro'

    class NoPlatform:
        pass

    class NoDistro:
        platform = 'Test'

    def test_get_platform_subclass_test():
        '''test that a subclass for Test is returned if available'''
        result = get_platform_subclass(TestPlatform)
        assert TestPlatform == result, 'get_platform_subclass returned %s instead of TestPlatform' % result


# Generated at 2022-06-22 22:07:23.475135
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    def mock_os_release_info(self):
        return {
            'version_codename': 'Xenial Xerus',
            'ubuntu_codename': 'xenial',
            'id': 'Ubuntu',
        }

    class MockSystem:
        system = 'Linux'

    class MockDistro:
        @classmethod
        def id(cls):
            return 'ubuntu'

        @staticmethod
        def os_release_info():
            return mock_os_release_info()

        @staticmethod
        def codename():
            return 'yakkety'

        @staticmethod
        def lsb_release_info():
            return {
                'codename': 'yakkety',
            }


# Generated at 2022-06-22 22:07:30.338727
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # test conditions for Ubuntu
    code_name = get_distribution_codename()

    if code_name is None:
        assert(distro.codename() == '')
    elif distro.codename() == u'':
        assert(code_name == distro.os_release_info().get('version_codename'))
    elif distro.codename() == u'bionic': # Ubuntu 18.04 bionic does not have version_codename in /etc/os-release
        assert(distro.os_release_info().get('version_codename') == '')
    else:
        assert(code_name == distro.codename())

# Generated at 2022-06-22 22:07:42.878420
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test whether the version returned is correct, or None is returned for a non-Linux platform

    The test works by calling the get_distribution_version function and checking whether the return
    value is correct based on the operating system.

    :returns: boolean result of test, True if test passes and False if test fails

    Tests are run as follows:
    - Operating system is Linux with a version number for the version of the distribution
        - Actual version number returned
    - Operating system is Linux with no version number for the version of the distribution
        - Empty string returned
    - Operating system is non-Linux
        - None is returned
    '''
    class NonLinux:
        def system():
            return "Non-Linux"

    orig_platform = platform.system
    platform.system = NonLinux.system

    assert get_distribution_version() is None



# Generated at 2022-06-22 22:07:51.184606
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible_test.data.unit.module_utils.common.subclassable_class as module_subclassable_class
    import platform

    if platform.system() == "Linux":
        assert module_subclassable_class.get_platform_subclass(SubclassableClass) == SubclassableClassLinux
    elif platform.system() == "Darwin":
        assert module_subclassable_class.get_platform_subclass(SubclassableClass) == SubclassableClassDarwin
    else:
        assert False, "We don't know what to assert for platform.system()" + platform.system()

# Unit test class for function get_platform_subclass

# Generated at 2022-06-22 22:08:01.474322
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class MetaClass:
        platform = None
        distribution = None

    # pylint: disable=unused-variable
    class OldStyle:
        pass

    # pylint: disable=unused-variable
    class NonPlatform(MetaClass):
        pass

    # pylint: disable=unused-variable
    class LinuxNonDistribution(MetaClass):
        platform = 'Linux'

    # pylint: disable=unused-variable
    class LinuxNonOtherLinux(MetaClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    # pylint: disable=unused-variable
    class LinuxCentOS(MetaClass):
        platform = 'Linux'
        distribution = 'CentOS'

    # pylint: disable=unused-variable

# Generated at 2022-06-22 22:08:12.436153
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    This unit test checks whether get_platform_subclass() works for
    Linux, macOS and Windows.
    '''
    distribution = get_distribution()
    platform = get_platform_subclass(User)
    uname = platform.system()

    if platform.system() == "Windows":
        assert platform.distribution is None
        assert platform.platform == "Windows"
        assert issubclass(platform, WindowsUser)
    elif platform.system() == "Linux":
        assert platform.distribution == distribution
        assert platform.platform == "Linux"
        assert issubclass(platform, LinuxUser)
    elif platform.system() == "Darwin":
        assert platform.distribution is None
        assert platform.platform == "Darwin"
        assert issubclass(platform, DarwinUser)

# Generated at 2022-06-22 22:08:13.797204
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '16.04'



# Generated at 2022-06-22 22:08:23.093421
# Unit test for function get_distribution
def test_get_distribution():

    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import configparser
    import os
    import sys
    import tempfile

    if PY2:
        config_string = u'''[test_get_distribution]
distro_id = None
'''
    else:
        config_string = u'''[test_get_distribution]
distro_id = None
'''

    config_file = None
    old_stdout = sys.stdout


# Generated at 2022-06-22 22:08:28.419586
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.basic import get_distribution_codename
    dist = get_distribution_codename()
    if dist is not None:
        print(dist)
    else:
        print("None")


# Generated at 2022-06-22 22:08:40.630767
# Unit test for function get_distribution
def test_get_distribution():
    old_dist = platform.dist

# Generated at 2022-06-22 22:08:47.953271
# Unit test for function get_distribution_version
def test_get_distribution_version():
    "Unit tests for get_distribution_verion"
    # This is the only way to make the function aware we are testing it
    # When the module is imported, it will try to use the real functions
    # so we need to override them
    def fake_distro_id():
        return 'Debian'
    def fake_distro_version():
        return '9.123.456'
    def fake_distro_version_best():
        return '9.123.456.789'
    mock_distro_module = {
        "id" : fake_distro_id,
        "version" : fake_distro_version,
        "version_best" : fake_distro_version_best,
    }
    from ansible.module_utils.distro import _distro_info, _distro_version, _

# Generated at 2022-06-22 22:08:49.903600
# Unit test for function get_distribution
def test_get_distribution():
    '''
    unit test for get_distribution
    '''
    assert get_distribution() == 'Ubuntu'


# Generated at 2022-06-22 22:09:00.001295
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distro_codename_pairs = {
        "LinuxMint": "sonya",
        "Ubuntu": "bionic"
    }

    for distro_name, codename in distro_codename_pairs.items():
        distro_name_returned = distro_name.lower()
        codename_returned = codename.lower()

        def id_side_effect(*args, **kwargs):
            return distro_name_returned

        def release_side_effect(*args, **kwargs):
            return {'version_codename': codename_returned}

        # one of the above distro_name, codename pairs

# Generated at 2022-06-22 22:09:01.702452
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == u'bionic'

# Generated at 2022-06-22 22:09:03.610614
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-22 22:09:10.488654
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Check the get_distribution_version
    '''
    distro_name = get_distribution()
    distro_version = get_distribution_version()
    distribution_codename = get_distribution_codename()
    if distribution_codename is None:
        distribution_codename = ''
    print("%s %s %s" % (distro_name, distro_version, distribution_codename))



# Generated at 2022-06-22 22:09:16.304272
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution() function

    :rtype: tuple
    :returns: a tuple of success and a list of errors
    '''

    errors = []
    success = True

    # Set the Linux distribution to a known value
    distro_name = get_distribution()

    # Test the function output
    if distro_name is None:
        success = False
        errors.append("Nothing was returned")

    return success, errors

# Generated at 2022-06-22 22:09:18.533736
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Simple test that ensures we have a major distribution string
    '''
    assert get_distribution() is not None

# Generated at 2022-06-22 22:09:19.948820
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == u'Amazon'


# Generated at 2022-06-22 22:09:28.698024
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts import distribution, platform

    # Here is a sample class hierarchy to test
    class Animal:
        def noise(self):
            return 'noise'

    class Cat:
        distribution = 'Darwin'
        platform = platform.system()
        def noise(self):
            return 'meow'

    class Dog:
        distribution = 'Darwin'
        platform = platform.system()
        def noise(self):
            return 'woof'

    class Human:
        distribution = distribution.id()
        platform = platform.system()
        def noise(self):
            return 'talk'

    class Basset:
        distribution = None
        platform = platform.system()
        def noise(self):
            return 'howl'

    class Liger:
        distribution = distribution.id()

# Generated at 2022-06-22 22:09:32.326247
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is None

if __name__ == '__main__':
    print(get_distribution())
    print(get_distribution_version())

# Generated at 2022-06-22 22:09:34.511252
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename() == None

# Generated at 2022-06-22 22:09:35.527819
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert (get_distribution_version() == u'')

# Generated at 2022-06-22 22:09:38.283057
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Debian'
    assert get_distribution_version() == '8.10'


# Generated at 2022-06-22 22:09:43.554704
# Unit test for function get_distribution
def test_get_distribution():
    if platform.system() == 'Linux':
        known_distros = ('Centos', 'Debian', 'Freebsd', 'Openbsd', 'Redhat', 'Ubuntu', 'SuSE', 'Sunos', 'Alpine', 'Amazon', 'Gentoo')
        assert get_distribution() in known_distros
    else:
        known_distros = ('Freebsd', 'Netbsd', 'Sunos', 'Darwin')
        assert get_distribution() in known_distros


# Generated at 2022-06-22 22:09:46.894327
# Unit test for function get_distribution
def test_get_distribution():
    '''
    This function unit test the function get_distribution.
    '''
    assert get_distribution() == "Amazon"


# Generated at 2022-06-22 22:09:56.020904
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    This unit test covers only one of the many use cases, but serves as an example
    of what unit tests should look like.
    '''
    def change_distribution(distro):
        saved_platform = platform.system
        saved_distribution = distro.id

        try:
            platform.system = lambda: 'Linux'
            distro.id = lambda: distro

            return platform, distro
        finally:
            platform.system = saved_platform
            distro.id = saved_distribution

    # Mark this as not being a unit test
    test_get_platform_subclass.__test__ = False


# Generated at 2022-06-22 22:10:05.670679
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class X:
        pass

    class XLinux(X):
        platform = 'Linux'
        distribution = None

    class XLinuxCentOS7(XLinux):
        distribution = 'CentOS'

    class XLinuxRedHat7(XLinux):
        distribution = 'RedHat'

    class XLinuxOtherLinux(XLinux):
        distribution = 'OtherLinux'

    class XLinuxFedora(XLinux):
        distribution = 'Fedora'

    # Set the distribution to CentOS 7
    distro.id = lambda: 'centos'
    distro.codename = lambda: 'Core'
    get_distribution = lambda: 'CentOS'
    get_distribution_version = lambda: '7'

    assert get_platform_subclass(X) is XLinux
    assert get_platform_subclass(XLinux) is XLinuxCent

# Generated at 2022-06-22 22:10:08.793236
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Amazon'

    # Note: This test may not always be valid. e.g. In Fedora 24 and later,
    # distribution is "Fedora" and distribution version
    # is an empty string.
    assert (get_distribution_version() == '7' or
            get_distribution_version() == '')



# Generated at 2022-06-22 22:10:20.873624
# Unit test for function get_distribution_version

# Generated at 2022-06-22 22:10:28.645562
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import os

    lsb_release = """
DISTRIB_ID=Ubuntu
DISTRIB_RELEASE=16.04
DISTRIB_CODENAME=xenial
DISTRIB_DESCRIPTION="Ubuntu 16.04.2 LTS"
    """

    centos_release = """
CentOS Linux release 7.5.1804 (Core) 
    """

    fedora_release = """
Fedora release 28 (Twenty Eight)
    """


# Generated at 2022-06-22 22:10:42.211691
# Unit test for function get_distribution
def test_get_distribution():
    # TODO: add a test for each distribution id
    mock_platform_system = platform.system
    mock_distro_id = distro.id
    platform.system = lambda: 'Linux'
    distro.id = lambda: 'Ubuntu'
    assert 'Ubuntu' == get_distribution(), 'test Ubuntu failed'

    platform.system = lambda: 'Linux'
    distro.id = lambda: ''
    assert 'OtherLinux' == get_distribution(), 'test OtherLinux failed'

    platform.system = lambda: 'Darwin'
    assert 'Macosx' == get_distribution(), 'test Macosx failed'

    platform.system = lambda: 'FreeBSD'
    assert 'Freebsd' == get_distribution(), 'test Freebsd failed'

    platform.system = lambda: 'OpenBSD'

# Generated at 2022-06-22 22:10:54.877307
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test where /etc/os-release exists
    distributions = ('centos', 'fedora', 'debian', 'ubuntu')
    for distribution in distributions:
        with mock.patch.dict('ansible.module_utils.common.distro._distro', {'id': lambda: distribution}):
            codename = get_distribution_codename()

    # Test where /etc/os-release does not exist
    distributions = ('debian')

# Generated at 2022-06-22 22:11:03.418465
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert None == get_distribution_codename()

    # Patch up distro.id() to return a Linux name
    distro.id = lambda: 'arch'
    assert None == get_distribution_codename()

    distro.id = lambda: 'debian'
    # Patch up distro.os_release_info() to return a release codename
    distro.os_release_info = lambda: {'version_codename': 'oldname', 'ubuntu_codename': None}
    assert 'oldname' == get_distribution_codename()

    distro.os_release_info = lambda: {'version_codename': None, 'ubuntu_codename': 'newname'}
    assert 'newname' == get_distribution_codename()


# Generated at 2022-06-22 22:11:05.630459
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == distro.codename()
    assert get_distribution_codename() is None


# Generated at 2022-06-22 22:11:07.147881
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'OtherLinux'


# Generated at 2022-06-22 22:11:08.658222
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == distro.version()

# Generated at 2022-06-22 22:11:19.932694
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """Unit test for function get_distribution_version
    """
    #TODO: Write a proper unit test for this function.
    #This function is deprecated and should not be used.
    import platform
    import os
    import stat
    import tempfile

    platform_system = platform.system()
    if platform_system == 'Linux':
        tmp_os_release_file = tempfile.NamedTemporaryFile(mode='w+t',
                                                          delete=False)

# Generated at 2022-06-22 22:11:25.038062
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Any changes to the distro name or distro version in /etc/os-release
    # will cause this test to fail
    distro_id = 'centos'
    distro_version = '7.5.1804'
    assert get_distribution_version() == distro_version

# Generated at 2022-06-22 22:11:37.728399
# Unit test for function get_distribution_codename

# Generated at 2022-06-22 22:11:45.130160
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    This function allows us to test the function get_distribution_version().
    '''
    import distro
    distro.os_release_info = lambda: {'version': '1.2.3'}
    distro.lsb_release_info = lambda: {'codename': 'codename'}
    distro.id = lambda: 'ubuntu'
    distro.codename = lambda: 'codename'
    distro.version = lambda best=False: '1.2' if not best else '1.2.3'

    assert(get_distribution_version() == '1.2.3')

    # With centos
    distro.id = lambda: 'centos'

    assert(get_distribution_version() == '1.2')

    # With debian