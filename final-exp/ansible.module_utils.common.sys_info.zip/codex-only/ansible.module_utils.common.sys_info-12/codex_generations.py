

# Generated at 2022-06-22 22:01:44.606189
# Unit test for function get_distribution
def test_get_distribution():
    # Get the name of the distribution the module is running on
    distribution = get_distribution()
    assert distribution != 'OtherLinux'


# Generated at 2022-06-22 22:01:55.759289
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    from ansible.module_utils import basic

    class A:
        '''
        Class A
        '''
        distribution = None
        platform = None

    class B(A):
        '''
        Class B
        '''
        distribution = 'Linux'
        platform = None

    class C(A):
        '''
        Class C
        '''
        distribution = 'Linux'
        platform = 'Linux'

    # Test that at base level, we get base class
    assert get_platform_subclass(A) is A

    # Test that we're able to load a default class for the platform
    assert get_platform_subclass(B) is B

    # Test that we can load a subclass, when we're on a linux platform

# Generated at 2022-06-22 22:02:00.076701
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class MyBaseClass:
        pass

    class GenericSubClass(MyBaseClass):
        platform = None
        distribution = None

    class SpecificSubClass(MyBaseClass):
        platform = "Linux"
        distribution = "CentOS"

    assert get_platform_subclass(MyBaseClass) == MyBaseClass
    assert get_platform_subclass(GenericSubClass) == GenericSubClass
    assert get_platform_subclass(SpecificSubClass) == SpecificSubClass

# Generated at 2022-06-22 22:02:04.295173
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Check function get_distribution_version works properly on different Linux distributions
    '''
    correct_distribution_versions = {
        'Centos': '7.2.1511',
        'Debian': '8.3',
        'Ubuntu': '12.04',
        'Freebsd': None
    }

    for key, value in correct_distribution_versions.items():
        assert get_distribution_version() == value


# Generated at 2022-06-22 22:02:16.906885
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Linux'
        distribution = None

    class Ubuntu(Base):
        distribution = 'Ubuntu'

    class Centos(Base):
        distribution = 'Centos'

    class Redhat(Centos):
        distribution = 'Redhat'

    class Centos8(Centos):
        distribution = 'Centos'
        version = '8'

    class Solaris(Base):
        platform = 'SunOS'

    class Windows(Base):
        platform = 'Windows'

    assert get_platform_subclass(Base) == Base
    assert get_platform_subclass(Centos) == Centos8
    assert get_platform_subclass(Redhat) == Redhat
    assert get_platform_subclass(Ubuntu) == Ubuntu
    assert get_platform_subclass(Solaris) == Solaris
   

# Generated at 2022-06-22 22:02:18.907109
# Unit test for function get_distribution
def test_get_distribution():
    import platform
    os = platform.system()
    assert get_distribution() == os


# Generated at 2022-06-22 22:02:30.789189
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.distro import Distribution
    distribution_tests = {
        'Amzn': 'Amazon',
        'Arch': 'Archlinux',
        'CentOS': 'Centos',
        'debian': 'Debian',
        'Fedora': 'Fedora',
        'FreeBSD': 'Freebsd',
        'MacOSX': 'Macosx',
        'OpenBSD': 'Openbsd',
        'Raspbian': 'Raspbian',
        'RedHat': 'Redhat',
        'Solaris': 'Solaris',
        'SuSE': 'SuSE',
        'Ubuntu': 'Ubuntu',
    }

    for test_distro, expected_return in distribution_tests.items():
        distribution = Distribution(test_distro, '1')
        distribution.id = lambda: test_dist

# Generated at 2022-06-22 22:02:37.819561
# Unit test for function get_distribution
def test_get_distribution():
    distributions = {
        'Linux' : 'otherlinux',
        'Darwin' : 'MacOSX',
        'FreeBSD' : 'FreeBSD',
        'OpenBSD' : 'OpenBSD',
        'SunOS' : 'Solaris'
    }
    for d in distributions:
        if d == 'Linux':
            distro.id = lambda: distributions[d].title()
        else:
            distro.id = lambda: distributions[d]
        distro.lsb_release_info = lambda: {}
        assert get_distribution() == distributions[d]


# Generated at 2022-06-22 22:02:47.048468
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class FooBase:
        platform = "Base"
        distribution = None

    class FooBaseOtherLinux(FooBase):
        distribution = "OtherLinux"

    class FooBaseUbuntu(FooBase):
        distribution = "Ubuntu"

    class FooBaseRedhat(FooBase):
        distribution = "Redhat"

    class BarBase:
        platform = "Base"
        distribution = None

    class BarBaseOtherLinux(BarBase):
        distribution = "OtherLinux"

    assert get_platform_subclass(FooBase) == FooBase
    assert get_platform_subclass(BarBase) == BarBase

    assert get_platform_subclass(FooBaseUbuntu) == FooBaseUbuntu
    assert get_platform_subclass(FooBaseRedhat) == FooBaseRedhat

# Generated at 2022-06-22 22:02:51.780726
# Unit test for function get_distribution
def test_get_distribution():
    '''
    test the get_distribution function.
    '''
    assert get_distribution() == get_distribution_version()
    assert get_distribution_version().upper() != get_distribution_version()
    assert get_distribution_version() is not None


# Generated at 2022-06-22 22:03:03.571043
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # We will test the function on a testing system.
    # CentOS release 6.10 (Final)
    distribution = 'CentOS'
    # 6.10
    version = '6.10'
    # Should return 6.10
    assert get_distribution_version() == version
    # Should return CentOS
    assert get_distribution() == distribution
    # Should return None
    assert get_distribution_codename() is None

    # Ubuntu Xenial
    distribution = 'Ubuntu'
    version = '16.04'
    # Should return 16.04
    assert get_distribution_version() == version
    # Should return Ubuntu
    assert get_distribution() == distribution
    # Should return xenial
    assert get_distribution_codename() == 'xenial'

    # Debian 9.2.1

# Generated at 2022-06-22 22:03:09.785079
# Unit test for function get_distribution
def test_get_distribution():

    # Test for Ubuntu
    with open("/etc/os-release", "w") as f:
        f.write("""NAME="Ubuntu"
VERSION="18.04.3 LTS (Bionic Beaver)"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 18.04.3 LTS"
VERSION_ID="18.04"
HOME_URL="https://www.ubuntu.com/"
SUPPORT_URL="https://help.ubuntu.com/"
BUG_REPORT_URL="https://bugs.launchpad.net/ubuntu/"
PRIVACY_POLICY_URL="https://www.ubuntu.com/legal/terms-and-policies/privacy-policy"
VERSION_CODENAME=bionic
UBUNTU_CODENAME=bionic
""")
    assert get_dist

# Generated at 2022-06-22 22:03:14.789265
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for the get_distribution_codename() function.

    This function should return the code name of the distribution on which
    the function is run.  The function should return None if run on a
    non-Linux platform.
    '''
    assert get_distribution_codename() is not None

# Generated at 2022-06-22 22:03:25.204492
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test to ensure that get_distribution_version() returns the correct values.

    :rtype: bool
    :returns: True if the test passed, False otherwise.
    '''
    # As of this writing, get_distribution_version() retrieves the version
    # data from /usr/lib/os-release. This test set stubs the distro
    # module to provide the following data:
    #
    # SLE_12_3=python3 -c 'import json; print(json.dumps({
    #     "id": "sles",
    #     "version": "12.3",
    #     "version_best": "12.3.4",
    #     "codename": "",
    #     "pretty_name": "SUSE Linux Enterprise Server 12 SP3"
    # }

# Generated at 2022-06-22 22:03:27.312044
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename() == "bionic"

# Generated at 2022-06-22 22:03:28.527391
# Unit test for function get_distribution
def test_get_distribution():
    assert 'OtherLinux' == get_distribution()


# Generated at 2022-06-22 22:03:30.150910
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == platform.system()



# Generated at 2022-06-22 22:03:43.187942
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test get_distribution_version()
    '''


# Generated at 2022-06-22 22:03:45.277747
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test function that returns the name of the distribution the module is running on
    '''
    return get_distribution()



# Generated at 2022-06-22 22:03:46.616885
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == distro.id().capitalize()


# Generated at 2022-06-22 22:03:49.352800
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible.module_utils.facts import cache
    assert get_distribution_version() == cache.platform_facts['ansible_distribution_version']

# Generated at 2022-06-22 22:03:59.772412
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Function to test operation of get_distribution()
    '''
    test_dist_name = "TestDistribution"
    test_dist_version = "1.2.3"
    test_dist_id = "test"
    test_platform = "TestPlatform"
    test_codename = "test"

    # Check for when we can't determine distribution
    assert get_distribution() == 'OtherLinux'

    # Define some stub functions to test various scenarios
    # Stub function which returns a lower-case distribution name
    def stub_lower_case_distro_id():
        return test_dist_id.lower()

    # Stub function which returns a mixed-case distribution name
    def stub_mixed_case_distro_id():
        return test_dist_id.capitalize()

    # Stub function which returns

# Generated at 2022-06-22 22:04:02.227804
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    ''' Test for function get_distribution_codename '''
    assert(get_distribution_codename() is None)


# Generated at 2022-06-22 22:04:13.551969
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class SuperClass:
        platform = None
        distribution = None

    class SubClass1(SuperClass):
        platform = u'Linux'

    class SubClass2(SuperClass):
        platform = u'Linux'
        distribution = u'Ubuntu'

    class SubClass3(SuperClass):
        platform = u'Windows'

    class SubClass4(SuperClass):
        distribution = u'Ubuntu'

    class SubClass5(SuperClass):
        platform = u'Linux'
        distribution = u'Ubuntu'

    class SubClass6(SuperClass):
        platform = u'Linux'
        distribution = u'RedHat'

    class SubClass7(SuperClass):
        platform = u'Windows'
        distribution = u'Windows'

    class SubClass8(SuperClass):
        platform = u'Linux'

# Generated at 2022-06-22 22:04:17.153964
# Unit test for function get_distribution
def test_get_distribution():
    result = get_distribution()
    assert result in ('Freebsd', 'Linux', 'Darwin', 'Openbsd', 'Netbsd', 'Unknown')

# Generated at 2022-06-22 22:04:27.845175
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic

    class LoadPlatformSubclassCommon(basic.AnsibleModule):
        pass

    class LoadPlatformSubclassLinuxDistribution(LoadPlatformSubclassCommon):
        platform = 'Linux'
        distribution = 'Centos'

    class LoadPlatformSubclassLinux(LoadPlatformSubclassCommon):
        platform = 'Linux'
        distribution = None

    class LoadPlatformSubclassCommonOther(LoadPlatformSubclassCommon):
        platform = None
        distribution = None

    class LoadPlatformSubclassOther(LoadPlatformSubclassLinux):
        platform = 'Other'
        distribution = None

    class LoadPlatformSubclassOtherDistribution(LoadPlatformSubclassLinux):
        platform = 'Other'
        distribution = 'Other'

    # load_platform_subclass() function tests

# Generated at 2022-06-22 22:04:38.590321
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class Unix:
        platform = 'Linux'
        distribution = None
    class Linux:
        platform = 'Linux'
        distribution = None
    class Distro:
        platform = 'Linux'
        distribution = 'Distro'
    class DistroLinux(Linux, Distro):
        platform = 'Linux'
        distribution = 'Distro'
    class Distro2(Distro):
        distribution = 'Distro2'
    class Distro2Linux(Linux, Distro2):
        platform = 'Linux'
        distribution = 'Distro2'
    class NotDistro(Distro):
        distribution = 'NotDistro'
    class NotDistroLinux(Linux, NotDistro):
        platform = 'Linux'
        distribution = 'NotDistro'

# Generated at 2022-06-22 22:04:45.394109
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'
    import distro
    distro.os_release_info = lambda: {'name': 'Linux Mint', 'id': 'LinuxMint', 'version_id': '18.1'}
    assert get_distribution() == 'Linuxmint'
    assert get_distribution_version() == '18.1'
    assert get_distribution_codename() is None

# Generated at 2022-06-22 22:04:56.608390
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the different types of Linux distributions and also a windows machine
    '''

# Generated at 2022-06-22 22:05:09.182957
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base(object):
        platform = 'Linux'
        distribution = None
    class Amazon(Base):
        distribution = 'Amazon'
    class AmazonSecondary(Amazon):
        distribution_version = '1.2.3'
    class Redhat(Base):
        distribution = 'Redhat'
    class RedhatSecondary(Redhat):
        distribution_version = '2.2.2'
    class OtherLinux(Base):
        distribution = 'OtherLinux'
    class OtherLinuxSecondary(OtherLinux):
        distribution_version = '3.3.3'
    class NotLinux(object):
        platform = 'BSD'

    assert get_platform_subclass(Base) == Base
    assert get_platform_subclass(Amazon) == Amazon
    assert get_platform_subclass(AmazonSecondary) == AmazonSecondary
    assert get

# Generated at 2022-06-22 22:05:20.321489
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    # Testing for non-linux platform
    assert get_distribution_version() is None

    # Testing for various linux platforms
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''

# Generated at 2022-06-22 22:05:29.735540
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class PlatformSubclass(object):
        distribution = None
        platform = 'Linux'

    class DistributionSubclass(PlatformSubclass):
        distribution = 'RedHat'

    class OtherDistributionSubclass(PlatformSubclass):
        distribution = 'OtherLinux'

    class WindowsSubclass(PlatformSubclass):
        distribution = None
        platform = 'Windows'

    assert get_platform_subclass(PlatformSubclass) == PlatformSubclass
    assert get_platform_subclass(DistributionSubclass) == DistributionSubclass
    assert get_platform_subclass(OtherDistributionSubclass) == OtherDistributionSubclass
    assert get_platform_subclass(WindowsSubclass) == WindowsSubclass

# Generated at 2022-06-22 22:05:31.650599
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    x = get_platform_subclass(A)
    assert x is B


# Generated at 2022-06-22 22:05:37.917623
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the version of the distribution the code is running on

    :rtype: NativeString or None
    :returns: A string representation of the version of the distribution. If it
    cannot determine the version, it returns an empty string.
    '''
    version = get_distribution_version()

    if version is not None:
        if platform.system() != 'Linux':
            raise AssertionError('get_distribution_version can only get Linux OS version!')

# Generated at 2022-06-22 22:05:43.713655
# Unit test for function get_distribution_version
def test_get_distribution_version():
    versions = {
        'amzn':        '',
        'centos':      '7.6.1810',
        'debian':      '9.9',
        'rhel':        '7.7',
        'ubuntu':      '20.04',
    }

    for distro_id, distro_version in versions.items():
        assert distro_version == get_distribution_version(distro_id)

# Generated at 2022-06-22 22:05:44.392045
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-22 22:05:55.673615
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class SuperClass:
        platform = 'Linux'
        distribution = 'Redhat'

        def __new__(cls, args, kwargs):
            return cls

    class RedHatUser(SuperClass):
        platform = 'Linux'
        distribution = 'Redhat'

        def __new__(cls, args, kwargs):
            return cls

    class AmazonUser(SuperClass):
        platform = 'Linux'
        distribution = 'Amazon'

        def __new__(cls, args, kwargs):
            return cls

    class AppleUser(SuperClass):
        platform = 'Darwin'
        distribution = 'Chainsaw'

        def __new__(cls, args, kwargs):
            return cls

    class NoUser(SuperClass):
        platform = 'No idea what platform this is'

# Generated at 2022-06-22 22:05:57.256358
# Unit test for function get_distribution
def test_get_distribution():
    # Just assume we are running on some Linux distro
    assert get_distribution() == 'OtherLinux'


# Generated at 2022-06-22 22:06:08.188703
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit tests for function ``get_platform_subclass()``
    '''

    class Base(object):
        '''
        Superclass of all the other subclasses
        '''
        platform = 'Base'
        distribution = None

    class GenericLinux(Base):
        '''
        Subclass of Base implemented for ALL Linux distros
        '''
        platform = 'Linux'
        distribution = None

    class CentOSLinux(Base):
        '''
        Subclass of Base implemented for ONLY CentOS Linux distro
        '''
        platform = 'Linux'
        distribution = 'CentOS'

    class CentOSLinuxDerived(CentOSLinux):
        '''
        Class that is derived from CentOSLinux
        '''
        pass


# Generated at 2022-06-22 22:06:18.072936
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Check that the distro.version() output is parsed correctly
    class DistributionVersion(object):
        '''
        Class to mock results of distro.version()
        '''
        def __init__(self, version):
            self.version = version
            self.id = ''

    assert get_distribution_version(DistributionVersion('7.2')) == '7.2'

    # Check that the distro.version(best=True) output is parsed correctly
    class DistributionVersion(object):
        '''
        Class to mock results of distro.version()
        '''
        def __init__(self, version):
            self.version = version
            self.id = ''

        def best(self):
            return '7.2.1511'


# Generated at 2022-06-22 22:06:20.185740
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    _distro_name = distro.name()
    _codename = get_distribution_codename()
    assert _codename is not None, f"failed to get code name for {_distro_name}: code name was None"

# Generated at 2022-06-22 22:06:30.395811
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version

    These tests validate the behavior of get_distribution_version.

    To run from the ansible directory:
    python -m test.unit.utils.platform_test.test_get_distribution_version
    '''
    import unittest
    import platform

    class Test_get_distribution_version(unittest.TestCase):
        '''
        Unit test class for get_distribution_version

        Contains tests for get_distribution_version.
        '''
        def test_linux_distribution(self):
            '''
            Test Linux platforms.
            '''
            # Mock out distro
            distro_id = 'centos'
            # distro.id() is called with the mock_distro_id parameter
            # set to None. 

# Generated at 2022-06-22 22:06:42.453792
# Unit test for function get_distribution_version
def test_get_distribution_version():

    # Test for Debian 9 Stretch
    def test_debian_9(monkeypatch):
        monkeypatch.setattr(distro, 'id', lambda: 'debian')
        monkeypatch.setattr(distro, 'version', lambda: '9')
        monkeypatch.setattr(distro, 'version', lambda best: '9.6')
        assert get_distribution_version() == '9'

    test_debian_9(monkeypatch)

    # Test for Debian 8 Jessie
    def test_debian_8(monkeypatch):
        monkeypatch.setattr(distro, 'id', lambda: 'debian')
        monkeypatch.setattr(distro, 'codename', lambda: 'jessie')
        monkeypatch.setattr(distro, 'version', lambda: '8')

# Generated at 2022-06-22 22:06:54.764553
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # pylint: disable=protected-access
    class Base(object):
        distribution = None
        platform = None

    class Specific(Base):
        distribution = 'Redhat'
        platform = 'Linux'

    class DistroIndependentSubclass(Base):
        platform = 'Linux'

    assert get_platform_subclass(Base) is Base
    assert get_platform_subclass(Specific) is Specific
    assert get_platform_subclass(DistroIndependentSubclass) is DistroIndependentSubclass

    # class for linux platform on a non redhat distro
    class SpecificLinux(Base):
        distribution = 'OtherLinux'
        platform = 'Linux'

    assert get_platform_subclass(SpecificLinux) is SpecificLinux
    assert get_platform_subclass(Specific) is Specific

# Generated at 2022-06-22 22:07:04.360358
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    '''
    distro_id_version = {
        'Alpine Linux 3.8': ['Alpine', '3.8'],
        'Amazon Linux 2018.03': ['Amazon', '2018.03'],
        'CentOS Linux 7 (Core)': ['Centos', '7']}
    for version, distro_version in distro_id_version.items():
        distro_id, distro_version = distro_version
        distro.id = lambda: distro_id
        distro.version = lambda: version
        assert get_distribution() == distro_id
        assert get_distribution_version() == distro_version

# Generated at 2022-06-22 22:07:14.342744
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    class TestCase():
        ''' Define TestCase class as a wrapper of TestCase method '''

        def __init__(self, expected_result=None, test_input=None):
            self.expected = expected_result
            self.test_input = test_input

    # Test Case 1: check the returned codename from get_distribution_codename method
    # when the system is Amazon Linux
    expected_result = 'amzn2'
    amazon_linux_test_case = TestCase(expected_result, "linux")

# Generated at 2022-06-22 22:07:24.039783
# Unit test for function get_distribution
def test_get_distribution():
    original_system = platform.system
    original_distro_id = distro.id

    def restore():
        platform.system = original_system
        distro.id = original_distro_id

    try:
        platform.system = lambda: 'Linux'
        distro.id = lambda: 'amzn'
        assert get_distribution() == 'Amazon'
    finally:
        restore()

    try:
        platform.system = lambda: 'Linux'
        distro.id = lambda: 'rhel'
        assert get_distribution() == 'Redhat'
    finally:
        restore()

    try:
        platform.system = lambda: 'Linux'
        distro.id = lambda: 'redhat'
        assert get_distribution() == 'Redhat'
    finally:
        restore()


# Generated at 2022-06-22 22:07:27.218272
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the normal invocation of get_distribution_version()
    '''

    distribution_version = get_distribution_version()

    assert not isinstance(distribution_version, type(None))
    assert isinstance(distribution_version, str)


# Generated at 2022-06-22 22:07:31.835669
# Unit test for function get_distribution
def test_get_distribution():

    # Get distribution name
    assert(get_distribution() == 'Redhat')

    # Get distribution version
    assert(get_distribution_version() == '6.10')

    # Get distribution code name
    assert(get_distribution_codename() == 'Santiago')

# Generated at 2022-06-22 22:07:32.761495
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert u'7' == get_distribution_version()

# Generated at 2022-06-22 22:07:46.027394
# Unit test for function get_distribution
def test_get_distribution():
    import unittest

    try:
        import distro  # pylint: disable=unused-import
    except ImportError:
        raise unittest.SkipTest("Python 'distro' package not installed")

    with unittest.mock.patch('platform.system', return_value='Linux'):
        with unittest.mock.patch('distro.id', return_value='amzn'):
            assert get_distribution() == 'Amazon'

        with unittest.mock.patch('distro.id', return_value='rhel'):
            assert get_distribution() == 'Redhat'

        with unittest.mock.patch('distro.id', return_value=''):
            assert get_distribution() == 'OtherLinux'


# Generated at 2022-06-22 22:07:57.666672
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import tempfile
    import platform
    import shutil

    # test 1: Used on ubuntu 18.04
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 22:07:58.329714
# Unit test for function get_distribution
def test_get_distribution():
    return get_distribution()

# Generated at 2022-06-22 22:07:59.601513
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert 'xenial' == get_distribution_codename()

# Generated at 2022-06-22 22:08:11.013976
# Unit test for function get_distribution
def test_get_distribution():
    # Test for Amazon Linux 1
    amzn_release_info = {
        'id': 'amzn',
        'release': '2017.03'
    }
    assert get_distribution() == 'Amazon'
    assert get_distribution_version() == '2017.03'

    # Test for Amazon Linux 2
    amzn_release_info = {
        'id': 'amzn',
        'release': '2'
    }
    assert get_distribution() == 'Amazon'
    assert get_distribution_version() == '2'

    # Test for Ubuntu Xenial
    ubuntu_release_info = {
        'id': 'ubuntu',
        'version_id': '16.04',
        'ubuntu_codename': 'xenial'
    }
    assert get_distribution() == 'Ubuntu'


# Generated at 2022-06-22 22:08:20.907733
# Unit test for function get_distribution
def test_get_distribution():
    # First test that get_distribution is using distro
    distro_id = distro.id()
    assert(get_distribution() == distro_id.capitalize())

    # Next test that get_distribution returns the correct version of Linux
    assert(get_distribution() == 'Amazon')

    # Next test that get_distribution returns the correct version of Linux
    assert(get_distribution() == 'Redhat')

    # Next test that get_distribution returns the correct version of Linux
    # when the Linux distro is not supported.
    assert(get_distribution() == 'OtherLinux')

    # Finally test that get_distribution returns the correct version of
    # another operating system.
    assert(get_distribution() == 'Freebsd')


# Generated at 2022-06-22 22:08:24.539762
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution() == distro.id().capitalize()
    assert get_distribution_version() == distro.version()
    assert get_distribution_codename() == distro.codename()

# Generated at 2022-06-22 22:08:35.596013
# Unit test for function get_distribution_codename

# Generated at 2022-06-22 22:08:41.029932
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    if distribution == "Redhat":
        pass
    elif distribution == "Centos":
        pass
    elif distribution == "OpenSUSE":
        pass
    else:
        raise AssertionError("ERROR:  get_distribution function failed!! the value is: "
                             "%s, but must be Redhat or Centos or OpenSUSE" % distribution)



# Generated at 2022-06-22 22:08:51.699491
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''

    class PlatformA:
        platform = "PlatformA"
        distribution = None

    class PlatformB:
        platform = "PlatformB"
        distribution = None

    class PlatformC:
        platform = "PlatformA"
        distribution = "C1"

    class PlatformD:
        platform = "PlatformA"
        distribution = "D1"

    class PlatformE:
        platform = "PlatformA"
        distribution = "C1"

    class PlatformF:
        platform = "PlatformA"
        distribution = "D1"

    class PlatformG:
        platform = "PlatformB"
        distribution = "C1"

    class PlatformH:
        platform = "PlatformB"
        distribution = "D1"


# Generated at 2022-06-22 22:09:01.738946
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class AnsibleModule1:
        ''' base class '''
        distribution = None
        platform = 'Linux'

    class AnsibleModule1_Fedora(AnsibleModule1):
        '''Fedora'''
        distribution = 'Fedora'

    class AnsibleModule1_Redhat(AnsibleModule1):
        '''Redhat'''
        distribution = 'Redhat'

    class AnsibleModule2:
        ''' another base class '''
        distribution = None
        platform = 'Linux'

    class AnsibleModule2_Fedora(AnsibleModule2):
        '''Fedora'''
        distribution = 'Fedora'

    class AnsibleModule2_Redhat(AnsibleModule2):
        '''Redhat'''
        distribution = 'Redhat'


# Generated at 2022-06-22 22:09:04.265706
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert isinstance(distribution, NativeString)



# Generated at 2022-06-22 22:09:15.547372
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distributions = (
        (u'linuxmint', None),
        (u'ubuntu', u'xenial'),
        (u'debian', u'sid'),
        (u'fedora', u'28'),
        (u'opensuse-leap', u'15.0'),
    )
    for distribution, codename in distributions:
        os_release_info = {
            u'ID': distribution.split('-', 1)[0],
            u'VERSION_ID': u'',
            u'VERSION_CODENAME': codename,
            u'UBUNTU_CODENAME': u'',
        }


# Generated at 2022-06-22 22:09:16.401086
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-22 22:09:25.903275
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test module for function get_distribution_version
    '''
    os_release = open('/etc/os-release', 'r')
    lsb_release = open('/etc/lsb-release', 'r')

    os_release_info = distro.os_release_info()
    lsb_release_info = distro.lsb_release_info()

    os_release.close()
    lsb_release.close()

    distribution = distro.id()
    version = get_distribution_version()

    assert version == os_release_info.get('version_id') or \
           version == os_release_info.get('version_id') or \
           version == lsb_release_info.get('release') or \
           version == distro.version()

# Generated at 2022-06-22 22:09:37.001272
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        platform = "Linux"
        distribution = "SunOS"
    class A1(A):
        platform = "SunOS"
        distribution = None
    class A2(A):
        platform = "SunOS"
        distribution = "SunOS"
    class B(object):
        platform = "Darwin"
        distribution = None

    try:
        get_platform_subclass(A)
    except AttributeError:
        pass
    else:
        assert False

    if get_platform_subclass(A1) is A1:
        pass
    else:
        assert False

    if get_platform_subclass(A2) is A2:
        pass
    else:
        assert False

    if get_platform_subclass(B) is B:
        pass

# Generated at 2022-06-22 22:09:38.705136
# Unit test for function get_distribution_version

# Generated at 2022-06-22 22:09:44.517598
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest

    from ansible.module_utils.basic import AnsibleModule

    class Class1(object):
        platform = 'Linux'
        distribution = None

    class Class2(Class1):
        platform = 'Linux'
        distribution = 'redhat'

    class Class3(Class1):
        platform = 'Linux'
        distribution = 'ubuntu'

    class Class4(Class1):
        platform = 'linux'
        distribution = 'ubuntu'

    class Class5(Class1):
        platform = 'linux'
        distribution = 'redhat'

    class Class6(Class1):
        platform = 'linux'
        distribution = None

    class Class7(Class1):
        platform = 'aix'
        distribution = None

    class Class8(Class1):
        platform = 'Linux'

# Generated at 2022-06-22 22:09:55.076771
# Unit test for function get_distribution
def test_get_distribution():
    """
    Returns the distribution the Ansible module is running on.
    """
    for os_variant in [None, '', 'Generic']:
        this_platform = 'Linux'
        distribution = get_distribution(os_variant)
        if  distribution:
            assert distribution == 'GenericLinux', "Expected 'GenericLinux', got '%s'" % distribution
        else:
            assert False, "Expected distribution to be set"
        distribution = get_distribution('GenToo')
        if  distribution:
            assert distribution == 'GenericLinux', "Expected 'GenericLinux', got '%s'" % distribution
        else:
            assert False, "Expected distribution to be set"
    for os_variant in [None, '', 'Generic']:
        this_platform = 'FreeBSD'

# Generated at 2022-06-22 22:10:05.257410
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function ``get_distribution_codename()`` by mocking ``platform.system()`` and ``distro.id()``.
    The function is tested for Linux distributions where the code name is available in ``/etc/os-release``
    or ``/etc/lsb-release``.

    :rtype: NativeString or None
    :returns: A string representation of the distribution's codename or None if not a Linux distro
    '''
    from distutils.version import LooseVersion
    import sys

    if LooseVersion(sys.version) >= LooseVersion('2.7'):
        import mock
    else:
        from unittest import mock

    @mock.patch('platform.system')
    def test_distribution_codename(platform):
        platform.return_value = 'Linux'

# Generated at 2022-06-22 22:10:06.440438
# Unit test for function get_distribution_version
def test_get_distribution_version():
    if platform.system() == 'Linux':
        assert get_distribution_version() == '9.5'

# Generated at 2022-06-22 22:10:18.634455
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # test for Debian
    test1distro = {'ID': 'debian', 'VERSION_ID': '9.9', 'VERSION_CODENAME': 'stretch/sid'}
    assert get_distribution_codename(test1distro) == 'stretch'
    # test for Ubuntu
    test2distro = {'ID': 'ubuntu', 'VERSION_ID': '16.04', 'UBUNTU_CODENAME': 'xenial'}
    assert get_distribution_codename(test2distro) == 'xenial'
    # test for Fedora
    test3distro = {'ID': 'fedora', 'VERSION_ID': '28', 'VERSION_CODENAME': ''}
    assert get_distribution_codename(test3distro) is None
    # test for Centos


# Generated at 2022-06-22 22:10:27.116652
# Unit test for function get_distribution
def test_get_distribution():
    from collections import namedtuple
    from ansible.module_utils.common._collections_compat import Mapping

    class DistroMock(object):
        def __init__(self, id_, version, version_best, codename, os_release, lsb_release):
            self._id = id_
            self._version = version
            self._version_best = version_best
            self._codename = codename
            self._os_release = os_release
            self._lsb_release = lsb_release

        def id(self):
            return self._id

        def version(self, best=False):
            if best:
                return self._version_best
            return self._version

        def codename(self):
            return self._codename


# Generated at 2022-06-22 22:10:33.951676
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    import os
    import io
    import tempfile
    import unittest
    import ansible.module_utils.basic


# Generated at 2022-06-22 22:10:35.692938
# Unit test for function get_distribution
def test_get_distribution():

    assert(get_distribution() == "Redhat")



# Generated at 2022-06-22 22:10:45.317442
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Function to test Linux distribution code name detection
    '''
    codename_test_data = {
        'Fedora': '28',
        'Ubuntu': 'xenial',
        'Debian': 'buster',
    }

    # Patch the distribution ID and version so we can test the codename detection
    distro.id = lambda: 'Fedora'
    distro.version = lambda: '28'
    assert get_distribution_codename() == codename_test_data['Fedora']

    distro.id = lambda: 'Ubuntu'
    distro.version = lambda: '16.04'
    assert get_distribution_codename() == codename_test_data['Ubuntu']

    distro.id = lambda: 'Debian'
    distro.version = lambda: '10'
   

# Generated at 2022-06-22 22:10:57.136206
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    class FakeModule(object):
        # Needed by get_platform_subclass because it calls get_all_subclasses
        # to find other classes that this class can be subclassed from.
        __subclasses__ = ()

    class FakeIbmClass(FakeModule):
        platform = 'Linux'
        distribution = 'OtherLinux'

        def __new__(cls, *args, **kwargs):
            return super(FakeIbmClass, cls).__new__(cls)

    class FakeOracleClass(FakeModule):
        platform = 'Linux'
        distribution = 'OtherLinux'


# Generated at 2022-06-22 22:11:09.353856
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'
        distribution = None

    class LinuxBase(Base):
        platform = 'Linux'

    class ArchLinux(LinuxBase):
        distribution = 'Arch'

    class OtherLinux(LinuxBase):
        distribution = 'OtherLinux'

    class Arch(Base):
        distribution = 'Arch'

    class Darwin(Base):
        platform = 'Darwin'

    # We don't have a base class that is just Darwin so this should
    # fail to find a class.
    class Darwin2(Base):
        platform = 'Darwin'
        distribution = 'Darwin'

    # This should fail to find a class.  We should get the next best
    # superclass available.
    class OtherLinux2(LinuxBase):
        distribution = 'OtherLinux'
        platform = 'Linux'

    # This class should

# Generated at 2022-06-22 22:11:12.213480
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '6.10'
    assert get_distribution_version() is not None


# Generated at 2022-06-22 22:11:14.014782
# Unit test for function get_distribution
def test_get_distribution():
    distro = get_distribution()
    assert isinstance(distro, str)

# Generated at 2022-06-22 22:11:23.990492
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible_collections.ansible.os_family.tests.unit.compat import unittest
    from ansible_collections.ansible.os_family.tests.unit.compat.mock import patch, MagicMock
    import platform

    class TestGetDistributionCodename(unittest.TestCase):

        @patch('platform.system')
        @patch('ansible_collections.ansible.os_family.distro.os_release_info')
        def test_get_distribution_codename_return_code_name(self, mock_os_release_info, mock_platform):
            mock_platform.return_value = 'Linux'
            mock_os_release_info.return_value = {'version_codename': 'codename'}
            result = get_distribution_codename()
           

# Generated at 2022-06-22 22:11:25.086035
# Unit test for function get_distribution
def test_get_distribution():
    platform = get_distribution()
    return platform

# Generated at 2022-06-22 22:11:27.022884
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '1', 'Not an Ubuntu version 1 system'

# Generated at 2022-06-22 22:11:39.390142
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import sys
    class SaveArgv:
        '''
        Context manager to save and restore the current process' argv
        '''
        def __init__(self, newargv):
            self.newargv = newargv

        def __enter__(self):
            self.oldargv = sys.argv
            sys.argv = self.newargv

        def __exit__(self, *args):
            sys.argv = self.oldargv

    def test_version(argv, expected_version):
        if platform.system() == 'Linux':
            with SaveArgv(argv):
                version = get_distribution_version()
                assert version == expected_version
        else:
            assert version is None

    # Test some oses that have known issues