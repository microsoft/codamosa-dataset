

# Generated at 2022-06-22 22:01:40.339465
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename()

# Generated at 2022-06-22 22:01:41.879126
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test get_distribution()
    '''
    assert None not in (get_distribution(),)

# Generated at 2022-06-22 22:01:52.588618
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Function get_platform_subclass has a pretty complex pattern of behaviors based on
    what the subclass and the running platform are.  This test makes sure it finds
    the right subclass every time.
    '''
    import os
    import sys

    class FakeSubclass:
        def __init__(self, platform, distribution, codename):
            self.platform = platform
            self.distribution = distribution
            self.codename = codename

    # This code only runs on Linux.  Make the code think it's running on Linux
    # even if it really isn't
    orig_platform = platform.system
    platform.system = lambda: 'Linux'

    # Make the platform return a known distribution
    def fake_distro(distribution=None, version=None, id=None, like=None, best=False):
        return distribution



# Generated at 2022-06-22 22:02:00.614682
# Unit test for function get_distribution
def test_get_distribution():
    # Test all the expected values of distro.id()

    # These distros are fully tested with vagrant boxes
    tested_distros = (
        'Ubuntu',
        'Clear',
        'Fedora',
        'Centos',
        'OpenSuse',
        'Redhat',
        'Oracle',
        'Scientific',
        'Suse',
    )

    for distro_id in tested_distros:
        distro.id_cache = distro_id
        assert get_distribution() == distro_id.capitalize()

    # These are just a few distros that we know of that use distro.id() but
    # don't have vagrant boxes

# Generated at 2022-06-22 22:02:06.472631
# Unit test for function get_distribution
def test_get_distribution():
    # Mock platform.dist()
    def mock_platform_dist(distname='', version='', id='', supported_dists=platform._supported_dists,
                           full_distribution_name=1):
        if id == 'centos':
            return ('CentOS', '7.1.1503', 'Core')
        elif id == 'debian':
            return ('Debian', '9.9', '')
        elif id == 'ubuntu':
            return ('Ubuntu', '16.04', 'Xenial Xerus')
        else:
            return (id, '7.1.1503', 'Core')

    # Mock distro.id()
    def mock_distro_id():
        return 'centos'

    # Mock distro.version()

# Generated at 2022-06-22 22:02:18.445994
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform

    from ansible.module_utils.common._collections_compat import MutableMapping

    class DummyBase(object):
        ''' for test only '''

        def __init__(self):
            pass

    class DummySubclass1(DummyBase):
        ''' for test only '''
        pass

    class DummySubclass2(DummyBase):
        ''' for test only '''
        pass

    class DummySubclass3(DummyBase):
        ''' for test only '''
        pass

    class DummySubclass4(DummyBase):
        ''' for test only '''
        pass

    class DummyRealBase(DummyBase):
        ''' for test only '''
        platform = 'linux'
        distribution = None


# Generated at 2022-06-22 22:02:19.776812
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution()
    assert get_distribution_version() is not None

# Generated at 2022-06-22 22:02:28.565441
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Run unit test for "get_distribution_version"
    '''

    # set up test variables
    import distro
    distro.linux_distribution = lambda *args, **kwargs: (u'centos', u'7', u'Final')
    distro.id = lambda *args, **kwargs: u'centos'
    distro.version = lambda *args, **kwargs: u'7'
    expected_version = u'7'

    # check the version against the expected version
    actual_version = get_distribution_version()
    assert(expected_version == actual_version)

# Generated at 2022-06-22 22:02:38.473505
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test that function get_distribution_codename returns the right code name of the distribution

    :rtype: None
    :returns: None

    This unit test expects that the distro module implements distro.codename() and it returns the correct
    distribution code name. However, when called on Ubuntu Xenial Xerus, distro.codename() returns 'xenial',
    but the code name is 'xenial'.
    '''
    codename = get_distribution_codename()

    if platform.system() == 'Linux':
        if get_distribution() == 'Fedora':
            if get_distribution_version() >= '28':
                # Fedora 28+ does not have a code name and thus get_distribution_codename() returns None
                assert codename is None

# Generated at 2022-06-22 22:02:47.368994
# Unit test for function get_distribution_version
def test_get_distribution_version():

    assert get_distribution() == 'Ubuntu', 'The test cannot run on this distribution: %s' % get_distribution()

    # Use lsb_release to get the version number of the distribution
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import bash as bash_module
    import subprocess

    lsb_release = bash_module.lsbrelease()
    v = subprocess.check_output(['lsb_release', '-r']).split(':')[1].strip()
    if v.find( b'.') != -1:
        v = v.decode('utf-8').split('.')[0]
    else:
        v = v.decode('utf-8')

    assert get_distribution_version() == v

    module = AnsibleModule

# Generated at 2022-06-22 22:02:53.780225
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Function get_distribution_codename did not return codename for Fedora 28 release.
    # Function get_distribution_codename did not return codename for Ubuntu Xenial Xerus release.
    # get_distribution_codename did not return codename for Amazon Linux release.
    assert get_distribution_codename() in (None, u'28', u'xenial', u'amzn')
# end of test_get_distribution_codename()

# Generated at 2022-06-22 22:03:05.436540
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        pass

    class B(object):
        platform = 'Linux'
        distribution = 'Redhat'

    class C(B):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class D(C):
        distribution = 'OtherOtherLinux'

    class E(B):
        platform = 'FreeBSD'

    def testcase(check_class, expected_class):
        found = get_platform_subclass(check_class)
        if found is not expected_class:
            raise AssertionError("get_platform_subclass(%s) returned %s when it should have returned %s" % (check_class, found, expected_class))

    testcase(A, A)
    testcase(B, B)
    testcase(C, C)

# Generated at 2022-06-22 22:03:16.785243
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    There is a series of "tests" in the docs directory that describes how basic subclasses of other classes
    should be implemented.  This function contains tests that make sure that the function get_platform_subclass
    is found to return the correct results in a variety of situations.  There is one "test" per item described
    in the documentation.  The code that runs the tests is contained in tests/unit/module_utils/basic.py in the
    ansible source tree.
    '''
    # pylint: disable=no-self-use,too-few-public-methods, unused-argument

    # Now we have an abstract base class.  It is the super class of all other Basic classes.
    # If a class is derived from this then it is a Basic class.  If not then it does not
    # partake in all of the base class functionality

# Generated at 2022-06-22 22:03:27.953786
# Unit test for function get_distribution_version

# Generated at 2022-06-22 22:03:29.446696
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == platform.system()

# Generated at 2022-06-22 22:03:36.202542
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # For Ubuntu
    codename = get_distribution_codename()
    assert codename.lower() == distro.codename(), 'Failed to retrieve the codename for Ubuntu'

    # For Fedora
    codename = get_distribution_codename()
    assert codename is None, 'Did not get None for codename for Fedora'

# Generated at 2022-06-22 22:03:37.356786
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert(get_distribution_version() is not None)

# Generated at 2022-06-22 22:03:40.638276
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    codename = get_distribution_codename()
    assert isinstance(codename, type(u'')) or codename is None

# Generated at 2022-06-22 22:03:42.005456
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == u'16.04'

# Generated at 2022-06-22 22:03:51.982753
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    # Default Debian
    platform_system = 'Linux'
    lsb_info = {'id': 'debian', 'release': '9.9'}
    os_release_info = {'version': '9.9'}
    version = get_distribution_version()

    assert version == '9.9'

    # Default RedHat
    lsb_info = {'id': 'redhat', 'release': '7.4'}
    os_release_info = {'version': '7.4'}
    version = get_distribution_version()

    assert version == '7.4'

    # Ubuntu and code name
    lsb_info = {'id': 'ubuntu', 'release': '16.04'}
    os_release

# Generated at 2022-06-22 22:04:03.440343
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common._utils import get_python_version

    # We need to create the module in a class so we can use
    # get_platform_subclass to find the right one.
    if get_python_version() >= (2, 7):
        import inspect
        import mock
        import sys

        class FakeModule:
            '''
            Fake module class to test get_distribution()
            '''

            # Class variables that need to be set by the test
            # module_utils.distro.id.return_value = 'ubuntu'
            # module_utils.distro.version.return_value = '1.2.3'
            # module_utils.distro.codename.return_value = 'codename

# Generated at 2022-06-22 22:04:05.842767
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == None
    assert get_distribution_version() == ''

# Generated at 2022-06-22 22:04:10.196349
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test that the correct distributions are returned for each platform
    '''
    assert get_distribution() == 'Redhat'
    assert get_distribution_version() == '7.5'
    assert get_distribution_codename() is None

# Generated at 2022-06-22 22:04:17.999405
# Unit test for function get_distribution_version
def test_get_distribution_version():
    class Unknown(object):
        def __iter__(self):
            return [].__iter__()

        def __getitem__(self, key):
            raise KeyError

    import pytest
    import distro

    distro_id = platform.system().lower()


# Generated at 2022-06-22 22:04:28.826164
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class FakeClass:
        pass

    class SpecificSubclass(FakeClass):
        distribution = 'Specific'

    class DistributionSubclass(FakeClass):
        distribution = 'Distribution'

    class PlatformSubclass(FakeClass):
        platform = 'Platform'

    class DefaultSubclass(FakeClass):
        pass

    class GeneralSubclass(FakeClass):
        pass

    def test_find_specific():
        SpecificSubclass.distribution = 'Specific'
        SpecificSubclass.platform = 'Platform'
        assert get_platform_subclass(SpecificSubclass) == SpecificSubclass

    def test_find_distribution():
        DistributionSubclass.distribution = 'Distribution'
        DistributionSubclass.platform = 'Platform'
        assert get_platform_subclass(DistributionSubclass) == DistributionSubclass


# Generated at 2022-06-22 22:04:39.154874
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = None
        distribution = None

    class BSD(BaseClass):
        platform = 'BSD'

    class Linux(BaseClass):
        platform = 'Linux'

    class LinuxRedhat(Linux):
        distribution = 'Redhat'

    class LinuxOther(Linux):
        distribution = 'OtherLinux'

    class LinuxSuse(Linux):
        distribution = 'Suse'

    class LinuxSuse11(LinuxSuse):
        distribution_version = '11'

    class LinuxSuse12(LinuxSuse):
        distribution_version = '12'

    class Darwin(BaseClass):
        platform = 'Darwin'

    class Windows(BaseClass):
        platform = 'Windows'

    # Test where we are given the exact class we want back
    assert get_platform_subclass(BaseClass) == BaseClass

# Generated at 2022-06-22 22:04:44.683891
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test on Ubuntu 14.04 (Trusty Tahr)
    def _test_get_distribution_codename_ubuntu1404():
        assert get_distribution_codename() == "trusty"
    class_assert(module=__name__, function=_test_get_distribution_codename_ubuntu1404)

# Generated at 2022-06-22 22:04:45.343277
# Unit test for function get_distribution
def test_get_distribution():
    pass

# Generated at 2022-06-22 22:04:56.563131
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Insert into the namespace of the module we're testing so that it can call it
    def get_distribution_codename_replacement():
        return "bionic"


# Generated at 2022-06-22 22:05:09.134943
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # get_platform_subclass() should be able to return the most specific class
    # when it's on Linux
    class SpecificClass(object):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class GeneralClass(object):
        platform = 'Linux'
        distribution = None

    class NonSpecificClass(object):
        platform = 'Darwin'
        distribution = 'Ubuntu'

    result = get_platform_subclass(SpecificClass)
    assert result == SpecificClass

    result = get_platform_subclass(GeneralClass)
    assert result == GeneralClass

    result = get_platform_subclass(NonSpecificClass)
    assert result == GeneralClass

    # when it's on Darwin
    result = get_platform_subclass(SpecificClass)
    assert result == GeneralClass

    # when it fails to get the distribution
   

# Generated at 2022-06-22 22:05:20.985000
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        platform = None
        distribution = None

    class B(A):
        platform = 'Linux'
        distribution = 'Centos'

    class C(A):
        platform = 'Linux'
        distribution = 'Debian'

    class D(A):
        platform = 'Linux'
        distribution = 'Redhat'

    class E(A):
        platform = 'Linux'
        distribution = None

    class F(E):
        distribution = 'Redhat'

    class G(F):
        distribution = 'Debian'

    class H(A):
        platform = 'Darwin'
        distribution = None

    class I(A):
        platform = 'FreeBSD'
        distribution = None

    class J(A):
        platform = 'OpenBSD'
        distribution = None

    class K(A):
        platform

# Generated at 2022-06-22 22:05:23.574679
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Basic test to check get_distribution()
    '''
    distribution = get_distribution()

    if distribution is not None:
        assert isinstance(distribution, str)



# Generated at 2022-06-22 22:05:28.362374
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test to get the code name of the distribution the code is running on

    :rtype: NativeString or None
    :returns: A string representation of the distribution's codename or None if not a Linux distro
    '''
    codename = get_distribution_codename()
    assert codename is not None

# Generated at 2022-06-22 22:05:39.810822
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Tests the distribution function
    '''

    distribution = get_distribution()

    if not isinstance(distribution, str) and distribution is not None:
        raise AssertionError("test_get_distribution: distribution function did not return a string or None.")

    # test the specific distribution cases
    if platform.system() == 'Linux':
        # test the ubuntu case
        if distribution == 'Ubuntu':
            if distro.id() != 'ubuntu':
                raise AssertionError("test_get_distribution: Failed on Ubuntu case.")
        # test the centos case
        if distribution == 'Centos':
            if distro.id() != 'centos':
                raise AssertionError("test_get_distribution: Failed on Centos case.")
        # test the amazon case

# Generated at 2022-06-22 22:05:50.295836
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

    # Test if code-name is empty
    old_distro_id = distro.id
    old_distro_codename = distro.codename

    def my_id():
        return 'mydistro'
    def my_codename():
        return ''

    distro.id = my_id
    distro.codename = my_codename

    assert get_distribution_codename() == None

    # Test if codename is not empty
    def my_id_2():
        return 'mydistro2'
    def my_codename_2():
        return 'mycodename'
    distro.id = my_id_2
    distro.codename = my_codename_2


# Generated at 2022-06-22 22:05:51.432159
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == get_distribution().capitalize()


# Generated at 2022-06-22 22:05:57.428344
# Unit test for function get_distribution
def test_get_distribution():
    expected_distribution = {
        'Redhat': 'Redhat',
        'Oracle': 'Oracle',
        'Amazon': 'Amazon',
        'Fedora': 'Fedora',
        'Centos': 'Centos',
        'Ubuntu': 'Ubuntu',
        'Debian': 'Debian',
        'LinuxMint': 'LinuxMint',
        'OtherLinux': 'OtherLinux',
    }

    assert get_distribution() == expected_distribution[get_distribution()]

# Generated at 2022-06-22 22:06:04.669959
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.distro._distribution import get_distribution_codename
    from ansible.module_utils.distro.distro import CentosDistribution, AmazonDistribution, OpenSUSEDistribution, UbuntuDistribution

    # Test Centos
    # Fedora seems to have a weird version of os-release and therefore distro doesn't put it in the codename
    centos = CentosDistribution()
    codename = get_distribution_codename()
    assert codename is None

    # Test Amazon Linux
    amzn = AmazonDistribution()
    codename = get_distribution_codename()
    assert codename == u'amzn1'

    # Test openSUSE
    opensuse = OpenSUSEDistribution()
    codename = get_distribution_codename()

# Generated at 2022-06-22 22:06:07.493893
# Unit test for function get_distribution_version
def test_get_distribution_version():
    prep_system_for_distro_test()

    assert get_distribution() == 'Centos'
    assert get_distribution_version() == '6.5'


# Generated at 2022-06-22 22:06:11.607140
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    expected_output = 'stretch'
    output = get_distribution_codename()
    if output != expected_output:
        raise AssertionError('Unexpected output: %s' % output)

# Generated at 2022-06-22 22:06:19.643713
# Unit test for function get_platform_subclass

# Generated at 2022-06-22 22:06:21.148140
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'bionic'

# Generated at 2022-06-22 22:06:23.861095
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    try:
        codename = get_distribution_codename()
    except:
        pass
    assert codename is not None, "current distribution codename is None"

# Generated at 2022-06-22 22:06:26.085030
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '16.04'


# Generated at 2022-06-22 22:06:37.888706
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''test the get_platform_subclass function
    Will create a fake class hierarchy and test the get_platform_subclass function
    against it.  Makes sure the most specific class is returned
    '''
    # pylint: disable=too-few-public-methods
    class p1():
        platform = None
        distribution = None
    class p2():
        platform = None
        distribution = 'foo'
    class p3():
        platform = 'bar'
        distribution = None
    class p4():
        platform = 'bar'
        distribution = 'foo'

    p1_subclass = get_platform_subclass(p1)
    p2_subclass = get_platform_subclass(p2)
    p3_subclass = get_platform_subclass(p3)

# Generated at 2022-06-22 22:06:39.812817
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Darwin'

# Generated at 2022-06-22 22:06:52.073550
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """Assert that get_distribution_version returns a version"""

    # When distro.version is found, it should be returned
    def id_sideeffect_version(*args, **kwargs):
        if args[0] == 'version':
            return u'1.2.3'
        else:
            return u'LinuxMint'

    # When distro.version is not found, it should be ""
    def id_sideeffect_return_None(*args, **kwargs):
        return None

    revision = u'18'

    id_mocker = mocker.patch('distro.id')
    version_mocker = mocker.patch('distro.version')
    best_version_mocker = mocker.patch('distro.version', best=True)

# Generated at 2022-06-22 22:06:54.310919
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Debian'


# Generated at 2022-06-22 22:07:05.658565
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # Fake classes
    class MyPlatform(object):
        platform = None
        distribution = None

    class MyPlatformA(MyPlatform):
        platform = 'A'
        distribution = None

    class MyPlatformB(MyPlatform):
        platform = 'B'
        distribution = None

    class MyPlatformC(MyPlatform):
        platform = 'C'
        distribution = None

    class MyDistribution(object):
        platform = None
        distribution = None

    class MyDistributionX(MyDistribution):
        platform = None
        distribution = 'X'

    class MyDistributionY(MyDistribution):
        platform = None
        distribution = 'Y'

    class MyDistributionZ(MyDistribution):
        platform = None
        distribution = 'Z'

    class MyPlatformDistribution(object):
        platform = None
        distribution = None

# Generated at 2022-06-22 22:07:16.094734
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    """
    Unit test for function get_distribution_codename
    """

    from ansible.module_utils.basic import AnsibleModule

    def get_distribution_codename_test(arg):
        """
        A test function which mocks get_distribution_codename
        """
        return 'test'

    def test_function(module):
        """
        A test function which mocks for ansible module
        """
        module.exit_json(changed=1, ansible_facts={'distribution_codename': get_distribution_codename()})

    import unittest

    class TestGetDistributionCodename(unittest.TestCase):
        """
        Unit test class for function get_distribution_codename
        """

# Generated at 2022-06-22 22:07:25.494440
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Class for testing purposes
    '''
    class BaseClass:
        '''
        Base class for this example
        '''
        platform = 'Default'
        distribution = None

    class LinuxClass(BaseClass):
        '''
        Linux implementation
        '''
        platform = 'Linux'

    class LinuxDistClass(LinuxClass):
        '''
        Linux implementation specific to a distribution
        '''
        distribution = 'LinuxDist'

    class LinuxDistClass2(LinuxClass):
        '''
        Another Linux implementation specific to a distribution
        '''
        distribution = 'LinuxDist2'

    class SolarisDistClass(LinuxClass):
        '''
        Solaris implementation specific to a distribution
        '''
        platform = 'Solaris'
        distribution = 'SolarisDist'

    # Non-Linux platforms should use

# Generated at 2022-06-22 22:07:34.255379
# Unit test for function get_distribution_version
def test_get_distribution_version():
    expected_versions = {
        'amzn': '2',
        'arch': '2017.02.01',
        'centos': '7.5.1804',
        'debian': '9.5',
        'fedora': '28',
        'opensuse': '42.3',
        'oracle': '6.9',
        'rhel': '7.5',
        'slackware': '14.2',
        'sles': '12-sp3',
        'ubuntu': '18.04',
        'clear': '2.0',
        'coreos': '1235.9.0'
    }

    for distribution in expected_versions:
        distribution_expected_version = expected_versions[distribution]

        distribution_version = get_distribution_version()
        assert distribution_expected_version

# Generated at 2022-06-22 22:07:39.066710
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '16.04'
    assert get_distribution_codename() == 'xenial'
    assert get_distribution() == 'Ubuntu'

# Generated at 2022-06-22 22:07:49.076182
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    idempotence = make_idempotence_test(get_distribution_codename)

    codename = get_distribution_codename()

    if codename is None:
        print("Failed to detect a valid codename for this distribution. Test skipped.")
    else:
        # Tuple of (expected function return value, function args)
        # Each tuple represents a test to be run
        #     expected: The expected return value of the function when called with the supplied args
        #     args: The args to pass to the function
        # We are not testing inter-platform change, so there should only be one platform-specific test
        test_set = [
            (codename, None),
        ]

        idempotence(test_set)

# Generated at 2022-06-22 22:08:00.131268
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import CommandLine
    from ansible.module_utils.facts.system.posix import POSIXFactCollector


# Generated at 2022-06-22 22:08:11.056547
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Module:
        platform = 'Linux'
        distribution = None

    assert get_platform_subclass(Module) == Module

    class ModuleLinux(Module):
        platform = 'Linux'

    assert get_platform_subclass(Module) == ModuleLinux

    class ModuleLinuxFreeBSD(ModuleLinux):
        platform = 'FreeBSD'

    assert get_platform_subclass(Module) == ModuleLinux

    class ModuleLinuxFreeBSDOpenBSD(ModuleLinuxFreeBSD):
        platform = 'OpenBSD'

    assert get_platform_subclass(Module) == ModuleLinux

    class ModuleLinuxFreeBSDOpenBSDNetBSD(ModuleLinuxFreeBSDOpenBSD):
        platform = 'NetBSD'

    assert get_platform_subclass(Module) == ModuleLinux


# Generated at 2022-06-22 22:08:17.032678
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for get_distribution()
    '''
    arch = platform.machine()
    if arch == 'x86_64' or arch == 'i686':
        value = get_distribution()
        if value == 'Linux':
            return True
        else:
            raise AssertionError('get_distribution() returned {0}'.format(value))
    else:
        raise AssertionError('get_distribution() does not support your architecture {0}'.format(arch))

# Generated at 2022-06-22 22:08:21.848429
# Unit test for function get_distribution_version
def test_get_distribution_version():
    if platform.system() == 'Linux':
        v = get_distribution_version()
        assert v is not None, u"get_distribution_version returned None when the distribution is not unknown"
    else:
        v = get_distribution_version()
        assert v is None, u"get_distribution_version returned None when the distribution is not unknown"

# Generated at 2022-06-22 22:08:33.621457
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for get_distribution_codename function
    '''
    with open('/etc/os-release') as os:
        lines = os.readlines()
    codename = get_distribution_codename()

    # If /etc/os-release is present, the codename should be in /etc/os-release
    # Ubuntu is a special case, as the codename can be found in /etc/lsb-release
    # but the Distributor ID is not present in /etc/lsb-release
    if codename is not None:
        for line in lines:
            if line.startswith('DISTRIB_CODENAME='):
                return codename == line.split('=')[1].strip("\n")

# Generated at 2022-06-22 22:08:43.514974
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import pytest
    import sys
    import os

    def  _set_distro_id(distro_id):
        fake_distro_id = os.path.join(os.path.dirname(__file__), 'distro_id')
        with open(fake_distro_id, 'w') as f:
            f.write(distro_id)
        sys.modules['distro']._distro.DISTRO_RELEASE_FILE = \
            os.path.join(os.path.dirname(__file__), 'os-release')
        sys.modules['distro']._distro._release_filename = None
        sys.modules['distro']._distro._lsb_release_filename = None
        sys.modules['distro']._distro._lsb_release_info

# Generated at 2022-06-22 22:08:45.944472
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    This is a unit test for get_distribution_codename.
    '''
    codename = get_distribution_codename()
    print(codename)

# Generated at 2022-06-22 22:08:47.682188
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Function to test distribution codename
    '''
    assert get_distribution_codename() is not None

# Generated at 2022-06-22 22:08:55.004898
# Unit test for function get_distribution
def test_get_distribution():
    import platform
    current_platform = platform.system()

    # get_distribution should return None for windows
    if current_platform == 'Windows':
        assert get_distribution() is None

    # get_distribution should return RedHat for CentOS
    elif current_platform == 'Linux' and distro.id() == 'centos':
        assert get_distribution() == 'Redhat'

    # get_distribution should return Amazon for Amazon Linux
    elif current_platform == 'Linux' and distro.id() == 'amzn':
        assert get_distribution() == 'Amazon'

    # get_distribution should return Debian for Debian
    elif current_platform == 'Linux' and distro.id() == 'debian':
        assert get_distribution() == 'Debian'

    # get_distribution should return None for unsupported Linux

# Generated at 2022-06-22 22:08:58.486314
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Function returns codename, or None
    '''
    assert get_distribution_codename() is None



# Generated at 2022-06-22 22:08:59.550844
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-22 22:09:05.324585
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    functional test for get_distribution_version function

    :returns: None
    '''
    ansible_facts = {
        'distribution': get_distribution(),
        'distribution_version': get_distribution_version(),
    }

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    module.exit_json(ansible_facts=ansible_facts)



# Generated at 2022-06-22 22:09:16.191953
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Create a platform subclass hierarchy and verify that this function
    returns the correct subclass.
    """

    class Base:
        pass

    class LinuxBase(Base):
        platform = "Linux"
        distribution = None

    class LinuxOtherLinux(LinuxBase):
        distribution = "OtherLinux"

    class LinuxUbuntu(LinuxBase):
        distribution = "Ubuntu"

    class LinuxRedHat(LinuxBase):
        distribution = "RedHat"

    class LinuxAmazon(LinuxBase):
        distribution = "Amazon"

    class LinuxSUSEEnterpriseServer(LinuxBase):
        distribution = "SUSEEnterpriseServer"

    class LinuxSUSEEnterpriseServer15(LinuxSUSEEnterpriseServer):
        version = "15"

    class LinuxSUSEEnterpriseServer12(LinuxSUSEEnterpriseServer):
        version = "12"


# Generated at 2022-06-22 22:09:25.973102
# Unit test for function get_distribution_version

# Generated at 2022-06-22 22:09:34.459485
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class foo():
          platform = None
          distribution = None
    class foo_Linux(foo):
          platform = "Linux"
          distribution = None
    class foo_Linux_RedHat(foo_Linux):
          distribution = "RedHat"
    class foo_Linux_RedHat_amzn(foo_Linux_RedHat):
          distribution = "amzn"
    class foo_Windows(foo):
          platform = "Windows"
    class foo_Darwin(foo):
          platform = "Darwin"

    assert foo_Linux_RedHat_amzn == get_platform_subclass(foo)

# Generated at 2022-06-22 22:09:44.324677
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo:
        distribution = None
        platform = None
        pass

    class FooLinux(Foo):
        distribution = None
        platform = 'Linux'
        pass

    class FooLinuxDebian(Foo):
        distribution = 'Debian'
        platform = 'Linux'
        pass

    class FooLinuxUnknown(Foo):
        distribution = 'Unknown'
        platform = 'Linux'

    class FooLinuxDebianUbuntu(Foo):
        distribution = 'Ubuntu'
        platform = 'Linux'

    class FooLinuxDebianUbuntuXenial(Foo):
        distribution = 'Xenial'
        platform = 'Linux'

    class FooLinuxDebianUbuntuXenialXerus(Foo):
        distribution = 'Xerus'
        platform = 'Linux'


# Generated at 2022-06-22 22:09:50.388406
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    import unittest

    # class User(unittest.TestCase):
    class User:
        ''' class User is a fake module class to test get_platform_subclass '''
        platform = 'Linux'
        distribution = None

        def __init__(self, *args, **kwargs):
            pass
            # self.assertEqual(TestDistroClass.platform, 'Linux')
            # self.assertEqual(TestDistroClass.distribution, 'TestDistro')

        # def __new__(cls, *args, **kwargs):
        #     new_cls = get_platform_subclass(cls)
        #     return super(cls, new_cls).__new__(new_cls)


# Generated at 2022-06-22 22:10:01.324258
# Unit test for function get_distribution_version

# Generated at 2022-06-22 22:10:02.662508
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-22 22:10:14.557316
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils._text import to_bytes
    class Generic(object):
        platform = 'Generic'

        @staticmethod
        def foo():
            return 'bar'

    class LinuxGeneric(Generic):
        platform = 'Linux'
        distribution = None

    class LinuxRedHat(LinuxGeneric):
        distribution = 'Redhat'

    class LinuxRedHat6(LinuxRedHat):
        distribution_version = '6'

    class LinuxRedHat7(LinuxRedHat):
        distribution_version = '7'

    class LinuxDebian(LinuxGeneric):
        distribution = 'Debian'

    class LinuxDebian6(LinuxDebian):
        distribution_version = '6'

    class LinuxDebian7(LinuxDebian):
        distribution_version = '7'

    class LinuxDebian8(LinuxDebian):
        distribution

# Generated at 2022-06-22 22:10:26.526191
# Unit test for function get_distribution_codename

# Generated at 2022-06-22 22:10:33.733282
# Unit test for function get_distribution
def test_get_distribution():
    ansible_module = MagicMock(platform={'system': 'Linux'})
    ansible_module.distribution.id.return_value = 'CentOS'
    assert get_distribution() == 'Centos'

    ansible_module = MagicMock(platform={'system': 'Linux'})
    ansible_module.distribution.id.return_value = 'AMZN'
    assert get_distribution() == 'Amazon'

    ansible_module = MagicMock(platform={'system': 'Linux'})
    ansible_module.distribution.id.return_value = 'rhel'
    assert get_distribution() == 'Redhat'

    ansible_module = MagicMock(platform={'system': 'Linux'})
    ansible_module.distribution.id.return_value = None
    assert get

# Generated at 2022-06-22 22:10:44.437629
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import collections
    import ansible.module_utils.basic

    class BaseClass:
        pass

    class Platform1(BaseClass):
        platform = 'Platform 1'

    class Distribution1(Platform1):
        distribution = 'Distribution 1'

    class Distribution2(Platform1):
        distribution = 'Distribution 2'

    class Platform2(BaseClass):
        platform = 'Platform 2'

    class Distribution1(Platform2):
        distribution = 'Distribution 1'

    class Distribution1(Platform2):
        distribution = 'Distribution 2'

    class DistributionOnly(BaseClass):
        distribution = 'Distribution Only'

    # Make a note of the class attributes defined on the Base class
    base_class_attributes = collections.OrderedDict(BaseClass.__dict__)

    # Need to set the platform
    ansible.module

# Generated at 2022-06-22 22:10:56.539576
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    def run_test(distro_id, version_id, version_codename, ubuntu_codename):
        # Create the module.  We don't want to use the real distro module
        # so instead create a Mock object which we can control using
        # side effects on the return value
        mock_distro = Mock()

        # Make the module's id() method return the distro id.  This value
        # is used by the first if statement in get_distribution_codename()
        # to determine if we're running on Linux
        mock_distro.id = Mock(return_value=distro_id)

        # If we're running on Linux, we need to be able to return a
        # value for distro.os_release_info()

# Generated at 2022-06-22 22:10:59.783137
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Amazon'


# Generated at 2022-06-22 22:11:01.630211
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == u'Redhat'
# End of unit test for get_distribution

# Generated at 2022-06-22 22:11:13.330960
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest
    import sys

    class Test(object):
        platform = None
        distribution = 'Test_distribution'

    class TestSubclass(Test):
        platform = 'Test_platform'
        distribution = 'Test_distribution'

    class TestSubclass2(Test):
        platform = 'Test_platform_2'
        distribution = None

    class TestSubclass3(TestSubclass2):
        platform = 'Test_platform_2'
        distribution = None

    class TestSubclass4(Test):
        platform = 'Test_platform'
        distribution = 'Test_distribution_2'

    def get_platform_subclass_clean(cls):
        this_platform = platform.system()
        distribution = 'Test_distribution'

        subclass = None

        # get the most specific superclass for this platform
       

# Generated at 2022-06-22 22:11:21.005958
# Unit test for function get_distribution_version
def test_get_distribution_version():

    test_versions = [
        ('8.2.2004', ['centos', 'redhatenterpriseserver']),
        ('', ['fedora', 'amzn', 'amazon']),
        ('', ['ubuntu']),
        ('', ['debian']),
        ('', ['opensuse-leap']),
        ('5.7.17', ['suse']),
    ]

    for version, distros in test_versions:
        for distro in distros:
            got_version = get_distribution_version()
            print(distro, version, got_version)
            assert got_version == version

# Generated at 2022-06-22 22:11:22.846626
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is None



# Generated at 2022-06-22 22:11:35.414453
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Stub distro.id () to return different values
    mocker = Mocker()
    id_stub = mocker.replace('distro.id')

    # Stub distro.codename() to return a different value
    codename_stub = mocker.replace('distro.codename')
    codename_stub()
    mocker.result(u'VALUE')

    # Stub distro.os_release_info() to return a different value
    os_release_info_stub = mocker.replace('distro.os_release_info')
    os_release_info_stub()
    mocker.result({'version_codename': 'CODENAMEHERE'})

    # Stub lsb_release_info to return a different value

# Generated at 2022-06-22 22:11:44.299010
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test cases get_distribution_version method.

    '''