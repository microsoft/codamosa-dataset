

# Generated at 2022-06-22 22:01:45.044617
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test distribution codename
    '''
    codename = get_distribution_codename()
    print ('Distribution codename is ', codename)

# Generated at 2022-06-22 22:01:46.925981
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux', "Should be Linux"



# Generated at 2022-06-22 22:01:57.496538
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Define our target class and subclasses
    class Base(object):
        platform = 'Base'
        distribution = None

    class LinuxBase(Base):
        platform = 'Linux'
        distribution = None

    class Fedora(LinuxBase):
        distribution = 'Fedora'

    class RedHat(LinuxBase):
        distribution = 'Redhat'

    class CentOS(LinuxBase):
        distribution = 'Centos'

    # A subclass that changes only the distribution should be returned
    # by get_platform_subclass(LinuxBase)
    assert get_platform_subclass(LinuxBase) is Fedora
    # A subclass that implements the same distribution and platform
    # should be returned by get_platform_subclass(RedHat).
    assert get_platform_subclass(RedHat) is RedHat
    # get_platform_subclass(Base) returns the

# Generated at 2022-06-22 22:01:58.474040
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-22 22:02:08.452788
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    def distro_mock(distribution_name, version, id, release, codename):
        """
        Monkey patch distro to return our values
        """
        # If a string is passed, we're asking if it starts with that string and
        # should return True or False
        if isinstance(distribution_name, str):
            return distribution_name in (id, release)
        # Otherwise, we're figuring out what distro it is
        return {'distribution': distribution_name, 'version': version, 'id': id,
                'release': release, 'codename': codename}

    with distro.LinuxDistribution(distro=distro_mock) as mocked_distro:

        # Test for Red Hat
        distribution_codename = get_distribution_codename()

# Generated at 2022-06-22 22:02:10.161951
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None


# Generated at 2022-06-22 22:02:19.923565
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base(object):
        pass

    class A(Base):
        platform = 'Linux'
        distribution = None

    class B(A):
        pass

    class C(Base):
        platform = 'Linux'
        distribution = 'Redhat'

    class D(Base):
        platform = 'Linux'
        distribution = 'Redhat'

    class E(Base):
        platform = 'Linux'
        distribution = None

    assert get_platform_subclass(Base) == Base
    assert get_platform_subclass(C) == C
    assert get_platform_subclass(D) == D
    assert get_platform_subclass(B) == B
    # When there are two equally specific superclasses, get_platform_subclass
    # will pick the first one.  This is a bug in get_platform_subclass.
   

# Generated at 2022-06-22 22:02:23.634372
# Unit test for function get_distribution
def test_get_distribution():
    # Test distro is redhat
    test_distribution = u'Redhat'

    assert get_distribution() == test_distribution

# Generated at 2022-06-22 22:02:34.915687
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import MutableSequence

    def _fake_distro_id(name):
        return name

    def _fake_os_release_info(codename):
        os_release_info = {'version_codename': codename}
        return os_release_info

    def _fake_lsb_release_info(codename):
        lsb_release_info = {'codename': codename}
        return lsb_release_info

    def _fake_codename(codename):
        return codename

    def _fake_none():
        return None


# Generated at 2022-06-22 22:02:37.138413
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Returns a tuple that can be used by the test functions.
    '''
    return (get_distribution_version(), )

# Generated at 2022-06-22 22:02:46.710803
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Returns an error string or None

    This will not always be run.  The code to invoke it is in ``unit tests/units/modules/basic.py``.
    This is a temporary situation until we have a good way to have unit tests for imported modules.
    '''

    class SubTest(object):
        distribution = platform.system()  # Use the real platform

    class SubTest1a(SubTest):
        distribution = 'Linux'

    class SubTest1b(SubTest):
        distribution = None

    class SubTest1c(SubTest):
        distribution = 'Linux'

    class SubTest2a(SubTest):
        distribution = 'OS X'

    class SubTest2b(SubTest):
        distribution = None

    class SubTest2c(SubTest):
        distribution = 'OS X'


# Generated at 2022-06-22 22:02:58.482140
# Unit test for function get_distribution

# Generated at 2022-06-22 22:03:09.896653
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestClass():
        pass
    # Test finding a class that matches distro and platform
    class TestSubclass1(TestClass):
        platform = "Linux"
        distribution = "Ubuntu"
    assert TestSubclass1 == get_platform_subclass(TestClass)
    # Test finding a class that matches platform and has no distribution
    class TestSubclass2(TestClass):
        platform = "Linux"
        distribution = None
    assert TestSubclass2 == get_platform_subclass(TestClass)
    # Test finding a class that matches platform and has empty distribution
    class TestSubclass3(TestClass):
        platform = "Linux"
        distribution = ""
    assert TestSubclass3 == get_platform_subclass(TestClass)
    # Test finding the default class

# Generated at 2022-06-22 22:03:11.878572
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    if distribution:
        assert (type(distribution) == str)



# Generated at 2022-06-22 22:03:20.258749
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    :rtype: bool
    :returns: ``True`` if function returns the same class if no subclasses are found
    '''
    class PlatformA:
        platform = 'A'

    class PlatformB(PlatformA):
        platform = 'A'
        distribution = 'B'

    class PlatformC(PlatformB):
        platform = 'A'
        distribution = 'B'

    assert PlatformA == get_platform_subclass(PlatformA)
    assert PlatformB == get_platform_subclass(PlatformA)
    assert PlatformC == get_platform_subclass(PlatformA)

# Generated at 2022-06-22 22:03:26.670531
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test :func:`get_distribution`
    '''
    # Test many platforms at once
    # Since get_distribution uses get_platform, these are tested implicitly
    assert get_distribution() in (
        'AIX',
        'Darwin',
        'DragonFly',
        'FreeBSD',
        'Linux',
        'NetBSD',
        'OpenBSD',
        'SunOS',
    )

# Generated at 2022-06-22 22:03:30.718804
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    """
    Simple test to validate the get_distribution_codename function
    """
    if platform.system() == 'Linux':

        codename = get_distribution_codename()

        if codename is None:
            raise ValueError('Unsupported OS')

    else:
        raise ValueError('Unsupported OS')


# Generated at 2022-06-22 22:03:43.622128
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.common._utils import get_all_subclasses
    from ansible.module_utils.basic import AnsibleModule  # noqa

    import platform
    import sys

    class FakeModule:
        def __init__(self):
            self.params = {'name': 'testuser'}
            self.check_mode = False
            self.debug = False
    # First let's see if we can get the Linux distro

# Generated at 2022-06-22 22:03:51.222634
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test for Amazon Linux
    distro_id = 'Linux'
    amzn_lsb_release_info = {'distributor_id': 'AmazonAMI', 'code_name': 'Final'}
    amzn_os_release_info = {}

    # Test for Fedora
    fedora_lsb_release_info = {}
    fedora_os_release_info = {'version_codename': 'Spherical Cow'}

    # Test for Debian
    debian_lsb_release_info = {'codename': 'stretch'}
    debian_os_release_info = {}

    # Test for Ubuntu Xenial
    xenial_lsb_release_info = {'codename': 'xenial'}
    xenial_os_release_info = {}

    # Test for Ubuntu Bionic
    bionic_ls

# Generated at 2022-06-22 22:04:02.078145
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """Unit test for get_platform_subclass"""

    # This is a simple test of the get_platform_subclass function.
    # It should be tested more thoroughly in each of the
    # platforms/distribution-dependent Ansible modules that use it.

    class BaseClass:
        pass

    # Create a series of classes that derive from BaseClass as follows:
    # - BaseClass1: no platform or distro defined
    # - BaseClass2: 'Linux' as the platform, no distro defined
    # - BaseClass3: 'Linux' as the platform, 'Amazon' as the distro
    # - BaseClass4: 'Linux' as the platform, 'Redhat' as the distro
    # - BaseClass5: 'Linux' as the platform, 'OtherLinux' as the distro
    # - BaseClass6: 'Linux' as the platform

# Generated at 2022-06-22 22:04:04.059780
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Debian'
    assert get_distribution() == 'Ubuntu'

# Generated at 2022-06-22 22:04:14.808831
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import sys
    import os
    os.chdir(os.path.join(os.path.dirname(__file__), '../../..'))
    sys.path.insert(0,os.path.dirname(__file__))
    import distro

    distro.release_info['version_codename'] = 'codename_from_release_info'
    distro.lsb_release_info['codename'] = 'codename_from_lsb_release_info'
    distro.os_release_info['ubuntu_codename'] = 'codename_from_os_release_info'
    assert get_distribution_codename() == 'codename_from_release_info'
    del distro.release_info['version_codename']

# Generated at 2022-06-22 22:04:22.879993
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version and return:
    True if success, False else
    '''
    distribution_function = (
        (u'centos', u'7.4.1708'),
        (u'debian', u'9.4'),
        (u'ubuntu', u'18.04'),
        (u'freebsd', u''),
    )

    for distro_name, version in distribution_function:
        if get_distribution() == distro_name and get_distribution_version() == version:
            return True
        else:
            return False

# Generated at 2022-06-22 22:04:25.475487
# Unit test for function get_distribution
def test_get_distribution():
    """Test AnsibleModule get_distribution() function for facts
     """
    test_distros = {
        "centos": "Centos",
        "centos linux": "Redhat",
        "debian": "Debian",
        "fedora": "Fedora",
        "freebsd": "Freebsd",
        "Ubuntu": "Ubuntu",
    }
    for key, value in test_distros.items():
        distro.id = lambda: key
        assert value == get_distribution()

# Generated at 2022-06-22 22:04:36.529725
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Base1(object):
        pass

    class Base2(object):
        pass

    class Base3(object):
        pass

    class Base4(object):
        pass

    class Test1(Base1):
        pass

    class Test2(Base1):
        platform = "AIX"

    class Test3(Base1):
        platform = "AIX"
        distribution = "AIX"

    class Test4(Base2):
        platform = "Linux"

    class Test5(Base4):
        platform = "Linux"
        distribution = "Ubuntu"

    class Test6(Base4):
        platform = "Linux"
        distribution = "Ubuntu"
        codename = "karmic"

    class Test7(Base3):
        platform = "Linux"
        distribution = "Ubuntu"
        codename

# Generated at 2022-06-22 22:04:48.732647
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import os
    import tempfile

    codenames = {
        'centos': 'TestOS',
        'debian': 'TestOS',
        'fedora': 'TestOS',
        'oracle': 'TestOS',
        'redhat': 'TestOS',
        'ubuntu': 'TestCodename'
    }


# Generated at 2022-06-22 22:04:55.210830
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    DISTRIBUTION_ID = get_distribution()
    DISTRIBUTION_VERSION = get_distribution_version()
    DISTRIBUTION_CODENAME = get_distribution_codename()
    print("{} {} {}".format(DISTRIBUTION_ID, DISTRIBUTION_VERSION, DISTRIBUTION_CODENAME))

if __name__ == '__main__':
    test_get_distribution_codename()

# Generated at 2022-06-22 22:04:57.645527
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # The code name for Ubuntu 18.04.2 LTS Xenial Xerus is xenial
    assert get_distribution_codename() == u'xenial'


# Generated at 2022-06-22 22:05:10.413145
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Function get_distribution_version returns a string representation of the version of the distribution
    the code is running on. If it cannot determine the version, it returns an empty string. If this is not
    run on a Linux machine it returns None.

    This unit test tests this function by calling it on a set of Linux distributions.
    '''
    # Note: This is a quick and dirty test, so the unit test does not mock out the
    # underlying modules that the get_distribution_version function uses for determining
    # the distribution.

    import unittest


# Generated at 2022-06-22 22:05:21.574365
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """ Used in test/unit/module_utils/basic.py """
    class Base:
        platform = 'Linux'
        distribution = None
    class SubclassA(Base):
        platform = 'Linux'
        distribution = 'Redhat'
    class SubclassB(Base):
        platform = 'Linux'
        distribution = 'Ubuntu'
    class SubclassC(Base):
        platform = 'Linux'
        distribution = 'Amazon'
    class SubclassD(Base):
        platform = 'Linux'
        distribution = 'OtherLinux'
    class SubclassE(Base):
        platform = 'FreeBSD'
        distribution = 'FreeBSD'
    class SubclassF(SubclassB):
        platform = 'Linux'
        distribution = 'Ubuntu'
        codename = 'trusty'

# Generated at 2022-06-22 22:05:32.973685
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Validate get_distribution_codename() method
    '''
    distribution_codename = get_distribution_codename()

    cls = None
    if distribution_codename == "trusty":
        cls = Ubuntu
    elif distribution_codename == "xenial":
        cls = Ubuntu
    elif distribution_codename == "bionic":
        cls = Ubuntu
    elif distribution_codename == "buster":
        cls = Debian
    elif distribution_codename == "focal":
        cls = Ubuntu

    assert cls is not None

    # Test 2nd distro_codename for Ubuntu bionic
    if distribution_codename == "bionic":
        os_release_info = distro.os_release_info()
        codename = os_release_info.get

# Generated at 2022-06-22 22:05:35.357382
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename is not None and codename != '', "The distribution's codename was not returned"

# Generated at 2022-06-22 22:05:43.412358
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distribution_versions = {
        u'debian': u'',
        u'opensuse-leap': u'15.0',
        u'opensuse-tumbleweed': u'',
        u'fedora': u'',
        u'centos': u'',
        u'ubuntu': u'',
        u'cumulus': u'',
        u'oracle': u'8',
        u'amzn': u'',
        u'rhel': u'',
    }

    for distribution, version in distribution_versions.items():
        distro.id = lambda: distribution  # pylint: disable=unnecessary-lambda
        assert get_distribution_version() == version

# Generated at 2022-06-22 22:05:55.061290
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo(object):
        platform = "Linux"
        distribution = None

        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(Foo)
            return super(cls, new_cls).__new__(new_cls)

    class FooRedHat(Foo):
        platform = "Linux"
        distribution = "RedHat"

    class FooUbuntu(Foo):
        platform = "Linux"
        distribution = "Ubuntu"

    class FooSolaris(Foo):
        platform = "SunOS"

    class FooAIX(Foo):
        platform = "AIX"

    class FooWindows(Foo):
        platform = "Windows"

    assert isinstance(Foo(), Foo)

    class Bar(Foo):
        pass



# Generated at 2022-06-22 22:06:05.803715
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible.module_utils._text import to_bytes
    try:
        from unittest import mock
    except ImportError:
        import mock

    # mocked for Ubuntu 16.04
    mocked_distro_version = mock.Mock(return_value='16.04')
    mocked_distro_id = mock.Mock(return_value='ubuntu')
    mocked_best_version = mock.Mock(return_value='16.04.4')


# Generated at 2022-06-22 22:06:14.300301
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    # Test that a codename is returned when os-release version_codename is set
    os_release_info_original = distro.os_release_info()
    os_release_info = os_release_info_original.copy()
    os_release_info['version_codename'] = 'UnitTestCodename'
    distro._get_lsb_release_info = lambda x: os_release_info

    codename = get_distribution_codename()
    assert codename == 'UnitTestCodename', "codename returned is %s not UnitTestCodename" % codename
    distro._get_os_release_info = lambda x: os_release_info_original

    # Test that a codename is returned when lsb_release codename is set and id is ubuntu

# Generated at 2022-06-22 22:06:15.542655
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '16.04'

# Generated at 2022-06-22 22:06:20.942286
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function to get the distribution codename

    :rtype: bool
    :returns: True if the codename returned is of type NativeString else returns False
    '''
    codename = get_distribution_codename()
    if codename:
        return isinstance(codename, str)
    return False

# Generated at 2022-06-22 22:06:31.850566
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class Sub1(Base):
        platform = "Linux"
        distribution = 'Centos'

    class Sub2(Base):
        platform = 'Linux'
        distribution = 'Debian'

    class Sub3(Base):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class Sub4(Base):
        platform = 'Linux'
        distribution = None

    class Sub5(Base):
        platform = 'Linux'
        distribution = 'Centos'

    class Sub6(Base):
        platform = None
        distribution = None

    class Sub7(Base):
        platform = 'Linux'
        distribution = 'Redhat'

    class Sub8(Base):
        platform = 'Linux'
        distribution = 'Amazon'

    # If we're on CentOS, we should choose the most specific subclass that

# Generated at 2022-06-22 22:06:35.876221
# Unit test for function get_distribution_version
def test_get_distribution_version():

    assert 'any', get_distribution_version() == None
    assert 'redhat', get_distribution_version() == '6.10'
    assert 'debian', get_distribution_version() == '9'

# Generated at 2022-06-22 22:06:45.847490
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function.

    This test is a bit silly.  Since we can't control the machine the tests are running on and
    we don't want to make the tests fail if they are running on a supported platform that we
    didn't cover, we have to try a bunch of different values and then ignore them.  For now, we
    just check that the function returns a non-None value and that it is a string.

    TODO:
        Use |ansible.module_utils.facts.system.distribution.name| to get a value we control
        and make sure it is valid
    '''
    dist_first_try = get_distribution()

    # If the first try failed, we couldn't figure out the distribution.  Try try
    # again.
    if dist_first_try is None:
        dist_second

# Generated at 2022-06-22 22:06:53.475448
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest

    # These tests require the user to be running on a Linux distribution
    if platform.system() != 'Linux':
        return None

    class TestClass(object):
        pass

    class SubClass1(TestClass):
        platform = 'Linux'
        distribution = None

    class SubClass2(TestClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class SubClass3(TestClass):
        platform = 'Linux'
        distribution = 'Fedora'

    class SubClass4(TestClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class SubClass5(TestClass):
        platform = 'Linux'
        distribution = 'Fedora'

    class SubClass6(TestClass):
        platform = None
        distribution = None


# Generated at 2022-06-22 22:07:00.233729
# Unit test for function get_distribution_version
def test_get_distribution_version():
    def _test_version(id, version, expected):
        class FakeDistro(object):
            osr = {
                'id': id,
                'version': version
            }

            @classmethod
            def id(cls):
                return cls.osr['id']

            @classmethod
            def version(cls, *a, **kw):
                return cls.osr['version']

        distribution_version = get_distribution_version()
        assert distribution_version == expected

    # centos
    _test_version('centos', '7.4.1708', '7.4')
    _test_version('centos', '7.4.1', '7.4')
    _test_version('centos', '7', '7')

# Generated at 2022-06-22 22:07:10.682461
# Unit test for function get_distribution
def test_get_distribution():
    import platform

    original_distribution_id = platform.dist
    original_system = platform.system

# Generated at 2022-06-22 22:07:14.404750
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test get_distribution() function
    '''
    mydistro = get_distribution()
    assert mydistro == "Amazon", "Distribution %s is not Amazon" % mydistro


# Generated at 2022-06-22 22:07:24.117062
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class Base1(Base):
        platform = 'linux'

    class Base2(Base):
        platform = 'linux'
        distribution = 'redhat'

    class Base3(Base):
        platform = 'linux'
        distribution = 'centos'

    class Base4(Base):
        platform = 'linux'
        distribution = 'fedora'

    class Base5(Base):
        platform = 'linux'
        distribution = 'unknown'

    class Base6(Base):
        platform = 'windows'
        distribution = 'unknown'

    class Base7(Base):
        platform = 'bsd'
        distribution = 'freebsd'

    class Base8(Base):
        platform = 'bsd'
        distribution = 'openbsd'

    class Derived1(Base1):
        pass



# Generated at 2022-06-22 22:07:25.506123
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == platform.linux_distribution()[0].capitalize()



# Generated at 2022-06-22 22:07:26.861735
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None, "Failed to detect distribution"

# Generated at 2022-06-22 22:07:35.086636
# Unit test for function get_distribution_version
def test_get_distribution_version():

    distribution_map = {
        'Ubuntu': '14.04',
        'Debian': '8.3',
        'RedHat': '7.2',
        'CentOS': '7.2.1511',
        'Fedora': '23',
        'Mint': '17.3',
        'SUSE': '12.1',
        'OpenSUSE': '13.2',
        'SLES': '12-SP1',
        'SLED': '11-SP4'
    }


# Generated at 2022-06-22 22:07:39.648027
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test that the function returns None when not called on a linux machine
    assert get_distribution_version() is None
    # Test that the function returns an empty string when the version cannot be determined
    assert get_distribution_version() == ''

# Generated at 2022-06-22 22:07:50.183117
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for the get_platform_subclass convenience function
    '''
    import platform

    class A:
        platform = 'test'
        distribution = None

    class B(A):
        platform = 'test'
        distribution = 'test_distro'

    class C(A):
        platform = 'test'

    class D(A):
        platform = 'another_platform'
        distribution = 'test_distro'

    class E(C):
        platform = 'another_platform'

    assert platform.system() == 'test'
    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == B
    assert get_platform_subclass(C) == C
    assert get_platform_subclass(D) == A

# Generated at 2022-06-22 22:08:00.727089
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test regular codename
    os_info = {'version_codename': 'buster'}
    distro.distro._os_release_info = os_info
    assert get_distribution_codename() == 'buster'

    # Test no codename, Ubuntu Xenial
    os_info = {'ubuntu_codename': 'xenial'}
    distro.distro._os_release_info = os_info
    assert get_distribution_codename() == 'xenial'

    # Test no codename, Ubuntu
    os_info = {}
    distro.distro._os_release_info = os_info
    distro.distro._lsb_release_info = {'codename': 'bionic'}
    distro.distro._id = 'ubuntu'
    assert get_distribution_cod

# Generated at 2022-06-22 22:08:11.703802
# Unit test for function get_distribution
def test_get_distribution():
    import os
    import shutil
    import tempfile
    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 22:08:21.429779
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    class FakeDistro(object):
        def __init__(self, distro_id, codename):
            self.distro_id = distro_id
            self.codename = codename

        def id(self):
            return self.distro_id

        def codename(self):
            return self.codename

    with distro.DistroPatcher() as distro_patcher:
        distro_patcher.distro = FakeDistro('ubuntu', 'bionic')
        assert get_distribution_codename() == 'bionic'

        # codename == '' returns None
        distro_patcher.distro = FakeDistro('ubuntu', '')
        assert get_distribution_codename() is None

        # codename returned from distro.codename() is None returns None

# Generated at 2022-06-22 22:08:33.205409
# Unit test for function get_distribution_codename

# Generated at 2022-06-22 22:08:43.424727
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import load_platform_subclass
    from ansible.module_utils.basic import get_platform_subclass
    from ansible.module_utils.six import with_metaclass
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.system import System

    class BaseClass(with_metaclass(Distribution, with_metaclass(System, object))):
        pass

    class LinuxSubclass(BaseClass):
        distribution = None
        platform = "Linux"

        def __new__(cls, *args, **kwargs):
            return "LinuxSubclass"

    class DifferentDistroSubclass(BaseClass):
        distribution = "RedHat"
        platform = "Linux"


# Generated at 2022-06-22 22:08:49.819813
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.distro import Distro
    id = 'ubuntu'
    codename = 'xenial'
    os_release_info = {
        'version_codename': codename
    }
    lsb_release_info = {}
    dist = Distro(id, os_release_info, lsb_release_info)
    try:
        assert get_distribution_codename() == codename
    finally:
        dist.reset()

# Generated at 2022-06-22 22:08:59.931884
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    import sys
    import os
    import pytest


# Generated at 2022-06-22 22:09:09.410364
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    platform.system = lambda: 'Linux'
    distro.codename = lambda: 'wheezy'
    assert get_distribution_codename() == 'wheezy'
    distro.codename = lambda: ''
    assert get_distribution_codename() == None
    os_release_info = { 'version_codename': 'xenial' }
    distro.os_release_info = lambda: os_release_info
    assert get_distribution_codename() == 'xenial'
    distro.id = lambda: 'ubuntu'
    os_release_info = { 'version_codename': None }
    lsb_release_info = { 'codename': 'xenial' }
    distro.lsb_release_info = lambda: l

# Generated at 2022-06-22 22:09:15.414866
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # pylint: disable=unused-variable
    class Module:
        platform = None
        distribution = None
    class LinuxOnly(Module):
        platform = 'Linux'
    class RedHatOnly(LinuxOnly):
        distribution = 'RedHat'
    class RedHat6Only(RedHatOnly):
        distribution_release = '6'
    class OnlySolaris(Module):
        platform = 'SunOS'
    class OnlySolaris2(Module):
        platform = 'SunOS'
        distribution = 'Solaris'
    class OnlySolaris11(Module):
        platform = 'SunOS'
        distribution = 'Solaris'
        distribution_version = '11'

    assert get_platform_subclass(Module) == Module, 'Failed to respect default class'

# Generated at 2022-06-22 22:09:16.280943
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '20'

# Generated at 2022-06-22 22:09:20.460502
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    This function tests the case that whether the function of get_distribution_version can get the version of the distribution correctly.
    '''
    version = get_distribution_version()
    assert version is not None and version != '', 'Failed with the None or empty string version'

# Generated at 2022-06-22 22:09:29.456874
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import ansible.module_utils.common._utils as utils
    linux_release = u'''NAME="Ubuntu"
VERSION="14.04.5 LTS, Trusty Tahr"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 14.04.5 LTS"
VERSION_ID="14.04"
HOME_URL="http://www.ubuntu.com/"
SUPPORT_URL="http://help.ubuntu.com/"
BUG_REPORT_URL="http://bugs.launchpad.net/ubuntu/"'''


# Generated at 2022-06-22 22:09:40.524953
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distros_os_release_version = dict(
        amazon=         '',
        centos=         '7.5.1804',
        debian=         '8.11',
        fedora=         '',
        opensuse=       '',
        redhat=         '',
        suse=           '',
        ubuntu=         '',
        clear=          '',
        oracleserver=   '',
    )

# Generated at 2022-06-22 22:09:52.039050
# Unit test for function get_distribution_codename

# Generated at 2022-06-22 22:09:52.849558
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-22 22:09:57.324365
# Unit test for function get_distribution_version
def test_get_distribution_version():
    try:
        distribution = get_distribution()
        version = get_distribution_version()
    except:
        distribution = version = None
    print("Distribution is %s, version is %s" % (distribution, version))


# Generated at 2022-06-22 22:09:58.523733
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-22 22:10:05.006809
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Test:
        platform = 'Linux'
        distribution = None

    class TestSubclass(Test):
        platform = 'Linux'
        distribution = 'Centos'

    class TestSubclass2(Test):
        platform = 'Linux'
        distribution = 'Centos'

    assert Test == get_platform_subclass(Test)
    assert TestSubclass == get_platform_subclass(TestSubclass)
    assert TestSubclass2 == get_platform_subclass(TestSubclass2)
    assert TestSubclass2 == get_platform_subclass(Test)

# Generated at 2022-06-22 22:10:12.260590
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Foo:
        pass

    class FooDarwin(Foo):
        platform = 'Darwin'

    class FooLinux(Foo):
        platform = 'Linux'

    class FooLinuxDistro(FooLinux):
        distribution = 'Centos'

    class FooLinuxDistroVersion(FooLinuxDistro):
        version = '7'

    subclasses = get_all_subclasses(Foo)

    # On Darwin
    if platform.system() == 'Darwin':
        assert get_platform_subclass(Foo) == FooDarwin

    # On Linux

# Generated at 2022-06-22 22:10:23.980271
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class User1:
        def __init__(self):
            self.message = 'User1'
            self.distribution = None
            self.platform = 'Linux'

    class User2(User1):
        def __init__(self):
            super(User2, self).__init__()
            self.message = 'User2'
            self.distribution = 'Redhat'
            self.platform = 'Linux'

    class User3(User1):
        def __init__(self):
            super(User3, self).__init__()
            self.message = 'User3'
            self.distribution = 'OtherLinux'
            self.platform = 'Linux'

    class User4(User1):
        def __init__(self):
            super(User4, self).__init__()
            self.message

# Generated at 2022-06-22 22:10:34.093014
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.facts.system.distribution import DistributionFacts

    dist = DistributionFacts()

    dist_data = dist.populate()

    distro_id = distro.id()
    distro_name = distro_id.capitalize()

    if distro_name in ('Centos', 'Redhat', 'Amazon', 'Fedora'):
        # Don't test centos, redhat, amazon or fedora, they need
        # specific information or they will all return RedHat
        # 'Amazon' is returned by Amazon Linux 1, not 2
        # 'Fedora' is returned by Fedora 29 and below
        pass
    elif distro_name == '' and distro_id == '':
        assert get_distribution() == 'OtherLinux'

# Generated at 2022-06-22 22:10:44.636411
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass

    :returns: Boolean if tests were successful or not
    '''
    ret = True

    class a(object):
        '''
        Base Class A
            This class is used to test the get_platform_subclass function.  It is used as the base case for
            testing the general case where there is no platform specific subclass.
        '''
        platform = None
        distribution = None

    class b(a):
        '''
        Class B
            This class is used to test the get_platform_subclass function.  It is used as a case
            where a subclass based on the platform is defined but the distribution is not defined.
        '''
        platform = u'some_platform'


# Generated at 2022-06-22 22:10:45.907333
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == get_distribution()

# Generated at 2022-06-22 22:10:57.596596
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.distro import Distro
    from ansible.module_utils.distro import DistroNotFoundError

    import os, shutil, tempfile

    # First check the regular codename
    try:
        codename = get_distribution_codename()
        assert codename is not None
    except DistroNotFoundError:
        # Not a linux system
        pass

    # Now create a mock distro and make sure the code uses that
    # instead.  This test isn't exhaustive.  It's just to make sure
    # the code finds os-release instead of lsb_release when os-release
    # is available
    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, 'etc'))

# Generated at 2022-06-22 22:11:03.635124
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function.

    In order to make this function more easily testable, this function was
    separated out from the get_platform function.  This test function covers the
    functionality in get_distribution.
    '''
    # Test the get_distribution function
    distribution = get_distribution()

    if platform.system() == 'Linux':
        if distribution == 'Amzn':
            distribution = 'Amazon'
        elif distribution == 'Rhel':
            distribution = 'Redhat'
        elif not distribution:
            distribution = 'OtherLinux'

    # Test the new name change
    elif distribution == 'Macosx':
        distribution = 'Darwin'

    return distribution

# Generated at 2022-06-22 22:11:08.194701
# Unit test for function get_distribution
def test_get_distribution():
    # test to see if get_distribution returns the expected output
    distribution = get_distribution()

    if distribution == 'Darwin':
        assert distribution == platform.system()

    elif distribution == 'OtherLinux':
        assert distribution != platform.system()

    else:
        assert distribution == platform.system()

# Generated at 2022-06-22 22:11:11.800269
# Unit test for function get_distribution_version
def test_get_distribution_version():
    platform_system = platform.system()
    platform_id = distro.id()

    assert platform_id in distro.SUPPORTED_DISTROS
    assert isinstance(get_distribution_version(), str)
    assert platform_system == 'Linux'

# Generated at 2022-06-22 22:11:15.118186
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit tests for get_distribution_codename

    :returns: Boolean True when the test completes successfully

    :todo: Add additional test cases for future behavior

    '''

    codename = get_distribution_codename()

    if codename is not None:
        if isinstance(codename, str) and len(codename) > 0:
            return True
        else:
            raise AssertionError("Codename returned isn't a string")
    else:
        raise AssertionError("Codename variable is not set")


# Generated at 2022-06-22 22:11:24.672130
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible_collections.ansible.builtin.plugins.modules.user import User

    class SuperClass:
        pass

    class LinuxSuperClass(SuperClass):
        platform = 'Linux'
        distribution = None

    class RHELSuperClass(SuperClass):
        platform = 'Linux'
        distribution = 'RedHat'

    class Rhel7SuperClass(RHELSuperClass):
        distribution_version = '7'

    class FedoraSuperClass(LinuxSuperClass):
        distribution = 'Fedora'
        distribution_version = None

    # If there is a most specific subclass, it should be returned
    assert Rhel7SuperClass == get_platform_subclass(Rhel7SuperClass)

    # If there is not a most specific subclass, the first non-specific subclass
    # listed should be returned
    assert LinuxSuperClass == get_platform

# Generated at 2022-06-22 22:11:26.143496
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'
    assert get_distribution_version() == '7.4'
    assert get_distribution_codename() is None

# Generated at 2022-06-22 22:11:27.638011
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_platform_subclass == get_platform_subclass

# Generated at 2022-06-22 22:11:28.760403
# Unit test for function get_distribution
def test_get_distribution():
    pass


# Generated at 2022-06-22 22:11:29.929320
# Unit test for function get_distribution_version
def test_get_distribution_version():
    print('test_get_distribution_version')
    assert get_distribution_version() != None
    assert get_distribution_version() != ""


# Generated at 2022-06-22 22:11:31.578845
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == "jessie"

# Generated at 2022-06-22 22:11:42.228529
# Unit test for function get_distribution
def test_get_distribution():
    plat = platform.system()
    if plat == 'Linux':
        # This is a bit of a hack.  Even though we can't control the platform we run on for
        # unit tests, we can replace the distro object with one that has a controlled prefix
        # for its linux distro.  We indicate this with the prefix 'test-' so that we can
        # differentiate between 'Redhat' meaning RHEL and 'test-Redhat' meaning the test prefix.
        orig_distro = distro.linux_distribution
        distro.linux_distribution = lambda: ('Redhat', '7.2.1511', 'Final')
        dist_name = get_distribution()
        assert dist_name == 'Redhat'
        distro.linux_distribution = lambda: ('test-Redhat', '7.2.1511', 'Final')
