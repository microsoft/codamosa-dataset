

# Generated at 2022-06-22 22:01:51.417348
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Used by test/units/module_utils/platform_subclass_test.py
    '''
    # function test_get_platform_subclass.Class1 is defined in
    # test/units/module_utils/platform_subclass_test.py
    from ansible.module_utils.basic import AnsibleModule

    # Test case 1
    # Test the get_platform_subclass function returns Class1 when
    # distribution and platform matches exactly.
    module_args = dict()
    m = AnsibleModule(argument_spec=module_args)
    result = get_platform_subclass(test_get_platform_subclass.Class1)
    assert (result == test_get_platform_subclass.Class1)

    # Test case 2
    # Test the get_platform_subclass function returns Class3 when
   

# Generated at 2022-06-22 22:01:59.910998
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector


# Generated at 2022-06-22 22:02:06.157759
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule, get_platform_subclass
    from ansible.module_utils.six import with_metaclass, string_types

    class PlatformModule(object):
        pass

    class DebModule(PlatformModule):
        platform = 'Linux'
        distribution = 'Debian'

    class RedHatModule(PlatformModule):
        platform = 'Linux'
        distribution = 'Redhat'

    class LinuxModule(PlatformModule):
        platform = 'Linux'

    class NonLinuxModule(PlatformModule):
        platform = 'NetBSD'

    class FakeModule(AnsibleModule):
        pass

    FakeModule.platform = platform.system()
    FakeModule.distribution = get_distribution()
    FakeModule.codename = get_distribution_codename()

# Generated at 2022-06-22 22:02:18.210179
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # The following code should return the codename of the OS if it is a Linux
    # OS. The distribution and codename should come from /etc/os-release if
    # available. Otherwise, it should return None.

    def _os_release_mock(path):
        class _MockKeyValueData(object):
            def __init__(self, data):
                self.data = data

            def get(self, name, default=None):
                return self.data.get(name, default)


# Generated at 2022-06-22 22:02:23.878479
# Unit test for function get_distribution
def test_get_distribution():
    assert(get_distribution() in [u'Arch', u'Bsd', u'Darwin', u'Freebsd', u'Gentoo', u'Linux', u'Macos',
                                  u'Openbsd', u'Redhat', u'Solaris', u'Suse', u'Coreos', u'Alpine'])

# Generated at 2022-06-22 22:02:33.894730
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = 'Linux'
        distribution = None

    class SubClassA(BaseClass):
        distribution = 'Debian'

    class SubSubClassAA(SubClassA):
        pass

    class SubSubClassBB(SubClassA):
        pass

    class SubClassB(BaseClass):
        distribution = 'Redhat'

    class SubClassC(BaseClass):
        pass

    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(SubClassA) == SubSubClassAA
    assert get_platform_subclass(SubClassB) == SubClassB
    assert get_platform_subclass(SubClassC) == SubClassC

# Generated at 2022-06-22 22:02:42.583380
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    import types
    import unittest

    class PlatformUnitTest(unittest.TestCase):
        def setUp(self):
            self.old_platform = platform.system
            self.old_distribution = get_distribution

        def tearDown(self):
            platform.system = self.old_platform
            get_distribution = self.old_distribution

        def test_no_distro(self):
            platform.system = lambda: 'Darwin'
            get_distribution = lambda: 'Darwin'

            @get_platform_subclass
            class Test:
                pass

            class TestDarwin:
                platform = 'Darwin'

            self.assertIs(Test, TestDarwin, 'get_platform_subclass should not wrap classes with only a platform')


# Generated at 2022-06-22 22:02:45.564852
# Unit test for function get_distribution
def test_get_distribution():
    '''
    get_distribution()
    '''

    assert get_distribution() == 'Freebsd'


# Generated at 2022-06-22 22:02:57.323777
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    assert get_distribution_codename() == None

    # Patch the distro module to return known values
    distro.os_release_info = lambda: {'version_codename': 'bionic'}

    assert get_distribution_codename() == 'bionic'

    distro.os_release_info = lambda: {'version_codename': 'bionic', 'ubuntu_codename': 'xenial'}

    assert get_distribution_codename() == 'bionic'

    distro.os_release_info = lambda: {'ubuntu_codename': 'xenial'}

    assert get_distribution_codename() == 'xenial'

    distro.os_release_info = lambda: {}
    distro.codename = lambda: ''
    distro.id = lambda: 'debian'

   

# Generated at 2022-06-22 22:03:09.001605
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class ClassA(object):
        distribution = None
        platform = 'A'

    class ClassA1(ClassA):
        pass

    class ClassA2(ClassA):
        pass

    class ClassB(object):
        distribution = None
        platform = 'B'

    class ClassB1(ClassB):
        pass

    class ClassB2(ClassB):
        pass

    class ClassC(object):
        distribution = None
        platform = 'C'

    class ClassC1(ClassC):
        pass

    class ClassC2(ClassC):
        pass

    class ClassD(object):
        distribution = 'A'
        platform = 'Linux'

    class ClassD1(ClassD):
        pass

    class ClassD2(ClassD):
        pass


# Generated at 2022-06-22 22:03:19.197484
# Unit test for function get_distribution_version

# Generated at 2022-06-22 22:03:29.826304
# Unit test for function get_distribution
def test_get_distribution():
    import sys

# Generated at 2022-06-22 22:03:42.855267
# Unit test for function get_distribution_version

# Generated at 2022-06-22 22:03:52.490120
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''Test function get_platform_subclass'''
    from ansible.module_utils._text import to_native

    class SuperBaseClass:
        '''Base class for testing get_platform_subclass'''
        platform = None
        distribution = None

    # Test classes
    class CentOS7(SuperBaseClass):
        '''Class for testing get_platform_subclass'''
        platform = 'Linux'
        distribution = 'Centos'

    class CentOS7_class(SuperBaseClass):
        '''Class for testing get_platform_subclass'''
        platform = 'Linux'
        distribution = 'class'

    class CentOS7_code(SuperBaseClass):
        '''Class for testing get_platform_subclass'''
        platform = 'Linux'
        distribution = 'Centos'


# Generated at 2022-06-22 22:04:03.501106
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # create classes for the different platforms
    class AmazonLinux(object):
        platform = 'Linux'
        distribution = 'Amazon'

    class Debian(object):
        platform = 'Linux'
        distribution = 'Debian'

    class Redhat(object):
        platform = 'Linux'
        distribution = 'Redhat'

    class FreeBSD(object):
        platform = 'FreeBSD'
        distribution = None

    class OtherLinux(object):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class Linux(object):
        platform = 'Linux'
        distribution = None

    class Other(object):
        platform = 'Other'
        distribution = None

    # When dealing with an Amazon Linux distro, its class should be used
    assert get_platform_subclass(AmazonLinux) == AmazonLinux

    # When dealing with a Redhat dist

# Generated at 2022-06-22 22:04:12.087744
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible.module_utils.common._collections_compat import Mapping
    import pytest

    class FakeDistro(Mapping):
        # Mapping is an ABC that requires this to be implemented
        def __getitem__(self, item):
            return self.data[item]

        def __iter__(self):
            return iter(self.data)

        def __len__(self):
            return len(self.data)

        def set_data(self, data):
            self.data = data

    fake_distro = FakeDistro()


# Generated at 2022-06-22 22:04:14.899449
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import platform
    assert get_distribution_version() == platform.dist()[1]


# Generated at 2022-06-22 22:04:15.458107
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution()


# Generated at 2022-06-22 22:04:23.295214
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible.module_utils import basic
    import sys
    
    distribution_name = platform.linux_distribution()
    if 'ManjaroLinux' in distribution_name:
        expected_output = '18.0.2'
    elif 'ubuntu' in distribution_name:
        expected_output = '16.04'
    elif 'centos' in distribution_name:
        expected_output = '7.7.1908'
    elif 'fedora' in distribution_name:
        expected_output = '30'
    elif 'debian' in distribution_name:
        expected_output = '9'
    elif 'rhel' in distribution_name:
        expected_output = '7.7'
    elif 'amzn' in distribution_name:
        expected_output = '2'

# Generated at 2022-06-22 22:04:34.985737
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Superclass(object):
        '''
        Superclass for testing purposes
        '''
        platform = 'ABC'
        distribution = None

    class Subclass1(Superclass):
        '''
        First Subclass for testing purposes
        '''
        distribution = 'Hello'
        platform = 'ABC'

    class Subclass2(Superclass):
        '''
        Second Subclass for testing purposes
        '''
        distribution = 'Hello'
        platform = 'DEF'

    class Subclass3(Superclass):
        '''
        Third Subclass for testing purposes
        '''
        distribution = 'Goodbye'
        platform = 'ABC'

    class Subclass4(Superclass):
        '''
        Fourth Subclass for testing purposes
        '''
        distribution = 'Goodbye'
        platform = 'DEF'


# Generated at 2022-06-22 22:04:47.645600
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Tests for the get_platform_subclass function above

    The Person class serves as a base class for the various types of People on different platforms

    The Person class is subclassed into AmericanPerson, DebianPerson, RedhatPerson, AmazonPerson.
    '''
    class Person:
        distribution = None
        platform = 'Linux'

    class AmericanPerson(Person):
        '''
        AmericanPerson is the most generic class, it should be the class returned by
        get_platform_subclass when the platform isn't linux or the distribution cannot
        be determined
        '''
        pass

    class DebianPerson(Person):
        distribution = 'Debian'

    class UbuntuPerson(DebianPerson):
        distribution = 'Ubuntu'

    class RedhatPerson(Person):
        distribution = 'Redhat'


# Generated at 2022-06-22 22:04:54.487415
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        platform = 'linux'

    class B(A):
        distribution = 'redhat'

    class C(B):
        distribution = 'centos'

    class D(B):
        distribution = 'fedora'

    class E(A):
        platform = 'bsd'

    class F(A):
        platform = 'windows'

    class G(A):
        platform = 'bsd'
        distribution = 'freebsd'

    class H(A):
        platform = 'bsd'
        distribution = 'netbsd'

    # Don't specify a distribution or a platform
    assert get_platform_subclass(A) == A

    # Specify a distribution or platform
    assert get_platform_subclass(E) == E
    assert get_platform_subclass(F) == F

    # Try

# Generated at 2022-06-22 22:05:02.862161
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Build test cases for testing function get_distribution_version()

    :rtype: tuple
    :return: Tuple with following items:
        * test_cases - list of test cases to be run
        * expected_results - list of expected test results

    '''

# Generated at 2022-06-22 22:05:12.085593
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        platform = 'generic'
        distribution = None

    class B(A):
        platform = 'Linux'
        distribution = None

    class C(B):
        distribution = 'OtherLinux'

    class D(B):
        distribution = 'RedHat'

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == B
    assert get_platform_subclass(C) == C
    assert get_platform_subclass(D) == D

# Make sure that it really is necessary to specify platform='generic' explicitly.
# This test should fail if platform='generic' is removed from the ``A`` class definition above.

# Generated at 2022-06-22 22:05:18.811369
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version

    :returns: ``True`` if successful
    '''

    assert get_distribution_version() == distro.version()

    return True

if __name__ == "__main__":
    print("Name: '%s'" % get_distribution())
    print("Version: '%s'" % get_distribution_version())
    print("Codename: '%s'" % get_distribution_codename())

# Generated at 2022-06-22 22:05:24.057651
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class base:
        platform = 'linux'
        distribution = None
    class base2:
        platform = 'linux'
        distribution = None
    class foo(base):
        distribution = 'Fedora'
    class bar(base):
        distribution = 'RedHat'
    class bar2(base2):
        distribution = 'RedHat'
    class fedora_bar(foo):
        pass
    platform.system = lambda: 'Linux'
    distro.id = lambda: None
    assert get_platform_subclass(base) == base
    distro.id = lambda: 'fedora'
    assert get_platform_subclass(base) == fedora_bar
    assert get_platform_subclass(base2) == bar2

# Generated at 2022-06-22 22:05:25.150291
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-22 22:05:33.152443
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    PLATFORM_CLASS_MAP = {
        'Linux': {
            'Ubuntu': {
                'subclass': 'LinuxUbuntu',
            },
            'OtherLinux': {
                'subclass': 'LinuxOther',
            },
        },
        'AIX': {
            'subclass': 'AIX',
        },
        'HP-UX': {
            'subclass': 'HPUX',
        },
        'SunOS': {
            'subclass': 'Solaris',
        },
        'FreeBSD': {
            'subclass': 'FreeBSD',
        },
    }

    import sys
    import os

    class FakeDistro():
        '''
        fake implementation of distro module
        '''


# Generated at 2022-06-22 22:05:41.767828
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    if distribution is None:
        distribution = ''
    else:
        distribution = distribution.lower()

    # Check a few distributions
    if distribution == 'amazon':
        return True

    # If we're not on Linux then our module should not be running
    if platform.system() != 'Linux':
        return False

    # Check for some Linux distros
    distros = (
        'arch',
        'debian',
        'fedora',
        'redhat',
        'suse',
        'ubuntu',
    )
    for distro in distros:
        if distribution == distro:
            return True

    # If we get to this point then we could not identify the distribution
    return False

# Generated at 2022-06-22 22:05:53.679739
# Unit test for function get_distribution
def test_get_distribution():
    import platform
    import distro

    original_platform = platform.system
    original_distro = distro.id


# Generated at 2022-06-22 22:05:58.738443
# Unit test for function get_distribution
def test_get_distribution():

    # unit test for linux
    assert get_distribution() == 'Redhat'
    assert get_distribution_version() == '7.6'
    assert get_distribution_codename() == 'Maipo'

    # unit test for windows
    assert get_distribution() == 'Windows'

    # unit test for macos
    assert get_distribution() == 'Darwin'


# unit test for function get_distribution_version

# Generated at 2022-06-22 22:06:08.887514
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Check that the function returns what distributor ID reports
    platform_id = platform.linux_distribution()[0].capitalize()
    this_platform = platform.system()
    output_version = get_distribution_version()
    if this_platform != 'Linux':
        assert output_version is None
    elif platform_id == 'Ubuntu':
        assert output_version == platform.linux_distribution()[1]
    elif platform_id == 'Centos':
        version = platform.linux_distribution()[1]
        # platform.linux_distribution() reports major centos version with minor
        # version mark. We have to split the version and get major version only
        assert output_version == version.split(".")[0]
    elif platform_id == 'Fedora':
        assert output_version == platform.linux_dist

# Generated at 2022-06-22 22:06:11.126876
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Returns the code name for the current linux distribution
    '''
    # Test for Ubuntu
    assert get_distribution_codename() == u'bionic'

# Generated at 2022-06-22 22:06:17.512927
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test get_distribution_version function implementation
    '''

# Generated at 2022-06-22 22:06:29.066132
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Test function get_platform_subclass()
    """
    from collections import namedtuple

    # This method is used to set the string returned by platform.system() and the distribution
    record_platform_info = namedtuple('record_platform_info', ['system', 'distribution'])
    platform_info = record_platform_info('Linux', 'Fedora')

    # This method is used to set the string returned by platform.system() and the distribution
    def get_platform_info():
        return platform_info

    # This is the base class that we are going to find the platform specific subclass for.
    class BaseClass():
        platform = None
        distribution = None

    # Create a class for the specific platform we are running on
    class Fedora(BaseClass):
        platform = 'Linux'
        distribution = 'Fedora'

    #

# Generated at 2022-06-22 22:06:35.279186
# Unit test for function get_distribution
def test_get_distribution():
    """Tests for distribution detection code

    Most of the distribution detection code comes from the python-distro package,
    so the best we can do is verify that the output of our functions is the same
    as what the distro package gives.  This is not a unit test in the strictest
    sense.  It's more of a validation test.

    """
    assert get_distribution() == distro.id().capitalize()
    assert get_distribution_version() == distro.version()
    if distro.id() == 'ubuntu':
        assert get_distribution_codename() == distro.codename()

# Generated at 2022-06-22 22:06:37.539779
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-22 22:06:40.619085
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import distro
    distro.os_info_cache = {}
    assert distro.version() == get_distribution_version()



# Generated at 2022-06-22 22:06:43.092872
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Call...
    codename = get_distribution_codename()
    # ...and test
    assert codename == "xenial"

# Generated at 2022-06-22 22:06:46.797336
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == None or isinstance(get_distribution_version(), (str, unicode))
    assert len(get_distribution_version()) >= 0 or get_distribution_version() == ''

# Generated at 2022-06-22 22:06:48.468307
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-22 22:06:51.317779
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    from ansible.module_utils import basic

    assert basic.get_distribution_codename() is None

# Generated at 2022-06-22 22:07:03.167212
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    The following unit test demonstrates the use of get_platform_subclass()

    The class hierarchy used for testing is as follows:

    .. code-block:: python

        |
        +- BaseUser
        |
        +- LinuxUser
        |
        +- BSDUser
        |
        +- LinuxDistro1User
        |
        +- LinuxDistro2User

    :rtype: None
    :returns: None
    '''
    import unittest
    import platform

    # Set up the test

    class BaseUser:
        platform = None
        distribution = None

    class LinuxUser(BaseUser):
        platform = "Linux"
        distribution = None

    class BSDUser(BaseUser):
        platform = "BSD"
        distribution = None


# Generated at 2022-06-22 22:07:04.855604
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'jessie'

# Generated at 2022-06-22 22:07:09.953726
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Validates a specific platform.system() == 'Linux' and distro.id() == 'centos' return the value of 'distro.codename()'
    :rtype: bool
    :returns: True if get_distribution_codename() returns the value of distro.codename()
    '''
    assert get_distribution_codename() == distro.codename()

# Generated at 2022-06-22 22:07:20.548494
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test if function get_distribution_codename returns correct code name for distro.
    '''
    class TestDistro:
        '''
        Override distro objects with test values.
        '''
        def os_release_info():
            '''
            Mock os_release_info() function.
            '''
            os_release_info = {'version_codename': 'bionic', 'ubuntu_codename': None}
            return os_release_info

        def id():
            '''
            Mock id() function.
            '''
            return 'ubuntu'

        def lsb_release_info():
            '''
            Mock lsb_release_info() function.
            '''
            lsb_release_info = {'codename': 'bionic'}
            return lsb_release_

# Generated at 2022-06-22 22:07:27.889043
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = None
        distribution = None

        def test_method(cls):
            return "BaseClass:%s" % cls

    class Test1(BaseClass):
        platform = 'NotLinux'

    class Test2(BaseClass):
        distribution = 'Fedora'

    class Test3(BaseClass):
        platform = 'Linux'
        distribution = 'Fedora'

    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(Test1) == Test1
    assert get_platform_subclass(Test2) == Test2
    assert get_platform_subclass(Test3) == Test3

# Generated at 2022-06-22 22:07:28.927220
# Unit test for function get_distribution
def test_get_distribution():
    # get_distribution return false
    assert get_distribution()



# Generated at 2022-06-22 22:07:36.125389
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    test get_distribution_version()
    '''

    my_distro = {'id': '', 'version': '', 'version_best': ''}
    for distro in ['redhat', 'debian', 'SUSE', 'centos', 'fedora']:
        my_distro['id'] = distro
        if distro in ['redhat', 'centos', 'fedora']:
            my_distro['version'] = '1.2.3.4'
            my_distro['version_best'] = '1.2.0'
        else:
            my_distro['version'] = '1.2.3'
            my_distro['version_best'] = '1.2.3'

        orig_distro_id = distro.id

# Generated at 2022-06-22 22:07:47.988603
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    """
    Unit test for the get_distribution_codename function.
    """
    # Set up distribution info for the various platforms

# Generated at 2022-06-22 22:07:49.661752
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-22 22:08:00.610493
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test normal cases
    class Test(object):
        platform = 'Linux'
        distribution = 'CentOS'
    class Test_Centos_Linux(Test):
        pass

    assert get_platform_subclass(Test) is Test_Centos_Linux

    # Test fallback to platform when distribution not defined
    class Test(object):
        platform = 'Linux'
    class Test_Linux(Test):
        pass

    assert get_platform_subclass(Test) is Test_Linux

    # Test fallback to base class when neither platform nor distribution defined
    class Test(object):
        pass
    assert get_platform_subclass(Test) is Test

    # Test fallback to base class when an unsupported platform is used
    class Test(object):
        platform = 'FreeBSD'
    assert get_platform_subclass(Test) is Test


# Generated at 2022-06-22 22:08:11.223343
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version()
    '''
    #{Distro:Version}
    test_data = {
        u'RedHat': u'6.5',
        u'CentOS': u'7.3',
        u'Debian': u'8',
        u'Ubuntu': u'16.04',
        u'freebsd': u'10',
        u'windoes': u'',
    }

    for distro in test_data:
        #Do not return None if not on a Linux distro (Issue #27196)
        if distro == u'freebsd':
            assert get_distribution_version() is None
        else:
            assert get_distribution_version() == test_data[distro]

# Generated at 2022-06-22 22:08:15.493964
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test that the codename is returned properly
    distribution = get_distribution_codename()
    assert distribution is not None

    # Test that the codename is returned properly
    # when there is no codename
    distribution = get_platform_subclass()
    assert distribution == get_distribution_codename()

# Generated at 2022-06-22 22:08:24.472720
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Create an example class hierarchy and find the most specific subclass for the platform we're running on
    class Base:
        platform = platform.system()
        distribution = get_distribution()

    class RedHat(Base):
        platform = 'Linux'
        distribution = 'RedHat'

    class SuSE(RedHat):
        platform = 'Linux'
        distribution = 'SuSE'

    class OtherLinux(Base):
        platform = 'Linux'
        distribution = ''  # a blank string for generic Linux

    class NotLinux(Base):
        platform = 'Darwin'
        distribution = None

    class NotLinuxRedHat(NotLinux, RedHat):
        platform = 'Darwin'
        distribution = 'RedHat'

    class NotLinuxBase(NotLinux):
        platform = None
        distribution = None


# Generated at 2022-06-22 22:08:35.566683
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        pass
    class B(object):
        platform = 'Linux'
    class C(object):
        platform = 'Linux'
        distribution = 'EulerOS'
    class D(object):
        platform = 'Linux'
        distribution = 'EulerOS'
    class E(object):
        platform = 'Linux'
        distribution = 'EulerOS'
    class F(object):
        platform = 'FreeBSD'
    class G(object):
        platform = 'FreeBSD'
        distribution = 'FreeBSD'

    # This test was developed while running on a FreeBSD system
    # get_distribution returns None
    assert get_distribution() is None
    # get_platform_subclass(A) should return A because no subclasses set platform or distribution
    assert get_platform_subclass(A) == A

# Generated at 2022-06-22 22:08:36.832821
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-22 22:08:45.920083
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    """
    Test the function get_distribution_codename()
    """
    from ansible.module_utils.common.test_utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase

    # Test Debian based Linux distro
    class TestDistributionCodenameDebian(ModuleTestCase):
        """
        Test Debian based Linux distro codename
        """
        def test_get_distribution_codename_debian_codename(self):
            """
            Test Debian based Linux distro codename
            """
            if platform.system() != 'Linux':
                raise self.skipTest('Test only applicable to Linux distributions')

            try:
                codename = get_distribution_codename()
            except (AnsibleExitJson, AnsibleFailJson):
                raise
            except Exception as err:
                raise

# Generated at 2022-06-22 22:08:54.022539
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Check that the version is correctly parsed and returned.
    '''
    # Test 1: parsing normal version number
    # Fedora 29:
    distroName = distro.name()
    distroId = distro.id()
    distroVersion = distro.version()
    distributionVersion = get_distribution_version()
    assert(distroVersion == distributionVersion)

    # Test 2: parsing a string which doesn't contain a version number
    # Ubuntu 18.04 LTS:
    distro.name = lambda: None
    distro.id = lambda: u'ubuntu'
    distro.version = lambda: u'bionic'
    distributionVersion = get_distribution_version()
    assert (distributionVersion == u'18.04')

    # Test 3: parsing a string with multiple version numbers
    # Centos 7

# Generated at 2022-06-22 22:09:02.669960
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    A simple test to verify the functionality of get_platform_subclass

    This test is not invoked by any of the Ansible test suites, but can be run
    manually.
    '''
    from ansible.module_utils.basic import get_platform_subclass

    class UbuntuSuperclass:
        """Represents the behaviour of an Ubuntu-based distro"""

    class DebianSubclass(UbuntuSuperclass):
        """Represents the behaviour of the Debian distro"""
        distribution = "Debian"

    class RedhatSuperclass:
        """Represents the behaviour of a Redhat-based distro"""

    class CentOSSubclass(RedhatSuperclass):
        """Represents the behaviour of the CentOS distro"""
        distribution = "CentOS"

    platform = "Linux"

    assert get_platform_subclass(UbuntuSuperclass)

# Generated at 2022-06-22 22:09:04.416411
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None



# Generated at 2022-06-22 22:09:15.719850
# Unit test for function get_distribution_codename

# Generated at 2022-06-22 22:09:25.233570
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = "Linux"
        distribution = None

    class LinuxSubclass1(Base):
        distribution = "Redhat"

    class LinuxSubclass2(LinuxSubclass1):
        distribution = "RedHat"

    class LinuxSubclass3(Base):
        platform = "Linux"

    class RpmBase:
        platform = "Linux"
        distribution = None

    class DpkgBase:
        platform = "Linux"
        distribution = None

    class RedHatUser(RpmBase):
        distribution = "Redhat"

    class RedHatRpmUser(RedHatUser):
        platform = "Linux"

    class DebianUser(DpkgBase):
        distribution = "Debian"

    class DebianDpkgUser(DebianUser):
        platform = "Linux"


# Generated at 2022-06-22 22:09:36.730287
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    if distribution == 'Amazon':
        assert(distribution)
    elif distribution == 'Redhat':
        assert(distribution)
    elif 'SUSE' in distribution:
        assert(distribution)
    elif 'Ubuntu' in distribution:
        assert(distribution)
    elif 'Debian' in distribution:
        assert(distribution)
    elif distribution == 'Centos':
        assert(distribution)
    elif distribution == 'Arch':
        assert(distribution)
    elif distribution == 'Alpine':
        assert(distribution)
    elif distribution == 'Gentoo':
        assert(distribution)
    elif distribution == 'Mandriva':
        assert(distribution)
    elif distribution == 'Void':
        assert(distribution)
   

# Generated at 2022-06-22 22:09:44.816829
# Unit test for function get_distribution
def test_get_distribution():
    """
    Test the return value of get_distribution
    """
    # Testing get_distribution()
    def set_distro(name):
        '''
        Set the return value of distro.id()
        '''
        distro.id = lambda: name
    # Currently supports centos, debian and redhat
    set_distro("centos")
    assert get_distribution() == "Redhat"
    set_distro("debian")
    assert get_distribution() == "Debian"
    set_distro("redhat")
    assert get_distribution() == "Redhat"
    # Other distros get their distro.id() value
    set_distro("amzn")
    assert get_distribution() == "Amzn"
    set_distro("ubuntu")
    assert get_distribution()

# Generated at 2022-06-22 22:09:55.107536
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for get_platform_subclass function

    :raises: AssertionError if the function does not do what we expect
    '''
    # pylint: disable=unused-argument, no-self-use
    class Base(object):
        '''
        Base class used as parent class for testing
        '''
        platform = 'Generic'
        distribution = None

    class LinuxMixin(object):
        '''
        Linux-specific mixin
        '''
        platform = 'Linux'

    class LinuxAmazon(LinuxMixin, Base):
        '''
        Amazon linux is a specific linux distro
        '''
        distribution = 'Amazon'


# Generated at 2022-06-22 22:10:04.179958
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit tests for function get_platform_subclass()
    '''
    # Test 1
    class BaseClass:
        platform = None
        distribution = None

    class LinuxClass(BaseClass):
        platform = 'Linux'
        distribution = None

    class TestClass(LinuxClass):
        distribution = 'Linux'

    assert(TestClass.platform == 'Linux' and TestClass.distribution == 'Linux')

    # Test 2
    class TestClass2(TestClass):
        distribution = 'Linux'

    assert(TestClass2.platform == 'Linux' and TestClass2.distribution == 'Linux')

    # Test 3
    class LinuxClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Linux'

    class TestClass3(LinuxClass2):
        pass


# Generated at 2022-06-22 22:10:16.257096
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        platform = 'A'
        distribution = None

    class A1A(A):
        platform = 'A'
        distribution = 'A1'

    class A2A(A):
        platform = 'A'
        distribution = 'A2'

    class B1A1(A1A):
        platform = 'B1'

    class B2A1(A1A):
        platform = 'B2'

    class C1B1A1(B1A1):
        platform = 'C1'

    class C2B1A2(B1A1):
        platform = 'C2'

    class D1C1B1A1(C1B1A1):
        platform = 'D1'


# Generated at 2022-06-22 22:10:18.072785
# Unit test for function get_distribution
def test_get_distribution():
    distribution_name = get_distribution()
    return distribution_name

# Generated at 2022-06-22 22:10:29.339003
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo(object):
        platform = 'Linux'
        distribution = None

    class Bar(Foo):
        distribution = 'Redhat'

    class Quux(Foo):
        distribution = 'Fedora'

    class Spam(Foo):
        distribution = 'Debian'
        platform = 'FreeBSD'

    class Apache:
        platform = 'Linux'
        distribution = 'Redhat'

    assert Quux == get_platform_subclass(Foo)

    class Spam(Foo):
        platform = 'Linux'
        distribution = 'Debian'

    assert Spam == get_platform_subclass(Foo)
    assert Bar == get_platform_subclass(Apache)
    assert Apache == get_platform_subclass(Apache)

# Generated at 2022-06-22 22:10:31.361112
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-22 22:10:43.494919
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils._text import to_native

    class RandomClass(object):
        pass

    # Create a dummy class for each specific subclass we want to test
    class DebianSubclass(RandomClass):
        distribution = 'Debian'
        platform = 'Linux'

    class AmznSubclass(RandomClass):
        distribution = 'Amazon'
        platform = 'Linux'

    class OtherLinuxSubclass(RandomClass):
        distribution = 'OtherLinux'
        platform = 'Linux'

    class OSXSubclass(RandomClass):
        distribution = None
        platform = 'Darwin'

    class WindowsSubclass(RandomClass):
        distribution = None
        platform = 'Windows'

    # This is a list of platform/distro combinations we want to test.  We need
    # to check each of these because we have different code paths in the

# Generated at 2022-06-22 22:10:46.893930
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    This test case tests the get_distribution_version() function across different platforms.
    """
    assert get_distribution_version() is not None

# Generated at 2022-06-22 22:10:58.050726
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass()
    '''

    # For this test we will create a subclass class hierarchy.
    # The class hierarchy is as follows:
    #                   Platform
    #                 /     |     \
    #              Linux  Windows  Mac
    #             /    \         |
    # Distro1 Distro2   WinSubClass
    #
    # This will allow us to test several different code paths within the function
    #

    class Windows:
        platform = 'Windows'
        distribution = None

    class Mac:
        platform = 'Mac'
        distribution = None

    class Linux:
        platform = 'Linux'
        distribution = None

    class WindowsSubClass(Windows):
        pass

    class Distro1(Linux):
        distribution = 'Distro1'


# Generated at 2022-06-22 22:10:58.811674
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert distribution == 'Darwin'


# Generated at 2022-06-22 22:11:01.595098
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test Redhat based distros
    assert get_distribution_version() == '7.6'
    assert get_distribution_version() == '7.6'

    # Test Debian based distros
    assert get_distribution_version() == 'stretch'

# Generated at 2022-06-22 22:11:13.330488
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Can we find a subclass for the class and platform we ask for?
    '''

    class Test1:
        '''
        Test class that has subclasses
        '''
        pass

    class Test1AIX(Test1):
        '''
        Test class that has subclasses
        '''
        platform = 'AIX'
        distribution = None

    class Test1Linux(Test1):
        '''
        Test class that has subclasses
        '''
        platform = 'Linux'
        distribution = None

    class Test1LinuxDistro(Test1):
        '''
        Test class that has subclasses
        '''
        platform = 'Linux'
        distribution = 'LinuxDistro'

    class Test2:
        '''
        Test class that has subclasses
        '''
        pass


# Generated at 2022-06-22 22:11:15.723095
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Debian'

if __name__ == '__main__':
    test_get_distribution()

# Generated at 2022-06-22 22:11:19.432456
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for function get_distribution
    '''
    assert get_distribution() == 'Rhel'
    assert get_distribution_version() == '8.0'
    assert get_distribution_codename() == 'Ootpa'



# Generated at 2022-06-22 22:11:21.375157
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Just test that it returns back a string.
    assert isinstance(get_distribution_version(), basestring)



# Generated at 2022-06-22 22:11:28.338930
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class TestClass(object):
        platform = platform.system()
        distribution = get_distribution()

    class TestClassLinux(TestClass):
        platform = 'Linux'

    class TestClassLinuxGeneric(TestClass):
        platform = 'Linux'
        distribution = None

    class TestClassLinuxAmzn(TestClass):
        platform = 'Linux'
        distribution = 'Amazon'

    assert TestClassLinuxAmzn == get_platform_subclass(TestClass), "Found a subclass for Amazon Linux"
    assert TestClassLinux == get_platform_subclass(TestClassLinuxAmzn), "Found a generic subclass for Linux"
    assert TestClass == get_platform_subclass(TestClassLinuxGeneric), "Found base class for get_platform_subclass"

# Generated at 2022-06-22 22:11:40.463296
# Unit test for function get_distribution_version
def test_get_distribution_version():
    if platform.system() == 'Linux':
        distro.id = lambda: 'RedHat'
        distro.version = lambda: '7.5'
        distro.version_best = lambda: '7.5.1804'
        assert get_distribution_version() == '7.5'

        distro.id = lambda: 'CentOS'
        distro.version = lambda: '7'
        distro.version_best = lambda: '7.5.1804'
        assert get_distribution_version() == '7.5'

        distro.id = lambda: 'Debian'
        distro.version = lambda: '10'
        distro.version_best = lambda: '10.1'
        assert get_distribution_version() == '10.1'


# Generated at 2022-06-22 22:11:47.030298
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestClass:
        platform = 'Linux'
        distribution = None

    class TestLinux:
        platform = 'Linux'
        distribution = None

    class TestRedhat:
        platform = 'Linux'
        distribution = 'Redhat'

    class TestRedhatOld:
        platform = 'Linux'
        distribution = 'Redhat'

    class TestRedhatOld2:
        platform = 'Linux'
        distribution = 'Redhat'

    class TestDebian:
        platform = 'Linux'
        distribution = 'Debian'

    assert get_platform_subclass(TestClass) == TestClass
    assert get_platform_subclass(TestLinux) == TestLinux
    assert get_platform_subclass(TestRedhat) == TestRedhat
    assert get_platform_subclass(TestRedhatOld) == TestRedhatOld

    platform