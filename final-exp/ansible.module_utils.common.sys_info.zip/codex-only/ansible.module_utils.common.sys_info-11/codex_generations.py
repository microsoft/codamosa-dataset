

# Generated at 2022-06-22 22:01:49.530105
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils import basic

    distro = basic.get_distribution()
    version = basic.get_distribution_version()
    codename = basic.get_distribution_codename()

    # Test on Debian
    linux_release = '''PRETTY_NAME="Debian GNU/Linux 9 (stretch)"
NAME="Debian GNU/Linux"
VERSION_ID="9"
VERSION="9 (stretch)"
ID=debian
HOME_URL="https://www.debian.org/"
SUPPORT_URL="https://www.debian.org/support"
BUG_REPORT_URL="https://bugs.debian.org/"
'''
    basic.__distro = None
    basic.__distro_id = None
    basic.__distro_version = None
    basic._distro = None
    basic._

# Generated at 2022-06-22 22:02:01.973983
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    class TestDistro:
        @staticmethod
        def id():
            return u'debian'

        @staticmethod
        def codename():
            return u''

        @staticmethod
        def os_release_info():
            return {'version_codename': u''}

        @staticmethod
        def lsb_release_info():
            return {'codename': u''}

    # Test non-linux OS
    platform_system_save = platform.system
    platform.system = lambda: 'SomeOtherOS'
    assert get_distribution_codename() is None
    platform.system = platform_system_save

    # Test linux OS when codename is not available
    platform_system_save = platform.system
    platform.system = lambda: 'Linux'
    distro_id_save = distro.id
    dist

# Generated at 2022-06-22 22:02:14.975551
# Unit test for function get_distribution_version
def test_get_distribution_version():
    def fake_distro(distro_name):
        def _fake_distro(**kwargs):
            if kwargs.get('id', None) == 'id':
                return distro_name
        return _fake_distro

    tests = {
        'centos7': ('Centos', u'7.4.1708'),
        'centos8': ('Centos', u'8.0'),
        'debian10': ('Debian', u'10'),
        'ubuntu1804': ('Ubuntu', u'18.04.2'),
    }

    for test in tests:
        (distro_name, version) = tests[test]

        assert get_distribution_version() == version
        assert get_distribution_version(fake_distro(distro_name)) == version

# Generated at 2022-06-22 22:02:16.567146
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
  codename = get_distribution_codename()
  assert codename == 'disco'

# Generated at 2022-06-22 22:02:18.583828
# Unit test for function get_distribution_version
def test_get_distribution_version():

    distro_vers = get_distribution_version()
    if distro_vers is not None:
        assert isinstance(get_distribution_version(), str)
    else:
        assert get_distribution_version() is None

# Generated at 2022-06-22 22:02:29.889337
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest
    import sys

    class Device(object):
        platform = None
        distribution = None

    class smart_phone(Device):
        platform = 'Linux'

    class android_phone(smart_phone):
        distribution = 'Android'

    class apple_phone(smart_phone):
        distribution = 'Apple'

    class apple_phone_2(apple_phone):
        pass

    class computer(Device):
        platform = 'Linux'

    class computer_apple(computer):
        distribution = 'Apple'

    class computer_apple_2(computer_apple):
        pass

    class computer_android(computer):
        distribution = 'Android'

    class computer_android_2(computer_android):
        pass

    class computer_other(computer):
        distribution = 'OtherLinux'


# Generated at 2022-06-22 22:02:32.914932
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() in ('Freebsd', 'Linux', 'Openbsd', 'Netbsd', 'Dragonfly', 'Darwin', 'Sunos', 'Aix')



# Generated at 2022-06-22 22:02:41.788634
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    This unittest implements a simple class hierarchy and its purpose is to check if the get_platform_subclass function
    properly returns the platform specific subclass based on the class provided and the current running platform.
    '''
    class base_class():
        """
        This is the base class for the hierarchy.
        It does not provide any platform specific implementation.
        """
        pass

    class platform1_class(base_class):
        """
        This class implements the first platform specific implementation.
        """
        platform = 'platform1'

    class platform1_child1_class(platform1_class):
        """
        This class is a child of the first platform specific implementation and implements the first distribution specific
        implementation.
        """
        distribution = 'platform1_distribution1'


# Generated at 2022-06-22 22:02:47.725179
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit tests for function get_distribution_codename()
    :return: None if all tests pass
    '''

    ret = get_distribution_codename()
    if not isinstance(ret, str):
        return 'get_distribution_codename() return value is not a string'
    return None

# Generated at 2022-06-22 22:02:49.175725
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == platform.linux_distribution()[1]

# Generated at 2022-06-22 22:03:01.166724
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # For test purpose we are importing the following modules under a different name so we can mock their
    # behavior for testing purposes.
    import sys
    import platform as plat
    import distro as ds
    from distro import os_release_info as ori
    from distro import lsb_release_info as lri
    from distro import codename as cn
    from ansible.module_utils.common._utils import get_all_subclasses

    # this is a mock for platform.system()
    def mock_plat_system(actual_platform):
        plat.system = lambda: actual_platform

    # this is a mock for distro.id()
    def mock_distro_id(actual_distro_id):
        ds.id = lambda: actual_distro_id

    # this is a mock for distro.os

# Generated at 2022-06-22 22:03:13.307997
# Unit test for function get_distribution_codename

# Generated at 2022-06-22 22:03:23.673929
# Unit test for function get_distribution
def test_get_distribution():
    test_cases = (
        ('Linux', 'debian', 'Debian'),
        ('Linux', 'fedora', 'Fedora'),
        ('Linux', 'FreeBSD', 'Freebsd'),
        ('Linux', 'redhat', 'Redhat'),
        ('Linux', '', 'OtherLinux'),
        ('Linux', 'amzn', 'Amazon'),
        ('Linux', None, 'OtherLinux'),
        ('', '', None),
        ('', None, None),
        (None, None, None),
        ('Linux', 'ubuntu', 'Ubuntu'),
        ('Linux', 'SuSE', 'SuSE'),
        ('Linux', 'scientific', 'Scientific'),
        ('Linux', 'alt', 'ALT'),
        ('SunOS', '', 'Solaris'),
        ('')
    )

# Generated at 2022-06-22 22:03:33.524935
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.facts.test_distribution_implementations import TestDistribution
    if platform.system() != 'Linux':
        raise AssertionError('Unable to run tests on non-Linux platforms')


# Generated at 2022-06-22 22:03:41.914514
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # An issue with the distro library has been reported.
    # https://github.com/nir0s/distro/issues/69
    # https://github.com/nir0s/distro/issues/71
    # This can cause distro.version() to return ''.  Since we've worked around this,
    # ensure that the returned string is a number.
    version = get_distribution_version()
    if version:
        try:
            int(version)
        except ValueError:
            return False
    return True

# Generated at 2022-06-22 22:03:51.890291
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass
    class SubclassNotLinux(Base):
        platform = 'Darwin'
    class SubclassNotRedhat(Base):
        platform = 'Linux'
    class SubclassNot6(Base):
        distribution = 'RedHat'
        distribution_version = '5'
    class SubclassNot5(Base):
        distribution = 'RedHat'
        distribution_version = '5'
    class SubclassNot5(Base):
        distribution = 'RedHat'
        distribution_version = '6'
    class Subclass5(Base):
        distribution = 'RedHat'
        distribution_version = '5'
    class Subclass6(Base):
        distribution = 'RedHat'
        distribution_version = '6'
    class Subclass7(Base):
        distribution = 'RedHat'

# Generated at 2022-06-22 22:04:02.027716
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    test_get_distribution_version : Test get_distribution_version function,
    this function return a version of distribution
    '''

    # For test, we should not use distro module
    # But mock function get_distribution_version is not easy to write in python 2.7
    # So, we can set a fake distribution (id_like and id)
    # Then, we be able to mock get_distribution_version
    distro.DISTRO_VERSION = 'debian'
    distro.DISTRO_NAME = 'debian'
    assert get_distribution_version() is not None

    # cleanup distro
    distro.DISTRO_VERSION = None
    distro.DISTRO_NAME = None

# Generated at 2022-06-22 22:04:04.005641
# Unit test for function get_distribution
def test_get_distribution():
    print("Unit test for function get_distribution")
    print("Passed")
    return



# Generated at 2022-06-22 22:04:07.262121
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # https://bugs.debian.org/cgi-bin/bugreport.cgi?bug=931197
    assert get_distribution_codename() == "buster"

# Generated at 2022-06-22 22:04:14.321655
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import os

    test_version = '7.1'

    def _unset_os_release_version():
        for variable in ['VERSION_ID']:
            if variable in os.environ:
                del os.environ[variable]

    try:
        os.environ['VERSION_ID'] = test_version
        assert test_version == get_distribution_version()

        _unset_os_release_version()
        assert get_distribution_version() is None

    finally:
        _unset_os_release_version()

# Generated at 2022-06-22 22:04:25.864904
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    This is the initial test for get_distribution_version, it tests
    run_command from module_utils/shell.py

    The test checks to see if the get_distribution_version
    function returns the correct version for a distribution.
    The test checks major, minor and extra versions for a
    distribution. The test also checks to make sure that
    a distribution that does not have a minor version
    is working correctly.

    """

    from ansible.module_utils.shell import get_distribution_version

    def test_get_distribution_version_correct_major(monkeypatch):
        """
        Tests to see if the functions handles
        Major version correctly.
        """
        # Test to see if get_distribution_version returns
        # the correct version
        # Get the version of the distribution
        version = get_distribution_

# Generated at 2022-06-22 22:04:27.041385
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None



# Generated at 2022-06-22 22:04:34.878969
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the function get_distribution_codename()
    '''
    tests = {
        'Ubuntu Xenial Xerus': 'xenial',
        'Ubuntu Bionic Beaver': 'bionic',
        'Ubuntu Trusty Tahr': 'trusty',
        'Ubuntu Precise Pangolin': 'precise',
        'Ubuntu Lucid Lynx': 'lucid',
        'Amazon Linux': None,
        'Fedora 27': 'Twenty Seven',
        'Fedora 28': None,
        'Fedora 28': None,
        'CentOS 6': 'Final',
        'CentOS 7': 'Core',
        'CentOS 8': 'Core',

    }

    for test, expected_result in tests.items():
        actual_result = get_distribution_codename()
        assert actual_

# Generated at 2022-06-22 22:04:47.492267
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    import platform
    import unittest

    class TestDistribution(unittest.TestCase):
        '''
        Test the get_distribution function
        '''

        def test_redhat(self):
            '''
            Test that RedHat returns Redhat
            '''
            self.assertEqual(get_distribution_version(), u'7.5')
            self.assertEqual(get_distribution(), u'Redhat')

        def test_centos(self):
            '''
            Test that Centos returns Redhat
            '''
            self.assertEqual(get_distribution_version(), u'7.5')
            self.assertEqual(get_distribution(), u'Redhat')


# Generated at 2022-06-22 22:04:52.113964
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic

    # If a distro-specific subclass is available,
    # get_platform_subclass returns that subclass.
    class DistroA_Subclass_TestA(basic.AnsibleModule):
        platform = 'Fake'
        distribution = 'DistroA'

    class DistroA_Subclass_TestB(basic.AnsibleModule):
        platform = 'Fake'
        distribution = 'DistroA'

    class DistroA_Subclass_TestC(basic.AnsibleModule):
        platform = 'Fake'
        distribution = 'DistroA'

    class Fake_Subclass_Test(basic.AnsibleModule):
        platform = 'Fake'
        distribution = None

    class ModuleClass(basic.AnsibleModule):
        platform = None
        distribution = None


# Generated at 2022-06-22 22:04:55.023124
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test that the function get_distribution_version() returns the correct version
    '''

    assert(get_distribution_version() == '7')

# Generated at 2022-06-22 22:05:02.435500
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo:
        platform = 'Linux'
        distribution = None

    class Redhat(Foo):
        distribution = 'Redhat'

    class Amazon(Redhat):
        distribution = 'Amazon'

    class OtherLinux(Foo):
        platform = 'Linux'
        distribution = None

    class BSD(Foo):
        platform = 'BSD'
        distribution = None

    assert get_platform_subclass(Foo) == OtherLinux
    assert get_platform_subclass(Redhat) == Redhat
    assert get_platform_subclass(Amazon) == Amazon
    assert get_platform_subclass(OtherLinux) == OtherLinux
    assert get_platform_subclass(BSD) == BSD

# Generated at 2022-06-22 22:05:12.597565
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test that get_platform_subclass behaves correctly
    '''
    # An empty set of subclasses.  Should return the base class.
    empty_set_of_subclasses = get_platform_subclass(MockEmptyClass)
    assert empty_set_of_subclasses == MockEmptyClass

    # A set of subclasses, of which two implement the platform and distribution.
    # Should return the first one in the tree.
    first_class = get_platform_subclass(MockDistroClassFirstClass)
    assert first_class == MockDistroClassFirstClass

    # A set of subclasses, of which two implement the platform.
    # Should return the first one in the tree.
    first_class = get_platform_subclass(MockDistroClassFirstClass)
    assert first_class == MockDistroClassFirst

# Generated at 2022-06-22 22:05:15.465510
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename() == 'xenial'
    assert get_distribution_codename() is None

# Generated at 2022-06-22 22:05:16.610210
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-22 22:05:19.316447
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    Test the function get_distribution_version.

    Unit test for function get_distribution_version
    """

    assert get_distribution_version() is not None

# Generated at 2022-06-22 22:05:28.687853
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()

    if distribution is None:
        assert platform.system() != 'Linux'
    else:
        assert distribution in ('Debian', 'Redhat', 'Centos', 'Fedora', 'Freebsd', 'Openbsd', 'Netbsd',
                            'Archlinux', 'Gentoo', 'Slackware', 'Suse', 'Sles', 'Solaris', 'Darwin',
                            'Amazon', 'Sunos', 'Macos', 'Aix', 'Alpine', 'OtherLinux')


# Generated at 2022-06-22 22:05:33.081714
# Unit test for function get_platform_subclass

# Generated at 2022-06-22 22:05:34.221376
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '18.04'

# Generated at 2022-06-22 22:05:35.709972
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-22 22:05:36.797742
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7'

# Generated at 2022-06-22 22:05:47.748250
# Unit test for function get_distribution
def test_get_distribution():

    from ansible.module_utils.six import StringIO

    def do_distro_test(distro_data, expected_distro, expected_version, expected_codename):
        with open('/etc/os-release', 'w') as f:
            f.write(distro_data)

        # reset the cache
        distro._lsb_release_info = None
        distro._os_release_info = None
        distro._distro_id_cache = None
        distro._distro_release_cache = None
        distro._distro_codename_cache = None

        this_distro = get_distribution()
        this_version = get_distribution_version()
        this_codename = get_distribution_codename()

        assert this_distro == expected_distro
        assert this_

# Generated at 2022-06-22 22:05:49.814398
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Centos'
    assert get_distribution_version() == '7.6.1810'

# Generated at 2022-06-22 22:05:50.707489
# Unit test for function get_distribution
def test_get_distribution():
    return get_distribution()


# Generated at 2022-06-22 22:06:00.210543
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import sys

    class LinuxBase(object):
        platform = "Linux"
        distribution = None

    # This class will be returned because it's the most specific subclass that
    # matches the current platform and distribution.
    class RedHat(LinuxBase):
        distribution = "RedHat"

    class DebianBase(LinuxBase):
        distribution = "Debian"

    # This class will be returned because it's the most specific subclass that
    # matches the current platform.
    class Debian(DebianBase):
        pass

    # This class will be returned because it's the only subclass that matches
    # the current platform and an unknown distribution.
    class OtherLinux(LinuxBase):
        pass

    class MacOS(object):
        platform = "Darwin"
        distribution = None

    # This class will be returned because it's the only class with a matching
    #

# Generated at 2022-06-22 22:06:02.519833
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test to see that output of get_distribution is useful
    '''
    assert get_distribution() is not None


# Generated at 2022-06-22 22:06:11.996448
# Unit test for function get_distribution_version
def test_get_distribution_version():
    platform_system = platform.system()
    platform_version = platform.version()

    is_rhel_based_linux_distro = platform_system == 'Linux' and (
        platform_version.startswith('7')) or get_distribution() in ('Redhat', 'OracleLinux')
    is_debian_based_linux_distro = platform_system == 'Linux' and get_distribution() in ('Debian', 'Ubuntu', 'Raspbian')

    if platform_system == 'Linux' and is_rhel_based_linux_distro:
        assert(get_distribution_version() == '7.5')

    if platform_system == 'Linux' and is_debian_based_linux_distro:
        assert(get_distribution_version() == '9.9')


# Generated at 2022-06-22 22:06:13.234561
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-22 22:06:20.300827
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils import basic

    distributions = {
        'Ubuntu': 'bionic',
        'Debian': None,
        'CentOS': 'Core',
        'RedHat': 'Core',
        'OracleLinux': 'Core',
        'Fedora': None,
        'Amazon': 'Core',
        'Scientific': 'Core',
        'SUSE': 'Core',
        'SLES': 'Core',
        'Solaris': None,
        'OtherLinux': None
    }

    for distro_name, codename in distributions.items():
        module = basic.AnsibleModule(argument_spec={})
        module.params = {}
        distro.set_os_distribution(distro_name)
        assert codename == get_distribution_codename()

# Generated at 2022-06-22 22:06:31.160514
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class BaseClass(object):
        platform = 'Linux'
        distribution = None

    class DebianClass(BaseClass):
        distribution = 'Debian'

    class OtherLinuxClass(BaseClass):
        distribution = 'OtherLinux'

    class RedHatClass(BaseClass):
        distribution = 'RedHat'

    # Get a specific distribution subclass from a Linux base class
    linux_cls = get_platform_subclass(BaseClass)
    assert linux_cls is BaseClass

    linux_cls = get_platform_subclass(DebianClass)
    assert linux_cls is DebianClass

    linux_cls = get_platform_subclass(OtherLinuxClass)
    assert linux_cls is OtherLinuxClass

    linux_cls = get_platform_subclass(RedHatClass)
    assert linux_cls is RedHatClass



# Generated at 2022-06-22 22:06:43.023157
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import sys
    from ansible.module_utils.common._utils import get_all_subclasses, get_distribution_codename, get_distribution_version, get_platform_subclass, load_platform_subclass, get_distribution

    class Parent(object):
        platform = 'Linux'
        distribution = None

    class Subclass(Parent):
        distribution = 'Amazon'

    # Ensure the parent class is returned if it's the most specific subclass
    assert(get_platform_subclass(Parent) == Parent)
    # Ensure a subclass of the parent class is returned if it's the most specific subclass
    assert(get_platform_subclass(Parent) == get_platform_subclass(Subclass))
    # Ensure no subclass is returned if it is not the most specific subclass
    class Subclass2(Parent):
        distribution = 'Redhat'

# Generated at 2022-06-22 22:06:55.380532
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Grandpa(object):
        platform = None
        distribution = None

    class Dad(Grandpa):
        platform = "Linux"

    class Son(Dad):
        distribution = "Debian"

    class OtherSon(Dad):
        distribution = "Ubuntu"

    class OtherDad(Grandpa):
        platform = "FreeBSD"

    class OtherSon(OtherDad):
        distribution = "FreeBSD"

    # Test basic class usage
    assert get_platform_subclass(Grandpa) == Grandpa
    assert get_platform_subclass(Dad) == Dad
    assert get_platform_subclass(Son) == Son
    assert get_platform_subclass(OtherSon) == OtherSon
    assert get_platform_subclass(OtherDad) == OtherDad
    assert get_platform_subclass(OtherSon) == OtherSon

    #

# Generated at 2022-06-22 22:06:56.441599
# Unit test for function get_distribution
def test_get_distribution():
    assert (get_distribution() == 'Amzn')

# Generated at 2022-06-22 22:07:07.662191
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distro.id = lambda: 'debian'
    distro.version = lambda: '5'
    distro.version_best = lambda: '5.0.5'
    assert get_distribution_version() == '5'
    distro.version = lambda: '5.0'
    assert get_distribution_version() == '5.0'
    distro.version = lambda: ''
    assert get_distribution_version() == ''

    distro.id = lambda: 'ubuntu'
    distro.version = lambda: '15.10'
    distro.version_best = lambda: '15.10.5'
    distro.os_release_info = lambda: {}
    distro.lsb_release_info = lambda: {}
    assert get_distribution_version() == ''

    distro.os_

# Generated at 2022-06-22 22:07:18.477461
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class P1():
        platform = 'Linux'
        distribution = None

    class P2(P1):
        distribution = 'FooLinux'

    class P3(P1):
        distribution = 'OtherLinux'

    class P4(P2):
        distribution = 'OtherLinux'

    class P5():
        platform = 'Windows'
        distribution = None

    class P6(P1):
        platform = 'Windows'

    class P7(P1):
        platform = 'AIX'

    class P8(P7):
        distribution = 'AIX'

    class P9(P1):
        distribution = 'Amazon'

    class P10(P1):
        distribution = 'Archlinux'

    assert get_platform_subclass(P1) is P1
    assert get_platform_subclass(P2)

# Generated at 2022-06-22 22:07:26.713259
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test that get_distribution_codename returns the expected values
    '''

    import os

    os_release_file = '/etc/os-release'
    lsb_release_file = '/etc/lsb-release'

    with open(os_release_file) as fo:
        os_release_data = fo.read()

    with open(lsb_release_file) as fo:
        lsb_release_data = fo.read()


# Generated at 2022-06-22 22:07:34.933058
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.facts.system.distribution import LinuxDistribution

    def stub_os_release_info(self):
        return {
            'version_codename': 'blah',
            'ubuntu_codename': 'bar',
        }

    def stub_lsb_release_info(self):
        return {
            'codename': 'foo',
        }

    def stub_id(self):
        return 'ubuntu'

    # Test the case where the distribution codename is set in os-release
    LinuxDistribution.os_release_info = stub_os_release_info
    assert get_distribution_codename() == 'blah'

    # Test the case where the distribution codename is set in os-release as a legacy name

# Generated at 2022-06-22 22:07:35.972246
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    pass

# Generated at 2022-06-22 22:07:47.861659
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''

    import os
    import sys
    import tempfile
    import traceback

    from ansible.module_utils.basic import get_platform_subclass

    # Import the common test class
    srcdir = os.path.abspath(os.path.dirname(__file__))
    sys.path.append(os.path.join(srcdir, "../../common"))
    from TestModule import TestCase, ModuleTestCase

    # This is a basic test case class.  Subclasses will add tests,
    # set up data, and clean up after running
    class TestPlatformSubclass(TestCase):

        def setUp(self):
            '''
            create temp directory and cd into it
            '''
            tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 22:07:59.372104
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Ensure that get_distribution_codename() returns the codename as expected
    '''
    distribution_codename_test_cases = dict(
        # Platform and distribution, expected codename
        (u'Linux', u'Ubuntu', u'bionic'),
        (u'Linux', u'Debian', u'sid'),
        (u'Linux', u'Centos', None),
        (u'Linux', u'Redhat', None),
        (u'Linux', u'Amazon', None),
        (u'Linux', u'Fedora', u'unknown'),
        (u'Darwin', u'Darwin', None),
    )
    for platform, distro, codename in distribution_codename_test_cases:
        main_platform = platform
        distro_id = distro
        os_release_info

# Generated at 2022-06-22 22:08:11.025165
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import sys
    import tempfile
    try:
        import ConfigParser
        configparser = ConfigParser
    except ImportError:
        import configparser
    class MockDistro:
        def __init__(self, id, version=None):
            self.id = id
            self.version = version or ''
        def id(self):
            return self.id
        def version(self, best=False):
            return self.version
        def os_release_info(self):
            return {}
        def lsb_release_info(self):
            return {}
    class Mock:
        def os_release_info(self):
            return {'version_codename': None, 'python': '2.7.12'}

# Generated at 2022-06-22 22:08:19.221752
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # The first base class should not have any subclasses
    class myclass1(object):
        distribution = None
        platform = None
        def __init__(self):
            pass

    # This base classe has one subclass : Ubuntu
    class myclass2(object):
        distribution = None
        platform = None
        def __init__(self):
            pass

    # Subclass for Ubuntu
    class myclass2_Ubuntu(myclass2):
        distribution = "Ubuntu"
        platform = "Linux"

    # This base classe has two subclasses : Amazon and Redhat
    class myclass3(object):
        distribution = None
        platform = None

    # Subclass for Amazon
    class myclass3_Amazon(myclass3):
        distribution = "Amazon"
        platform = "Linux"

    # Subclass for Redhat

# Generated at 2022-06-22 22:08:25.314753
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from distutils.version import LooseVersion

    tests = (
        (('Ubuntu', '16.04'), '16.04'),
        (('Ubuntu', '14.04'), '14.04'),
        (('RedHat', '6'), '6'),
        (('RedHat', '7'), '7'),
        (('RedHat', '8'), '8'),
        (('RedHat', '9'), ''),
        (('SuSE', '15'), '15'),
        (('SuSE', '15.1'), '15.1'),
        (('SuSE', '15.2'), '15.2'),
        (('SuSE', '15.3'), '15.3'),
        (('Amazon', '7'), '7'),
    )

    # Pretend we are running on some distribution
    distro_orig = distro

# Generated at 2022-06-22 22:08:35.954268
# Unit test for function get_distribution
def test_get_distribution():

    import sys
    import unittest

    if sys.version_info[0] == 3:
        # On Python3, we can import the module's own defined distribution
        class FakeDistro(object):
            def __init__(self):
                self.name = u'sometest'
                self.version = None
                self.id = None
                self.codename = None

            def id(self):
                return self.id

            def version(self, best=False):
                return self.version

            def codename(self):
                return self.codename

            def os_release_info(self):
                return {'codename': self.codename}

            def lsb_release_info(self):
                return {'codename': self.codename}


# Generated at 2022-06-22 22:08:38.969821
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    codename = get_distribution_codename()
    if platform.system() == 'Linux':
        assert codename is not None
    else:
        assert codename is None


# Generated at 2022-06-22 22:08:40.016837
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-22 22:08:42.381838
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-22 22:08:51.503717
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Setup a system that would return a version like '3'
    platform.system = lambda: 'Linux'
    distro.version = lambda: '3'
    distro.id = lambda: 'Amzn'
    assert get_distribution_version() == '3'

    # Setup a system that would return a version like '18.04'
    distro.version = lambda best=False: '18.04'
    distro.version = lambda: '18.04.4'
    distro.id = lambda: 'Ubuntu'
    assert get_distribution_version() == '18.04'

    # Setup a system that would return a version like '7.5'
    # This is a workaround for CentOS 7.5 not explicitly
    # including the minor version in /etc/os-release and
    # the distro module being unable to

# Generated at 2022-06-22 22:08:54.090455
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None

# Generated at 2022-06-22 22:09:02.695143
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Fedora
    old_distro_id = distro.id
    old_distro_version = distro.version
    old_distro_version_best = distro.version_best
    distro.id = lambda: "fedora"
    # Fedora < 29 do not have version_codename in /etc/os-release
    distro.version = lambda best=True: '29'
    distro.version_best = lambda: '29'
    assert get_distribution_version() == "29"
    distro.id = lambda: "fedora"
    # Fedora >= 29 have version_codename in /etc/os-release but not version_best()
    distro.version = lambda best=True: '29'
    distro.version_best = lambda: '29.1'
    assert get_distribution_version

# Generated at 2022-06-22 22:09:14.467823
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    from ansible.module_utils.basic import AnsibleModule

    class GetPlatformSubclassTestClass(object):
        platform = None
        distribution = None

    class GetPlatformSubclassTestClass1(GetPlatformSubclassTestClass):
        pass

    class GetPlatformSubclassTestClass2(GetPlatformSubclassTestClass):
        pass

    class GetPlatformSubclassTestClass3(GetPlatformSubclassTestClass):
        pass

    class GetPlatformSubclassTestClass4(GetPlatformSubclassTestClass):
        pass

    class GetPlatformSubclassTestClass5(GetPlatformSubclassTestClass):
        pass

    class GetPlatformSubclassTestClass6(GetPlatformSubclassTestClass):
        pass

    class GetPlatformSubclassTestClass7(GetPlatformSubclassTestClass):
        pass


# Generated at 2022-06-22 22:09:18.198123
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Prints the distribution and the codename in a format that the unit test can check.
    '''
    distribution = distro.id()
    codename = get_distribution_codename()
    print("{0}:{1}".format(distribution, codename))

# Generated at 2022-06-22 22:09:19.243557
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-22 22:09:28.074797
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Create simple examples of a platform independent class, a distribution dependent class,
    # a distribution dependent class with the same functionality on multiple distributions,
    # and a distribution dependent class with the same functionality on multiple distributions
    # that happens to be the same class as the platform independent class.

    class Base(object):
        pass

    class DistributionA(Base):
        platform = None
        distribution = 'DistributionA'

    class DistributionB(Base):
        platform = None
        distribution = 'DistributionB'

    class DistributionC(DistributionB):
        platform = None
        distribution = 'DistributionC'

    class PlatformIndependent(DistributionB):
        platform = None
        distribution = None

    class DistributionAandB(PlatformIndependent):
        platform = None
        distribution = None

    class DistributionAandC(DistributionC):
        pass

    #

# Generated at 2022-06-22 22:09:30.486653
# Unit test for function get_distribution
def test_get_distribution():
    '''
    A function that returns the distribution name according to /etc/os-release
    needs to be mocked to test this error case.  The tests for this function
    live in unit/test_distribution_utils.py.
    '''
    pass

# Generated at 2022-06-22 22:09:33.007634
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print('Testing Ansible Distribution codename')
    # Unsupported
    assert get_distribution_codename() == None


# Generated at 2022-06-22 22:09:33.678908
# Unit test for function get_distribution_version
def test_get_distribution_version():
    pass

# Generated at 2022-06-22 22:09:43.589004
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the functions in this module.  We only test the get_distribution_version function because
    it has better bindings to the underlying distro module than the rest.  If that works then it
    is likely the rest work.

    To test, we rely on the fact that ``distro.version()`` and ``distro.version(best=True)`` return
    different results to the function we're testing.  We mock out those results and check that
    the function returns the correct value.
    '''
    import mock

    class TestDistro(object):

        @classmethod
        def id(cls):
            return 'centos'

        @classmethod
        def version(cls, best=False):
            if best:
                return '7.9.9'
            else:
                return '7.9'

    get

# Generated at 2022-06-22 22:09:47.507854
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename
    '''
    codename = get_distribution_codename()
    assert codename is not None

# Generated at 2022-06-22 22:09:53.426506
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test some major distros
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''
    assert get_distribution_version() == ''

# Generated at 2022-06-22 22:10:04.413565
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit tests for function get_distribution_codename
    '''
    expected = ['jessie', 'stretch', 'sid', 'focal', 'bionic', 'disco', 'xenial', 'artful', 'centos 7', None]
    actual = []

    # Modified Path is meant to simulate a system which is running multiple codenames
    # If you are running two versions of Debian, you will see something like this in your
    # /etc/os-release:
    # NAME="Debian GNU/Linux"
    # ID=debian
    # VERSION_ID="8"
    # VERSION="8 (jessie)"
    # VERSION_CODENAME="jessie"
    # PRETTY_NAME="Debian GNU/Linux 8 (jessie)"

# Generated at 2022-06-22 22:10:06.002581
# Unit test for function get_distribution_version
def test_get_distribution_version():

    assert '7.5' == get_distribution_version()

# Generated at 2022-06-22 22:10:12.788096
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class TestCls:
        platform = "TestPlatform"
        distribution = None

    # test subclass method overriding
    class TestClsSubclass(TestCls):
        distribution = "SomeDistro"

    # test recursive subclasses
    class TestClsChild(TestCls):
        def some_method(self):
            pass

    class TestClsChildChild(TestClsChild):
        def some_method(self):
            pass

    result = get_platform_subclass(TestCls)
    assert result == TestCls

    result = get_platform_subclass(TestClsSubclass)
    assert result == TestClsSubclass

    result = get_platform_subclass(TestClsChild)
    assert result == TestClsChild

    result = get_platform_subclass(TestClsChildChild)
   

# Generated at 2022-06-22 22:10:24.543373
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic
    class Foo(ansible.module_utils.basic.AnsibleModule):
        pass
    class LinuxFoo(Foo):
        platform = 'Linux'
    class WindowsBar(Foo):
        platform = 'Windows'
    class AmznLinuxFoo(LinuxFoo):
        distribution = 'Amazon'

    class Foo2(ansible.module_utils.basic.AnsibleModule):
        pass
    class LinuxFoo2(Foo2):
        platform = 'Linux'
    class WindowsBar2(Foo2):
        platform = 'Windows'

    assert get_platform_subclass(Foo) == LinuxFoo
    assert get_platform_subclass(Foo2) == LinuxFoo2
    assert get_platform_subclass(Foo2) != AmznLinux

# Generated at 2022-06-22 22:10:34.452287
# Unit test for function get_distribution
def test_get_distribution():
    distro = get_distribution()
    if platform.system() == 'Linux':
        assert distro in ('Arch', 'Coreos', 'Devuan', 'Fedora', 'Redhat', 'Centos',
                          'Gentoo', 'Mageia', 'Mandrake', 'Mandriva', 'Mint', 'OpenSuse',
                          'Oracle', 'Pld', 'Rosa', 'Slackware', 'Sles', 'Suse', 'Ubuntu',
                          'Alpine', 'Archlinux', 'Amzn', 'Cloudlinux', 'Parabola',
                          'Debian', 'Freebsd', 'Junos', 'Gentoo', 'Netbsd', 'Nixos',
                          'Openwrt', 'Puppy', 'Solus', 'Void', 'Amazon', 'OtherLinux')

# Generated at 2022-06-22 22:10:36.201228
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-22 22:10:37.988019
# Unit test for function get_distribution
def test_get_distribution():

    version = get_distribution()
    assert type(version) is str

# Generated at 2022-06-22 22:10:44.284998
# Unit test for function get_distribution
def test_get_distribution():
    distros = {
        'Linux': 'OtherLinux',
        'HP-UX': 'HpuX',
        'Darwin': 'Macosx',
    }

    for platform_name, expected_distro_name in distros.items():
        class FakePlatform:
            system = platform_name

        saved_platform = platform.system
        platform.system = FakePlatform().system
        distro_name = get_distribution()
        platform.system = saved_platform

        assert distro_name == expected_distro_name

# Generated at 2022-06-22 22:10:56.345480
# Unit test for function get_distribution
def test_get_distribution():
    if platform.system() == 'Linux':
        distribution = get_distribution()
        assert distribution == 'Linux', 'expected `Linux` but got %s' % distribution
    elif platform.system() == 'FreeBSD':
        distribution = get_distribution()
        assert distribution == 'Freebsd', 'expected `Freebsd` but got %s' % distribution
    elif platform.system() == 'OpenBSD':
        distribution = get_distribution()
        assert distribution == 'Openbsd', 'expected `Openbsd` but got %s' % distribution
    elif platform.system() == 'NetBSD':
        distribution = get_distribution()
        assert distribution == 'Netbsd', 'expected `Netbsd` but got %s' % distribution
    elif platform.system() == 'Darwin':
        distribution = get_distribution()

# Generated at 2022-06-22 22:10:57.366014
# Unit test for function get_distribution_version
def test_get_distribution_version():
    pass



# Generated at 2022-06-22 22:10:58.245133
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    If version is None, it returns an empty string
    """
    assert get_distribution_version() == ''

# Generated at 2022-06-22 22:11:04.712132
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    class LinuxUserModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(LinuxUserModule, self).__init__(*args, **kwargs)
        platform = 'Linux'

    class LinuxDebianUserModule(LinuxUserModule):
        distribution = 'Debian'

    class LinuxRedHatUserModule(LinuxUserModule):
        distribution = 'RedHat'

    class LinuxOtherUserModule(LinuxUserModule):
        distribution = 'OtherLinux'

    class LinuxAIXUserModule(LinuxUserModule):
        distribution = 'AIX'
        platform = 'AIX'

    class LinuxOtherLinuxUserModule(LinuxUserModule):
        distribution = ''
        platform = 'Linux'


# Generated at 2022-06-22 22:11:10.563817
# Unit test for function get_distribution
def test_get_distribution():

    # Case 1: OtherLinux is returned for Linux distros not in the list
    distro_name = get_distribution()
    if distro_name == 'Centos':
        print("Success in CentOS")
    elif distro_name == "OtherLinux":
        print("Success in Other Linux")
    else:
        print("Failed to get the distribution")

if __name__ == '__main__':
    test_get_distribution()

# Generated at 2022-06-22 22:11:13.122122
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == u'Redhat'

# Generated at 2022-06-22 22:11:15.068723
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Get the version of the distribution the code is running on
    assert get_distribution_version() == '16.04'

# Generated at 2022-06-22 22:11:26.126369
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo:
        platform = 'Linux'
        distribution = None

    class FooLinux(Foo):
        pass

    class FooLinuxRedhat(FooLinux):
        distribution = 'Redhat'

    class FooLinuxOtherLinux(FooLinux):
        distribution = 'OtherLinux'

    assert get_platform_subclass(Foo) is Foo

    create_platform_subclass = lambda platform, distribution: type('Foo%s%s' % (platform, distribution),
                                                                  (Foo,),
                                                                  dict(platform=platform,
                                                                       distribution=distribution))


# Generated at 2022-06-22 22:11:27.179693
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-22 22:11:39.517892
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.common._collections_compat import UserDict

    def get_platform_system(new_value):
        old_value = platform.system
        platform.system = lambda: new_value
        return old_value

    # Stub out distro
    old_distro_id = distro.id
    old_lsb_release_info = distro.lsb_release_info
    old_os_release_info = distro.os_release_info

    distro_id_retval = old_distro_id()

    distro.id = lambda: distro_id_retval
    distro.lsb_release_info = lambda: UserDict({})
    distro.os_release_info = lambda: UserDict({})

    # Test for 'Linux'
    assert get

# Generated at 2022-06-22 22:11:44.029797
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Ensure that the get_distribution() function returns the correct distribution for a number of distributions.

    .. note:: This test uses a test shim that overrides the platform.dist() function with the expected
        return value to avoid having to use a wide variety of distributions.
    '''
    distribution = get_distribution()

    assert distribution == 'Fedora', 'get_distribution() did not return "Fedora"'
