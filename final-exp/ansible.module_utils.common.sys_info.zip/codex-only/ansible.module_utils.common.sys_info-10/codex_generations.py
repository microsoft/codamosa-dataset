

# Generated at 2022-06-22 22:01:45.914499
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        platform = 'a'

    class B(A):
        pass

    class C(A):
        platform = 'c'

    assert B == get_platform_subclass(A)
    assert C == get_platform_subclass(C)
    assert C == get_platform_subclass(B)

# Generated at 2022-06-22 22:01:56.992243
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Return the version of the distribution the code is running on

    :rtype: NativeString or None
    :returns: A string representation of the version of the distribution. If it
    cannot determine the version, it returns an empty string. If this is not run on
    a Linux machine it returns None.
    '''
    version = None

    # Test with Debian distribution
    needs_best_version = [
        u'centos',
        u'debian',
    ]
    version = '6.1'
    distro_id = 'debian'
    if version is not None:
        if distro_id in needs_best_version:
            version_best = '6.1.11'

# Generated at 2022-06-22 22:02:05.297909
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Run unit tests to validate get_distribution_version()

    :rtype: dict
    :returns: A dictionary of test results
    '''

# Generated at 2022-06-22 22:02:17.512223
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    This is the unit test for get_platform_subclass

    The unit test is a subclass of the main class, then we do the tests:

     - Check if subclass is main class since under Solaris, it is not available
     - Check if subclass is Solaris subclass
     - Check if subclass is Linux subclass
     - Check if subclass is RedHat subclass
    '''
    class MainClass():
        platform = 'Test'
        distribution = None

    class SolarisClass(MainClass):
        platform = 'SunOS'
        distribution = None

    class LinuxClass(MainClass):
        platform = 'Linux'
        distribution = None

    class RedHatClass(LinuxClass):
        distribution = 'Redhat'


# Generated at 2022-06-22 22:02:20.733265
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Verify that get_distribution_codename() returns proper values
    '''
    assert get_distribution_codename() is None
    assert get_distribution_codename() == 'bionic'

# Generated at 2022-06-22 22:02:30.300653
# Unit test for function get_distribution
def test_get_distribution():
    import sys
    if sys.platform.startswith('linux'):
        assert get_distribution().lower() == platform.dist()[0].lower()
    elif sys.platform.startswith('freebsd'):
        assert get_distribution() == 'Freebsd'
    elif sys.platform.startswith('darwin'):
        assert get_distribution() == 'Macosx'
    elif sys.platform.startswith('sunos'):
        assert get_distribution() == 'Solaris'
    else:
        assert get_distribution() == None


# Generated at 2022-06-22 22:02:39.740220
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    distro.id = lambda: 'Ubuntu'
    assert get_distribution_codename() == 'xenial'
    distro.id = lambda: 'Debian'
    assert get_distribution_codename() == 'stretch'
    distro.id = lambda: 'RedHat'
    assert get_distribution_codename() == None
    distro.id = lambda: 'RedHatEnterpriseServer'
    assert get_distribution_codename() == 'Maipo'
    distro.id = lambda: 'SUSE'
    assert get_distribution_codename() == 'Leap'
    distro.id = lambda: 'CentOS'
    assert get_distribution_codename() == None
    distro.id = lambda: 'Fedora'


# Generated at 2022-06-22 22:02:40.923968
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None

# Generated at 2022-06-22 22:02:48.977391
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version.
    '''
    distro_id_pairs = (
        (u'centos', u'Linux'),
        (u'debian', u'Linux'),
        # Fedora 27+ and Ubuntu 18.04 lack /etc/debian_version
        (u'Ubuntu', u'Linux'),
    )

# Generated at 2022-06-22 22:02:52.106230
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for get_distribution()
    '''
    assert get_distribution() == 'Redhat'
    assert get_distribution() == 'Redhat'

# Generated at 2022-06-22 22:02:53.621599
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-22 22:02:55.432492
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-22 22:02:57.488109
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() in ('Linux', 'Freebsd', 'Darwin')



# Generated at 2022-06-22 22:03:00.101346
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for the get_distribution_codename function
    '''
    assert get_distribution_codename() == "sid"

# Generated at 2022-06-22 22:03:07.864779
# Unit test for function get_distribution_version
def test_get_distribution_version():
    "This function unittests the function get_distribution_version()"

    # Get the distribution version on CentOS
    assert get_distribution_version() == u'7'

    # Get the distribution version on Debian
    assert get_distribution_version() == u'9'

    # Get the distribution version on Oracle
    assert get_distribution_version() == u'7'

    # Get the distribution version on RedHat
    assert get_distribution_version() == u'7'

    # Get the distribution version on Suse
    assert get_distribution_version() == u'13.2'

    # Get the distribution version on Ubuntu
    assert get_distribution_version() == u'16.04'

    # Get the distribution version on AIX
    assert get_distribution_version() is None

    # Get the distribution version on OpenBSD

# Generated at 2022-06-22 22:03:10.177444
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    assert get_distribution_version() is not None

# Generated at 2022-06-22 22:03:20.424108
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class _ClassToSubclassify(object):
        platform = None
        distribution = None

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class _SpecificSubclass(_ClassToSubclassify):
        platform = "FreeBSD"
        distribution = "FreeBSD"

    class _GenericSubclass(_ClassToSubclassify):
        platform = "FreeBSD"

    assert get_platform_subclass(_ClassToSubclassify) == _ClassToSubclassify
    assert get_platform_subclass(_SpecificSubclass) == _SpecificSubclass
    assert get_platform_subclass(_GenericSubclass) == _GenericSubclass


# Generated at 2022-06-22 22:03:30.719138
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test classes to have subclasses implement different behavior based on
    # platform and distribution
    class BaseClass(object):
        platform = 'Linux'
        distribution = None

        def __init__(self):
            self.bar = None
        def who_am_i(self):
            return "I am a BaseClass"

    class AmznClass(BaseClass):
        platform = 'Linux'
        distribution = 'Amazon'

        def who_am_i(self):
            return "I am an AmznClass"

    class RedHatClass(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

        def who_am_i(self):
            return "I am a RedHatClass"

    class CentOSClass(BaseClass):
        platform = 'Linux'
        distribution = 'Centos'


# Generated at 2022-06-22 22:03:43.622129
# Unit test for function get_distribution
def test_get_distribution():
    '''unit test for get_distribution'''
    # Note: this test is not comprehensive and only looks for some of the more common platforms
    distribution = get_distribution()
    if platform.system() == 'Linux':
        if distribution == 'Debian':
            assert 'Debian' in distro.id()
        elif distribution == 'Ubuntu':
            assert 'Ubuntu' in distro.id()
        elif distribution == 'Redhat':
            assert 'Redhat' in distro.id()
        elif distribution == 'Suse':
            assert 'Suse' in distro.id()
        elif distribution == 'Amazon':
            assert 'Amazon' in distro.id()
        elif distribution == 'Fedora':
            assert 'Fedora' in distro.id()

# Generated at 2022-06-22 22:03:51.226642
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import sys
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils import distro
    from ansible.module_utils.six import u

    if platform.system() != 'Linux':
        sys.exit('This test only runs on Linux systems')
    if not isinstance(distro.os_release_info(), Mapping):
        sys.exit('This test only runs when os_release_info() is available')

    distribution = distro.id().capitalize()
    version = distro.version()

    version_best = distro.version(best=True)

    # CentoOS maintainers believe only the major version is appropriate
    # but Ansible users desire minor version information, e.g., 7.5.
    # https://github.com/ansible/ansible/issues

# Generated at 2022-06-22 22:03:54.303216
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # not a linux system
    platForm = platform.system()
    if platForm != 'Linux':
        assert get_distribution_codename() is None
    else:
        # a linux system
        assert get_distribution_codename() is not None

# Generated at 2022-06-22 22:03:56.231845
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == distro.version()

# Generated at 2022-06-22 22:04:09.153439
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the functionality of get_platform_subclass()
    '''
    class Base(object):
        pass

    class Base1(Base):
        pass

    class Base2(Base):
        pass

    class Base3(Base2):
        pass

    class Base4(Base3):
        pass

    class Base5(Base3):
        pass

    class Base6(Base5):
        pass

    class Specific1(Base1):
        platform = 'Test1'
        distribution = None

    class Specific2(Base2):
        platform = 'Test2'
        distribution = 'Specific'

    class Specific3(Base3):
        platform = 'Test3'
        distribution = 'Specific'

    class Specific4(Base4):
        platform = 'Test4'
        distribution = 'Specific'


# Generated at 2022-06-22 22:04:17.548600
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseTest:
        pass

    class BaseTestPosix(BaseTest):
        platform = 'Posix'

    class FreeBSDTest(BaseTestPosix):
        distribution = 'FreeBSD'

    class LinuxTest(BaseTestPosix):
        distribution = 'Linux'

    class PosixTest(BaseTestPosix):
        pass

    class OtherBaseTest:
        pass

    class OtherTest(OtherBaseTest):
        platform = 'Other'

    assert get_platform_subclass(BaseTest) == PosixTest
    assert get_platform_subclass(BaseTestPosix) == PosixTest
    assert get_platform_subclass(LinuxTest) == LinuxTest
    assert get_platform_subclass(FreeBSDTest) == FreeBSDTest
    assert get_platform_subclass(PosixTest) == PosixTest
    assert get_platform

# Generated at 2022-06-22 22:04:18.564898
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '14.04'


# Generated at 2022-06-22 22:04:27.660335
# Unit test for function get_distribution
def test_get_distribution():
    supported_distros = ['Amzn', 'Amazon', 'Arch', 'Centos', 'Debian', 'Fedora', 'Freebsd', 'Gentoo', 'Mageia', 'Mandrake', 'Mandrakelinux', 'Mandriva', 'MandrivaLinux', 'Mint', 'Nexenta', 'Oracle', 'OracleLinux', 'OtherLinux', 'Pld', 'PldLinux', 'Redhat', 'Rhel', 'Slackware', 'Sles', 'Suse', 'SuseLinux', 'Ubuntu', 'Windows']

    distribution = get_distribution()
    assert distribution in supported_distros, ("%s is not a supported distribution" % distribution)


# Generated at 2022-06-22 22:04:38.446698
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible import module_utils
    from ansible.module_utils import basic
    from ansible.module_utils.distro import Distro, RedHatDistro, DebianDistro, OracleLinuxDistro
    # Reset the Distro() class
    module_utils.distro.Distro = Distro
    # Mock some platform data
    original_platform_system = platform.system
    original_distro_id = Distro.id
    platform.system = lambda : 'Linux'
    Distro.id = lambda x : 'Debian'
    # Test that we get the right codename
    os_release_info_return = {'version_codename': 'stretch'}
    Distro.os_release_info = lambda x : os_release_info_return
    assert basic.get_distribution_codename() == 'stretch'

# Generated at 2022-06-22 22:04:50.972089
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest

    class BaseClass(object):
        pass

    class PlatformSubclass(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class DistributionSubclass(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class PlatformSubclassDefault(BaseClass):
        platform = 'Linux'
        distribution = None

    class DefaultSubclass(BaseClass):
        platform = None
        distribution = None

    class TestClass(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class TestSubclass(TestClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class TestOtherSubclass(TestClass):
        platform = 'Linux'
        distribution = 'Debian'


# Generated at 2022-06-22 22:04:52.168930
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None



# Generated at 2022-06-22 22:05:01.433850
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class X:
        pass

    class Y(X):
        distribution = None
        platform = None

    class Z(Y):
        distribution = 'Linux'

    class Qt(Z):
        distribution = 'Linux'
        platform = 'Linux'

    class Q(Z):
        distribution = 'Linux'
        platform = 'Other'

    assert get_platform_subclass(X) is X
    assert get_platform_subclass(Y) is Y
    assert get_platform_subclass(Z) is Z
    assert get_platform_subclass(Qt) is Qt

    # this one is platform specific
    import platform
    if platform.system() == 'Linux':
        assert get_platform_subclass(Q) is Z
    else:
        assert get_platform_subclass(Q) is Q

# Generated at 2022-06-22 22:05:05.191292
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename() == get_distribution_codename()
    assert get_distribution_codename() != get_distribution_codename()

# Generated at 2022-06-22 22:05:15.167479
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test that the function get_platform_subclass returns the appropriate class
    '''

    class BaseClass:
        pass

    class OtherSubClass(BaseClass):
        platform = 'Bogus'
        distribution = None

    class SuSE(BaseClass):
        platform = 'Linux'
        distribution = 'SuSE'

    class RedHat(BaseClass):
        platform = 'Linux'
        distribution = 'RedHat'

    class FreeBDS(BaseClass):
        platform = 'FreeBSD'
        distribution = None

    class CentOS(BaseClass):
        platform = 'Linux'
        distribution = 'CentOS'

    class Debian(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class Amazon(BaseClass):
        platform = 'Linux'
        distribution = 'Amazon'


# Generated at 2022-06-22 22:05:24.795169
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.common._collections_compat import MutableMapping
    import sys
    import types

    module_inst = sys.modules[__name__]

    def side_effect_call1(name=None, version=None, best=False, pretty=False, **kwargs):
        if name == 'id':
            return 'rhel'
        return None

    def side_effect_call2(name=None, version=None, best=False, pretty=False, **kwargs):
        if name == 'id':
            return 'amzn'
        return None

    def side_effect_call3(name=None, version=None, best=False, pretty=False, **kwargs):
        if name == 'id':
            return ''
        return None


# Generated at 2022-06-22 22:05:29.343286
# Unit test for function get_distribution_version
def test_get_distribution_version():
    version_centos = get_distribution_version()
    version_redhat = get_distribution_version()
    version_debian = get_distribution_version()
    version_ubuntu = get_distribution_version()
    assert version_centos == version_redhat
    assert len(version_centos) >= 2
    assert len(version_debian) >= 2
    assert len(version_ubuntu) >= 2

# Generated at 2022-06-22 22:05:40.551425
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import platform
    import copy

    class MockDistro:
        def __init__(self, platform_str, id_str, version_str, version_best_str,
                     idversion_str, codename_str, os_release_info, lsb_release_info):
            self.platform_string = platform_str
            self.id_string = id_str
            self.version_string = version_str
            self.version_best_string = version_best_str
            self.id_and_version_string = idversion_str
            self.codename_string = codename_str
            self.os_release_info = os_release_info
            self.lsb_release_info = lsb_release_info

        def platform(self):
            return self.platform_string


# Generated at 2022-06-22 22:05:50.851711
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Run a unit test against get_distribution_codename
    '''

# Generated at 2022-06-22 22:05:51.607044
# Unit test for function get_distribution
def test_get_distribution():
    get_distribution()



# Generated at 2022-06-22 22:06:01.172612
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # Define the fake classes for testing purposes
    class BaseClass(object):
        platform = None
        distribution = None

    class Subclass1(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class Subclass2(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class Subclass3(BaseClass):
        platform = 'Linux'
        distribution = None

    class Subclass4(BaseClass):
        platform = 'Darwin'
        distribution = None

    class Subclass5(BaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class Subclass6(BaseClass):
        platform = 'Windows'
        distribution = None

    # Define the list of fake classes for testing purposes

# Generated at 2022-06-22 22:06:03.183462
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit tests for function get_distribution
    '''
    results = get_distribution()
    assert results is not None


# Generated at 2022-06-22 22:06:12.583908
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for the get_platform_subclass function.
    '''
    class SuperClass:
        pass

    class GenericSubClass(SuperClass):
        pass

    class DebianSubClass(SuperClass):
        distribution = u'debian'
        pass

    class RedHatSubClass(SuperClass):
        distribution = u'RedHat'
        platform = u'Linux'
        pass

    class AMZNSubClass(SuperClass):
        distribution = u'Amazon'
        platform = u'Linux'
        pass

    #
    # Test not providing a distribution name for Linux
    #
    assert get_platform_subclass(SuperClass) == SuperClass

    #
    # Test providing a subclass for a distribution not supported by the user
    #
    assert get_platform_subclass(SuperClass, u'asdf')

# Generated at 2022-06-22 22:06:17.163125
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common.sys_info import get_platform_subclass
    from ansible.module_utils.six.moves import UserDict
    class Platform(object):
        platform = 'ThisPlatform'
        distribution = None

    class Distribution(Platform):
        distribution = 'ThisDistro'

    class Distribution2(Platform):
        distribution = 'AnotherDistro'

    class Other(Platform):
        platform = 'AnotherPlatform'

    class OtherDistribution(Other):
        distribution = 'ThisDistro'

    class OtherDistribution2(Distribution):
        platform = 'AnotherPlatform'

    assert get_platform_subclass(Platform).__name__ == 'Distribution2', \
           "Incorrect Platform: %s" % get_platform_subclass(Platform).__name__


# Generated at 2022-06-22 22:06:20.991272
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename = get_distribution_codename()
    # If this is a Linux distro, a codename should be returned
    assert distribution_codename is None or isinstance(distribution_codename, basestring)

# Generated at 2022-06-22 22:06:31.303351
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # test for the python2 only modules
    import ansible_module_file

    file_subclass = get_platform_subclass(ansible_module_file.File)
    assert file_subclass == ansible_module_file.File

    # test for the python2 and python3 modules
    import ansible_module_group
    group_subclass = get_platform_subclass(ansible_module_group.Group)

    # different subclass depending on distribution
    if get_distribution() in ("FreeBSD", "OpenBSD"):
        assert group_subclass == ansible_module_group.BSDGroup
    else:
        assert group_subclass == ansible_module_group.Group

    # test for the AnsibleModule class
    import ansible_module_sysvars
    sysvars_subclass = get_platform_sub

# Generated at 2022-06-22 22:06:43.140973
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename_tests = {
        u'bionic': u'bionic',
        u'amzn': u'amzn',
        u'alpine': None,
        u'centos': None,
        u'debian': u'buster',
        u'fedora': None,
        u'oracle': None,
        u'redhat': None,
        u'slackware': None,
        u'suse': None,
        u'ubuntu': u'xenial',
    }
    for test_distro, expected_codename in codename_tests.items():
        platform.system = lambda: 'Linux'
        distro.id = lambda: test_distro
        distro.codename = lambda: u''
        distro.os_release_info = lambda: {}
        distro.lsb_release

# Generated at 2022-06-22 22:06:45.774635
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Fedora 28+ does not have a version and will return None
    none_version = b''
    assert get_distribution_version() == none_version

# Generated at 2022-06-22 22:06:57.650301
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    # Get the platform the unit test is running on
    current_platform = platform.system()
    this_distro = get_distribution()

    # Create a base class where all subclasses are subclasses of
    class Base:
        '''
        Base class all other test classes will inherit from
        '''
        platform = None
        distribution = None

    # Create a subclass that is always selected when the platform is linux
    class LinuxOnly(Base):
        '''
        Class for linux platform only
        '''
        platform = 'Linux'

    # Create a subclass that is always selected when the platform is linux and the distribution is LinuxOnly
    class LinuxDistro(LinuxOnly):
        '''
        Class for linux distribution only
        '''
        distribution = this_

# Generated at 2022-06-22 22:07:03.272210
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    import unittest

    class TestClass:
        """
        Test class that has subclasses which do different things depending on the platform and distribution you're on
        """
        platform = platform.system()
        distribution = get_distribution()

    class SubClass1(TestClass):
        """
        subclass that handles mac systems
        """
        platform = 'Darwin'

    class SubClass2(TestClass):
        """
        subclass that handles Red Hat systems
        """
        distribution = 'Redhat'

    class SubClass3(TestClass):
        """
        subclass that handles Red Hat linux 5 and earlier
        """
        distribution = 'Redhat'
        version = '0.0'

    class SubClass4(TestClass):
        """
        Subclass that handles any linux flavor
        """
        platform = 'Linux'



# Generated at 2022-06-22 22:07:04.957637
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'bionic'

# Generated at 2022-06-22 22:07:10.378332
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test for get_distribution_version for RHEL and CentOS,
    Debian and Ubuntu distro
    '''
    distro_id = get_distribution()
    if 'Redhat' in distro_id:
        assert get_distribution_version() == get_distribution_version()
    if 'Debian' in distro_id:
        assert get_distribution_version() == get_distribution_version()

# Generated at 2022-06-22 22:07:12.727966
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test get_distribution_version function
    '''
    assert get_distribution_version() == platform.dist()[1]

# Generated at 2022-06-22 22:07:23.260191
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class PlatformA:
        platform = "PlatformA"

    class DistributionA:
        platform = "PlatformA"
        distribution = "DistributionA"

    class DistributionB:
        platform = "PlatformA"
        distribution = "DistributionB"

    class PlatformB:
        platform = "PlatformB"

    class Default:
        platform = None
        distribution = None

    class NoDistributionMatch:
        platform = "PlatformA"
        distribution = "NoDistributionMatch"

    class NoPlatformMatch:
        platform = "NoPlatformMatch"
        distribution = None

    # basic test case
    assert get_platform_subclass(Default) is Default

    # test multiple subclasses of different platforms
    assert get_platform_subclass(PlatformA) is PlatformA
    assert get_platform_subclass(PlatformB) is PlatformB

   

# Generated at 2022-06-22 22:07:24.144565
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution()


# Generated at 2022-06-22 22:07:31.619924
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import os

    class GenericUnix:
        platform = 'Linux'
        distribution = None  # Any distribution

    class GenericLinux(GenericUnix):
        platform = 'Linux'

    class RedHatLinux(GenericLinux):
        distribution = 'Redhat'

    class RedHat7Linux(RedHatLinux):
        distribution = 'Redhat'
        distribution_release = '7'

    class RedHat6Linux(RedHatLinux):
        distribution = 'Redhat'
        distribution_release = '6'

    class SuseLinux(GenericLinux):
        distribution = 'Suse'

    class OtherLinux(GenericLinux):
        distribution = 'OtherLinux'

    class OpenSUSE11Linux(SuseLinux):
        distribution = 'Suse'
        distribution_release = '11'


# Generated at 2022-06-22 22:07:44.541381
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    class PlatformClass:
        platform = 'Test'
        distribution = None

        def __new__(cls, args, kwargs):
            print(cls)
            return load_platform_subclass(PlatformClass, args, kwargs)

    class Subclass1(PlatformClass):
        platform = 'Test'
        distribution = None

    class Subclass2(PlatformClass):
        platform = 'Test'
        distribution = 'Subclass2'

    class Subclass3(PlatformClass):
        platform = 'Test'
        distribution = 'Subclass3'

    assert get_platform_subclass(PlatformClass) == Subclass1

    # If a subclass exists that matches the distribution exactly, it gets chosen
    platform.system = lambda: 'Test'

# Generated at 2022-06-22 22:07:53.031065
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.module_utils.common._collections_compat import UserList
    from ansible.module_utils.common._collections_compat import UserString
    # Use a "random" set of values that's mostly interesting, similar to various types of distros
    distro_values = {u'codename': u'xenial', u'ubuntu_codename': u'xenial', u'version_codename': u'xenial', u'ID_LIKE': u'centos rhel fedora'}
    test_data = ['dummy', 'dummy', None, None, None, None, UserDict(), UserList(), UserString('')]
    test_data.append(distro.LinuxDistribution())
    # Iter

# Generated at 2022-06-22 22:08:02.276170
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    class Base:
        '''Base class for testing get_platform_subclass'''
        platform = None
        distribution = None

    class SubclassA(Base):
        '''Subclass with platform and distribution'''
        platform = 'A'
        distribution = 'A'

    class SubclassB(Base):
        '''Subclass without distribution'''
        platform = 'B'

    class SubclassC(Base):
        '''Subclass with wrong platform and distribution'''
        platform = 'C'
        distribution = 'C'

    class SubclassD(Base):
        '''Subclass with wrong distribution'''
        platform = 'D'
        distribution = 'D'

    class SubclassE(Base):
        '''Subclass with correct platform and wrong distribution'''

# Generated at 2022-06-22 22:08:07.302863
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # Test for module_utils.common.platform

    # function call
    get_platform_subclass(distro)

    # Test for module_utils.selinux

    import module_utils.selinux as selinux

    # function call
    get_platform_subclass(selinux.Selinux)

# Generated at 2022-06-22 22:08:17.001096
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform

    class A(object):
        pass

    class B(A):
        pass

    class Redhat(B):
        pass

    class RedhatB(Redhat):
        pass

    class Solaris(B):
        pass

    class SolarisB(Solaris):
        pass

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == B
    assert get_platform_subclass(Redhat) == Redhat
    assert get_platform_subclass(RedhatB) == RedhatB
    assert get_platform_subclass(Solaris) == Solaris
    assert get_platform_subclass(SolarisB) == SolarisB

    old_value = platform.system

# Generated at 2022-06-22 22:08:25.582821
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for get_distribution_codename
    '''

    import mock
    import unittest

    from distro import os_release_info

    from ansible.module_utils.common._utils import get_distribution_codename

    class TestGetDistributionCodename(unittest.TestCase):

        ubuntu_codenames = os_release_info.lsb_release_info.copy()
        ubuntu_codenames.update({'name': 'Ubuntu', 'version_codename': None, 'ubuntu_codename': None})
        debian_codenames = os_release_info.lsb_release_info.copy()
        debian_codenames.update({'name': 'Debian', 'version_codename': None, 'ubuntu_codename': None})
        fedora_coden

# Generated at 2022-06-22 22:08:36.826051
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    import unittest
    import ansible.module_utils.linux

    class Distribution(object):
        platform = ''
        distribution = ''

    class LinuxDistribution(Distribution):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class LinuxOtherLinux(LinuxDistribution):
        distribution = 'OtherLinux'

    class LinuxRedhat(LinuxDistribution):
        distribution = 'Redhat'

    class LinuxOtherLinuxAlt(LinuxDistribution):
        distribution = 'OtherLinux'

    class LinuxDebian(LinuxDistribution):
        distribution = 'Debian'

    class LinuxUbuntu(LinuxDistribution):
        distribution = 'Ubuntu'

    class LinuxFreeBSD(Distribution):
        platform = 'FreeBSD'

    class LinuxOpenBSD(Distribution):
        platform = 'OpenBSD'


# Generated at 2022-06-22 22:08:44.544220
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test that get_platform_subclass returns the right classes
    '''
    # This subclass only works on CentOS
    class CentOSOnly(object):
        distribution = u'Redhat'
        platform = u'Linux'

    class LinuxOnly(object):
        distribution = None
        platform = u'Linux'

    # This subclass works on any platform
    class AnyPlatform(object):
        distribution = None
        platform = None

    assert get_platform_subclass(CentOSOnly) == CentOSOnly
    assert get_platform_subclass(LinuxOnly) == LinuxOnly
    assert get_platform_subclass(AnyPlatform) == AnyPlatform



# Generated at 2022-06-22 22:08:46.273655
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None

# Generated at 2022-06-22 22:08:51.004222
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    class MockDistro:
        id = 'MockDistro'
        version = '1.0'
        codename = ''

    orig_distro = distro.__dict__
    try:
        distro.__dict__ = dict(MockDistro().__dict__)
        assert get_distribution_codename() is None
    finally:
        distro.__dict__ = orig_distro

# Generated at 2022-06-22 22:09:01.231556
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    def fake_get_distribution(distribution):
        def fake_distro():
            return distribution
        return fake_distro

    class fake_module:
        @staticmethod
        def params():
            return {}

        @staticmethod
        def get_bin_path(program, required=False, opt_dirs=()):
            return '/bin/' + program

    codename = get_distribution_codename()

    # Ubuntu 18.04 Bionic
    distro.id = fake_get_distribution(u'ubuntu')
    distro.codename = fake_get_distribution(u'')
    distro.os_release_info = lambda: {'version_codename': 'bionic', 'ubuntu_codename': 'bionic'}

# Generated at 2022-06-22 22:09:13.131321
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Get the class PlatformA, which is a subclass of PlatformA
    from ansible.module_utils.facts.system.distribution import PlatformA
    from ansible.module_utils.facts.system.distribution import PlatformAA
    from ansible.module_utils.facts.system.distribution import PlatformAB
    from ansible.module_utils.facts.system.distribution import PlatformAC
    subclass = get_platform_subclass(PlatformA)
    assert subclass == PlatformAA

    # Get the most specific subclass of PlatformA, which is PlatformAB
    subclass = get_platform_subclass(PlatformAB)
    assert subclass == PlatformAB

    # Get the most specific subclass of PlatformA, which is PlatformAC
    subclass = get_platform_subclass(PlatformAC)
    assert subclass == PlatformAC

    # Get the most specific subclass when there is a platform

# Generated at 2022-06-22 22:09:14.655863
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None

# Generated at 2022-06-22 22:09:16.121063
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is None

# Generated at 2022-06-22 22:09:25.932936
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # A base class
    class BaseClass:
        platform = 'all'
        distribution = None

    class Subclass1(BaseClass):
        platform = 'all'
        distribution = None

    class Subclass2(BaseClass):
        platform = 'this_platform'
        distribution = None

    class Subclass3(BaseClass):
        platform = 'this_platform'
        distribution = 'this_distro'

    class Subclass4(BaseClass):
        platform = 'this_platform'
        distribution = 'this_distro'

    # Which subclass to select depends on the value of distribution and platform.
    # If distribution is "this_distro", then Subclass4 should be selected.

    # If distribution is not "this_distro", then Subclass2
    # should be selected.

    # If distribution is None, then Subclass1

# Generated at 2022-06-22 22:09:37.044716
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # TODO: pylint 2.5.3 has a bug where it's not possible to
    # raise AssertionError and have AssertionError be the exception
    # raised.  Remove the following two pylint directives when we
    # upgrade pylint:
    # https://github.com/PyCQA/pylint/pull/1651
    # pylint: disable=unidiomatic-typecheck

    # Set up some fixtures
    class LinuxDistroInformation(object):
        ''' Class to save and restore the results from platform.linux_distribution()
        This is needed because Python 3.7 changed the name and semantics of that
        function.  Previously, it returned a tuple of information about the distro.
        In Python 3.7, it is deprecated and it returns the name of the distro.
        '''

# Generated at 2022-06-22 22:09:43.742745
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Note: dict is ordered in Python 3.6 and above.
    if get_platform_subclass(Base) == Base:
        assert False, "Base should not be returned on any platform"

    assert get_platform_subclass(Fedora) == Fedora, "Fedora should be returned on Fedora"
    assert get_platform_subclass(Redhat) == Redhat, "Redhat should be returned on Fedora"
    assert get_platform_subclass(Centos) == Redhat, "Centos should be returned on Fedora"
    assert get_platform_subclass(Amazon) == Amazon, "Amazon should be returned on Amazon"
    assert get_platform_subclass(Centos) == Redhat, "Centos should be returned on Amazon"
    assert get_platform_subclass(Redhat) == Redhat, "Redhat should be returned on Amazon"
   

# Generated at 2022-06-22 22:09:54.873772
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils import basic
    import distro
    distro.os_release_info = lambda: {'id': 'centos', 'version_id': '7'}
    print(get_distribution())
    distro.os_release_info = lambda: {'id': 'fedora', 'version_id': '28'}
    print(get_distribution())
    distro.os_release_info = lambda: {
        'id': 'ubuntu',
        'version_id': '16.04',
        'version_codename': 'xenial'
    }
    print(get_distribution())
    distro.os_release_info = lambda: {'id': 'darwin', 'version_id': '16.7.0'}
    print(get_distribution())
    distro

# Generated at 2022-06-22 22:10:03.837360
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    if platform.system() != u'Linux':
        return

    distribution = get_distribution()
    if not distribution:
        return

    codename = get_distribution_codename()
    if distribution == u'Debian':
        if codename not in (None, u'bullseye', u'buster', u'jessie', u'sid', u'testing', u'unstable'):
            raise AssertionError("Unexpected codename '%s' for Debian" % codename)

# Generated at 2022-06-22 22:10:15.878341
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import shutil
    import tempfile
    import os

    # Fedora
    data = {
        'ID': 'fedora',
        'VERSION_ID': '26',
    }
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 22:10:28.053156
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import os
    import tempfile
    import shutil
    import sys

    code_name = sys.version_info
    distro_version = distro.version(best=True)
    distro_version_best = distro.version(best=False)


# Generated at 2022-06-22 22:10:34.353392
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import platform
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 22:10:44.792854
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native

# Generated at 2022-06-22 22:10:56.838731
# Unit test for function get_distribution
def test_get_distribution():
    PLATFORM_TEST_DATA = {}
    PLATFORM_TEST_DATA["Linux"] = ("amazon", "redhat", "centos", "docker", "fedora", "korora", "oracle", "scientific", "slackware", "suse", "ubuntu")
    PLATFORM_TEST_DATA["Darwin"] = ("mac_os_x",)
    PLATFORM_TEST_DATA["FreeBSD"] = ("freebsd",)
    PLATFORM_TEST_DATA["OpenBSD"] = ("openbsd",)
    PLATFORM_TEST_DATA["NetBSD"] = ("netbsd",)
    PLATFORM_TEST_DATA["Windows"] = ("windows",)
    PLATFORM_TEST_DATA["AIX"] = ("aix",)

    DISTRIBUTION_OVERR

# Generated at 2022-06-22 22:11:04.644709
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    Test that get_distribution_version returns expected results
    """

    # Test function with a variety of Linux distributions, as well as non-Linux distributions

# Generated at 2022-06-22 22:11:08.335585
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    calls the function get_distribution_version() and compares the value to the
    distro.version() function
    '''
    distro_version = distro.version()
    function_version = get_distribution_version()
    assert distro_version == function_version


# Generated at 2022-06-22 22:11:10.420586
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'bionic'
    assert get_distribution_codename() != 'cosmic'

# Generated at 2022-06-22 22:11:11.274202
# Unit test for function get_distribution
def test_get_distribution():
    pass

# Generated at 2022-06-22 22:11:20.021666
# Unit test for function get_distribution
def test_get_distribution():
    # Need to mock pkg_resources when importing distro in test_utils
    # as it's not installed on a clean Ansible test environment.
    distro.id = lambda: 'centos'
    assert get_distribution() == 'Redhat'
    distro.id = lambda: 'ubuntu'
    assert get_distribution() == 'Ubuntu'
    distro.id = lambda: 'ubuntu'
    distro.os_release_info = lambda: {'version_codename': 'xenial'}
    assert get_distribution_codename() == 'xenial'


# Generated at 2022-06-22 22:11:33.033468
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version to set version string on
    supported distributions.
    '''
    assert get_distribution_version() != None, "Fail to get current version.  Unable to test next code block."
    assert get_distribution_version() != '', "Fail to get current version.  Unable to test next code block."

    # Test for use_best = False
    if get_distribution() == 'Amazon':
        assert get_distribution_version() == '2010.09', "Fail to get current version for Amazon Linux"
    elif get_distribution() == 'Redhat':
        assert get_distribution_version() == '7.4', "Fail to get current version for Redhat Enterprise Linux"

# Generated at 2022-06-22 22:11:34.935917
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == "Redhat"
    assert get_distribution_version() == "6.5"

# Generated at 2022-06-22 22:11:44.034898
# Unit test for function get_distribution
def test_get_distribution():
    import platform
    from ansible.module_utils.common.os import _distribution

    #
    # Note: These tests are dependent on the implementation of distro.id()
    #       We'll want to keep an eye on future changes to that library.
    #

    #
    # Linux distro tests
    #

    # Test system name is used
    try:
        platform.system = lambda: 'Linux'
        assert get_distribution() == 'Linux'
    finally:
        del platform.system

    # Test Linux distro name
    try:
        platform.system = lambda: 'Linux'
        _distribution.name = lambda: 'Fedora'
        assert get_distribution() == 'Fedora'
    finally:
        del platform.system

    # Test Amazon distro name