

# Generated at 2022-06-22 22:01:49.483876
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version()
    '''
    dist_version_dict = {
        'centos': '7.5.1804',
        'debian': '9',
        'fedora': '28',
        'redhat': '6.10',
        'ubuntu': '17.10',
    }
    print("Testing get_distribution_version()")
    for distro_id, distro_version in dist_version_dict.items():
        print("Testing {}".format(distro_id))
        obj = type('MockDistro', (object,), {
            'id': lambda: distro_id,
            'version': lambda *args, **kwargs: distro_version
        })
        saved_distro = distro.distro
        distro.distro

# Generated at 2022-06-22 22:01:58.965563
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.dict_transformations import snake_dict_to_camel_dict

    class test_class(object):
        platform = 'Linux'
        distribution = None

        def __init__(self, module):
            self.module = module

        def run(self):
            self.module.exit_json(changed=False, ansible_facts=snake_dict_to_camel_dict({'subclass_ran': 'subclass_ran'}))

    class test_subclass_linux(test_class):
        platform = 'Linux'
        distribution = None


# Generated at 2022-06-22 22:02:02.506608
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() in ('Redhat', 'Freebsd', 'Aix', 'Openbsd', 'Darwin', 'Sunos', 'OtherLinux', 'HPUX', 'Windows', 'SuSE')



# Generated at 2022-06-22 22:02:10.641354
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distribution_version_dict = {
        'Ubuntu-18.04': '18.04',
        'CentOS-7.5.1804': '7.5',
        'Amazon-2': '2',
        'Redhat-4': '4',
    }
    for test_distribution, expect_version in distribution_version_dict.items():
        result = get_distribution_version()
        assert result == expect_version

# Generated at 2022-06-22 22:02:20.137442
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import sys
    import os

    __original_distro_id = distro.id
    __original_distro_version = distro.version
    __original_distro_best_version = distro.version_best
    __original_distro_os_release_info = distro.os_release_info
    __original_distro_lsb_release_info = distro.lsb_release_info

    def _no_distro(release_file=None):
        raise distro.UnsupportedVersionError('no distro')


# Generated at 2022-06-22 22:02:23.119031
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename()
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-22 22:02:27.400682
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() in ['Linux', 'Freebsd', 'Openbsd', 'Netbsd', 'Darwin', 'Sunos', 'OtherLinux', 'Aix', 'OtherPosix']

# Generated at 2022-06-22 22:02:28.937549
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()

    assert codename == 'bionic'

# Generated at 2022-06-22 22:02:34.293778
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    platform_with_distribution = platform.system()
    distributions = {'Oracle': 'OracleLinux', 'Amazon': 'Amazon', 'Redhat': 'RedHat', 'OtherLinux': 'OtherLinux', 'Linux': 'Linux'}
    distributions['Linux'] = platform_with_distribution if platform_with_distribution != 'Linux' else None

    return {'distributions': distributions, 'platforms': ['Darwin', 'Linux']}

# Generated at 2022-06-22 22:02:44.952759
# Unit test for function get_distribution
def test_get_distribution():
    # Check case of distro name with capitalization
    distro_id = b'Ubuntu'
    distro.id = lambda: distro_id
    assert get_distribution() == 'Ubuntu'

    # Check case of distro name without capitalization
    distro_id = b'ubuntu'
    distro.id = lambda: distro_id
    assert get_distribution() == 'Ubuntu'

    # Check case of None
    distro_id = None
    distro.id = lambda: distro_id
    assert get_distribution() is None

    # Check case of centos
    distro_id = 'centos'
    distro.id = lambda: distro_id
    assert get_distribution() == 'Centos'

    # Check case of redhat

# Generated at 2022-06-22 22:02:46.757080
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test Linux distributions
    assert get_distribution_version() == None


# Generated at 2022-06-22 22:02:58.533705
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import sys
    import os
    import unittest
    import io

    class TestDistro(unittest.TestCase):
        def setUp(self):
            self.real_stdout = sys.stdout
            sys.stdout = self.out = io.StringIO()
            self.real_platform = platform.system
            platform.system = lambda: 'Linux'
            self.real_distro = distro.linux_distribution
            distro.linux_distribution = lambda **kwargs: ('Ubuntu', '', '')
            self.real_distro_id = distro.id
            distro.id = lambda: 'ubuntu'
            self.real_distro_version = distro.version
            distro.version = lambda **kwargs: '16.04'
            self.real_lsb_release_

# Generated at 2022-06-22 22:03:00.153119
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'jessie'

# Generated at 2022-06-22 22:03:11.621129
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic
    class Foo(object):
        distribution = None
        platform = 'Linux'
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    class RedhatFoo(Foo):
        distribution = 'Redhat'
    class LinuxBar(object):
        distribution = None
        platform = 'Linux'
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    class DarwinBar(object):
        distribution = None
        platform = 'Darwin'
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

# Generated at 2022-06-22 22:03:22.693290
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        platform = 'PlatformA'
        distribution = None

    class B:
        platform = 'PlatformB'
        distribution = None

    class C(A):
        distribution = 'Distro'

    class D(B):
        distribution = 'Distro'

    class E(A):
        distribution = 'Distro'
        platform = None

    class F(A):
        distribution = None
        platform = None

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == B
    assert get_platform_subclass(C) == C
    assert get_platform_subclass(D) == D
    assert get_platform_subclass(E) == E
    assert get_platform_subclass(F) == A

# Generated at 2022-06-22 22:03:32.161006
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the functionality implemented in get_distribution_codename.

    The test verifies the functionality of get_distribution_codename by giving it
    a set of mocked /etc/os-release (or similar) data. The test passes if the
    expected result is returned for each distribution.
    '''

    import sys

    # This is the base class for the mocked distro module.
    class TestDistroMock(object):
        def __init__(self):
            self.os_release_info = {}

        # Python3 overrides __getattr__.  We want the older
        # behavior of __getattr__ so we use __getattribute__
        def __getattribute__(self, attr):
            return getattr(sys.modules[__name__], attr)


# Generated at 2022-06-22 22:03:44.533768
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class ClassA:
        platform = None
        distribution = None

    class ClassB(ClassA):
        platform = 'Linux'
        distribution = 'RedHat'

    class ClassC(ClassA):
        platform = 'Linux'
        distribution = None
        distribution_version = '6'

    class ClassD(ClassC):
        distribution_version = '7'

    class ClassE(ClassC):
        pass

    # Check that non-Linux platforms get the base class
    platform.system = lambda : 'Darwin'
    get_distribution = lambda : 'Darwin'

    assert(get_platform_subclass(ClassA) == ClassA)

    # Check that Linux platforms get the most recent Linux base class
    platform.system = lambda : 'Linux'
    get_distribution = lambda : 'RedHat'

# Generated at 2022-06-22 22:03:54.092871
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    # create a series of subclasses for testing
    class PlatformA(AnsibleModule):
        platform = 'PlatformA'

    class DistributionA(PlatformA):
        distribution = 'PlatformADistroA'

    class DistributionB(PlatformA):
        distribution = 'PlatformADistroB'

    class PlatformB(AnsibleModule):
        platform = 'PlatformB'

    class DistributionB(PlatformB):
        distribution = 'PlatformBDistroB'

    class DistributionA(PlatformB):
        distribution = 'PlatformBDistroA'

    # test that we get the right answer when we have a distribution
    assert get_platform_subclass(AnsibleModule) == DistributionA
    # test that we get the right answer when we don't have a distribution
    assert get_platform

# Generated at 2022-06-22 22:04:06.054280
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class SuperClass:
        pass

    class MyClass(SuperClass):
        platform = "Darwin"

    class MyClass2(SuperClass):
        platform = "Linux"

    class MyClass3(SuperClass):
        distribution = "RedHat"
        platform = "Linux"

    class MyClass4(SuperClass):
        distribution = "RedHat"
        platform = "Darwin"

    class MyClass5(SuperClass):
        distribution = "RedHat"
        platform = "Linux"

    class MyClass6(MyClass5):
        pass

    assert get_platform_subclass(SuperClass) == SuperClass

    assert get_platform_subclass(MyClass) == MyClass
    assert get_platform_subclass(MyClass2) == MyClass2
    assert get_platform_subclass(MyClass3) == MyClass

# Generated at 2022-06-22 22:04:15.900314
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    get_platform_subclass: tests for the function
    '''
    # None of the below classes will be available if you ran
    # this test directly.  This is to make it so the unit tests
    # can test these classes directly.
    class Base:
        platform = 'BasePlatform'

    class Specific:
        platform = 'SpecificPlatform'

    class DistSpecific:
        platform = 'SpecificPlatform'
        distribution = 'SpecificDist'

    class Generic:
        pass

    def foo(platform, distribution):
        return {
            'BasePlatform': Base,
            'SpecificPlatform': Specific,
        }.get(platform, Generic)

    result = get_platform_subclass(foo('BasePlatform', None))
    assert result == Base

    result = get_platform_subclass(foo('SpecificPlatform', None))
   

# Generated at 2022-06-22 22:04:26.713653
# Unit test for function get_distribution_version
def test_get_distribution_version():
    rhel_6 = 'Red Hat Enterprise Linux Server release 6.7 (Santiago)'
    rhel_7 = 'Red Hat Enterprise Linux Server release 7.3 (Maipo)'
    centos_7 = 'CentOS Linux release 7.3.1611 (Core)'
    fedora_27 = 'Fedora release 27 (Twenty Seven)'
    fedora_rawhide = 'Fedora release 28 (Rawhide)'
    amazon_linux_2 = 'Amazon Linux 2'

    tests = (
        (rhel_6, '6.7'),
        (rhel_7, '7.3'),
        (centos_7, '7.3.1611'),
        (fedora_27, '27'),
        (fedora_rawhide, '28'),
        (amazon_linux_2, '2'),
    )

    got

# Generated at 2022-06-22 22:04:28.909818
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert distribution is not None
    assert distribution.isalpha(), "Distribution is alpha: %s" % distribution


# Generated at 2022-06-22 22:04:30.117062
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'buster'

# Generated at 2022-06-22 22:04:39.347955
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        from ansible.module_utils.facts import Facts
        from ansible.module_utils.facts.linux import Linux
        from ansible.module_utils.facts.other import Other
    except ImportError as e:
        print("test_get_platform_subclass: Please run unit tests from the same directory you ran this script from.")
        raise e

    # Testing get_platform_subclass
    assert get_platform_subclass(Facts) == Facts
    assert get_platform_subclass(Linux) == Linux
    assert get_platform_subclass(Other) == Other
    print("test_get_platform_subclass: PASSED")


if __name__ == '__main__':
    test_get_platform_subclass()

# Generated at 2022-06-22 22:04:51.853032
# Unit test for function get_distribution
def test_get_distribution():
    # Null test
    distribution = get_distribution()
    assert(platform.system() == distribution)
    # Test using linux distribution
    # Replace "platform.dist" with "MockedDist"
    # needs to be done first to overwrite the original value
    platform.dist = None
    platform.uname = lambda: ['Linux', 'MockedDist', 'MockedVersion']
    distribution = get_distribution()
    assert(distribution == 'Mockeddist')
    platform.uname = None
    # Test using linux distribution with no value
    platform.dist = None
    platform.linux_distribution = lambda: ['MockedDist']
    distribution = get_distribution()
    assert(distribution == 'Mockeddist')
    platform.linux_distribution = None
    # Test using linux distribution with no value
    platform.dist = None


# Generated at 2022-06-22 22:04:52.689239
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-22 22:04:54.474295
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None



# Generated at 2022-06-22 22:04:55.944885
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == "7.5"

# Generated at 2022-06-22 22:04:56.521854
# Unit test for function get_distribution_version
def test_get_distribution_version():
    pass

# Generated at 2022-06-22 22:05:09.089119
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import unittest

    class TestGetDistributionVersion(unittest.TestCase):
        def test_alpine(self):
            distro.id = lambda: u'alpine'
            distro.version = lambda: u'3.7.0'
            self.assertEqual(get_distribution_version(), distro.version())

        def test_centos_with_version(self):
            distro.id = lambda: u'centos'
            distro.version = lambda: u'7.2.1511'
            distro.version.major = lambda: u'7'
            distro.version.minor = lambda: u'2'
            distro.version.best = lambda: u'7.2.1511'

# Generated at 2022-06-22 22:05:14.389161
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename in (None, u'bionic', u'cosmic', u'trusty', u'xenial', u'yakkety', u'zesty', u'artful', u'jessie', u'buster')

# Generated at 2022-06-22 22:05:22.204150
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class base(object):
        platform = None
        distribution = None
    class foo_platform(base):
        platform = 'Foo'
    class bar_platform(base):
        platform = 'Bar'
        distribution = 'Baz'
    class baz_platform(bar_platform):
        distribution = 'Baz'
    assert get_platform_subclass(base) is base
    assert get_platform_subclass(foo_platform) is foo_platform
    assert get_platform_subclass(bar_platform) is bar_platform
    assert get_platform_subclass(baz_platform) is baz_platform

# Generated at 2022-06-22 22:05:31.174717
# Unit test for function get_distribution
def test_get_distribution():
    ''' Unit test for function get_distribution '''
    # [UNIT TEST]
    # Subprocesses is used to test the get_distribution method, if it is found
    # in our requirements, then we can test it.
    #
    # [UNITTEST: TBD]
    # TODO: Figure out how to create a testable environment to run this function in.
    # Ideas:
    #  1. Create a virtualenv and install ansible, distro, and a subset of the
    #     operating systems that may have problems.
    #  2. Have a command line switch to create a temp directory and run bash in
    #     that directory.
    #  3. Run `sudo` and try to change permissions for the calling user.
    #     Don't let them use sudo if they don't have the right permissions.
    #  4

# Generated at 2022-06-22 22:05:41.435662
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the function get_distribution_codename
    
    :rtype: None
    :returns: None
    '''

# Generated at 2022-06-22 22:05:51.079822
# Unit test for function get_distribution

# Generated at 2022-06-22 22:05:55.757632
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test get_distribution_codename() to make sure all supported distros return the codename
    '''

    codename = get_distribution_codename()

    if not codename:
        raise Exception('test_get_distribution_codename(): Failed to get the codename for the distribution')

    return codename


# Generated at 2022-06-22 22:06:03.556163
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    This test documents that the get_distribution_codename function works as expected.
    '''
    # These distributions have codenames
    codenames_we_expect = {
        'Ubuntu': ['focal', 'bionic'],
        'Debian': ['sid', 'buster', 'stretch', 'jessie', 'wheezy'],
        'Fedora': ['rawhide', 'f30'],
        'Redhat': ['8.0.0'],
        'CentOS': ['8.0.1905'],
        'Amazon': ['2'],
        'Scientific': ['7.6'],
        'CumulusLinux': ['3.7.1'],
    }

    # These distros are not expected to have codenames
    distros_we_dont_expect

# Generated at 2022-06-22 22:06:12.880048
# Unit test for function get_platform_subclass

# Generated at 2022-06-22 22:06:24.633734
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    ''' Unit tests for function ``get_platform_subclass`` '''
    import unittest

    class Base():
        platform='Linux'

        def __init__(self, args, kwargs):
            self.args = args
            self.kwargs = kwargs

    class FirstSubclass(Base):
        distribution='Amazon'

    class SecondSubclass(Base):
        distribution='Redhat'

    class ThirdSubclass(Base):
        distribution='Redhat'
        version='6.5'

    class FourthSubclass(Base):
        pass

    class FifthSubclass(Base):
        distribution='Amazon'
        version='6.5'

    class SixthSubclass(Base):
        platform='SunOS'

    class SeventhSubclass(Base):
        platform='SunOS'
        version='5.5'


# Generated at 2022-06-22 22:06:27.332955
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == u'OtherLinux'
    assert get_distribution_version() == u''



# Generated at 2022-06-22 22:06:39.711521
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic

    class DemoBase:
        platform = "Base"
        distribution = None

    class Demo1(DemoBase):
        platform = "Demo"
        distribution = "DemoDistro"

    class Demo1a(DemoBase):
        platform = "Demo"
        distribution = "DemoDistro"

    class Demo2(DemoBase):
        platform = "Demo"
        distribution = None

    class Demo3(DemoBase):
        platform = "Other"
        distribution = "OtherDistro"

    # Develop tests for various platforms and distributions.
    class Tests(object):
        # Tests for platform "Demo" and distribution "DemoDistro".
        def test_1_1(self):
            res = get_platform_subclass(DemoBase)

# Generated at 2022-06-22 22:06:52.078506
# Unit test for function get_distribution
def test_get_distribution():

    # In case of OSX
    if platform.system() == 'Darwin':
        distro_id = get_distribution()
        assert distro_id == 'Darwin'

    # In case of FreeBSD
    if platform.system() == 'FreeBSD':
        distro_id = get_distribution()
        assert distro_id == 'Freebsd'

    # In case of SunOS
    if platform.system() == 'SunOS':
        distro_id = get_distribution()
        assert distro_id == 'Solaris'

    # In case of windows
    if platform.system() == 'Windows':
        distro_id = get_distribution()
        assert distro_id == 'Windows'

    # In case of Linux
    if platform.system() == 'Linux':
        distro_id = get_

# Generated at 2022-06-22 22:06:54.299921
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-22 22:06:57.856194
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # For All the disros the verson is expected to be returned
    assert get_distribution_version() != ''
    assert get_distribution_version() != None
    assert get_distribution_version() != 'Unknown'


# Generated at 2022-06-22 22:07:08.927577
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test Fedora
    distro.id = lambda: 'fedora'
    distro.codename = lambda: 'Spherical Cow'
    distro.lsb_release_info = lambda: {}
    distro.os_release_info = lambda: {'version_codename': 'Spherical Cow'}
    assert get_distribution_codename() == 'Spherical Cow'

    # Test Debian
    distro.id = lambda: 'debian'
    distro.codename = lambda: 'Stretch'
    distro.lsb_release_info = lambda: {}
    distro.os_release_info = lambda: {'version_codename': 'Stretch'}
    assert get_distribution_codename() == 'Stretch'

    # Test Ubuntu
    distro.id = lambda: 'ubuntu'

# Generated at 2022-06-22 22:07:19.770419
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import tempfile
    import unittest
    from shutil import rmtree
    from os import makedirs
    from os.path import isdir

    import distro
    distro_bak = distro.__file__


# Generated at 2022-06-22 22:07:27.485780
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseTestClass:
        pass

    class TestClass1(BaseTestClass):
        platform = "Linux"
        distribution = "Test1"

    class TestClass2(BaseTestClass):
        platform = "Linux"
        distribution = None

    class TestClass3(BaseTestClass):
        platform = "ThisPlatform"

    platform_linux = get_platform_subclass(BaseTestClass)
    assert(platform_linux is BaseTestClass)

    platform_test1 = get_platform_subclass(TestClass1)
    assert(platform_test1 is BaseTestClass)

    platform_test2 = get_platform_subclass(TestClass2)
    assert(platform_test2 is BaseTestClass)

    platform_test3 = get_platform_subclass(TestClass3)
    assert(platform_test3 is BaseTestClass)

# Generated at 2022-06-22 22:07:28.568998
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == u'OtherLinux'

# Generated at 2022-06-22 22:07:31.556472
# Unit test for function get_distribution
def test_get_distribution():
    dist = get_distribution()
    assert dist == 'Amazon'
    assert isinstance(dist, str)


# Generated at 2022-06-22 22:07:44.440204
# Unit test for function get_distribution_codename

# Generated at 2022-06-22 22:07:51.070601
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    info = distro.os_release_info()
    if info['ID'] == 'fedora':
        codename = info['VERSION_ID']
    elif info['ID'] == 'debian':
        codename = info['VERSION_CODENAME']
    elif info['ID'] == 'ubuntu':
        codename = info['VERSION_CODENAME']
    elif info['ID'] == 'rhel':
        codename = info['VERSION_CODENAME']
    else:
        codename = None

    assert codename == get_distribution_codename()

# Generated at 2022-06-22 22:07:53.206644
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    print(distribution)



# Generated at 2022-06-22 22:08:02.352820
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Verify that the correct versions are returned.
    '''
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    TEST_LONG_VER = u'1.2.3.4'

    # Expected results.  Ordering is key, distrib_id, version,
    # expected_result

# Generated at 2022-06-22 22:08:03.880866
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'bionic'

# Generated at 2022-06-22 22:08:15.171581
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # clear some environment variables which influence distro.py code
    for key in ('container', 'OSTYPE', 'MACHTYPE', 'ID'):
        if key in os.environ:
            del os.environ[key]

    def _set_env(distro_id, version, codename):
        os.environ['ID'] = distro_id
        os.environ['VERSION_ID'] = version
        os.environ['VERSION_CODENAME'] = codename

    _set_env('ubuntu', '16.04', 'xenial')
    assert get_distribution_codename() == 'xenial'

    _set_env('ubuntu', '18.04', '')
    assert get_distribution_codename() == ''

    _set_env('debina', '9', '')


# Generated at 2022-06-22 22:08:16.491043
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert 'bionic' == get_distribution_codename()

# Generated at 2022-06-22 22:08:18.663514
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Input:
    Output:
    '''
    assert get_distribution_version() == '11.0'

# Generated at 2022-06-22 22:08:30.072257
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestClass(object):
        platform = None
        distribution = None

    class TestClassArch(TestClass):
        platform = 'Linux'
        distribution = 'Arch'

    class TestClassCentos(TestClass):
        platform = 'Linux'
        distribution = 'Centos'

    class TestClassLinux(TestClass):
        platform = 'Linux'

    class TestClassDarwin(TestClass):
        platform = 'Darwin'

    assert get_platform_subclass(TestClassLinux) == TestClassLinux
    assert get_platform_subclass(TestClassDarwin) == TestClassDarwin

    orig_platform = platform.system
    orig_distro = distro.id


# Generated at 2022-06-22 22:08:41.262800
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Function get_platform_subclass accepts one or more arguments
    # We will call this function with None as an argument to cover
    # all the possible cases
    class MySuperclass():
        '''
        This is a simple base class
        '''
        platform = None
        distribution = None

        def get_default_arg(self):
            return "Hello World"

    class MySubclass1(MySuperclass):
        platform = 'myplatform'
        distribution = 'mydistro'

        def get_default_arg(self):
            return "Hello Universe"

    class MySubclass2(MySuperclass):
        platform = 'myplatform'
        distribution = None

    class MySubclass3(MySuperclass):
        platform = None
        distribution = 'mydistro'


# Generated at 2022-06-22 22:08:46.613106
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils._text import to_bytes
    assert b'Linux' in to_bytes(platform.platform())
    assert get_distribution() in ('Redhat', 'Centos', 'Fedora', 'Amazon', 'Debian', 'Ubuntu', 'OpenSUSE project', 'SUSE', 'Mageia', 'Arch', 'Gentoo', 'Funtoo', 'Slackware', 'Alpine', 'OtherLinux')

# Generated at 2022-06-22 22:08:57.724275
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    valid_codenames = frozenset((
        u'buster',
        u'bullseye',
        u'focal',
        u'jessie',
        u'sid',
        u'testing',
        u'trusty',
        u'unstable',
        u'utopic',
        u'vivid',
        u'wily',
        u'xenial',
        u'yakkety',
        u'zesty',
    ))
    invalid_codenames = frozenset((
        u'Wheezy',
        u'Wheezy/oldstable',
    ))

    for code in valid_codenames:
        assert get_distribution_codename() == code

    for code in invalid_codenames:
        assert get_distribution_codename() != code

# Generated at 2022-06-22 22:09:02.635724
# Unit test for function get_distribution_version
def test_get_distribution_version():
    my_distro = distro.linux_distribution(full_distribution_name=0)[0]
    my_distro_version = distro.linux_distribution(full_distribution_name=0)[1]
    assert (my_distro_version == get_distribution_version())

# Generated at 2022-06-22 22:09:05.509987
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

if __name__ == '__main__':
    test_get_distribution_codename()

# Generated at 2022-06-22 22:09:16.349685
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Returns a tuple of sample data in the format of (name, expected_distribution_name)
    '''

# Generated at 2022-06-22 22:09:19.717915
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test method ``get_distribution()``.

    :rtype: None
    :returns: No return value. Method will raise an assertion error if the test fails
    '''
    assert get_distribution() in (None, 'Linux', 'Freebsd', 'Darwin'), "get_distribution() returned unexpected value"


# Generated at 2022-06-22 22:09:29.315374
# Unit test for function get_distribution
def test_get_distribution():
    # Test each Linux distro we think we may find
    def _test_linux(test_distro, distro_id, version_id, id_like, version_codename):
        distro.id = lambda: distro_id
        distro.version = lambda: version_id
        distro.lsb_release_info = lambda: {'id_like': id_like, 'codename': version_codename}  # NOQA
        distro.os_release_info = lambda: {'id_like': id_like, 'codename': version_codename, 'version_codename': version_codename, 'ubuntu_codename': version_codename}  # NOQA
        osfamily = 'RedHat' if distro_id == 'fedora' else 'Debian'
        assert get_distribution_codename

# Generated at 2022-06-22 22:09:40.407335
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    This unit test uses the mock distribution that is created in test_distro
    to test whether get_platform_subclass returns the right subclasses.
    """
    class Base:
        pass

    class RhelBase(Base):
        distribution = 'Redhat'
        platform = 'Linux'

    class AmazonBase(Base):
        distribution = 'Amazon'
        platform = 'Linux'

    class SunOSBase(Base):
        distribution = None
        platform = 'SunOS'

    class OtherLinuxBase(Base):
        distribution = 'OtherLinux'
        platform = 'Linux'

    class AmznDerived(AmazonBase):
        pass

    class RhelDerived(RhelBase):
        pass

    class AmazonDerived(AmazonBase):
        pass

    # Test all possible combinations of platform and distribution
    rhel_subclass

# Generated at 2022-06-22 22:09:47.060272
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    - This test has to check for any regression in get_platform_subclass.
    - get_platform_subclass(User) is checked against get_platform_subclass(User), as find_needle
      is called inside get_platform_subclass(User).
    - get_platform_subclass(Other) is checked against get_platform_subclass(Other), as find_needle
      is not called inside get_platform_subclass(Other).
    '''
    class User():
        platform = platform.system()
        distribution = get_distribution()

    class Other():
        pass

    class UserRedHat(User):
        distribution = 'Redhat'

    class UserOtherLinux(User):
        distribution = 'OtherLinux'

    class UserOther(User):
        distribution = 'Other'


# Generated at 2022-06-22 22:09:56.098649
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for get_distribution() function
    '''
    # RedHat derived
    assert get_distribution() == 'Redhat'

    # Debian derived
    assert get_distribution() == 'Debian'

    # SuSE derived
    assert get_distribution() == 'Suse'

    # EL derived
    assert get_distribution() == 'Amazon'

    # Linux
    assert get_distribution() == 'OtherLinux'

    # Generic Darwin
    assert get_distribution() == 'Darwin'

    # Generic FreeBSD
    assert get_distribution() == 'Freebsd'

    # Generic OpenBSD
    assert get_distribution() == 'Openbsd'

    # Generic NetBSD
    assert get_distribution() == 'Netbsd'

    # Generic Solaris
    assert get_distribution()

# Generated at 2022-06-22 22:09:57.369005
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'



# Generated at 2022-06-22 22:10:06.886482
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = "Linux"
        distribution = None

    class BaseLinuxOther(BaseLinux):
        distribution = "OtherLinux"

    class BaseLinuxOtherOther(BaseLinuxOther):
        pass

    class BaseLinuxOtherOtherOther(BaseLinuxOtherOther):
        pass

    class BaseLinuxRedhat(BaseLinux):
        distribution = "Redhat"

    class BaseLinuxRedhat6(BaseLinuxRedhat):
        pass

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        pass

    class BaseLinuxRedhatFuture(BaseLinuxRedhat):
        pass

    class BaseLinuxAmazon(BaseLinux):
        distribution = "Amazon"

    class BaseLinuxAmazonFuture(BaseLinuxAmazon):
        pass

    class BaseLinuxCentos(BaseLinux):
        distribution = "Centos"



# Generated at 2022-06-22 22:10:19.136182
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Make sure the platform module returns the distribution properly depending on which Linux
    distribution it is run on
    '''
    old_distro_id = distro.id
    old_platform_system = platform.system


# Generated at 2022-06-22 22:10:30.726333
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class LinuxBase(Base):
        platform = 'Linux'
        distribution = None

    class LinuxDistBase(Base):
        platform = 'Linux'
        distribution = 'RedHat'

    class LinuxDistBase2(Base):
        platform = 'Linux'
        distribution = 'RedHat'

    class LinuxDistBase3(Base):
        platform = 'Linux'
        distribution = 'RedHat'

    class LinuxDistBase4(Base):
        platform = 'Linux'
        distribution = 'RedHat'

    class LinuxDistBase5(Base):
        platform = 'Linux'
        distribution = 'RedHat'

    class LinuxDistBase6(Base):
        platform = 'Linux'
        distribution = 'RedHat'

    Base.__subclasses__ = ()
    LinuxBase.__subclasses__ = ()
   

# Generated at 2022-06-22 22:10:36.663848
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for function get_distribution

    :returns: None
    :raises AssertionError: If one of the tests fails
    '''
    assert get_distribution() in ('Linux', 'Freebsd', 'Netbsd', 'Openbsd', 'Sunos')


# Generated at 2022-06-22 22:10:39.301706
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for the function get_distribution_codename
    '''
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-22 22:10:50.871105
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base(object):
        pass
    class Windows(Base):
        platform = 'Windows'
    class Linux(Base):
        platform = 'Linux'
    class OtherLinux(Linux):
        distribution = 'OtherLinux'
    class Amazon(Linux):
        distribution = 'Amazon'
    class Redhat(Linux):
        distribution = 'Redhat'

    _distro = get_distribution()

    for cls in (Windows, Linux, OtherLinux, Amazon, Redhat):
        platform.system = lambda: cls.platform

        if cls == Base:
            _distro = None
        elif cls == Windows:
            _distro = None  # noqa
        elif cls == Linux:
            _distro = None  # noqa

# Generated at 2022-06-22 22:11:00.991450
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Mock out platform.system() to return Linux.  We don't need to actually test
    # all the available platforms.
    original_platform_system = platform.system

    platform.system = lambda: 'Linux'

    class PlatformIndependentClass:
        '''
        This class is not implemented for a specific platform
        '''

        def __init__(self):
            pass

    class LinuxClass:
        '''
        This class is implemented for a Linux platform
        '''
        platform = 'Linux'
        distribution = None

        def __init__(self):
            pass

    class LinuxUbuntuClass(LinuxClass):
        '''
        This class is implemented for a Ubuntu Linux platform
        '''
        distribution = 'Ubuntu'

        def __init__(self):
            pass


# Generated at 2022-06-22 22:11:12.739993
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils import distro
    distro._distro = None

    import platform
    platform_system = platform.system
    platform_dist = platform.dist
    platform_linux_distribution = platform.linux_distribution
    def _linux_distribution_mock():
        return ('Red Hat Enterprise Linux Server', '7.5', 'Maipo')
    platform.system = lambda: 'Linux'
    platform.dist = lambda: ('redhat', '7', '5')
    platform.linux_distribution = _linux_distribution_mock

    try:
        assert get_distribution_codename() == 'Maipo'
    except:  # noqa: E722
        platform.system = platform_system
        platform.dist = platform_dist
        platform.linux_distribution = platform_linux_

# Generated at 2022-06-22 22:11:14.704993
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == u'Otherlinux', "failed to get_distribution()"

# Generated at 2022-06-22 22:11:21.376129
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for function get_distribution
    '''

    assert get_distribution() == u'Amazon'
    assert get_distribution() == u'Freebsd'
    assert get_distribution() == u'Macos'
    assert get_distribution() == u'Redhat'
    assert get_distribution() == u'Sles'
    assert get_distribution() == u'Ubuntu'
    assert get_distribution() == u'Windows'
    assert get_distribution() == u'OtherLinux'


# Generated at 2022-06-22 22:11:34.146721
# Unit test for function get_distribution

# Generated at 2022-06-22 22:11:38.254663
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution = get_distribution()
    codename = get_distribution_codename()
    if distribution == 'Amazon':
        assert codename == 'amzn', codename
    elif distribution == 'Redhat':
        assert codename == 'rhel', codename
    elif distribution == 'Debian':
        assert codename == 'wheezy', codename
    elif distribution in ('Suse', 'Sles'):
        assert codename == 'sles', codename
    elif distribution == 'Ubuntu':
        assert codename == 'xenial', codename
    elif distribution == 'Centos':
        assert codename is not None, codename

# Generated at 2022-06-22 22:11:45.599112
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    # Bionic Beaver (18.04)
    os_release = {
        'name': 'Ubuntu',
        'id': 'ubuntu',
        'version_id': '18.04',
        'ubuntu_codename': 'bionic'
    }
    distro_codename = get_distribution_codename()
    assert distro_codename == 'bionic'

    # Disco Dingo (19.04)
    os_release = {
        'name': 'Ubuntu',
        'id': 'ubuntu',
        'version_id': '19.04',
        'ubuntu_codename': 'disco'
    }
    distro_codename = get_distribution_codename()