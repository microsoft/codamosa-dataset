

# Generated at 2022-06-24 20:56:28.144270
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass
    class BSD(BaseClass):
        platform = 'BSD'
    class Linux(BaseClass):
        platform = 'Linux'
    class LinuxWithDist(Linux):
        distribution = 'A'

    # BSD should be chosen if we are on BSD
    platform.system = lambda: 'BSD'
    assert get_platform_subclass(BaseClass) == BSD
    # Linux should be chosen if we are on Linux
    platform.system = lambda: 'Linux'
    assert get_platform_subclass(BaseClass) == Linux
    # we should use a subclass that matches the distribution
    platform.system = lambda: 'Linux'
    get_distribution = lambda: 'A'
    assert get_platform_subclass(BaseClass) == LinuxWithDist
    # we should choose the most specific subclass available
   

# Generated at 2022-06-24 20:56:34.450008
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()
    subclass = None
    # get the most specific superclass for this platform
    if distribution is not None:
        for sc in get_all_subclasses(test_get_platform_subclass):
            if sc.distribution is not None and sc.distribution == distribution and sc.platform == this_platform:
                subclass = sc
    if subclass is None:
        for sc in get_all_subclasses(test_get_platform_subclass):
            if sc.platform == this_platform and sc.distribution is None:
                subclass = sc
    if subclass is None:
        subclass = test_get_platform_subclass
    return subclass

# Generated at 2022-06-24 20:56:42.188176
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()

    ans_cls = get_platform_subclass(platform)
    ans_cls2 = get_platform_subclass(distribution)
    ans_cls3 = get_platform_subclass(this_platform)

    print(" Type ans_cls : ", type(ans_cls))
    print(" Type ans_cls2 : ", type(ans_cls2))
    print(" Type ans_cls3 : ", type(ans_cls3))

# Generated at 2022-06-24 20:56:43.502272
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()
    assert var_0



# Generated at 2022-06-24 20:56:45.539031
# Unit test for function get_distribution
def test_get_distribution():
    assert True == get_distribution()
create_test_case("test_get_distribution", test_get_distribution)



# Generated at 2022-06-24 20:56:53.200896
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # This class is for testing get_platform_subclass
    class ClassA:
        platform = None
        distribution = None
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    class ClassB(ClassA):
        platform = "foo"
        distribution = None

    class ClassC(ClassA):
        platform = None
        distribution = "bar"

    class ClassD(ClassA):
        platform = "foo"
        distribution = "bar"

    # This test expects the default ClassA to be returned as the superclass since no platform and
    # distribution is provided.
    a = ClassA(1, 2)
    assert(get_platform_subclass(ClassA) == ClassA)

    # This test expects the ClassB to be returned after setting the

# Generated at 2022-06-24 20:56:56.898960
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_1 = get_platform_subclass(None)


# Generated at 2022-06-24 20:57:05.721721
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test if the codename is parsed correctly
    assert get_distribution_codename() == "xenial"

    # Test for platforms with a specific distro and platform implemented
    cls = get_platform_subclass(User)
    assert cls.__name__ == 'SpecificPlatformImplementation'

    cls = get_platform_subclass(Group)
    assert cls.__name__ == 'SpecificPlatformImplementation'

    # Test for platforms with a specific platform but not a specific distro implemented
    cls = get_platform_subclass(Service)
    assert cls.__name__ == 'SpecificPlatformImplementation'

    cls = get_platform_subclass(Package)
    assert cls.__name__ == 'SpecificPlatformImplementation'

    # Test for platforms with neither a specific platform or distro implemented
    cls = get

# Generated at 2022-06-24 20:57:06.312339
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:57:09.813191
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    if platform.system() == 'Linux':
        assert get_distribution_codename() is not None
    else:
        assert get_distribution_codename() is None

# Generated at 2022-06-24 20:57:24.439514
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import mock
    import ansible.module_utils.basic

    class TestClass(ansible.module_utils.basic.AnsibleModule):
        distribution = None
        platform = platform.system()

        def __init__(self, *args, **kwargs):
            super(TestClass, self).__init__(*args, **kwargs)

    class TestUbuntu(TestClass):
        distribution = u'Ubuntu'
        platform = platform.system()

        def __init__(self, *args, **kwargs):
            super(TestUbuntu, self).__init__(*args, **kwargs)

    class TestRedhat(TestClass):
        distribution = u'Redhat'
        platform = platform.system()

        def __init__(self, *args, **kwargs):
            super(TestRedhat, self).__

# Generated at 2022-06-24 20:57:35.544459
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Dummy:
        pass

    class DummyPlatform(Dummy):
        platform = platform.system()

    class DummyOtherPlatform(Dummy):
        platform = 'Other'

    class DummyLinux(Dummy):
        platform = 'Linux'

    class DummyRedhat(Dummy):
        distribution = 'Redhat'

    class DummyRedhatCentOS(Dummy):
        distribution = 'Redhat'

    class DummyRedhatCentOSPlatform(DummyRedhat, DummyRedhatCentOS):
        platform = platform.system()

    class DummyRedhatCentOS5(DummyRedhatCentOS):
        distribution_version = '5'

    class DummyRedhatCentOS5Platform(DummyRedhatCentOS5, DummyRedhatCentOSPlatform):
        pass


# Generated at 2022-06-24 20:57:41.541558
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test resolved via the real thing
    var_1 = get_distribution_version()
    # Test resolved via the mock
    with mock.patch('ansible.module_utils.common.distro.version'):
        var_2 = get_distribution_version()
    assert var_1 == var_2


# Generated at 2022-06-24 20:57:43.406844
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    print(var_0)


# Generated at 2022-06-24 20:57:44.621992
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()

    assert var_0 is None

# Generated at 2022-06-24 20:57:54.930264
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()

    class Class:
        distribution = None
        platform = this_platform

        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(cls)
            return super(cls, new_cls).__new__(new_cls)

    subclass = None

    # get the most specific superclass for this platform
    if distribution is not None:
        for sc in get_all_subclasses(Class):
            if sc.distribution is not None and sc.distribution == distribution and sc.platform == this_platform:
                subclass = sc

# Generated at 2022-06-24 20:58:00.808633
# Unit test for function get_distribution
def test_get_distribution():
    # print("get_distribution():", get_distribution())
    var_1 = get_distribution()
    print("var_1:", var_1)
    if ((var_1 is not None) and (len(var_1) > 0)):
        assert var_1 in ['LinuxMint', 'Fedora', 'Ubuntu', 'Debian', 'Darwin', 'NetBSD', 'FreeBSD', 'Archlinux']
    else:
        assert 0, "get_distribution() == " + str(var_1)



# Generated at 2022-06-24 20:58:13.247852
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import Environment

    # Known platforms that subclass works correctly for
    known_platforms = (
        ('Linux', 'Amazon', 'AmazonLinux'),
        ('Linux', None, 'OtherLinux'),
        ('Linux', 'CentOS', 'Redhat'),
        ('Linux', 'Ubuntu', 'Debian'),
        ('FreeBSD', 'FreeBSD'),
    )

    for platform_, distro_, class_name in known_platforms:
        env = Environment({'distribution': distro_, 'platform': platform_})
        subclass = get_platform_subclass(env)
        assert class_name == subclass.__name__, 'Expected {0}, got {1}'.format(class_name, subclass.__name__)
        # MacOS is mostly Linux compatible and has been
        # reported to have a

# Generated at 2022-06-24 20:58:13.990318
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    new_class = get_distribution_codename()


# Generated at 2022-06-24 20:58:23.707011
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible_module_utils.common.distribution import DistributionBase, RedHatSysV, Debian, BSD
    import types

    class Foo(object):
        def __init__(self):
            pass

    foo_subclass1 = types.new_class('foo_subclass1', (Foo,))
    foo_subclass1.platform = 'Linux'
    foo_subclass1.distribution = 'RedHat'
    foo_subclass2 = types.new_class('foo_subclass2', (Foo,))
    foo_subclass2.platform = 'Linux'
    foo_subclass2.distribution = None
    foo_subclass3 = get_platform_subclass(Foo)

    assert foo_subclass1 is None
    assert foo_subclass2 is None

# Generated at 2022-06-24 20:58:32.029426
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic
    this_platform = platform.system()
    distribution = get_distribution()

    example = get_platform_subclass(ansible.module_utils.basic.AnsibleModule)
    assert isinstance(example, ansible.module_utils.basic.AnsibleModule)

# Generated at 2022-06-24 20:58:32.803248
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()

# Generated at 2022-06-24 20:58:34.047524
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:35.096002
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'



# Generated at 2022-06-24 20:58:37.361585
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:58:45.837235
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test case 1
    from ansible.module_utils.basic import *

    class DummyModule:
        platform = 'Linux'
        distribution = 'Redhat'

    this_platform = platform.system()
    distribution = get_distribution()

    assert distribution == 'Redhat', 'get_distribution should return RedHat'
    assert this_platform == 'Linux', 'platform.system() should return Linux'

    assert get_platform_subclass(DummyModule) == RedHatModules, 'get_platform_subclass should return RedHatModules'

# Generated at 2022-06-24 20:58:56.197561
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import User as User_

    class User(User_):
        platform = 'Linux'
        distribution = None

    class LSBUser(User_):
        platform = 'Linux'
        distribution = 'LSB'

    class LinuxUser(User_):
        platform = 'Linux'
        distribution = None

    class OtherLinuxUser(User_):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class RedhatUser(User_):
        platform = 'Linux'
        distribution = 'Redhat'

    class AmazonUser(User_):
        platform = 'Linux'
        distribution = 'Amazon'

    class UbuntuUser(User_):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class DebianUser(User_):
        platform = 'Linux'

# Generated at 2022-06-24 20:58:59.283726
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    invocation = 'Invocation'
    # No arguments
    expected_result = 'Invocation'
    actual_result = get_distribution_codename()
    assert expected_result == actual_result, "'Invocation' does not match '{actual_result}'"

# Generated at 2022-06-24 20:59:10.084015
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from .ansible_module_utils.basic import AnsibleModule, load_platform_subclass

    class BSDCommon:
        @staticmethod
        def random_func():
            return 'BSDCommon'

    class LinuxCommon:
        @staticmethod
        def random_func():
            return 'LinuxCommon'

    class DebianCommon(LinuxCommon):
        @staticmethod
        def random_func():
            return 'DebianCommon'

    class FedoraCommon(LinuxCommon):
        @staticmethod
        def random_func():
            return 'FedoraCommon'

    class RHELCommon(LinuxCommon):
        @staticmethod
        def random_func():
            return 'RHELCommon'

    class FreeBSDCommon(BSDCommon):
        @staticmethod
        def random_func():
            return 'FreeBSDCommon'


# Generated at 2022-06-24 20:59:19.826391
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule, AnsibleModuleError
    from ansible.module_utils.basic import get_distribution, get_distribution_version, get_platform_subclass

    class Basic(object):
        platform = "All"
        distribution = None

        def __init__(self, module):
            self.module = module

    class LinuxOnly(Basic):
        platform = "Linux"

    class OtherLinuxOnly(Basic):
        platform = "Linux"
        distribution = "OtherLinux"

    class AmazonLinuxOnly(Basic):
        platform = "Linux"
        distribution = "Amazon"

    class AmazonLinuxOnly_v2(Basic):
        platform = "Linux"
        distribution = "Amazon"

    class LinuxDebianOnly(Basic):
        platform = "Linux"
        distribution = "Debian"

# Generated at 2022-06-24 20:59:27.570336
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Darwin'


# Generated at 2022-06-24 20:59:28.939924
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass()



# Generated at 2022-06-24 20:59:30.183370
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()


# Generated at 2022-06-24 20:59:33.524136
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Setup
    class class_0():
        def __init__(self):
            self.distribution = None
            self.platform = None

    # Testing
    var_0 = get_platform_subclass(class_0)
    assert not var_0

# Generated at 2022-06-24 20:59:35.087478
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None


# Generated at 2022-06-24 20:59:36.361716
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:59:37.715660
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:59:45.252424
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # get_platform_subclass() raises nothing if called on incorrect type
    try:
        assert callable(distro.id)
        assert callable(distro.version)
    except AssertionError:
        # Ansible does not yet run python 3 so distro is not yet properly ported
        return

    class Python3:
        platform = 'Linux'
        distribution = 'Python3'
        pass

    assert get_platform_subclass(Python3) == Python3
    class Python3:
        platform = 'Linux'
        distribution = 'Fedora'
        pass

    assert get_platform_subclass(Python3) == Python3
    class Python3:
        platform = 'SunOS'
        distribution = 'Python3'
        pass

    assert get_platform_subclass(Python3) == Python3

# Generated at 2022-06-24 20:59:47.915339
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        var_1 = isinstance(get_platform_subclass(test_case_0), type)
    except Exception:
        var_1 = False

    assert var_1

if __name__ == '__main__':
    test_get_platform_subclass()

# Generated at 2022-06-24 20:59:49.598821
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    try:
        assert get_distribution_codename()
    except:
        assert 1==1


# Generated at 2022-06-24 21:00:02.337588
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert var_0 in [False, True]
    # We don't know the distribution so we don't know what the
    # value will be


# Generated at 2022-06-24 21:00:12.107230
# Unit test for function get_distribution
def test_get_distribution():

    this_platform = platform.system().lower()
    expected = None

    if this_platform == u'linux':
        distro_obj = distro.LinuxDistribution()
        expected = distro_obj.id().capitalize()

        if not expected:
            expected = u'OtherLinux'
    elif this_platform == u'darwin':
        expected = u'Macosx'
    elif this_platform == u'freebsd':
        expected = u'Freebsd'
    elif this_platform == u'sunos':
        expected = u'Solaris'
    elif this_platform == u'aix':
        expected = u'Aix'

    assert expected == get_distribution()

# Generated at 2022-06-24 21:00:18.886540
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils._text import to_bytes

    assert 'DistributionModule' in str(get_platform_subclass(distro.DistributionModule))
    assert 'RedHatModule' in str(get_platform_subclass(distro.DistributionModule))
    assert 'DistributionModule' in str(get_platform_subclass(distro.LinuxDistributionModule))
    assert 'RedHatModule' in str(get_platform_subclass(distro.LinuxDistributionModule))

    class RedHatModule(distro.DistributionModule):
        _dist_name = 'redhat'
        _module_name = 'redhat_module'
        _module_args = 'modules/redhat_module.py'

        @property
        def distribution(self):
            return self._dist_name


# Generated at 2022-06-24 21:00:19.387678
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True

# Generated at 2022-06-24 21:00:20.112805
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    pass


# Generated at 2022-06-24 21:00:21.145070
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(True) == None, "Check should return None"

# Generated at 2022-06-24 21:00:22.717347
# Unit test for function get_distribution_version
def test_get_distribution_version():
    pass


# Generated at 2022-06-24 21:00:27.666888
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    arg_0 = type('', (), {})()
    ret_0 = get_platform_subclass(arg_0)
    assert ret_0 == arg_0

# Generated at 2022-06-24 21:00:33.876898
# Unit test for function get_distribution
def test_get_distribution():

    # Variables
    var_0 = None
    var_1 = None
    var_2 = None

    # Create standard class instance
    obj_0 = var_0

    # Create standard class instance
    obj_1 = var_0

    # Create standard class instance
    obj_2 = var_0

    # Create standard class instance
    obj_3 = var_0

    # Create standard class instance
    obj_4 = var_0

    # Create standard class instance
    obj_5 = var_0

    # Create standard class instance
    obj_6 = var_0

    # Create standard class instance
    obj_7 = var_0

    # Create standard class instance
    obj_8 = var_0

    # Create standard class instance
    obj_9 = var_0

    # Create standard class instance
    obj_10 = var

# Generated at 2022-06-24 21:00:41.278832
# Unit test for function get_distribution_version
def test_get_distribution_version():
    Linux = "Linux"
    Redhat = "Redhat"
    Linux_version = "5.10"
    Redhat_version = "5.10"
    try:
        assert get_distribution_version() == Linux_version or Redhat_version
    except AssertionError:
        print("get_distribution_version doesn't work properly")



# Generated at 2022-06-24 21:01:04.080258
# Unit test for function get_distribution_codename

# Generated at 2022-06-24 21:01:09.089821
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic_module_utils

    plat_subclass = get_platform_subclass(basic_module_utils.PlatformModule)

    assert plat_subclass is not None

    return plat_subclass

# Generated at 2022-06-24 21:01:11.469820
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial', 'Expected: xenial, Actual: {}'.format(get_distribution_codename())


# Generated at 2022-06-24 21:01:15.781368
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # No parameters
    try:
        get_distribution_version()
    except SystemExit:
        assert False
    except Exception:
        assert True
    else:
        assert True


# Generated at 2022-06-24 21:01:16.771890
# Unit test for function get_distribution
def test_get_distribution():
    assert test_case_0() == 'Amazon'


# Generated at 2022-06-24 21:01:28.074180
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # For this, we have to have the User module implementation
    # to see what the subclass is.
    from ansible.modules.user.user import User
    this_platform = platform.system()
    distribution = get_distribution()

    platform_class = get_platform_subclass(User)

    # If the platform is Windows, no distribution was likely specified so the
    # subclass should just be the topmost one
    if this_platform == 'Windows':
        assert isinstance(platform_class, User)
    else:
        assert isinstance(platform_class, type)
        assert issubclass(platform_class, User)
        assert platform_class.distribution == distribution
        # Can't test for this because different systems have different versions
        # of distro
        # assert platform_class.distribution_version == distribution_version
        assert platform

# Generated at 2022-06-24 21:01:28.940503
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()

# Generated at 2022-06-24 21:01:31.658097
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Case 0:
    var_0 = get_distribution_codename()

    # Test for source match (case 0)
    assert var_0 == None, 'Test for source match (case 0)'



# Generated at 2022-06-24 21:01:39.764848
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import sys
    import json
    import platform
    if platform.system() == 'Linux':
        var_2 = get_distribution_codename()
    else:
        var_2 = 'Not Linux'
    var_3 = platform.system()
    print('get_distribution_codename() returns {} on {}'.format(var_2, var_3))


# Generated at 2022-06-24 21:01:45.581309
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()

    #if var_0 is None:
    #    raise ValueError('test_get_distribution() did not return expected value')


# Generated at 2022-06-24 21:02:11.544722
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version
    '''
    # Element 0 - test case

    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:02:22.432271
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    with patch("%s.platform.system" % MODULE_NAME, return_value="Linux"):
        with patch("%s.distro.os_release_info" % MODULE_NAME, return_value={"ubuntu_codename": "trusty"}):
            assert get_distribution_codename() == "trusty"
        with patch("%s.distro.os_release_info" % MODULE_NAME, return_value={"version_codename": "trusty"}):
            assert get_distribution_codename() == "trusty"
        with patch("%s.distro.os_release_info" % MODULE_NAME, return_value={"version_codename": ""}):
            assert get_distribution_codename() is None

# Generated at 2022-06-24 21:02:24.384662
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_2 = get_distribution_version()



# Generated at 2022-06-24 21:02:25.407070
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(str)
    return

# Generated at 2022-06-24 21:02:34.576630
# Unit test for function get_distribution
def test_get_distribution():
    import ansible_collections.ansible.community.tests.unit.compat.mock as mock
    import collections

    mock_value = 'mock_value'
    var_0 = mock.MagicMock(return_value = mock_value)
    with mock.patch('ansible_collections.ansible.community.tests.unit.test_distro.distro.id', var_0):
        mock_value_1 = 'mock_value_1'
        var_1 = mock.MagicMock(return_value = mock_value_1)
        with mock.patch('ansible_collections.ansible.community.tests.unit.test_distro.platform.system', var_1):
            setattr(collections, 'OrderedDict', dict)
            var_3 = get_distribution()

# Generated at 2022-06-24 21:02:38.195757
# Unit test for function get_distribution
def test_get_distribution():
    expected = platform.system()
    expected = expected.capitalize()

    actual = get_distribution()

    assert actual == expected



# Generated at 2022-06-24 21:02:42.120851
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print('Test: test_get_distribution_codename')
    var_codename = get_distribution_codename()
    if var_codename == None:
        print('OK')
    else:
        print('FAILED')
        print('Returned: ' + var_codename)


# Generated at 2022-06-24 21:02:44.092457
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Check if it returns a string
    assert type(get_distribution_codename()) == type("string")


# Generated at 2022-06-24 21:02:46.006544
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert isinstance(var_0, str)



# Generated at 2022-06-24 21:02:47.589030
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-24 21:03:32.794333
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'


# Generated at 2022-06-24 21:03:34.071526
# Unit test for function get_distribution
def test_get_distribution():
    # Try to seed for all 7 possible results
    pass



# Generated at 2022-06-24 21:03:37.581922
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert var_0 == 'Ubuntu'



# Generated at 2022-06-24 21:03:38.888497
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '19.10'

# Generated at 2022-06-24 21:03:40.183062
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == get_distribution_version()

# Generated at 2022-06-24 21:03:42.657796
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_1 = get_platform_subclass(platform.system())
    assert isinstance(var_1, str)

# Generated at 2022-06-24 21:03:45.586841
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test for function get_platform_subclass
    '''
    for cls in get_all_subclasses(native_ansible.module_utils.basic.AnsibleModule):
        new_cls = get_platform_subclass(cls)
        assert new_cls, "Failed to create a new class for class %s" % cls



# Generated at 2022-06-24 21:03:46.557100
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:03:52.597932
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic

    class Base(object):
        pass

    class LinuxSubclass(Base):
        platform = "Linux"

    class LinuxDistroSubclass(LinuxSubclass):
        distribution = "LinuxDistro"

    class LinuxAnotherDistroSubclass(LinuxSubclass):
        distribution = "LinuxAnotherDistro"

    class LinuxNotDistroSubclass(LinuxSubclass):
        distribution = "NotDistro"

    class LinuxAnotherNotDistroSubclass(LinuxSubclass):
        distribution = "AnotherNotDistro"

    assert get_platform_subclass(LinuxSubclass) == LinuxSubclass
    assert get_platform_subclass(LinuxDistroSubclass) == LinuxDistroSubclass
    assert get_platform_subclass(LinuxAnotherDistroSubclass) == LinuxAnotherDistroSubclass


# Generated at 2022-06-24 21:03:53.829622
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # FIXME: Add a test case for this function
    pass

# Generated at 2022-06-24 21:04:39.065371
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()



# Generated at 2022-06-24 21:04:43.456348
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    ret = get_distribution_codename()
    assert ret is not None


# Generated at 2022-06-24 21:04:51.204972
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()

    subclass = None

    # get the most specific superclass for this platform
    if distribution is not None:
        for sc in get_all_subclasses():
            if sc.distribution is not None and sc.distribution == distribution and sc.platform == this_platform:
                subclass = sc
    if subclass is None:
        for sc in get_all_subclasses():
            if sc.platform == this_platform and sc.distribution is None:
                subclass = sc
    if subclass is None:
        subclass = cls

    return subclass

# Generated at 2022-06-24 21:04:52.235724
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == None


# Generated at 2022-06-24 21:04:53.437188
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename = get_distribution_codename()
    assert distribution_codename

# Generated at 2022-06-24 21:04:59.533812
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()
    subclass = None
    try:
        cls = get_platform_subclass(subclass)
    except:
        print("Failed to fetch subclass")

# Generated at 2022-06-24 21:05:01.073097
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'ringtail'
    return True


# Generated at 2022-06-24 21:05:02.272692
# Unit test for function get_distribution
def test_get_distribution():
    print("in test_get_distribution")
    assert test_case_0() == "Redhat"

# Generated at 2022-06-24 21:05:05.100579
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:05:13.918636
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    # check that the module class gets returned when there is no platform subclass
    assert get_platform_subclass(AnsibleModule) == AnsibleModule  # noqa F821

    # create a dummy platform subclass
    class FakeModulePlatform(AnsibleModule):
        platform = 'Linux'  # noqa F821
        distribution = 'FakeLinux'  # noqa F821

    # check that the platform subclass gets returned when the platform is detected
    assert get_platform_subclass(AnsibleModule) == FakeModulePlatform  # noqa F821

# Generated at 2022-06-24 21:06:00.380114
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:06:02.650296
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print('\n')
    print(get_distribution_codename())
    print('\n')


# Generated at 2022-06-24 21:06:03.689812
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:06:13.187481
# Unit test for function get_distribution_version
def test_get_distribution_version():
    os_release_info = u'''
NAME="openSUSE Leap"
VERSION="42.3"
ID=opensuse
ID_LIKE="suse linux"
VERSION_ID="42.3"
PRETTY_NAME="openSUSE Leap 42.3"
ANSI_COLOR="0;32"
CPE_NAME="cpe:/o:opensuse:leap:42.3:ga"
BUG_REPORT_URL="https://bugs.opensuse.org"
HOME_URL="https://www.opensuse.org/"
'''

    distribution_id = u'opensuse'
    codename = u''
    version_info = u'42.3'

    # Test function with os release file