

# Generated at 2022-06-24 20:56:28.170438
# Unit test for function get_distribution_version
def test_get_distribution_version():
    current_distro = distro.id()

    assert get_distribution_version().isalnum()
    assert get_distribution_version() != ""
    assert current_distro == 'fedora'


# Generated at 2022-06-24 20:56:28.676373
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True

# Generated at 2022-06-24 20:56:29.613450
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass  # TODO


# Generated at 2022-06-24 20:56:30.566513
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()

# Generated at 2022-06-24 20:56:31.088849
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True == True

# Generated at 2022-06-24 20:56:35.121957
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True

# Generated at 2022-06-24 20:56:36.270299
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:56:37.189717
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_1 = get_platform_subclass('str')


# Generated at 2022-06-24 20:56:38.958578
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True == True


# Generated at 2022-06-24 20:56:40.910176
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    result = get_distribution_codename()
    assert result
    assert type(result) is str


# Generated at 2022-06-24 20:56:50.532826
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    #         (self, *args, **kwargs)
    """Expected results:
    None
    None
    None
    """
    assert get_distribution_codename('gibberish') is None
    assert get_distribution_codename('') is None
    assert get_distribution_codename(None) is None


# Generated at 2022-06-24 20:56:52.523311
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename runs smoothly
    :return:
    '''
    assert get_distribution_codename() == None

# Generated at 2022-06-24 20:57:04.420343
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test the class variables to ensure we have the correct data.
    # Test for init, first for proper input, then for improper input
    # Test for repr (with inputs)

    # Reuse this over and over
    s = get_distribution_codename()

# Generated at 2022-06-24 20:57:07.722717
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass(cls, var_0)
    return var_0


if __name__ == '__main__':
    print(test_case_0())

# Generated at 2022-06-24 20:57:10.450410
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    arg_0 = type
    get_platform_subclass(arg_0)



# Generated at 2022-06-24 20:57:13.032188
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()


# Generated at 2022-06-24 20:57:14.261836
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:57:22.856246
# Unit test for function get_distribution
def test_get_distribution():
    ansible_0 = Ansible()

    platform_0 = run_command('uname -s')
    if (platform_0['rc'] == 0):
        if (platform_0['stdout'].strip() == 'Linux'):
            var_0 = get_distribution()
            if (var_0 == 'OtherLinux'):
                assert var_0 == 'OtherLinux'
            else:
                assert var_0._get_name() == 'ansible.module_utils.basic.get_distribution'
                var_0 = get_distribution()
                if (var_0 == 'OtherLinux'):
                    assert var_0 == 'OtherLinux'
                else:
                    assert var_0.__getattr__('_get_name') == 'ansible.module_utils.basic.get_distribution'
                    assert var

# Generated at 2022-06-24 20:57:24.128786
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Replace with actual test of this function
    print ("Tried to run unit test for function get_platform_subclass.\n")


# Generated at 2022-06-24 20:57:25.470269
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() != None


# Generated at 2022-06-24 20:57:41.306243
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # xfail
    if get_distribution_codename() != u'xenial':
        raise AssertionError("get_distribution_codename() failed")


# Generated at 2022-06-24 20:57:44.333815
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # get_distribution_version with 'version-maybe-none' argument
    # get_distribution_version executed with the arguments: ('version-maybe-none',)
    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:57:45.197062
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True, 'Test not implemented'

# Generated at 2022-06-24 20:57:49.196260
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert distro.linux_distribution() == get_distribution_version()


# Generated at 2022-06-24 20:57:56.281767
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Test_0:
        distribution = None
        platform = 'Linux'

    class Test_1:
        distribution = 'NonLinux'
        platform = 'Linux'

    class Test_2:
        distribution = None
        platform = 'NonLinux'

    class Test_3:
        distribution = 'NonLinux'
        platform = 'NonLinux'

    class Test_4(Test_0):
        pass

    class Test_5(Test_1):
        pass

    class Test_6(Test_2):
        pass

    class Test_7(Test_3):
        pass

    class Test_8(Test_4):
        pass

    class Test_9(Test_5):
        pass

    class Test_10(Test_6):
        pass

    class Test_11(Test_7):
        pass


# Generated at 2022-06-24 20:57:57.860703
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == distro.version()



# Generated at 2022-06-24 20:57:59.186057
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:57:59.793355
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == get_distribution()



# Generated at 2022-06-24 20:58:04.339665
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Provided arguments and expected results
    testdata = {
        # TODO: Add test cases
    }

    # Loop through and test list of inputs
    for type_prefix, outcome in testdata.items():
        # Skip test cases with None input
        if type_prefix is None:
            continue

        # Skip test cases with None expected outcome
        if outcome is None:
            continue

        # Assert expected outcome
        error_msg = 'Module: get_platform_subclass, Function: get_distribution, Error Code: {}'.format(type_prefix)
        assert expected == get_distribution_codename(type_prefix), error_msg

# Generated at 2022-06-24 20:58:06.299752
# Unit test for function get_distribution_version
def test_get_distribution_version():
    with pytest.raises(AssertionError):
        get_distribution_version(obj, cls='str')

# Generated at 2022-06-24 20:58:21.437597
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    this_platform = platform.system()

    os_release_info = distro.os_release_info()
    codename = os_release_info.get('version_codename')

    if codename is None:
        codename = os_release_info.get('ubuntu_codename')

    if codename is None and distro.id() == 'ubuntu':
        lsb_release_info = distro.lsb_release_info()
        codename = lsb_release_info.get('codename')

    if codename is None:
        codename = distro.codename()

# Generated at 2022-06-24 20:58:24.283231
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    var_1 = get_distribution()
    var_2 = get_distribution()

    #These tests should run successfully.
    assert var_0 is not None, "get_distribution function failed to return distro name."


# Generated at 2022-06-24 20:58:25.337060
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert callable(get_platform_subclass)


# Generated at 2022-06-24 20:58:26.657344
# Unit test for function get_distribution
def test_get_distribution():
    '''
    >>> var_0 = get_distribution()
    '''
    pass


# Generated at 2022-06-24 20:58:28.609905
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass('test_input')
    assert var_0 == 'test_output'



# Generated at 2022-06-24 20:58:32.736970
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 20:58:34.008392
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is 'xenial'

# Generated at 2022-06-24 20:58:39.304994
# Unit test for function get_distribution
def test_get_distribution():

    # No args. Should return 'Linux' on a Linux box and 'Darwin' on a Mac.
    distro_name = get_distribution()
    this_system = platform.system()
    if this_system == 'Linux':
        assert distro_name == 'Linux', "Expected 'Linux', got '%s'" % distro_name
    elif this_system == 'Darwin':
        assert distro_name == 'Darwin', "Expected 'Darwin', got '%s'" % distro_name
    else:
        assert False, "Running this on a Windows or BSD machine is not supported"



# Generated at 2022-06-24 20:58:49.896410
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from unittest import TestLoader, TextTestRunner
    from ansible.module_utils.basic import get_platform_subclass
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    class A(object):
        def __init__(self, name):
            self.name = name

    class A1(A):
        pass

    class A2(A):
        pass

    class B(object):
        pass

    class A1B(A1, B):
        pass

    class A2B(A2, B):
        pass

    class A1B1(A1B):
        pass

    class C(object):
        def __init__(self, name):
            self.name = name + "C"


# Generated at 2022-06-24 20:59:00.042405
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic

    class Test():
        distribution = None
        platform      = 'Linux'

    class TestTest(basic.AnsibleModule):
        pass

    class TestTestTest(Test):
        pass

    class TestTestTestTest(TestTestTest):
        distribution = 'TestTestTest'

    class TestTestTestTestTest(TestTestTest):
        platform = 'TestTestTest'

    assert get_platform_subclass(Test) == Test
    assert get_platform_subclass(TestTest) == TestTest
    assert get_platform_subclass(TestTestTest) == TestTestTest
    assert get_platform_subclass(TestTestTestTest) == TestTestTestTest
    assert get_platform_subclass(TestTestTestTestTest) == TestTestTestTest


# Generated at 2022-06-24 20:59:19.861029
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.basic import get_exception_only
    from ansible.module_utils.six import string_types

    cls = None

    if not isinstance(cls, type):
        raise AttributeError('get_platform_subclass(): first argument must be a class')

    if not issubclass(cls, object):
        raise AttributeError('get_platform_subclass(): first argument must be a class')

    subclass = get_platform_subclass(cls)

    if subclass is None:
        raise AttributeError('get_platform_subclass(): subclass is None')


# Generated at 2022-06-24 20:59:23.581035
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_1 = get_platform_subclass('role_definition')
    var_2 = get_platform_subclass(get_platform_subclass)


# Generated at 2022-06-24 20:59:28.445568
# Unit test for function get_distribution
def test_get_distribution():
    # the test method requires that these variables be defined
    var_0 = platform.system()
    var_1 = distro.id()
    var_2 = distro.version(best=True)

    out = get_distribution()
    assert type(out) in [type(None), str, unicode]


# Generated at 2022-06-24 20:59:30.101908
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()
    assert var_1 == "Linuxmint"


# Generated at 2022-06-24 20:59:31.005788
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert False, "Test not implemented"



# Generated at 2022-06-24 20:59:32.847549
# Unit test for function get_distribution_version
def test_get_distribution_version():
    result = get_distribution_version()
    assert result == "7"


# Generated at 2022-06-24 20:59:33.884735
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    func = get_distribution_codename
    func()

# Generated at 2022-06-24 20:59:35.042305
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert(callable(get_platform_subclass))

# Generated at 2022-06-24 20:59:36.320586
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:59:37.654084
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:59:53.452691
# Unit test for function get_distribution_version
def test_get_distribution_version():
    test_case_0()


# Generated at 2022-06-24 20:59:54.412063
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()


# Generated at 2022-06-24 20:59:58.407392
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None



# Generated at 2022-06-24 21:00:06.029179
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys
    import unittest

    class Animal():
        pass

    class HornedAnimal(Animal):
        platform = None
        distribution = None

    class Rhino(HornedAnimal):
        platform = 'Linux'
        distribution = 'Redhat'

    class Unicorn(HornedAnimal):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class WindowsUnicorn(Unicorn):
        platform = 'Windows'

    class NonLinuxUnicorn(Unicorn):
        distribution = None

    class HornedAnimalModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            kwargs['argument_spec'] = dict()

# Generated at 2022-06-24 21:00:09.907442
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.basic import AnsibleModule
    if AnsibleModule.get_distribution() != 'Darwin':
        raise AssertionError('Expected: Darwin, but got: %s.' % AnsibleModule.get_distribution())



# Generated at 2022-06-24 21:00:11.243219
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'



# Generated at 2022-06-24 21:00:12.888936
# Unit test for function get_distribution
def test_get_distribution():
    assert (get_distribution()) != None, "Unable to determine distribution"


# Generated at 2022-06-24 21:00:13.759258
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()

# Generated at 2022-06-24 21:00:20.418610
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class User: pass
    class UserLinux(User):
        platform = 'Linux'
        distribution = None
    class UserRedHat(User):
        platform = 'Linux'
        distribution = 'RedHat'
    class UserCentOS(User):
        platform = 'Linux'
        distribution = 'CentOS'

    # test to make sure the most specific subclass is chosen
    assert get_platform_subclass(User) == UserLinux, 'Class UserLinux should have been chosen'
    assert get_platform_subclass(UserLinux) == UserLinux, 'Class UserLinux should have been chosen'
    assert get_platform_subclass(UserRedHat) == UserRedHat, 'Class UserRedHat should have been chosen'
    assert get_platform_subclass(UserCentOS) == UserCentOS, 'Class UserCentOS should have been chosen'

# Generated at 2022-06-24 21:00:21.605503
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:00:47.638819
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()

    assert var_0 is None



# Generated at 2022-06-24 21:00:48.918960
# Unit test for function get_distribution
def test_get_distribution():
    result = get_distribution()
    assert True


# Generated at 2022-06-24 21:00:54.502613
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distro_codename = get_distribution_codename()


# Generated at 2022-06-24 21:01:06.036282
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Get the class that implements the desired functionality on the platform
    """

    # The base class
    class BaseClass:
        class_var = "BaseClass"
        pass
    # The platform subclass
    class PlatformSubClass:
        class_var = "PlatformSubClass"
        pass
    # The distribution subclass
    class DistributionSubClass:
        class_var = "DistributionSubClass"
        pass
    # The platform distribution subclass
    class PlatformDistributionSubClass:
        class_var = "PlatformDistributionSubClass"
        pass
    # The OtherLinux subclass
    class OtherLinuxSubClass:
        class_var = "OtherLinuxSubClass"
        pass
    # The DifferentPlatform subclass
    class DifferentPlatformSubClass:
        class_var = "DifferentPlatformSubClass"
        pass

    # Test when no subclass has been

# Generated at 2022-06-24 21:01:07.707937
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'


# Generated at 2022-06-24 21:01:08.658135
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()
    assert var_0 is not None


# Generated at 2022-06-24 21:01:12.802714
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import *
    class MyClass(object):
        platform = None
        distribution = None

    class MySubClass(MyClass):
        platform = 'Linux'
        distribution = 'Amazon'

    get_platform_subclass(MyClass)
    get_platform_subclass(MySubClass)

# Generated at 2022-06-24 21:01:22.252202
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock

    class TestClass:
        pass

    class SubclassForMe(TestClass):
        distribution = "TestOS"
        platform = "Linux"

    class SubclassForEveryone(TestClass):
        distribution = None
        platform = "Linux"

    class SubclassForPeopleLikeMe(TestClass):
        distribution = "TestOS"
        platform = None

    class SubclassForSomeoneElse(TestClass):
        distribution = "TestOS"
        platform = "Windows"

    # This is the first test to make sure that the plugin returns the subclass for the platform
    # the code is actually running on.

# Generated at 2022-06-24 21:01:23.521797
# Unit test for function get_distribution
def test_get_distribution():
    pass


# Generated at 2022-06-24 21:01:24.963356
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    result = get_platform_subclass()


# Generated at 2022-06-24 21:02:11.168521
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename()

# Generated at 2022-06-24 21:02:13.381240
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-24 21:02:23.077670
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import get_platform_subclass
    from ansible.module_utils import user_module
    from ansible.module_utils.basic import UserModule
    this_platform = platform.system()
    distribution = get_distribution()

    # get the most specific superclass for this platform
    if distribution is not None:
        for sc in get_all_subclasses(UserModule):
            if sc.distribution is not None and sc.distribution == distribution and sc.platform == this_platform:
                subclass = sc
    if subclass is None:
        for sc in get_all_subclasses(UserModule):
            if sc.platform == this_platform and sc.distribution is None:
                subclass = sc
    if subclass is None:
        subclass = UserModule
    return subclass


# Generated at 2022-06-24 21:02:32.704330
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        class TestCase:
            platform = 'Linux'
            distribution = 'test_dist'

        result = get_platform_subclass(TestCase)
        assert result == TestCase
    except:
        assert False

    try:
        class TestCase:
            platform = 'Linux'

        result = get_platform_subclass(TestCase)
        assert result == TestCase
    except:
        assert False


# Generated at 2022-06-24 21:02:33.992103
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:02:34.995366
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:02:38.724525
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # No args required.
    var_1 = get_distribution_codename()
    print(var_1)
    assert True



# Generated at 2022-06-24 21:02:40.339173
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    func = get_distribution_codename
    assert func() is not None
    pass


# Generated at 2022-06-24 21:02:50.754686
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class PlatformSpecific(object):
        platform = None
        distribution = None

    class Linux(PlatformSpecific):
        platform = 'Linux'

    class LinuxDistro(PlatformSpecific):
        platform = 'Linux'
        distribution = 'BobsYourUncle'

    class LinuxDistroPlatform(Linux):
        distribution = 'BobsYourUncle'

    assert LinuxDistroPlatform == get_platform_subclass(PlatformSpecific)

    class LinuxDistroPlatform2(LinuxDistro):
        platform = 'Linux'

    assert LinuxDistroPlatform2 == get_platform_subclass(PlatformSpecific)

    class LinuxOther(PlatformSpecific):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class LinuxOther2(PlatformSpecific):
        platform = 'Linux'
        distribution = 'OtherLinux'

    # Subclasses that have different distributions and platforms should

# Generated at 2022-06-24 21:02:52.514975
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    arg_0 = 'debian'
    assert get_distribution_codename() == arg_0



# Generated at 2022-06-24 21:03:39.381448
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename()


# Generated at 2022-06-24 21:03:40.680071
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert(get_distribution_version() is not None)


# Generated at 2022-06-24 21:03:42.437697
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert False, "TODO: Implement test"

# Generated at 2022-06-24 21:03:47.140452
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-24 21:03:48.205789
# Unit test for function get_distribution
def test_get_distribution():
    print('in function: get_distribution')
    test_case_0()

# Generated at 2022-06-24 21:03:50.455923
# Unit test for function get_distribution
def test_get_distribution():
    assert 'Ubuntu' == get_distribution()


# Generated at 2022-06-24 21:04:00.461776
# Unit test for function get_distribution
def test_get_distribution():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import get_distribution


# Generated at 2022-06-24 21:04:01.988888
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None


# Generated at 2022-06-24 21:04:05.344619
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    cls = object
    subclass = get_platform_subclass(cls)
    assert isinstance(subclass, object)

# Generated at 2022-06-24 21:04:07.007943
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == get_distribution()

# Generated at 2022-06-24 21:05:00.944283
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert load_platform_subclass(User, 'user') == UserLinux
    assert load_platform_subclass(User, 'user') == UserRedhat
    assert load_platform_subclass(User, 'user') != UserAIX
    assert load_platform_subclass(User, 'user') != UserDarwin
    assert load_platform_subclass(User, 'user') != UserFreeBSD



# Generated at 2022-06-24 21:05:06.207896
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    try:
        expected_0 = u"xenial"
        actual_0 = get_distribution_codename()
        assert expected_0 == actual_0
    except AssertionError:
        raise Exception("Test Case 0: Expected <%s>, but got <%s>" % (expected_0, actual_0))


# Generated at 2022-06-24 21:05:15.172898
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()

    subclass = None

    # get the most specific superclass for this platform
    if distribution is not None:
        for sc in get_all_subclasses(User):
            if sc.distribution is not None and sc.distribution == distribution and sc.platform == this_platform:
                subclass = sc
    if subclass is None:
        for sc in get_all_subclasses(User):
            if sc.platform == this_platform and sc.distribution is None:
                subclass = sc
    if subclass is None:
        subclass = User

    return subclass

# Generated at 2022-06-24 21:05:15.816556
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:05:17.293760
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # FIXME: Update this test to work with your new code
    assert False, "TODO: Write this test!"

# Generated at 2022-06-24 21:05:18.785230
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass() is None
# END def test_get_platform_subclass():

# Generated at 2022-06-24 21:05:21.124898
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


if __name__ == '__main__':
    test_case_0()
    test_get_distribution_version()

# Generated at 2022-06-24 21:05:24.644145
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    dummy_cls = None
    result = get_platform_subclass(dummy_cls)



# Generated at 2022-06-24 21:05:25.577729
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()


# Generated at 2022-06-24 21:05:26.609605
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass()


# Generated at 2022-06-24 21:06:15.293911
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()
    assert isinstance(var_1, str)
    assert var_1 == '' or isinstance(var_1, str)

