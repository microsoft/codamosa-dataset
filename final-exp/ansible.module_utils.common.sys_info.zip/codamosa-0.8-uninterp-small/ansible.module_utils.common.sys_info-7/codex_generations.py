

# Generated at 2022-06-24 20:56:24.997727
# Unit test for function get_distribution
def test_get_distribution():
  try:
      var_0 = get_distribution()
      var_0 = get_distribution()
      assert var_0 is None
      # If not exception is thrown, assertion is passed
  except AssertionError:
      print('Test  get_distribution() failed on line {}'.format(sys.exc_info()[-1].tb_lineno))
      raise


# Generated at 2022-06-24 20:56:27.007715
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # This is an example of what a unittest for this function might look like
    assert get_platform_subclass('cls') == 'cls'

# Generated at 2022-06-24 20:56:30.353086
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()

    assert var_0 in [u'RedHat', u'CentOS', u'Fedora', u'Debian', u'Ubuntu', u'Amazon', u'FreeBSD', u'OpenBSD', u'NetBSD', u'Darwin', u'OtherLinux', ]


# Generated at 2022-06-24 20:56:31.437223
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert callable(get_distribution_codename)


# Generated at 2022-06-24 20:56:41.341168
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    import inspect
    import os
    import sys

    # The module_utils directory is two directories above us, so we need to
    # add that to the path.
    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    sys.path.append(root_dir)

    # Create the test object
    class PlatformTest(object):
        distribution = None
        platform = None

        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    # The tests

# Generated at 2022-06-24 20:56:42.287846
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None

# Generated at 2022-06-24 20:56:43.585196
# Unit test for function get_platform_subclass

# Generated at 2022-06-24 20:56:47.711930
# Unit test for function get_distribution_version
def test_get_distribution_version():
    myos = platform.system()
    if myos == 'Linux':
        version = get_distribution_version()
        assert version is not None
    elif myos == 'Darwin':
        version = get_distribution_version()
        assert version is None
    else:
        # FIXME: windows support
        pass


# Generated at 2022-06-24 20:56:50.982109
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common.parameters import User

    x = User('foo', 1234)
    assert x.__class__.__name__ == 'User'
    assert x.__class__.__module__ == 'ansible.module_utils.basic'

# Generated at 2022-06-24 20:56:53.150554
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()
    subclass = get_platform_subclass(User)

# Generated at 2022-06-24 20:56:59.375685
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()


# Generated at 2022-06-24 20:57:01.038178
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:57:08.498374
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # Test function get_platform_subclass
    class User:
        pass

    # Test function get_platform_subclass
    class LinuxUser(User):
        pass

    class AmazonLinuxUser(LinuxUser):
        pass

    class UserTest:

        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(cls)


    class LinuxUserTest(UserTest):
        pass


    class AmazonLinuxUserTest(LinuxUserTest):
        pass

# Generated at 2022-06-24 20:57:16.888488
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Unit test setup
    os_release_info = {
        'version_codename': 'bionic'
    }

    # FIXME (#2530): Need to make some mocks for the `distro` module
    # FIXME (#2530): Need to figure out how to patch `distro.os_release_info`.  It seems to be a property.
    test_0 = get_distribution_codename()
    print(test_0)
        


# Generated at 2022-06-24 20:57:18.086863
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass() == 'test string'

# Generated at 2022-06-24 20:57:19.954489
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    Test get_distribution_version
    """
    assert get_distribution_version() in ('', '18.04', '14.04', '16.04', '7', '6', '8', '7.5')


# Generated at 2022-06-24 20:57:25.262700
# Unit test for function get_distribution
def test_get_distribution():
    try:
        test_case_0()
    except Exception as e:
        print("get_distribution() failed with exception: ", str(e))
        err = True
        return err
    else:
        return 0


# Generated at 2022-06-24 20:57:30.032135
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test with a class that has platform specific subclasses.  This should
    # return a subclass of the original class.
    class TestClass(object):
        platform = None
        distribution = None

    class TestSubClass(TestClass):
        pass

    assert get_platform_subclass(TestClass) == TestClass
    assert get_platform_subclass(TestSubClass) == TestSubClass

# Generated at 2022-06-24 20:57:32.904445
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()


# Generated at 2022-06-24 20:57:41.845453
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import types
    import platform

    the_platform = platform.system()

    class MyClass(object):
        pass

    class MyLinuxClass(MyClass):
        platform = 'Linux'
        distribution = None

    class MyLinuxAmazonClass(MyLinuxClass):
        distribution = 'Amazon'

    class MyWindowsClass(MyClass):
        platform = 'Windows'
        distribution = None

    c = get_platform_subclass(MyClass)
    assert c is MyClass
    assert type(c) is type
    assert issubclass(c, MyClass) is True
    assert (c.platform is None) and (c.distribution is None)

    c = get_platform_subclass(MyLinuxClass)
    assert c is MyLinuxClass
    assert type(c) is type
    assert issubclass(c, MyLinuxClass)

# Generated at 2022-06-24 20:57:47.609408
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_2 = get_distribution_codename()


# Generated at 2022-06-24 20:57:51.057067
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Class_0:
        platform = 'Linux'
        distribution = 'Redhat'

    # Test with Class_0
    class_0_object = Class_0()
    var_0 = get_platform_subclass( class_0_object )
    assert var_0 == Class_0


# Generated at 2022-06-24 20:57:51.456577
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass



# Generated at 2022-06-24 20:58:01.857456
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.compat.tests import unittest
    import ansible.module_utils.basic

    class FakeClass:
        pass

    class FakeSubclass(FakeClass):
        platform = 'SomePlatform'

    class FakeSubclassWithDistro(FakeClass):
        platform = 'SomePlatform'
        distribution = get_distribution()

    class FakeOtherSubclass(FakeClass):
        platform = 'SomeOtherPlatform'

    class FakeOtherSubclassWithDistro(FakeClass):
        platform = 'SomeOtherPlatform'
        distribution = get_distribution()

    def get_platform_subclass(cls):
        for sc in get_all_subclasses(cls):
            if sc.platform == platform.system():
                return sc
        return cls


# Generated at 2022-06-24 20:58:05.126569
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None


# Generated at 2022-06-24 20:58:12.908653
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test with an invalid input argument
    var_1 = get_distribution_version("")
    if var_1 != None:
        raise AssertionError("Invalid value returned %s" % var_1)

    # Test with an invalid input argument
    var_1 = get_distribution_version([])
    if var_1 != None:
        raise AssertionError("Invalid value returned %s" % var_1)

    # Test with an invalid input argument
    var_1 = get_distribution_version({})
    if var_1 != None:
        raise AssertionError("Invalid value returned %s" % var_1)

# Generated at 2022-06-24 20:58:14.110242
# Unit test for function get_distribution
def test_get_distribution():
    assert distro.id().capitalize() == get_distribution()


# Generated at 2022-06-24 20:58:16.875099
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:21.158029
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('ansible.module_utils.distro.id', lambda: 'RedHat'):
        with patch('ansible.module_utils.distro.os_release_info', lambda: {'version_codename': 'foobar'}):
            assert get_distribution_codename() == 'foobar'

# Generated at 2022-06-24 20:58:21.676898
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
	assert()

# Generated at 2022-06-24 20:58:38.750489
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Test:
        distribution = None
        platform = None

    class LinuxTest(Test):
        platform = 'Linux'

    class RedhatTest(LinuxTest):
        distribution = 'Redhat'

    class OtherLinuxTest(LinuxTest):
        distribution = 'OtherLinux'

    class WindowsTest(Test):
        platform = 'Windows'

    class AllTest(Test):
        pass

    import sys
    import platform

    platform.system = lambda: 'Linux'
    distro.id = lambda: None

    assert get_platform_subclass(AllTest) is AllTest
    assert get_platform_subclass(Test) is Test
    assert get_platform_subclass(LinuxTest) is OtherLinuxTest
    assert get_platform_subclass(RedhatTest) is OtherLinuxTest

# Generated at 2022-06-24 20:58:48.094044
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.parameters import get_platform_subclass as ansible_get_platform_subclass

    # All of the tests pass
    def test(cls, expected, distribution=None, distribution_version=None, distribution_codename=None):
        this_platform = platform.system()

        # Test the current platform when we do not specify it
        result = ansible_get_platform_subclass(cls)
        assert result == expected

        # Test the current platform when we specify it and it should not override the current platform
        result = ansible_get_platform_subclass(cls, platform=this_platform)
        assert result == expected

        # Test other platforms when we do not specify a distribution

# Generated at 2022-06-24 20:58:50.726880
# Unit test for function get_distribution
def test_get_distribution():
    try:
        var_0 = get_distribution()
    except:
        var_0 = None


# Generated at 2022-06-24 20:58:52.977859
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test the function
    var_1 = get_distribution_codename()

    # Make some assertions about the result


# Generated at 2022-06-24 20:58:54.190410
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None


# Generated at 2022-06-24 20:58:59.287671
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = 'Redhat'
    var_1 = 'Darwin'
    var_2 = 'OtherLinux'
    var_3 = 'Amazon'
    get_platform_subclass(var_0)
    get_platform_subclass(var_1)
    get_platform_subclass(var_2)
    get_platform_subclass(var_3)


# Generated at 2022-06-24 20:59:03.895006
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    this_platform = platform.system()
    distribution = get_distribution()
    codename = get_distribution_codename()

    if this_platform == 'Linux' and distribution == 'Ubuntu':
        assert codename is not None
        assert codename != ''
        assert codename in ['xenial', 'disco']
    else:
        assert codename is None



# Generated at 2022-06-24 20:59:13.914700
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    ansible_user_module_user_module_main_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module_class_module

# Generated at 2022-06-24 20:59:16.092062
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None
    assert get_distribution_codename() is not None


# Generated at 2022-06-24 20:59:20.657126
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    # Test case 0
    try:
        test_case_0()
    except:
        # if it throws an exception, that's the wrong answer
        assert(False)
    # Test case 1
    if (var_0 is None):
        assert(False)
    # Test case 2
    if (var_0 != "Redhat"):
        assert(False)



# Generated at 2022-06-24 20:59:39.475931
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class base_class:
        platform = None
        distribution = None

    class linux_fedora(base_class):
        platform = 'Linux'
        distribution = 'Fedora'

    class linux_redhat(base_class):
        platform = 'Linux'
        distribution = 'Redhat'

    class linux_redhat_enterprise_linux(base_class):
        platform = 'Linux'
        distribution = 'RedhatEnterpriseLinux'

    class linux_base(base_class):
        platform = 'Linux'

    class windows_base(base_class):
        platform = 'Windows'

    class macos_base(base_class):
        platform = 'Darwin'

    # Default case
    assert base_class == get_platform_subclass(linux_fedora)

    # Fedora

# Generated at 2022-06-24 20:59:43.773338
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:59:46.255934
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '2.7.17'

# Generated at 2022-06-24 20:59:47.793445
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()

    assert isinstance(var_0, NativeString)



# Generated at 2022-06-24 20:59:53.045103
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Ansible User module
    import ansible.module_utils.common.user

    # This shouldn't fail
    this_platform = platform.system()
    distribution = get_distribution()
    if distribution is not None:
        if this_platform == 'Linux' and distribution == 'FreeBSD':
            class_name = get_platform_subclass(ansible.module_utils.common.user.User).__name__
            assert class_name == 'FreeBSDUser'
        elif this_platform == 'Linux' and distribution == 'Darwin':
            class_name = get_platform_subclass(ansible.module_utils.common.user.User).__name__
            assert class_name == 'GenericUser'
        elif this_platform == 'Linux' and distribution == 'OpenBSD':
            class_name = get_platform_subclass

# Generated at 2022-06-24 20:59:58.356659
# Unit test for function get_distribution
def test_get_distribution():

    # call function
    try:
        var_0 = get_distribution()
    except Exception as exception:
        assert type(exception) == AttributeError

    # check results
    assert var_0 == 'Ubuntu'


# Generated at 2022-06-24 21:00:02.374202
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # assert that all branches are covered with at least one test case
    assert all("if " in line or "elif " in line or "else" in line for line in open(__file__).readlines())

if __name__ == "__main__":
    test_get_platform_subclass()
    test_case_0()

# Generated at 2022-06-24 21:00:04.480484
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass


# Generated at 2022-06-24 21:00:05.797463
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:00:07.507001
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()



# Generated at 2022-06-24 21:00:33.484889
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test a subclass that is not a subclass of the base class.
    import distutils.version
    class FooBar(object):
        platform = 'Linux'
        distribution = 'FooBar'
    class FooBarLinux(FooBar):
        pass
    assert get_platform_subclass(FooBarLinux) == FooBarLinux

    # Test a subclass that does not have an appropriate platform/distribution
    # pair
    class FooBarLinuxBaz(FooBar):
        platform = 'Baz'
    assert get_platform_subclass(FooBarLinuxBaz) == FooBar

    # Test a subclass that doesn't match the current platform
    class FooBarBadPlatform(FooBar):
        platform = 'Baz'
    assert get_platform_subclass(FooBarBadPlatform) == FooBar

    # Test a subclass that

# Generated at 2022-06-24 21:00:44.760087
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts import distribution
    this_platform = platform.system()
    this_distribution = get_distribution()
    this_distribution_version = get_distribution_version()
    this_distribution_codename = get_distribution_codename()

    pytest_args = distribution.get_platform_subclass('LinuxBaseDistribution')
    assert isinstance(pytest_args, distribution.LinuxBaseDistribution)
    assert pytest_args.distribution is None
    assert pytest_args.platform == this_platform
    assert pytest_args.distribution_version == this_distribution_version
    assert pytest_args.distribution_codename == this_distribution_codename


# Generated at 2022-06-24 21:00:50.160121
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Unit test for function get_platform_subclass()
    os_pt = get_platform_subclass('os')
    # import pdb; pdb.set_trace()
    assert os_pt.platform == platform.system()
    assert os_pt.distribution == get_distribution()

# Generated at 2022-06-24 21:00:51.778430
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()


# Generated at 2022-06-24 21:00:52.996563
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_1 = get_platform_subclass('test')

# Generated at 2022-06-24 21:00:54.212991
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None, 'Failed to get distribution version'

# Generated at 2022-06-24 21:00:57.777826
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass(None)

    assert var_0 == None, "Expected get_platform_subclass to return 'None', got '%s'" % var_0

# Generated at 2022-06-24 21:01:01.692482
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()



# Generated at 2022-06-24 21:01:03.144652
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    test_cls = get_distribution()

    assert test_cls == 'TEST_PLATFORM', test_cls

# Generated at 2022-06-24 21:01:08.839594
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    get_distribution_codename unit test stubs
    '''
    ret = get_distribution_codename()
    expected = None
    assert ret == expected


# Generated at 2022-06-24 21:01:30.042556
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print("get_distribution_codename")

    var_0 = get_distribution_codename()

    assert var_0 == None


# Generated at 2022-06-24 21:01:32.071820
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Assert if get_distribution_codename returns non-None value
    assert get_distribution_codename() is not None


# Generated at 2022-06-24 21:01:37.829832
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var1 = get_platform_subclass()


if __name__ == '__main__':
    test_case_0()
    test_get_platform_subclass()

# Generated at 2022-06-24 21:01:41.907838
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts import distribution

    # Here is how you test the modules that are automatically loaded in
    # by get_platform_subclass
    from ansible.module_utils.facts import enable_disable_module

    # Here is how you test later inherited functionality
    from ansible.module_utils.facts import augeas

    # Test a module that uses get_platform_subclass with no arguments
    test_case_0()

# Generated at 2022-06-24 21:01:43.201633
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    for new_class in get_all_subclasses(test_class):
        print(new_class.__name__)
        assert True


# Generated at 2022-06-24 21:01:44.065010
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert 'jessie' == get_distribution_codename()

# Generated at 2022-06-24 21:01:52.817933
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import User
    assert get_platform_subclass(User) is User
    assert get_platform_subclass(User) is User
    # If the distribution is not in the list of supported distributions, it should
    # just return the "base" class.
    assert get_platform_subclass(User) is User
    # If the distribution is in the list and there's a specific subclass for this
    # platform and distro, return that class.
    assert get_platform_subclass(User) is User
    # If the distribution is in the list but there's no specific subclass for this
    # platform, return the general class for the distribution.
    assert get_platform_subclass(User) is User

# Generated at 2022-06-24 21:01:55.774084
# Unit test for function get_distribution
def test_get_distribution():
    s = get_distribution()
    # assert-type-string
    assert isinstance(s, basestring)



# Generated at 2022-06-24 21:01:58.381386
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    expected = 'xenial'
    result = get_distribution_codename()
    assert result == expected

# Generated at 2022-06-24 21:02:07.394293
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class test_class:
        pass
    this_platform = platform.system()
    distribution = get_distribution()
    assert 'test_class' == get_platform_subclass(test_class).__name__
    assert this_platform == get_platform_subclass(test_class).platform
    assert distribution == get_platform_subclass(test_class).distribution
    assert 'test_class' == get_platform_subclass(test_class).__name__


if __name__ == '__main__':
    test_case_0()
    test_get_platform_subclass()

# Generated at 2022-06-24 21:02:28.828974
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Testing if distribution name is returned correctly
    assert get_distribution() == 'Linux'


# Generated at 2022-06-24 21:02:30.341146
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert var_0 is not None


# Generated at 2022-06-24 21:02:31.012605
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:02:34.642894
# Unit test for function get_distribution_version
def test_get_distribution_version():
    pass
    #  if platform.system() == 'Linux':
    #      # FIXME: This should be mocked away
    #      assert get_distribution_version() in ('', '17.2', '1.2.3')
    #  else:
    #      assert get_distribution_version() is None



# Generated at 2022-06-24 21:02:39.029920
# Unit test for function get_distribution
def test_get_distribution():
    # test case 1
    var_0 = get_distribution()
    # test case 2
    var_1 = get_distribution()

    assert var_0 is None and var_1 is None


# Generated at 2022-06-24 21:02:47.061356
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic
    if platform.system() == "Linux":
        assert isinstance(ansible.module_utils.basic.User(), ansible.module_utils.basic.UserLinux)
        assert isinstance(get_platform_subclass(ansible.module_utils.basic.User), ansible.module_utils.basic.UserLinux)
    else:
        assert isinstance(ansible.module_utils.basic.User(), ansible.module_utils.basic.UserBSD)
        assert isinstance(get_platform_subclass(ansible.module_utils.basic.User), ansible.module_utils.basic.UserBSD)

# Generated at 2022-06-24 21:02:55.441745
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    os_release_info = distro.os_release_info()
    codename = os_release_info.get('version_codename')
    #if codename is None:
    #    codename = os_release_info.get('ubuntu_codename')
    #if codename is None and distro.id() == 'ubuntu':
    #    lsb_release_info = distro.lsb_release_info()
    #    codename = lsb_release_info.get('codename')
    #if codename is None:
    #    codename = distro.codename()
    #if codename == u'':
    #    codename = None
    print(codename)


# Generated at 2022-06-24 21:02:58.424401
# Unit test for function get_distribution_version
def test_get_distribution_version():
    version = get_distribution_version()
    if version is None:
        assert platform.system() != 'Linux'
    else:
        assert isinstance(version, str)
        assert len(version) > 0


# Generated at 2022-06-24 21:03:04.343271
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    platform_ = platform.system()
    if platform_ == 'Linux':

        # For now, this is the only case we have.  We may need to add more
        # once we have code that imports more subclasses using the
        # get_platform_subclass function so that we have more tests to actually
        # run.
        codename = get_distribution_codename()
        print("codename:  " + str(codename))

# Generated at 2022-06-24 21:03:08.957958
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # If the source distribution is not implemented, change the value of the variable from None to the target distribution
    var_0 = 'source'

    # If the source distribution version is not implemented, change the value of the variable from None to the target distribution version
    var_1 = None
    var_2 = '1.0'

    # If the source distribution codename is not implemented, change the value of the variable from None to the target distribution codename
    var_3 = None

if __name__ == '__main__':
    from ansible.module_utils.common._utils import Test

    test_case_0()
    test_get_platform_subclass()
    Test()

# Generated at 2022-06-24 21:03:29.528712
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True



# Generated at 2022-06-24 21:03:30.972372
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()


# Generated at 2022-06-24 21:03:38.061259
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic #@UnresolvedImport

    class MyClass(ansible.module_utils.basic.AnsibleModule):
        platform = None
        distribution = None

    class MySubclass(MyClass):
        platform = platform.system()
        distribution = get_distribution()

    obj = get_platform_subclass(MyClass)
    assert issubclass(obj, MySubclass) or obj is MyClass

# Generated at 2022-06-24 21:03:39.381462
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'trusty'


# Generated at 2022-06-24 21:03:41.151031
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import User

    assert User is get_platform_subclass(User)

# Generated at 2022-06-24 21:03:43.842113
# Unit test for function get_distribution
def test_get_distribution():
    assert isinstance(get_distribution(), str)


# Generated at 2022-06-24 21:03:46.968092
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()

# Generated at 2022-06-24 21:03:47.452751
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:03:48.482521
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:03:59.807362
# Unit test for function get_distribution
def test_get_distribution():
    this_platform = platform.system()
    if this_platform == 'Linux':
        try:
            import distro
        except ImportError:
            assert False, "Failed to import distro"
            return

        dist_id = distro.id()
        assert dist_id != '', "No distro id"
        dist_name = distro.name()
        assert dist_name != '', "No distro name"
        dist_version = distro.version()
        assert dist_version != '', "No distro version"
        dist_codename = distro.codename()
        assert dist_codename != '', "No distro codename"

        # we don't actually need a running system to test it.
        assert get_distribution() is not None, "No distribution"
        assert get_distribution() == get

# Generated at 2022-06-24 21:04:19.907210
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None


# Generated at 2022-06-24 21:04:20.420912
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:04:21.783219
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert_equals(get_platform_subclass(), get_platform_subclass())

# Generated at 2022-06-24 21:04:23.239989
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:04:32.042494
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    p_0 = 'Linux'
    p_1 = None
    p_2 = 'Linux'
    p_3 = None
    p_4 = 'Linux'
    p_5 = None
    p_6 = 'Linux'
    p_7 = None
    p_8 = 'Linux'
    p_9 = None
    res = get_platform_subclass(p_0)
    assert res == p_1
    res = get_platform_subclass(p_2)
    assert res == p_3
    res = get_platform_subclass(p_4)
    assert res == p_5
    res = get_platform_subclass(p_6)
    assert res == p_7
    res = get_platform_subclass(p_8)
    assert res == p_9

# Unit test

# Generated at 2022-06-24 21:04:33.703107
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:04:36.348823
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert var_0 is not None, "distribution cannot be None"
    assert isinstance(var_0, six.string_types), "distribution must be a string"
    assert len(var_0) > 0, "distribution cannot be an empty string"

# Generated at 2022-06-24 21:04:39.542535
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    assert AnsibleModule.__name__ == 'AnsibleModule'

    assert isinstance(get_platform_subclass(AnsibleModule), AnsibleModule)

# Generated at 2022-06-24 21:04:49.519183
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest
    class TestClass:
        platform = 'NotWindows'
        distribution = None
    class TestClassAmzn(TestClass):
        distribution = u'Amzn'
    class TestClassWindows(TestClass):
        platform = 'Windows'

    class TestCase(unittest.TestCase):
        def test_basic(self):
            platform_class = get_platform_subclass(TestClass)
            self.assertEqual(platform_class, TestClass)
        def test_amzn(self):
            platform_class = get_platform_subclass(TestClass)
            self.assertEqual(platform_class, TestClass)
        def test_windows(self):
            platform_class = get_platform_subclass(TestClass)
            self.assertEqual(platform_class, TestClass)
    unitt

# Generated at 2022-06-24 21:04:49.907210
# Unit test for function get_distribution
def test_get_distribution():
    assert True

# Generated at 2022-06-24 21:05:30.635169
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print("testing function, get_distribution_codename")

    assert get_distribution_codename() == None


# Generated at 2022-06-24 21:05:34.205133
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()


# Generated at 2022-06-24 21:05:39.294635
# Unit test for function get_distribution_version
def test_get_distribution_version():
    try:
        res = get_distribution_version()
    except Exception as e:
        print(e)
        assert False
    else:
        assert type(res) == str or type(res) == NoneType
test_get_distribution_version()


# Generated at 2022-06-24 21:05:47.578058
# Unit test for function get_distribution
def test_get_distribution():
    fixtures_0 = [
        ('Amazon',),
        ('CentOS',),
        ('Debian',),
        ('Fedora',),
        ('RedHat',),
        ('Ubuntu',),
        ('OtherLinux',)
    ]
    fixtures_1 = [
        ('Amazon', '2018.03'),
        ('CentOS', '7.5.1804'),
        ('Debian', '9.4'),
        ('Fedora', '29'),
        ('RedHat', '6.10'),
        ('Ubuntu', '16.04'),
        ('OtherLinux', '')
    ]

# Generated at 2022-06-24 21:05:51.583686
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule, get_platform_subclass, HAS_LIBUSER

    class ModTest(get_platform_subclass(AnsibleModule)):
        def __init__(self):
            pass

    class DefaultTest(ModTest):
        def __init__(self):
            pass

    test_class = get_platform_subclass(ModTest)
    assert ModTest == DefaultTest



# Generated at 2022-06-24 21:05:59.312413
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.system.distribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution

    assert issubclass(get_platform_subclass(AnsibleModule), AnsibleModule)

    assert issubclass(get_platform_subclass(BaseFactCollector), BaseFactCollector)

    platform = platform.system()
    distribution = get_distribution()

    if platform == 'Linux':
        if distribution == 'Debian':
            assert issubclass(get_platform_subclass(LinuxDistribution), ansible.module_utils.facts.system.distribution.Debian)
        elif distribution == 'RedHat':
            assert iss

# Generated at 2022-06-24 21:06:01.137596
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    variable_0 = get_distribution_codename()
    print(variable_0)


# Generated at 2022-06-24 21:06:09.891055
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()
    var_2 = 'Linux'
    var_3 = var_1 == var_2
    var_4 = get_distribution_version()
    var_5 = '18.04'
    var_6 = var_4 == var_5
    var_7 = get_distribution_codename()
    var_8 = 'bionic'
    var_9 = var_7 == var_8
    var_10 = var_3 and var_6 and var_9
    return var_10


# Generated at 2022-06-24 21:06:14.774206
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass()
