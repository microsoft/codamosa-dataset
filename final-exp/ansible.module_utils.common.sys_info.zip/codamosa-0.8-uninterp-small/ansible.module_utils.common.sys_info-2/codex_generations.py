

# Generated at 2022-06-24 20:56:21.092480
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()

# Generated at 2022-06-24 20:56:22.265302
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'stretch'

# Generated at 2022-06-24 20:56:24.429365
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # test `subclass_dict`
    subclass_dict = {}
    assert get_platform_subclass(subclass_dict) == {}

# Generated at 2022-06-24 20:56:30.643145
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    This function is prototyped to use a generic class as a parameter.
    This is to have work seamlessly with python2 vs python3.
    '''
    from ansible.module_utils.basic import User, UserLinux

    ansible_user = User()
    assert ansible_user.__class__ == UserLinux
    assert issubclass(ansible_user.__class__, User)


# Generated at 2022-06-24 20:56:31.948967
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 20:56:37.405971
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    val_0 = "NotAvailable"
    if get_distribution_codename() != None:
        val_0 = get_distribution_codename()
    assert isinstance(val_0,str)


# Generated at 2022-06-24 20:56:40.011201
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution()
    var_2 = get_distribution_codename()


# Generated at 2022-06-24 20:56:49.788980
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class A:
        platform = 'Linux'
        distribution = 'Redhat'

    class B(A):
        platform = 'Linux'
        distribution = 'Redhat'

    class C(A):
        platform = 'Linux'
        distribution = 'Redhat'

    class D:
        platform = 'Linux'
        distribution = 'Redhat'

    class E(D):
        platform = 'Linux'
        distribution = 'Redhat'

    class F(E):
        platform = 'Linux'
        distribution = 'Redhat'

    def assert_result(expected, cls):
        assert expected is get_platform_subclass(cls)

    assert_result(A, A)
    assert_result(B, A)
    assert_result(C, A)
    assert_result(D, A)
    assert_result

# Generated at 2022-06-24 20:56:53.219768
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_platform

    var_0 = get_platform_subclass(AnsibleModule)
    var_1 = get_platform_subclass(ansible_platform)


# Generated at 2022-06-24 20:56:57.757270
# Unit test for function get_distribution_version
def test_get_distribution_version():
    if platform.system() == 'Linux' and get_distribution_version() == 'Ubuntu':
        return True


# Generated at 2022-06-24 20:57:07.564074
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # setup data
    version = None
    # instance to invoke function
    get_platform_subclass_class_instance = get_platform_subclass(version)
    # invoke function
    get_platform_subclass_class_instance.func_to_test(version)


# Generated at 2022-06-24 20:57:18.046444
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils import distro

    # Return the code name for this Linux Distribution
    # rtype: NativeString or None
    # returns: A string representation of the distribution's codename or None if not a Linux distro

    # Until this gets merged and we update our bundled copy of distro:
    # https://github.com/nir0s/distro/pull/230
    # Fixes Fedora 28+ not having a code name and Ubuntu Xenial Xerus needing to be "xenial"
    os_release_info = distro.os_release_info()
    codename = os_release_info.get('version_codename')

    if codename is None:
        codename = os_release_info.get('ubuntu_codename')


# Generated at 2022-06-24 20:57:19.235121
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()



# Generated at 2022-06-24 20:57:28.141002
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class A:
        platform = None
        distribution = None

    class A_B:
        platform = None
        distribution = 'B'

    class A_B_C:
        platform = 'C'
        distribution = 'B'

    class A_B_C_D:
        platform = 'C'
        distribution = 'D'

    for this_class in (A, A_B, A_B_C, A_B_C_D):
        this_platform = this_class.platform
        this_distribution = this_class.distribution

        rv = get_platform_subclass(this_class)

        assert rv == A_B_C_D



# Generated at 2022-06-24 20:57:32.377946
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()
    assert var_0 is not None
    assert var_0 == 'xenial'
    assert type(var_0) == str

# Generated at 2022-06-24 20:57:33.933041
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None


# Generated at 2022-06-24 20:57:39.570326
# Unit test for function get_distribution
def test_get_distribution():
    # Verify the call to get_distribution() returns the expected value for
    # a variety of platforms.
    assert get_distribution() == 'Darwin'
    assert get_distribution() == 'Freebsd'
    assert get_distribution() == 'Linux'
    assert get_distribution() == 'Openbsd'
    assert get_distribution() == 'Sunos'


# Generated at 2022-06-24 20:57:42.853724
# Unit test for function get_distribution
def test_get_distribution():
    ret = get_distribution()
    assert ret == 'Ubuntu'



# Generated at 2022-06-24 20:57:49.274675
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    assert get_distribution_codename() == 'trusty'
    assert get_distribution_codename() == 'xenial'
    assert get_distribution_codename() == 'bionic'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'buster'
    assert get_distribution_codename() == 'jessie'
    assert get_distribution_codename() == 'stretch'
    assert get_distribution_codename() == 'sid'


# Generated at 2022-06-24 20:57:50.385544
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    var_1 = get_distribution()

# Generated at 2022-06-24 20:57:56.873103
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for function get_distribution
    '''
    pass


# Generated at 2022-06-24 20:57:59.113759
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_1 = get_platform_subclass(None)
    assert var_0 == '7.5'
    assert var_1 == None

# Generated at 2022-06-24 20:58:01.139106
# Unit test for function get_distribution
def test_get_distribution():
    if platform.system() == 'Linux':
        assert get_distribution() == distro.id().capitalize()
    else:
        assert get_distribution() == platform.system()


# Generated at 2022-06-24 20:58:04.654931
# Unit test for function get_distribution
def test_get_distribution():
    assert case0 == "Some result"


# Generated at 2022-06-24 20:58:06.604247
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()
    assert isinstance(var_1, str)


# Generated at 2022-06-24 20:58:07.763882
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution()



# Generated at 2022-06-24 20:58:13.651252
# Unit test for function get_distribution
def test_get_distribution():
    # Check if the function throws exception
    try:
        get_distribution()
    except Exception as e:
        assert False, 'Function threw exception: ' + str(e)

    check_get_distribution_correct()


# Generated at 2022-06-24 20:58:23.695110
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    this_platform = platform.system()
    distribution = get_distribution()
    distribution_version = get_distribution_version()
    distribution_codename = get_distribution_codename()

    # Test Basic
    test_basic = get_platform_subclass('Basic')
    assert test_basic == 'AnsibleModule', 'Test class inheritance'

    # Test AnsibleModule
    test_ansible_module = get_platform_subclass('AnsibleModule')
    assert test_ansible_module == 'AnsibleModule', 'Test class inheritance'

    # Test User
    test_user = get_platform_subclass('User')
    if this_platform == 'Linux':
        assert test_user == 'User', 'Test class inheritance'

# Generated at 2022-06-24 20:58:26.435883
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() in {None, "unknown", "xenial", "jessie", "buster"}


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:58:29.101580
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert type(codename) == type(None) or isinstance(codename, (str, unicode))
    assert codename is None or codename[0].islower()

# Generated at 2022-06-24 20:58:36.048388
# Unit test for function get_distribution
def test_get_distribution():
    assert Platform.platform == platform.system()
    assert Platform.distribution == distro.id().capitalize()
    assert Platform.codename == distro.codename()


# Generated at 2022-06-24 20:58:39.610624
# Unit test for function get_distribution
def test_get_distribution():
    pass

# Generated at 2022-06-24 20:58:48.041448
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import User as basic_user
    from ansible.module_utils.basic import get_platform_subclass as get_platform_subclass_basic
    from ansible.module_utils.basic import get_platform_subclass as get_platform_subclass_basic
    from ansible.module_utils.basic import get_platform_subclass as get_platform_subclass_basic

    var_0 = get_platform_subclass(basic_user)

# Generated at 2022-06-24 20:58:51.014920
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    res = get_distribution()
    assert res == 'OtherLinux'



# Generated at 2022-06-24 20:58:52.929355
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
   res = get_platform_subclass()
   assert str(res) == "Linux"



# Generated at 2022-06-24 20:58:55.038456
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Make sure string or None are returned
    isinstance(get_distribution_codename(), (type(None), str))


# Generated at 2022-06-24 20:58:56.122411
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()



# Generated at 2022-06-24 20:59:03.083891
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible_collections.ansible.community.plugins.modules.system import user as test_cls

    # Verify that the platform-specific subclass for this platform
    # is returned by get_platform_subclass()
    this_platform = distro.id()
    distribution = get_distribution()

    for sc in get_all_subclasses(test_cls):
        if sc.distribution == distribution and sc.platform == this_platform:
            expected = sc

    result = get_platform_subclass(test_cls)
    assert type(result) == type(expected)

# Generated at 2022-06-24 20:59:04.394088
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'



# Generated at 2022-06-24 20:59:06.091436
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()
    assert var_0 == None


# Generated at 2022-06-24 20:59:19.309019
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    if distro.id() == 'rhel':
        assert get_distribution_codename() == 'Maipo'
    elif distro.id() == 'centos':
        assert int(get_distribution_codename()) == 7


# Generated at 2022-06-24 20:59:22.784353
# Unit test for function get_distribution
def test_get_distribution():
    with open('/etc/os-release') as f:
        with mock.patch('ansible.module_utils.distro.open', return_value=f, create=True):
            assert get_distribution() == 'Redhat'


# Generated at 2022-06-24 20:59:26.224268
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    var_01 = distro.version()
    var_02 = get_distribution_version()
    assert var_01 == var_02

# Generated at 2022-06-24 20:59:26.973860
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:59:28.574693
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()
    assert var_1 == 'Linux'


# Generated at 2022-06-24 20:59:34.070757
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common.collections import ImmutableDict

    class SuperClass:
        pass

    class SubClass(SuperClass):
        distribution = 'Fedora'
        platform = 'Linux'

    class SubSubClass(SubClass):
        distribution = 'RedHat'

    class OtherSubClass(SuperClass):
        distribution = 'Darwin'
        platform = 'Darwin'

    class NoSystemClass(SuperClass):
        platform = 'Darwin'
        distribution = 'Darwin'

    class NoPlatformClass(SuperClass):
        distribution = 'Darwin'

    class KWArgPlatformClass(SuperClass):
        platform = 'Darwin'

        def __init__(self, **kwargs):
            super(KWArgPlatformClass, self).__init__()


# Generated at 2022-06-24 20:59:36.967876
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test for function get_distribution_codename
    assert get_distribution_codename() is not None


# Generated at 2022-06-24 20:59:40.048962
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    environ_copy = dict(os.environ)
    os.environ['VERSION_CODENAME'] = 'fooey'
    var_0 = get_distribution_codename()
    os.environ = environ_copy


# Generated at 2022-06-24 20:59:47.044090
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    expected = get_platform_subclass(User, *args, **kwargs)
    actual = get_platform_subclass(User, *args, **kwargs)
    assert expected == actual


# Generated at 2022-06-24 20:59:48.542144
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() # >= 0


# Generated at 2022-06-24 21:00:15.351699
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        pass
    class B(A):
        platform = u'Linux'
    class C(A):
        platform = u'Linux'
        distribution = u'Redhat'
    class D(A):
        platform = u'Linux'
        distribution = u'Redhat'

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == B
    assert get_platform_subclass(C) == C

    # class D is newer, but class B is more specific
    assert get_platform_subclass(D) == B

# Generated at 2022-06-24 21:00:24.977504
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class TestClass:
        platform = None
        distribution = None
        def __new__(cls, args, kwargs):
            return get_platform_subclass(cls)

    class TestClassSubclassLinux(TestClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class TestClassSubclassLinuxSubclassRedhat(TestClassSubclassLinux):
        distribution = 'Redhat'

    class TestClassSubclassLinuxSubclassRedhatSubclass7(TestClassSubclassLinuxSubclassRedhat):
        distribution_version = '7'

    class TestClassSubclassLinuxSubclassRedhatSubclass6(TestClassSubclassLinuxSubclassRedhat):
        distribution_version = '6'

    class TestClassSubclassLinuxSubclassOtherLinux(TestClassSubclassLinux):
        distribution = 'OtherLinux'


# Generated at 2022-06-24 21:00:25.974888
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution = 'Ubuntu'
    distribution_codename = get_distribution_codename()
    assert distribution == distribution_codename


# Generated at 2022-06-24 21:00:27.115326
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert('No return value unit test' == test_case_0())


# Generated at 2022-06-24 21:00:28.299249
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert '2.0' == get_distribution_version()

test_get_distribution_version()

# Generated at 2022-06-24 21:00:29.179253
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 21:00:31.411122
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:00:35.154424
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    for cls in get_all_subclasses(AnsibleModule):
        if cls.platform == platform.system() and cls.distribution == distribution:
            assert(cls == get_platform_subclass(AnsibleModule))
        else:
            assert(cls != get_platform_subclass(AnsibleModule))

# Generated at 2022-06-24 21:00:46.347935
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function `get_platform_subclass`
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_platform_subclass
    import platform

    # Utilities
    def get_test_data():
        """
        Return a list of test data sets.

        For each test data set, return a 3-tuple of
        * The subclass implementation that this test should be looking for
        * The platform name to pass to platform.system()
        * The distribution name to pass to get_distribution()
        """
        basic = AnsibleModule

        class platform_linux_subclass(basic):
            platform = 'Linux'

        class platform_linux_distribution_subclass(platform_linux_subclass):
            distribution = 'Linux'


# Generated at 2022-06-24 21:00:48.761713
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pf_subclass = get_platform_subclass(platform.system())
    assert pf_subclass is not None


# Generated at 2022-06-24 21:01:14.338845
# Unit test for function get_distribution
def test_get_distribution():
    this_platform = platform.system()
    distribution = get_distribution()
    version = get_distribution_version()
    codename = get_distribution_codename()

    print("""This system is running on: {platform} {distribution} {version} {codename}""".format(platform=this_platform, distribution=distribution, version=version, codename=codename))

if __name__ == "__main__":
    test_get_distribution()

# Generated at 2022-06-24 21:01:15.156985
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(None) == None

# Generated at 2022-06-24 21:01:16.146504
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Darwin'



# Generated at 2022-06-24 21:01:19.472999
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:01:26.407609
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts import user  # pylint: disable="import-error"

    this_platform = platform.system()
    distribution = get_distribution()

    cls = get_platform_subclass(user.User)

    assert cls.platform == this_platform

    if distribution is not None:
        assert cls.distribution == distribution
    else:
        assert cls.distribution is None

# Generated at 2022-06-24 21:01:28.189273
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()
    assert var_0 == "bionic"


# Generated at 2022-06-24 21:01:29.464666
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()


# Generated at 2022-06-24 21:01:31.262927
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = None
    expected = True
    result = (codename == None)
    assert result == expected



# Generated at 2022-06-24 21:01:36.960243
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()



# Generated at 2022-06-24 21:01:38.269844
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_1 = get_platform_subclass(subclass)

    assert var_1 == None

# Generated at 2022-06-24 21:02:01.390167
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 21:02:03.338380
# Unit test for function get_distribution
def test_get_distribution():
    # Can't do unit testing as it depends on the platform the code is
    # running on.
    pass



# Generated at 2022-06-24 21:02:11.474187
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        from sys import version_info as var_0
    except ImportError:
        var_0 = None
    class var_1:
        def __init__(self, arg_2): pass
        var_3=('FreeBSD', 'OpenBSD', 'NetBSD', 'Linux', 'SunOS', 'Darwin', 'Windows')
        var_4=getattr(var_0, 'major', None)
        var_5=getattr(var_0, 'minor', None)
    var_6 = import_module(fromlist=['distro', 'platform'])
    var_7 = var_6.distro.id()
    var_8 = var_7.capitalize()
    var_9 = var_6.platform.system()

# Generated at 2022-06-24 21:02:16.284369
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    # Check if function get_distribution_codename returns expected result for
    # dummy value 'dummy_value_0'
    dummy_value_0 = 'dummy_value_0'
    assert isinstance(get_distribution_codename(dummy_value_0), str)


# Generated at 2022-06-24 21:02:20.488221
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    test_cases = [
    ]
    for test_case in test_cases:
        var_0 = test_case[0]
        result = test_case[1]
        assert(test_case[0] == test_case[1])
    return


# Generated at 2022-06-24 21:02:27.036606
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Animal():
        platform = None
        distribution = None

    class Cat(Animal):
        platform = 'Linux'
        distribution = 'Debian'

    class Dog(Animal):
        platform = 'Linux'
        distribution = 'Amazon'

    class Dog1(Dog):
        pass

    class Dog2(Dog):
        platform = 'Darwin'

    class Dog3(Dog):
        distribution = 'Amazon'
        platform = 'Linux'

    class Dog4(Dog):
        distribution = 'Amazon'

    assert get_platform_subclass(Animal) == Animal
    assert get_platform_subclass(Cat) == Cat
    assert get_platform_subclass(Dog) == Dog
    assert get_platform_subclass(Dog1) == Dog1
    assert get_platform_subclass(Dog2) == Dog2
    assert get

# Generated at 2022-06-24 21:02:27.994450
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert callable(get_platform_subclass)

# Generated at 2022-06-24 21:02:31.870319
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Can't write a test that can be run by nosetests and works on all platforms
    # The codename isn't available on all Linux distros and I'm not sure which distros
    # have a codename set.
    #if get_distribution_codename() == 'codename':
    #    assert True
    assert True

# Generated at 2022-06-24 21:02:42.663679
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert distro.name() == 'debian'
    assert distro.id() == 'debian'
    assert distro.version(best=True) == '8'
    assert distro.version() == '8'
    assert distro.codename() == 'jessie'
    assert distro.id_like() == 'debian'
    assert distro.version_like() == '8'
    assert distro.pretty_name() == 'Debian GNU/Linux 8 (jessie)'
    assert distro.major_version() == '8'
    assert distro.minor_version() is None

# Generated at 2022-06-24 21:02:45.383606
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print('Testing get_distribution_codename...')
    assert get_distribution_codename() == "bionic"

# unit test for function get_distribution_codename

# Generated at 2022-06-24 21:03:07.665346
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()
    assert var_1 == 'Linux'
    var_2 = get_distribution()
    assert var_2 == 'Linux'

# Generated at 2022-06-24 21:03:12.334440
# Unit test for function get_distribution
def test_get_distribution():
    print("Test case: ", end="")
    test_case_0()


# Generated at 2022-06-24 21:03:18.977877
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    _ansible_module_name = '__main__'
    print("ABSOLUTE_IMPORT: %s" % __name__)
    print("Loading '%s' from %s" % (get_platform_subclass, __file__))
    print("Loading %s from %s" % (get_distribution, __file__))
    print("Loading %s from %s" % (get_distribution_version, __file__))
    print("Loading %s from %s" % (get_distribution_codename, __file__))
    platform_module = __import__(_ansible_module_name, globals(), locals(), ['get_platform_subclass'], 0)
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-24 21:03:19.556432
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:03:21.174035
# Unit test for function get_distribution
def test_get_distribution():
    # No implementation
    pass



# Generated at 2022-06-24 21:03:25.172757
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:03:26.372079
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:03:33.366492
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    class DistributionFacts:
        def __init__(self):
            self.distribution_version = u''

    class CollectorSubclass(DistributionFactCollector):
        @staticmethod
        def get_facts(module):
            facts_dict = {u'distribution_version': u'10.1'}
            return facts_dict

    new_facts = default_collectors.copy()
    new_facts[u'system'][u'distribution'] = CollectorSubclass

# Generated at 2022-06-24 21:03:39.063586
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_1 = 'Linux'
    var_2 = 'OtherLinux'
    var_3 = 'User'
    from ansible.module_utils.basic import User

    var_4 = get_platform_subclass(User)
    var_4.assertTrue(var_4.isinstance(var_4, User))

# Generated at 2022-06-24 21:03:46.768355
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common._collections_compat import Mapping
    class TestMap(Mapping):
        @property
        def platform(self):
            return None
        @property
        def distribution(self):
            return None
        def __getitem__(self, key):
            return key
        def __iter__(self):
            return iter((1, 2))
        def __len__(self):
            return 1
    test_map = TestMap()
    assert get_platform_subclass(test_map) == test_map

if __name__ == "__main__":
    test_get_platform_subclass()

# Generated at 2022-06-24 21:04:07.714760
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-24 21:04:09.154333
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(get_distribution()) is not None



# Generated at 2022-06-24 21:04:10.759107
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == "OtherLinux"

if __name__ == '__main__':
    pass

# Generated at 2022-06-24 21:04:18.504694
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest
    class TestClass1(object):
        distribution = 'Redhat'
        platform = 'Linux'
    class TestClass2(object):
        distribution = 'CentOS'
        platform = 'Linux'
    class TestClass3(object):
        distribution = 'Amzn'
        platform = 'Linux'
    class TestClass4(object):
        distribution = 'Amazon'
        platform = 'Linux'
    class TestClass5(object):
        distribution = 'LinuxMint'
        platform = 'Linux'
    class TestClass6(object):
        distribution = None
        platform = 'Linux'
    import ansible.modules.system.user
    class TestClass7(ansible.modules.system.user.User):
        distribution = 'Redhat'
        platform = 'Linux'

# Generated at 2022-06-24 21:04:19.191981
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass



# Generated at 2022-06-24 21:04:27.989525
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class param_0:
        distribution = None
        platform = 'Linux'
    class param_1:
        distribution = 'OtherLinux'
        platform = 'Linux'
    class param_2:
        distribution = None
        platform = 'Test'

    var_0 = get_platform_subclass(param_0)
    assert var_0 == param_0, "Expected (%s) to be (%s)" % (var_0, param_0)

    var_1 = get_platform_subclass(param_1)
    assert var_1 == param_1, "Expected (%s) to be (%s)" % (var_1, param_1)

    var_2 = get_platform_subclass(param_2)

# Generated at 2022-06-24 21:04:39.672796
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.modules.system.user as user_mod

    subclasses = []
    for cls in get_all_subclasses(user_mod.User):
        if cls.distribution is not None:
            subclasses.append((cls.distribution, cls.platform, cls.distribution_version))
        else:
            subclasses.append((cls.platform,))

    # This represents the platforms we expect the module to run on.  If platforms
    # are added or removed, the list needs to be updated
    #
    # The first column is the platform we expect, the second is the distribution
    # name, and the third is the distribution version.  If the distribution is
    # unknown, then the second column is empty.

# Generated at 2022-06-24 21:04:45.008745
# Unit test for function get_distribution
def test_get_distribution():
    try:
        assert (get_distribution()) != None
    except AssertionError as e:
        raise(AssertionError(str(e)+' Function get_distribution() does not return value'))
    assert (get_distribution() is not None), 'Function get_distribution() returned None'
    assert (get_distribution() != ""), 'Function get_distribution() returned empty string'

# Generated at 2022-06-24 21:04:46.244953
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestClass:
        platform = None
        distribution = None
    test_class = TestClass()
    assert get_platform_subclass(test_class) == test_class



# Generated at 2022-06-24 21:04:47.625138
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()


# Generated at 2022-06-24 21:05:16.777773
# Unit test for function get_distribution
def test_get_distribution():
    # No exception was thrown
    print("var_0 = get_distribution()")
    var_0 = get_distribution()
    print("unit test for 'get_distribution': get_distribution()")
    print("expecting: %s" % None)
    print("return   : %s" % var_0)
    try:
        assert var_0 == None
    except AssertionError:
        print("unit test for 'get_distribution' FAILED")
    print("unit test for 'get_distribution': get_distribution() passed")
    print("")



# Generated at 2022-06-24 21:05:18.923148
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert callable(get_platform_subclass)


# Tests for various distributions.  This is only for testing.  In ansible the information
# is replaced with the actual distro

# Generated at 2022-06-24 21:05:27.837005
# Unit test for function get_distribution
def test_get_distribution():
    # mock_ubuntu = MagicMock()
    # mock_ubuntu.id.return_value = 'Ubuntu'
    # mock_ubuntu.version.return_value = '14.04'
    #
    # with patch('distro.id', mock_ubuntu.id):
    #     with patch('distro.version', mock_ubuntu.version):
    #         assert get_distribution() == 'Ubuntu'
    #         assert get_distribution_version() == '14.04'

    # assert get_distribution() == 'Ubuntu'
    # assert get_distribution_version() == '14.04'

    assert get_distribution() == 'Ubuntu'



# Generated at 2022-06-24 21:05:28.956604
# Unit test for function get_distribution
def test_get_distribution():
    assert callable(get_distribution)



# Generated at 2022-06-24 21:05:30.215445
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_platform_subclass(False)



# Generated at 2022-06-24 21:05:34.399741
# Unit test for function get_distribution
def test_get_distribution():
    # Test with a correct input
    res = get_distribution()
    if not isinstance(res, (type(None), str)):
        raise ValueError("Invalid return value for function get_distribution")
    # Test with a wrong input
    res = get_distribution(distribution="a")
    if not isinstance(res, (type(None), str)):
        raise ValueError("Invalid return value for function get_distribution")



# Generated at 2022-06-24 21:05:44.748167
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic
    import ansible.module_utils.common.dict_transformations

    # Testing with AnsibleTest
    test_class = ansible.module_utils.basic.AnsibleTest
    test_cls = ansible.module_utils.basic.AnsibleModule

    # Testing with AnsibleModule
    test_class = ansible.module_utils.common.dict_transformations.AnsibleModule
    test_cls = ansible.module_utils.common.dict_transformations.AnsibleModule

    # This is what the AnsibleModule constructor calls
    ansible_module = ansible.module_utils.basic.AnsibleModule(  # noqa
        argument_spec=dict(),
    )

    # True
    assert ansible_module.__class__ == ansible.module_

# Generated at 2022-06-24 21:05:45.807023
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()
    assert True


# Generated at 2022-06-24 21:05:48.003639
# Unit test for function get_distribution_version
def test_get_distribution_version():
    print('Testing get_distribution_version...', end='')

    var_0 = get_distribution_version()
    assert var_0 != u''

    print('ok')


# Generated at 2022-06-24 21:05:48.534529
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass