

# Generated at 2022-06-24 20:56:23.113142
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-24 20:56:25.175339
# Unit test for function get_platform_subclass

# Generated at 2022-06-24 20:56:26.242169
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True



# Generated at 2022-06-24 20:56:28.987614
# Unit test for function get_distribution
def test_get_distribution():
    try:
        var_0 = get_distribution()
        assert var_0 is not None, 'Function get_distribution did not return anything'
    except Exception as e:
        raise AssertionError(e)


# Generated at 2022-06-24 20:56:36.705336
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Dummy class to test
    class Dummy:
        platform = None
        distribution = None

    # Create an instance
    dummy_inst = Dummy()

    # Create a subclass
    class SubDummy(Dummy):
        def __init__(self):
            pass

    # Create another subclass
    class AnotherSubDummy(Dummy):
        def __init__(self):
            pass

    # Create a third subclass with a main class method
    class ThirdClass(Dummy):
        def __init__(self):
            pass

        def this_is_subclass_function(self):
            pass

    # Create a fourth subclass with a main class method and a function
    class DummyPlatform(Dummy):
        def __init__(self):
            pass

        def this_is_subclass_function(self):
            pass

# Generated at 2022-06-24 20:56:40.780158
# Unit test for function get_distribution
def test_get_distribution():
    this_platform = platform.system()
    if this_platform == 'Linux':
        assert test_case_0() == get_distribution()
    else:
        var_1 = get_distribution()



# Generated at 2022-06-24 20:56:50.236184
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print("Testing get_distribution_codename():")

    # These tests are expected to work on any linux distro.  As a result, the
    # distro we're running under isn't as important as the distro we're testing.
    # I'm on a RHEL system at the moment so I'll use that as the test.  In the
    # future, if this function needs more tests, we can expand this to verify
    # more distros.

    # Test RHEL 8
    old_id = distro.id
    old_codename = distro.codename
    old_os_release_info = distro._os_release_info
    old_lsb_release_info = distro._lsb_release_info

# Generated at 2022-06-24 20:56:52.734080
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic
    assert (ansible.module_utils.basic.get_platform_subclass(object) is object)


# Generated at 2022-06-24 20:56:57.652323
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = distro.id().capitalize()

    if var_0 == '':
        var_0 = 'OtherLinux'

    return var_0



# Generated at 2022-06-24 20:56:59.356304
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass(User)

# Generated at 2022-06-24 20:57:15.095970
# Unit test for function get_platform_subclass

# Generated at 2022-06-24 20:57:19.193756
# Unit test for function get_distribution
def test_get_distribution():

    # Run test case 0
    # No exception should be raised
    try:
        test_case_0()
        # If no exception was thrown, this test has passed
        passed = True
    except Exception:
        # An exception was thrown. This test has failed
        passed = False

    assert passed == True




# Generated at 2022-06-24 20:57:25.771517
# Unit test for function get_distribution
def test_get_distribution():
    # Test with no definitive answer
    var1 = 'foo'
    with mock.patch('platform.system', return_value='Linux'):
        with mock.patch.dict(distro._distros, clear=True):
            result1 = get_distribution()
    assert result1 == 'OtherLinux'

    # Test with a bad answer
    var1 = 'foo'
    with mock.patch('platform.system', return_value='Linux'):
        with mock.patch.dict('distro._distros', {'id': 'foo', 'version': 'bar'}):
            result1 = get_distribution()
    assert result1 == 'OtherLinux'

    # Test with an answer
    var1 = 'foo'

# Generated at 2022-06-24 20:57:28.552835
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    expected = "xenial"
    actual = get_distribution_codename()

    assert actual == expected, "Expected {0}, but got {1}".format(expected, actual)


# Generated at 2022-06-24 20:57:33.711223
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    args = []
    if test_get_platform_subclass.__dict__.get('__call__'):
        get_platform_subclass(*args)
    else:
        get_platform_subclass.__call__(*args)


# Generated at 2022-06-24 20:57:35.747326
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # pylint: disable=unused-variable
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:57:36.810070
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == u'16.04'


# Generated at 2022-06-24 20:57:41.303964
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert __name__ == '__main__'
    assert test_case_0() == None

if __name__ == '__main__':
    test_get_platform_subclass()

# Generated at 2022-06-24 20:57:42.590632
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'tara'

# Generated at 2022-06-24 20:57:43.795284
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == u''


# Generated at 2022-06-24 20:58:03.327388
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test for the function get_distribution_codename
    '''

    # The method is tested on various platforms and distribution codenames (if present).
    if platform.system() == 'Linux':
        if get_distribution() == 'Ubuntu' and get_distribution_version() == '14.04':
            assert get_distribution_codename() == 'trusty'
        elif get_distribution() == 'Debian' and get_distribution_version() == '8':
            assert get_distribution_codename() == 'jessie'
        elif get_distribution() == 'Redhat' and get_distribution_version() == '7.5':
            assert get_distribution_codename() == 'Maipo'

# Generated at 2022-06-24 20:58:08.337891
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import UserModule
    expected_subclass = UserModule
    actual_subclass = get_platform_subclass(AnsibleModule)
    assert(expected_subclass == actual_subclass)


# Generated at 2022-06-24 20:58:13.412621
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 20:58:23.876470
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import platform
    # Setup the environment to test different OSes
    thistest_platform = platform.system
    thistest_distro = distro.id
    thistest_release_os = distro.os_release_info
    thistest_release_lsb = distro.lsb_release_info
    platform.system = lambda: 'Linux'
    distro.id = lambda: 'ubuntu'
    distro.os_release_info = lambda: {'version_codename': 'xenial'}
    distro.lsb_release_info = lambda: {'codename': 'Xenial Xerus'}
    # Run the test
    assert get_distribution_codename() == 'xenial'
    # Clear the environment
    platform.system = thistest_platform

# Generated at 2022-06-24 20:58:25.273325
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass
# vim: set et ai ts=4 sw=4 ft=ansible tw=75 :

# Generated at 2022-06-24 20:58:26.066839
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version()

# Generated at 2022-06-24 20:58:33.572024
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    testcase0_mock_get_distribution = 'testcase0_mock_get_distribution'
    class testcase0_mock_platform():
        @classmethod
        def system(cls):
            return testcase0_mock_get_distribution

# Generated at 2022-06-24 20:58:34.659718
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:37.920241
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(str) == str



# Generated at 2022-06-24 20:58:39.227043
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    expected = None
    actual = get_platform_subclass(None)
    assert actual == expected

# Generated at 2022-06-24 20:58:50.013173
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert 1
    return True

# Generated at 2022-06-24 20:58:55.615807
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()

    subclass = None

    # get the most specific superclass for this platform
    if distribution is not None:
        for sc in get_all_subclasses(cls):
            if sc.distribution is not None and sc.distribution == distribution and sc.platform == this_platform:
                subclass = sc
    if subclass is None:
        for sc in get_all_subclasses(cls):
            if sc.platform == this_platform and sc.distribution is None:
                subclass = sc
    if subclass is None:
        subclass = cls

    return subclass

# Generated at 2022-06-24 20:59:00.062509
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 20:59:01.059637
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:59:02.423937
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass('test-var-0')

# Generated at 2022-06-24 20:59:13.041024
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # make a fake class so we can test
    # create a subclass of cls that matches the platform we're running on
    class fake_cls():
        def __init__(self, *args, **kwargs):
            pass
    class fake_cls_win(fake_cls):
        distribution = None
        platform = 'Windows'
    class fake_cls_linux(fake_cls):
        distribution = None
        platform = 'Linux'

    assert get_platform_subclass(fake_cls).platform == platform.system()

    # create a subclass of cls that matches the platform & distribution we're running on
    class fake_cls_win_2k(fake_cls_win):
        distribution = 'Windows 2000'

# Generated at 2022-06-24 20:59:21.918599
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import get_platform_subclass

    class Foo:
        distribution = None
        platform = None
        pass

    class Foo_Default(Foo):
        pass

    class Foo_Linux(Foo):
        platform = "Linux"
        pass

    class Foo_Linux_Other(Foo_Linux):
        pass

    class Foo_Linux_Redhat(Foo_Linux):
        distribution = "Redhat"
        pass

    class Foo_Linux_SuSE(Foo_Linux):
        distribution = "SuSE"
        pass

    class Foo_Darwin(Foo):
        platform = "Darwin"
        pass

    class Foo_Darwin_MountainLion(Foo_Darwin):
        distribution = "MountainLion"
        pass


# Generated at 2022-06-24 20:59:32.173273
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts import DistributionFactCollector
    import ansible.module_utils.facts.system.distribution.freebsd

    # cls requirement
    cls = DistributionFactCollector
    # str requirement
    cls_str = 'DistributionFactCollector'
    # subclass requirement
    cls_subclass = ansible.module_utils.facts.system.distribution.freebsd.DistributionFactCollector
    # subclass name requirement
    cls_subclass_str = 'ansible.module_utils.facts.system.distribution.freebsd.DistributionFactCollector'

    # Test success code path.
    platform_subclass = get_platform_subclass(cls)
    assert platform_subclass.__name__ == cls_subclass.__name__
    assert platform_subclass

# Generated at 2022-06-24 20:59:33.585488
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(None) == None


# Generated at 2022-06-24 20:59:36.854014
# Unit test for function get_distribution
def test_get_distribution():
    try:
        var_0 = get_distribution()
        assert 'distribution' in globals(), 'Variable distribution not defined'
    except Exception as exception:
        print(exception)
        assert False, exception


# Generated at 2022-06-24 20:59:47.205835
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-24 20:59:48.728812
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == distro.id().capitalize()


# Generated at 2022-06-24 20:59:54.253807
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()
    assert var_1 is not None, "Function get_distribution returned an empty answer"
    assert isinstance(var_1, basestring) or var_1 is None, "Function get_distribution returned an invalid answer"



# Generated at 2022-06-24 20:59:54.748704
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:00:05.154291
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
  import os, os.path
  data_dir = os.path.normpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../unit/modules/test_data'))
  sys.path.append(data_dir)
  from linux_get_distribution_subclass_1 import LinuxDistribution  # noqa pylint: disable=wrong-import-position
  obj = get_platform_subclass(LinuxDistribution)
  assert obj.__name__ == 'LinuxDistribution2'
  assert obj.distribution == 'Ubuntu'
  assert obj.platform == 'Linux'

# Generated at 2022-06-24 21:00:05.757709
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:00:06.888421
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert 'Windows' == get_distribution()

# Generated at 2022-06-24 21:00:15.838958
# Unit test for function get_platform_subclass

# Generated at 2022-06-24 21:00:23.620432
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Try to get an instance of the User class that will work on the current
    # platform.  We need to import the User module here to avoid having it
    # imported into the global namespace when the module cache is initialized
    from ansible.modules.system.user import User
    user_class = get_platform_subclass(User)

    # Now try to create a user instance of the proper User class for this platform
    try:
        user = user_class({'name': 'test'})
    except NotImplementedError as e:
        pass


# Generated at 2022-06-24 21:00:30.486468
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic
    # Test the code path when no subclass is found
    assert ansible.module_utils.basic.get_platform_subclass(ansible.module_utils.basic.AnsibleModule) == ansible.module_utils.basic.AnsibleModule
    # Test getting one of the two subclasses defined in ansible.module_utils.basic
    assert ansible.module_utils.basic.get_platform_subclass(ansible.module_utils.basic.ModuleDeprecationWarning) == ansible.module_utils.basic.ModuleDeprecationWarning


# Generated at 2022-06-24 21:00:41.453587
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """Check if the function runs properly"""

    assert get_distribution_version() == u''

# Generated at 2022-06-24 21:00:43.582805
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution()

test_case_0()

# Generated at 2022-06-24 21:00:53.279789
# Unit test for function get_distribution
def test_get_distribution():
    from collections import namedtuple

    _test_version = namedtuple('os_release_info', 'version_codename')
    _test_lsb_release = namedtuple('lsb_release_info', 'codename')

    _test_distro = namedtuple('distro_info', 'id codename lsb_release_info os_release_info version')
    _test_platform = namedtuple('platform_info', 'system')

    # Ubuntu 20.04
    _get_platform = namedtuple('platform_info', 'system')
    _get_distro = namedtuple('distro_info', 'id codename lsb_release_info os_release_info version')
    _get_lsb_release = namedtuple('lsb_release_info', 'codename')
    _get_os_release

# Generated at 2022-06-24 21:01:05.065045
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_platform_subclass

    class Test:
        platform = None
        distribution = None

    class TestLinuxSubclass(Test):
        platform = 'Linux'
        distribution = 'RedHat'

    class TestLinuxSubclass2(Test):
        platform = 'Linux'
        distribution = 'Debian'

    class TestLinuxSubclass3(Test):
        platform = 'Linux'
        distribution = None

    class TestLinuxSubclass4(Test):
        platform = 'Linux'
        distribution = 'RedHat'

    assert get_platform_subclass(Test) == Test
    assert issubclass(get_platform_subclass(TestLinuxSubclass), TestLinuxSubclass)

# Generated at 2022-06-24 21:01:15.448957
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distribution = get_distribution()
    version = get_distribution_version()
    codename = get_distribution_codename()

    # This is not a perfect matcher since some distributions give different and some
    # give more information than others.  For instance CentOS only reports the major
    # version number of the distribution.  We explicitly spell out those exceptions
    # below.

    # TODO: This data is quite spread out.  We should probably keep it all in one
    # place.  However, I'm trying to keep the scope of this patch small so it can
    # be merged quickly.  I haven't found where all this data is stored yet.

    if distribution == 'Centos':
        # CentOS gives only major.minor
        distro_version = '{}.{}'.format(distribution, version)
        distro_codename = None

# Generated at 2022-06-24 21:01:23.281744
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.module_utils.basic import get_platform_subclass

    class TestDict(UserDict):
        pass

    class TestDictRedhat(TestDict):
        platform = 'Linux'
        distribution = 'Redhat'

    class TestDictOther(TestDict):
        platform = 'other'

    assert get_platform_subclass(TestDict) == TestDict

    assert get_platform_subclass(TestDict, required_platform='other') == TestDictOther
    assert get_platform_subclass(TestDict, required_platform='Linux') == TestDict

    assert get_platform_subclass(TestDict, required_distribution='Redhat') == TestDictRedhat

# Generated at 2022-06-24 21:01:24.819524
# Unit test for function get_distribution
def test_get_distribution():
    assert var_0 == "Linux", 'Assertion Error'


# Generated at 2022-06-24 21:01:27.047601
# Unit test for function get_distribution
def test_get_distribution():

    # var_0 = get_distribution()
    # AssertionError: The distribution should not return None
    assert test_case_0()


# Generated at 2022-06-24 21:01:28.461512
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:01:30.084864
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    print("Get distribution: " + str(var_0))


# Generated at 2022-06-24 21:01:50.594402
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:01:51.665222
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()


# Generated at 2022-06-24 21:01:52.868913
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None


# Generated at 2022-06-24 21:01:54.927296
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == "bionic"



# Generated at 2022-06-24 21:02:04.256236
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass()
    var_1 = get_platform_subclass()
    var_2 = get_platform_subclass(var_0)
    var_3 = get_platform_subclass(var_1)

    assert var_0 == var_0
    assert var_0 == var_1
    assert var_0 != var_1
    assert var_2 == var_2
    assert var_2 != var_3



# Generated at 2022-06-24 21:02:06.949735
# Unit test for function get_distribution_version
def test_get_distribution_version():
    print('Testing get_distribution_version()')
    print(get_distribution_version())

if __name__ == '__main__':
    # test_get_distribution_version()
    test_case_0()

# Generated at 2022-06-24 21:02:11.007245
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:02:13.229883
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    ret = get_distribution_codename()


# Generated at 2022-06-24 21:02:16.539445
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()
    assert(var_0 == 'bionic')


# Generated at 2022-06-24 21:02:25.212857
# Unit test for function get_distribution
def test_get_distribution():
    dist = get_distribution()
    assert dist in [
        'Freebsd',
        'Mandrake',
        'Mandriva',
        'Mint',
        'Oracle',
        'Redhat',
        'Suse',
        'Debian',
        'Ubuntu',
        'Amazon',
        'Gentoo',
        'Arch',
        'Pld',
        'Slackware',
        'Fedora',
        'Centos',
        'Oel',
        'Vmwareesx',
        'Debian',
        'Solaris',
        'Alpine',
        'Mageia',
        'Raspbian',
        'Rhel',
        'OtherLinux',
    ], 'Invalid dist: %s' % dist



# Generated at 2022-06-24 21:03:04.561513
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_1 = None
    assert 'Linux' == get_platform_subclass(var_1)


# Generated at 2022-06-24 21:03:06.379093
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '', 'test failed'


# Generated at 2022-06-24 21:03:07.076906
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(None) is None

# Generated at 2022-06-24 21:03:08.815024
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Make sure that get_distribution_codename() returns a string
    '''
    distribution = get_distribution_codename()
    assert type(distribution) is str or distribution is None


# Generated at 2022-06-24 21:03:13.762689
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_distribution()
    print(var_0)

if __name__ == '__main__':
    test_get_platform_subclass()

# Generated at 2022-06-24 21:03:21.909113
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleFallbackNotFound
    try:
        ansible_module = AnsibleModule(
            argument_spec=dict(),
        )
        my_platform = get_platform_subclass(input_data=ansible_module)
    except AnsibleFallbackNotFound:
        assert False, "A distribution was not found, but it should have been."
    else:
        assert True, "Successfully imported the distribution."

    assert ansible_module == my_platform, "Successfully loaded the right subclass."


# Generated at 2022-06-24 21:03:23.106264
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None


# Generated at 2022-06-24 21:03:29.263963
# Unit test for function get_distribution
def test_get_distribution():
    try:
        # function provided by the module under test
        from ansible.module_utils.facts.system.distribution import get_distribution
        import os
        # use a fixed value for the os.name
        os.name = 'posix'
        # call the function
        var_0 = get_distribution()
        assert(var_0 == 'Linux')
    except ImportError as e:
        # if import fails, the module under test is not available -> raise an exception
        raise Exception('Could not import module under test: %s' % e)


# Generated at 2022-06-24 21:03:30.413093
# Unit test for function get_distribution
def test_get_distribution():
    print('Testing function get_distribution')
    test_case_0()


# Generated at 2022-06-24 21:03:32.630178
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Need to get the class for the derrived class
    myobj = get_platform_subclass(get_platform_subclass)



# Generated at 2022-06-24 21:04:11.905063
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:04:15.614741
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()
    assert isinstance(var_1, NativeString)
    assert var_1 == 'Redhat'



# Generated at 2022-06-24 21:04:18.590273
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()



# Generated at 2022-06-24 21:04:19.820836
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == distro.version()


# Generated at 2022-06-24 21:04:28.306217
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # This is a simple example of using a library function,  If you have a
    # library function and you want to see if it works,  you can make a small
    # test case like this.
    #
    # You would write the unit test before you write the code.  Once you
    # have the test writing, run it and check that it fails before you write
    # the code.  Once you have the code written, run the test again and check
    # that it passes.
    this_distribution = get_distribution()
    this_version = get_distribution_version()
    this_codename = get_distribution_codename()

    print('You appear to be running %s %s (%s)' % (this_distribution, this_version, this_codename))

# Generated at 2022-06-24 21:04:29.836117
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None



# Generated at 2022-06-24 21:04:32.015730
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:04:33.662842
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    f = get_distribution_codename()
    print(f)



# Generated at 2022-06-24 21:04:35.705164
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()
    assert isinstance(var_1, str)


# Generated at 2022-06-24 21:04:46.790682
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        from ansible.module_utils.common.os.user import User
    except ImportError:
        raise SkipTest()

    if platform.system() == 'Linux':
        distro_id = get_distribution()
    elif platform.system() == 'FreeBSD':
        distro_id = 'FreeBSD'
    else:
        distro_id = 'NON-LINUX'

    if distro_id == 'FreeBSD':
        assert get_platform_subclass(User).__name__ == 'UserBSD'
    elif distro_id in ['Linux', 'SuSe', 'Redhat', 'Fedora']:
        assert get_platform_subclass(User).__name__ == 'UserLinux'
    elif distro_id == 'NON-LINUX':
        assert get_platform_subclass

# Generated at 2022-06-24 21:06:13.354309
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class _User:
        distribution = None
        platform = None

        def __new__(cls):
            new_cls = get_platform_subclass(_User)
            return super(cls, new_cls).__new__(new_cls)

    class LinuxUser(_User):
        distribution = platform.dist()[0]
        platform = platform.system()

    class DarwinUser(_User):
        platform = 'Darwin'
        distribution = None

    class LinuxDebianUser(LinuxUser):
        distribution = 'Debian'

    assert(isinstance(LinuxUser(), LinuxUser))
    assert(isinstance(DarwinUser(), DarwinUser))
    assert(isinstance(LinuxDebianUser(), LinuxDebianUser))

    assert(isinstance(LinuxDebianUser(), LinuxUser))