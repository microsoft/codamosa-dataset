

# Generated at 2022-06-24 20:56:20.843573
# Unit test for function get_distribution
def test_get_distribution():
    for arg in [None]:
        result = get_distribution(arg)
        assert(result == None)



# Generated at 2022-06-24 20:56:27.306353
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # generate test data
    test_data = [
        ('Linux', None),
        ('Windows', None),
        ('Darwin', None),
        ('FreeBSD', None),
        ('OpenBSD', None),
        ('NetBSD', None),
    ]

    # run test
    for test in test_data:
        platform.system = lambda: test[0]

        distribution_codename = get_distribution_codename()

        assert distribution_codename == test[1], "Expected %s, got %s" % (test[1], distribution_codename)


# Generated at 2022-06-24 20:56:29.908941
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    try:
        assert (get_distribution_codename() == 'stretch')
    except:
        print('Failed test_get_distribution_codename')
        print(get_distribution_codename())


# Generated at 2022-06-24 20:56:34.095791
# Unit test for function get_distribution
def test_get_distribution():
    # Find if the function get_distribution return the right value
    var_0 = get_distribution()
    if var_0 == "Freebsd":
        print("get_distribution returned: " + var_0)
    else:
        print("get_distribution returned: something else")


# Generated at 2022-06-24 20:56:35.663039
# Unit test for function get_distribution
def test_get_distribution():
    expected = 'Redhat'
    actual = get_distribution()
    assert actual == expected


# Generated at 2022-06-24 20:56:46.420625
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test for common case
    print("Testing common case")
    class TestClass(object):
        platform = "common"
        distribution = None
    TestClassSubclass = TestClass
    assert(get_platform_subclass(TestClass) == TestClassSubclass)
    # Test for platform-specific subclass
    print("Testing platform-specific subclass")
    class TestClassPlatform(TestClass):
        platform = platform.system()
    TestClassPlatformSubclass = TestClassPlatform
    assert(get_platform_subclass(TestClass) == TestClassPlatformSubclass)
    # Test for distro-specific subclass
    print("Testing distro-specific subclass")
    class TestClassDistro(TestClass):
        distribution = get_distribution()
    TestClassDistroSubclass = TestClassDistro

# Generated at 2022-06-24 20:56:56.168170
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic

    cls = ansible.module_utils.basic.AnsibleModule
    subclass = get_platform_subclass(cls)
    assert isinstance(subclass, type)
    assert subclass.__module__ == 'ansible.module_utils.basic'
    assert issubclass(subclass, ansible.module_utils.basic.AnsibleModule)
    assert subclass.__name__ == 'AnsibleModule'

    class AnsibleModuleImplementation(ansible.module_utils.basic.AnsibleModule):
        distribution = get_distribution()
        platform = platform.system()

    test_class = AnsibleModuleImplementation
    subclass = get_platform_subclass(test_class)
    assert isinstance(subclass, type)

# Generated at 2022-06-24 20:56:59.048234
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert isinstance(var_0, (str, type(None)))


# Generated at 2022-06-24 20:57:00.806898
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:57:10.474393
# Unit test for function get_distribution
def test_get_distribution():
    this_platform = platform.system()
    this_distro = None
    if this_platform == 'Linux':
        this_distro = platform.dist()[0].capitalize()
    elif this_platform == 'FreeBSD':
        this_distro = 'FreeBSD'
    elif this_platform == 'Darwin':
        this_distro = 'MacOSX'
    elif this_platform == 'SunOS':
        this_distro = 'Solaris'
    elif this_platform.startswith('CYGWIN'):
        this_distro = 'Cygwin'
    elif this_platform.startswith('MSYS'):
        this_distro = 'MSYS'
    else:
        this_distro = None


# Generated at 2022-06-24 20:57:20.820440
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:57:21.315289
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:57:22.355061
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()



# Generated at 2022-06-24 20:57:25.383671
# Unit test for function get_distribution_version
def test_get_distribution_version():
    version = get_distribution_version()

# Generated at 2022-06-24 20:57:36.583363
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    if this_platform == 'Linux':
        distribution = get_distribution()
    else:
        distribution = None


# Generated at 2022-06-24 20:57:40.252700
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    actual = get_distribution_codename()
    expected = None
    assert actual == expected


# Generated at 2022-06-24 20:57:48.946476
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    import os
    import tempfile
    import pytest

    class MyLinux:
        platform = 'Linux'

    class MyLinux_Redhat:
        platform = 'Linux'
        distribution = 'Redhat'

    class MyLinux_Redhat_6:
        platform = 'Linux'
        distribution = 'Redhat'
        version = '6'

    # This test module should run on a Linux-y system
    if platform.system() != 'Linux':
        pytest.skip("Not Linux")

    # If we're on a Redhat system, then we can test that it will pick the most specific
    # Redhat class and that it will pick the right version.
    if distro.id() == "rhel":
        my_subclass = get_platform_subclass(MyLinux)
        assert my_subclass == My

# Generated at 2022-06-24 20:57:50.081331
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(None) is None

# Generated at 2022-06-24 20:57:57.005798
# Unit test for function get_platform_subclass

# Generated at 2022-06-24 20:57:59.508869
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print("Old call: %s" % get_distribution_codename())
    print("New call: %s" % get_distribution_codename())


# Generated at 2022-06-24 20:58:07.815838
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # dummy variable to pass as parameter
    arg_0 = ''
    var_0 = get_distribution_codename(arg_0)


# Generated at 2022-06-24 20:58:12.928583
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:13.632949
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'


# Generated at 2022-06-24 20:58:17.116893
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux', "get_distribution() == 'Linux'"


# Generated at 2022-06-24 20:58:22.367984
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    cls = get_distribution()

    expected_result = ['Amzn', 'Centos', 'Debian', 'Freebsd', 'Macosx', 'Openbsd', 'Redhat', 'Smartos', 'Sunos', 'Windows', 'Ubuntu', 'OtherLinux']
    expected_result = frozenset(expected_result)
    result = get_distribution_version()
    if result not in expected_result:
        raise Exception('Unexpected distribution: {0}'.format(result))


# Generated at 2022-06-24 20:58:25.698786
# Unit test for function get_distribution
def test_get_distribution():
    # test case #0
    test_case_0()
    # test case #1
    var_1 = get_distribution()
    assert var_1 is not None



# Generated at 2022-06-24 20:58:30.622253
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.six import PY3
    if PY3:
        # This test does not run on Python3 because Python3's distro library returns a frozen set
        # and the doctest does not check a frozen sets's contents.
        pass
    else:
        # setup
        var_0 = get_distribution_codename()
        assert var_0 is not None

        # teardown
        pass


# Generated at 2022-06-24 20:58:36.285013
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule, AnsibleModuleError

    class MyBaseClass:
        platform = 'Linux'
        distribution = None

        def __init__(self, module):
            self.module = module

        def run(self):
            return self.module.params['value']

    class MySubclass(MyBaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

        def run(self):
            return u'-'.join([self.module.params['value'], self.distribution])

    value = u'test value'
    module = AnsibleModule({'value': value}, supports_check_mode=True)

# Generated at 2022-06-24 20:58:39.284497
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Global variables
    class_0 = None
    class_1 = None
    class_1 = get_platform_subclass(class_0)


# Generated at 2022-06-24 20:58:49.907871
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import User
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic

    # Test with a class that has no subclasses
    this_platform = platform.system()
    distribution = get_distribution()
    cls = get_platform_subclass(User)
    this_platform = platform.system()
    distribution = get_distribution()
    cls = get_platform_subclass(ansible.module_utils.basic.User)
    this_platform = platform.system()
    distribution = get_distribution()
    cls = get_platform_subclass(ansible.module_utils.basic.User)


# Generated at 2022-06-24 20:59:03.849586
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    expected_result = 'jessie'
    actual_result = get_distribution_codename()
    assert expected_result == actual_result, "Test Failed: test_get_distribution_codename"


# Generated at 2022-06-24 20:59:07.934811
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import User

    u = get_platform_subclass(User)
    if not isinstance(u(), User):
        raise AssertionError()


# skipped for now, until implementation is defined and agreed upon

# Generated at 2022-06-24 20:59:17.257933
# Unit test for function get_distribution
def test_get_distribution():
    this_platform = platform.system()
    distribution = get_distribution()

    assert distribution # Declarative setup of this test requires that this not be None
    if this_platform == 'Linux':
        assert distribution in ('Amazon', 'Centos', 'Debian', 'Fedora', 'Gentoo', 'Redhat', 'Ubuntu', 'OtherLinux')
    elif this_platform == 'FreeBSD':
        assert distribution in ('Freebsd')
    elif this_platform == 'OpenBSD':
        assert distribution in ('Openbsd')
    elif this_platform == 'Darwin':
        assert distribution in ('Darwin')



# Generated at 2022-06-24 20:59:20.005723
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()
    assert var_1 is None


# Generated at 2022-06-24 20:59:30.358165
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    if this_platform == 'Linux':
        from ansible.module_utils.basic import User
        from ansible.module_utils.linux.user import User
        assert User == get_platform_subclass(User)
    if this_platform == 'OpenBSD':
        from ansible.module_utils.basic import User
        from ansible.module_utils.openbsd.user import User
        assert User == get_platform_subclass(User)
    if this_platform == 'FreeBSD':
        from ansible.module_utils.basic import User
        from ansible.module_utils.freebsd.user import User
        assert User == get_platform_subclass(User)
    if this_platform == 'Darwin':
        from ansible.module_utils.basic import User

# Generated at 2022-06-24 20:59:31.733402
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert True


# Generated at 2022-06-24 20:59:32.749167
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass



# Generated at 2022-06-24 20:59:33.337780
# Unit test for function get_distribution
def test_get_distribution():
    pass



# Generated at 2022-06-24 20:59:42.205789
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = "gentoo"
    var_2 = "redhat"
    var_3 = "redhat"
    var_4 = "redhat"
    var_5 = "redhat"
    var_6 = "redhat"
    var_7 = "unknown"
    var_8 = "redhat"
    var_9 = "redhat"
    var_10 = "redhat"
    var_11 = "redhat"
    var_12 = "redhat"
    var_13 = "redhat"
    var_14 = "redhat"
    var_15 = "redhat"
    var_16 = "redhat"
    var_17 = "redhat"
    var_18 = "redhat"
    var_19 = "redhat"
    var_20 = "redhat"


# Generated at 2022-06-24 20:59:51.489576
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test cases
    platform_system_mock = None
    platform_system_mock = 'Linux'
    distribution_mock = None
    distribution_mock = 'Rhel'
    this_platform_mock = None
    this_platform_mock = 'Linux'
    cls_mock = None
    platform_system_mock = None
    platform_system_mock = 'Linux'
    distribution_mock = None
    distribution_mock = 'Rhel'
    this_platform_mock = None
    this_platform_mock = 'Linux'
    cls_mock = None
    platform_system_mock = None
    platform_system_mock = 'Linux'
    distribution_mock = None
    distribution_mock = 'Rhel'
    this_platform_mock = None

# Generated at 2022-06-24 21:00:04.949800
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass('cls')


# Generated at 2022-06-24 21:00:14.418792
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.common.sys_info
    from ansible.module_utils.basic import *

    class BaseClass:
        distribution = None
        platform = platform.system()

    class LinuxSubclass(BaseClass):
        distribution = get_distribution()
        platform = platform.system()

    class OtherLinuxSubclass(BaseClass):
        distribution = 'OtherLinux'
        platform = platform.system()

    class MacSubclass(BaseClass):
        distribution = None
        platform = 'Darwin'

    class WindowsSubclass(BaseClass):
        distribution = None
        platform = 'Windows'

    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(LinuxSubclass) == LinuxSubclass
    assert get_platform_subclass(OtherLinuxSubclass) == LinuxSubclass


# Generated at 2022-06-24 21:00:15.149004
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()



# Generated at 2022-06-24 21:00:20.192195
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    r = get_distribution_codename()
    assert r is not None



# Generated at 2022-06-24 21:00:20.955011
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None

# Generated at 2022-06-24 21:00:27.403121
# Unit test for function get_distribution
def test_get_distribution():

    # unit tests for function get_distribution
    var_0 = get_distribution()  # Unit test for function get_distribution
    import pytest
    from ansible.module_utils.common._utils import get_all_subclasses
    from ansible.module_utils.common.dataloader import DataLoader

    # Test Python 2.7 and 3.6
    assert var_0 == 'Darwin'

    # Test Windows
    os.environ["__ansible_os_family"] = "Windows"
    _test_1 = get_distribution()
    assert _test_1 == 'Windows'

    # Test freebsd
    os.environ["__ansible_os_family"] = "freebsd"
    _test_2 = get_distribution()
    assert _test_2 == 'Freebsd'



# Generated at 2022-06-24 21:00:28.576293
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:00:34.613148
# Unit test for function get_distribution
def test_get_distribution():
    # Get distribution name
    var_1 = get_distribution()
    assert var_1 == 'Linux', "var_1 is not the expected value"



# Generated at 2022-06-24 21:00:46.026024
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_id = get_distribution().lower()
    if distribution_id == 'debian':
        # Debian does not have a code name until later versions and
        #   https://github.com/nir0s/distro/issues/245 says that Xenial is "xenial", not "Xenial Xerus"
        #   As a result, we can't really test this on debian systems and we should just not run this test
        #   We do know that the latest debian distributions do have the code name in /etc/os-release
        #   And that Debian only sets the major and not minor version
        pass
    elif distribution_id == 'fedora':
        codename = get_distribution_codename()
        assert codename is None
    elif distribution_id == 'ubuntu':
        # Ubuntu has a codename
        codename = get_

# Generated at 2022-06-24 21:00:47.630754
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # platform.system() = Linux
    # will return OtherLinux
    assert get_distribution() == 'OtherLinux'

# Generated at 2022-06-24 21:00:59.443413
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:01:02.646293
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import User
    ansible_user = get_platform_subclass(User)()
    assert isinstance(ansible_user, User)

# Generated at 2022-06-24 21:01:06.884809
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Please re-enable after you have implemented this function.
    # assert False, "Test has not been implemented."
    pass

# Generated at 2022-06-24 21:01:09.850107
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible_collections.community.general.plugins.modules.cloud.amazon.aws_lambda_function import LambdaFunction
    assert get_distribution_codename() == 'xenial'


# Generated at 2022-06-24 21:01:17.768147
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    if str(var_0) != str('Linux'):
        var_1 = 1
    var_2 = " Failed - expected value: 'Linux', in function: test_get_distribution()"
    if var_1 == 1:
        raise AssertionError(var_2)


# Generated at 2022-06-24 21:01:19.331631
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() != None



# Generated at 2022-06-24 21:01:23.143316
# Unit test for function get_distribution
def test_get_distribution():
    assert ('get_distribution' in locals() or 'get_distribution' in globals())
    assert (type(get_distribution()) is str or type(get_distribution()) is None)


# Generated at 2022-06-24 21:01:23.894366
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:01:27.571967
# Unit test for function get_distribution
def test_get_distribution():
    pass

# Generated at 2022-06-24 21:01:34.420818
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()

#   Try to distinguish python 2 vs. python 3 class usage
try:
    from future.utils import with_metaclass
    def get_all_subclasses(cls):
        from future.utils import with_metaclass
        return cls.__subclasses__() + [g for s in cls.__subclasses__() for g in get_all_subclasses(s)]
except ImportError:
    def get_all_subclasses(cls):
        return cls.__subclasses__() + [g for s in cls.__subclasses__() for g in get_all_subclasses(s)]


# Generated at 2022-06-24 21:01:50.462730
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 21:01:51.551440
# Unit test for function get_distribution
def test_get_distribution():
    var = get_distribution()
    assert var == 'Redhat'



# Generated at 2022-06-24 21:02:01.610089
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Foo:
        platform = u'Linux'
        distribution = u'Debian'

    class Bar:
        platform = u'Linux'
        distribution = u'OtherLinux'

    class Baz:
        platform = u'Linux'
        distribution = None

    class Quux:
        platform = u'FreeBSD'
        distribution = None

    def mock_get_distribution():
        return u'Debian'
    def mock_get_distribution_version():
        return u''
    def mock_get_distribution_codename():
        return u''
    #
    # Mock out the get* methods to test the cases.  We don't want the unit tests
    # to run on only a single platform so we mock out the API
    #

    # test that we get a subclass where we have a distro
    orig_distro

# Generated at 2022-06-24 21:02:02.610769
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True


# Generated at 2022-06-24 21:02:04.265081
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    d = get_platform_subclass()
    assert callable(d)


# Generated at 2022-06-24 21:02:05.299923
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # No parameters
    assert isinstance(get_platform_subclass(), object)

# Generated at 2022-06-24 21:02:10.737058
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-24 21:02:18.383582
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test that on Redhat 3.10.0-693.11.1.el7.x86_64 the get_platform_subclass function returns 'RedhatUser'
    this_platform = platform.system()
    test_platform = 'Linux'
    assert this_platform == test_platform
    distribution = get_distribution()
    test_distribution = 'Redhat'
    assert distribution == test_distribution
    test_version = get_distribution_version()
    assert test_version == '7.5'


# Generated at 2022-06-24 21:02:26.709368
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_platform_subclass

    class ModuleFail(AnsibleModule):
        platform = 'Linux'
        distribution = None

        def fail_from_any_platform(self):
            self.fail_json(msg="This should fail from any platform", failed=True)

    class ModuleLinuxFailFreeBSD(ModuleFail):
        platform = 'Linux'
        distribution = 'FreeBSD'

        def fail_from_freebsd(self):
            self.fail_from_any_platform()

    class ModuleLinuxFailOtherLinux(ModuleFail):
        platform = 'Linux'
        distribution = 'OtherLinux'

        def fail_from_otherlinux(self):
            self.fail_from_any_platform()


# Generated at 2022-06-24 21:02:33.112403
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import BSDDistribution
    from ansible.module_utils.basic import LinuxDistribution

    var_0 = get_platform_subclass(AnsibleModule)
    var_1 = get_platform_subclass(BSDDistribution)
    var_2 = get_platform_subclass(LinuxDistribution)


if __name__ == '__main__':
    test_case_0()
    test_get_platform_subclass()

# Generated at 2022-06-24 21:02:57.253404
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    print("check platform")
    assert 'Linux' == platform.system(), "Can't test this platform"



# Generated at 2022-06-24 21:02:59.467334
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # set up
    cls = platform.system()
    # exercise the function
    subclass = get_platform_subclass(cls)
    # verify the result
    assert isinstance(subclass, str)

# Generated at 2022-06-24 21:03:02.788797
# Unit test for function get_distribution
def test_get_distribution():
    # Setup
    var_0 = None

    # Testing
    try:
        var_0 = get_distribution()
    except NotImplementedError:
        pass
    finally:
        # Teardown
        pass


# Generated at 2022-06-24 21:03:08.354971
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class test_class:
        platform = 'Linux'
        distribution = None
    class test_class_1:
        platform = 'Linux'
        distribution = 'Redhat'
    class test_class_2:
        platform = 'Linux'
        distribution = 'Fedora'
    assert get_platform_subclass(test_class_1).__name__ == test_class_1.__name__
    assert get_platform_subclass(test_class_2).__name__ == test_class_2.__name__
    assert get_platform_subclass(test_class).__name__ == test_class.__name__

# Generated at 2022-06-24 21:03:13.373718
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert var_0 == "Freebsd"



# Generated at 2022-06-24 21:03:14.796064
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:03:17.091563
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is None
    assert get_distribution_version() is None

# Generated at 2022-06-24 21:03:18.515720
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    ret_value = get_distribution_codename()
    print(ret_value)


# Generated at 2022-06-24 21:03:19.680229
# Unit test for function get_distribution
def test_get_distribution():
    test_case_0()


# Generated at 2022-06-24 21:03:21.346389
# Unit test for function get_distribution
def test_get_distribution():
    assert True == True


# Generated at 2022-06-24 21:03:44.501326
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()


# Generated at 2022-06-24 21:03:47.601428
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        assert False, 'FIXME'
    except AssertionError:
        pass

# Generated at 2022-06-24 21:03:48.644076
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass()


# Generated at 2022-06-24 21:03:59.452183
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    if ":" in var_0:
        var_0 = var_0.split(":")
        var_0 = var_0[0]
        if var_0.lower() in ("redhat","centos","scientific linux","oracle linux"):
            var_0 = "RedHat"
        elif var_0.lower() in ("ubuntu", "debian", "mint"):
            var_0 = "Debian"
    elif var_0.lower().startswith("sles"):
        var_0 = "Suse"
    elif var_0.lower().startswith("opensuse"):
        var_0 = "Suse"
    return var_0




# Generated at 2022-06-24 21:04:00.978852
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    assert isinstance(get_distribution_codename(), (type(None), str))


# Generated at 2022-06-24 21:04:02.870450
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert var_0 == 'Linuxredhat' 


# Generated at 2022-06-24 21:04:07.491935
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # set up
    cls = object
    # perform test
    result = get_platform_subclass(cls)
    assert type(result) is type


# Generated at 2022-06-24 21:04:08.902483
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None


# Generated at 2022-06-24 21:04:17.028750
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()

    subclass = get_platform_subclass()

    # get the most specific superclass for this platform
    if distribution is not None:
        for sc in get_all_subclasses(cls):
            if sc.distribution is not None and sc.distribution == distribution and sc.platform == this_platform:
                subclass = sc
    if subclass is None:
        for sc in get_all_subclasses(cls):
            if sc.platform == this_platform and sc.distribution is None:
                subclass = sc
    if subclass is None:
        subclass = cls

    return subclass


# Generated at 2022-06-24 21:04:20.571668
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # From the test case
    #   Test case 0
    var_0 = get_distribution_codename()
    assert (var_0 == None)



# Generated at 2022-06-24 21:04:52.268858
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import get_platform_subclass
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils.facts.hardware.linux import LinuxHardware
    from ansible.module_utils.facts.hardware.macos import DarwinHardware
    from ansible.module_utils.facts.hardware.bsd import BSDHardware

    # Test Linux
    if not isinstance(get_platform_subclass(Hardware), LinuxHardware):
        raise AssertionError('Test Linux failed')

    # Test MacOS
    if not isinstance(get_platform_subclass(Hardware, platform='Darwin'), DarwinHardware):
        raise AssertionError('Test MacOS failed')

    # Test BSD

# Generated at 2022-06-24 21:04:58.032114
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.module_utils.basic import AnsibleModule

    # This is a simple subclass that doesn't have different functionality
    # from the main class.  It uses this to exist so that tests can test
    # the logic of the function.
    class BasicUserDict(UserDict):
        pass

    # This is a subclass with a different implementation on RedHat
    class RedHatUserDict(UserDict):
        platform = 'Linux'
        distribution = 'Redhat'

    # This is a subclass with a different implementation on RedHat
    class OtherLinuxUserDict(UserDict):
        platform = 'Linux'
        distribution = 'OtherLinux'

    # This is a subclass with a different implementation on FreeBSD

# Generated at 2022-06-24 21:05:05.174694
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # We should get a codename for Ubuntu
    assert get_distribution_codename() is not None
    # We should get a codename for RedHat
    assert get_distribution_codename() is not None

    # We should not get a codename for windows
    assert get_distribution_codename() is None


# Generated at 2022-06-24 21:05:07.671051
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    check_0 = get_distribution_codename()

    print("get_distribution_codename returns: ", check_0)


# Generated at 2022-06-24 21:05:09.119341
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    cls = None
    get_platform_subclass(cls)

# Generated at 2022-06-24 21:05:09.876173
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:05:14.479164
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    #Testing to ensure get_distribution_codename method is working as expected.
    #Also testing that if a distribution is not convertable to a lower case string,
    #get_distribution_codename will return None.
    test_var = get_distribution()
    assert test_var is not None


# Generated at 2022-06-24 21:05:15.058398
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert False

# Generated at 2022-06-24 21:05:20.384124
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert var_0.capitalize() == distro.id().capitalize()


# Generated at 2022-06-24 21:05:30.407049
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    from ansible.module_utils.basic import load_platform_subclass

    class TestMain(object):
        """
        Stub class for testing get_platform_subclass
        """
        platform = 'Linux'
        distribution = 'Debian'

        def __new__(cls, *args, **kwargs):
            # This is needed to simulate the base class behavior.
            new_cls = get_platform_subclass(TestMain)
            return super(TestMain, new_cls).__new__(new_cls)

    class TestDebianSubclass(TestMain):
        """
        Stub class for testing get_platform_subclass
        """
        distribution = 'Debian'

    class TestLinuxSubclass(TestMain):
        """
        Stub class for testing get_platform_subclass
        """

# Generated at 2022-06-24 21:05:55.351471
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True == True



# Generated at 2022-06-24 21:05:57.029714
# Unit test for function get_distribution_version
def test_get_distribution_version():
    expected_result = '6.10'
    result = get_distribution_version()
    assert result == expected_result


# Generated at 2022-06-24 21:05:58.412225
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    args = ['linux', 'linux', None]
    assert get_platform_subclass(*args) == args


# Generated at 2022-06-24 21:05:59.327943
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_1 = get_platform_subclass('User')

# Generated at 2022-06-24 21:06:00.298712
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()

# Generated at 2022-06-24 21:06:01.886769
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None


# Generated at 2022-06-24 21:06:10.693376
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    if platform.system() == 'Linux':
        # Case 1: Ubuntu
        ubuntu_codename = get_distribution_codename()
        assert ubuntu_codename == 'bionic'

        # Case 2: Debian
        debian_codename = get_distribution_codename()
        assert debian_codename == 'buster'

        # Case 3: Fedora
        fedora_codename = get_distribution_codename()
        assert fedora_codename is None


if __name__ == '__main__':
    get_distribution()
    get_distribution_codename()