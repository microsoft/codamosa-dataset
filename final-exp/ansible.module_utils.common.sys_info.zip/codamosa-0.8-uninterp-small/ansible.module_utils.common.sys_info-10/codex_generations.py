

# Generated at 2022-06-24 20:56:25.252607
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class test_class:
        pass

    def test_case_1(cls):
        return get_platform_subclass(cls)

    var_1 = test_case_1(test_class)


# Generated at 2022-06-24 20:56:27.229972
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test for the get_distribution_codename function
    '''
    print(get_distribution_codename())



# Generated at 2022-06-24 20:56:29.078387
# Unit test for function get_distribution
def test_get_distribution():
    print(get_distribution())

# Generated at 2022-06-24 20:56:37.378308
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping

    class Foo:
        distribution = None
        platform = None

        def __init__(self, distribution, platform):
            self.distribution = distribution
            self.platform = platform

        def __eq__(self, other):
            return self.distribution == other.distribution and self.platform == other.platform

        def __repr__(self):
            return to_native(u'Foo({0}, {1})'.format(self.distribution, self.platform))

    class Platform:
        distribution = None
        platform = None

        def __init__(self, *args, **kwargs):
            self.restrict

# Generated at 2022-06-24 20:56:41.542431
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename
    '''
    # Setup
    _var_0 = get_distribution_codename()

    # Check
    assert _var_0



# Generated at 2022-06-24 20:56:42.146548
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:56:42.764131
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:56:46.594315
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass()

    print(var_0)
    print(get_distribution_codename())
    print(get_distribution_version())
    print(get_distribution())


if __name__ == "__main__":
    test_get_platform_subclass()

# Generated at 2022-06-24 20:56:47.791509
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linuxmint'


# Generated at 2022-06-24 20:56:53.520477
# Unit test for function get_distribution_version
def test_get_distribution_version():
    my_distro_version = distro.version()
    my_distro = distro.id().capitalize()

    if my_distro_version is None:
        my_distro_version = u''
    if my_distro == u'Amzn':
        my_distro = u'Amazon'
    if my_distro == u'Rhel':
        my_distro = u'Redhat'
    if my_distro == u'Ubuntu':
        my_distro = u'Debian'
    if my_distro is None:
        my_distro = u'OtherLinux'



# Generated at 2022-06-24 20:57:01.382941
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    obj = get_platform_subclass(obj=AnsibleModule)

# Generated at 2022-06-24 20:57:10.515409
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    cls = test_get_platform_subclass_0()
    assert cls.__name__ == "RedHatUser"
    subclass = get_platform_subclass(cls)
    assert subclass.__name__ == "RHELUser"
    subclass_ = get_platform_subclass(subclass)
    assert subclass_.__name__ == "RHEL6User"
    assert get_platform_subclass(subclass_).__name__ == "RHEL6User"

    cls = test_get_platform_subclass_1()
    assert cls.__name__ == "RedHatUser"
    subclass = get_platform_subclass(cls)
    assert subclass.__name__ == "RHELUser"
    subclass_ = get_platform_subclass(subclass)

# Generated at 2022-06-24 20:57:12.015691
# Unit test for function get_distribution
def test_get_distribution():
    # We should be running this test on Ubuntu 16.04
    assert get_distribution() == u'Ubuntu'


# Generated at 2022-06-24 20:57:12.673057
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert 1 == 1

# Generated at 2022-06-24 20:57:13.885300
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'


# Generated at 2022-06-24 20:57:19.021436
# Unit test for function get_distribution
def test_get_distribution():
    print("Calling get_distribution()")
    var_0 = get_distribution()
    if isinstance(var_0, str):
        print("Success at line number: " + str(inspect.currentframe().f_lineno))
    else:
        print("Failed at line number: " + str(inspect.currentframe().f_lineno))
        sys.exit(1)
        

# Generated at 2022-06-24 20:57:19.819836
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:57:25.594644
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Make a mock class to test if get_platform_subclass works
    class MyClass:
        distribution = 'foobar'
        platform = 'windows'

    # Test that get_platform_subclass returns MyClass
    assert get_platform_subclass(MyClass) == MyClass

# Generated at 2022-06-24 20:57:29.208898
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'stretch'
    assert get_distribution_codename() == 'stretch'
    assert get_distribution_codename() == 'stretch'


# Generated at 2022-06-24 20:57:33.607482
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Return the code name for this Linux Distribution
    assert get_distribution_codename() == None
    assert get_distribution_codename() == "xenial"


# Generated at 2022-06-24 20:57:41.966433
# Unit test for function get_distribution_version
def test_get_distribution_version():
    this_platform = platform.system()

    if this_platform == 'Linux':
        version = get_distribution_version()
        this_platform = platform.system()



# Generated at 2022-06-24 20:57:45.886621
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test for distro's code name for this Linux Distribution
    '''

    codename = get_distribution_codename()

    # Assert that Fedora distribution returns a codename
    assert codename


if __name__ == '__main__':
    import sys
    import pytest

    sys.exit(pytest.main(__file__))

# Generated at 2022-06-24 20:57:48.253965
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:57:49.047271
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass


# Generated at 2022-06-24 20:57:51.055912
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        from ansible.module_utils.basic import User
    except ImportError:
        pass

    assert User is not None
    assert 'User' in str(User)

# Generated at 2022-06-24 20:57:52.170434
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:03.275392
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    for distribution in (None, 'Amzn', 'RedHat', 'OtherLinux'):
        for platform in ('Darwin', 'Linux', 'Windows'):
            for cls in (DistributionA, DistributionB, DistributionA_SubclassB, DistributionB_SubclassB):
                if distribution == 'Amzn' and cls == DistributionA_SubclassB:
                    continue

                # Test the __new__() method worked
                assert get_platform_subclass(cls).__new__() is not None

                attributes = {'platform': platform, 'distribution': distribution}
                expected_class = get_expected_class(attributes, cls)

                # Test as a function
                result = get_platform_subclass(cls, **attributes)
                assert result == expected_class

                # Test as a class method
                result = cls

# Generated at 2022-06-24 20:58:05.796002
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    assert type(get_distribution_codename()) == None

# Generated at 2022-06-24 20:58:15.081854
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # From test/unit/test_utils.py
    this_platform = platform.system()
    distro = get_distribution()

    # we should be able to find the platform class for the module
    for cls in (UserModule, UserModuleLinux, UserModuleLinuxSuse, UserModuleLinuxDebian, UserModuleLinuxRedhat, UserModuleMacOS):
        subclass = get_platform_subclass(cls)
        if this_platform == 'Linux':
            assert subclass == UserModuleLinuxSuse or subclass == UserModuleLinuxDebian or subclass == UserModuleLinuxRedhat or subclass == UserModuleLinux
        elif this_platform == 'Darwin':
            assert subclass == UserModuleMacOS
        else:
            assert subclass == UserModule

    # we should be able to get the most specific class that we can find
    subclass = get_platform_subclass

# Generated at 2022-06-24 20:58:19.743096
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()

# Generated at 2022-06-24 20:58:26.583123
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:33.924776
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Try to get a subclass for a nonexistent class
    try:
        x = get_platform_subclass(None)
    except ValueError as e:
        if e.args[0] != "Class None not found when trying to fetch platform subclass":
            raise ValueError("Expected ValueError exception with message 'Class None not found when trying to fetch platform subclass'")
    else:
        raise ValueError("Expected ValueError exception with message 'Class None not found when trying to fetch platform subclass'")
    # No subclass is returned when no platform is defined
    x = get_platform_subclass(object)

# Generated at 2022-06-24 20:58:41.091515
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible_collections.ansible.builtin.systemd as systemd
    import ansible_collections.ansible.os_family.bsd as bsd
    import ansible_collections.ansible.os_family.freebsd.systemd as freebsd_systemd
    import ansible_collections.ansible.os_family.linux as linux

    if platform.system() == 'Linux':
        assert linux.GenericLinuxSystemdModule is get_platform_subclass(systemd.SystemdModule)
        assert linux.AnsibleModule is get_platform_subclass(linux.GenericLinuxSystemdModule)
        assert linux.AnsibleModule is get_platform_subclass(linux.AnsibleModule)
    elif platform.system() == 'FreeBSD':
        assert freebsd_systemd.GenericFreeBSDModule

# Generated at 2022-06-24 20:58:41.740505
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()

# Generated at 2022-06-24 20:58:47.488624
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.common.os import get_distribution_codename

    distribution, codename = get_distribution_codename()

    assert distribution is not None and codename is not None

# Generated at 2022-06-24 20:58:49.897933
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:51.590672
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # TODO: Create a list of values that satisfy the test constraints
    from ansible.module_utils.basic import AnsibleModule
    var_0 = get_platform_subclass(AnsibleModule)
    pass

# Generated at 2022-06-24 20:58:53.798915
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # assert callable(get_distribution_codename)
    assert get_distribution_codename() is None


# Generated at 2022-06-24 20:58:54.826490
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:58:55.288498
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True == True

# Generated at 2022-06-24 20:59:00.869820
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True

# Generated at 2022-06-24 20:59:03.759389
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule, String
    module = AnsibleModule(argument_spec={'new': String()})
    assert module.params['new'] == 'new'


# Generated at 2022-06-24 20:59:12.689206
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass([])
    var_1 = get_platform_subclass([])
    if var_0 != var_1:
        var_0 = False
    var_0 = get_platform_subclass([])
    if var_0 != var_1:
        var_0 = False
    var_0 = get_platform_subclass([])
    if var_0 != var_1:
        var_0 = False
    var_0 = get_platform_subclass([])
    if var_0 != var_1:
        var_0 = False
    assert var_0 == var_1


# Generated at 2022-06-24 20:59:14.358436
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '1404'


# Generated at 2022-06-24 20:59:16.181490
# Unit test for function get_distribution
def test_get_distribution():
    var_8 = get_distribution()
    assert var_8 == 'OtherLinux'



# Generated at 2022-06-24 20:59:23.694044
# Unit test for function get_platform_subclass

# Generated at 2022-06-24 20:59:33.784459
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common._utils import get_platform_subclass
    from ansible.module_utils.common._utils import get_distribution
    from ansible.module_utils._text import to_bytes
    reload(distro)
    import platform

    orig_system = platform.system
    platform.system = lambda: to_bytes('Linux')
    orig_distro = distro.id
    distro.id = lambda: to_bytes('fedora')

    class Base(object):
        pass

    class Fedora(Base):
        platform = 'Linux'
        distribution = 'fedora'

    subclass = get_platform_subclass(Base)
    assert Fedora is subclass

    distro.id = lambda: to_bytes('rhel')

    class RedHat(Base):
        platform = 'Linux'

# Generated at 2022-06-24 20:59:35.306429
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass(cls)


# Generated at 2022-06-24 20:59:37.181424
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Make sure we return an empty string for non-linux systems
    assert get_distribution_codename() is None


# Generated at 2022-06-24 20:59:38.351128
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-24 20:59:45.310526
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from test_module.test_module_utility import TestModule
    t = get_platform_subclass(TestModule)
    assert t.__name__ == 'TestModule'



# Generated at 2022-06-24 20:59:46.681268
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()


# Generated at 2022-06-24 20:59:47.664109
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    print(var_0)



# Generated at 2022-06-24 20:59:53.824948
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test for function get_distribution_codename
    '''
    assert get_distribution_codename() == 'bionic' or get_distribution_codename() == 'n/a'


# Generated at 2022-06-24 21:00:01.499335
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Run function get_distribution
    func_0 = get_distribution()
    assert func_0

    # Run function get_distribution_version
    func_1 = get_distribution_version()
    assert func_1

    # Run function get_platform_subclass
    func_2 = get_platform_subclass()
    assert func_2

# Generated at 2022-06-24 21:00:02.699113
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass(None)

# Generated at 2022-06-24 21:00:04.809582
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert True


# Generated at 2022-06-24 21:00:07.025161
# Unit test for function get_distribution
def test_get_distribution():
    try:
        print(get_distribution())
    except Exception as e:
        print(e)
        raise


# Generated at 2022-06-24 21:00:08.887966
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None, "Failed to get codename"


# Generated at 2022-06-24 21:00:11.511457
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() != None, "get_distribution: <null>"


# Generated at 2022-06-24 21:00:21.109654
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'jessie'

if __name__ == "__main__":
    print(get_distribution())
    print(get_distribution_codename())
    print(platform.system())

# Generated at 2022-06-24 21:00:26.519744
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic
    # assert get_platform_subclass(basic.AnsibleModule) == 'basic'
    pass

# Generated at 2022-06-24 21:00:26.921030
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True

# Generated at 2022-06-24 21:00:30.257626
# Unit test for function get_distribution
def test_get_distribution():
    # Run unit test for function get_distribution
    test_cases = [
        # Test Case 0
        "",
    ]

    for case in test_cases:
        assert test_case_0() == case, "Test Case 0 Failed!"

# Generated at 2022-06-24 21:00:40.988176
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule, load_platform_subclass
    from ansible.module_utils._text import to_str
    class MyClass():
        platform = None
        distribution = None
    test_cases = [
        (MyClass, None),
        (MyClass, 'linux'),
        (MyClass, 'linux', 'centos'),
        (MyClass, 'linux', 'centos', '7.5'),
    ]
    for platform, distribution, distro_version, codename in test_cases:
        # 1. Ensure MyClass.get_distribution() can be called
        var_0 = MyClass.get_distribution()
        # 2. Ensure MyClass.get_platform() can be called
        var_1 = MyClass.get_platform()
        # 3. Ensure MyClass.get

# Generated at 2022-06-24 21:00:42.402775
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass()

# Generated at 2022-06-24 21:00:45.850777
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import datetime
    var_0 = get_platform_subclass(datetime.date)

# Generated at 2022-06-24 21:00:47.078311
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()


# Generated at 2022-06-24 21:00:50.593175
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assertion_status = False
    #  make sure the codename returns an empty string on a non-linux platform
    assertion_status = (get_distribution_codename() == None)
    return assertion_status


# Generated at 2022-06-24 21:00:52.009599
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:01:11.813828
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    class AnsibleModuleTesting(AnsibleModule):
        platform = 'linux'
        distribution = None

        def __init__(self, *args, **kwargs):
            if distribution == 'RedHat':
                distribution = 'RedHat'
            else:
                distribution = None

        def exit_json(self, *args, **kwargs):
            return

        def fail_json(self, *args, **kwargs):
            return

    loaded_platform = get_platform_subclass(AnsibleModuleTesting)

    assert loaded_platform == AnsibleModuleTesting

# Generated at 2022-06-24 21:01:22.203198
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.basic import AnsibleModule
    import copy

    class FakeModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(FakeModule, self).__init__(*args, **kwargs)
            self.params = {
                'name': 'foo',
                'state': 'present',
                'password': None,
                'groups': 'wheel',
                'home': '/home/foo',
                'shell': '/bin/bash',
                'uid': None,
                'update_password': 'always',
                'seuser': None,
                'login_class': None,
                'move_home': False,
            }


# Generated at 2022-06-24 21:01:23.939880
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename()


# Generated at 2022-06-24 21:01:29.860965
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Stub for get_distribution_version
    if platform.system() == 'Linux':
        assert get_distribution_version() is not None
    else:
        assert get_distribution_version() is None


# Generated at 2022-06-24 21:01:30.971747
# Unit test for function get_distribution_version
def test_get_distribution_version():
  assert(get_distribution_version() != "")

# Generated at 2022-06-24 21:01:35.186063
# Unit test for function get_distribution_version
def test_get_distribution_version():

    # set up test data
    var_0 = get_distribution_version()
    var_1 = get_distribution_version()

    # perform test steps
    var_2 = get_distribution_version()

    var_3 = get_distribution_version()
    var_4 = get_distribution_version()
    var_5 = get_distribution_version()
    var_6 = get_distribution_version()

# Generated at 2022-06-24 21:01:37.513003
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert var_0 is not None


# Generated at 2022-06-24 21:01:39.025552
# Unit test for function get_distribution
def test_get_distribution():
    var = get_distribution()
    assert var is None or isinstance(var, (str)),\
        "get_distribution() return value is not an instance of (str)"


# Generated at 2022-06-24 21:01:41.528199
# Unit test for function get_distribution
def test_get_distribution():
    assert(get_distribution() is not None)


# Generated at 2022-06-24 21:01:45.575364
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class cls:
        pass

    class sc:
        pass

    var_13 = cls.distribution = None

    var_14 = cls.platform = None

    var_15 = sc.distribution = None

    var_16 = sc.platform = None

    import platform

    var_1 = platform.system()

    from ansible.module_utils import distro

    var_2 = distro.id()

    if var_1 == "Linux":
        if not var_13:
            var_8 = get_all_subclasses(cls)

            for var_9 in var_8:
                if var_9.platform == var_1 and not var_9.distribution:
                    var_3 = var_9
                    break

            else:
                var_3 = cls

    else:
        var_

# Generated at 2022-06-24 21:02:14.891012
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import load_platform_subclass

    class FirstClass(basic.AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(FirstClass, self).__init__(*args, **kwargs)

    class SecondClass(FirstClass):
        def __init__(self, *args, **kwargs):
            super(SecondClass, self).__init__(*args, **kwargs)

    class ThirdClass(FirstClass):
        platform = 'Linux'

        def __init__(self, *args, **kwargs):
            super(ThirdClass, self).__init__(*args, **kwargs)


# Generated at 2022-06-24 21:02:23.146396
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import get_platform_subclass as gp
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors

    class MyModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(MyModule, self).__init__(*args, **kwargs)
            # gather facts
            self.facts = {}
            for fact in default_collectors:
                self.facts.update(fact.get_facts(self))
            if self.facts.get('distribution_file_parsers'):
                del self.facts['distribution_file_parsers']
            # get platform specific subclass
            self.platform_class = gp(MyModule)

    m = MyModule()

# Generated at 2022-06-24 21:02:32.969973
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test with mock based inputs
    var_1 = get_distribution_version()
    # Test with scalar inputs
    var_2 = get_distribution_version()
    # Test with scalar inputs
    var_3 = get_distribution_version()
    # Test with scalar inputs
    var_4 = get_distribution_version()
    # Test with scalar inputs
    var_5 = get_distribution_version()
    # Test with scalar inputs
    var_6 = get_distribution_version()
    # Test with scalar inputs
    var_7 = get_distribution_version()
    # Test with scalar inputs
    var_8 = get_distribution_version()
    # Test with scalar inputs
    var_9 = get_distribution_version()
    # Test with scalar inputs
    var

# Generated at 2022-06-24 21:02:38.324650
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

if __name__ == '__main__':
    # unit test of get_distribution
    if test_case_0():
        print("Test Case 0 succeeds.")
    else:
        print("Test Case 0 fails.")
    # unit test of get_platform_subclass
    test_get_platform_subclass()

# Generated at 2022-06-24 21:02:39.293659
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass
    assert get_platform_subclass() == ''

# Generated at 2022-06-24 21:02:40.538508
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(int) == int



# Generated at 2022-06-24 21:02:41.398579
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-24 21:02:46.485653
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import User

    # Test with a class that is *not* a subclass of the User class
    try:
        get_platform_subclass("fake_module")
    except TypeError as e:
        pass
    else:
        raise
    # Test with a class that is a subclass of the User class
    assert get_platform_subclass(User)

# Generated at 2022-06-24 21:02:48.047577
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_2 = get_distribution_version()


# Generated at 2022-06-24 21:02:51.186725
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic
    cls = ansible.module_utils.basic.AnsibleModule
    assert get_platform_subclass(cls).__name__ == cls.__name__

# Generated at 2022-06-24 21:03:14.636145
# Unit test for function get_distribution
def test_get_distribution():
    try:
        assert test_case_0()
    except:
        try:
            assert test_case_0()
        except:
            print("FAILED: test_case_0()")
            assert False



# Generated at 2022-06-24 21:03:24.876796
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    expected_codename_dict = dict(
        centos='z',
        debian='stretch',
        fedora='',
        rhel='',
        suse='Leap',
        ubuntu='xenial',
        amazon='',
        opensuseleap='Leap',
        ubuntubionic='bionic',
    )
    for distro_name in expected_codename_dict:
        distro.id = lambda: distro_name
        # For distro that does not have codename, distro.codename() will
        # return '' which could be mistaken for None. Ensure that
        # get_distribution_codename returns None.

# Generated at 2022-06-24 21:03:29.869265
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print("Testing get_distribution_codename():\n")

    # Test that a linux distribution returns the correct codename
    print("Checking for correct codename of a linux distribution:")
    var_0 = get_distribution_codename()
    assert(var_0 == "xenial")

    print("Passed assert that get_distribution_codename() is 'xenial'")
    print("Passed get_distribution_codename()\n")


# Generated at 2022-06-24 21:03:30.933542
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    pass



# Generated at 2022-06-24 21:03:32.243095
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:03:32.800292
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass # TODO

# Generated at 2022-06-24 21:03:33.717533
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(object) == object

# Generated at 2022-06-24 21:03:39.429567
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        # additional import required
        from ansible.module_utils.basic import AnsibleModule
        class TestModule(AnsibleModule):
            pass
        # currently assertion is not working as expected
        assert get_platform_subclass(TestModule) == AnsibleModule
    except ImportError:
        pass

# Generated at 2022-06-24 21:03:40.034659
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    test_case_0()

# Generated at 2022-06-24 21:03:44.829736
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts import User as facts_user

    test = User()

    # this platform does not have a subclass for User
    assert test.__class__ == get_platform_subclass(User)

    # this platform does have a subclass for User
    assert facts_user.__class__ == get_platform_subclass(facts_user)

# Generated at 2022-06-24 21:04:14.653254
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_distribution()
    print('get_distribution: ' + str(var_0))

    var_1 = get_distribution_version()
    print('get_distribution_version: ' + str(var_1))

    var_2 = get_distribution_codename()
    print('get_distribution_codename: ' + str(var_2))

    var_3 = get_platform_subclass(None)
    print('get_platform_subclass: ' + str(var_3))


if __name__ == '__main__':
    test_get_platform_subclass()
    print('Success')


# Generated at 2022-06-24 21:04:21.287804
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import sys

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    import ansible.module_utils.common.platform

    #class TestModuleUtilsCommonPlatform(unittest.TestCase):
    #    def test_get_platform_subclass(self):
    #        pass

    #if __name__ == '__main__':
    #    print(__name__, __file__)
    #    if len(sys.argv) > 1 and sys.argv[1].startswith('-'):
    #        # unittest.main()
    #        pass
    #    else:
    #        test_get_platform_subclass()
    #        test_case_0()

    test_get_platform_subclass()
    test_case_

# Generated at 2022-06-24 21:04:22.763902
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is not None


# Generated at 2022-06-24 21:04:23.392548
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True



# Generated at 2022-06-24 21:04:26.045146
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'



if __name__ == '__main__':
    res = get_distribution_codename()
    print(res)

# Generated at 2022-06-24 21:04:27.208611
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:04:28.275974
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass



# Generated at 2022-06-24 21:04:33.183522
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    get_distribution_codename
    '''
    #########################
    # Test 0
    #########################
    var_0 = get_distribution_codename()
    print(var_0)
    assert var_0 == None


# Generated at 2022-06-24 21:04:36.416502
# Unit test for function get_distribution
def test_get_distribution():
    # Input parameters
    # Output paramaters
    # Expected result
    assert get_distribution() == 'Debian'


# Generated at 2022-06-24 21:04:37.954939
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:05:29.438027
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts.system import Distribution

    assert Distribution == get_platform_subclass(Distribution)
    assert Distribution == get_platform_subclass(Distribution)

    assert Distribution.Linux == get_platform_subclass(Distribution.Linux)
    assert Distribution.Linux == get_platform_subclass(Distribution.Linux)

    assert Distribution.Linux.Debian == get_platform_subclass(Distribution.Linux.Debian)
    assert Distribution.Linux.Debian == get_platform_subclass(Distribution.Linux.Debian)

    assert Distribution.Linux == get_platform_subclass(Distribution.Linux.Debian)
    assert Distribution.Linux == get_platform_subclass(Distribution.Linux.Debian)

    assert Distribution == get_platform_subclass(Distribution.Linux.Debian)

# Generated at 2022-06-24 21:05:34.126000
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None


# Generated at 2022-06-24 21:05:36.037345
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:05:43.412262
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()
    assert var_0 is not None, "Function get_distribution_codename should have returned an instance that is not None"
    #assert var_0 == "expected output", "Function get_distribution_codename returned {0} instead of {1}".format(var_0, "expected output")


# Generated at 2022-06-24 21:05:44.613654
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass
    # assert get_platform_subclass() == "Expected result"

# Generated at 2022-06-24 21:05:45.645331
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:05:46.546275
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:05:48.748343
# Unit test for function get_distribution
def test_get_distribution():
    try:
        print(get_distribution())
    except Exception as e:
        print('Caught exception in get_distribution: ', e)
        raise AssertionError()


# Generated at 2022-06-24 21:05:50.039738
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # assert not isinstance(get_platform_subclass(arg_0), arg_1)
    pass

# Generated at 2022-06-24 21:05:51.025814
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()
