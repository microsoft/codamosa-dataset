

# Generated at 2022-06-24 20:56:21.815011
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-24 20:56:22.665346
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()



# Generated at 2022-06-24 20:56:25.441760
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    pass

# Generated at 2022-06-24 20:56:27.964207
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    rv = get_distribution_codename()

    assert isinstance(rv, str)

    rv = get_distribution_codename()

    assert isinstance(rv, str)



# Generated at 2022-06-24 20:56:29.701162
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print('Test get_distribution_codename')
    assert get_distribution_codename() == 'xenial'
    return



# Generated at 2022-06-24 20:56:36.507267
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class test_fixture_0(object):
        distribution = None
        platform = u'Linux'

        def __init__(self, *args, **kwargs):
            pass

    class test_fixture_1(test_fixture_0):
        distribution = u'OtherLinux'

        def __init__(self, *args, **kwargs):
            super(test_fixture_1, self).__init__(*args, **kwargs)

    class test_fixture_2(test_fixture_0):
        distribution = u'Amazon'
        platform = u'Linux'

        def __init__(self, *args, **kwargs):
            super(test_fixture_2, self).__init__(*args, **kwargs)


# Generated at 2022-06-24 20:56:37.639895
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert False # TODO: implement your test here

# Generated at 2022-06-24 20:56:39.849434
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == "jessie"

# Generated at 2022-06-24 20:56:42.380377
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()
    assert var_0 != None and len(var_0) >= 0

# Generated at 2022-06-24 20:56:48.850123
# Unit test for function get_distribution
def test_get_distribution():
    try:
        os_name = platform.system().lower()
        if os_name == 'linux':
            assert get_distribution() == 'Linux'
        elif os_name == 'darwin':
            assert get_distribution() == 'Darwin'
        elif os_name == 'windows':
            assert get_distribution() == 'Windows'
        else:
            assert get_distribution() == 'Other'
    except AttributeError:
        # special case for embedded platforms
        assert get_distribution() == 'Other'



# Generated at 2022-06-24 20:56:58.493120
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None


# Generated at 2022-06-24 20:56:59.165294
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert 1 == 1

# Generated at 2022-06-24 20:57:00.899356
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_3 = get_distribution_codename()


# Generated at 2022-06-24 20:57:06.343739
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None, "'get_distribution_codename' failed"


# Generated at 2022-06-24 20:57:08.038442
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()
    assert var_1 == 'bionic'

# Generated at 2022-06-24 20:57:10.325683
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'OTHERLINUX'


# Generated at 2022-06-24 20:57:19.330868
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils._text import to_native
    except ImportError:
        # skip those test if we are in py3
        return

    class SubclassLinux(AnsibleModule):
        distribution = None
        platform = u'Linux'
    class SubclassRHEL(AnsibleModule):
        distribution = u'RedHat'
        platform = u'Linux'
    class SubclassDebian(AnsibleModule):
        distribution = u'Debian'
        platform = u'Linux'
    class SubclassOtherLinux(AnsibleModule):
        distribution = None
        platform = u'Linux'

    class BaseModule(AnsibleModule):
        platform = u'All'
        distribution = None


# Generated at 2022-06-24 20:57:20.151768
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True


# Generated at 2022-06-24 20:57:26.346612
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # get_platform_subclass(cls)
    import os
    import tempfile
    import shutil
    dirpath = tempfile.mkdtemp()

# Generated at 2022-06-24 20:57:26.998746
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True

# Generated at 2022-06-24 20:57:45.472632
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert (var_0 == 'Redhat' or var_0 == 'Ubuntu' or var_0 == 'OtherLinux' or var_0 == 'SuSE' or var_0 == 'Darwin' or var_0 == 'Freebsd' or var_0 == 'Windows' or var_0 == 'Openbsd' or var_0 == 'AIX' or var_0 == 'Amazon' or var_0 == 'Netbsd' or var_0 == 'Sunos')


# Generated at 2022-06-24 20:57:48.830499
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert 0
    # TODO test this function


# Generated at 2022-06-24 20:57:51.909297
# Unit test for function get_distribution_version
def test_get_distribution_version():
    this_platform = platform.system()
    distribution = get_distribution()

    if this_platform == 'Linux' and distribution == 'Ubuntu':
        xversion = distro.version()
        yversion = get_distribution_version()
        assert xversion == yversion


# Generated at 2022-06-24 20:57:56.017741
# Unit test for function get_distribution
def test_get_distribution():
    try:
        assert test_case_0() == 'Redhat'
    except AssertionError as ae:
        raise AssertionError(ae.message)


# Generated at 2022-06-24 20:57:56.883670
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:57:57.390707
# Unit test for function get_distribution_version

# Generated at 2022-06-24 20:57:58.974854
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:00.030945
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:58:13.411688
# Unit test for function get_distribution_version
def test_get_distribution_version():
    result = get_distribution_version()
    assert result == '4.4.0' or result == '4.4.0-124' or result == '4.4.0-124-generic' or result == '4.4.0-124.148' or result == '4.4.0-124.148-generic' or result == '4.4.0-124-virtual' or result == '4.4.0-147' or result == '4.4.0-147-generic' or result == '4.4.0-147-generic' or result == '4.4.0-147-lowlatency' or result == '4.4.0-147-lowlatency' or result == '4.4.0-147-lowlatency' or result == '4.4.0-147-lowlatency'

# Generated at 2022-06-24 20:58:21.812401
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Error should be raised when no argument is given
    boolean, msg = False, None
    try:
        get_platform_subclass()
    except TypeError as e:
        boolean, msg = True, "TypeError: get_platform_subclass() takes exactly 1 argument (0 given)"
    assert boolean and msg

    # Check for proper subclass
    if get_distribution() == "Linux":
        assert get_platform_subclass('Linux') == platform.linux_distribution()

    # Check for proper subclass
    if platform.system() == 'Darwin':
        assert get_platform_subclass('Darwin') == platform.mac_ver()

# Generated at 2022-06-24 20:58:46.418851
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:58:47.901685
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Must be run as root to get accurate results
    assert get_distribution_version() == distro.version()

# Generated at 2022-06-24 20:58:50.532407
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()
    assert var_0 == "18.04"


# Generated at 2022-06-24 20:58:53.885800
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import User

    class TestUserRedhat(User):
        platform = 'Linux'
        distribution = 'Redhat'

    assert TestUserRedhat == get_platform_subclass(User)



# Generated at 2022-06-24 20:58:56.932169
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    this_platform = platform.system()
    distribution = get_distribution()
    assert distribution

    codename = get_distribution_codename()
    if this_platform == 'Linux':
        assert codename

# Generated at 2022-06-24 20:58:58.175939
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == None


# Generated at 2022-06-24 20:58:59.398518
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'


# Generated at 2022-06-24 20:59:00.653625
# Unit test for function get_distribution
def test_get_distribution():
    print('Test: get_distribution')


# Generated at 2022-06-24 20:59:01.202884
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True == True

# Generated at 2022-06-24 20:59:12.248791
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test only works entirely on Linux
    if platform.system() != 'Linux':
        return

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert module.__class__ == AnsibleModule

    subclass = get_platform_subclass(AnsibleModule)

    assert subclass is not None

    assert subclass is not AnsibleModule

    assert subclass.__class__ == type

    assert issubclass(subclass, AnsibleModule)

    # platform_subclass_loader_test.py's __init__.py has:
    #
    #    from ansible.module_utils.basic import AnsibleModule
    #
    #    class AnsibleModuleTest(AnsibleModule):
    #        def __init__(self, *args, **kwargs):
    #           

# Generated at 2022-06-24 20:59:36.688461
# Unit test for function get_distribution
def test_get_distribution():
    dist = get_distribution()
    assert dist is not None


# Generated at 2022-06-24 20:59:38.841411
# Unit test for function get_distribution
def test_get_distribution():

    # Exercise function
    result = get_distribution()

    # Ensure that exceptions raised in the remainder of this function
    # are not misconstrued as expected exceptions
    assert True



# Generated at 2022-06-24 20:59:46.016449
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Replace function default args with mock objects
    import BaseHTTPServer
    class MockRequestHandler(object):
        def __init__(self):
            self.headers = {}
        def send_response(self, *args, **kwargs):
            return None
        def end_headers(self, *args, **kwargs):
            return None
        def log_message(self, *args, **kwargs):
            return None
        def send_header(self, *args, **kwargs):
            return None
        def wfile(self, *args, **kwargs):
            return None
    from ansible.module_utils.six.moves.urllib.request import build_opener
    from ansible.module_utils.six.moves.urllib.request import Request

# Generated at 2022-06-24 20:59:50.342744
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    if var_0 != 'Linux':
        print("FAILED: Expected value 'Linux' got {0}".format(var_0))


# Generated at 2022-06-24 20:59:51.330798
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None



# Generated at 2022-06-24 20:59:52.964172
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:59:57.390430
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Code to test get_platform_subclass
    from ansible.module_utils.basic import AnsibleModule

    # Test with a class that is identical across all platforms
    class BasicTest:

        def __init__(self, test_arg=None):
            self.test_arg = test_arg

    for arg in ('foo', 'bar'):
        assert issubclass(get_platform_subclass(BasicTest), BasicTest)
        assert BasicTest(arg) == BasicTest(arg)

    # Test with a class that has different implementations on different platforms
    class TestUbuntu:
        distribution = 'Ubuntu'
        platform = 'Linux'

        @staticmethod
        def true():
            return True

    class TestRedhat:
        distribution = 'Redhat'
        platform = 'Linux'


# Generated at 2022-06-24 20:59:59.327228
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()


# Generated at 2022-06-24 21:00:01.508878
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
        correct_codename = "xenial"
        test_codename = get_distribution_codename()

        assert test_codename == correct_codename

# Generated at 2022-06-24 21:00:12.549581
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test :meth:`get_platform_subclass`
    '''
    # Verify we import from ansible.module_utils.basic
    from ansible.module_utils.basic import get_platform_subclass

    # Create a base class to use for testing
    class Test:
        '''
        Base class for testing get_platform_subclass
        '''
        distribution = None
        platform = None

    # Create subclasses to use for testing
    class TestLinux(Test):
        '''
        Linux subclass
        '''
        distribution = None
        platform = 'Linux'

    class TestLinuxRedhat(Test):
        '''
        Redhat subclass
        '''
        distribution = 'Redhat'
        platform = 'Linux'


# Generated at 2022-06-24 21:01:00.442079
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:01:02.212820
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True, "Function test_get_platform_subclass not implemented"


# TESTS
# =====


# Generated at 2022-06-24 21:01:13.467179
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    s = '''
    class Subclass:
        def __init__(self, *args, **kwargs):
            super(Subclass, self).__init__(*args, **kwargs)
            self.distribution = '10.11'

    class Superclass:
        def __init__(self, *args, **kwargs):
            super(Superclass, self).__init__(*args, **kwargs)
            self.distribution = '10.11'
            self.platform = 'darwin'

    subclass = Subclass()
    superclass = Superclass()
    assert subclass == get_platform_subclass(superclass)
    '''

    code = compile(s, '<string>', 'exec')
    exec(code)

# Generated at 2022-06-24 21:01:20.008303
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    f = open("test_file", "r")
    f.readline()
    f.readline()
    f.close()
    distribution_codename = get_distribution_codename()
    if distribution_codename == "xenial": # This should be true if the unit test was run on Ubuntu 16.04
        pass # Pass if this is True
    else:
        return False # Fail if distribution_codename does not equal xenial


# Generated at 2022-06-24 21:01:24.092453
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic as basic
    subclss = get_platform_subclass(basic.User)
    assert subclss.__name__

# Generated at 2022-06-24 21:01:25.468139
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:01:30.412102
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    for distro_name in ['debian']:
        distribution = distro.LinuxDistribution(id=distro_name)
        (distro_id, codename, major_version) = distribution.parse_version()
        assert get_distribution_codename() == codename



# Generated at 2022-06-24 21:01:35.398032
# Unit test for function get_distribution
def test_get_distribution():
    # Testing is difficult to do here since we don't know what distribution the code will be running on
    # However, we can test that we use the distro module to pull the info and that the return value
    # is a NativeString and not an instance of distro.LinuxDistribution
    assert isinstance(get_distribution(), str), "get_distribution does not return a NativeString"
    assert get_distribution() != distro.name(), "get_distribution does not return a NativeString"



# Generated at 2022-06-24 21:01:40.551136
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean

    # This function is not supported on Windows
    if platform.system() == 'Windows':
        return

    module = AnsibleModule(
        argument_spec=dict(
            test=dict(type='bool', required=False, default=False),
        ),
        supports_check_mode=False,
    )

    # This is the super class that we want to test
    from ansible.module_utils.basic import User

    # Create the class that we want to test for here

# Generated at 2022-06-24 21:01:46.381973
# Unit test for function get_distribution
def test_get_distribution():
    # This testcase allows to check the function get_distribution
    from ansible.module_utils.basic import get_distribution
    expected_value = get_distribution()
    assert expected_value == "Linux"


# Generated at 2022-06-24 21:03:27.127978
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestClass:
        platform = 'Linux'
        distribution = 'Ubuntu'

    class TestClass1:
        platform = 'Linux'
        distribution = 'Redhat'

    TestClass1 = get_platform_subclass(TestClass1)
    TestClass = get_platform_subclass(TestClass)
    assert TestClass1.__name__ == 'TestClass1'
    assert TestClass.__name__ == 'TestClass'

# Generated at 2022-06-24 21:03:28.265081
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()


# Generated at 2022-06-24 21:03:33.944199
# Unit test for function get_distribution
def test_get_distribution():
    this_platform = platform.system()
    distribution = get_distribution()

    assert distribution is not None

    if this_platform == 'Linux':
        # On Linux distributions should always be set
        assert distribution is not None
    else:
        # On non-Linux platforms distribution should be None
        assert distribution is None



# Generated at 2022-06-24 21:03:37.453153
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    users = get_distribution()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:03:39.160055
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()
    assert var_0 is not None

# Generated at 2022-06-24 21:03:39.750997
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:03:43.867247
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    this_platform = platform.system()
    distribution = get_distribution()

    if this_platform == 'Linux':
        assert get_distribution_codename() is not None
    else:
        assert get_distribution_codename() is None


# Generated at 2022-06-24 21:03:45.981215
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestCls:
        pass

    cls = get_platform_subclass(TestCls)
    assert(cls is TestCls)

    class SubTestCls(TestCls):
        pass

    cls = get_platform_subclass(TestCls)
    assert(cls is TestCls)

# Generated at 2022-06-24 21:03:46.702718
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class_ = get_platform_subclass()

# Generated at 2022-06-24 21:03:52.674138
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    """
    Verify get_distribution_codename() for Linux distributions
    """
    distributions = {
        # (distro, version, codename)
        ('centos', '7.6.1810', 'Core'),
        ('debian', '8.11', 'jessie'),
        ('ubuntu', '14.04', 'Trusty Tahr'),
        ('ubuntu', '16.04', 'xenial'),
        ('ubuntu', '18.04', 'bionic'),
    }

    if platform.system() != 'Linux':
        raise Exception('test_get_distribution_codename() can only be run on Linux')
