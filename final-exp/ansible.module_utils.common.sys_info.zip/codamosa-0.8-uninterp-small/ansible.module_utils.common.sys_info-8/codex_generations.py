

# Generated at 2022-06-24 20:56:28.419517
# Unit test for function get_distribution_version
def test_get_distribution_version():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()


# Generated at 2022-06-24 20:56:30.869505
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert distro.id() == 'ubuntu', 'Failed to get_distribution_codename'
    assert distro.codename() == 'bionic', 'Failed to get_distribution_codename'

# Generated at 2022-06-24 20:56:31.590858
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass


# Generated at 2022-06-24 20:56:33.473675
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic
    print(get_platform_subclass(ansible.module_utils.basic.AnsibleModule))

# Generated at 2022-06-24 20:56:44.372671
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'bionic'

    # Test with a stubbed out distro.lsb_release_info()
    # Return value from an Ubuntu Bionic system run on Travis CI
    distro.lsb_release_info = lambda: {'codename': 'bionic'}
    assert get_distribution_codename() == 'bionic'

    # Test the codename None case - go through the dir of our stubbed out
    # distro.lsb_release_info()
    distro.lsb_release_info = lambda: dict(foo='bar')
    assert get_distribution_codename() is None

    # Test with a stubbed out distro.lsb_release_info()
    # Return value from an Ubuntu Bionic system run on Travis CI
    distro.lsb_release_info

# Generated at 2022-06-24 20:56:46.464051
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    if var_0 is not "OtherLinux":
        raise Exception("Test case 0 for get_distribution() failed")

# Generated at 2022-06-24 20:56:47.673096
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 20:56:49.139747
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass('foo') == 'foo'


# Generated at 2022-06-24 20:56:50.601209
# Unit test for function get_distribution
def test_get_distribution():
    print("Running test get_distribution")
    var_0 = get_distribution()
    assert True


# Generated at 2022-06-24 20:56:51.782620
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert 1 == 1, "Function not implemented yet"



# Generated at 2022-06-24 20:57:00.010867
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    print(get_distribution())



# Generated at 2022-06-24 20:57:02.144661
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()
    assert isinstance(var_0, (str, type(None)))



# Generated at 2022-06-24 20:57:06.985611
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


if __name__ == '__main__':
    import __main__
    test_case_0()
    test_get_distribution_codename()

# Generated at 2022-06-24 20:57:09.183039
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 20:57:12.942556
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 20:57:14.531564
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    test_case_0()
    assert var_0 == 'Linux'
    assert var_0 == 'Linux'

# Generated at 2022-06-24 20:57:15.595529
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    ret = get_distribution_codename()
    assert ret == u'xenial'



# Generated at 2022-06-24 20:57:22.751212
# Unit test for function get_distribution
def test_get_distribution():
    import ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock as mock
    import StringIO
    var_0 = get_distribution(StringIO.StringIO)
    assert var_0 == 'Debian'
    assert var_0 == 'Ubuntu'
    assert var_0 == 'CumulusLinux'


# Generated at 2022-06-24 20:57:32.486907
# Unit test for function get_distribution
def test_get_distribution():
    this_platform = platform.system()
    distribution = get_distribution()

    if this_platform == 'Linux':

        if distribution in ('Centos', 'Redhat', 'Amazon', 'Oracle', 'Scientific', 'Fedora'):
            assert distribution in ('Centos', 'Redhat', 'Amazon', 'Oracle', 'Scientific', 'Fedora')
            assert distribution in ('Centos', 'Redhat', 'Amazon', 'Oracle', 'Scientific', 'Fedora')
            assert distribution in ('Centos', 'Redhat', 'Amazon', 'Oracle', 'Scientific', 'Fedora')
            assert distribution in ('Centos', 'Redhat', 'Amazon', 'Oracle', 'Scientific', 'Fedora')
            assert distribution in ('Centos', 'Redhat', 'Amazon', 'Oracle', 'Scientific', 'Fedora')

# Generated at 2022-06-24 20:57:41.665379
# Unit test for function get_distribution
def test_get_distribution():
    this_platform = platform.system()
    var_0 = get_distribution()
    assert var_0
    assert get_distribution() == get_distribution()
    assert get_distribution() == get_distribution()
    assert get_distribution() == get_distribution()
    assert get_distribution() == get_distribution()
    assert get_distribution() == get_distribution()
    assert get_distribution() == get_distribution()
    assert get_distribution() == get_distribution()
    assert get_distribution() == get_distribution()
    assert get_distribution() == get_distribution()
    assert get_distribution() == get_distribution()
    assert get_distribution() == get_distribution()
    assert get_distribution() == get_distribution()


# Unit test

# Generated at 2022-06-24 20:57:55.957945
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True == isinstance(get_platform_subclass(), object)


# Generated at 2022-06-24 20:57:57.346223
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename()


# Generated at 2022-06-24 20:58:04.039271
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic as basic
    import platform
    from ansible.module_utils.basic import AnsibleModule

    class Base(object):
        platform = 'Linux'
        distribution = None

    class LinuxSubclass(Base):
        pass

    class RedhatSubclass(LinuxSubclass):
        distribution = 'Redhat'

    class DebianSubclass(LinuxSubclass):
        distribution = 'Debian'

    class AnotherLinuxSubclass(LinuxSubclass):
        distribution = 'OtherLinux'

    class WindowsSubclass(Base):
        platform = 'Windows'

    class Windows2016(WindowsSubclass):
        distribution = 'Windows2016'

    def test_platform(cls, expected_platform, expected_distribution):
        module = AnsibleModule({})
        module.set_defaults()

# Generated at 2022-06-24 20:58:07.866653
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

	# Test with a mocked class
    class TestCls:
        platform = 'windows'
        distribution = 'sunos'
    result = get_platform_subclass(TestCls)
    assert isinstance(result, TestCls)

# Generated at 2022-06-24 20:58:18.647921
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import get_platform_subclass

    # Test no subclass
    assert get_platform_subclass(basic.AnsibleModule) == basic.AnsibleModule

    # Test subclass with no distribution qualifier
    class TestClass(basic.AnsibleModule):
        platform = 'foo'

    assert get_platform_subclass(TestClass) == TestClass

    # Test subclass with distribution qualifier that matches
    distribution = get_distribution()
    if distribution is not None:
        class TestClass(basic.AnsibleModule):
            platform = 'Linux'
            distribution = distribution
        assert get_platform_subclass(TestClass) == TestClass

    # Test subclass with distribution qualifier that doesn't match
    class TestClass(basic.AnsibleModule):
        platform

# Generated at 2022-06-24 20:58:20.601710
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common.network import Network

    test_class = Network

    result = get_platform_subclass(test_class)

    assert isinstance(result,
                      Network)



# Generated at 2022-06-24 20:58:29.919234
# Unit test for function get_distribution
def test_get_distribution():
    this_platform = platform.system()

    if this_platform == 'Linux':
        # Linux base test cases
        assert get_distribution() == "Linux"

        # Linux distribution test cases

# Generated at 2022-06-24 20:58:33.256238
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        t = get_platform_subclass()
    except Exception as e:
        print(e)

# Generated at 2022-06-24 20:58:39.973852
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(A)
            return new_cls(*args, **kwargs)

        def __init__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs

    class B(A):
        platform = u'Linux'
        distribution = u'OtherLinux'

        def __init__(self, *args, **kwargs):
            kwargs[u'foo'] = u'bar'
            super(B, self).__init__(*args, **kwargs)

    class C(A):
        platform = u'Linux'
        distribution = u'Redhat'


# Generated at 2022-06-24 20:58:41.559214
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    var_0 = get_platform_subclass(platform)
    return 'Success'

# Generated at 2022-06-24 20:59:10.621849
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    _, var_1 = get_platform_subclass()
    assert var_1 is None

# Generated at 2022-06-24 20:59:15.315427
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None


# Generated at 2022-06-24 20:59:16.337583
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:59:24.827751
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
            import ansible.module_utils.basic
            import ansible.module_utils.six
            import ansible.module_utils.facts.system
            import ansible.module_utils.facts.distribution
            import platform
            import sys
            import types
            import importlib
    except ImportError as e:
            print(str(e))
    else:
            ansible.module_utils.six.moves.builtins.print = lambda x: None
            ansible.module_utils.six.moves.builtins.__import__ = lambda x: None
            ansible.module_utils.six.moves.builtins.open = None
            ansible.module_utils.six.moves.builtins.getattr = lambda x: None
            ansible.module_utils.six.moves.builtins.set

# Generated at 2022-06-24 20:59:26.358804
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Attempt to assign the class to the subclass (ex. User)
    class_0 = get_platform_subclass(User)


# Generated at 2022-06-24 20:59:32.079072
# Unit test for function get_distribution_version
def test_get_distribution_version():
    try:
        ansible_version = get_distribution_version()
    except:
        ansible_version = None

    if platform.system() == 'Linux':
        assert (ansible_version is not None)
    else:
        assert (ansible_version is None)



# Generated at 2022-06-24 20:59:41.196649
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        distribution = None
        platform = None

    class OtherLinux(Base):
        distribution = 'OtherLinux'
        format = 'no format for OtherLinux'

    class Linux(Base):
        platform = 'Linux'
        format = 'no format for Linux'

    class Redhat(Linux):
        distribution = 'Redhat'
        format = 'posix'

    class Debian(Linux):
        distribution = 'Debian'
        format = 'posix'

    # Test the simple case
    assert get_platform_subclass(Redhat).format == 'posix'

    # Test finding the subclass with the most specific distribution
    assert get_platform_subclass(Debian).format == 'posix'

    # Test finding the subclass with the most generic distribution

# Generated at 2022-06-24 20:59:52.450214
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    t_case_0 = "User"
    assert get_platform_subclass(t_case_0) == 'User'

    t_case_1 = "User"
    assert get_platform_subclass(t_case_1) == 'User'

    t_case_2 = "User"
    assert get_platform_subclass(t_case_2) == 'User'

    t_case_3 = "User"
    assert get_platform_subclass(t_case_3) == 'User'

    t_case_4 = "User"
    assert get_platform_subclass(t_case_4) == 'User'

    t_case_5 = "User"
    assert get_platform_subclass(t_case_5) == 'User'

    t_case_6 = "User"

# Generated at 2022-06-24 20:59:53.857067
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:00:05.677239
# Unit test for function get_distribution
def test_get_distribution():
    # Create a directory
    # Change to that directory
    old_cwd = os.getcwd()
    new_cwd = tempfile.mkdtemp()
    os.chdir(new_cwd)

    # Create an os-release file in the new directory
    os_release_file = os.path.join(new_cwd, 'os-release')

# Generated at 2022-06-24 21:01:02.854829
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test to assert that 'codename' is returned.
    expected = "bionic"
    actual = get_distribution_codename()
    assert expected == actual

# Generated at 2022-06-24 21:01:05.655490
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-24 21:01:07.247037
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()

# Generated at 2022-06-24 21:01:08.685548
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()


# Generated at 2022-06-24 21:01:09.848496
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass("test") == "test"

# Generated at 2022-06-24 21:01:18.159352
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    # not testing for AnsibleModule here because it is a Python builtin
    import ansible.module_utils.basic

    ans_module = ansible.module_utils.basic.AnsibleModule  # noqa: F841
    from ansible.module_utils.basic import AnsibleModule  # noqa: F811

    loaded_class = get_platform_subclass(AnsibleModule)

    # Assign a class to a variable that is named the same as the class
    AnsibleModule = loaded_class

    # Load the module
    module_args = dict()
    ansible_module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )  # noqa: F841

    # Run the unit tests

# Generated at 2022-06-24 21:01:20.599842
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # FIXME: get a valid test case
    # FIXME: remove the hardcoded version
    # FIXME: remove the hardcoded result
    # NOTE: this test case can only be ran on a CentOS 6.5 box, because of the get_distribution() call
    assert test_case_0() == "Centos"

# Generated at 2022-06-24 21:01:22.779872
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
        var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:01:23.989233
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()

# Generated at 2022-06-24 21:01:27.632214
# Unit test for function get_distribution
def test_get_distribution():
    # Test with:
    #     get_distribution()
    # Expect:
    #     (A) == (B)
    var_0 = get_distribution()
    var_1 = 'Redhat'
    assert var_0 == var_1


# Generated at 2022-06-24 21:02:24.766834
# Unit test for function get_distribution
def test_get_distribution():
    # Place your code here
    assert get_distribution() == 'Fedora'


# Generated at 2022-06-24 21:02:34.108461
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import sys
    f_platform = 'linux2'
    f_distribution = 'Linux'
    f_distribution_version = '3.10.0-327.el7.x86_64'
    f_distribution_codename = None
    f_platform_subclass = None
    f_expected_platform_subclass = None
    f_this_platform = platform.system()
    f_distribution = get_distribution()
    f_distribution_version = get_distribution_version()
    f_distribution_codename = get_distribution_codename()
    f_platform_subclass = get_platform_subclass(TestGetPlatformSubclass_0)
    f_expected_platform_subclass = TestGetPlatformSubclass_0

# Generated at 2022-06-24 21:02:38.368285
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class DistributionNotReadyObject(object):
        platform = None
        distribution = None

    actual_result = get_platform_subclass(DistributionNotReadyObject)
    assert actual_result == DistributionNotReadyObject


# Generated at 2022-06-24 21:02:39.375914
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'

# unit test for function get_distribution_version

# Generated at 2022-06-24 21:02:40.468338
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '18.04'

# Generated at 2022-06-24 21:02:44.120538
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    try:
        cmd='bash -c "cat /etc/os-release"'
        r1 = sh(cmd)
        var_1 = get_distribution_codename()
        if r1['rc'] == 0 and var_1 is not None:
            print('Test passed for function get_distribution_codename')
        else:
            print('Test failed for function get_distribution_codename')
    except Exception as e:
        print('Test failed for function get_distribution_codename')


# Generated at 2022-06-24 21:02:47.076041
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for get_platform_subclass
    '''
    cls = Platform
    cls2 = get_platform_subclass(cls)
    assert cls2.platform == 'Linux'
    assert cls2.distribution == get_distribution()


# Generated at 2022-06-24 21:02:48.544357
# Unit test for function get_distribution
def test_get_distribution():
    a = get_distribution()
    assert a == 'Debian'



# Generated at 2022-06-24 21:02:50.477144
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # From sample data
    assert get_distribution_codename() == 'xenial'


# Generated at 2022-06-24 21:02:51.810151
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() != None, "No implementation for platform"



# Generated at 2022-06-24 21:04:41.908480
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()



# Generated at 2022-06-24 21:04:46.517608
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()
    var_0 = distro.id()
    print(var_0)
    var_1 = distro.codename()
    print(var_1)
    var_2 = distro.version()
    print(var_2)

# Generated at 2022-06-24 21:04:52.236570
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestClass():
        platform = 'Linux'
        distribution = None

    class TestSubclassAmazon():
        platform = 'Linux'
        distribution = 'Amazon'

    TestClass.__subclasses__ = ()
    TestClass.__subclasses__ = (TestSubclassAmazon,)

    assert get_platform_subclass(TestClass) == TestClass
    assert get_platform_subclass(TestSubclassAmazon) == TestSubclassAmazon
    assert get_platform_subclass(TestSubclassAmazon) == TestSubclassAmazon

# Generated at 2022-06-24 21:04:57.220728
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution() == 'Ubuntu'
    assert get_distribution_version() == '18.04'
    assert get_distribution_codename() == 'bionic'

# Generated at 2022-06-24 21:04:58.553621
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()
    print(var_1)


# Generated at 2022-06-24 21:04:59.522244
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:05:00.794062
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None


# Generated at 2022-06-24 21:05:08.966181
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Test function get_platform_subclass
    """
    this_platform = platform.system()
    distribution = get_distribution()

    subclass = None

    # get the most specific superclass for this platform
    if distribution is not None:
        for sc in get_all_subclasses(cls):
            if sc.distribution is not None and sc.distribution == distribution and sc.platform == this_platform:
                subclass = sc
    if subclass is None:
        for sc in get_all_subclasses(cls):
            if sc.platform == this_platform and sc.distribution is None:
                subclass = sc
    if subclass is None:
        subclass = cls

    return subclass

# Generated at 2022-06-24 21:05:12.379935
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    # ---START OF CODE---
    assert isinstance(var_0, str)
    # ---END OF CODE---


# Generated at 2022-06-24 21:05:14.085731
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # AssertionError: None is not None
    assert get_distribution_codename() is not None
