

# Generated at 2022-06-24 20:56:24.118045
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Known values
    fix_version = '1.2.3'
    check_str = get_distribution_version()
    assert check_str == fix_version, 'result should equal fix_version, result=' + str(check_str) + ' fix_version=' + str(fix_version)



# Generated at 2022-06-24 20:56:28.896538
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == None

# Generated at 2022-06-24 20:56:35.481088
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo:
        pass

    f1 = Foo()
    f2 = Foo()

    f1.platform = 'Linux'
    f1.distribution = 'Debian'

    f2.platform = 'Linux'
    f2.distribution = None

    f_subclass = get_platform_subclass(f1)
    assert f_subclass is f1

    f_subclass = get_platform_subclass(f2)
    assert f_subclass is f2

if __name__ == '__main__':
    test_case_0()
    test_get_platform_subclass()

# Generated at 2022-06-24 20:56:37.153041
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    print(var_0)


# Generated at 2022-06-24 20:56:39.349745
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    element = "abcd"
    assert 'a' in element


# Generated at 2022-06-24 20:56:40.900179
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert(False), "No tests for get_platform_subclass()"

# Generated at 2022-06-24 20:56:41.527586
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()

# Generated at 2022-06-24 20:56:42.467309
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # No test available
    pass


# Generated at 2022-06-24 20:56:46.638218
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Test all the subclasses defined in this module to ensure they don't cause errors
    all_subclasses = get_all_subclasses(BaseFactCollector)

    for cls in all_subclasses:
        get_platform_subclass(cls)


# Generated at 2022-06-24 20:56:56.184835
# Unit test for function get_distribution

# Generated at 2022-06-24 20:57:13.075448
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # AssertionError: get_platform_subclass(float)
    with pytest.raises(AssertionError):
        get_platform_subclass(float)

    # AssertionError: get_platform_subclass('string')
    with pytest.raises(AssertionError):
        get_platform_subclass('string')

    # AssertionError: get_platform_subclass(None)
    with pytest.raises(AssertionError):
        get_platform_subclass(None)

    # AssertionError: get_platform_subclass(5)
    with pytest.raises(AssertionError):
        get_platform_subclass(5)

    # AssertionError: get_platform_subclass(True)

# Generated at 2022-06-24 20:57:14.102081
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:57:18.877236
# Unit test for function get_distribution
def test_get_distribution():
    '''
    :param int test:  This param is a documentation test
    :returns: Returns True if successful, otherwise False
    '''
    # Find the function get_distribution which is a method of the module distro.
    # The find_spec() method returns a spec, which is an object that represents
    # the import being sought. The spec contains a loader attribute that is a
    # loader object. The spec also contains the origin attribute, which is the
    # filename where the module was loaded from.

    # The spec.loader.load_module() method returns the module identified by the
    # module name.

    # The getattr() method returns the value of the named attribute of an
    # object.
    # This is the import module.distro statement.

# Generated at 2022-06-24 20:57:24.457952
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_1 = platform.system()
    var_2 = get_distribution()
    for sc in get_all_subclasses(cls):
        if sc.distribution is not None:
            if sc.distribution == var_2 and sc.platform == var_1:
                var_3 = sc
    if var_3 is None:
        for sc in get_all_subclasses(cls):
            if sc.platform == var_1:
                var_3 = sc
    if var_3 is None:
        var_3 = cls


# Generated at 2022-06-24 20:57:29.566236
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Randomly generate an object and test
    # the get_platform_subclass() function
    import random
    import string

    class_name = ''.join(random.choice(
        string.ascii_uppercase + string.digits) for _ in range(5))

    class_name = class_name + "_class_name"

    class_object = type(class_name, (object,), {})
    assert get_platform_subclass(class_object) is class_object
    assert get_platform_subclass(class_object) == class_object

# Generated at 2022-06-24 20:57:32.481389
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-24 20:57:40.007844
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import get_platform_subclass
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.config import NetworkConfig
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.config import NetworkIniConfig
    result = get_platform_subclass(NetworkIniConfig)
    assert result == NetworkIniConfig
    result = get_platform_subclass(NetworkConfig)
    assert result == NetworkConfig

# Generated at 2022-06-24 20:57:40.652183
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:57:41.999430
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert var_0 == "INTEL-OPTANEOS-0.1"


# Generated at 2022-06-24 20:57:43.560551
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    print('get the most specific superclass for this platform')
# TODO: Add your tests here.

# Generated at 2022-06-24 20:57:49.988337
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()



# Generated at 2022-06-24 20:57:52.386732
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Feature test for get_distribution_codename function
    '''
    res = get_distribution_codename()
    if res is not None:
        assert isinstance(res, str)

# Generated at 2022-06-24 20:57:54.714529
# Unit test for function get_distribution_version
def test_get_distribution_version():
    pass


# Generated at 2022-06-24 20:57:57.864235
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'el8'

if __name__ == '__main__':
    print(get_distribution())
    test_case_0()
    test_get_distribution_codename()

# Generated at 2022-06-24 20:57:58.711355
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    

# Generated at 2022-06-24 20:57:59.544716
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()

# Generated at 2022-06-24 20:58:02.565354
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Attempt to do something with get_platform_subclass(cls)

    get_platform_subclass(cls)


if __name__ == "__main__":
    print("distribution: " + get_distribution())
    print("version: " + get_distribution_version())
    print("codename: " + get_distribution_codename())

# Generated at 2022-06-24 20:58:08.244412
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible_collections.ansible.builtin.plugins.module_utils.basic
    cls = ansible_collections.ansible.builtin.plugins.module_utils.basic.AnsibleModule
    assert get_platform_subclass(cls).__name__ == 'AnsibleModule'

# Generated at 2022-06-24 20:58:12.484257
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    pass


# Generated at 2022-06-24 20:58:14.618253
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass(test_case_0)

if __name__ == '__main__':
    test_get_platform_subclass()

# Generated at 2022-06-24 20:58:27.327031
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:58:30.561063
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Get the distribution code name
    codename = get_distribution_codename()

    if codename is not None:
        print('Code name for this distribution is: ' + codename)
    else:
        print('Not running on a Linux distribution')


# Generated at 2022-06-24 20:58:32.902683
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    function_test_0 = get_platform_subclass(cls)


# Generated at 2022-06-24 20:58:35.485315
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename = get_distribution_codename()
    print('distribution_codename ' + distribution_codename)



# Generated at 2022-06-24 20:58:40.399478
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    obj = AnsibleModule
    retval = get_platform_subclass(obj)
    assert type(retval).__name__ == 'AnsibleModule'

    obj = None
    retval = get_platform_subclass(obj)
    assert retval == None

# Generated at 2022-06-24 20:58:50.664314
# Unit test for function get_distribution
def test_get_distribution():
    # Mock the needed imports
    import platform
    import platform as platform
    import ansible.module_utils.distro as distro

    # Mock needed classes
    class OtherLinux:
        def __init__(self):
            pass

        @classmethod
        def id(cls):
            return u'OtherLinux'

        @classmethod
        def os_release_info(cls):
            os_release_info = {
                u'version_codename': None,
                u'ubuntu_codename': None,
            }
            return os_release_info

        @classmethod
        def lsb_release_info(cls):
            lsb_release_info = {
                u'codename': None,
            }
            return lsb_release_info


# Generated at 2022-06-24 20:58:55.010976
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()
    var_1 = get_distribution_version()

# main function for testing

# Generated at 2022-06-24 20:59:04.479596
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import mock
    from ansible.module_utils._text import to_bytes

    # Test for get_platform_subclass when arguments are not present
    return_value = get_platform_subclass(str)

    if return_value != str:
        raise AssertionError()

    # Test for get_platform_subclass when arguments are present
    # Setup mock objects
    return_value_mock = mock.Mock(return_value=str)

    with mock.patch('platform.system', return_value_mock.return_value):
        return_value = get_platform_subclass(str)

    if return_value != str:
        raise AssertionError()

    # Test for get_platform_subclass when arguments are not present
    # Setup mock objects

# Generated at 2022-06-24 20:59:09.376540
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert var_0 is not None, "Variable var_0 should have a value"
    # print("Test case 0: " + str(var_0 == "Redhat"))
    assert var_0 == "Redhat", "Value should be Redhat"



# Generated at 2022-06-24 20:59:16.452634
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    print("Running get_platform_subclass tests")

    this_platform = get_distribution()
    print(this_platform)
    print(get_distribution_version())
    print(get_distribution_codename())
    print(get_platform_subclass(this_platform))


if __name__ == '__main__':
    test_case_0()
    test_get_platform_subclass()

# Generated at 2022-06-24 20:59:28.984208
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(None) == 'None'


# Generated at 2022-06-24 20:59:31.286394
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()
    if var_1 == 'Redhat':
        var_2 = get_distribution_version()


# Generated at 2022-06-24 20:59:39.020942
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for function get_distribution
    '''
    # These values are only used as an example.
    # They are subject to change without notice.
    # I've tested on Fedora and Ubuntu, that's as far as I go from a live system
    supported_distributions = (
        'Amzn',
        'Archlinux',
        'Centos',
        'Debian',
        'Fedora',
        'Linuxmint',
        'OpenSuse',
        'Rhel',
        'Suse',
        'Ubuntu',
    )

    distribution = get_distribution()
    assert distribution in supported_distributions



# Generated at 2022-06-24 20:59:42.060356
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test with arguments: <cls>
    var_cls = 'tests/resources/modules/test_case_0.py:test_case_0'
    get_platform_subclass(var_cls)
    assert(var_cls)


# Generated at 2022-06-24 20:59:46.394213
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert type(var_0) == str


# Generated at 2022-06-24 20:59:48.381730
# Unit test for function get_distribution
def test_get_distribution():
    print("Test -1")
    test_case_0()


if __name__ == '__main__':
    test_get_distribution()

# Generated at 2022-06-24 20:59:52.217539
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()
    assert(var_1 == u'')

# Generated at 2022-06-24 20:59:54.044704
# Unit test for function get_distribution
def test_get_distribution():
    var_2 = get_distribution()
    assert var_2 is not None
    return var_2


# Generated at 2022-06-24 20:59:54.577452
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:00:06.257348
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test for getting distribution codenames
    '''
    # get_distribution_codename: empty case
    assert get_distribution_codename() is None

    # get_distribution_codename: Amazon Linux
    assert get_distribution_codename() == 'bionic'

    # get_distribution_codename: CentOS 6
    assert get_distribution_codename() == 'el6'

    # get_distribution_codename: CentOS 7
    assert get_distribution_codename() == 'el7'

    # get_distribution_codename: Debian
    assert get_distribution_codename() == 'buster'

    # get_distribution_codename: Fedora
    assert get_distribution_codename() == 'f28'

    # get_distribution_codename: Red Hat
   

# Generated at 2022-06-24 21:00:21.820031
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert 'os_version' in test_get_distribution_version.__annotations__
    expected = test_get_distribution_version.__annotations__['os_version']
    actual = get_distribution_version()
    assert actual == expected

test_get_distribution_version.__annotations__ = {
    'os_version': '10.14'
}


# Generated at 2022-06-24 21:00:31.419776
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common import get_module_path
    import os
    import sys

    test_class = get_module_path('ansible.module_utils.basic', 'User')
    test_file = os.path.join(test_class, '__init__.py')

    # find the User class in that file
    with open(test_file, 'rb') as f:
        for line in f:
            line = line.decode('utf-8')
            if line.strip().startswith('class User'):
                break
        else:
            assert False, "No User class in %s" % test_file

        # add the directory to the path
        sys.path.append(os.path.dirname(test_file))
        # load the module and class

# Generated at 2022-06-24 21:00:32.922192
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert(get_platform_subclass(platform.system()) == platform.system())
    assert(get_platform_subclass(platform.system()) != "")

# Generated at 2022-06-24 21:00:33.474644
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:00:39.301850
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test case for the get_distribution_codename function
    '''
    def test_case_0():
        '''
        Test case for the get_distribution_codename function
        '''
        var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:00:41.284493
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None


# Generated at 2022-06-24 21:00:48.762152
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic
    from ansible.module_utils.basic import get_platform_subclass
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    with patch('platform.system') as mock_platform_system:
        mock_platform_system.return_value = 'Linux'
        with patch('ansible.module_utils.distro.id') as mock_distro_id:
            mock_distro_id.return_value = 'RedHat'

            # Verify that we get the subclass that has the most specific platform name
            ansi_pmod = ansible.module_utils.basic.AnsibleModule
            subclass = get_platform_subclass(ansi_pmod)
            assert subclass == ansi_pmod.RedHat

           

# Generated at 2022-06-24 21:00:54.572194
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    # Set up mock
    distro_id = distro.id()
    os_release_info = distro.os_release_info()
    lsb_release_info = distro.lsb_release_info()
    codename = distro.codename()

    distro.id = mock.Mock(return_value='centos')
    distro.os_release_info = mock.Mock(return_value={'version_codename': 'Uncle Buck'})

    # Invoke method
    result = get_distribution_codename()

    # Check assumptions
    assert result == 'Uncle Buck'

    # Check method calls
    distro.id.assert_called_with()
    distro.os_release_info.assert_called_with()
    assert not distro.lsb_release_info.called

# Generated at 2022-06-24 21:01:06.058118
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert 'Solaris' in globals(), "globals()['Solaris'] must define class 'Solaris'"
    assert 'OtherLinux' in globals(), "globals()['OtherLinux'] must define class 'OtherLinux'"
    assert 'OpenBSD' in globals(), "globals()['OpenBSD'] must define class 'OpenBSD'"
    assert 'FreeBSD' in globals(), "globals()['FreeBSD'] must define class 'FreeBSD'"

    class Platform:
        platform = 'Linux'

    class Distribution(Platform):
        distribution = 'OpenSuSE'

    class OpenSuSE(Distribution):
        pass

    class Amazon(Distribution):
        distribution = 'Amazon'

    assert get_platform_subclass(Platform) == Platform, 'Could not detect current distribution'

# Generated at 2022-06-24 21:01:08.172040
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    unittest_helper_class_0 = get_distribution_codename()  # type: ignore


# Generated at 2022-06-24 21:01:38.093627
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename
    '''
    # Test 1
    var_1 = get_platform_subclass()
    print(var_1)




# Generated at 2022-06-24 21:01:40.174436
# Unit test for function get_distribution
def test_get_distribution():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert 'returned non-string (type NoneType)' in str(excinfo.value)

# Generated at 2022-06-24 21:01:43.147049
# Unit test for function get_distribution
def test_get_distribution():
    distribution = distro.id().capitalize()
    if platform.system() == 'Linux':
        if distribution == 'Amzn':
            distribution = 'Amazon'
        elif distribution == 'Rhel':
            distribution = 'Redhat'
        elif not distribution:
            distribution = 'OtherLinux'
    assert get_distribution() == distribution


# Generated at 2022-06-24 21:01:49.539543
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    if get_platform_subclass is None:
        # in py2, None is an int which is not iterable
        get_platform_subclass = None
    # Create class
    class Class(object): pass
    Class.platform = 'Linux'
    Class.distribution = 'Debian'
    Class.sub_platform = None
    Class.sub_distribution = None
    # Create instances
    instance = Class()
    # Test first condition
    if get_platform_subclass(Class) is None:
        pass

if __name__ == '__main__':
    test_case_0()
    test_get_platform_subclass()

# Generated at 2022-06-24 21:01:50.893145
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True


# Generated at 2022-06-24 21:01:53.018000
# Unit test for function get_distribution
def test_get_distribution():
    assert callable(get_distribution)
    var_1 = get_distribution()
    assert type(var_1) is str and var_1 == 'Freebsd'



# Generated at 2022-06-24 21:02:02.679022
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class A:
        pass


    class A_0(A):

        def __init__(self):
            self.distribution = None
            self.platform = 'Linux'


    class A_1(A):

        def __init__(self):
            self.distribution = 'FreeBSD'
            self.platform = 'Linux'


    class A_2(A):

        def __init__(self):
            self.distribution = 'FreeBSD'
            self.platform = 'FreeBSD'
    res = get_platform_subclass(A, 'FreeBSD', 'Linux')
    assert res == A_1
    res = get_platform_subclass(A, 'FreeBSD', 'FreeBSD')
    assert res == A_2
    res = get_platform_subclass(A, '', 'Linux')
   

# Generated at 2022-06-24 21:02:09.361829
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # mock a class for get_platform_subclass to choose from.
    class Base(object):
        platform = platform.system()
        distribution = None

    class Platform1(Base):
        platform = u'Darwin'
        distribution = None

    class Platform2(Base):
        platform = u'Linux'
        distribution = None

    class Platform3(Base):
        platform = u'Linux'
        distribution = u'OtherLinux'

    class Platform4(Base):
        platform = u'Linux'
        distribution = distro.id()

    target_platform = get_platform_subclass(Base)

    assert target_platform is not None

    assert Platform1 not in target_platform.__mro__
    assert Platform2 not in target_platform.__mro__
    assert Platform3 not in target_platform.__mro__


# Generated at 2022-06-24 21:02:11.877290
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()
    expected_1 = 'Darwin'
    assert var_1 == expected_1



# Generated at 2022-06-24 21:02:13.527303
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    pass


# Generated at 2022-06-24 21:02:42.893472
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common._collections_compat import Mapping
    ansible_module_cls = type(b'AnsibleModule', (Mapping,), dict(distribution=None, platform=None))
    new_cls = get_platform_subclass(ansible_module_cls)
    assert new_cls is ansible_module_cls

# Generated at 2022-06-24 21:02:53.338834
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import Ubuntu
    from ansible.module_utils.facts.system.distribution import Debian
    from ansible.module_utils.facts.system.distribution import SUSE
    from ansible.module_utils.facts.system.distribution import Fedora
    from ansible.module_utils.facts.system.distribution import RedHat
    from ansible.module_utils.facts.system.distribution import Raspbian
    from ansible.module_utils.facts.system.distribution import Alpine
    from ansible.module_utils.facts.system.distribution import Archlinux
    from ansible.module_utils.facts.system.distribution import Gentoo

# Generated at 2022-06-24 21:02:59.245115
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Calling function get_distribution_codename.
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:03:07.382647
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import tempfile
    import shutil
    import sys

    # we're going to need a working set

    # see http://peak.telecommunity.com/DevCenter/setuptools#developer-s-guide

    # create a fake working set
    original_path = sys.path[:]
    original_modules = sys.modules.copy()

    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, 'ansible'))
    os.mkdir(os.path.join(tmpdir, 'ansible', 'module_utils'))

    # make a fake module

# Generated at 2022-06-24 21:03:13.783286
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # FIXME: This only works on Linux
    # Set up
    codename = get_distribution_codename()

    # Test
    assert codename is None or isinstance(codename, str)
    assert codename != ''

    # Clean up

# Generated at 2022-06-24 21:03:17.214026
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_distribution()
    var_1 = get_distribution_version()

    if var_0 == 'Freebsd':
        var_2 = get_platform_subclass(var_0)


# Generated at 2022-06-24 21:03:26.729561
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Source:
    # http://pymotw.com/2/platform/index.html

    # RedHat (RHEL, Fedora, CentOS)
    assert get_platform_subclass(UserModule).__name__ == UserModule.__name__
    assert get_platform_subclass(UserModuleRedHat).__name__ == UserModuleRedHat.__name__
    assert get_platform_subclass(UserModuleRedHat8).__name__ == UserModuleRedHat8.__name__

    # Ubuntu
    assert get_platform_subclass(UserModule).__name__ == UserModule.__name__
    assert get_platform_subclass(UserModuleUbuntu).__name__ == UserModuleUbuntu.__name__

    # Slackware
    assert get_platform_subclass(UserModule).__name__ == UserModule.__name__
   

# Generated at 2022-06-24 21:03:27.633395
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:03:32.418793
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-24 21:03:40.097025
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Finish testing the get_platform_subclass function. The current test
    # just fails by accident if the function doesn't work.
    from ansible.module_utils.parsing.convert_bool import Conditional
    from ansible.module_utils.basic import AnsibleModule
    assert issubclass(get_platform_subclass(Conditional), Conditional)
    assert issubclass(get_platform_subclass(AnsibleModule), AnsibleModule)

# Generated at 2022-06-24 21:04:05.168660
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:04:06.873445
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass()



# Generated at 2022-06-24 21:04:10.376570
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert var_0 == 'OtherLinux'
    assert var_0 != 'RedHat'
    assert var_0 != 'Linux'
    assert var_0 != 'Other'



# Generated at 2022-06-24 21:04:14.945831
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # get_platform_subclass(cls)
    assert None


# Generated at 2022-06-24 21:04:22.376644
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic
    basic.MODULE_COMPLEX_ARGS = {'foo': 'bar'}
    for key, value in basic.MODULE_COMPLEX_ARGS.items():
        assert key in basic.AnsibleModule.argument_spec
        assert value == basic.AnsibleModule.argument_spec[key]

    assert issubclass(basic.AnsibleModule, basic.Basic)
    assert basic.AnsibleModule.__module__ == 'ansible.module_utils.basic'

    _module = basic.AnsibleModule()
    assert _module.basic == basic.Basic()
    assert _module.params['foo'] == 'bar'


# Generated at 2022-06-24 21:04:23.338473
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass


# Generated at 2022-06-24 21:04:25.032332
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    with raises(NotImplementedError) as e:
        get_distribution_codename()


# Generated at 2022-06-24 21:04:29.000572
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestClass():
        pass

    assert get_platform_subclass(TestClass) == TestClass
    assert issubclass(get_platform_subclass(TestClass), TestClass)

# Generated at 2022-06-24 21:04:36.457910
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # FIXME: Replace this with a mock class so we don't have to have a dependency on the fcntl module
    # Base on implementation of fcntl.flock()
    from fcntl import flock
    from fcntl import _flock_platform

    subclass = get_platform_subclass(_flock_platform.flock)
    assert(subclass is not None)



# Generated at 2022-06-24 21:04:38.005208
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:05:26.488355
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()


# Generated at 2022-06-24 21:05:27.545106
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert(get_distribution_codename() is not None)


# Generated at 2022-06-24 21:05:28.244414
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print(get_distribution_codename())

# Generated at 2022-06-24 21:05:35.933236
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import get_platform_subclass
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.basic
    class TestCls():
        platform = 'Linux'
        distribution = None
    class SubCls1(TestCls):
        distribution = 'Redhat'
    assert TestCls == get_platform_subclass(TestCls)
    assert SubCls1 == get_platform_subclass(TestCls)
    class SubCls2(TestCls):
        distribution = 'Centos'
    assert TestCls == get_platform_subclass(TestCls)
    assert SubCls2 == get_platform_subclass(TestCls)
    class SubCls3(TestCls):
        platform = 'Windows'
    assert Sub

# Generated at 2022-06-24 21:05:44.585001
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import User
    from ansible.module_utils.facts import cache

    this_platform = platform.system()
    distribution = get_distribution()

    new_class = get_platform_subclass(User)

    # if only we could get the exact version number :)
    cache.set('ansible_distribution', distribution)
    cache.set('ansible_distribution_version', get_distribution_version())
    cache.set('ansible_distribution_codename', get_distribution_codename())
    cache.set('ansible_system', this_platform)

# Generated at 2022-06-24 21:05:45.643226
# Unit test for function get_distribution
def test_get_distribution():
    assert 'AmazonLinux' == get_distribution()


# Generated at 2022-06-24 21:05:47.535021
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # This will be called with a specific value for the parameter and test the
    # code to make sure it returns the correct value.
    var_0 = get_distribution_codename()

# Generated at 2022-06-24 21:05:48.616440
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:05:51.484504
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print('Testing the get_distribution_codename function')
    var = get_distribution_codename()
    if (var is None):
        print('SUCCESS: function returns expected output')
    else:
        print('FAILURE: unexpected function output: ' + str(var))


# Generated at 2022-06-24 21:05:52.718946
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert var_0 is None
