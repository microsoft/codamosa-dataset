

# Generated at 2022-06-24 20:56:28.521278
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import module_utils.basic
    import module_utils.linux_distribution
    import module_utils.special_distribution
    from module_utils.special_distribution import GenericBSD

    cls = module_utils.basic.AnsibleModule
    assert get_platform_subclass(cls) == cls

    cls = module_utils.linux_distribution.DistributionModule
    assert get_platform_subclass(cls) == module_utils.special_distribution.GenericLinux

    cls = module_utils.special_distribution.GenericLinux
    assert get_platform_subclass(cls) == module_utils.special_distribution.GenericLinux

    cls = module_utils.special_distribution.GenericBSD
    assert get_platform_subclass(cls) == module_utils.special_distribution.GenericBSD



# Generated at 2022-06-24 20:56:31.091023
# Unit test for function get_distribution_version
def test_get_distribution_version():
    dist = get_distribution()
    if dist == 'Redhat':
        ver = get_distribution_version()
        assert float(ver) >= 5

# Generated at 2022-06-24 20:56:32.318001
# Unit test for function get_distribution
def test_get_distribution():
    # test for get_distribution
    assert test_case_0() == 'OtherLinux'

# Generated at 2022-06-24 20:56:34.503739
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()

# Generated at 2022-06-24 20:56:35.700899
# Unit test for function get_distribution
def test_get_distribution():

    assert test_case_0() == 'Distro_0'

# Generated at 2022-06-24 20:56:36.486124
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    pass


# Generated at 2022-06-24 20:56:40.020209
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert 'str' in str(type(var_0)), 'get_distribution does not return a string'



# Generated at 2022-06-24 20:56:44.662570
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Make sure that get_platform_subclass calls get_distribution and get_distribution_codename
    # so that the lazy properties get set.
    assert get_distribution()
    assert get_distribution_codename()

    # Check that we may use any class as an argument.
    assert get_platform_subclass(object)



# Generated at 2022-06-24 20:56:46.137538
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # This function is designed to be called from Ansible code.  It is not
    # intended to be used from unit tests.  It is recommended that you use
    # sample code from the Ansible User module to test this function.
    pass


# Generated at 2022-06-24 20:56:50.492561
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class User:
        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(User)
            return super(cls, new_cls).__new__(new_cls)

    class System(User):
        platform = 'system'
        distribution = 'system'

    assert isinstance(User(), System)

# Generated at 2022-06-24 20:56:57.433100
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert None == get_platform_subclass()


# Generated at 2022-06-24 20:56:58.889019
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test for function get_platform_subclass
    '''
    pass

# Generated at 2022-06-24 20:56:59.656174
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:57:01.787979
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    dist = get_distribution_codename()
    assert dist == get_distribution_codename()


# Generated at 2022-06-24 20:57:06.961330
# Unit test for function get_distribution
def test_get_distribution():
    assert callable(get_distribution)
    res = get_distribution()
    # Check if exception was raised
    if res is not None and res is not False:
        raise Exception("Exception was raised unexpectedly")


# Generated at 2022-06-24 20:57:09.138299
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass() == None


# Generated at 2022-06-24 20:57:19.266273
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test with arguments.
    majors = (
        (u'alpine', u'alpine'),
        (u'Amazon', u'amzn'),
        (u'Amazon', u'amzn2'),
        (u'Amazon', u'amzn3'),
        (u'centos', u'centos'),
        (u'centos', u'centos7'),
        (u'centos', u'centos8'),
        (u'debian', u'debian'),
        (u'debian', u'debian8'),
        (u'fedora', u'fedora'),
        (u'freebsd', u'freebsd'),
        (u'ubuntu', u'ubuntu'),
        (u'ubuntu', u'xenial'),
    )
    for distribution in majors:
        code_name = get

# Generated at 2022-06-24 20:57:19.871224
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(None)
    pass

# Generated at 2022-06-24 20:57:29.412575
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # These are partially taken from aiocore
    # http://pydoc.net/Python/aiocore/0.1.0/aiocore.loop/_SelectorEventLoop
    from ansible.module_utils.basic import AnsibleModule, AnsibleModuleError
    from ansible.module_utils.six import PY3
    if PY3:
        from ansible.module_utils.six import raise_from
    else:
        # Python 2.6
        def raise_from(value, from_value):  # pylint: disable=redefined-builtin
            if isinstance(value, BaseException):
                value.__context__ = from_value
                raise value
            raise value

    class BaseClass(object):
        platform = None
        distribution = None


# Generated at 2022-06-24 20:57:30.251320
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert 0 == 0

# Generated at 2022-06-24 20:57:40.055819
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert 'raspberrypi' in get_distribution()
    assert 'Linux' in platform.system()

# Generated at 2022-06-24 20:57:43.301197
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:57:47.126227
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common._collections_compat import Iterable

    assert type(get_platform_subclass(int)) == int
    assert type(get_platform_subclass(str)) == str
    assert type(get_platform_subclass(Iterable)) is Iterable  # pylint: disable=unidiomatic-typecheck

# Generated at 2022-06-24 20:57:47.961169
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert True



# Generated at 2022-06-24 20:57:49.154326
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:57:50.322551
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:57:52.383773
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print("\nRunning test method %s" % sys._getframe().f_code.co_name)
    assert "bionic" == get_distribution_codename()


# Generated at 2022-06-24 20:57:57.544446
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()
    subclass = get_platform_subclass(UserModule)

    if distribution is not None:
        assert subclass == UserModule or subclass != UserModule
    assert subclass == UserModule or subclass != UserModule
    assert this_platform == 'Linux' or this_platform != 'Linux'
    assert subclass == BsdUserModule or subclass != BsdUserModule
    assert subclass == HPUserModule or subclass != HPUserModule
    assert subclass == LinuxUserModule or subclass != LinuxUserModule
    assert subclass == UserModule or subclass != UserModule
    assert subclass == UserModule or subclass != UserModule
# END

# Generated at 2022-06-24 20:57:58.190358
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass



# Generated at 2022-06-24 20:58:01.110512
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class AnsibleModule:
        def __init__(self, *args, **kwargs):
            self._name = "ansible_module"
    # Test case 1
    var_0 = get_platform_subclass(AnsibleModule)
    assert var_0._name == "ansible_module"


# Generated at 2022-06-24 20:58:14.033613
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:18.725313
# Unit test for function get_distribution
def test_get_distribution():
    # The function should return either a string or None
    var_0 = get_distribution()
    assert isinstance(var_0, type(None))
    var_1 = get_distribution()
    assert isinstance(var_1, type(None))


# Generated at 2022-06-24 20:58:19.895804
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    cls = object()
    get_platform_subclass(cls)



# Generated at 2022-06-24 20:58:21.040671
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:21.864666
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is None



# Generated at 2022-06-24 20:58:25.903178
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:27.061153
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename()


# Generated at 2022-06-24 20:58:29.103152
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    var_0 = get_platform_subclass(AnsibleModule)


# Generated at 2022-06-24 20:58:34.766610
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    mock_module = types.ModuleType('ansible.module_utils.facts.system.distribution')
    mock_module.distro.lsb_release_info = lambda: {'codename': 'my_codename'}
    mock_module.distro.os_release_info = lambda: {}
    mock_module.distro.id = lambda: 'Ubuntu'
    mock_module.platform.system = lambda: 'Linux'

    with mock.patch.dict(sys.modules, {'ansible.module_utils.facts.system.distribution': mock_module}):
        codename = get_distribution_codename()
        assert codename == 'my_codename'



# Generated at 2022-06-24 20:58:40.027576
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:52.125409
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:59:01.494673
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts import distributions

    class TestClass(object):
        pass

    # Test explicit set distribution
    class Test_Explicit_Distro_Class(TestClass):
        pass
    Test_Explicit_Distro_Class.distribution = 'Fedora'
    assert get_platform_subclass(TestClass) == TestClass
    assert get_platform_subclass(Test_Explicit_Distro_Class) == Test_Explicit_Distro_Class

    # Test setting to a general distribution class
    class Test_Distribution_Fedora_Class(TestClass):
        pass
    Test_Distribution_Fedora_Class.distribution = distributions.Fedora
    assert get_platform_subclass(TestClass) == TestClass

# Generated at 2022-06-24 20:59:02.946617
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:59:04.126106
# Unit test for function get_distribution
def test_get_distribution():
    """Test get_distribution."""
    var_0 = get_distribution()
    assert var_0



# Generated at 2022-06-24 20:59:09.607422
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test 1 - Redhat Linux 7
    assert get_platform_subclass(BasePlatform) == LinuxBasePlatform
    assert get_platform_subclass(LinuxBasePlatform) == RedhatBasePlatform
    assert get_platform_subclass(RedhatBasePlatform) == Redhat7BasePlatform

    # Test 2 - CentOS 6
    assert get_platform_subclass(BasePlatform) == LinuxBasePlatform
    assert get_platform_subclass(LinuxBasePlatform) == RedhatBasePlatform
    assert get_platform_subclass(RedhatBasePlatform) == CentOSBasePlatform
    assert get_platform_subclass(CentOSBasePlatform) == CentOS6BasePlatform

    # Test 3 - Amazon Linux 2017.03
    assert get_platform_subclass(BasePlatform) == LinuxBasePlatform
    assert get_platform_subclass(LinuxBasePlatform) == RedhatBasePlatform

# Generated at 2022-06-24 20:59:15.025326
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True == True



# Generated at 2022-06-24 20:59:17.249454
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils import basic

    var_cls = basic.AnsibleModule
    var_ret = get_platform_subclass(var_cls)

# Generated at 2022-06-24 20:59:22.794750
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert(get_platform_subclass(None) is not None)


# Generated at 2022-06-24 20:59:23.920332
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-24 20:59:31.196361
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Iterate the given path and find all .py files.
    from tests.unit import get_data_path
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.os import Darwin

    assert(get_platform_subclass(AnsibleModule) == AnsibleModule)
    assert(get_platform_subclass(Darwin) == Darwin)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:59:46.498676
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None, 'Failed to get distribution'


# Generated at 2022-06-24 20:59:57.115601
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts import cache as facts_cache
    from ansible.module_utils.facts import system as facts_system

# Generated at 2022-06-24 21:00:05.124497
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()
    subclass = None

    # get the most specific superclass for this platform
    if distribution is not None:
        for sc in get_all_subclasses(cls):
            if sc.distribution is not None and sc.distribution == distribution and sc.platform == this_platform:
                subclass = sc
    if subclass is None:
        for sc in get_all_subclasses(cls):
            if sc.platform == this_platform and sc.distribution is None:
                subclass = sc
    if subclass is None:
        subclass = cls
    print(subclass)

# Generated at 2022-06-24 21:00:06.982739
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()
    assert var_1 == "Linux"


# Generated at 2022-06-24 21:00:12.846820
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        assert distro.id() == 'centos'
        assert get_distribution() == 'Centos'
        assert get_distribution_version() == '7'
        assert get_distribution_codename() is None

    except AssertionError:
        raise AssertionError("unit test for get_platform_subclass.get_distribution() failed")


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:00:14.037671
# Unit test for function get_distribution
def test_get_distribution():
    # case 0

    assert get_distribution() is not None


# Generated at 2022-06-24 21:00:19.146460
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.system import System
    from ansible.module_utils.facts.system.osx import Darwin

    _cls = get_platform_subclass(System)
    assert _cls == Darwin
    assert _cls.distribution == to_bytes('')
    assert _cls.platform == "Darwin"

    # needed for code coverage
    from ansible.module_utils.facts.system.linux import Linux
    _cls = get_platform_subclass(Linux)
    assert _cls is Linux

# Generated at 2022-06-24 21:00:20.727407
# Unit test for function get_distribution
def test_get_distribution():
    var_0 = get_distribution()
    assert isinstance(var_0, None) == False, 'return get_distribution'

# Generated at 2022-06-24 21:00:26.744339
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
# this module isn't present on all platforms
    if 'ansible.modules.system.user' in sys.modules:
        assert get_platform_subclass(User) == UserFreeBSD


# Generated at 2022-06-24 21:00:28.360189
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    var_0 = get_platform_subclass(AnsibleModule)


# Generated at 2022-06-24 21:00:41.499117
# Unit test for function get_distribution
def test_get_distribution():
    print('In get_distribution')
    test_case_0()



# Generated at 2022-06-24 21:00:42.899285
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert False



# Generated at 2022-06-24 21:00:53.213973
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class f:
        distribution = None
        platform = None

    class l:
        distribution = get_distribution()
        platform = 'Linux'

    class b:
        distribution = get_distribution()
        platform = 'Linux'

    class a:
        distribution = 'Amazon'
        platform = 'Linux'

    class c:
        distribution = 'Amazon'
        platform = 'Linux'

    class d:
        distribution = 'Redhat'
        platform = 'Linux'

    class e:
        distribution = 'Redhat'
        platform = 'Linux'

    assert get_platform_subclass(l) == l
    assert get_platform_subclass(b) == b
    assert get_platform_subclass(a) == a
    assert get_platform_subclass(c) == a
    assert get_platform_subclass

# Generated at 2022-06-24 21:00:53.764159
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:01:00.037263
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import User
    from ansible.module_utils.facts import SystemInfo
    # Used for verifying the User class
    assert isinstance(get_platform_subclass(User), User), "Incorrect subclass returned"

    # Used for verifying the SystemInfo class
    assert isinstance(get_platform_subclass(SystemInfo), SystemInfo), "Incorrect subclass returned"

# Generated at 2022-06-24 21:01:08.633570
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule as TestModule

    class TestPlatformSubclass0(TestModule):
        platform = 'Darwin'
        distribution = 'Darwin'

    class TestPlatformSubclass1(TestPlatformSubclass0):
        platform = 'Darwin'
        distribution = 'MacOS'

    class TestPlatformSubclass2(TestPlatformSubclass0):
        platform = 'Linux'
        distribution = 'CentOS'

    class TestPlatformSubclass3(TestPlatformSubclass0):
        platform = None
        distribution = 'Linux'

    result = get_platform_subclass(TestPlatformSubclass0)
    assert len(set(result.__bases__) & set(TestPlatformSubclass0.__bases__)) == len(TestPlatformSubclass0.__bases__)
    assert result.distribution

# Generated at 2022-06-24 21:01:17.318125
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test for an Amazon Linux distribution
    os_release_info = {'version_codename': 'n/a', 'id': 'amzn', 'pretty_name': 'Amazon Linux AMI 2018.03', 'version_id': '2018.03', 'home_url': 'http://aws.amazon.com/amazon-linux-ami/2018.03-release-notes'}
    lsb_release_info = {}
    distro_info = {'id': 'amzn', 'release': '2018.03', 'version': '2018.03', 'codename': 'n/a', 'like': 'rhel fedora', 'pretty_name': 'Amazon Linux AMI 2018.03'}
    distro._distro = None
    distro.os_release_info = lambda: os_release_info
    distro.lsb_release_

# Generated at 2022-06-24 21:01:22.686862
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_1 = get_distribution_codename()


# Generated at 2022-06-24 21:01:25.468516
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_1 = get_platform_subclass(cls = None)
    if var_1 == None:
        pass
    elif var_1 != None:
        pass

# Generated at 2022-06-24 21:01:26.034402
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:01:40.041254
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    actual = get_platform_subclass(str)
    expected = str
    assert actual == expected, "Failed test_get_platform_subclass"

# Generated at 2022-06-24 21:01:41.467624
# Unit test for function get_distribution_version
def test_get_distribution_version():
    if platform.system() == 'Linux':
        version = get_distribution_version()
        assert(isinstance(version, str))

# Generated at 2022-06-24 21:01:46.531664
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Create a class to test with
    class Foo:
        def subclass_method(self):
            return "Foo.subclass_method"

    # Create a subclass of Foo to test with
    class Bar(Foo):
        @classmethod
        def get_platform_subclass(cls, **kwargs):
            return Foo

        distribution = 'FooDistro'
        platform = 'FooPlatform'
        def bar_method(self):
            return "Bar.bar_method"

    # Another class to use for testing
    class Baz:
        def get_platform_subclass(cls, **kwargs):
            return Foo
        distribution = 'FooDistro'
        platform = 'FooPlatform'
        def baz_method(self):
            return "Baz.baz_method"

    # Test that Foo

# Generated at 2022-06-24 21:01:53.544420
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.plugins.action.normal import ActionModule as action_module_class
    from ansible.plugins.action import ActionBase as action_base_class
    assert type(get_platform_subclass(action_module_class)) is not action_module_class
    assert issubclass(get_platform_subclass(action_module_class), action_base_class)

# Generated at 2022-06-24 21:01:57.466775
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()

# Generated at 2022-06-24 21:02:01.682701
# Unit test for function get_distribution
def test_get_distribution():
    this_platform = platform.system()
    distribution = get_distribution()
    assert (this_platform is not None)
    assert (distribution is not None)


# Generated at 2022-06-24 21:02:02.850621
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()

# Generated at 2022-06-24 21:02:04.097267
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:02:06.813282
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == "7.5"  # TODO: why 7.5 not 7.6?


# Generated at 2022-06-24 21:02:07.357622
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True

# Generated at 2022-06-24 21:02:34.660060
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    var_0 = get_platform_subclass()
    var_1 = get_platform_subclass()
    var_2 = get_platform_subclass()
    var_3 = get_platform_subclass()
    var_4 = get_platform_subclass()


# Generated at 2022-06-24 21:02:37.385553
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'bionic'


# Generated at 2022-06-24 21:02:43.225043
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestClass: pass
    class TestClass_Sub_1(TestClass): pass
    class TestClass_Sub_2(TestClass_Sub_1): pass

    TestClass_Sub_1.platform = "test"
    TestClass_Sub_1.distribution = None
    TestClass_Sub_2.platform = None
    TestClass_Sub_2.distribution = "test"

    res = get_platform_subclass(TestClass)
    assert res == TestClass

# Generated at 2022-06-24 21:02:53.686693
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test 1: Testing a Ubuntu Xenial Xerus
    distribution = 'Debian'
    distribution_version = '9.4'
    distribution_codename = 'stretch'
    assert get_distribution_codename() == distribution_codename
    # Test 2: Testing a Ubuntu Xenial Xerus
    distribution = 'Debian'
    distribution_version = '9.5'
    distribution_codename = 'stretch'
    assert get_distribution_codename() == distribution_codename
    # Test 3: Testing a Ubuntu Xenial Xerus
    distribution = 'Ubuntu'
    distribution_version = '16.04'
    distribution_codename = 'xenial'
    assert get_distribution_codename() == distribution_codename
    # Test 4: Testing a Ubuntu Xenial Xerus
    distribution = 'Fedora'


# Generated at 2022-06-24 21:02:59.045518
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.plugins.connection.network_cli
    assert get_platform_subclass(ansible.plugins.connection.network_cli.Connection) == ansible.plugins.connection.network_cli.Connection



# Generated at 2022-06-24 21:03:00.278132
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()


# Generated at 2022-06-24 21:03:06.836316
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Input parameters:
    cls = None

    # Return type:
    # class

    return None

# Generated at 2022-06-24 21:03:07.813982
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        assert True
    except AssertionError as e:
        raise e



# Generated at 2022-06-24 21:03:16.098741
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.modules.system.group
    class Base:
        pass

    class One(Base):
        distribution = 'RedHat'
        platform = 'Linux'

    class Two(One):
        distribution = 'RedHat'
        platform = 'Linux'

    class Three(Two):
        distribution = 'RedHat'
        platform = 'Linux'

    ansible.modules.system.group.RedHatGroup = Three

    assert get_platform_subclass(Base) == Three

# Generated at 2022-06-24 21:03:16.890578
# Unit test for function get_distribution
def test_get_distribution():
    assert True


# Generated at 2022-06-24 21:03:42.220576
# Unit test for function get_distribution_version
def test_get_distribution_version():
    version = get_distribution_version()


# Generated at 2022-06-24 21:03:47.741757
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import User
    assert get_platform_subclass(User) is not None

# Generated at 2022-06-24 21:03:48.515609
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == ""

# Generated at 2022-06-24 21:03:50.856741
# Unit test for function get_distribution
def test_get_distribution():
    assert 'Amazon' in test_case_0()


# Generated at 2022-06-24 21:03:51.998116
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:04:01.501380
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class cls():
        def __init__(self, args, kwargs):
            self._args = args
            self._kwargs = kwargs
        def set_platform(self, platform):
            self.platform = platform
        def set_distribution(self, distribution):
            self.distribution = distribution
    class cls_0(cls):
        pass
    class cls_1(cls_0):
        pass
    class cls_2(cls_0):
        pass
    class cls_3(cls_1):
        pass
    class cls_4(cls_2):
        pass
    sc = cls_4()
    sc.set_platform('linux2')
    sc.set_distribution(None)

# Generated at 2022-06-24 21:04:06.695739
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print('Testing get_distribution_codename...')
    var_0 = get_distribution_codename()
    assert var_0 == u'xenial'

test_get_distribution_codename()


# Generated at 2022-06-24 21:04:08.389797
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:04:09.773971
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:04:16.482043
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_distribution() == get_distribution(), 'get_distribution() return value is not equal to get_distribution()'
    assert get_distribution_version() == get_distribution_version(), 'get_distribution_version() return value is not equal to get_distribution_version()'
    assert get_distribution_codename() == get_distribution_codename(), 'get_distribution_codename() return value is not equal to get_distribution_codename()'

# Generated at 2022-06-24 21:05:05.961133
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert 'bionic' == get_distribution_codename()

# Generated at 2022-06-24 21:05:07.823480
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:05:12.875598
# Unit test for function get_distribution
def test_get_distribution():
    # Call function get_distribution
    var_0 = get_distribution()
    assert type(var_0) == str


# Generated at 2022-06-24 21:05:13.797374
# Unit test for function get_distribution_version
def test_get_distribution_version():
    ret_obj = get_distribution_version()

# Generated at 2022-06-24 21:05:14.627878
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass


# Generated at 2022-06-24 21:05:15.176119
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:05:16.206088
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Fail the test if this does not have a codename
    assert get_distribution_codename() is not None


# Generated at 2022-06-24 21:05:16.733202
# Unit test for function get_distribution
def test_get_distribution():
    pass

# Generated at 2022-06-24 21:05:18.264401
# Unit test for function get_distribution
def test_get_distribution():
    print("The test case result is ", end="")
    print(get_distribution())


# Generated at 2022-06-24 21:05:19.825178
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()
