

# Generated at 2022-06-24 20:56:22.665798
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Make sure function is callable for any platform
    get_distribution_codename()


# Generated at 2022-06-24 20:56:26.986403
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert('stretch' == get_distribution_codename())

# Generated at 2022-06-24 20:56:33.988926
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()

    subclass = None

    # get the most specific superclass for this platform
    if distribution is not None:
        for sc in get_all_subclasses(User):
            if sc.distribution is not None and sc.distribution == distribution and sc.platform == this_platform:
                subclass = sc
    if subclass is None:
        for sc in get_all_subclasses(User):
            if sc.platform == this_platform and sc.distribution is None:
                subclass = sc
    if subclass is None:
        subclass = User

    return subclass

# Generated at 2022-06-24 20:56:44.571269
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    print("Assuming get_distribution() works correctly")
    distro = get_distribution()
    if distro == "Linux":
        print("Assuming get_distribution_version() works correctly")
        version = get_distribution_version()
        if version.startswith("7."):
            print("Assuming get_distribution_codename() works correctly")
            codename = get_distribution_codename()
            if codename.startswith("xenial"):
                print("Validating get_platform_subclass with class LinuxUser")
                from ansible.module_utils.common._collections_compat import Mapping
                from ansible.module_utils.basic import AnsibleModule
                from ansible.module_utils.ansible_free_ipa_module import options
                opts = options

# Generated at 2022-06-24 20:56:45.970409
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:56:51.722193
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()



# Generated at 2022-06-24 20:57:03.495863
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        import ansible.module_utils.basic
    except ImportError:
        from ansible.module_utils import basic

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import load_platform_subclass

    ansible.module_utils.basic.MODULE_COMPLEX_ARGS = dict()
    ansible.module_utils.basic.BOOLEANS_TRUE = set()
    ansible.module_utils.basic.BOOLEANS_FALSE = set()


if __name__ == '__main__':
    print('=== test_case_0() ===')
    test_case_0()
    print('=== test_get_platform_subclass() ===')
    test_get_platform_subclass()

# Generated at 2022-06-24 20:57:12.876363
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    this_platform = platform.system()
    distribution = get_distribution()
    codename = get_distribution_codename()

    if this_platform == 'Linux':
        if distribution == 'Ubuntu':
            assert codename == 'xenial'
        elif distribution == 'Fedora':
            assert codename is None
        elif distribution == 'Redhat':
            assert codename is None
        elif distribution == 'Amazon':
            assert codename is None
        elif distribution == 'Debian':
            assert codename == 'jessie'
        else:
            assert codename is None
    else:
        assert codename is None

# Generated at 2022-06-24 20:57:14.809011
# Unit test for function get_distribution_version
def test_get_distribution_version():
    print("Testing get_distribution_version")
    var_0 = get_distribution_version()
    print("Test complete")


# Generated at 2022-06-24 20:57:24.615870
# Unit test for function get_distribution_version
def test_get_distribution_version():

    # Assuming the current OS we are running on is Linux
    sys_str = 'Linux'
    # Assuming the distribution for current OS is centos
    dstrb_str = 'centos'
    # Assuming the version for current OS is 7.5.1804
    vrsn_str = '7.5.1804'

    # The function get_distribution_version() gives a string as output.
    # We are checking if the output is str.
    if not isinstance(get_distribution_version(), str):
        assert False

    # The function get_distribution_version() should return 7.5 as the output
    if vrsn_str == get_distribution_version():
        assert True

# Generated at 2022-06-24 20:57:35.779862
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    pass

# Generated at 2022-06-24 20:57:46.552266
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from ansible.module_utils.common.distribution import Distribution as distribution

    # This is just to initialize the distro_id/version tuple
    distro.id()

    # Test for a value in codename_map
    distribution.codename_map = {u'centos': u'CentOS'}
    distro.distribution = distribution
    assert get_distribution_codename() == 'CentOS'

    # Test for a value in codename_map but with a different version
    distribution.codename_map = {u'centos': u'CentOS'}
    distribution.distro_id = (u'centos', u'7.5.1804')
    distribution.distro_version = u'7.5.1804'
    distro.distribution = distribution

# Generated at 2022-06-24 20:57:54.413076
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import get_platform_subclass

    from ansible.module_utils.distro_test import TestCase0
    from ansible.module_utils.distro_test import TestCase1
    from ansible.module_utils.distro_test import TestCase2
    from ansible.module_utils.distro_test import TestCase3
    from ansible.module_utils.distro_test import TestCase5
    from ansible.module_utils.distro_test import TestCase6
    from ansible.module_utils.distro_test import TestCase7
    from ansible.module_utils.distro_test import TestCase8

    # get_platform_subclass(TestCase3)

    TestCase0.platform = "Not Linux"
    TestCase1.platform = "Linux"


# Generated at 2022-06-24 20:57:58.739829
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test with a mocked class
    class TestClass(object):
        platform = 'linux'

    assert(get_platform_subclass(TestClass) == TestClass)
    # Test with a real class
    from ansible.module_utils.basic import ModuleBase, AnsibleModule
    assert(isinstance(get_platform_subclass(ModuleBase), ModuleBase))

# Generated at 2022-06-24 20:57:59.846708
# Unit test for function get_distribution_version
def test_get_distribution_version():

    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:58:10.206394
# Unit test for function get_distribution_version
def test_get_distribution_version():
    this_platform = platform.system()
    version = get_distribution_version()

    assert version is not None

    if this_platform == 'Linux':
        # For Linux, we need to validate that the version string has the form
        # major.minor at least
        assert len(version) > 1
        assert version.count('.') >= 1
    else:
        # On Windows and macOS, we don't know what versions of those platforms
        # are in use so we can't validate the version string.
        pass

# Generated at 2022-06-24 20:58:11.464147
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 20:58:12.968073
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # noop for now
    pass

# Generated at 2022-06-24 20:58:14.148620
# Unit test for function get_distribution_version
def test_get_distribution_version():
    result = get_distribution_version()
    print(result)
    assert result == None

# Generated at 2022-06-24 20:58:19.504978
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # TODO: Update this test for when distro and platform information is
    # available for the testing Linuxes
    assert (get_platform_subclass(os.path.posixpath)().__class__.__name__ == 'posixpath'), \
        "Test code 1 failed"
    assert (get_platform_subclass(os.path.ntpath)().__class__.__name__ == 'ntpath'), \
        "Test code 2 failed"
    assert (get_platform_subclass(os.path.macpath)().__class__.__name__ == 'posixpath'), \
        "Test code 3 failed"



# Generated at 2022-06-24 20:58:32.834970
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert not check_result('test_case_0')
    print('Test success')

# Generated at 2022-06-24 20:58:33.763047
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass # TODO


# Generated at 2022-06-24 20:58:34.834263
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    print("In test_get_platform_subclass()")
    return True

# Generated at 2022-06-24 20:58:40.555342
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    """
    Make sure we detect codenames on Linux distributions
    """
    codename = get_distribution_codename()
    if platform.system() == 'Linux':
        # We should always be able to get a codename on Linux
        assert codename is not None
    else:
        # On the other platforms we should not get a codename
        assert codename is None

# Generated at 2022-06-24 20:58:41.428189
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:58:43.113276
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    this_platform = platform.system()
    distribution = get_distribution()
    codename = get_distribution_codename()
    assert distribution == 'Rhel'
    assert codename == 'Maipo'

# Generated at 2022-06-24 20:58:46.762690
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-24 20:58:51.737709
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Ensure that get_distribution_codename() returns a string on Linux systems
    '''
    if platform.system() == 'Linux':
        assert isinstance(get_distribution_codename(), str)
    else:
        assert get_distribution_codename() is None



# Generated at 2022-06-24 20:58:52.841149
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_2 = get_distribution_version()

# Generated at 2022-06-24 20:58:53.808965
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert True, "Unit test not implemented"

# Generated at 2022-06-24 20:59:05.775060
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 20:59:09.191679
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    print(
        "Test get_platform_subclass")
    test_case_0()

if __name__ == '__main__':
    test_get_platform_subclass()

# Generated at 2022-06-24 20:59:15.977893
# Unit test for function get_distribution
def test_get_distribution():
    # Assert list is returned
    assert True
    # Assert length of list is 3
    assert 3
    # Assert first element of list is 'bar'
    assert 'bar'
    # Assert second element of list is 8
    assert 8
    # Assert third element of list is 'gronk'
    assert 'gronk'



# Generated at 2022-06-24 20:59:16.749887
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == None


# Generated at 2022-06-24 20:59:25.425437
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import User
    from ansible.module_utils.facts import User as FUser
    from ansible.module_utils.facts.collector import User as FUserCol
    distro_0 = get_distribution()
    distro_1 = 'Linux'
    distro_2 = get_distribution_version()
    distro_3 = get_distribution_codename()

    assert issubclass(test_get_platform_subclass.get_platform_subclass_0(User), User)
    assert issubclass(test_get_platform_subclass.get_platform_subclass_1(FUser), FUser)
    assert issubclass(test_get_platform_subclass.get_platform_subclass_2(FUserCol), FUserCol)


# Generated at 2022-06-24 20:59:26.067685
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 20:59:27.883889
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename = get_distribution_codename()
    assert distribution_codename == 'bionic'

# Generated at 2022-06-24 20:59:30.577685
# Unit test for function get_distribution
def test_get_distribution():
    """Test get_distribution
    """
    assert 'Linux' == get_distribution()
    assert 'Linux' == get_distribution()
    assert 'Linux' == get_distribution()


# Generated at 2022-06-24 20:59:32.025113
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Darwin'


# Generated at 2022-06-24 20:59:34.364613
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # make sure keys are present
    assert 'darwin' in (get_distribution_codename() or {})


# Generated at 2022-06-24 20:59:46.208289
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 20:59:57.140215
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    ansible_platform = platform.system()
    ansible_distribution = get_distribution()
    ansible_distribution_version = get_distribution_version()

    distro_info = dict(distribution=ansible_distribution, distribution_version=ansible_distribution_version)

    # Make a platform subclass to test.
    class TestSubclass:
        distribution = None
        platform = ansible_platform

    # test top level class
    class_var_0 = get_platform_subclass(TestSubclass)
    assert class_var_0 == TestSubclass

    # test a specific distribution
    TestSubclass.distribution = ansible_distribution
    class_var_1 = get_platform_subclass(TestSubclass)
    assert class_var_1 == TestSubclass

    # test a specific distribution and version

# Generated at 2022-06-24 21:00:01.514685
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import User as mod_0
    class_var_0 = get_platform_subclass(mod_0)

# Generated at 2022-06-24 21:00:04.575333
# Unit test for function get_distribution
def test_get_distribution():
    # Testing with default values for argument 'distribution'
    distribution = get_distribution()


# Generated at 2022-06-24 21:00:05.886335
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename = get_distribution_codename()



# Generated at 2022-06-24 21:00:07.546622
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    f = get_distribution_codename
    assert f() == None

# Generated at 2022-06-24 21:00:13.069454
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:00:13.584655
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:00:14.882796
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # should be true
    assert callable(get_platform_subclass)


# Generated at 2022-06-24 21:00:15.982106
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class_obj = None
    assert not get_platform_subclass(class_obj)



# Generated at 2022-06-24 21:00:29.154797
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    f = open("tests/data/example_output/get_distribution_codename", "r")
    for line in iter(f):
        assert line == get_distribution_codename()
    f.close()

# Generated at 2022-06-24 21:00:32.057729
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
  var_1 = AnsibleModuleTest1()
  assert var_1.test_func_0() == 'AnsibleModuleTest2'


# Generated at 2022-06-24 21:00:34.740540
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Platform(object):
        def __init__(self):
            self.distribution = get_distribution()
    platform = Platform()
    cls = get_platform_subclass(platform)

# Generated at 2022-06-24 21:00:42.027569
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Function to be tested
    from ansible.module_utils.basic import get_platform_subclass

    # Arguments
    class cls:
        def __init__(self):
            self.platform = None
            self.distribution = None
        pass

    # Return value
    return_value = None

    # Actual code to run
    return_value = get_platform_subclass(cls)

    assert return_value is not None

# Generated at 2022-06-24 21:00:45.812300
# Unit test for function get_distribution
def test_get_distribution():
    expected = 'Linux'
    actual = get_distribution()
    assert expected == actual


# Generated at 2022-06-24 21:00:47.409947
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        get_platform_subclass()
    except Exception as e:
        pass



# Generated at 2022-06-24 21:00:48.268129
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == "Linux"


# Generated at 2022-06-24 21:00:54.493339
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    class FauxSubclass(AnsibleModule):
        pass
    class FauxDistroSubclass(AnsibleModule):
        pass
    class FauxDistroSubclass_wrong(AnsibleModule):
        distribution = 'Wrong-Distro'
    class FauxDistroSubclass_correct(AnsibleModule):
        distribution = get_distribution()
    assert FauxDistroSubclass_correct == get_platform_subclass(FauxDistroSubclass)
    assert FauxDistroSubclass_correct != get_platform_subclass(FauxDistroSubclass_wrong)

# Generated at 2022-06-24 21:01:04.029010
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_module_args
    from ansible.module_utils.facts.system.distribution import LinuxDistribution

    # Tests to ensure the correct subclass is chosen when the code is running on Linux
    assert isinstance(get_platform_subclass(LinuxDistribution), LinuxDistribution)
    assert isinstance(get_platform_subclass(AnsibleModule), AnsibleModule)
    assert isinstance(get_platform_subclass(ansible_module_args), dict)

# Generated at 2022-06-24 21:01:07.036423
# Unit test for function get_distribution
def test_get_distribution():
    assert None is test_case_0()


# Generated at 2022-06-24 21:01:28.824520
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Redirect standard output to a temporary file because the unit test output
    # would fail on systems that don't have a /etc/os-release file.
    import tempfile
    import sys
    outfile = tempfile.NamedTemporaryFile(delete=False)
    sys.stdout = outfile

    # Mock class that is used in the test
    class TestSubclass:
        def __init__(self, args, kwargs):
            self.args = args
            self.kwargs = kwargs

    class TestClass:
        class TestClassSubclass(TestSubclass):
            platform = 'TestPlatform'
            distribution = 'TestDistribution'

        class TestClassSubclassNoDist(TestSubclass):
            platform = 'TestPlatform'
            distribution = None


# Generated at 2022-06-24 21:01:31.969978
# Unit test for function get_distribution
def test_get_distribution():
  from ansible.module_utils import basic
  from ansible.module_utils.basic import _load_platform_subclass
  
  res = get_distribution()

  assert (res == 'Debian') 


# Generated at 2022-06-24 21:01:35.593361
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:01:41.284591
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Test:
        distribution = None
        platform = 'test'
    class Test_Subclass_0:
        distribution = 'Test'
        platform = 'test'
    class Test_Subclass_1:
        distribution = 'Subclass_0'
        platform = 'test'
    class Test_Subclass_2:
        distribution = 'Subclass_1'
        platform = 'test'
    class Test_Subclass_3:
        distribution = 'Subclass_2'
        platform = 'test'
    class Test_Subclass_4:
        distribution = 'Subclass_3'
        platform = 'test'
    class Test_Subclass_5:
        distribution = 'Subclass_4'
        platform = 'test'
    class Test_Subclass_6:
        distribution = 'Subclass_5'

# Generated at 2022-06-24 21:01:45.019353
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 21:01:46.243255
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()

    return var_1


# Generated at 2022-06-24 21:01:55.383039
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    this_platform = platform.system()
    distribution = get_distribution()

    subclass = None

    # get the most specific superclass for this platform
    if distribution is not None:
        for sc in get_all_subclasses(UserModuleBase):
            if sc.distribution is not None and sc.distribution == distribution and sc.platform == this_platform:
                subclass = sc
    if subclass is None:
        for sc in get_all_subclasses(UserModuleBase):
            if sc.platform == this_platform and sc.distribution is None:
                subclass = sc
    if subclass is None:
        subclass = UserModuleBase

    return subclass

# Generated at 2022-06-24 21:01:58.047579
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'



# Generated at 2022-06-24 21:02:09.368819
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit tests for function ``get_platform_subclass``
    '''
    import ansible.module_utils.common.linux

    cls = get_platform_subclass(ansible.module_utils.common.linux.User)
    assert(cls == ansible.module_utils.common.linux.User)

    import ansible.module_utils.common.osx

    cls = get_platform_subclass(ansible.module_utils.common.osx.User)
    assert(cls == ansible.module_utils.common.osx.User)

    import ansible.module_utils.common.windows

    cls = get_platform_subclass(ansible.module_utils.common.windows.User)
    assert(cls == ansible.module_utils.common.windows.User)


# Generated at 2022-06-24 21:02:10.739762
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '9.0'


# Generated at 2022-06-24 21:02:31.804219
# Unit test for function get_distribution_version
def test_get_distribution_version():
    os_id = distro.id()
    if os_id == 'redhat':
        version_info = distro.info()
        major_version = version_info.major
    elif os_id == 'centos':
        version_info = distro.info()
        major_version = version_info.major
    elif os_id == 'ubuntu':
        version_info = distro.info()
        major_version = version_info.major
    elif os_id == 'debian':
        version_info = distro.info()
        major_version = version_info.major
    elif os_id == 'suse':
        version_info = distro.info()
        major_version = version_info.major
    elif os_id == 'opensuse':
        version_info = distro.info

# Generated at 2022-06-24 21:02:32.957310
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 21:02:34.211258
# Unit test for function get_distribution_version
def test_get_distribution_version():
    f = get_distribution_version()
    assert f is not None


# Generated at 2022-06-24 21:02:36.584504
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_0 = get_distribution_version()


# Generated at 2022-06-24 21:02:39.762460
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Get the codename of the test distribution
    codename = get_distribution_codename()

    assert codename is not None, 'Failed to get_distribution_codename'



# Generated at 2022-06-24 21:02:40.982043
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert (get_distribution_codename( ) == get_distribution_codename( ))

# Generated at 2022-06-24 21:02:42.117379
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert callable(get_platform_subclass)

# Generated at 2022-06-24 21:02:42.964212
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()

# Generated at 2022-06-24 21:02:44.558540
# Unit test for function get_distribution
def test_get_distribution():
    assert isinstance(test_case_0(), str)


# Generated at 2022-06-24 21:02:54.600674
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestCls:
        pass

    assert(get_platform_subclass(TestCls) == TestCls)

    class TestClsSubclass1(TestCls):
        distribution = 'Redhat'
        platform = 'Linux'
        
    class TestClsSubclass1(TestCls):
        distribution = 'Debian'
        platform = 'Linux'
    
    class TestClsSubclass2(TestCls):
        distribution = 'Redhat'
        platform = 'Linux'
    
    class TestClsSubclass3(TestCls):
        platform = 'Linux'

    class TestClsSubclass4(TestCls):
        platform = 'Linux'
        distribution = 'OtherLinux'

    assert(get_platform_subclass(TestCls) == TestCls)

# Generated at 2022-06-24 21:03:17.927366
# Unit test for function get_distribution
def test_get_distribution():
    assert None is get_distribution()



# Generated at 2022-06-24 21:03:27.769952
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic

    lsb_release_info_value = {
        'distributor_id': 'Ubuntu',
        'description': 'Ubuntu 16.04.2 LTS',
        'release': '16.04',
        'codename': 'xenial',
    }


# Generated at 2022-06-24 21:03:31.537743
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distro = get_distribution_codename()
    if distro is not None:
        return 0
    else:
        return None

# Generated at 2022-06-24 21:03:33.176270
# Unit test for function get_distribution_version
def test_get_distribution_version():
    expected = ''
    actual = get_distribution_version()
    assert actual == expected


# Generated at 2022-06-24 21:03:37.409540
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print(get_distribution_codename())

if __name__ == '__main__':
    test_case_0()
    test_get_distribution_codename()

# Generated at 2022-06-24 21:03:38.379328
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    test_case_0()

# Generated at 2022-06-24 21:03:42.828697
# Unit test for function get_distribution_version
def test_get_distribution_version():
    output = get_distribution_version()
    ansible_current_platform = platform.system()
    ansible_current_distribution = get_distribution()
    if ansible_current_platform == 'Linux':
        if ansible_current_distribution in ['Centos', 'Redhat', 'Amazon']:
            assert output in ['7.5', '8']
        elif ansible_current_distribution == 'Debian':
            assert output in ['9', '10']
        else:
            assert output == ''
    elif ansible_current_platform == 'FreeBSD':
        assert output == '12'
    elif ansible_current_platform == 'OpenBSD':
        assert output == '6.4'
    elif ansible_current_platform == 'NetBSD':
        assert output == '8.0'
   

# Generated at 2022-06-24 21:03:47.728943
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass


# Generated at 2022-06-24 21:03:48.746343
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:03:51.111554
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 21:04:14.039483
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-24 21:04:15.553312
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    cls = get_platform_subclass()
    assert cls is not None


# Generated at 2022-06-24 21:04:17.776254
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version()

# Generated at 2022-06-24 21:04:22.985688
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test for the get_distribution_version function
    '''

    # Unit test for function get_distribution_version
    # Test with id() being a specific distribution
    # Test with version() being None
    # Test with version() being a specific version

    pass

# Generated at 2022-06-24 21:04:26.005575
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # Test of a simple call to the function
    print('Test of a simple call to the function')
    test_case_0()

# Unit test execution
if __name__ == '__main__':
    test_get_platform_subclass()

# Generated at 2022-06-24 21:04:29.135914
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    assert isinstance(get_platform_subclass(DistributionFactCollector), DistributionFactCollector)

# Generated at 2022-06-24 21:04:32.901486
# Unit test for function get_distribution_version
def test_get_distribution_version():
    if platform.system() == 'Linux':
        assert get_distribution_version() is not None
    else:
        assert get_distribution_version() is None


# Generated at 2022-06-24 21:04:33.805776
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-24 21:04:37.613735
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    sample_cls = User
    sys_platform = 'Windows'
    sample_cls.platform = sys_platform
    sample_sc = get_platform_subclass(sample_cls)
    assert sample_sc.platform == sys_platform

# Generated at 2022-06-24 21:04:43.579359
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    if __name__ == '__main__':
        test_case_0()
        test_get_distribution_version()


# Generated at 2022-06-24 21:05:06.869991
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()
    assert var_1 == 'Darwin'



# Generated at 2022-06-24 21:05:15.660876
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts import abstract

    var_1 = abstract.User()
    print("")
    print("var_1:", var_1)

    cls_1 = get_platform_subclass(type(var_1))
    print("")
    print("cls_1:", cls_1)


if __name__ == '__main__':
    print("")
    print("test_get_platform_subclass")
    test_get_platform_subclass()

# Generated at 2022-06-24 21:05:16.805834
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:05:20.635249
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    ansible_user = get_platform_subclass(User)
    assert ansible_user.__name__ == 'User'



# Generated at 2022-06-24 21:05:21.905748
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert str(get_distribution_codename()) is not None



# Generated at 2022-06-24 21:05:26.940478
# Unit test for function get_distribution
def test_get_distribution():
    var_1 = get_distribution()
    assert var_1 == True


# Generated at 2022-06-24 21:05:28.011805
# Unit test for function get_distribution_version
def test_get_distribution_version():
    var_1 = get_distribution_version()


# Generated at 2022-06-24 21:05:35.724664
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule(argument_spec={})

    # Test normal cases
    am.run_command = lambda *args, **kwargs: (0, 'Debian', '')
    assert am.get_platform_subclass() == 'AnsibleModule'

    am.run_command = lambda *args, **kwargs: (0, 'RedHat', '')
    assert am.get_platform_subclass() == 'AnsibleModule'

    am.run_command = lambda *args, **kwargs: (0, 'Amazon', '')
    assert am.get_platform_subclass() == 'AnsibleModule'

    am.run_command = lambda *args, **kwargs: (0, 'FreeBSD', '')
    assert am.get_platform_sub

# Generated at 2022-06-24 21:05:36.830797
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    var_0 = get_distribution_codename()


# Generated at 2022-06-24 21:05:45.537443
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # 0: Debian
    # 1: RHEL
    # 2: Ubuntu
    # 3: Amazon
    # 4: CentOS
    # 5: Fedora
    # 6: OpenSUSE/SUSE Linux Enterprise Server
    # 7: FreeBSD
    # 8: Solaris
    # 9: AIX
    # 10: macOS
    # 11: Microsoft Windows
    # 12: OSX
    # 13: OSX
    # 14: OSX
    # 15: OSX
    # 16: OSX
    # 17: macOS
    # 18: macOS
    # 19: macOS
    from distro import linux_distribution
    from platform import system
    from ansible.module_utils.common._utils import to_text

    linux_distributions = ['debian', 'redhat', 'ubuntu', 'amazon']
    linux_distro_id_