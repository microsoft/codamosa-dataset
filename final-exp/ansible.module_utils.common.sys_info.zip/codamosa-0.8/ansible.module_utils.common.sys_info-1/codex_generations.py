

# Generated at 2022-06-11 01:29:50.453530
# Unit test for function get_distribution

# Generated at 2022-06-11 01:30:02.026107
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform

    class base:
        pass

    class derived1(base):
        pass

    class derived2(base):
        pass

    class derived1_1(derived1):
        pass

    class derived1_1_1(derived1_1):
        pass

    class derived1_1_1_1(derived1_1_1):
        pass

    # return of get_platform_subclass without implementation
    assert base == get_platform_subclass(base)

    # return of get_platform_subclass with implementation
    assert derived1 == get_platform_subclass(base, derived1)

    # return of get_platform_subclass with two implementations
    assert derived2 == get_platform_subclass(base, derived1, derived2)

    # return of get_platform_subclass with two implementations with common ancestor
   

# Generated at 2022-06-11 01:30:12.915273
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Code to test that the get_platform_subclass should be able to return the correct
    class for the platform and distribution.
    '''
    from ansible.module_utils.six import with_metaclass

    class Base(with_metaclass(type, object)):
        platform = 'Linux'
        distribution = None

    class BaseLinux(Base):
        pass

    class BaseRedHat(BaseLinux):
        distribution = 'Redhat'

    class BaseUbuntu(BaseLinux):
        distribution = 'Ubuntu'

    class BaseGeneric(Base):
        platform = 'Generic'

    platform = get_platform_subclass(Base)
    assert platform == Base, "Expected Base, got %s" % str(platform)

    platform = get_platform_subclass(BaseLinux)

# Generated at 2022-06-11 01:30:13.505779
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-11 01:30:23.915127
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Use this function to test the get_distribution_codename function defined above.
    Requirements for this function to pass:
      1)  Have ansible installed.
      2)  Set the 'ANSIBLE_CHECK_COMMAND' environment variable to the path of 'ansible-playbook'

    Usage:
        ansible-playbook -i ./hosts -K tests/unit/lib/ansible/module_utils/basic_distro_tests.py
    '''
    # This will cause the unit test to fail if this is not a Linux machine.
    try:
        platform.linux_distribution
    except:
        assert False

    distribution_codename = get_distribution_codename()
    # This will cause the unit test to fail if the distribution codename cannot be determined
    # on Linux.
    assert distribution_cod

# Generated at 2022-06-11 01:30:34.371378
# Unit test for function get_platform_subclass

# Generated at 2022-06-11 01:30:45.327895
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Return the code name for this Linux Distribution

    :rtype: NativeString or None
    :returns: A string representation of the distribution's codename or None if not a Linux distro
    '''
    from ansible.module_utils.common._utils import get_distribution_codename
    codename = None
    if platform.system() == 'Linux':
        # Until this gets merged and we update our bundled copy of distro:
        # https://github.com/nir0s/distro/pull/230
        # Fixes Fedora 28+ not having a code name and Ubuntu Xenial Xerus needing to be "xenial"
        os_release_info = distro.os_release_info()
        codename = os_release_info.get('version_codename')

        if codename is None:
            codename = os

# Generated at 2022-06-11 01:30:46.980138
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Fedora'

# Generated at 2022-06-11 01:30:48.946267
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    assert get_distribution_codename() == 'xenial'
    # TODO: Add more test cases

# Generated at 2022-06-11 01:30:59.247296
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    class TestNativeLinux:
        platform = "Linux"
        distribution = None
    assert get_platform_subclass(TestNativeLinux) == TestNativeLinux
    class TestNativeLinuxCentos:
        platform = "Linux"
        distribution = "Centos"
    assert get_platform_subclass(TestNativeLinuxCentos) == TestNativeLinuxCentos
    class TestNativeLinuxCentos7:
        platform = "Linux"
        distribution = "Centos"
        version = "7"
    assert get_platform_subclass(TestNativeLinuxCentos7) == TestNativeLinuxCentos7

    class TestNativeLinuxRedhat7:
        platform = "Linux"
        distribution = "Redhat"
        version = "7"
    assert get_platform_subclass(TestNativeLinuxRedhat7) == TestNativeLinuxCentos7



# Generated at 2022-06-11 01:31:11.466016
# Unit test for function get_distribution
def test_get_distribution():
    if platform.system() == 'Linux':

        platform_dist = platform.linux_distribution()
        if platform_dist[0] == '':
            expected_distribution = 'OtherLinux'
        else:
            expected_distribution = platform_dist[0].capitalize()

        this_distribution = get_distribution()

        assert this_distribution == expected_distribution, "Expected: %s, Got: %s" % (expected_distribution, this_distribution)

# Generated at 2022-06-11 01:31:21.490315
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        platform = 'foo'
        distribution = None

    class B(A):
        pass

    class C(B):
        pass

    class D:
        platform = 'bar'
        distribution = None

    class E(D):
        pass

    class F(D):
        distribution = 'foobar'

    class G(F):
        pass

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == C
    assert get_platform_subclass(C) == C
    assert get_platform_subclass(D) == D
    assert get_platform_subclass(E) == E
    assert get_platform_subclass(F) == G

# Generated at 2022-06-11 01:31:30.500337
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base(object):
        platform = 'Generic'
        distribution = None

    class Linux(Base):
        pass

    class LinuxDistribution(Base):
        distribution = 'Generic'

    class LinuxDistributionPlatform(Base):
        distribution = 'Generic'
        platform = 'Generic'

    assert get_platform_subclass(Base) is Base
    assert get_platform_subclass(Linux) is Linux
    assert get_platform_subclass(LinuxDistribution) is LinuxDistribution
    assert get_platform_subclass(LinuxDistributionPlatform) is LinuxDistributionPlatform

    class LinuxDistributionClass(LinuxDistribution):
        platform = 'Linux'

    class LinuxDistributionPlatformClass(LinuxDistributionPlatform):
        distribution = 'Linux'
        platform = 'Linux'

    assert get_platform_subclass(LinuxDistributionClass) is LinuxDist

# Generated at 2022-06-11 01:31:43.220809
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Make sure that get_distribution() returns the correct values.

    :rtype: str
    :returns: A message informing the user if the test passed or failed.

    The values to test are dependent on the distribution the test suite is running on.
    '''
    if distro.id().capitalize() == 'Centos':
        if get_distribution() != 'Centos':
            return 'Wrong distribution returned from get_distribution().'
    elif distro.id().capitalize() == 'Fedora':
        if get_distribution() != 'Fedora':
            return 'Wrong distribution returned from get_distribution().'
    else:
        return 'The test suite must be run on a Centos or Fedora machine to test get_distribution().'


# Generated at 2022-06-11 01:31:53.210227
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest

    class TestClass(object):
        platform = ''
        distribution = ''

    class TestLinux(TestClass):
        platform = 'Linux'
        distribution = 'SomeLinux'

    class TestOtherLinux(TestClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class TestMacOSX(TestClass):
        platform = 'Darwin'

    class TestUnsupportedPlatform(TestClass):
        platform = 'I am unique'

    class TestLinuxSubclass(TestLinux):
        distribution = 'SomeLinuxSubClass'

    class TestOtherLinuxSubclass(TestOtherLinux):
        distribution = 'OtherLinuxSubClass'

    class TestMacOSXSubclass(TestMacOSX):
        platform = 'Darwin'


# Generated at 2022-06-11 01:32:04.636810
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest

    class MySuperClass:
        pass

    class MyClass1(MySuperClass):
        distribution = 'foo'
        platform = 'bar'

    class MyClass2(MySuperClass):
        distribution = 'foo'
        platform = 'baz'

    class MyClass3(MySuperClass):
        distribution = 'quux'
        platform = 'bar'

    class MyClass4(MySuperClass):
        platform = 'baz'

    platform.system = lambda: 'bar'
    get_distribution = lambda: 'foo'
    assert MyClass1 == get_platform_subclass(MySuperClass)

    platform.system = lambda: 'bar'
    get_distribution = lambda: 'quux'
    assert MyClass3 == get_platform_subclass(MySuperClass)

    platform.system

# Generated at 2022-06-11 01:32:06.842223
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Make sure we always return a known value
    '''
    assert get_distribution()



# Generated at 2022-06-11 01:32:08.659779
# Unit test for function get_distribution
def test_get_distribution():
    '''Test get_distribution function'''
    return get_distribution()

# Generated at 2022-06-11 01:32:10.962055
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''

    assert get_distribution_codename() is None



# Generated at 2022-06-11 01:32:20.906159
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Base(object):
        platform = 'BasePlatform'
        distribution = None

    class BasePlatform(Base):
        platform = 'BasePlatform'
        distribtuion = None

    class RedHat(BasePlatform):
        platform = 'Linux'
        distribution = 'Redhat'

    class OtherLinux(BasePlatform):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class FreeBSD(BasePlatform):
        platform = 'FreeBSD'
        distribution = None

    class NetBSD(BasePlatform):
        platform = 'NetBSD'
        distribution = None

    class OpenBSD(BasePlatform):
        platform = 'OpenBSD'
        distribution = None

    class Darwin(BasePlatform):
        platform = 'Darwin'
        distribution = None


# Generated at 2022-06-11 01:32:35.174516
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # class User:
    #    pass
    # this does not work here, as get_platform_subclass needs a proper class
    # with attributes and methods
    assert get_platform_subclass(platform.system) == platform.system

# Generated at 2022-06-11 01:32:46.945862
# Unit test for function get_distribution

# Generated at 2022-06-11 01:32:54.747157
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # This is a test for the get_platform_subclass function.

    # pylint: disable=too-few-public-methods
    class TestBase():
        """
        Test Class Base
        """
        platform = 'Posix'
        distribution = None

    # pylint: disable=too-few-public-methods
    class TestOne(TestBase):
        """
        Test Class One
        """
        platform = 'Linux'
        distribution = 'Redhat'

    # pylint: disable=too-few-public-methods
    class TestTwo(TestBase):
        """
        Test Class Two
        """
        platform = 'Linux'
        distribution = None

    # pylint: disable=too-few-public-methods

# Generated at 2022-06-11 01:33:07.740560
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test method to test the get_distribution_codename()
    '''
    codenames = [
        'xenial',
        'bionic',
        'bullseye',
        'sid',
    ]

    for codename in codenames:
        os_release = {
            'VERSION_CODENAME': codename,
            'UBUNTU_CODENAME': codename
        }
        lsb_release_info = {
            'codename': codename
        }
        distro.os_release_info = lambda: os_release
        distro.lsb_release_info = lambda: lsb_release_info
        actual_codename = get_distribution_codename()

# Generated at 2022-06-11 01:33:18.800929
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import platform
    import os
    import sys
    import subprocess
    if platform.system() == 'Linux':
        version = get_distribution_version()
        if version == '':
            print('Cannot get distribution version')
            sys.exit(1)
        else:
            print('Distribution version is %s' % version)
        # run distro.version() from distro package directly
        current_dir = os.path.dirname(os.path.realpath(__file__))
        distro_version_test_py = os.path.join(current_dir, 'distro_version_test.py')
        r = subprocess.check_output([sys.executable, distro_version_test_py])

# Generated at 2022-06-11 01:33:29.406320
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Red Hat Enterprise Linux
    rhel_7_4 = {'NAME': 'Red Hat Enterprise Linux Server',
                'ID': 'rhel',
                'VERSION_ID': '7.4',
                'VERSION_CODENAME': 'Maipo',
                'PRETTY_NAME': 'Red Hat Enterprise Linux Server 7.4 (Maipo)',
                'ANSI_COLOR': '0;31',
                'CPE_NAME': 'cpe:/o:redhat:enterprise_linux:7.4:GA:server'}
    assert get_distribution_codename() == rhel_7_4['VERSION_CODENAME']

    # Fedora

# Generated at 2022-06-11 01:33:38.362142
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class A(object):
        platform = 'Linux'
        distribution = None

    class B(A):
        distribution = 'Debian'

    class C(B):
        platform = 'Windows'

    class D(A):
        pass

    class E(A):
        distribution = 'Debian'

    class F(A):
        platform = 'Windows'

    def test(cls):
        assert get_platform_subclass(cls) == cls

    test(A)
    test(B)
    test(C)
    test(D)
    test(E)
    test(F)


# Generated at 2022-06-11 01:33:46.686468
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        '''This is the base class for unit testing'''
        platform = 'Linux'
        distribution = None
    class Subclass1(BaseClass):
        '''This is the first subclass for unit testing'''
        distribution = 'RedHat'
    class Subclass2(BaseClass):
        '''This is the second subclass for unit testing'''
        distribution = 'Debian'
    class Subclass3(BaseClass):
        '''This is the third subclass for unit testing'''
        distribution = 'Amazon'
    class Subclass4(BaseClass):
        '''This is the fourth subclass for unit testing'''
        platform = 'Darwin'

    # Test that we get 'OtherLinux' if we don't know the Linux distribution
    get_distribution_orig = distro.id

# Generated at 2022-06-11 01:33:55.548833
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    if platform.system() == "Linux":
        codename = get_distribution_codename()
        if codename is None:
            raise AssertionError("get_distribution_codename() should not return None for Linux. It returned (%s)" % codename)
        if not isinstance(codename, str):
            raise AssertionError("get_distribution_codename() should return a str. It returned (%s)" % type(codename))
        if not codename:
            raise AssertionError("get_distribution_codename() should not return an empty str. It returned (%s)" % codename)

# Generated at 2022-06-11 01:33:57.894984
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test for function get_distribution
    '''
    assert get_distribution() == "OpenSuse"


# Generated at 2022-06-11 01:34:30.692493
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class machineA(object):
        platform = 'A'
        distribution = 'ONE'

    class machineB(object):
        platform = 'B'
        distribution = 'TWO'

    class machineC(object):
        platform = 'C'
        distribution = 'ONE'

    class machineD(object):
        platform = 'C'
        distribution = None

    class machineE(object):
        platform = 'B'
        distribution = None

    class machineF(object):
        platform = 'A'
        distribution = None

    class machineG(object):
        platform = 'A'
        distribution = 'THREE'

    class machineH(object):
        platform = 'A'
        distribution = 'TWO'

    class machineI(object):
        platform = 'C'
        distribution = 'TWO'


# Generated at 2022-06-11 01:34:33.504581
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    old_platform_system = platform.system
    platform.system = lambda: 'Linux'
    try:
        assert get_distribution_codename() is not None
    finally:
        platform.system = old_platform_system

# Generated at 2022-06-11 01:34:40.839219
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function to see if the return value of get_distribution_codename() is accurate.
    '''
    import re
    codename_regex = re.compile(r"^[a-z]+$")

    if platform.system() == 'Linux':
        codename = get_distribution_codename()

        if codename_regex.match(codename):
            return 'PASS'
        else:
            return 'FAIL'
    else:
        return 'FAIL'

# Generated at 2022-06-11 01:34:52.487332
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    from ansible.module_utils.facts import module_facts
    from ansible.module_utils.facts.system.distribution import Distribution, System

    # Engine implementation for BSD
    class BSD(System):
        platform = 'OpenBSD'

    # Engine implementation for Linux
    class Linux(System):
        platform = 'Linux'

    # Engine implementation for Red Hat
    class RedHat(Distribution):
        platform = 'Linux'
        distribution = 'RedHat'

    # Engine implementation for Debian
    class Debian(Distribution):
        platform = 'Linux'
        distribution = 'Debian'

    class MyClass():
        pass

    # Create a fake module object with the above class
    fake_module = type('module', (object,), {'params': {}})
    fake_module.__class__ = MyClass

    # Create

# Generated at 2022-06-11 01:35:00.624455
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class SuperClass:
        pass
    class SubClass1(SuperClass):
        platform = 'Linux'
        distribution = 'OtherLinux'
    class SubClass2(SuperClass):
        platform = 'Linux'
        distribution = None
    class SubClass3(SuperClass):
        platform = 'Linux'
        distribution = 'Amazon'
    class SubClass4(SuperClass):
        platform = 'Darwin'
        distribution = None
    # other class
    class SubClass5(SuperClass):
        platform = 'Linux'
        distribution = 'not_exit_distro'
    class SubClass6(SuperClass):
        platform = 'not_exit_Platform'
        distribution = None

    assert get_platform_subclass(SuperClass) == SuperClass
    assert get_platform_subclass(SuperClass) != SubClass1
    assert get

# Generated at 2022-06-11 01:35:12.584974
# Unit test for function get_distribution_version
def test_get_distribution_version():
    class TestDistroIdVersion(object):
        id = None
        version = None
        @classmethod
        def best_version(cls):
            return u'OtherLinux'

    distro.id = lambda: TestDistroIdVersion.id
    distro.version = lambda: TestDistroIdVersion.version
    distro.version.__func__ = distro.version
    distro.version = distro.version()
    version = get_distribution_version()
    assert version is None

    # test Redhat distro
    TestDistroIdVersion.id = u'Rhel'
    TestDistroIdVersion.version = u'7'
    assert u'7' == get_distribution_version()
    TestDistroIdVersion.version = u'7.2'
    assert u'7.2' == get_

# Generated at 2022-06-11 01:35:16.582817
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # With /etc/os-release present and with version in it
    assert get_distribution_version() == '14.04'
    # With /etc/os-release present and without version in it
    assert get_distribution_version() == '14.04'

# Generated at 2022-06-11 01:35:21.053724
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Return the code name for this Linux Distribution

    :rtype: NativeString or None
    :returns: A string representation of the distribution's codename or None if not a Linux distro
    '''
    codename = get_distribution_codename()
    if codename is None:
        return codename
    else:
        return codename.lower()

# Generated at 2022-06-11 01:35:32.789496
# Unit test for function get_distribution
def test_get_distribution():
    import platform
    import pprint

    if platform.system() == 'Linux':
        platform_distro = platform.dist()

        # Convert tuple to a dictionary
        platform_distro = dict(zip(['id', 'version', 'id_like', 'version_like', 'like'], platform_distro))

        linux_distributions = ['Alpine', 'Amazon', 'Arch', 'Centos', 'Debian', 'Fedora', 'Gentoo', 'Linuxmint', 'Macosx', 'Mandrake', 'Mageia', 'Oel', 'Oracle', 'Pld', 'Redhat', 'Slackware', 'Solaris', 'Suse', 'Ubuntu', 'Xenserver', 'Zos', 'Aix', 'Hpux', 'Misc']
        distribution = get_distribution()

# Generated at 2022-06-11 01:35:34.126018
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'



# Generated at 2022-06-11 01:36:19.473675
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:36:29.676865
# Unit test for function get_distribution_version
def test_get_distribution_version():

    def _validate_version(os_release_data, lsb_release_data, dist_version, dist_id, dist_version_best):
        distro.os_release_info = lambda: os_release_data
        distro.lsb_release_info = lambda: lsb_release_data
        distro.id = lambda: dist_id
        distro.version = lambda best=False: dist_version if not best else dist_version_best
        real_version = get_distribution_version()
        assert real_version == dist_version

    # Test for Ubuntu Xenial (16.04) with /etc/os-release, /etc/lsb-release and non-vendor case

# Generated at 2022-06-11 01:36:31.156570
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Simple unit test for function get_distribution_codename
    '''
    assert get_distribution_codename() == None
    assert get_distribution_codename()


# Generated at 2022-06-11 01:36:32.761286
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    expected = u'xenial'
    codename = get_distribution_codename()
    assert (expected == codename)

# Generated at 2022-06-11 01:36:42.967348
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test for the get_platform_subclass function
    '''
    import sys
    import platform

    # Set up a dummy class hierarchy and a dummy subclass
    class DummyBase(object):
        platform = None
        distribution = None

    class DummySub1(DummyBase):
        platform = platform.system()

    class DummySub2(DummyBase):
        platform = 'Linux'

    class DummySub3(DummyBase):
        platform = platform.system()
        distribution = get_distribution()

    # Save our platform, distro and python version so we can restore it later
    orig_platform = platform.system()
    orig_distro = get_distribution()
    orig_python_version = sys.version_info

    # Test 1: No subclass
    # Test that we can get a subclass when

# Generated at 2022-06-11 01:36:54.740134
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class SuperClass(object):
        platform = "ThisPlatform"
        distribution = None

    class SuperClassLinux(SuperClass):
        platform = "Linux"

    class SuperClassLinuxDebian(SuperClassLinux):
        distribution = "Debian"

    class SuperClassLinuxUbuntu(SuperClassLinux):
        distribution = "Ubuntu"

    class SuperClassLinuxCentos(SuperClassLinux):
        distribution = "CentOS"


    class TestClass(SuperClass):
        pass

    class TestClassLinux(TestClass):
        platform = "Linux"

    class TestClassLinuxDebian(TestClassLinux):
        distribution = "Debian"

    class TestClassLinuxUbuntu(TestClassLinux):
        distribution = "Ubuntu"

    class TestClassLinuxCentos(TestClassLinux):
        distribution = "CentOS"


# Generated at 2022-06-11 01:37:01.977860
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BasePlatform:
        platform = None
        distribution = None

    class LinuxPlatform(BasePlatform):
        platform = 'Linux'
        distribution = None

    class RedHatPlatform(LinuxPlatform):
        distribution = 'RedHat'

    class FreeBSDPlatform(BasePlatform):
        platform = 'FreeBSD'
        distribution = None

    class OtherLinuxPlatform(LinuxPlatform):
        distribution = 'OtherLinux'

    assert get_platform_subclass(BasePlatform) is BasePlatform
    assert get_platform_subclass(LinuxPlatform) is LinuxPlatform
    assert get_platform_subclass(FreeBSDPlatform) is FreeBSDPlatform
    assert get_platform_subclass(RedHatPlatform) is RedHatPlatform
    assert get_platform_subclass(OtherLinuxPlatform) is OtherLinuxPlatform

    # On Dis

# Generated at 2022-06-11 01:37:14.623698
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import os
    import shutil
    import tempfile
    import unittest

    from ansible.module_utils.common._collections_compat import Mapping


# Generated at 2022-06-11 01:37:22.143597
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    import platform
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.common.os

    class B(object):
        pass

    class A(object):
        pass

    class C(A):
        platform = 'Linux'
        distribution = 'Redhat'

    class D(A):
        platform = 'Linux'
        distribution = 'Amazon'

    class E(A):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class F(A):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class G(A):
        platform = 'Linux'
        distribution = None

    class H(A):
        platform = 'Linux'
        distribution = None

    class I(A):
        platform = None

# Generated at 2022-06-11 01:37:25.236256
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Distribution function returns distribution name
    '''
    distribution = get_distribution()
    assert distribution == distro.id().capitalize()


# Generated at 2022-06-11 01:38:11.460558
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Super:
        pass

    class Subclass(Super):
        platform = 'Linux'

    assert Subclass == get_platform_subclass(Super)



# Generated at 2022-06-11 01:38:19.482241
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test Module class before inheritance
    assert get_platform_subclass(Module) == Module

    # Test Module subclass with one distribution (Debian)
    class ModuleDebian(Module):
        distribution = 'Debian'
        platform = 'Linux'
    assert get_platform_subclass(ModuleDebian) == ModuleDebian

    class ModuleDebianCentOS(ModuleDebian):
        distribution = 'CentOS'
        platform = 'Linux'
    assert get_platform_subclass(ModuleDebianCentOS) == ModuleDebianCentOS

    # Test Module subclass with one distribution (Debian) and one (CentOS)
    class ModuleDebianCentOS(ModuleDebian):
        distribution = 'CentOS'
        platform = 'Linux'
    assert get_platform_subclass(ModuleDebianCentOS) == ModuleDebianCentOS

    # Test

# Generated at 2022-06-11 01:38:27.576522
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test get_distribution_codename()
    '''

    assert get_distribution_codename() is None, 'This is not a Linux distribution'

    # On Fedora
    codename_fedora_28 = {
        'like': 'fedora',
        'name': 'Fedora',
        'id': 'fedora',
        'version_id': '28',
        'variant': '',
        'pretty_name': 'Fedora 28 (Server Edition)',
        'version': '28 (Server Edition)',
        'codename': ''
    }

# Generated at 2022-06-11 01:38:28.758256
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:38:32.289043
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils import basic

    # Make sure that that the get_distribution function returns the expected
    # distribution name
    assert basic.get_distribution() == platform.system()



# Generated at 2022-06-11 01:38:42.321134
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    def mock_os_release_info(self):
        return {
            'ansible_os_family': 'RedHat',
            'name': 'CentOS Linux',
            'id': 'centos',
            'id_like': 'rhel fedora',
            'version': '8.2.2004',
            'version_codename': 'Ootpa',
        }

    def mock_lsb_release_info(self):
        return {
            'ansible_lsb': {
                'codename': 'stretch',
            },
        }

    def mock_codename(self):
        return ''

    monkeypatch.setattr(distro.RhelDistro, 'os_release_info', mock_os_release_info)

# Generated at 2022-06-11 01:38:43.204290
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Amazon'

# Generated at 2022-06-11 01:38:54.548438
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform

    class A:
        platform = 'OldTest'

    class B(A):
        platform = 'Test'

    class C(B):
        pass

    class D(A):
        platform = 'Test'
        distribution = 'Dist'

    class E(D):
        distribution = 'Dist'

    class A1:
        platform = 'Test'

    class B1(A1):
        pass

    class C1(B1):
        distribution = None

    class A2:
        platform = 'Other'

    class B2(A2):
        platform = 'Other'

    class C2(B2):
        platform = 'Other'
        distribution = 'Dist'

    class D2(C2):
        platform = 'Other'
        distribution = 'Dist'


# Generated at 2022-06-11 01:38:56.659696
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    result = get_distribution_codename()
    assert result == 'xenial', 'Got: %s' % result

# Generated at 2022-06-11 01:39:07.268735
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo:
        platform = 'Foo'
        distribution = None

    class FooLinux(Foo):
        platform = 'Linux'

    class FooLinuxRedhat(FooLinux):
        distribution = 'Redhat'

    class FooLinuxRedhat6(FooLinuxRedhat):
        distribution_version = '6'

    class FooLinuxRedhat7(FooLinuxRedhat):
        distribution_version = '7'

    class FooLinuxDebian(FooLinux):
        distribution = 'Debian'

    class FooLinuxDebian8(FooLinuxDebian):
        distribution_version = '8'

    class FooLinuxDebian9(FooLinuxDebian):
        distribution_version = '9'

    class BarLinuxRedhat7(FooLinuxRedhat):
        distribution = 'Bar'

    assert get_platform_sub