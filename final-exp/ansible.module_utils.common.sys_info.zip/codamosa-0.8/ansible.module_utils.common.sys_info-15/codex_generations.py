

# Generated at 2022-06-11 01:29:52.183148
# Unit test for function get_distribution
def test_get_distribution():
    if platform.system() == 'Linux':
        distro_id = get_distribution()
        assert distro_id in ('Amazon', 'Centos', 'Debian', 'Fedora', 'Freebsd', 'Oracle', 'Redhat', 'OtherLinux', 'Sles', 'Ubuntu'), \
            "get_distribution failed to return one of the expected values. returned %s" % distro_id
    else:
        distro_id = get_distribution()
        assert distro_id in ('Darwin', 'Freebsd', 'Sunos'), \
            "get_distribution failed to return one of the expected values. returned %s" % distro_id


# Generated at 2022-06-11 01:29:55.008860
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    """ Test get_distribution_codename function """
    distribution_codename = get_distribution_codename()
    assert distribution_codename is not None

# Generated at 2022-06-11 01:30:02.525955
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    """
    Verify that asking for codename returns the expected, or empty string;
    """
    # get_distribution_codename() uses distro()
    # distro() assumes multiple Linux Distros.
    # distro() returns None for other systems, just in case test driven on macOS or Windows
    assert get_distribution_codename() is None
    # distro() requires a working /etc/os-release file on Linux
    # return empty string instead of None if this fails;
    assert get_distribution_codename() == ''

# Generated at 2022-06-11 01:30:13.291874
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base_class:
        platform = "Base"

    class Linux_class(Base_class):
        platform = "Linux"

    class Debian_class(Linux_class):
        distribution = "Debian"

    class Redhat_class(Linux_class):
        distribution = "Redhat"

    class Other_Linux_class(Linux_class):
        distribution = "OtherLinux"

    class BSD_class(Base_class):
        platform = "BSD"

    class Darwin_class(BSD_class):
        platform = "Darwin"

    class Other_class(Base_class):
        platform = "Other"

    # No Distribution
    platform.system = lambda: "Linux"
    distribution = get_distribution()
    assert distribution is None
    cls = get_platform_subclass(Base_class)
    assert cls

# Generated at 2022-06-11 01:30:23.691532
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''Test function get_platform_subclass'''
    class A:
        "A"

    class B(A):
        "B"

    class C(B):
        "C"

    class D(C):
        "D"

    class E(D):
        "E"

    class F(E):
        "F"

    class TestBaseClass:
        "Base class for unit testing"

        platform = None
        distribution = None

    class TestSubClassA(TestBaseClass):
        "Subclass of TestBaseClass for unit testing"

        platform = 'Windows'
        distribution = None

    class TestSubClassB(TestBaseClass):
        "Subclass of TestBaseClass for unit testing"

        platform = None
        distribution = 'B'


# Generated at 2022-06-11 01:30:34.001214
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass
    class LinuxBase(Base):
        platform = 'Linux'
        distribution = None
    class BSDBase(Base):
        platform = 'BSD'
        distribution = None
    class LinuxDistroBase(Base):
        platform = 'Linux'
    class LinuxDistroOne(LinuxDistroBase):
        distribution = 'DistroOne'
    class LinuxDistroTwo(LinuxDistroBase):
        distribution = 'DistroTwo'
    class LinuxAnotherDistro(LinuxDistroBase):
        distribution = 'AnotherDistro'
    class OtherLinuxDistro(LinuxDistroBase):
        distribution = 'OtherLinux'
    class BSDDistroBase(Base):
        platform = 'BSD'
    class BSDDistroOne(BSDDistroBase):
        distribution = 'DistroOne'

# Generated at 2022-06-11 01:30:35.668122
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    print(codename)


# Generated at 2022-06-11 01:30:41.459526
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    PLATFORM_DEBIAN9 = '''
    NAME="Debian GNU/Linux"
    VERSION_ID="9"
    VERSION="9 (stretch)"
    ID=debian
    HOME_URL="https://www.debian.org/"
    SUPPORT_URL="https://www.debian.org/support"
    BUG_REPORT_URL="https://bugs.debian.org/"
    '''

# Generated at 2022-06-11 01:30:53.332544
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class base_cls:
        platform = 'TestPlatform'
        distribution = None

    class second_cls(base_cls):
        distribution = 'TestDistribution'

    class third_cls(second_cls):
        distribution = 'TestDistribution2'

    class fourth_cls(base_cls):
        pass

    # Ensure that fourth_cls is an ancestor of third_cls to test that
    # get_platform_subclass will find the most specific subclass
    assert fourth_cls in third_cls.__mro__

    # Test the base case of no subclasses specified
    assert get_platform_subclass(base_cls) == base_cls

    # Test the case of only one subclass defined
    assert get_platform_subclass(second_cls) == second_cls

    #

# Generated at 2022-06-11 01:31:02.524958
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import sys
    class _Base(object):
        pass
    class _Base_Linux(_Base):
        platform = 'Linux'
    class _Base_Linux_Redhat(_Base_Linux):
        distribution = 'Redhat'
    class _Base_Linux_Debian(_Base_Linux):
        distribution = 'Debian'

    class _Specific_Linux_Redhat(_Base_Linux_Redhat):
        pass

    class _Generic_Linux(_Base_Linux):
        distribution = None
    class _Generic_Unix(_Base):
        platform = 'Unix'
        distribution = None

    class _Specific_Linux(_Generic_Linux):
        pass

    sys.modules[__name__] = _Base
    _Base_Linux.__module__ = __name__
    _Base_Linux_Debian.__module__ = __name__
    _

# Generated at 2022-06-11 01:31:18.752725
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''Function get_distribution_version unit test'''
    platform_system = platform.system()
    if platform_system == 'Linux':
        distro_version = get_distribution_version()
        if distro_version:
            try:
                version_splits = distro_version.split('.')
                version_splits = list(map(int, version_splits))
            except ValueError:
                raise AssertionError("Function get_distribution_version did not return a version number!")
        else:
            raise AssertionError("Function get_distribution_version did not return a version number!")


if __name__ == '__main__':
    test_get_distribution_version()

# Generated at 2022-06-11 01:31:25.510338
# Unit test for function get_distribution
def test_get_distribution():
    distrodict = {
        'Redhat': 'RedHat',
        'SuSE': 'Suse',
        'debian': 'Debian',
        'Ubuntu': 'Ubuntu',
        OtherLinux: 'OtherLinux',
    }
    for distro, o in distrodict.items():
        try:
            distribution = get_distribution()
        except NameError:
            distribution = None
        assert distribution == o, ('Distribution returned %s, expected %s' % (distribution, o))



# Generated at 2022-06-11 01:31:37.948919
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import sys

    class FakeModule():
        platform = sys.platform
        distribution = get_distribution()

    class MyClass: pass
    class MySubClass(MyClass): pass
    class MyLinuxSubClass(MyClass): platform = 'linux'
    class MyDarwinSubClass(MyClass): platform = 'darwin'
    class MyAmazonSubClass(MyClass):
        platform = 'linux'
        distribution = 'Amazon'

    fakemodule = FakeModule()
    assert get_platform_subclass(MyClass) is MyClass

    if fakemodule.platform == 'linux':
        assert get_platform_subclass(MyLinuxSubClass) is MyLinuxSubClass
    else:
        assert get_platform_subclass(MyLinuxSubClass) is MyClass

    if fakemodule.platform == 'darwin':
        assert get_platform_sub

# Generated at 2022-06-11 01:31:39.036559
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:31:50.306478
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # Simple test subclass
    class Platform_A(object):
        platform = "A"
        distribution = None

    # Test platform
    class Platform_A_Test(Platform_A):
        platform = "A_Test"
        distribution = None

    # Test distribution
    class Platform_A_B(Platform_A):
        platform = "A"
        distribution = "B"

    # Test distribution and platform
    class Platform_A_Test_B(Platform_A):
        platform = "A_Test"
        distribution = "B"

    assert get_platform_subclass(Platform_A) == Platform_A
    assert get_platform_subclass(Platform_A_Test) == Platform_A_Test
    assert get_platform_subclass(Platform_A_B) == Platform_A_B
    assert get_platform_subclass

# Generated at 2022-06-11 01:32:00.208730
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = None
        distribution = None

    class PlatformA(Base):
        platform = 'ABC'
        distribution = None

    class PlatformB(Base):
        platform = 'ABC'
        distribution = None

    class DistributionA(Base):
        platform = None
        distribution = 'XYZ'

    class DistributionB(Base):
        platform = None
        distribution = 'XYZ'

    class SpecificA(Base):
        platform = 'ABC'
        distribution = 'XYZ'

    assert SpecificA == get_platform_subclass(SpecificA)
    assert SpecificA == get_platform_subclass(PlatformA)
    assert SpecificA == get_platform_subclass(PlatformB)
    assert SpecificA == get_platform_subclass(DistributionA)

# Generated at 2022-06-11 01:32:02.823033
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == ''

if __name__ == '__main__':
    test_get_distribution_version()

# Generated at 2022-06-11 01:32:09.592972
# Unit test for function get_distribution_version
def test_get_distribution_version():
    my_platform = platform.system()
    my_distribution = get_distribution()
    my_distribution_version = get_distribution_version()
    if my_platform == 'Linux':
        assert type(my_distribution) == str, 'Bad return value'
        assert type(my_distribution_version) == str, 'Bad return value'
    else:
        assert my_distribution is None
        assert my_distribution_version is None

# Generated at 2022-06-11 01:32:11.956236
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
  codename = get_distribution_codename()

  if codename == 'stretch':
    assert True == True
  else:
    assert True == False

# Generated at 2022-06-11 01:32:21.505643
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Validate function get_platform_subclass
    '''
    __test__ = True
    import platform as plat

    class PlatformA(object):
        platform = 'Linux'
        distribution = 'Redhat'

    class PlatformB(object):
        platform = 'Linux'
        distribution = 'Suse'

    class PlatformC(object):
        platform = 'Linux'
        distribution = 'NonExistingDistro'

    class PlatformD(object):
        platform = 'Linux'
        distribution = None

    class PlatformE(object):
        platform = 'FreeBSD'
        distribution = None

    class PlatformF(object):
        platform = 'AIX'
        distribution = None

    class PlatformG(object):
        platform = 'AIX'
        distribution = 'AIX'


# Generated at 2022-06-11 01:32:33.201262
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    """test_get_distribution_codename can be used to find out the code name for
    distribution, which is used in test_get_distribution_subclass.  Make sure
    you set the distribution to your distro
    """
    codename = get_distribution_codename()
    print(codename)

# Generated at 2022-06-11 01:32:37.306606
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        distribution = None
        platform = 'foo'

    class B(A):
        distribution = 'bar'

    class C(A):
        distribution = 'baz'

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == B
    assert get_platform_subclass(C) == C

# Generated at 2022-06-11 01:32:49.098720
# Unit test for function get_distribution
def test_get_distribution():
    # It is easiest to test this by mocking the results of calls to platform.system() and
    # distro.id() but those are staticmethods so they can't be monkeypatched.  Instead,
    # we trap the import of distro and platform
    orig_import = __import__

    def my_import(name, *args, **kwargs):
        # Trap calls to import distro and platform and import them from the same place
        # we did originally.  This allows us to monkeypatch their functions.
        if name == 'distro':
            distro = orig_import('ansible.module_utils.distro')
        elif name == 'platform':
            distro = orig_import('platform')
        # if we aren't trying to import distro or platform, just import the requested module

# Generated at 2022-06-11 01:32:53.024891
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(User) == BSDUser
    assert get_platform_subclass(Group) == BSDGroup

    assert get_platform_subclass(User) == BSDUser
    assert get_platform_subclass(Group) == BSDGroup

if __name__ == '__main__':
    test_get_platform_subclass()

# Generated at 2022-06-11 01:33:06.267868
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common.platform import PlatformGeneric

    # Tests for class with superclass PlatformGeneric
    class PlatformGenericTest(PlatformGeneric):
        platform = 'test'
        distribution = None

    class PlatformGenericTestDistribution(PlatformGeneric):
        platform = 'test'
        distribution = 'test'

    class OtherPlatform(object):
        platform = 'other'
        distribution = None

    class OtherPlatformDistribution(object):
        platform = 'other'
        distribution = 'other'

    class OtherPlatformOtherDistribution(object):
        platform = 'other'
        distribution = 'other_distribution'

    class MultiPlatform(object):
        platform = ['other', 'test']
        distribution = None

    class MultiPlatformDistribution(object):
        platform = ['other', 'test']
        distribution = 'test'

    #

# Generated at 2022-06-11 01:33:12.947679
# Unit test for function get_distribution
def test_get_distribution():
    DISTRIBUTION_NAME = {
        'Linux': get_distribution(),
        'Darwin': 'Macosx',
        'FreeBSD': 'Freebsd',
        'OpenBSD': 'Openbsd',
        'NetBSD': 'Netbsd',
        'SunOS': 'Sunos'
    }[platform.system()]

    assert get_distribution() == DISTRIBUTION_NAME

# Generated at 2022-06-11 01:33:14.460590
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'trusty'

# Generated at 2022-06-11 01:33:22.925127
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        platform = None
        distribution = None
        pass

    class B(A):
        platform = 'Linux'
        distribution = 'Redhat'
        pass

    class C(A):
        platform = 'Linux'
        pass

    class D(A):
        pass

    subclasses = (B, C, D)

    tests = (
        ('Linux', 'Redhat', B),
        ('Linux', 'OtherLinux', C),
        ('Other', 'Other', D),
    )

    for test in tests:
        (this_platform, distribution, expected_subclass) = test
        classname = this_platform + distribution
        input_class = type(classname, (A,), {'platform': this_platform, 'distribution': distribution})

# Generated at 2022-06-11 01:33:24.908619
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename


# Generated at 2022-06-11 01:33:36.317910
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class base:
        pass

    class BSDUser(base):
        platform = "BSD"

    class LinuxUser(base):
        platform = "Linux"
    class OtherLinuxUser(base):
        platform = "Linux"
        distribution = "OtherLinux"
    class RedHatUser(base):
        platform = "Linux"
        distribution = "RedHat"
    class DebianUser(base):
        platform = "Linux"
        distribution = "Debian"

    user_cls = get_platform_subclass(base)
    assert user_cls is base

    user_cls = get_platform_subclass(LinuxUser)
    assert user_cls is LinuxUser

    user_cls = get_platform_subclass(OtherLinuxUser)
    assert user_cls is OtherLinuxUser

    user_cls = get_

# Generated at 2022-06-11 01:33:59.833089
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    # Mock the functions we want to test
    distro.id = lambda: 'Ubuntu'

    # Check codename is returned as expected
    distro.os_release_info = lambda: {'version_codename': 'bionic', 'ubuntu_codename': 'bionic'}
    assert(get_distribution_codename() == 'bionic')

    # Check codename is returned as expected
    distro.os_release_info = lambda: {'version_codename': 'bionic', 'ubuntu_codename': 'ubuntu_codename'}
    assert(get_distribution_codename() == 'bionic')

    # Check codename is returned as expected
    distro.os_release_info = lambda: {'version_codename': 'bionic', 'ubuntu_codename': 'NONE'}

# Generated at 2022-06-11 01:34:10.185333
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import load_platform_subclass
    from ansible.module_utils._text import to_bytes
    from io import StringIO

    class PlatformA(object):
        platform = 'A'
        distribution = None

        def __init__(self, module):
            self.argument_spec = dict(
                foo=dict(type='str')
            )
            self.module = module

        def run(self):
            return self.module.params['foo']

    class PlatformB(PlatformA):
        platform = 'B'

    class PlatformC(PlatformA):
        platform = 'A'
        distribution = 'C'

    class PlatformD(PlatformA):
        platform = 'B'
        distribution = 'C'


# Generated at 2022-06-11 01:34:21.565327
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Unit test for function 'get_platform_subclass'
    """

    class BaseTestClass:
        platform = None
        distribution = None

    class OS1(BaseTestClass):
        platform = 'OS1'
        distribution = None

    class OS1Dist1(OS1):
        platform = 'OS1'
        distribution = 'Dist1'

    class OS2(BaseTestClass):
        platform = 'OS2'
        distribution = None

    class OS2Dist1(OS2):
        platform = 'OS2'
        distribution = 'Dist1'

    class OS2Dist2(OS2):
        platform = 'OS2'
        distribution = 'Dist2'

    # Mock platform.system()

# Generated at 2022-06-11 01:34:23.091383
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-11 01:34:33.134509
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    with mock.patch('ansible.module_utils.distro._distro', new_callable=mock.PropertyMock) as _distro_mock:
        _distro_mock.return_value = 'ubuntu'

        _os_release_info = {
            'id': 'ubuntu',
            'version': '18.04.2 LTS (Bionic Beaver)',
            'pretty_name': 'Ubuntu 18.04.2 LTS',
            'name': 'Ubuntu',
            'version_id': '18.04',
            'home_url': 'https://www.ubuntu.com/',
            'support_url': 'https://help.ubuntu.com/',
            'bug_report_url': 'https://bugs.launchpad.net/ubuntu/',
        }


# Generated at 2022-06-11 01:34:44.469960
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit tests for function get_platform_subclass
    '''
    # Create a class hierarchy with some subclasses containing distribution
    # and platform attributes
    class Base:
        '''
        The top level class which other classes inherit from
        '''
        distribution = None
        platform = u'Base'

    class LinuxBase(Base):
        '''
        The next level class which other classes inherit from
        '''
        platform = u'Linux'

    class LinuxRedhatBase(LinuxBase):
        '''
        The next level class which other classes inherit from
        '''
        distribution = u'Redhat'

    class AmznLinux(LinuxBase):
        '''
        The next level class which other classes inherit from
        '''
        distribution = u'Amazon'


# Generated at 2022-06-11 01:34:46.781697
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    Check if the distribution version is correctly obtained
    """
    assert get_distribution_version() is None

# Generated at 2022-06-11 01:34:49.280909
# Unit test for function get_distribution_version
def test_get_distribution_version():
    expected = u'1.1'
    actual = get_distribution_version()
    assert actual == expected


# Generated at 2022-06-11 01:34:56.333447
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test for function get_distribution_codename to check if it returns the correct codename
    for the platform on which it is executing.
    '''
    # Add test cases here
    test_cases = {
        'Amazon': 'amzn',
        'CentOS': 'Core',
        'Debian': 'stretch',
        'FreeBSD': None,
        'RedHat': 'Ootpa'
    }
    # Perform testing
    for distro, codename in test_cases.items():
        assert get_distribution_codename() == codename

# Generated at 2022-06-11 01:35:07.739740
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # set a generic ID so we can switch out the codename
    distro.id = lambda: 'ubuntu'

    # set an os_release_info that has a version_codename
    distro.os_release_info = lambda: {'version_codename': 'fakename'}
    assert get_distribution_codename() == u'fakename'

    # set an os_release_info that has a ubuntu_codename
    distro.os_release_info = lambda: {'ubuntu_codename': 'fakename'}
    assert get_distribution_codename() == u'fakename'

    # set an os_release_info that has neither
    distro.os_release_info = lambda: {}
    assert get_distribution_codename() is None

    # set an os_release_info

# Generated at 2022-06-11 01:35:20.309671
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'

# Generated at 2022-06-11 01:35:22.271859
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(object).__name__ == 'object'

# Generated at 2022-06-11 01:35:24.587094
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test that get_distribution_version returns the correct value
    '''

    assert get_distribution_version()

# Generated at 2022-06-11 01:35:35.548685
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    class FakeDistro:
        def __init__(self, distro_id=None, version_id=None, version_codename=None, version_best=None, version=None, codename=None, ubuntu_codename=None):
            self._distro_id = distro_id
            self._version_id = version_id
            self._version_codename = version_codename
            self._version_best = version_best
            self._version = version
            self._codename = codename
            self._ubuntu_codename = ubuntu_codename

        def os_release_info(self):
            return {'version_codename': self._version_codename, 'ubuntu_codename': self._ubuntu_codename}

        def id(self):
            return self._distro_id


# Generated at 2022-06-11 01:35:39.514218
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the get_distribution_codename function

    :returns: bool indicating if test passed
    '''
    # Test output on Ubuntu
    test_output_ubuntu = u'xenial'
    if get_distribution_codename() != test_output_ubuntu:
        return False

    return True

# Generated at 2022-06-11 01:35:46.088248
# Unit test for function get_distribution
def test_get_distribution():
    import platform

    test_platform = {
        'darwin': u'Darwin',
        'freebsd': u'FreeBSD',
        'linux': u'OtherLinux',
        'linux2': u'OtherLinux',
        'openbsd': u'OpenBSD',
        'sunos5': u'SunOS',
        'sunos6': u'SunOS',
        'sunos7': u'SunOS',
        'sunos8': u'SunOS',
        'sunos9': u'SunOS',
        'sunos10': u'SunOS',
        'win32': u'Windows',
    }

    assert get_distribution() == test_platform[platform.system().lower()]

# Generated at 2022-06-11 01:35:56.692933
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native

    class PlatformA(object):
        platform = 'A'

        def __repr__(self):
            return self.__class__.__name__ + "<platform=%s>" % to_native(self.platform)

    class SubPlatformAA(PlatformA):
        platform = 'AA'

    class PlatformB(object):
        platform = 'B'

        def __repr__(self):
            return self.__class__.__name__ + "<platform=%s>" % to_native(self.platform)

    class SubPlatformBA(PlatformB):
        platform = 'BA'

    class PlatformC(PlatformA):
        distribution = 'C'


# Generated at 2022-06-11 01:36:00.127389
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    distributions = set(['stretch', 'buster', 'xenial', 'trusty', 'jessie', 'bionic', 'focal'])
    assert codename in distributions

# Generated at 2022-06-11 01:36:08.763499
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from types import ModuleType
    from ansible.test.unit.test_utils import TestAnsibleCore

    # Make distro module available
    distro_module = ModuleType('distro')
    setattr(distro_module, 'id', lambda: 'ubuntu')
    setattr(distro_module, 'version', lambda: '18.04')
    setattr(distro_module, 'version', lambda best=False: '18.04.1')
    setattr(distro_module, 'os_release_info', lambda: {'version_codename': 'bionic'})
    setattr(distro_module, 'lsb_release_info', lambda: {'codename': 'bionic'})
    setattr(distro_module, 'codename', lambda: '')

# Generated at 2022-06-11 01:36:09.692454
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == u'Amazon'

# Generated at 2022-06-11 01:36:31.910603
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test to see if the get_platform_subclass function works as expected
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleLinuxModule
    from ansible.module_utils.basic import AnsibleFreeBSDModule
    from ansible.module_utils.basic import AnsibleMacOSModule
    from ansible.module_utils.basic import AnsibleOpenBSDModule

    # Test to see if the AnsibleModule is selected
    ans_mod = get_platform_subclass(AnsibleModule)
    assert(ans_mod == AnsibleModule)

    # Test to see if the AnsibleLinuxModule is selected
    ans_mod = get_platform_subclass(AnsibleLinuxModule)
    assert(ans_mod == AnsibleLinuxModule)

    # Test

# Generated at 2022-06-11 01:36:32.947506
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'focal'

# Generated at 2022-06-11 01:36:34.403895
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'


# Generated at 2022-06-11 01:36:43.176552
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() in ('AmigaOS', 'Android', 'Arch', 'Archarm', 'AIX', 'Chromeos', 'Cumulus', 'Cygwin', 'Debian', 'Euleros', 'Fedora', 'Freebsd', 'Freenas', 'Gentoo', 'Junos', 'Linux', 'Macos', 'Nexenta', 'Netbsd', 'Netscaler', 'Oe', 'Opensuse', 'Openwrt', 'Ovs_system', 'Ovs_user', 'Pld', 'Smartos', 'Solaris', 'Suse', 'Truenas', 'Ubuntu', 'Vios', 'Windows')


# Generated at 2022-06-11 01:36:47.171310
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    print('Starting test_get_distribution_codename')
    print('Distribution codename is ' + get_distribution_codename())

if __name__ == '__main__':
    test_get_distribution_codename()

# Generated at 2022-06-11 01:36:57.899475
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Method to test get_platform_subclass
    '''
    from ansible.module_utils.basic import AnsibleModule

    # Lets define some classes to test that out
    class confmodule1(object):
        platform = platform.system()
        distribution = get_distribution()

    class confmodule2(object):
        # This class would be used for platforms other than Linux
        platform = 'Linux'
        distribution = None

    class confmodule3(object):
        platform = platform.system()
        distribution = get_distribution()
        # This class is useless as confmodule1 will always be preferred on this Linux distro

    # Now lets instantiate a class and test it
    module_args = dict()
    module = AnsibleModule(argument_spec=module_args)


# Generated at 2022-06-11 01:37:00.078305
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Check for Ubuntu Xenial
    codename = get_distribution_codename()
    assert codename == "xenial"

# Generated at 2022-06-11 01:37:11.534112
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test CentOS
    distro.lsb_release = lambda: {'release': '', 'description': 'CentOS Linux release 7.6.1810 (Core)'}
    distro.os_release = lambda: {'id': 'centos', 'release': '7.6.1810', 'version': '7.6.1810'}
    if get_distribution_version() != '7.6.1810':
        raise AssertionError()

    # Test Redhat
    distro.lsb_release = lambda: {'release': '', 'description': 'Red Hat Enterprise Linux Workstation release 7.6 (Maipo)'}
    distro.os_release = lambda: {'id': 'rhel', 'release': '7.6', 'version': '7.6'}

# Generated at 2022-06-11 01:37:14.393298
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Ubuntu 16.04
    assert get_distribution_codename() == u'xenial'

# Generated at 2022-06-11 01:37:17.703638
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Function used by the get_platform_subclass unit test to simulate a superclass

    The unit test will test importing this module, creating subclasses and instantiating those
    classes.  This class is used to simulate the type of class we are going to be instantiating.
    '''
    pass

# Generated at 2022-06-11 01:37:43.687590
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distribution_version = get_distribution_version()
    assert(distribution_version is not None)

# Generated at 2022-06-11 01:37:44.932236
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == "maverick"

# Generated at 2022-06-11 01:37:51.084713
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test for function get_distribution_codename

    :returns: Null if no error encountered
    '''
    from ansible.module_utils import basic


# Generated at 2022-06-11 01:38:02.526991
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution = get_distribution()
    if distribution == 'Debian':
        assert get_distribution_codename() in (u'sid', u'bullseye', u'testing', u'stable', u'jessie', u'wheezy')
    elif distribution == 'Ubuntu':
        assert get_distribution_codename() in (u'raring', u'saucy', u'trusty', u'artful', u'bionic', u'xenial', u'yakkety', u'zesty', u'cosmic', u'disco')
    elif distribution == 'Smartos':
        assert get_distribution_codename() is None
    elif distribution == 'Freebsd':
        assert get_distribution_codename() is None
    elif distribution == 'Openbsd':
        assert get_dist

# Generated at 2022-06-11 01:38:10.670981
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    import sys
    import io

    import unittest
    from ansible.module_utils import basic

    class PlatformSuper(basic.AnsibleModule):
        pass

    class PlatformSub(PlatformSuper):
        platform = 'Linux'
        distribution = 'Redhat'

    class PlatformSubOther(PlatformSuper):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class PlatformSubOtherDistro(PlatformSuper):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class PlatformSubOtherLinux(PlatformSuper):
        platform = 'Linux'
        distribution = None

    class PlatformSubOtherPlatform(PlatformSuper):
        platform = 'Other'
        distribution = 'Redhat'


# Generated at 2022-06-11 01:38:19.045385
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from  ansible.module_utils.basic import AnsibleModule, get_platform_subclass

    class PlatformA(object):
        platform = 'PlatformA'
        distribution = None

    class PlatformB(object):
        platform = 'PlatformB'
        distribution = None

    class DistributionA(object):
        platform = 'PlatformA'
        distribution = 'DistributionA'

    class DistributionB(object):
        platform = 'PlatformA'
        distribution = 'DistributionB'

    class DistributionADistributionA(object):
        platform = 'PlatformA'
        distribution = 'DistributionA'

    class DistributionADistributionB(object):
        platform = 'PlatformA'
        distribution = 'DistributionB'

    class DistributionBDistributionB(object):
        platform = 'PlatformB'
        distribution = 'DistributionB'



# Generated at 2022-06-11 01:38:20.386958
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() != None


# Generated at 2022-06-11 01:38:29.252751
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    import warnings
    import sys

    # This is a simple test for get_platform_subclass and assumes that the
    # module is being run on a platform with a subclass
    # Check to see if we have the right version of python.
    if platform.python_version() < '2.7':
        sys.exit(1)

    # Make sure we have the right version of distro
    import distro
    if distro.version().split('.')[0] != '1':
        sys.exit(2)

    # Make sure warnings are raised
    warnings.simplefilter('error')
    warnings.simplefilter('ignore')

    # Make sure we have six
    import six

    # Create a dummy class

# Generated at 2022-06-11 01:38:38.885203
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass

    This is the unit test for function get_platform_subclass
    '''
    class GenericClass:
        '''
        Generic class
        '''
        platform = 'Generic'
        distribution = None

    # On a Linux platform return the distribution-specific class when present
    distribution = get_distribution()
    if distribution is not None:
        class DistributionClass:
            '''
            Distribution class
            '''
            platform = 'Linux'
            distribution = distribution

        assert get_platform_subclass(DistributionClass) == DistributionClass
    else:
        assert get_platform_subclass(GenericClass) == GenericClass

# Generated at 2022-06-11 01:38:39.736143
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert(None is get_platform_subclass(None))

# Generated at 2022-06-11 01:39:04.929542
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'bionic'

# Generated at 2022-06-11 01:39:15.059680
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Dummy class for unit test
    class MyClass:
        distribution = None
        platform = None

    class MyClassSolaris(MyClass):
        platform = 'SunOS'

    class MyClassRedhat(MyClass):
        distribution = 'Redhat'

    class MyClassRedhatLinux(MyClass):
        platform = 'Linux'
        distribution = 'Redhat'

    # Test scenarios
    assert get_platform_subclass(MyClass) == MyClass
    assert get_platform_subclass(MyClassSolaris) == MyClassSolaris
    assert get_platform_subclass(MyClassRedhat) == MyClassRedhat
    assert get_platform_subclass(MyClassRedhatLinux) == MyClassRedhatLinux

# Generated at 2022-06-11 01:39:17.408253
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Tests to make sure the return values match what we expect
    '''
    assert get_distribution() == 'Linux'

# Generated at 2022-06-11 01:39:18.469174
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:39:29.499957
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    Returns 0 on success, otherwise returns 1
    '''
    # Test 1 - CentOS 5
    ret_str_expected = 'Final'

    release_info = {
        'id': 'centos',
        'name': 'CentOS',
        'vers': '5.11',
        'full': '5.11',
        'major': '5',
        'minor': '11',
        'code': 'Final',
    }
    distro_codename = get_distribution_codename()
    if not distro_codename == ret_str_expected:
        return 1

    # Test 2 - CentOS 6
    ret_str_expected = 'Final'


# Generated at 2022-06-11 01:39:38.639686
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class SuperClass:
        pass

    class PlatformA(SuperClass):
        platform = 'Linux'
        distribution = None

    class DistributionA(PlatformA):
        distribution = 'Redhat'

    class DistributionB(PlatformA):
        distribution = 'Debian'

    class PlatformB(SuperClass):
        platform = 'FreeBSD'
        distribution = None

    class TestClass(PlatformA, PlatformB):
        pass

    test_object = TestClass()

    # Test platform
    assert(test_object.__class__ is PlatformA), "get_platform_subclass() returned wrong class"

    # Test distribution
    assert(test_object.__class__ is PlatformA), "get_platform_subclass() returned wrong class"

    PlatformA.distribution = 'Redhat'