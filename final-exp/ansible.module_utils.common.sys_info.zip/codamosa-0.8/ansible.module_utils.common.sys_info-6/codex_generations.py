

# Generated at 2022-06-11 01:29:46.582413
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    assert get_distribution_version() == '7.5', 'False'

# Generated at 2022-06-11 01:29:51.362985
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock

    version = u'8.0'
    version_best = u'8.0.1'
    distro_id = u'centos'
    distro = Mock()
    distro.id.return_value = distro_id
    distro.version.return_value = version
    distro.version.return_value = version
    distro.version.return_value = version_best

    assert get_distribution_version() == u'8.0'

# Generated at 2022-06-11 01:30:03.261478
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Arch
    os_release = (
        'NAME="Arch Linux"\n'
        'ID=arch\n'
        'PRETTY_NAME="Arch Linux"'
    )
    lsb_release = ''
    assert get_distribution_codename(os_release, lsb_release) is None

    # Debian 10
    os_release = (
        'NAME="Debian GNU/Linux"\n'
        'VERSION_ID="10"\n'
        'VERSION="10 (buster)"\n'
        'ID=debian\n'
        'HOME_URL="https://www.debian.org/"\n'
        'SUPPORT_URL="https://www.debian.org/support"'
    )
    lsb_release = ''

# Generated at 2022-06-11 01:30:13.413888
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    # There is also a test for this function in the stated test module
    class LoadPlatformSubclassModule(AnsibleModule):
        '''Test class for get_platform_subclass()'''
        def __init__(self):

            argument_spec = dict(
                distribution=dict(),
            )

            super(LoadPlatformSubclassModule, self).__init__(argument_spec=argument_spec,
                                                             supports_check_mode=False)

            self.run_command = self.get_bin_path('ls').strip

    test_module = LoadPlatformSubclassModule()

    # Test class has no subclass so it should be returned
    assert test_module.__class__ == LoadPlatformSubclassModule


# Generated at 2022-06-11 01:30:23.827758
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class RedHatUser(object):
        platform = 'Linux'
        distribution = 'RedHat'

    class OtherLinuxUser(object):
        platform = 'Linux'
        distribution = None

    class LinuxUser(object):
        platform = 'Linux'
        distribution = None

    class BSDUser(object):
        platform = 'FreeBSD'
        distribution = None

    class User(LinuxUser):
        pass

    assert get_platform_subclass(User) == LinuxUser

    class User(RedHatUser, OtherLinuxUser, LinuxUser, BSDUser):
        pass

    assert get_platform_subclass(User) == RedHatUser

    class User(OtherLinuxUser, LinuxUser, BSDUser):
        pass

    assert get_platform_subclass(User) == OtherLinuxUser


# Generated at 2022-06-11 01:30:34.253659
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    from ansible.module_utils.facts import cache

    if get_distribution() == 'Amazon':
        cache.set('ansible_distribution', 'Amazon')
        cache.set('ansible_distribution_version', '2018.03')
        codename = get_distribution_codename()
        assert codename == '2018.03'
    elif get_distribution() == 'RedHat':
        cache.set('ansible_distribution', 'RedHat')
        cache.set('ansible_distribution_version', '7.5')
        codename = get_distribution_codename()
        assert codename == 'AltArch'

# Generated at 2022-06-11 01:30:44.893154
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test various codepaths in get_distribution()
    '''
    import platform
    import ansible.module_utils.common.distro
    import ansible.module_utils.common._collections_compat as collections_compat

    from ansible.module_utils.common.distro import DistributionNotFoundError
    from ansible.module_utils._text import to_native

    # We need to remember the old value for distro.id() so we can get back to it when we're done
    orig_distro_id = ansible.module_utils.common.distro.id
    orig_platform_system = platform.system

    def id_fake(best=False):
        if not best:
            return 'DistroFake'
        else:
            return 'DistroFake.Version'


# Generated at 2022-06-11 01:30:45.690091
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == distro.version()

# Generated at 2022-06-11 01:30:47.909238
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None or isinstance(get_distribution_codename(), str)

# Generated at 2022-06-11 01:30:58.437729
# Unit test for function get_distribution
def test_get_distribution():
    import platform
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            # Reset the distribution_mock attribute back to None so that each
            # test case can set the expected value
            self.ORIGINAL_DISTRO = distro.id
            self.ORIGINAL_SYSTEM = platform.system

        def tearDown(self):
            distro.id = self.ORIGINAL_DISTRO
            platform.system = self.ORIGINAL_SYSTEM

        def test_linux(self):
            def distro_mock():
                return 'linux'
            distro.id = distro_mock
            platform.system = lambda: 'Linux'
            self.assertEqual(get_distribution(), 'Linux')


# Generated at 2022-06-11 01:31:15.631198
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Test:
        platform = 'FooBar'
        distribution = None

    class TestLinux(Test):
        platform = 'Linux'

    class TestLinuxRedhat(TestLinux):
        distribution = 'Redhat'

    class TestLinuxAmazon(TestLinux):
        distribution = 'Amazon'

    class TestLinuxCentos(TestLinux):
        distribution = 'Centos'

    class TestLinuxFedora(TestLinux):
        distribution = 'Fedora'

    class TestLinuxFreebsd(TestLinux):
        distribution = 'Freebsd'

    class TestLinuxOpenbsd(TestLinux):
        distribution = 'Openbsd'

    class TestLinuxOpenwrt(TestLinux):
        distribution = 'Openwrt'

    class TestLinuxAIX(TestLinux):
        distribution = 'AIX'


# Generated at 2022-06-11 01:31:24.140022
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Parent(object):
        platform = 'Linux'
        distribution = None
        pass
    assert get_platform_subclass(Parent) == Parent

    class Child(Parent):
        platform = 'Linux'
        distribution = get_distribution()
        pass
    assert get_platform_subclass(Parent) is Child

    class Grandchild(Child):
        platform = 'Linux'
        distribution = 'Redhat'
        pass
    assert get_platform_subclass(Parent) is Grandchild

    class WinChild(Parent):
        platform = 'Windows'
        pass
    assert get_platform_subclass(Parent) == Parent

# Generated at 2022-06-11 01:31:32.004971
# Unit test for function get_distribution

# Generated at 2022-06-11 01:31:39.461987
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # get centos7.5 codename
    assert get_distribution_codename() == u'Core'

    # get fedora28 codename
    assert get_distribution_codename() == u'Fedora'

    # get debian9 codename
    assert get_distribution_codename() == u'stretch'

    # get ubuntu16.04 codename
    assert get_distribution_codename() == u'xenial'

# Generated at 2022-06-11 01:31:50.664639
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest

    class LinuxABC(object):
        platform = 'Linux'
        distribution = None

    class LinuxCentOS(LinuxABC):
        distribution = 'CentOS'

    class LinuxUbuntu(LinuxABC):
        distribution = 'Ubuntu'

    class MacOSXABC(object):
        platform = 'MacOSX'
        distribution = None

    class MyBaseClass(object):
        '''
            Base class for which we want to find a subclass that implements a particular function on the current
            platform.
        '''
        platform = None
        distribution = None

        def do_platform_thing(self):
            return "Default"

    class MyCentOSClass(MyBaseClass, LinuxCentOS):
        def do_platform_thing(self):
            return "CentOS"


# Generated at 2022-06-11 01:31:56.512903
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Changed in version 2.5: This function serves as the replacement for
      :func:`ansible.module_utils.basic.load_platform_subclass`.
    '''
    codename = get_distribution_codename()
    # We only get a codename when running on a Linux distribution
    if platform.system() == 'Linux':
        assert isinstance(codename, str), 'Codename must be a string'
    else:
        assert codename is None, 'Codenames only exist on Linux'

# Generated at 2022-06-11 01:32:06.741312
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # test with arbitrary class
    class TestClass:
        platform = u'Linux'
        distribution = None

    assert get_platform_subclass(TestClass) == TestClass

    # test with a subclass
    class TestClassSubClass(TestClass):
        pass

    assert get_platform_subclass(TestClass) == TestClassSubClass

    # test with most specific subclass
    class TestClassSubClass(TestClass):
        pass

    assert get_platform_subclass(TestClass) == TestClassSubClass

    # test with missing subclass
    class TestClassSubClassMissing(TestClass):
        platform = u'Darwin'

    assert get_platform_subclass(TestClass) == TestClass

# Generated at 2022-06-11 01:32:17.949766
# Unit test for function get_distribution
def test_get_distribution():
    """This will test the get_distribution() function.

    The tests included:
        * Testing Amazon Linux
        * Testing CentOS
        * Testing Debian
        * Testing Fedora
        * Testing FreeBSD
        * Testing Ubuntu
        * Testing macOS
        * Testing OpenBSD
        * Testing OpenSUSE
        * Testing OracleLinux
        * Testing RedHat
        * Testing SuSE
        * Testing Unknown Linux
    """

    # Test Amazon Linux
    # For this test, I've created a virtualenv and installed a version of the
    # distro module.  In that version, I've removed everything but Amzn for
    # the ID, and I've altered the version() function to return the version
    # I want the test to use.
    amzn_results = get_distribution()
    assert amzn_results == 'Amazon'

    # Test CentOS
    #

# Generated at 2022-06-11 01:32:29.640730
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Testing get_platform_subclass
    '''
    class Base(object):
        platform = 'Base'
        distribution = None

    class BSD(Base):
        platform = 'BSD'

    class Linux(Base):
        platform = 'Linux'

    class LinuxBase(Linux):
        distribution = None

    class LinuxRedhat(Linux):
        distribution = 'Redhat'

    class LinuxOSX(Linux):
        distribution = 'OSX'

    class LinuxAIX(Linux):
        distribution = 'AIX'

    class LinuxOSXRedhat(LinuxOSX):
        distribution = 'Redhat'

    class LinuxRedhatAIX(LinuxRedhat):
        distribution = 'AIX'

    # testing for exact platform subclass match
    assert get_platform_subclass(Base) == Base
    assert get_platform

# Generated at 2022-06-11 01:32:39.032049
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Function to test the get_platform_subclass function

    Tests the get_platform_subclass function by creating a base class and a
    subclass of it with a custom platform. The function is called and the
    returned class is compared to the custom class.  The same test is also
    run on a subclass of the custom class to ensure we get the subclass back
    instead of the custom class.

    This function is called directly by the unit test system.
    '''

    class TestPlatformClass:
        platform = None

    class TestPlatformSubClass(TestPlatformClass):
        platform = 'TestPlatform'

    class TestPlatformSubSubClass(TestPlatformSubClass):
        platform = 'TestPlatform'

    assert get_platform_subclass(TestPlatformClass) == TestPlatformClass
    assert get_platform_subclass(TestPlatformSubClass) == TestPlatform

# Generated at 2022-06-11 01:32:52.708133
# Unit test for function get_distribution
def test_get_distribution():
    # Returns the name of the distribution
    assert get_distribution() == "Redhat"

# Old method to find subclass

# Generated at 2022-06-11 01:33:00.632489
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base(object):
        platform = 'this_is_a_test_of_load_platform_subclass'

    class Foo(Base):
        pass

    class LinuxFoo(Foo):
        platform = 'linux'

    class WindowsFoo(Foo):
        platform = 'windows'

    result = get_platform_subclass(LinuxFoo)

    assert result == LinuxFoo

# Generated at 2022-06-11 01:33:12.597067
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Note: We use a platform that has subclasses defined that support it but isn't supported by
    # distro.id(), but we use distro.id() to ensure that distro.id() is called properly.
    # The actual values don't matter since we don't have any actual classes defined in the unit test.
    distro.id = lambda: 'unsupported'
    platform.system = lambda: 'Linux'

    class DummyParent:
        platform = 'Linux'
        distribution = 'RedHat'

    class DummySubclass(DummyParent):
        platform = 'Linux'
        distribution = 'RedHat'

    # when subclass is included in get_all_subclasses we should get it back
    assert get_platform_subclass(DummyParent) == DummySubclass
    assert get_platform_subclass(DummyParent) != D

# Generated at 2022-06-11 01:33:16.550830
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test get_distribution_version() function

    :raises: AssertionError when function does not work as expected.
    '''
    assert(get_distribution_version() == '7' or get_distribution_version() == '8')


# Generated at 2022-06-11 01:33:20.268832
# Unit test for function get_distribution
def test_get_distribution():
    """
    Test the method get_distribution.

    This test is mainly to check if get_distribution is able
    to return the distribution name, while not testing if it is
    in fact the right distribution name.
    """
    distribution = get_distribution()
    assert distribution is not None



# Generated at 2022-06-11 01:33:23.828097
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.common._utils import get_distribution

    assert get_distribution() == 'Redhat'
    assert get_distribution_version() == '6'
    assert get_distribution_codename() == 'Santiago'

# Generated at 2022-06-11 01:33:35.589029
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Foo:
        pass

    class LinuxFoo(Foo):
        platform = "Linux"
        distribution = None

    class LinuxRedhatFoo(Foo):
        platform = "Linux"
        distribution = "Redhat"

    class LinuxSolarisFoo(Foo):
        platform = "Linux"
        distribution = "Solaris"

    class WindowsFoo(Foo):
        platform = "Windows"

    class BigLinuxFoo(LinuxFoo):
        pass

    class BigLinuxRedhatFoo(LinuxRedhatFoo):
        pass

    class BigWindowsFoo(WindowsFoo):
        pass

    class SpecialFoo(BigLinuxRedhatFoo):
        pass

    class SpecialLinuxFoo(BigLinuxFoo):
        pass

    # Normal case

# Generated at 2022-06-11 01:33:39.205378
# Unit test for function get_distribution
def test_get_distribution():
    dist = get_distribution()
    if dist not in ['Linux', 'Darwin', 'FreeBSD', 'OpenBSD', 'SunOS', 'NetBSD']:
        assert False, "invalid distribution %s" % dist



# Generated at 2022-06-11 01:33:41.005441
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # return None when not a Linux distro
    assert get_distribution_version() is None
    # return an empty string when there is no distro version
    assert get_distribution_version() == u''

# Generated at 2022-06-11 01:33:46.374605
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        platform = 'Linux'

    class B(A):
        platform = 'Linux'
        distribution = 'Redhat'

    class C(B):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '7.5'

    subclass = get_platform_subclass(A)
    assert subclass is A

    subclass = get_platform_subclass(B)
    assert subclass is B

    subclass = get_platform_subclass(C)
    assert subclass is C

# Generated at 2022-06-11 01:34:20.692145
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # we must mock the function platform.system() to return the appropriate value
    platform.system = lambda: 'Linux'
    get_distribution = lambda: 'Centos'
    # we must define the class hierarchy matching the code in the User module
    class BaseUser(object):
        platform = None
        distribution = None

    class GenericUser(BaseUser):
        platform = 'Linux'
        distribution = None

    class RedhatUser(BaseUser):
        platform = 'Linux'
        distribution = 'Redhat'

    class CentosUser(RedhatUser):
        distribution = 'Centos'
    # we test the different possibilities
    assert get_platform_subclass(BaseUser) == BaseUser
    assert get_platform_subclass(GenericUser) == GenericUser
    assert get_platform_subclass(RedhatUser) == RedhatUser
   

# Generated at 2022-06-11 01:34:29.543352
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Mock distro.distro.id
    distro.distro.id = lambda: "CentOS Linux"

    # Test on CentOS release
    distro.distro.version = lambda: "7.7.1908"
    distro.distro.version_best = lambda: "7.7.1908"
    assert get_distribution_version() == "7.7"

    # Test on RHEL release
    distro.distro.version = lambda: "7.8"
    distro.distro.version_best = lambda: "7.8.0"
    assert get_distribution_version() == "7.8"

# Generated at 2022-06-11 01:34:30.905096
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Fedora'


# Generated at 2022-06-11 01:34:39.648325
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Test:
        platform = 'A'
        distribution = None

    class TestA(Test):
        platform = 'A'
        distribution = None
    class TestB(Test):
        platform = 'B'
        distribution = None
    class TestAD(Test):
        platform = 'A'
        distribution = 'D'
    class TestBD(Test):
        platform = 'B'
        distribution = 'D'
    class TestAD2(Test):
        platform = 'A'
        distribution = 'D'

    assert TestA == get_platform_subclass(Test)
    assert TestAD == get_platform_subclass(TestA)
    assert TestAD2 == get_platform_subclass(TestAD)

# Generated at 2022-06-11 01:34:42.647006
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    version = get_distribution_version()
    assert version, 'version should have a value'

# Generated at 2022-06-11 01:34:53.983035
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    ''' Unit test for function get_platform_subclass '''
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.cloud import get_platform_subclass

    import platform
    import unittest

    class TestClass(object):

        platform = None
        distribution = None

        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(TestClass)
            return super(cls, new_cls).__new__(new_cls)

        def __init__(self):
            self.my_distribution = self.distribution
            self.my_platform = self.platform

    class CentosClass(TestClass):

        platform = 'Linux'
        distribution = 'Centos'


# Generated at 2022-06-11 01:35:01.463828
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        platform = None
        distribution = None

    class B(A):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class C(A):
        platform = 'Linux'
        distribution = None

    class D(A):
        platform = 'Darwin'
        distribution = None

    class E(B):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class F(B):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class G(B):
        platform = 'FreeBSD'
        distribution = 'Ubuntu'

    class H(D):
        platform = 'Darwin'
        distribution = 'Placeholder'

    class I(F):
        platform = 'Linux'
        distribution = 'Placeholder'

    class J(F):
        platform

# Generated at 2022-06-11 01:35:11.517094
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass(object):
        platform = 'Linux'
        distribution = None

    class RedHatClass(BaseClass):
        distribution = 'Redhat'

    class SuseClass(BaseClass):
        distribution = 'Suse'

    class TestClass(object):
        platform = 'OpenBSD'
        distribution = None

    assert(get_platform_subclass(BaseClass) == BaseClass)
    assert(get_platform_subclass(RedHatClass) == RedHatClass)

    class SubClass(SuseClass):
        pass

    assert(get_platform_subclass(SubClass) == SubClass)
    assert(get_platform_subclass(TestClass) == TestClass)

# Generated at 2022-06-11 01:35:15.863938
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test combination of platform and distribution

    get_platform_subclass()

    Note: test cases are found in ansible/test/units/module_utils/test_get_platform_subclass.py:TestGetPlatformSubclass
    '''
    pass

# Generated at 2022-06-11 01:35:24.489896
# Unit test for function get_distribution
def test_get_distribution():
    old_platform = platform.system
    old_distro = distro.id
    old_distro_version = distro.version
    old_distro_codename = distro.codename
    old_os_release = distro.os_release_info
    old_lsb_release = distro.lsb_release_info

    def _distro_id(x=None):
        return x

    def _distro_version(x=None):
        return x

    def _distro_codename(x=None):
        return x


# Generated at 2022-06-11 01:35:57.887360
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    # Create a base class with no methods or attributes
    # Requires python 3.4 for subclass check
    class Base:
        pass

    # Create a subclass of Base with an attribute named distribution
    # and assign it a value
    class BaseSubClass(Base):
        distribution = u'DistroName'
    # Assert BaseSubClass is a subclass of Base
    assert issubclass(BaseSubClass, Base)

    # Create a subclass of AnsibleModule
    # assert it is a subclass of AnsibleModule
    class FooClass(AnsibleModule):
        pass
    assert issubclass(FooClass, AnsibleModule)

    # Create a subclass of FooClass
    # assert it is a subclass of FooClass
    class FooSubClass(FooClass):
        pass

# Generated at 2022-06-11 01:36:07.421815
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the get_distribution_codename function
    '''
    # Stub out calls to distro.lsb_release_info
    original_distro_lsb_release_info = distro.lsb_release_info
    distro.lsb_release_info = lambda: {'codename': 'fancypants'}
    # Stub out calls to distro.os_release_info
    original_distro_os_release_info = distro.os_release_info
    distro.os_release_info = lambda: {}
    # Stub out calls to distro.id
    original_distro_id = distro.id
    distro.id = lambda: 'ubuntu'

    # Test Ubuntu distro codename
    assert get_distribution_codename() == 'fancypants'

    # Test

# Generated at 2022-06-11 01:36:17.736518
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Base(object):
        distribution = None
        platform = None

    class BaseLinux(Base):
        platform = u'Linux'

    class BaseRedHat(BaseLinux):
        distribution = u'Redhat'

    class Centos(BaseRedHat):
        # NOTE: this class used to be assumed which would cause it to be returned
        # if no classes were supplied.
        distribution = u'CentOS'
        platform = u'Linux'

    class Debian(BaseLinux):
        distribution = u'Debian'
        platform = u'Linux'

    class Fedora(BaseRedHat):
        distribution = u'Fedora'
        platform = u'Linux'

    class BaseFreeBSD(Base):
        platform = u'FreeBSD'

    class FreeBSD(BaseFreeBSD):
        platform = u'FreeBSD'

        # NOTE: FreeBSD is

# Generated at 2022-06-11 01:36:25.074415
# Unit test for function get_distribution_version
def test_get_distribution_version():
    test_distro_id = ['debian', 'redhat', 'ubuntu', 'suse', 'arch', 'fedora']
    test_distro_version = ['8.1', '7.5', '16.04.3', '12.3', '18', '28']

    for index, distro_id in enumerate(test_distro_id):
        distro.id = lambda: distro_id
        distro.version = lambda: test_distro_version[index]

        version = get_distribution_version()
        assert version == test_distro_version[index]

# Generated at 2022-06-11 01:36:34.267607
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    expected_values = {
        'arch': None,
        'centos': u'Core',
        'debian': u'buster',
        'fedora': None,
        'ubuntu': u'stretch',
    }

    if platform.system() == 'Linux':
        distro_id = distro.id()
        codename = get_distribution_codename()

        message = None
        if codename is None:
            if expected_values[distro_id] is not None:
                message = u'codename was None and it should have been %s' % expected_values[distro_id]
        elif codename not in expected_values[distro_id]:
            message = u'codename was %s and it should have been %s' % (codename, expected_values[distro_id])

# Generated at 2022-06-11 01:36:44.752255
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class BaseClass:
        '''
        Base class for testing get_platform_subclass
        '''
        distribution = None
        platform = None

    # Define classes for testing get_platform_subclass
    class DefaultClass(BaseClass):
        '''
        Default class for testing get_platform_subclass
        '''

    class PlatformClass(BaseClass):
        '''
        Class for testing get_platform_subclass using platform
        '''
        platform = platform.system()

    class DefaultDistroClass(BaseClass):
        '''
        Class for testing get_platform_subclass using default distribution
        '''
        distribution = get_distribution()


# Generated at 2022-06-11 01:36:47.575102
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test of function get_distribution_codename
    '''
    assert get_distribution_codename() == None

# Generated at 2022-06-11 01:36:58.164301
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import unittest
    import unittest.mock as mock

    class GetDistributionVersionTestCase(unittest.TestCase):
        @mock.patch('ansible.module_utils.distro.version')
        @mock.patch('ansible.module_utils.distro.id')
        def _run_test(self, distro_version, distro_id):
            test_distribution = 'testdistro'
            test_version = 'testversion'

            distro.version.return_value = test_version
            distro.id.return_value = test_distribution

            self.assertEqual(get_distribution_version(), test_version)

    def _get_test_modules(base_class):
        '''
        Returns a list of the test cases contained in this module.
        '''

# Generated at 2022-06-11 01:36:59.281131
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Amzn'

# Generated at 2022-06-11 01:37:10.772032
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Simple class to use for the test
    class MyClass():
        pass

    class Subclass1(MyClass):
        platform = 'Linux'
    class Subclass2(MyClass):
        platform = 'Linux'
        distribution = 'RedHat'
    class Subclass3(MyClass):
        platform = 'Linux'
        distribution = 'CentOS'
    class Subclass4(MyClass):
        platform = 'Darwin'

    # Test the class and the base case
    assert isinstance(get_platform_subclass(MyClass), MyClass)

    # Test with simple cases
    assert isinstance(get_platform_subclass(MyClass), MyClass)
    assert isinstance(get_platform_subclass(MyClass), MyClass)

    # Test with real distribution and platform

# Generated at 2022-06-11 01:37:34.602268
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:37:44.794329
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    import os
    import platform
    import tempfile

    if os.path.exists('/etc/os-release') and os.path.isfile('/etc/os-release'):
        os_release = os.path.join(tempfile.mkdtemp(), 'os-release')
        os.symlink('/etc/os-release', os_release)

    distribution = get_distribution()
    thisplatform = platform.system()
    class TestClass:
        platform = 'Linux'
        distribution = 'RedHat'

        def __init__(self):
            pass

    class TestSubClass(TestClass):
        platform = 'Linux'
        distribution = 'Redhat'

    # Test subclass is returned

# Generated at 2022-06-11 01:37:48.192594
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import get_platform_subclass
    from ansible.module_utils.basic import AnsibleModule
    fake_module = AnsibleModule(
        argument_spec=dict(),
    )
    assert get_platform_subclass(fake_module) == fake_module

# Generated at 2022-06-11 01:37:59.521168
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''Unit test for function get_distribution_codename'''
    def test_pass_on_non_linux(platform_system, distro_id):
        '''Unit test for function get_distribution_codename with non-Linux platform'''
        with patch('platform.system') as mock_platform_system:
            with patch('ansible.module_utils.distro.id') as mock_distro_id:
                mock_platform_system.return_value = platform_system
                mock_distro_id.return_value = distro_id

                assert get_distribution_codename() is None


# Generated at 2022-06-11 01:38:08.011448
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Assume that the code is running on Linux
    this_platform = platform.system()
    distribution = get_distribution()

    # get the most specific superclass for this platform
    for cls in get_all_subclasses(object):
        if cls.platform == this_platform and cls.distribution == distribution:
            # the most specific subclass
            subclass = cls
            break
    else:
        for cls in get_all_subclasses(object):
            if cls.platform == this_platform and cls.distribution is None:
                # the most specific subclass
                subclass = cls
                break
        else:
            subclass = object

    assert subclass == get_platform_subclass(object)

# Generated at 2022-06-11 01:38:17.591542
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest
    import sys
    import os

    # We don't know what platform we're on so we don't know what the right
    # answer is.
    class Base(object):
        distribution = None
        platform = 'Generic'

    class Platform1(Base):
        platform = 'Platform1'

    class Platform2(Base):
        platform = 'Platform2'

    class Distribution1_Platform1(Platform1):
        distribution = 'Distribution1'

    class Distribution2_Platform1(Platform1):
        distribution = 'Distribution2'

    class Distribution2_Platform2(Platform2):
        distribution = 'Distribution2'

    class TestGetPlatformSubclass(unittest.TestCase):
        @staticmethod
        def get_platform():
            # Make it look like we're on Distribution2_Platform2
            this

# Generated at 2022-06-11 01:38:22.945901
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test of the function get_distribution_codename()
    Need to find an automated way to make the test work on different distribution

    :returns: None
    '''
    codename = get_distribution_codename()
    print("Distribution codename is : %s" % codename)

if __name__ == '__main__':
    test_get_distribution_codename()

# Generated at 2022-06-11 01:38:33.580691
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class SpecificClass(BaseClass):
        platform = "A"
        distribution = "1"

    class OtherClass(BaseClass):
        platform = "A"

    class LastClass(BaseClass):
        pass

    # If we're running on platform A, get the most specific subclass for that
    platform.system = lambda: "A"
    get_distribution = lambda: "1"
    assert get_platform_subclass(BaseClass) is SpecificClass

    # If we're running on a platform that's not A, then use the last subclass
    platform.system = lambda: "B"
    get_distribution = lambda: "2"
    assert get_platform_subclass(BaseClass) is LastClass

    # If we're running on platform A and we don't have a specific distribution,
    # then get

# Generated at 2022-06-11 01:38:35.545397
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert(get_distribution_codename() == 'tara')

# Generated at 2022-06-11 01:38:38.394689
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'wheezy'
    assert get_distribution_codename() == 'jessie'
    assert get_distribution_codename() == 'trusty'

# Generated at 2022-06-11 01:39:05.004222
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    good_tests = {
        'debian': {
            'version_codename': 'buster',
            'platform': 'Linux',
        },
        'ubuntu': {
            'version': '20.04',
            'ubuntu_codename': 'focal',
            'platform': 'Linux',
        },
        'redhat': {
            'platform': 'Linux',
        },
    }

    bad_tests = (
        {
            'platform': 'Linux',
            'version_codename': '',
        },
        {
            'platform': 'Linux',
        },
        {
            'platform': 'Linux',
            'version_codename': '',
            'ubuntu_codename': '',
        },
    )

    for test in good_tests:
        distro.id = lambda: test

# Generated at 2022-06-11 01:39:16.447757
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test of get_platform_subclass.

    Creates a set of classes that have attributes representing what platform they apply to.  The
    example used here is the User module which is a class on Windows and Linux.  There are
    additional subclasses on specific Linux distributions or Linux implemented differently depending
    on Python 2 vs Python 3.

    '''
    # This class is used for all platforms that do not have a specialized class for the platform
    class BaseUser:  # pylint: disable=too-few-public-methods
        ''' Base User class '''
        distribution = None
        platform = None
        def __init__(self, *args, **kwargs):
            ''' Store the arguments sent in.  Only used for testing. '''
            self.args = args
            self.kwargs = kwargs

    # This

# Generated at 2022-06-11 01:39:26.940662
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    def test_get_superclass(cls, expected_superclass):
        actual_superclass = get_platform_subclass(cls)
        assert actual_superclass is expected_superclass, \
            "%s was expected to be %s but was %s" % (cls, expected_superclass, actual_superclass)

    class Base:
        platform = "All"

    class SubclassA(Base):
        platform = "Linux"
        distribution = "Distribution"

    class SubclassB(Base):
        platform = "Linux"

    class SubclassC(Base):
        distribution = "Distribution"

    class SubclassD(Base):
        platform = "FreeBSD"
        distribution = "Distribution"

    class SubclassE(SubclassA):
        distribution = "OtherDistribution"

    test_get_super

# Generated at 2022-06-11 01:39:37.244715
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    tests = (
        ('oracle', 'OracleLinux', '7', None),
        ('deb', 'Debian', '9', 'stretch'),
        ('ubuntu', 'Ubuntu', 'xenial', 'xenial'),
        ('fedora', 'Fedora', '28', None),
        ('redhat', 'RedHat', '7.4', None),
        ('amazon', 'Amazon', '2', None),
        ('suse', 'SUSE', '15', None),
        ('centos', 'CentOS', '6.10', None),
        ('centos', 'CentOS', '7.5', None),
    )
    for test in tests:
        distro.id = lambda: test[0]
        distro.version = lambda: test[2]
        distribution_codename = get_distribution_codename()