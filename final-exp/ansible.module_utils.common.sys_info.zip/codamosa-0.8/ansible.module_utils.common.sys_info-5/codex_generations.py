

# Generated at 2022-06-11 01:29:48.226213
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

    # Until this gets merged and we update our bundled copy of distro:
    # https://github.com/nir0s/distro/pull/230
    # Fixes Fedora 28+ not having a code name and Ubuntu Xenial Xerus needing to be "xenial"
    assert get_distribution_codename() == None

# Generated at 2022-06-11 01:29:50.397591
# Unit test for function get_distribution
def test_get_distribution():
    """Test distribution retrieval"""
    assert get_distribution() == 'Debian'


# Generated at 2022-06-11 01:30:01.972583
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    # pylint: disable=unnecessary-pass

# Generated at 2022-06-11 01:30:12.888533
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Linux(object):
        platform = "Linux"
        distribution = None
    class OtherLinux(object):
        platform = "Linux"
        distribution = "OtherLinux"
    class LinuxAmazon(object):
        platform = "Linux"
        distribution = "Amazon"
    class LinuxCentos(object):
        platform = "Linux"
        distribution = "Centos"
    class LinuxRedhat(object):
        platform = "Linux"
        distribution = "Redhat"
    class Darwin(object):
        platform = "Darwin"
        distribution = None
    class Aix(object):
        platform = "AIX"
        distribution = None

# Generated at 2022-06-11 01:30:20.934187
# Unit test for function get_distribution
def test_get_distribution():
    '''
    make sure we get the right names for our distributions back
    '''
    for distro_name, expected_str in (
            ('amzn', 'Amazon'),
            ('centos', 'Centos'),
            ('debian', 'Debian'),
            ('fedora', 'Fedora'),
            ('redhat', 'Redhat'),
            ('ubuntu', 'Ubuntu'),
            (None, 'OtherLinux')
    ):
        # need to explicitly assign it since it is also used as the return value
        distribution = get_distribution()
        assert distribution == expected_str, '%s != %s' % (distribution, expected_str)



# Generated at 2022-06-11 01:30:28.397131
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    import os
    import sys

    # We are using strings to store the data because we are patching
    # the functions and the class would have to be redefined to do that.
    class Distribution:
        def __init__(self, data):
            self.data = data

        def codename(self):
            return self.data

        def id(self):
            return self.data

        def version(self):
            return self.data

    class Platform:
        def __init__(self, data):
            self.data = data

        def system(self):
            return self.data

        def linux_distribution(self):
            return self.data.split()

    class OsRelease:
        def __init__(self, data):
            self.data = data


# Generated at 2022-06-11 01:30:38.164388
# Unit test for function get_distribution

# Generated at 2022-06-11 01:30:50.342287
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename_map = {
        'Ubuntu': 'precise',
        'Amazon': '',
        'Redhat': '',
        'Darwin': None,
        'Alpine': None,
        'Archlinux': None,
        'CentOS': 'Maipo',
        'Debian': 'jessie',
        'FreeBSD': None,
        'Fedora': '',
        'Gentoo': None,
        'Mageia': None,
        'SUSE': None,
        'Solaris': None
    }

    for test_distribution in distribution_codename_map:
        actual_codename = get_distribution_codename()
        expected_codename = distribution_codename_map[actual_codename]

# Generated at 2022-06-11 01:30:55.113502
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.facts import kernel

    # test we find the correct class for a platform
    assert get_platform_subclass(kernel.Kernel) == kernel.KernelLinux

    # and that we return the base class when no platform subclass is found
    get_platform_subclass(kernel.KernelOSX) == kernel.KernelOSX

# Generated at 2022-06-11 01:30:58.569126
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distro_codename = get_distribution_codename()
    assert distro_codename in {'xenial', 'bionic'}, \
        'get_distribution_codename() returned a value other than xenial or bionic'

# Generated at 2022-06-11 01:31:05.565025
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == get_distribution()


# Generated at 2022-06-11 01:31:17.028170
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # pylint: disable=protected-access

    import platform

    class A(object):
        _platform = '__NOT_A_REAL_PLATFORM__'

    class B(A):
        pass

    class C(A):
        _distribution = '__NOT_A_REAL_DISTRIBUTION__'

    class D(C):
        _platform = platform.system()

    class E(C):
        _platform = platform.system()
        _distribution = get_distribution()

    class F(E):
        pass

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == B
    assert get_platform_subclass(C) == C
    if platform.system() == 'Linux':
        assert get_platform_subclass(D) != D

# Generated at 2022-06-11 01:31:18.497281
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:31:28.271209
# Unit test for function get_distribution
def test_get_distribution():
    # Linux and other systems that have /etc/os-release
    # Ansible uses os-release to determine the system name
    # This is done using the library Distro
    # https://github.com/nir0s/distro

    # Debian 8
    os_release_content = {
        'NAME': 'Debian GNU/Linux',
        'VERSION': '8 (jessie)',
        'ID': 'debia',
        'ID_LIKE': 'debian',
        'VERSION_ID': '8'
    }
    platform_system_return = 'Linux'
    distro_id_return = 'debian'
    distro_version_return = '8'
    distro_codename_return = 'jessie'
    expected_return = 'Debian'


# Generated at 2022-06-11 01:31:37.319288
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class LinuxOnly:
        platform = 'Linux'
        distribution = None

    class RDOLinuxOnly(LinuxOnly):
        distribution = 'Redhat'

    class UbuntuLinuxOnly(LinuxOnly):
        distribution = 'Ubuntu'

    class LinuxThing(RDOLinuxOnly, UbuntuLinuxOnly):
        pass

    class PlatformIndependent:
        pass

    assert (get_platform_subclass(PlatformIndependent)) is PlatformIndependent
    assert (get_platform_subclass(LinuxOnly)) is RDOLinuxOnly
    assert (get_platform_subclass(LinuxThing)) == (RDOLinuxOnly, LinuxOnly)

# Generated at 2022-06-11 01:31:38.787036
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-11 01:31:40.901395
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'
    assert get_distribution_version() != None

# Generated at 2022-06-11 01:31:42.041784
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import platform
    assert get_distribution_codename() is None
    assert get_distribution_codename() == platform.linux_distribution(supported_dists="debian")[2]

# Generated at 2022-06-11 01:31:43.546214
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-11 01:31:53.450482
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """Unit tests for function get_platform_subclass()"""
    import ansible.release
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system.distribution

    # Test 1:
    # Test that EarthClass is returned if distribution and platform are in the subclass
    # (i.e. EarthClass is the most specific subclass for the platform)
    ansible_major = ansible.release.__version_info__['major']

    if ansible_major < 2:
        # Old Ansible
        platform_mock = fake_platform('Linux', 'Redhat')
        distro_mock = fake_distro('Linux', 'Redhat', '7', '')
    else:
        # Ansible 2.0+
        platform_mock = fake_platform('Linux', 'RedHat')
       

# Generated at 2022-06-11 01:32:15.854471
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import platform
    import os
    import sys
    import tempfile
    import shutil
    import subprocess

    # Make sure we start with a clean test environment.
    file_handles = []
    tmp_dirs = []

    # python 2 and 3 compatibility
    import six
    if six.PY3:
        def write_file(handle, content):
            handle.write(bytes(content, 'utf-8'))
    else:
        def write_file(handle, content):
            handle.write(content)

    def cleanup():
        '''Clean up any temporary files and directories.
        '''
        for handle in file_handles:
            handle.close()

        for tmpdir in tmp_dirs:
            shutil.rmtree(tmpdir)


# Generated at 2022-06-11 01:32:23.333254
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    # Some stub classes
    class IamSuperclass(object):  # pylint: disable=too-few-public-methods
        '''Dummy superclass that all others subclass'''
        pass

    class ImSubclass(IamSuperclass):  # pylint: disable=too-few-public-methods
        '''Subclass of IamSuperclass'''
        platform = 'Linux'
        distribution = 'Redhat'

    class ImSubclass2(IamSuperclass):  # pylint: disable=too-few-public-methods
        '''Subclass of IamSuperclass'''
        platform = 'Linux'
        distribution = 'Redhat'

    # Class needs to be instantiated
    module = AnsibleModule({})
    subclass = get

# Generated at 2022-06-11 01:32:35.016207
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    from ansible.module_utils.basic import AnsibleModule

    class Base(object):
        platform = 'Generic'

    class Foo(Base):
        platform = 'Linux'
        distribution = None

    class Bar(Foo):
        distribution = 'RedHat'

    class Baz(Bar):
        distribution = 'Fedora'

    def get_platform(module):
        return module.params.get('platform', '')

    def get_distribution(module):
        return module.params.get('distribution', '')

    module = AnsibleModule({'platform': 'Linux', 'distribution': ''}, supports_check_mode=True)
    module.get_platform = get_platform
    module.get_distribution = get_distribution
    assert get_platform_subclass(Base) == Foo
    assert get_platform_subclass

# Generated at 2022-06-11 01:32:36.318595
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Amazon'



# Generated at 2022-06-11 01:32:48.130410
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import *

    class X(object):
        pass

    class X1(X):
        platform = 'Linux'
        distribution = 'Fedora'

    class X2(X):
        platform = 'Linux'

    class X3(X):
        distribution = 'Fedora'

    class X4(X):
        pass

    class X5(X):
        pass

    assert get_platform_subclass(X) == X
    assert get_platform_subclass(X1) == X1
    assert get_platform_subclass(X2) == X2
    assert get_platform_subclass(X3) == X3
    assert get_platform_subclass(X4) == X4
    assert get_platform_subclass(X5) == X5


# Generated at 2022-06-11 01:32:55.377774
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import sys

    class Subclass1:
        pass

    class Subclass2(Subclass1):
        distribution = u'RedHat'
        platform = u'Linux'

    class Subclass3(Subclass1):
        distribution = u'Ubuntu'
        platform = u'Linux'

    class TestClass:
        def __new__(cls):
            new_cls = get_platform_subclass(cls)
            return super(cls, new_cls).__new__(new_cls)

    old_plat = sys.platform
    old_dist = distro.id()

# Generated at 2022-06-11 01:33:07.844435
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = 'Base'
        distribution = None

    class PlatformClass:
        platform = 'TestPlatform'
        distribution = None

    class DistributionClass:
        platform = 'TestPlatform'
        distribution = 'TestDistro'

    class ExactMatchClass:
        platform = 'TestPlatform'
        distribution = 'TestDistro'

    # The right class should be selected by platform when there is no distribution
    BaseClass = get_platform_subclass(BaseClass)
    assert BaseClass == PlatformClass, "Should have selected platform class"

    # The right class should be selected by platform and distribution
    BaseClass = get_platform_subclass(BaseClass)
    assert BaseClass == ExactMatchClass, "Should have selected exact match class"

    # A base class should be returned if there is no match

# Generated at 2022-06-11 01:33:12.151088
# Unit test for function get_distribution
def test_get_distribution():
    from distro import id
    from distro import version
    from ansible.module_utils.basic import AnsibleModule

    import ansible.module_utils.basic
    ansible.module_utils.basic.distro = None

    # RedHat-like
    distro.id = lambda: 'centos'
    distro.version = lambda **kwargs: '6.7'
    assert get_distribution() == 'Redhat'

    # Amazon
    distro.id = lambda: 'amzn'
    distro.version = lambda **kwargs: '2016.03'
    assert get_distribution() == 'Amazon'

    # Debian-like
    distro.id = lambda: 'ubuntu'
    distro.version = lambda **kwargs: '16.04'
    assert get_distribution() == 'Debian'



# Generated at 2022-06-11 01:33:21.628987
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class SuperClass:
        platform = 'Linux'
        distribution = None

    class SubClassA(SuperClass):
        platform = 'Linux'
        distribution = 'RedHat'

    class SubClassB(SuperClass):
        platform = 'Linux'
        distribution = 'Debian'

    class SubClassC(SuperClass):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class SubClassD(SuperClass):
        platform = 'Linux'

    class SubClassZ(SuperClass):
        pass

    assert get_platform_subclass(SuperClass) == SubClassD
    assert get_platform_subclass(SubClassA) == SubClassA
    assert get_platform_subclass(SubClassB) == SubClassB
    assert get_platform_subclass(SubClassC) == SubClassC
    assert get_platform

# Generated at 2022-06-11 01:33:33.068019
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distro_test_cases = (
        ('debian9', 'stretch'),
        ('ubuntu18.04', 'bionic'),
        ('centos7', 'Core'),
        ('amzn2', ''),
        ('rhel8', ''),
        ('otherlinux', ''),
    )
    for test_case in distro_test_cases:
        setattr(platform, 'system', lambda: 'Linux')
        setattr(distro, 'id', lambda: test_case[0])
        if test_case[0] == 'debian9':
            os_release_info = dict(version_codename='stretch')
        elif test_case[0] == 'centos7':
            os_release_info = dict(centos_version=u'7')

# Generated at 2022-06-11 01:34:04.412593
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test for get_platform_subclass()
    # Note: If you add more platforms to the tests below, please also add them
    # to the test script t/test-test_utils.sh.
    from ansible.module_utils.basic import AnsibleModule, HAS_AIX, HAS_MACOS, HAS_HPUX, HAS_SOLARIS, HAS_WINRM

    class Linux(object):
        platform = u'Linux'
        distribution = None
        ansible_module = AnsibleModule

    class EL7(object):
        pass

    class Debian(object):
        distribution = u'Debian'

    class Ubuntu(object):
        distribution = u'Ubuntu'

    class FreeBSD(object):
        distribution = u'FreeBSD'

    class NetBSD(object):
        distribution = u'NetBSD'


# Generated at 2022-06-11 01:34:13.083315
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Platform(object):
        platform = None
        distribution = None

    class Gnome(Platform):
        platform = 'Linux'
        distribution = 'Gnome'

    class OtherLinux(Platform):
        platform = 'Linux'
        distribution = None

    class BSD(Platform):
        platform = 'BSD'

    class Darwin(Platform):
        platform = 'Darwin'

    class Linux(Platform):
        platform = 'Linux'

    class Other(Platform):
        pass

    assert get_platform_subclass(Gnome) == Gnome
    assert get_platform_subclass(BSD) == BSD
    assert get_platform_subclass(Darwin) == Darwin
    assert get_platform_subclass(Linux) == Linux
    assert get_platform_subclass(Other) == Other

# Generated at 2022-06-11 01:34:15.989457
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Basic test for function get_distribution_codename
    '''
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:34:27.279510
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    def get_distribution_codename_mock():
        return u'fedora'

    def get_distribution_version_mock():
        return u'28'

    def get_distribution_codename_mock_with_os_release_version_codename():
        return u'Bionic Beaver (development branch)'

    def get_distribution_codename_mock_with_lsb_codename():
        return u'xenial'


# Generated at 2022-06-11 01:34:35.573416
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass.

    We can't run this test on all platforms.  So, we mock ``subprocess.Popen`` to return the platform
    we want to test in the output.  We also mock ``get_distribution`` to return what we want to
    test.
    '''

    import subprocess
    import sys
    from mock import patch, MagicMock

    platform = MagicMock()
    platform.system = MagicMock(return_value=u'Linux')
    platform.platform = MagicMock(return_value=u'Linux-3.16.0-4-amd64-x86_64-with-debian-stretch-sid')
    distro = MagicMock()
    distro.id = MagicMock(return_value=u'ubuntu')

# Generated at 2022-06-11 01:34:37.147283
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Fedora'


# Generated at 2022-06-11 01:34:44.567220
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test method to test the get_distribution method

    :rtype: None
    :returns: This method simply asserts whether the get_distribution method has returned the expected value or not.
    '''

    get_distribution_id = get_distribution()
    platform_distro = platform.dist()[0].capitalize()

    assert get_distribution_id == platform_distro, 'get_distribution method returned unexpected value'


# Generated at 2022-06-11 01:34:55.391838
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test to see if the correct distribution version is returned
    '''
    # This function is a test to see if the correct distribution is returned.  By using two
    # different distributions and changing 'distro.id()' and 'distro.version()' we are able to
    # check if we get the appropriate distribution version returned.

    # Create a new class called distro_temp that has a new 'id' and 'version', with the new
    # 'id' and 'version' we can check and see if we get the correct distribution returned.
    class distro_temp(object):
        @classmethod
        def id(cls):
            return 'ubuntu'
        @classmethod
        def version(cls):
            return '16.04'

    # Save the current distro module to a temporary variable called 'distro_test'


# Generated at 2022-06-11 01:35:06.529328
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class _Base:
        platform = None
        distribution = None

    class _BaseLinux(_Base):
        platform = 'Linux'

    class _Ubuntu(_BaseLinux):
        distribution = 'Ubuntu'

    class _CentOS(_BaseLinux):
        distribution = 'CentOS'

    class _RedHat(_BaseLinux):
        distribution = 'RedHat'

    class _GenericLinux(_BaseLinux):
        distribution = None

    class _Windows(_Base):
        platform = 'Windows'

    class _Darwin(_Base):
        platform = 'Darwin'

    class _AIX(_Base):
        platform = 'AIX'

    class _BaseClass2(_Base):
        pass

    class _BaseLinuxClass2(_BaseLinux):
        pass

    class _LinuxSpecificClass2(_GenericLinux):
        pass

    # Test for the base

# Generated at 2022-06-11 01:35:07.240912
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None


# Generated at 2022-06-11 01:35:50.471175
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution()


# Generated at 2022-06-11 01:35:56.104988
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    print("Testing get_distribution_codename")
    distribution_codename = get_distribution_codename()
    print("distribution_codename: '%s'" % distribution_codename)
    assert(distribution_codename is not None and
           isinstance(distribution_codename, basestring))

# Generated at 2022-06-11 01:36:05.858774
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from types import ModuleType
    import ansible.module_utils.common.distro as distro
    import ansible.module_utils.common.platform as platform


# Generated at 2022-06-11 01:36:09.080993
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test to get the version of the distribution it is running on
    # Code should return a string even if it is empty
    assert isinstance(get_distribution_version(), str)
    # Test to return None if not a Linux machine
    assert get_distribution_version() is None

# Generated at 2022-06-11 01:36:19.520277
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test function get_platform_subclass()
    '''
    class cls(object):
        platform = 'Linux'
        distribution = None
        def __repr__(self):
            return '{}.{}'.format(this_platform, distribution)

    class cls_linux_centos(cls):
        platform = 'Linux'
        distribution = 'CentOS'

    class cls_linux_otherlinux(cls):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class cls_linux_redhat(cls):
        platform = 'Linux'
        distribution = 'RedHat'

    class cls_linux_redhat_centos(cls):
        platform = 'Linux'
        distribution = 'RedHat'


# Generated at 2022-06-11 01:36:23.405669
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test RedHat based systems
    assert get_distribution_codename() == "''"

    # Test Ubuntu based systems
    assert get_distribution_codename() == "''"

    # Test Debian based systems
    assert get_distribution_codename() == "''"

# Generated at 2022-06-11 01:36:33.035862
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from collections import namedtuple

    # Define a class
    class SomeClass:
        ''' base class for testing '''
        platform = None
        distribution = None

    # Define a couple subclasses
    class SomeClassLinux(SomeClass):
        ''' subclass representing Linux '''
        platform = 'Linux'
        distribution = None

    class SomeClassLinuxRedHat(SomeClass):
        ''' subclass representing Linux Red Hat '''
        platform = 'Linux'
        distribution = 'Redhat'

    TestCase = namedtuple('TestCase', 'platform distribution expected')
    TestCase.__new__.__defaults__ = (None,) * len(TestCase._fields)

    Cases = set()
    Cases.add(TestCase(platform='Linux', distribution='Redhat', expected=SomeClassLinuxRedHat))

# Generated at 2022-06-11 01:36:43.624114
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # test case if distro.version() returns None
    assert get_distribution_version() == u'', \
        "function get_distribution_verion() do not return empty string if distro.version() returns None"
    # test case if distro.version() returns version
    distribution_version_dict = {'version': '1.0'}
    original_distro_version = distro.version
    distro.version = lambda: distribution_version_dict['version']
    # test case if distro.id() returns centos
    distro_id_dict = {'id': 'centos'}
    original_distro_id = distro.id
    distro.id = lambda: distro_id_dict['id']
    # test 1st if block

# Generated at 2022-06-11 01:36:46.040620
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Tests for function get_distribution_codename
    '''
    assert get_distribution_codename() is not None

# Generated at 2022-06-11 01:36:57.150997
# Unit test for function get_distribution_codename

# Generated at 2022-06-11 01:38:31.768061
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic

    class Base:

        distribution = None
        platform = None

    class BaseOtherLinux(Base):

        distribution = 'OtherLinux'
        platform = 'Linux'

    class BaseRedHat(Base):

        distribution = 'RedHat'
        platform = 'Linux'

    class BaseOtherLinuxOtherLinux(BaseOtherLinux):

        distribution = BaseOtherLinux.distribution + 'X'
        platform = BaseOtherLinux.platform + 'X'

    class BaseRedHatRedHat(BaseRedHat):

        distribution = BaseRedHat.distribution + 'X'
        platform = BaseRedHat.platform + 'X'

    class BaseOtherLinuxRedHat(BaseOtherLinux):

        distribution = BaseRedHat.distribution
        platform = BaseRedHat.platform


# Generated at 2022-06-11 01:38:39.311291
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''...'''
    from .my_test_class import MyTestClass

    #
    # Test normal case
    #

    # Return a subclass with a matching platform of the passed class
    assert(MyTestClass == get_platform_subclass(MyTestClass))

    #
    # Test failing case
    #

    from .my_bad_test_class import MyBadTestClass

    # Return the original passed class when no subclasses exist
    assert(MyBadTestClass == get_platform_subclass(MyBadTestClass))



# Generated at 2022-06-11 01:38:50.738931
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    class TestDistro(object):
        @staticmethod
        def os_release_info():
            return {u'version_codename': u'xenial'}

        @staticmethod
        def lsb_release_info():
            return {u'codename': u'xenial'}

        @staticmethod
        def codename():
            return u''

        @staticmethod
        def id():
            return u'ubuntu'

    class TestPlatform(object):
        @staticmethod
        def system():
            return u'Linux'

    os_release_info = TestDistro.os_release_info
    lsb_release_info = TestDistro.lsb_release_info
    codename = TestDistro.codename
    distro_id = TestDistro.id
    system = TestPlatform.system

   

# Generated at 2022-06-11 01:38:56.621439
# Unit test for function get_distribution
def test_get_distribution():
    platform_distributions = {
        'Linux': 'OtherLinux',
        'Windows': 'Windows',
        'AIX': 'AIX',
        'Darwin': 'MacOSX',
        'FreeBSD': 'FreeBSD',
        'OpenBSD': 'OpenBSD',
        'NetBSD': 'NetBSD',
        'SunOS': 'Solaris',
    }

    system = platform.system()
    assert get_distribution() == platform_distributions[system]


# Generated at 2022-06-11 01:39:07.233874
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):

        platform =  "First"
        distribution = "A"

    class B(A):

        platform = "Second"
        distribution = "B"

    class C(B):
        platform = "Third"
        distribution = "C"

    class D(B):
        platform = "Second"
        distribution = "D"

    class E(object):
        platform = "Fourth"
        distribution = "E"

    class F(E):
        platform = "Fifth"
        distribution = "F"

    class G(E):
        platform = "Fourth"
        distribution = "G"

    class H(object):
        platform = "Sixth"

    class I(H):
        platform = "Seventh"
        distribution = "I"


# Generated at 2022-06-11 01:39:14.335052
# Unit test for function get_distribution_version
def test_get_distribution_version():
    for testcase in (
            (u'7', u'7'),
            (u'7.1', u'7.1'),
            (u'7.1.1503', u'7.1'),
            (None, u''),
            (u'', u''),
            (u'', u''),
    ):
        assert testcase[1] == get_distribution_version(testcase[0])


# Generated at 2022-06-11 01:39:24.975860
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Make sure get_distribution_codename returns the correct codename for each distribution
    '''
    # In the previous implementation of get_distribution_codename there was a bug
    # related to CentOS and Redhat, which would return the version of the distribution
    # instead of the codename.  CentOS 7.5 was codenamed 'Core' but the codename would
    # have returned 7.5, but Redhat 7.6 would also have returned 7.6.  This test is to
    # make sure that is fixed.

# Generated at 2022-06-11 01:39:35.624174
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Ad hoc unit test for function get_platform_subclass
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import load_platform_subclass as old_get_platform_subclass

    # mocking platform.system() and get_distribution()
    class MockPlatformSystem:
        def __call__(self):
            return self.system_name
        def __init__(self, system_name):
            self.system_name = system_name

    class MockGetDistribution:
        def __call__(self):
            return self.distribution_name
        def __init__(self, distribution_name):
            self.distribution_name = distribution_name

    old_platform_system = platform.system
    old_get_distribution = get_distribution

