

# Generated at 2022-06-11 01:29:50.323499
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import tempfile
    import os
    with tempfile.TemporaryDirectory() as os_release_dir:
        test_dir = os.path.join(os_release_dir, 'etc')
        os.makedirs(test_dir)
        os_release_path = os.path.join(test_dir, 'os-release')

        with open(os_release_path, 'w') as os_release:
            os_release.write('NAME=Fedora\nID=fedora\nVERSION_ID=29\nVERSION_CODENAME=Bo\nPRETTY_NAME="Fedora 29 (Bo)"')

        with tempfile.TemporaryDirectory() as lsb_release_dir:
            test_dir = os.path.join(lsb_release_dir, 'etc')

# Generated at 2022-06-11 01:30:01.926447
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Mock out function get_distribution()
    def mock_get_distribution():
        return "MockLinux"

    from ansible.module_utils.common._utils import get_platform_subclass
    get_platform_subclass_original = get_platform_subclass


# Generated at 2022-06-11 01:30:12.830395
# Unit test for function get_distribution_codename

# Generated at 2022-06-11 01:30:15.218700
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Compares what get_distribution_codename returns with what uname -r returns.
    '''
    assert get_distribution_codename() == platform.uname()[2]



# Generated at 2022-06-11 01:30:18.586794
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test Fedora platform
    platform_fedora = 'Linux'
    codename_fedora = get_distribution_codename()
    assert platform.system() == platform_fedora
    assert codename_fedora == 'Fedora'

    # Test Ubuntu platform
    platform_ubuntu = 'Linux'
    codename_ubuntu = get_distribution_codename()
    assert platform.system() == platform_ubuntu
    assert codename_ubuntu == 'Ubuntu'

# Generated at 2022-06-11 01:30:23.736447
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible.module_utils.facts.test.test_distribution import test_cases

    for case in test_cases:
        dist = get_distribution()
        version = get_distribution_version()
        assert dist == case.get('distribution')
        assert version == case.get('distribution_version')

# Generated at 2022-06-11 01:30:34.108915
# Unit test for function get_distribution
def test_get_distribution():
    if platform.system() != 'Linux':
        assert get_distribution() == distro.id().capitalize()
        return

    if platform.dist()[0] == 'Ubuntu':
        assert get_distribution() == 'Ubuntu'
    elif platform.dist()[0] == 'centos':
        assert get_distribution() == 'Centos'
    elif platform.dist()[0] == 'amzn':
        assert get_distribution() == 'Amazon'
    elif platform.dist()[0] == 'redhat':
        assert get_distribution() == 'Redhat'
    elif platform.dist()[0] == 'fedora':
        assert get_distribution() == 'Fedora'

# Generated at 2022-06-11 01:30:44.799864
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    def mock_distro_codename():
        return 'codename'

    def mock_lsb_release_info():
        return {'codename': 'codename'}

    def mock_os_release_info():
        return {'version_codename': 'codename'}

    def mock_os_release_info_empty():
        return {}

    def mock_distro_id():
        return u'ubuntu'

    def mock_distro_id_other():
        return u'distro_id_other'

    class MockDistro(distro.LinuxDistribution):
        def __init__(self, codename=None, lsb_release_info=None, os_release_info=None, distro_id=None):
            self.codename = codename
            self.lsb_release_info = l

# Generated at 2022-06-11 01:30:56.647122
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    Return the version of the distribution the code is running on
    """
    assert get_distribution_version() == '20.04'
    assert get_distribution_version() == '5.5'
    assert get_distribution_version() == '2.2.0'
    assert get_distribution_version() == '20.04'
    assert get_distribution_version() == '20.04'
    assert get_distribution_version() == '20.04'
    assert get_distribution_version() == '20.04'
    assert get_distribution_version() == '18.04'
    assert get_distribution_version() == '16.04'
    assert get_distribution_version() == '18.04'
    assert get_distribution_version() == '20.04'

# Generated at 2022-06-11 01:31:04.327526
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import contextlib
    import os
    import tempfile
    import textwrap

    @contextlib.contextmanager
    def fake_os_release(codename, id_like=None):
        '''
        Creates a fake /etc/os-release file with the given values for ``ID`` and
        ``VERSION_CODENAME``.

        :arg codename: Codename to set in the fake /etc/os-release file
        :arg id_like: Value for ``ID_LIKE`` to put in the fake /etc/os-release file
        '''
        fd, os_release_file = tempfile.mkstemp(prefix='ansible_os_release_test')


# Generated at 2022-06-11 01:31:13.503245
# Unit test for function get_distribution
def test_get_distribution():
    pass
#   assert get_distribution() in ('Amazon', 'Redhat', 'Fedora', 'Debian', 'Ubuntu', 'OpenSUSE', 'SUSE', 'Mandrake', 'Mageia', None)

# Generated at 2022-06-11 01:31:20.123811
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test for the Linux distribution codenames
    # The codename is stored in the version_codename key of /etc/os-release
    # The dictionary with the operating system name and codename will be returned
    # if the operating system is tested.
    # If the operating system is not tested, None will be returned.
    # We can use this to check if the get_distribution_code can detect Linux distribution.
    tested_linux_distribution = {
        'Debian': 'stretch',
        'Ubuntu': 'xenial',
        'Redhat': 'Maipo',
        'Centos': 'Core',
        'Fedora': 'Twenty Nine',
        'Amazon': '2018.03',
    }
    detected_os = get_distribution()
    detected_codename = get_distribution_codename()

# Generated at 2022-06-11 01:31:21.577571
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-11 01:31:30.573611
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        pass

    class B(A):
        platform = 'foo'

    class C(A):
        distribution = 'bar'

    class D(A):
        platform = 'foo'
        distribution = 'bar'

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(B) == A
    assert get_platform_subclass(C) == A
    assert get_platform_subclass(D) == A

    @staticmethod
    def get_platform():
        return 'foo'

    @staticmethod
    def get_distribution():
        return 'bar'

    class E(A):
        platform = get_platform
        distribution = get_distribution

    assert get_platform_subclass(A) == A
    assert get_platform_subclass(E) == E

# Generated at 2022-06-11 01:31:32.119547
# Unit test for function get_distribution
def test_get_distribution():

    assert get_distribution() == 'Linux' or get_distribution() == 'Darwin'

# Generated at 2022-06-11 01:31:43.436822
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the function get_platform_subclass()

    :return: a boolean indicating if the test succeed or not.
    '''
    from ansible.module_utils.basic import get_platform_subclass
    from ansible.module_utils.basic import AnsibleModule

    input_class = None
    cls = None
    result = False
    # initialize the class
    input_class = AnsibleModule(argument_spec={})
    # test for the class get_platform_subclass on input_class
    cls = get_platform_subclass(input_class)
    # check if cls is the same as input_class
    if cls == input_class:
        result = True
    return result

# Generated at 2022-06-11 01:31:53.371027
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test function for function get_distribution_codename
    :returns: Nothing
    '''

    from distutils import version

    # This is a basic test to ensure the function exists and
    # does not return None for distributions that have a codename.
    codename = get_distribution_codename()

    if distro.id() == 'debian':
        if distro.version() == '9':
            codename_version = version.StrictVersion('stretch')
        elif distro.version() == '10':
            codename_version = version.StrictVersion('buster')

        if version.StrictVersion(codename) < codename_version:
            raise AssertionError("Invalid code name returned for debian.")


# Generated at 2022-06-11 01:31:54.656828
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '8'

# Generated at 2022-06-11 01:32:06.206877
# Unit test for function get_distribution
def test_get_distribution():
    # RedHat Enterprise Linux 7
    with open("/etc/redhat-release", 'w') as f:
        f.write("Red Hat Enterprise Linux Server release 7.8 (Maipo)")
    assert get_distribution() == "Redhat"
    assert get_distribution_version() == "7.8"

    # Fedora 32
    with open("/etc/redhat-release", 'w') as f:
        f.write("Fedora release 32 (Thirty Two)")
    assert get_distribution() == "Fedora"
    assert get_distribution_version() == "32"

    # CentOS Linux release 8.1.1911 (Core)
    with open("/etc/centos-release", 'w') as f:
        f.write("CentOS Linux release 8.1.1911 (Core)")

# Generated at 2022-06-11 01:32:17.539941
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import mock
    import pytest

    @mock.patch.object(distro, 'lsb_release_info')
    @mock.patch.object(distro, 'os_release_info')
    def test_distribution_codename(mock_os_release_info, mock_lsb_release_info):
        # Test existing code name in /etc/os-release
        mock_os_release_info.return_value = {'version_codename': 'name'}
        codename = get_distribution_codename()
        assert 'name' == codename

        # Test existing Ubuntu code name in /etc/os-release
        mock_os_release_info.return_value = {'ubuntu_codename': 'name'}
        codename = get_distribution_codename()

# Generated at 2022-06-11 01:32:26.282424
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the get_distribution_codename function

    '''
    assert get_distribution_codename() is None
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:32:27.325732
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() != None

# Generated at 2022-06-11 01:32:37.857642
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Ensure that the correct subclass is selected for each platform
    '''

    class A(object):
        platform = 'A'
        distribution = None

    class B(object):
        platform = 'B'
        distribution = None

    class C(object):
        platform = 'A'
        distribution = 'C'

    class D(object):
        platform = 'A'
        distribution = 'D'

    # Class C should be selected because it's platform is 'A' and its distribution is 'C'
    ret_cls = get_platform_subclass(C)
    assert ret_cls == C

    # If platform doesn't support classes with a distribution, then the
    # generic subclass should be used
    ret_cls = get_platform_subclass(A)
    assert ret_cls == A

    # If

# Generated at 2022-06-11 01:32:42.817307
# Unit test for function get_platform_subclass

# Generated at 2022-06-11 01:32:52.184799
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Write a unit test for get_platform_subclass
    """
    from ansible.module_utils.common._collections_compat import Mapping
    class Base:
        pass

    class A(Base):
        pass

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(C):
        pass

    class F(E):
        pass

    class G(F):
        pass

    d = {
        # derived, base, assertion
        A: (D, C),
        F: (G, E),
        A: (G, C),
        C: (G, C),
        C: (A, None),
        A: (D, None),
    }


# Generated at 2022-06-11 01:33:05.587057
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.common._utils import get_distribution
    from ansible.module_utils.common._collections_compat import Mapping

    assert get_distribution() == u'Linux', 'Should be Linux '

    # Mock get_distribution for non Linux system
    def mock_distribution():
        return u'Windows 10'

    distro_save = distro.id
    distro.id = mock_distribution
    try:
        assert get_distribution() == u'Windows 10', 'Should be Windows 10'
    finally:
        distro.id = distro_save

    # Mock get_distribution for Linux system
    def mock_distribution():
        return u''

    distro_save = distro.id
    distro.id = mock_distribution

# Generated at 2022-06-11 01:33:17.246609
# Unit test for function get_distribution
def test_get_distribution():
    distribution_to_test = {
        'fedora-20': 'Fedora',
        'rhel-7.0': 'Redhat',
        'amzn-2014.09': 'Amazon',
        'debian-wheezy': 'Debian',
        'ubuntu-12.04': 'Ubuntu',
        'unknown': 'OtherLinux',
        'Darwin': None,
        'SunOS': None,
        'FreeBSD': None,
        'Windows': None,
    }
    for test_distro in distribution_to_test.keys():
        platform.system = lambda: test_distro.split('-')[0].title()
        distro.id = lambda: test_distro.split('-')[0].lower()

# Generated at 2022-06-11 01:33:18.599065
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'
    assert get_distribution_version() == '7.6'

# Generated at 2022-06-11 01:33:24.909422
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class ClassA(object):
        platform = 'Linux'
        distribution = 'RedHat'

    class ClassB(ClassA):
        platform = 'Linux'
        distribution = None

    class ClassC(ClassA):
        platform = 'FreeBSD'
        distribution = None

    assert get_platform_subclass(ClassA) == ClassA
    assert get_platform_subclass(ClassB) == ClassB
    assert get_platform_subclass(ClassC) == ClassC

# Generated at 2022-06-11 01:33:26.380458
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None



# Generated at 2022-06-11 01:33:40.777872
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename is None or isinstance(codename, (str, unicode)), 'codename should be None or a string'



# Generated at 2022-06-11 01:33:42.857235
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None

# Generated at 2022-06-11 01:33:53.645482
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        platform = 'Linux'
        distribution = None
    class B(A):
        pass
    class C(A):
        distribution = 'Fedora'
    class D(B):
        pass
    class E(C):
        pass
    class F(E):
        pass
    class G(C):
        platform = 'FreeBSD'

    assert get_platform_subclass(A) == A
    assert issubclass(get_platform_subclass(B), B)
    assert issubclass(get_platform_subclass(C), C)
    assert issubclass(get_platform_subclass(D), D)
    assert issubclass(get_platform_subclass(E), E)
    assert issubclass(get_platform_subclass(F), F)

# Generated at 2022-06-11 01:33:55.068388
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
   assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-11 01:34:03.590184
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    os_release_info = {
        'distro_id': u'ubuntu',
        'version_codename': u'xenial',
        'ubuntu_codename': u'xenial'
    }
    lsb_release_info = {
        'codename': u'xenial'
    }
    distribution = get_distribution_codename(os_release_info, lsb_release_info, u'ubuntu')
    assert distribution == u'xenial'
    distribution = get_distribution_codename(os_release_info, lsb_release_info, u'fedora')
    assert distribution is None

# Generated at 2022-06-11 01:34:04.970511
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:34:10.057650
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass(ClsWithPlatform) == ClsWithPlatform
    assert get_platform_subclass(ClsWithDistribution) == ClsWithDistribution
    assert get_platform_subclass(ClsWithDistributionAndPlatform) == ClsWithDistributionAndPlatform
    assert get_platform_subclass(ClsWithPlatformAndDistribution) == ClsWithPlatformAndDistribution


# Generated at 2022-06-11 01:34:21.311289
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    test_get_distribution_codename: Test the function get_distribution_codename

    :return: Boolean True or False
    '''

# Generated at 2022-06-11 01:34:31.749026
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    with open("/etc/os-release", "w") as out:
        os_release_str = '''NAME="Amazon Linux"
VERSION="2"
ID="amzn"
ID_LIKE="centos rhel fedora"
VERSION_ID="2"
PRETTY_NAME="Amazon Linux 2"
ANSI_COLOR="0;33"
CPE_NAME="cpe:2.3:o:amazon:amazon_linux:2"
HOME_URL="https://amazonlinux.com/"
'''
        out.write(os_release_str)
        out.close()
    codename = get_distribution_codename()
    assert codename is not None
    assert codename == "2"

# Generated at 2022-06-11 01:34:42.201834
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Init class to test
    class PlatformA:
        platform = "A"

    # Parametrize class PlatformA
    class PlatformA_AA(PlatformA):
        distribution = "AA"
    class PlatformA_AB(PlatformA):
        distribution = "AB"
    class PlatformA_AC(PlatformA):
        distribution = "AC"
    class PlatformA_AD(PlatformA):
        distribution = "AD"
    class PlatformA_AE(PlatformA):
        distribution = "AE"
    class PlatformA_AF(PlatformA):
        distribution = "AF"

    # Test with many cases
    assert get_platform_subclass(PlatformA) is PlatformA
    assert get_platform_subclass(PlatformA_AA) is PlatformA_AA
    assert get_platform_subclass(PlatformA_AB) is PlatformA_

# Generated at 2022-06-11 01:34:59.596098
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # test major version
    test_version = u'7.6.1810'
    assert test_version == get_distribution_version(), 'Failed get_distribution_version() unit test'

    # test minor version
    test_version = u'7.6.1810'
    assert test_version == get_distribution_version(), 'Failed get_distribution_version() unit test'

    # test empty version
    test_version = u''
    assert test_version == get_distribution_version(), 'Failed get_distribution_version() unit test'


# Generated at 2022-06-11 01:35:11.142438
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class base_class():
        platform = None
        distribution = None

    class base_linux(base_class):
        platform = 'Linux'

    class fedora(base_linux):
        distribution = 'Fedora'

    class rhel(base_linux):
        distribution = 'Redhat'

    class rhel_redhat(rhel):
        platform = 'redhat'
        distribution = 'Redhat'

    class rhel_fedora(rhel):
        distribution = 'Fedora'

    class rhel_family(rhel):
        pass

    class rhel_family_redhat(rhel_family):
        platform = 'redhat'
        distribution = 'Redhat'

    class rhel_family_fedora(rhel_family):
        platform = 'fedora'
        distribution = 'Fedora'

    platform

# Generated at 2022-06-11 01:35:21.247627
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Base(object):
        platform = 'Base'
        distribution = None

    class BaseAllLinux(object):
        platform = 'Linux'
        distribution = None

    class LinuxFoo(object):
        platform = 'Linux'
        distribution = 'Foo'

    class LinuxBar(object):
        platform = 'Linux'
        distribution = 'Bar'

    class MicrosoftX(object):
        platform = 'Microsoft'
        distribution = 'X'

    class MicrosoftY(object):
        platform = 'Microsoft'
        distribution = 'Y'

    class MicrosoftZ(object):
        platform = 'Microsoft'
        distribution = 'Z'

    class AllEverything(object):
        platform = None
        distribution = None

    class BaseAllEverything(object):
        platform = 'Base'
        distribution = None


# Generated at 2022-06-11 01:35:33.008984
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # Example classes to test get_platform_subclass() on
    class PlatformA(object):
        platform = 'PlatformA'
        distribution = None

    class PlatformB(object):
        platform = 'PlatformB'
        distribution = None

    class DistributionXPlatformA(object):
        platform = 'PlatformA'
        distribution = 'DistributionX'

    class DistributionXPlatformB(object):
        platform = 'PlatformB'
        distribution = 'DistributionX'

    class DistributionYPlatformA(object):
        platform = 'PlatformA'
        distribution = 'DistributionY'

    class DistributionYPlatformB(object):
        platform = 'PlatformB'
        distribution = 'DistributionY'

    class PlatformC(PlatformA):
        platform = 'PlatformC'


# Generated at 2022-06-11 01:35:34.397461
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-11 01:35:43.353640
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import mock
    import platform

    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import Mapping

    def _fake__uname(self):
        class X(object):
            pass
        ret = X()
        ret.system = 'Linux'
        return ret

    def _fake_uname(self):
        return 'Linux'

    def _fake_os_release_info(self):
        return {'version_codename': 'bionic'}


# Generated at 2022-06-11 01:35:54.288653
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function ``get_platform_subclass``

    This unit test also indirectly tests the :class:`@platform_subclass <ansible.module_utils.basic.AnsibleModule.platform_subclass>`
    decorator.

    :returns: True if the unit tests pass and False otherwise
    '''
    import sys
    import types

    class Base(object):
        '''
        Base class
        '''

    @platform_subclass(platform='Linux')
    class LinuxSubclass(Base):
        '''
        Subclass of Base1 class
        '''

    @platform_subclass(platform='Linux', distribution='Redhat')
    class RedhatSubclass(LinuxSubclass):
        '''
        Subclass of Base2 class
        '''


# Generated at 2022-06-11 01:35:57.045828
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    for subclass_name in ('Linux', 'RedHat', 'SUSE', 'Debian'):
        assert subclass_name == getattr(
            get_platform_subclass(BasePlatform), 'distribution').capitalize()



# Generated at 2022-06-11 01:35:57.974596
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:36:03.804862
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    function to test get_distribution_version
    '''
    my_distribution = 'centos'
    my_version = '7.5.1804'
    my_expected = '7.5'
    my_result = get_distribution_version(my_distribution, my_version)
    if my_result == my_expected:
        print('Test - passed')
    else:
        print('Test - failed')

# Generated at 2022-06-11 01:36:25.073627
# Unit test for function get_distribution
def test_get_distribution():
    def assert_distro(expected_distro, os_release='', lsb_release='', platform_system=''):
        distro.distro_info_cache.clear()
        # set for later retrieval
        distro._lsb_release = lsb_release
        distro._os_release = os_release
        distro._platform_system = platform_system
        distro.id()
        assert distro.get_distribution() == expected_distro

    assert_distro('Linux')
    assert_distro('SuSe', platform_system='Linux', lsb_release='SuSE')
    assert_distro('Fedora', platform_system='Linux', lsb_release='Fedora')
    assert_distro('Debian', platform_system='Linux', lsb_release='Debian')

# Generated at 2022-06-11 01:36:34.264939
# Unit test for function get_distribution
def test_get_distribution():
    import functools
    import sys
    import unittest

    @functools.wraps(unittest.TestCase)
    class TestGetDistribution(unittest.TestCase):
        def setUp(self):
            self.old_platform = sys.modules.pop('platform', None)
            sys.modules['platform'] = self._MockPlatform()
            self.old_distro = sys.modules.pop('distro', None)
            sys.modules['distro'] = self._MockDistro()

        def tearDown(self):
            if self.old_platform is not None:
                sys.modules['platform'] = self.old_platform
            else:
                del sys.modules['platform']
            if self.old_distro is not None:
                sys.modules['distro'] = self.old_

# Generated at 2022-06-11 01:36:36.046900
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None
    assert get_distribution_version() != u''



# Generated at 2022-06-11 01:36:47.172571
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
        Unit test for function get_platform_subclass

        returns: True or False
    '''

    class A:
        platform = "linux"
        distribution = None

    class B(A):
        platform = "linux"
        distribution = "Fedora"

    class C(A):
        platform = "linux"
        distribution = "Redhat"

    class C1(C):
        platform = "linux"
        distribution = "Redhat"

    class D(A):
        platform = "linux"
        distribution = "Scientific"

    class E(A):
        platform = "linux"
        distribution = "Debian"

    class F(A):
        platform = "linux"
        distribution = "Debian"

    class G(A):
        platform = "linux"
        distribution = "Ubuntu"



# Generated at 2022-06-11 01:36:57.899891
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    # Replace distro.os_release_info() with a generator that yields tuples of key/value pairs
    old_os_release_info = distro.os_release_info
    with patch.object(distro, 'os_release_info') as mock_os_release_info:
        # Test when version_codename is set
        mock_os_release_info.return_value = dict(version_codename='wheezy')
        assert get_distribution_codename() == 'wheezy'
        # Test when version_codename is not set
        mock_os_release_info.return_value = dict()
        assert get_distribution_codename() is None
    # Restore the os_release_info function
    distro.os_release_info = old_

# Generated at 2022-06-11 01:37:02.266339
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class MyBase:
        pass

    class MyConcrete(MyBase):
        platform = 'LOL'
        distribution = 'FUN'

    assert get_platform_subclass(MyBase)
    assert MyBase == get_platform_subclass(MyBase)
    assert MyConcrete == get_platform_subclass(MyBase)

# Generated at 2022-06-11 01:37:14.979858
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # common class for testing
    class Base:
        pass

    class Linux(Base):
        platform = 'Linux'

    class Darwin(Base):
        platform = 'Darwin'

    class LinuxRedHat(Linux):
        distribution = 'Redhat'

    class LinuxAmazon(Linux):
        distribution = 'Amazon'

    class LinuxCentOS(Linux):
        distribution = 'CentOS'

    class LinuxSUSE(Linux):
        distribution = 'SUSE'

    class LinuxMint(Linux):
        distribution = 'Mint'

    # test data

# Generated at 2022-06-11 01:37:15.573084
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution()


# Generated at 2022-06-11 01:37:19.351118
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test codenames
    assert get_distribution_codename() == 'xenial'
    assert get_distribution_codename() == 'stretch'
    # Test no codename
    assert get_distribution_codename() == '28'
    # Test if not Linux
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:37:20.606083
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename is not None

# Generated at 2022-06-11 01:37:45.486788
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    codename = get_distribution_codename()

    assert isinstance(codename, str)


# Generated at 2022-06-11 01:37:51.322529
# Unit test for function get_distribution
def test_get_distribution():
    current = get_distribution()

    if platform.system() == 'Linux':
        if platform.linux_distribution()[0] == 'Amazon':
            assert current == 'Amazon'
        elif platform.linux_distribution()[0] == 'CentOS':
            assert current == 'Centos'
        elif platform.linux_distribution()[0] == 'Debian':
            assert current == 'Debian'
        elif platform.linux_distribution()[0] == 'Red Hat Enterprise Linux Server':
            assert current == 'Redhat'
        elif platform.linux_distribution()[0] == 'Ubuntu':
            assert current == 'Ubuntu'
        else:
            assert current == 'OtherLinux'
    elif platform.system() == 'FreeBSD':
        assert current == 'Freebsd'

# Generated at 2022-06-11 01:37:54.863384
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    if not codename:
        raise Exception("Invalid codename")


if __name__ == '__main__':
    test_get_distribution_codename()

# Generated at 2022-06-11 01:37:56.342420
# Unit test for function get_distribution
def test_get_distribution():
    assert(get_distribution() == distro.id().capitalize())


# Generated at 2022-06-11 01:37:58.603229
# Unit test for function get_distribution_version
def test_get_distribution_version():

    d = get_distribution_version()
    print('Distribution version: %s' % d)


# Generated at 2022-06-11 01:38:08.249175
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # pylint: disable=missing-docstring
    import platform
    import unittest
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat import mock
    from ansible.module_utils.common.get_distribution_info import get_distribution_codename, get_distribution_version, get_platform_subclass
    from ansible.module_utils.common.get_distribution_info import get_distribution

    class ClassA(object):
        platform = 'Linux'
        distribution = None

    class ClassB(ClassA):
        distribution = 'LinuxMint'

    class ClassC(ClassB):
        distribution = 'LinuxMint'
        codename = 'qiana'

    class ClassD(ClassB):
        distribution = 'LinuxMint'
       

# Generated at 2022-06-11 01:38:17.743536
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename

    :returns: None
    '''
    # Test specific codename in /etc/os-release
    with open(os.path.join(os.path.dirname(__file__), 'os-releases', 'elementary'), 'r') as f:
        with patch('ansible.module_utils.distro._distro.open', Mock(return_value=f)):
            assert get_distribution_codename() == u'juno'

    # Test for codename in /etc/lsb-release

# Generated at 2022-06-11 01:38:24.652561
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Test get_platform_subclass function of module_utils
    """
    class Foo(object):
        pass

    class FooRedhat(Foo):
        distribution = 'Redhat'

    class FooAmzn(Foo):
        distribution = 'Amazon'

    class FooLinux(Foo):
        distribution = None

    def get_platform_subclass_of(cls):
        ''' Returns the subclass that would be returned by get_platform_subclass '''
        return get_platform_subclass(cls)

    # return the subclass matching the current platform
    assert F

# Generated at 2022-06-11 01:38:36.046202
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the platform.get_distribution_version() function for correct values

    :returns: True if the test cases are successful, false otherwise
    '''

    # test platforms that are known to need the best version
    tests = {
        u'centos': (u'7.0', u'7'),
        u'debian': (u'1.3', u'1.3')
    }

    passed = True

    for distro, versions in tests.items():
        returned_value = distro.version()
        best_version = distro.version(best=True)
        assert_value = returned_value == versions[0]
        expected_value = versions[1]

        passed &= assert_value

# Generated at 2022-06-11 01:38:44.462208
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        pass
    class B(A):
        platform = 'Linux'
        distribution = None
    class C(A):
        platform = 'Linux'
        distribution = 'Redhat'
    class D(A):
        platform = 'Linux'
        distribution = 'Redhat'
    class E(C):
        pass
    class F(D):
        pass

    A.platform = 'SunOS'
    A.distribution = None
    B.platform = 'SunOS'
    B.distribution = None
    C.platform = 'AIX'
    C.distribution = None
    D.platform = 'Linux'
    D.distribution = 'Redhat'
    E.platform = 'Linux'
    E.distribution = 'Redhat'
    F.platform = 'Linux'
    F.distribution

# Generated at 2022-06-11 01:39:29.811709
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == u'stretch'

# Generated at 2022-06-11 01:39:38.857583
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    # TODO: Needs more validation

    # CentOS / RHEL
    # Testing is done with a CentOS 7 machine
    # /etc/os-release
    # CentOS Linux release 7.6.1810 (Core)
    assert get_distribution_codename() == 'Core'

    # Debian / Ubuntu
    # Upstream bug report https://bugs.debian.org/cgi-bin/bugreport.cgi?bug=931197
    # Debian Buster testing with /etc/os-release
    # PRETTY_NAME="Debian GNU/Linux buster/sid"
    # NAME="Debian GNU/Linux"
    # ID=debian
    # HOME_URL="https://www.debian.org/"
    # SUPPORT_URL="https://www.debian.org