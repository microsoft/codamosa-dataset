

# Generated at 2022-06-11 01:29:50.253003
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test function get_distribution
    '''
    # Set up distribution and architecture
    distribution = get_distribution()

    # Check distribution
    if distribution is not None:
        assert distribution in ("Redhat", "Centos", "Debian", "Amzn", "Ubuntu", "Amazon", "OtherLinux"), \
            'test_get_distribution failed: distribution is not expected. Got ' + distribution
    else:
        assert True, 'test_get_distribution failed: distribution is None.'

# Generated at 2022-06-11 01:29:56.316322
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test for module_utils.platform_impl.get_distribution

    :returns: None

    This function tests the functionality of the function ``get_distribution()`` to make sure it returns the correct
    distribution name.

    '''
    distribution = get_distribution()
    assert distribution == 'Linux', \
        "Expected get_distribution to return 'Linux', got {0}".format(distribution)

# Generated at 2022-06-11 01:30:02.074428
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    subclasses = get_all_subclasses(get_platform_subclass())
    version_codename_mapping = {}
    for subclass in subclasses:
        codename = get_distribution_codename()
        if codename is not None:
            version_codename_mapping[subclass.distribution] = codename
    return version_codename_mapping

# Generated at 2022-06-11 01:30:03.708809
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert distribution is not None

# Generated at 2022-06-11 01:30:04.374682
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:30:09.743520
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from distutils.version import LooseVersion

    # Test for versions in the form of major.minor.patch-suffix
    version = '14.1.2-default'
    assert LooseVersion(distro.version_info(version).version_string()) == LooseVersion(get_distribution_version())

    # Test for versions in the form of major.minor-suffix
    version = '13.2-default'
    assert LooseVersion(distro.version_info(version).version_string()) == LooseVersion(get_distribution_version())

    # Test for versions in the form of major.minor.patch (e.g. Gentoo)
    version = '9.1.2'

# Generated at 2022-06-11 01:30:10.763498
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert 'string' in get_distribution_version()

# Generated at 2022-06-11 01:30:18.224799
# Unit test for function get_distribution
def test_get_distribution():
    # Test for Linux
    distributions = {
        'amazon': 'Amazon',
        'centos linux': 'Redhat',
        'fedora': 'Fedora',
        'freebsd': 'FreeBSD',
        'linuxmint': 'LinuxMint',
        'n/a': 'OtherLinux',
        'opensuse': 'Suse',
        'oracle': 'OracleLinux',
        'oracle linux server': 'OracleLinux',
        'red hat enterprise linux server': 'Redhat',
        'scientific': 'Scientific',
        'suse': 'Suse',
        'ubuntu': 'Ubuntu',
    }

    for dist, dist_name in distributions.items():
        # Implement distro.id to return the item in distributions
        distro.id = lambda: dist

# Generated at 2022-06-11 01:30:24.005163
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test function get_distribution

    :rtype: None
    :returns: Nothing
    '''
    assert get_distribution() in ('Centos', 'Debian', 'Freebsd', 'Linux', 'OtherLinux', 'Redhat', 'OtherLinux', 'Darwin', 'Aix', 'Sunos') or platform.system() == get_distribution()

# Generated at 2022-06-11 01:30:24.663991
# Unit test for function get_distribution
def test_get_distribution():
    get_distribution()

# Generated at 2022-06-11 01:30:39.502113
# Unit test for function get_distribution
def test_get_distribution():
    cur_distro = get_distribution()
    cur_platform = platform.system()

    if cur_platform == 'Linux':
        assert isinstance(cur_distro, basestring)
        assert cur_distro != ''
        assert cur_distro.capitalize() == distro.id().capitalize(), 'current distribution |%s| should be |%s|' % (cur_distro, distro.id().capitalize())

        if cur_distro == 'Debian':
            assert cur_distro == 'Debian'
        elif cur_distro == 'Ubuntu':
            assert cur_distro == 'Ubuntu'
        elif cur_distro == 'LinuxMint':
            assert cur_distro == 'LinuxMint'
        elif cur_distro == 'Gentoo':
            assert cur_

# Generated at 2022-06-11 01:30:51.286298
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """ get_distribution_version function unit test"""
    #  Test case for Redhat distribution
    #  Example: Redhat 7.3
    platform.system = lambda: "Linux"
    distro.id = lambda: "rhel"
    distro.version = lambda: "7.3"
    version = get_distribution_version()
    assert version == "7.3"

    #  Test case for Debian distribution
    #  Example: Debian 9.6
    platform.system = lambda: "Linux"
    distro.id = lambda: "debian"
    distro.version = lambda: "9.6"
    distro.version = lambda: "9.6"
    version = get_distribution_version()
    assert version == "9.6"

    #  Test case for Debian distribution
    #  Example: Debian

# Generated at 2022-06-11 01:31:01.067752
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version for every distribution
    '''
    versions = {
        # debian 7
        'debian': u'7.11',
        # centos 7
        'centos': u'7',
        # ubuntu 16.04
        'ubuntu': u'16.04',
        # amzn
        'amazon': u'2',
        # redhat
        'redhat': u'7.6',
        'fedora': u'27',
        # suse
        'opensuse': u'42.3',
        'suse': u'12.4',
        # oracle
        'oracle': u'7.4',
        # Scientific Linux
        'scientific': u'7.4',
        # Unknown distro
        'Unknown': ''
    }


# Generated at 2022-06-11 01:31:11.003376
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    class FakeDistro:
        @staticmethod
        def id():
            return 'debian'

        @staticmethod
        def version(best=False):
            return '9.9'

        @staticmethod
        def codename():
            return 'stretch'

        @staticmethod
        def os_release_info():
            return dict(
                version_codename='stretch',
            )

        @staticmethod
        def lsb_release_info():
            return dict(
                distribution_id='Debian',
                codename='stretch',
            )

    saved_distro = distro
    distro = FakeDistro

    assert 'stretch' == get_distribution_codename()

    distro = saved_distro

# Generated at 2022-06-11 01:31:22.167353
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test for get_platform_subclass for the following 3 cases :

    1. class for specific Linux distribution
    2. class for generic Linux distribution
    3. class for non-Linux platform
    '''
    try:
        import ansible.modules.system.user as user
    except ImportError:
        import ansible.modules.system.user_detect as user

    # Test case 1 - Match specific Linux distribution
    assert user.get_platform_subclass(user.User) == user.UserLinux
    # Test case 2 - Match generic Linux distribution
    assert user.get_platform_subclass(user.UserLinux) == user.UserLinux
    # Test case 3 - Match non-Linux platform
    assert user.get_platform_subclass(user.UserFreeBSD) == user.UserFreeBSD

# Generated at 2022-06-11 01:31:23.474794
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-11 01:31:31.573355
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test for class that does not have a subclass defined yet
    class TestPlatform:
        platform = 'Linux'
        distribution = None

    subTestPlatform = get_platform_subclass(TestPlatform)
    assert subTestPlatform == TestPlatform

    # Test for class that has a subclass defined, platform matches, subclass distribution also matches
    class TestPlatform:
        platform = 'Linux'
        distribution = 'RedHat'

    class TestPlatformSubNoDist:
        platform = 'Linux'
        distribution = None

    class TestPlatformSubDist:
        platform = 'Linux'
        distribution = 'RedHat'

    subTestPlatform = get_platform_subclass(TestPlatform)
    assert subTestPlatform == TestPlatformSubDist

    # Test for class that has a subclass defined, platform matches, subclass distribution does not match

# Generated at 2022-06-11 01:31:44.265513
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base(object):
        pass

    class LinuxOnly(Base):
        platform = 'Linux'
        distribution = None

    class LinuxUbuntu(Base):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class LinuxUbuntu18(Base):
        platform = 'Linux'
        distribution = 'Ubuntu'
        version = '18'

    class LinuxUbuntu16(Base):
        platform = 'Linux'
        distribution = 'Ubuntu'
        version = '16'

    class Darwin(Base):
        platform = 'Darwin'
        distribution = None

    assert get_platform_subclass(Base) == Base
    assert get_platform_subclass(LinuxOnly) == LinuxOnly
    assert get_platform_subclass(LinuxUbuntu) == LinuxUbuntu
    # arg is instance of LinuxUbuntu, return most specific

# Generated at 2022-06-11 01:31:53.961630
# Unit test for function get_distribution_codename

# Generated at 2022-06-11 01:32:00.227222
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test Ubuntu Trusty
    result = get_distribution_codename()
    assert result == 'trusty'

    # Test Debian Jessie
    result = get_distribution_codename()
    assert result == 'jessie'

    # Test CentOS 7
    result = get_distribution_codename()
    assert result == 'Core'

    # Test Fedora 28
    result = get_distribution_codename()
    assert result == None

# Generated at 2022-06-11 01:32:21.777367
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''Tests for functions defined in module_utils.basic.py
    This include the get_platform_subclass function.
    '''

    # Test Get_Platform_Subclass
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        # Ansible < 2.0
        from ansible.module_utils.basic import *

    sys_platform = platform.system()
    distribution = get_distribution()
    version = get_distribution_version()

    # Add test classes for all supported platforms and distributions to test
    # the method get_platform_subclass

    class TestGenericPlatform(object):
        ''' This is a generic class for a linux platform'''
        platform = 'Linux'  # Name of the platform
        distribution = None  # Distribution name
        version = None


# Generated at 2022-06-11 01:32:34.252083
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test get_platform_subclass()
    '''
    class Foo:
        platform = None
        distribution = None

    class Bar(Foo):
        distribution = 'Redhat'

    class Baz(Foo):
        distribution = 'Suse'

    class FooBar(Foo):
        platform = 'Linux'

    class FooBaz(Foo):
        platform = 'Linux'
        distribution = 'Redhat'

    class BarBaz(Bar):
        platform = 'Linux'
        distribution = 'Redhat'

    class BarQuux(Bar):
        platform = 'Linux'
        distribution = 'Suse'

    # Test 1
    # No distribution.
    # No platform specified.
    cls = get_platform_subclass(Foo)
    assert cls == Foo

    # Test 2


# Generated at 2022-06-11 01:32:46.288693
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Make this test runnable from the command line directly
    from unittest import TestCase
    from collections import namedtuple

    class DefaultClass(object):
        platform = 'All Platforms'
        distribution = None

    class FakeClass(DefaultClass):
        platform = 'Linux'
        distribution = 'FakeLinuxDistro'

    class TestPlatform(TestCase):
        def test_get_platform_subclass(self):
            self.assertEqual(get_platform_subclass(DefaultClass), DefaultClass)
            self.assertEqual(get_platform_subclass(FakeClass), FakeClass)

            FakeModule = namedtuple('FakeModule', 'platform distribution')
            fake_module = FakeModule(platform='Linux', distribution='FakeLinuxDistro')

# Generated at 2022-06-11 01:32:55.268102
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class ExampleBase:
        '''
        Base class for different implementations of Example
        '''

    class ExampleBaseUbuntu(ExampleBase):
        '''
        Base class for different implementations of AnsibleModule on Ubuntu platforms
        '''
        distribution = u'Ubuntu'
        platform = u'Linux'

    class ExampleBaseUbuntu1804(ExampleBaseUbuntu):
        '''
        Implementation of AnsibleModule on Ubuntu 18.04
        '''
        distribution = u'Ubuntu'
        platform = u'Linux'
        distribution_version = u'18.04'

    class ExampleBaseUbuntu1604(ExampleBaseUbuntu):
        '''
        Implementation of AnsibleModule on Ubuntu 16.04
        '''
        distribution = u'Ubuntu'
        platform = u'Linux'

# Generated at 2022-06-11 01:33:07.797979
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import types

    # Make an empty class that has no subclasses.  This is what we want to test get_platform_subclass
    # with.
    class MyAnsibleModule:
        pass

    # This class is a subclass that uses the platform Linux.  We'll not use this in the test.
    class MyAnsibleModuleLinux(MyAnsibleModule):
        platform = 'Linux'

    # This class is a subclass of MyAnsibleLinuxModule that is for the distribution Debian.  We'll
    # choose to use this class in the test.
    class MyAnsibleModuleDebian(MyAnsibleModuleLinux):
        distribution = u'Debian'

    # This class is a subclass of MyAnsibleModuleLinux that is for the distribution Redhat.  This class
    # should not be selected because this test is running on a Debian

# Generated at 2022-06-11 01:33:18.844898
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from functools import partial
    import platform
    import sys

    # Some distros come with both python 2 and python 3 installed.  Running `python`
    # will run python 2 but running `python3` will run python 3.  In that case, we'll
    # get different results in our tests depending on which python is being run.  This
    # check protects against that.
    #
    # We always want to be testing the behavior of the system when the python major
    # version matches the major version of the python we're running.
    if platform.python_version_tuple()[0] != sys.version_info[0]:
        raise NotImplementedError("Please run these tests with the same major version of python that the system you're testing has installed.")

    # Our test class hierarchy is:
    #
    #    Grandparent
    #       

# Generated at 2022-06-11 01:33:20.977825
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assertequal = "unit test for get_distribution_version"
    assert get_distribution_version() == '', assertequal

# Generated at 2022-06-11 01:33:31.989132
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class _BaseClass(object):
        platform = 'BasePlatform'
        distribution = None

    class _BasePlatformAnotherSubClass(_BaseClass):
        platform = 'BasePlatform'
        distribution = 'AnotherLinux'

    class _BasePlatformSubClass(_BaseClass):
        platform = 'BasePlatform'
        distribution = 'Linux'

    class _AnotherPlatformSubClass(_BaseClass):
        platform = 'AnotherPlatform'
        distribution = None


    class _SpecificSubClass(_BasePlatformSubClass):
        platform = 'BasePlatform'
        distribution = 'Linux'

    class _MoreSpecificSubClass(_BasePlatformSubClass):
        platform = 'BasePlatform'
        distribution = 'Linux'

    class _ChangeSubClass(_BaseClass):
        platform = 'BasePlatform'
        distribution = 'Linux'

    class _TestClass(_BaseClass):
        platform

# Generated at 2022-06-11 01:33:42.858827
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the behavior of get_distribution_codename across various known linux
    platforms.  We do this by patching the underlying distro module's os_release_info()
    and lsb_release_info() methods.
    '''

# Generated at 2022-06-11 01:33:53.645778
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.common._utils import get_all_subclasses

    class GenericClass:
        platform = "Generic"
        distribution = None

    class GenericPosix(GenericClass):
        platform = "GenericPosix"

    class Linux(GenericPosix):
        platform = "Linux"

    class Redhat(Linux):
        distribution = "Redhat"

    class Debian(Linux):
        distribution = "Debian"

    class SUSE(Linux):
        distribution = "SUSE"

    class Fedora(Linux):
        distribution = "Fedora"

    class OpenSuSE(Linux):
        distribution = "OpenSuSE"

    class OpenWrt(Linux):
        distribution = "OpenWrt"

    class OpenBSD(GenericPosix):
        platform = "OpenBSD"


# Generated at 2022-06-11 01:34:06.516126
# Unit test for function get_distribution_version
def test_get_distribution_version():

    assert get_distribution_version() == '14.04'

# Generated at 2022-06-11 01:34:08.038618
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    # Case 1
    # Method returns None if it is not a Linux distribution
    assert get_distribution_codename() is None

    # Case 2
    # Method returns code name if it is a Linux distribution
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-11 01:34:11.471786
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Verify that get_distribution_version() returns a string
    assert isinstance(get_distribution_version(), basestring)

    # Verify that get_distribution_version() returns an empty string if the
    # platform is not Linux and not FreeBSD
    assert get_distribution_version() is None or len(get_distribution_version()) >= 1

# Generated at 2022-06-11 01:34:16.931978
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    class BaseModule(AnsibleModule):
        pass

    class BasePlatformCorrect(BaseModule):
        platform = 'Linux'

    class BasePlatformIncorrect(BaseModule):
        platform = 'FreeBSD'

    class Subclass1(BasePlatformCorrect):
        distribution = 'RedHat'
        distribution_version = '7'

    class Subclass2(BasePlatformCorrect):
        distribution = 'RedHat'
        distribution_version = '6'

    class Subclass3(BasePlatformCorrect):
        distribution = 'Amazon'
        distribution_version = '2'

    class Subclass4(BasePlatformIncorrect):
        distribution = 'Debian'
        distribution_version = '8'

    class Subclass5(BasePlatformCorrect):
        distribution = 'Debian'
        distribution_

# Generated at 2022-06-11 01:34:24.436034
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestClass(object):
        platform = ''
        distribution = ''

    class TestClass2(TestClass):
        platform = 'Linux'
        distribution = 'Redhat'

    def test_get_platform_subclass_should_return_linux_redhat():
        assert TestClass2 == get_platform_subclass(TestClass)

    def test_get_platform_subclass_should_return_linux_redhat_b():
        assert TestClass2 == get_platform_subclass(TestClass2)

# Generated at 2022-06-11 01:34:25.829953
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert '7' == get_distribution_version()


# Generated at 2022-06-11 01:34:27.731231
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == distro.id().capitalize()



# Generated at 2022-06-11 01:34:35.808648
# Unit test for function get_platform_subclass

# Generated at 2022-06-11 01:34:37.846588
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    # TODO: Unit test this on Debian and Ubuntu and various versions of Fedora

# Generated at 2022-06-11 01:34:50.036159
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.distribution import Distribution

    module = AnsibleModule(
        os_platform=None,
        os_distribution=None,
        os_family=None,
        os_release=None,
    )

    distro = Distribution(module)

    # Simple cases in alphabetical order
    assert distro.get_distribution_version() == '7.6', 'CentOS 7.x returns "7.6".'
    assert distro.get_distribution_version() == '17.7', 'Debian 17.x returns "17.7".'

# Generated at 2022-06-11 01:35:22.777060
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Main:
        platform = None
        distribution = None
        def __init__(self, *args, **kwargs):
            pass

    class OtherLinux(Main):
        platform = 'Linux'
        distribution = 'OtherLinux'
        def __init__(self, *args, **kwargs):
            super(OtherLinux, self).__init__(*args, **kwargs)

    class Debian(Main):
        platform = 'Linux'
        distribution = 'Debian'
        def __init__(self, *args, **kwargs):
            super(Debian, self).__init__(*args, **kwargs)

    class LinuxLike(Main):
        platform = 'Linux'
        distribution = None

# Generated at 2022-06-11 01:35:26.750052
# Unit test for function get_distribution
def test_get_distribution():

    assert get_distribution() is not None

    # Test the case of an unsupported platform with None
    assert get_distribution_version() is None

    # Test the case of an unsupported platform with not-None
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:35:37.526798
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    A simple unittest to make sure that get_platform_subclass works.
    '''
    class MyBaseClass(object):
        platform = 'Linux'
        distribution = None

    class MyFedoraClass(MyBaseClass):
        platform = 'Linux'
        distribution = 'Fedora'

    class MyRHELClass(MyBaseClass):
        platform = 'Linux'
        distribution = 'RedHat'

    class MyTestClass(MyBaseClass):
        '''
        A class that is supposed to return the base class
        '''
        platform = 'Linux'
        distribution = None

    subclass = get_platform_subclass(MyTestClass)
    assert subclass is MyBaseClass

    subclass = get_platform_subclass(MyFedoraClass)
    assert subclass is MyFedoraClass

    subclass = get_platform

# Generated at 2022-06-11 01:35:39.603877
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename = get_distribution_codename()
    assert distribution_codename in ['', 'xenial', 'bionic', 'focal', 'buster', None]


# Generated at 2022-06-11 01:35:46.879950
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseUser(object):
        """Base User class"""
        platform = 'Linux'
        distribution = None

    class UserLinux(BaseUser):
        """User class implemented on Linux"""
        platform = 'Linux'

    class UserLinuxRedHat(UserLinux):
        """User class implemented on Linux Red Hat"""
        platform = 'Linux'
        distribution = 'Redhat'

    class UserLinuxDebian(UserLinux):
        """User class implemented on Linux Debian"""
        platform = 'Linux'
        distribution = 'Debian'

    class UserLinuxIosxr(UserLinux):
        """User class implemented on Linux Iosxr"""
        platform = 'Linux'
        distribution = 'Iosxr'


# Generated at 2022-06-11 01:35:57.443031
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class SuperClass:
        platform = None
        distribution = None
    class SubClass1(SuperClass):
        platform = 'Linux'
        distribution = 'FreeBSD'
    class SubClass2(SuperClass):
        platform = 'Linux'
        distribution = 'Redhat'
    class SubClass3(SuperClass):
        distribution = 'Redhat'
    class SubClass4(SuperClass):
        platform = 'Linux'
    class SubClass5(SuperClass):
        platform = 'Linux'
        distribution = 'Redhat'
    class SubClass6(SuperClass):
        platform = 'Linux'
        distribution = 'Redhat'
    class SubClass7(SubClass5):
        platform = 'Linux'
        distribution = 'Redhat'

    # No subclass
    platform.system = lambda: 'Linux'

# Generated at 2022-06-11 01:36:07.053904
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import sys
    import tempfile
    import textwrap
    import unittest

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import builtins

    builtins.__dict__['__salt__'] = dict()

    class FakeDistro:
        id = 'FakeLinux'
        version = lambda best: '0.0.0'
        os_release_info = lambda: dict()
        codename = lambda: ''

    def setUpModule():
        sys.modules['distro'] = FakeDistro()

    def tearDownModule():
        del sys.modules['distro']

        builtins = vars(builtins)
        for k in ('__salt__',):
            if k in builtins:
                del builtins[k]


# Generated at 2022-06-11 01:36:08.017963
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:36:15.779495
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.common._utils import _module_class_for_name

    test_get_distribution.__name__ = 'ModuleTest.test_get_distribution'
    for distro_name in ('Amazon', 'Debian', 'Foo', 'Redhat', 'Ubuntu'):
        with  _module_class_for_name(test_get_distribution)({'ID': distro_name}, module_name=test_get_distribution.__name__):
            assert get_distribution() == distro_name


# Generated at 2022-06-11 01:36:25.824101
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''

    class FakeModule:
        '''
        Provided a class where it will look for the target class
        '''
        class GenericClass:
            '''
            Base class for this test
            '''
            platform = None
            distribution = None

        class Linux(GenericClass):
            '''
            Subclass that matches the current platform
            '''
            platform = 'Linux'

        class LinuxDebian(Linux):
            '''
            Subclass that matches the current platform and distribution
            '''
            distribution = 'Debian'

        class Other(GenericClass):
            '''
            Subclass that matches the current platform
            '''
            platform = 'Solaris'
            distribution = None


# Generated at 2022-06-11 01:36:58.897197
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    distribution_version = get_distribution_version()

    # Skip test if this is not a Linux machine
    if distribution_version is None:
        return

    parts = distribution_version.split('.')

    # Skip if this is not a Linux machine
    if not parts:
        return

    assert isinstance(parts, list), "Return value of get_distribution_version is not a list"
    assert len(parts) > 0, "Return value of get_distribution_version is an empty list"

    for part in parts:
        assert isinstance(part, str), "Return value of get_distribution_version is not a string"
        assert int(part), "Return value of get_distribution_version is not an integer"

# Generated at 2022-06-11 01:37:10.259995
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """Basic validation that get_distribution_version gives expected results."""
    from ansible.module_utils import basic

    distribution_version_data = [
        (u'7.5', u'centos7.5.1804', u'7.5'),
        (u'7.6', u'centos7.6.1810', u'7.6'),
        (u'16.04', u'xenial', u'16.04'),
        (u'18.04', u'bionic', u'18.04'),
    ]


# Generated at 2022-06-11 01:37:14.401777
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    if codename is None:
        assert platform.system() != 'Linux'
    if codename is not None:
        assert platform.system() == 'Linux'

# Generated at 2022-06-11 01:37:15.259391
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    assert get_distribution_codename() == 'stretch'


# Generated at 2022-06-11 01:37:22.456591
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import sys
    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils.common._utils import get_module_path, run_command

    class TestGetDistributionVersion(unittest.TestCase):
        def setUp(self):
            # On a Debian machine, test with a different os-release file we
            # have control over
            distro_id = distro.id()
            if distro_id == u'debian':
                os_release_path = b'/etc/os-release'
                p = run_command([b'cat', os_release_path])
                self.os_release_orig = p.stdout

                # need to be root to write to /etc/os

# Generated at 2022-06-11 01:37:23.587052
# Unit test for function get_distribution_version
def test_get_distribution_version():
    return u''


# Generated at 2022-06-11 01:37:35.068839
# Unit test for function get_platform_subclass

# Generated at 2022-06-11 01:37:45.165432
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    import unittest
    import sys

    class TestModuleSubclass(object):
        distribution = None
        platform = None
    class TestModuleSubclass1(TestModuleSubclass):
        distribution = "Redhat"
        platform = "Linux"
    class TestModuleSubclass2(TestModuleSubclass):
        distribution = "Amazon"
        platform = "Linux"
    class TestModuleSubclass3(TestModuleSubclass):
        distribution = "Redhat"
        platform = "FreeBSD"
    class TestModuleSubclass4(TestModuleSubclass):
        distribution = "Amazon"
        platform = "FreeBSD"
    class TestModuleSubclass5(TestModuleSubclass):
        distribution = "FreeBSD"
        platform = "FreeBSD"

# Generated at 2022-06-11 01:37:51.848459
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

    # create a mock class with selected distro attributes
    class mock():
        @staticmethod
        def id():
            return 'ubuntu'
        @staticmethod
        def codename():
            return ''
        @staticmethod
        def os_release_info():
            return {'version_codename': 'Xenial Xerus'}
    # patch distro module with mock class
    distro.distro = mock()
    # check result
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-11 01:38:03.172278
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    def mock_distro_os_release_info(self):
        return {'version_codename': 'alpine', 'id': 'alpine', 'pretty_name': 'Alpine Linux'}

    def mock_distro_lsb_release_info(self):
        return {'distributor_id': 'Ubuntu', 'codename': 'xenial'}

    import ansible.module_utils.distro as old_distro
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.distro import Distro
    import unittest


# Generated at 2022-06-11 01:38:27.737033
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-11 01:38:39.048492
# Unit test for function get_distribution_version
def test_get_distribution_version():
    class MockDistro():
        os_release_info = {
            'centos': {
                'ID': 'centos',
                'VERSION_ID': '7',
                'VERSION': '7 (Core)',
                'VERSION_CODENAME': 'Core',
            },
            'debian': {
                'ID': 'debian',
                'VERSION_ID': '10',
                'VERSION': '10 (buster)',
                'VERSION_CODENAME': 'buster',
            },
            'ubuntu': {
                'ID': 'ubuntu',
                'VERSION_ID': '18.04',
                'VERSION': '18.04 (Bionic Beaver)',
                'VERSION_CODENAME': 'bionic',
            },
        }


# Generated at 2022-06-11 01:38:46.306975
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test get_platform_subclass().
    '''

    class A:
        pass

    # Create two dummy subclasses for testing
    class A_SubA(A):
        platform = 'GenericA'

    class A_SubB(A):
        distribution = 'GenericB'

    # This test doesn't run on Windows - return None
    if platform.system() == 'Windows':
        return None

    # Test for the generic 'Linux' platform
    assert get_platform_subclass(A) == A

    # Test for the linux platform with no distribution
    A.platform = platform.system()
    if A.platform == 'Linux':
        A.distribution = None
        assert get_platform_subclass(A) == A

    # Test for the linux platform with distribution with no matching class

# Generated at 2022-06-11 01:38:56.481451
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from subclasses import User, Adm_user

    class User_Linux(User):
        platform = 'Linux'
        distribution = None

    class User_Linux_Redhat(User):
        platform = 'Linux'
        distribution = 'Redhat'

    class User_Linux_Redhat_5(User):
        platform = 'Linux'
        distribution = 'Redhat'
        distribution_version = '5'

    class User_Linux_Redhat_6(User):
        platform = 'Linux'
        distribution = 'Redhat'
        distribution_version = '6'

    class User_Linux_Nos(User):
        platform = 'Linux'
        distribution = 'Nos'

    class User_Linux_Nos_1(User):
        platform = 'Linux'
        distribution = 'Nos'

# Generated at 2022-06-11 01:39:07.123325
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Case1: test centos with version
    fake_centos = [
        dict(id='centos', versiontuple=(7, 5)),
        dict(id='centos', version='7.5.1804'),
        dict(id='centos', version='7'),
    ]

    # assert result of centos with version
    for centos_version in fake_centos:
        distro.linux_distribution = lambda **kwargs: (centos_version['id'].capitalize(), 'None', centos_version['version'])

        assert get_distribution_version() == '7.5'

    # Case2: test centos without version
    fake_centos2 = [
        dict(id='centos', version=None),
        dict(id='centos', version=''),
    ]

    # assert

# Generated at 2022-06-11 01:39:10.506830
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename = get_distribution_codename()
    if distribution_codename is None:
        return True
    else:
        return False


# Generated at 2022-06-11 01:39:21.054963
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Setup test classes
    class A:
        platform = 'Linux'
        distribution = None

    class B(A):
        platform = 'Linux'
        distribution = 'Amazon'

    class C(A):
        platform = 'Linux'
        distribution = 'Amazon'

    class D(B, C):
        platform = 'Linux'
        distribution = 'Amazon'

    assert D is get_platform_subclass(A)
    assert B is get_platform_subclass(B)
    assert C is get_platform_subclass(C)
    assert D is get_platform_subclass(D)

    class E:
        platform = 'Linux'

    class F(E):
        platform = 'Linux'
        distribution = 'Amazon'

    assert F is get_platform_subclass(E)

# Generated at 2022-06-11 01:39:32.314886
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Verify that ``get_platform_subclass`` returns the proper class.

    :rtype: tuple(bool, string)
    :returns: (was the test successful, failure reason)
    '''

    class A:
        platform = 'A'

    class B(A):
        distribution = 'B'

    class C(A):
        platform = 'C'

    class D(C):
        platform = 'D'

    class E(C):
        platform = 'E'

    class F(C):
        distribution = 'F'

    class G(E):
        platform = 'G'

    assert get_platform_subclass(A) is A
    assert get_platform_subclass(B) is B
    assert get_platform_subclass(C) is C

# Generated at 2022-06-11 01:39:32.857842
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == u''

# Generated at 2022-06-11 01:39:40.617464
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # CentOS version is not normal case for this function, but we are
    # testing for a few special cases.
    centos_info = {
        'centos': '7.6.1810',
        'ubuntu': 'xenial',
        'debian': '8',
        'fedora': '28',
        'mock': '1.4.0',
    }

    for distribution in centos_info:
        distro.init(distribution, centos_info[distribution])
        if distribution == 'centos':
            assert get_distribution_version() == '7.6'
        elif distribution == 'fedora':
            assert get_distribution_version() == ''
        else:
            assert get_distribution_version() == centos_info[distribution]

        distro.init_non_linux()