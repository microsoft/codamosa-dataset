

# Generated at 2022-06-11 01:29:47.833869
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    assert get_distribution_codename() == "buster"

# Generated at 2022-06-11 01:29:48.633638
# Unit test for function get_distribution_version
def test_get_distribution_version():
    pass

# Generated at 2022-06-11 01:30:00.230300
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.common._collections_compat import Mapping

    # The code paths for the supported distributions
    expected_distribution_names = (
        'Amazon',
        'Arch',
        'Darwin',
        'Debian',
        'Freebsd',
        'Macos',
        'Openbsd',
        'OtherLinux',
        'Redhat',
        'SuSE',
        'Sunos',
        'Ubuntu',
    )
    # Expected versions for the distributions

# Generated at 2022-06-11 01:30:08.714562
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class Sub1(Base):
        platform = 'Linux'
        distribution = 'Redhat'

    class Sub2(Base):
        platform = 'Linux'
        distribution = 'Fedora'

    class Sub3(Base):
        platform = 'Linux'
        distribution = 'Amazon'

    assert get_platform_subclass(Base) == Base

    assert get_platform_subclass(Sub1) == Sub1
    assert get_platform_subclass(Sub2) == Sub2
    assert get_platform_subclass(Sub3) == Sub3

# Generated at 2022-06-11 01:30:09.555254
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename is not None

# Generated at 2022-06-11 01:30:15.852721
# Unit test for function get_distribution_version
def test_get_distribution_version():
    return_dict = {
        'centos': u'7.4.1708',
        'ubuntu': u'16.04',
        'amzn': u'2017.09',
        'fedora': u'28',
        'suse': u'15.1',
        'microsoft': u'1709',
    }
    for distro in return_dict:
        if distro == 'microsoft':
            assert get_distribution_version() == u'10.0'
        else:
            assert get_distribution_version() == return_dict[distro]

# Generated at 2022-06-11 01:30:16.731490
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'


# Generated at 2022-06-11 01:30:26.661788
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass(object):
        pass

    class BaseLinux(object):
        distribution = None
        platform = 'Linux'

    class RedHat(BaseLinux):
        distribution = 'Redhat'

    class Debian(BaseLinux):
        distribution = 'Debian'

    class OtherLinux(BaseLinux):
        pass

    class TestClass(object):
        def __new__(cls, args, kwargs):
            return get_platform_subclass(cls, args, kwargs)

    class TestClass1(TestClass, BaseClass):
        pass

    class TestClass2(TestClass1, BaseLinux):
        pass

    class TestClass3(TestClass2, RedHat):
        pass

    class TestClass4(TestClass3, Debian):
        pass

    assert TestClass4.__new__ == get_platform_

# Generated at 2022-06-11 01:30:27.658111
# Unit test for function get_distribution
def test_get_distribution():
    pass



# Generated at 2022-06-11 01:30:37.609790
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import types
    import platform

    # We're looking for the FOO platform subclass
    class FOO(object):
        platform = 'FOO'

        def __init__(self):
            pass

    # We only have one subclass of FOO and it works on all distributions
    class FOO_ALL(FOO):

        distribution = None

    # The FOO_SOMEOSTAGING distribution is still in testing and needs a special subclass
    class FOO_SOMEOSTAGING(FOO):

        distribution = 'FOO_SOMEOSTAGING'

    # The FOO_SOMEOS distribution is released and needs a special subclass
    class FOO_SOMEOS(FOO):

        distribution = 'FOO_SOMEOS'

    # The FOO_SOMEOS_SOMECODENAME distribution is released and needs

# Generated at 2022-06-11 01:30:54.744322
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Module_Linux(object):
        platform = 'Linux'
        distribution = None

    class Module_OtherLinux(object):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class Module_Redhat(object):
        platform = 'Linux'
        distribution = 'Redhat'

    class Module_Windows(object):
        platform = 'Windows'
        distribution = None

    class Module_OtherWindows(object):
        platform = 'Windows'
        distribution = 'OtherWindows'

    # Platform
    platform.system = lambda: 'Linux'

    # Distribution - id
    distro.id = lambda: ''
    distro.id = lambda: 'Debian'
    distro.id = lambda: 'OtherLinux'
    distro.id = lambda: 'Redhat'
    distro.id = lambda: 'Ubuntu'

# Generated at 2022-06-11 01:30:58.257019
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for get_distribution

    This should test for all the OSes that we support
    '''
    assert get_distribution() in TYPE_MAP, "OS not supported: %s" % platform.system()

# Generated at 2022-06-11 01:31:07.826420
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # testing class has one subclass and one platform
    class X:
        distribution = 'Amzn'
        platform = 'Linux'

    class X1(X):
        pass

    class Y:
        platform = 'Linux'

    # testing class has no subclass and one platform
    assert get_platform_subclass(X) == X

    # testing class has one subclass and two platforms
    class X:
        distribution = 'Amzn'
        platform = 'Linux'

    class X1(X):
        pass

    class X2(X):
        distribution = 'Redhat'

    class Y:
        platform = 'Linux'

    # testing class has no subclass and one platform
    assert get_platform_subclass(X) == X1

    # testing class has no subclass and no platform
    assert get_platform_subclass(Y) == Y

# Generated at 2022-06-11 01:31:10.689600
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test that get_distribution returns correct values
    '''

    assert(get_distribution() == 'Linux')

# Generated at 2022-06-11 01:31:21.867655
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class TestClass:
        pass

    class TestPlatformClass1(TestClass):
        platform = 'Linux'
        distribution = None

    class TestPlatformClass2(TestClass):
        platform = 'Linux'
        distribution = 'A'

    class TestPlatformClass3(TestClass):
        platform = 'Linux'
        distribution = 'B'

    class TestPlatformClass4(TestClass):
        platform = 'Linux'
        distribution = 'C'

    assert(TestPlatformClass1 == get_platform_subclass(TestClass))

    assert(TestPlatformClass1 == get_platform_subclass(TestClass))

    TestClass.platform = 'Linux2'
    assert(TestClass == get_platform_subclass(TestClass))
    del TestClass.platform

    TestClass.platform = 'Linux'

# Generated at 2022-06-11 01:31:30.778630
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    ''' Test function : function get_distribution_codename '''

    # Test Ubuntu
    assert get_distribution_codename() == 'bionic'

    # Test Debian
    assert get_distribution_codename() == 'stretch'

    # Test Fedora
    assert get_distribution_codename() == 'None'

    # Test RHEL
    assert get_distribution_codename() == 'None'

    # Test Amazon
    assert get_distribution_codename() == 'None'

    # Test CentOS (os-release not available, using lsb_release)
    assert get_distribution_codename() == 'Core'

    # Test openSUSE (os-release not available)
    assert get_distribution_codename() == 'Tumbleweed'

    # Test Oracle Linux (os-release not available)

# Generated at 2022-06-11 01:31:35.306316
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test get_distribution_codename()
    '''
    codename = get_distribution_codename()
    if platform.system() == 'Linux':
        assert codename is not None
    else:
        assert codename is None

# Generated at 2022-06-11 01:31:47.309690
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class SubclassA(Base):
        platform = 'Darwin'

    class SubclassB(Base):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubclassC(Base):
        platform = 'Linux'

    class SubclassD(Base):
        distribution = 'Ubuntu'

    # Should be able to instantiate the original class
    assert get_platform_subclass(Base) == Base

    # Should be able to instantiate a subclass for the platform
    assert get_platform_subclass(SubclassA) == SubclassA

    # Should be able to instantiate a subclass for the platform and distribution
    assert get_platform_subclass(SubclassB) == SubclassB

    # Should be able to instantiate a subclass for the platform even if there are other subclasses with the same platform


# Generated at 2022-06-11 01:31:48.706005
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'tara'

# Generated at 2022-06-11 01:31:56.536582
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo(object):
        platform = 'Bar'
        distribution = None

    # simple class without subclasses
    assert get_platform_subclass(Foo) == Foo
    # simple subclass
    class FooBar(Foo):
        pass
    assert get_platform_subclass(Foo) == FooBar
    # subclass with different platform
    class FooZot(Foo):
        platform = 'Zot'
    # subclass with additional condition which is not true
    class FooZim1(Foo):
        platform = 'Zim'
        distribution = 'Gir'
    # subclass with additional condition which is true
    class FooZim2(Foo):
        platform = 'Zim'
        distribution = 'Dib'
    assert get_platform_subclass(Foo) == FooZim2

# Generated at 2022-06-11 01:32:18.393947
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    """
    Test function get_platform_subclass()
    """
    from ansible.module_utils.basic import HumanReadableError
    from ansible.module_utils.basic import ModuleGeneric
    from ansible.module_utils.basic import ModuleSkeleton
    from ansible.module_utils.basic import NoSubClassError
    from ansible.module_utils.basic import DistributionNotFound
    from ansible.module_utils.basic import SkeletonModule

    # create some test classes for this test
    class ModuleSkeletonAndroid(ModuleSkeleton):
        platform = 'Android'

    class ModuleSkeletonCentos7(ModuleSkeleton):
        distribution = 'Centos'
        distribution_version = '7'
        platform = 'Linux'

    class ModuleSkeletonFreebsd12(ModuleSkeleton):
        distribution = 'Freebsd'


# Generated at 2022-06-11 01:32:25.600051
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the function get_distribution_codename()
    '''
    codename = get_distribution_codename()

    if platform.system() == 'Linux' and (distro.id() == 'centos' or distro.id() == 'redhat'):
        assert codename == 'Maipo'
    elif platform.system() == 'Linux' and distro.id() == 'debian':
        assert codename == 'stretch'
    else:
        assert codename == None

# Generated at 2022-06-11 01:32:36.675717
# Unit test for function get_distribution_version
def test_get_distribution_version():
    ''''
    This function test get_distribution_version function in module_utils.common.distribution
    '''
    import platform
    import unittest
    import os
    import shutil
    import tempfile
    import sys
    import io

    def create_fake_os_release_file(distro_id, version):
        '''
        This function creates a fake os-release file and set the environment variable
        required for distro.version() to return the correct value

        :arg string distro_id: The distro name
        :arg string version: The distro version
        :returns: temp file name
        '''
        tempdir = tempfile.mkdtemp()
        os_release = os.path.join(tempdir, 'os-release')

# Generated at 2022-06-11 01:32:48.456345
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = ''
        distribution = ''

    class PlatformBase(Base):
        platform = 'Linux'

    class LinuxBase(PlatformBase):
        distribution = 'Redhat'

    class OtherBase(PlatformBase):
        distribution = 'OtherLinux'

    class LinuxBaseNoDist(PlatformBase):
        distribution = ''

    class OtherBaseNoDist(PlatformBase):
        distribution = ''

    class PlatformBaseNoDist(Base):
        platform = 'Linux'
        distribution = ''

    class OtherPlatformBase(Base):
        platform = 'Solaris'

    class PlatformBaseNoDist2(Base):
        platform = 'Linux'
        distribution = ''

    class PlatformBaseSuper3(PlatformBaseNoDist2):
        platform = 'Linux'
        distribution = ''

    class LinuxBaseSuper2(PlatformBaseSuper3):
        distribution

# Generated at 2022-06-11 01:32:55.552392
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

    # Include code to test on each major platform
    if platform.system() == 'Linux':
        class MockDistro(object):
            pass

        # Test variant of Debian

        mock_distro = MockDistro()
        mock_distro.id = lambda: u'Debian'
        mock_distro.codename = lambda: u''

        mock_os_release = {
            u'id': u'debian',
            u'name': u'Debian GNU/Linux',
            u'version': u'10',
            u'version_id': u'10',
            u'pretty_name': u'Debian GNU/Linux 10 (buster)',
            u'codename': u'buster'
        }

# Generated at 2022-06-11 01:32:59.439507
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() in ('Linux', 'Darwin', 'Freebsd', 'Openbsd', 'Netbsd', 'Sunos')


# Generated at 2022-06-11 01:33:01.294217
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    print("Distribution: " + distribution)


# Generated at 2022-06-11 01:33:02.728020
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None


# Generated at 2022-06-11 01:33:14.742638
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    from ansible.module_utils.basic import AnsibleModule

    def run_module():
        # initialize
        module_args = dict()

        # AnsibleModule args
        argument_spec = dict(
            name=dict(type='str'),
            foo=dict(type='bool'),
        )
        module = AnsibleModule(argument_spec=argument_spec,
                               supports_check_mode=True)

        result = dict(
            changed=False,
            codename=get_distribution_codename()
        )
        module.exit_json(**result)


# Generated at 2022-06-11 01:33:18.758394
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base(object):
        pass

    class Sub(Base):
        pass

    Base.platform = 'test'
    Base.distribution = 'test'

    Sub.platform = 'test'
    Sub.distribution = 'test'

    assert get_platform_subclass(Base) == Sub

# Generated at 2022-06-11 01:33:40.678892
# Unit test for function get_distribution
def test_get_distribution():
    import platform

    # Ubuntu
    distro.id = lambda: 'ubuntu'
    assert 'Ubuntu' == get_distribution()

    # Fedora
    distro.id = lambda: 'fedora'
    assert 'Fedora' == get_distribution()

    # CentOS/RHEL
    distro.id = lambda: 'rhel'
    assert 'Redhat' == get_distribution()

    # Amazon Linux
    distro.id = lambda: 'amzn'
    assert 'Amazon' == get_distribution()

    # OpenSUSE
    distro.id = lambda: 'opensuse'
    assert 'Opensuse' == get_distribution()

    # Other Linux
    distro.id = lambda: None
    platform.system = lambda: 'Linux'
    assert 'OtherLinux' == get_distribution()

   

# Generated at 2022-06-11 01:33:44.060931
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    """The get_distribution_codename function should return codename when it exists and is not empty string."""
    codename = get_distribution_codename()
    if codename is not None and codename != u'':
        assert True
    else:
        assert False

# Generated at 2022-06-11 01:33:45.905738
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Centos', 'OS distribution is not Centos'


# Generated at 2022-06-11 01:33:57.378545
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class default_class:
        platform = None
        distribution = None

    class other_linux_class:
        platform = u'Linux'
        distribution = u'OtherLinux'

    class fedora_class:
        platform = u'Linux'
        distribution = u'Fedora'

    class redhat_class:
        platform = u'Linux'
        distribution = u'Redhat'

    class macos_class:
        platform = u'Darwin'
        distribution = None

    assert get_platform_subclass(default_class) == default_class

    assert get_platform_subclass(other_linux_class) == other_linux_class

    assert get_platform_subclass(fedora_class) == fedora_class

    assert get_platform_subclass(redhat_class) == redhat_class

    assert get_

# Generated at 2022-06-11 01:33:59.119920
# Unit test for function get_distribution
def test_get_distribution():

    assert get_distribution() == 'Debian', 'Something has gone wrong in get_distribution()'



# Generated at 2022-06-11 01:34:09.622619
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import os
    import tempfile
    import shutil

    from ansible.module_utils.common.text import is_text_string

    # Set up a directory to test in
    lib_path = os.path.join(tempfile.mkdtemp(), 'ansible', 'module_utils', 'basic.py')


# Generated at 2022-06-11 01:34:16.136960
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    One class with no subclass inheriting
    '''
    import copy

    class TestClass():
        platform = None
        distribution = None

    assert TestClass == get_platform_subclass(TestClass)
    assert TestClass != get_platform_subclass(TestClass)

    '''
    One subclass always taking precedence over the base class
    '''
    class TestClassNoDistro():
        platform = platform.system()
        distribution = None

    class TestClassWithDistro(TestClassNoDistro):
        distribution = 'Redhat'

    assert TestClassWithDistro == get_platform_subclass(TestClassNoDistro)

    '''
    One subclass specific to a certain Linux distribution
    '''
    class TestClassNoDistro():
        platform = platform.system()
        distribution = None


# Generated at 2022-06-11 01:34:27.547034
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest2 as unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule

    class fakeOS(object):
        @staticmethod
        def system():
            return 'Linux'

        @staticmethod
        def get_distribution():
            return 'Debian'

    class fakeModule():
        params = {}

    class testClass(object):
        def __init__(self, *args, **kwargs):
            self.args = args

        def testFunction(self):
            return self.args

        def input(self):
            return self.params

    class testSubClass1(testClass):
        pass

    class testSubClass2(testClass):
        pass


# Generated at 2022-06-11 01:34:35.736038
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # mock the function and set it to return specific values
    this_platform = platform.system()
    distribution = get_distribution()
    version = get_distribution_version()
    codename = get_distribution_codename()

    # import the class we want to test
    from ansible.module_utils.facts import distribution

    # generic parent class
    class myclass:
        distribution = None
        platform = None
        @staticmethod
        def __subclasshook__(cls, othercls):
            return NotImplemented

    # first subclass
    class subclass1(myclass):
        platform = this_platform
        distribution = distribution
        @staticmethod
        def __subclasshook__(cls, othercls):
            return NotImplemented

    # second subclass
    class subclass2(myclass):
        platform

# Generated at 2022-06-11 01:34:37.753990
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class cls(object):
        platform = None
        distribution = None


# Generated at 2022-06-11 01:35:09.294270
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # pylint: disable=too-few-public-methods,invalid-name
    class Addition(object):
        platform = 'Linux'
        distribution = 'OtherLinux'
        pass

    class AdditionDistro(Addition):
        distribution = 'OtherOtherLinux'
        pass

    class AdditionPlatform(AdditionDistro):
        platform = 'Darwin'
        pass

    result = get_platform_subclass(Addition)
    assert result == AdditionDistro, "Got wrong implementation for distribution"
    result = get_platform_subclass(AdditionDistro)
    assert result == AdditionDistro, "Got wrong implementation for distribution"
    result = get_platform_subclass(AdditionPlatform)
    assert result == AdditionPlatform, "Got wrong implementation for distribution"

# Generated at 2022-06-11 01:35:19.794388
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class MainClass:
        platform = 'Darwin'
        distribution = None
    class SubClassA(MainClass):
        platform = 'Darwin'
        distribution = 'Darwin'
    class SubClassB(MainClass):
        platform = 'Linux'
        distribution = 'Redhat'
    class SubClassC(MainClass):
        platform = 'Darwin'
        distribution = 'Darwin'
    class SubClassD(MainClass):
        platform = 'Linux'
        distribution = 'Redhat'

    def test(cls, expected_cls):
        assert get_platform_subclass(cls) == expected_cls

    # Test that we get the same output regardless of the order of subclasses
    test(MainClass, MainClass)
    test(SubClassA, SubClassA)

# Generated at 2022-06-11 01:35:31.541417
# Unit test for function get_distribution_version
def test_get_distribution_version():
    from ansible_collections.community.general.tests.unit.compat.mock import patch, MagicMock

    # Test with a non-Linux distribution
    with patch('distro.id', MagicMock(return_value='FreeBSD')):
        assert get_distribution_version() is None

    # Test where /etc/os-release does not exist and /usr/bin/lsb_release returns an empty string
    with patch('distro.version', MagicMock(return_value=None)):
        distro.version = MagicMock(return_value=None)
        assert get_distribution_version() == u''
        distro.version.assert_called_once_with(best=False)
        distro.version.reset_mock()

    # Test where /etc/os-release has the version specified

# Generated at 2022-06-11 01:35:34.351517
# Unit test for function get_distribution
def test_get_distribution():
    distro = get_distribution()
    assert distro
    print()
    print("You are running %s" % distro)
    print()
test_get_distribution()

# Generated at 2022-06-11 01:35:43.318599
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename.

    This is a test to verify the following distribution code names:
    - ubuntu bionic
    - debian testing
    - debian sid
    - centos 7.5
    - rhel 7.5
    - rhel 7.0
    - amazon 7.5
    - opensuse 42.2

    When updating this unit test, additional distro code name possibilities may be added. As a result,
    the distro code name may be added to the list of distribution code names to be verified above.
    If a new distro version is released for which it is known the code name will change, that distro
    code name should be added to the list of distribution code names to be verified above.
    '''


# Generated at 2022-06-11 01:35:44.368867
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()

    assert distribution is not None


# Generated at 2022-06-11 01:35:55.493103
# Unit test for function get_distribution
def test_get_distribution():
    ''' Test for function get_distribution '''
    import platform
    import os

    distribution = get_distribution()
    other_platform = 'SunOS'

    def test_with_id(distro_id, distro_codename):
        try:
            distro.id = lambda: distro_id
            distro.codename = lambda: distro_codename
            distribution = get_distribution()
        except:
            if platform.system() != other_platform:
                raise
        finally:
            reload(distro)

    test_with_id('arch', '')
    assert distribution == 'Arch'

    test_with_id('centos', 'Twiddle Sticks')
    assert distribution == 'Centos'

    test_with_id('debian', 'Bunny')
    assert distribution == 'Debian'

# Generated at 2022-06-11 01:36:05.262484
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # CentOS 6.5
    # https://github.com/ansible/ansible/issues/14884
    centos = {
        'ID': 'centos',
        'VERSION_ID': '6.5',
    }
    centos_expected = '6.5'

    # CentOS 6.5 update 1
    # https://github.com/ansible/ansible-modules-core/issues/966
    centos_update1 = {
        'ID': 'centos',
        'VERSION_ID': '6.5-0.1',
    }
    centos_update1_expected = '6.5-0.1'

    # CentOS 6.9
    # https://github.com/ansible/ansible/issues/50141

# Generated at 2022-06-11 01:36:15.272631
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    import os
    import pwd
    import tempfile

    from ansible.module_utils._text import to_bytes, to_text

    from ansible.module_utils.basic import BOOLEANS_TRUE, AnsibleModule, AnsibleModuleHelper, get_platform_subclass
    from ansible.module_utils.local_ansible_utils_extend_module import LocalAnsibleUtilsExtendModule

    # Test class to find the right subclass for
    class User(object):
        platform = None
        distribution = None

        def __init__(self, *args, **kwargs):
            super(User, self).__init__()

        def getpwuid(self, uid):
            raise NotImplementedError

    # The intended subclass
    class User_Linux(User):
        platform = 'Linux'
       

# Generated at 2022-06-11 01:36:16.629225
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()

# Generated at 2022-06-11 01:37:05.763250
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import distro_info
    di = distro_info.DistroInfo()
    for distro_name in di.get_distro_names():
        distro_info = di.get_distro_info(distro_name)
        codename = distro_info.get('codename', None)
        if codename:
            actual_codename = get_distribution_codename()
            assert actual_codename == codename

# Generated at 2022-06-11 01:37:15.304911
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class BaseClass:
        pass

    class SpecificClass(BaseClass):
        distribution = 'Fedora'

    class SpecificClass2(BaseClass):
        distribution = 'Fedora'
        platform = 'Linux'

    base_class = get_platform_subclass(BaseClass)
    assert base_class == BaseClass

    specific_class = get_platform_subclass(SpecificClass)
    assert specific_class == SpecificClass

    specific_class2 = get_platform_subclass(SpecificClass2)
    assert specific_class2 == SpecificClass2

if __name__ == "__main__":
    test_get_platform_subclass()

# Generated at 2022-06-11 01:37:24.625998
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Helper function to test the get_platform_subclass() function above.

    :raises: AssertionError: if get_platform_subclass() is not working correctly.
    '''
    from ansible.module_utils.basic import get_platform_subclass

    this_platform = platform.system()
    distribution = get_distribution()

    class Base_class(object):
        platform = 'Base'
        distribution = None

    class Linux_base(Base_class):
        platform = 'Linux'
        distribution = None

    class Redhat_linux(Linux_base):
        distribution = 'Redhat'

    class SLES_linux(Linux_base):
        distribution = 'Suse'

    class SunOS_base(Base_class):
        platform = 'SunOS'
        distribution = None


# Generated at 2022-06-11 01:37:36.105563
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = None
        distribution = None

    class Subclass(Base):
        pass

    assert get_platform_subclass(Base) == Base

    class RedHatLinux(Base):
        platform = 'Linux'
        distribution = 'Redhat'

    class OtherLinux(Base):
        platform = 'Linux'
        distribution = None

    if get_platform_subclass(Base) == RedHatLinux:
        # Test on RedHat-like platform
        assert get_platform_subclass(Base) == RedHatLinux
        assert get_platform_subclass(RedHatLinux) == RedHatLinux
        assert get_platform_subclass(OtherLinux) == RedHatLinux
        assert get_platform_subclass(Subclass) == Subclass
        return


# Generated at 2022-06-11 01:37:45.930366
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class TestPlatform:
        platform = platform.system().lower()
        distribution = get_distribution()

    assert get_platform_subclass(TestPlatform) == TestPlatform

    class TestPlatform2(TestPlatform):
        pass

    assert get_platform_subclass(TestPlatform) == TestPlatform

    class TestPlatform:
        platform = 'test_platform'
        distribution = None

    assert get_platform_subclass(TestPlatform) == TestPlatform

    class TestPlatform2(TestPlatform):
        pass

    assert get_platform_subclass(TestPlatform) == TestPlatform

    class TestPlatform:
        platform = 'test_platform'
        distribution = 'test_distribution'

    assert get_platform_subclass(TestPlatform) == TestPlatform

    class TestPlatform2(TestPlatform):
        pass


# Generated at 2022-06-11 01:37:57.317490
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestLinuxA(object):
        platform = 'Linux'
        distribution = 'LinuxA'
    class TestLinuxB(object):
        platform = 'Linux'
        distribution = None
    class TestMac(object):
        platform = 'Darwin'
        distribution = None
    class TestLinuxC(TestLinuxA):
        pass
    class TestLinuxD(TestLinuxB):
        pass

    this_platform = platform.system()
    distribution = get_distribution()

    cls = get_platform_subclass(TestLinuxA)
    assert cls.__name__ == 'TestLinuxA'

    cls = get_platform_subclass(TestLinuxB)
    if distribution is not None:
        assert cls.__name__ == 'TestLinuxB'

# Generated at 2022-06-11 01:38:07.327060
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    class BaseClass:
        distribution = None
        platform = None

    class BaseLinux(BaseClass):
        platform = 'Linux'

    class BaseFreeBSD(BaseClass):
        platform = 'FreeBSD'

    class BaseDarwin(BaseClass):
        platform = 'Darwin'

    class LinuxClass(BaseLinux):
        distribution = 'Linux'

    class OtherLinuxClass(BaseLinux):
        distribution = 'OtherLinux'

    class BSDClass(BaseFreeBSD):
        pass

    class OtherBSDClass(BaseFreeBSD):
        pass

    class DarwinClass(BaseDarwin):
        pass

    class OtherDarwinClass(BaseDarwin):
        pass

    class OtherClass(BaseClass):
        pass


# Generated at 2022-06-11 01:38:14.727154
# Unit test for function get_distribution
def test_get_distribution():
    installed_distros = []
    for subclass in get_all_subclasses(distro.LinuxDistribution):
        installed_distros.append(subclass.id())

    for subclass in get_all_subclasses(distro.LinuxDistribution):
        distribution = get_distribution()
        if subclass.id() in installed_distros:
            assert distribution == subclass.id().capitalize()
        else:
            # If the distro is not installed the best we can do is
            # the distribution is a Linux distro (assumption)
            assert distribution == 'OtherLinux'



# Generated at 2022-06-11 01:38:23.985298
# Unit test for function get_distribution
def test_get_distribution():
    '''
    :return: A test result object
    :rtype: :py:class:`unittest.TestResult` object

    Python's unittest module is modular.  This function must be in a module that
    starts with ``test_`` in order to be automatically discovered by the test
    suite.
    '''
    import unittest

    class SetupTestCase(unittest.TestCase):
        '''
        :py:class:`unittest.TestCase` subclass for testing the
        get_distribution function
        '''

        def setUp(self):
            '''
            Make sure we have a string for the distribution name
            '''
            self.test_value = get_distribution()
            self.assertIsInstance(self.test_value, str)


# Generated at 2022-06-11 01:38:35.241232
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test to check that get_platform_subclass identify the most specific subclass for this platform
    '''
    class foo():
        platform = 'linux'
        distribution = None

    class foo_linux(foo):
        platform = 'linux'
        distribution = None

    class foo_linux_other(foo_linux):
        platform = 'linux'
        distribution = 'other'

    class foo_linux_debian(foo_linux):
        platform = 'linux'
        distribution = 'debian'

    class foo_linux_debian_8(foo_linux_debian):
        platform = 'linux'
        distribution = 'debian'
        codename = 'jessie'

    class foo_linux_debian_9(foo_linux_debian):
        platform = 'linux'
        distribution = 'debian'

# Generated at 2022-06-11 01:39:21.054998
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class test_base_class(object):
        pass

    class test_sub_class(test_base_class):
        platform = 'Linux'
        distribution = 'RedHat'

    subclass_instance = get_platform_subclass(test_base_class)
    assert subclass_instance is test_sub_class

# Generated at 2022-06-11 01:39:32.314431
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''Unit test for function get_platform_subclass'''

    # subclass for Linux with a specific distribution
    class LinuxWithDistribution(object):

        platform = u'Linux'
        distribution = u'foo'

    # subclass for Linux with no distribution
    class LinuxWithoutDistribution(object):

        platform = u'Linux'
        distribution = None

    class OtherPlatform(object):

        platform = u'foo'
        distribution = u'bar'

    class SpecificDistribution(object):

        platform = u'Linux'
        distribution = u'baz'

    class OtherDistribution(object):

        platform = u'Linux'
        distribution = u'qux'

    class NoPlatformOrDistribution(object):

        platform = None
        distribution = None

    assert get_platform_subclass(LinuxWithDistribution) == LinuxWithDist

# Generated at 2022-06-11 01:39:40.303470
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # set up test classes
    class TestClass:
        pass
    class TestClassSubclass(TestClass):
        pass
    class TestClassLinuxSubclass(TestClass):
        distribution = u'Linux'
    class TestClassOtherLinuxSubclass(TestClass):
        distribution = u'OtherLinux'
    class TestClassLinuxDebianSubclass(TestClass):
        platform = u'Linux'
        distribution = u'Debian'
    class TestClassLinuxRedhatSubclass(TestClass):
        platform = u'Linux'
        distribution = u'Redhat'
    class TestClassLinuxTestSubclass(TestClass):
        platform = u'Linux'
        distribution = u'Test'
    class TestClassLinuxVersionSubclass(TestClass):
        platform = u'Linux'
        distribution = u'Test'