

# Generated at 2022-06-11 01:29:51.005607
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Base:
        pass

    class AllLinux(Base):
        platform = "Linux"

    class AllFreeBSD(Base):
        platform = "FreeBSD"

    class Fedora(AllLinux):
        distribution = "Fedora"

    class OtherLinux(AllLinux):
        distribution = "OtherLinux"

    class OtherFreeBSD(AllFreeBSD):
        distribution = "OtherFreeBSD"

    class Redhat(AllLinux):
        distribution = "Redhat"

    class Amazon(AllLinux):
        distribution = "Amazon"

    class Redhat7(AllLinux):
        platform = "Linux"
        distribution = "Redhat"
        major_version = "7"

    class Redhat8(AllLinux):
        platform = "Linux"
        distribution = "Redhat"
        major_version = "8"


# Generated at 2022-06-11 01:29:54.961372
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test for linux codenames
    '''
    codename = get_distribution_codename()

    print('Detected linux codename: {0}'.format(codename))

    assert isinstance(codename, str)

# Generated at 2022-06-11 01:30:06.628624
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = 'XXX'
        distribution = None
        pass

    class BaseClassB:
        platform = 'XXX'
        distribution = 'YYY'
        pass

    class BaseClassC:
        platform = 'XXX'
        distribution = 'ZZZ'
        pass

    class BaseClassD:
        platform = 'XXX'
        distribution = 'ZZY'
        pass

    class PlatformClassA(BaseClass):
        platform = 'Linux'
        pass

    class PlatformClassB(BaseClassB):
        platform = 'Darwin'
        pass

    class PlatformClassC(BaseClassC):
        platform = 'Linux'
        pass

    class PlatformClassD(BaseClassD):
        platform = 'Darwin'
        pass

    class DistributionClassA(PlatformClassA):
        distribution = 'Linux'


# Generated at 2022-06-11 01:30:15.989374
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform

    # Save off the current platform in case the test runner needs to use it
    original_platform = platform.system()

    class Base(object):
        platform = "Generic"
        distribution = None

    class Linux(Base):
        platform = "Linux"
        distribution = None

    class RedHat(Linux):
        distribution = "Redhat"

    class Fedora(RedHat):
        distribution = "Fedora"

    class LinuxSubclass(Linux):
        pass

    class OtherLinuxSubclass(Linux):
        pass

    class OtherLinux(Linux):
        platform = "OtherLinux"

    needed_subclasses = (
        (Linux, RedHat, Fedora),
        (Linux, RedHat),
        (Linux, LinuxSubclass, OtherLinuxSubclass),
        (Base,),
        (Base, OtherLinux),
    )



# Generated at 2022-06-11 01:30:26.197867
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Base:
        platform = 'Linux'
        distribution = None

    class Distro(Base):
        distribution = 'LinuxDistro'

    class AnotherDistro(Base):
        distribution = 'AnotherDistro'

    class ThirdDistro(Base):
        distribution = 'ThirdDistro'

    class DistroSubclass(Distro):
        pass

    class DistroSubSubclass(DistroSubclass):
        pass

    class AnotherDistroSubclass(AnotherDistro):
        pass

    class AnotherDistroSubSubclass(AnotherDistroSubclass):
        pass

    class GenericSubclassOfBase(Base):
        pass

    class GenericSubSubclass(GenericSubclassOfBase):
        pass

    #
    # Test for a platform subclass for which a distribution subclass exists
    #

# Generated at 2022-06-11 01:30:36.483214
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # For CentOS, the version is shown as '7.5.1804' when running the ansible module on the
    # remote machine itself. It is shown as '7.5' when running the ansible module on the
    # control machine.
    # https://github.com/nir0s/distro/pull/230
    # https://github.com/ansible/ansible/issues/50141#issuecomment-449452781
    # The below code tests the above scenario.
    version = distro.version()
    distro_id = distro.id()
    if version is not None:
        if distro_id == u'centos':
            version_best = distro.version(best=True)
            version_best = u'.'.join(version_best.split(u'.')[:2])
            assert version

# Generated at 2022-06-11 01:30:39.088957
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert distribution is not None
    assert isinstance(distribution, str)



# Generated at 2022-06-11 01:30:50.878972
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class FOO(object):
        platform = 'Linux'
        distribution = None
    class BAR(FOO):
        platform = 'Linux'
        distribution = 'Debian'

    # Find the most specific class for the distribution
    class SUSE(FOO):
        platform = 'Linux'
        distribution = 'SUSE'
    class SUSE_12(SUSE):
        distribution = 'SUSE'
        version = '12'
    class SUSE_11(SUSE):
        distribution = 'SUSE'
        version = '11'

    # Find the most specific class for the distribution and version
    class RedHat(FOO):
        platform = 'Linux'
        distribution = 'Redhat'
    class RedHat_7(RedHat):
        distribution = 'Redhat'
        version = '7'

# Generated at 2022-06-11 01:31:00.839727
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    ''' ensure get_platform_subclass works as expected '''

    class BaseClass:
        ''' dummy base class '''
        pass

    class PlatformClass(BaseClass):
        ''' dummy platform specific class '''
        platform = platform.system()
        distribution = None

    class PlatformDistroClass(BaseClass):
        ''' dummy platform+distro specific class '''
        platform = platform.system()
        distribution = distro.id().capitalize()

    class NonMatchingPlatformClass(BaseClass):
        ''' dummy class for a non-matching platform '''
        platform = 'nonmatching'
        distribution = None

    class NonMatchingDistroClass(BaseClass):
        ''' dummy class for a non-matching distribution '''
        platform = platform.system()
        distribution = 'Nonmatching'

    assert get

# Generated at 2022-06-11 01:31:11.574052
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        distribution = None
        platform = 'Linux'

        def func(self):
            return 'A'

    class B(A):
        distribution = 'redhat'

        def func(self):
            return 'B'

    class C(B):
        distribution = 'fedora'

        def func(self):
            return 'C'

    class D(A):
        distribution = 'ubuntu'

        def func(self):
            return 'D'

    # Test with A (Ubuntu returns A)
    subclass = get_platform_subclass(A)
    assert subclass == A

    # Test with B (B overrides A, but it's not Ubuntu)
    subclass = get_platform_subclass(B)
    assert subclass == B

    # Test with C (C overrides B, but it's not Ubuntu)


# Generated at 2022-06-11 01:31:19.213197
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is None
    assert get_platform_subclass(object) is object


# Generated at 2022-06-11 01:31:28.809096
# Unit test for function get_distribution

# Generated at 2022-06-11 01:31:40.663592
# Unit test for function get_distribution

# Generated at 2022-06-11 01:31:42.553692
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == "Linux"



# Generated at 2022-06-11 01:31:52.710845
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.network.common.utils

    # test for ansible_os_family and ansible_distribution case
    m = AnsibleModule(
        {'ansible_distribution': 'Fedora', 'ansible_os_family': 'RedHat'},
        ''
    )
    cls = ansible.module_utils.network.common.utils.get_platform_subclass(AnsibleModule)
    assert cls == ansible.module_utils.network.common.utils.RedHat

    # test for ansible_distribution
    m = AnsibleModule(
        {'ansible_distribution': 'Fedora'},
        ''
    )
    cls = ansible.module_utils.network.common.utils.get_platform

# Generated at 2022-06-11 01:31:54.707564
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    res = get_distribution_codename()
    exp = u'xenial'
    assert res == exp

# Generated at 2022-06-11 01:32:06.257461
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    This function tests the get_platform_subclass function

    '''
    class PlatformA(object):
        platform = 'A'

    class PlatformB(object):
        platform = 'B'

    class DistributionX(PlatformA):
        distribution = 'X'

    class DistributionY(PlatformA):
        distribution = 'Y'

    class DistributionZ(PlatformB):
        distribution = 'Z'

    class DistributionQUnknown(PlatformA):
        distribution = ''

    class PlatformUnknown(object):
        pass

    assert get_platform_subclass(PlatformA) is PlatformA
    assert get_platform_subclass(PlatformB) is PlatformB
    assert get_platform_subclass(PlatformUnknown) is PlatformUnknown
    assert get_platform_subclass(DistributionX) is DistributionX

# Generated at 2022-06-11 01:32:17.540029
# Unit test for function get_distribution
def test_get_distribution():
    import platform
    platform.system = lambda: 'Darwin'
    assert get_distribution() == 'Darwin'
    platform.system = lambda: 'FreeBSD'
    assert get_distribution() == 'Freebsd'
    platform.system = lambda: 'Linux'
    import distro
    distro.id = lambda: 'centos'
    assert get_distribution() == 'Redhat'
    distro.id = lambda: 'opensuse'
    assert get_distribution() == 'Opensuse'
    distro.id = lambda: 'ubuntu'
    assert get_distribution() == 'Ubuntu'
    distro.id = lambda: 'unknown'
    assert get_distribution() == 'OtherLinux'
    distro.id = lambda: 'amzn'
    assert get_distribution() == 'Amazon'


# Generated at 2022-06-11 01:32:19.805203
# Unit test for function get_distribution
def test_get_distribution():

    if platform.system() == 'Linux':
        assert get_distribution() == 'OtherLinux'
    else:
        assert get_distribution() is None


# Generated at 2022-06-11 01:32:32.188541
# Unit test for function get_distribution_version

# Generated at 2022-06-11 01:32:49.272029
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Plugin:
        platform = 'Linux'
        distribution = None

    class PluginA(Plugin):
        platform = 'Linux'
        distribution = 'Debian'

    class PluginB(Plugin):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class PluginC(Plugin):
        platform = 'Linux'
        distribution = 'Redhat'

    class PluginD(Plugin):
        platform = 'Linux'
        distribution = 'SUSE'

    class PluginE:
        platform = 'FreeBSD'
        distribution = None

    class PluginF(Plugin):
        platform = 'Linux'

    class PluginG(PluginF):
        distribution = 'Redhat'

    class PluginH(PluginG):
        distribution = 'Fedora'

    class PluginI(PluginF):
        distribution = 'Fedora'

    subclass = get_

# Generated at 2022-06-11 01:32:58.228701
# Unit test for function get_distribution
def test_get_distribution():
    successful_tests = {
        u'Linux': u'OtherLinux',
        u'FreeBSD': u'Freebsd',
        u'OpenBSD': u'Openbsd',
        u'NetBSD': u'Netbsd',
        u'Darwin': u'Macosx',
        u'SunOS': u'Sunos',
        u'AIX': u'Aix',
    }

    for platform_name, distro_name in successful_tests.items():
        platform.system = lambda: platform_name
        assert get_distribution() == distro_name

# Generated at 2022-06-11 01:32:59.888252
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == get_distribution()


# Generated at 2022-06-11 01:33:03.555484
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Function used to test the get_distribution function.

    :returns: True it get_distribution returns the distribution
    '''
    distribution = get_distribution()

    return int(distribution is not None)

# Generated at 2022-06-11 01:33:11.236372
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    code_names = {
        'Ubuntu': 'Bionic Beaver',
        'Debian': 'buster/sid',
        'SLES': 'Leap',
        'SLES/SLED': 'Leap',
        'Fedora': '28',
        'CentOS': 'Core',
        'Raspbian': 'stretch/sid',
    }

    for distribution, code_name in code_names.items():
        assert code_name == get_distribution_codename()

# Generated at 2022-06-11 01:33:17.081007
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class WantPlatform():
        distribution = 'Redhat'
        platform = 'Linux'

    class WantPlatformRedhat(WantPlatform):
        distribution = 'Redhat'

    class WantPlatformLinux(WantPlatform):
        platform = 'Linux'

    class WantPlatformLinuxRedhat(WantPlatform):
        distribution = 'Redhat'
        platform = 'Linux'

    class DontWantPlatform():
        distribution = 'OtherLinux'
        platform = 'Other'

    class DontWantPlatformOtherLinux(DontWantPlatform):
        distribution = 'OtherLinux'

    class DontWantPlatformOther(DontWantPlatform):
        platform = 'Other'

    class DontWantPlatformOtherLinuxOther(DontWantPlatform):
        distribution = 'OtherLinux'
        platform = 'Other'

    class WantPlatformFallback():
        distribution = None

# Generated at 2022-06-11 01:33:27.116691
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """Test that get_distribution_version returns the correct
    value for various Linux distributions
    """

    mock_distro_dict = {
        'amazon': '2015.03',
        'centos': '7.4.1708',
        'debian': '9.5',
        'fedora': '28',
        'oracle': '7.4',
        'ubuntu': '16.04'
    }
    old_distro = distro.id
    # We need to mock this because six.moves.builtins.open can't be mocked
    old_open = open

# Generated at 2022-06-11 01:33:28.580551
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution().lower() == platform.system().lower()


# Generated at 2022-06-11 01:33:34.482471
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    This tests the get_platform_subclass() function

    This test depends on the ordering of the get_all_subclasses() function
    '''
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    assert get_platform_subclass(D) == D

# Generated at 2022-06-11 01:33:44.410201
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import ansible.module_utils.basic
    class Base(object):
        platform = None
        distribution = None
    class Derived(Base):
        platform = "Linux"
        distribution = None
    class Other(Base):
        platform = "Linux"
        distribution = "Redhat"
    class Redhat(Base):
        platform = "Linux"
        distribution = "Redhat"
    class CentOS(Base):
        platform = "Linux"
        distribution = "CentOS"
    class Amazon(Base):
        platform = "Linux"
        distribution = "Amazon"
    class Amazon2(Base):
        platform = "Linux"
        distribution = "Amazon Linux AMI"
    class OtherLinux(Base):
        platform = "Linux"
        distribution = "OtherLinux"
    class Darwin(Base):
        platform = "Darwin"


# Generated at 2022-06-11 01:33:58.791851
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename
    '''
    input_data = {
        'Amazon': 'Amzn',
        'RedHat': 'Rhel',
        'Ubuntu': 'Bionic',
        'CentOS': 'CentOS',
        'Debian': 'Buster',
        'Fedora': 'Fedora',
        'LinuxMint': 'Tara',
        'openSUSE': 'Leap',
        'openSUSE Tumbleweed': 'Tumbleweed',
    }
    for distro, output in input_data.items():
        assert output == get_distribution_codename()

# Generated at 2022-06-11 01:34:03.589148
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    for cls in (Linux, RedhatLinux, UbuntuLinux):
        assert get_platform_subclass(cls) == cls, 'Failed to get desired class for {}'.format(cls)

    assert get_platform_subclass(RedhatLinux) == RedhatLinux, 'Failed to get the most specific class'



# Generated at 2022-06-11 01:34:13.065375
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Run unit tests against get_distribution().
    '''
    def run_test(distribution):
        '''
        Run unit tests for get_distribution().

        :arg str distribution: Distribution to return for test purposes
        '''
        assert get_distribution() == distribution

    distribution = get_distribution()

    try:
        from unittest import mock
    except ImportError:
        import mock

    with mock.patch('ansible.module_utils.distro.id') as m:
        m.return_value = 'amazon'
        run_test('Amazon')
    with mock.patch('ansible.module_utils.distro.id') as m:
        m.return_value = 'centos'
        run_test('Centos')
        m.return_value = 'centos linux'


# Generated at 2022-06-11 01:34:24.731788
# Unit test for function get_distribution
def test_get_distribution():
    '''
    unit test for get_distribution
    '''
    # FreeBSD, NetBSD, OpenBSD, MacOSX, Dragonfly, and Darwin are considered BSD
    for this_platform in ('FreeBSD', 'NetBSD', 'OpenBSD', 'DragonFly', 'Darwin'):
        assert get_distribution() == 'Freebsd', 'get_distribution() returns correct value'

    # Linux, GNU and GNU/kFreeBSD are all considered Linux
    for this_platform in ('Linux', 'GNU', 'GNU/kFreeBSD'):
        assert get_distribution() == 'Linux', 'get_distribution() returns correct value'

    # Solaris and SunOS are considered Solaris

# Generated at 2022-06-11 01:34:34.258492
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class SuperClassLinux:
        platform = 'Linux'
        distribution = None

    class SubclassAmazonLinux(SuperClassLinux):
        distribution = 'Amazon'

    class SubclassRedHat(SuperClassLinux):
        distribution = 'Redhat'

    def test_subclass(subclass, result):
        assert subclass == result

    # Get the basic platform class
    test_subclass(get_platform_subclass(SuperClassLinux), SuperClassLinux)

    # Get the distribution specific class if it exists
    test_subclass(get_platform_subclass(SubclassAmazonLinux), SubclassAmazonLinux)
    test_subclass(get_platform_subclass(SubclassRedHat), SubclassRedHat)

    # Get the basic generic class if a distribution specific class doesn't exist

# Generated at 2022-06-11 01:34:46.435615
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        platform = None
        distribution = None

    class B(A):
        platform = "TestPlatform"
        distribution = None

    class C(A):
        platform = None
        distribution = "TestDistribution"

    class F(B, C):
        pass

    class D(B):
        platform = None
        distribution = "TestDistribution"

    class E(C):
        platform = "TestPlatform"
        distribution = None

    class G(C):
        platform = None
        distribution = "TestDistribution2"


# Generated at 2022-06-11 01:34:56.584585
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # When the platform is not Linux, it returns None
    platform_org = platform.system
    platform.system = lambda: 'freebsd'
    assert get_distribution_version() is None
    platform.system = platform_org

    # When the distribution is not rpm or deb based, it returns an empty string
    distro_id_org = distro.id
    distro.id = lambda: 'freebsd'
    assert get_distribution_version() == ''
    distro.id = distro_id_org

    # When distro does not support "best=True", it returns distro.version() directly
    distro_version_org = distro.version
    distro.version = lambda best=False: '1.2.3' if not best else '1.2.3.4'
    assert get_distribution

# Generated at 2022-06-11 01:35:08.088929
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # First one is listed in os-release, others are tested in distro
    codenames = [
        ('debian8', 'jessie'),
        ('debian9', 'stretch'),
        ('ubuntu1404', 'trusty'),
        ('ubuntu1610', 'yakkety'),
        ('ubuntu1704', 'zesty'),
        ('ubuntu1710', 'artful'),
        ('ubuntu1804', 'bionic'),
        ('ubuntu1810', 'cosmic'),
        ('ubuntu1904', 'disco'),
        ('ubuntu1910', 'eoan'),
        ('ubuntu2002', 'focal'),
        ('ubuntu2004', 'focal'),
        ('rhel6', 'Santiago'),
        ('rhel7', 'Maipo'),
        ('rhel8', None),
    ]

# Generated at 2022-06-11 01:35:18.709590
# Unit test for function get_distribution_codename

# Generated at 2022-06-11 01:35:28.196496
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Base1(object):
        platform = 'Linux'
        distribution = 'RedHat'

    class Base2(object):
        platform = 'Linux'

    class Subclass1(Base1):
        pass

    class Subclass2(Base2):
        pass

    class Subclass3(Base1):
        distribution = 'Ubuntu'

    assert get_platform_subclass(Base1) is Base1
    assert get_platform_subclass(Base2) is Base2
    assert get_platform_subclass(Subclass1) is Subclass1
    assert get_platform_subclass(Subclass2) is Subclass2
    assert get_platform_subclass(Subclass3) is Subclass3

# Generated at 2022-06-11 01:35:42.661199
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        platform = 'Darwin'
        distribution = None

    class B(A):
        platform = 'Darwin'
        distribution = 'macOS'

    class C(A):
        platform = 'Darwin'
        distribution = 'macOS'
        version = '10.14'

    assert get_platform_subclass(A) == C


if __name__ == '__main__':
    import sys
    import os
    import pytest
    # We should always have a 'this_platform' attribute and a 'distribution'
    # attribute.  These aren't exposed to the ansible module but instead
    # implemented by the platform class.
    assert hasattr(get_platform_subclass(object), 'this_platform')
    assert hasattr(get_platform_subclass(object), 'distribution')


# Generated at 2022-06-11 01:35:52.878458
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import itertools
    import sys

    distribution = get_distribution()

    class SuperClass:
        platform = 'SuperClass'
        distribution = None

    class ClassA(SuperClass):
        platform = 'SuperClass'
        distribution = None

    class ClassAOtherLinux(SuperClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class ClassAAmazon(SuperClass):
        platform = 'Linux'
        distribution = 'Amazon'

    class ClassB(ClassAAmazon):
        platform = 'Linux'
        distribution = 'Amazon'

    # When both the platform and distribution match
    assert get_platform_subclass(SuperClass) == SuperClass
    assert get_platform_subclass(ClassA) == ClassA
    assert get_platform_subclass(ClassAOtherLinux) == ClassAOtherLinux
   

# Generated at 2022-06-11 01:35:57.974841
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename

    :rtype: boolean
    :return: Boolean indicating if a test failed or not. True means the test failed, False means no failures.
    '''
    distribution_codename = get_distribution_codename()
    if distribution_codename is None:
        return True
    else:
        return False

# Generated at 2022-06-11 01:36:07.484335
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Base(object):
        pass

    class A(Base):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class B(Base):
        platform = 'Linux'
        distribution = 'Redhat'

    class C(Base):
        platform = 'Linux'

    class D(Base):
        platform = 'Linux'
        distribution = 'Redhat'

    class E(D):
        platform = 'Darwin'
        distribution = 'Redhat'

    class F(D):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class G(D):
        pass

    class H(F):
        platform = 'Linux'

    assert get_platform_subclass(Base) is Base
    assert get_platform_subclass(A) is A

# Generated at 2022-06-11 01:36:08.381134
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'

# Generated at 2022-06-11 01:36:10.861549
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename('not a linux distro') is None

    # Test all the other distributions if needed

# Generated at 2022-06-11 01:36:13.321015
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the get_distribution_version function
    '''
    assert get_distribution_version() is not None

# Generated at 2022-06-11 01:36:23.544583
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import AnsibleModule

    # Dummy classes for this test
    class Basic(object):
        platform = None
        distribution = None
        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(cls)
            return super(cls, new_cls).__new__(new_cls)

    class SpecificLinux(Basic):
        platform = u'Linux'
        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(cls)
            return super(cls, new_cls).__new__(new_cls)

    class SpecificUnix(Basic):
        platform = u'Unix'

# Generated at 2022-06-11 01:36:33.077107
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'base'
        distribution = None

    class A(Base):
        distribution = 'A'

    class B(Base):
        distribution = 'B'

    class C(Base):
        distribution = 'C'

    assert get_platform_subclass(A) is A
    assert get_platform_subclass(B) is B
    assert get_platform_subclass(C) is C

    class D(A):
        pass

    assert get_platform_subclass(D) is D

    class E(A):
        platform = 'E'
        distribution = 'E'

    assert get_platform_subclass(E) is E

    class F(A):
        distribution = 'B'

    assert get_platform_subclass(F) is B


# Generated at 2022-06-11 01:36:34.510842
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == "Redhat"


# Generated at 2022-06-11 01:36:56.126275
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Simple test to make sure that we can find classes based on the platform and distribution
    '''
    # Our dummy classes
    class Base:
        platform = 'Fake'
        distribution = None

    class FakeLinux(Base):
        distribution = 'Linux'

    class FakeLinuxOther(Base):
        distribution = 'OtherLinux'

    class FakeLinuxRedhat(Base):
        distribution = 'Redhat'

    class FakeWindows(Base):
        platform = 'Windows'

        # this is important for the test
        distribution = 'FakeWindows'

    class FakeDarwin(Base):
        platform = 'Darwin'

    class FakeAmazon(Base):
        platform = 'Linux'
        distribution = 'Amazon'


# Generated at 2022-06-11 01:37:06.401771
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    @add_platform_subclass(platform='Linux', distribution='RedHat')
    class RedHatClass(BaseClass):
        pass

    @add_platform_subclass(platform='Linux', distribution='Ubuntu')
    class UbuntuClass(BaseClass):
        pass

    class RedHatOtherClass(BaseClass):
        pass
    RedHatOtherClass.platform = 'Linux'
    RedHatOtherClass.distribution = 'RedHat'

    class UbuntuOtherClass(BaseClass):
        pass
    UbuntuOtherClass.platform = 'Linux'
    UbuntuOtherClass.distribution = 'Ubuntu'

    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(RedHatOtherClass) == RedHatOtherClass
    assert get_platform_subclass(UbuntuOtherClass)

# Generated at 2022-06-11 01:37:12.949771
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class Base(object):
        platform = 'test'
        distribution = None

    class BaseDistro(object):
        platform = 'test'
        distribution = 'test_distro'

    class SubClass(Base):
        pass

    class SubClassDistro(SubClass):
        distribution = 'test_distro'

    class OtherSubClass(Base):
        distribution = 'other'

    class OtherPlatformSubClass(Base):
        platform = 'other'

    class OtherOtherPlatformSubClass(Base):
        platform = 'other_other'

    assert get_platform_subclass(Base) == Base
    assert get_platform_subclass(BaseDistro) == BaseDistro
    assert get_platform_subclass(SubClass) == SubClass
    assert get_platform_subclass(SubClassDistro) == SubClassDistro
   

# Generated at 2022-06-11 01:37:21.361396
# Unit test for function get_distribution
def test_get_distribution():
    old_os_release_id = None
    distribution = None


# Generated at 2022-06-11 01:37:28.668570
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version
    '''
    centos_version = distro.version(best=True)
    ubuntu_version = distro.version(best=True)

    # Verify if get_distribution_version returns best version for centos
    assert centos_version == get_distribution_version()

    # Verify if get_distribution_version returns best version for ubuntu
    assert ubuntu_version == get_distribution_version()

# Generated at 2022-06-11 01:37:36.004994
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distro_dict = {'centos': u'7',
                   'debian': u'9',
                   'fedora': u'28',
                   'opensuse': u'15.0',
                   'redhat': u'7.5',
                   'ubuntu': u'18.04'}

    for distro_id, version in distro_dict.items():
        distro.id = lambda: distro_id
        distro.version = lambda: version
        assert isinstance(get_distribution_codename(), str)

# Generated at 2022-06-11 01:37:38.121070
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename() != ''

# Generated at 2022-06-11 01:37:41.331784
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test function get_distribution
    '''
    class Mock(object):
        '''Mock class for platform.system()'''
        @staticmethod
        def system():
            '''Mock platform.system'''
            return 'Linux'
    old_platform = platform.system
    platform.system = Mock.system
    assert get_distribution() == 'Otherlinux'
    platform.system = old_platform


# Generated at 2022-06-11 01:37:47.108284
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test for invalid Linux distribution
    distro_list = ['', 'ubuntu', 'fedora', 'CENTOS', 'Debian', ' RHEL', 'SUSE ']
    for distro in distro_list:
        distro_mock = MagicMock(distro.Distribution)
        distro_mock.id.return_value = distro.strip()
        with patch('ansible.module_utils.common._utils.distro', distro_mock):
            assert get_distribution_version() == u''

# Generated at 2022-06-11 01:37:58.360699
# Unit test for function get_distribution
def test_get_distribution():

    from types import ModuleType
    import imp

    class MockLinuxDistro(ModuleType):
        '''
        Mocks platform.linux_distribution() for testing.
        '''
        def __init__(self, *args, **kwargs):
            super(MockLinuxDistro, self).__init__(*args, **kwargs)
            self.name = 'mockdistro'
            self.version = '1.2.3'
            self.id = 'mockdistro'

        def __call__(self, *args, **kwargs):
            return self.name, self.version, self.id


# Generated at 2022-06-11 01:38:27.600700
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import mock

    distro_id = 'example_distro'
    version_codename = 'example_codename'

    with mock.patch('ansible.module_utils.common.distro.id', return_value=distro_id):
        with mock.patch('ansible.module_utils.common.distro.os_release_info', return_value={'version_codename': version_codename}):
            codename = get_distribution_codename()
            assert codename == version_codename


# Generated at 2022-06-11 01:38:32.492425
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    ''' Function to test get_distribution_codename
    '''
    codename = get_distribution_codename()

    if codename is None:
        if platform.system() != 'Linux':
            assert codename is None
        else:
            assert False, 'codename is None'

# Generated at 2022-06-11 01:38:34.656358
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    print("Distribution codename: " + codename)

# Generated at 2022-06-11 01:38:36.045517
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution()


# Generated at 2022-06-11 01:38:42.440793
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    class distro_object:
        def __getitem__(self, key):
            return {
                'ID_LIKE': ['ubuntu'],
                'UBUNTU_CODENAME': 'trusty'
            }[key] if key in ['ID_LIKE', 'UBUNTU_CODENAME'] else None

        def __contains__(self, key):
            return key in ['ID_LIKE', 'UBUNTU_CODENAME']

    assert get_distribution_codename(distro_object()) == 'trusty'

# Generated at 2022-06-11 01:38:48.144466
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Mock ansible.module_utils.distro.id
    saved_distro = distro.id

    def mock_distro_id(id=None):
        return 'faux'

    distro.id = mock_distro_id

    class PlatformA:
        platform = 'Linux'
        distribution = None

    class PlatformB(PlatformA):
        platform = 'Linux'
        distribution = 'faux'

    class PlatformC(PlatformB):
        platform = 'Linux'
        distribution = 'faux'

    class Mock:
        def assertEqual(self, a, b):
            assert a == b, "%r != %r" % (a, b)

    mock = Mock()

    # The last subclass should be returned even though it is a subclass of the first subclass
    # that matches.
    mock.assertE

# Generated at 2022-06-11 01:38:52.602529
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == "7.5"
    assert get_distribution_version() == "7.5"
    assert get_distribution_version() == "7.5"
    assert get_distribution_version() == "7.5"

# Generated at 2022-06-11 01:38:55.344500
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    :returns: None

    Function that tests the results of ``get_platform_subclass()``.
    '''
    _ = get_platform_subclass

# Generated at 2022-06-11 01:39:06.125457
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        '''
        A testing class
        '''
        distribution = None
        platform = 'Linux'

    class B(A):
        '''
        A testing subclass of A
        '''
        distribution = 'Redhat'

    class C(A):
        '''
        A testing subclass of A
        '''
        distribution = 'Redhat'
        platform = 'Windows'

    class D(C):
        '''
        A testing subclass of C
        '''
        distribution = 'Redhat'

    class E(A):
        '''
        A testing subclass of A
        '''
        distribution = 'Debian'

    class F(E):
        '''
        A testing subclass of A
        '''
        pass


# Generated at 2022-06-11 01:39:11.714407
# Unit test for function get_distribution_version
def test_get_distribution_version():
    (rc, out, err) = module.run_command(["python", "-c",
        "import platform; import ansible.module_utils.facts.system; print(ansible.module_utils.facts.system.get_distribution_version())"])
    assert rc == 0
    assert len(out) > 0
