

# Generated at 2022-06-11 01:29:46.052621
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for get_distribution_codename

    This is pretty minimal right now.  As I port more code to this module
    and the functionality becomes more stable the unit tests will expand.
    '''

    # RedHat and CentOS don't have a codename
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:29:48.709565
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename() == get_distribution_codename()

# Generated at 2022-06-11 01:30:00.330801
# Unit test for function get_distribution_version
def test_get_distribution_version():
    platform_os_release_map = {
        'centos': ['7', '7.5.1810'],
        'darwin': ['15.7.0'],
        'debian': ['9.5'],
        'fedora': ['28', '28'],
        'rhel': ['8.0', '8.0'],
        'ubuntu': ['16.04', '16.04.5'],
    }

    for platform_name, (expected_version, expected_version_best) in platform_os_release_map.items():
        distro.lsb_release = lambda: None
        distro.os_release = lambda: {'VERSION': ''}
        platform.system = lambda: 'Linux'
        distro.id = lambda: platform_name
        distro.version = lambda best=False: expected

# Generated at 2022-06-11 01:30:08.762162
# Unit test for function get_distribution
def test_get_distribution():
    '''
    unittest function for function get_distribution

    :rtype: Boolean
    :returns: Return 0 if function get_distribution returns correct value, otherwise 1
    '''

    # Case 1: sample value for Linux machine
    distribution = get_distribution()
    if 'Linux' == platform.system() and distribution.capitalize() == distro.id().capitalize():
        return True

    # Case 2: sample value for Windows machine
    if 'Windows' == platform.system() and 'Windows' == distribution.capitalize():
        return True

    return False


# Generated at 2022-06-11 01:30:11.371624
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test to validate the code name for this Linux Distribution
    '''
    codename = get_distribution_codename()
    assert codename is not None

# Generated at 2022-06-11 01:30:17.262250
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    # Distribution is Ubuntu Xenial 16.04.
    # /etc/os-release has a 'Codename' that is different from what is in /etc/lsb-release
    os_release_info = {'version_codename': 'xenial'}
    lsb_release_info = {'codename': 'XenialXerus'}
    codename = get_distribution_codename()
    assert codename is not None, "Distribution codename not found"
    assert codename == 'xenial', "Distribution codename is " + str(codename) + " while it should be xenial"

# Generated at 2022-06-11 01:30:26.993219
# Unit test for function get_distribution
def test_get_distribution():
    '''
    This function has been created to test the output of get_distribution function on various platforms.
    '''

# Generated at 2022-06-11 01:30:28.380027
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == "bionic"



# Generated at 2022-06-11 01:30:30.613696
# Unit test for function get_distribution
def test_get_distribution():
    """
    Test that get_distribution works as expected.
    """
    assert get_distribution() == "Freebsd"



# Generated at 2022-06-11 01:30:34.885965
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert None == get_distribution_version()
    # This should always run on a Linux based system
    # So, the above assert should never pass.
    # The following assert may fail, however, as it depends on the
    # distro details
    assert None != get_distribution_version()

# Generated at 2022-06-11 01:30:42.049286
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert 'tessa' == get_distribution_codename()

# Generated at 2022-06-11 01:30:42.671880
# Unit test for function get_distribution_version
def test_get_distribution_version():
    return None

# Generated at 2022-06-11 01:30:49.956456
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Mock distro.version so the code will work on a non-Linux machine
    distro.version = lambda *args, **kwargs: '3.10.0-957.12.2'
    assert get_distribution_version() == '3.10.0'

    distro.version = lambda *args, **kwargs: '7.5.1804'
    assert get_distribution_version() == '7.5.1804'

# Generated at 2022-06-11 01:30:52.668425
# Unit test for function get_distribution
def test_get_distribution():
    # This is just a demonstration of how this code works.
    # We don't really care that it actually returns a useful value.
    print(get_distribution())



# Generated at 2022-06-11 01:31:02.053366
# Unit test for function get_distribution
def test_get_distribution():
    import distro
    distro.id = lambda: 'RedHatEnterpriseServer'
    assert get_distribution() == 'Redhat'
    distro.id = lambda: 'CentOS'
    assert get_distribution() == 'Centos'
    distro.id = lambda: 'Ubuntu'
    assert get_distribution() == 'Ubuntu'
    distro.id = lambda: 'MeeGo'
    assert get_distribution() == 'Meego'
    distro.id = lambda: 'arch'
    assert get_distribution() == 'Arch'
    distro.id = lambda: 'Mint'
    assert get_distribution() == 'Mint'
    distro.id = lambda: 'XCP'
    assert get_distribution() == 'Xcp'

# Generated at 2022-06-11 01:31:13.497177
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    platform = "Linux"
    distribution = get_distribution()
    # Test for Linux distributions subclass
    for subclass in get_all_subclasses(object):
        if subclass.platform is not None and subclass.platform == platform and subclass.distribution is not None:
            assert(get_platform_subclass(subclass) == subclass)
    # Test for Linux subclass
    for subclass in get_all_subclasses(object):
        if subclass.platform is not None and subclass.platform == platform and subclass.distribution is None:
            assert(get_platform_subclass(subclass) == subclass)
    # Test for Default subclass
    for subclass in get_all_subclasses(object):
        if subclass.platform is None and subclass.distribution is None:
            assert(get_platform_subclass(subclass) == subclass)

# Generated at 2022-06-11 01:31:20.105074
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from distro import os_release_info
    from ansible.module_utils.common._collections_compat import OrderedDict

    # Test for broken version of distro that doesn't have version_codename
    os_release_info["VERSION_CODENAME"] = ""
    os_release_info["UBUNTU_CODENAME"] = ""
    codename = get_distribution_codename()
    assert codename is None

    # Test for version_codename
    os_release_info["VERSION_CODENAME"] = "eoan"
    codename = get_distribution_codename()
    assert codename == "eoan"

    # Test for ubuntu_codename
    os_release_info["VERSION_CODENAME"] = ""

# Generated at 2022-06-11 01:31:29.529789
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass

    :raises AssertionError: On test failure
    '''
    # For this test, platform.system() returns 'Generic'
    # and get_distribution() returns 'GenericLinux'

    # This is the class that will be passed to get_platform_subclass
    class Base():
        platform = None
        distribution = None

    # This class will be the returned subclass if GenericLinux is the
    # current distribution
    class GenericLinux(Base):
        distribution = 'GenericLinux'

    # This class will be the returned subclass if Generic is the current
    # platform
    class Generic(Base):
        platform = 'Generic'

    # This class will be the returned subclass if neither of the above two
    # are the current platform or distribution
    class SuperGeneric(Base):
        pass

# Generated at 2022-06-11 01:31:42.082055
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test that we can return a Linux subclass
    from ansible.module_utils._text import to_bytes
    import six
    import sys

    if to_bytes(u'\u203d') != b'?':
        print('Skipping tests that require unicode.  Use python3 for this test.')
        sys.exit(0)

    class BaseClass:
        platform = 'Linux'
        distribution = None

    class LinuxSubclass1(BaseClass):
        platform = 'Linux'
        distribution = 'RedHat'

    class LinuxSubclass2(BaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    # On any Linux distribution, LinuxSubclass1 should be returned
    subclass = get_platform_subclass(LinuxSubclass1)

# Generated at 2022-06-11 01:31:46.337539
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution = get_distribution()
    codename = get_distribution_codename()
    assert codename is not None, 'distribution codename is None'
    assert isinstance(codename, str), 'distribution codename is not str'



# Generated at 2022-06-11 01:32:02.871038
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    from distro import os_release_info
    from distro import lsb_release_info
    def os_release_info_stub(*args, **kwargs):
        if 'debian' in args:
            return {'version_codename': 'buster'}
        elif 'ubuntu' in args:
            return {'ubuntu_codename': 'xenial'}
        else:
            return {}

    def lsb_release_info_stub(*args, **kwargs):
        if 'codename' in args:
            return 'yakkety'

    distro.os_release_info = os_release_info_stub
    distro.lsb_release_info = lsb_release_info_stub

    assert get_distribution_codename() == 'buster'


# Generated at 2022-06-11 01:32:14.392421
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    For each supported platform, test that get_distribution_codename() returns the expected codename
    '''

# Generated at 2022-06-11 01:32:22.758313
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.six import with_metaclass
    import ansible.module_utils.six as six

    class PlatformSubclassTestMeta(type):
        def __repr__(cls):
            return '<PlatformSubclassTest {}>'.format(cls.__name__)

    class PlatformSubclassTest(six.with_metaclass(PlatformSubclassTestMeta, object)):
        platform = None
        distribution = None

    class PlatformSubclassTestLinux(PlatformSubclassTest):
        platform = 'Linux'

    class PlatformSubclassTestLinuxRedhat(PlatformSubclassTestLinux):
        distribution = 'Redhat'

    class PlatformSubclassTestLinuxOther(PlatformSubclassTestLinux):
        distribution = 'OtherLinux'


# Generated at 2022-06-11 01:32:25.128667
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert type(codename) == str, "get_distribution_codename() should return string"

# Generated at 2022-06-11 01:32:31.285664
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class AnsibleModule:
        platform = None
        distribution = None

    class AnsibleModuleOther:
        platform = None
        distribution = None

    assert hasattr(get_platform_subclass(AnsibleModule), 'load_platform_subclass')
    assert not hasattr(get_platform_subclass(AnsibleModuleOther), 'load_platform_subclass')

# Generated at 2022-06-11 01:32:32.344580
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()
    assert distribution != None

# Generated at 2022-06-11 01:32:40.351160
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import unittest

    class Base(object):
        platform = 'Linux'

    class RedHat(Base):
        distribution = 'RedHat'

    class RedHat6(RedHat):
        version = '6'

    class RedHat7(RedHat):
        version = '7'

    class Ubuntu(Base):
        distribution = 'Ubuntu'

    class OtherLinux(Base):
        distribution = None

    class Windows(Base):
        platform = 'Windows'

    class Other(Base):
        pass

    class TestGetPlatformSubclass(unittest.TestCase):
        def test_redhat_6(self):
            '''
            Test that RedHat6 is returned as a subclass for RedHat 6
            '''
            platform.system = lambda: 'Linux'
            get_distribution = lambda: 'RedHat'
           

# Generated at 2022-06-11 01:32:50.721296
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Function to unit test the get_distribution_codename function
    '''
    # Test Fedora
    os_release_info = {u'distro_id': u'fedora', u'id': u'Fedora', u'name': u'Fedora', u'version': u'28', u'version_id': u'28', u'version_codename': None, 'variant_id': u'Server'}
    codename = distro.get_distribution_codename(os_release_info)
    assert codename is None

    # Test Ubuntu Xenial

# Generated at 2022-06-11 01:33:03.506591
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = 'all'
        distribution = None

    class SubClass1(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass2(BaseClass):
        platform = 'Linux'

    class SubClass3(BaseClass):
        distribution = 'Redhat'

    class SubClass4(SubClass2):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass5(SubClass2):
        platform = 'Linux'
        distribution = 'Redhat'

    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(SubClass1) == SubClass1
    assert get_platform_subclass(SubClass2) == SubClass2
    assert get_platform_subclass(SubClass3) == SubClass3

# Generated at 2022-06-11 01:33:05.093365
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '18.04'

# Generated at 2022-06-11 01:33:17.567139
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test pass
    assert get_distribution_codename() == None

# Generated at 2022-06-11 01:33:23.939565
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Tests for the get_distribution function
    '''
    plat = platform.system().lower()
    if plat == 'linux':
        if distro.id() == 'amzn':
            assert get_distribution() == 'Amazon'
        elif distro.id() == 'rhel':
            assert get_distribution() == 'Redhat'
        elif distro.id() == 'centos':
            assert get_distribution() == 'Centos'
        else:
            # If the distribution is not known assume it's another Linux distribution
            assert get_distribution() == 'OtherLinux'
    else:
        # Non Linux platform
        assert get_distribution() == plat.capitalize()


# Generated at 2022-06-11 01:33:25.304609
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() != None


# Generated at 2022-06-11 01:33:35.877912
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the function get_distribution_codename.
    '''
    codename = get_distribution_codename()
    if codename is not None:
        codename = codename.lower()
    if get_distribution() in ['Debian', 'Ubuntu']:
        assert get_distribution_codename() == get_distribution_version()
    elif get_distribution() == 'Fedora':
        assert get_distribution_codename() is None
    elif get_distribution() == 'Amazon':
        # There is no single codename for Amazon Linux, so return None
        assert get_distribution_codename() is None
    else:
        assert get_distribution_codename() is not None

# Generated at 2022-06-11 01:33:45.333329
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_plaform_subclass
    '''

    # Mock the platform.system() and get_distribution() function as they are used in the get_platform_subclass
    # Using side_effect allows to get the mocked function to return a different value in each iteration thus
    # allowing to test different combinations in one test
    #
    # Mock calls to get_platform_subclass() in the class under test
    # Allowing to specify return values for different function calls
    def side_effect_get_platform_subclass(cls):
        return cls.__clsmap.get(cls.__call_to_get_platform_subclass, cls)


# Generated at 2022-06-11 01:33:47.196279
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename() == u'xenial'

# Generated at 2022-06-11 01:33:56.161525
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    assert get_platform_subclass('linux', 'default') == 'linux'
    assert get_platform_subclass('linux2', 'default') == 'linux2'
    assert get_platform_subclass('linux', 'fedora') == 'fedora'
    assert get_platform_subclass('linux', 'amazon') == 'redhat'
    assert get_platform_subclass('darwin', 'default') == 'darwin'
    assert get_platform_subclass('freebsd', 'default') == 'freebsd'
    assert get_platform_subclass('openbsd', 'default') == 'openbsd'

# Generated at 2022-06-11 01:34:07.065208
# Unit test for function get_distribution_codename

# Generated at 2022-06-11 01:34:09.522353
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import platform
    if platform.system() == 'Linux':
        codename=get_distribution_codename()
        if codename is not None:
            print("Test codename:  " + codename)
            return True
        else:
            return False
    else:
        return None

# Generated at 2022-06-11 01:34:16.094740
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Parent(object):
        platform = 'Linux'
        distribution = None

    class CentOS(Parent):
        distribution = 'RedHat'

    class Fedora(Parent):
        distribution = 'Fedora'

    class Gentoo(Parent):
        distribution = 'Gentoo'

    class FreeBsd(Parent):
        platform = 'FreeBSD'

    class Other(Parent):
        pass

    # Test normal case - find a subclass on the current platform
    platform.system = lambda : 'Linux'
    distribution = get_distribution
    distribution.return_value = 'Redhat'

    assert get_platform_subclass(Parent) is CentOS

    # Test fallback to an unspecified platform
    platform.system = lambda : 'FreeBSD'

    assert get_platform_subclass(Parent) is Parent

    # Test a platform that has more than one subclass

# Generated at 2022-06-11 01:34:50.949315
# Unit test for function get_distribution_version
def test_get_distribution_version():

    # Test data to simulate os-release
    os_release_info = {}
    os_release_info[u'NAME'] = u'Fedora'
    os_release_info[u'VERSION_ID'] = u'27'

    os_release_info_centos = {}
    os_release_info_centos[u'NAME'] = u'CentOS Linux'
    os_release_info_centos[u'VERSION_ID'] = u'7.5.1804'

    # Test data to simulate lsb_release
    lsb_release_info = {}
    lsb_release_info[u'distributor_id'] = u'Ubuntu'
    lsb_release_info[u'description'] = u'Ubuntu 16.04.4 LTS'
    lsb_release_info[u'release']

# Generated at 2022-06-11 01:34:59.695667
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Fedora and Debian specific files to test
    class _file_mocks:
        # Create an object with all the required data to test from /etc/os-release
        # The name, id and version_id should always be present
        @staticmethod
        def os_release_info():
            return {
                'name': 'Fedora',
                'id': 'fedora',
                'version_id': '27',
                'version_codename': 'Twenty Seven'
            }

        # Create an object with all the required data to test from /usr/bin/lsb_release
        @staticmethod
        def lsb_release_info():
            return {
                'distributor_id': 'Debian',
                'codename': 'sid'
            }

        # Create a function that returns Fedora

# Generated at 2022-06-11 01:35:11.248850
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import get_platform_subclass

    import platform
    import sys

    # Fake an OpenSUSE distribution on a Linux machine
    # NOTE:  We have to do this before the module import or the platform module will load the name of the
    #        distribution from the host
    saved_platform_dist = platform.dist
    saved_platform_system = platform.system
    platform.system = lambda: 'Linux'
    platform.dist = lambda: ('opensuse', '42.1', 'x86_64')

    import ansible.module_utils.basic as basic

    # Create a class that has different subclasses for different Linux distributions
    # This class is a mock of the Ansible User module

# Generated at 2022-06-11 01:35:21.323417
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Function: test_get_platform_subclass()
    Purpose: Test the function get_platform_subclass()
    Parameters: none
    Returns: none
    '''

    # class definitions
    class cls_ABCD(object):
        '''Super class'''
        platform = 'ABCD'
        distribution = None

    class cls_EFG(cls_ABCD):
        '''Sub class inheriting super cls_ABCD'''
        platform = 'EFG'
        distribution = None

    class cls_HIJ(cls_EFG):
        '''Sub class inheriting super cls_EFG'''
        platform = 'HIJ'
        distribution = None


    # test cases

# Generated at 2022-06-11 01:35:31.635076
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Make sure the get_distribution_version funtion works for each supported
    linux distribution.
    '''

    distributions_and_versions = {
        'Amazon': '2',
        'Debian': '8',
        'RedHat': '6.1',
        'SUSE': '11.3',
        'Ubuntu': '14.04',
    }

    for distribution, version in distributions_and_versions.items():
        assert get_distribution_version(distribution, version) == version

    if get_distribution() is None:
        distributions_and_versions['OtherLinux'] = ''
        assert get_distribution_version(distribution, version) == ''

# Generated at 2022-06-11 01:35:32.963435
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-11 01:35:34.306182
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() != None, "Function get_distribution_version failed."

# Generated at 2022-06-11 01:35:42.388998
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Until this gets merged and we update our bundled copy of distro:
    # https://github.com/nir0s/distro/pull/230
    # (Fixes Fedora 28+ not having a code name and Ubuntu Xenial Xerus needing to be "xenial")
    # should return xenial
    assert get_distribution_codename() == 'xenial'
    # should return None
    assert get_distribution_codename() is None
    # should return 'el7' for Red Hat Enterprise Linux 7.6
    assert get_distribution_codename() == 'el7'
    # should return 'bionic' (or None if not fixed)
    assert get_distribution_codename() == 'bionic'

# Generated at 2022-06-11 01:35:43.369727
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-11 01:35:54.337562
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class PlatformClass(BaseClass):
        platform = "Linux"
        distribution = None

    class DistributionClass(BaseClass):
        platform = "Linux"
        distribution = "Ubuntu"

    class DistributionVersionClass(DistributionClass):
        distribution_version = "18.04"

    class PlatformDistributionClass(BaseClass):
        platform = "Linux"
        distribution = "Ubuntu"

    class InvalidPlatformDistributionClass(BaseClass):
        platform = "Windows"
        distribution = "Ubuntu"

    class InvalidDistributionClass(BaseClass):
        platform = "Linux"
        distribution = "asdf"

    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(PlatformClass) == PlatformClass

# Generated at 2022-06-11 01:36:26.780405
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'
        distribution = None
        def __init__(self, value):
            self.value = value

    class Ubuntu(Base):
        distribution = 'Ubuntu'
        def __init__(self, value):
            super(Ubuntu, self).__init__(value)
            self.value = 'Ubuntu(%s)' % self.value

    class Centos(Base):
        distribution = 'Centos'
        def __init__(self, value):
            super(Centos, self).__init__(value)
            self.value = 'Centos(%s)' % self.value

    class OtherLinux(Base):
        platform = 'Linux'
        def __init__(self, value):
            super(OtherLinux, self).__init__(value)

# Generated at 2022-06-11 01:36:35.423390
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = None
        distribution = None

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseBSD(Base):
        platform = 'BSD'

    class Debian(BaseLinux):
        distribution = 'Debian'

    class OtherLinux(BaseLinux):
        distribution = 'OtherLinux'

    class RedHat(BaseLinux):
        distribution = 'Redhat'

    class Fedora(BaseLinux):
        distribution = 'Fedora'

    class FreeBSD(BaseBSD):
        distribution = 'FreeBSD'

    platform_subclass = get_platform_subclass(Base)

    # Red Hat
    if platform.system() == 'Linux':
        assert RedHat == platform_subclass, 'Red Hat is not the platform subclass'

    # BSD

# Generated at 2022-06-11 01:36:46.255036
# Unit test for function get_distribution
def test_get_distribution():
    distribution_id_map = {
        'amazon': 'Amazon',
        'centos': 'Centos',
        'clear-linux-os': 'Clearlos',
        'debian': 'Debian',
        'fedora': 'Fedora',
        'opensuse-leap': 'Opensuse',
        'opensuse-tumbleweed': 'Opensuse',
        'oracle': 'OracleLinux',
        'redhat': 'Redhat',
        'sles': 'Suse',
        'sles_sicily': 'Suse',
        'ubuntu': 'Ubuntu',
        'xenserver': 'Xenserver',
    }


# Generated at 2022-06-11 01:36:47.512909
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-11 01:36:53.034144
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    if codename is None:
        assert(distro.id() not in ('debian', 'ubuntu'))
    else:
        assert(codename in ('xenial', 'bionic'))


if __name__ == '__main__':
    test_get_distribution_codename()

# Generated at 2022-06-11 01:37:01.255898
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class baseA:
        platform = 'Linux'
        distribution = None

    class ubuntuA(baseA):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class SuseA(baseA):
        distribution = 'Suse'

    class SuseB(SuseA):
        platform = 'Linux'

    class SuseC(SuseA):
        platform = 'SunOS'

    class SuseD(baseA):
        platform = 'Linux'
        distribution = 'Suse'

    class baseB:
        distribution = None
        platform = 'SunOS'

    class sunB(baseB):
        distribution = 'SunOS'

    class hpB(baseB):
        distribution = 'HP-UX'

    class NotSet(object):
        pass


# Generated at 2022-06-11 01:37:13.667857
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class PlatformA(object):
        distribution = None
        platform = 'A'

    class DistributionBPlatformA(PlatformA):
        distribution = 'B'

    class PlatformB(object):
        distribution = None
        platform = 'B'

    class PlatformC(PlatformA):
        platform = 'C'

    class DistributionA(object):
        distribution = 'A'
        platform = None

    class DistributionB(object):
        distribution = 'B'
        platform = None

    class DistributionC(object):
        distribution = 'C'
        platform = None

    assert get_platform_subclass(PlatformA) == PlatformA
    assert get_platform_subclass(PlatformB) == PlatformB
    assert get_platform_subclass(PlatformC) == PlatformC
    assert get_platform_subclass(DistributionA) == DistributionA


# Generated at 2022-06-11 01:37:21.686314
# Unit test for function get_platform_subclass
def test_get_platform_subclass():  # noqa
    '''
    Function to test the get_platform_subclass function.  It's not a real unit test since it
    depends on being able to run on a wide variety of Linux and Windows machines.
    '''
    import pprint
    import sys
    import unittest

    # We're going to be testing our test harness so we need to get the actual class to
    # test against.
    this_class = get_platform_subclass(sys.modules[__name__].test_get_platform_subclass.__func__)

    # These are the most important class variables to test.  We verify them here to avoid
    # Verifying them in the tests where it would be too late to fail the test.
    assert this_class.platform == platform.system().lower()

# Generated at 2022-06-11 01:37:27.732900
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Get the version of the distribution the code is running on

    :rtype: NativeString or None
    :returns: A string representation of the version of the distribution. If it
    cannot determine the version, it returns an empty string. If this is not run on
    a Linux machine it returns None.
    '''

    version = get_distribution_version()

    assert version is not None

# Generated at 2022-06-11 01:37:38.882900
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    ubuntu = {'ID': 'ubuntu', 'VERSION_ID': '18.04', 'VERSION': '18.04 (Bionic Beaver)',
              'ID_LIKE': 'debian', 'NAME': 'Ubuntu',
              'VERSION_CODENAME': 'bionic', 'UBUNTU_CODENAME': 'bionic'}
    assert get_distribution_codename(ubuntu) == 'bionic'
    debian = {'ID': 'debian', 'VERSION_ID': '9', 'VERSION': '9 (stretch)',
              'NAME': 'Debian GNU/Linux', 'ID_LIKE': 'debian',
              'VERSION_CODENAME': 'stretch', 'UBUNTU_CODENAME': 'n/a'}
    assert get_distribution_codename(debian) == 'stretch'

# Generated at 2022-06-11 01:38:34.039371
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    import unittest

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        platform = 'Linux'
        distribution = 'Redhat'

    class D(A):
        platform = 'Linux'

    class E(A):
        platform = 'Linux'
        distribution = 'Redhat'

    class F(A):
        platform = 'SunOS'

    class G(A):
        platform = 'Linux'
        distribution = 'Redhat'

    # This class will be used in unit test.
    class TestClass(object):
        platform = platform.system()
        distribution = get_distribution()

        def __init__(self, name):
            self.name = name

    test_classes = (B, C, D, E, F, G)


# Generated at 2022-06-11 01:38:43.437443
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Code that tests the get_distribution function.

    :rtype: None
    :returns: None
    '''
    # Example output of platform.dist() function
    # ('AmazonAMI', '4.4.35-38.55.amzn1.x86_64', 'amzn1')

    # We cannot test this from platforms other than Linux so fake the return value of platform.dist()
    platform.dist = lambda ignored: ('AmazonAMI', '4.4.35-38.55.amzn1.x86_64', 'amzn1')

    # Verify get_distribution() returns 'Amazon'
    assert get_distribution() == 'Amazon'

    # Example output of platform.dist() function
    # ('centos', '7.4.1708', 'Core')

    # We cannot test this from platforms

# Generated at 2022-06-11 01:38:45.023116
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert None == get_distribution_codename()

# Generated at 2022-06-11 01:38:46.937522
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Get the distribution the code is running on
    '''
    assert get_distribution() == u'Amazon'

# Generated at 2022-06-11 01:38:56.905106
# Unit test for function get_distribution_version
def test_get_distribution_version():
    ''' get_distribution_version: Test the get_distribution_version function '''

    # Ubuntu 18.04
    distro.id = lambda: 'ubuntu'
    distro.lsb_release_info = lambda: {'release': '18.04', 'codename': 'bionic'}
    distro.version = lambda: None
    assert get_distribution_version() == u'18.04'

    # CentOS 7.5
    distro.id = lambda: 'centos'
    distro.version = lambda: u'7'
    distro.version = lambda best: u'7.5.1804'
    assert get_distribution_version() == u'7.5'

    # Debian 10
    distro.id = lambda: 'debian'

# Generated at 2022-06-11 01:38:58.952111
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == None
    assert get_distribution_version() == ''

# Generated at 2022-06-11 01:39:00.115524
# Unit test for function get_distribution
def test_get_distribution():
    distribution = get_distribution()

# Generated at 2022-06-11 01:39:01.276396
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename is not None, 'codename should not be empty'

# Generated at 2022-06-11 01:39:03.984943
# Unit test for function get_distribution
def test_get_distribution():
    """Return the name of the distribution we are running on"""
    f = get_distribution
    assert f() == 'Redhat'


# Generated at 2022-06-11 01:39:10.370329
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''Test if get_distribution_codename() returns expected values'''
    if platform.system() == 'Linux':
        distro_codename = get_distribution_codename()
        # Test distributions with /etc/os-release codename
        if distro.id() == 'alpine':
            assert distro_codename == 'edge'
        elif distro.id() == 'arch':
            assert distro_codename == 'rolling'
        elif distro.id() == 'debian':
            assert distro_codename == 'buster'
        elif distro.id() == 'fedora':
            assert distro_codename is None
        elif distro.id() == 'opensuse-leap':
            assert distro_codename == '15.0'