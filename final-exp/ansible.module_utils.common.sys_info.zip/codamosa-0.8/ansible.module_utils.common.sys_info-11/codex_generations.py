

# Generated at 2022-06-11 01:29:51.644286
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils.basic import get_platform_subclass
    class TestClass(object):
        platform = 'Linux'

    class TestClassDistroA(TestClass):
        distribution = 'A'

    class TestClassDistroB(TestClass):
        distribution = 'B'

    class TestClassSubclass(TestClassDistroA):
        distribution = 'B'

    assert get_platform_subclass(TestClass) == TestClass
    assert get_platform_subclass(TestClassDistroA) == TestClassDistroA

    assert get_platform_subclass(TestClassDistroB) == TestClassDistroB

    assert get_platform_subclass(TestClassSubclass) == TestClassSubclass


if __name__ == '__main__':
    import sys
    import unittest

# Generated at 2022-06-11 01:30:03.610573
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class BaseClass:
        platform = u'Linux'
        distribution = None

        def __new__(cls, *args, **kwargs):
            new_cls = get_platform_subclass(BaseClass)
            return super(cls, new_cls).__new__(new_cls)

    class CentOS(BaseClass):
        platform = u'Linux'
        distribution = u'Redhat'

    class SLES(BaseClass):
        platform = u'Linux'
        distribution = u'SLES'

    class SLES12(SLES):
        distribution_version = u'12'

    class SLES11(SLES):
        distribution_version = u'11'

    class OtherLinux(BaseClass):
        platform = u'Linux'

    assert CentOS(None) != BaseClass(None)
    assert SL

# Generated at 2022-06-11 01:30:14.011822
# Unit test for function get_distribution
def test_get_distribution():

    # Test for RedHatEnterpriseLinux
    distro.id = lambda: 'rhel'
    assert 'Redhat' == get_distribution()

    # Test for Debian
    distro.id = lambda: 'debian'
    assert 'Debian' == get_distribution()

    # Test for Ubuntu
    distro.id = lambda: 'ubuntu'
    assert 'Ubuntu' == get_distribution()

    # Test for Amazon Linux
    distro.id = lambda: 'amzn'
    assert 'Amazon' == get_distribution()

    # Test for SuSE
    distro.id = lambda: 'suse'
    assert 'Suse' == get_distribution()

    # Test for FreeBSD
    distro.id = lambda: None
    platform.system = lambda: 'FreeBSD'

# Generated at 2022-06-11 01:30:24.509800
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    @classmethod
    def _os_release_info(cls):
        return {
            u'name': u'CentOS Linux',
            u'version': u'7 (Core)',
            u'version_id': u'7',
            u'version_codename': u'Core',
            u'release_id': u'1810',
            u'release': u'',
            u'codename': u'Core',
        }
    # save distro's os_release_info method
    distro_os_release_info = distro.os_release_info
    # set distro's os_release_info method to our fake one
    distro.os_release_info = _os_release_info
    # get distro's codename
    codename = get_distribution_codename()


# Generated at 2022-06-11 01:30:26.418665
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    assert get_distribution_version() is not None

# Generated at 2022-06-11 01:30:36.680507
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import os
    import tempfile


# Generated at 2022-06-11 01:30:48.744212
# Unit test for function get_distribution
def test_get_distribution():
    import unittest

    class TestDistro(unittest.TestCase):
        def test_distro_name_normalization(self):

            self.assertEqual(get_distribution(), distro.id().capitalize())
            self.assertEqual(distro.id().capitalize(), distro.name().capitalize())

    class TestDistroMock(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            from unittest.mock import patch
            cls.mock_platform = patch('ansible.module_utils.common._utils.platform')
            cls.mock_distro = patch('ansible.module_utils.common._utils.distro')
            cls.mocked_platform = cls.mock_platform.start()
            cls.m

# Generated at 2022-06-11 01:30:59.121497
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base(object):
        platform = 'Linux'
        distribution = None

    class Linux(Base):
        pass

    class LinuxCentos(Linux):
        distribution = 'Centos'

    class LinuxDebian(Linux):
        distribution = 'Debian'

    class LinuxUbuntu(Linux):
        distribution = 'Ubuntu'

    # The following classes are not used in get_platform_subclass(). They're present to test
    # get_all_subclasses() and that it does not return non-Linux or non-Darwin classes.
    class Darwin(Base):
        platform = 'Darwin'

    class LinuxFedora(Linux):
        distribution = 'Fedora'

    class Other(object):
        pass


# Generated at 2022-06-11 01:31:01.043284
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distribution_codename = get_distribution_codename()
    print("Distribution codename:" + distribution_codename)


# Generated at 2022-06-11 01:31:11.759875
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test for the function get_distribution_codename()
    '''
    # set up some dummy data and run the function
    test_data = {
        'centos': 'Centos_version',
        'debian': 'Debian_version',
        'fedora': 'Fedora_version',
        'freebsd': 'FreeBSD_version', # the capital S is correct
        'gentoo': 'Gentoo_version',
        'macos': 'macOS_version', # the capital S is correct
        'rhel': 'Redhat_version',
        'sles': 'SLES_version',
        'ubuntu': 'Ubuntu_version',
    }


# Generated at 2022-06-11 01:31:28.031101
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''

    class Base(object):
        platform = 'Linux'

    class DistroBase(Base):
        distribution = 'OtherLinux'

    class PlatformBase(Base):
        pass

    class DistroBaseSubclass(DistroBase):
        pass

    class DistroBaseSubSubclass(DistroBaseSubclass):
        pass

    class PlatformBaseSubclass(PlatformBase):
        pass

    class PlatformBaseSubSubclass(PlatformBaseSubclass):
        pass

    class DistroSubclass(DistroBase):
        distribution = 'RedHat'

    class DistroSubSubclass(DistroSubclass):
        '''
        This class intentionally does not override distribution
        '''

    class PlatformSubclass(PlatformBase):
        platform = 'BSD'


# Generated at 2022-06-11 01:31:39.619735
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import sys
    import os
    import pytest

    this_platform = platform.system()
    distribution = get_distribution()

    class UbuntuOldStyle(object):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class UbuntuNewStyle(UbuntuOldStyle):
        distribution = 'Ubuntu'
        distribution_release = 'Trusty'

    class OtherLinuxOldStyle(object):
        platform = 'Linux'
        distribution = None

    class OtherLinuxNewStyle(OtherLinuxOldStyle):
        pass

    class WindowsOldStyle(object):
        platform = 'Windows'
        distribution = None

    class WindowsNewStyle(WindowsOldStyle):
        pass

    class NoDistroOldStyle(object):
        platform = this_platform
        distribution = distribution

    class NoDistroNewStyle(NoDistroOldStyle):
        pass

# Generated at 2022-06-11 01:31:50.788753
# Unit test for function get_distribution
def test_get_distribution():
    # OS X
    assert get_distribution() == 'Darwin'
    # Amazon Linux
    distro.id = lambda: 'amzn'
    assert get_distribution() == 'Amazon'
    # CentOS
    distro.id = lambda: 'centos'
    assert get_distribution() == 'Centos'
    # Debian
    distro.id = lambda: 'debian'
    assert get_distribution() == 'Debian'
    # Fedora
    distro.id = lambda: 'fedora'
    assert get_distribution() == 'Fedora'
    # openSUSE
    distro.id = lambda: 'opensuse'
    assert get_distribution() == 'Opensuse'
    # RedHat Enterprise Linux
    distro.id = lambda: 'rhel'

# Generated at 2022-06-11 01:31:56.337376
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # Test results on CentOS 7 system
    assert get_distribution_version() == u'7.5'
    # Test results on CentOS 6 system
    assert get_distribution_version() == u'6.10'
    # Test results on Ubuntu 16.04 system
    assert get_distribution_version() == u'16.04'
    # Test results on Ubuntu 18.04 system
    assert get_distribution_version() == u'18.04'



# Generated at 2022-06-11 01:32:08.228602
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class user:
        platform = 'Linux'
        distribution = 'Debian'

    class user_debian(user):
        platform = 'Linux'
        distribution = 'Debian'

    class user_sles(user):
        platform = 'Linux'
        distribution = 'Suse'

    class user_sles12(user_sles):
        platform = 'Linux'
        distribution = 'Suse'
        distribution_version = '12'

    class user_sles12_ppc64(user_sles12):
        platform = 'Linux'
        architecture = 'ppc64'
        distribution = 'Suse'
        distribution_version = '12'

    class user_sles11(user_sles):
        platform = 'Linux'
        distribution = 'Suse'
        distribution_version = '11'


# Generated at 2022-06-11 01:32:19.129346
# Unit test for function get_distribution
def test_get_distribution():
    from ansible.module_utils.facts.system.distribution import (
        GenericLinux,
        RedHat,
        Debian,
        Suse,
        FreeBSD,
        OpenBSD,
        Darwin
    )

    class TestLinux(GenericLinux):
        distribution = 'OtherLinux'

    class TestRedHat(RedHat):
        pass

    class TestDebian(Debian):
        pass

    class TestSuSE(Suse):
        pass

    class TestFreeBSD(FreeBSD):
        pass

    class TestOpenBSD(OpenBSD):
        pass

    class TestDarwin(Darwin):
        pass


# Generated at 2022-06-11 01:32:31.287300
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test with functioning lsb-release and os-release
    distro.os_release_info = lambda: {'version_codename': 'alabaster'}
    assert get_distribution_codename() == 'alabaster'

    # Test with not functioning os-release
    distro.os_release_info = lambda: {'version_codename': ''}
    assert get_distribution_codename() is None

    # Test with not functioning os-release and functioning lsb-release
    distro.os_release_info = lambda: {'version_codename': ''}
    distro.lsb_release_info = lambda: {'codename': 'beige'}
    assert get_distribution_codename() == 'beige'

    # Test with not functioning lsb-release
    distro.lsb_release

# Generated at 2022-06-11 01:32:32.342375
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-11 01:32:36.550469
# Unit test for function get_distribution
def test_get_distribution():
    distributions = ('Arch', 'Debian', 'Gentoo', 'Redhat', 'SuSE', 'Suse', 'Mandrake', 'Mandriva', 'Mageia', 'Solaris', 'OtherLinux', 'Amazon')
    for distribution in distributions:
        assert get_distribution() == distribution



# Generated at 2022-06-11 01:32:46.083952
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass
    class Linux(Base):
        platform = "Linux"
    class RedHat(Linux):
        distribution = "RedHat"
    class Ubuntu(Linux):
        distribution = "Ubuntu"
    class LinuxGentoo(Linux):
        distribution = "Gentoo"
    assert get_platform_subclass(Linux) == Linux
    assert get_platform_subclass(Base) == Base
    assert get_platform_subclass(RedHat) == RedHat
    assert get_platform_subclass(Ubuntu) == Ubuntu
    assert get_platform_subclass(LinuxGentoo) == LinuxGentoo

# Generated at 2022-06-11 01:33:10.106625
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    correct_codename = {
        'centos': '',
        'fedora': '',
        'amazon': '',
        'rhel': '',
        'debian': '',
        'ubuntu': 'precise',
    }

    wrong_codename = {
        'centos': 'CentOS',
        'fedora': 'fedora',
        'amazon': 'amazon',
        'rhel': 'rhel',
        'debian': 'debian',
        'ubuntu': 'ubuntu',
    }

    for distro_id, codename in correct_codename.items():
        assert get_distribution_codename(distro_id) == codename
        assert get_distribution_codename(distro_id.capitalize()) == codename


# Generated at 2022-06-11 01:33:13.795299
# Unit test for function get_distribution_version
def test_get_distribution_version():
    # mock distribution.py's id function to return a distro name
    distro.id = lambda: 'debian'
    # make sure we get the right version
    assert get_distribution_version() == '9.9'

# Generated at 2022-06-11 01:33:20.930651
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Shows how to use get_platform_subclass
    '''

    # class that uses get_platform_subclass
    class PlatformClass():
        platform = None
        distribution = None

        @classmethod
        def myfunction(cls):
            return(u'In class: %s' % cls.__name__)

        @classmethod
        def anotherfunction(cls):
            return(u'In class: %s' % cls.__name__)

    # platform specific subclass
    class MyMacOS(PlatformClass):
        platform = u'Darwin'

    # distribution specific subclass
    class MyDebian(PlatformClass):
        platform = None
        distribution = u'Debian'

    # subclass of distribution specific subclass
    class MyUbuntu(MyDebian):
        distribution = u'Ubuntu'



# Generated at 2022-06-11 01:33:31.939297
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for get_platform_subclass

    :returns: ``True`` if all tests pass, ``False`` otherwise
    '''

    import platform

    class BaseClass:
        platform = 'Linux'
        distribution = None

    class TestClassA(BaseClass):
        distribution = 'TestClassA'

    class TestClassB(BaseClass):
        distribution = 'TestClassB'

    class TestClassC(BaseClass):
        pass

    platform_subclass = get_platform_subclass(BaseClass)

    # Test Linux subclass
    assert platform_subclass is BaseClass

    # Test Linux subclass
    TestClassA.platform = 'TestClassA'
    platform_subclass = get_platform_subclass(TestClassA)
    assert platform_subclass is TestClassA

    # Test Linux subclass
    Test

# Generated at 2022-06-11 01:33:42.771784
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    Run the test_get_distribution_version test
    """
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    with patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.distro.id', return_value='distro_id'), \
        patch.object(distro, 'version', return_value=None), \
        patch.object(distro, 'version', return_value='version', __getitem__=lambda self, arg: arg):
            assert get_distribution_version() == None

# Generated at 2022-06-11 01:33:47.964523
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    test linux distro version
    """
    import os
    distro_id = get_distribution()
    distro_version = get_distribution_version()
    if distro_id == 'centos' and os.path.exists("/etc/os-release"):
        os_release_info = distro.os_release_info()
        version_best = os_release_info.get('version_id')
        version = version_best.split('.')[0]
        assert version == distro_version
    else:
        version_best = distro.version(best=True)
        assert version_best == distro_version

# Generated at 2022-06-11 01:33:50.064485
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == get_distribution().capitalize() or get_distribution() == 'OtherLinux'



# Generated at 2022-06-11 01:33:52.942122
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    expected = u'cosmic'
    assert get_distribution_codename() == expected, 'get_distribution_codename() != %s' % expected

# Generated at 2022-06-11 01:34:03.590082
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform


# Generated at 2022-06-11 01:34:12.460990
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for get_distribution_version()
    '''
    distributions = (
        # Not Linux distributions
        ('FreeBSD', None),
        ('Darwin', None),
        ('Windows', None),
        # Linux distributions
        ('Centos', '7.5.1804'),
        ('Debian', '9.5'),
        ('Fedora', '28'),
        ('OpenSUSE', 'Leap 42.3'),
        ('Redhat', '7'),
        ('Ubuntu', '16.04.5 LTS'),
    )
    for mock_distro_id, expected_version in distributions:
        actual_version = get_distribution_version(mock_distro_id)
        assert actual_version == expected_version

# Generated at 2022-06-11 01:34:46.782606
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    assert codename is not None
    debian_version = platform.linux_distribution()[2]
    if debian_version.startswith('wheezy') or debian_version.startswith('jessie'):
        assert codename == 'wheezy' or codename == 'jessie'
    if debian_version.startswith('stretch') or debian_version.startswith('buster'):
        assert codename == 'stretch' or codename == 'buster'
    if codename == 'xenial':
        assert debian_version.startswith('xenial')

# Generated at 2022-06-11 01:34:56.860621
# Unit test for function get_distribution
def test_get_distribution():
    import sys

    platform_to_distro = {
        'Linux': ('Amazon', 'CentOS', 'Debian', 'Fedora', 'RedHat', 'SUSE'),
        'OpenBSD': ('OpenBSD',),
        'FreeBSD': ('FreeBSD',),
        'Darwin': ('MacOSX',),
        'SunOS': ('Solaris', ),
    }

    for ostype, distros in platform_to_distro.items():
        for distro in distros:
            # Test with a variety of different python versions
            python_versions = ['2.', '3.']
            if ostype == 'Linux':
                # Linux includes a fallback to 'OtherLinux'
                python_versions.extend(['pypy', 'pypy3', 'jython'])


# Generated at 2022-06-11 01:35:08.423046
# Unit test for function get_distribution_codename
def test_get_distribution_codename():

    # Test that codename is returned when code name is in os-release
    distro.linux_distribution = lambda *args, **kwargs: ('Ubuntu', '18.04', 'bionic')
    codename = get_distribution_codename()

    assert codename == 'bionic'

    # Test that codename is returned when code name is in lsb_release
    distro.os_release_info = lambda: {'ubuntu_codename': None}
    distro.lsb_release_info = lambda: {'codename': 'bionic'}
    codename = get_distribution_codename()

    assert codename == 'bionic'

    # Test that codename is returned when lsb_release is empty
    distro.os_release_info = lambda: {'ubuntu_codename': None}
    distro

# Generated at 2022-06-11 01:35:19.016769
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass

    Check that the function can find specific subclasses, but fall back to the
    base class if an appropriate subclass cannot be found.
    '''

    class A:
        platform = 'A'
        distribution = 'A'

    class B:
        platform = 'A'
        distribution = 'B'

    class C:
        platform = 'C'
        distribution = 'C'

    class D(B):
        platform = 'D'
        distribution = 'D'

    class E(D):
        platform = 'E'
        distribution = 'E'

    class F(D):
        platform = 'F'
        distribution = 'F'

    class G(E):
        platform = 'G'
        distribution = 'G'


# Generated at 2022-06-11 01:35:29.990001
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class ParentModule:
        distribution = None
        platform = None

    class ChildLinuxModule(ParentModule):
        distribution = None
        platform = 'Linux'

    class ChildLinuxUbuntuModule(ChildLinuxModule):
        distribution = 'Ubuntu'

    class ChildLinuxRedHatModule(ChildLinuxModule):
        distribution = 'RedHat'

    class ChildLinuxCentOSModule(ChildLinuxRedHatModule):
        distribution = 'CentOS'
        version = 'CentOS8'

    class ChildLinuxAmazonModule(ChildLinuxModule):
        distribution = 'Amazon'

    class ChildLinuxSUSEModule(ChildLinuxModule):
        distribution = 'SUSE'

    class ChildLinuxDebianModule(ChildLinuxModule):
        distribution = 'Debian'

    class ChildLinuxDSLModule(ChildLinuxModule):
        distribution = 'DSL'

# Generated at 2022-06-11 01:35:39.913925
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit tests for get_platform_subclass function
    '''
    import pytest

    class Subclass(object):
        ''' Base class '''
        platform = None
        distribution = None

    class LinuxSubclass(Subclass):
        ''' Linux subclass '''
        platform = u'Linux'
        distribution = None

    class LinuxDistroSubclass(Subclass):
        ''' Linux distribution specific subclass '''
        platform = u'Linux'
        distribution = get_distribution()

    class OtherPlatformSubclass(Subclass):
        ''' Unsupported/unrecognized subclass '''
        platform = u'Other'
        distribution = None

    class LinuxDistroOtherPlatformSubclass(Subclass):
        ''' Unsupported/unrecognized subclass '''
        platform = u'Other'
        distribution = get_dist

# Generated at 2022-06-11 01:35:47.068236
# Unit test for function get_distribution

# Generated at 2022-06-11 01:35:57.615270
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the get_platform_subclass() function
    '''
    import textwrap

    # Dummy class hierarchy to test
    class Meta(type):
        platform = None
        distribution = None

        def __new__(metacls, name, bases, namespace):
            cls = super(Meta, metacls).__new__(metacls, name, bases, namespace)
            return cls


    class Platform1(object):
        __metaclass__ = Meta
        platform = 'Platform1'


    class Platform2(Platform1):
        __metaclass__ = Meta
        platform = 'Platform2'


    class Platform3(Platform2):
        __metaclass__ = Meta
        platform = 'Platform3'


    class Distribution1(Platform1):
        __metaclass__ = Meta


# Generated at 2022-06-11 01:36:07.201789
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    ''' Function get_platform_subclass is tested by running the unit test '''
    from ansible.module_utils.six import add_metaclass

    @add_metaclass(get_platform_subclass)
    class MySubclassTest(object):
        ''' Class for testing function get_platform_subclass '''
        platform = 'Linux'
        distribution = None

    @add_metaclass(get_platform_subclass)
    class MySubclassTest2(MySubclassTest):
        ''' Class for testing function get_platform_subclass '''
        distribution = get_distribution()


    my_class_test = MySubclassTest()
    assert isinstance(my_class_test, MySubclassTest)
    my_class_test2 = MySubclassTest2()

# Generated at 2022-06-11 01:36:08.474046
# Unit test for function get_distribution_version
def test_get_distribution_version():
    version = get_distribution_version()
    return version


# Generated at 2022-06-11 01:37:01.209404
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    cls = get_platform_subclass
    assert cls == distro.get_platform_subclass
    assert cls(platform.system) is platform.system
    assert cls(get_distribution) is get_distribution
    assert cls(get_distribution_version) is get_distribution_version
    assert cls(get_distribution_codename) is get_distribution_codename

# Generated at 2022-06-11 01:37:13.607116
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test returning the best subclass for a certain distro/platform combination.
    '''
    # Fake class hierarchy
    class Base(object):
        platform = "Linux"

    class FirstSubclass(Base):
        platform = "Linux"
        distribution = None

    class SecondSubclass(Base):
        platform = "Linux"
        distribution = "Fedora"

    class ThirdSubclass(Base):
        platform = "Linux"
        distribution = "Redhat"

    class FourthSubclass(SecondSubclass):
        distribution = "Fedora"

    # search on current platform
    assert get_platform_subclass(Base) == Base
    assert get_platform_subclass(FirstSubclass) == FirstSubclass
    assert get_platform_subclass(SecondSubclass) == SecondSubclass

# Generated at 2022-06-11 01:37:16.848519
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''Test the get_distribution_version function'''
    distribution = get_distribution()
    version = get_distribution_version()
    print("distribution: %s, version: %s" % (distribution, version))


# Generated at 2022-06-11 01:37:27.400914
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Create some classes to test with
    class TestClass1:
        platform = 'linux'
        distribution = None

    class TestClass2(TestClass1):
        distribution = 'redhat'

    class TestClass3(TestClass1):
        distribution = 'amazon'

    class TestClass4(TestClass1):
        platform = 'windows'
        distribution = None

    class TestClass5(TestClass3):
        platform = 'windows'

    # Function get_platform_subclass should:
    #  - return the most specific subclass (TestClass2)
    #  - return the most specific subclass for other Linux distros (TestClass1)
    #  - return the most specific subclass for other platforms (TestClass4)
    #  - return the class if no subclass is defined (TestClass5)

# Generated at 2022-06-11 01:37:28.901729
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-11 01:37:40.029106
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    from distro import id
    from distro import version
    from distro import version_best
    from distro import os_release_info
    from distro import lsb_release_info

    # mock platform.system
    platform.system = lambda: 'Linux'

    # mock distro.id
    distro.id = lambda: 'Ubuntu'

    # mock distro.version
    distro.version = lambda: '18.04'

    # mock distro.version_best
    distro.version_best = lambda best=False: '18.04.3 LTS (Bionic Beaver)'

    # mock distro.os_release_info

# Generated at 2022-06-11 01:37:41.332011
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == u'xenial'

# Generated at 2022-06-11 01:37:49.425966
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class LinuxDistributionA(object):
        platform = 'Linux'
        distribution = 'DistroA'
    class LinuxDistributionB(object):
        platform = 'Linux'
        distribution = 'DistroB'
    class LinuxDistributionC(object):
        platform = 'Linux'
        distribution = 'DistroC'
    class LinuxDistributionD(object):
        platform = 'Linux'
        distribution = None
    class LinuxDistributionE(object):
        platform = 'Linux'
        distribution = None
    class FakeDistribution(object):
        platform = 'FakeDistribution'
        distribution = 'foo'

    class SubclassTestA(LinuxDistributionA):
        pass

# Generated at 2022-06-11 01:38:00.968496
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    test_cases = (
        (u'centos', u'centos', u'7', u'Core'),
        (u'debian', None, u'8', u''),
        (u'debian', u'jessie/sid', u'8', u'jessie'),
        (u'fedora', None, u'28', u''),
        (u'fedora', u'Twenty Eight', u'28', u'Twenty Eight'),
        (u'opensuse', u'Leap', u'15.1', u'Leap'),
        (u'ubuntu', None, None, u''),
        (u'ubuntu', u'xenial', None, u'xenial'),
    )


# Generated at 2022-06-11 01:38:09.736338
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        pass

    class A_unix(A):
        pass

    class A_bsd(A_unix):
        pass

    class A_linux(A_unix):
        pass

    class A_mac(A):
        pass

    class A_distro(object):
        distribution = 'TEST'

    class A_linux_distro1(A_linux, A_distro):
        pass

    class A_linux_distro2(A_linux, A_distro):
        pass

    class A_linux_distro2_2(A_linux_distro2):
        pass

    class A_bsd_distro(A_bsd, A_distro):
        pass

    class A_mac_distro1(A_mac, A_distro):
        pass

