

# Generated at 2022-06-11 01:29:56.277064
# Unit test for function get_distribution
def test_get_distribution():
    expected_distribution = platform.system().capitalize()

    if platform.system() == 'Linux':
        if expected_distribution == 'Linuxmint':
            expected_distribution = 'Mint'
        elif expected_distribution == 'AIX':
            expected_distribution = 'OtherLinux'
        elif expected_distribution == 'Raspbian':
            expected_distribution = 'Debian'

    if isinstance(expected_distribution, bytes):
        expected_distribution = expected_distribution.decode('utf-8', 'surrogateescape')

    assert get_distribution() == expected_distribution

# Generated at 2022-06-11 01:30:08.097699
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    original_platform_system = platform.system
    original_distro_id = distro.id
    original_distro_codename = distro.codename

    try:
        platform.system = lambda: 'Linux'
        distro.id = lambda: 'Ubuntu'
        distro.codename = lambda: 'UnsupportedUbuntu'

        os_release_info = {'version_codename': 'wily'}
        lsb_release_info = {'codename': 'wily'}

        distro.os_release_info = lambda: os_release_info
        distro.lsb_release_info = lambda: lsb_release_info

        assert get_distribution_codename() == 'wily'
    finally:
        platform.system = original_platform_system
        distro.id = original_

# Generated at 2022-06-11 01:30:16.783069
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
        Unit test for get_platform_subclass
    '''

    unittest.TestCase.assertEqual(get_platform_subclass(User, "linux", "centos"), UserLinux)
    unittest.TestCase.assertEqual(get_platform_subclass(User, "linux", "ubuntu"), UserLinux)
    unittest.TestCase.assertEqual(get_platform_subclass(User, "linux", "rhel"), UserLinux)
    unittest.TestCase.assertEqual(get_platform_subclass(User, "linux", "amazon"), UserLinux)
    unittest.TestCase.assertEqual(get_platform_subclass(User, "linux", "redhat"), UserLinux)

# Generated at 2022-06-11 01:30:23.415482
# Unit test for function get_distribution
def test_get_distribution():
    # Get distribution the code is running on
    distribution = get_distribution()

    # If get_distribution function return either 'Linux' or None
    # It means the function get_distribution isn't working
    if distribution is None or distribution == 'Linux':
        print("FAILED: function get_distribution is not working")
    else:
        print("SUCCESS: function get_distribution is working: %s" % distribution)


# Generated at 2022-06-11 01:30:33.483988
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass

    :rtype: NativeString or None
    :returns: A string representation of the distribution's codename or None if not a Linux distro
    '''
    class A:
        platform = 'Linux'
        distribution = None

    class B(A):
        platform = 'Linux'
        distribution = 'El7'
        pass

    class C(B):
        platform = 'Linux'
        distribution = 'El7'
        pass

    class D(A):
        platform = 'Linux'
        distribution = 'El6'
        pass

    class E(A):
        pass

    class F(A):
        platform = 'Windows'
        distribution = 'Windows'

    assert get_platform_subclass(A) == A

# Generated at 2022-06-11 01:30:38.501090
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
        This is a unit test for the function get_platform_subclass()
    '''
    # Only run the test on Linux
    if platform.system() == 'Linux':
        # Insert a new class into the platform_subclass_tree
        class _TestClassLinux(object):
            platform = 'Linux'
            distribution = get_distribution()
        _TestClassLinux.__name__ = 'TestClass' + _TestClassLinux.platform + _TestClassLinux.distributio

# Generated at 2022-06-11 01:30:50.456164
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    import pytest

    test_scenario_list = [
        ('debian', 'buster'),
        ('ubuntu', 'xenial'),
        ('centos', 'centos7'),
        ('fedora', '28')
    ]
    for scenario in test_scenario_list:
        distro_id = scenario[0]
        codename = scenario[1]

        def mock_distro_id(os_release=False):
            if os_release:
                return None
            else:
                return distro_id

        def mock_codename(os_release=True):
            if os_release:
                return None
            else:
                return codename

        def mock_os_release_info():
            return {'version_codename': codename}


# Generated at 2022-06-11 01:31:00.486576
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''

# Generated at 2022-06-11 01:31:11.056023
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.parameters import is_empty

    from ansible_collections.sensu.sensu_go.plugins.module_utils.sensu_common import SENSUBase

    class A(SENSUBase):
        platform = 'test'
        distribution = 'test'

    class B(A):
        platform = 'test'
        distribution = 'test'
        REQUIRED_IF = []

    assert get_platform_subclass(A) == B

    del B.REQUIRED_IF
    assert get_platform_subclass(A) == A

    class C(A):
        platform = 'test'
        distribution = 'test'
        REQUIRED_IF = []


# Generated at 2022-06-11 01:31:22.224608
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    # define test classes
    class Common(object):
        platform = None
        distribution = None

    class LinuxOnly(Common):
        platform = "Linux"

    class RedHatOnly(LinuxOnly):
        distribution = 'Redhat'

    # define test cases

# Generated at 2022-06-11 01:31:39.798324
# Unit test for function get_distribution_codename

# Generated at 2022-06-11 01:31:50.570763
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    if platform.system() == 'Linux':
        assert get_platform_subclass(LinuxUser) == LinuxUser
        assert get_platform_subclass(LinuxUser, distribution='Ubuntu') == UbuntuUser
        assert get_platform_subclass(LinuxUser, distribution='Amazon') == AmazonUser
    else:
        assert get_platform_subclass(LinuxUser) == LinuxUser
        assert get_platform_subclass(LinuxUser, distribution='Ubuntu') == LinuxUser
        assert get_platform_subclass(LinuxUser, distribution='Amazon') == LinuxUser

    assert get_platform_subclass(User) == User
    assert get_platform_subclass(User, distribution='Ubuntu') == User
    assert get_platform_subclass(User, distribution='Amazon') == User



# Generated at 2022-06-11 01:31:57.440744
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test on a Centos 7 machine
    def mock_distro_id(distribution=''):
        return 'centos'

    def mock_distro_codename(distribution=''):
        return 'Core'

    def mock_distro_os_release_info():
        return {'version_codename': None, 'ubuntu_codename': None}

    def mock_distro_lsb_release_info():
        return {}

    mock_type_specific_distro_module = get_platform_subclass(None)

    import ansible.module_utils.distro
    original_distro_id = ansible.module_utils.distro.id
    original_distro_codename = ansible.module_utils.distro.codename
    original_distro_os_release_info = ansible.module

# Generated at 2022-06-11 01:32:00.153210
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    codename = get_distribution_codename()
    if get_distribution() == 'Ubuntu':
        assert codename == 'xenial'

# Generated at 2022-06-11 01:32:11.905468
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class PlatformIndependentClass:
        platform = "Independent"
        distribution = None

    class Debian:
        platform = "Linux"
        distribution = "Debian"

    class OtherLinux:
        platform = "Linux"
        distribution = None

    assert get_platform_subclass(PlatformIndependentClass) == PlatformIndependentClass
    assert get_platform_subclass(Debian) == Debian
    assert get_platform_subclass(OtherLinux) == OtherLinux

    class IndependentUser(PlatformIndependentClass):
        pass
    class LinuxUser(PlatformIndependentClass):
        platform = "Linux"
    class DebianUser(LinuxUser):
        distribution = "Debian"
    class OtherUser(LinuxUser):
        distribution = None

    assert get_platform_subclass(IndependentUser) == IndependentUser
    assert get_platform_subclass(LinuxUser) == LinuxUser


# Generated at 2022-06-11 01:32:13.488140
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == u'bionic'


# Generated at 2022-06-11 01:32:22.352758
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    This is a unit test for the function get_platform_subclass.
    First we will test if it finds the right subclass if the class has a subclass that
    matches both the platform and the distribution, then if it will find a subclass
    that matches the platform and has a distribution of None, and finally the class passed in.
    '''
    import unittest
    import platform

    # Define three classes that implement the same functions, with platform and distribution
    # defined.
    class Class1:
        platform = 'foo'
        distribution = 'bar'

        def get_platform(self):
            return 'foo'

        def get_distribution(self):
            return 'bar'

    class Class2:
        platform = 'foo'
        distribution = None

        def get_platform(self):
            return 'foo'


# Generated at 2022-06-11 01:32:34.283272
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        def __init__(self):
            self.platform = platform.system()

    class A(Base):
        distribution = None

    class B(A):
        distribution = None

    class C(Base):
        distribution = None

    class E(Base):
        platform = 'Linux'

    class F(Base):
        platform = 'Darwin'

    class G(Base):
        platform = 'Linux'
        distribution = None

    class H(Base):
        platform = 'Linux'
        distribution = get_distribution()

    class I(Base):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class J(Base):
        platform = 'Linux'
        distribution = get_distribution()

    class K(H):
        distribution = None

    class L(J):
        distribution = None

# Generated at 2022-06-11 01:32:46.286142
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the function get_distribution()
    '''
    def get_distribution_stub(self):
        return 'centos'

    def get_distribution_stub_not_defined(self):
        return None

    #
    # Test the case when the distribution is defined
    #
    # Note: mock works only in Python 2.x
    #
    with mock.patch('ansible.module_utils.distro.id', get_distribution_stub):
        assert get_distribution() == 'Centos'

    #
    # Test the case when the distribution is not defined, so the platform is Linux
    #
    # Note: mock works only in Python 2.x
    #

# Generated at 2022-06-11 01:32:48.782204
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-11 01:33:07.740300
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename
    '''

    from ansible.module_utils.test_fixture_utils import TestCase # pylint: disable=missing-docstring
    import mock # pylint: disable=import-error

    # System is Linux and distro.id() is ubuntu

# Generated at 2022-06-11 01:33:17.695225
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # The behavior of this function changed in Ansible 2.5.
    # In Ansible 2.4 it was possible to use 'cls' instead of 'cls.__name__' and
    # the extra arguments were passed to the super class initializer.
    this_platform = platform.system()
    distribution = get_distribution()

    class base():
        distribution = None
        platform = this_platform

    class sub1(base):
        distribution = distribution

    class sub2(base):
        platform = 'Nope'

    assert get_platform_subclass(base) == base
    assert get_platform_subclass(sub1) == sub1
    assert get_platform_subclass(sub2) == base

# Generated at 2022-06-11 01:33:24.248581
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class Derived1(Base):
        platform = 'Linux'

    class Derived2(Derived1):
        distribution = None

    class Derived3(Derived1):
        distribution = ''

    class Derived4(Derived1):
        distribution = 'Linux'

    class Derived5(Derived1):
        distribution = 'CentOS'
        platform = 'Linux'

    class Derived6(Base):
        distribution = 'CentOS'
        platform = 'Windows'

    class Derived7(Base):
        distribution = None
        platform = 'Windows'

    assert get_platform_subclass(Base) == Base
    assert get_platform_subclass(Derived1) == Derived2

    d2 = Derived2()
    d2.distribution = 'Linux'

# Generated at 2022-06-11 01:33:35.880044
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Create classes for testing
    class PlatformClass(object):
        platform = platform.system()
        distribution = get_distribution()

    class PlatformClassWrongPlatform(PlatformClass):
        platform = 'WrongPlatform'

    class PlatformClassWrongDist(PlatformClass):
        distribution = 'WrongDistribution'

    class PlatformClassUbuntu(PlatformClass):
        distribution = 'Ubuntu'

    class PlatformClassFedora(PlatformClass):
        distribution = 'Fedora'
        platform = 'Linux'

    class PlatformClassLinux(PlatformClass):
        platform = 'Linux'

    class PlatformClassWindows(PlatformClass):
        platform = 'Windows'

    class PlatformClassMac(PlatformClass):
        platform = 'Mac'

    class PlatformClassFreeBSD(PlatformClass):
        platform = 'FreeBSD'


# Generated at 2022-06-11 01:33:45.333680
# Unit test for function get_distribution_codename

# Generated at 2022-06-11 01:33:54.611249
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    distro_id = u'linuxmint'
    distro_version = u'19'
    distro_codename = u'Unknown'

    class TestFacts:
        pass

    test_instance = TestFacts()

    test_instance.lsb = {}
    test_instance.lsb['distro_id'] = distro_id
    test_instance.lsb['distro_release'] = distro_version
    test_instance.lsb['distro_codename'] = distro_codename

    codename = get_distribution_codename()

    assert codename is not None
    assert codename == u'tara'

# Generated at 2022-06-11 01:33:57.070089
# Unit test for function get_distribution_version
def test_get_distribution_version():
    """
    unit test for function get_distribution_version
    """
    assert get_distribution_version() == "7.6"


# Generated at 2022-06-11 01:34:07.753654
# Unit test for function get_distribution

# Generated at 2022-06-11 01:34:15.192007
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the get_platform_subclass function
    '''
    class base(object):
        '''
        An empty base class for testing get_platform_subclass
        '''
        pass

    class ubuntu(base):
        '''
        A subclass of base specific to ubuntu
        '''
        distribution = 'Ubuntu'
        platform = 'Linux'

    class ubuntu_exact(ubuntu):
        '''
        A subclass of base specific to an exact version of ubuntu
        '''
        version = '14.04'

    class ubuntu_major(ubuntu):
        '''
        A subclass of base specific to a major version of ubuntu
        '''
        version = '14'


# Generated at 2022-06-11 01:34:26.251937
# Unit test for function get_distribution_version
def test_get_distribution_version():
    distribution = platform.linux_distribution(full_distribution_name=1)[0]
    version = get_distribution_version()
    if version is not None and distribution in ('CentOS', 'RedHatEnterpriseServer'):
        distribution_full_version = platform.linux_distribution(full_distribution_name=1)[1] # e.g. '7.3.1611'
        assert distribution_full_version.split('.')[0] == version, "get_distribution_version() returns major version instead of minor version for %s." % distribution

    # Test get_distribution_version() returns an empty string when no version is available
    distribution_version = distro.version()
    if distribution_version is None:
        assert version == '', "get_distribution_version() returns content when there is no version available."


#

# Generated at 2022-06-11 01:34:43.071080
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class my_class:
        """ Normal class. """
        pass

    class my_subclass1(my_class):
        """ Linux only class. """
        platform = 'Linux'
        distribution = None

    class my_subclass2(my_class):
        """ Linux with distribution. """
        platform = 'Linux'
        distribution = 'Redhat'

    class my_subclass3(my_class):
        """ Windows class. """
        platform = 'Windows'
        distribution = None

    class my_subclass4(my_subclass1):
        """ Linux only class with a more specific distribution. """
        distribution = 'Fedora'


    # test with a platform that doesn't have any subclasses
    result = get_platform_subclass(my_class)
    assert result is my_class

    # test with a platform that

# Generated at 2022-06-11 01:34:54.347453
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    # Test distribution is not Linux
    def _test_distribution_not_linux():
        '''
        Test Linux distribution as "OtherLinux"
        '''
        # Set platform to not Linux
        original_platform = platform.system()
        platform.system = lambda: 'OtherLinux'
        assert(get_distribution_codename() is None)
        # Restore platform
        platform.system = original_platform

    _test_distribution_not_linux()

    # Test distribution is Linux but not known
    def _test_distribution_linux_unknown():
        '''
        Test Linux distribution as "OtherLinux"
        '''
        # Set platform to Linux
        original_platform = platform.system()
        platform.system = lambda: 'Linux'

# Generated at 2022-06-11 01:34:56.335962
# Unit test for function get_distribution
def test_get_distribution():
    from ansible_collections.ansible.community.plugins.module_utils.basic import get_distribution
    assert get_distribution() == 'OtherLinux'

# Generated at 2022-06-11 01:34:57.480196
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
  assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-11 01:35:08.964972
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import threading
    import socket

    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        def __new__(cls, *args, **kwargs):
            return object.__new__(C, *args, **kwargs)

    class D(A):
        pass

    class E(C):
        pass

    class F(E):
        def __new__(cls, *args, **kwargs):
            return object.__new__(F, *args, **kwargs)

    class Socket(socket.socket):
        """
        Mock socket class that saves the instance in the instances list.
        """
        instances = []

        def __init__(self, *args, **kwargs):
            self.__class__.instances.append(self)
           

# Generated at 2022-06-11 01:35:19.492719
# Unit test for function get_platform_subclass

# Generated at 2022-06-11 01:35:31.135935
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    tests = [
        # output, expected result
        ('', None),
        ('Santiago', None),
        ('Maipo', None),
        ('Red Hat Enterprise Linux Server release 6.5 (Santiago)', 'santiago'),
        ('CentOS Linux release 6.7 (Final)', None),
        ('Fedora release 25 (Twenty Five)', 'twentyfive'),
    ]

    platform_save = platform.system
    distro_id_save = distro.id

    for test, expected in tests:
        platform.system = lambda: 'Linux'
        distro.id = lambda: 'Linux'
        distro.os_release_info = lambda: {'version_codename':test}
        result = get_distribution_codename()
        assert result == expected
        # Test that the same result is returned on

# Generated at 2022-06-11 01:35:36.616704
# Unit test for function get_distribution
def test_get_distribution():
    testcases = {
        'redhat': 'Redhat',
        'amzn': 'Amazon',
        'ubuntu': 'Ubuntu',
        'alpine': 'Alpine',
        'darwin': None,
    }

    for distro_id, expected_result in testcases.items():
        distro.id = lambda: distro_id
        assert get_distribution() == expected_result


# Generated at 2022-06-11 01:35:40.391033
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename() == ''
    assert get_distribution_codename() == 'xenial'
    assert get_distribution_codename() == ''
    assert get_distribution_codename() == ''
    assert get_distribution_codename() == ''

# Generated at 2022-06-11 01:35:47.364165
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    This isn't an elegant way to test a function but it's better than nothing

    :rtype: None
    :raises: Exception if the tests fail.
    '''
    expected_values = dict()
    expected_values['Amazon'] = u'2018.03'
    expected_values['Centos'] = u'7.6.1810'
    expected_values['Debian'] = u'9.5'
    expected_values['Kali'] = u'kali-rolling'
    expected_values['OpenSuse'] = u'15.0'
    expected_values['Redhat'] = u'7.6'
    expected_values['Ubuntu'] = u'16.04'

    for dist_name in expected_values:
        if not dist_name in distro.id():
            continue

        dist_

# Generated at 2022-06-11 01:35:56.826337
# Unit test for function get_distribution
def test_get_distribution():
    """
    When distribution cannot be determined, returns "OtherLinux"
    """
    if platform.system() == 'Linux':
        assert get_distribution() == "OtherLinux"
    else:
        assert get_distribution() is None



# Generated at 2022-06-11 01:36:06.510984
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test autogenerated from get_distribution_version.py
    '''

    # We need to mock distro.py to properly test this function
    import sys
    import inspect
    import ansible.module_utils.common.distro

    # We need to mock the distro.py library to return our test values
    class MockDistro(object):
        def __init__(self):
            self.distro_id_map = {
                'centos': 'CentOS',
                'rhel': 'RedHat',
                'fedora': 'Fedora',
                'debian': 'Debian',
                'ubuntu': 'Ubuntu',
            }

# Generated at 2022-06-11 01:36:16.717683
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the get_platform_subclass function

    :return: True if the tests pass, False if one fails
    '''
    # We could make this a proper unit test file.  However, this function is
    # only used by modules.  If we create a unit test here, it will have to be
    # added to ansible-test so that it will run on every platform with every
    # major version of Python tested by Ansible.  That will slow the tests down
    # significantly.  In the future, it may make sense to put it in ansible-test
    # since it will only run when porting modules.  For now, just do a simple
    # test.

# Generated at 2022-06-11 01:36:26.693461
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # This is a hackish way to test this function without actually
    # running it on each possible operating system.  If we can
    # figure out a better way to test this, we should change it.
    class Base(object):
        platform = 'Base'
        distro = None

    class POSIX(Base):
        platform = 'POSIX'

    class Linux(POSIX):
        platform = 'Linux'

    class Darwin(POSIX):
        platform = 'Darwin'

    class OpenBSD(POSIX):
        platform = 'OpenBSD'

    class SunOS(POSIX):
        platform = 'SunOS'

    class LinuxOther(Linux):
        platform = 'Linux'
        distro = 'OtherLinux'

    class LinuxFedora(Linux):
        platform = 'Linux'
        distro = 'Fedora'


# Generated at 2022-06-11 01:36:28.072905
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'


# Generated at 2022-06-11 01:36:36.166341
# Unit test for function get_platform_subclass

# Generated at 2022-06-11 01:36:47.273312
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Create a class hierarchy that mirrors the current structure of the user module platform specifics

    class User:
        platform = 'Posix'
        distribution = None

    class UserBSD(User):
        platform = 'BSD'
        distribution = None

        class UserPCBSD(UserBSD):
            distribution = 'FreeBSD'

        class UserMacOSX(UserBSD):
            distribution = 'MacOSX'

    class UserLinux(User):
        platform = 'Linux'
        distribution = None

        class UserDebian(UserLinux):
            distribution = 'Debian'

            class UserUbuntu(UserDebian):
                distribution = 'Ubuntu'

    class UserSolaris(User):
        platform = 'Solaris'
        distribution = None

        class UserSmartOS(UserSolaris):
            distribution = 'SmartOS'

    assert get_platform_sub

# Generated at 2022-06-11 01:36:47.967354
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-11 01:36:49.371910
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    codename = get_distribution_codename()
    assert codename == None
    return

# Generated at 2022-06-11 01:36:55.904598
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class TestA(object):
        platform = 'XXX'
        distribution = None
    class TestB(object):
        platform = 'YYY'
        distribution = None
    class TestC(object):
        platform = 'XXX'
        distribution = 'ZZZ'
    class TestD(object):
        platform = 'XXX'
        distribution = 'YYY'
    assert get_platform_subclass(TestA) == TestA # no platform match
    assert get_platform_subclass(TestB) == TestB # no platform match
    assert get_platform_subclass(TestC) == TestC # platform match
    assert get_platform_subclass(TestD) == TestD # platform match
    # Make sure the most specific match is returned
    assert get_platform_subclass(TestA) == TestA

# Generated at 2022-06-11 01:37:14.343067
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''Test function get_platform_subclass'''

    # Test creating an object from a base class with no platform-specific
    # subclasses registered
    assert BasicClass == get_platform_subclass(BasicClass)
    basic = BasicClass()
    assert isinstance(basic, BasicClass)

    # Test creating an object from a base class with platform-specific
    # subclasses registered
    assert UbuntuClass == get_platform_subclass(PlatformClass)
    ubuntu = PlatformClass()
    assert isinstance(ubuntu, UbuntuClass)

    # Test creating an object from a base class with a mix of platform-specific
    # subclasses and general-purpose subclasses registered
    assert MixedPlatformClass == get_platform_subclass(MixedClass)
    mixed = MixedClass()
    assert isinstance(mixed, MixedPlatformClass)

    # Test creating an

# Generated at 2022-06-11 01:37:21.988946
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test that given known codename and version_codenames they match up correctly.
    '''

    import distro
    distro._distro = None  # Force a reload on next access
    platform_system = platform.system()
    class MockOSRelease:
        def __init__(self, os_release_info):
            self.os_release_info = os_release_info

        def __iter__(self):
            return iter(self.os_release_info.items())

    class MockLSBRelease:
        def __init__(self, lsb_release_info):
            self.lsb_release_info = lsb_release_info

        def __iter__(self):
            return iter(self.lsb_release_info.items())


# Generated at 2022-06-11 01:37:33.929955
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class LinuxBase(Base):
        platform = 'Linux'

    class RHEL(LinuxBase):
        platform = 'Linux'
        distribution = 'RedHat'

    class Fedora(LinuxBase):
        platform = 'Linux'
        distribution = 'Fedora'

    class WindowsBase(Base):
        platform = 'Windows'

    class Win2008R2(WindowsBase):
        platform = 'Windows'
        distribution = '2008ServerR2'

    class Win2012R2(WindowsBase):
        platform = 'Windows'
        distribution = '2012ServerR2'

    class BaseTest:
        def __init__(self, platform, distribution, expected_type):
            self.platform = platform
            self.distribution = distribution
            self.expected_type = expected_type


# Generated at 2022-06-11 01:37:44.251307
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'All'
        distribution = None
    class A(Base):
        platform = 'Linux'
        distribution = 'CentOS'
    class B(Base):
        platform = 'Linux'
        distribution = 'Debian'
    class C(Base):
        platform = 'Darwin'
        distribution = 'OS X'
    class D(B):
        platform = 'Linux'
        distribution = 'Debian'

    # platform is All, distribution is none
    # expect Base
    assert Base == get_platform_subclass(Base)

    # platform is All, distribution is B
    # expect B
    assert B == get_platform_subclass(B)

    # platform is All, distribution is C
    # expect C
    assert C == get_platform_subclass(C)

    # platform is Linux,

# Generated at 2022-06-11 01:37:53.367326
# Unit test for function get_distribution_version
def test_get_distribution_version():
    ''' Test get_distribution_version '''

    # Note: test_distro requires the following packages to be installed on the
    # test system:
    #   - debian: lsb-release
    #   - centos: yum-utils
    #   - redhat: yum-utils
    #   - Fedora: fedora-release
    #   - Ubuntu: lsb-release

    # Specific versions of OS. Returned version should match test_distro

# Generated at 2022-06-11 01:37:54.915693
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None  # type: ignore

# Generated at 2022-06-11 01:37:59.232882
# Unit test for function get_distribution
def test_get_distribution():
    distro_name = get_distribution()
    distro_version = get_distribution_version()
    assert distro_name is not None, "get_distribution returned none"
    assert distro_version is not None, "get_distribution_version returned none"


# Generated at 2022-06-11 01:38:01.013062
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'trusty'

# Generated at 2022-06-11 01:38:09.753324
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Create a class hierarchy of platform specific subclasses
    class Generic:
        pass

    class GenericLinux(Generic):
        platform = 'Linux'

    class Ubuntu(GenericLinux):
        distribution = 'Ubuntu'

    class Centos(GenericLinux):
        distribution = 'Centos'

    class Windows(Generic):
        platform = 'Windows'

    class POSIX(Generic):
        platform = None

    # Test the function with multiple platforms
    import sys
    save_platform = sys.platform

# Generated at 2022-06-11 01:38:18.797949
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Fedora 29
    os_release_str = 'NAME=Fedora\nVERSION="29 (Workstation Edition)"\nID=fedora\nVERSION_ID=29\nPLATFORM_ID="platform:f29"\nPRETTY_NAME="Fedora 29 (Workstation Edition)"\nANSI_COLOR="0;34"'
    os_release_info = distro._parse_os_release(os_release_str)
    codename = distro._parse_codename(os_release_info)
    assert codename == None

    # Ubuntu Xenial Xerus

# Generated at 2022-06-11 01:38:40.672744
# Unit test for function get_distribution
def test_get_distribution():
    import os

    # Test our mapping of os-release ID to distribution name
    assert get_distribution() == 'Debian'
    assert get_distribution_version() == '7'
    assert get_distribution_codename() == 'wheezy'

    os.environ['ID'] = 'amazon'
    del os.environ['VERSION_ID']
    del os.environ['VERSION']
    assert get_distribution() == 'Amazon'

    os.environ['ID'] = 'redhat'
    os.environ['VERSION_ID'] = '5'
    os.environ['VERSION'] = '5Server'
    assert get_distribution() == 'Redhat'
    assert get_distribution_version() == '5'

    os.environ['ID'] = 'centos'

# Generated at 2022-06-11 01:38:42.302229
# Unit test for function get_distribution
def test_get_distribution():
    d = get_distribution()
    assert d is not None # We should always get something



# Generated at 2022-06-11 01:38:48.081826
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Foo(object):
        platform = 'Linux'
        distribution = None

        class Redhat(object):
            platform = 'Linux'
            distribution = 'Redhat'

        class OtherLinux(object):
            platform = 'Linux'
            distribution = 'OtherLinux'

        class Windows(object):
            platform = 'Windows'
            distribution = None

    class Bar(Foo):
        class Debian(object):
            platform = 'Linux'
            distribution = 'Debian'

    # Test when no distribution matches
    subclass = get_platform_subclass(Foo)
    assert subclass == Foo

    # The order of these tests should correspond to the order of the loop in get_platform_subclass()
    # Capitalization must be exactly as returned from get_distribution().
    # These tests work because they set platform.system() and get_distribution

# Generated at 2022-06-11 01:38:57.600551
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''

    # A sample class hierarchy to test get_platform_subclass
    class Cls:  # pylint: disable=too-few-public-methods
        platform = None
        distribution = None

        # pylint: disable=unused-argument
        def __init__(self, *args, **kwargs):
            return

    class Subcls1(Cls):  # pylint: disable=too-few-public-methods
        platform = 'Linux'
        distribution = 'Redhat'

    class Subcls2(Cls):  # pylint: disable=too-few-public-methods
        platform = 'Linux'
        distribution = 'Centos'


# Generated at 2022-06-11 01:39:07.987554
# Unit test for function get_platform_subclass
def test_get_platform_subclass():

    class BaseClass():
        platform = 'A'
        distribution = None

    class SubClass1(BaseClass):
        platform = 'B'
        distribution = None

    class SubClass2(BaseClass):
        platform = 'A'
        distribution = 'X'

    class SubClass3(BaseClass):
        platform = 'A'
        distribution = 'Y'

    class SubClass4(BaseClass):
        platform = 'B'
        distribution = 'Y'

    class SubClass5(BaseClass):
        platform = 'B'
        distribution = 'Z'

    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(SubClass1) == SubClass1
    assert get_platform_subclass(SubClass2) == SubClass2

# Generated at 2022-06-11 01:39:19.240866
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

    old_platform_system = platform.system
    old_distro_id = distro.id
    old_os_release_info = distro.os_release_info
    old_lsb_release_info = distro.lsb_release_info
    old_codename = distro.codename


# Generated at 2022-06-11 01:39:19.826915
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    pass

# Generated at 2022-06-11 01:39:31.029800
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class PlatformSubclassTest:
        '''
        Subclass used for testing platform specific subclasses
        '''
        distribution = None  # None means no distribution specified
        platform = 'A'

    class PlatformSubclassTestA1(PlatformSubclassTest):
        '''
        Multiple subclasses can have the same platform value
        '''
        platform = 'A'

    class PlatformSubclassTestA2(PlatformSubclassTest):
        '''
        Multiple subclasses can have the same platform value
        '''
        platform = 'A'

    class PlatformSubclassTestB1(PlatformSubclassTest):
        '''
        Multiple subclasses can have the same platform value
        '''
        platform = 'B'


# Generated at 2022-06-11 01:39:39.653172
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Tests for the get_platform_subclass() function

    `assertEqual` is used to verify the result is as expected.

    :returns: None

    '''
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    # pylint: disable=unused-variable,protected-access
    class PlatformSpecific(object):
        '''
        A class that's used for testing get_platform_subclass()
        '''
        platform = None
        distribution = None
        distribution_version = None
        distribution_release = None
        distribution_codename = None
        distribution_full = None

        def __init__(self):
            pass
