

# Generated at 2022-06-16 22:58:57.162788
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'

# Generated at 2022-06-16 22:59:04.041953
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'
        distribution = None

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        version = '7'

    class BaseLinuxRedhat6(BaseLinuxRedhat):
        version = '6'

    class BaseLinuxRedhat5(BaseLinuxRedhat):
        version = '5'

    class BaseLinuxRedhat4(BaseLinuxRedhat):
        version = '4'

    class BaseLinuxRedhat3(BaseLinuxRedhat):
        version = '3'

    class BaseLinuxRedhat2(BaseLinuxRedhat):
        version = '2'


# Generated at 2022-06-16 22:59:13.919878
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseRedhat6(BaseRedhat):
        version = '6'

    class BaseRedhat7(BaseRedhat):
        version = '7'

    class BaseRedhat8(BaseRedhat):
        version = '8'

    class BaseRedhat9(BaseRedhat):
        version = '9'

    class BaseRedhat10(BaseRedhat):
        version = '10'

    class BaseRedhat11(BaseRedhat):
        version = '11'

    class BaseRedhat12(BaseRedhat):
        version = '12'

    class BaseRedhat13(BaseRedhat):
        version = '13'

   

# Generated at 2022-06-16 22:59:15.315696
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None

# Generated at 2022-06-16 22:59:28.259713
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class BaseClass:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'Base'
        distribution = None

    class LinuxClass(BaseClass):
        '''
        Linux subclass for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = None

    class LinuxDistroClass(LinuxClass):
        '''
        Linux distribution subclass for testing get_platform_subclass
        '''
        distribution = 'LinuxDistro'

    class LinuxDistroVersionClass(LinuxDistroClass):
        '''
        Linux distribution version subclass for testing get_platform_subclass
        '''
        version = 'LinuxDistroVersion'


# Generated at 2022-06-16 22:59:37.723512
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = None
        distribution = None

    class PlatformClass(BaseClass):
        platform = 'Linux'

    class DistributionClass(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class DistributionVersionClass(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '7.0'

    class DistributionCodenameClass(BaseClass):
        platform = 'Linux'
        distribution = 'Ubuntu'
        codename = 'xenial'

    class OtherPlatformClass(BaseClass):
        platform = 'FreeBSD'

    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(PlatformClass) == PlatformClass
    assert get_platform_subclass(DistributionClass) == DistributionClass
    assert get_platform_

# Generated at 2022-06-16 22:59:48.946296
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename() == 'xenial'
    assert get_distribution_codename() == 'bionic'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename

# Generated at 2022-06-16 22:59:51.043872
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 22:59:56.707308
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class SubClass1(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class SubClass3(BaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class SubClass4(BaseClass):
        platform = 'Linux'
        distribution = None

    class SubClass5(BaseClass):
        platform = 'FreeBSD'
        distribution = None

    class SubClass6(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass7(SubClass6):
        distribution = 'Debian'

    class SubClass8(SubClass6):
        distribution = 'OtherLinux'


# Generated at 2022-06-16 22:59:58.234677
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:00:09.053309
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:00:11.330893
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:00:12.841660
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:00:14.356872
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:00:25.254581
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    import platform
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_platform_subclass

    class TestModule(AnsibleModule):
        pass

    class TestModuleLinux(TestModule):
        platform = 'Linux'
        distribution = None

    class TestModuleLinuxRedhat(TestModule):
        platform = 'Linux'
        distribution = 'Redhat'

    class TestModuleLinuxRedhat6(TestModule):
        platform = 'Linux'
        distribution = 'Redhat'
        distribution_version = '6'

    class TestModuleLinuxRedhat7(TestModule):
        platform = 'Linux'
        distribution = 'Redhat'
        distribution_version = '7'

    class TestModuleLinuxRedhat8(TestModule):
        platform = 'Linux'

# Generated at 2022-06-16 23:00:36.737501
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseRedHat(BaseLinux):
        distribution = 'RedHat'

    class BaseRedHat6(BaseRedHat):
        distribution_version = '6'

    class BaseRedHat7(BaseRedHat):
        distribution_version = '7'

    class BaseDebian(BaseLinux):
        distribution = 'Debian'

    class BaseDebian8(BaseDebian):
        distribution_version = '8'

    class BaseDebian9(BaseDebian):
        distribution_version = '9'

    class BaseDarwin(Base):
        platform = 'Darwin'
        distribution = None

    class BaseDarwin10(BaseDarwin):
        distribution_version = '10'


# Generated at 2022-06-16 23:00:38.165122
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:00:40.827159
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the function get_distribution_codename
    '''
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:00:47.806627
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class Base:
        platform = 'Base'
        distribution = None

    class LinuxBase(Base):
        platform = 'Linux'
        distribution = None

    class LinuxDistroBase(LinuxBase):
        distribution = 'LinuxDistro'

    class LinuxDistroVersionBase(LinuxDistroBase):
        version = 'LinuxDistroVersion'

    class LinuxDistroVersionCodenameBase(LinuxDistroVersionBase):
        codename = 'LinuxDistroVersionCodename'

    class LinuxDistroVersionCodenameDerived(LinuxDistroVersionCodenameBase):
        pass

    class LinuxDistroVersionDerived(LinuxDistroVersionBase):
        pass

    class LinuxDistroDerived(LinuxDistroBase):
        pass


# Generated at 2022-06-16 23:00:59.032643
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxDistro(Base):
        platform = 'Linux'
        distribution = 'Distro'

    class BaseLinuxDistroVersion(Base):
        platform = 'Linux'
        distribution = 'Distro'
        version = 'Version'

    class BaseLinuxDistroVersionCodename(Base):
        platform = 'Linux'
        distribution = 'Distro'
        version = 'Version'
        codename = 'Codename'

    class BaseLinuxDistroVersionCodenameArch(Base):
        platform = 'Linux'
        distribution = 'Distro'
        version = 'Version'
        codename = 'Codename'
        architecture = 'Arch'

    class BaseLinuxDistroVersionCodenameArch2(Base):
        platform

# Generated at 2022-06-16 23:01:26.315875
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = None
        distribution = None

    class Linux(Base):
        platform = 'Linux'
        distribution = None

    class LinuxDistro(Base):
        platform = 'Linux'
        distribution = 'LinuxDistro'

    class LinuxDistroVersion(Base):
        platform = 'Linux'
        distribution = 'LinuxDistro'
        version = '1.0'

    class LinuxDistroVersion2(Base):
        platform = 'Linux'
        distribution = 'LinuxDistro'
        version = '2.0'

    class LinuxDistroVersion3(Base):
        platform = 'Linux'
        distribution = 'LinuxDistro'
        version = '3.0'

    class LinuxDistroVersion4(Base):
        platform = 'Linux'
        distribution = 'LinuxDistro'

# Generated at 2022-06-16 23:01:27.439616
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7'

# Generated at 2022-06-16 23:01:29.082745
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:01:38.345611
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = 'BasePlatform'
        distribution = None

    class LinuxClass(BaseClass):
        platform = 'Linux'
        distribution = None

    class LinuxDistroClass(LinuxClass):
        distribution = 'LinuxDistro'

    class OtherLinuxClass(LinuxClass):
        distribution = 'OtherLinux'

    class OtherPlatformClass(BaseClass):
        platform = 'OtherPlatform'
        distribution = None

    class OtherPlatformDistroClass(OtherPlatformClass):
        distribution = 'OtherPlatformDistro'

    class OtherPlatformOtherDistroClass(OtherPlatformClass):
        distribution = 'OtherPlatformOtherDistro'

    class OtherPlatformOtherDistroVersionClass(OtherPlatformOtherDistroClass):
        version = 'OtherPlatformOtherDistroVersion'

    # Test that we get the most specific subclass

# Generated at 2022-06-16 23:01:40.258342
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:01:51.653620
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = 'BasePlatform'
        distribution = None

    class BasePlatform(BaseClass):
        pass

    class LinuxBase(BaseClass):
        platform = 'Linux'

    class Linux(LinuxBase):
        pass

    class LinuxDistro(LinuxBase):
        distribution = 'LinuxDistro'

    class LinuxDistroPlatform(LinuxDistro):
        platform = 'LinuxDistroPlatform'

    class LinuxDistroPlatformSubclass(LinuxDistroPlatform):
        pass

    class LinuxDistroPlatformSubclass2(LinuxDistroPlatform):
        pass

    class LinuxDistroPlatformSubclass3(LinuxDistroPlatform):
        pass

    class LinuxDistroPlatformSubclass4(LinuxDistroPlatform):
        pass

    class LinuxDistroPlatformSubclass5(LinuxDistroPlatform):
        pass


# Generated at 2022-06-16 23:01:53.745076
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    assert get_distribution_version() == distro.version()

# Generated at 2022-06-16 23:01:55.009835
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-16 23:02:05.434295
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the get_distribution_version function
    '''
    # Test for Ubuntu
    distro.id = lambda: 'ubuntu'
    distro.version = lambda: '18.04'
    distro.version.__name__ = 'version'
    distro.version.__doc__ = 'Returns the version of the distribution'
    distro.version.__module__ = 'distro'
    distro.version.__defaults__ = None
    distro.version.__code__ = None
    distro.version.__globals__ = None
    distro.version.__dict__ = None
    distro.version.__closure__ = None
    distro.version.__annotations__ = None
    distro.version.__kwdefaults__ = None

# Generated at 2022-06-16 23:02:07.010388
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:02:49.063896
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:03:01.264293
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class SubClass1(BaseClass):
        platform = 'Linux'
        distribution = 'RedHat'

    class SubClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class SubClass3(BaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class SubClass4(BaseClass):
        platform = 'Linux'
        distribution = None

    class SubClass5(BaseClass):
        platform = 'FreeBSD'
        distribution = None

    class SubClass6(BaseClass):
        platform = 'Linux'
        distribution = 'RedHat'

    class SubClass7(BaseClass):
        platform = 'Linux'
        distribution = 'RedHat'

    class SubClass8(BaseClass):
        platform = 'Linux'

# Generated at 2022-06-16 23:03:10.110500
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    # pylint: disable=too-few-public-methods
    class BaseClass:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = None
        distribution = None

    class LinuxClass(BaseClass):
        '''
        Linux class for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = None

    class LinuxRedhatClass(LinuxClass):
        '''
        Linux Redhat class for testing get_platform_subclass
        '''
        distribution = 'Redhat'

    class LinuxRedhat6Class(LinuxRedhatClass):
        '''
        Linux Redhat 6 class for testing get_platform_subclass
        '''

# Generated at 2022-06-16 23:03:15.998968
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test for Ubuntu
    assert get_distribution_codename() == 'xenial'
    # Test for Debian
    assert get_distribution_codename() == 'stretch'
    # Test for Fedora
    assert get_distribution_codename() == 'Twenty Eight'
    # Test for CentOS
    assert get_distribution_codename() == 'Core'
    # Test for Amazon Linux
    assert get_distribution_codename() == '2018.03'

# Generated at 2022-06-16 23:03:16.954547
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:03:18.113837
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:03:19.249635
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:03:20.475549
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7'

# Generated at 2022-06-16 23:03:32.884459
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = 'Linux'
        distribution = None

    class LinuxClass(BaseClass):
        platform = 'Linux'
        distribution = None

    class OtherLinuxClass(BaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class LinuxRedhatClass(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class LinuxAmazonClass(BaseClass):
        platform = 'Linux'
        distribution = 'Amazon'

    class LinuxDebianClass(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class LinuxCentosClass(BaseClass):
        platform = 'Linux'
        distribution = 'Centos'

    class LinuxUbuntuClass(BaseClass):
        platform = 'Linux'
        distribution = 'Ubuntu'


# Generated at 2022-06-16 23:03:34.355815
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:04:16.021606
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:04:27.094445
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxDistro(BaseLinux):
        distribution = 'Distro'

    class BaseLinuxOther(BaseLinux):
        distribution = 'Other'

    class BaseOther(Base):
        platform = 'Other'
        distribution = None

    class BaseOtherDistro(BaseOther):
        distribution = 'Distro'

    class BaseOtherOther(BaseOther):
        distribution = 'Other'

    class BaseLinuxDistroDistro(BaseLinuxDistro):
        distribution = 'Distro'

    class BaseLinuxDistroOther(BaseLinuxDistro):
        distribution = 'Other'

    class BaseLinuxOtherDistro(BaseLinuxOther):
        distribution = 'Distro'

    class BaseLinuxOtherOther(BaseLinuxOther):
        distribution

# Generated at 2022-06-16 23:04:29.023681
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:04:34.922222
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None
    assert get_distribution_codename() == 'xenial'
    assert get_distribution_codename() == 'bionic'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename() == 'focal'
    assert get_distribution_codename

# Generated at 2022-06-16 23:04:36.570037
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:04:48.505938
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class BaseClass:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'BasePlatform'
        distribution = None

    class BasePlatformSubClass(BaseClass):
        '''
        Subclass of BaseClass for testing get_platform_subclass
        '''
        platform = 'BasePlatform'
        distribution = None

    class BasePlatformDistroSubClass(BaseClass):
        '''
        Subclass of BaseClass for testing get_platform_subclass
        '''
        platform = 'BasePlatform'
        distribution = 'BaseDistro'

    class OtherPlatformSubClass(BaseClass):
        '''
        Subclass of BaseClass for testing get_platform_subclass
        '''

# Generated at 2022-06-16 23:04:49.619067
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:04:50.311085
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-16 23:05:00.771341
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxRedHat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedHat7(BaseLinuxRedHat):
        distribution_version = '7'

    class BaseLinuxRedHat8(BaseLinuxRedHat):
        distribution_version = '8'

    class BaseLinuxRedHat8_1(BaseLinuxRedHat):
        distribution_version = '8.1'

    class BaseLinuxRedHat8_2(BaseLinuxRedHat):
        distribution_version = '8.2'

    class BaseLinuxRedHat8_3(BaseLinuxRedHat):
        distribution_version = '8.3'


# Generated at 2022-06-16 23:05:02.697715
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:06:24.971629
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the function get_distribution_codename
    '''
    assert get_distribution_codename() is None

# Generated at 2022-06-16 23:06:33.431781
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = 'BasePlatform'
        distribution = None

    class BasePlatformClass(BaseClass):
        platform = 'BasePlatform'
        distribution = None

    class BasePlatformDistroClass(BaseClass):
        platform = 'BasePlatform'
        distribution = 'BaseDistro'

    class OtherPlatformClass(BaseClass):
        platform = 'OtherPlatform'
        distribution = None

    class OtherPlatformDistroClass(BaseClass):
        platform = 'OtherPlatform'
        distribution = 'OtherDistro'

    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(BasePlatformClass) == BasePlatformClass
    assert get_platform_subclass(BasePlatformDistroClass) == BasePlatformDistroClass
    assert get_platform_subclass(OtherPlatformClass) == OtherPlatformClass

# Generated at 2022-06-16 23:06:34.589236
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() is not None

# Generated at 2022-06-16 23:06:36.495141
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:06:38.100315
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:06:50.069231
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'
        distribution = None

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxRedHat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedHat7(BaseLinuxRedHat):
        version = '7'

    class BaseLinuxRedHat6(BaseLinuxRedHat):
        version = '6'

    class BaseLinuxDebian(BaseLinux):
        distribution = 'Debian'

    class BaseLinuxDebian9(BaseLinuxDebian):
        version = '9'

    class BaseLinuxDebian8(BaseLinuxDebian):
        version = '8'

    class BaseLinuxDebian7(BaseLinuxDebian):
        version = '7'


# Generated at 2022-06-16 23:06:57.749804
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class Base(object):
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'Base'
        distribution = None

    class BaseLinux(Base):
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = None

    class BaseLinuxDistro(BaseLinux):
        '''
        Base class for testing get_platform_subclass
        '''
        distribution = 'BaseLinuxDistro'

    class BaseLinuxDistroVersion(BaseLinuxDistro):
        '''
        Base class for testing get_platform_subclass
        '''
        version = 'BaseLinuxDistroVersion'


# Generated at 2022-06-16 23:06:59.993578
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:07:10.428274
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'
        distribution = None

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseRedhat(Base):
        platform = 'Linux'
        distribution = 'Redhat'

    class BaseRedhat6(Base):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '6'

    class BaseRedhat7(Base):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '7'

    class BaseRedhat8(Base):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '8'

    class BaseRedhat9(Base):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '9'


# Generated at 2022-06-16 23:07:18.858251
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class Base(object):
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'Base'
        distribution = None

    class Linux(Base):
        '''
        Linux class for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = None

    class LinuxDistro(Linux):
        '''
        LinuxDistro class for testing get_platform_subclass
        '''
        distribution = 'LinuxDistro'

    class LinuxOtherDistro(Linux):
        '''
        LinuxOtherDistro class for testing get_platform_subclass
        '''
        distribution = 'LinuxOtherDistro'
