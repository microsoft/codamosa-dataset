

# Generated at 2022-06-16 22:58:59.159074
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test get_distribution function
    '''
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 22:59:01.576791
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 22:59:06.799523
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test for Ubuntu
    codename = get_distribution_codename()
    assert codename == 'bionic'

    # Test for Debian
    codename = get_distribution_codename()
    assert codename == 'stretch'

    # Test for Fedora
    codename = get_distribution_codename()
    assert codename == '28'

    # Test for CentOS
    codename = get_distribution_codename()
    assert codename == 'Core'

    # Test for Amazon
    codename = get_distribution_codename()
    assert codename == '2'

# Generated at 2022-06-16 22:59:08.920472
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    assert get_distribution() == 'Linux'


# Generated at 2022-06-16 22:59:19.583417
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    import unittest

    class BaseClass:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = None
        distribution = None

    class LinuxClass(BaseClass):
        '''
        Linux class for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = None

    class LinuxDistroClass(LinuxClass):
        '''
        Linux class for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = 'LinuxDistro'

    class LinuxDistroVersionClass(LinuxDistroClass):
        '''
        Linux class for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = 'LinuxDistro'

# Generated at 2022-06-16 22:59:31.247561
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Create a base class
    class BaseClass:
        platform = None
        distribution = None

    # Create a subclass for a specific platform
    class SubClass1(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    # Create a subclass for a specific platform
    class SubClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    # Create a subclass for a specific platform
    class SubClass3(BaseClass):
        platform = 'Linux'
        distribution = 'Amazon'

    # Create a subclass for a specific platform
    class SubClass4(BaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    # Create a subclass for a specific platform
    class SubClass5(BaseClass):
        platform = 'Linux'
        distribution = 'Ubuntu'

    #

# Generated at 2022-06-16 22:59:33.042749
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 22:59:36.641096
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    distribution = get_distribution()
    assert distribution is not None
    assert isinstance(distribution, str)


# Generated at 2022-06-16 22:59:38.331610
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 22:59:40.292929
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 22:59:51.443673
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'


# Generated at 2022-06-16 23:00:02.692861
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseRedHat(BaseLinux):
        distribution = 'RedHat'

    class BaseRedHat6(BaseRedHat):
        distribution_version = '6'

    class BaseRedHat7(BaseRedHat):
        distribution_version = '7'

    class BaseRedHat8(BaseRedHat):
        distribution_version = '8'

    class BaseRedHat9(BaseRedHat):
        distribution_version = '9'

    class BaseRedHat10(BaseRedHat):
        distribution_version = '10'

    class BaseRedHat11(BaseRedHat):
        distribution_version = '11'

    class BaseRedHat12(BaseRedHat):
        distribution_version = '12'


# Generated at 2022-06-16 23:00:10.359529
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class BaseClass:
        pass

    class LinuxClass(BaseClass):
        platform = 'Linux'
        distribution = None

    class OtherLinuxClass(BaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class LinuxRedhatClass(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class LinuxRedhat7Class(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '7'

    class LinuxRedhat6Class(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '6'

    class LinuxRedhat5Class(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

# Generated at 2022-06-16 23:00:11.138833
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:00:22.354811
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class SubClass1(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Amazon'

    class SubClass3(BaseClass):
        platform = 'Linux'
        distribution = None

    class SubClass4(BaseClass):
        platform = 'FreeBSD'
        distribution = None

    class SubClass5(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass6(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass7(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass8(BaseClass):
        platform = 'Linux'

# Generated at 2022-06-16 23:00:33.016063
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        platform = 'Linux'
        distribution = None

    class B(A):
        platform = 'Linux'
        distribution = 'RedHat'

    class C(B):
        platform = 'Linux'
        distribution = 'RedHat'

    class D(A):
        platform = 'Linux'
        distribution = 'Debian'

    class E(A):
        platform = 'FreeBSD'
        distribution = None

    class F(E):
        platform = 'FreeBSD'
        distribution = 'FreeBSD'

    class G(A):
        platform = 'Linux'
        distribution = 'RedHat'

    class H(G):
        platform = 'Linux'
        distribution = 'RedHat'

    class I(H):
        platform = 'Linux'
        distribution = 'RedHat'


# Generated at 2022-06-16 23:00:44.047283
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedhat6(BaseLinuxRedhat):
        distribution_version = '6'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        distribution_version = '7'

    class BaseLinuxRedhat8(BaseLinuxRedhat):
        distribution_version = '8'

    class BaseLinuxRedhat9(BaseLinuxRedhat):
        distribution_version = '9'

    class BaseLinuxRedhat10(BaseLinuxRedhat):
        distribution_version = '10'

    class BaseLinuxRedhat11(BaseLinuxRedhat):
        distribution_version = '11'


# Generated at 2022-06-16 23:00:47.092472
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the function get_distribution_codename
    '''
    codename = get_distribution_codename()
    assert codename is not None

# Generated at 2022-06-16 23:00:48.301468
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'


# Generated at 2022-06-16 23:00:50.419555
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-16 23:01:20.443713
# Unit test for function get_distribution_version
def test_get_distribution_version():
    import platform
    import distro
    import sys
    import os

    # Test for Ubuntu
    distro.id = lambda: 'ubuntu'
    distro.version = lambda: '16.04'
    distro.version.__name__ = 'version'
    distro.version.__module__ = 'distro'
    distro.version.__globals__ = sys.modules['distro']
    distro.version.__defaults__ = None
    distro.version.__kwdefaults__ = None
    distro.version.__closure__ = None
    distro.version.__code__ = distro.version.__code__.replace(co_name='version')
    distro.version.__dict__ = {}
    distro.version.func_closure = lambda: None
    distro.version.func_

# Generated at 2022-06-16 23:01:32.725371
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseRedHat(BaseLinux):
        distribution = 'RedHat'

    class BaseRedHat6(BaseRedHat):
        distribution_version = '6'

    class BaseRedHat7(BaseRedHat):
        distribution_version = '7'

    class BaseRedHat8(BaseRedHat):
        distribution_version = '8'

    class BaseRedHat9(BaseRedHat):
        distribution_version = '9'

    class BaseRedHat10(BaseRedHat):
        distribution_version = '10'

    class BaseRedHat11(BaseRedHat):
        distribution_version = '11'

    class BaseRedHat12(BaseRedHat):
        distribution_version = '12'


# Generated at 2022-06-16 23:01:33.757936
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:01:44.230054
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class SubClass1(BaseClass):
        platform = 'Linux'
        distribution = None

    class SubClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass3(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass4(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass5(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass6(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass7(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass8(BaseClass):
        platform = 'Linux'
       

# Generated at 2022-06-16 23:01:55.042346
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version
    '''
    # Test for Redhat
    distro.id = lambda: 'rhel'
    distro.version = lambda: '7.5'
    distro.version.__name__ = 'version'
    distro.version.__module__ = 'distro'
    distro.version.__globals__ = globals()
    distro.version.__closure__ = None
    distro.version.__code__ = distro.version.__code__
    distro.version.__defaults__ = None
    distro.version.__kwdefaults__ = None
    distro.version.__annotations__ = {}
    distro.version.__dict__ = {}
    distro.version.__self__ = None
    distro.version.__

# Generated at 2022-06-16 23:02:03.107263
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A:
        platform = 'Linux'
        distribution = None

    class B(A):
        distribution = 'Redhat'

    class C(A):
        distribution = 'Redhat'

    class D(A):
        distribution = 'Redhat'

    class E(A):
        distribution = 'Redhat'

    class F(A):
        distribution = 'Redhat'

    class G(A):
        distribution = 'Redhat'

    class H(A):
        distribution = 'Redhat'

    class I(A):
        distribution = 'Redhat'

    class J(A):
        distribution = 'Redhat'

    class K(A):
        distribution = 'Redhat'

    class L(A):
        distribution = 'Redhat'

    class M(A):
        distribution = 'Redhat'


# Generated at 2022-06-16 23:02:15.081412
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    # Test on Linux
    assert get_distribution() == 'Linux'

    # Test on FreeBSD
    assert get_distribution() == 'Freebsd'

    # Test on OpenBSD
    assert get_distribution() == 'Openbsd'

    # Test on NetBSD
    assert get_distribution() == 'Netbsd'

    # Test on SunOS
    assert get_distribution() == 'Sunos'

    # Test on AIX
    assert get_distribution() == 'Aix'

    # Test on HP-UX
    assert get_distribution() == 'Hpux'

    # Test on Darwin
    assert get_distribution() == 'Darwin'

    # Test on Windows
    assert get_distribution() == 'Windows'

# Generated at 2022-06-16 23:02:27.270050
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # pylint: disable=unused-variable
    class Base:
        platform = 'Base'
        distribution = None

    class LinuxBase(Base):
        platform = 'Linux'
        distribution = None

    class LinuxDistroBase(LinuxBase):
        distribution = 'LinuxDistro'

    class LinuxDistroVersionBase(LinuxDistroBase):
        version = 'LinuxDistroVersion'

    class OtherLinux(LinuxBase):
        distribution = 'OtherLinux'

    class OtherLinuxVersion(OtherLinux):
        version = 'OtherLinuxVersion'

    class LinuxDistro(LinuxBase):
        distribution = 'LinuxDistro'

    class LinuxDistroVersion(LinuxDistro):
        version = 'LinuxDistroVersion'

    class LinuxDistroVersionCodename(LinuxDistroVersion):
        codename = 'LinuxDistroVersionCodename'



# Generated at 2022-06-16 23:02:28.788155
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'


# Generated at 2022-06-16 23:02:40.484053
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = None
        distribution = None

    class LinuxBase(Base):
        platform = 'Linux'
        distribution = None

    class LinuxDistBase(LinuxBase):
        distribution = None

    class LinuxDistSub(LinuxDistBase):
        distribution = None

    class LinuxDistSubSub(LinuxDistSub):
        distribution = None

    class LinuxDistSubSubSub(LinuxDistSubSub):
        distribution = None

    class LinuxDistSubSubSubSub(LinuxDistSubSubSub):
        distribution = None

    class LinuxDistSubSubSubSubSub(LinuxDistSubSubSubSub):
        distribution = None

    class LinuxDistSubSubSubSubSubSub(LinuxDistSubSubSubSubSub):
        distribution = None

    class LinuxDistSubSubSubSubSubSubSub(LinuxDistSubSubSubSubSubSub):
        distribution = None

   

# Generated at 2022-06-16 23:03:24.200952
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:03:36.182787
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base(object):
        pass

    class LinuxBase(Base):
        platform = 'Linux'
        distribution = None

    class LinuxRedhat(LinuxBase):
        distribution = 'Redhat'

    class LinuxRedhat7(LinuxRedhat):
        distribution_version = '7'

    class LinuxRedhat6(LinuxRedhat):
        distribution_version = '6'

    class LinuxAmazon(LinuxBase):
        distribution = 'Amazon'

    class LinuxAmazon2(LinuxAmazon):
        distribution_version = '2'

    class LinuxAmazon1(LinuxAmazon):
        distribution_version = '1'

    class LinuxDebian(LinuxBase):
        distribution = 'Debian'

    class LinuxDebian9(LinuxDebian):
        distribution_version = '9'

    class LinuxDebian8(LinuxDebian):
        distribution_version

# Generated at 2022-06-16 23:03:47.535874
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    # Test for RedHat
    distro.id = lambda: 'rhel'
    distro.version = lambda: '7.5'
    distro.version.__name__ = 'version'
    distro.version.__globals__ = globals()
    distro.version.__module__ = 'distro'
    distro.version.__defaults__ = None
    distro.version.__code__ = distro.version.__code__
    distro.version.__closure__ = None
    distro.version.__kwdefaults__ = None
    distro.version.__annotations__ = {}
    distro.version.__dict__ = distro.version.__dict__

# Generated at 2022-06-16 23:03:49.361713
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:03:50.929702
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:03:52.439303
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:04:01.001880
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the get_platform_subclass function
    '''
    class Base:
        platform = 'Base'
        distribution = None

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        distribution_version = '7'

    class BaseLinuxRedhat8(BaseLinuxRedhat):
        distribution_version = '8'

    class BaseLinuxRedhat9(BaseLinuxRedhat):
        distribution_version = '9'

    class BaseLinuxRedhat10(BaseLinuxRedhat):
        distribution_version = '10'

    class BaseLinuxRedhat11(BaseLinuxRedhat):
        distribution_version = '11'


# Generated at 2022-06-16 23:04:12.902921
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxAmazon(BaseLinux):
        distribution = 'Amazon'

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxOther(BaseLinux):
        distribution = 'OtherLinux'

    class BaseLinuxDebian(BaseLinux):
        distribution = 'Debian'

    class BaseLinuxUbuntu(BaseLinux):
        distribution = 'Ubuntu'

    class BaseLinuxCentos(BaseLinux):
        distribution = 'Centos'

    class BaseLinuxFedora(BaseLinux):
        distribution = 'Fedora'

    class BaseLinuxSuse(BaseLinux):
        distribution = 'Suse'

    class BaseLinuxMint(BaseLinux):
        distribution = 'Mint'


# Generated at 2022-06-16 23:04:20.705772
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the get_distribution_codename function
    '''
    # Test Ubuntu
    codename = get_distribution_codename()
    assert codename == 'bionic'

    # Test Debian
    codename = get_distribution_codename()
    assert codename == 'buster'

    # Test Fedora
    codename = get_distribution_codename()
    assert codename == '29'

    # Test CentOS
    codename = get_distribution_codename()
    assert codename is None

# Generated at 2022-06-16 23:04:26.526793
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the get_distribution_codename function
    '''
    # Test for Ubuntu
    assert get_distribution_codename() == 'xenial'
    # Test for Fedora
    assert get_distribution_codename() == '28'
    # Test for CentOS
    assert get_distribution_codename() == 'Core'
    # Test for Debian
    assert get_distribution_codename() == 'stretch'

# Generated at 2022-06-16 23:05:59.741952
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = 'Linux'
        distribution = None

    class LinuxSubclass(BaseClass):
        distribution = 'Redhat'

    class OtherLinuxSubclass(BaseClass):
        distribution = 'OtherLinux'

    class OtherSubclass(BaseClass):
        platform = 'Other'

    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(LinuxSubclass) == LinuxSubclass
    assert get_platform_subclass(OtherLinuxSubclass) == OtherLinuxSubclass
    assert get_platform_subclass(OtherSubclass) == OtherSubclass

# Generated at 2022-06-16 23:06:11.319986
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the get_distribution_codename function
    '''
    # Test for Fedora
    distro.id = lambda: 'fedora'
    distro.os_release_info = lambda: {'version_codename': 'Spherical Cow'}
    assert get_distribution_codename() == 'Spherical Cow'

    # Test for Ubuntu
    distro.id = lambda: 'ubuntu'
    distro.os_release_info = lambda: {'ubuntu_codename': 'Xenial Xerus'}
    assert get_distribution_codename() == 'Xenial Xerus'

    # Test for Debian
    distro.id = lambda: 'debian'
    distro.os_release_info = lambda: {'version_codename': 'Buster'}
    assert get_distribution_codename

# Generated at 2022-06-16 23:06:24.167159
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedhat6(BaseLinuxRedhat):
        version = '6'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        version = '7'

    class BaseLinuxRedhat8(BaseLinuxRedhat):
        version = '8'

    class BaseLinuxOther(BaseLinux):
        distribution = 'OtherLinux'

    class BaseLinuxOther2(BaseLinux):
        distribution = 'OtherLinux2'

    class BaseLinuxOther3(BaseLinux):
        distribution = 'OtherLinux3'

    class BaseLinuxOther4(BaseLinux):
        distribution = 'OtherLinux4'


# Generated at 2022-06-16 23:06:26.283141
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Unit test for function get_distribution_codename
    '''
    # Test for Ubuntu
    codename = get_distribution_codename()
    if codename is None:
        assert False, "get_distribution_codename() returned None"
    else:
        assert codename == "xenial", "get_distribution_codename() returned %s instead of xenial" % codename

# Generated at 2022-06-16 23:06:34.289121
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base(object):
        platform = 'Base'
        distribution = None

    class Linux(Base):
        platform = 'Linux'
        distribution = None

    class LinuxDistro(Linux):
        distribution = 'LinuxDistro'

    class LinuxDistroVersion(LinuxDistro):
        version = 'LinuxDistroVersion'

    class LinuxOtherDistro(Linux):
        distribution = 'LinuxOtherDistro'

    class LinuxOtherDistroVersion(LinuxOtherDistro):
        version = 'LinuxOtherDistroVersion'

    class OtherPlatform(Base):
        platform = 'OtherPlatform'
        distribution = None

    class OtherPlatformDistro(OtherPlatform):
        distribution = 'OtherPlatformDistro'

    class OtherPlatformDistroVersion(OtherPlatformDistro):
        version = 'OtherPlatformDistroVersion'


# Generated at 2022-06-16 23:06:46.922382
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxDebian(BaseLinux):
        distribution = 'Debian'

    class BaseLinuxDebianUbuntu(BaseLinuxDebian):
        distribution = 'Ubuntu'

    class BaseLinuxDebianUbuntuXenial(BaseLinuxDebianUbuntu):
        distribution = 'Xenial'

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedhatCentos(BaseLinuxRedhat):
        distribution = 'Centos'

    class BaseLinuxRedhatCentos7(BaseLinuxRedhatCentos):
        distribution = 'Centos7'

    class BaseLinuxRedhatCentos8(BaseLinuxRedhatCentos):
        distribution = 'Centos8'


# Generated at 2022-06-16 23:06:55.740301
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'
        distribution = None

    class LinuxBase(Base):
        platform = 'Linux'
        distribution = None

    class LinuxDistroBase(LinuxBase):
        distribution = 'LinuxDistro'

    class LinuxDistroVersionBase(LinuxDistroBase):
        version = 'LinuxDistroVersion'

    class LinuxDistroVersionCodenameBase(LinuxDistroVersionBase):
        codename = 'LinuxDistroVersionCodename'

    class LinuxDistroVersionCodenameDerived(LinuxDistroVersionCodenameBase):
        pass

    class LinuxDistroVersionDerived(LinuxDistroVersionBase):
        pass

    class LinuxDistroDerived(LinuxDistroBase):
        pass

    class LinuxDerived(LinuxBase):
        pass

    class OtherBase(Base):
        platform = 'Other'
       

# Generated at 2022-06-16 23:06:57.411561
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:07:07.898188
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = None
        distribution = None

    class SubClass1(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class SubClass3(BaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class SubClass4(BaseClass):
        platform = 'Linux'
        distribution = None

    class SubClass5(BaseClass):
        platform = 'FreeBSD'
        distribution = None

    class SubClass6(BaseClass):
        platform = 'OpenBSD'
        distribution = None

    class SubClass7(BaseClass):
        platform = 'NetBSD'
        distribution = None

    class SubClass8(BaseClass):
        platform = 'SunOS'

# Generated at 2022-06-16 23:07:17.299762
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class BaseClass:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'Base'
        distribution = None

    class BasePlatform(BaseClass):
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'Base'

    class LinuxPlatform(BaseClass):
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'Linux'

    class LinuxDistro(LinuxPlatform):
        '''
        Base class for testing get_platform_subclass
        '''
        distribution = 'LinuxDistro'
