

# Generated at 2022-06-16 22:58:58.029990
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the function get_distribution_codename
    '''
    codename = get_distribution_codename()
    assert codename is not None

# Generated at 2022-06-16 22:58:59.666762
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Unit test for function get_distribution
    '''
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 22:59:01.632041
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 22:59:08.507345
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'
        distribution = None

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        version = '7'

    class BaseLinuxRedhat8(BaseLinuxRedhat):
        version = '8'

    class BaseLinuxRedhat9(BaseLinuxRedhat):
        version = '9'

    class BaseLinuxRedhat10(BaseLinuxRedhat):
        version = '10'

    class BaseLinuxRedhat11(BaseLinuxRedhat):
        version = '11'

    class BaseLinuxRedhat12(BaseLinuxRedhat):
        version = '12'


# Generated at 2022-06-16 22:59:10.522060
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the function get_distribution_version
    '''
    assert get_distribution_version() == '7'

# Generated at 2022-06-16 22:59:13.043283
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '18.04'

# Generated at 2022-06-16 22:59:14.907999
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename
    '''
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 22:59:27.661708
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxOther(BaseLinux):
        distribution = 'OtherLinux'

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedhat6(BaseLinuxRedhat):
        version = '6'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        version = '7'

    class BaseLinuxRedhat7_1(BaseLinuxRedhat7):
        version = '7.1'

    class BaseLinuxRedhat7_2(BaseLinuxRedhat7):
        version = '7.2'

    class BaseLinuxRedhat7_3(BaseLinuxRedhat7):
        version = '7.3'


# Generated at 2022-06-16 22:59:29.216889
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 22:59:30.488445
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 22:59:43.654484
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 22:59:45.941914
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 22:59:57.979168
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class PlatformA(BaseClass):
        platform = 'A'

    class PlatformB(BaseClass):
        platform = 'B'

    class PlatformA_Distro1(PlatformA):
        distribution = 'Distro1'

    class PlatformA_Distro2(PlatformA):
        distribution = 'Distro2'

    class PlatformB_Distro1(PlatformB):
        distribution = 'Distro1'

    class PlatformB_Distro2(PlatformB):
        distribution = 'Distro2'

    class PlatformB_Distro3(PlatformB):
        distribution = 'Distro3'

    class PlatformB_Distro4(PlatformB):
        distribution = 'Distro4'

    class PlatformB_Distro5(PlatformB):
        distribution = 'Distro5'


# Generated at 2022-06-16 23:00:06.878262
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    # Test for Linux
    assert get_distribution() == 'OtherLinux'
    # Test for Windows
    assert get_distribution() == 'Windows'
    # Test for MacOS
    assert get_distribution() == 'Darwin'
    # Test for FreeBSD
    assert get_distribution() == 'Freebsd'
    # Test for OpenBSD
    assert get_distribution() == 'Openbsd'
    # Test for NetBSD
    assert get_distribution() == 'Netbsd'
    # Test for SunOS
    assert get_distribution() == 'Sunos'
    # Test for AIX
    assert get_distribution() == 'Aix'
    # Test for HP-UX
    assert get_distribution() == 'Hp-ux'


# Generated at 2022-06-16 23:00:09.092406
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the function get_distribution_codename
    '''
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:00:20.962121
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version
    '''
    # Test for Redhat
    distro.id = lambda: 'rhel'
    distro.version = lambda: '7.5'
    distro.version.__name__ = 'version'
    distro.version.__doc__ = 'version'
    distro.version.__module__ = 'distro'
    distro.version.__defaults__ = None
    distro.version.__code__ = None
    distro.version.__globals__ = None
    distro.version.__dict__ = None
    distro.version.__closure__ = None
    distro.version.__annotations__ = None
    distro.version.__kwdefaults__ = None
    distro.version.__self__ = None
    dist

# Generated at 2022-06-16 23:00:21.988489
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:00:23.992055
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    assert get_distribution() == 'Redhat'

# Generated at 2022-06-16 23:00:24.925507
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-16 23:00:27.167515
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the function get_distribution_codename
    '''
    codename = get_distribution_codename()
    assert codename is not None

# Generated at 2022-06-16 23:00:58.950009
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the function get_distribution_codename
    '''
    # Test for Ubuntu
    codename = get_distribution_codename()
    assert codename == 'bionic'

    # Test for Debian
    codename = get_distribution_codename()
    assert codename == 'stretch'

    # Test for Fedora
    codename = get_distribution_codename()
    assert codename == '28'

    # Test for CentOS
    codename = get_distribution_codename()
    assert codename == 'Core'

    # Test for Amazon
    codename = get_distribution_codename()
    assert codename == '2'

# Generated at 2022-06-16 23:01:01.426277
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:01:04.052378
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test function get_distribution
    '''
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:01:14.738731
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename
    '''
    # Test for Ubuntu
    codename = get_distribution_codename()
    assert codename == 'xenial'

    # Test for Debian
    codename = get_distribution_codename()
    assert codename == 'stretch'

    # Test for Fedora
    codename = get_distribution_codename()
    assert codename == '28'

    # Test for CentOS
    codename = get_distribution_codename()
    assert codename == 'Core'

    # Test for Amazon Linux
    codename = get_distribution_codename()
    assert codename == '2'

    # Test for Red Hat Enterprise Linux
    codename = get_distribution_codename()
    assert codename == '7.5'

    # Test

# Generated at 2022-06-16 23:01:23.708974
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseRedHat(BaseLinux):
        distribution = 'RedHat'

    class BaseRedHat6(BaseRedHat):
        version = '6'

    class BaseRedHat7(BaseRedHat):
        version = '7'

    class BaseRedHat8(BaseRedHat):
        version = '8'

    class BaseRedHat8_1(BaseRedHat8):
        version = '8.1'

    class BaseRedHat8_2(BaseRedHat8):
        version = '8.2'

    class BaseRedHat8_3(BaseRedHat8):
        version = '8.3'

    class BaseRedHat8_4(BaseRedHat8):
        version = '8.4'



# Generated at 2022-06-16 23:01:25.281043
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:01:30.345902
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    # Test on Linux
    assert get_distribution() == 'Redhat'

    # Test on Windows
    assert get_distribution() == 'Windows'

    # Test on Mac OS
    assert get_distribution() == 'Darwin'



# Generated at 2022-06-16 23:01:38.860015
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class SubClass1(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class SubClass3(BaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class SubClass4(BaseClass):
        platform = 'Linux'
        distribution = None

    class SubClass5(BaseClass):
        platform = 'FreeBSD'
        distribution = None

    class SubClass6(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass7(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass8(BaseClass):
        platform = 'Linux'

# Generated at 2022-06-16 23:01:40.804567
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:01:42.303677
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:02:29.745502
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:02:41.217036
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None
    assert get_

# Generated at 2022-06-16 23:02:46.801611
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class BaseClass:
        platform = 'Linux'
        distribution = None

    class LinuxSubclass(BaseClass):
        distribution = 'Redhat'

    class OtherLinuxSubclass(BaseClass):
        distribution = 'OtherLinux'

    class LinuxSubclass2(BaseClass):
        distribution = 'Redhat'

    class LinuxSubclass3(BaseClass):
        distribution = 'Redhat'

    class LinuxSubclass4(BaseClass):
        distribution = 'Redhat'

    class LinuxSubclass5(BaseClass):
        distribution = 'Redhat'

    class LinuxSubclass6(BaseClass):
        distribution = 'Redhat'

    class LinuxSubclass7(BaseClass):
        distribution = 'Redhat'


# Generated at 2022-06-16 23:02:52.793392
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Linux'
        distribution = None

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxRedhat(BaseLinux):
        platform = 'Linux'
        distribution = 'Redhat'

    class BaseLinuxRedhat6(BaseLinuxRedhat):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '6'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '7'

    class BaseLinuxRedhat8(BaseLinuxRedhat):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '8'

    class BaseLinuxRedhat7X(BaseLinuxRedhat7):
        platform = 'Linux'

# Generated at 2022-06-16 23:02:56.067572
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test function get_distribution_codename
    '''
    # Test for Ubuntu
    codename = get_distribution_codename()
    if codename is None:
        raise AssertionError("get_distribution_codename() returned None")
    if codename == "":
        raise AssertionError("get_distribution_codename() returned empty string")
    if codename != "xenial":
        raise AssertionError("get_distribution_codename() returned wrong codename")

# Generated at 2022-06-16 23:03:02.482018
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class SubClass1(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class SubClass3(BaseClass):
        platform = 'Linux'
        distribution = None

    class SubClass4(BaseClass):
        platform = 'FreeBSD'
        distribution = None

    class SubClass5(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass6(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass7(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass8(BaseClass):
        platform = 'Linux'

# Generated at 2022-06-16 23:03:03.374100
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:03:04.361062
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:03:16.620783
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseRedHat(BaseLinux):
        distribution = 'RedHat'

    class BaseRedHat6(BaseRedHat):
        distribution_version = '6'

    class BaseRedHat7(BaseRedHat):
        distribution_version = '7'

    class BaseUbuntu(BaseLinux):
        distribution = 'Ubuntu'

    class BaseUbuntu14(BaseUbuntu):
        distribution_version = '14'

    class BaseUbuntu16(BaseUbuntu):
        distribution_version = '16'

    class BaseDarwin(Base):
        platform = 'Darwin'
        distribution = None

    class BaseDarwin10(BaseDarwin):
        distribution_version = '10'


# Generated at 2022-06-16 23:03:23.055330
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the get_platform_subclass function
    '''
    class BaseClass:
        platform = None
        distribution = None

    class Linux(BaseClass):
        platform = 'Linux'

    class Redhat(Linux):
        distribution = 'Redhat'

    class Debian(Linux):
        distribution = 'Debian'

    class OtherLinux(Linux):
        distribution = 'OtherLinux'

    class BSD(BaseClass):
        platform = 'BSD'

    class Darwin(BaseClass):
        platform = 'Darwin'

    class Windows(BaseClass):
        platform = 'Windows'

    # Test Linux
    assert get_platform_subclass(BaseClass) == Linux
    assert get_platform_subclass(Linux) == Linux
    assert get_platform_subclass(Redhat) == Redhat
    assert get_platform

# Generated at 2022-06-16 23:05:00.708742
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:05:10.873417
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'
        distribution = None

    class Linux(Base):
        platform = 'Linux'
        distribution = None

    class LinuxDistro(Linux):
        distribution = 'LinuxDistro'

    class LinuxDistroVersion(LinuxDistro):
        version = 'LinuxDistroVersion'

    class LinuxDistroVersionCodename(LinuxDistroVersion):
        codename = 'LinuxDistroVersionCodename'

    class LinuxDistroVersionCodename2(LinuxDistroVersion):
        codename = 'LinuxDistroVersionCodename2'

    class LinuxDistroVersion2(LinuxDistro):
        version = 'LinuxDistroVersion2'

    class LinuxDistroVersion2Codename(LinuxDistroVersion2):
        codename = 'LinuxDistroVersion2Codename'


# Generated at 2022-06-16 23:05:22.974634
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    import unittest

    class TestClass:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = None
        distribution = None

    class TestSubclass1(TestClass):
        '''
        Subclass of TestClass
        '''
        platform = 'Linux'
        distribution = 'Redhat'

    class TestSubclass2(TestClass):
        '''
        Subclass of TestClass
        '''
        platform = 'Linux'
        distribution = 'Debian'

    class TestSubclass3(TestClass):
        '''
        Subclass of TestClass
        '''
        platform = 'Linux'
        distribution = None


# Generated at 2022-06-16 23:05:24.537043
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:05:26.155693
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:05:36.281748
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class Base:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = None
        distribution = None

    class LinuxBase(Base):
        '''
        Base class for testing get_platform_subclass on Linux
        '''
        platform = 'Linux'

    class LinuxDistroBase(LinuxBase):
        '''
        Base class for testing get_platform_subclass on a Linux distribution
        '''
        distribution = 'LinuxDistro'

    class LinuxDistroVersionBase(LinuxDistroBase):
        '''
        Base class for testing get_platform_subclass on a Linux distribution version
        '''
        distribution_version = 'LinuxDistroVersion'


# Generated at 2022-06-16 23:05:37.645795
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:05:39.096054
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:05:40.338256
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-16 23:05:42.349440
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'
