

# Generated at 2022-06-16 22:59:05.112213
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class A(object):
        platform = 'Linux'
        distribution = None

    class B(A):
        distribution = 'RedHat'

    class C(A):
        distribution = 'Debian'

    class D(A):
        distribution = 'RedHat'

    class E(D):
        platform = 'FreeBSD'

    class F(D):
        platform = 'Linux'
        distribution = 'Debian'

    class G(D):
        platform = 'Linux'
        distribution = 'RedHat'

    class H(D):
        platform = 'Linux'
        distribution = 'RedHat'

    class I(H):
        distribution = 'Debian'

    class J(H):
        distribution = 'RedHat'

    class K(H):
        distribution = 'RedHat'


# Generated at 2022-06-16 22:59:06.080537
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the function get_distribution_version
    '''
    assert get_distribution_version() is not None

# Generated at 2022-06-16 22:59:14.687022
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    # Test for Linux
    assert get_distribution() == 'Linux'

    # Test for Windows
    assert get_distribution() == 'Windows'

    # Test for Darwin
    assert get_distribution() == 'Darwin'

    # Test for FreeBSD
    assert get_distribution() == 'Freebsd'

    # Test for OpenBSD
    assert get_distribution() == 'Openbsd'

    # Test for NetBSD
    assert get_distribution() == 'Netbsd'

    # Test for SunOS
    assert get_distribution() == 'Sunos'

    # Test for AIX
    assert get_distribution() == 'Aix'

    # Test for HP-UX
    assert get_distribution() == 'Hp-ux'

    #

# Generated at 2022-06-16 22:59:15.879075
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 22:59:18.518587
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 22:59:20.226771
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 22:59:26.445691
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    # Test for Linux
    assert get_distribution() == 'Linux'

    # Test for Windows
    assert get_distribution() == 'Windows'

    # Test for Mac
    assert get_distribution() == 'Darwin'

    # Test for Other
    assert get_distribution() == 'Other'


# Generated at 2022-06-16 22:59:36.230070
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    import sys
    import platform

    class Base:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = None
        distribution = None

    class LinuxBase(Base):
        '''
        Base class for testing get_platform_subclass on Linux
        '''
        platform = 'Linux'

    class LinuxDistroBase(LinuxBase):
        '''
        Base class for testing get_platform_subclass on a specific Linux distribution
        '''
        distribution = None

    class LinuxDistro1(LinuxDistroBase):
        '''
        Class for testing get_platform_subclass on Linux distribution 1
        '''
        distribution = 'LinuxDistro1'


# Generated at 2022-06-16 22:59:37.959736
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 22:59:49.152007
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the get_platform_subclass function
    '''
    class BaseClass:
        pass

    class SubClass1(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class SubClass3(BaseClass):
        platform = 'Linux'
        distribution = None

    class SubClass4(BaseClass):
        platform = 'FreeBSD'
        distribution = None

    class SubClass5(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass6(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class SubClass7(BaseClass):
        platform = 'Linux'
        distribution = None


# Generated at 2022-06-16 23:00:01.206168
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        platform = 'BasePlatform'
        distribution = None

    class PlatformSubclass(BaseClass):
        platform = 'TestPlatform'

    class DistributionSubclass(BaseClass):
        distribution = 'TestDistro'

    class PlatformDistributionSubclass(BaseClass):
        platform = 'TestPlatform'
        distribution = 'TestDistro'

    assert get_platform_subclass(BaseClass) == BaseClass
    assert get_platform_subclass(PlatformSubclass) == PlatformSubclass
    assert get_platform_subclass(DistributionSubclass) == DistributionSubclass
    assert get_platform_subclass(PlatformDistributionSubclass) == PlatformDistributionSubclass

# Generated at 2022-06-16 23:00:09.052453
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    import sys
    import unittest

    class BaseClass:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'Base'
        distribution = None

    class BaseSubclass(BaseClass):
        '''
        Base subclass for testing get_platform_subclass
        '''
        platform = 'Base'
        distribution = None

    class LinuxSubclass(BaseClass):
        '''
        Linux subclass for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = None

    class LinuxDistroSubclass(BaseClass):
        '''
        Linux subclass for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = 'LinuxDistro'

# Generated at 2022-06-16 23:00:11.330401
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None


# Generated at 2022-06-16 23:00:15.396388
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    # Test for the case where there is a subclass for the platform and distribution
    class TestClass:
        platform = 'Linux'
        distribution = 'Redhat'

    class TestClassSubclass1(TestClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class TestClassSubclass2(TestClass):
        platform = 'Linux'
        distribution = 'Redhat'

    assert get_platform_subclass(TestClass) == TestClassSubclass2

    # Test for the case where there is a subclass for the platform but not the distribution
    class TestClass:
        platform = 'Linux'
        distribution = 'Redhat'

    class TestClassSubclass1(TestClass):
        platform = 'Linux'
        distribution = None

    class TestClassSubclass2(TestClass):
        platform = 'Linux'
        distribution = None



# Generated at 2022-06-16 23:00:17.199819
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:00:18.678505
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() is not None


# Generated at 2022-06-16 23:00:28.363950
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseRedHat(BaseLinux):
        distribution = 'RedHat'

    class BaseRedHat6(BaseRedHat):
        version = '6'

    class BaseRedHat7(BaseRedHat):
        version = '7'

    class BaseRedHat8(BaseRedHat):
        version = '8'

    class BaseRedHat9(BaseRedHat):
        version = '9'

    class BaseRedHat10(BaseRedHat):
        version = '10'

    class BaseRedHat11(BaseRedHat):
        version = '11'

    class BaseRedHat12(BaseRedHat):
        version = '12'

    class BaseRedHat13(BaseRedHat):
        version = '13'

   

# Generated at 2022-06-16 23:00:40.175423
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'

    class BaseLinuxOther(BaseLinux):
        distribution = 'OtherLinux'

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        distribution_version = '7'

    class BaseLinuxRedhat8(BaseLinuxRedhat):
        distribution_version = '8'

    class BaseLinuxRedhat7_1(BaseLinuxRedhat7):
        distribution_version = '7.1'

    class BaseLinuxRedhat7_2(BaseLinuxRedhat7):
        distribution_version = '7.2'

    class BaseLinuxRedhat7_3(BaseLinuxRedhat7):
        distribution_version = '7.3'


# Generated at 2022-06-16 23:00:50.144274
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedhat6(BaseLinuxRedhat):
        distribution_version = '6'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        distribution_version = '7'

    class BaseLinuxOther(BaseLinux):
        distribution = 'OtherLinux'

    class BaseLinuxOther6(BaseLinuxOther):
        distribution_version = '6'

    class BaseLinuxOther7(BaseLinuxOther):
        distribution_version = '7'

    class BaseLinuxOther8(BaseLinuxOther):
        distribution_version = '8'

    class BaseLinuxOther9(BaseLinuxOther):
        distribution_version = '9'


# Generated at 2022-06-16 23:01:00.346607
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the get_platform_subclass function
    '''
    class Base:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = None
        distribution = None

    class Linux(Base):
        '''
        Linux class for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = None

    class LinuxRedhat(Base):
        '''
        LinuxRedhat class for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = 'Redhat'

    class LinuxRedhat7(Base):
        '''
        LinuxRedhat7 class for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = 'Redhat'
        version = '7'


# Generated at 2022-06-16 23:01:20.777536
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class SubClass1(BaseClass):
        platform = 'Linux'
        distribution = 'Ubuntu'

    class SubClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class SubClass3(BaseClass):
        platform = 'Linux'
        distribution = 'RedHat'

    class SubClass4(BaseClass):
        platform = 'Linux'
        distribution = 'OtherLinux'

    class SubClass5(BaseClass):
        platform = 'Linux'
        distribution = None

    class SubClass6(BaseClass):
        platform = 'FreeBSD'
        distribution = None

    class SubClass7(BaseClass):
        platform = 'OpenBSD'
        distribution = None

    class SubClass8(BaseClass):
        platform = 'SunOS'
        distribution = None

# Generated at 2022-06-16 23:01:33.126986
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the get_distribution_codename function
    '''
    from ansible.module_utils.common._collections_compat import Mapping

    # Test for Ubuntu Xenial Xerus
    os_release_info = {'version_codename': 'xenial'}
    distro.os_release_info = lambda: os_release_info
    assert get_distribution_codename() == 'xenial'

    # Test for Fedora 28
    os_release_info = {'version_codename': ''}
    distro.os_release_info = lambda: os_release_info
    assert get_distribution_codename() is None

    # Test for Ubuntu Xenial Xerus
    os_release_info = {'ubuntu_codename': 'xenial'}
    distro.os_release

# Generated at 2022-06-16 23:01:43.143678
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'
        distribution = None

    class LinuxBase(Base):
        platform = 'Linux'
        distribution = None

    class LinuxDistroBase(LinuxBase):
        distribution = 'LinuxDistro'

    class LinuxDistroVersionBase(LinuxDistroBase):
        version = 'LinuxDistroVersion'

    class LinuxDistroVersionCodenameBase(LinuxDistroVersionBase):
        codename = 'LinuxDistroVersionCodename'

    class LinuxDistroVersionBase2(LinuxDistroBase):
        version = 'LinuxDistroVersion2'

    class LinuxDistroVersionCodenameBase2(LinuxDistroVersionBase2):
        codename = 'LinuxDistroVersionCodename2'

    class LinuxDistroVersionBase3(LinuxDistroBase):
        version = 'LinuxDistroVersion3'


# Generated at 2022-06-16 23:01:44.712473
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:01:55.451914
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class Linux(Base):
        platform = 'Linux'

    class RedHat(Linux):
        distribution = 'RedHat'

    class Debian(Linux):
        distribution = 'Debian'

    class OtherLinux(Linux):
        distribution = 'OtherLinux'

    class Darwin(Base):
        platform = 'Darwin'

    class Windows(Base):
        platform = 'Windows'

    class Other(Base):
        pass

    assert get_platform_subclass(Base) == Base
    assert get_platform_subclass(Linux) == Linux
    assert get_platform_subclass(RedHat) == RedHat
    assert get_platform_subclass(Debian) == Debian
    assert get_platform_subclass(OtherLinux) == OtherLinux
    assert get_platform_subclass(Darwin) == Darwin
   

# Generated at 2022-06-16 23:01:56.682467
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:02:04.177649
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test get_platform_subclass()
    '''
    class BaseClass:
        pass

    class PlatformA(BaseClass):
        platform = 'A'
        distribution = None

    class PlatformB(BaseClass):
        platform = 'B'
        distribution = None

    class PlatformA_Distro1(PlatformA):
        distribution = 'Distro1'

    class PlatformA_Distro2(PlatformA):
        distribution = 'Distro2'

    class PlatformB_Distro1(PlatformB):
        distribution = 'Distro1'

    class PlatformB_Distro2(PlatformB):
        distribution = 'Distro2'

    class PlatformB_Distro3(PlatformB):
        distribution = 'Distro3'

    # Test that we get the most specific subclass

# Generated at 2022-06-16 23:02:15.967206
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class BaseClass:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'Base'
        distribution = None

    class LinuxClass(BaseClass):
        '''
        Linux class for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = None

    class LinuxDistroClass(LinuxClass):
        '''
        Linux distribution class for testing get_platform_subclass
        '''
        distribution = 'LinuxDistro'

    class LinuxDistroVersionClass(LinuxDistroClass):
        '''
        Linux distribution version class for testing get_platform_subclass
        '''
        distribution_version = 'LinuxDistroVersion'


# Generated at 2022-06-16 23:02:17.853132
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    '''
    Test the get_distribution_codename function
    '''
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:02:20.211300
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:02:53.335056
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    # Test for Ubuntu
    os_release_info = {'version_codename': 'xenial', 'ubuntu_codename': 'xenial'}
    lsb_release_info = {'codename': 'xenial'}
    codename = get_distribution_codename(os_release_info, lsb_release_info, 'ubuntu')
    assert codename == 'xenial'

    # Test for Fedora
    os_release_info = {'version_codename': None, 'ubuntu_codename': None}
    lsb_release_info = {'codename': None}
    codename = get_distribution_codename(os_release_info, lsb_release_info, 'fedora')
    assert codename is None

# Generated at 2022-06-16 23:02:54.213032
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:03:05.623932
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'
        distribution = None

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        version = '7'

    class BaseLinuxRedhat6(BaseLinuxRedhat):
        version = '6'

    class BaseLinuxRedhat5(BaseLinuxRedhat):
        version = '5'

    class BaseLinuxRedhat4(BaseLinuxRedhat):
        version = '4'

    class BaseLinuxRedhat3(BaseLinuxRedhat):
        version = '3'

    class BaseLinuxRedhat2(BaseLinuxRedhat):
        version = '2'


# Generated at 2022-06-16 23:03:17.106322
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxDistro(Base):
        platform = 'Linux'
        distribution = 'Distro'

    class BaseLinuxDistroVersion(Base):
        platform = 'Linux'
        distribution = 'Distro'
        version = '1.0'

    class BaseLinuxDistroVersion2(Base):
        platform = 'Linux'
        distribution = 'Distro'
        version = '2.0'

    class BaseLinuxDistro2(Base):
        platform = 'Linux'
        distribution = 'Distro2'

    class BaseLinuxDistro2Version(Base):
        platform = 'Linux'
        distribution = 'Distro2'
        version = '1.0'


# Generated at 2022-06-16 23:03:27.691583
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class BaseClass:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'BasePlatform'
        distribution = None

    class SubClass1(BaseClass):
        '''
        Subclass for testing get_platform_subclass
        '''
        platform = 'SubClass1Platform'
        distribution = None

    class SubClass2(BaseClass):
        '''
        Subclass for testing get_platform_subclass
        '''
        platform = 'SubClass2Platform'
        distribution = 'SubClass2Distribution'

    class SubClass3(BaseClass):
        '''
        Subclass for testing get_platform_subclass
        '''
        platform = 'SubClass3Platform'

# Generated at 2022-06-16 23:03:32.941340
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test the function get_distribution_version
    '''
    # Test for the case of a Linux distribution
    assert get_distribution_version() is not None

    # Test for the case of a non-Linux distribution
    assert get_distribution_version() is not None

# Generated at 2022-06-16 23:03:33.994440
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None

# Generated at 2022-06-16 23:03:35.297176
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:03:47.261996
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Unit test for function get_distribution_version
    '''
    # Test for Redhat
    distro.id = lambda: 'rhel'
    distro.version = lambda: '7.6'
    distro.version.__name__ = 'version'
    distro.version.__doc__ = 'version'
    distro.version.__module__ = 'distro'
    distro.version.__defaults__ = None
    distro.version.__code__ = None
    distro.version.__globals__ = None
    distro.version.__dict__ = None
    distro.version.__closure__ = None
    distro.version.__annotations__ = None
    distro.version.__kwdefaults__ = None
    distro.version.__self__ = None


# Generated at 2022-06-16 23:03:57.704166
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'
        distribution = None

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        version = '7'

    class BaseLinuxRedhat8(BaseLinuxRedhat):
        version = '8'

    class BaseLinuxOther(BaseLinux):
        distribution = 'OtherLinux'

    class BaseLinuxOther7(BaseLinuxOther):
        version = '7'

    class BaseLinuxOther8(BaseLinuxOther):
        version = '8'

    class BaseLinuxOther9(BaseLinuxOther):
        version = '9'

    class BaseLinuxOther10(BaseLinuxOther):
        version = '10'


# Generated at 2022-06-16 23:04:51.057664
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    import sys
    import unittest

    class BaseClass(object):
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'Base'
        distribution = None

    class PlatformClass(BaseClass):
        '''
        Platform class for testing get_platform_subclass
        '''
        platform = platform.system()
        distribution = None

    class DistributionClass(BaseClass):
        '''
        Distribution class for testing get_platform_subclass
        '''
        platform = 'Base'
        distribution = get_distribution()

    class PlatformDistributionClass(BaseClass):
        '''
        Platform and Distribution class for testing get_platform_subclass
        '''
        platform = platform.system()
       

# Generated at 2022-06-16 23:04:52.036255
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == 'xenial'

# Generated at 2022-06-16 23:04:52.751654
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() is None

# Generated at 2022-06-16 23:04:53.945027
# Unit test for function get_distribution_version
def test_get_distribution_version():
    assert get_distribution_version() == '7.5'

# Generated at 2022-06-16 23:05:06.704519
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Base'
        distribution = None

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseLinuxRedHat(BaseLinux):
        distribution = 'RedHat'

    class BaseLinuxRedHat7(BaseLinuxRedHat):
        version = '7'

    class BaseLinuxRedHat8(BaseLinuxRedHat):
        version = '8'

    class BaseLinuxRedHat7_1(BaseLinuxRedHat7):
        version = '7.1'

    class BaseLinuxRedHat7_2(BaseLinuxRedHat7):
        version = '7.2'

    class BaseLinuxRedHat7_3(BaseLinuxRedHat7):
        version = '7.3'


# Generated at 2022-06-16 23:05:08.039038
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:05:10.022339
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:05:11.320460
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:05:23.425692
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class LinuxBase(Base):
        platform = 'Linux'

    class LinuxDistroBase(LinuxBase):
        distribution = 'Redhat'

    class LinuxDistroVersionBase(LinuxDistroBase):
        version = '6.0'

    class LinuxDistroVersionBase2(LinuxDistroBase):
        version = '7.0'

    class LinuxDistroBase2(LinuxBase):
        distribution = 'Debian'

    class LinuxDistroVersionBase3(LinuxDistroBase2):
        version = '7.0'

    class LinuxDistroVersionBase4(LinuxDistroBase2):
        version = '8.0'

    class LinuxDistroBase3(LinuxBase):
        distribution = 'OtherLinux'


# Generated at 2022-06-16 23:05:34.283484
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseRedhat(BaseLinux):
        distribution = 'Redhat'

    class BaseRedhat6(BaseRedhat):
        version = '6'

    class BaseRedhat7(BaseRedhat):
        version = '7'

    class BaseRedhat8(BaseRedhat):
        version = '8'

    class BaseRedhat9(BaseRedhat):
        version = '9'

    class BaseRedhat10(BaseRedhat):
        version = '10'

    class BaseRedhat11(BaseRedhat):
        version = '11'

    class BaseRedhat12(BaseRedhat):
        version = '12'

    class BaseRedhat13(BaseRedhat):
        version = '13'

   

# Generated at 2022-06-16 23:07:11.053003
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class Base:
        pass

    class Linux(Base):
        platform = 'Linux'

    class Redhat(Linux):
        distribution = 'Redhat'

    class Debian(Linux):
        distribution = 'Debian'

    class OtherLinux(Linux):
        distribution = 'OtherLinux'

    class Darwin(Base):
        platform = 'Darwin'

    class Windows(Base):
        platform = 'Windows'

    class BSD(Base):
        platform = 'BSD'

    class OpenBSD(BSD):
        distribution = 'OpenBSD'

    class FreeBSD(BSD):
        distribution = 'FreeBSD'

    class NetBSD(BSD):
        distribution = 'NetBSD'

    class SunOS(Base):
        platform = 'SunOS'


# Generated at 2022-06-16 23:07:12.430700
# Unit test for function get_distribution_version
def test_get_distribution_version():
    '''
    Test function get_distribution_version
    '''
    assert get_distribution_version() is not None

# Generated at 2022-06-16 23:07:21.058714
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Unit test for function get_platform_subclass
    '''
    class Base:
        platform = 'Base'
        distribution = None

    class BaseLinux(Base):
        platform = 'Linux'
        distribution = None

    class BaseRedhat(Base):
        platform = 'Linux'
        distribution = 'Redhat'

    class BaseRedhat7(Base):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '7'

    class BaseRedhat8(Base):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '8'

    class BaseRedhat8_1(Base):
        platform = 'Linux'
        distribution = 'Redhat'
        version = '8.1'

    class BaseRedhat8_2(Base):
        platform = 'Linux'

# Generated at 2022-06-16 23:07:32.002964
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        platform = 'Linux'
        distribution = None

    class Linux(Base):
        pass

    class Redhat(Linux):
        distribution = 'Redhat'

    class Redhat6(Redhat):
        distribution_version = '6'

    class Redhat7(Redhat):
        distribution_version = '7'

    class Redhat8(Redhat):
        distribution_version = '8'

    class Redhat9(Redhat):
        distribution_version = '9'

    class Redhat10(Redhat):
        distribution_version = '10'

    class Redhat11(Redhat):
        distribution_version = '11'

    class Redhat12(Redhat):
        distribution_version = '12'

    class Redhat13(Redhat):
        distribution_version = '13'


# Generated at 2022-06-16 23:07:34.708781
# Unit test for function get_distribution_codename
def test_get_distribution_codename():
    assert get_distribution_codename() == None
    assert get_distribution_codename() == None

# Generated at 2022-06-16 23:07:37.313073
# Unit test for function get_distribution
def test_get_distribution():
    '''
    Test the get_distribution function
    '''
    assert get_distribution() == 'Redhat'


# Generated at 2022-06-16 23:07:44.721165
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class Base:
        pass

    class BaseLinux(Base):
        platform = 'Linux'

    class BaseLinuxDistro(BaseLinux):
        distribution = 'RedHat'

    class BaseLinuxDistroVersion(BaseLinuxDistro):
        version = '6'

    class BaseLinuxDistroVersionCodename(BaseLinuxDistroVersion):
        codename = 'Santiago'

    class BaseLinuxDistroVersionCodenameArch(BaseLinuxDistroVersionCodename):
        architecture = 'x86_64'

    class BaseLinuxDistroVersionCodenameArch2(BaseLinuxDistroVersionCodename):
        architecture = 'i386'

    class BaseLinuxDistroVersion2(BaseLinuxDistro):
        version = '7'

    class BaseLinuxDistro2(BaseLinux):
        distribution = 'Debian'


# Generated at 2022-06-16 23:07:52.271082
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    class BaseClass:
        pass

    class SubClass1(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass2(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class SubClass3(BaseClass):
        platform = 'Linux'
        distribution = None

    class SubClass4(BaseClass):
        platform = 'FreeBSD'
        distribution = None

    class SubClass5(BaseClass):
        platform = 'Linux'
        distribution = 'Redhat'

    class SubClass6(BaseClass):
        platform = 'Linux'
        distribution = 'Debian'

    class SubClass7(BaseClass):
        platform = 'Linux'
        distribution = None

    class SubClass8(BaseClass):
        platform = 'FreeBSD'
        distribution = None



# Generated at 2022-06-16 23:07:53.663574
# Unit test for function get_distribution
def test_get_distribution():
    assert get_distribution() == 'Linux'


# Generated at 2022-06-16 23:08:05.552529
# Unit test for function get_platform_subclass
def test_get_platform_subclass():
    '''
    Test the get_platform_subclass function
    '''
    import sys

    class Base:
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'Base'
        distribution = None

    class BaseLinux(Base):
        '''
        Base class for testing get_platform_subclass
        '''
        platform = 'Linux'
        distribution = None

    class BaseLinuxRedhat(BaseLinux):
        '''
        Base class for testing get_platform_subclass
        '''
        distribution = 'Redhat'

    class BaseLinuxRedhat7(BaseLinuxRedhat):
        '''
        Base class for testing get_platform_subclass
        '''
        distribution_version = '7'
