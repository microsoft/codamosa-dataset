

# Generated at 2022-06-25 10:11:48.482226
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    from ansible.parsing.dataloader import DataLoader
    loader_0 = DataLoader()
    path_0 = 'test.yaml'
    cache_0 = True
    inventory_module_0.parse(inventory_module_0.inventory, loader_0, path_0, cache=cache_0)


# Generated at 2022-06-25 10:11:52.073878
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule()
    loader_0 = InventoryModule()
    path_0 = 'ansible.cfg'
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)

if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:12:00.344197
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():


    # Set up inputs for test method
    valid = False
    path = "/home/user/ansible-dummy/inventory/file"
    default_ext = ['.yaml', '.yml', '.json']
    # expected outcome:
    expected_return = False
    # set up return values when super method is called
    def mock_super(self):
        valid = True
    # patch super:
    InventoryModule.verify_file = mock_super

    # Create instance of InventoryModule class
    inventory_module_1 = InventoryModule()

    # Call the tested method of the class
    actual_return = inventory_module_1.verify_file(path)

    # check that that the class method returns the expected value
    assert expected_return == actual_return, "bad return value: %s" % actual_return

# Unit test

# Generated at 2022-06-25 10:12:05.885863
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    import yaml
    data = yaml.safe_load(EXAMPLES)

    inventory_module_1.parse(None, None, None)
    inventory_module_1._parse_group(None, None)
    inventory_module_1._parse_host(None)
    #for group_name in data:
    #    inventory_module_1._parse_group(group_name, data[group_name])

test_InventoryModule_parse()

# Generated at 2022-06-25 10:12:11.510289
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import re

    inventory_module_1 = InventoryModule()
    inventory = re.match('^([^:]+):$', EXAMPLES, flags=0)
    loader = re.match('^([^:]+):$', EXAMPLES, flags=0)
    path = re.match('^([^:]+):$', EXAMPLES, flags=0)
    inventory_module_1.parse(inventory, loader, path)

# Generated at 2022-06-25 10:12:22.253753
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Create instance of InventoryModule using default constructor
    inventory_module = InventoryModule()

    # Create file /tmp/inventory.yaml for testing
    f = open('/tmp/inventory.yaml', 'w')
    f.write('valid yaml')
    f.close()

    # Invoke InventoryModule.verify_file with verify_file
    ret = inventory_module.verify_file('/tmp/inventory.yaml')
    # Test that return value is True
    assert ret == True

    # Create file /tmp/inventory.cfg for testing
    f = open('/tmp/inventory.cfg', 'w')
    f.write('valid ini')
    f.close()

    # Invoke InventoryModule.verify_file with verify_file
    ret = inventory_module.verify_file('/tmp/inventory.cfg')

# Generated at 2022-06-25 10:12:30.099376
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    """Test case for InventoryModule method verify_file"""
    # create an instance of the InventoryModule class
    inventory_module_1 = InventoryModule()
    # define a path to a test file
    path = "/c/foobar"
    # verify the result of calling verify_file with path as its parameter
    rval = inventory_module_1.verify_file(path)
    assert rval == False


# Generated at 2022-06-25 10:12:33.752656
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file("abc.yml")
    assert inventory_module_1.verify_file("abc.yaml")
    assert inventory_module_1.verify_file("abc.json")
    assert not inventory_module_1.verify_file("abc.txt")

# Generated at 2022-06-25 10:12:35.521756
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    assert inventory_module.parse(inventory='', loader='', path='', cache=True) == None

    data = inventory_module.loader.load_from_file(path='', cache=False)
    assert isinstance(data, MutableMapping)


# Generated at 2022-06-25 10:12:41.508820
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = inventory_module_0.parse(inventory=inventory_0, loader=loader_0, path="test_path")


# Generated at 2022-06-25 10:12:53.525934
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 10:12:54.959349
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory = None, loader = None, path = None)


# Generated at 2022-06-25 10:12:56.072881
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.set_options()


# Generated at 2022-06-25 10:12:59.749021
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_0 = InventoryModule()

    assert( inventory_module_0.verify_file("test.yaml") )
    assert( inventory_module_0.verify_file("test.yml") )
    assert( inventory_module_0.verify_file("test.json") )
    assert( not inventory_module_0.verify_file("test.py") )

if __name__ == "__main__":

    test_case_0()
    test_InventoryModule_verify_file()

# Generated at 2022-06-25 10:13:08.876972
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    for ext in inventory_module_1.get_option('yaml_extensions'):
        assert(inventory_module_1.verify_file('inventory' + ext) == True)
        assert(inventory_module_1.verify_file('inventory' + ext + '.bak') == False)

    class MockInventory():
        class MockGroup():
            def __init__(self):
                self.vars = dict()
                self.hosts = dict()
                self.children = dict()
            def __str__(self):
                return 'MockGroup: ' + str(self.vars) + str(self.hosts) + str(self.children)
            def set_variable(self, variable, value):
                self.vars[variable] = value


# Generated at 2022-06-25 10:13:12.737289
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_data = (
"""
all:
    hosts:
        localhost:
            ansible_connection: ssh
    vars:
        var1: value1
        var2: value2
        var3: value3
        var4: value4
        var5: value5
"""
)
    from io import StringIO
    inventory_data_file = StringIO(inventory_data)
    inventory_module.parse(inventory_data_file,'mock_loader','mock_path')
    print("test_InventoryModule_parse - SUCCESS")

if __name__ == "__main__":
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:13:13.604679
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    pass



# Generated at 2022-06-25 10:13:20.318697
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  file_path = 'test_parsing.yaml'
  ansible_inventory_module = InventoryModule()
  
  ansible_inventory_module.parse(None, None, file_path, cache=True)
  ansible_inventory_module.get_host('h0')
  ansible_inventory_module.get_host('h1')
  ansible_inventory_module.get_host('h2')
  ansible_inventory_module.get_host('h3')
  ansible_inventory_module.get_host('h4')
  ansible_inventory_module.get_host('h5')


if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:13:25.163801
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(inventory=inventory_module_0.inventory, loader=inventory_module_0.loader, path="test0") == None


# Generated at 2022-06-25 10:13:32.830139
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    print("***** Parse Test *****")
