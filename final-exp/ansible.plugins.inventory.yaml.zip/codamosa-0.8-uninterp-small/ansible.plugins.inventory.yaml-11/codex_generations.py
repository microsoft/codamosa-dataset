

# Generated at 2022-06-25 10:11:46.152931
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    inventory_module_1.set_options = set_options_mock
    inventory_module_1.verify_file(path)


# Generated at 2022-06-25 10:11:49.371520
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # Construct with default arguments
    inventory_module_0 = InventoryModule()

    test_path_0 = '/foo/bar'
    test_path_1 = 'foo.yaml'
    assert (inventory_module_0.verify_file(test_path_0) == False)
    assert (inventory_module_0.verify_file(test_path_1) == True)


# Generated at 2022-06-25 10:11:51.832645
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}
    loader = {"load_from_file": lambda x: {"all": {"hosts": {}}}}
    path = "/etc/ansible/hosts"
    cache = True
    inventory_module = InventoryModule()
    inventory_module.parse(inventory, loader, path, cache=True)


# Generated at 2022-06-25 10:11:56.347273
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    """
      This test is for verifying verify_file
    """
    inventory_module_0 = InventoryModule()

    #Verify for PEP 8
    assert verify_pep8("test_InventoryModule.py")==True

    #Verify the meta class
    assert 'ansible.plugins.inventory.yaml.InventoryModule' in str(type(inventory_module_0))

    #Verify the meta class of super class
    assert 'ansible.plugins.inventory.BaseFileInventoryPlugin' in str(type(super(InventoryModule, inventory_module_0)))


# Generated at 2022-06-25 10:12:02.970052
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    inventory_module_1.get_option = lambda x: ['.yaml'] if x == 'yaml_extensions' else None
    assert inventory_module_1.verify_file('./test_test_cases/test_InventoryModule_verify_file.yaml') == True


# Generated at 2022-06-25 10:12:05.333875
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    try:
        inventory_module_0.verify_file('test.yml')
    except:
        print('Unexpected exception thrown')


# Generated at 2022-06-25 10:12:14.848300
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

# Generated at 2022-06-25 10:12:19.123623
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('inventory_1', 'loader_1', 'path_1', cache=True)



# Generated at 2022-06-25 10:12:22.371911
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.set_options()
    loader_0 = None
    path_0 = None


# Generated at 2022-06-25 10:12:24.007748
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    inventory_module_parse.parse(None, None, '', False)


# Generated at 2022-06-25 10:12:36.850100
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    path = "/tmp/sample_file.txt"
    inventory_module.verify_file(path)
    assert True


# Generated at 2022-06-25 10:12:43.638738
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Testing verify_file by passing a file name with valid extension
    inventory_module = InventoryModule()
    assert inventory_module.verify_file(path='test_yaml_file.yml') == True
    # Testing verify_file by passing a file name with invalid extension
    assert inventory_module.verify_file(path='inventory_config') == False


# Generated at 2022-06-25 10:12:49.976668
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file("/tmp/test_ansible_file_verify") == False
    assert inventory_module_1.verify_file("/tmp/test_ansible_file_verify.yml") == True

test_case_0()
test_InventoryModule_verify_file()

# Generated at 2022-06-25 10:12:53.419434
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
  inventory_module_0 = InventoryModule()
  file_name = os.getcwd() + "/../../../playbooks/inventory/prod"
  assert inventory_module_0.verify_file(file_name) == True


# Generated at 2022-06-25 10:12:58.432429
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    inventory_module.set_options()
    inventory_module.verify_file('test_case_0')
    inventory_module.verify_file('test_case_1')
    inventory_module.verify_file('test_case_2')
    inventory_module.verify_file('test_case_3')
    inventory_module.verify_file('test_case_4')
    inventory_module.verify_file('test_case_5')
    inventory_module.verify_file('test_case_6')

# Test case for class Inventorymodule
# Test Test case for method verify_file of class InventoryModule

# Generated at 2022-06-25 10:13:08.786769
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    yaml_inventory = """
example:
    hosts:
        host1:
            ansible_host: 1.1.1.1
            ansible_user: root
            ansible_port: 22
        host2:
        host3:
            ansible_host: 3.3.3.3
    children:
        group1:
            hosts:
                host4:
                    ansible_host: 4.4.4.4
            children:
                group2:
                    hosts:
                        host5:
    vars:
        group_var: "value"
        group_var2: "value2"
"""
    print(yaml_inventory)
    # Test about group "example"
    group = inventory_module_0.inventory.groups['example']
    assert len(group.hosts) == 3

# Generated at 2022-06-25 10:13:14.525062
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    try:
        inventory_module_1 = InventoryModule()
        path = "/tmp/ansible_inventory_plugin_yaml_test"
        with open(path, "w") as f:
            f.write("plugin: yaml")
        assert True == inventory_module_1.verify_file(path)
    except Exception as e:
        print("InventoryModule verify_file() failed -> %s" % e)
        assert False



# Generated at 2022-06-25 10:13:17.629811
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file('~/Desktop/ansible-test/test-suites/inventory/plugins/inventory_plugin_yaml.yaml') == True


# Generated at 2022-06-25 10:13:18.792301
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()


# Generated at 2022-06-25 10:13:23.470370
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("inventory", "loader", "path")


# Generated at 2022-06-25 10:13:43.661370
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = [None]
    loader_0 = [None]
    path_0 = [None]
    cache = [None]
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache = True)

#Unit test case for class InventoryModule

# Generated at 2022-06-25 10:13:47.995246
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_2 = InventoryModule()
    path_to_file = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '../../../examples/ansible.cfg'))
    inventory_module_2.verify_file(path_to_file)


# Generated at 2022-06-25 10:13:51.412586
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory, loader, path)
    assert inventory_module_1.verify_file(path) == True


# Generated at 2022-06-25 10:13:53.950292
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # inventory_loader = ok
    # inventory = ok
    # path = ok
    # InventoryModule.parse(inventory_loader=inventory_loader, inventory=inventory, path=path)


# Generated at 2022-06-25 10:13:55.131525
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    try:
        inventory_module_1 = InventoryModule()
        inventory = inventory_module_1.parse("test", "loader", "path", "cache")
    except Exception as e:
        print("Exception caught = ", e)

# Generated at 2022-06-25 10:14:02.077570
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    data = {
        'all': {
            'hosts': {
            },
            'vars': {
            },
            'children': {
            }
        }
    }
    inventory_module_p = InventoryModule()
    assert inventory_module_p.parse(data) == None

# Generated at 2022-06-25 10:14:03.640567
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse("yaml", "yaml", "yaml", "yaml")

# This code will be executed when the file is loaded.
# Unit test file for this module

# Generated at 2022-06-25 10:14:06.766844
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    #assert True # We need to write a test.
    inventory_module_0 = InventoryModule()

    #  We use to check the correct types of values passed to methods.
    #mock_InventoryFile.assert_called_with('/opt/local/ansible/inventory', 'ansible', False, False)
    assert True


test_case_0()

# Generated at 2022-06-25 10:14:17.727650
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.set_options()

# Generated at 2022-06-25 10:14:25.258034
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os
    inventory_module_1 = InventoryModule()
    inventory_module_1.get_option = os.path.splitext
    inventory_module_1.get_option.return_value = ['.yaml','.yml','.json']
    print(inventory_module_1.verify_file('./test_yaml.yaml'))
    print(inventory_module_1.verify_file('./test_yaml'))
    print(inventory_module_1.verify_file('./test_yaml.json'))

# Generated at 2022-06-25 10:14:55.004537
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    file_name = 'test.yaml'
    inventory_module = InventoryModule()
    inventory_module.set_options()
    assert inventory_module.verify_file(file_name)


# Generated at 2022-06-25 10:14:58.417297
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file('inventory.yaml')
    assert not inventory_module_1.verify_file('inventory.yml')
    assert inventory_module_1.verify_file('inventory.json')
    assert not inventory_module_1.verify_file('inventory.txt')
    assert not inventory_module_1.verify_file('inventory')


# Generated at 2022-06-25 10:15:00.983139
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    path = "../ansible/plugins/inventory/yaml.py"
    assert inventory_module_1.verify_file(path) is True
    path = "../ansible/plugins/inventory/ini.py"
    assert inventory_module_1.verify_file(path) is False
 

# Generated at 2022-06-25 10:15:04.555023
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0__ = "~/ansible_test/testfile"

    try:
        result_0__ = inventory_module_0.verify_file(path_0__)

        assert False
    except Exception as e_0__:
        print(e_0__)


# Generated at 2022-06-25 10:15:08.362792
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module = InventoryModule()

    # Test verify_file method of class InventoryModule
    # Filename shouldn't have an extension to pass
    # Expected result : False

    result=inventory_module.verify_file('filename')
    assert not result


# Generated at 2022-06-25 10:15:15.191475
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("Testing InventoryModule.parse")

    try:
        inventory_module_0 = InventoryModule()
        inventory_module_0.inventory = object()
        inventory_module_0.loader = object()
        inventory_module_0.set_options = object()
        inventory_module_0.get_option = object()

        inventory_module_0.parse(inventory_module_0.inventory, inventory_module_0.loader, path=os.getcwd(), cache=True)
        print("Successfully parsed the YAML inventory file")

    except AnsibleError as e:
        print("AnsibleError: " + str(e))


# Generated at 2022-06-25 10:15:22.558465
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # data
    inventory_module_pass_case_0 = InventoryModule()
    retval_pass_case_0 = inventory_module_pass_case_0.verify_file("./test_cases/test_data/inventory_plugin_yaml/yaml_pass_case_0.yml")
    assert(retval_pass_case_0 == True)
    retval_pass_case_1 = inventory_module_pass_case_0.verify_file("./test_cases/test_data/inventory_plugin_yaml/yaml_pass_case_1.yaml")
    assert(retval_pass_case_1 == True)

# Generated at 2022-06-25 10:15:27.979519
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    mock_inventory = dict()
    mock_loader = dict()
    mock_path = dict()
    test_case_string_0 = 'test_string_0'
    mock_loader.load_from_file = Mock(
        side_effect=AnsibleError('Raise exception for test_case_string_0')
    )
    mock_path.endswith = Mock(
        side_effect=AnsibleParserError('Raise exception for test_case_string_0')
    )
    with pytest.raises(AnsibleParserError):
        inventory_module.parse(mock_inventory, mock_loader, mock_path)
    # No exception was raised, this is a success


# Generated at 2022-06-25 10:15:33.656031
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_0 = InventoryModule()

    assert inventory_module_0.verify_file('/etc/ansible/hosts')==True
    assert inventory_module_0.verify_file('/etc/ansible/hosts.yaml')==True
    assert inventory_module_0.verify_file('/etc/ansible/hosts.yml')==True
    assert inventory_module_0.verify_file('/etc/ansible/hosts.json')==True


# Generated at 2022-06-25 10:15:37.568879
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = ansible.inventory.Inventory(loader=Loader(), host_list=['localhost'])
    try:
        inventory_module_0.parse(inventory=inventory_0, loader=DummyVarsModule(), path='/etc/ansible/hosts')
    except AnsibleParserError as e:
        ansible_module_0 = AnsibleModule(argument_spec={})
        ansible_module_0.fail_json(msg='Parsing the config file has failed:', details=to_text(e))


# Generated at 2022-06-25 10:16:35.320168
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file("./.gitignore") == False
    assert inventory_module.verify_file("test_yaml.yaml") == True


# Generated at 2022-06-25 10:16:45.433387
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # One test case
    inventory_module_0 = InventoryModule()
    inventory_module_0.inventory = MutableMapping()
    # input data
    loader = MutableMapping()
    path = './test/test_case_0/test_case_0.txt'
    cache = True
    # expected result
    expected_result = None
    expected_exception = AnsibleError
    # test call
    try:
        inventory_module_0.parse(inventory_module_0.inventory, loader, path, cache)
    except Exception as got_exception:
        assert isinstance(got_exception, expected_exception)
    else:
        assert inventory_module_0.inventory == expected_result


# Generated at 2022-06-25 10:16:57.420839
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0 = "adsfadsfasdf"
    assert not os.path.exists(path_0)
    assert not inventory_module_0.verify_file(path_0)
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as tempf_0:
        tempf_0.write("hehe, it worked")
        tempf_0.close()
    path_1 = tempf_0.name
    inventory_module_1 = InventoryModule()
    assert True == inventory_module_1.verify_file(path_1)
    path_2 = path_1 + '.yml'
    shutil.move(path_1, path_2)

# Generated at 2022-06-25 10:17:06.301826
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    class dummy(object):
        def __init__(self, name):
            self.name = name
    inventory_module_1.inventory = dummy('inventory_module_1.inventory')
    class dummy(object):
        def __init__(self):
            self.get_groups = []
        def add_group(self, group):
            self.get_groups.append(group)
            return group
        def get_group(self, group):
            return group
        def set_variable(self, group, var, value):
            return group
    inventory_module_1.inventory.inventory = dummy()
    class dummy(object):
        def __init__(self):
            self.plugins = []

# Generated at 2022-06-25 10:17:10.133785
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    inventory_module_0.set_options()
    inventory_path_1 = "inventory_module_data.yaml"

    assert inventory_module_0.verify_file(inventory_path_1) == True 


# Generated at 2022-06-25 10:17:15.875670
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    input_path = '/home/runner/work/inventory_plugins/inventory_plugins/playbooks/inventory/yaml/test_input_parse.yml'
    inventory_module._read_file(input_path)
    inventory_module.parse(None,None,input_path)
    output_path = '/home/runner/work/inventory_plugins/inventory_plugins/playbooks/inventory/yaml/test_output_parse.yml'
    inventory_module._write_file(output_path)



# Generated at 2022-06-25 10:17:17.591904
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file('/home/ansible/playbook/inventory') == True

# Test Case 1

# Generated at 2022-06-25 10:17:19.324209
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    path = 'valid_file.yaml'
    assert(inventory_module_1.verify_file(path))


# Generated at 2022-06-25 10:17:24.820928
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    file_name = "C:/Users/Administrator/Ansible/test.yml"
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file("C:/Users/Administrator/Ansible/test.yaml") == True
    assert inventory_module_1.verify_file("C:/Users/Administrator/Ansible/test.yml") == True
    assert inventory_module_1.verify_file("C:/Users/Administrator/Ansible/test.json") == True
    assert inventory_module_1.verify_file("C:/Users/Administrator/Ansible/test.txt") == False


# Generated at 2022-06-25 10:17:29.100617
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_verify_file = InventoryModule()
    assert inventory_module_verify_file.verify_file("/test/test_file.yaml") == True
    assert inventory_module_verify_file.verify_file("/test/test_file.txt") == False


# Generated at 2022-06-25 10:20:12.415760
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    inventory_module_0.set_options()
    #print("Head of test_case_0")
    assert inventory_module_0.verify_file("/hosts") == 0
    

# Generated at 2022-06-25 10:20:14.754912
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse(inventory_module, loader, path, cache=True)


# Generated at 2022-06-25 10:20:24.516641
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    class Inventory:
        def add_group(self, group):
            return group
        def add_host(self, host, group):
            return host
        def add_child(self, group, subgroup):
            return group
        def set_variable(self, group, var, value):
            return group
    inventory_module_1.inventory = Inventory()
    class Loader:
        def get_basedir(self, path):
            return 'basedir'
        def load_from_file(self, path, cache=True):
            return {'test' : 'test'}
    inventory_module_1.loader = Loader()
    inventory_module_1.set_options()
    inventory_module_1.verify_file('test')

# Generated at 2022-06-25 10:20:30.442227
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert(inventory_module_1.verify_file('TEST_FILE.yaml'))
    assert(inventory_module_1.verify_file('TEST_FILE.yml'))
    assert(inventory_module_1.verify_file('TEST_FILE.json'))
    assert(not inventory_module_1.verify_file('TEST_FILE.txt'))


# Generated at 2022-06-25 10:20:33.333736
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = InventoryModule()

    loader = InventoryModule()
    path = 'ansible-inventory'
    cache = True
    inventory_module.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 10:20:35.022839
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse({}, {}, '/etc/ansible/hosts')


# Generated at 2022-06-25 10:20:40.832030
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    yaml_item_0 = {"test_host": {}}
    yaml_item_0["test_host"]["hosts"] = ["test host"]
    yaml_item_0["test_host"]["children"] = []
    yaml_item_0["test_host"]["vars"] = {}
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(yaml_item_0)


if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:20:48.324885
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('./test_cases/test_case_0.yaml') == True
    assert inventory_module.verify_file('./test_cases/test_case_0.yaml.bak') == True
    assert inventory_module.verify_file('./test_cases/test_case_0.json') == True
    assert inventory_module.verify_file('./test_cases/test_case_0.txt') == False
    assert inventory_module.verify_file('./test_cases/test_case_0.php') == False
    assert inventory_module.verify_file('./test_cases/test_case_0.rb') == False


# Generated at 2022-06-25 10:20:51.917869
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    inventory_module_0.set_options()
    assert inventory_module_0.verify_file("examples/hosts") == True
    assert inventory_module_0.verify_file("examples/hosts.txt") == False


# Generated at 2022-06-25 10:21:00.291960
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

    # Test with an empty inventory file
    with open('/tmp/inventory_empty', 'w') as f:
        f.write('')
    try:
        inventory_module.parse(None, None, '/tmp/inventory_empty')
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('AnsibleParserError not raised')

    # Test with an inventory file with invalid structure
    with open('/tmp/inventory_invalid', 'w') as f:
        f.write('---\n')
        f.write('\ntest:\n')
    try:
        inventory_module.parse(None, None, '/tmp/inventory_invalid')
    except AnsibleParserError:
        pass