

# Generated at 2022-06-25 10:11:42.466058
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    data_0 = dict()
    loader_0 = None
    path_0 = '_2Q'
    cache_0 = None
    inventory_module_0.parse(data_0, loader_0, path_0, cache=cache_0)


# Generated at 2022-06-25 10:11:47.485172
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0 = '/dev/null'
    bool_0 = inventory_module_0.verify_file(path_0)
    assert bool_0 == False


# Generated at 2022-06-25 10:11:48.577015
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert False


# Generated at 2022-06-25 10:11:50.144167
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('inventory', 'loader', 'path', cache=True)


# Generated at 2022-06-25 10:11:55.216587
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_1 = InventoryModule()
    loader_0 = inventory_module_0.loader
    path_0 = 'w]`b\xde\xe4\xeb\xe1\x9c\x95S\xef'
    path_1 = 'w]`b\xde\xe4\xeb\xe1\x9c\x95S\xef'
    inventory_module_1.parse(inventory_module_0, loader_0, path_0, cache=False)
    inventory_module_1.parse(inventory_module_0, loader_0, path_1, cache=False)


# Generated at 2022-06-25 10:12:01.076269
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Test for simple string
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file('test_file_name') == False, 'verify_file() function failed for simple string'

    # Test for string with extension
    assert inventory_module_0.verify_file('test_file_name.yaml') == True, 'verify_file() function failed with extension'


# Generated at 2022-06-25 10:12:03.021797
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    inventory_module_1.parse()


# Generated at 2022-06-25 10:12:10.080133
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory=
    inventory_module_0
    , loader=MockAnsibleLoader()
    , path=
    './test/inventory/test_data/test.yaml'
    )

# Generated at 2022-06-25 10:12:15.381531
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0 = 'D\xce\xfeB\xf1\x12\x13\xac\x90'
    assert inventory_module_0.verify_file(path_0) == False


# Generated at 2022-06-25 10:12:26.413834
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.inventory import BaseFileInventoryPlugin
    inventory_module_1 = InventoryModule()
    inventory_1 = Dummy()
    loader_1 = Dummy()
    path_1 = 'test'
    cache_1 = True
    # Test T1
    try:
        inventory_module_1.parse(inventory_1, loader_1, path_1, cache_1)
    except AnsibleError as e:
        print(e)
        assert type(e) == AnsibleError
    else:
        assert False, 'AnsibleError expected'
    # Test T2
    loader_2 = Dummy()
    # Test T3
    inventory_3 = Dummy()
    loader_3 = Dummy()
    path_3 = 'test'
    cache_3 = True
    # Test T4


# Generated at 2022-06-25 10:12:43.869642
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = inventory_module_0.inventory
    loader_0 = inventory_module_0.loader
    path_0 = '/vagrant/inventory'
    cache_0 = False
    # excercise the method
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)



# Generated at 2022-06-25 10:12:49.455771
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(bytearray([98, 97, 115, 104]), bytearray, b'\xbc\x8a\x91\x1a`')  # 1. arg (x, y, z)


# Generated at 2022-06-25 10:12:58.200128
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inc = 'ansible/inventory'
    inventory_module_2 = InventoryModule()
    inventory_module_2.set_options(
        { 'yaml_extensions': ('.yaml', '.yml', '.json') }
    )
    inventory_module_3 = InventoryModule()
    inventory_module_3.set_options(
        { 'yaml_extensions': ('.yaml', '.yml', '.json') }
    )
    inventory_module_4 = InventoryModule()
    inventory_module_4.set_options(
        { 'yaml_extensions': ('.yaml', '.yml', '.json') }
    )

    if (not os.path.isdir(inc)):
        os.mkdir(inc)

# Generated at 2022-06-25 10:13:06.791539
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    data = '''
    all:
        hosts:
            test1:
        vars:
            group_all_var: value
        children:
            other_group:
                children:
                    group_x:
                        hosts:
                            test5
                    group_y:
                        hosts:
                            test6
                vars:
                    g2_var2: value3
                hosts:
                    test4:
                        ansible_host: 127.0.0.1
            last_group:
                hosts:
                    test1 # same host as above, additional group membership
                vars:
                    group_last_var: value
    '''

    inventory_module = InventoryModule()


# Generated at 2022-06-25 10:13:18.080634
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    str_0 = '\x0c\xca\xd5\x1b\xd8\xbf4\x08x&\xe5\t'
    str_1 = '\x86\x9d\xb8\x07\xac\xe0\xe5\x07\x84\xba\xed'
    str_2 = '\xee\xdc\xfc\xf7\x97\xd8\x99\xa2\x9f\xb6\x8c;#\x1c'
    str_3 = 'Y\xe0\xaf\x08m\x9aZ\x94\x82\xfd'
    path_0 = os.path.join(str_0, str_1)

# Generated at 2022-06-25 10:13:19.997258
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0 = b'/usr/local/share/gir-1.0'
    # State assertions
    assert inventory_module_0.verify_file(path_0) == False


# Generated at 2022-06-25 10:13:25.624944
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_test_0 = InventoryModule()
    path_test_0 = 'test_value'
    result_test_0 = inventory_module_test_0.verify_file(path_test_0)
    assert result_test_0 is False


# Generated at 2022-06-25 10:13:27.164246
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse("inventory", "loader", "path")


# Generated at 2022-06-25 10:13:29.241634
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    path = None
    loader = None
    inventory = None
    inventory_module_0.parse(inventory, loader, path)


# Generated at 2022-06-25 10:13:36.013849
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_file = os.path.join(os.path.dirname(__file__), "../test_data/yaml_inventory_1.yaml")
    test_data = open(test_file, 'r').read()

    import json
    test_data_json = json.loads(test_data)
    test_data_json['plugin'] = "dummy"

    from ansible.inventory.data import InventoryData
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import inventory_loader
    from ansible.plugins.inventory import BaseInventoryPlugin
    from ansible.errors import AnsibleParserError

    loader = DataLoader()
    inv_data = InventoryData(loader=loader)
    group = inv_data.add_group('all')
    inv_data._inventory

# Generated at 2022-06-25 10:14:00.740186
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    bytes_1 = b'\x8d\x8b\x0f\x9e\x13\x8d\x53\x93\x1d\x80'
    inventory_1 = MockInventory()
    bytes_2 = b'\xbb\xb7\xe0\x1f\x8d\x83\xd6\xda\x8a\xaf'
    loader_1 = MockLoader()
    str_1 = '\x0c\xfc\xfa\x8f\xa0\x88\xf1\x87\x8f\xde'
    path_1 = '\x05\x95\xf3\x98\xa4\x8d\xeb\xc2\x9c\x87'
   

# Generated at 2022-06-25 10:14:09.865391
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-25 10:14:15.320898
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    data = {}
    group = "test_group"
    group_data = {'vars': {'a': 'b'}}
    inventory_module.display = None
    inventory_module._parse_group(group, group_data)
    assert "test_group" in data

# Generated at 2022-06-25 10:14:22.526424
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_0 = InventoryModule()
    param_0 = 20
    file_name_0 = '/etc/hosts'
    inventory_module_0.get_option = MagicMock(return_value = param_0)
    var_0 = inventory_module_0.verify_file(file_name_0)
    var_1 = inventory_module_0.get_option
    var_1.assert_called_with('yaml_extensions')
    assert not var_0


# Generated at 2022-06-25 10:14:23.760974
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()


# Generated at 2022-06-25 10:14:28.057530
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0 = b'\xea\x15\xbfz\xb4\x8a\x9e\xb3\x9f#\xa6i\x84'


# Generated at 2022-06-25 10:14:34.415235
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    inventory_module_0.parse()

if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:14:38.947992
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    bytes_0 = b'D\x0e\x1b\xb6\xcf\xee\x95\x9e'
    bytes_1 = b'\x1b\xf4\x8a\xdd!\xed\x99\xbe\x9a\x00\x0b'
    bytes_2 = b'\x1d\xbb\x00\x1f\xfc\x84\x94\xdc\xc1\xfe\xe7\xeff\xa2\x15\xd9A\x10'
    ansible_inventory_0 = AnsibleInventory()
    ansible_loader_0 = AnsibleLoader()

# Generated at 2022-06-25 10:14:43.629612
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = 'S\x8f?\xb0"\xe6\x8f\x8e\x88\x1d}\x92&\x10\xfa\xdf\xf59g\xbc\xe8\xc1\x1a\xaa\x9c\x8a\x960K!'
    assert inventory_module_0.verify_file(path) == False

# Generated at 2022-06-25 10:14:53.747297
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    # for future ref: '''Parsed empty YAML file'''
    try:
        inventory_module_0.verify_file()
        assert False
    except Exception as e:
        assert e.args[0] == "takes exactly 2 arguments (1 given)"

    try:
        inventory_module_0.verify_file(1)
        assert False
    except Exception as e:
        assert e.args[0] == "takes exactly 2 arguments (1 given)"


# Generated at 2022-06-25 10:15:29.748116
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = None
    loader = None
    path = 'A1'
    cache = True

    try:
        inventory_module.parse(inventory, loader, path, cache)
    except (AnsibleError, AnsibleParserError) as exception:
        return 'AnsibleError' in str(exception)
    return False


# Generated at 2022-06-25 10:15:32.735830
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_2 = InventoryModule()
    str_2 = 'inventory_plugin_yaml'
    bool_2 = inventory_module_2.verify_file(str_2)
    assert bool_2 == True


# Generated at 2022-06-25 10:15:34.166769
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0_class = InventoryModule
    inventory_module_0_obj = inventory_module_0_class()
    inventory_module_0_obj.parse()


# Generated at 2022-06-25 10:15:40.187219
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    bytes_1 = b'w%r\xe0\x1e\xd9\xb8D\xa9Aj\x11'
    mutable_mapping_1 = MutableMapping()
    str_1 = str(mutable_mapping_1)
    file_loader_1 = FileLoader()
    str_2 = str(file_loader_1)
    ansible_inventory_1 = AnsibleInventory()
    str_3 = str(ansible_inventory_1)
    inventory_module_1.parse(ansible_inventory=ansible_inventory_1, loader=file_loader_1, path=str_2, cache=False)


# Generated at 2022-06-25 10:15:50.372835
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 10:16:01.815281
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    inventory_module_0.loader = DictDataLoader()
    inventory_module_0.loader.set_basedir('/etc/ansible/test_project')

    # Test 1

# Generated at 2022-06-25 10:16:04.125185
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    path = "path"
    assert inventory_module.verify_file(path) == False


# Generated at 2022-06-25 10:16:13.854086
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    bytes_1 = b'\x87\xd3\x14Q\x90\xc8\x8c\xcb\x0e\xc4\xa4\x8e\x93\x94\x11'
    bytes_2 = b'\x0e\x84\x9f0\xd4\xab\xdfc\x81\x8c\xaf\xcd\xa0\x9a'
    bytes_3 = b'\x1c\x0e\xb8\xed\x1c\xb9\xd6M\xf6\x81\x90'
    within_1, within_2, within_3 = str(), str(), str()
    inventory_module_1.set_options()


# Generated at 2022-06-25 10:16:18.869621
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = None
    loader_0 = None
    path_0 = bytes_0 = b'w%r\xe0\x1e\xda\xb8D\xa9Aj\x11'
    inventory_module_0.parse(inventory_0, loader_0, path_0)
    assert inventory_0
    assert loader_0
    assert path_0 == bytes_0

test_case_0()

# vim: set ai et ts=4 sw=4 :

# Generated at 2022-06-25 10:16:27.109501
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = 'Ansible Inventory'
    loader_0 = to_text('lS\xef\x90\xfb%U\x19\xcf\x03\xdeLW\xc8\x87\x18\xd7\xba\x8b\xd9')
    path_0 = b'\xa2\x18\xbf/\x1e\xda\xe3\x9d\x10\xc7\x94\xd8l\x82J\xbb\xee\x1a'
    cache_0 = 2131440122
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0, 1)


# Generated at 2022-06-25 10:17:28.630280
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_2 = InventoryModule()
    assert (inventory_module_2.verify_file() == True)


# Generated at 2022-06-25 10:17:37.984060
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0 = 'forjnVCGh-NsUV\\'
    inventory_module_0.set_options({'yaml_extensions': ['.ljK', '.sdV', '.tZF', '.ybP']})
    assert inventory_module_0.verify_file(path_0) == True
    inventory_module_0.set_options({'yaml_extensions': ['.ZjY', '.hVK', '.AyN', '.Sms']})
    assert inventory_module_0.verify_file(path_0) == False
    inventory_module_0.set_options({'yaml_extensions': ['.hJx', '.BJi', '.YRI']})

# Generated at 2022-06-25 10:17:39.032515
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    assert (inventory_module.parse(
        'exact_match', 'key_filename', True, 'module_name') == None)


# Generated at 2022-06-25 10:17:45.209832
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import re
    import hashlib
    import collections
    import yaml
    inventory_module_0 = InventoryModule()
    int_0 = 0
    while int_0 < 50:
        file_name_0 = 'test_case_0'
        file_path_0 = 'tests/inventory_plugins/yaml_test_cases/test_case_0.yml'
        path_0 = file_path_0
        cache_0 = True
        data_0 = inventory_module_0._parse_host(file_name_0)
        data_1 = yaml.safe_load(open(path_0).read())
        vars_0 = data_1.get('plugin')
        data_2 = inventory_module_0.verify_file(path_0)

# Generated at 2022-06-25 10:17:54.337493
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module_path = b'/tmp/inventory_module_file'
    inventory_module_data = {'plugin': 'test_inventory_module_data_plugin', 'something': 'test_inventory_module_data_something'}
    inventory_module_cache = True
    class DummyInventory():
        def __init__(self):
            self.hosts = {b'host2': {}, b'host1': {}, b'host3': {}}

# Generated at 2022-06-25 10:18:01.157656
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    inventory_module_0._options = dict()
    inventory_module_0._options['yaml_extensions'] = ['json', 'yaml', 'yml']
    inventory_module_0.loader = dict()
    inventory_module_0.loader['_basedir'] = '~/Python/ansible'
    bool_0 = inventory_module_0.verify_file('/etc/passwd')
    assert bool_0 == False


# Generated at 2022-06-25 10:18:06.162423
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = inventory_module_0.inventory
    loader_0 = inventory_module_0.loader
    path_0 = 't0'
    cache_0 = True
    (test_0, test_1) = inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)
    assert test_0 != None
    assert test_1 != None
    assert test_1 == True


# Generated at 2022-06-25 10:18:09.745625
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = dict()
    path_0 = 'j\x14\xbf\x92\x1e\xfe\x8c\x014!\x93c'
    inventory_module_0.parse(inventory_0, path_0)


# Generated at 2022-06-25 10:18:11.614878
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    path = b'inventory.useful'
    inventory_module.verify_file(path)


# Generated at 2022-06-25 10:18:15.057963
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_rv_1 = InventoryModule()
    bytes_rv_1 = b'\x86\xac\x91\x90\x1e\xfb\\'


# Generated at 2022-06-25 10:20:38.066881
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    str_0 = to_text(b'6\xb1\x92\xef\x16\xfc\x85\xba\xf8\x97\xa0\xbd\x01\x15\x0e\x88\x90\xb6\xa8\n\x1f\x9b\x12\x8b\xe2\x0b\xad\xa4\xc1\xbd\xb4\xcc\xf4\x8a\x03\x00\x16')

# Generated at 2022-06-25 10:20:42.048264
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = None
    loader_0 = None
    path_0 = '_i,$}a/|L'
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)


# Generated at 2022-06-25 10:20:46.237574
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Setup fixture
    inventory_module_0 = InventoryModule()
    path_0 = '='
    loader_0 = MockModuleLoader()
    inventory_0 = MockInventory()

    # Invoke method
    inventory_module_0.parse(inventory_0, loader_0, path_0)

    # Check results
    assert inventory_0.add_group.call_count == 0



# Generated at 2022-06-25 10:20:49.686129
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    bytes_0 = b'\x1e\xb1\x88\xdc[&\xe4>\xc5\x9d\x1c\x85\x80\x8d'

    # AssertionError: 'Parsed empty YAML file'
    inventory_module_0.parse(data=bytes_0)


# Generated at 2022-06-25 10:20:53.268262
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Setup
    inventory_module_1 = InventoryModule()
    loader_loader_1 = BaseFileInventoryPlugin.loader.loader(path='/dev/null')
    loader_loader_1 = BaseFileInventoryPlugin.loader.loader(path='/dev/null')
    cache_2 = True

    # Testing
    inventory_module_1.parse(loader_loader_1, loader_loader_1, '/dev/null', cache_2)

    # Teardown
    pass


# Generated at 2022-06-25 10:20:55.030594
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    inventory_module_0.verify_file(path=bytes_0)


# Generated at 2022-06-25 10:21:02.398128
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = Inventory(loader=None, variable_manager=None, host_list=[])
    loader_0 = DataLoader()
    path_0 = 'Yw\x05\xa2\xcb\xf9\x1f\xa8\x1e\xae\xc0\xfb\xf8\xbb\xd0\x12\x9d\x8a'
    cache_0 = False
    try:
        inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)
    except AnsibleError as e:
        assert "expected dictionary and got:\n\n" in str(e)


# Generated at 2022-06-25 10:21:06.136733
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_0 = InventoryModule()
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    bytes_1 = b'\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b'
    bytes_2 = b'\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b'
    bytes_3 = b'\x1b\x1b\x1b\x1b\x1b\x1b\x1b\x1b'

# Generated at 2022-06-25 10:21:08.717577
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    content = 'foo: bar'
    data = {u'foo': u'bar'}

    inventory_module = InventoryModule()
    inventory_module._parse_group('group', data)

if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:21:11.349558
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    filepath = '../../test/plugin/inventory-data/yaml/hosts.yml'
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('', '', filepath)

if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()