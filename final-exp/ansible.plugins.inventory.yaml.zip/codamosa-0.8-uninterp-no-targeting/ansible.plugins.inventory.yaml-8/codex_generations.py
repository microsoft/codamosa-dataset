

# Generated at 2022-06-21 05:32:44.865068
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    m_cls = type('Module', (), {'params': {'name': 'value'}})
    m_args = type('ModuleArgs', (), {'params': {}, '_ansible_debug': True})
    i = m_cls()
    a = m_args()
    i.args = a
    i.args.params = {'name': 'value', 'not_relevant': 'value'}
    i.name = 'name'
    i.path = 'tests/test_data/hosts'
    i.loader = None
    try:
        i.parse(i, a, i.path)
        assert False
    except(AnsibleParserError):
        assert True

# Generated at 2022-06-21 05:32:51.476882
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    """
    Test for method verify_file

    Test for method verify_file of class InventoryModule.

    :return: None
    """
    retval = InventoryModule().verify_file('test')
    if retval:
        print("InventoryModule.verify_file returns True for file name test")
    else:
        print("InventoryModule.verify_file returns False for file name test")


# Generated at 2022-06-21 05:33:02.757582
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    examples = EXAMPLES.split("\n")
    input_data = examples[2:]
    plugin = InventoryModule()

    # add lines of example to ansible.cfg
    plugin._config_data = []
    for line in examples:
        plugin._config_data.append(line)

    inventory = plugin.parse(inventory=None, loader=None, path=None, cache=True)

    # check if both groups are the same and have the same structure
    # check if both groups are the same and have the same structure
    assert input_data[0] == "all: # keys must be unique, i.e. only one 'hosts' per group"

    for line in input_data:
        if "other_group:" in line:
            assert line == "other_group:"
            break

# Generated at 2022-06-21 05:33:05.643048
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    assert inventory_module is not None
    assert isinstance(inventory_module, BaseFileInventoryPlugin)

# Generated at 2022-06-21 05:33:09.822508
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    assert im
    assert im.NAME == im.__class__.__name__.lower()


# Generated at 2022-06-21 05:33:13.688809
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    # test the constructor and get_option method
    assert module is not None, "Failed to create InventoryModule instance"
    assert module.get_option('yaml_extensions') == ['.yaml', '.yml', '.json'], 'Failed to get expected yaml_extensions options from InventoryModule'


# Generated at 2022-06-21 05:33:23.823397
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    yaml_file_extensions = ['.yaml', '.yml', '.json']

    # (file_exist, file_valid, file_ext)
    test_cases = [
        [True, False, '.invalid_ext'],
        [False, False, '.invalid_ext'],
        [True, True, '.yaml'],
        [True, True, '.yml'],
        [True, True, '.json'],
        [True, False, '.txt']
    ]

    module = InventoryModule()


# Generated at 2022-06-21 05:33:30.258500
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    class Options():
        yaml_extensions = ['.yaml', '.yml']

    class Inventory():
        def __init__(self):
            self.sources = None
            self.sources_counts = None

        def add_group(self, group_name):
            return group_name

        def add_child(self, group, subgroup):
            self.group = group
            self.subgroup = subgroup

        def set_variable(self, group, var, value):
            self.group = group
            self.var = var
            self.value = value

    class InventoryModule(InventoryModule):
        def __init__(self):
            self.plugin_name = 'yaml'
            self.options = Options()
            self.inventory = Inventory()

    im = InventoryModule()

# Generated at 2022-06-21 05:33:32.597416
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
        '''
        This is a basic unit test for constructor of class InventoryModule()
        '''
        yaml_obj = InventoryModule()
        if yaml_obj.NAME == 'yaml':
            print ("test_InventoryModule: Test Passed")
        else:
            print ("test_InventoryModule: Test Failed")


# Generated at 2022-06-21 05:33:36.455280
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    assert inv_mod is not None


# Generated at 2022-06-21 05:33:49.497812
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    x = InventoryModule()
    assert x.NAME == 'yaml'


# Generated at 2022-06-21 05:33:55.588838
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    inv = InventoryManager(
        loader=DataLoader(),
        sources=['localhost,']
    )
    inv.clear_pattern_cache()

    inv_plugin = InventoryModule()
    inv_plugin.parse(inv, None, None, cache=False)

# Generated at 2022-06-21 05:34:05.782862
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    c = InventoryModule()
    assert c.NAME == 'yaml'
    assert c._plugin_config_file == 'plugins/inventory/yaml.yaml'
    assert c.loader == 'yaml'
    assert c.options_cache == {}

    assert c.verify_file('test.yaml') == True
    assert c.verify_file('test.ini') == False

    c.parse('inventory', 'loader', 'path', cache=True)
    c._parse_group('group', None)
    c._parse_host('host_pattern')

# Generated at 2022-06-21 05:34:09.487701
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Test with valid extension
    assert InventoryModule().verify_file('file.yml')
    # Test with invalid extension
    assert not InventoryModule().verify_file('file.invalid')

# Generated at 2022-06-21 05:34:21.408374
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import yaml
    yml_text = '''
all:
    hosts:
        localhost:
        host.example.com:
            ansible_host: 1.2.3.4
    children:
        webservers:
        dbservers:
        region:
            children:
                us_east:
                    hosts:
                        host.example.com:
                    vars:
                        region: us-east
                        asn: 1234
        asn:
            hosts:
                host.example.com:
            vars:
                asn: 1234
    vars:
        region: us-east
        asn: 4321
'''
    yml_data = yaml.safe_load(yml_text)
    yml_inv = InventoryModule()

# Generated at 2022-06-21 05:34:27.543872
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import ansible.plugins.inventory.yaml
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader, sources=['all:hosts'])
    inventory = inventory_manager.get_inventory()
    im = ansible.plugins.inventory.yaml.InventoryModule()
    im.parse(inventory, loader, 'tests/unit/plugins/inventory/data/valid.yaml')

    print("helo")

# Generated at 2022-06-21 05:34:40.044102
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import os
    import json
    from ansible.parsing.dataloader import DataLoader

    # Get the current directory
    current_dir = os.path.dirname(os.path.realpath(__file__))

    # Read the file
    with open(current_dir + "/hosts", 'r') as f:
        data = f.read()

    # Create a new DataLoader and load the data
    loader = DataLoader()
    data = loader.load(data)

    # Create the InventoryModule object
    yaml_inv = InventoryModule()

    # Create a new Inventory object
    inv = yaml_inv.inventory

    # Call the parse method for the data
    yaml_inv.parse(inv, loader, 'hosts', cache=True)

    # Check the groups
    groups = inv.groups
   

# Generated at 2022-06-21 05:34:47.864786
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    inv = InventoryModule()
    print("Unit test for InventoryModule class")
    assert inv.verify_file("test") is False
    assert inv.verify_file("test.yml") is True
    assert inv.verify_file("test.yaml") is True
    assert inv.verify_file("test.json") is True
    assert inv.verify_file("test.other") is False

    print("Unit test for InventoryModule ends")

if __name__ == '__main__':
    test_InventoryModule()

# Generated at 2022-06-21 05:34:50.187499
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    my_obj = InventoryModule()
    assert isinstance(my_obj, InventoryModule)


# Generated at 2022-06-21 05:34:51.586106
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv is not None


# Generated at 2022-06-21 05:35:13.079167
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins
    plugin_loader.add_directory(os.path.join(os.path.dirname(ansible.plugins.__file__), 'inventory'))
    from ansible.compat import selectors

    im = plugin_loader.get_plugin_loader('inventory').all()['yaml']()
    # test for methods in super-class
    for method in ['parse', 'verify_file']:
        assert hasattr(im, method)
    # test for methods in this class
    for method in ['_parse_group', '_parse_host']:
        assert hasattr(im, method)


# Generated at 2022-06-21 05:35:15.838836
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_module =  InventoryModule()
    inv_module.parse(None, None, 'inventory_plugins/test_yaml_inventory')


# Generated at 2022-06-21 05:35:19.508413
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import ansible.plugins.inventory.yaml
    assert ansible.plugins.inventory.yaml.InventoryModule.NAME == 'yaml'



# Generated at 2022-06-21 05:35:21.472054
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module.NAME == 'yaml'

# Generated at 2022-06-21 05:35:23.245515
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.NAME == 'yaml'

# Generated at 2022-06-21 05:35:29.728011
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-21 05:35:35.652703
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = {}
    loader = {}
    path = 'example.yaml'
    cache = True

    try:
        inventory_module.parse(inventory, loader, path, cache)
    except Exception as error:
        print('Error: ' + repr(error))
    else:
        print('Success!\n')

if __name__ == '__main__':

    test_InventoryModule_parse()

# Generated at 2022-06-21 05:35:37.913043
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    inv.verify_file("hosts.yaml")

# Generated at 2022-06-21 05:35:42.456334
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """
    Unit test for constructor of class InventoryModule
    """
    yaml_plugin = InventoryModule()
    assert isinstance(yaml_plugin, InventoryModule)



# Generated at 2022-06-21 05:35:45.500387
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    doc = InventoryModule.__doc__
    assert doc.startswith(' parses the inventory file '), 'incorrect doc string'

# Generated at 2022-06-21 05:36:10.117494
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_data = '''
all:
    hosts:
        "test1":
        "test2":
            host_var: value
    vars:
        group_all_var: value
    children:
        other_group:
            children:
                group_x:
                    hosts:
                        test5
                group_y:
                    hosts:
                        test6:
            vars:
                g2_var2: value3
            hosts:
                test4:
                    ansible_host: 127.0.0.1
        last_group:
            hosts:
                test1
            vars:
                group_last_var: value
    '''

    inv_file = 'test_inventory'
    with open(inv_file, 'w') as f:
        f.write(inv_data)


# Generated at 2022-06-21 05:36:18.550287
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # unit tests
    config = {'yaml_extensions': ['.yaml', '.yml', '.json']}

    inv = InventoryModule()
    inv.set_options(config)

    assert inv.verify_file('/path/to/yaml/file.yaml') is True
    assert inv.verify_file('/path/to/yaml/file.yml') is True
    assert inv.verify_file('/path/to/yaml/file.json') is True
    assert inv.verify_file('/path/to/yaml/file.txt') is False
    assert inv.verify_file('/path/to/yaml/file') is True

test_InventoryModule_verify_file()

# Generated at 2022-06-21 05:36:31.898422
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-21 05:36:40.489530
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    im = InventoryModule()
    actual = im.verify_file(path='')
    assert actual == False
    actual = im.verify_file(path='/tmp/a')
    assert actual == False
    actual = im.verify_file(path='/tmp/a.yaml')
    assert actual == True
    actual = im.verify_file(path='/tmp/a.json')
    assert actual == True


# Generated at 2022-06-21 05:36:48.519514
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    myobj = InventoryModule()
    myobj.set_options()
    valid = myobj.verify_file('test.yaml')
    assert(valid == True)
    valid = myobj.verify_file('test.json')
    assert(valid == True)
    valid = myobj.verify_file('test.txt')
    assert(valid == False)



# Generated at 2022-06-21 05:36:52.669972
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    plugin = InventoryModule()
    plugin.parse(inventory={}, loader={}, path={}, cache=True)
    plugin.verify_file(path={})
    plugin.__init__()


# Generated at 2022-06-21 05:37:04.366499
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    InventoryModule.verify_file(
        './test/unit/plugins/inventory/test.yaml',
        DataLoader(),
        InventoryManager(),
        './test/unit/plugins/inventory/test.yaml'
    )
    InventoryModule.verify_file(
        './test/unit/plugins/inventory/test.json',
        DataLoader(),
        InventoryManager(),
        './test/unit/plugins/inventory/test.json'
    )
    InventoryModule.verify_file(
        './test/unit/plugins/inventory/test.yml',
        DataLoader(),
        InventoryManager(),
        './test/unit/plugins/inventory/test.yml'
    )
   

# Generated at 2022-06-21 05:37:14.852738
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Unit test for method parse of class InventoryModule
    """
    import mock
    import pprint
    import StringIO
    import sys
    import yaml

    def _inventory_get_host_variables(inventory, host):
        """
        Helper method to get host variables
        """
        host_vars = {}
        if host in inventory._hosts_cache:
            host_vars = inventory._hosts_cache[host].get_vars()
            host_vars['inventory_hostname'] = host
            host_vars['inventory_hostname_short'] = host.split('.')[0]

        return host_vars

    def _inventory_get_group_variables(inventory, group):
        """
        Helper method to get group variables
        """
        group_vars = {}

# Generated at 2022-06-21 05:37:15.749690
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()

# Generated at 2022-06-21 05:37:18.008302
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_mod = InventoryModule()
    assert isinstance(inventory_mod.loader, BaseFileInventoryPlugin)

# Generated at 2022-06-21 05:37:57.567058
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    yaml_verify_file = InventoryModule()
    yaml_verify_file.set_options()
    if not yaml_verify_file.verify_file('inventory1.yaml'):
        raise AssertionError('inventory1.yaml is a valid yaml file')
    if yaml_verify_file.verify_file('inventory2.yml'):
        raise AssertionError('inventory2.yml is not a valid yaml file')
    if yaml_verify_file.verify_file('inventory3.json'):
        raise AssertionError('inventory3.json is not a valid yaml file')
    if yaml_verify_file.verify_file('inventory4.txt'):
        raise AssertionError('inventory4.txt is not a valid yaml file')


# Generated at 2022-06-21 05:37:59.522852
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    assert module.verify_file('.yml') == True
    assert module.verify_file('.yaml') == True


# Generated at 2022-06-21 05:38:01.451214
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert inventory is not None

# Generated at 2022-06-21 05:38:10.728446
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # Init class
    inventory_module = InventoryModule()

    # Test with a valid file
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)),'../data/test_yaml_plugin_inventory.yml')

    # Test without setting the yaml_extensions option
    inventory_module.set_options({})
    assert inventory_module.verify_file(path)

    # Test with a matching file extension in the list
    inventory_module.set_options({'yaml_extensions': ['.yaml']})
    assert inventory_module.verify_file(path)

    # Test with a matching file extension in the list
    inventory_module.set_options({'yaml_extensions': ['.yaml', '.json']})
    assert inventory_module.ver

# Generated at 2022-06-21 05:38:17.267514
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('test.yml') == True
    assert inventory_module.verify_file('test.yaml') == True
    assert inventory_module.verify_file('test.json') == True
    assert inventory_module.verify_file('test') == False

# Generated at 2022-06-21 05:38:18.770781
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule


# Generated at 2022-06-21 05:38:23.969271
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    inventory_module.parse("", "inventory", "test_data.yaml")
    print(inventory_module)

if __name__ == '__main__':
    test_InventoryModule()

# Generated at 2022-06-21 05:38:27.782038
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    '''
    Test module is correctly loaded by Ansible
    '''
    assert hasattr(InventoryModule, 'verify_file'), 'method verify_file() not in class InventoryModule'


# Generated at 2022-06-21 05:38:31.428401
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert isinstance(InventoryModule(), InventoryModule)
    assert isinstance(InventoryModule.parse, object)
    assert isinstance(InventoryModule.verify_file, object)

# Generated at 2022-06-21 05:38:41.091484
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    loader = DictDataLoader({
        'test.yaml': """
all:
    hosts:
        test1:
            subvariable: 123
        test2:
            subvariable: 1234
            subvariable_test: 12
    vars:
        group_all_var: value
    children:
        group2:
            hosts:
                test3:
            vars:
                g2_var: value2
        group3:
            hosts:
                test4:
            vars:
                g3_var: value3
        group4:
            vars:
                g4_var: value4
                """})

    inv = InventoryModule()
    inv.set_options()
    inv.loader = loader
    inv.parse("/dev/null", loader, "test.yaml")

    # global v

# Generated at 2022-06-21 05:39:53.670176
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    for path in ("myhosts.yaml", "/Users/johndoe/myhosts.yaml",
                 "myhosts.yml", "/Users/johndoe/myhosts.yml",
                 "myhosts.json", "/Users/johndoe/myhosts.json"):
        assert InventoryModule().verify_file(path)
    assert not InventoryModule().verify_file("/Users/johndoe/myhosts.txt")
    assert not InventoryModule().verify_file("/Users/johndoe/myhosts")

# Generated at 2022-06-21 05:40:06.098045
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Verify that check for empty extension succeeds
    assert InventoryModule.verify_file("foo.yml") == True

    # Verify that check for empty extension succeeds
    assert InventoryModule.verify_file("foo.yaml") == True

    # Verify that check for empty extension succeeds
    assert InventoryModule.verify_file("foo.json") == True

    # Verify that check for other extension fails
    assert InventoryModule.verify_file("foo.yaml.swp") == False

    # Verify that check for other extension fails
    assert InventoryModule.verify_file("foo.yml.swp") == False

    # Verify that check for other extension fails
    assert InventoryModule.verify_file("foo.json.swp") == False

    assert InventoryModule.verify_file("foo.ymlswp") == True

    assert InventoryModule

# Generated at 2022-06-21 05:40:17.301246
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins import group_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    x = InventoryModule()
    x._inventory = MagicMock()
    x.loader = DataLoader()
    x.set_options()

# Generated at 2022-06-21 05:40:18.729039
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert False, "Test not implemented"


# Generated at 2022-06-21 05:40:27.508152
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    import sys
    sys.path.insert(0, 'plugins/inventory')
    import yaml

    inventory_module = InventoryModule()
    inventory_module.verify_file = lambda path: True

    for path in ['tests/inventory/yaml_inventory', 'tests/inventory/yaml_plugin_inventory']:
        data = yaml.load(open(path, 'r').read())

        if not isinstance(data, MutableMapping):
            raise AnsibleParserError('YAML inventory has invalid structure, it should be a dictionary, got: %s' % type(data))

        inventory_module.parser.parse(inventory_module._get_base_path(path), data)
        #  print(yaml.dump(inventory_module.inventory.get_groups_dict(),
        #                  default_flow_style=False))


# Generated at 2022-06-21 05:40:30.714737
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    print("\n### Test of class constructor InventoryModule() ###\n")
    inv = InventoryModule()
    assert inv is not None


# Generated at 2022-06-21 05:40:39.265427
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    import sys
    import os
    import json
    import unittest
    from collections import namedtuple
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import inventory_loader

    class DummyConfig:
        def __init__(self):
            self.cache = False
            self.vault_password = 'bla'
            self.enable_plugins = 'YAML'

    class Options:
        def __init__(self):
            self.inventory = None

    class C:
        def __init__(self):
            self.options = Options()
            self.config = DummyConfig()

# Generated at 2022-06-21 05:40:42.336299
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryModule()

    loader = DataLoader()

    path = './test.yml'

    inventory.parse(inventory, loader, path)
    assert inventory.NAME == 'yaml'


# Generated at 2022-06-21 05:40:49.881091
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from io import StringIO
    example_yaml = '''
    all:
        hosts:
            host1:
        vars:
            group_all_var: value
        children:
            group1:
                hosts:
                    host2:
                vars:
                    group1_var: value
                children:
                    group1_1:
                        hosts:
                            host3:
                        vars:
                            group1_1_var: value
            group2:
                hosts:
                    host4:
                vars:
                    group2_var: value
    '''

# Generated at 2022-06-21 05:41:00.208184
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import json

    # params
    test_data = {"plugin": "yaml",
                 "hosts": ["host1", "host2"],
                 "children": {},
                 "vars": {}}

    test_positions = [(None, None, None),
                      ("host_name", None, None),
                      ("host_name", "group_name", None),
                      ("host_name", "group_name", 1234),
                      ("host_name", "group_name", None)]

    # start test
    im_obj = InventoryModule()
    im_obj.parse("inventory", "loader", "path_to_file")

    assert isinstance(im_obj, InventoryModule)
    assert isinstance(im_obj.loader, string_types)
    assert isinstance(im_obj.inventory, string_types)