

# Generated at 2022-06-21 05:32:44.813090
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    group_vars = dict(
        group_var1='value1',
        group_var2='value2'
    )

    host_vars = dict(
        host_var1='value1',
        host_var2='value2'
    )

    inventory = InventoryManager(loader=DataLoader(), sources=None)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    plugin = InventoryModule()
    plugin.parse(inventory, loader=plugin.loader, path='test_InventoryModule_parse.yaml')

    # Test groups

# Generated at 2022-06-21 05:32:54.524993
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import sys
    import io
    import yaml
    sys.path.append('lib/ansible/plugins/inventory')
    import InventoryModule as imclass
    im = imclass.InventoryModule()
    im.loader = yaml.SafeLoader
    im.set_options()
    im.inventory = im.inventory_class()

# Generated at 2022-06-21 05:33:01.227468
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_mod = InventoryModule()
    # Test with invalid file name
    assert(inv_mod.verify_file('/dev/null') is False)
    # Test with valid file name
    assert(inv_mod.verify_file('test_file.yaml') is True)
    # Test with valid file name and unsupported extension
    assert(inv_mod.verify_file('test_file.xyz') is False)


# Generated at 2022-06-21 05:33:07.512484
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    #from ansible.plugins.inventory import InventoryModule
    results = []
    inventory_module = InventoryModule()
    inventory = {}
    
    content = '''
    [host]
    127.0.0.1
    [host:vars]
    ansible_connection=local
    '''

    test_file = '/tmp/test_file'
    with open(test_file, 'w') as f:
        f.write(content)

    inventory_module.parse(inventory, None, test_file)
    results.append(inventory == {
        'hosts': ['127.0.0.1'],
        'vars': {
            'ansible_connection': 'local'
        }
    })
    

# Generated at 2022-06-21 05:33:18.690669
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    '''
    Test against file /etc/ansible/hosts
    '''
    test_obj = InventoryModule()
    result = test_obj.verify_file('/etc/ansible/hosts')
    assert result == True

    '''
    Test against file /etc/ansible/hosts.1
    '''
    result = test_obj.verify_file('/etc/ansible/hosts.1')
    assert result == False

    '''
    Test against file /etc/ansible/hosts.yaml
    '''
    result = test_obj.verify_file('/etc/ansible/hosts.yaml')
    assert result == True

    '''
    Test against file /etc/ansible/hosts.yml
    '''
    result = test_obj.verify

# Generated at 2022-06-21 05:33:25.526316
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = """
---
# sample inventory file
all:
  hosts:
    host1:
    host2:
      var: 1
    host3:
    host4:
      var: 2
      var2: 3
  vars:
    group_all_var: value
    group_all_var2: value2
  children:
    other_group:
      hosts:
        host5:
        host6:
          var: 3
      vars:
        g2_var2: value3
    last_group:
      hosts:
        host1
      vars:
        group_last_var: value
    """

    inv_obj = InventoryModule()
    data = inv.split('\n')
    inv_data = {}

# Generated at 2022-06-21 05:33:29.805227
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """Test constructor of class InventoryModule
    """
    from ansible.plugins.loader import inventory_loader
    inventory_loader.add_directory(os.path.join(os.path.dirname(__file__), '../..','plugins','inventory'))
    assert 'yaml' == InventoryModule.NAME
    assert BaseFileInventoryPlugin == InventoryModule.__bases__[0]
    inv_module = InventoryModule()
    assert 'yaml' == inv_module.NAME

# Generated at 2022-06-21 05:33:31.750044
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    test1 = InventoryModule()
    assert test1 is not None

# Generated at 2022-06-21 05:33:38.281768
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
   im = InventoryModule()
   assert im.NAME == 'yaml'
   assert im.plugin_type == 'inventory'
   assert im.VERIFY_FILE == '/etc/ansible/plugins/inventory/yaml.yml'

# Generated at 2022-06-21 05:33:45.340289
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    # Verify file with valid '.yaml' extension and config.
    assert inventory.verify_file("myfile.yaml") == True
    # Verify file with valid '.yml' extension.
    assert inventory.verify_file("myfile.yml") == True
    # Verify file with different extensions
    assert inventory.verify_file("myfile.txt") == False
    assert inventory.verify_file("myfile.csv") == False

# Generated at 2022-06-21 05:34:08.160625
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    ''' 
    ansible.plugins.inventory.yaml.InventoryModule.verify_file
    '''
    # Test the 'verify_file(self, path)' method of the InventoryModule class.
    print("entering test_InventoryModule_verify_file")
    # Construct an instance of the InventoryModule class
    y = InventoryModule()
    # y.verify_file should return True 
    # when the file is a regular file or a symbolic link
    # and the extension is in the list of acceptable extensions
    # and both the file and the link are accessible.
    # convert the path to an absolute path
    yamlfile1 = '/home/vagrant/test/inventory.yml'
    fpath = os.path.abspath(yamlfile1)
    # Expect the function verify_file to return

# Generated at 2022-06-21 05:34:17.779316
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.plugin_docs import read_docstring

    inv = InventoryModule()
    inv.set_options()
    path = os.path.realpath(__file__)
    data = read_docstring(to_bytes(path))
    assert inv.verify_file(path)
    assert not inv.verify_file(__file__)
    assert not inv.verify_file(path+'_')
    assert not inv.verify_file(path+'.md')

# Generated at 2022-06-21 05:34:20.219972
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    assert inv_mod is not None
    assert isinstance(inv_mod, InventoryModule)

# Generated at 2022-06-21 05:34:24.458914
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    im = InventoryModule()
    im.set_options()
    im.get_option = lambda x: {'yaml_extensions': ['.yml']}[x]
    assert im.verify_file('/tmp/filename.yml')
    assert not im.verify_file('/tmp/filename.yaml')


# Generated at 2022-06-21 05:34:35.427303
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create an instance of the InventoryModule class
    inventory_module = InventoryModule()
    # Test with no params
    inventory_module.parse()
    # Test with param inventory
    inventory_module.parse(None)
    # Test with params inventory and loader
    inventory_module.parse(None, None)
    # Test with params invenory, loader and path
    inventory_module.parse(None, None, None)
    # Test with params invenory, loader, path and cache
    inventory_module.parse(None, None, None, None)


# Generated at 2022-06-21 05:34:41.113955
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.NAME == "yaml"
    assert hasattr(inv, 'verify_file')
    assert hasattr(inv, 'parse')
    assert hasattr(inv, '_parse_group')
    assert hasattr(inv, '_parse_host')


# Generated at 2022-06-21 05:34:51.182381
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    yaml_plugin = InventoryModule()
    assert yaml_plugin.verify_file('yml_inventory.yml')
    assert yaml_plugin.verify_file('yaml_inventory.yaml')
    assert yaml_plugin.verify_file('json_inventory.json')
    assert yaml_plugin.verify_file('inventory.yaml')
    assert yaml_plugin.verify_file('inventory.yml')
    assert yaml_plugin.verify_file('inventory.json')
    assert not yaml_plugin.verify_file('inventory.cfg')
    assert not yaml_plugin.verify_file('inventory.ini')

# Generated at 2022-06-21 05:34:58.947061
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from io import StringIO
    from ansible.errors import AnsibleError
    from ansible.plugins.inventory import BaseFileInventoryPlugin
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import MutableMapping

    class InventoryModule_Mock(InventoryModule):
        def verify_file(self, path):
            return True

    group = Group('group')
    group.vars = {'group_var': 'group_value'}

# Generated at 2022-06-21 05:35:01.208386
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module is not None

# Generated at 2022-06-21 05:35:08.014340
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Create an object of InventoryModule class
    inventory_module_obj = InventoryModule()
    # Create an object of BaseFileInventoryPlugin class
    base_file_inventory_plugin_obj = BaseFileInventoryPlugin()
    path = 'test.yaml'
    base_file_inventory_plugin_obj.set_options()
    # Call the method verify_file of class InventoryModule
    return inventory_module_obj.verify_file(path)



# Generated at 2022-06-21 05:35:27.995863
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    cls = InventoryModule()
    files = ['./test_yaml.yaml', './test_json.json', './test_yaml.yml']
    assert cls.verify_file(path=files[0])
    assert cls.verify_file(path=files[1])
    assert cls.verify_file(path=files[2])



# Generated at 2022-06-21 05:35:34.287180
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    '''
    check the success of verify_file method in class InventoryModule
    '''
    test_obj = InventoryModule()
    result = test_obj.verify_file('./test_file')
    assert result == False

    result = test_obj.verify_file('./test_file.yaml')
    assert result == True


# Generated at 2022-06-21 05:35:45.741786
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import os
    import ansible.plugins.loader as plugin_loader

    plugin_loader._load_plugins(class_prefix='BaseInventoryPlugin', package='ansible.plugins.inventory')

    # Instanciate a test class
    test_class = InventoryModule()

    assert test_class is not None

    test_class.parse(None, None, os.path.join(os.path.dirname(__file__), 'tests', 'yaml_test_inventory.yaml'))

# Unit test to check parsing YAML file

# Generated at 2022-06-21 05:35:58.585520
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():  
    test_file_path = "/tmp/test_InventoryModule_parse"
    test_file_content = b'''
all:
  hosts:
    test-host:
      ansible_host: 127.0.0.1
    test-host-with-port:
    - ansible_host: 127.0.0.1
      ansible_port: 1234
  children:
    test-group:
      hosts:
        - test-child-host-1
        - test-child-host-2
    test-group2:
      hosts:
        - test-child-host-3
    test-group3:
      hosts:
        - test-child-host-4
        - test-child-host-5
'''


# Generated at 2022-06-21 05:35:59.902048
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse({}, {}, EXAMPLES)

# Generated at 2022-06-21 05:36:01.388524
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.inventory import InventoryModule

    inv = InventoryModule()
    inv._parse_host('test1:1234')



# Generated at 2022-06-21 05:36:10.561499
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    manager = InventoryManager(loader=loader)

    path = "./test.yaml"
    plugin = inventory_loader.get('yaml', manager)
    plugin.parse(manager.groups, loader, path)

    assert manager.groups.get_group("all").get_host("test1").vars == {}
    assert manager.groups.get_group("all").get_host("test2").vars == {"host_var":"value"}
    assert manager.groups.get_group("all").vars == {"group_all_var":"value"}

# Generated at 2022-06-21 05:36:14.133331
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # the following line is required to create
    # InventoryModule class object
    i = InventoryModule()

    # Try to set some configuarion options for
    # InventoryModule class object
    i.set_options()

# Generated at 2022-06-21 05:36:20.004960
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    assert isinstance(im, BaseFileInventoryPlugin)
    assert im.NAME == 'yaml'
    assert im.verify_file("foo.yaml")
    assert not im.verify_file("foo.yml")
    assert im.verify_file("foo.yml")
    assert not im.verify_file("foo.txt")
    assert im.verify_file("foo.txt")



# Generated at 2022-06-21 05:36:23.345536
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    yaml_plugin = InventoryModule()
    # set yaml_valid_extensions to ['.json']
    yaml_plugin.get_option = lambda key: (['.json'])
    # test valid file
    assert yaml_plugin.verify_file('test.json') == True, 'test.json should be valid'
    # test invalid file
    assert yaml_plugin.verify_file('test.yaml') == False, 'test.yaml should not be valid'

# Generated at 2022-06-21 05:37:03.908129
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}
    loader = None
    path = None
    cache = True
    im = InventoryModule()
    im.parse(inventory, loader, path, cache)
    assert type(inventory) == dict
    assert type(inventory['all']['hosts']['test1']) == dict
    assert type(inventory['all']['vars']['group_all_var']) == str
    assert type(inventory['all']['children']) == dict
    assert type(inventory['other_group']['children']) == dict
    assert type(inventory['other_group']['children']['group_x']['hosts']['test5']) == dict
    assert type(inventory['other_group']['children']['group_y']['hosts']['test6']) == dict


# Generated at 2022-06-21 05:37:14.509334
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader, disable_all_plugins

    disable_all_plugins()
    for i in inventory_loader.all():
        if i.NAME == 'yaml':
            plugin = i
            break

    if not plugin:
        raise AssertionError('Missing YAML inventory plugin in loader')

    dataloader = DataLoader()
    inventory = InventoryManager(loader=dataloader)

    plugin.parse(inventory, dataloader, 'tests/inventory/test_inventory_plugin.yml')
    assert inventory.hosts['test1']['hostvars']['host_var'] == 'value'

# Generated at 2022-06-21 05:37:15.394975
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule() # just create an object
    pass

# Generated at 2022-06-21 05:37:17.265088
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module.NAME == 'yaml'

# Generated at 2022-06-21 05:37:22.343498
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
   y = InventoryModule()
   assert y.verify_file("example_hosts") == False
   assert y.verify_file("example_hosts.yaml") == True
   assert y.verify_file("example_hosts.yml") == True
   assert y.verify_file("example_hosts.txt") == False


# Generated at 2022-06-21 05:37:34.001958
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    s = """
        foo:
          hosts:
            host1:
          vars:
             key1: value1
        """
    loader = AnsibleLoader(s, 'local')
    data = loader.get_single_data()

    assert isinstance(data, MutableMapping)

    i = InventoryModule()
    i.set_options()

    group = 'foo'
    group_data = {'hosts': {'host1': None}, 'vars': {'key1': 'value1'}}

    group = i._parse_group(group, group_data)

    assert group == 'foo'



# Generated at 2022-06-21 05:37:46.912071
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    def get_options(yaml_extensions):
        class Options:
            yaml_extensions = yaml_extensions

        return Options()

    inv = InventoryModule()

    path = '/opt/fake/path/inventory.yml'
    assert inv.verify_file(path)

    path = '/opt/fake/path/inventory.yaml'
    assert inv.verify_file(path)

    path = '/opt/fake/path/inventory.json'
    assert inv.verify_file(path)

    path = '/opt/fake/path/inventory.yaml.swp'
    assert not inv.verify_file(path)

    path = '/opt/fake/path/inventory.ini'
    assert not inv.verify_file(path)

    path = '/opt/fake/path/inventory'


# Generated at 2022-06-21 05:37:48.355183
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()


# Generated at 2022-06-21 05:37:51.308664
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host_pattern = 'test1'
    InventoryModule()._parse_host(host_pattern)


# Generated at 2022-06-21 05:38:00.693071
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    '''
    Run the constructor of class InventoryModule
    '''

    config_data = [None]
    inv_data = [None]
    inventory = [None]
    loader = [None]
    inventory_class = [None]
    inventory_filename = [None]

    obj = InventoryModule()

    def mock_constructor_init():
        '''
        Mock for constructor of class BaseFileInventoryPlugin
        '''
        pass

    def mock_get_option(var_name):
        '''
        Mock for get_option(self, varname) in class BaseInventoryPlugin
        '''
        if var_name == 'yaml_extensions':
            return ['.yaml', '.yml', '.json']
        else:
            return None


# Generated at 2022-06-21 05:39:20.647414
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-21 05:39:30.318060
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    yaml_plugin = InventoryModule()
    assert yaml_plugin.verify_file("test.yaml") == True
    assert yaml_plugin.verify_file("test.json") == True
    assert yaml_plugin.verify_file("test.yml") == True
    assert yaml_plugin.verify_file("test.py") == False
    assert yaml_plugin.verify_file("test") == False

if __name__ == "__main__":
    test_InventoryModule_verify_file()

# Generated at 2022-06-21 05:39:41.887273
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.plugins import get_all_plugin_loaders
    from ansible.plugins.loader import InventoryPluginLoader
    from ansible.plugins.inventory.yaml import InventoryModule

    for name, plugin_loader in get_all_plugin_loaders(path_lists=[]).items():
        if isinstance(plugin_loader, InventoryPluginLoader):
            if plugin_loader.name == name:
                #print(plugin_loader)
                plugin = plugin_loader.get(plugin_loader.name)
                inv = plugin(plugin_loader.name)
                #print(type(inv))

                if isinstance(inv, InventoryModule):
                    return inv
    return None


# Generated at 2022-06-21 05:39:54.118170
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    import os
    inv_yaml_ext = ['.yaml', '.yml', '.json']
    # create a temp file
    temp_file = None
    try:
        with tempfile.NamedTemporaryFile(delete=False) as temp_file:
            temp_file.write("#!/usr/bin/python")
            path = temp_file.name
    except Exception as e:
        print(str(e))

    # test that verify_file returns True if file exists
    assert True == InventoryModule().verify_file(path)

    # test that verify_file returns True if file exists and has valid extension

# Generated at 2022-06-21 05:40:05.962912
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    plugin_instance = InventoryModule()

    # test empty filename
    assert not plugin_instance.verify_file('')

    # test wrong extension
    assert not plugin_instance.verify_file('/tmp/foo.txt')

    # test right extension
    assert plugin_instance.verify_file('/tmp/foo.yaml')

    plugin_instance.set_option('yaml_extensions', ['.json', '.yml'])

    # test right extension
    assert plugin_instance.verify_file('/tmp/foo.json')
    assert plugin_instance.verify_file('/tmp/foo.yml')

    # test wrong extension
    assert not plugin_instance.verify_file('/tmp/foo.yaml')


# Generated at 2022-06-21 05:40:17.225836
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import yaml

# Generated at 2022-06-21 05:40:19.756426
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    assert isinstance(inv_mod, InventoryModule)


# Generated at 2022-06-21 05:40:23.623888
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module.verify_file('test.yml')
    assert not module.verify_file('test.txt')

# Generated at 2022-06-21 05:40:37.039168
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    mod = InventoryModule()

    valid_files = [
        'test/inventory/test_yaml.yaml',
        'test/inventory/test_yaml.yml',
        'test/inventory/test_yaml.json',
    ]
    invalid_files = [
        'test/inventory/test_yaml.yml4',
        'test/inventory/test_yaml_unicode.yml',
        'test/inventory/test_yaml_unicode_bom.yml',
        'test/inventory/test_yaml_binary.yml',
    ]

    # Reset to defaults
    mod.set_options()

    # Test defaults
    for f in valid_files:
        assert mod.verify_file(f)
        assert mod.verify_file(f + '4')  #

# Generated at 2022-06-21 05:40:40.431007
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    return True

if __name__ == '__main__':
    print(test_InventoryModule())

# Generated at 2022-06-21 05:42:07.498523
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.inventory import InventoryModule

    loader = DataLoader()
    inventory = InventoryModule()
    inventory.parse("", loader, "/etc/ansible/hosts", cache=False)



# Generated at 2022-06-21 05:42:11.895701
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    assert module.verify_file('test/resources/inventory_yaml/1/all.yml') is True
    assert module.verify_file('test/resources/inventory_yaml/1/all.txt') is False
    assert module.verify_file('test/resources/inventory_yaml/1/all.yaml') is True
    assert module.verify_file('test/resources/inventory_yaml/1/all.txt') is False
    assert module.verify_file('test/resources/inventory_yaml/1/all.json') is True
    assert module.verify_file('test/resources/inventory_yaml/1/all.txt') is False

# Generated at 2022-06-21 05:42:23.491285
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert parse_hacking_inventory("""
all:
  hosts:
  - web01
  vars:
    ansible_connection: network_cli
    ansible_network_os: ios
    ios_config:
      - int fa0/1
      - ip address dhcp
    ios_command:
      - show version
""") == {'_meta': {'hostvars': {}}, 'all': {'hosts': ['web01'], 'vars': {'ansible_connection': 'network_cli', 'ansible_network_os': 'ios', 'ios_config': ['int fa0/1', 'ip address dhcp'], 'ios_command': ['show version']}, 'children': []}}



# Generated at 2022-06-21 05:42:28.081748
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert hasattr(inventory, '_options')
    assert hasattr(inventory, '_subs')
    assert isinstance(inventory._subs, dict)
