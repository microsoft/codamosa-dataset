

# Generated at 2022-06-21 05:32:37.420315
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()
    inv.__init__()
    assert inv.verify_file(path="test") == False


# Generated at 2022-06-21 05:32:39.093745
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module.NAME == 'yaml'

# Generated at 2022-06-21 05:32:45.564283
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader
    src = inventory_loader.get('yaml')

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    plugin = src(loader)

    import tempfile
    (fd, path) = tempfile.mkstemp()
    f = os.fdopen(fd,'w')
    f.write(EXAMPLES)
    f.close()

    plugin.parse(None, loader, path)

    print(plugin.inventory.get_groups_dict())
    print(plugin.inventory.hosts)

    assert plugin.inventory.hosts['test1'].groups[0].name == 'all'

# Generated at 2022-06-21 05:32:47.564417
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Create an instance of InventoryModule
    test_inv_mod = InventoryModule()

# Generated at 2022-06-21 05:32:55.417708
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("Testing InventoryModule.parse")
    inventory = FakeInventory(loader=FakeLoader())
    plugin = InventoryModule()
    plugin.parse(inventory, loader=inventory.loader, path="test_yaml")
    pprint.pprint(inventory._hosts)
    assert len(inventory._hosts) == 11
    assert 'test1' in inventory._hosts
    assert inventory.get_variable('all', 'group_all_var') == 'value'
    assert inventory.get_variable('other_group', 'g2_var2') == 'value3'
    assert inventory.get_variable('other_group', 'g2_var1') == 'value1'
    assert inventory.get_variable('test5', 'g_var') == 'value'

# Generated at 2022-06-21 05:32:59.028839
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host_pattern = "test.example.com"
    Module = InventoryModule()
    (hostnames, port) = Module._parse_host(host_pattern)
    assert hostnames == [u'test.example.com']
    assert port == 22


# Generated at 2022-06-21 05:33:05.155555
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.cli.inventory.direct import InventoryDirect
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import inventory_loader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryDirect(loader, 'local')
    variable_manager = VariableManager()

    inventory.set_variable_manager(variable_manager)
    variable_manager.set_inventory(inventory)
    inventory_loader.add_directory(loader.get_basedir() + '/plugins/inventory')

    im = inventory_loader.get('yaml')

    im.parse(inventory, loader, 'tests/units/plugins/inventory/data/sample.yaml')

    assert len(inventory.groups) == 4
    assert len(inventory.get_groups_dict()) == 4



# Generated at 2022-06-21 05:33:15.702985
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-21 05:33:22.916331
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    filename = "./test_yaml_inventory.yml"
    inventory = InventoryModule()
    inventory.parse(yaml_data='''all:
        hosts:
            test1:
        children:
            other_group:
                hosts:
                    test5
                children:
                    group_x:
                        hosts:
                            test5  # But this won't
                            test7  #
                    group_y:
                        hosts:
                            test6  # So always use a colon
''')
    out_of_dict = {}
    print("1.constructor test:")
    print(str(out_of_dict == inventory.groups))

# Generated at 2022-06-21 05:33:29.457875
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.parse(EXAMPLES, 'yaml')

# Generated at 2022-06-21 05:33:40.115789
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module.NAME == 'yaml'

# Generated at 2022-06-21 05:33:43.563681
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Unit test for method parse of class InventoryModule
    :return:
    """
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test.yml'])
    inventory._inventory = inventory
    inventory.parse_inventory(inventory)

# Local Testing method, calls function InventoryModule_parse

# Generated at 2022-06-21 05:33:57.135174
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-21 05:34:02.410182
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_filepath = os.path.join(os.path.dirname(__file__), "test_InventoryModule_parse.yaml")
    test_InventoryModule = InventoryModule()
    test_InventoryModule.parse(inventory_filepath)

# Generated at 2022-06-21 05:34:04.569679
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    obj = InventoryModule()
    assert obj.verify_file('test.yml') == True
    assert obj.verify_file('test.yaml') == True
    assert obj.verify_file('test') == False
    assert obj.verify_file('test.py') == False

# Generated at 2022-06-21 05:34:10.793635
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_module = InventoryModule()
    assert inv_module.verify_file("/home/ansible/inventory/hosts") == False
    assert inv_module.verify_file("/home/ansible/inventory/hosts.yaml") == True
    assert inv_module.verify_file("/home/ansible/inventory/hosts.yml") == True
    assert inv_module.verify_file("/home/ansible/inventory/hosts.json") == True
    assert inv_module.verify_file("/home/ansible/inventory/hosts.not_a_valid_extension") == False

# Generated at 2022-06-21 05:34:20.759780
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import InventoryLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    class TestInventory(InventoryManager):
        def __init__(self, loader, sources=None, vault_password=None):
            super(TestInventory, self).__init__(loader, sources, vault_password)

        def _match(self, name, pattern_str):
            return super(TestInventory, self)._match(name, pattern_str)
    # Set our inventory environment
    sources = ['test/units/plugins/inventory/yaml/inventory_empty.yaml']
    loader = InventoryLoader(None, sources, vault_password=None)
    inventory = TestInventory(loader, sources)
    # Set our inventory plugin
    plugin = Inventory

# Generated at 2022-06-21 05:34:29.245169
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test for membership of a host in one group
    groups = {}
    groups['all'] = {'hosts': {'test1': None}, 'vars': None, 'children': None}
    inventory_module = InventoryModule()
    inventory_module._parse_group('all', groups['all'])
    assert inventory_module.inventory.hosts['test1'] == {'vars': {'group_names': ['all'], 'inventory_dir': ''}}

    # Test for host membership of multiple groups, nesting of groups and
    # variable assignment
    groups = {}
    groups['all'] = {'hosts': {'test1': None}, 'vars': {'group_all_var': 'value'}, 'children': ['other_group', 'last_group']}

# Generated at 2022-06-21 05:34:41.136564
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    import ansible.plugins.loader as plugins_loader
    import ansible.plugins.inventory as plugins_inventory

    from ansible.errors import AnsibleError

    from ansible.parsing.plugin_docs import read_docstring

    plugin_loader = plugins_loader.InventoryPluginLoader()

    for plugin_class in plugin_loader.all():

        plugin_object = plugin_class()

        if plugin_object.NAME == 'yaml':
            break

    if plugin_object.NAME != 'yaml':
        raise AnsibleError("Unable to create InventoryModule instance")

    # Incorrect file extension test
    result = plugin_object.verify_file('./test/test_inventory_yaml_incorrect_extension_file')
    assert result is False

    # Correct file extension test
    result = plugin_object.verify

# Generated at 2022-06-21 05:34:46.698492
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    valid_exts = ['.yaml', '.yml', '.json']
    data = '''
all:
  hosts:
    foo
    bar
'''

    obj = InventoryModule()
    obj.set_option('yaml_extensions', valid_exts)

    obj.parse(None, None, None, cache=True)

# Generated at 2022-06-21 05:35:02.225021
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """
    Constructor of Class InventoryModule Test.
    """
    inventory_module = InventoryModule()
    assert type(inventory_module.loader) is object, "The constructor of InventoryModule class is not working correctly."


# Generated at 2022-06-21 05:35:09.343481
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    extension_list = ['.yaml', '.yml']
    file_name = '~/ansible/inventory.yaml'
    inventory_module = InventoryModule()
    inventory_module._set_options()

    config_options = {'yaml_extensions': ['.yaml', '.yml']}
    inventory_module.set_options(config_options)

    assert(inventory_module.verify_file(file_name) == True)
    assert(inventory_module.verify_file(file_name + 'x') == False)


# Generated at 2022-06-21 05:35:18.390376
# Unit test for constructor of class InventoryModule

# Generated at 2022-06-21 05:35:24.987490
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    m = InventoryModule()
    #Passes
    assert m.verify_file("./test.yaml")
    assert m.verify_file("./test.yml")
    assert m.verify_file("./test.json")
    #Fails
    assert not m.verify_file("./test")
    assert not m.verify_file("./test.txt")

# Generated at 2022-06-21 05:35:28.720053
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module.__class__.__name__ == 'InventoryModule'

# Generated at 2022-06-21 05:35:36.584148
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/units/plugins/inventory/test_yaml_inventory.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 05:35:39.608744
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # verify the module is constructed properly
    yaml = InventoryModule()
    assert yaml is not None

# Generated at 2022-06-21 05:35:41.439362
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert(InventoryModule)

# Generated at 2022-06-21 05:35:45.661200
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """This is a test for testing constructor of class InventoryModule
       It tests the two modules created are instances of InventoryModule
    """
    inventory = InventoryModule()
    assert isinstance(inventory, InventoryModule)

# Generated at 2022-06-21 05:35:58.556514
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    test = ['test.yaml', 'test.yml', 'test.json']
    test2 = ['test.txt', 'test.yaml.bak']
    test3 = ['test.yaml', 'test.txt']
    test4 = ['test.yaml', 'test.yml', 'test.json', 'test.yaml.bak']

    invmod = InventoryModule()
    if (not invmod.verify_file(test[0]) or not invmod.verify_file(test[1]) or not invmod.verify_file(test[2]) ):
        return False

    if (invmod.verify_file(test2[0]) or invmod.verify_file(test2[1]) ):
        return False


# Generated at 2022-06-21 05:36:14.062512
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    pass

# Generated at 2022-06-21 05:36:18.463692
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    c = InventoryModule()
    c.parse('inventory', None, './library/plugins/inventory/inventories/p_yaml/sample.yaml', False)
    assert c.get_option('yaml_extensions') == ['.yaml', '.yml', '.json']
    #TODO: Test assert

# Generated at 2022-06-21 05:36:21.903970
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    '''
    Constructor of class InventoryModule is being checked.
    '''

    inventory_mod = InventoryModule()

    assert(inventory_mod.get_option('yaml_extensions') == ['.yaml', '.yml', '.json'])


if __name__ == '__main__':
    print("Running the unit test of InventoryModule class")
    test_InventoryModule()
    print("All tests passed")

# Generated at 2022-06-21 05:36:25.417811
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    host = '/etc/ansible/hosts'
    group = InventoryModule()
    group.verify_file(host)



# Generated at 2022-06-21 05:36:29.688642
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    yaml_base = InventoryModule()
    assert yaml_base is not None
    assert isinstance(yaml_base, InventoryModule)
    assert isinstance(yaml_base, BaseFileInventoryPlugin)



# Generated at 2022-06-21 05:36:38.037159
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import unittest2 as unittest

    class TestInventoryModuleClass(unittest.TestCase):
        def setUp(self):
            self.inventory_module = InventoryModule()

        def test_verify_file_negative(self):
            self.assertFalse(self.inventory_module.verify_file('/tmp/yaml'))

    unittest.main()


# Generated at 2022-06-21 05:36:42.360023
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    filename = "hosts"
    loader = "loader"
    inventory = "inventory"
    x = InventoryModule()
    assert isinstance(x, InventoryModule)
    assert isinstance(x, BaseFileInventoryPlugin)
    x.parse(inventory, loader, filename)
    x._parse_group("test", "test")
    x.verify_file("test")

# Generated at 2022-06-21 05:36:50.040425
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # check if verify_file is returning false for non-existing file
    plugin = InventoryModule()
    data = plugin.verify_file("/tmp/non-existing")
    assert not data

    # check if verify_file is returning false for a file which does not have any extension
    plugin = InventoryModule()
    data = plugin.verify_file("/tmp/nofileextension")
    assert not data

# Generated at 2022-06-21 05:37:03.319229
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    import os
    import sys
    import tempfile
    import unittest

    from ansible import context
    from ansible.cli import CLI
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    from ansible_collections.ansible.community.tests.unit.compat import mock

    from ansible_collections.ansible.community.tests.unit.plugins.loader import DictDataLoader

    class TestInventoryModule(unittest.TestCase):

        def tearDown(self):
            ''' called to delete temporary directories '''
            for path in dir_locations:
                if os.path.isdir(path):
                    shutil.rmtree(path)


# Generated at 2022-06-21 05:37:10.461183
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    m = InventoryModule()
    fn = 'test.yaml'
    assert(m.verify_file(fn) is True)
    fn = 'test.txt'
    assert(m.verify_file(fn) is False)
    assert(m.verify_file('test.yml') is True)
    assert(m.verify_file('test.json') is True)
    assert(m.verify_file('test.yaml') is True)

# Generated at 2022-06-21 05:37:47.455875
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=[])

    source = """
        hosts:
            test3:
                foo: bar
            test1:
                baz: foo
        children:
            next_level:
                hosts:
                    test2:
                vars:
                    new: value
                    new_var: value
                    port: 8080
                children:
                    last_level:
                        hosts:
                            test4:
    """
    plugin = InventoryModule()
    plugin.parse(inv, loader, source)



# Generated at 2022-06-21 05:37:51.525441
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ext = ['.yaml', '.yml', '.json']
    inventory = InventoryModule()
    assert inventory.get_option('yaml_extensions') == ext

# Generated at 2022-06-21 05:37:53.578310
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule()
    assert isinstance(obj, InventoryModule)

# Generated at 2022-06-21 05:37:54.526160
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    InventoryModule()

# Generated at 2022-06-21 05:38:00.747405
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
  test_obj = InventoryModule()
  print(test_obj.verify_file("./invalid_file.txt"))
  print(test_obj.verify_file("./valid_file.yaml"))


# Generated at 2022-06-21 05:38:10.370295
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.inventory.yaml import InventoryModule
    from ansible.inventory.manager import InventoryManager

    InventoryModule.NAME = 'yaml'

    plugin = InventoryModule()
    # Path of the YAML file to be used for input to InventoryModule.
    path = './tests/inventory/inventory.yaml'

    inventory = InventoryManager("localhost")

    plugin.parse(inventory, None, path, cache=True)
    hosts = inventory.list_hosts("all")

    assert len(hosts) == 7
    assert "test1" in hosts
    assert "test2" in hosts
    assert "test5" in hosts
    assert "test6" in hosts
    assert "test7" in hosts
    assert "test3" in hosts
    assert "test4" in hosts
    assert inventory.get_restriction()

# Generated at 2022-06-21 05:38:21.995383
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host_patterns = ["localhost:2401"]
    inventory = InventoryModule()
    inventory._expand_hostpattern = mock_expand_hostpattern
    inventory.inventory.add_group = mock_add_group
    inventory._parse_host = mock_parse_host
    inventory.inventory.set_variable = mock_set_variable
    inventory.inventory.add_child = mock_add_child
    inventory.inventory.add_host = mock_add_host
    inventory.loader.load_from_file = mock_load_from_file

    assert inventory.parse(None, None, None) is None
    assert inventory._parse_group("localhost", {
        "vars": {"ansible_user": "vagrant"},
        "hosts": host_patterns,
        "children": {}}) == "localhost"



# Generated at 2022-06-21 05:38:23.969287
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    InventoryModule()

# Generated at 2022-06-21 05:38:32.266692
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = MockInventory()
    loader = MockLoader()
    path = os.path.join(os.path.dirname(__file__), "inventory_yaml_test_inventory.yaml")

    inv = InventoryModule()
    inv.set_inventory(inventory)
    inv.set_loader(loader)
    inv.parse(path=path)

    # try to add wrong vars
    inventory.set_variable(to_text('group1'), to_text('host_var'), 'wrong value')
    inventory.set_variable(to_text('group1'), to_text('group_var'), 'value2')

    # set vars for hosts
    inventory.set_variable(to_text('test1'), to_text('host_var'), to_text('host_value'))

# Generated at 2022-06-21 05:38:34.245090
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    # A test inventory in YAML format
    inventory.parse('all:\n    hosts:\n      test1:\n      test2:')

# Generated at 2022-06-21 05:39:33.001535
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.loader == None
    assert inv.path_to_yaml == None
    assert inv.display == None
    assert inv.inventory == None
    assert inv.extra_vars == None
    assert inv.loader_options == None
    assert inv.passwords == None
    assert inv.connection_info == None
    assert inv.options == None
    assert inv.basedir == None
    assert inv.cache == None


# Generated at 2022-06-21 05:39:43.886517
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import collections
    import shutil
    import tempfile

    file_contents = {}
    expected_results = {}

    def get_results(file_name):
        results = {}
        results['plugin'] = InventoryModule()
        results['plugin'].parse(results['plugin'].inventory, results['plugin'].loader, file_name)

        results['group'] = ResultsKeyDict()
        results['host'] = ResultsKeyDict()

        for group in results['plugin'].inventory.groups.values():
            group_name = group.name
            results['group'][group_name] = {}
            results['group'][group_name]['hosts'] = group.get_hosts()


# Generated at 2022-06-21 05:39:45.951497
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    i = InventoryModule()
    assert(i is not None)



# Generated at 2022-06-21 05:39:55.808236
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader

    config_data = b'''
plugin: yaml
yaml_extensions: ['.yml', '.yaml']
'''


# Generated at 2022-06-21 05:40:06.225111
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module = InventoryModule()
    path = os.path.split(os.path.realpath(__file__))[0] + '/../../../../../test/integration/inventory/test_yaml_plugin/test_inventory_plugin.yaml'
    result = inventory_module.verify_file(path)
    assert(result == True)

    inventory_module.set_option('yaml_extensions', ['.yml'])
    result = inventory_module.verify_file(path)
    assert(result == True)

    inventory_module.set_option('yaml_extensions', ['.json'])
    result = inventory_module.verify_file(path)
    assert(result == False)


# Generated at 2022-06-21 05:40:08.450823
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    i = InventoryModule()
    assert isinstance(i, InventoryModule)

# Generated at 2022-06-21 05:40:16.887631
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    p = InventoryModule()
    file_name = 'data/yaml.yml'
    assert p.verify_file(file_name) == True
    file_name = 'data/yaml'
    assert p.verify_file(file_name) == False
    file_name = 'data/yaml.yaml'
    assert p.verify_file(file_name) == True
    file_name = 'data/yaml.json'
    assert p.verify_file(file_name) == True
    file_name = 'data/yaml.txt'
    assert p.verify_file(file_name) == False

# Generated at 2022-06-21 05:40:21.509333
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    p = InventoryModule()
    assert p 
    assert not p.NAME
    assert not p.inventory
    assert not p.loader
    assert not p.parser
    assert not p.display
    assert not p.host_pattern
    assert not p.variable_manager

# Generated at 2022-06-21 05:40:28.428177
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.parsing.dataloader import DataLoader
    path = os.path.join(os.path.dirname(__file__), 'yamlexamples')
    loader = DataLoader()

    # Create inventory object and get it ready
    inv = InventoryModule()
    inv.loader = loader
    inv.set_options()
    inv.clear_pattern_cache()

    # Gather data
    inv_data = loader.load_from_file(os.path.join(path, 'hosts'))

    # Verify structure
    inv.verify_data(inv_data)

    # Parse data and check that we have a valid host in the inventory
    inv.parse(inv_data, loader=loader, cache=False)
    assert 'test1' in inv.inventory.hosts

# Generated at 2022-06-21 05:40:30.427675
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    assert inventory_module.NAME == 'yaml'