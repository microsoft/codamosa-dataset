

# Generated at 2022-06-11 14:51:05.275154
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    from ansible.plugins.inventory import InventoryModule

    plugin = InventoryModule()
    file_name = ['test.txt', 'test.yaml', 'test.yml', 'test.json']
    expected = [False, True, True, True]

    for i in range(0, len(file_name)):
        result = plugin.verify_file(file_name[i])
        assert result == expected[i]

# Generated at 2022-06-11 14:51:11.598066
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    im = InventoryModule()
    assert im.verify_file('/tmp/test.py') == False
    assert im.verify_file('/tmp/test.yml') == True
    assert im.verify_file('/tmp/test.yaml') == True
    assert im.verify_file('/tmp/test.json') == True
    assert im.verify_file('/tmp/test.j2') == False


# Generated at 2022-06-11 14:51:17.179874
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.plugins.inventory import InventoryModule
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    invmod = InventoryModule()
    invmod.loader = loader
    invmod.set_options()
    invmod.parse(None, loader, 'tests/unit/inventory/hosts', cache=False)
    #assert False

# Generated at 2022-06-11 14:51:28.000879
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    plugin = InventoryModule()

# Generated at 2022-06-11 14:51:38.890044
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    i = InventoryModule()

    assert i.verify_file("./test/myfile") == False
    assert i.verify_file("./test/myfile.yaml") == True
    assert i.verify_file("./test/myfile.yml") == True
    assert i.verify_file("./test/myfile.json") == True
    assert i.verify_file("./test/myfile.j") == False
    assert i.verify_file("./test/myfile.y") == False
    assert i.verify_file("./test/myfile.ya") == False
    assert i.verify_file("./test/myfile.yam") == False

# Generated at 2022-06-11 14:51:48.054953
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader
    from tempfile import NamedTemporaryFile
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    def _assert_host_in_group(host_name, group, host_vars=None):
        group_hosts = group.get_hosts()
        assert isinstance(group_hosts, list)
        assert len(group_hosts) > 0
        for group_host in group_hosts:
            assert isinstance(group_host, Host)

# Generated at 2022-06-11 14:51:59.089075
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from collections import namedtuple
    TestInventoryModule = namedtuple('TestInventoryModule', 'file_name')
    test_module = TestInventoryModule('test.yaml')
    inventory = YAMLInventory()
    loader = DataLoader()
    path = 'tests/unit/data/my_inventory.yml'

    # The file is not found
    try:
        result = inventory.parse(test_module, loader, 'tests/unit/data/not_found.yml')
        assert not result
    except AnsibleError:
        pass

    # Parse the file once
    assert inventory.parse(test_module, loader, path)

    # Parse the file a second time
    assert inventory.parse(test_module, loader, path)



# Generated at 2022-06-11 14:52:00.500178
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Check that YamlInventoryPlugin.parse runs
    yaml_inv = InventoryModule()

# Generated at 2022-06-11 14:52:06.821657
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule().verify_file('/tmp/test.yml') == True
    assert InventoryModule().verify_file('/tmp/test.yaml') == True
    assert InventoryModule().verify_file('/tmp/test.json') == True
    assert InventoryModule().verify_file('/tmp/test.yaml.plop') == False
    assert InventoryModule().verify_file('/tmp/test.yml.plop') == False
    assert InventoryModule().verify_file('/tmp/test.json.plop') == False


# Generated at 2022-06-11 14:52:09.805495
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader

    paths = []

    inv = inventory_loader.get('yaml', paths)
    inv.parse({}, None, paths)



# Generated at 2022-06-11 14:52:25.826894
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=os.path.abspath('inventory'))
    var_manager = VariableManager(loader=loader, inventory=inventory)

    class TestModule:
        def __init__(self, inventory, loader, path, cache=True):
            self.inventory = inventory
            self.loader = loader
            self.path = path
            self.cache = cache
    
    x = TestModule(inventory, loader, 'hosts')
    x.parse(inventory, loader, 'hosts', cache=True)


if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-11 14:52:37.381212
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.inventory.yaml import InventoryModule
    im = InventoryModule()
    im._parse_host('127.0.0.1')
    im._parse_host('*:2222')
    im._parse_host('127.0.0.1:22')
    im._parse_host('127.0.0.1:22:3306')
    im._parse_host('127.0.0.1:22:3306:somegroup')
    im._parse_host('127.0.0.1:22:3306:somegroup2')
    im._parse_host('127.0.0.1:22:*:somegroup')
    im._parse_host('127.0.0.1:*:*:somegroup')

# Generated at 2022-06-11 14:52:45.811476
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    im = InventoryModule()

    # Test with invalid file extension
    path = '/tmp/inventory_fixture.txt'
    assert im.verify_file(path) is False, 'Failed to verify file extension'

    # Test with valid file extension but non existent file
    path = '/tmp/inventory_fixture.yaml'
    assert im.verify_file(path) is False, 'Failed to verify non existent file'

    # Test with valid file extension and valid file
    import tempfile
    path = tempfile.mkstemp(suffix='.yaml')
    assert im.verify_file(path[1]) is True, 'Failed to verify valid file'



# Generated at 2022-06-11 14:52:57.295844
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    loader = DictDataLoader({
        "test.yml": '''
#!/usr/bin/env python2.7
#-*- coding: utf-8 -*-

all:
 hosts:
   bjstdmngbdr01:
   bjstdmngbdr02:
 vars:
   group_all_var: value
 children:
   other_group:
     hosts:
       bjstdmngbdr03:
       bjstdmngbdr04:
       bjstdmngbdr05:
     vars:
       g2_var2: value3
   last_group:
     hosts:
       bjstdmngbdr01:
     vars:
       group_last_var: value
'''
    })

# Generated at 2022-06-11 14:53:02.878303
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
  obj = InventoryModule()
  assert obj.verify_file('test.yaml')
  assert obj.verify_file('test.yml')
  assert obj.verify_file('test.json')
  assert not obj.verify_file('test.cfg')
  assert not obj.verify_file('test.cfg')

# Generated at 2022-06-11 14:53:11.990149
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    path = '/tmp/test'
    assert inventory_module.verify_file(path) is True
    path = '/tmp/test.yml'
    assert inventory_module.verify_file(path) is True
    path = '/tmp/test.yaml'
    assert inventory_module.verify_file(path) is True
    path = '/tmp/test.json'
    assert inventory_module.verify_file(path) is True
    path = '/tmp/test.invalid'
    assert inventory_module.verify_file(path) is False

# Generated at 2022-06-11 14:53:14.969986
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test can't work. It requires a class with methods which are not in this file.
    # Therefore we check the code quality by pylint instead.
    assert True

# Generated at 2022-06-11 14:53:26.357802
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_path = "/home/umair/ansible/ansible/plugins/inventory/yaml.yaml"

    inventory_path1 = "/home/umair/ansible/ansible/plugins/inventory/yaml.yml"

    inventory_path2 = "/home/umair/ansible/ansible/plugins/inventory/yaml.json"

    inventory_path3 = "/home/umair/ansible/ansible/plugins/inventory/yaml.py"

    extension_list = ['.yaml', '.yml', '.json']

    assert (verify_file(inventory_path,extension_list) == True)

    assert (verify_file(inventory_path1,extension_list) == True)

    assert (verify_file(inventory_path2,extension_list) == True)


# Generated at 2022-06-11 14:53:36.109751
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    module = InventoryModule()

    #testing the method with a valid '.yml' file
    assert module.verify_file('/tmp/test.yml') == True

    #testing the method with a valid '.yaml' file
    assert module.verify_file('/tmp/test.yaml') == True

    #testing the method with a valid '.json' file
    assert module.verify_file('/tmp/test.json') == True

    #testing the method with a valid file without an extension
    assert module.verify_file('/tmp/test') == True

    #testing the method with an invalid file
    assert module.verify_file('/tmp/test.test') == False

# Generated at 2022-06-11 14:53:48.167841
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    '''
    Test_create_group_instance tests the verify_file method of class InventoryModule
    with following conditions.

    1. verify_file must return True if input file is empty
    2. verify_file must return True if extension is one of yaml_extensions
    3. verify_file must return True if extension is one of yaml_extensions
    '''

    inventory_module = InventoryModule()
    inventory_module.set_options()

    assert inventory_module.verify_file("sample.yml") == True
    assert inventory_module.verify_file("sample.yaml") == True
    assert inventory_module.verify_file("sample.json") == True
    assert inventory_module.verify_file("sample") == False
    assert inventory_module.verify_file("/tmp/sample.ini") == False

# Generated at 2022-06-11 14:54:14.011995
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    obj = InventoryModule()

    #assert obj.verify_file('/etc/hosts') == False
    assert obj.verify_file('/etc/hosts.yml') == True
    assert obj.verify_file('/etc/hosts.yaml') == True
    assert obj.verify_file('/etc/hosts.json') == True
    assert obj.verify_file('/etc/hosts.yaml.yml') == True
    assert obj.verify_file('/etc/hosts.yaml.yaml') == True
    assert obj.verify_file('/etc/hosts.yaml.json') == True
    assert obj.verify_file('/etc/hosts.yaml.yaml.yml') == True

    #assert obj.verify_file('/etc/

# Generated at 2022-06-11 14:54:22.685683
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    import os
    import json

    inv_path = os.path.join(os.path.dirname(__file__), '../../tests/inventory/valid_yaml_inventory.yaml')
    loader = DataLoader()
    variable_manager = VariableManager()
    inv_obj = InventoryModule()
    inv_obj.verify_file(path=inv_path)
    assert inv_obj.verify_file(path=inv_path) is True, 'test InventoryModule_verify_file failed!'


# Generated at 2022-06-11 14:54:27.517045
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert not inventory_module.verify_file("/tmp/test.yaml")
    assert inventory_module.verify_file("/tmp/test.yml")
    assert not inventory_module.verify_file("/tmp/test.yamlnot")

# Generated at 2022-06-11 14:54:38.938957
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:54:43.049285
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Test with a valid YAML file
    plugin = InventoryModule()
    path = 'test/test.yml'
    assert plugin.verify_file(path)

    # Test with a file with a non-whitelisted extension
    plugin = InventoryModule()
    path = 'test/test.txt'
    assert not plugin.verify_file(path)

# Generated at 2022-06-11 14:54:45.509726
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.parse(loader=None, inventory=None, path='../tests/inventory/test_inventory.yaml', cache=True)

# Generated at 2022-06-11 14:54:57.050647
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Basic unit test for InventoryModule.parse method
    '''
    import os
    import sys
    import shutil
    import tempfile
    import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common import ANSIBALLZ_CACHE
    from ansible.module_utils.pycompat24 import get_exception
    import ansible.plugins.inventory

    # Create a temporary directory to simulate an ansible installation
    # where we put an ansible.cfg file with a minimal configuration to
    # enable the plugins we are interested in testing
    tmp_dir = tempfile.mkdtemp()
    cwd = os.getcwd()

    # Create ansible.cfg file in the temporary directory

# Generated at 2022-06-11 14:55:01.759596
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    test_instance = InventoryModule()
    assert test_instance.verify_file('/tmp/test.ini') == False
    assert test_instance.verify_file('/tmp/test.json') == True


# Generated at 2022-06-11 14:55:03.139164
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert False, 'Test Not Implemented'


# Generated at 2022-06-11 14:55:08.370995
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    inventory = Inventory("localhost")
    inventory.vars = dict()
    loader = DataLoader()
    inv_mod = InventoryModule()
    inv_mod.parse(inventory, loader, None)
    inv_mod.populate_host_vars(["ansible_host"])



# Generated at 2022-06-11 14:55:56.205038
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from io import StringIO

    yaml_inventory = '''
all:
  children:
    group1:
      children:
        group2:
      hosts:
        group1host1:
        group1host2:
      vars:
        group1_var1: value1
    group2:
      hosts:
        group2host1:
      vars:
        group2_var1: value1
'''
    fake_loader = DataLoader()
    mock_inventory = InventoryManager(loader=fake_loader, sources=StringIO(yaml_inventory))
    mock_variable_manager = VariableManager()
    mock_variable_manager.set

# Generated at 2022-06-11 14:56:06.158932
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    ansible_yaml = '''
all:
    vars:
        var1: value1
        var2: value2
    children:
        child1:
            vars:
                var3: value3
            children:
                child2:
                    hosts:
                        host1:
                            var4: value4
                        host2:
        child2:
            hosts:
                host3:
                    var5: value5
    hosts:
        host4:
            var6: value6
    '''
    yml_loader = DataLoader()
    yml_loader.set_basedir('/root')
    yml_loader.set_inventory_basedir('/root')


# Generated at 2022-06-11 14:56:18.746726
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print('Test: parse')
    print('Test: parse: invalid data')
    print('Test: parse: invalid data, string')
    try:
        InventoryModule().parse(None, None, './test/test_invalid_yaml_data_string.yaml')
        print('FAIL')
    except AnsibleParserError as e:
        print('PASS: ' + str(e))

    print('Test: parse: invalid data, missing group')
    try:
        InventoryModule().parse(None, None, './test/test_invalid_yaml_data_missing_group.yaml')
        print('FAIL')
    except AnsibleParserError as e:
        print('PASS: ' + str(e))

    print('Test: parse: invalid data, invalid group')

# Generated at 2022-06-11 14:56:28.477621
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import ast
    import io
    import yaml

    yaml_file_name = "test_fileinvent.yml"

# Generated at 2022-06-11 14:56:39.350130
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit test for method parse of class InventoryModule.
    '''
    class FakeGroup:
        '''
        Fake class to use as an inventory group.
        '''
        def __init__(self, _group_name):
            self.name = _group_name

        def add_host(self, _host, port=None):
            '''
            Fake method, do nothing.
            '''
            pass

        def set_variable(self, _var_name, _var_value):
            '''
            Fake method, do nothing.
            '''
            pass

    class FakeInventory:
        '''
        Fake class to use as an inventory.
        '''
        def __init__(self):
            self._groups = []


# Generated at 2022-06-11 14:56:43.181787
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = 'test/test_ansible_inventory.yml'
    inv = InventoryModule()
    inv.parse(None, None, path)
    assert(inv.get_option('yaml_extensions') == ['.yaml', '.yml', '.json'])


# Generated at 2022-06-11 14:56:53.151477
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    plugin = InventoryModule()
    os.chdir(os.path.join(os.path.dirname(__file__), '..'))
    path = os.path.abspath(os.curdir)
    path = path.replace(u'\\', u'/')
    path = path.replace(u'//', u'/')
    path = path + u'/examples/inventory/dynamic_inventory.py'
    assert(plugin.verify_file(path) == False)
    path = path + u'c'
    assert(plugin.verify_file(path) == False)
    # change extension
    path = path.replace(u'.pyc', u'.yaml')
    assert(plugin.verify_file(path) == True)
    # remove plugin dir

# Generated at 2022-06-11 14:56:53.916892
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass

# Generated at 2022-06-11 14:57:05.697843
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    group_name = 'webservers'
    group_name2 = 'dbservers'

# Generated at 2022-06-11 14:57:16.144442
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Pre-requisites, create the loader and inventory
    loader = DictDataLoader({})
    inventory = Inventory(loader=loader)

    # Create the instance
    inv_mod = InventoryModule()
    inv_mod.inventory = inventory
    inv_mod.loader = loader

    # And now parse, with a path and a file
    path = '/path/to/yaml/file'

# Generated at 2022-06-11 14:58:17.931739
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()

    inventory = FakeInventory()
    loader = FakeLoader()
    path = "./"
    module.parse(inventory, loader, path)

    assert inventory.group_dict == {"all":{"children":{"other_group":{"children":{"group_x":{}, "group_y":{}}, "hosts":{"test4":{}}, "vars":{"g2_var2":"value3"}}, "last_group":{"hosts":{"test1":{}}, "vars":{"group_last_var":"value"}}}}, "other_group":{"children":{"group_x":{"hosts":{"test5":{}}}}}, "group_x":{"hosts":{"test5":{"host_var":"value"}}}, "group_y":{"hosts":{"test6":{"host_var":"value"}}}, "last_group":{"hosts":{"test1":{}}}}

# Generated at 2022-06-11 14:58:28.382262
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    from ansible.plugins.loader import inventory_loader
    # Make sure that the plugin is active
    assert 'yaml' in [name for name, plugin in inventory_loader.all()]
    # Initialize the plugin
    my_plugin = InventoryModule()
    # Confirm that the verification is successful for the default extension
    assert my_plugin.verify_file('test.yaml')
    # Confirm that the verification is successful for a custom extension
    my_plugin.set_option('yaml_extensions', '.custom')
    assert my_plugin.verify_file('test.custom')
    # Confirm that the verification fails for an unknown extension
    assert not my_plugin.verify_file('test.txt')


# Generated at 2022-06-11 14:58:35.646415
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    plugin = InventoryModule()
    valid_files = [
        'file.yml',
        'file.yaml',
        'file.json',
        'file.yaml.json',
        'file.yaml.yaml',
        'file',
    ]
    invalid_files = [
        'file.yml.txt',
        'file.json.yml',
        'file.yaml.txt',
        'file.txt',
        ''
    ]
    for valid_file in valid_files:
        assert plugin.verify_file(valid_file) == True
    for invalid_file in invalid_files:
        assert plugin.verify_file(invalid_file) == False

# Generated at 2022-06-11 14:58:45.836052
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    from ansible.plugins.loader import inventory_loader
    from ansible.module_utils.ansible_release import __version__
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.cache import FactCache
    from ansible.plugins.inventory.yaml import InventoryModule

    any_type = Sentinel()


# Generated at 2022-06-11 14:58:48.078948
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # We can not add a test here, since the method tries to open a file. 
    # This will fail and coverage will not be reported.
    pass


# Generated at 2022-06-11 14:58:59.039679
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    '''
        Unit test function for class InventoryModule
        Argument: None
        Return: None
    '''
    # Path - string
    inventory_module_instance = InventoryModule()
    yaml_extensions = ['.yaml', '.yml', '.json']
    yaml_valid_extensions = yaml_extensions
    yaml_valid_extensions.append('.j2')

    # initializing options
    inventory_module_instance.set_options({'yaml_extensions': yaml_extensions})

    #Below test case is for failure scenario
    #with nonexistent path
    result = inventory_module_instance.verify_file('/nonexistent/')
    assert result is False, 'Test case failed, expected = False'

    # with path not matching valid extensions
    result = inventory_module_instance.verify

# Generated at 2022-06-11 14:59:09.897798
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.inventory import InventoryModule

    im = InventoryModule()
    im.display = None
    im.inventory = None
    im.loader = None

    data = {
        "group1": {
            "children": {
                "group2": {
                    "children": None,
                    "hosts": {
                        "host1": None
                    },
                    "vars": {
                        "group2_var1": "value1"
                    }
                }
            },
            "hosts": {
                "host2": {
                    "host2_var1": "value1"
                }
            },
            "vars": {
                "group1_var1": "value1"
            }
        }
    }


# Generated at 2022-06-11 14:59:16.693414
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    invmod = InventoryModule()
    invmod.set_options()

    assert invmod.verify_file("/foo/bar/hosts") == False
    assert invmod.verify_file("/foo/bar/hosts.yaml") == True
    assert invmod.verify_file("/foo/bar/hosts.yml") == True
    assert invmod.verify_file("/foo/bar/hosts.json") == True
    assert invmod.verify_file("/foo/bar/hosts.txt") == False

# Generated at 2022-06-11 14:59:28.706341
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    mod = InventoryModule()

    data = '''
all:
    hosts:
        test1:
        test2:
            host_var: value
    vars:
        group_all_var: value
    children:
        other_group:
            children:
                group_x:
                    hosts:
                        test5
                group_x:
                    hosts:
                        test5
                group_y:
                    hosts:
                        test6
            vars:
                g2_var2: value3
            hosts:
                test4:
                    ansible_host: 127.0.0.1
        last_group:
            hosts:
                test1
            vars:
                group_last_var: value'''

    mod.loader = DictDataLoader({'example.yml': data})

# Generated at 2022-06-11 14:59:37.233334
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create inventory module helper
    im = InventoryModule()

    # Add example data and create a test plugin configuration
    im.parser = im
    im.loader = None
    im.inventory = im.create_inventory_object(None, im.create_loader_object())
    im.display = im.create_display_object()
    im.filename = "test.yaml"
    im.loader.load_from_file = lambda x, cache: EXAMPLES
    im.path_to_basedir = lambda x: ""

    # Create expected data using old parser
    groups = {}
    groups['all'] = im.get_group_object("all", [], [], [], {})
    groups['other_group'] = im.get_group_object("other_group", [], [], [], {})