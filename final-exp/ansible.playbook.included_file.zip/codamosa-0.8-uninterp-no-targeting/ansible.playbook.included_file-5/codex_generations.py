

# Generated at 2022-06-21 00:43:24.793533
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Prepare parameters
    filename = "myfile"
    args = dict()
    vars = dict()
    task = dict()

    # Create two files
    file1 = IncludedFile(filename, args, vars, task)
    file2 = IncludedFile(filename, args, vars, task)
    assert file1 == file2

    args["somekey"] = "somevalue"
    file2 = IncludedFile(filename, args, vars, task)
    assert file1 != file2

if __name__ == '__main__':
    main()

# Generated at 2022-06-21 00:43:39.303330
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    class Task:
        def __init__(self, name):
            self.name = name
            self._uuid = self
            self._parent = self
            self._role = None
            self._role_name = None
            self._role_path = None
            self._from_files = {}

        def __hash__(self):
            return hash(self.name)

    class Host:
        def __init__(self, name):
            self.name = name

        def __hash__(self):
            return hash(self.name)

    f1 = IncludedFile('file1', dict(), dict(), Task('task'))
    f1.add_host(Host('host1'))

    f2 = IncludedFile('file2', dict(), dict(), Task('task'))

# Generated at 2022-06-21 00:43:50.242173
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = '/path/to/file'
    args = {'name': 'test'}
    vars = {}
    task = {}

    new_inc_file = IncludedFile(filename, args, vars, task)

    assert new_inc_file._filename == filename
    assert new_inc_file._args == args
    assert new_inc_file._vars == vars
    assert new_inc_file._task == task
    assert new_inc_file._hosts == []
    assert new_inc_file._is_role == False

    filename_1 = '/path/to/file'
    args_1 = {'name': 'test'}
    vars_1 = {}
    task_1 = {}


# Generated at 2022-06-21 00:44:02.437712
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from collections import namedtuple

    Options = namedtuple('Options', ['module_path'])
    class DummyClass():
        name = 'DummyClass'
        _options = Options(module_path='/usr/share/ansible')

    filename = '/etc/shadow'
    args = 'args'
    vars = 'vars'
    task = DummyClass()

    incfile = IncludedFile(filename, args, vars, task)

    assert incfile._filename == filename
    assert incfile._args == args
    assert incfile._vars == vars
    assert incfile._task._uuid == task._uuid
    assert incfile._task._parent._uuid == task._parent._uuid
    assert incfile._is_role == False
    assert incfile._hosts == []



# Generated at 2022-06-21 00:44:12.650847
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    included_files = set()

    for host in inventory.get_hosts():
        result = TaskResult(host, {'failed': False, 'skipped': False, 'include_args': dict(), 'include': 'test1.yml', 'changed': False, 'parsed': True})
        included_files = included_files.union(IncludedFile.process_include_results([result], Play()._iterator, loader, VariableManager(loader=loader, inventory=inventory)))



# Generated at 2022-06-21 00:44:17.442454
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'a'
    args = 'args'
    vars = 'vars'
    task = 'task'
    ifile = IncludedFile(filename, args, vars, task)
    assert 'a (args=args vars=vars): []' == str(ifile)

    ifile._hosts.append('host')
    assert 'a (args=args vars=vars): [\'host\']' == str(ifile)

# Generated at 2022-06-21 00:44:24.871179
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    class FakeHost:
        def __init__(self, classname):
            self._name = classname
        def __eq__(self, other):
            return self._name == other._name

    h1 = FakeHost("FakeHost1")
    h2 = FakeHost("FakeHost2")
    h3 = FakeHost("FakeHost3")
    h4 = FakeHost("FakeHost4")
    h5 = FakeHost("FakeHost5")
    class FakeIterator:
        def __init__(self, classname):
            self._play = classname
    p1 = FakeIterator("Play1")
    p2 = FakeIterator("Play2")
    class FakeResult:
        def __init__(self, host, task):
            self._task = task
            self._host = host

# Generated at 2022-06-21 00:44:35.182245
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    incl_file = IncludedFile(filename='/a/b/x', args={}, vars={}, task=TaskInclude(name='', action=''))
    incl_file.add_host('host1')
    assert incl_file._hosts == ['host1']
    incl_file.add_host('host2')
    assert incl_file._hosts == ['host1', 'host2']
    incl_file.add_host('host1')
    assert incl_file._hosts == ['host1', 'host2']

# Generated at 2022-06-21 00:44:42.771771
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import ansible.playbook
    # assert(IncludedFile(1, 2, 3, 4, 5) == IncludedFile(1, 2, 3, 4, 5))
    assert(IncludedFile('filename1', 'args1', 'vars1', TaskInclude(ansible.playbook.PlayContext(), ansible.playbook.Playbook()), 'is_role1') ==
           IncludedFile('filename1', 'args1', 'vars1', TaskInclude(ansible.playbook.PlayContext(), ansible.playbook.Playbook()), 'is_role1'))
    # assert(IncludedFile(1, 2, 3, 4, 5) != IncludedFile(1, 2, 3, 4, 5))

# Generated at 2022-06-21 00:44:47.315931
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    x = IncludedFile("test_file.yml", {'key': 'value'}, {'key': 'value'}, "test_task")
    x.add_host("test_host")
    assert(x._hosts == ["test_host"])

# Generated at 2022-06-21 00:45:12.377918
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    a = IncludedFile('/a', {}
        , {}, None)
    b = IncludedFile('/b', {}, {}, None)
    c = IncludedFile('/c', {}, {}, None)

    # test for same object being added
    host = 'test'
    a.add_host(host)

    assert(len(a._hosts) == 1)
    assert(a._hosts[0] == host)

    try:
        a.add_host(host)
        assert(0)
    except ValueError:
        pass

    # test for different objects being added
    host = 'test2'
    a.add_host(host)

    assert(len(a._hosts) == 2)
    assert(a._hosts[0] == 'test')

# Generated at 2022-06-21 00:45:18.243270
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    class FakeHost:
        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return self.name

    # IncludedFile instance for testing
    class IncludedFileTest:
        def __init__(self, filename, args, vars, task):
            self._filename = filename
            self._args = args
            self._vars = vars
            self._task = task
            self._hosts = []

        def add_host(self, host):
            if host not in self._hosts:
                self._hosts.append(host)
                return
            raise ValueError()


# Generated at 2022-06-21 00:45:31.964829
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_iterator import PlaybookIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError
    from ansible.utils.vars import combine_vars

    class Host(object):
        name = 'fake_name'
    loader = DataLoader()

# Generated at 2022-06-21 00:45:44.003869
# Unit test for method __eq__ of class IncludedFile

# Generated at 2022-06-21 00:45:55.336289
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    ifile1 = IncludedFile("file1.yml", {"a": "b", "c": "d"}, {"e": "f", "g": "h"}, "task1")
    ifile2 = IncludedFile("file2.yml", {"a": "b", "c": "d"}, {"e": "f", "g": "h"}, "task1")
    ifile3 = IncludedFile("file1.yml", {"a": "b", "c": "d"}, {"e": "f", "g": "h"}, "task2")
    ifile4 = IncludedFile("file1.yml", {"a": "b", "c": "d"}, {"e": "f", "g": "h"}, "task1")

    assert ifile1 == ifile1
    assert not ifile1 == ifile2

# Generated at 2022-06-21 00:45:59.858494
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    t_IncludedFile = IncludedFile('ansible.cfg', dict(), dict(), dict())
    assert repr(t_IncludedFile) == "ansible.cfg (args={} vars={}): []"
    return

# Generated at 2022-06-21 00:46:08.284904
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    Ansible-specific test that exercises the process_include_results method of
    class IncludedFile.
    """
    class _Host:
        def __init__(self):
            self._name = None
        def get_name(self):
            return self._name
        def set_name(self, value):
            self._name = value
            return

    class _Task:
        def __init__(self):
            self._uuid = None
            self._parent = None
        def set_uuid(self, value):
            self._uuid = value
            return
        def set_parent(self, value):
            self._parent = value
            return
        def get_uuid(self):
            return self._uuid

    class _Result:
        def __init__(self):
            self._host = None

# Generated at 2022-06-21 00:46:18.256419
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Include without args
    # TASK [debug] **************************************************************
    # ok: [localhost] => {
    #     "msg": "h=localhost"
    # }
    # TASK [include_vars] *******************************************************
    # ok: [localhost] => {
    #     "msg": "h=localhost"
    # }
    # TASK [debug] **************************************************************
    # ok: [localhost] => {
    #     "msg": "h=localhost"
    # }
    # TASK [debug] **************************************************************
    # ok: [localhost] => {
    #     "msg": "h=localhost"
    # }
    included_files = []

# Generated at 2022-06-21 00:46:20.604513
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile("test_filename", [] ,{}, task="test_task", is_role=False)
    assert repr(included_file) == "test_filename (args=[] vars={}): []"

# Generated at 2022-06-21 00:46:29.113110
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins import callback_loader, module_loader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')

    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 00:46:58.510079
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    play = Play().load({'name': 'test', 'hosts': 'testhost'}, variable_manager=None, loader=None)
    task = Task().load({'action': 'test'}, variable_manager=None, loader=None)
    play.add_task(task)

    include_a = IncludedFile('test.yaml', {'a': 'b'}, {'c': 'd'}, task)
    include_b = IncludedFile('test.yaml', {'a': 'b'}, {'c': 'd'}, task, is_role=False)
    assert include_a == include_b


# Generated at 2022-06-21 00:47:04.332931
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    inc_file = IncludedFile('a', 'b', 'c', 'd')
    assert inc_file._hosts == []

    inc_file.add_host('x')
    assert inc_file._hosts == ['x']

    try:
        inc_file.add_host('x')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-21 00:47:16.794870
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    file1 = IncludedFile("file1.yml", dict(k="v"), dict(k1="v1"), dict(k2="v2"))
    assert file1._filename == "file1.yml"
    assert file1._args == dict(k="v")
    assert file1._vars == dict(k1="v1")
    assert file1._task == dict(k2="v2")
    assert file1._hosts == []
    assert file1._is_role == False
    assert file1.__repr__() == "file1.yml (args={'k': 'v'} vars={'k1': 'v1'}): []"
    assert file1.__eq__(file1) == True

# Generated at 2022-06-21 00:47:25.998162
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task

    task_1 = Task()
    task_2 = Task()
    task_a = Task()
    task_b = Task()
    task_c = Task()

    role = IncludeRole()
    role.name = 'my_role'
    role._role_path = '/path/to/my_role'
    role.vars = {'role_var_1': 'role_val_1', 'role_var_2': 'role_val_2'}
    task_1._parent = role
    task_2._parent = role

    task_a._parent = role
    task_b._parent = role
    task_c._parent = role


# Generated at 2022-06-21 00:47:33.837521
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = "/test1/test2/test3.yaml"
    args = {'test1': 0, 'test2': 1, 'test3': 2}
    vars = {'test1': 0, 'test2': 1, 'test3': 2}
    task = lambda x: 0
    incfile = IncludedFile(filename, args, vars, task)
    assert incfile._filename == filename
    assert incfile._args == args
    assert incfile._vars == vars
    assert incfile._task == task
    assert incfile._hosts == []
    
test_IncludedFile()

# Generated at 2022-06-21 00:47:41.113000
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    ifile = IncludedFile('filename', 'args', 'vars', 'task')
    ifile.add_host('host1')
    ifile.add_host('host2')

    try:
        ifile.add_host('host1')
    except ValueError:
        pass
    else:
        assert False, "add_host() did not verify the host value"

    try:
        ifile.add_host('host3')
    except ValueError:
        assert False, "add_host() failed to add a new host value"


# Generated at 2022-06-21 00:47:53.490994
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # pylint: disable=unused-import,import-error
    import ansible.plugins.loader
    # pylint: enable=unused-import,import-error

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handlers.include import Include
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    results = []

    play = Play()
    play.name = 'test play'
   

# Generated at 2022-06-21 00:48:04.309261
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    args = {'_raw_params': './include_tasks_test.yaml'}
    variable_manager = 'Fake variable manager'
    loader = 'Fake loader'
    display = 'Fake display'
    variable_manager = 'Fake variable manager'
    hosts = 'Fake hosts'
    task_uuid = 'Fake task uuid'
    task = 'Fake task'
    class_task = IncludedFile('./include_tasks_test.yaml',args, variable_manager, loader, display, hosts, task_uuid, task)
    assert(str(class_task.__repr__()) == "./include_tasks_test.yaml (args={'_raw_params': './include_tasks_test.yaml'} vars=Fake variable manager): Fake hosts")

# Generated at 2022-06-21 00:48:06.610635
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile("foo", "args", "vars", "task", "is_role")
    b = IncludedFile("foo", "args", "vars", "task", "is_role")
    assert a == b

# Generated at 2022-06-21 00:48:15.670733
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import pytest
    from ansible.vars.manager import VariableManager

    class Iterator:
        class Play:
            class Role:
                def __init__(self, name):
                    self.name = name
                def get_role_path(self, name):
                    return self.name

            def __init__(self, role_path, role_name):
                self.role = self.Role(role_path)
                self.role.name = role_name

        class Host:
            def __init__(self, name):
                self.name = name

        # Overwritten in test
        def get_play(self):
            return self.Play('/etc/ansible/roles/testRole', 'testRole')


# Generated at 2022-06-21 00:49:07.939721
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    print("start test_IncludedFile")
    filename = "ansible/filename."
    args = {}
    vars = {}
    task = ()
    is_role = False

    if is_role == False:
        print("Constructing IncludedFile() with file")
        included_file = IncludedFile(filename, args, vars, task, is_role)
        print("IncludedFile.__init__(filename with extension) returned", included_file)
        assert included_file._filename == filename, "IncludedFile._filename was not set correctly."
        assert included_file._args == args, "IncludedFile._args was not set correctly."
        assert included_file._vars == vars, "IncludedFile._vars was not set correctly."
        assert included_file._task == task, "IncludedFile._task was not set correctly."

# Generated at 2022-06-21 00:49:17.267164
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = 'filename1'
    args = {'arg1': 'value1', 'arg2': 'value2'}
    vars = {'var1': 'value1', 'var2': 'value2'}
    task = None  # TODO: add a task object here..
    included_file = IncludedFile(filename, args, vars, task)

    assert included_file._filename == filename
    assert included_file._args == args
    assert included_file._vars == vars
    assert included_file._task == task

# Generated at 2022-06-21 00:49:28.794413
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.block import Block
    from ansible.plugins.loader import include_role_plugin, include_tasks_plugin, import_playbook_plugin, import_tasks_plugin
    import ansible.plugins.action
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    ansible.plugins.action.ActionBase.add_directory(os.path.join(os.path.dirname(__file__), '../action_plugins'), with_subdir=True)

    variable_manager = VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,127.0.0.1,'])
    host = inventory.get_host("127.0.0.1")
    play

# Generated at 2022-06-21 00:49:36.401683
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test when _filename and _args are different
    f1 = IncludedFile('filename1', {'a': 'A'}, {'b': 'B'}, None)
    f2 = IncludedFile('filename2', {'a': 'A'}, {'b': 'B'}, None)
    assert f1 != f2

    # Test when _filename is the same, but _args are different
    f1 = IncludedFile('filename1', {'a': 'A'}, {'b': 'B'}, None)
    f2 = IncludedFile('filename1', {'a': 'A2'}, {'b': 'B'}, None)
    assert f1 != f2

    # Test when _filename and _args are the same, but _vars are different

# Generated at 2022-06-21 00:49:47.038840
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    """Unit test for method __repr__ of class IncludedFile."""
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task import Task

    host1 = "1.1.1.1"
    host2 = "2.2.2.2"
    filename1 = "/etc/ansible/roles/site.yml"
    filename2 = "/etc/ansible/playbooks/role2.yml"
    args1 = {"arg1": "value1", "arg2": "value2"}
    args2 = {"arg1": "value3", "arg2": "value4"}
    vars1 = {"var1": "value1", "var2": "value2"}
    vars2 = {"var1": "value3", "var2": "value4"}
   

# Generated at 2022-06-21 00:49:59.078210
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    loader = None
    variable_manager = None

    include_arguments = dict()
    include_arguments['x'] = 2
    include_result = dict()
    include_result['include'] = "./myInclude.yaml"
    include_result['include_args'] = include_arguments
    include_result['ansible_loop_var'] = 'item'
    include_result['ansible_index_var'] = 'index'
    include_result['item'] = 5
    include_result['index'] = 0

    res = object()
    host = object()
    res._task = object()
    res._task.action = 'include'
    res._task._uuid = 'uuid1'
    res._task._parent = object()
    res._task._parent._uuid = 'uuid2'
   

# Generated at 2022-06-21 00:50:07.159054
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Create two host objects
    host1 = []
    host2 = []

    # Create an IncludedFile object
    inc = IncludedFile('filename', 'args', 'vars', 'task')
    inc.add_host(host1)

    try:
        inc.add_host(host1)
        assert False
    except ValueError:
        pass

    inc.add_host(host2)

    # Create a second IncludedFile object
    inc2 = IncludedFile('filename', 'args', 'vars', 'task')
    inc2.add_host(host1)

    # Check if the two objects are equal, only the host list should be different
    assert inc != inc2

if __name__ == '__main__':
    test_IncludedFile_add_host()

# Generated at 2022-06-21 00:50:11.601335
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    include_file = IncludedFile('/foo/bar', {}, {}, None)
    assert include_file.add_host('localhost') == ['localhost']
    assert include_file.add_host('localhost') == None

# Generated at 2022-06-21 00:50:21.599879
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # Test if the generation of IncludedFile works correctly
    filename = 'file_name'
    args = {'arg1': '1'}
    vars = {'var1': '2'}
    task = 'task1'

    included_file = IncludedFile(filename, args, vars, task)
    assert included_file._filename == 'file_name'
    assert included_file._args == {'arg1': '1'}
    assert included_file._vars == {'var1': '2'}
    assert included_file._task == 'task1'
    assert included_file._hosts == []
    assert included_file._is_role == False

if __name__ == "__main__":
    test_IncludedFile()

# Generated at 2022-06-21 00:50:31.954675
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    include = IncludedFile("file1", {}, {}, "task1")

    # First host added
    include.add_host("host1")
    assert include._hosts == ["host1"]

    # Duplicate host
    try:
        include.add_host("host1")
        assert False
    except ValueError:
        assert True

    # Second host added
    include.add_host("host2")
    assert include._hosts == ["host1", "host2"]


# Generated at 2022-06-21 00:51:40.025402
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False, "Not implemented"

# Generated at 2022-06-21 00:51:48.556025
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = 'foo.yml'
    args = 'bar'
    vars = 'baz'
    task = 'biz'
    included_file = IncludedFile(filename, args, vars, task)
    assert included_file._filename == filename
    assert included_file._args == args
    assert included_file._vars == vars
    assert included_file._task == task
    assert included_file._hosts == []
    assert included_file._is_role is False


# Generated at 2022-06-21 00:51:59.570511
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    file1 = IncludedFile('filename', 'args', 'vars', 'task')
    file2 = IncludedFile('filename', 'args', 'vars', 'task')
    file3 = IncludedFile('filename', 'args', 'vars1', 'task')
    file4 = IncludedFile('filename', 'args1', 'vars', 'task')
    file5 = IncludedFile('filename', 'args', 'vars', 'task1')
    file6 = IncludedFile('filename1', 'args', 'vars', 'task')
    assert file1 == file2
    assert file1 != file3 and file1 != file4 and file1 != file5 and file1 != file6

# Generated at 2022-06-21 00:52:12.578566
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    rval = IncludedFile('file1', dict(), dict(), None)
    rval = IncludedFile('file1', dict(), dict(), None)
    assert rval == rval
    assert not rval != rval
    rval = IncludedFile('file1', dict(), dict(), None)
    rval2 = IncludedFile('file1', dict(), dict(), None)
    assert rval == rval2
    assert not rval != rval2
    rval = IncludedFile('file1', dict(), dict(), None)
    rval2 = IncludedFile('file2', dict(), dict(), None)
    assert not rval == rval2
    assert rval != rval2
    rval = IncludedFile('file1', dict(), dict(), None)
    rval2 = IncludedFile('file1', dict(foo='bar'), dict(), None)
   

# Generated at 2022-06-21 00:52:25.485193
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # Note: in this test, we use a dummy iterator that has a fake play object
    # called _play to which we can fake attaching the included files
    # TODO: If a proper test iterator is developed, this one should be removed

    # Create dummy iterator and loader objects (we won't be using them
    # directly in the function call)
    class DummyPlay(object):

        included_files = []

        def __init__(self, included_files):
            self.included_files = included_files

    class DummyIterator(object):

        def __init__(self):
            self._play = DummyPlay(self.included_files)


    class DummyLoader(object):

        def get_basedir(self):
            return '.'

    # Case 0: Try function with empty list of results
    results = []
   

# Generated at 2022-06-21 00:52:33.322850
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook import Playbook

    # First make a Playbook
    p = Playbook()
    # Then make a fake play to use in get_vars call below
    fake_play = Playbook.get_playbook(dict(name='fake_play'))

    # Create a fake task which will be the 'parent' of the task that we're testing
    fake_parent_task = dict(uuid='not_uuid')

    # Create a mock task which is the task that we're testing
    fake_task = dict(action='include', _role_name=None, _parent=fake_parent_task, _hosts=['hostname'], _uuid='uuid', _ansible_no_log=False, no_log=False, _loop_type=None, loop=None)

    # Create a fake result which is

# Generated at 2022-06-21 00:52:36.158019
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    obj = IncludedFile("__filename", None, None, None, False)
    obj._hosts = ["__host1", "__host2"]
    assert repr(obj) == "__filename (args=None vars=None): ['__host1', '__host2']"
