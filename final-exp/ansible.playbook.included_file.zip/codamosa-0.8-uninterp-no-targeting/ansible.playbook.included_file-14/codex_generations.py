

# Generated at 2022-06-21 00:43:16.649633
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    eq = IncludedFile(__file__, 'a', 'b', 'c') == IncludedFile(__file__, 'a', 'b', 'c')
    assert(eq)
    eq = IncludedFile(__file__, 'a', 'b', 'c') == IncludedFile(__file__, 'a', 'b', 'c', True)
    assert(not eq)
    eq = IncludedFile(__file__, 'a', 'b', 'c') == IncludedFile(__file__, 'a', 'b', 'c', False)
    assert(eq)
    eq = IncludedFile(__file__, 'a', 'b', 'c') == IncludedFile(__file__, 'a', 'b', 'd')
    assert(not eq)


# Generated at 2022-06-21 00:43:21.072285
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile('filename', 'arguments', 'variables', 'task')
    assert repr(included_file) == "filename (args=arguments vars=variables): []"

# Generated at 2022-06-21 00:43:26.768640
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    if2 = IncludedFile('file.yml', {}, {}, {'name': 'test_task'})
    assert if2._filename == 'file.yml'
    assert if2._args == {}
    assert if2._vars == {}
    assert if2._task == {'name': 'test_task'}


# Generated at 2022-06-21 00:43:34.920918
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    t = IncludedFile("filename", "args", "vars", "task", "is_role")
    t.add_host("host1")
    t.add_host("host2")
    t.add_host("host3")
    t.add_host("host2")
    assert t == 'filename (args=args vars=vars): [\'host1\', \'host2\', \'host3\']'

# Generated at 2022-06-21 00:43:48.415805
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    play = Play().load({
        'name': 'test',
        'hosts': ['host1', 'host2'],
        'tasks': [
            dict(action=dict(module='include_role', name='test'))
        ]
    }, variable_manager='vars')

    task = play.get_task_by_name('task1')
    task._role_name = 'test'


# Generated at 2022-06-21 00:43:49.002485
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    assert IncludedFile

# Generated at 2022-06-21 00:43:57.479414
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_file = IncludedFile("/home/vars.yml", "args", "vars", "task")
    included_file.add_host("host1")
    included_file.add_host("host2")
    try:
        included_file.add_host("host1")
    except ValueError:
        print("test_IncludedFile_add_host successful")
    else:
        print("test_IncludedFile_add_host failed")


# Generated at 2022-06-21 00:44:04.169618
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # arrange
    i = IncludedFile("filename", "arg", "var", "task")
    i.add_host("host1")

    # act
    i.add_host("host2")

    # assert
    assert len(i._hosts) == 2

    # act
    i.add_host("host2")

    # assert
    assert len(i._hosts) == 2

# Generated at 2022-06-21 00:44:14.100894
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    class FakeHost:
        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return self.name == other.name

        def __hash__(self):
            return hash(self.name)

    class FakeTask:
        def __init__(self, uuid):
            self._uuid = uuid
            self._parent = FakeTask(uuid)

    h1 = FakeHost('host1')
    h2 = FakeHost('host2')
    h3 = FakeHost('host3')
    t1 = FakeTask('task1')
    t2 = FakeTask('task2')

    inc1 = IncludedFile('include1', {}, {}, t1)
    inc2 = IncludedFile('include1', {}, {}, t2)
    inc3 = IncludedFile

# Generated at 2022-06-21 00:44:27.363718
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    def test_dict_equal(d1, d2):
        d1_keys = set(d1.keys())
        d2_keys = set(d2.keys())
        if d1_keys != d2_keys:
            return False
        shared_keys = d1_keys & d2_keys
        for key in shared_keys:
            if d1[key] != d2[key]:
                return False
        return True

    included_file = IncludedFile("file", 1, 3, 2)

    assert included_file._filename == "file"
    assert included_file._args == 1
    assert included_file._vars == 3
    assert included_file._task == 2
    assert included_file._hosts == []

    included_file.add_host("hostname")

# Generated at 2022-06-21 00:44:52.100077
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext

    # Init all the objects needed by class IncludedFile to define class IncludedFile is equal to another one
    loader, variable_manager, inventory = C.load_extra_vars(C.DEFAULT_VAULABLE_MGR_PLUGINS, C.DEFAULT_VAULABLE_MGR_PLUGINS)

# Generated at 2022-06-21 00:44:58.679584
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile('pippo', '', '', '')

    inc_file.add_host('pluto')

    assert inc_file._hosts == ['pluto']

    # Duplicate host
    try:
        inc_file.add_host('pluto')
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 00:45:10.572982
# Unit test for method __eq__ of class IncludedFile

# Generated at 2022-06-21 00:45:25.150785
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    if not display.verbosity:
        return

    # Test __init__()
    try:
        if_1 = IncludedFile('/path/to/file_1',
                            {'vars': {'a': '1', 'b': '2'}},
                            {'a': '11', 'b': '22', 'c': '33'},
                            'task_object_1')
    except (TypeError, ValueError) as e:
        display.display('Constructor of IncludedFile() failed.')
        display.display(str(e))
        sys.exit(1)

    # Test __eq__()

# Generated at 2022-06-21 00:45:30.711539
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    host1 = 'host1'
    host2 = 'host2'
    host3 = 'host3'
    host4 = 'host4'
    host5 = 'host5'
    host6 = 'host6'

    filename1 = 'filename1'
    filename2 = 'filename2'
    filename3 = 'filename3'
    filename4 = 'filename4'
    filename5 = 'filename5'
    filename6 = 'filename6'

    args1 = {'_ansible_check_mode': False}
    args2 = {'check_mode': True}
    args3 = {'_ansible_check_mode': False}
    args4 = {'check_mode': True}
    args5 = {'_ansible_check_mode': False}
    args6 = {'check_mode': True}
   

# Generated at 2022-06-21 00:45:43.509220
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.task_include import TaskInclude

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-21 00:45:55.119593
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({}, loader=loader, variable_manager=variable_manager, loader_cache=loader._cache)

    # Test iterator.get_basedir(). Result should be the current working dir
    iterator = play.make_iterator(loader=loader, variable_manager=variable_manager)
    assert iterator.get_basedir() == os.getcwd(), "Incorrect basedir. Returned {0} but expected {1}".format(iterator.get_basedir(), os.getcwd())

    # Test case where 'include:' action is used. Result should be the first entry of the search path
    search

# Generated at 2022-06-21 00:45:56.581916
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    inc_file = IncludedFile()

# Generated at 2022-06-21 00:46:03.197419
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Passed arguments are not used
    args = ()
    kwargs = {'args': args}
    # No exception is expected to be raised
    try:
        # Initialized object
        test_obj = IncludedFile(*args, **kwargs)
        # Call the method
        test_obj.__eq__(*args, **kwargs)
    except Exception:
        assert False, 'Unxpected exception raised'


# Generated at 2022-06-21 00:46:13.930762
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    print("Testing the constructor of class IncludedFile.")

    # test 1
    try:
        ifile = IncludedFile("filename", "args", "vars", "task")
        print("Test 1: included_file constructor works correctly.")
    except ValueError:
        print("Test 1: included_file constructor doesn't work correctly.")

    # test 2
    try:
        ifile.add_host("host")
        print("Test 1: included_file.add_host works correctly.")
    except ValueError:
        print("Test 1: included_file.add_host doesn't work correctly.")



# Generated at 2022-06-21 00:47:04.509274
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    i = IncludedFile('a', None, None, None)
    i.add_host('b')
    try:
        i.add_host('b')
    except ValueError:
        pass
    else:
        assert 1 == 0
    i.add_host('c')


# Generated at 2022-06-21 00:47:16.851708
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor import task_result
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    results = []

    task = Task()
    task.action = 'include'
    task.args = dict(
        _raw_params='include.yml',
        _ansible_ignore_errors=False,
        _ansible_no_log=False,
        _ansible_verbosity=0,
    )


# Generated at 2022-06-21 00:47:24.441326
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    play_context = PlayContext()
    task = Task()
    block = Block()

    included_file = IncludedFile('/path/to/file', {}, {}, task)
    included_file._hosts = ['host1', 'host2', 'host3']
    expected = "/path/to/file (args={} vars={}): ['host1', 'host2', 'host3']"

    assert repr(included_file) == expected

# Generated at 2022-06-21 00:47:34.891239
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class Task:
        """Dummy class to pass as parameter"""
        def __init__(self, filename):
            self._filename = filename

    class Data:
        """Dummy class to pass as parameter"""
        def __init__(self, filename):
            self._filename = filename

    inc1 = IncludedFile("/home/user/file1.yml", "var1", "arg1", Task("/home/user/tasks.yml"))
    inc2 = IncludedFile("/home/user/file1.yml", "var2", "arg2", Task("/home/user/tasks.yml"))
    inc3 = IncludedFile("/home/user/file1.yml", "var1", "arg1", Task("/home/user/tasks2.yml"))

# Generated at 2022-06-21 00:47:41.199311
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    in_file = IncludedFile(
        filename = '/path/name',
        args = {'a':'1', 'b':'2'},
        vars = {'x':'3', 'y':'4'},
        task = None
    )
    assert 'args={a: 1, b: 2} vars={x: 3, y: 4}' in repr(in_file)
    assert 'name' in repr(in_file)

# Generated at 2022-06-21 00:47:50.614705
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    ifile = IncludedFile("myfile", "myargs", "myvars", "mytask")
    ifile.add_host("myhost")
    ifile.add_host("myhost")
    ifile.add_host("yourhost")
    assert "myhost" in ifile._hosts
    try:
        ifile.add_host("myhost")
        assert False
    except ValueError:
        pass
    assert "myhost" in ifile._hosts
    assert "yourhost" in ifile._hosts


# Generated at 2022-06-21 00:48:00.517897
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = "/my/file/path/foo.yaml"
    args = [ "arg1", "arg2" ]
    vars = { "var1": "value1", "var2": "value2" }
    task = "task"

    # Test a normal IncludedFile
    included_file = IncludedFile(filename, args, vars, task)
    
    assert included_file._filename == filename
    assert included_file._args == args
    assert included_file._vars == vars
    assert included_file._task == task
    assert included_file._hosts == []

# Generated at 2022-06-21 00:48:12.776198
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    _filename1 = "/etc/hosts"
    _filename2 = "/etc/hosts"
    _filename3 = "/etc/hosts3"
    assert IncludedFile(_filename1, {}, {}, {}, False)._filename == IncludedFile(_filename2, {}, {}, {}, False)._filename
    assert not IncludedFile(_filename1, {}, {}, {}, False)._filename == IncludedFile(_filename3, {}, {}, {}, False)._filename

    _args1 = {'a': 1, 'b': 2}
    _args2 = {'a': 1, 'b': 2}
    _args3 = {'a': 1, 'b': 3}
    _args4 = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-21 00:48:22.761614
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    myObj = IncludedFile(filename = 'sample.yml', args = 'sample_args', vars = 'sample_vars', task = 'sample_task', is_role = False)
    print(myObj)
    myObj.add_host('localhost')
    print(myObj)
    myObj.add_host('127.0.0.1')
    print(myObj)
    myObj.add_host('192.168.0.1')
    print(myObj)
    myObj.add_host('192.168.0.1')
    print(myObj)


# Generated at 2022-06-21 00:48:28.425026
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile("abc", {}, {}, object())
    b = IncludedFile("abc", {}, {}, object())

    assert a == b
    assert (a == None) == False
    assert (None == a) == False



# Generated at 2022-06-21 00:49:01.761726
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    args = {'name': 'test'}
    vars = {'test': 1, 'name': 2}
    task = object()

    include_file = IncludedFile('test_filename', args, vars, task)
    assert str(include_file) == 'test_filename (args={\'name\': \'test\'} vars={\'test\': 1, \'name\': 2}): []'

# Generated at 2022-06-21 00:49:13.008341
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():

  from mock import MagicMock
  from ansible.playbook.play_context import PlayContext
  from ansible.playbook.task_include import TaskInclude
  from ansible.playbook.task import Task
  from ansible.playbook.block import Block
  # Create mock objects for method __repr__ of class IncludedFile
  mock_include_role = MagicMock(spec=IncludeRole)
  mock_task = MagicMock(spec=Task)
  mock_block = MagicMock(spec=Block)
  task_include = TaskInclude(block=mock_block, role_name="", play_context=PlayContext(), task=mock_task, role=mock_include_role)
  included_file = IncludedFile("filename", "args", "vars", task_include)
  # Execute method __re

# Generated at 2022-06-21 00:49:25.482856
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # TODO: Replace with mock objects
    class Task:
        def __init__(self):
            self._uuid = "1234567890"
            self._parent = None
            self.action = C.INCLUDE_TASK_FILENAME
            self.no_log = False
            self.loop = False
            self._role = None
            self._role_name = None
            self._from_files = dict()
            self.FROM_ARGS = ["role_from"]

    class Result:
        def __init__(self, host, task, results={}, failed=False, skipped=False):
            self._host = host
            self._task = task
            self._result = results


# Generated at 2022-06-21 00:49:34.504510
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult

    t = TaskResult(host="localhost")
    t._task = None
    t._result = {
        "include": "foo",
        "include_args": {
            "arg1": "value1",
            "arg2": 42,
            "arg3": True,
        },
        "ansible_item_label": "item",
        "ansible_loop_var": "item"
    }
    t._host = "localhost"
    results = [t]

    vars = {}

    included_files = IncludedFile.process_include_results(
        results, iterator=None, loader=None, variable_manager=None
    )
    assert(len(included_files) == 1)

# Generated at 2022-06-21 00:49:40.589561
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    try:
        assert repr(IncludedFile(None, None, None, None)) == 'None (args=None vars=None): []'
    except AssertionError as e:
        print(repr(e))
        raise e
# end def test_IncludedFile___repr__

# Generated at 2022-06-21 00:49:49.306643
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # Test basic
    included_file = IncludedFile("1.yml", "2.yml", "3.yml", "4.yml")
    assert included_file._filename == "1.yml"
    assert included_file._args == "2.yml"
    assert included_file._vars == "3.yml"
    assert included_file._task == "4.yml"
    assert included_file._hosts == []
    assert included_file._is_role == False

    # Test __eq__
    included_file2 = IncludedFile("1.yml", "2.yml", "3.yml", "4.yml")
    assert included_file == included_file2

# Generated at 2022-06-21 00:49:54.731901
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename='/etc/apache2/conf.d/security.conf'
    args='dict()'
    vars='dict()'
    task='dict()'
    is_role='False'

    inc_file = IncludedFile(filename, args, vars, task, is_role)

    assert inc_file._filename == filename
    assert inc_file._args == args
    assert inc_file._vars == vars
    assert inc_file._task == task
    assert inc_file._is_role == is_role

# Generated at 2022-06-21 00:50:05.335363
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    import ansible.playbook.task

    hosts = []
    task = ansible.playbook.task.Task()
    # Add a host
    included_file = IncludedFile('filename', {}, {}, task)
    included_file.add_host('host1')
    assert included_file._hosts == ['host1']
    # Add another host
    included_file.add_host('host2')
    assert included_file._hosts == ['host1', 'host2']
    # Associate the same host which should raise an error
    try:
        included_file.add_host('host1')
        assert 1 == 2
    except ValueError:
        pass
    # Check that the hosts have not changed
    assert included_file._hosts == ['host1', 'host2']


# Generated at 2022-06-21 00:50:17.496470
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    import os
    import sys
    import shutil
    import pytest
    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    cur_dir = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.join(cur_dir, 'test_dir')
    example

# Generated at 2022-06-21 00:50:25.884195
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    mock_loader = DictDataLoader({})
    mock_inventory = Inventory(loader=mock_loader, variable_manager=VariableManager(), host_list=[])
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)

    mock_task_vars = dict()

    i1 = IncludedFile('file.yml', dict(), dict(), Task())
    i2 = IncludedFile('file.yml', dict(), dict(), Task())

    assert i1 == i2



# Generated at 2022-06-21 00:51:23.834186
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    object1 = IncludedFile('filename', 'args', 'vars', 'task')
    object2 = IncludedFile('filename', 'args', 'vars', 'task')

    assert(object1 == object2)


# Generated at 2022-06-21 00:51:31.824139
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    c = IncludedFile('file', {}, {}, {})

    # Add host to the list
    try:
        c.add_host('first')
        c.add_host('second')
    except:
        assert False, "Host was not added to the list"

    # Try to add the same host twice
    try:
        c.add_host('first')
        assert False, "Second host was added to the list"
    except:
        assert True

    # Try to add the same host twice
    try:
        c.add_host('second')
        assert False, "Second host was added to the list"
    except:
        assert True

# Generated at 2022-06-21 00:51:37.056981
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    assert eval(repr(IncludedFile('filename', 'args', 'vars', uuid='uuid', parent_uuid='parent'))) == \
           IncludedFile(filename='filename', args='args', vars='vars', uuid='uuid', parent_uuid='parent')


# Generated at 2022-06-21 00:51:50.148767
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # pylint: disable=unused-import
    # The 'ansible.inventory' module below is called by the Ansible class, so we need to import it to prevent
    # NoNameError in the code and for coverage to increment the code count
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    host1 = 'host1'
   

# Generated at 2022-06-21 00:51:59.801761
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename_task = "filename"
    args_task = "args"
    vars_task = "vars"
    task_task = "task"
    test_case = IncludedFile(filename_task, args_task, vars_task, task_task)
    assert test_case._filename == filename_task
    assert test_case._args == args_task
    assert test_case._vars == vars_task
    assert test_case._task == task_task
    assert test_case._hosts == []
    assert test_case._is_role == False


# Generated at 2022-06-21 00:52:09.235188
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    inc_file = IncludedFile("/path/to/file",
                            {'k1': 'v1'},
                            {'k2': 'v2'},
                            {'k3': 'v3'})
    assert inc_file._filename == "/path/to/file"
    assert inc_file._args == {'k1': 'v1'}
    assert inc_file._vars == {'k2': 'v2'}
    assert inc_file._task == {'k3': 'v3'}


# Generated at 2022-06-21 00:52:09.829995
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    pass

# Generated at 2022-06-21 00:52:17.175764
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    inc = IncludedFile('test_file', [1, 'test'],
                       {'_raw_params': "'test1'", 'name': 'test1'},
                       None, True)
    inc.add_host('host1')
    inc.add_host('host2')
    assert repr(inc) == "test_file (args=[1, 'test'] vars={'name': 'test1', '_raw_params': \"'test1'\"}): ['host1', 'host2']"


# Generated at 2022-06-21 00:52:23.301458
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    obj = IncludedFile("file", "args", "vars", "task")
    obj._hosts = ["host1", "host2"]
    assert repr(obj) == "file (args=args vars=vars): ['host1', 'host2']"



# Generated at 2022-06-21 00:52:32.015397
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    class MockHost:
        def __init__(self, name):
            self.name = name

    class MockTask:
        def __init__(self):
            self._uuid = 'mocktask'

    class MockPlay:
        def __init__(self):
            self._uuid = 'mockplay'

    host1 = MockHost('hostname')
    host2 = MockHost('otherhost')
    host3 = MockHost('nonunique')

    task1 = MockTask()
    task1._parent = MockPlay()

    # Test for a single host
    include1 = IncludedFile('filename', 'args', 'vars', task1)
    try:
        include1.add_host(host1)
    except ValueError:
        raise AssertionError("IncludedFile._hosts cannot be empty")