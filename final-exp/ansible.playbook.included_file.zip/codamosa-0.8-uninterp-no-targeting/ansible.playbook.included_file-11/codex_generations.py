

# Generated at 2022-06-21 00:43:11.256591
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    pass

# Generated at 2022-06-21 00:43:17.122015
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = 'filename'
    args = 'args'
    vars = 'vars'
    task = 'task'

    included_file = IncludedFile(filename, args, vars, task)

    assert included_file._filename == filename
    assert included_file._args == args
    assert included_file._vars == vars
    assert included_file._task == task
    assert included_file._hosts == []
    assert included_file._is_role == False

# Generated at 2022-06-21 00:43:29.796613
# Unit test for method __eq__ of class IncludedFile

# Generated at 2022-06-21 00:43:39.696250
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    """
    Test __eq__ method of class IncludedFile
    """
    filename = "test"
    args = dict()
    vars = dict()
    task = object()
    included_file = IncludedFile(filename, args, vars, task)

    # test add_host when passed host does not exist in self._hosts
    host = "test1"
    assert included_file.add_host(host) == None
    assert included_file._hosts == [host]

    # test add_host when passed host already exist in self._hosts
    assert included_file.add_host(host) == None
    assert included_file._hosts == [host]


# Generated at 2022-06-21 00:43:47.969830
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    called = False
    try:
        # attempt to construct an IncludedFile object in an invalid way
        test_included_file = IncludedFile("test_file", "test_args", "test_vars", "test_task")
    except Exception as e:
        if str(e) == "method add_host expected an object of type Host, received object of type str instead.":
            called = True
    assert called, "Expected constructor to throw exception: method add_host expected an object of type Host, received object of type str instead."

# Generated at 2022-06-21 00:43:52.401806
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    task_vars = {}
    loader = None
    variable_manager = None

    results = task_vars['result']
    iterator = task_vars['iterator']

    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    for i in included_files:
        print(str(i))

# test_IncludedFile_process_include_results()

# Generated at 2022-06-21 00:43:54.673545
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    obj = IncludedFile()
    assert isinstance(obj, IncludedFile)


# Generated at 2022-06-21 00:44:04.767468
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    test_parent_task = 'test_parent'
    test_task = 'test_task'
    test_filename = '/tmp/test_playbooks'
    test_args = {'verbose': True}
    test_host = 'host1.example.com'
    inc_file = IncludedFile(test_filename, test_args, {}, test_task)

    assert inc_file._filename == test_filename
    assert inc_file._args == test_args
    assert inc_file._task == test_task
    assert inc_file._hosts == []
    assert inc_file._is_role == False

    inc_file.add_host(test_host)
    assert inc_file._hosts == ['host1.example.com']

# Generated at 2022-06-21 00:44:14.561515
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    fake_loader = DataLoader()
    fake_variable_manager = VariableManager()
    fake_inventory = InventoryManager(loader=fake_loader, sources=[])

    fake_task = Task()
    fake_task._role_name = 'my_role'
    fake_task._role_path = '/roles/my_role'
    fake_task._role = None
    fake_task._parent = Block()

    fake_play_context = {}

   

# Generated at 2022-06-21 00:44:25.157131
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile('inc_file', {}, {}, 'parent_task')
    inc_file.add_host('host1')
    inc_file.add_host('host2')
    try:
        inc_file.add_host('host1')
    except ValueError:
        pass
    else:
        raise Exception('add_host() must not allow to add an existent host')
    if inc_file._hosts != ['host1', 'host2']:
        raise Exception('Unexpected host list')


# Generated at 2022-06-21 00:44:59.460729
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    file_name      = "foo.yaml"
    args           = "include_args"
    vars           = {"one": "two"}
    task           = "task"
    host           = "localhost"

    inc_file = IncludedFile(file_name, args, vars, task)
    inc_file.add_host(host)

    assert inc_file.__repr__() == "foo.yaml (args=include_args vars={'one': 'two'}): ['localhost']"

# Generated at 2022-06-21 00:45:10.216842
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    test_filename = 'test_filename'
    test_args = 'test_args'
    test_vars = 'test_vars'
    test_task = 'test_task'
    test_is_role = 'test_is_role'
    included_file = IncludedFile(test_filename, test_args, test_vars, test_task, test_is_role)
    assert included_file._filename == test_filename
    assert included_file._args == test_args
    assert included_file._vars == test_vars
    assert included_file._task == test_task
    assert included_file._hosts == []
    assert included_file._is_role == test_is_role

# Generated at 2022-06-21 00:45:23.495720
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task = TaskInclude('task')
    task._uuid = 'task-uuid'

    task_parent = TaskInclude('task_parent')
    task_parent._uuid = 'task_parent-uuid'
    task._parent = task_parent

    task2 = TaskInclude('task2')
    task2._uuid = 'task2-uuid'
    task2._parent = task_parent

    task_parent_diff = TaskInclude('task_parent_diff')
    task_parent_diff._uuid = 'task_parent_diff-uuid'
    task_diff = TaskInclude('task_diff')
    task_diff._uuid = 'task_diff-uuid'
    task_diff._parent = task_parent_diff

    filename = '/path/to/file.yml'
    args

# Generated at 2022-06-21 00:45:34.080667
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """
    Test __eq__ method of class IncludedFile.
    """

    import mock
    import imp
    from ansible.plugins import module_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    mock_loader = imp.load_source('mock_loader', './test/unit/plugins/loader/mock_loader.py')
    module_loader.add_directory(mock_loader.path)

    def fake_get_vars(self, play, host, task):
        if play._basedir:
            basedir = play._basedir
        else:
            basedir = '.'
        self._basedir = basedir
        self._hostname = host.name

# Generated at 2022-06-21 00:45:44.598211
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert IncludedFile("filename1", {'k1': 'v1'}, {'k1': 'v1'}, "task1") != IncludedFile("filename2", {'k1': 'v1'}, {'k1': 'v2'}, "task2")
    assert IncludedFile("filename1", {'k1': 'v1'}, {'k1': 'v2'}, "task2") != IncludedFile("filename2", {'k1': 'v1'}, {'k1': 'v1'}, "task1")
    assert IncludedFile("filename1", {'k1': 'v2'}, {'k1': 'v1'}, "task1") != IncludedFile("filename2", {'k1': 'v1'}, {'k1': 'v1'}, "task1")


# Generated at 2022-06-21 00:45:53.256361
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class TestClass:
        _uuid = 1
    args = {'arg1': 1, 'arg2': 2}
    vars = {'var1': 1, 'var2': 2}
    task = TestClass()
    filename = 'test'

    testObj = IncludedFile(filename, args, vars, task)
    assert repr(testObj) == "test (args={'arg1': 1, 'arg2': 2} vars={'var1': 1, 'var2': 2}): []"


# Generated at 2022-06-21 00:46:05.130715
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task = TaskInclude('a_task')
    vars = {'a': 1, 'b': 2}
    filename = 'foo.yaml'
    args = {'a': 'b'}
    e1 = IncludedFile(filename, args, vars, task)
    e2 = IncludedFile(filename, args, vars, task)

    assert e1 == e2

    e2._hosts = ['host1']
    assert e1 != e2

    e1._hosts = ['host1']
    assert e1 == e2

    e2._args['a'] = 'c'
    assert e1 != e2

    e2._args['a'] = 'b'
    assert e1 == e2

    e2._filename = 'bar.yaml'
    assert e1 != e2

    e2._

# Generated at 2022-06-21 00:46:09.315275
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    inc_file = IncludedFile(None, None, None, None)
    assert 'None (args=None vars=None): []' == inc_file.__repr__()

# Generated at 2022-06-21 00:46:18.598958
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook import Playbook, PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """
        def __init__(self, *args, **kwargs):
            super

# Generated at 2022-06-21 00:46:28.543277
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-21 00:47:00.071790
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import pdb
    try:
        IncludedFile('filename', 'args', 'vars', 'task')
    except ValueError:
        pdb.post_mortem()

# Generated at 2022-06-21 00:47:07.986025
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    include_file = IncludedFile('filename', {}, {}, None)
    include_file.add_host('host1')
    assert len(include_file._hosts) == 1
    assert include_file._hosts[0] == 'host1'

    try:
        include_file.add_host('host1')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-21 00:47:10.676571
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    iterator = None
    loader = None
    variable_manager = None

    file_name = IncludedFile.process_include_results([], iterator, loader, variable_manager)
    file_name = IncludedFile.process_include_results(file_name, iterator, loader, variable_manager)

# Generated at 2022-06-21 00:47:15.146484
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    inc_task = IncludedFile(filename='file1', args=dict(), vars=dict(), task='task1')
    assert inc_task._filename == 'file1'
    assert inc_task._args == dict()
    assert inc_task._vars == dict()
    assert inc_task._task == 'task1'



# Generated at 2022-06-21 00:47:25.069523
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    tmp_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'vars', 'test.yml')
    loader = None
    variable_manager = None
    tmp_task = TaskInclude(loader, variable_manager, filename=tmp_file, task=None, block=None, role=None)
    tmp_host = "host"

    m_args = dict()
    m_args['tags'] = ['test']
    m_args['when'] = 'test'
    m_args['name'] = 'test'
    tmp_vars = {"m_args": m_args}

    inc1 = IncludedFile(tmp_file, m_args, tmp_vars, tmp_task, False)
    inc1.add_host(tmp_host)


# Generated at 2022-06-21 00:47:35.409360
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import loader as plugin_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({'.': {
        'common.yml': '',
        'webservers.yml': '',
        'roles': {
            'riemann': {
                'tasks': {
                    'main.yml': '''
                      - import_tasks: webservers.yml
                    ''',
                },
            },
        },
    }})
    variable_manager = VariableManager(loader=loader)
    play_context = Play

# Generated at 2022-06-21 00:47:45.153683
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from collections import namedtuple
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    PlayResult = namedtuple('PlayResult', 'play task host task_result')
    RoleResult = namedtuple('RoleResult', '_host _task')

# Generated at 2022-06-21 00:47:53.459737
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible import context
    from ansible.vars import VariableManager

    vars_manager = VariableManager()
    context._init_global_context(vars_manager)

    results = IncludedFile.process_include_results_test()
    included_files = IncludedFile.process_include_results(results,
                                                          iterator=None,
                                                          loader=None,
                                                          variable_manager=None)
    assert len(included_files) == 1
    assert len(included_files[0]._hosts) == 2


# Test data structure for method process_include_results of class IncludedFile

# Generated at 2022-06-21 00:48:04.542606
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    a = IncludedFile('abc.yml', {}, {}, Task())
    b = IncludedFile('abc.yml', {}, {}, Task())
    c = IncludedFile('xyz.yml', {}, {}, Task())

    assert (a == b)
    assert (b == a)
    assert (not (a == c))
    assert (not (c == a))

    e = IncludedFile('abc.yml', {'a': 1}, {}, Task())
    assert (not (a == e))
    assert (not (e == a))

    f = IncludedFile('abc.yml', {}, {'a': 1}, Task())
    assert (not (a == f))
    assert (not (f == a))



# Generated at 2022-06-21 00:48:10.034446
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import sys
    from ansible.module_utils.six import PY2

    args = dict()

    # To test __eq__, we need to create 2 objects, then compare them.
    class ParentTestClass:
        _uuid = "1234"
        _parent = None
    parentObj = ParentTestClass()

    class TestClass:
        def __init__(self):
            self.action = "test_action"
            self._uuid = "test_uuid"
            self._parent = parentObj

    obj = TestClass()

    # Create 2 objects, then compare them.
    file1 = IncludedFile("test_file_1", args, args, obj)
    file2 = IncludedFile("test_file_2", args, args, obj)
    assert(file1 == file2)

    # Create 2 objects, then

# Generated at 2022-06-21 00:49:11.639233
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file_1 = IncludedFile(filename='/path/to/tasks/main.yml', args={'x': 1, 'y': 2}, vars={'a': 1, 'b': 2}, task=None, is_role=False)
    included_file_2 = IncludedFile(filename='/path/to/roles/common/tasks/main.yml', args={'x': 1, 'y': 2}, vars={'a': 1, 'b': 2}, task=None, is_role=True)
    assert isinstance(included_file_1, IncludedFile)
    assert isinstance(included_file_2, IncludedFile)
    assert included_file_1._filename == '/path/to/tasks/main.yml'

# Generated at 2022-06-21 00:49:16.339483
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile('test', 'args', 'vars', 'task')
    included_file._hosts=['host1']
    assert repr(included_file) == "test (args=args vars=vars): ['host1']"


# Generated at 2022-06-21 00:49:21.239042
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    c0 = IncludedFile("1", "2", "3", "4")
    assert c0._filename == "1" and c0._args == "2" and c0._vars == "3" and c0._task == "4"


if __name__ == "__main__":
    test_IncludedFile()

# Generated at 2022-06-21 00:49:31.931966
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file1 = IncludedFile('filename', 'args', 'vars', 'task')
    included_file2 = IncludedFile('filename', 'args', 'vars', 'task')
    included_file3 = IncludedFile('filename1', 'args', 'vars', 'task')
    included_file4 = IncludedFile('filename', 'args1', 'vars', 'task')
    included_file5 = IncludedFile('filename', 'args', 'vars1', 'task')
    included_file6 = IncludedFile('filename', 'args', 'vars', 'task1')
    included_file7 = IncludedFile('filename', 'args', 'vars', 'task', True)

    assert included_file1 == included_file2
    assert not included_file1 == included_file3
    assert not included_file1 == included_file4
   

# Generated at 2022-06-21 00:49:42.600404
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_data = [
        ("filename", "arguments", "variables", "task", False),
        ("filename", "arguments", "variables", "task", True)
    ]

    result = [IncludedFile(*data) for data in test_data]

    assert result[0] == result[0]
    assert not result[0] != result[0]
    assert result[0] != result[1]
    assert result[1] != result[0]
    assert not (result[0] == result[1])


# Generated at 2022-06-21 00:49:54.100892
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # The args are different
    a = IncludedFile('test_filename', 'test_args_1', 'test_vars', 'test_task')
    b = IncludedFile('test_filename', 'test_args_2', 'test_vars', 'test_task')
    assert a != b

    # The vars are different
    a = IncludedFile('test_filename', 'test_args', 'test_vars_1', 'test_task')
    b = IncludedFile('test_filename', 'test_args', 'test_vars_2', 'test_task')
    assert a != b

    # The tasks differ
    a = IncludedFile('test_filename', 'test_args', 'test_vars', 'test_task_1')

# Generated at 2022-06-21 00:50:05.057584
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    host = "test_host"
    task_uuid = "0123456789"
    task_uuid2 = "9876543210"
    filename = "/tmp/foo.yml"
    args = dict(a=1, b=2)
    vars = dict(QUESTION="the answer is 42")
    role = "role"
    play_context = PlayContext()
    task = Task()
    task._uuid = task_uuid
    task_name = "Task 1"
    task._parent = task

# Generated at 2022-06-21 00:50:15.201735
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    ''' Unit test for constructor of class IncludedFile'''
    filename = 'filename'
    args = 'args'
    vars = 'vars'
    task = 'task'
    is_role = 'is_role'
    host = 'host'
    inc_file = IncludedFile(filename, args, vars, task, is_role)
    assert inc_file._filename == filename
    assert inc_file._args == args
    assert inc_file._vars == vars
    assert inc_file._task == task
    assert inc_file._hosts == []
    assert inc_file._is_role == is_role


# Generated at 2022-06-21 00:50:19.084621
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile('filename', 'args', 'vars', 'task')
    b = IncludedFile('filename2', 'args2', 'vars2', 'task')
    c = IncludedFile('filename', 'args', 'vars', 'task')

    assert a == c
    assert a != b


# Generated at 2022-06-21 00:50:27.614707
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = 'sample.yml'
    args = {}
    vars = {}
    task = task_fixture
    is_role = False

    inc_file = IncludedFile(filename, args, vars, task, is_role)

    assert inc_file._filename == 'sample.yml'
    assert inc_file._args == {}
    assert inc_file._vars == {}
    assert inc_file._task == task_fixture
    assert inc_file._is_role == False

# Task fixture for unit test
task_fixture = type('obj', (object,), {
    '_attributes': {},
    '_parent': None,
    '_role': None,
    'action': 'something',
    'loop': False,
    '_uuid': '123',
})