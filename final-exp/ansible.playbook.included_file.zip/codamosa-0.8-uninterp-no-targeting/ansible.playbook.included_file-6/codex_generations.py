

# Generated at 2022-06-21 00:43:21.442536
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # initialize an IncludedFile class
    inc_file = IncludedFile('filename', 'args', 'vars', 'task')
    # test that the add_host function returns no error
    assert inc_file.add_host('host') == None

# Generated at 2022-06-21 00:43:29.070328
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class Host:
        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return self.name

    class Task:
        _uuid = 'test_uuid'
        _parent = 'parent_uuid'

    inc_file = IncludedFile('filename', 'args', 'vars', Task())
    inc_file._hosts = [Host('host')]
    assert str(inc_file) == "filename (args=args vars=vars): ['host']"


# Generated at 2022-06-21 00:43:33.365974
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Arrange
    IncludedFile = Ansible.Task.IncludedFile
    x = IncludedFile(filename="test", args="test", vars="test", task="test")

    # Act
    result = x.add_host("host")

    # Assert
    assert result == None


# Generated at 2022-06-21 00:43:42.713368
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    file_options = {'_parent': '', 'action': 'include', 'loop': None, 'no_log': False, 'static': False}
    file_task = IncludedFile('filename', 'args', 'vars', file_options)
    assert file_task._filename == 'filename'
    assert file_task._args == 'args'
    assert file_task._vars == 'vars'
    assert file_task._task == file_options
    assert file_task._hosts == []



# Generated at 2022-06-21 00:43:52.340644
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import fragment_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = fragment_loader.add_directory(loader, C.DEFAULT_FRAGMENT_PLUGIN_PATH)

    play_context = PlayContext()
    templar = Templar(loader=loader, variable_manager=variable_manager,
        shared_loader_obj=loader, fail_on_undefined=C.DEFAULT_UNDEFINED_VAR_BEHAVIOR)

    # The same except for the uuids
    if_ = IncludedFile('/home/username/ansible/main.yml', dict(), dict(), 'task1')
    if_

# Generated at 2022-06-21 00:44:04.154526
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    ''' Test __eq__ method of class IncludedFile
        Assertion:
            - returns true if the tasks have the same attributes;
            - returns false otherwise.
    '''
    # pylint: disable=too-many-instance-attributes
    # pylint: disable=attribute-defined-outside-init
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.task import Task

    filename = "some_file.yaml"
    args = {"some_var": "some_val"}
    vars = {"some_var_2": "some_val_2"}
    uuid = "some_uuid"
    parent_uuid = "some_parent_uuid"
    is_role = True
    __task = Task()
    __task._uuid = uuid


# Generated at 2022-06-21 00:44:09.456520
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = '/home/michael.dehaan/playbooks/webservers.yml'
    args = {}
    vars = {}
    task = None

    included_file1 = IncludedFile(filename, args, vars, task, False)
    included_file2 = IncludedFile(filename, args, vars, task, False)

    assert(included_file1 == included_file2)


# Generated at 2022-06-21 00:44:21.664554
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    import pytest

# Generated at 2022-06-21 00:44:26.199623
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile(None, None, None, None, None)

    # Check if we can add the same host twice
    host1 = "test.example.com"
    inc_file.add_host(host1)

    try:
        inc_file.add_host(host1)
        assert(False)
    except ValueError:
        assert(True)

    # Check if we can add 2 different hosts
    host2 = "test2.example.com"
    inc_file.add_host(host2)

    assert(len(inc_file._hosts) == 2)


# Generated at 2022-06-21 00:44:39.482370
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    # Test for add a host to a null IncludedFile
    included_file = IncludedFile('', '', '', '')
    assert included_file.add_host('myhost'), "It can not add host to a null IncludedFile"
    assert included_file._hosts == ['myhost'], "It can not add host to a null IncludedFile"

    # Test for add a host to a valid IncludedFile
    included_file = IncludedFile('include_file', 'include_args', 'include_vars', 'original_task')
    assert included_file.add_host('myhost'), "It can not add host to a null IncludedFile"
    assert included_file._hosts == ['myhost'], "It can not add host to a null IncludedFile"

    # Test for add a repeated host to a valid IncludedFile
    assert included_file.add_

# Generated at 2022-06-21 00:45:09.827007
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """
    Test object equality for class IncludedFile.
    """
    filename = "/path/to/file"
    args = {'one': 1}
    vars = {'two': 2}

    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult
    task = Task()
    task._parent = Play()
    task._parent._play = Play()
    task_result = TaskResult(task, "localhost")

    inc_file1 = IncludedFile(filename, args, vars, task_result)
    inc_file2 = IncludedFile(filename, args, vars, task_result)

    assert inc_file1 == inc_file2

# Generated at 2022-06-21 00:45:23.332616
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    print('test_IncludedFile_add_host')
    filename = 'filename'
    args = {}
    vars = {}
    task = None
    is_role = False
    inc_file = IncludedFile(filename, args, vars, task, is_role)
    assert inc_file._hosts == []
    host1 = 'host1'
    host2 = 'host2'
    inc_file.add_host(host1)
    assert inc_file._hosts == [host1]
    inc_file.add_host(host2)
    assert inc_file._hosts == [host1, host2]
    # Adding an existing host should raise a ValueError
    try:
        inc_file.add_host(host2)
    except ValueError:
        pass

# Generated at 2022-06-21 00:45:31.465465
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_file = IncludedFile("a.yml", {}, {}, "task")
    included_file.add_host("host1")
    included_file.add_host("host2")

    assert len(included_file._hosts) == 2
    assert "host1" in included_file._hosts
    assert "host2" in included_file._hosts

    try:
        included_file.add_host("host1")
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-21 00:45:43.788810
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    class Options:
        connection = 'local'

    class MockConnection:
        def __init__(self, runner):
            pass

        def exec_command(self, cmd, tmp_path, sudo_user=None, sudoable=False, executable='/bin/sh'):
            return (0, '', '')

        def put_file(self, in_path, out_path):
            return (0, '', '')


# Generated at 2022-06-21 00:45:54.987063
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    file1 = IncludedFile('path/to/file', dict(), dict(), None)
    file2 = IncludedFile('path/to/file', dict(), dict(), None)
    file3 = IncludedFile('other/path/to/file', dict(), dict(), None)
    file4 = IncludedFile('path/to/file', dict(arg1=1,arg2=2), dict(var1=1,var2=2), None)
    file5 = IncludedFile('path/to/file', dict(arg1=1,arg2=2), dict(var1=1,var2=2), None)
    assert(file1 == file2)
    assert(not (file1 == file3))
    assert(file4 == file5)
    assert(not (file1 == file4))


# Generated at 2022-06-21 00:46:05.804113
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    t = TaskInclude()
    t._parent = 'test'
    t._uuid = 'test'
    f1 = IncludedFile('test', [], [], t)
    f2 = IncludedFile('test', [], [], t)
    f3 = IncludedFile('test', ['t'], [], t)
    f4 = IncludedFile('test', [], ['t'], t)
    f5 = IncludedFile('test', ['t'], ['t'], t)
    f6 = IncludedFile('test', [], [], 't')
    f7 = IncludedFile('test1', [], [], t)
    f8 = IncludedFile('test', [], [], t, True)

    assert(f1 == f2)
    assert(f1 != f3)
    assert(f1 != f4)

# Generated at 2022-06-21 00:46:16.071635
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    filename = "test_filename"
    args = dict()
    vars = dict()
    host = "test_host"

    play = Play()
    task = Task()
    task._parent = play

    inc_file = IncludedFile(filename, args, vars, task)
    inc_file.add_host(host)

    # Use the repr() method to get the same object
    inc_file2 = eval(repr(inc_file))

    assert inc_file == inc_file2 and repr(inc_file) == repr(inc_file2)


# Generated at 2022-06-21 00:46:27.725916
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class FakeLoader:
        def get_basedir(self):
            return "."

    class FakeIterator:
        def __init__(self):
            self._play = FakePlay()

    class FakePlay:
        def __init__(self):
            self._included_files = []

    class FakeTask:
        def __init__(self, action):
            self.action = action
            self.loop = False
            self._uuid = 42
            self.no_log = False
            self._parent = None
            self._from_files = dict()

        def copy(self):
            return self

        def get_search_path(self):
            return list()

    class FakeResult:
        def __init__(self, task_action, result, host):
            self._task = FakeTask(task_action)
           

# Generated at 2022-06-21 00:46:36.982924
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import unittest

    class VariableManager:
        def __init__(self, playbook):
            playbook_vars = playbook.get_variable_manager()._playbook_vars
            self._vars_cache = {(playbook, None, None): playbook_vars}

        def get_vars(self, play, host, task):
            return self._vars_cache[(play, host, task)]

    class Loader:
        def get_basedir(self):
            return '/tmp'

        def path_dwim(self, path):
            return path

        def path_dwim_relative(self, basedir, relative_path, path):
            return 'path_dwim_relative'

    class Playbook:
        def get_variable_manager(self):
            return VariableManager(self)

   

# Generated at 2022-06-21 00:46:45.340919
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # Initialize set up the environment
    # Run test
    # Check the result
    included_file = IncludedFile('filename', 'args', 'vars', 'task')
    included_file.add_host('host')

    assert included_file._filename == 'filename'
    assert included_file._args == 'args'
    assert included_file._vars == 'vars'
    assert included_file._task == 'task'
    assert included_file._hosts == ['host']



# Generated at 2022-06-21 00:47:35.658612
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    inc_file_1 = IncludedFile('filename', 'args', 'vars', 'task', 'is_role')
    inc_file_2 = IncludedFile('filename', 'args', 'vars', 'task', 'is_role')
    assert inc_file_1.__eq__(inc_file_2) is True

# Generated at 2022-06-21 00:47:45.597727
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    from ansible.playbook import PlayContext
    from ansible.module_utils.basic import AnsibleModule

    module_kwargs = dict(
        argument_spec=dict(
            msg=dict(type='str', required=True),
        ),
        supports_check_mode=True,
    )

    module = AnsibleModule(**module_kwargs)
    results = [module.res]
    context = PlayContext()
    context._play = None
    context._play_hosts = None
    context._play_name = None
    context._play_basedir = None
    context._task = None
    context._task_type = None
    context._task_name = None
    context._task_args = None
    context._task_action = None
    context._task_path = None

# Generated at 2022-06-21 00:47:54.734983
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.base import Base
    import copy

    included_file1 = IncludedFile('../tasks/main.yml', {}, {}, Base(), False)
    included_file2 = IncludedFile('../tasks/main.yml', {}, {}, Base(), False)
    included_file3 = IncludedFile('../tasks/main.yml', {'v1':1}, {}, Base(), False)
    included_file4 = IncludedFile('../tasks/main.yml', {'v1':1}, {}, Base(), False)
    included_file5 = IncludedFile('../tasks/main.yml', {'v2':2}, {}, Base(), False)

# Generated at 2022-06-21 00:47:58.733867
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename_ = 'tasks/test.yml'
    args_ = {'test1': 1, 'test2': 2}
    vars_ = {'var1': 'v1', 'var2': 'v2'}
    task_ = 'include'
    assert (IncludedFile(filename_, args_, vars_, task_).__repr__() ==
            "tasks/test.yml (args={'test1': 1, 'test2': 2} vars={'var2': 'v2', 'var1': 'v1'}): []")


# Generated at 2022-06-21 00:48:05.859111
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    """add_host of class IncludedFile should add host to list of hosts if not present,
    otherwise ValueError is raised.

    This unittest tests those two cases.
    """
    included_file = IncludedFile("/path/to/file", dict(), dict(), object())

    # add_host should not raise any exception
    included_file.add_host("localhost")
    assert included_file._hosts == ["localhost"]

    # should raise ValueError
    try:
        included_file.add_host("localhost")
    except ValueError:
        assert included_file._hosts == ["localhost"]
    else:
        raise AssertionError

# Generated at 2022-06-21 00:48:08.243764
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    f = IncludedFile('/etc/hosts', {}, {}, 'task')
    f.add_host('host1')
    try:
        f.add_host('host1')
        assert False, "failed to raise ValueError()"
    except ValueError:
        pass
    f.add_host('host2')

# Generated at 2022-06-21 00:48:16.542641
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import imp
    import io

    test_file = imp.find_module('ansible.test.test_include')[1]
    test_path = os.path.dirname(test_file)
    test_file = os.path.join(test_path, 'ansible.test.test_include.yml')

    test_file_d = imp.find_module('ansible.test.test_include_dynamic')[1]
    test_path_d = os.path.dirname(test_file_d)
    test_file_d = os.path.join(test_path_d, 'ansible.test.test_include_dynamic.yml')

    test_file_e = imp.find_module('ansible.test.test_include_extra')[1]

# Generated at 2022-06-21 00:48:24.907451
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    inc_file = IncludedFile("/home/user/file.yml", {'with_items': ['1', '2', '3']}, "vars", "task")
    inc_file.add_host("host1")
    inc_file.add_host("host2")
    inc_file.add_host("host3")

    result = inc_file.__repr__()
    assert result == "/home/user/file.yml (args={'with_items': ['1', '2', '3']} vars=vars): ['host3', 'host2', 'host1']"

# Generated at 2022-06-21 00:48:35.859968
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import ansible.playbook.task

    task1 = ansible.playbook.task.Task()
    task2 = ansible.playbook.task.Task()
    task3 = ansible.playbook.task.Task()

    base_args = dict()
    base_args['_uuid'] = task1._uuid
    base_args['loop_control'] = task1.loop_control
    base_args['action'] = 'include'
    base_args['_role'] = task1._role
    base_args['when'] = task1.when
    base_args['delegate_to'] = task1.delegate_to
    base_args['loop'] = task1.loop
    base_args['tags'] = task1.tags
    base_args['any_errors_fatal'] = task1.any_errors

# Generated at 2022-06-21 00:48:38.052820
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    pass


# Generated at 2022-06-21 00:49:30.758308
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    var = dict()
    var['var'] = 'test'
    test_obj = IncludedFile('filename', var, var, 'task')
    assert test_obj._filename == 'filename'
    assert test_obj._args == var
    assert test_obj._task == 'task'
    assert test_obj._is_role == False
    assert repr(test_obj) == "filename (args={'var': 'test'} vars={'var': 'test'}): []"

    # test add_host()
    try:
        test_obj.add_host("host")
        assert test_obj._hosts == ["host"]
        test_obj.add_host("host")
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError expected")


# Generated at 2022-06-21 00:49:44.576907
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import vars_loader
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.executor.playbook_iterator import TaskIterator
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor

    display = Display()

    lookup = lookup_loader.get('file')
    var_mgr = VariableManager()
    # var_mgr.set_inventory(inventory)


# Generated at 2022-06-21 00:49:54.597792
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from ansible.playbook.task import Task
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    host = Host(name="localhost", port=22)
    task = Task()
    base = Base()
    base._parent = Play()
    task._parent = base
    ifile = IncludedFile("/etc/hosts", "args", {}, task)
    ifile.add_host(host)
    ifile.add_host(host)

# Generated at 2022-06-21 00:50:05.276470
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.vars.unsafe_proxy import UnsafeProxy

    filename = '/etc/yum.repos.d/s3tools.repo'
    args = {'_raw_params': 's3://oliver-s3tools/s3tools.repo', 'name': 's3tools', 'state': 'present'}
    vars = {'arg1': 'value1'}
    task_uuid = '2d6bbd7f-0cc6-4140-a5e5-5bd7b56a6b5a'

# Generated at 2022-06-21 00:50:17.452224
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager

    if not C.DEFAULT_LOADER:
        # Handle the case where we didn't load the config
        loader = DataLoader()
    else:
        loader = C.DEFAULT_LOADER

    variable_manager = VariableManager()

    # instantiate our result callback
    results_callback = ResultCallback()
    results_callback._tqm = TaskQueueManager(inventory=None, variable_manager=variable_manager)
    results_callback._host = None
    results_callback._task = TaskInclude()
    results_callback._task._loader = loader
    results_callback._task._templar = Templar(loader=loader, variables=variable_manager.get_vars(loader=loader))
   

# Generated at 2022-06-21 00:50:22.667229
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile("filename", "args", "vars", "task")
    test_host = "test host"
    inc_file.add_host(test_host)
    assert inc_file._hosts == [test_host]

    try:
        inc_file.add_host(test_host)
        assert False, "Fail to raise ValueError"
    except ValueError:
        pass


# Generated at 2022-06-21 00:50:29.821082
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = "include_task.yml"
    args = {}
    vars = {}
    task = ""
    included_file = IncludedFile(filename, args, vars, task)

    # add host to IncludedFile
    included_file.add_host("192.168.1.1")
    assert "192.168.1.1" in included_file._hosts

    # ensure that method do not add host if it is already in hosts list
    try:
        included_file.add_host("192.168.1.1")
        assert False
    except ValueError:
        assert True
    assert "192.168.1.1" in included_file._hosts

# Generated at 2022-06-21 00:50:37.948890
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    fake_loader = DataLoader()
    fake_invent = InventoryManager(loader=fake_loader, sources='localhost,')
    fake_var_manager = VariableManager(loader=fake_loader, inventory=fake_invent)
    fake_play_context = PlayContext()
    fake_task = Task()
    fake_task._uuid = 'myuuid'
    fake_task._

# Generated at 2022-06-21 00:50:43.393403
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    """The method `add_host` should raise ValueError if a host already exists"""
    in_file = IncludedFile("test", 1, 2, 3)
    in_file.add_host("test_host")
    try:
        in_file.add_host("test_host")
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-21 00:50:51.123622
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc1 = IncludedFile('a', 1, 2, None)
    inc2 = IncludedFile('a', 1, 2, None)
    inc3 = IncludedFile('b', 1, 2, None)

    inc1.add_host('host1')
    inc1.add_host('host2')
    assert inc1._hosts == ['host1', 'host2']
    try:
        inc1.add_host('host1')
        assert False, 'ValueError was not raised'
    except ValueError:
        pass

    inc2.add_host('host2')
    inc2.add_host('host3')
    assert inc2._hosts == ['host2', 'host3']

    inc3.add_host('host1')
    inc3.add_host('host2')