

# Generated at 2022-06-21 00:43:11.500126
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    host = "localhost"
    filename = "file.yml"
    task = mock.Mock()
    inc_file = IncludedFile(filename, "args", "vars", task)
    assert(inc_file._filename == filename)
    assert(inc_file._args == "args")
    assert(inc_file._vars == "vars")
    assert(inc_file._task == task)
    assert(inc_file._task._uuid == task._uuid)
    assert(inc_file._task._parent._uuid == task._parent._uuid)
    assert(inc_file._hosts == [])
    assert(inc_file._is_role == False)

    inc_file2 = IncludedFile(filename, "args", "vars", task)
    assert(inc_file == inc_file2)


# Generated at 2022-06-21 00:43:18.437132
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    PLAYBOOK_PATH = './test_playbook.yml'


# Generated at 2022-06-21 00:43:24.097771
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    test_file_name = "test"
    test_args = "test"
    test_vars = "test"
    test_task = "test"
    includedFile = IncludedFile(test_file_name, test_args, test_vars, test_task)
    assert includedFile._filename == test_file_name
    assert includedFile._args == test_args
    assert includedFile._vars == test_vars
    assert includedFile._task == test_task
    assert includedFile._hosts == []
    assert includedFile._is_role == False

# Generated at 2022-06-21 00:43:37.245296
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    filename = './hosts'
    args = '2.2'
    vars = {'foo': 'bar'}
    play = Play.load(dict(name='play_test', hosts=['test'], tasks=[]), loader=None, variable_manager=None)
    tasks = [dict(name='test', include=filename, args=vars)]
    task = Task.load(tasks, play)
    context = PlayContext(play=play)
    host = Host(name='test', port=22)
    include = IncludedFile(filename=filename, args=args, vars=vars, task=task)

# Generated at 2022-06-21 00:43:39.302792
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO: implement unit test
    pass

# Generated at 2022-06-21 00:43:43.474033
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    test_file = IncludedFile('file', 'args', 'vars', 'task')
    test_file._hosts.append('host1')
    test_file._hosts.append('host2')
    assert test_file.__repr__() == 'file (args=args vars=vars): [\'host1\', \'host2\']'

# Generated at 2022-06-21 00:43:47.506534
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'filename'
    args = 'args'
    vars = 'vars'
    task = 'task'
    res = IncludedFile(filename, args, vars, task)
    assert res.__repr__() == "filename (args=args vars=vars): []"

# Generated at 2022-06-21 00:43:53.040138
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    class Fake:
        def __init__(self, host):
            self._host = host

    class FakeHost:
        def __repr__(self):
            return "host"

    f1 = Fake(FakeHost())
    f2 = Fake(FakeHost())

    inc = IncludedFile(None, None, None, None)
    inc.add_host(f1)
    inc.add_host(f2)

    try:
        inc.add_host(f1)
        assert False
    except ValueError:
        pass



# Generated at 2022-06-21 00:44:04.612973
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    def create_result(host, include, loop_var=None, include_args=None, index_var=None, item_label=None, loop=None, task=None, failed=None, skipped=None):
        res = object()
        res._host = host
        res._result = {'include': include}
        if loop_var:
            res._result['ansible_loop_var'] = loop_var
        if index_var:
            res._result['ansible_index_var'] = index_var
        if item_label:
            res._result['_ansible_item_label'] = item_label
        if loop:
            res._result['ansible_loop'] = loop
        if include_args:
            res._result['include_args'] = include_args
        if task:
            res._task = task

# Generated at 2022-06-21 00:44:10.655283
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = "filename"
    task = "task"
    args = ["arg1", "arg2"]
    hosts = ["host1", "host2"]
    ifile = IncludedFile(filename, args, task)
    ifile.add_host(hosts)
    result = ifile.__repr__()
    assert(result == 'filename (args=[\'arg1\', \'arg2\'] vars=None): [host1, host2]')

# Generated at 2022-06-21 00:44:31.125620
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-21 00:44:38.832432
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
        included_file=IncludedFile("filename", "args", "vars", "task")
        assert included_file._filename == "filename"
        assert included_file._args == "args"
        assert included_file._vars == "vars"
        assert included_file._task == "task"
        assert included_file._hosts == []
        assert included_file._is_role is False
        assert included_file.__repr__() == "filename (args=args vars=vars): []"

# Generated at 2022-06-21 00:44:50.545821
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task

    assert IncludedFile('foo', {'one': 1}, {'two': 2}, Task()) == IncludedFile('foo', {'one': 1}, {'two': 2}, Task())

    assert IncludedFile('foo', {'one': 1}, {'two': 2}, Task()) != IncludedFile('foo', {'one': 1}, {'two': 2, 'three': 3}, Task())
    assert IncludedFile('foo', {'one': 1}, {'two': 2}, Task()) != IncludedFile('foo', {'one': 1, 'one': 2}, {'two': 2}, Task())
    assert IncludedFile('foo', {'one': 1}, {'two': 2}, Task()) != IncludedFile('foo', {'one': 1}, {'two': 2}, Task())

    # At the time of writing, this

# Generated at 2022-06-21 00:45:02.104900
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import json

    # Suppress deprecation warnings
    display.deprecation_warnings = False

    fake_loader = DataLoader()

    fake_inventory = InventoryManager(loader=fake_loader, sources='localhost,')
    variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)

    task1 = Task()
    task1._uuid = 'task1'
    task1.action = 'include'
    task1.args = dict()

# Generated at 2022-06-21 00:45:07.688536
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    result = IncludedFile("test_file", "test_args", "test_vars", "test_task", False)
    assert result.__repr__() == "test_file (args=test_args vars=test_vars): []"



# Generated at 2022-06-21 00:45:21.716756
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import copy
    class fake_TaskInclude(object):
        _uuid = 'task_include_uuid'
        class fake_parent(object):
            _uuid = 'parent_uuid'
        _parent = fake_parent
    class fake_Handler(object):
        _uuid = 'handler_uuid'
        class fake_parent(object):
            _uuid = 'parent_uuid'
        _parent = fake_parent
    class fake_IncludeRole(object):
        class fake_handler(object):
            _uuid = 'handler_uuid'
            class fake_parent(object):
                _uuid = 'parent_uuid'
            _parent = fake_parent
        _handler = fake_handler
    class fake_task(object):
        _uuid = 'task_uuid'
       

# Generated at 2022-06-21 00:45:33.475754
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    filename = 'test_filename'
    args = {'test_args': 'test_args'}
    vars = {'test_vars': 'test_vars'}
    play_context = PlayContext()
    task = Task()
    task.async_val = 0
    task.action = 'test_action'
    task.ad_hoc_attribute_count = 0
    task.always_run = False
    task.any_errors_fatal = False
    task.block = None
    task.changed_when = False
    task.check_mode = False
    task.delegate_facts = True
    task.delegate_to = None

# Generated at 2022-06-21 00:45:34.230457
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    ifile = IncludedFile()
    ifile

# Generated at 2022-06-21 00:45:43.821325
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.playbook.play
    import ansible.playbook.task
    
    class Host:
        def __init__(self, name):
            self.name = name
            
    class Task:
        def __init__(self, task_uuid, parent_uuid, action):
            self._uuid = task_uuid
            self._parent_uuid = parent_uuid
            self.action = action
            
        @property
        def _parent(self):
            return self._parent_uuid
            
        def __eq__(self, other):
            return (other._uuid == self._uuid and 
                    other._parent_uuid == self._parent_uuid and 
                    other.action == self.action)
                    

# Generated at 2022-06-21 00:45:55.273818
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # test 1 passed
    filename = "i.txt"
    args = "arg1"
    vars = "v1"
    task = "task1"
    is_role = False
    inc_file = IncludedFile(filename, args, vars, task, is_role)
    inc_file.add_host("host1")
    print("test 1 passed")

    # test 2 failed
    # filename = "i.txt"
    # args = "arg1"
    # vars = "v1"
    # task = "task1"
    # is_role = False
    #
    # inc_file = IncludedFile(filename, args, vars, task, is_role)
    # inc_file.add_host("host1")
    #
    # try:
    #     inc_file.add_

# Generated at 2022-06-21 00:46:31.957561
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = '/path/to/file.yml'
    args = {
        'param': 'test',
        'with': 'args'
    }
    vars = {
        'test': 'var'
    }

    class TestTask:
        _uuid = 'test_uuid'
        _parent = 'parent_uuid'

    task = TestTask()

    inc_file = IncludedFile(filename, args, vars, task)
    assert inc_file._filename == filename
    assert inc_file._args == args
    assert inc_file._vars == vars
    assert inc_file._task._uuid == 'test_uuid'
    assert inc_file._task._parent == 'parent_uuid'
    assert inc_file._is_role == False

# Generated at 2022-06-21 00:46:38.601123
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    file1 = IncludedFile(a, b, c, d)
    file2 = IncludedFile(a, b, c, d)
    file3 = IncludedFile(b, c, d, e)

    assert file1 == file1
    assert file1 == file2
    assert file2 != file3

# Generated at 2022-06-21 00:46:44.067631
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    """
    Test function for method add_host of class IncludedFile
    """
    include_file = IncludedFile("foo", "args", "vars", "task")
    try:
        include_file.add_host("host")
    except ValueError:
        raise ValueError("add_host failed")

# Generated at 2022-06-21 00:46:57.361308
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class Task:
        def __init__(self):
            self._uuid = 123
            self._parent = None
    class ParentTask(Task):
        def __init__(self):
            self._uuid = 12345
            self._parent = None
    class ParentTask2(Task):
        def __init__(self):
            self._uuid = 12346
            self._parent = None

    t1 = Task()
    t2 = ParentTask()
    t3 = ParentTask2()

    f1 = IncludedFile('filename1', {'arg1': 1, 'arg2': 2}, {'var1': 1, 'var2': 2}, t1)
    f2 = IncludedFile('filename1', {'arg1': 1, 'arg2': 2}, {'var1': 1, 'var2': 2}, t1)

# Generated at 2022-06-21 00:47:06.672669
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    class Dummy(object):
        def __init__(self, d):
            self.__dict__ = d

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

    d = IncludedFile('test_filename', {'test_args': 'value'}, {'test_vars': 'value'}, Dummy({'_uuid': 'test_uuid'}))
    assert(d._filename == 'test_filename')
    assert(d._args == {'test_args': 'value'})
    assert(d._vars == {'test_vars': 'value'})
    assert(len(d._hosts) == 0)

    d.add_host('test_host')
    assert(len(d._hosts) == 1)

# Generated at 2022-06-21 00:47:13.689066
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import pprint


# Generated at 2022-06-21 00:47:23.604591
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = "/filename.yml"
    args = { "_raw_params" : "{{ var }}" }
    vars = { "var" : "value" }
    task = {"uuid" : "uuid", "parent" : {"uuid" : "parent_uuid"}}

    incFile = IncludedFile(filename, args, vars, task)
    print(incFile.__repr__())
    print(incFile.__eq__(incFile))

    # Test comparison
    incFile2 = IncludedFile(filename, args, vars, task)
    print(incFile.__eq__(incFile2))

    # Test equality of content of the object
    incFile.add_host("host")
    print(incFile.__eq__(incFile2))

    # Test equality of content of the object
    inc

# Generated at 2022-06-21 00:47:34.404904
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from collections import namedtuple

    FakeTask = namedtuple('FakeTask', '_uuid _parent')

    tasks = [FakeTask(1, 'parent_1'), FakeTask(2, 'parent_2'),
             FakeTask(3, 'parent_3')]

    included_files = [IncludedFile('filename1', {}, {}, tasks[0]),
                      IncludedFile('filename2', {}, {}, tasks[1]),
                      IncludedFile('filename3', {}, {}, tasks[2])]

    assert str(included_files[0]) == 'filename1 (args={} vars={}): []'
    assert str(included_files[1]) == 'filename2 (args={} vars={}): []'

# Generated at 2022-06-21 00:47:44.392046
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = "filename"
    args = {"arg1": "value1"}
    vars = {"var1": "value1"}
    task1 = "task1"
    is_role = False
    test_included_file = IncludedFile(filename, args, vars, task1, is_role)
    test_included_file2 = IncludedFile(filename, args, vars, task1, is_role)
    assert test_included_file == test_included_file2
    test_included_file2._filename = "other_filename"
    assert not test_included_file == test_included_file2
    test_included_file2._filename = filename
    test_included_file2._args["arg1"] = "other_value"
    assert not test_included_file == test_

# Generated at 2022-06-21 00:47:54.904664
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    task = {'action': 'inc_cls',
            'args': {'name': 'some_role'},
            '_host': 'some_host'}
    result = {'include': 'some_role'}
    inc_file = IncludedFile(result['include'], result.get('include_args', dict()), {}, task, is_role=True)
    assert inc_file._filename == 'some_role'
    assert inc_file._args == {}
    assert inc_file._vars == {}
    assert inc_file._task == {'action': 'inc_cls', 'args': {'name': 'some_role'}, '_host': 'some_host'}
    assert inc_file._hosts == []
    assert inc_file._is_role == True

# Generated at 2022-06-21 00:48:24.677741
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # __repr__ of class should return a string including filename, args and var
    # create an object of class IncludedFile
    included_file = IncludedFile(filename='file1', args='arg1', vars='var1')
    # get string returned by __repr__ of class
    string_returned_by_repr = included_file.__repr__()
    # check if the string include filename, args and var
    assert string_returned_by_repr == 'file1 (args=arg1 vars=var1): []'
    

# Generated at 2022-06-21 00:48:35.741122
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # test method __eq__
    ifa = IncludedFile('/etc/passwd', '', '', '', )
    ifb = IncludedFile('/etc/passwd', '', '', '', )
    ifc = IncludedFile('/etc/passwd', '', '', '', '', '', )
    ifd = IncludedFile('/etc/shadow', '', '', '', )
    ife = IncludedFile('/etc/group', '', '', '', )
    if (ifa == ifb) is True:
        print('ifa is same as ifb')
    if (ifa == ifc) is True:
        print('ifa is same as ifc')
    if (ifa == ifd) is True:
        print('ifa is same as ifd')

# Generated at 2022-06-21 00:48:41.807565
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    incfile1 = IncludedFile(None, None, None, None)
    incfile2 = IncludedFile(None, None, None, None)
    incfile3 = IncludedFile(None, None, None, None)

    assert incfile1 == incfile2
    assert incfile1 != incfile3



# Generated at 2022-06-21 00:48:55.538404
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import sys
    import os
    import unittest

    sys.path.append(os.path.abspath('lib'))
    import ansible.playbook.role.include

    class MyTest(unittest.TestCase):
        def test_equal(self):
            include_1 = IncludedFile('/tmp/test1.yml', None, None, None)
            include_2 = IncludedFile('/tmp/test1.yml', None, None, None)
            include_3 = IncludedFile('/tmp/test2.yml', None, None, None)

            # Test for Equivalence of the Include file
            self.assertEqual(include_1, include_2, "Include files are not identical")
            self.assertFalse(include_1 == include_3, "Include files are identical")


# Generated at 2022-06-21 00:49:06.562471
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    class included_file(IncludedFile):
        def __init__(self, filename, args, vars, task, is_role=False):
            self._filename = filename
            self._args = args
            self._vars = vars
            self._task = task
            self._hosts = []
            self._is_role = is_role

    class Task():
        _parent = 0
        _uuid = "test_task"

    class ModuleResult():
        _task = Task()
        _host = "test_host"
        _result = "test_result"

    def test_add_host():
        inc_file = included_file("test_filename", "test_args", "test_vars", "test_task")
        inc_file.add_host("test_host")
        assert inc_file._host

# Generated at 2022-06-21 00:49:18.855507
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    print("test_IncludedFile()")

# Generated at 2022-06-21 00:49:28.649170
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    included_file = IncludedFile("/home/user/file.yml", {'test-args': 'value'}, {'test-vars': 'value'}, "test-task")

    assert(included_file._filename == "/home/user/file.yml")
    assert(included_file._args == {'test-args': 'value'})
    assert(included_file._vars == {'test-vars': 'value'})
    assert(included_file._task == "test-task")
    assert(included_file._hosts == [])
    assert(included_file._is_role == False)


# Generated at 2022-06-21 00:49:31.154401
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    assert IncludedFile('filename', 'args', 'vars', 'task')
    assert not IncludedFile('filename', 'args', 'vars', 'arg1', 'arg2')

# Generated at 2022-06-21 00:49:38.920578
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = "/path/to/file.yml"
    args = {"foo": "bar"}
    vars = {"bar": "foo"}
    task = IncludedFile.__init__(filename, args, vars, task)
    task2 = IncludedFile.__init__(filename, args, vars, task)

    assert task == task2

# Generated at 2022-06-21 00:49:48.520548
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.plays import Play
    roletest = Role()
    blocktest = Block()
    tasktest = Task()
    playtest = Play()
    roletest._role_path = "/home/matt/ansible"
    tasktest._parent = roletest
    blocktest._parent = tasktest
    blocktest._play = playtest
    filename="hosts"
    args={}
    vars={}
    task=blocktest

    includedfile = IncludedFile(filename, args, vars, task)
    includedfile2 = IncludedFile(filename, args, vars, task)

    assert includedfile == includedfile2

# Generated at 2022-06-21 00:50:41.346182
# Unit test for constructor of class IncludedFile
def test_IncludedFile():

    result = dict(
        ansible_loop_var='item',
        ansible_index_var='index',
        _ansible_item_label='item',
        ansible_loop=dict(a='a', b='b'),
        include='../../../include/file'
        )
    res = Result._result_from_failed_async('hostname', result, dict(task=Task(), host=Host('hostname'), task_vars=dict(omit='*')))
    file_from_res = IncludedFile.process_include_results([res], PlayIterator(), None, None)
    IncludedFile._is_role = False

    file1 = IncludedFile('../../../include/file', dict(), dict(), Task())

# Generated at 2022-06-21 00:50:51.534253
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = '/some/file'
    args = dict()
    vars = dict()
    task = dict()
    included_file = IncludedFile(filename, args, vars, task)
    assert included_file._filename == filename
    assert included_file._args == args
    assert included_file._vars == vars
    assert included_file._task == task
    assert included_file._hosts == []
    assert included_file._is_role == False


# Generated at 2022-06-21 00:50:55.964273
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = "test"
    args =  {"test": "test"}
    vars =  {"test": "test"}
    task = IncludeRole()
    included_file = IncludedFile(filename, args, vars, task)
    assert included_file._filename == "test"

# Generated at 2022-06-21 00:51:05.927528
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename='/some/dir/some.yaml'
    args={'one': 1, 'two': 2}
    vars={'one': 'ONE'}
    task='some task string'
    included_file = IncludedFile(filename, args, vars, task)
    assert included_file._filename == filename
    assert included_file._args == args
    assert included_file._vars == vars
    assert included_file._task == task

# Generated at 2022-06-21 00:51:19.210938
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    class MockTask():
        def __init__(self, uuid, parent=None):
            self._uuid = uuid
            self._parent = parent

    def test_add_host():
        included_file = IncludedFile(filename=None, args=None, vars=None, task=None, is_role=None)

        include_host = 'host1'
        included_file.add_host(include_host)
        assert len(included_file._hosts) == 1
        assert included_file._hosts[0] == include_host

        duplicate_include_host = 'host1'
        try:
            included_file.add_host(duplicate_include_host)
        except ValueError:
            pass


# Generated at 2022-06-21 00:51:21.459473
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    t1 = IncludedFile('abc', 1, 2, 3)
    t2 = IncludedFile('abc', 1, 2, 3)
    t3 = IncludedFile('xyz', 1, 2, 3)
    assert t1 == t2
    assert t1 != t3


# Generated at 2022-06-21 00:51:31.711085
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # init
    filename = 'filename'
    args = {'a': 'a'}
    vars = {'b': 'b'}
    task = 'task'
    i1 = IncludedFile(filename, args, vars, task)
    i2 = IncludedFile(filename, args, vars, task)
    assert i1 == i2
    i3 = IncludedFile(filename, {'a': 'A'}, vars, task)
    assert i1 != i3
    i4 = IncludedFile(filename, args, {'b': 'B'}, task)
    assert i1 != i4
    i5 = IncludedFile('i5', args, vars, task)
    assert i1 != i5


# Generated at 2022-06-21 00:51:39.875300
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    class Task:
        def __init__(self, uuid, parent):
            self._uuid = uuid
            self._parent = parent

    class Host:
        def __init__(self, name):
            self.name = name

    # Create tasks
    task1 = Task("1", None)
    task2 = Task("2", task1)
    task3 = Task("3", task2)
    # Create hosts
    host1 = Host("localhost")
    host2 = Host("somewhere")
    # Create included files
    inc1 = IncludedFile("/path/to/file", {}, {}, task1)
    inc2 = IncludedFile("/path/to/file", {}, {}, task2)
    inc3 = IncludedFile("/path/to/file", {}, {}, task3)
    # Add hosts

# Generated at 2022-06-21 00:51:49.961825
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    h1 = 'hostname'
    h2 = 'hostname2'
    filename = 'file1'
    args = dict()
    vars = dict()
    task = dict()

    inc_file = IncludedFile(filename, args, vars, task)
    inc_file.add_host(h1)
    inc_file.add_host(h2)
    assert len(inc_file._hosts) == 2
    try:
        inc_file.add_host(h2)
    except ValueError:
        pass
    else:
        raise
    assert len(inc_file._hosts) == 2


# Generated at 2022-06-21 00:52:02.002779
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    # Case 1: Two IncludedFile objects are equal
    display.display("Case 1: Two IncludedFile objects are equal")
    firstIncludedFile = IncludedFile("include_file", {"extra_vars": {}}, {"item": "1"}, TaskInclude(), False)
    secondIncludedFile = IncludedFile("include_file", {"extra_vars": {}}, {"item": "1"}, TaskInclude(), False)
    assert (firstIncludedFile == secondIncludedFile)

    # Case 2: Two IncludedFile objects are not equal
    display.display("Case 2: Two IncludedFile objects are not equal")
    firstIncludedFile = IncludedFile("include_file", {"extra_vars": {}}, {"item": "1"}, TaskInclude(), False)