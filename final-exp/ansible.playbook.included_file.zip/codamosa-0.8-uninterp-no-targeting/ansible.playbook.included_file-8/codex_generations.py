

# Generated at 2022-06-21 00:43:14.177781
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook.task import Task
    task = Task()
    task._parent = Task()
    includedFile = IncludedFile('example', {}, {}, task)
    assert(includedFile._filename == 'example')
    assert(includedFile._args == {})
    assert(includedFile._vars == {})
    assert(includedFile._task == task)
    assert(includedFile._hosts == [])
    assert(includedFile._is_role == False)

# Generated at 2022-06-21 00:43:25.325853
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    file_name = 'test_file_name1'
    args = dict()
    vars = dict()
    task = dict()
    is_role = False

    inc_file = IncludedFile(file_name, args, vars, task, is_role)

    assert inc_file._filename == file_name
    assert inc_file._args == args
    assert inc_file._vars == vars
    assert inc_file._task == task
    assert inc_file._hosts == []
    assert inc_file._is_role == is_role

# Generated at 2022-06-21 00:43:39.303024
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    class test_included_file(object):
        filename = 'test_filename'
        args = 'test_args'
        vars = 'test_vars'
        task = 'test_task'
        host = 'test_host'

        def __init__(self):
            self.hosts = []

        def add_host(self, host):
            if host in self.hosts:
                raise ValueError()
            self.hosts.append(host)

        def __eq__(self, other):
            return (other.filename == self.filename and
                other.args == self.args and
                other.vars == self.vars and
                other.task == self.task)

        def __repr__(self):
            return self.filename + ' ' + self.args + ' ' + self.vars

# Generated at 2022-06-21 00:43:46.698689
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_file = IncludedFile("filename.yml", dict(), dict(), "task")
    included_file.add_host("127.0.0.1")
    assert included_file._hosts == ["127.0.0.1"]
    try:
        included_file.add_host("127.0.0.1")
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 00:43:54.115732
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    print('Testing constructor of class IncludedFile')
    try:
        icf = IncludedFile('filename', 'args', 'vars', 'task')
    except Exception as e:
        print(e)
        print('Unexpected error, constructor should not throw any exception')
        print('Failed test for constructor of class IncludedFile')


# Generated at 2022-06-21 00:44:05.230918
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = '/home/user/file.yml'
    args = dict(foo=1, bar=2)
    vars = dict(ansible_connection='network_cli', ansible_network_os='nxos')
    task = dict(name='Test name', uuid='108b2c9c-cc42-42c8-b8e3-3a27b7498b35')

    included_file = IncludedFile(filename, args, vars, task)
    assert repr(included_file) == '/home/user/file.yml (args={\'foo\': 1, \'bar\': 2} vars={\'ansible_connection\': \'network_cli\', \'ansible_network_os\': \'nxos\'}): []'

# Unit tests for method __eq__ of class IncludedFile

# Generated at 2022-06-21 00:44:15.278014
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    iterator, loader, variable_manager, host, task, play_context, new_stdin, task_vars, play_vars = mock_objects()
    included_file1 = IncludedFile('file1', 'args1', 'vars1', task, is_role=False)
    included_file2 = IncludedFile('file1', 'args1', 'vars1', task, is_role=False)
    included_file3 = IncludedFile('file3', 'args3', 'vars3', task, is_role=False)
    included_file4 = IncludedFile('file1', 'args1', 'vars1', task, is_role=True)
    # Equal objects
    assert included_file1 == included_file2
    # Different objects
    assert not included_file1 == included_file3
    # Different objects

# Generated at 2022-06-21 00:44:27.801826
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = 'some/random/file'
    args = dict(somevar='someval')
    vars = dict(someothervar='someotherval')
    task = FakeTask()

    includedFile1 = IncludedFile(filename, args, vars, task)
    includedFile2 = IncludedFile(filename, args, vars, task)
    assert includedFile1 == includedFile2
    assert includedFile1 is not includedFile2

    includedFile1.add_host('somehost')
    assert includedFile1._hosts == ['somehost']
    try:
        includedFile1.add_host('somehost')
    except ValueError:
        pass  # We want a ValueError to be thrown when adding duplicate hosts
    else:
        assert False  # ValueError was not thrown


# Generated at 2022-06-21 00:44:36.305980
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    """
    This function tests for the print format of IncludedFile class.
    """
    expected_repr = '<IncludedFile filename=/path/to/filename (args=args_value vars=vars_value): []]>'
    includedfile_obj = IncludedFile('filename', 'args_value', 'vars_value', None)
    assert repr(includedfile_obj) == expected_repr



# Generated at 2022-06-21 00:44:49.434419
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars import merge_hash
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.__dict__.update({
        '_fact_cache': {},
        '_vars': {},
        '_extra_vars': {},
        '_options': {},
    })
    display = Display()


# Generated at 2022-06-21 00:45:10.797601
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    """
    Returns an example of instantiated IncludedFile class.
    :return: Instantiated IncludedFile instance.
    :rtype: IncludedFile
    """
    try:
        # Create instantiated IncludedFile class class
        _filename = 'some_filename'
        _args = 'some_args'
        _vars = 'some_vars'
        _task = 'some_task'
        # Create instance of object
        ai = IncludedFile(_filename, _args, _vars, _task)
        # Return instantiated IncludedFile class
        return ai
    except Exception:
        raise


# Generated at 2022-06-21 00:45:13.833447
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Test exceptions
    included_file = IncludedFile('', {}, {}, '')
    try: included_file.add_host('test')
    except ValueError: assert False, 'test_add_host: Exception should not be raised'
    try: included_file.add_host('test')
    except ValueError: pass
    else: assert False, 'test_add_host: Exception should be raised'

# Generated at 2022-06-21 00:45:20.361247
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    include_file1 = IncludedFile('include_filename_1', {'k1':'v1', 'k2':'v2'}, {}, None)
    include_file2 = IncludedFile('include_filename_2', {'k1':'v1', 'k2':'v2'}, {}, None)
    include_file3 = IncludedFile('include_filename_1', {'k1':'v1', 'k2':'v2'}, {}, None)

    assert include_file1.__eq__(include_file3)
    assert not include_file1.__eq__(include_file2)
    assert not include_file1.__eq__('Not an IncludeFile')



# Generated at 2022-06-21 00:45:32.900636
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 00:45:44.214334
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test case setup: 
    class Host:
        name = "Host_name"
    class Task:
        action = "my_include"
        no_log = True
        def get_search_path(self):
            return ["foo", "bar"]
    class Play:
        name = "test_play"
    class Playbook:
        def __init__(self):
            self.inventory = PlaybookInventory()
            self.variable_manager = VariableManager()
    class PlaybookIterator:
        def __init__(self):
            self._play = Play()
    class VariableManager:
        def get_vars(self, play, host, task):
            return {
                "foo": "bar",
                "ansible_name": host.name,
            }

# Generated at 2022-06-21 00:45:47.161503
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # Add tests here...
    raise NotImplementedError()

# Generated at 2022-06-21 00:45:56.442354
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task import Task
    from ansible.plugins import loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader.all(class_only=True)

# Generated at 2022-06-21 00:46:08.281104
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    filename = "somefile.yml"
    args = {'a': 'z', 'b': 'y'}
    vars = {'c': 'x'}

# Generated at 2022-06-21 00:46:18.251464
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    class Options:
        connection = 'local'
        module_path = None
        forks = 100
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        listhosts = None
        listtasks = None
        listtags = None
        syntax = False
        verbosity = 5

    loader = DataLoader()
    inventory = InventoryManager([loader.load_inventory('tests/units/inventory')])
   

# Generated at 2022-06-21 00:46:28.415112
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class example_task(object):
        def __init__(self, uuid, parent):
            self._uuid = uuid
            self._parent = parent

    task1 = example_task("task1", "task1")
    task2 = example_task("task2", "task2")
    class example_IncludedFile(object):
        def __init__(self, filename, args, vars, task, is_role=False):
            self._filename = filename
            self._args = args
            self._vars = vars
            self._task = task
            self._hosts = []
            self._is_role = is_role

    IncludedFile1 = example_IncludedFile("filename1", "args1", "vars1", task1, True)

# Generated at 2022-06-21 00:46:49.774141
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'filename1'
    args = {'arg1': 'arg1'}
    vars1 = {'var1': 'var1'}
    vars2 = {'var2': 'var2'}
    task = {'task1': 'task1'}
    inc_file = IncludedFile(filename, args, vars1, task)
    inc_file.add_host('localhost')
    inc_file.add_host('localhost')
    inc_file.add_host('localhost')
    inc_file.add_host('localhost')

    result = inc_file.__repr__()
    expected_result = filename + ' (args=' + str(args) + ' vars=' + str(vars1) + '): [' + str(task) + ']'

    assert result == expected_result

# Generated at 2022-06-21 00:46:59.914001
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # arrange
    filename = r'filename'
    args = [['a', 'b'], ['c', 'd']]
    vars = [{'m1': '1', 'm2': '2'}, {'m3': '3', 'm4': '4'}]
    task = [1, 2, 3]
    hosts = ['abc', 'xyz']
    is_role = False

    # act
    included_file = IncludedFile(filename, args, vars, task, is_role)
    included_file._hosts = hosts

    # assert
    assert repr(included_file) == r"filename (args=['a', 'b'] ['c', 'd'] vars=['m1', 'm2', 'm3', 'm4']): ['abc', 'xyz']"

# Generated at 2022-06-21 00:47:02.620937
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    f = IncludedFile("/foo/bar.yml", {"arg1": "val1"}, {"v1": "var1"}, None)
    print(f)
    print(f == f)

# Generated at 2022-06-21 00:47:15.999466
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # TODO: Test whether _args and _vars is passed or not
    test_file = IncludedFile('/path/to/file', {'a': 'A'}, {'b': 'B'}, None)
    assert test_file._filename == '/path/to/file'
    assert test_file._args == {'a': 'A'}
    assert test_file._vars == {'b': 'B'}
    assert test_file._task is None
    assert test_file._hosts == []
    assert test_file._is_role == False
    assert repr(test_file) == "/path/to/file (args={'a': 'A'} vars={'b': 'B'}): []"


# Generated at 2022-06-21 00:47:20.309547
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    ifile = IncludedFile(None, None, None, None)
    ifile.add_host('host1')
    try:
        ifile.add_host('host1')
    except ValueError:
        pass
    else:
        raise AssertionError('This should have raised a value error')

# Generated at 2022-06-21 00:47:28.300668
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    i = IncludedFile('filename', 'args', 'vars', 'task')
    i._hosts.append('host')
    i._hosts.append('host2')
    i._hosts.append('host3')
    i._hosts.append('host3')

    assert repr(i) == "filename (args='args' vars='vars'): ['host', 'host2', 'host3']"

# Generated at 2022-06-21 00:47:32.000211
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    included_file = IncludedFile('filename.yml', dict(), dict(), dict())

# Generated at 2022-06-21 00:47:41.655708
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-21 00:47:48.552804
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    incfile = IncludedFile("somefile", {}, {}, None, is_role=False)
    incfile.add_host("testhost")
    assert ["testhost"] == incfile._hosts
    try:
        incfile.add_host("testhost")
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-21 00:47:53.959082
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    t = IncludedFile('test/test.yml', '', '', '', '', )
    assert t.__repr__() == 'test/test.yml (args= vars=): []'

    t = IncludedFile('test/test.yml', '', '', '', '')
    t.add_host('127.0.0.1')
    assert t.__repr__() == 'test/test.yml (args= vars=): [127.0.0.1]'


# Generated at 2022-06-21 00:48:15.002209
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = "/tmp/test_file"
    args = {"arg1": "arg1 value" , "arg2": "arg2 value"}
    vars = {"var1" : "var1 value"}
    task = "test_task"
    is_role = False

    assert filename == IncludedFile(filename,args,vars,task,is_role)._filename
    assert args == IncludedFile(filename, args, vars, task, is_role)._args
    assert vars == IncludedFile(filename, args, vars, task, is_role)._vars
    assert task == IncludedFile(filename, args, vars, task, is_role)._task
    assert is_role == IncludedFile(filename, args, vars, task, is_role)._is_role


# Generated at 2022-06-21 00:48:24.907980
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # object Variables
    # object ids for this test
    obj_id = {
        'filename': 0,
        'args': 1,
        'vars': 2,
        'task': 3,
        'hosts': 4
    }

    # get all necessary obj ids
    filename, args, vars, task = obj_id['filename'], obj_id['args'], obj_id['vars'], obj_id['task']
    hosts = obj_id['hosts']

    # test text
    assert repr(
        IncludedFile(filename, args, vars, task)) == str(
        '%s (args=%s vars=%s): %s' % (filename, args, vars, hosts))

# Generated at 2022-06-21 00:48:30.727417
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_files = []
    for idx in range(1, 6):
        filename = 'file_{0}'.format(idx)
        args = 'args_{0}'.format(idx)
        vars = 'vars_{0}'.format(idx)
        task = 'task_{0}'.format(idx)
        inc_file = IncludedFile(filename, args, vars, task)
        if idx == 1 or idx == 2:
            host = 'host_1'
        elif idx == 3 or idx == 4:
            host = 'host_2'
        else:
            host = 'host_3'
        try:
            inc_file.add_host(host)
            included_files.append(inc_file)
        except Exception:
            pass



# Generated at 2022-06-21 00:48:41.314074
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    result = {'include_params': {}, 'include': 'tasks/main.yml', 'failed': False, 'skipped': False, 'include_args': {}}
    iterator = None
    loader = None
    variable_manager = None
    included_files = [IncludedFile.process_include_results([result], iterator, loader, variable_manager)]
    exp = ["tasks/main.yml (args={} vars={}): ['']"]
    assert str(included_files) == str(exp)

# Generated at 2022-06-21 00:48:54.263801
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    import uuid
    from ansible.playbook.task import Task

    original_task = Task()
    original_task._uuid = uuid.uuid4()
    original_task._parent = Task()
    original_task._parent._uuid = uuid.uuid4()

    inc_file = IncludedFile("/tmp/test.yml", dict(), dict(), original_task)

    #host1
    inc_file.add_host("localhost")

    #host2
    inc_file.add_host("localhost")

    #host3
    hosts = ["localhost", "localhost"]
    for host in hosts:
        inc_file.add_host(host)

# Generated at 2022-06-21 00:49:00.032164
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile('/tmp/test.yml', dict(), dict(), dict(), dict())
    assert str(included_file) == "/tmp/test.yml (args=dict_keys([]) vars=dict_keys([])): []"

# Generated at 2022-06-21 00:49:11.752147
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    assert IncludedFile("test.yml", {}, {}, "task1") != IncludedFile("test.yml", {}, {}, "task2")
    assert IncludedFile("test.yml", {}, {}, "task1") != IncludedFile("no_test.yml", {}, {}, "task1")
    assert IncludedFile("test.yml", {"var1": 1}, {}, "task1") != IncludedFile("test.yml", {"var1": 2}, {}, "task1")
    assert IncludedFile("test.yml", {}, {"var2": 3}, "task1") != IncludedFile("test.yml", {}, {"var2": 4}, "task1")

# Generated at 2022-06-21 00:49:23.781975
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_one = IncludedFile(
        'filename_one',
        'args_one',
        'vars_one',
        'task_one',
        is_role=True
    )

    included_file_two = IncludedFile(
        'filename_two',
        'args_two',
        'vars_two',
        'task_two',
        is_role=False
    )

    included_file_three = IncludedFile(
        'filename_one',
        'args_one',
        'vars_one',
        'task_one',
        is_role=True
    )

    included_file_four = IncludedFile(
        'filename_two',
        'args_one',
        'vars_one',
        'task_one',
        is_role=False
    )

# Generated at 2022-06-21 00:49:29.445463
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.plugins.loader import action_loader, lookup_loader


# Generated at 2022-06-21 00:49:36.798679
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    ifile1 = IncludedFile("filename1", "args1", "vars1", "task1", "is_role1")
    ifile2 = IncludedFile("filename1", "args1", "vars1", "task1", "is_role1")
    assert ifile1 == ifile2
    ifile2 = IncludedFile("filename2", "args1", "vars1", "task1", "is_role1")
    assert ifile1 != ifile2
    ifile2 = IncludedFile("filename1", "args2", "vars1", "task1", "is_role1")
    assert ifile1 != ifile2
    ifile2 = IncludedFile("filename1", "args1", "vars2", "task1", "is_role1")
    assert ifile1 != ifile2
    ifile2

# Generated at 2022-06-21 00:50:07.835062
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-21 00:50:16.822328
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # Initialize IncludedFile object
    inc_file = IncludedFile("/etc/path", {'role': 'roles/test'}, {'variable': 'new'}, "Task to include")
    # Test the object
    assert inc_file._filename == "/etc/path"
    assert inc_file._args == {'role': 'roles/test'}
    assert inc_file._vars == {'variable': 'new'}
    assert inc_file._task == "Task to include"
    assert inc_file._is_role is False
    print("Test of IncludedFile is OK")

# Generated at 2022-06-21 00:50:25.191633
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class Test_task:

        def __init__(self):
            self._uuid = '1111-1111-1111-1111'
            self._parent = 'parent'
            class Test_parent:
                def __init__(self):
                    self._uuid = '2222-2222-2222-2222'
            self._parent = Test_parent()

    task_obj = Test_task()

    f1 = IncludedFile('test/test_file_1', {'test': 'test'}, {'test': 'test'}, task_obj)
    f2 = IncludedFile('test/test_file_1', {'test': 'test'}, {'test': 'test'}, task_obj)

    assert f1 == f2
    
    f2._filename = 'test/test_file_2'

    assert f1

# Generated at 2022-06-21 00:50:35.476176
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class FakeTask(object):
        def __init__(self, name):
            self._uuid = name

    class FakePlay(object):
        def __init__(self, name):
            self._uuid = name

    my_task = FakeTask('my_task')
    my_play = FakePlay('my_play')
    file_1 = IncludedFile('one.yml', 'name', 'one', my_task)
    file_1.add_host('host1')
    file_1_iter = IncludedFile('one.yml', 'name', 'one', my_task)
    file_1_iter.add_host('host1')
    file_1_iter.add_host('host2')
    file_2 = IncludedFile('two.yml', 'name', 'two', my_task)
    file

# Generated at 2022-06-21 00:50:42.128096
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    def fake_it(results):
        iterator = type('FakeIterator', (object,), {'_play': type('FakePlay', (object,), {'handlers': []})()})()
        loader = type('FakeLoader', (object,), {'path_dwim': lambda x: x, 'get_basedir': lambda: os.getcwd()})()
        variable_manager = type('FakeVariableManager', (object,), {'get_vars': lambda x, y, z: {}})()

        return IncludedFile.process_include_results(results, iterator, loader, variable_manager)

    def fake_res(task, host, result):
        return type('FakeResult', (object,), {'_task': task, '_host': host, '_result': result})()

    # Loader.path_dwim

# Generated at 2022-06-21 00:50:53.213473
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile('/tmp/abc', {'a': '1'}, {'b': '2'}, None)
    included_file.add_host('host1')
    included_file.add_host('host2')

    output = included_file.__repr__()
    expected = "/tmp/abc (args={'a': '1'} vars={'b': '2'}): ['host1', 'host2']"

    assert output == expected



# Generated at 2022-06-21 00:50:58.757416
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    loader = object()
    variable_manager = object()
    play = object()
    iterator = object()
    iterator._play = play
    task = object()
    task.action = 'action'
    results = [object(), object()]
    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    filename1 = included_files[0]._filename
    filename2 = included_files[1]._filename
    assert filename1 != filename2



# Generated at 2022-06-21 00:51:03.761293
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    included_file = IncludedFile(filename='/tmp/test', args={'foo': 'bar'}, vars={'hello': 'world'}, task='t')
    print(included_file)

# Generated at 2022-06-21 00:51:07.950943
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = 'filename.yml'
    args = dict(a='b')
    vars = dict(c=2)
    task = 'task'
    is_role = True
    includedFile = IncludedFile(filename, args, vars, task, is_role)
    assert includedFile._filename == filename
    assert includedFile._args == args
    assert includedFile._vars == vars
    assert includedFile._task == task
    assert includedFile._hosts == []
    assert includedFile._is_role == is_role


# Generated at 2022-06-21 00:51:19.641817
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import copy
    loader, variable_manager, allocation, iterator, options = None, None, None, None, None
    hosts = ['localhost']
    play = Play().load(dict(
        name = "test play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ include_args.v1 }}'))),
        ]
    ), variable_manager=variable_manager, loader=loader)

    tqm = TaskQueueManager(
        inventory=allocation.inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=options,
        passwords=dict(),
        stdout_callback="default",
    )
    results = tqm.run(play)
    IncludedFile.process_include_

# Generated at 2022-06-21 00:52:15.240064
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Calling add_host on an empty IncludedFile should not raise any exception
    if_1 = IncludedFile('/tmp/foo', {}, {}, None)
    if_1.add_host('myhost')
    # Calling add_host twice on an empty IncludedFile should raise an exception
    try:
        if_1.add_host('myhost')
        assert False
    except ValueError:
        pass


# Generated at 2022-06-21 00:52:28.666892
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole

    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list=['host1'])
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='ping', args=''))
               ]
        )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 00:52:39.090735
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import Playbook

    loader = DictDataLoader({})
    variable_manager = VariableManager()

    fake_module = {}

    # Add some hosts to the fake inventory
    fake_inventory = InventoryManager(loader, variable_manager).add_host()
    fake_inventory.set_variable('foo', 'bar')

    # Create a fake task result
    fake_task_result = FakeTaskResult()
    fake_task_result._host = fake_inventory.get_host('localhost')
    fake_task_result._task = 'fake_task'
    fake_task_result._result = {}

# Generated at 2022-06-21 00:52:42.965441
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    args = {'include_args': {}}
    vars = {}
    filename = './roles/nginx/tasks/main.yml'
    task = TaskInclude(DummyParent())
    host = Host('dummyhost')

    inc = IncludedFile(filename, args, vars, task)
    inc.add_host(host)

    assert repr(inc) == "./roles/nginx/tasks/main.yml (args={'include_args': {}} vars={}): ['dummyhost']"
