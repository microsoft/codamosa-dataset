

# Generated at 2022-06-21 00:43:09.957716
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    class Task:
        def __init__(self, uuid, parent_uuid):
            self._uuid = uuid
            self._parent = parent_uuid

    file1 = IncludedFile("file1", {} , {} , Task(1, 2))
    assert file1._filename == "file1"
    assert file1._args == {}
    assert file1._vars == {}
    assert file1._task._uuid == 1
    assert file1._task._parent._uuid == 2



# Generated at 2022-06-21 00:43:17.752682
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # The result contains the action include_task
    result = {
        "_ansible_ignore_errors": None,
        "_ansible_item_result": True,
        "_ansible_no_log": False,
        "_ansible_parsed": True,
        "_ansible_verbose_always": True,
        "changed": False,
        "failed": False,
        "include": "{{ item.name }}"
    }
    # The result contains the action import_tasks

# Generated at 2022-06-21 00:43:26.656635
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    '''
    IncludedFile.add_host raises ValueError when
    it's called with a host already in self._hosts
    '''
    inc_file = IncludedFile("x.yml", {}, {}, None)
    assert inc_file._hosts == []

    inc_file.add_host("host1")
    assert inc_file._hosts == ["host1"]
    inc_file.add_host("host2")
    assert inc_file._hosts == ["host1", "host2"]
    inc_file.add_host("host3")
    assert inc_file._hosts == ["host1", "host2", "host3"]

    try:
        inc_file.add_host("host1")
    except ValueError:
        pass
    else:
        assert False # add_host should raise an exception

# Generated at 2022-06-21 00:43:39.006963
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    results = []
    results.append(json.loads('{"_host": "host1", "_task": "task1", "results": [{"include": "file1"}]}'))
    results.append(json.loads('{"_host": "host1", "_task": "task1", "results": [{"include": "file2"}]}'))
    results.append(json.loads('{"_host": "host1", "_task": "task1", "results": [{"include": "file1", "include_args": {"arg1": "val1"}}]}'))
    results.append(json.loads('{"_host": "host1", "_task": "task1", "results": [{"include": "file1", "include_args": {"arg2": "val2"}}]}'))

# Generated at 2022-06-21 00:43:46.531344
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'filename'
    args = 'args'
    vars = 'vars'
    task = 'task'
    hosts = 'hosts'
    is_role = 'is_role'

    included_file = IncludedFile(filename, args, vars, task, is_role)
    assert repr(included_file) == str(
        'filename (args=args vars=vars): hosts')

# Generated at 2022-06-21 00:43:58.942023
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = "/home/user/ansible/roles/role/tasks/main.yml"
    args = {'_raw_params' : './roles/role/tasks/main.yml'}
    vars = {'item' : 'output1'}
    task = 'dummy_task'
    included_file = IncludedFile(filename, args, vars, task)
    assert included_file.__repr__() == "/home/user/ansible/roles/role/tasks/main.yml (args={'_raw_params': './roles/role/tasks/main.yml'} vars={'item': 'output1'}): []"


# Generated at 2022-06-21 00:44:00.597585
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    file = IncludedFile('file', {}, {}, {}, True)
    file.add_host('localhost')
    file.add_host('localhost')


# Generated at 2022-06-21 00:44:05.911307
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    """
    Test that the method add_host of class IncludedFile raises an
    exception when the host already exists for this include file.
    """
    obj = IncludedFile('/path/to/include', {}, {}, {})
    obj.add_host('host_name')
    try:
        obj.add_host('host_name')
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 00:44:16.240142
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.block import TaskBlock
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    task = Task()
    task._role = None
    task._role_name = ''

    task._task_fields['action'] = 'include'
    task._task_fields['loop'] = 'results'
    task._task_fields['args'] = {}

    task_block = TaskBlock(play=None)
    task_block.block = [task]
    task_block.block[0] = task
    task._parent = task_block


# Generated at 2022-06-21 00:44:28.507757
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    abc=IncludedFile("abc",{"arg1":"value1","arg2":"value2"},{},"a")
    assert abc._filename == "abc"
    assert abc._args == {"arg1":"value1","arg2":"value2"}
    assert abc._vars == {}
    assert abc._task == "a"
    assert abc._is_role == False
    # test: add host for a new include
    abc.add_host("host1")
    assert abc._hosts == ["host1"]
    # test: add the same host for the same include again
    abc.add_host("host1")
    assert abc._hosts == ["host1"]

# Generated at 2022-06-21 00:44:47.691216
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = 'filename'
    args = 'args'
    vars = 'task vars'
    task = 'task'
    included_file = IncludedFile(filename, args, vars, task)
    assert included_file._filename == filename
    assert included_file._args == args
    assert included_file._vars == vars
    assert included_file._task == task
    assert included_file._hosts == []

# Generated at 2022-06-21 00:45:00.663084
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager

    play = Playbook()
    play._included_files = []

    # Load two tasks in separate files
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=True,
        run_tree=True,
        timeout=C.DEFAULT_TIMEOUT
    )
    play_context = PlayContext()
    play_context.play = play
    tqm._play_context = play_context
    tqm._loader = None
    tqm._final_q = []

# Generated at 2022-06-21 00:45:06.213117
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    test_obj = IncludedFile('filename', 'args', 'vars', 'task')
    add_host = test_obj.add_host
    add_host('host1')
    assert repr(test_obj) == "filename (args=args vars=vars): ['host1']"
    add_host('host2')
    assert repr(test_obj) == "filename (args=args vars=vars): ['host1', 'host2']"



# Generated at 2022-06-21 00:45:08.848854
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    inc_file = IncludedFile(__file__, {}, {}, object())
    assert inc_file.__repr__() == "%s (args={} vars={}): []" % inc_file._filename


# Generated at 2022-06-21 00:45:20.016767
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile('myfile', 'args', 'vars', 'task')
    assert repr(included_file) == "myfile (args=args vars=vars): []"
    included_file.add_host('host1')
    assert repr(included_file) == "myfile (args=args vars=vars): ['host1']"
    included_file.add_host('host2')
    assert repr(included_file) == "myfile (args=args vars=vars): ['host1', 'host2']"


# Generated at 2022-06-21 00:45:25.152405
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    a = IncludedFile('filename', 'args', 'vars', 'task')
    a._hosts = ['host1']
    assert a.__repr__() == "filename (args=args vars=vars): ['host1']"

# Generated at 2022-06-21 00:45:32.318045
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class MockTask:
        def __init__(self):
            self._uuid = 'uuid'
            self._parent = MockParentTask()

    class MockParentTask:
        def __init__(self):
            self._uuid = 'parent_uuid'

    class MockHost:
        def __init__(self):
            self._name = 'mock_hostname'

    args = dict()
    vars = dict()
    filename = 'test_file'
    task = MockTask()
    is_role = False

    included_file = IncludedFile(filename, args, vars, task, is_role)


# Generated at 2022-06-21 00:45:34.839508
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    included_file = IncludedFile("foo", {"k": 1, "k2": 2}, {"k3": 3, "k4": 4}, "task", True)
    assert  isinstance(included_file, IncludedFile)


# Generated at 2022-06-21 00:45:44.302430
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    print('>>>test_IncludedFile___repr__')
    filename = 'helloworld.yml'
    args = dict(name = 'A')
    vars = dict(name = 'A')
    #task = include_role(name = 'roles/helloworld', tasks_from = 'main.yml')
    task = dict(name = 'include_role', _role_name = 'roles/helloworld', _from_files = dict(tasks_from = 'main.yml'))
    hosts = ['TestHost']
    inc_file = IncludedFile(filename, args, vars, task)
    inc_file.add_host('TestHost')

# Generated at 2022-06-21 00:45:47.783089
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    ifile = IncludedFile('filename', 'args', 'vars', 'task')
    assert ifile


# Generated at 2022-06-21 00:46:17.740472
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Create some tasks as parents
    p1 = TaskInclude()
    p1._uuid = "parent1"
    p2 = TaskInclude()
    p2._uuid = "parent2"

    # Create some tasks as args
    task1 = TaskInclude()
    task1._parent = p1
    task1._uuid = "task1"
    task2 = TaskInclude()
    task2._parent = p1
    task2._uuid = "task2"
    task3 = TaskInclude()
    task3._parent = p2
    task3._uuid = "task3"

    host1 = "host1"
    host2 = "host2"

    filename1 = "filename1"
    filename2 = "filename2"


# Generated at 2022-06-21 00:46:28.309201
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    # test 1
    host1 = '123.45.67.89'
    host2 = '127.0.0.1'
    host3 = '192.168.0.1'
    filename = 'test.py'
    args = []
    vars = []
    task = 'test'
    is_role = False

    includedFile = IncludedFile(filename, args, vars, task, is_role)

    # host1 not in hosts
    includedFile.add_host(host1)

    # host1 in hosts
    try:
        includedFile.add_host(host1)
        assert False
    except ValueError:
        pass

    # host2 not in hosts
    includedFile.add_host(host2)

    # host3 not in hosts
    includedFile.add_host(host3)

   

# Generated at 2022-06-21 00:46:33.751341
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    """Return the string representation of the IncludeFile class.
    """
    from ansible.playbook.task import Task

    ifm = IncludedFile("filename", "args", "vars", Task())
    assert repr(ifm) == "filename (args=args vars=vars): []", "The string representation method doesn't work"



# Generated at 2022-06-21 00:46:41.426784
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # Test creating an object
    obj = IncludedFile('/etc/hosts', {}, {}, None)

    # Test repr()
    repr(obj)

    # Test adding hosts
    obj.add_host('localhost')
    obj.add_host('localhost')

    # Test eq operator
    obj2 = obj
    obj == obj2


# Generated at 2022-06-21 00:46:48.618056
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = 'foo'
    args = {}
    vars = {}
    task = 'task'

    inc_file = IncludedFile(filename, args, vars, task)

    try:
        inc_file.add_host('unique-host')
        inc_file.add_host('another-unique-host')
        assert len(inc_file._hosts) == 2
    except ValueError:
        assert False

# Generated at 2022-06-21 00:46:59.384647
# Unit test for constructor of class IncludedFile
def test_IncludedFile():

	# Constructor 1
    testobj1 = IncludedFile("foo.yml", {"_raw_params" : "1", "foo" : "bar"}, {"baz" : "qux"}, "foo.yml")

    # Constructor 2
    testobj2 = IncludedFile("foo.yml", {"_raw_params" : "1", "foo" : "bar"}, {"baz" : "qux"}, "foo.yml")

    if testobj1 == testobj2:
        print ("Test1: Objects initialized with same values are Equal \n")
    else:
        print ("Test1: Objects initialized with same values are not Equal \n")

    # Constructor 3

# Generated at 2022-06-21 00:47:12.680166
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class FakeTask:
        def __init__(self, uuid):
            self._uuid = uuid
    class FakeParent:
        def __init__(self, uuid):
            self._uuid = uuid
    included_file1 = IncludedFile('/path/to/include1', 'args', 'vars', FakeTask('abc'))
    included_file1._task._parent = FakeParent('def')
    included_file2 = IncludedFile('/path/to/include2', 'args2', 'vars2', FakeTask('abc2'))
    included_file2._task._parent = FakeParent('def2')

    assert not included_file1 == included_file2
    assert not included_file1 == included_file1._filename
    assert included_file1 == included_file1

# Generated at 2022-06-21 00:47:15.012252
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # obj = class_under_test()
    # assert_equal(expected, obj.__repr__())
    pass


# Generated at 2022-06-21 00:47:20.311520
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = {'foo': 'bar'}
    args = {'foo': 'bar'}
    vars = {'foo': 'bar'}
    task = {'foo': 'bar'}
    is_role = True
    test_case = IncludedFile(filename, args, vars, task, is_role)
    assert test_case == test_case

# Generated at 2022-06-21 00:47:29.989625
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = "/path/to/file.yml"
    args = {}
    vars = {}
    uuid = "UUID"
    parent_uuid = "PARENT"
    task = mockTask(uuid, parent_uuid)
    included_file = IncludedFile(filename, args, vars, task)
    assert included_file.__repr__() == "%s (args=%s vars=%s): %s" % (filename, args, vars, included_file._hosts)


# Generated at 2022-06-21 00:47:57.747661
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    import pytest

    ifile = IncludedFile(0, 0, 0, 0)

    ifile.add_host('host1')
    assert len(ifile._hosts) == 1
    assert ifile._hosts[0] == 'host1'

    # Test that an exception is raised if the same host is added again
    with pytest.raises(ValueError):
        ifile.add_host(u'host1')



# Generated at 2022-06-21 00:48:03.295991
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    test_class = IncludedFile('filename', 'args', 'vars', 'task')
    test_class.add_host('host')
    assert test_class.__repr__() == "filename (args=args vars=vars): ['host']", 'The repr should be filename (args=args vars=vars): [\'host\'] but it was %s' % test_class.__repr__()

# Generated at 2022-06-21 00:48:14.230112
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    S = IncludedFile.__repr__
    assert S(IncludedFile('abc', 123, {}, 'task')) == "abc (args=123 vars={}): []"
    assert S(IncludedFile('abc', 123, {1:2}, 'task')) == "abc (args=123 vars={1: 2}): []"
    assert S(IncludedFile('abc', 123, {'a':'b'}, 'task', True)) == "abc (args=123 vars={'a': 'b'}): []"
    try:
        S(IncludedFile('abc', 123, 'abc', 'task'))
    except TypeError:
        pass
    else:
        raise AssertionError('IncludedFile.__repr__() did not raise TypeError')

test_IncludedFile___repr__()

# Generated at 2022-06-21 00:48:23.766357
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    loader = DictDataLoader({
        'defaults/main.yml': '',
        'vars/v.yml': '',
        'tasks/task.yml': '',
        'tasks/task1.yml': '',
        'tasks/task2.yml': '',
        'tasks/task3.yml': '',
        'tasks/task4.yml': '',
        'tasks/task5.yml': '',
        'handlers/handler.yml': '',
        'meta/main.yml': '',
        'library/module.py': '',
    })

    def mock_variable_manager(host, play=None, task=None):
        variables = dict()
        variables['ansible_play_dir'] = '.'
        return variables

# Generated at 2022-06-21 00:48:35.400657
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import sys, tempfile, shutil, os

    cur_dir = os.path.dirname(__file__)
    test_dir = os.path.join(cur_dir, "files", "filter_plugins")
    playbook_file = os.path.join(test_dir, "include_playbook.yml")
    result_file = os.path.join(test_dir, "include_playbook.ret")

    temp_dir = tempfile.mkdtemp()

    # Create a temp directory to store a copy of the strategy plugin
    strategy_dir = os.path.join(temp_dir, "strategy")
    shutil.copytree(os.path.join(cur_dir, "strategy"), strategy_dir)
    # Insert the path to the temp directory in the module search path

# Generated at 2022-06-21 00:48:41.355217
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    a = IncludedFile('file1', dict(), dict(), dict(), True)
    b = IncludedFile('file1', dict(), dict(), dict(), True)
    c = IncludedFile('file2', dict(), dict(), dict(), True)
    assert a == b
    assert a != c

# Generated at 2022-06-21 00:48:55.492870
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyBase

    class TestStrategy(StrategyBase):
        def __init__(self, tqm):
            super(TestStrategy, self).__init__(tqm)
            self._tqm._stdout_callback = None

        def run(self, iterator, connection_info):
            results = super(TestStrategy, self).run(iterator, connection_info)

# Generated at 2022-06-21 00:49:05.305476
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    args = {"arg1": "val1", "arg2": "val2"}
    vars = {"var1": "val3", "var2": "val4"}
    task = "task_description_string"
    filename = "filename_string"
    is_role = True
    inc_file = IncludedFile(filename, args, vars, task)
    actual = repr(inc_file)
    # repr() will format the __repr__ string with double quotes
    expected = "{filename} (args={args_str} vars={vars_str}): []".format(
        filename=filename,
        args_str=args,
        vars_str=vars
    )
    assert actual == expected


# Generated at 2022-06-21 00:49:13.374801
# Unit test for method __eq__ of class IncludedFile

# Generated at 2022-06-21 00:49:25.879310
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Ensure _args, _vars and _task_uuid are equal
    task_a = TaskInclude()
    task_a._parent._parent._parent._vars = dict()
    task_b = TaskInclude()
    task_b._parent._parent._parent._vars = dict()

    file_a = IncludedFile('filename', dict(), dict(), task_a)
    file_b = IncludedFile('filename', dict(), dict(), task_b)
    assert file_a == file_b

    # Ensure _args and _vars are not equal
    task_a = TaskInclude()
    task_a._parent._parent._parent._vars = dict()
    task_b = TaskInclude()
    task_b._parent._parent._parent._vars = dict(var1=1)
    file_a = IncludedFile

# Generated at 2022-06-21 00:50:16.485250
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    class MockHost(object):
        def __init__(self, hostname):
            self.hostname = hostname

    class MockTaskResult(object):
        def __init__(self, hostname, action, include_result):
            self._host = MockHost(hostname)
            self._task = MockTask(action)
            self._result = include_result

    class MockTask(object):
        action = None

        def __init__(self, action):
            self.action = action

    class MockIterator(object):
        def __init__(self):
            self._play = 'play'

    class MockVariableManager(object):
        def get_vars(self, play, host, task):
            return 'vars'

    class MockLoader(object):
        def __init__(self, basedir):
            self

# Generated at 2022-06-21 00:50:25.040426
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
   # test 1
   filename = "/path/to/file"
   args = dict()
   vars = dict()
   task = "task"
   included_file1 = IncludedFile(filename, args, vars, task)

   # test 2
   filename = "/path/to/file"
   args = dict()
   vars = dict()
   task = "task"
   included_file2 = IncludedFile(filename, args, vars, task)

   # test 3
   filename = "/path/to/file1"
   args = dict()
   vars = dict()
   task = "task"
   included_file3 = IncludedFile(filename, args, vars, task)

   # test 4
   filename = "/path/to/file"
   args = dict()
   vars = dict()

# Generated at 2022-06-21 00:50:35.453201
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task = IncludedFile('/foo.yml', {}, {}, object(), is_role=False)
    assert task == task
    assert task == task
    assert task != None
    assert task == IncludedFile('/foo.yml', {}, {}, object(), is_role=False)
    assert task != IncludedFile('/foo2.yml', {}, {}, object(), is_role=False)
    assert task != IncludedFile('/foo.yml', {'bar': 2}, {}, object(), is_role=False)
    assert task != IncludedFile('/foo.yml', {}, {'bar': 2}, object(), is_role=False)
    assert task != IncludedFile('/foo.yml', {}, {}, object(), is_role=True)

# Generated at 2022-06-21 00:50:46.373802
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-21 00:50:52.012866
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile(filename='filename', args='args', vars='vars', task='task')
    actual = included_file.__repr__()
    expected = "filename (args=args vars=vars): []"
    assert actual == expected


# Generated at 2022-06-21 00:50:55.879000
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    assert(str(IncludedFile("/tmp/foo.yml", {"a": "A"}, {"a": "A"}, None)) == "/tmp/foo.yml (args=['a'] vars=['a']): []")


# Generated at 2022-06-21 00:51:08.714700
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    orig_task = TaskInclude()
    orig_args = {'name': 'godzilla',
                 'x': '2'}
    orig_vars = {'omit': 'omitted_var'}
    inc_file = IncludedFile('the_file', orig_args, orig_vars, orig_task)

    assert inc_file._filename == 'the_file'
    assert inc_file._vars == orig_vars
    assert inc_file._task == orig_task
    assert inc_file._is_role == False

    # check copy constructor
    inc_file_copy = IncludedFile('', orig_args, orig_vars, orig_task, inc_file._is_role)
    assert inc_file == inc_file_copy

# Generated at 2022-06-21 00:51:15.607547
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_file = IncludedFile('hosts', {}, {}, None)
    included_file.add_host('host1')
    included_file.add_host('host2')

    try:
        included_file.add_host('host1')
        assert False, "Should not be reached"
    except ValueError:
        pass


# Generated at 2022-06-21 00:51:19.850508
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task

    assert IncludedFile(
        "filepath",
        {"test1": "test1 content"},
        {"test2": "test2 content"},
        Task()
    ) == IncludedFile(
        "filepath",
        {"test1": "test1 content"},
        {"test2": "test2 content"},
        Task()
    )
    assert IncludedFile(
        "filepath",
        {},
        {},
        Task()
    ) != IncludedFile(
        "filepath",
        {"test": "test content"},
        {},
        Task()
    )

# Generated at 2022-06-21 00:51:31.507386
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    class FakeLoader():
        def __init__(self):
            self.basedir = '.'

        def get_basedir(self):
            return self.basedir

        def path_dwim(self, path):
            return path

        def path_dwim_relative(self, root, path, include_target):
            return os.path.join(root, path, include_target)

    class FakeTask():
        def __init__(self, name, uuid, args=dict(), result=dict()):
            self.name = name
            self._uuid = uuid
            self._args = args
            self._result = result
