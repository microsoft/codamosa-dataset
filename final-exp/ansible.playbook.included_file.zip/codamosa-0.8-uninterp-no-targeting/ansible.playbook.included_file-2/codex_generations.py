

# Generated at 2022-06-21 00:43:05.806259
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = "playbook.yml"
    args = {}
    vars = {}
    task = None
    is_role = False

    file1 = IncludedFile(filename, args, vars, task, is_role)
    assert repr(file1) == "playbook.yml (args={} vars={}): []"



# Generated at 2022-06-21 00:43:14.446225
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    #
    # Verify that method returns True when _filename and _task are the same
    #
    test_filename = "/home/test/playbook.yml"
    test_task = "test_task"

    include_file_1 = IncludedFile(test_filename, None, None, test_task)
    include_file_2 = IncludedFile(test_filename, None, None, test_task)

    assert include_file_1 == include_file_2


# Generated at 2022-06-21 00:43:26.093934
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    loader = None
    variable_manager = None
    iterator = None
    results = []
    my_task = None
    my_host = "blah"
    test_inc_file = IncludedFile("blah.yml", "blah.yml", "blah.yml", my_task)
    # when adding a host that is not already present, it should be added and return true
    assert test_inc_file.add_host(my_host) == None
    # when adding the same host again, it should raise a value error and return None
    assert test_inc_file.add_host(my_host) == None

# Generated at 2022-06-21 00:43:38.765393
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    inventory = InventoryManager(loader=loader, source=None, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    play_source = dict(
        name='Test Play',
        hosts=['test'],
        gather_facts='no',
        tasks=[]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 00:43:50.544362
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    t1 = TaskInclude()
    t2 = TaskInclude()
    t1.vars = {'foo': 'bar'}
    t2.vars = {'foo': 'bar'}
    assert IncludedFile('file.yml', {}, {}, t1) == IncludedFile('file.yml', {}, {}, t2)

    r1 = IncludeRole()
    r2 = IncludeRole()
    assert IncludedFile('file.yml', {}, {}, r1) == IncludedFile('file.yml', {}, {}, r2)

    t1.vars['foo'] = 'banana'
    assert IncludedFile('file.yml', {}, {}, t1) != IncludedFile('file.yml', {}, {}, t2)

    t1.vars = {'foo': 'bar'}


# Generated at 2022-06-21 00:44:01.190538
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = 'test.yml'
    args = {'some': 'args', 'another': 'arg'}
    vars = {'var': 'value', 'another': 'var'}
    task = 'some_task'
    test_init = IncludedFile(filename, args, vars, task)
    for key, value in vars.items():
        assert test_init._vars[key] == value
    for key, value in args.items():
        assert test_init._args[key] == value
    assert test_init._filename == filename
    assert test_init._task == task
    assert test_init._is_role is False


# Generated at 2022-06-21 00:44:07.197163
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = "test.yml"
    args = dict()
    vars = dict()
    host = "localhost"
    included_file = IncludedFile(filename, args, vars, None)
    included_file.add_host(host)
    exp_repr = "test.yml (args={} vars={}): ['localhost']"
    assert exp_repr == included_file.__repr__()


# Generated at 2022-06-21 00:44:13.835492
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    result = IncludedFile(filename='yes', args='yes', vars='yes', task='yes')
    assert result.__repr__() == "yes (args=yes vars=yes): []", 'Unexpected result: %s' % result.__repr__()


# Generated at 2022-06-21 00:44:19.519504
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = "hosts.txt"
    args = {'arg1': "value1"}
    vars = {'var1': "value1"}
    #task = {'task1': "value1"}
    is_role = True
    inc_file = IncludedFile(filename, args, vars, None, is_role)
    assert inc_file._filename == filename
    assert inc_file._args == args
    assert inc_file._vars == vars
    assert inc_file._task is None
    assert inc_file._is_role == is_role
    assert inc_file._hosts == []


# Generated at 2022-06-21 00:44:22.981623
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # Create a IncludedFile object with a dummy uuid and dummy list for hosts
    incFile = IncludedFile("filename", "args", "vars", "task", "role")
    setattr(incFile, "_hosts", ['host'])
    # Assert that the object's string representation is as expected
    assert repr(incFile) == "filename (args=args vars=vars): ['host']"

# Generated at 2022-06-21 00:44:51.312568
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    included_files = [
        'tasks/foo.yml',
        'tasks/bar.yml',
        'roles/baz/tasks/main.yml',
        'roles/baz/meta/main.yml'
    ]
    results = []
    task_vars = {
        'ansible_play_batch': included_files,
        'ansible_play_hosts_all': included_files
    }
    pc = PlayContext()
    pc.task_vars = task_vars
    pc.var_manager = combine_vars(pc.task_vars, pc.extra_vars)
    included_files = IncludedFile.process_include

# Generated at 2022-06-21 00:45:02.433184
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # given
    filename = "/ansible/playbooks/roles/foo/tasks/main.yml"
    args = {"version": "1.0", "debug": True}
    vars = {"foo": "bar"}
    task = C._TASK_TYPE_INCLUDE
    is_role = False

    included_file = IncludedFile(filename, args, vars, task, is_role)
    included_file._hosts = ["localhost"]

    # when
    result = included_file.__repr__()

    # then
    assert result == "/ansible/playbooks/roles/foo/tasks/main.yml (args={'version': '1.0', 'debug': True} vars={'foo': 'bar'}): ['localhost']"


# Generated at 2022-06-21 00:45:06.841132
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    assert repr(IncludedFile('file1', {}, {}, None)) == "file1 (args={} vars={}): []"
    assert repr(IncludedFile('file2', {'x': 1}, {'y':2, 'z':3}, None)) == "file2 (args={'x': 1} vars={'y': 2, 'z': 3}): []"

# Generated at 2022-06-21 00:45:12.902742
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    # ansible.cfg should exist in current working directory to avoid "ERROR! Unable to parse /etc/ansible/ansible.cfg"
    from ansible.config.manager import ConfigManager
    config = ConfigManager(os.path.abspath("./ansible.cfg"))
    config.set_config_file()

    play_context = PlayContext()

# Generated at 2022-06-21 00:45:19.911875
# Unit test for constructor of class IncludedFile
def test_IncludedFile():

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook_include.task_include import TaskInclude
    from ansible.playbook_include.role_include import IncludeRole
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar
    from ansible.template.vars import AnsibleVars

    d = AnsibleDumper()
    t = Templar(loader=None, variables={})
    m = VariableManager()
    c = PlayContext()
    tc = Task()
    pc = Play()
    pi = TaskInclude()


# Generated at 2022-06-21 00:45:29.012365
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    task_1 = Task()
    block_1 = Block()
    block_1._uuid = '1' * 32
    task_1._parent = block_1
    task_2 = Task()
    block_2 = Block()
    block_2._uuid = '2' * 32
    task_2._parent = block_2

    included_file_1_1 = IncludedFile('filename', {'arg':'value'}, {'var':'value'}, task_1)
    included_file_1_2 = IncludedFile('filename', {'arg':'value'}, {'var':'value'}, task_2)

# Generated at 2022-06-21 00:45:35.964795
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = "blah"
    args = "blah"
    vars = "blah"
    task = "blah"
    is_role = "blah"
    includedfile = IncludedFile(filename, args, vars, task, is_role)


# Generated at 2022-06-21 00:45:45.095051
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    ifh = IncludedFile('filename', {'args1': 'args1'}, {'vars1': 'vars1'}, {'task1': 'task1'}, True)
    ifh2 = IncludedFile('filename', {'args1': 'args1'}, {'vars1': 'vars1'}, {'task1': 'task1'}, True)
    assert (ifh == ifh2)

    ifh2 = IncludedFile('filename1', {'args1': 'args1'}, {'vars1': 'vars1'}, {'task1': 'task1'}, True)
    assert (ifh != ifh2)


# Generated at 2022-06-21 00:45:50.290436
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible import variables
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_iterator import PlaybookIterator

    class FakeHost:
        def __init__(self, name):
            self.name = name

    class FakeTask:
        def __init__(self, action):
            self.action = action
            self._dep_chain = []
            self._parent = None

        def copy(self):
            new_task = FakeTask(self.action)
            new_task._parent = self
            return new_task

    class FakePlay:
        def __init__(self, variable_manager, loader, templar, task_vars, include_tasks):
            self._variable_manager = variable_manager
            self._

# Generated at 2022-06-21 00:46:03.739039
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class Temp:
        def __init__(self, _uuid):
            self._uuid = _uuid
    class Temp2:
        def __init__(self, _parent, _uuid):
            self._parent = _parent
            self._uuid = _uuid
    filename = 'host_1'
    args = {'_raw_params': 'host_2'}
    vars = {'host_3':'host_4'}
    task1 = 'task1'
    task2 = 'task2'
    temp1 = Temp('temp1')
    temp2 = Temp2(temp1, 'temp2')
    tempTask = TaskInclude(task1, temp2, filename, args, loader=None, variable_manager=None, loader_cache=dict())

# Generated at 2022-06-21 00:46:27.788676
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    Test IncludedFile.process_include_results method
    """
    # Create mock result data

# Generated at 2022-06-21 00:46:37.006196
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    assert co.IncludedFile("foo", None, None, None) == co.IncludedFile("foo", None, None, None)
    assert not co.IncludedFile("foo", None, None, None) != co.IncludedFile("foo", None, None, None)
    assert not co.IncludedFile("foo", None, None, None) == co.IncludedFile("foo", None, None, None, is_role=True)
    assert co.IncludedFile("foo", None, None, None) != co.IncludedFile("foo", None, None, None, is_role=True)
    assert not co.IncludedFile("foo", None, None, None) == co.IncludedFile("foo2", None, None, None)

# Generated at 2022-06-21 00:46:45.239749
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible import utils
    from ansible.module_utils.facts import is_local_address
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager

    from collections import namedtuple

    class FakeHost(object):
        def __init__(self, name):
            self.name = name

        def __hash__(self):
            return hash(self.name)


# Generated at 2022-06-21 00:46:56.507811
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_file = IncludedFile("some_filename", None, None, None)

    # test add_host
    # add a host
    included_file.add_host("localhost")
    assert included_file._hosts[0] == "localhost"

    # add same host twice and raises ValueError
    try:
        included_file.add_host("localhost")
        assert False
    except ValueError:
        assert True

    # add a new host
    included_file.add_host("127.0.0.1")
    assert included_file._hosts[0] == "localhost"
    assert included_file._hosts[1] == "127.0.0.1"



# Generated at 2022-06-21 00:47:06.456721
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # TODO: create proper test for method __repr__ of class IncludedFile
    # TODO: create tests for all other methods and classes in this file

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    play = Play()
    play.vars = {'var1': 'val1'}
    play.hosts = ['host1', 'host2']

    task = Task()
    task.vars = {'var2': 'val2'}
    task.action = "test"
    task._uuid = "id1234"
    task._parent = play

    ifile = IncludedFile("filename", {'arg1': 'val1'}, {'var2': 'val2'}, task, is_role=True)


# Generated at 2022-06-21 00:47:14.060353
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    print(IncludedFile('filename', dict(), dict(), dict()))
    print(IncludedFile('filename', dict(key='value'), dict(), dict()))
    print(IncludedFile('filename', dict(), dict(key='value'), dict()))
    print(IncludedFile('filename', dict(key='value'), dict(key='value'), dict()))


# Generated at 2022-06-21 00:47:19.571048
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    assert (
        repr(IncludedFile(
            "test",
            dict(a=1,b=2),
            dict(c=3,d=4),
            "task"
        ))
    ) == """test (args=dict(a=1, b=2) vars=dict(c=3, d=4)): []"""


# Generated at 2022-06-21 00:47:20.424675
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    pass

# Generated at 2022-06-21 00:47:28.666472
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    task = object()
    included_file = IncludedFile('home/ansible/playbook.yml', 'args', 'vars', task)
    included_file.add_host('host1')
    included_file.add_host('host2')
    expected_output = "home/ansible/playbook.yml (args=args vars=vars): ['host1', 'host2']"
    assert repr(included_file) == expected_output

# Generated at 2022-06-21 00:47:40.980910
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import os
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    # Setup
    filename1 = '/tmp/file1'
    # filename2 = '/tmp/file2'
    args1 = {'some_arg': 'value_1'}
    args2 = {'some_arg': 'value_2'}
    vars1 = {'some_var': '1'}
    vars2

# Generated at 2022-06-21 00:48:01.226557
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task

    # TaskInclude and IncludeRole are only used for testing __eq__, so we don't need to import all module

    class TaskInclude(object):
        def __init__(self, uuid, parent):
            self._uuid = uuid
            self._parent = parent

    class IncludeRole(object):
        def __init__(self, uuid, role_path):
            self._uuid = uuid
            self._role_path = role_path

    included_file_1 = IncludedFile(
        filename='foo.yml',
        args=dict(),
        vars=dict(),
        task=TaskInclude(1, None),
        is_role=False
    )


# Generated at 2022-06-21 00:48:08.391083
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile("", {}, {}, None)
    inc_file.add_host("foobar")
    inc_file.add_host("foobar2")
    try:
        inc_file.add_host("foobar")
        assert False, "No error raised"
    except ValueError:
        pass


# Generated at 2022-06-21 00:48:16.617145
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    def _init_res(host, task, action, item=None, index_var='_index', loop_var='_item', results=None, failed=False, skipped=False):

        class Res:
            def __init__(self, host, task, action, item=None, index_var='_index', loop_var='_item', results=None, failed=False, skipped=False):
                self._host = host
                self._task = task
                self._result = dict()
                self._result['include'] = item
                self._result[action] = 'something'
                self._result['ansible_loop_var'] = loop_var
                self._result['ansible_index_var'] = index_var
                self._result['include_args'] = dict()

# Generated at 2022-06-21 00:48:25.846018
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    # Test case 1: two objects are different
    included_file1 = IncludedFile('foo', dict(), dict(), 'bar')
    included_file2 = IncludedFile('foo', dict(), dict(), 'bar')
    included_file1.add_host('test1')
    included_file1.add_host('test2')
    included_file2.add_host('test2')
    included_file2.add_host('test3')
    assert not included_file1 == included_file2

    # Test case 2: two objects are the same
    included_file1 = IncludedFile('foo', dict(), dict(), 'bar')
    included_file2 = IncludedFile('foo', dict(), dict(), 'bar')
    included_file1.add_host('test1')
    included_file1.add_host('test2')
    included_

# Generated at 2022-06-21 00:48:36.181582
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # mocks for IncludedFile
    class mock_task:
        _uuid = 'my_uuid'
        class mock_parent:
            _uuid = 'parent_uuid'
    # tests
    inc1 = IncludedFile('filename1', {'arg1': 'value1'}, {'var1': 'value1'}, mock_task())
    inc2 = IncludedFile('filename1', {'arg1': 'value1'}, {'var1': 'value1'}, mock_task())
    inc3 = IncludedFile('filename1', {'arg1': 'value1'}, {'var1': 'value3'}, mock_task())
    inc4 = IncludedFile('filename1', {'arg1': 'value1'}, {'var1': 'value1'}, mock_task())

# Generated at 2022-06-21 00:48:46.206551
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    host = Host(name="localhost", port=22)
    inventory.add_host(host)
    play_context = PlayContext(variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 00:48:58.421865
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()

    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    inventories = InventoryManager(loader=loader, sources=["tests/ansible/inventory/test_inventory"])
    original_host = inventories.get_host("testhost")
    original_task = TaskInclude(action="include", loop_control=dict(loop_var="item"))
    original_task.action = "include"
    original_task._role_name = ""
    original_task._from_files = {}
    original_task._role = None
    original_task._parent = None

    # Set the filename


# Generated at 2022-06-21 00:49:09.441726
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins import module_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    import tempfile
    import shutil

    step1 = tempfile.mkdtemp()
    step2 = tempfile.mkdtemp()
    step3 = tempfile.mkdtemp()



# Generated at 2022-06-21 00:49:22.279490
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # For details on these imports, see comments in the test module
    # test/units/module_utils/test_action.py, but don't move them into this file
    # as that would create a circular dependency.
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

# Generated at 2022-06-21 00:49:25.824290
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    result = str(IncludedFile('filename', 'args', 'vars', 'task'))
    assert result == "filename (args=args vars=vars): []"


# Generated at 2022-06-21 00:50:01.246215
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = "filename"
    args = "arg1"
    vars = "var1"
    task = "task1"

    included_file = IncludedFile(filename, args, vars, task)
    included_file.add_host("host1")
    included_file.add_host("host2")
    assert len(included_file._hosts) == 2
    included_file.add_host("host1")
    assert len(included_file._hosts) == 2

# Generated at 2022-06-21 00:50:11.194523
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    included_file = IncludedFile("/foo/bar.yml", {1:2}, {3:4}, 5)
    assert included_file._filename == "/foo/bar.yml"
    assert included_file._args == {1:2}
    assert included_file._vars == {3:4}
    assert included_file._task == 5
    assert included_file._hosts == []
    assert included_file._is_role == False


# Generated at 2022-06-21 00:50:21.051129
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = "/this/is/a/file.yml"
    args = {'x': "value for parameter x"}
    vars = {"myvar": 3}
    task = fake_Task()
    a = IncludedFile(filename, args, vars, task)
    b = IncludedFile(filename, args, vars, task)
    assert a == b

    x = IncludedFile(filename, args, vars, task)
    y = IncludedFile(filename + "2", args, vars, task)
    assert x != y

    c = IncludedFile(filename, args.copy(), vars, task)
    d = IncludedFile(filename, {'x': 'a different value'}, vars, task)
    assert c != d

    e = IncludedFile(filename, args, vars.copy(), task)
    f = IncludedFile

# Generated at 2022-06-21 00:50:34.211284
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-21 00:50:38.642455
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile('foo.yml', dict(), dict(), 'Test')
    b = IncludedFile('foo.yml', dict(), dict(), 'Test')
    assert a == b

# Generated at 2022-06-21 00:50:43.746365
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    """
    Tests method IncludedFile.add_host()
    """
    filename = "test_file"
    args = {}
    vars = {}
    task = ""
    inc_file = IncludedFile(filename, args, vars, task)
    host = "test_host"
    inc_file.add_host(host)


# Generated at 2022-06-21 00:50:49.153669
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'file1'
    args = {'arg1':'value1', 'arg2':'value2'}
    vars = {'var1':'value1', 'var2':'value2'}
    task = 'task'
    is_role = False

    incFile_obj = IncludedFile(filename, args, vars, task, is_role)

    assert repr(incFile_obj) == repr("%s (args=%s vars=%s): %s" % (filename, args, vars, incFile_obj._hosts))


# Generated at 2022-06-21 00:50:55.123889
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host

    item = Host(name='test')
    task = Task()
    inc_file = IncludedFile('file', {}, {}, task)
    inc_file.add_host(item)

    assert len(inc_file._hosts) == 1

# Generated at 2022-06-21 00:51:08.855053
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    host1 = 'host1.example.com'
    host2 = 'host2.example.com'
    host3 = 'host3.example.com'

    filename1 = '/tmp/file1'
    filename2 = '/tmp/file2'
    filename3 = '/tmp/file3'

    args1 = {'arg1': 'val1'}
    args2 = {'arg2': 'val2'}
    args3 = {'arg3': 'val3'}

    vars1 = {'var1': 'val1'}
    vars2 = {'var2': 'val2'}
    vars3 = {'var3': 'val3'}

    task1 = None
    task2 = None
    task3 = None


# Generated at 2022-06-21 00:51:17.407538
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    include = IncludedFile('test_include.yml', {}, {}, None)

    try:
        include.add_host('host1')
        assert len(include._hosts) == 1
        include.add_host('host2')
        assert len(include._hosts) == 2
        include.add_host('host1')
        assert True == False, "host1 shouldn't be re-added"
    except ValueError:
        assert len(include._hosts) == 2

# Generated at 2022-06-21 00:52:30.456947
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test match
    test_cases = [
        ('test1', 'test1', 'test1', 'test1', False, 'test1'),
        ('test2', 'test2', 'test2', 'test2', False, 'test2'),
        ('test3', 'test3', 'test3', 'test3', True, 'test3')
    ]
    for (fn1, fn2, arg1, arg2, role1, role2) in test_cases:
        obj1 = IncludedFile(fn1, arg1, '', '', role1)
        obj2 = IncludedFile(fn2, arg2, '', '', role2)
        assert obj1 == obj2
        assert obj2 == obj1

    # Test non-match

# Generated at 2022-06-21 00:52:34.875364
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    x = IncludedFile('filename', 'args', 'vars', 'task')
    y = IncludedFile('filename', 'args', 'vars', 'task')
    assert x == y


# Generated at 2022-06-21 00:52:40.483047
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import fragment_loader
    from ansible.executor.task_result import TaskResult
