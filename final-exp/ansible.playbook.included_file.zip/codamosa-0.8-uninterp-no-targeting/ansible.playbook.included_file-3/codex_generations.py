

# Generated at 2022-06-21 00:43:06.934620
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        from ansible.plugins.loader import action_loader
        from ansible.plugins.action.include_tasks import ActionModule as IncludeTasks
    except ImportError:
        print("unable to import IncludeTasks module, skipping test")
        return

    # IncludeTasks is the module for all %_tasks, so we'll use that for our unit test
    class MyIncludeTasks(IncludeTasks):
        pass

    from ansible.inventory import Host, Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class HostResult:
        def __init__(self, host, task, result):
            self._host = host
            self._task = task

# Generated at 2022-06-21 00:43:18.279222
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    import ansible.constants as C
    import json

    # This is the Host to be tested
    class Host(object):
        def __init__(self, name, groups=[]):
            self._name = name
            self._group_names = groups


# Generated at 2022-06-21 00:43:26.532747
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = 'file1.yml'
    args = {}
    vars = {}
    task = None
    is_role = False
    includedFile = IncludedFile(filename, args, vars, task, is_role)
    includedFile.add_host('host1')
    includedFile.add_host('host2')
    assert includedFile._hosts[0] == 'host1'
    assert includedFile._hosts[1] == 'host2'


# Generated at 2022-06-21 00:43:37.966268
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile("fake_file", "fake_args", "fake_vars", None)

    # Add a host
    inc_file.add_host("fake_host")
    assert len(inc_file._hosts) == 1
    assert inc_file._hosts[0] == "fake_host"

    # Add the same host again
    try:
        inc_file.add_host("fake_host")
    except ValueError:
        assert len(inc_file._hosts) == 1
        assert inc_file._hosts[0] == "fake_host"



# Generated at 2022-06-21 00:43:42.260876
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    file1 = IncludedFile("sample", {}, {}, "sample")
    file2 = IncludedFile("sample", {}, {}, "sample")

    assert file1 == file2


# Generated at 2022-06-21 00:43:47.505465
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile(None, None, None, None)
    inc_file.add_host('foo')
    inc_file.add_host('bar')

    try:
        inc_file.add_host('foo')
        assert 0, 'Re-Added a host to an include file'
    except ValueError:
        pass

# Generated at 2022-06-21 00:44:00.814256
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file_a = IncludedFile('/path/a', {}, '', '', is_role=False)
    inc_file_b = IncludedFile('/path/b', {}, '', '', is_role=False)

    inc_file_a.add_host('host1')
    inc_file_a.add_host('host2')
    inc_file_a.add_host('host3')

    inc_file_b.add_host('host4')
    inc_file_b.add_host('host5')
    inc_file_b.add_host('host6')

    try:
        inc_file_a.add_host('host1')
    except ValueError:
        pass
    else:
        assert False, 'We should not get to this point'


# Generated at 2022-06-21 00:44:09.016806
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    inc_file = IncludedFile('a filename', 'some arguments', 'some variables', 'a task')
    inc_file.add_host('localhost')
    assert repr(inc_file) == 'a filename (args=some arguments vars=some variables): [localhost]'
    inc_file.add_host('localhost2')
    assert repr(inc_file) == 'a filename (args=some arguments vars=some variables): [localhost, localhost2]'
    inc_file.add_host('localhost')
    assert repr(inc_file) == 'a filename (args=some arguments vars=some variables): [localhost, localhost2]'



# Generated at 2022-06-21 00:44:19.175400
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Play
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    mock_play_context = PlayContext()
    mock_play_context._included_file = None
    mock_play_context._host = "host"
    mock_play_context._task = "task"
    mock_play_context.CLIARGS = {}
    mock_play_context.new_stdin = None
    mock_play_context.extra_vars = {}

    mock_

# Generated at 2022-06-21 00:44:25.384582
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task

    # create the task
    task = Task()
    task._ds = {}
    task._ds['name'] = 'my_task'

    # create an include_role
    inc_role = IncludeRole()
    inc_role._ds = {}
    inc_role._ds['name'] = 'my_inc_role'
    inc_role._ds['args'] = {}
    inc_role._ds['args']['role'] = 'my_role'
    inc_role._parent = task

    # create an included files
    inc_file = IncludedFile('my_file', {'my_arg': 'my_val'}, {'my_var': 'my_val'}, task)
    assert inc_file == inc_file
    assert inc_file != 'my_file'

   

# Generated at 2022-06-21 00:44:46.720169
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # Test Invalid Type
    try:
        IncludedFile(1, 2, 3, 4)
    except TypeError:
        pass
    except Exception as e:
        raise TypeError(e)
    else:
        raise TypeError()

    # Test Same File (Positive)
    try:
        test1 = IncludedFile('test_file', 3, 4, 5)
        test2 = IncludedFile('test_file', 3, 4, 5)
        assert test1 == test2
    except Exception as e:
        raise TypeError(e)

    # Test Different File (Negative)
    try:
        test1 = IncludedFile('test_file', 3, 4, 5)
        test2 = IncludedFile('test_file2', 3, 4, 5)
        assert test1 != test2
    except Exception as e:
        raise Type

# Generated at 2022-06-21 00:44:57.311190
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    import tempfile
    include_file = tempfile.mktemp()
    inc_file = IncludedFile(include_file, {'arg1':1, 'arg2':2}, {'var1':1, 'var2':2}, None)
    assert repr(inc_file) == "'{0}' (args={1} vars={2}): []".format(include_file, {'arg1':1, 'arg2':2}, {'var1':1, 'var2':2})


# Generated at 2022-06-21 00:45:07.524399
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    f = IncludedFile('/path/to/file.yml', dict(), dict(), 'meh')
    h = object()
    assert f.add_host(h) is None
    assert f._hosts == [h]
    # check it's idempotent
    assert f.add_host(h) is None
    assert f._hosts == [h]
    try:
        f.add_host('yolo')
    except ValueError:
        return
    assert False, 'ValueError not raised'

# Generated at 2022-06-21 00:45:21.595508
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # import signal; signal.signal(signal.SIGINT, signal.SIG_DFL)
    import sys
    import tempfile
    import unittest
    try:
        from unittest import mock
    except ImportError:
        import mock

    import ansible.executor
    import ansible.utils
    import ansible.vars
    import ansible.utils.display
    import ansible.utils.template
    import ansible.template

    class TestIncludedFile(unittest.TestCase):
        def setUp(self):
            self.m_basedir = tempfile.mkdtemp()
            self.m_playbook = tempfile.NamedTemporaryFile()
            self.m_playbook.write(b'1')
            self.m_playbook.flush()

            # open a temp

# Generated at 2022-06-21 00:45:33.474161
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    obj1 = IncludedFile(None, None, None, None)
    obj2 = IncludedFile(None, None, None, None)
    obj3 = IncludedFile(None, None, None, None)
    obj3._task = "task_3"
    obj3._task._parent = "parent_3"

    obj1.add_host("host1")
    obj2.add_host("host2")
    obj3.add_host("host3")
    obj1.add_host("host4")
    obj2.add_host("host4")
    obj3.add_host("host4")
    try:
        obj1.add_host("host4")
    except ValueError:
        pass

    assert len(obj1._hosts) == 2
    assert len(obj2._hosts) == 2

# Generated at 2022-06-21 00:45:42.896039
# Unit test for constructor of class IncludedFile
def test_IncludedFile():

    class TestIncludedFile:
        def __init__(self, filename, args, vars, task, is_role=False):
            self._filename = filename
            self._args = args
            self._vars = vars
            self._task = task
            self._hosts = []
            self._is_role = is_role

        def add_host(self, host):
            if host not in self._hosts:
                self._hosts.append(host)
                return
            raise ValueError()


# Generated at 2022-06-21 00:45:54.788054
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    class Host:
        def __init__(self,name):
            self.name = name

        def __eq__(self,other):
            return self.name == other.name

        def __repr__(self):
            return "host '%s'" % self.name

    host1,host2 = Host("host1"), Host("host2")

    # Testing included file with no hosts
    included_file = IncludedFile("path/to/foo","some_args","some_vars","some_task")
    assert included_file._hosts == []

    # Testing included file with no host
    included_file.add_host(host1)
    assert included_file._hosts == [host1]

    # Testing included file with host already present
    included_file.add_host(host1)
    assert included_file._host

# Generated at 2022-06-21 00:46:05.739211
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    from ansible.plugins.loader import role_loader
    from ansible.playbook import task, role
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    r = role.Role()
    r._role_path = '/tmp/foo'

    t = task.Task()
    t._parent = AnsibleBaseYAMLObject()

    a = IncludedFile('foo', 'bar', 'baz', t)
    b = IncludedFile('foo', 'bar', 'baz', t)
    assert a == b

    t._parent = AnsibleBaseYAMLObject()
    c = IncludedFile('foo', 'bar', 'baz', t)
    assert a != c

    t._parent = AnsibleBaseYAMLObject()

# Generated at 2022-06-21 00:46:12.611344
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = "foo"
    args = "bar"
    vars = "baz"
    task = "baz"
    inc_file = IncludedFile(filename, args, vars, task)
    repr = inc_file.__repr__()
    assert repr is not "foo (args=bar vars=baz): []"


# Generated at 2022-06-21 00:46:26.273977
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    import sys
    import pytest
    from io import StringIO
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()
    temp_dir_path = temp_dir.name

    # create a dummy task action

# Generated at 2022-06-21 00:46:59.688607
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from ansible.playbook.task_include import TaskInclude

    test_case_data = ( (1,), (2,), (2,), (2,), (1,) )
    test_task = TaskInclude()
    ans_inc_file = IncludedFile('filename', {}, {}, test_task)
    # check number of items in inc_file._hosts
    assert len(ans_inc_file._hosts) == 0     # true

    for i in test_case_data:
        if i == 1:
            # if i is 1, the add_host method add host to inc_file._hosts
            ans_inc_file.add_host('host')
        else:
            # if i is 2, the add_host method raise ValueError
            with pytest.raises(ValueError):
                ans_inc

# Generated at 2022-06-21 00:47:13.350186
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    import copy
    import mock
    import nose

    class TestIncludedFile(IncludedFile):
        def __init__(self):
            pass

    test_instance = TestIncludedFile()


    # The class has no attribute '_filename'
    test_instance._filename = None
    result = test_instance.__repr__()
    assert result == "None (args=None vars=None): []"

    # The class has no attribute '_args'
    test_instance._filename = "test file"
    test_instance._args = None
    result = test_instance.__repr__()
    assert result == "test file (args=None vars=None): []"

    # The class has no attribute '_vars'
    test_instance._args = "test args"
    test_instance._vars = None

# Generated at 2022-06-21 00:47:24.273800
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole


# Generated at 2022-06-21 00:47:34.773195
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    import sys
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import test_loader

    class Bla(object):
        def __init__(self, _uuid, _parent):
            self._uuid = _uuid
            self._parent = _parent
            self.action = 'include_tasks'
            self.loop = True

    class Blaa(object):
        def __init__(self, _host, _task, _result, _task_fields):
            self._host = _host
            self._task = _task
            self._result = _result
            self._task_fields = _task_fields


# Generated at 2022-06-21 00:47:42.335288
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():

    class Object(object):
        pass

    args = dict(path=['a', 'b', 'c'])
    vars = dict(key=['d', 'e', 'f'])
    task = Object()
    task.uuid = 'g'

    included_file = IncludedFile('filename', args, vars, task)
    assert repr(included_file) == "filename (args={'path': ['a', 'b', 'c']} vars={'key': ['d', 'e', 'f']}): []"

# Generated at 2022-06-21 00:47:53.650546
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    ''' unit test for method process_include_results of class IncludedFile '''

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    try:
        from collections import OrderedDict
    except ImportError:
        from ansible.utils.ordered_dict import OrderedDict


# Generated at 2022-06-21 00:48:04.647532
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # pylint: disable=unused-variable,unused-argument
    import unittest
    import yaml

    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.strategy import StrategyBase
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    # Set up a dummy class for testing
    class Dummy:
        pass

    class DummyStrategy(StrategyBase):
        pass

    class DummyPlay(Dummy):
        # Do not use @staticmethod as it won't work for the test
        pass

        def get_variable_manager(self):
            return

# Generated at 2022-06-21 00:48:13.078278
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = 'my_file'
    args = {'a': 1}
    vars = {'v': 2}
    task = 'my_task'
    host = 'my_host'

    # init
    included_file = IncludedFile(filename, args, vars, task)

    # add host
    included_file.add_host(host)
    assert included_file._hosts == [host]

    # add already existing host
    try:
        included_file.add_host('my_host')
        assert False
    except ValueError:
        # expected
        assert True


# Generated at 2022-06-21 00:48:24.907576
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.vars.unsafe_proxy import UnsafeProxy

    task_res = []
    mock_host = Host(name="mock_host", port=22)
    mock_task = Task()
    mock_task.action = "include_tasks"
    mock_task._role = UnsafeProxy({'_role_path':'/some/path'})

    res = TaskResult(host=mock_host, task=mock_task, return_data={'include': '{{ lookup("env", "HOME") }}/some/path/foo.yml',
                                                                   'include_args': {'foo': 'bar'}}, loop_eval=True)

# Generated at 2022-06-21 00:48:28.233744
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'file'
    args = 'args'
    vars = 'vars'
    task = 'task'
    inc = IncludedFile(filename, args, vars, task)

    expected = "%s (args=%s vars=%s): %s" % (filename, args, vars, [])
    assert repr(inc) == expected

# Generated at 2022-06-21 00:49:49.781831
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'filename.yml'
    args = dict()
    vars = dict()
    task = object()
    included_file = IncludedFile(filename, args, vars, task)
    expected = 'filename.yml (args={} vars={}): []'
    assert repr(included_file) == expected


# Generated at 2022-06-21 00:50:02.636707
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from ansible.executor.task_executor import HostState
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext

    inc_file = IncludedFile("DUMMY", dict(), dict(), TaskInclude("INCLUDE_ARGS", PlayContext()))

    host1 = HostState("DUMMY_HOST1")
    inc_file.add_host(host1)
    host2 = HostState("DUMMY_HOST2")
    inc_file.add_host(host2)

    assert len(inc_file._hosts) == 2

    # Trying to add the same host again should raise a ValueError
    with pytest.raises(ValueError):
        inc_file.add_host(host1)



# Generated at 2022-06-21 00:50:06.926208
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    included_file = IncludedFile("test", "args", "vars", "task")
    assert included_file, "IncludedFile object not created"


# Generated at 2022-06-21 00:50:09.396361
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    a = IncludedFile("filename", "args", "vars", "task")
    assert a._filename == "filename"
    assert a._args == "args"
    assert a._vars == "vars"
    assert a._task == "task"
    assert a._hosts == []
    assert a._is_role == False


# Generated at 2022-06-21 00:50:16.986996
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    test_filename = "filename"
    test_args = ["args"]
    test_vars = {"vars": "value"}
    test_task = "task"
    inc_file = IncludedFile(test_filename, test_args, test_vars, test_task)
    assert inc_file._filename == test_filename
    assert inc_file._args == test_args
    assert inc_file._vars == test_vars
    assert inc_file._task == test_task
    assert inc_file._is_role == False

# Generated at 2022-06-21 00:50:20.667146
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile('test_filename', 'test_args', 'test_vars', 'test_task')

    assert repr(included_file) == "test_filename (args=test_args vars=test_vars): []"



# Generated at 2022-06-21 00:50:34.121318
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = 'test_filename'
    args = {'_uuid': '1'}
    vars = {'_uuid': '2'}
    action = 'include_tasks'
    test_task = Task()
    test_task._uuid = '2'
    test_task._parent = Task()
    test_task._parent._uuid = '1'

    # Test equality of objects with same attributes
    included_file_1 = IncludedFile(filename, args, vars, test_task)
    included_file_2 = IncludedFile(filename, args, vars, test_task)
    assert(included_file_1 == included_file_2)

    # Test inequality of objects with different attributes
    included_file_2._filename = 'not_test_filename'

# Generated at 2022-06-21 00:50:45.979719
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_result = [{
        "ansible_facts": {
            "discovered_interpreter_python": "/usr/bin/python"
        },
        "_ansible_item_label": "localhost",
        "changed": False,
        "include_args": {
            "c": "d",
            "a": "b"
        },
        "include": "abc",
    }]

    # class Iterator

# Generated at 2022-06-21 00:50:55.154817
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # test constructor
    inc_file1 = IncludedFile("file.yml", dict(), dict(), None)
    inc_file2 = IncludedFile("file.yml", dict(), dict(), None)

    # test __eq__
    if inc_file1 != inc_file2:
        raise Exception("__eq__ function failed to evaluate equal object")

    # test add_host
    inc_file1.add_host("host")
    if inc_file1 != inc_file2:
        raise Exception("__eq__ function failed to evaluate equal object")

    # test exception
    try:
        inc_file1.add_host("host")
        raise Exception("Expected exception not raised")
    except ValueError:
        pass

    # test __repr__

# Generated at 2022-06-21 00:51:08.902982
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class Task:
        def __init__(self, uuid):
            self._uuid = uuid

    class Parent:
        def __init__(self, uuid):
            self._uuid = uuid

    f1 = IncludedFile(
        filename='/tmp/main.yml',
        args={},
        vars={},
        task=Task(uuid='task_uuid')
    )
    f1._task._parent = Parent(uuid='parent_uuid')

    f2 = IncludedFile(
        filename='/tmp/main.yml',
        args={},
        vars={},
        task=Task(uuid='task_uuid')
    )
    f2._task._parent = Parent(uuid='parent_uuid')


# Generated at 2022-06-21 00:52:40.275717
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    '''
    C0111: Missing docstring: included_file.py:test_IncludedFile
    T0008: Function should have a "self" argument: included_file.py:test_IncludedFile
    T0008: Function should have a "self" argument: included_file.py:IncludedFile:__init__
    '''
    inc_file = IncludedFile("filename", "args", "vars", "task")

    assert inc_file._filename == 'filename'
    assert inc_file._args == 'args'
    assert inc_file._vars == 'vars'
    assert inc_file._task == 'task'
    assert inc_file._is_role == False
    assert inc_file._hosts == []
