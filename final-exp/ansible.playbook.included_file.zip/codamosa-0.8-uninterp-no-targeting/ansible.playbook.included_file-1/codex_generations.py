

# Generated at 2022-06-21 00:43:12.425201
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    import build_doc
    import task_include

    class TestClass:
        """Mock the TaskInclude object"""
        def __init__(self, value):
            self.value = value
        def __eq__(self, other):
            return other.value == self.value

    # IncludedFile(filename=str, args=dict, vars=dict, task=TaskInclude)
    filename = 'filename'
    args = {'arg_key': 'arg_value'}
    vars = {'var_key': 'var_value'}
    task = TestClass('task')
    obj = IncludedFile(filename, args, vars, task)

    assert obj.__eq__(obj)

    # test the case where TaskInclude are different
    args_copy = args.copy()
    vars_copy = vars

# Generated at 2022-06-21 00:43:14.590932
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # Construct an IncludedFile object
    includedFileTest = IncludedFile(None, None, None, None)
    assert includedFileTest is not None


# Generated at 2022-06-21 00:43:27.952522
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from ansible.playbook.task import Task
    from ansible.playbook.host import Host
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    t = Task()
    ti1 = TaskInclude()
    ti2 = TaskInclude()
    ir1 = IncludeRole()
    ir2 = IncludeRole()
    h1 = Host('h1')
    h2 = Host('h2')
    if1 = IncludedFile('test_file', 'test_args', 'test_vars', t)
    if2 = IncludedFile('test_file', 'test_args', 'test_vars', t)
    if3 = IncludedFile('test_file_2', 'test_args', 'test_vars', t)

# Generated at 2022-06-21 00:43:39.380648
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import os
    import tempfile
    test_dir = os.path.join(os.path.dirname(__file__), 'test_files')
    inv_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-21 00:43:50.377772
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult

    results = [
        TaskResult(
            host=dict(name='localhost'),
            task=dict(action='include_role', args=dict(name='foo')),
            result=dict(include='/home/myuser/foo/bar.yml')
            )
        ]
    Display.verbosity = 4
    included_files = IncludedFile.process_include_results(results, None, None, None)
    assert len(included_files) == 1
    assert included_files[0]._filename == '/home/myuser/foo/bar.yml'


# Generated at 2022-06-21 00:44:02.508380
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    # Needed for the function 'walk_down_play_block'
    from ansible.playbook.block import Block
    from ansible.utils.shlex import shlex_split
    import copy

    class FakeHost:
        def __init__(self, host):
            self._host = host

        def get_name(self):
            return self._host

    class FakeIterator:
        def __init__(self):
            pass

        def __init__(self, play):
            self._play = play

    class FakeTaskResult:
        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result


# Generated at 2022-06-21 00:44:09.298931
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
     tmpfile=file("test_include.yml",'w')
     tmpfile.write("tasks:\n- name: test_include.yml\n  debug:\n    msg: \"test_include.yml\"")
     tmpfile.close()
     returncode, out, err = ansible_module_run(["include: \"test_include.yml\""])
     print(returncode, out, err)
 
if __name__=="__main__":
    test_IncludedFile()

# Generated at 2022-06-21 00:44:14.478593
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert IncludedFile(1, 2, 3, 4).__eq__(IncludedFile(1, 2, 3, 4)) is True
    assert IncludedFile(1, 2, 3, 4).__eq__(IncludedFile(1, 2, 4, 4)) is False
    assert IncludedFile(1, 2, 3, 4).__eq__(IncludedFile(1, 2, 3, 5)) is False


# Generated at 2022-06-21 00:44:27.763240
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import sys
    import unittest

    sys.path.append('lib')
    from ansible.plugins import module_utils

    class FakeRunner(object):
        def __init__(self, included_files=None, task_vars=None):
            self.included_files = included_files if included_files is not None else []
            self.task_vars = task_vars if task_vars is not None else dict()

        def run(self, task, play_context, new_vars, iterator, iterator_vars, loader, templar, only_tags=None, role_vars=None, fork_vars=None, subset=None, task_uuid=None):
            res = FakeRunnerResult()

# Generated at 2022-06-21 00:44:39.989382
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import include_tasks_loader
    from ansible.plugins.loader import include_role_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from collections import namedtuple

    # Set up some data to be used as in variables
    hosts = ['host1', 'host2', 'host3']

# Generated at 2022-06-21 00:45:20.633552
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile(filename='/etc/passwd', args={'_raw_params': 'test_raw_params'},
                                 vars={'test': 'test'}, task=None)
    assert repr(included_file) == "/etc/passwd (args={'_raw_params': 'test_raw_params'} vars={'test': 'test'}): []"



# Generated at 2022-06-21 00:45:28.798185
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = '/some/file.yml'
    args = dict(foo='bar')
    vars = dict(baz='foo')
    task = None
    inc_file1 = IncludedFile(filename, args, vars, task)
    inc_file2 = IncludedFile(filename, args, vars, task)
    assert inc_file1 == inc_file2

# Generated at 2022-06-21 00:45:42.669793
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test all the conditions where the function __eq__, of class IncludedFile, should return True

    # 1. Condition where filenames, args and vars are equal, but task1's uuid is not equal to task2's uuid
    task1 = TaskInclude()
    task1._uuid = 'eliot'
    task2 = TaskInclude()
    task2._uuid = 'bishop'
    inc_file1 = IncludedFile('filename', {'arg' : 'arg'}, {'var' : 'var'}, task1)
    inc_file2 = IncludedFile('filename', {'arg' : 'arg'}, {'var' : 'var'}, task2)
    assert not inc_file1.__eq__(inc_file2)

    # 2. Condition where filenames, args and vars are equal, but task

# Generated at 2022-06-21 00:45:47.161686
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile(None, None, None, None)
    assert repr(included_file) == "None (args=None vars=None): []"

# Generated at 2022-06-21 00:45:48.951055
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    assert isinstance(IncludedFile('test/test.yml', {'a': 1, 'b': 2}, {'c': 3, 'd': 4}, 'test'), IncludedFile)

# Generated at 2022-06-21 00:45:57.458271
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = 'test_filename'
    args = {'a': 'b'}
    vars = {'x': 'y'}
    task = object()

    # Test with None and other types
    inc = IncludedFile(filename, args, vars, task)
    assert inc == inc
    assert inc != None
    assert inc != 1
    assert inc != 1.1

    # Test with equal IncludedFile instances
    inc2 = IncludedFile(filename, args, vars, task)
    assert inc == inc2

    # Test with different filename
    inc3 = IncludedFile('test_file', args, vars, task)
    assert inc != inc3

    # Test with different args
    inc4 = IncludedFile(filename, {'c': 'd'}, vars, task)
    assert inc != inc4

    # Test with different

# Generated at 2022-06-21 00:46:07.083105
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import ansible.playbook
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    task_action = "include_tasks"
    task_args = {"_raw_params": "../../myinclude.yml"}
    task_deps = []
    task_loop = None
    task_loop_args = None
    task_when = None
    task_register = None
    task_ignore_errors = False
    task_tags = None
    task_name = "this is the name of the task"

    task = Task()
    task._role = None
    task._block = None
    task.action = task_action
    task.args = task_args
    task.deps = task_deps
    task.loop

# Generated at 2022-06-21 00:46:17.808122
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    config = {}
    config['host_list'] = ['localhost']

    pl = Play()
    pl.vars = {}
    pl.tasks = []
    hs = Host(name='localhost')

    pl.hosts = [hs]
    t = Task()
    t.set_loader(DictDataLoader())
    t.action = 'debug'
    t.vars = {}
    t.args = {}

    # Create 2 different IncludedFile objects with different 'filename' attribute
    # The result should be False (they are not equal)
    if1 = IncludedFile('foo', {}, {}, pl)
    if2 = IncludedFile('foo1', {}, {}, pl)
    if if1 == if2:
        print('test_IncludedFile___eq__ failed!')
        return -1

    # Create 2 different

# Generated at 2022-06-21 00:46:23.310267
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    original_host = 'host'
    original_task = 'task'
    include_file = 'include_file'
    include_args = ['include_args']
    special_vars = ['special_vars']
    inc_file = IncludedFile(include_file, include_args, special_vars, original_task)
    inc_file.add_host(original_host)
    assert inc_file._hosts == [original_host]


# Generated at 2022-06-21 00:46:35.296746
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    print('class IncludedFile(object):')

    filename = 'myfile.yml'
    args = {'a': 1, 'b': 2}
    vars = {'var1': 'val1', 'var2': 'val2'}
    task = None
    result = IncludedFile(filename, args, vars, task)

    print('    def __init__(self, filename, args, vars, task):')
    print('        self._filename = filename')
    print('        self._args = args')
    print('        self._vars = vars')
    print('        self._task = task')
    print('        self._hosts = []\n')
    print('    def add_host(self, host):')
    print('        if host not in self._hosts:')

# Generated at 2022-06-21 00:47:06.913330
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = 'testfile'
    args = {'arg': 'test'}
    vars = {'var': 'test'}
    task = None
    is_role = False
    inc_file = IncludedFile(filename, args, vars, task, is_role)

    assert inc_file._filename == filename
    assert inc_file._args == args
    assert inc_file._vars == vars
    assert inc_file._task == task
    assert inc_file._is_role == is_role



# Generated at 2022-06-21 00:47:09.120198
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_file = IncludedFile('', {}, {}, None)
    included_file.add_host('localhost')
    try:
        included_file.add_host('localhost')
    except ValueError:
        pass
    else:
        raise RuntimeError('Expected ValueError exception.')


# Generated at 2022-06-21 00:47:15.275199
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    """
    Unit test for constructor of class IncludedFile
    """
    filename = '/etc/ansible/hosts'
    args = {'arg1': 'val1'}
    vars = {'var1': 'val1'}
    task = {'task1': 'val1'}
    is_role = False
    included_file = IncludedFile(filename, args, vars, task, is_role)
    assert included_file is not None
    assert included_file._filename == filename

# Generated at 2022-06-21 00:47:21.499475
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    incFile = IncludedFile("/tmp/test", {}, {}, None)
    incFile.add_host("host1")
    incFile.add_host("host2")
    assert len(incFile._hosts) == 2

    try:
        incFile.add_host("host1")
    except ValueError:
        pass
    else:
        assert False, "Should not be able to add host1 twice"
    assert len(incFile._hosts) == 2

# Generated at 2022-06-21 00:47:33.352239
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.playbook.task_include
    import ansible.playbook.helpers
    import ansible.inventory
    import ansible.vars.manager
    import ansible.template
    import ansible.parsing.dataloader

    class MockTaskResult(object):
        def __init__(self, host, task, result, loop=False):
            self._host = host
            self._task = task
            self._result = result
            self._task.loop = loop

    class MockTaskInclude(object):
        def __init__(self, action, args, no_log, parent):
            self._role = None
            self.action = action
            self._parent = parent

            self.args = {'_raw_params': args}
            self.no_log = no_log


# Generated at 2022-06-21 00:47:35.364235
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    generator = IncludedFile('filename', dict(), dict(), dict())
    assert IncludedFile('filename', dict(), dict(), dict()) == generator



# Generated at 2022-06-21 00:47:41.741178
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # test with the only argument
    args = None
    vars = None
    task = TaskInclude()
    filename = "/path/to/file"
    f = IncludedFile(filename, args, vars, task)
    result = f.__repr__()
    expected = '"/path/to/file (args=None vars=None): []"'
    assert repr(result) == repr(expected)
    return


# Generated at 2022-06-21 00:47:50.918158
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class dummyTask: pass
    class dummyHost: pass
    
    a = dummyTask()
    a._uuid = 'a'
    b = dummyTask()
    b._uuid = 'b'
    a._parent = b
    
    file = IncludedFile('/tmp/test_file', {'flag': True}, {'key': 'value'}, a)
    assert repr(file) == "/tmp/test_file (args={'flag': True} vars={'key': 'value'}): [None]"
    print(".")

# Generated at 2022-06-21 00:48:01.390415
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    class FakeHost():
        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return self.name == other.name

    host1 = FakeHost('host1')
    host2 = FakeHost('host2')
    args = {}
    vars = {}
    class FakeTask():
        def __init__(self):
            self.action = 'include'

    task = FakeTask()

    inc_file = IncludedFile('include_file', args, vars, task)
    inc_file.add_host(host1)
    inc_file.add_host(host2)

# Generated at 2022-06-21 00:48:13.343807
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Iterator:
        class Play:
            def __init__(self):
                self._basedir = os.path.realpath(os.curdir)

        def __init__(self):
            self._play = Iterator.Play()

    class Loader:
        def __init__(self):
            self._basedir = os.path.realpath(os.curdir)

        def path_dwim(self, include_file):
            return os.path.realpath(os.path.join(self._basedir, include_file))

        def get_basedir(self):
            return self._basedir

    class VariableManager:
        def __init__(self):
            self._hosts = dict()


# Generated at 2022-06-21 00:48:44.533673
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = "test_filename"
    args = {}
    vars = {}
    task = None
    is_role = False
    file = IncludedFile(filename, args, vars, task)

    host1 = "host1"
    file.add_host(host1)
    assert file._hosts[0] == host1
    host2 = "host2"
    try:
        file.add_host(host1)
    except ValueError:
        pass
    else:
        assert False, "ValueError should be raised due to adding a host that already exists"

# Generated at 2022-06-21 00:48:55.378655
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    ifile = IncludedFile('filename', {}, {}, None)
    ifile.add_host('hostA')
    ifile.add_host('hostB')
    ifile.add_host('hostC')

    ifile.add_host('hostA')
    ifile.add_host('hostB')
    ifile.add_host('hostC')

    ifile.add_host('hostA')
    ifile.add_host('hostB')
    ifile.add_host('hostC')

    ifile.add_host('hostA')
    ifile.add_host('hostB')
    ifile.add_host('hostC')


# Generated at 2022-06-21 00:49:06.086587
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = "/tmp/test1234.txt"
    args = {"arg1": 1, "arg2": 2}
    vars = {"var1": 1, "var2": 2}
    task = IncludedFile("/tmp/task1234.txt", {"arg1": 2}, {"var2": 2}, {}, is_role=True)
    included_file = IncludedFile(filename, args, vars, task)

    assert included_file.__repr__() == "%s (args=%s vars=%s): %s" % (filename, args, vars, [])


# Generated at 2022-06-21 00:49:09.415140
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    include_file = IncludedFile('/home/ansible/foo.yml',
                                ['one', 'two'],
                                {'one': 'three', 'four': 'five'},
                                'task')
    repr_include_file = repr(include_file)
    assert repr_include_file == "/home/ansible/foo.yml (args=['one', 'two'] vars={'one': 'three', 'four': 'five'}): []"

# Generated at 2022-06-21 00:49:14.062059
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile(filename = 'filename', args = 'args', vars = 'vars', task = 'task')
    assert included_file.__repr__() == "filename (args=args vars=vars): []"

# Generated at 2022-06-21 00:49:16.890717
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    first = IncludedFile("file1")
    second = IncludedFile("file1")
    assert first == second


# Generated at 2022-06-21 00:49:28.454868
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """
    Test method __eq__ of class IncludedFile
    """

    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    class MockTask(Task):
        def __init__(self, *args, **kwargs):
            self._play = Play()


    class MockPlay(Play):
        def __init__(self, *args, **kwargs):
            self.hosts = {}

    class MockRole(object):
        def __init__(self, path):
            self._role_path = path

    # Prepare mocks
    play = MockPlay()
    task = MockTask(play=play)
    task._role = MockRole("/")
    task._parent = MockTask(play=play)


# Generated at 2022-06-21 00:49:33.446718
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # unit test
    t = IncludedFile('/some/file.yml', {'a': 1, 'b': 2}, {'x': 'y'}, 'task')
    assert t._filename == '/some/file.yml'
    assert t._args == {'a': 1, 'b': 2}
    assert t._vars == {'x': 'y'}
    assert t._task == 'task'
    assert t._hosts == []

# Generated at 2022-06-21 00:49:45.579027
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Class TaskInclude is not mocked, we have to import it after all the monkey patching
    from ansible.playbook.task_include import TaskInclude

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,', 'otherhost,'])
    play1 = Play().load(dict(
        name="someplay",
        hosts=['somehost'],
        tasks=[dict(include='somefile'), dict(include='otherfile')],
    ), variable_manager=variable_manager, loader=loader)

    # Create two instances of IncludedFile

# Generated at 2022-06-21 00:49:54.813565
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    '''Unit test for method __repr__ of class IncludedFile'''
    basedir = os.getcwd()
    args = dict()
    vars = dict()
    task = dict()

    test_case = dict()
    test_case['filename'] = None
    test_case['args'] = None
    test_case['vars'] = None
    test_case['task'] = None

    included_file = IncludedFile(test_case['filename'], test_case['args'], test_case['vars'], test_case['task'])

    # expected_result
    expected_result = 'None (args=None vars=None): []'
    assert(str(included_file) == expected_result)

# Generated at 2022-06-21 00:51:11.999517
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    included_file = IncludedFile('roles/test/tasks/main.yml', None, None, TaskInclude('roles/test'))
    included_file_test = IncludedFile('roles/test/tasks/main.yml', None, None, TaskInclude('roles/test'))
    included_file_test2 = IncludedFile('roles/test2/tasks/main.yml', None, None, TaskInclude('roles/test2'))
    included_file_test3 = IncludedFile('roles/test/tasks/main.yml', {'somedict': True}, None, TaskInclude('roles/test'))

# Generated at 2022-06-21 00:51:14.884041
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    f = IncludedFile('filename', 'args', 'vars', 'task')
    if f.__repr__() is None:
        raise AssertionError()

# Generated at 2022-06-21 00:51:22.125097
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_executor import TaskResult
    from ansible.playbook import PlayContext
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    loader = DictDataLoader({})
    play = Play()
    play_context = PlayContext()
    task = Task()
    task.action = 'include'


# Generated at 2022-06-21 00:51:32.229569
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    import tempfile
    tfile = tempfile.NamedTemporaryFile()
    filename = tfile.name
    args = dict(a='b')
    vars = dict()
    task = dict(type='task')

    inc = IncludedFile(filename, args, vars, task)
    host1 = dict(name='test1')
    host2 = dict(name='test2')
    host3 = dict(name='test3')

    inc.add_host(host1)
    inc.add_host(host2)
    inc.add_host(host3)

    try:
        inc.add_host(host1)
    except ValueError:
        pass
    else:
        assert 1 == 2

    assert inc._hosts[0] == host1
    assert inc._hosts[1] == host2


# Generated at 2022-06-21 00:51:41.339485
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    host1 = MockHost("localhost")
    host2 = MockHost("other")
    #  IncludedFile(filename, args, vars, task, is_role=False)
    incfile = IncludedFile("/somefile.yml", {}, {}, None)
    incfile.add_host(host1)
    incfile.add_host(host2)
    resp = incfile.__repr__()
    assert resp == "/somefile.yml (args={} vars={}): [localhost, other]"
    #
    incfile = IncludedFile("/foo/bar.yml", {'this':'that'}, {'c':'d'}, None)
    incfile.add_host(host1)
    resp = incfile.__repr__()

# Generated at 2022-06-21 00:51:51.758411
# Unit test for constructor of class IncludedFile
def test_IncludedFile():

    filename = "/someplace/include.yml"
    args = "{{lookup('pipe','date')}}"
    vars = { "a": "b" }
    task = "include_file"
    is_role = False

    # Testing __init__
    inc_file = IncludedFile(filename, args, vars, task, is_role)
    assert inc_file._filename == filename
    assert inc_file._args == args
    assert inc_file._vars == vars
    assert inc_file._task == task
    assert inc_file._is_role == is_role
    assert inc_file._hosts == []

    # Testing add_host
    host = "hostname"
    inc_file.add_host(host)
    assert inc_file._hosts == [host]

    # Testing repr
   

# Generated at 2022-06-21 00:51:54.186056
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    a = IncludedFile('', '', '', '')
    b = IncludedFile('', '', '', '')
    a.add_host('a')
    a.add_host('b')
    a.add_host('a')
    b.add_host('a')
    b.add_host('b')
    b.add_host('a')

    assert a == b


# Generated at 2022-06-21 00:52:02.374487
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # Ensure variable 'IncludedFile._filename' is not empty
    inc_file_file_name = IncludedFile("file_name", "args", "vars", "task")
    assert inc_file_file_name._filename == "file_name"
    inc_file = IncludedFile("file_name", "args", "vars", "task")
    # Ensure variable 'IncludedFile._filename' is not empty
    assert inc_file._filename == "file_name"
    inc_file._hosts.append("host")
    assert inc_file.__repr__() == "file_name (args=args vars=vars): ['host']"

# Generated at 2022-06-21 00:52:08.838606
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    dummy_filename = '/my/path/to/file'
    dummy_args = {}
    dummy_vars = {}
    dummy_task = None
    dummy_is_role = False
    obj = IncludedFile(dummy_filename, dummy_args, dummy_vars, dummy_task, is_role=dummy_is_role)
    repr(obj)

# Generated at 2022-06-21 00:52:16.241465
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included_file = IncludedFile(__file__, args=dict(), vars=dict(), task=None)
    # Without adding host
    assert repr(included_file) == __file__ + " (args={} vars={}): []"
    included_file.add_host('localhost')
    # With adding host
    assert repr(included_file) == __file__ + " (args={} vars={}): ['localhost']"