

# Generated at 2022-06-21 00:43:16.758740
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Mimick the objects that would be passed to that method
    results = [
        {'_host': 'localhost', '_task': 'a task', '_result': {'include': 'included.yml'}},
        {'_host': 'localhost', '_task': 'a task', '_result': {'include': 'included.yml'}},
        {'_host': 'otherhost', '_task': 'a task', '_result': {'include': 'included.yml'}},
        {'_host': 'otherhost', '_task': 'a task', '_result': {'include': 'included.yml'}},
        {'_host': 'localhost', '_task': 'a task', '_result': {'include': 'included.yml'}}
    ]
   

# Generated at 2022-06-21 00:43:29.499778
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.playbook.block import Block

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader, module_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook

    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE

    import os
    import sys
    import unittest

# Generated at 2022-06-21 00:43:33.180736
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """ Test for method __eq__ of class IncludedFile """
    # Test for no exception
    try:
        IncludedFile.process_include_results(1, 1, 1, 1)
    except:
        assert False
    # Test for expected result
    # Not needed


# Generated at 2022-06-21 00:43:42.487819
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from copy import copy
    included_file = IncludedFile(None, None, None, None)
    test_host_01 = copy(included_file)
    test_host_02 = copy(included_file)
    included_file.add_host(test_host_01)
    included_file.add_host(test_host_02)
    try:
        included_file.add_host(test_host_01)
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 00:43:52.248730
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Initialize dependencies
    loader = DictDataLoader(dict())
    variable_manager = VariableManager()

    # Test the case where the include contains no loops

# Generated at 2022-06-21 00:44:03.996026
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-21 00:44:11.553123
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import ansible.playbook
    filename = 'anyfile'
    args = dict()
    vars = dict()
    task = ansible.playbook.Task()
    is_role = False
    anIncludedFile = IncludedFile(filename, args, vars, task, is_role)
    assert anIncludedFile._filename == filename
    assert anIncludedFile._args == args
    assert anIncludedFile._vars == vars
    assert anIncludedFile._task == task
    assert anIncludedFile._hosts == []
    assert anIncludedFile._is_role == is_role


# Generated at 2022-06-21 00:44:16.842193
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    infile = IncludedFile(1, 2, 3, {'var':'val'}, True)
    assert (infile._filename == 1 and
            infile._args == 2 and
            infile._vars == 3 and
            infile._hosts == [] and
            infile._is_role == True)


# Generated at 2022-06-21 00:44:27.993051
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    task = Task()
    task._parent = Play()
    task._parent._play_hosts = ['host1', 'host2']
    task._play = task._parent

    play_hosts = task._play._play_hosts
    filename = 'tests/playbooks/include_vars/vars.yml'
    args = {'a': 2}
    vars = {}
    idx = 0
    file1 = IncludedFile(filename, args, vars, task)
    file2 = IncludedFile(filename, args, vars, task)

    assert(file1 == file2)


# Generated at 2022-06-21 00:44:40.080494
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Ansible Options
    ansible_options_opt = {}
    ansible_options_opt['connection'] = 'ssh'
    ansible_options_opt['forks'] = 10
    ansible_options_opt['become_method'] = 'sudo'
    ansible_options_opt['module_path'] = '/tmp'
    ansible_options_opt['private_key_file'] = '/tmp/private_key'
    ansible_options_opt['remote_user'] = 'remote_user'
    ansible_options_opt['ssh_common_args'] = ' '
    ansible_options_opt['ssh_extra_args'] = '-o ForwardAgent=yes'
    ansible_options_opt['sftp_extra_args'] = ''

# Generated at 2022-06-21 00:44:54.696670
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    pass
    #this method is too difficult to test
    #please see tests/unit/test_include_vars.py


# Generated at 2022-06-21 00:45:01.950051
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class Object:
        def __init__(self, uuid) :
            self._uuid = uuid

    assert "testdata.yml (args={u'task': u'set_fact'} vars={u'ansible_search_path': [u'/home/ansible/playbook']}): ['localhost']" == \
           str(IncludedFile("testdata.yml", { "task": "set_fact" },
                            { "ansible_search_path": [ "/home/ansible/playbook" ] },
                            Object("TestData")))


# Generated at 2022-06-21 00:45:08.252241
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc = IncludedFile('filename', 'args', 'vars', 'task')
    inc.add_host('host1')
    inc.add_host('host2')
    inc.add_host('host3')
    with pytest.raises(ValueError):
        inc.add_host('host2')



# Generated at 2022-06-21 00:45:22.395415
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    class DummyTask:
        def __init__(self, task_name=None, task_path=None, task_action=None, _parent=None):
            self._parent = _parent
            self.name = task_name
            self.path = task_path
            self.action = task_action

        def get_search_path(self):
            return ['.']
        
        def __eq__(self, other):
            return (self.name == other.name) and (self.path == other.path) and (self.action == other.action)

        def __ne__(self, other):
            return not self.__eq__(other)
        
    #Test case no.1
    print(IncludedFile.__doc__)

# Generated at 2022-06-21 00:45:33.474182
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    # Create a mock object of class IncludedFile
    inc_file = IncludedFile(None, None, None, None)

    # Create also a mock object to be added to the hosts list
    class Host:
        name = 'test'

    first_host = Host()
    second_host = Host()

    # Add the hosts to the list, expect no ValueError to be raised
    inc_file.add_host(first_host)
    try:
        inc_file.add_host(second_host)
    except ValueError:
        assert False

    # Add again the first_host to the list, expect ValueError to be raised
    try:
        inc_file.add_host(first_host)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-21 00:45:44.435231
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    i1 = IncludedFile("/path/file1.yml", {}, {}, None)
    i2 = IncludedFile("/path/file1.yml", {}, {}, None)
    i3 = IncludedFile("/path/file2.yml", {}, {}, None)

    assert i1 == i2
    assert i1 != i3

    i1._args['name'] = 'role_name'
    assert i1 != i2
    i2._args['name'] = 'role_name'
    assert i1 == i2

    i1._args['private'] = True
    assert i1 != i2
    i2._args['private'] = True
    assert i1 == i2

    i1._vars = {'a': 'b'}
    assert i1 != i2
    i2._vars

# Generated at 2022-06-21 00:45:55.514482
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # In this unit test we only test the constructor logic
    # Other methods in IncludeFile are tested by test_include_tasks
    import ansible.playbook.play_context
    import ansible.playbook.task

    yml_content = """
- hosts: localhost
  gather_facts: False
  tasks:
  - name: include foo.yml
    include: foo.yml
"""
    tmp_path = ansible_module_utils.common.loader.write_file_to_tempfile(yml_content)
    with open(tmp_path) as f:
        yml_content = f.read()
        yml_content = yml_content.replace('\\', '\\\\')

        pc = ansible.playbook.play_context.PlayContext()
        loader = ansible.loader.DataLoader()


# Generated at 2022-06-21 00:46:06.032106
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    # Create an IncludedFile object
    filename = '/path/to/file'
    args = {'name': 'my_role_name'}
    vars = {}
    task = 'task'
    is_role = True
    inc_file_1 = IncludedFile(filename, args, vars, task, is_role)

    # Add a host to the object
    host = 'a_host'
    inc_file_1.add_host(host)

    # Check that the host was added
    assert(host in inc_file_1._hosts)

    # Try to add the host again. The function must thrown an exception
    try:
        inc_file_1.add_host(host)
    except ValueError:
        pass
    else:
        raise ValueError()

# Protected method process_include_results of

# Generated at 2022-06-21 00:46:17.337596
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
   class FakeHost:
       name = 'foo'
       def __init__(self, name):
           self.name = name

   class FakeResult:
       def __init__(self, host, task, result, loop_var, index_var, ansible_item_label, ansible_loop):
           if task.action == 'include':
               self._result = {'include_args': '', 'include': './tasks/bar.yaml', 'include_vars': ''}
           else:
               self._result = {'include_args': '', 'include': 'role:baz', 'include_vars': ''}

           self._host = host
           self._task = task
           self._result['ansible_loop_var'] = loop_var
           self._result['ansible_index_var'] = index_var

# Generated at 2022-06-21 00:46:27.756131
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import sys
    # Use the python 2.x or 3.x version of the class
    if sys.version_info[0] < 3:
        from ansible.playbook.include import IncludedFile
    else:
        from ansible.playbook.include import IncludedFile
    if1 = IncludedFile('file1', 'arg1', 'var1', object())
    if2 = IncludedFile('file1', 'arg1', 'var1', object())
    if3 = IncludedFile('file1', 'arg1', 'var1', object())
    if4 = IncludedFile('file1', 'arg1', 'var1', object())
    assert if1 == if2
    assert if1 == if3
    assert if1 == if4



# Generated at 2022-06-21 00:46:49.985438
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-21 00:46:54.729573
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    test_file = IncludedFile("/test/file.yml", {}, None, None)
    test_file.add_host("host1")
    test_file.add_host("host2")
    test_file.add_host("host1")


# Generated at 2022-06-21 00:47:06.365062
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    for i in range(5):
        print('part %d' % i)
        print('  begin')
        # Fake the autoloader to load followup include
        import ansible.plugins
        ansible.plugins.automodule.add_directory(os.path.join(os.path.dirname(__file__), '../ansible/plugins'))

        # Fake the connection
        import tempfile
        (fd, path) = tempfile.mkstemp()
        os.write(fd, b'$ cat %s | sudo tee %s' % (path, path))
        os.write(fd, b'\n')
        os.write(fd, b'1\n')
        os.write(fd, b'2\n')
        os.close(fd)

        # Fake the inventory

# Generated at 2022-06-21 00:47:16.824521
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.play

    filename = '/etc/ansible/playbook/a.yml'
    args = {'arg1': 'aaa'}
    vars = {'var1': 'vvv'}
    play = ansible.playbook.play.Play()
    block = ansible.playbook.block.Block(parent_block=play)
    task = ansible.playbook.task.Task()
    task.block = block
    included_file = IncludedFile(filename, args, vars, task)

    return included_file.__eq__(included_file)


# Generated at 2022-06-21 00:47:25.998109
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    host1 = Host('host1')
    block1 = Block()
    task1 = Task()
    task1._parent = block1
    task1._role = None
    variable_manager = VariableManager()

    included_file1 = IncludedFile('/tmp/my_include', {}, {}, task1)
    included_file2 = included_file1
    included_file3 = IncludedFile('/tmp/my_include', {}, {}, task1)
    included_file4 = IncludedFile('/tmp/my_include2', {}, {}, task1)

# Generated at 2022-06-21 00:47:33.147676
# Unit test for constructor of class IncludedFile
def test_IncludedFile():

    filename = '/test/foo'
    args = 'args'
    vars = 'vars'
    task = 'task'
    is_role = True
    included_file = IncludedFile(filename, args, vars, task, is_role)

    assert included_file._filename == filename
    assert included_file._args == args
    assert included_file._vars == vars
    assert included_file._task == task
    assert included_file._hosts == []
    assert included_file._is_role is True


# Generated at 2022-06-21 00:47:41.948253
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    file1 = IncludedFile(['test_arg'],
                         ['test_arg2'],
                         ['test_arg3'],
                         ['test_arg4'],
                         'test_arg5')
    file2 = IncludedFile(['test_arg'],
                         ['test_arg2'],
                         ['test_arg3'],
                         ['test_arg4'],
                         'test_arg5')
    file3 = IncludedFile(['test_arg2'],
                         ['test_arg2'],
                         ['test_arg3'],
                         ['test_arg4'],
                         'test_arg5')

    assert file1 == file2
    assert file1 != file3

# Generated at 2022-06-21 00:47:50.702320
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    obj1 = IncludedFile('filename.yml', {'a': 'b'}, {'c': 'd'}, None, True)
    obj2 = IncludedFile('filename.yml', {'a': 'b'}, {'c': 'd'}, None, True)
    obj3 = IncludedFile('filename.yml', {'a': 'b'}, {'c': 'd'}, None, False)
    print(obj1 == obj2)
    print(obj1 == obj3)


# Generated at 2022-06-21 00:47:51.560573
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-21 00:48:03.662973
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    # define tasks
    include = TaskInclude()
    include_role = IncludeRole()

    # define vars
    vars = {'omit': 'omit_token'}

    # define roles
    include_role._role_path = '/path/to/role'

    # include file1 with empty vars
    include_file1 = IncludedFile(filename='file1', args={'_raw_params': 'file1'}, vars=dict(), task=include)
   

# Generated at 2022-06-21 00:48:20.941215
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    inc_file = IncludedFile(filename="filename",args="args",vars="vars",task="task")
    assert inc_file.__repr__() == "filename (args=args vars=vars): []"


# Generated at 2022-06-21 00:48:34.382342
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from collections import namedtuple
    # Set up fake results
    Result = namedtuple('Result', '_host _task _result action')
    host = 'baz.example.com'
    task = namedtuple('Task', 'action loop')
    iterator = namedtuple('Iterator', '_play')
    loader = namedtuple('Loader', 'get_basedir path_dwim path_dwim_relative')
    loader.get_basedir.return_value = './control_dir'
    loader.path_dwim.return_value = './control_dir'
    loader.path_dwim_relative.return_value = './control_dir'
    variable_manager = namedtuple('VariableManager', 'get_vars')
    variable_manager.get_vars.return_value = {}
   

# Generated at 2022-06-21 00:48:44.533278
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test when two IncludedFiles are the same
    ifile0 = IncludedFile("filename", "args", "vars", "task", is_role=False)
    ifile1 = IncludedFile("filename", "args", "vars", "task", is_role=False)
    assert(ifile0 == ifile1)
    # Test when two IncludedFiles are different
    ifile0 = IncludedFile("filename", "args", "vars", "task", is_role=False)
    ifile1 = IncludedFile("filename2", "args2", "vars2", "task2", is_role=False)
    assert(ifile0 != ifile1)


# Generated at 2022-06-21 00:48:50.133774
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook import Play
    from ansible.playbook.task import Task

    # Create an "include" task with an "include_results" that
    # contains the same "include_results" as the "include_results" of the
    # "include" task from scenario of the use case
    task_include = Task()
    task_include._uuid = '6'
    task_include.action = 'include'
    task_include.loop = 'results'
    task_include._role = None
    task_include._role_name = None
    task_include._parent = Task()
    task_include._parent._uuid = '5'
    task_include._parent._role = None
    task_include._parent._parent = None

    # Scenario
    # "include_results" contains the same "include_results

# Generated at 2022-06-21 00:48:57.168467
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'file'
    args = dict(a=1,b=2)
    vars = dict(x=3,y=4)
    task = dict()
    ifile = IncludedFile(filename, args, vars, task)
    print(ifile)
    if 'file (args={\'a\': 1, \'b\': 2} vars={\'x\': 3, \'y\': 4}): []' != str(ifile):
        raise AssertionError



# Generated at 2022-06-21 00:49:08.173404
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Generate inputs
    vars = {'name': 'testing'}
    results = []
    for i in range(3):
        r = MockTaskResult()
        r._task = MockTask()
        r._task._uuid = i + 1
        r._task._parent = MockPlay()
        r._task._parent._uuid = i + 10
        r._task._action = 'include_tasks'
        r._result = {'include': 'test-include.yml', 'include_args': vars}
        r._host = MockHost(i)
        results.append(r)
    results.append(results[0])

    # Create test instance
    i = IncludedFile(None, None, None, None)

    # Process inputs and make assertations

# Generated at 2022-06-21 00:49:21.190525
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-21 00:49:31.893604
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    import ansible.inventory.host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    # Prepare data

# Generated at 2022-06-21 00:49:37.084019
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    task = None
    inc_file = IncludedFile('filename', dict(), dict(), task)
    assert 'filename (args={} vars={}): []' == inc_file.__repr__()

# Generated at 2022-06-21 00:49:44.088949
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    included_file = IncludedFile("testFile", "testArgs", "testVars", "testTask")
    assert included_file._filename == "testFile"
    assert included_file._args == "testArgs"
    assert included_file._vars == "testVars"
    assert included_file._task == "testTask"
    assert included_file._hosts == []
    assert included_file._is_role == False



# Generated at 2022-06-21 00:50:24.735788
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename="test.yml"
    args={}
    vars={}
    task="test.yml"
    is_role=False
    instance = IncludedFile(filename, args, vars, task, is_role)
    assert repr(instance) == "test.yml (args={} vars={}): []"

# Generated at 2022-06-21 00:50:35.340643
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # Test template
    filename = 'test_filename'
    args = 'test_args'
    vars = 'test_vars'
    task = 'test_task'
    included_file = IncludedFile(filename, args, vars, task)
    assert repr(included_file) == "%s (args=%s vars=%s): %s" % (filename, args, vars, [])
    # Test with valid host
    host = 'test_host'
    assert included_file.add_host(host) == None
    assert repr(included_file) == "%s (args=%s vars=%s): %s" % (filename, args, vars, [host])
    # Test with existing host
    with pytest.raises(ValueError):
        included_file.add_host(host)

# Generated at 2022-06-21 00:50:39.309316
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    inc = IncludedFile("/tmp/t.txt", dict(), dict(), dict())
    assert(isinstance(inc, IncludedFile))


# Generated at 2022-06-21 00:50:42.546684
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # Test the __init__ method
    inc_file = IncludedFile("filename.yml", "args", "vars", "task")
    assert inc_file


# Generated at 2022-06-21 00:50:47.334593
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class FakeTask(object):
        def __init__(self, uuid, parent):
            self._uuid = uuid
            self._parent = parent
    filename = "./test"
    args = "args"
    vars = "vars"
    task = FakeTask("uuid", "parent")
    inc_file = IncludedFile(filename, args, vars, task)
    assert repr(inc_file) == "./test (args=args vars=vars): []"



# Generated at 2022-06-21 00:50:56.843236
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars


# Generated at 2022-06-21 00:51:01.111033
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    #Method test_IncludedFile___repr__ of class IncludedFile is tested with test_IncludedFile.test__repr__
    pass


# Generated at 2022-06-21 00:51:11.407697
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import mock
    import __main__ as main
    main.ANSIBLE_LIBRARY = ''
    main.ANSIBLE_MODULE_UTILS = ''
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()
    loader = mock.MagicMock()
    loader.get_basedir.return_value = '/path/to/basedir'
    loader.path_dwim.return_value = '/path/to/include/file'

# Generated at 2022-06-21 00:51:18.868167
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook import Play, Playbook, Task
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    play = Play().load(dict(
        name='test_play',
        hosts=['127.0.0.1'],
        gather_facts='no',
        tasks=[dict(
            include='bla',
            loop='{{ test_loop }}',
        )],
    ), variable_manager=variable_manager, loader=loader)

    playbook = Playbook()
    playbook._entries = [play]


# Generated at 2022-06-21 00:51:30.934279
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    unit tests for IncludedFile, for method process_include_results
    """
    ji = None
    je = None
    js = None

    res1 = None
    res2 = None
    res3 = None
    it = None
    loader = None
    var_mgr = None
    results = None
    included_files = None

    ji = '{{ inventory_hostname }}'
    je = '{{ groups["all"] }}'
    js = '{{ ansible_python_version }}'

    res1 = type('', (), {'_host': ji, '_task': type('', (), {'action': 'include', 'loop': True, '_parent': je, 'get_search_path': type('', (), {'return_value': js})})})()

# Generated at 2022-06-21 00:52:36.880103
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    included = IncludedFile('/tmp/a', {}, {}, None)
    included.add_host('localhost')
    included.add_host('127.0.0.1')
    assert repr(included) == "/tmp/a (args={} vars={}): ['localhost', '127.0.0.1']"

