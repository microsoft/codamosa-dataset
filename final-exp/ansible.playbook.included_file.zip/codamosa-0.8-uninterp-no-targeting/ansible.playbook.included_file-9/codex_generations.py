

# Generated at 2022-06-21 00:43:18.060182
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Note: it is not easy to cover the whole method with a test because of
    # the intense use of global variables, classes, etc.
    # Tested here: adding hosts as long as only one is added each time.
    # The rest of the method is not executed because the first included file
    # is equal to the rest.
    # Besides, the main purpose of the method is to collect included files
    # in different tasks and variables, so this is the minimum coverage
    # needed

    class Host:
        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return self.name == other.name

    class Task:
        def __init__(self, action, loop=False, role=None, parent=None, no_log=False):
            self.action = action
            self

# Generated at 2022-06-21 00:43:26.933228
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict

    play_context = ImmutableDict()
    play_context.network_os = 'junos'
    loader = None
    variable_manager = VariableManager()

    class Play:
        pass
    play = Play()
    play.vars = dict()
    play.basedir = '/tmp'

    class Host:
        def __init__(self, name):
            self.name = name
            self.vars = {'omit': ''}


# Generated at 2022-06-21 00:43:39.302954
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile('/path/to/file.yml', dict(a=1), dict(b=2), None)
    b = IncludedFile('/path/to/file.yml', dict(a=1), dict(b=2), None)
    assert a == b

    c = IncludedFile('/path/to/file.yml', dict(a=1, c=3), dict(b=2), None)
    assert a != c
    c = IncludedFile('/path/to/file.yml', dict(a=1), dict(b=2, d=4), None)
    assert a != c
    c = IncludedFile('/path/to/file.yml', dict(a=1), dict(b=2), None, is_role=True)
    assert a != c

# Generated at 2022-06-21 00:43:50.243141
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Setup for test
    incfile1 = IncludedFile(filename="abc", args=["a1","a2","a3"], vars={"1":"2"}, task=["t1","t2","t3"], is_role=False)
    incfile2 = IncludedFile(filename="abc", args=["a1","a2","a3"], vars={"1":"2"}, task=["t1","t2","t3"], is_role=False)
    incfile3 = IncludedFile(filename="def", args=["a1","a2","a3"], vars={"1":"2"}, task=["t1","t2","t3"], is_role=False)

# Generated at 2022-06-21 00:43:55.181312
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # We need to do something for testing
    pass

# vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4

# Generated at 2022-06-21 00:44:05.953144
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    obj = IncludedFile(None, {}, {}, None)

    # This should not raise any error and return empty list
    # We do not know the size of the list at this point and hence use the
    # generic container [], and not any specific type like list, set etc.
    assert [] == obj._hosts

    # This should not raise any error and return [host]
    assert obj.add_host('host')
    assert ['host'] == obj._hosts

    try:
        obj.add_host('host')
    except ValueError:
        # This is expected, so swallow exception and continue
        pass
    else:
        assert 1 == 2, "This should not be happening"

    # If a host different from the existing one is passed, then the
    # list is updated, and no exception is raised

# Generated at 2022-06-21 00:44:16.240052
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from ansible.executor.task_executor import TaskResult
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.included_file import IncludedFile
    filename = "example.yml"
    args = {'myarg': "val1"}
    vars = {'myvar': "val2"}
    task = Task.load(dict(action=dict(module="some_module")))
    host = "host1"
    res = TaskResult(host=host, task=task, return_data=dict(include="some_data"))
    inc = IncludedFile(filename, args, vars, task)
    assert [host] == inc.add_host(host)

# Generated at 2022-06-21 00:44:28.507738
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader

    class FakeModuleLoader(object):
        def get_all_plugin_loaders(self):
            return {}
    module_loader.PluginLoader = FakeModuleLoader
    module_loader.module_utils_loader = FakeModuleLoader

    FakeModuleLoader.get_all_plugin_loaders = lambda self: dict(
        shell=FakeModuleLoader(),
        copy=FakeModuleLoader(),
        command=FakeModuleLoader(),
        the_rest=FakeModuleLoader()
    )

    class FakeActionPlugin(object):
        def __init__(self, name):
            self.name = name
    action_loader.ActionModuleLoader = lambda name: FakeActionPlugin(name)


# Generated at 2022-06-21 00:44:35.846592
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import StringIO
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-21 00:44:39.333758
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    x = IncludedFile('/path/to/file', dict(), dict(), dict())
    assert x


# Generated at 2022-06-21 00:45:01.982718
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext
    filename = 'filename.yml'
    args= {}
    task = TaskInclude(Task(), PlayContext(), filename, args)
    vars = VariableManager()
    vars.set_commandline_args(['a=b'])
    idx = 0

# Generated at 2022-06-21 00:45:10.010834
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    display = Display()
    play = Play.load(unfrackpath('test/playbooks/include_play.yml'), variable_manager=VariableManager(), loader=False)
    blocks = play.compile()
    task = play.compile()[0].block[0]._get_task_by_path('included_task.yml')
    task.args = {'_raw_params': 'included_task.yml'}


# Generated at 2022-06-21 00:45:15.459901
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert IncludedFile('/path/to/file1', {}, {}, None) == IncludedFile('/path/to/file1', {}, {}, None)
    assert IncludedFile('/path/to/file1', {'name': 'tag1'}, {}, None) == IncludedFile('/path/to/file1', {'name': 'tag1'}, {}, None)
    assert IncludedFile('/path/to/file2', {'name': 'tag2'}, {}, None) == IncludedFile('/path/to/file2', {'name': 'tag2'}, {}, None)
    assert IncludedFile('/path/to/file1', {}, {'var1': 'val1'}, None) == IncludedFile('/path/to/file1', {}, {'var1': 'val1'}, None)
    assert Included

# Generated at 2022-06-21 00:45:25.617296
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import tempfile
    filename = tempfile.mkstemp()
    args = {'b': 'b'}
    vars = {'c': 'c'}
    task = 'd'

    # test whether the object is successfully created.
    inc_file1 = IncludedFile(filename, args, vars, task)
    assert inc_file1._filename == filename
    assert inc_file1._args == args
    assert inc_file1._vars == vars
    assert inc_file1._task == task
    assert inc_file1._hosts == []

    # test whether this object is equal to another one
    inc_file2 = IncludedFile(filename, args, vars, task)
    assert inc_file1 == inc_file2

    # test whether add_host() works

# Generated at 2022-06-21 00:45:35.090129
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['./hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 00:45:36.061783
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

#        IncludedFile.process_include_results(...)
    return

# Generated at 2022-06-21 00:45:44.031081
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file1 = IncludedFile("filename1", "args", "vars", "task")
    inc_file2 = IncludedFile("filename1", "args", "vars", "task")

    inc_file1.add_host("host")
    try:
        inc_file1.add_host("host")
        assert(False)
    except ValueError:
        assert(True)

    inc_file2.add_host("host2")
    try:
        inc_file2.add_host("host2")
        assert(False)
    except ValueError:
        assert(True)


# Generated at 2022-06-21 00:45:51.264962
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = '/home/file'
    args = 'args'
    vars = 'vars'
    task = 'task_ob'
    inc_file = IncludedFile(filename, args, vars, task)
    assert repr(inc_file) == "%s (args=%s vars=%s): []" % (filename, args, vars)



# Generated at 2022-06-21 00:46:04.183259
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # __eq__ does not do type checking, but both objects to compare should be of class IncludedFile
    # Create two IncludedFile objects
    filename = "/path/to/file.yml"
    args = dict()
    vars = dict()

    task = object() # Any object can be used here
    is_role = False

    first = IncludedFile(filename, args, vars, task, is_role)
    second = IncludedFile(filename, args, vars, task, is_role)

    # If the two objects are the same, __eq__ should return True
    assert first == second

    # If any of the arguments used to create the IncludedFile objects differs, __eq__ should return False
    # Exceed the maximum number of arguments
    third = IncludedFile(filename, args, vars, task, is_role, object()) # Any object can

# Generated at 2022-06-21 00:46:13.081996
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = 'test_filename'
    args = {'test_arg': 'test_value'}
    vars = {'test_var': 'test_value'}
    test_IncludedFile = IncludedFile(filename, args, vars, None)
    assert test_IncludedFile._filename == filename
    assert test_IncludedFile._args == args
    assert test_IncludedFile._vars == vars
    assert test_IncludedFile._task == None

# Generated at 2022-06-21 00:46:46.218932
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook.task import Task

    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext

    from ansible.vars.manager import VariableManager

    my_play = Base()
    my_play_context = PlayContext()
    my_play_context.prompt = None
    my_play_context.become = None
    my_play_context.become_method = None
    my_play_context.become_user = None
    my_play._context = my_play_context

    my_task = Task()
    my_task._parent = my_task
    my_task._role = None
    my_task._play = my_play
    my_task._loader = None

    variable_manager = VariableManager()
    variable_manager._fact

# Generated at 2022-06-21 00:46:52.592279
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile('filename', args='args', vars='vars', task='task')
    inc_file.add_host('host1')
    inc_file.add_host('host2')
    assert inc_file._hosts == ['host1', 'host2']


# Generated at 2022-06-21 00:47:01.033051
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    display.deprecated('This is a pytest test/mock for a deprecated feature. Do not use this.', '2.16')
    # Test that should return True
    task1 = type('', (object,), {'_uuid': '1'})
    task2 = type('', (object,), {'_uuid': '1', '_parent': {'_uuid': '2'}})
    included_file1 = IncludedFile(filename="foo", args=["bar"], vars={"baz": "baz"}, task=task2)
    included_file2 = IncludedFile(filename="foo", args=["bar"], vars={"baz": "baz"}, task=task1)
    assert included_file1 == included_file2

    # Test that should return False

# Generated at 2022-06-21 00:47:15.035926
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    i1 = IncludedFile("/var/tmp/ansible.cfg", {"force": True}, {"var1": "value1"}, object)
    i2 = IncludedFile("/var/tmp/ansible.cfg", {"force": True}, {"var1": "value1"}, object)
    i3 = IncludedFile("/var/tmp/ansible.cfg", {"force": False}, {"var1": "value1"}, object)
    i4 = IncludedFile("/etc/ansible/ansible.cfg", {"force": True}, {"var1": "value1"}, object)
    i5 = IncludedFile("/var/tmp/ansible.cfg", {"force": True}, {"var1": "value2"}, object)
    i6 = IncludedFile("/var/tmp/ansible.cfg", {"force": True}, {"var2": "value1"}, object)


# Generated at 2022-06-21 00:47:24.969037
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    class Host:
        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return self.name

        def __eq__(self, other):
            if other is None:
                return False
            return self.name == other.name

    class Task:
        def __init__(self, name, uuid):
            self.name = name
            self._uuid = uuid

        def __eq__(self, other):
            if other is None:
                return False
            return self._uuid == other._uuid

    class Playbook:
        def __init__(self, hosts):
            self.hosts = hosts

    h1 = Host("host1")
    h2 = Host("host2")
    h3 = Host("host3")


# Generated at 2022-06-21 00:47:29.326270
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    print("\ntest_IncludedFile___repr___0")
    results = []
    inc_file = IncludedFile("filename", "args", "vars", "task")
    results.append(inc_file)
    print(inc_file)


# Generated at 2022-06-21 00:47:35.503156
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    if1 = IncludedFile("test1", "test2", "test3", "test4")
    if2 = IncludedFile("test5", "test6", "test7", "test8")
    assert if1.__repr__() == "test1 (args=test2 vars=test3): []"
    assert if2.__repr__() == "test5 (args=test6 vars=test7): []"
    assert if1.__repr__() != if2.__repr__()

# Generated at 2022-06-21 00:47:45.220276
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class DummyTask:
        def __init__(self, uuid, parent_uuid):
            self._uuid = uuid
            self._parent = _DummyParent(parent_uuid)

        def copy(self):
            return DummyTask(self._uuid, self._parent._uuid)

    class _DummyParent:
        def __init__(self, uuid):
            self._uuid = uuid

    inc_file1 = IncludedFile('filename', 'args', 'vars', DummyTask('uuid', 'parent_uuid'))
    inc_file2 = IncludedFile('filename', 'args', 'vars', DummyTask('uuid', 'parent_uuid'))

# Generated at 2022-06-21 00:47:47.892583
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile("../tasks/include_file_a.yml", dict(a=1), dict(b=2), None)
    inc_file.add_host("host1")
    inc_file.add_host("host1")


# Generated at 2022-06-21 00:47:51.591672
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    print ("Unit test for constructor of class IncludedFile")
    try:
        IncludedFile("filename", "args", "vars", "task", True)
    except Exception:
        assert False, "Error, constructor of class IncludedFile failed"
    else:
        pass

# Generated at 2022-06-21 00:48:40.898646
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    result = IncludedFile('filename', 'args', 'vars', 'task')
    result.add_host('host')
    assert str(result) == "filename (args=args vars=vars): ['host']"


# Generated at 2022-06-21 00:48:42.054255
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-21 00:48:45.935364
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    obj = IncludedFile('fake_file', {}, {}, {}, True)

    obj.add_host('fake_host')


# Generated at 2022-06-21 00:48:58.249606
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    input_array = [
        # filename, args, vars, task, is_role=False, hosts
        ('filename',{'a': 'A'}, {'v': 'V'}, 'task', 'is_role=False', ['host']),
        ('filename',{'a': 'A'}, {'v': 'V'}, 'task', 'is_role=False', ['host']),
    ]
    inc_file = None
    for (filename, args, vars, task, is_role, hosts) in input_array:
        if inc_file is None:
            inc_file = IncludedFile(filename, args, vars, task, is_role)
        else:
            inc_file = IncludedFile(filename, args, vars, task, is_role)

# Generated at 2022-06-21 00:49:09.242406
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-21 00:49:13.870101
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    try:
        # Instanciation of IncludedFile must be excutable without error
        IncludedFile("/tmp/ansible_file", {}, {}, "")
    except:
        # Test fail
        raise
    else:
        # Test ok
        pass

# Generated at 2022-06-21 00:49:20.733681
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc = IncludedFile("file.txt", None, None, None)
    inc.add_host("host1")
    inc.add_host("host2")

    assert inc._hosts == ["host1", "host2"]
    try:
        inc.add_host("host1")
    except ValueError as e:
        assert e
    else:
        raise Exception("ValueError was not raised")



# Generated at 2022-06-21 00:49:31.571903
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    inc_file1 = IncludedFile('/tmp/t1', "t1.yaml", {}, None)
    inc_file2 = IncludedFile('/tmp/t1', "t1.yaml", {}, None)
    assert inc_file1 == inc_file2
    inc_file2._filename = "/tmp/t2"
    assert inc_file1 != inc_file2
    inc_file2._filename = "/tmp/t1"
    assert inc_file1 == inc_file2
    inc_file2._args = "t2.yaml"
    assert inc_file1 != inc_file2
    inc_file2._args = "t1.yaml"
    assert inc_file1 == inc_file2
    inc_file2._vars["var"] = "value"

# Generated at 2022-06-21 00:49:41.190320
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'test.yaml'
    args = {'name': 'test'}
    vars = {'test': 'test'}
    task = 'task'

    included_file = IncludedFile(filename, args, vars, task)
    assert str(included_file) == 'test.yaml (args={u\'name\': u\'test\'} vars={u\'test\': u\'test\'}): []'



# Generated at 2022-06-21 00:49:42.902704
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO: Generate some test data for method process_include_results of class IncludedFile here
    pass

# Generated at 2022-06-21 00:51:41.716240
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    p = PlayContext()
    loader = DataLoader()
    task = Task()
    task.context = p
    task.action = 'include'
    task.args = dict(file='/test_playbook.tasks')
    task.loader = loader

    f = IncludedFile(filename='/test_playbook.tasks', args={'tags': ['all']}, vars={}, task=task)

    assert isinstance(f, IncludedFile)


# Generated at 2022-06-21 00:51:49.604808
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    includedfile = IncludedFile('file', None, None, None)
    assert len(includedfile._hosts) == 0
    includedfile.add_host('host1')
    assert len(includedfile._hosts) == 1
    assert 'host1' in includedfile._hosts
    includedfile.add_host('host2')
    assert len(includedfile._hosts) == 2
    assert 'host1' in includedfile._hosts
    assert 'host2' in includedfile._hosts


# Generated at 2022-06-21 00:51:58.875800
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_file = IncludedFile("file.yml", {}, {}, None)

    assert included_file._hosts == []

    included_file.add_host("host1")
    assert included_file._hosts == ["host1"]

    included_file.add_host("host1")
    assert included_file._hosts == ["host1"]

    included_file.add_host("host2")
    assert included_file._hosts == ["host1", "host2"]



# Generated at 2022-06-21 00:52:09.356738
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    """ Test IncludedFile._add_host method """

    # Instantiate the object
    inc = IncludedFile(None, None, None, None)

    # Add a valid host
    host = "127.0.0.1"
    inc.add_host(host)
    assert inc._hosts[0] == host

    # Add the same host again
    try:
        inc.add_host(host)
    except ValueError:
        pass
    else:
        # should not reach this point
        raise ValueError("IncludedFile should not have added the host twice")



# Generated at 2022-06-21 00:52:18.907522
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    test_dir = os.path.dirname(__file__)
    test_data_dir = os.path.join(test_dir, '../data')
    test_file = os.path.join(test_data_dir, 'plays/include/tasks.yml')

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

    variable_manager._extra_vars = dict(foo='bar')

    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 00:52:30.547738
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars import VariableManager

    from collections import namedtuple

    from ansible.utils.sentinel import Sentinel

    # Set up required objects for the test
    # We create a task with a TaskInclude as a parent
    # The TaskInclude has a loop, which yields two results
    # Each result yields two include statements, which we
    # want to check if they are processed properly
    display.verbosity = 4
    play = Play()

# Generated at 2022-06-21 00:52:38.087630
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import os
    import uuid
    # get current location of the test file
    current_dir = os.path.dirname(os.path.abspath(__file__))
    task = IncludedFile(current_dir, {'A': 1}, {'A': 1}, uuid.uuid1(), True)
    task.add_host('localhost')
    task.add_host('127.0.0.1')
    task.add_host('127.0.0.1')
    task.add_host('0.0.0.0')

# Generated at 2022-06-21 00:52:47.511423
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    a = IncludedFile(1, 2, 3, 4, 5)
    assert a._filename == 1
    assert a._args == 2
    assert a._vars == 3
    assert a._task == 4
    assert a._hosts == []
    assert a._is_role == 5
    try:
        a.add_host(1)
        a.add_host(2)
        assert a._hosts == [1, 2]
        a.add_host(1)
    except:
        pass
    else:
        assert False
