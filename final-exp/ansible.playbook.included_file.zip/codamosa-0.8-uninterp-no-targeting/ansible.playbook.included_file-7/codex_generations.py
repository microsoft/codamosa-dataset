

# Generated at 2022-06-21 00:43:11.361982
# Unit test for constructor of class IncludedFile

# Generated at 2022-06-21 00:43:14.503218
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    includeFile = IncludedFile("filename", "args", "vars", "task")
    assert includeFile._filename == "filename"
    assert includeFile._args == "args"
    assert includeFile._vars == "vars"
    assert includeFile._task == "task"

# Generated at 2022-06-21 00:43:19.539037
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    _filename = "test"
    _args = "args"
    _vars = "vars"
    _task = "task"
    assert not IncludedFile(_filename, _args, _vars, _task)

# Generated at 2022-06-21 00:43:25.588771
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    '''
    file = IncludedFile(filename, args, vars, task)

    For example:
    file = IncludedFile(  '/home/vagrant/ansible/myfile.py',
                          'args',
                          'vars',
                          'task')

    '''


# Generated at 2022-06-21 00:43:38.573394
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # test 1
    assert IncludedFile('f1', None, None, None) == IncludedFile('f1', None, None, None) is True

    # test 2
    assert IncludedFile('f1', 'a1', None, None) == IncludedFile('f1', 'a1', None, None) is True

    # test 3
    assert IncludedFile('f1', 'a1', 'v1', None) == IncludedFile('f1', 'a1', 'v1', None) is True

    # test 4
    assert IncludedFile('f1', 'a1', 'v1', None) == IncludedFile('f1', 'a1', 'v1', None) is True

    # test 5

# Generated at 2022-06-21 00:43:49.109780
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    # data for test
    filename_1 = 'playbooks/test.yml'
    filename_2 = 'playbooks/test2.yml'

# Generated at 2022-06-21 00:43:56.203965
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class FakeResult:
        def __init__(self, _host, _task, _result):
            self._host = _host
            self._task = _task
            self._result = _result

    class FakeTask:
        def __init__(self):
            self.action = "include_tasks"
            self.loop = True
            self.no_log = True
            self.FROM_ARGS = ["role_from", "from"]
            self._role_name = None

# Generated at 2022-06-21 00:44:06.687155
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import unittest
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.variable_manager import VariableManager

    loader = None

    class FakeIter(object):
        def __init__(self):
            self.play = Play()
            self.play._context = PlayContext()
            self.play._context._included_files = []
        def __getattr__(self, attr):
            if self.play._context is not None:
                return getattr(self.play._context, attr)
            else:
                raise AttributeError()

    class FakeRole(object):
        def __init__(self, name):
            self._

# Generated at 2022-06-21 00:44:08.765054
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    assert(IncludedFile("filename", {}, {}, None) == IncludedFile("filename", {}, {}, None))



# Generated at 2022-06-21 00:44:18.289266
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # test 1
    filename = "test_filename.py"
    args = '{"key":"value"}'
    vars = '{"key":"value"}'
    class Task:
        _uuid = "uuid"
        _parent = "uuid"
        _role = None
    task = Task()
    test_obj = IncludedFile(filename, args, vars, task)
    assert (test_obj._filename == filename)
    assert (test_obj._args == args)
    assert (test_obj._vars == vars)
    assert (test_obj._task._uuid == task._uuid)
    assert (test_obj._task._parent._uuid == task._parent._uuid)

# Generated at 2022-06-21 00:44:48.769621
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    filename = "filename"
    args = "args"
    vars = "vars"
    task = "task"
    incFile = IncludedFile(filename, args, vars, task)
    assert incFile._filename == filename
    assert incFile._args == args
    assert incFile._vars == vars
    assert incFile._task == task
    assert incFile._hosts == []
    assert incFile._is_role == False



# Generated at 2022-06-21 00:45:01.014561
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-21 00:45:07.812618
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'filename1'
    args = 'args'
    vars = 'vars'
    task = 'task'
    IncludedFile1 = IncludedFile(filename, args, vars, task)
    assert 'filename1 (args=args vars=vars): []' == IncludedFile1.__repr__()


# Generated at 2022-06-21 00:45:21.799270
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    from ansible.playbook.task import Task

    test_task = Task()
    test_task._role = None
    t1 = IncludedFile("test_file", {'test_key': 'test_value'}, {'test_var': 'test_value'}, test_task)
    assert t1._filename == "test_file", "filename should be set to test_file"
    assert t1._args.get('test_key') == 'test_value', "args should be set to {'test_key': 'test_value'}"
    assert t1._vars.get('test_var') == 'test_value', "vars should be set to {'test_var': 'test_value'}"
    assert t1._task == test_task, "task should be set to test_task"
    assert t1._hosts

# Generated at 2022-06-21 00:45:29.079289
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    try:
        IncludedFile('file.yml', 'args', 'vars', 'task').add_host('host1')
        IncludedFile('file.yml', 'args', 'vars', 'task').add_host('host1')
        assert False, 'Should have failed'
    except ValueError:
        pass


# Generated at 2022-06-21 00:45:42.862936
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = "file"
    args = {"one": "two"}
    vars = {"one": "two", "three": "four"}
    uuid_task = "e55e4c8a-4c4a-4d1b-b656-8cee7c2a0b57"
    uuid_parent = "7d0c4d07-d65d-4a8e-8c23-a5f5c5d5b841"
    task = TaskInclude.load({"include": "blah", "_uuid": uuid_task, "_parent": {"_uuid": uuid_parent}})
    incfile1 = IncludedFile(filename, args, vars, task)
    incfile2 = IncludedFile(filename, args, vars, task)
    assert incfile1 == incfile

# Generated at 2022-06-21 00:45:49.096838
# Unit test for method __repr__ of class IncludedFile

# Generated at 2022-06-21 00:45:49.876503
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-21 00:45:57.928693
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # return True
    loader = DictDataLoader({
        u'/etc/ansible/roles/test-role/tasks/main.yml': """---
- include_tasks: test-role-1.yml
""",
        u'/etc/ansible/roles/test-role/meta/main.yml': """---
dependencies:
- {role: test-role-1}
""",
    })
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader))
    variable_manager.extra_vars = {u'foo': u'bar'}
    variable_manager._fact_cache['ansible_env.HOME'] = '/home/test-user'

# Generated at 2022-06-21 00:46:07.264783
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    if __name__ == '__main__':
        included_files = []
        # Define the first instance of IncludedFile
        filename1 = 'test1.yml'
        args1 = {'file_path': 'test_path'}
        vars1 = {'var1': 'val1', 'var2': 'val2'}
        task1 = {}
        included_files.append(IncludedFile(filename1, args1, vars1, task1))

        # Define the second instance of IncludedFile, identical to the first
        filename2 = 'test1.yml'
        args2 = {'file_path': 'test_path'}
        vars2 = {'var1': 'val1', 'var2': 'val2'}
        task2 = {}

# Generated at 2022-06-21 00:46:45.487189
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # Sample data
    filename = "file1"
    args = "args1"
    vars = "vars1"
    task = "task1"
    is_role = False
    # Call
    inc_file = IncludedFile(filename, args, vars, task, is_role)
    # Verification
    assert str(inc_file) == 'file1 (args=args1 vars=vars1): []'
    # Now make it look like we have hosts in the included files
    inc_file._hosts = ['host1']
    # Verification
    assert str(inc_file) == 'file1 (args=args1 vars=vars1): [\'host1\']'


# Generated at 2022-06-21 00:46:52.372679
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    test_file = IncludedFile("filename", "args", "vars", "task")

    assert test_file.add_host("host1") == ["host1"]

    # Test adding the same host twice which should result in an error
    with pytest.raises(ValueError):
        test_file.add_host("host1")



# Generated at 2022-06-21 00:47:00.952738
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.vars import VariableManager

    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../lib/ansible/modules/core'))

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = {"test_var": "test_value"}
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 00:47:13.495804
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    list_test = []
    list_test.append(IncludedFile('filename1', 'args1', 'vars1', 'task1'))
    list_test.append(IncludedFile('filename2', 'args2', 'vars2', 'task2'))
    list_test.append(IncludedFile('filename3', 'args3', 'vars3', 'task3'))

    for value in list_test:
        assert(str(value) == "%s (args=%s vars=%s): %s" % (value._filename, value._args, value._vars, value._hosts))
#Unit test for method __repr__ of class IncludedFile


# Generated at 2022-06-21 00:47:23.456373
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    class test_Task:

        def __init__(self):
            self.action = 'action'
            self.loop = 'loop'
            self.no_log = 'no_log'
            self._parent = 'parent'
            self._uuid = 'uuid'

        def copy(self):
            return test_Task()

        def get_search_path(self):
            return 'search_path'

    class test_Host:

        def __init__(self, name):
            self.name = name

    class test_Play:

        def __init__(self):
            self.name = 'play'

    class test_IncludeRole:

        def __init__(self, role_path):
            self._role_path = role_path


# Generated at 2022-06-21 00:47:28.409755
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    original_task = object()
    original_host = object()
    filename = 'test.yml'
    args = dict()
    vars = dict()

    test = IncludedFile(filename, args, vars, original_task)
    assert(test._filename == filename)
    assert(test._args == args)
    assert(test._vars == vars)
    assert(test._task == original_task)


# Test function IncludedFile.add_host

# Generated at 2022-06-21 00:47:38.813005
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class obj:
        def __init__(self, uuid):
            self._uuid = uuid
    class obj2:
        def __init__(self, uuid, parent):
            self._uuid = uuid
            self._parent = parent
    a = obj(1)
    b = obj2(2,a)
    c = obj(3)
    assert str(IncludedFile("file",{},{},b)) == "file (args={} vars={}): []"
    assert str(IncludedFile("file",{"a":1},{},b)) == "file (args={'a': 1} vars={}): []"
    assert str(IncludedFile("file",{"a":1},{},b)) == str(IncludedFile("file",{"a":1},{},b))
    assert str

# Generated at 2022-06-21 00:47:51.843495
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    data = dict()
    data['filename'] = "/tmp/test_file"
    data['args'] = dict()
    data['vars'] = dict()
    data['task'] = dict()
    data['task']['_uuid'] = "123"
    data['task']['_parent'] = dict()
    data['task']['_parent']['_uuid'] = "456"
    new_IncludedFile = IncludedFile(data['filename'], data['args'], data['vars'], data['task'])
    assert new_IncludedFile._filename == "/tmp/test_file"
    assert new_IncludedFile._args == dict()
    assert new_IncludedFile._vars == dict()
    assert new_IncludedFile._task._uuid == "123"
    assert new_Included

# Generated at 2022-06-21 00:47:56.308888
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    inc_file = IncludedFile("filename", "args", "vars", "task")
    assert str(inc_file) == "filename (args=args vars=vars): []"


# Generated at 2022-06-21 00:48:01.085647
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    x = IncludedFile('foo', 'bar', 'baz', 'bam')
    assert x._filename == 'foo'
    assert x._args == 'bar'
    assert x._vars == 'baz'
    assert x._hosts == ['bam']
    assert x._task is None



# Generated at 2022-06-21 00:48:35.994033
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # Test constructor with parameters
    try:
        ifile = IncludedFile("filename", "args", "vars", "task")
        assert(isinstance(ifile, IncludedFile))
        assert(ifile._filename == "filename")
        assert(ifile._args == "args")
        assert(ifile._vars == "vars")
        assert(ifile._task == "task")
        assert(ifile._hosts == [])
        assert(ifile._is_role == False)
    except Exception as ex:
        assert False, "Unexpected exception occurred! %s" % (ex)

# Generated at 2022-06-21 00:48:46.133348
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Initialize
    tasks_to_add = []

# Generated at 2022-06-21 00:48:50.352568
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    x = IncludedFile("hosts", [], {}, [], True)
    print(x._filename)


if __name__ == '__main__':
    test_IncludedFile()

# Generated at 2022-06-21 00:49:00.576618
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # (filename, args, vars, task)
    included_file_1 = IncludedFile('task1.yml', {'_raw_params': '"{{ var1 }}"'}, {}, 'include')
    included_file_2 = IncludedFile('task2.yml', {}, {}, 'import_tasks')

    # Test equals function
    assert included_file_1 == included_file_1
    assert included_file_2 != included_file_1
    try:
        assert included_file_2 == included_file_1
    except AssertionError:
        assert True
    else:
        assert False

    # Test add_host function
    # add_host shall add a host to included_file
    included_file_1.add_host('host_1')

# Generated at 2022-06-21 00:49:12.177204
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    loader = DictDataLoader({'test1.yml': '{"include_tasks": "test2.yml"}', 'test2.yml': '{"include_tasks": "test3.yml"}', 'test3.yml': '{"include_tasks": "test2.yml"}'})
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 00:49:16.896741
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    ifs = IncludedFile('blah', 'args', 'vars', 'task')
    assert ifs._filename == 'blah'
    assert ifs._args == 'args'
    assert ifs._vars == 'vars'
    assert ifs._task == 'task'
    assert ifs._hosts == []
    assert not ifs._is_role

    ifs = IncludedFile('blah', 'args', 'vars', 'task', is_role=True)
    assert ifs._filename == 'blah'
    assert ifs._args == 'args'
    assert ifs._vars == 'vars'
    assert ifs._task == 'task'
    assert ifs._hosts == []
    assert ifs._is_role



# Generated at 2022-06-21 00:49:23.705106
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # generate some fake results
    results = []
    results.append(IncludedFile(filename='tasks/main.yml', args={}, vars={}, task=None))
    results.append(IncludedFile(filename='tasks/main.yml', args={}, vars={}, task=None))
    results.append(IncludedFile(filename='tasks/main.yml', args={}, vars={}, task=None))
    results.append(IncludedFile(filename='roles/test/tasks/main.yml', args={}, vars={}, task=None))
    results.append(IncludedFile(filename='roles/test/tasks/main.yml', args={}, vars={}, task=None))

# Generated at 2022-06-21 00:49:29.407579
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    # A string as first argument
    try:
        IncludedFile("filename", [], [], "task")
    except ValueError as e:
        assert str(e) == "__init__() missing 4 required positional arguments: 'args', 'vars', 'task' and 'is_role'"

    # A string as second argument
    try:
        IncludedFile("filename", "args", [], "task")
    except ValueError as e:
        assert str(e) == "__init__() missing 4 required positional arguments: 'args', 'vars', 'task' and 'is_role'"

    # A string as third argument

# Generated at 2022-06-21 00:49:32.736668
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    my_task = Task()
    my_Included_File = IncludedFile('filename', 'args', 'vars', my_task)
    assert my_Included_File.__repr__() == "filename (args=args vars=vars): []"


# Generated at 2022-06-21 00:49:45.333085
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.playbook.role_include
    import ansible.playbook.task_include
    import ansible.playbook.block
    import ansible.playbook.task

    results = [
        ansible.playbook.role_include.RoleInclude(
            ansible.playbook.task_include.TaskInclude(
                ansible.playbook.block.Block(
                    ansible.playbook.task.Task(
                        dict(foo="bar"),
                        dict(bar="baz")))))
    ]

    included_files = IncludedFile.process_include_results(
        results=results,
        iterator=None,
        loader=None,
        variable_manager=None)

    assert included_files[0]._filename == 'bar'

# Generated at 2022-06-21 00:50:46.074315
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.task import Task

    loader = 'Mock'
    variable_manager = 'Mock'
    filename = '/path/ansible/module.yml'
    args = {'name': 'included module'}
    vars = {'include_name': 'included module'}
    task = Task()

    mock_inc_file = IncludedFile(filename, args, vars, task)

    assert repr(mock_inc_file) == '/path/ansible/module.yml (args={\'name\': \'included module\'} vars={\'include_name\': \'included module\'}): []'


# Generated at 2022-06-21 00:50:51.186547
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    inc = IncludedFile(filename='filename', args='args', vars='vars', task='task')
    inc.add_host('localhost')
    assert str(inc) == "filename (args=args vars=vars): ['localhost']"

# Generated at 2022-06-21 00:51:00.299262
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.plugins.loader import get_all_plugin_loaders, get_all_plugins

    display.verbosity = 4

    playbook_path = 'test/unit/executor/test_include_results.yml'

    class MockIter(object):
        def __init__(self, play):
            self._play = play


# Generated at 2022-06-21 00:51:06.104892
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    fh = IncludedFile('filename', 'args', 'vars', 'task')
    assert fh is not None
    assert fh._filename == 'filename'
    assert fh._args == 'args'
    assert fh._vars == 'vars'


# Generated at 2022-06-21 00:51:18.018221
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    filename = 'filename'
    args = ['a', 'b']
    vars = {'dict': 'vars'}
    task = 'task'
    host = 'host'

    IncludedFile_obj = IncludedFile(filename, args, vars, task)
    assert IncludedFile_obj._filename == filename
    assert IncludedFile_obj._args == args
    assert IncludedFile_obj._vars == vars
    assert IncludedFile_obj._task == task
    assert IncludedFile_obj._hosts == []
    IncludedFile_obj.add_host(host)
    assert IncludedFile_obj._hosts == [host]


# Generated at 2022-06-21 00:51:26.239283
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    # pylint: disable=unused-variable
    filename = 'filename'
    args = 'args'
    vars = 'vars'
    task = 'task'
    a = IncludedFile(filename, args, vars, task)
    assert a._filename == filename
    assert a._args == args
    assert a._vars == vars
    assert a._task == task
    assert a._hosts == []

# Generated at 2022-06-21 00:51:36.009738
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    # Scenario A:
    # create an instance of IncludedFile
    # call __repr__ on that instance
    # expected outcome:
    # a string of the form:
    # <filename> (args=<args> vars=<vars>): [<list of hosts>]
    # where:
    # <filename> is the name of the included file
    # <args> is the params passed to the include file
    # <vars> is the variables that needs to be used in the template of the included file
    # <list of hosts> is a list of hosts that had the file included
    included_file = IncludedFile("/path/file_name", {'arg1': 1, 'arg2': 2}, {'var1': 'value1'}, None)

# Generated at 2022-06-21 00:51:40.905446
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    inc_1 = IncludedFile('/etc/file', {}, {}, Task())
    inc_1_dup = IncludedFile('/etc/file', {}, {}, Task())

    assert inc_1 == inc_1_dup



# Generated at 2022-06-21 00:51:51.598110
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    """
    Test that the __repr__ method of class IncludedFile returns correct
    representation of object
    """
    class mock_task():
        def __init__(self, uuid, parent):
            self._uuid = uuid
            self._parent = parent
        def __repr__(self):
            return 'task'
    class mock_play():
        def __init__(self, uuid):
            self._uuid = uuid
    # Test if correct string is returned
    t1 = mock_task('task 1', 'parent1')
    f1 = IncludedFile('/tmp/some/file.yml', {'name': 'some_name'}, {'vars': 'some_vars'}, t1)

# Generated at 2022-06-21 00:52:02.710816
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    test_result = []
    filename = 'include_file'
    args = [1, 2, 'a', 'b']
    vars = {'a': 1, 'b': 2}
    uuid = 'example-uuid'
    task = TaskInclude(dict())
    task._uuid = uuid

    includefile  = IncludedFile(filename, args, vars, task)

    assert(includefile._filename == 'include_file')
    assert(includefile._args == [1, 2, 'a', 'b'])
    assert(includefile._vars == {'a': 1, 'b': 2})
    assert(includefile._task._uuid == 'example-uuid')
    assert(includefile._is_role == False)