

# Generated at 2022-06-21 00:43:17.339506
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = []
    results.append([
        {'_result': {'include_args': dict(), 'include': './test_01'}, '_host': 'test_host1'},
        {'_result': {'include_args': dict(), 'include': './test_01'}, '_host': 'test_host2'},
        {'_result': {'include_args': dict(), 'include': './test_01'}, '_host': 'test_host3'},
        {'_result': {'include_args': dict(), 'include': './test_01'}, '_host': 'test_host1'}  # duplicate host
    ])

# Generated at 2022-06-21 00:43:25.954902
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task_1 = {
        'action': 'include_tasks',
        'args': { '_raw_params': 'test.yml'},
        'name': 'test',
        '_search_paths': None
    }

    task_2 = {
        'action': 'include_role',
        'args': { '_raw_params': 'test.yml'},
        'name': 'test',
        '_search_paths': None
    }

    class FakeTask:
        def __init__(self, task):
            self.action = task['action']
            self.name = task['name']
            self.args = task['args']
            self._search_paths = task['_search_paths']


# Generated at 2022-06-21 00:43:35.131571
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    task = object()
    incfile = IncludedFile('filename', 'args', 'vars', task)
    incfile.add_host('host1')
    incfile.add_host('host2')
    assert 'args=args' in repr(incfile)
    assert 'vars=vars' in repr(incfile)
    assert 'filename' in repr(incfile)
    assert 'host1' in repr(incfile)
    assert 'host2' in repr(incfile)

# Generated at 2022-06-21 00:43:48.538338
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import pytest

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # ------------------------------------------------------------------------
    # TEST DATASET 1
    # The files to load and the expected included files for the following tests
    # ------------------------------------------------------------------------
    include_tasks_file = os.path.join(os.path.dirname(__file__),
                                      "include_tasks_test.yml")

    # When not using a loop, the include file is included directly
    # The include file is included once at the play level
    dataset1 = {
        "include_tasks_file": include_tasks_file,
        "expected_included_files": [include_tasks_file]
    }

    # When using a loop, the include file is included once per loop iteration
    # The include file

# Generated at 2022-06-21 00:44:01.439870
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """Unit test for method "__eq__" of Class "IncludedFile"."""

    import ansible.plugins.loader as plugin_loader

    base_dir = "./tests/unit/test_included_file_eq/"
    module_list = plugin_loader.find_plugins(base_dir)
    plugin_loader.load_plugins(module_list)

    from ansible.playbook import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    variable_manager = VariableManager()

    play = Play()
    play.name = 'test play'
    play.vars = dict()
    play.vars['foo'] = 'bar'

# Generated at 2022-06-21 00:44:11.548708
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Unit test for method process_include_results of class IncludedFile
    from ansible.utils.vars import combine_vars

    # Create a dummy task result for use in the test
    class DummyTaskResult:
        def __init__(self):
            self._host = 'fake_host'
            self._task = None
            self._result = {'include_args': {}}

    # Test a good result, with no additional data, no included_files should be added
    fake_results = [DummyTaskResult()]
    fake_results[0]._task = task_one

# Generated at 2022-06-21 00:44:20.226817
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-21 00:44:26.247106
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # Test 1
    task1 = Task()
    task2 = Task()
    task1._uuid = task2._uuid
    task2._parent = task1
    task1._parent = task2
    inc1 = IncludedFile(filename='file1', args={}, vars={}, task=task1)
    inc2 = IncludedFile(filename='file2', args={}, vars={}, task=task2)
    assert (inc1 == inc1)
    assert (inc2 == inc2)
    assert (inc1 != inc2)

    # Test 2
    task1 = Task()

# Generated at 2022-06-21 00:44:39.514945
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Create a temporary file
    filename = 'testfile.txt'
    with open(filename, 'w') as file_:
        file_.write('test')

    # Create a new IncludedFile
    include_file = IncludedFile(filename, {}, {}, None)
    # Check that len(include_file._hosts) == 0
    assert len(include_file._hosts) == 0

    # Check that add_host() raises a ValueError if the argument is already in include_file._hosts
    with pytest.raises(ValueError):
        include_file.add_host('localhost')

    # Add a host to include_file
    include_file.add_host('192.168.1.1')
    # check that len(include_file._hosts) == 1

# Generated at 2022-06-21 00:44:49.331765
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task = '''
    - name: test
      command: echo "Hello world"
    '''
    args = {'arg1': 'Hello', 'arg2': 'world'}

    # test if equal
    file1 = IncludedFile('test.yml', args, task)
    file2 = IncludedFile('test.yml', args, task)
    assert file1 == file2

    # test if not equal
    file3 = IncludedFile('test3.yml', args, task)
    file4 = IncludedFile('test4.yml', args, task)
    assert file3 != file4

# Generated at 2022-06-21 00:45:05.944065
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    filename = 'myfile'
    args = 'myargs'
    vars = 'myvars'
    task = 'mytask'
    host = 'myhost'

    inc = IncludedFile(filename, args, vars, task)
    inc.add_host(host)

    assert repr(inc) == "%s (args=%s vars=%s): %s" % (filename, args, vars, [host])

# Generated at 2022-06-21 00:45:07.065155
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    IncludedFile("abc", "args", "vars", "task")


# Generated at 2022-06-21 00:45:10.038244
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    host = "host1"
    inc = IncludedFile("inc_file", "args", "vars", "task")
    inc.add_host(host)
    assert inc._hosts.__len__() == 1
    assert inc._hosts.__contains__(host)


# Generated at 2022-06-21 00:45:24.017968
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-21 00:45:31.592622
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    import types

    # In this unit test, we test the add_host method of IncludedFile class
    # The method takes an argument host, add it to the list of hosts
    # it there is no duplicates in the list of hosts
    # Otherwise an error is raised

    # Check if add_host method exists
    assert hasattr(IncludedFile, "add_host"), "'IncludedFile' object has no attribute 'add_host'"

    # Check if add_host is a method
    assert type(getattr(IncludedFile, "add_host")) == types.MethodType, "'add_host' is not a method"

    # Check if the error is raised
    inc_file = IncludedFile(None)
    inc_file.add_host("host1")

# Generated at 2022-06-21 00:45:43.818721
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.host import Host

    filename1 = "toto"
    filename2 = "tutu"
    args1 = dict()
    args1["tata"] = "titi"
    args2 = dict()
    args2["titi"] = "titi"
    vars1 = dict()
    vars1["toto"] = "toto"
    vars2 = dict()
    vars2["tutu"] = "tutu"
    task1 = Task()
    task2 = Task()
    task1._uuid = "toto123"
    task2._uuid = "toto456"

# Generated at 2022-06-21 00:45:53.173239
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    args = dict()
    vars = dict()
    included_file = dict()
    result = dict()
    included_file.no_log = False

    # TODO: create an instance of IncludedFile for the task and the result
    # and add assert not equal using the == operator
    results = []
    iterator = dict()
    loader = dict()
    variable_manager = dict()
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-21 00:46:05.130074
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    from ansible.playbook.task import Task

    # Create an IncludedFile object with a few hosts
    if1 = IncludedFile("filename", "args", "vars", Task())
    if1.add_host("host1")
    if1.add_host("host2")
    if1.add_host("host3")
    assert str(if1) == "filename (args=args vars=vars): ['host1', 'host2', 'host3']"

    # Create another IncludedFile object with only one of the same hosts that the first if has
    if2 = IncludedFile("filename", "args", "vars", Task())
    if2.add_host("host2")
    assert str(if2) == "filename (args=args vars=vars): ['host2']"

    # Compare if1 and if2.

# Generated at 2022-06-21 00:46:11.568606
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.plugins
    import ansible.plugins.loader
    from ansible.executor.task_result import TaskResult

    loader = ansible.plugins.loader.plugins_dynamic_loader
    results = []

    res = TaskResult(host=None, task=None, return_data={})
    res._host = 'host1'
    res._task = 'task1'
    res._result = {'_ansible_parsed': True, 'failed': False, 'changed': True, 'include_args': {'a': 1},
                   'include': './include1', 'ansible_facts': {'ansible_all_ipv4_addresses': ['1.1.1.1', '5.5.5.5']}}
    results.append(res)


# Generated at 2022-06-21 00:46:17.186719
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile('/test/file1.yml', '', '', '', '', '', '')
    b = IncludedFile('/test/file1.yml', '', '', '', '', '', '')
    assert a == b

# Generated at 2022-06-21 00:46:36.341109
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    t = TaskInclude()
    t._uuid = 'foo'
    p = Play()
    p._uuid = 'foo'
    t._parent = p
    t.action = 'include'
    t.loop = False
    args = {'_raw_params': 'foo.yml'}
    t.vars = {}
    included_file = IncludedFile('foo.yml', args, {}, t)
    assert repr(included_file) == "foo.yml (args={'_raw_params': 'foo.yml'} vars={}): []"


# Generated at 2022-06-21 00:46:42.637808
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    import copy

    my_results = []
    my_included_files = []

# Generated at 2022-06-21 00:46:51.478769
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    class Task:
        _uuid = 42
        _parent = None

        class _Parent:
            _uuid = 0

    task = Task()
    included_file = IncludedFile('foo', 'bar', 'baz', task)
    expected = "foo (args=bar vars=baz): []"

    assert str(included_file) == expected, "The two objects are not equal"

# Generated at 2022-06-21 00:47:00.611856
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():

    class Dummy(object):
        def __init__(self, uuid):
            self._uuid = uuid

    x = IncludedFile(
        filename = "/path/to/file",
        args     = {"key": "value"},
        vars     = {"var": "val"},
        task     = Dummy(42),
        is_role  = True
    )

    assert x.__repr__() == "/path/to/file (args={'key': 'value'} vars={'var': 'val'}): []"

    class Dummy(object):
        def __init__(self, uuid):
            self._uuid = uuid


# Generated at 2022-06-21 00:47:03.819367
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task = IncludedFile('file', {}, {}, 'task')
    task2 = IncludedFile('file', {}, {}, 'task')
    assert task == task2


# Generated at 2022-06-21 00:47:12.906019
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    """unit test for method __repr__ of class IncludedFile"""
    # create an instance of class IncludedFile
    included_file = IncludedFile('/home', 'args', 'vars', 'task')
    included_file._hosts = ['host1', 'host2']
    # check repr
    assert repr(included_file) == "/home (args=args vars=vars): ['host1', 'host2']"


# Generated at 2022-06-21 00:47:25.281931
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    class FakeHost:
        def __init__(self, name):
            self._name = name

        def get_name(self):
            return self._name

    from ansible.runner.return_data import ReturnData
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    loader = None
    variable_manager = None
    results = []
    iterator = None


# Generated at 2022-06-21 00:47:35.542954
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.utils.vars import combine_vars

    loader = DictDataLoader({
        "test_host1": {
            "roles": ["test_role"]
        }
    })

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['test_host1'])


# Generated at 2022-06-21 00:47:45.252172
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import find_plugin
    from ansible.utils.vars import combine_vars

    # define class to mock a task result
    class TaskResult:
        def __init__(self, host, task, loop=None, result=None):
            self._host = host
            self._task = task
            self._result = {}
            if result is not None:
                self._result['result'] = result
            if loop is not None:
                self._result['results'] = loop

    # define class to mock an iterator

# Generated at 2022-06-21 00:47:54.415091
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    included_files = []

    inc_file = IncludedFile('test1.yml', None, None, None)
    included_files.append(inc_file)

    inc_file.add_host('test1')
    inc_file.add_host('test2')

    assert len(inc_file._hosts) == 2

    # Test ValueError with duplicate host
    from ansible.module_utils.six import PY3
    if PY3:
        import pytest
        with pytest.raises(ValueError):
            inc_file.add_host('test2')
    else:
        try:
            inc_file.add_host('test2')
        except Exception as e:
            assert type(e).__name__ == 'ValueError'

# Generated at 2022-06-21 00:48:24.906947
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    ifm = IncludedFile(1, 2, 3, 4, 5)
    assert ifm._filename == 1
    assert ifm._args == 2
    assert ifm._vars == 3
    assert ifm._task == 4
    assert ifm._hosts == []
    assert ifm._is_role == 5


# Generated at 2022-06-21 00:48:35.843362
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    play_context = PlayContext()

# Generated at 2022-06-21 00:48:41.134860
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    assert repr(IncludedFile('/path/to/tasks.yaml', None, None, None, is_role=True)) == "/path/to/tasks.yaml (args=None vars=None): []"

# Generated at 2022-06-21 00:48:47.660737
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    t1 = TaskInclude()
    t1.action = 'include'
    t1.loop = False
    task = Task()
    task._parent = t1
    filename = '/etc/foo.inc'
    args = {}
    vars = {}
    inc1 = IncludedFile(filename, args, vars, task)

    t2 = TaskInclude()
    t2.action = 'include'
    t2.loop = False
    task = Task()
    task._parent = t2
    filename = '/etc/foo.inc'
    args = {}
    vars = {}
    inc2 = IncludedFile(filename, args, vars, task)

    assert inc1 == inc2

# Generated at 2022-06-21 00:48:59.313760
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import doctest
    import ansible.playbook.task_include
    import ansible.playbook.role_include
    import ansible.template
    import ansible.module_utils.common

    AnsibleError = ansible.errors.AnsibleError
    TaskInclude = ansible.playbook.task_include.TaskInclude
    IncludeRole = ansible.playbook.role_include.IncludeRole
    Templar = ansible.template.Templar
    AnsibleModule = ansible.module_utils.common.AnsibleModule

    class DummyVarsModule(AnsibleModule):
        def __init__(self):
            self.params = {'omit': '#'}
            super(DummyVarsModule, self).__init__()


# Generated at 2022-06-21 00:49:10.961305
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # invalid name or file not found
    f1 = IncludedFile(None,{},{},None)
    f2 = IncludedFile(None,{},{},None)
    assert not f1.__eq__(f2)
    f1 = IncludedFile("test.txt",{},{},None)
    f2 = IncludedFile(None,{},{},None)
    assert not f1.__eq__(f2)
    f1 = IncludedFile("test.txt",{},{},None)
    f2 = IncludedFile("test.txt",{},{},None)
    assert f1.__eq__(f2)

    # invalid args
    f1 = IncludedFile("test.txt",{"arg1":"X"},{},None)
    f2 = IncludedFile("test.txt",{},{},None)

# Generated at 2022-06-21 00:49:22.949791
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    base_dir = './test/test_playbooks'
    loader = DataLoader()

    ifn = IncludedFile('foo.yml', {}, {}, None)
    assert ifn._filename == 'foo.yml'
    assert ifn._args == {}
    assert ifn._vars == {}
    assert ifn._task is None
    assert ifn._hosts == []
    assert ifn._is_role is False

    ifn = IncludedFile('bar.yml', {'a': 1, 'b': 2}, {'c': 3, 'd': 4}, None)
    assert ifn._filename == 'bar.yml'
    assert ifn._args == {'a': 1, 'b': 2}
    assert ifn._vars == {'c': 3, 'd': 4}
    assert ifn._

# Generated at 2022-06-21 00:49:28.106819
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Create two IncludedFile objects with the same parameters.
    included_file1 = IncludedFile(1, 2, 3, 4)
    included_file2 = IncludedFile(1, 2, 3, 4)

    # __eq__ returns true in case of two equal objects, otherwise false.
    assert included_file1 == included_file2

# Generated at 2022-06-21 00:49:35.120908
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile('filename', 'args', 'vars', 'task')
    inc_file.add_host('host1')
    inc_file.add_host('host2')
    inc_file.add_host('host3')

    assert len(inc_file._hosts) == 3
    for h in ['host1', 'host2', 'host3']:
        assert h in inc_file._hosts

    try:
        inc_file.add_host('host1')
    except ValueError:
        # This is the expected behavior
        assert True
    else:
        assert False
    assert len(inc_file._hosts) == 3

# Generated at 2022-06-21 00:49:40.551444
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # initialize objects we need
    filename = 'some_file'
    args = {'a': 1}
    vars = {'b': 2}
    task = object()

    # create two objects that should compare equal
    obj_1 = IncludedFile(filename, args, vars, task)
    obj_2 = IncludedFile(filename, args, vars, task)

    # two objects should compare equal if and only if all their attributes compare equal
    assert(obj_1 == obj_2)
    assert(obj_2 == obj_1)
    assert(not (obj_1 != obj_2))
    assert(not (obj_2 != obj_1))

    # check all attributes for inequality

# Generated at 2022-06-21 00:50:33.723586
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    try:
        incfile = IncludedFile(None, None, None, None)
    except Exception as e:
        print(e)
        print('Failed to execute constructor of class IncludedFile')
        exit(1)

# Tests the method 'add_host', which should add the given host to the list of hosts of the current IncludedFile
# instance
# NOTE: the value error is raised using the following line:
# raise ValueError()

# Generated at 2022-06-21 00:50:45.917402
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    import os
    import sys
    import tempfile

    from ansible import constants as C
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import module_loader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager



# Generated at 2022-06-21 00:50:56.493170
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    import ansible.playbook.task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    # Ugly hack to ensure ansible-playbook doesn't throw an exception
    # not a big deal since the unit test is supposed to catch it
    class FakePlaybook:
        pass
    task = ansible.playbook.task.Task()
    fake_playbook = FakePlaybook()

# Generated at 2022-06-21 00:51:09.335452
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.executor.task_executor
    import ansible.playbook.play_context

    results = [ansible.executor.task_executor.TaskResult(None, None, {'results': [{'a': 'foo', 'include': './b/a.yml'}]}),
               ansible.executor.task_executor.TaskResult(None, None, {'results': [{'a': 'bar', 'include': './b/a.yml'}]})]

    ctx = ansible.playbook.play_context.PlayContext()

    included_files = IncludedFile.process_include_results(results, ctx, None, None)

    assert included_files == [IncludedFile('/b/a.yml', None, None, None)]

# Generated at 2022-06-21 00:51:17.435282
# Unit test for method __repr__ of class IncludedFile
def test_IncludedFile___repr__():
    assert IncludedFile('file1', 'args1', 'vars1', 'task1', True) == IncludedFile('file1', 'args1', 'vars1', 'task1', True)
    assert IncludedFile('file2', 'args2', 'vars2', 'task2', True) == IncludedFile('file2', 'args2', 'vars2', 'task2', True)
    assert IncludedFile('file1', 'args1', 'vars1', 'task1', True) != IncludedFile('file2', 'args1', 'vars1', 'task1', True)
    assert IncludedFile('file1', 'args1', 'vars1', 'task1', True) != IncludedFile('file1', 'args2', 'vars1', 'task1', True)

# Generated at 2022-06-21 00:51:30.298392
# Unit test for constructor of class IncludedFile
def test_IncludedFile():
    included_files = []
    included_files.append(IncludedFile('/etc/ansible/file1', None, None, None))
    included_files.append(IncludedFile('/etc/ansible/file2', None, None, None))
    included_files.append(IncludedFile('/etc/ansible/file3', None, None, None))
    # Adding the same IncludedFile should raise exception
    try:
        included_files.append(IncludedFile('/etc/ansible/file2', None, None, None))
    except ValueError as e:
        print ("ValueError : " + str(e))
    print ("len(included_files) : " + str(len(included_files)))

#if __name__ == '__main__':
#    test_IncludedFile()

# Generated at 2022-06-21 00:51:36.683172
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile("file1", {"a": 1}, {"b": 2}, None)
    inc_file.add_host("Host1")
    inc_file.add_host("Host2")
    assert inc_file._hosts == ["Host1", "Host2"]
    try:
        inc_file.add_host("Host2")
    except ValueError:
        pass
    else:
        raise ValueError("duplicate host expected!")


# Generated at 2022-06-21 00:51:49.365261
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    i = IncludedFile('test.yml', [], [], Task())
    i1 = IncludedFile('test.yml', [], [], Task())
    i2 = IncludedFile('test2.yml', [], [], Task())

    play = Play.load({}, variable_manager=VariableManager())
    results = [i, i1, i2]
    result = IncludedFile.process_include_results(results, play, None, None)
    assert result == [i, i2]


# Generated at 2022-06-21 00:52:01.042433
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    """
    :return: None
    """
    filename = 'test_file'
    args = dict()
    vars = dict()
    task = dict()
    includedfile = IncludedFile(filename, args, vars, task)
    # test if the value is included into the list of hosts
    assert includedfile.add_host('host') == None
    assert includedfile._hosts == ['host']
    # test if the method raise a ValueError if the value is already in the list of hosts
    assert includedfile.add_host('host') == None
    try:
        includedfile.add_host('host')
    except ValueError as e:
        assert str(e) == ""
    else:
        assert False


# Generated at 2022-06-21 00:52:13.298630
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    '''
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    '''

    # Test single include
    pass
    # Test double include
    pass
    # Test include with loop
    pass
    # Test include with loop and vars
    pass
    # Test include with vars
    pass
    # Test include with same vars
    pass
    # Test include role
    pass
    # Test include role with vars
    pass
    # Test include role with same vars
    pass
    # test included role with tasks
    pass
    # test included file with tasks
    pass
    # test included file with handlers
    pass
    # test included file with vars
    pass
    # test included file with vars and handlers
    pass
    # test included file with vars and tasks
    pass