

# Generated at 2022-06-17 07:26:03.167928
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader


# Generated at 2022-06-17 07:26:12.350298
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

    # Create a task
    task = Task()
    task._uuid = '123'
    task._role = Role()
    task._role._role_path = './'
    task._parent = Block()
    task._parent._uuid = '456'
    task._parent._role = Role()
    task._parent._role._role_path = './'
    task._parent._parent = Play()
    task._parent._parent._role = Role

# Generated at 2022-06-17 07:26:21.240629
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.utils.display import Display

# Generated at 2022-06-17 07:26:29.812723
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile('/path/to/file', {}, {}, None)
    inc_file.add_host('host1')
    inc_file.add_host('host2')
    inc_file.add_host('host3')
    assert inc_file._hosts == ['host1', 'host2', 'host3']
    try:
        inc_file.add_host('host1')
    except ValueError:
        pass
    else:
        assert False, "ValueError should be raised"


# Generated at 2022-06-17 07:26:38.822114
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 07:26:41.739287
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile("test_file", "test_args", "test_vars", "test_task")
    inc_file.add_host("test_host")
    assert inc_file._hosts == ["test_host"]
    try:
        inc_file.add_host("test_host")
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-17 07:26:47.985751
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile('test_file', {}, {}, None)
    inc_file.add_host('test_host')
    assert inc_file._hosts == ['test_host']
    try:
        inc_file.add_host('test_host')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-17 07:26:53.548217
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile("filename", "args", "vars", "task")
    inc_file.add_host("host1")
    inc_file.add_host("host2")
    inc_file.add_host("host1")


# Generated at 2022-06-17 07:27:03.914827
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test_loader
   

# Generated at 2022-06-17 07:27:13.085808
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 07:27:34.808218
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

# Generated at 2022-06-17 07:27:43.428207
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 07:27:53.352618
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.executor.task_result import TaskResult
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 07:27:59.816097
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 07:28:10.122001
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test for different filename
    filename1 = "filename1"
    filename2 = "filename2"
    args = "args"
    vars = "vars"
    task = "task"
    included_file1 = IncludedFile(filename1, args, vars, task)
    included_file2 = IncludedFile(filename2, args, vars, task)
    assert included_file1 != included_file2

    # Test for different args
    filename = "filename"
    args1 = "args1"
    args2 = "args2"
    included_file1 = IncludedFile(filename, args1, vars, task)
    included_file2 = IncludedFile(filename, args2, vars, task)
    assert included_file1 != included_file2

    # Test for different vars

# Generated at 2022-06-17 07:28:17.779072
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    from ansible.utils.vars import combine_

# Generated at 2022-06-17 07:28:23.867105
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test case 1
    filename1 = 'filename1'
    args1 = 'args1'
    vars1 = 'vars1'
    task1 = 'task1'
    is_role1 = 'is_role1'
    included_file1 = IncludedFile(filename1, args1, vars1, task1, is_role1)

    filename2 = 'filename1'
    args2 = 'args1'
    vars2 = 'vars1'
    task2 = 'task1'
    is_role2 = 'is_role1'
    included_file2 = IncludedFile(filename2, args2, vars2, task2, is_role2)

    assert included_file1 == included_file2

    # Test case 2
    filename1 = 'filename1'
    args1 = 'args1'

# Generated at 2022-06-17 07:28:34.031803
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader

# Generated at 2022-06-17 07:28:43.692840
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 07:28:54.517549
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 07:29:39.690261
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test case 1
    filename1 = 'test1'
    args1 = {'a': 1, 'b': 2}
    vars1 = {'x': 1, 'y': 2}
    task1 = 'task1'
    is_role1 = True
    inc_file1 = IncludedFile(filename1, args1, vars1, task1, is_role1)

    filename2 = 'test1'
    args2 = {'a': 1, 'b': 2}
    vars2 = {'x': 1, 'y': 2}
    task2 = 'task1'
    is_role2 = True
    inc_file2 = IncludedFile(filename2, args2, vars2, task2, is_role2)

    assert inc_file1.__eq__(inc_file2)

    #

# Generated at 2022-06-17 07:29:49.665049
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a fake task result
    task = Task()
    task._role = None
    task._role_name = None
    task._parent = None
    task._play = Play()
    task._play._included_files = []
    task._play._included_file_vars = []
    task._play._variable_manager = VariableManager()
    task._play._variable_manager._fact_cache = dict()
    task._play._variable_manager._hostvars = dict()
    task._play._variable_manager._hostvars['localhost']

# Generated at 2022-06-17 07:29:57.226736
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class MockTask:
        def __init__(self, uuid):
            self._uuid = uuid

    class MockParent:
        def __init__(self, uuid):
            self._uuid = uuid

    task = MockTask('task_uuid')
    parent = MockParent('parent_uuid')
    task._parent = parent

    inc_file1 = IncludedFile('filename', 'args', 'vars', task)
    inc_file2 = IncludedFile('filename', 'args', 'vars', task)
    inc_file3 = IncludedFile('filename', 'args', 'vars', task)

    assert inc_file1 == inc_file2
    assert inc_file1 != inc_file3

# Generated at 2022-06-17 07:30:07.036839
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 07:30:15.785788
# Unit test for method __eq__ of class IncludedFile

# Generated at 2022-06-17 07:30:29.291362
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 07:30:41.361733
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 07:30:53.469920
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    # Create a task
    task = Task()
    task._uuid = "task_uuid"
    task._role = RoleDefinition()
    task._role._role_path = "role_path"
    task._parent = Block()
    task._parent._uuid = "block_uuid"
    task._parent._parent = Play()
    task._parent._parent._uuid = "play_uuid"

    # Create an included file
    included_file = IncludedFile("filename", "args", "vars", task)

    # Create another included file

# Generated at 2022-06-17 07:31:05.660744
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test with different filename
    filename1 = "filename1"
    filename2 = "filename2"
    args = "args"
    vars = "vars"
    task = "task"
    included_file1 = IncludedFile(filename1, args, vars, task)
    included_file2 = IncludedFile(filename2, args, vars, task)
    assert included_file1 != included_file2

    # Test with different args
    filename = "filename"
    args1 = "args1"
    args2 = "args2"
    included_file1 = IncludedFile(filename, args1, vars, task)
    included_file2 = IncludedFile(filename, args2, vars, task)
    assert included_file1 != included_file2

    # Test with different vars

# Generated at 2022-06-17 07:31:18.721696
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 07:32:04.759023
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    class FakeLoader:
        def __init__(self):
            self.basedir = '/tmp'

        def get_basedir(self):
            return self.basedir

        def path_dwim(self, path):
            return path

        def path_dwim_relative(self, basedir, path, name, is_role=False):
            return path

    class FakeIterator:
        def __init__(self):
            self._play = Play()


# Generated at 2022-06-17 07:32:15.517433
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 07:32:25.027930
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 07:32:32.387739
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    class MyTaskQueueManager(TaskQueueManager):
        def _initialize_processes(self, num):
            pass

    class MyTask(Task):
        def __init__(self, action, args, parent):
            super(MyTask, self).__init__(action, args, parent)
            self._role = None


# Generated at 2022-06-17 07:32:42.764405
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test for equality
    filename = 'test_filename'
    args = {'test_arg': 'test_value'}
    vars = {'test_var': 'test_value'}
    task = 'test_task'
    is_role = True
    inc_file = IncludedFile(filename, args, vars, task, is_role)
    inc_file2 = IncludedFile(filename, args, vars, task, is_role)
    assert inc_file == inc_file2

    # Test for inequality
    filename = 'test_filename'
    args = {'test_arg': 'test_value'}
    vars = {'test_var': 'test_value'}
    task = 'test_task'
    is_role = True

# Generated at 2022-06-17 07:32:53.405774
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test case 1:
    #   - filename: /path/to/file1
    #   - args: {'a': 1, 'b': 2}
    #   - vars: {'c': 3, 'd': 4}
    #   - task: TaskInclude
    #   - is_role: False
    #   - hosts: [host1, host2]
    #   - result: True
    filename1 = '/path/to/file1'
    args1 = {'a': 1, 'b': 2}
    vars1 = {'c': 3, 'd': 4}
    task1 = TaskInclude()
    is_role1 = False
    hosts1 = ['host1', 'host2']

# Generated at 2022-06-17 07:33:02.256767
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    play = Play()
    task = Task()
    task._role = None
    task._role_name = None
    task._parent = None
    task._play = play
    task._ds = None
    task._uuid = '1234567890'
    task._role_name = 'test_role'
    task.action = 'include_role'
    task.loop = False
    task.no_log = False
    task.args = dict()
    task.args['name'] = 'test_role'
    task.args['_raw_params'] = 'test_role'

    task2 = Task()

# Generated at 2022-06-17 07:33:14.353491
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    play = Play().load({'name': 'test', 'hosts': 'all'}, variable_manager=None, loader=None)
    block = Block().load(dict(tasks=[{'include': 'test.yml'}]), play=play)
    task = Task().load(block.block, play=play)
    role = RoleDefinition()
    role._role_path = '/tmp'
    task._role = role
    task._role_name = 'test'
    task._parent = block
    task._uuid = '12345'
    task._role = role


# Generated at 2022-06-17 07:33:20.253675
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    play_context = PlayContext()

# Generated at 2022-06-17 07:33:30.758820
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader

# Generated at 2022-06-17 07:34:36.985379
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 07:34:47.404231
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test case 1:
    #   - filename: /path/to/file
    #   - args: {'a': 'b'}
    #   - vars: {'c': 'd'}
    #   - task: <TaskInclude>
    #   - is_role: False
    #   - hosts: ['host1']
    #
    #   - filename: /path/to/file
    #   - args: {'a': 'b'}
    #   - vars: {'c': 'd'}
    #   - task: <TaskInclude>
    #   - is_role: False
    #   - hosts: ['host1']
    #
    #   - expected: True
    filename = '/path/to/file'
    args = {'a': 'b'}
   

# Generated at 2022-06-17 07:34:56.414462
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_

# Generated at 2022-06-17 07:35:05.929805
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

# Generated at 2022-06-17 07:35:15.228977
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import filter_loader