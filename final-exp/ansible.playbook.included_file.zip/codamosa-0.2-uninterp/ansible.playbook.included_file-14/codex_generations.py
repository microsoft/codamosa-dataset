

# Generated at 2022-06-17 07:26:07.435243
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.playbook.task_include
    import ansible.playbook.role_include
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.handler
    import ansible.playbook.role
    import ansible.playbook.role_dependency
    import ansible.playbook.play_context
    import ansible.vars.manager
    import ansible.vars.hostvars
    import ansible.vars.variable_manager
    import ansible.vars.unsafe_proxy
    import ansible.template.template
    import ansible.template.vars
    import ansible.template.safe_eval
    import ansible.template.jinja2_native
    import ansible.template.jinja2

# Generated at 2022-06-17 07:26:18.338026
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Test 1: Add a host to an empty list
    inc_file = IncludedFile('filename', 'args', 'vars', 'task')
    inc_file.add_host('host')
    assert inc_file._hosts == ['host']

    # Test 2: Add a host to a non-empty list
    inc_file.add_host('host')
    assert inc_file._hosts == ['host']

    # Test 3: Add a different host to a non-empty list
    inc_file.add_host('host2')
    assert inc_file._hosts == ['host', 'host2']

    # Test 4: Add a host that already exists in the list
    try:
        inc_file.add_host('host')
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

# Generated at 2022-06-17 07:26:31.008434
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'


# Generated at 2022-06-17 07:26:35.112392
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Test case 1: add a host to an empty list
    inc_file = IncludedFile('filename', 'args', 'vars', 'task')
    inc_file.add_host('host1')
    assert inc_file._hosts == ['host1']

    # Test case 2: add a host to a non-empty list
    inc_file.add_host('host2')
    assert inc_file._hosts == ['host1', 'host2']

    # Test case 3: add a host that already exists
    try:
        inc_file.add_host('host1')
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'


# Generated at 2022-06-17 07:26:46.819778
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude

    task1 = Task()
    task1._uuid = '123'
    task1._parent = Play()
    task1._parent._uuid = '456'

    task2 = Task()
    task2._uuid = '123'
    task2._parent = Play()
    task2._parent._uuid = '456'

    task3 = Task()
    task3._uuid = '123'
    task3._parent = Play()
    task3._parent._uuid = '789'

    task4 = Task()
    task4._uuid = '321'

# Generated at 2022-06-17 07:26:56.841828
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
   

# Generated at 2022-06-17 07:27:05.654381
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    task1 = Task()
    task1._role = None
    task1._parent = None
    task1._play = None
    task1._ds = None
    task1._uuid = "12345"
    task1._role_name = None
    task1._from_files = {}
    task1._role_path = None

# Generated at 2022-06-17 07:27:14.390785
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = 'filename'
    args = 'args'
    vars = 'vars'
    task = 'task'
    is_role = 'is_role'
    included_file = IncludedFile(filename, args, vars, task, is_role)
    assert included_file == IncludedFile(filename, args, vars, task, is_role)
    assert not included_file == IncludedFile('other_filename', args, vars, task, is_role)
    assert not included_file == IncludedFile(filename, 'other_args', vars, task, is_role)
    assert not included_file == IncludedFile(filename, args, 'other_vars', task, is_role)
    assert not included_file == IncludedFile(filename, args, vars, 'other_task', is_role)
    assert not included_file

# Generated at 2022-06-17 07:27:27.272292
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.network_os

# Generated at 2022-06-17 07:27:34.443624
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])

# Generated at 2022-06-17 07:28:01.812384
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleError
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

# Generated at 2022-06-17 07:28:12.136924
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 07:28:18.609620
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import module_loader

# Generated at 2022-06-17 07:28:25.278449
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_

# Generated at 2022-06-17 07:28:35.261902
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
   

# Generated at 2022-06-17 07:28:44.420014
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-17 07:28:55.002345
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display

# Generated at 2022-06-17 07:29:05.754123
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar


# Generated at 2022-06-17 07:29:17.411060
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader

# Generated at 2022-06-17 07:29:23.985900
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    host = Host(name='localhost')

# Generated at 2022-06-17 07:30:19.796288
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])

# Generated at 2022-06-17 07:30:30.598787
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    class MockPlaybookExecutor(PlaybookExecutor):
        def __init__(self, playbooks, inventory, variable_manager, loader, options, passwords):
            self._playbooks = playbooks
            self._inventory = inventory
            self._variable_manager = variable_manager


# Generated at 2022-06-17 07:30:41.544399
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-17 07:30:53.417127
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-17 07:31:05.551374
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager

    # Create a fake task result
    task_result = TaskResult(host=None, task=None, return_data=dict(failed=False, skipped=False, include='test.yml'))
    task_result._host = 'localhost'
    task_result._task = Task()
    task_result._task._role = RoleDefinition()
    task_result._task._role._role_path = '/tmp/test_role'
    task_result._task._role._role_name = 'test_role'
    task_result._task._role._role_

# Generated at 2022-06-17 07:31:15.160229
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 07:31:29.093218
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars_files

# Generated at 2022-06-17 07:31:42.426770
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-17 07:31:52.190269
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory

# Generated at 2022-06-17 07:32:04.837102
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    loader = DataLoader()

# Generated at 2022-06-17 07:33:30.864273
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-17 07:33:40.613739
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
   

# Generated at 2022-06-17 07:33:46.223740
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    # Create a fake task result
    task_result = TaskResult(host=None, task=None, return_data=dict(include='test.yml', include_args=dict(a=1, b=2)))

    # Create a fake task
    task = Task()
    task._role = None
    task._role_name = None
    task._parent = None
    task._play = Play()
    task._play._basedir = '/tmp'
    task._play._loader = None
    task._play._variable_manager = VariableManager()

    # Create a fake iterator
    iterator = task._play

    # Create

# Generated at 2022-06-17 07:33:58.757162
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play()
    play.vars = HostVars(host=None, variables=dict(foo='bar'))
    variable_manager.set_play_context(play=play)

    task = Task

# Generated at 2022-06-17 07:34:09.245384
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-17 07:34:21.282016
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager

    # Create a fake task result
    task_result = TaskResult(host=None, task=None, return_data=dict(failed=False, changed=False, skipped=False, include='test.yml', include_args=dict(a=1, b=2)))

    # Create a fake task
    task = Task()
    task.action = 'include'
    task.loop = 'results'
    task.no_log = False

    # Create a fake block
    block = Block()

# Generated at 2022-06-17 07:34:30.522042
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader

# Generated at 2022-06-17 07:34:38.555484
# Unit test for method __eq__ of class IncludedFile

# Generated at 2022-06-17 07:34:44.599956
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
   

# Generated at 2022-06-17 07:34:49.130138
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user