

# Generated at 2022-06-11 10:08:11.341154
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.plugins.action.include_tasks import ActionModule as IncludeTasksActionModule
    from ansible.plugins.action.include_role import ActionModule as IncludeRoleActionModule
    from ansible.plugins.action.import_tasks import ActionModule as ImportTasksActionModule
    from ansible.plugins.action.import_playbook import ActionModule as ImportPlaybookActionModule
    from ansible.plugins.action import ActionBase

    # Fake the iterator variable
    iterator = type('iterator', (object,), {'_play': type('play', (object,), {'name': 'myplay'})})

    # Fake the loader variable
    class FakeLoader(object):
        def get_basedir(self):
            return '<basedir>/'

# Generated at 2022-06-11 10:08:23.929427
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = None
    variable_manager = None
    inventory = InventoryManager(loader, variable_manager, None)
    variable_manager = variable_manager or variable_manager.set_inventory(inventory)

    play = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'tasks': [
         { 'action': 'debug', 'args': {'msg': 'This is a test.'} }
        ]
    }, variable_manager=variable_manager, loader=loader)

    task = play.get_tasks()[0]
    task_executor = Task

# Generated at 2022-06-11 10:08:35.604686
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    from ansible.module_utils.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import IncludeRole
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    task1 = TaskInclude()
    task2 = TaskInclude()
    task1.action = u'set_fact'
    task2.action = u'set_fact'
    args1 = {'key1': u'val1', 'key2': u'val2', 'key3': u'val3'}
    args2 = {'key1': u'val1', 'key2': u'val2', 'key3': u'val3'}

# Generated at 2022-06-11 10:08:43.048502
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Initialization of class IncludedFile
    loader = None
    variable_manager = None
    # Initialization of class Iterator
    iterator = None

    # Create the following Ansible Result
    # {
    #     "changed": false, 
    #     "item": {
    #         "key": "my_key"
    #     }, 
    #     "results": [
    #         {
    #             "ansible_loop_var": "item", 
    #             "changed": false, 
    #             "failed": false, 
    #             "include": "../../../roles/master/defaults/main.yml", 
    #             "include_args": {
    #                 "role": "master", 
    #                 "x": "y"
    #             }, 
    #             "

# Generated at 2022-06-11 10:08:44.218927
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False, "not implemented"

# Generated at 2022-06-11 10:08:55.923515
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.clean import module_response_deepcopy

    class FakeLoader:
        def get_basedir(self):
            return '/tmp'

        def path_dwim(self, name):
            return '/tmp/%s' % name

    loader = FakeLoader()
    variable_manager = VariableManager()
    task_name = 'fake_task'
    task = Task()
    task.action = C.ACTION_INCLUDE
    task.name = task_name
    task.loop_control = 'loop_control'
    host = Host('127.0.0.1')
   

# Generated at 2022-06-11 10:09:06.027192
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    inc1 = IncludedFile("inc1", {"a":1}, {"b":2}, "task1")
    inc2 = IncludedFile("inc2", {"a":1, "c":3}, {"b":2, "d":4}, "task2")
    inc3 = IncludedFile("inc1", {"a":1}, {"b":2}, "task1")
    inc4 = IncludedFile("inc1", {"a":2}, {"b":2}, "task1")
    inc5 = IncludedFile("inc1", {"a":1}, {"b":3}, "task1")

    assert inc1 == inc3
    assert inc1 != inc2
    assert inc1 != inc4
    assert inc1 != inc5


# Generated at 2022-06-11 10:09:10.791543
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    assert IncludedFile('a', {}, {}, Task()) == IncludedFile('a', {}, {}, Task())
    assert IncludedFile('a', {}, {}, Task(Play())) == IncludedFile('a', {}, {}, Task(Play()))


# Generated at 2022-06-11 10:09:20.138832
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert IncludedFile(1, [], {}, object()) == IncludedFile(1, [], {}, object())
    assert IncludedFile(1, [1], {}, object()) != IncludedFile(1, [2], {}, object())
    assert IncludedFile(1, [], {1: 1}, object()) != IncludedFile(1, [], {1: 2}, object())
    assert IncludedFile(1, [], {}, object()) != IncludedFile(2, [], {}, object())
    assert IncludedFile(1, [], {}, object()) != IncludedFile(1, [], {}, object())


# Generated at 2022-06-11 10:09:31.077712
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # Tests to validate if the duplication issues in the included_files is fixed.
    # As part of issue #19242, this test must pass without failure.
    import pytest
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-11 10:09:52.082031
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.plugins.loader import action_loader
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'str1': 'str2'}

    play_ds = dict(
        name='play',
        hosts=[],
        include=['another_task']
    )

    task_ds = dict(
        name='task',
        loop='{{ tasks}}',
        include='{{item}}'
    )

    res = action_loader.get('include', task_ds, play_ds, loader=loader, variable_manager=variable_manager, templar=None)

# Generated at 2022-06-11 10:10:01.915943
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile

    class FakeHost(object):
        pass

    host = FakeHost()
    host.name = '127.0.0.1'


# Generated at 2022-06-11 10:10:15.888436
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 10:10:25.370721
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from units.mock.path import mock_unfrackpath_noop

    mock_loader, inventory, variable_manager, loader, options, play, tqm = None, None, None, None, None, None, None


# Generated at 2022-06-11 10:10:38.851087
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class FakeHost:
        name = "fakehost"

    class FakeRole:
        name = "fakerole"
        def __init__(self, role_path):
            self._role_path = role_path

    class FakeTask:
        def __init__(self, parent=None, role=None, action="fakeaction", loop="fakeloop", no_log="fakenolog"):
            self._parent = parent
            self._role = role
            self.action = action
            self.loop = loop
            self.no_log = no_log

    class FakeTaskInclude(FakeTask):
        def __init__(self, args):
            self.args = args


# Generated at 2022-06-11 10:10:43.540419
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult

    results = [
        TaskResult(host=None, task=None, return_data=dict(include='/a/b/main.yml', ansible_loop_var='item')),
        TaskResult(host=None, task=None, return_data=dict(include='/a/b/second.yml')),
        TaskResult(host=None, task=None, return_data=dict(include='/a/c/third.yml')),
    ]

    included_files = IncludedFile.process_include_results(results, iterator=None, loader=None, variable_manager=None)


# Generated at 2022-06-11 10:10:53.200186
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    class DummyLoader:
        def get_basedir(self):
            return '/home/joe'

        def path_dwim(self, path):
            return '/home/joe/' + path

        def path_dwim_relative(self, parent, child, is_role):
            return '/home/joe/' + child

    class DummyPlay:
        pass

    class RoleTask:
        _role_name = 'test_role'
        _role_path = '/home/joe/roles/test_role'
        action = 'include_role'
        _parent = None
        _role = None

        def __init__(self, loop=False):
            self.loop = loop



# Generated at 2022-06-11 10:11:06.377121
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    playbook = Play()
    variable_manager = VariableManager()
    variable_manager.set_inventory(None)
    variable_manager.set_loader(None)
    variable_manager.set_host_variables({})
    variable_manager.set_host_facts({})
    variable_manager.set_task_variables({})
    variable_manager.extra_vars.clear()
    variable_manager.extra_vars.update({'var1': 'bar', 'var2': 'foo'})

    task1 = Task()
    task1.action = 'Script'

# Generated at 2022-06-11 10:11:15.378324
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

    loader = DictDataLoader({
        'not_exists.yml': 'test'
    })

    result_data = {
        'include_args': {
            '_raw_params': '{{ my_include }}'
        },
        'ansible_loop_var': 'item',
        'ansible_index_var': 'idx',
        'item': 'my_include',
        'ansible_item_label': 'my_include'
    }


# Generated at 2022-06-11 10:11:26.384108
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    display = Display()
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor import task_queue_manager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.include import IncludeRole

    # include_tasks
    loader = DataLoader()
    variable_manager = VariableManager

# Generated at 2022-06-11 10:12:01.567242
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.vars.collection import VariableCollection
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders, get_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.listify import listify_lookup_

# Generated at 2022-06-11 10:12:11.534442
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import time
    import unittest
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.vars.manager

    class Host:

        def __init__(self, name):
            self.name = name
            self._vars = {}

        def get_vars(self):
            return self._vars

        def get_name(self):
            return self.name

        def set_variable(self, varname, value):
            self._vars[varname] = value

        def __eq__(self, other):
            return other.name == self.name


# Generated at 2022-06-11 10:12:23.177718
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()

# Generated at 2022-06-11 10:12:34.827560
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from collections import namedtuple

    TestIncludedFile = namedtuple(
        'TestIncludedFile', ['_filename', '_args', '_vars', '_task', '_hosts'])
    TestTask = namedtuple(
        'TestTask',
        ['action', 'args', 'loop', '_parent', '_search_path', '_role',
         '_role_name', '_from_files', '_uuid', 'no_log'])

# Generated at 2022-06-11 10:12:44.073382
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import role


    play1 = Play()
    play1._ds = dict(name="test_play", hosts="all")

    task1 = dict(action=dict(module="include_tasks", meta="tasks/main.yml", name="include_tasks example", loop_control={}, loop='{{ test_results }}'))

# Generated at 2022-06-11 10:12:55.484228
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.block import Block

    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play

    from ansible.playbook.task import Task

    from ansible.playbook.play_iterator import PlayIterator

    from ansible.playbook.role import Role

    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.executor.task_result import TaskResult

    from ansible.plugins.loader import action_loader

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    # Create a task empty task

# Generated at 2022-06-11 10:13:06.068174
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars

    class BaseTask:
        def __init__(self, name):
            self.name = name
    class IncludeRole(TaskInclude):
        def __init__(self, name):
            super(IncludeRole, self).__init__()
            self.action = 'include_role'
            self.args = {'name': name}
            self._role_name = name

    class MockPlay:
        def __init__(self):
            self.hostvars = HostVars(loader=None, variables=dict())

    class MockVariableManager:
        def __init__(self, variables):
            self._vars_cache = {}
            self

# Generated at 2022-06-11 10:13:09.318384
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [dict(), dict()]
    iterator = object()
    loader = object()
    variable_manager = object()
    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert included_files == []

# Generated at 2022-06-11 10:13:19.661562
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.plugins.loader
    from ansible.vars.manager import VariableManager

    loader = ansible.plugins.loader.PluginLoader(class_name='ModuleLoader')
    variable_manager = VariableManager(loader=loader)

# Generated at 2022-06-11 10:13:30.079326
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.template.vars
    import ansible.template.template
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.inventory
    import ansible.vars.manager
    import ansible.parsing.dataloader
    import ansible.executor.task_queue_manager
    loader = ansible.parsing.dataloader.DataLoader()
    basedir = ansible.__path__[0]
    inventory = ansible.inventory.inventory.Inventory(loader=loader, variable_manager=None, host_list='localhost')

# Generated at 2022-06-11 10:14:29.565292
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    import logging
    import sys
    import unittest

    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    from unit.mock.loader import DictDataLoader
    from unit.mock.path import mock_unfrackpath_noop as mock_unfrackpath


# Generated at 2022-06-11 10:14:40.540871
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    it = IncludedFile(filename='filename', args={}, vars={}, task=Task())
    # Same filename, args, vars and task
    assert it == IncludedFile(filename='filename', args={}, vars={}, task=Task())

    # Different filename
    assert it != IncludedFile(filename='other_filename', args={}, vars={}, task=Task())

    # Different args
    assert it != IncludedFile(filename='filename', args={'key': 'value'}, vars={}, task=Task())

    # Different vars
    assert it != IncludedFile(filename='filename', args={}, vars={'key': 'value'}, task=Task())

    # Different task

# Generated at 2022-06-11 10:14:53.432222
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole

    included_file1 = IncludedFile('_file_name', '_args', '_vars', '_task')
    assert included_file1.__eq__(included_file1) == True

    included_file2 = IncludedFile('_DIFFERENT_file_name', '_args', '_vars', '_task')
    assert included_file1.__eq__(included_file2) == False

    included_file2 = IncludedFile('_file_name', '_DIFFERENT_args', '_vars', '_task')
    assert included_file1.__eq__(included_file2) == False


# Generated at 2022-06-11 10:15:00.884908
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.module_utils._text import to_bytes
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import _HostVarsLoader
    from ansible.parsing.dataloader import DataLoader

    class Host:

        def __init__(self, name):
            self.name = name

        def __hash__(self):
            return hash(self.name)

        def __eq__(self, other):
            if other._name == self.name:
                return True
            return False

        def get_name(self):
            return self.name


# Generated at 2022-06-11 10:15:15.355746
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test for the process_include_results method of the IncludedFile class
    # This method is used to parse the result of an include task.
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    play = Play.load(loader.load_from_file('test/ansible_collections/ansible_test/test_filter_plugins/test_collection/include_test.yml'))
    play.ROLE_CACHE = {}

    host = play.get_variable_manager().get_vars

# Generated at 2022-06-11 10:15:25.076166
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    assert IncludedFile(filename='/tmp/include_file_test', args={}, vars={}, task=Task.load(dict(include="foo.yml"), play=Play().load(dict(name="test_play"), variable_manager=None, loader=None), block=Block()), is_role=False) == \
          IncludedFile(filename='/tmp/include_file_test', args={}, vars={}, task=Task.load(dict(include="foo.yml"), play=Play().load(dict(name="test_play"), variable_manager=None, loader=None), block=Block()), is_role=False)

# Generated at 2022-06-11 10:15:39.052821
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import os
    import shutil
    import tempfile
    import yaml

    dirpath = tempfile.mkdtemp()
    file = open(os.path.join(dirpath, 'test.yml'),'w')
    yaml.dump(yaml.safe_load('''
- include: other.yml item="test"
- include: other.yml item="test2"
- include: other.yml item="test3"
- include_tasks: other.yml
- import_tasks: other.yml
- import_playbook: other.yml
'''), file, default_flow_style=False)
    file.close()
    dirname = os.path.dirname

# Generated at 2022-06-11 10:15:50.478571
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import collections
    import os
    import sys
    import unittest
    import yaml

    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.executor.task_executor import remove_omit
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

# Generated at 2022-06-11 10:16:00.946748
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins import ModuleLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVars

    include_file = "./test/include_test.yml"
    include_target = "./test/include_test_target.yml"
    include_target2 = "./test/include_test_target2.yml"

# Generated at 2022-06-11 10:16:12.921168
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))))
    from collections import namedtuple
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task

    class FakeIterator:
        def __init__(self):
            self._play = FakePlay()

    class FakePlay:
        def __init__(self):
            self._ds = dict()


# Generated at 2022-06-11 10:17:13.756539
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import ansible.playbook.role_include
    import ansible.playbook.task_include
    from ansible.vars.manager import VariableManager

    filename = '/path/to/file'
    args = {'a': 1, 'b': 2}
    vars = {'a': 1, 'b': 2}
    vars['b'] = 3 #Check for hash of dict
    task = ansible.playbook.task_include.TaskInclude()
    inc_file = IncludedFile(filename, args, vars, task)

    assert inc_file == inc_file # Equal to itself
    assert inc_file != None # Not equal to None
    assert inc_file != 'inc_file' # Not equal to an other type

    # 'TaskInclude' is a proxy class to 'Task'
    # 'IncludeRole'

# Generated at 2022-06-11 10:17:22.067738
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import unittest
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    import os

    # Defining a class that mimics the behavior of ansible.inventory.host.Host
    class Host:
        def __init__(self, name):
            self.name = name

    class TestIncludedFile(unittest.TestCase):
        def setUp(self):
            self.context = PlayContext()
            self.context._play = Play.load({}, variable_manager=None, loader=None)
            self.context._play._basedir = os.getcwd()
            self.results = []

        def add_result(self, res):
            self.results.append(res)

        def test_simple_result(self):
            host = Host('localhost')

# Generated at 2022-06-11 10:17:33.894838
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()

    task1 = Task()
    task2 = Task()
    task3 = Task()

    task1.loop = 'loop_one'
    task2.loop = 'loop_one'
    task3.loop = 'loop_two'

    task1.context = context
    task2.context = context
    task3.context = context

    file1 = IncludedFile('path/to/file', 'args', 'vars', task1)
    file2 = IncludedFile('path/to/file', 'args', 'vars', task1)
    file3 = IncludedFile('path/to/file', 'args', 'vars', task1)
