

# Generated at 2022-06-11 10:08:22.205429
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    i1 = IncludedFile("test1.yml", None, None, None)
    try:
        i1.add_host("localhost")
    except ValueError:
        assert False, "Add first host failed"

    try:
        i1.add_host("localhost")
        assert False, "Add duplicate host should have failed"
    except ValueError:
        pass

    # Now test the __eq__ method
    i2 = IncludedFile("test1.yml", None, None, None)
    assert i1 == i2, "Included file matching failed"

    i3 = IncludedFile("test2.yml", None, None, None)
    assert i1 != i3, "Included file matching failed"

# Generated at 2022-06-11 10:08:33.903364
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Using a fake iterator and loader to test method process_include_results
    # (method process_include_results uses iterator, loader and AnsibleError)
    class FakeIterator:
        def __init__(self):
            self._play = FakePlay()
    class FakeLoader:
        def get_basedir(self):
            return "basedir"
        def path_dwim(self, include):
            # path_dwim calls os.path.exists()
            return include
        def path_dwim_relative(self, basedir, *a, **kw):
            return "relativedir/%s" % '/'.join(a)
    class FakeVariableManager:
        def __init__(self, hostvars):
            self._hostvars = hostvars

# Generated at 2022-06-11 10:08:42.360598
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    lst = []
    x = IncludedFile(None, None, None, None)
    x.add_host('localhost')
    x.add_host('remote')
    lst.append(x)

    y = IncludedFile(None, None, None, None)
    y.add_host('remote')
    y.add_host('localhost')
    lst.append(y)

    assert len(lst) == 1
    assert lst[0]._hosts == ['localhost', 'remote']

    try:
        y.add_host('remote')
        assert False, "The add_host method should have failed"
    except ValueError:
        pass

    z = IncludedFile(None, None, None, None)
    z.add_host('remote')
    lst.append(z)


# Generated at 2022-06-11 10:08:53.902683
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    t1 = TaskInclude()
    t1._role_name="role1"
    t1._parent= "p"

    t2 = TaskInclude()
    t2._role_name="role1"
    t2._parent= "p"

    t3 = TaskInclude()
    t3._role_name="role2"
    t3._parent= "p"

    t4 = TaskInclude()
    t4._role_name="role1"
    t4._parent= "q"

    t5 = TaskInclude()
    t5._role_name="role1"
    t5._parent= "p"
    t5._args = "arg1"

    f1 = IncludedFile("f", "arg", "var", t1)

# Generated at 2022-06-11 10:09:05.685203
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    result = []
    results = []
    # set up results
    res_hosts = ['A', 'B', 'C']
    res_vars = {'include': 'foo.yml', 'include_args': {'a': 'A'}}
    res_path = '/home/A/playbooks/foo.yml'
    res_uuid = 'bbccddee'
    res_action = 'include'
    res_play = 'play'
    res_task = 'task'
    for rh in res_hosts:
        res = {}
        res['_host'] = rh
        res['_result'] = res_vars
        res['_task'] = {}
        res['_task']['args'] = res_vars

# Generated at 2022-06-11 10:09:12.469801
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():

    import copy
    import pytest

    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole

    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager

    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude

    sample_host = 'testhost.example.org'
    sample_host_group = 'testhostgroup'
    sample_host_name = 'testhost'
    sample_host_address = '127.0.0.1'

    sample_

# Generated at 2022-06-11 10:09:25.174700
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # This is not a unit test as we are not testing any class, but a method
    # of class IncludedFile
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_helpers import TaskResult
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import module_loader

# Generated at 2022-06-11 10:09:34.095487
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    hosts = inventory.get_hosts()

# Generated at 2022-06-11 10:09:43.611721
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host

    def task(host, name):
        return Task(host=host, name=name)


    filename = '/tmp/file'
    args = {'a': 'b'}
    vars = {'a': 'b'}
    t = task(Host('localhost'), 't')

    i1 = IncludedFile(filename, args, vars, t)
    i2 = IncludedFile(filename, args, vars, t)
    i3 = IncludedFile(filename, args, dict(args), t)

    assert i1 == i2
    assert not i1 == i3

# Generated at 2022-06-11 10:09:53.434044
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    loader = None
    iterator = Play().set_loader(loader)
    variable_manager = VariableManager(loader=loader, play=iterator._play)
    task = TaskInclude().load({})


# Generated at 2022-06-11 10:10:43.996046
# Unit test for method __eq__ of class IncludedFile

# Generated at 2022-06-11 10:10:53.410804
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_result import TaskResult

    class TestIterator:
        def __init__(self, play):
            self._play = play

    class TestPlay:
        def __init__(self):
            self.name = 'testPlay'

    class TestTask:
        def __init__(self, action, loop=False, role=None, parent=None, from_files=dict(), role_name=None, no_log=False):
            self.action = action
            self.loop = loop
            self._role = role
            self._parent = parent
            self._from_files = from_files
            self._role_name = role_name
            self.no_log = no_log

# Generated at 2022-06-11 10:11:06.522598
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    loader1 = None
    variable_manager1 = None
    itertask1 = None
    display1 = None
    # Construct a task
    task1 = Task()
    task1._uuid = 'a3cf5d5e-a5d5-4ad5-b2f8-86e760bfe6c9'

    # Construct a task
    task2 = Task()
    task2._uuid = 'a3cf5d5e-a5d5-4ad5-b2f8-86e760bfe6c9'

    # Construct a IncludeRole
    includerole1 = IncludeRole()

# Generated at 2022-06-11 10:11:15.467398
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

    task1 = TaskInclude("/foo/bar", {}, {}, None)
    task2 = TaskInclude("/foo/bar", {}, {}, None)
    task3 = TaskInclude("/foo/bar", {}, {}, None)

    assert task1 == task2
    assert task1 == task3
    assert task2 == task3

    task1 = TaskInclude("/foo/bar", {'_raw_params': "foo"}, {}, None)
    task2 = TaskInclude("/foo/bar", {'_raw_params': "foo"}, {}, None)
    task3 = TaskInclude("/foo/bar", {'_raw_params': "foo"}, {}, None)



# Generated at 2022-06-11 10:11:26.519183
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = variable_manager._loader
    inventory = InventoryManager(loader=loader, sources=[])

    context = PlayContext()
    task1 = Task()
    task1._uuid = 'a'
    task1._parent = 'b'
    task1.vars = {}
    task2 = Task()
    task2._uuid = 'a'
    task2._parent = 'b'
    task2.vars = {}
    include_file1 = IncludedFile('a/b', 'c', 'd', task1)

# Generated at 2022-06-11 10:11:27.621164
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO: fix unit test
    pass

# Generated at 2022-06-11 10:11:39.401702
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    class Host():

        def __init__(self, name):
            self.name = name

        def __eq__(self, other):
            return (other.name == self.name)

        def get_name(self):
            return self.name

    class Task():

        def __init__(self):
            self._uuid = 0

        def _get_parent(self):
            return None

    class Result():

        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result

        @staticmethod
        def get_host(self):
            return self._host

        @staticmethod
        def get_task(self):
            return self._task

        @staticmethod
        def get_result(self):
            return self._result

   

# Generated at 2022-06-11 10:11:51.610051
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    def _create_object(**kwargs):
        class TestTask(Task):
            pass

        task = TestTask()
        task._role = kwargs.get('_role')
        task._role_name = kwargs.get('_role_name', kwargs.get('_role'))


# Generated at 2022-06-11 10:12:02.958605
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    # No result, no included files
    results = []
    included_files = IncludedFile.process_include_results(results, None, None, None)
    assert len(included_files) == 0

    # Results with no include_result, no included files
    # Use a variable manager
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Block -> Play -> Playbook -> Role
    block = Block(parent_block=None, role=None, task_include='foo')

# Generated at 2022-06-11 10:12:05.226676
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult

    # test static method process_include_results of class IncludedFile
    pass
    # TODO

# Generated at 2022-06-11 10:13:10.706593
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.plugins.loader as plugin_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import ansible.playbook.play
    import ansible.playbook.task
    import os

    output = None
    current_dir = os.path.dirname(__file__)
    my_play_dir = os.path.join(current_dir, 'data', 'files', 'play1')

    # Create a minimal play to use for testing
    play = ansible.playbook.play.Play()
    hostname = "host1"
    my_play = ansible.playbook.play.Play()
    my_play.hosts = [hostname]
    play.hosts = [hostname]
    play.name = "Test play"

    # set loader and variable_manager

# Generated at 2022-06-11 10:13:21.214813
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)

    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = {
        "myvar": "myvalue",
    }

    class TestInclude:
        def __init__(self, args):
            self.args = args

    class TestTask:
        def __init__(self, parent, action, args):
            self._parent = parent
            self.action = action
           

# Generated at 2022-06-11 10:13:32.702408
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    def test_results(results, iterator, loader, variable_manager, exp_files):
        got_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
        assert len(got_files) == len(exp_files), 'got: %s, expected: %s' % (len(got_files), len(exp_files))
        for idx in range(len(exp_files)):
            assert got_files[idx] == exp_files[idx]
    # setup
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task

# Generated at 2022-06-11 10:13:43.369447
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.constants as C
    from ansible.executor.task_executor import TaskResult
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task

    host = Host("example")
    task = Task()
    results = [
        TaskResult(
            host=host,
            task=task,
            result=dict(
                _ansible_item_result=True,
                include=dict(
                    file1="./bar.yml"
                )
            )
        ),
        TaskResult(
            host=host,
            task=task,
            result=dict(
                _ansible_item_result=True,
                include=dict(
                    file2="./bar.yml"
                )
            )
        )
    ]

# Generated at 2022-06-11 10:13:52.823579
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """Test IncludedFile.__eq__

    :return:
    """
    # When
    obj1 = IncludedFile(filename="foo", args="bar", vars="baz", task="qux", is_role=True)
    obj2 = IncludedFile(filename="foo", args="bar", vars="baz", task="qux", is_role=True)
    obj3 = IncludedFile(filename="foo", args="bar", vars="baz", task="other", is_role=True)
    obj4 = IncludedFile(filename="foo", args="bar", vars="baz", task="qux", is_role=False)
    obj5 = IncludedFile(filename="foo", args="moo", vars="baz", task="qux", is_role=True)

# Generated at 2022-06-11 10:14:02.959018
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.errors import AnsibleError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import lookup_loader, action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a test play

# Generated at 2022-06-11 10:14:11.709966
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    import collections

    class Options(object):
        def __init__(self, verbosity):
            self.verbosity = verbosity
            self.connection = 'local'
            self.module_path = ''
            self.forks = 1
            self.become = None
            self.become_method = None
            self.become_user = None
            self.check = False
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self.syntax = None
            self.diff = False



# Generated at 2022-06-11 10:14:18.717491
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor import TaskQueueManager
    from ansible.plugins.loader import  find_plugins

    loader = DataLoader()

    extra_vars = {"test_var": "foo", "test_var2": "bar", "test_var3": "baz"}
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory("localhost"))
    variable_manager.extra_vars = extra_vars


# Generated at 2022-06-11 10:14:27.685532
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = IncludedFile.process_include_results([(1, 2, 'fake_include', {'a': 1, 'b': 2}),
                                                           (1, 2, 'fake_include', {'a': 1, 'b': 2}),
                                                           (1, 2, 'fake_include', {'a': 1, 'b': 3}),
                                                           (1, 3, 'fake_include', {'a': 1, 'b': 2}),
                                                           (1, 2, 'fake_include', {'a': 2, 'b': 2}),
                                                           (2, 2, 'fake_include', {'a': 1, 'b': 2})],
                                                          1,
                                                          1,
                                                          1)


# Generated at 2022-06-11 10:14:38.309201
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    Test IncludedFile.process_include_results()
    """
    class Host:
        name = "localhost"
    task_vars = {'omit':None}
    cache_key = (1, Host(), 1)
    task_vars_cache = {cache_key:task_vars}

    class Results:

        class _task:
            no_log = False
            action = 'include'
            loop = False
            def get_search_path(self):
                return []

        def __init__(self, result, _host, _task):
            self._result = result
            self._host = _host
            self._task = _task


# Generated at 2022-06-11 10:15:52.076454
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # test data
    hosts = ['a1', 'a2', 'a3']
    tasks = ['t1', 't2', 't3']

# Generated at 2022-06-11 10:16:02.175515
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Create an instance
    included_file = IncludedFile(
        filename='filename',
        args='args',
        vars={'vars': 'vars'},
        task={'task': 'task'}
    )

    # Test with different class
    assert included_file != 'other'

    # Test with equal
    other = IncludedFile(
        filename='filename',
        args='args',
        vars={'vars': 'vars'},
        task={'task': 'task'}
    )
    assert included_file == other

    # Test with different filename
    other = IncludedFile(
        filename='other',
        args='args',
        vars={'vars': 'vars'},
        task={'task': 'task'}
    )
    assert included_file != other

    # Test with

# Generated at 2022-06-11 10:16:14.211461
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.plugins.loader as plugin_loader
    import ansible.inventory.loader as inventory_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.context import context

    context.CLIARGS = CLI.base_parser(constants=C).parse_args(args=[])
    loader = DataLoader()
    inventory = inventory_loader.InventoryLoader(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 10:16:23.991176
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import unittest
    import os
    import sys

    class MockTask:
        def __init__(self, parent=None, action='include'):
            self._parent = parent
            self.action = action
            self.loop = None
            self.no_log = None
            self._uuid = 'uuid-%s' % id(self)
            self.FROM_ARGS = (
                'delegate_to_file',
                'delegate_facts_file',
                'vars_file',
                'vars_prompt_file',
                'defaults_file',
                'meta_file',
                'handlers_file',
                'tasks_file',
                'files_file'
            )
            self._from_files = {}
            self._role = None
            self._role_

# Generated at 2022-06-11 10:16:34.405306
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:16:44.654206
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    '''
    Tests the IncludedFile.process_include_results function
    '''

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins import callback_loader

    class ResultsCollectorForUT(object):
       """ This is a minimal ResultsCollector for use with the TaskQueueManager """
       def __init__(self, *args, **kwargs):
           self.host_ok = {}
           self.host_unreachable = {}

# Generated at 2022-06-11 10:16:55.948802
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import pytest

    results = [
        pytest.Mock(),
        pytest.Mock(),
        pytest.Mock(),
    ]
    results[0]._task.loop = True
    results[1]._task.loop = True
    results[2]._task.loop = False

    results[0]._task.action = 'include_tasks'
    results[1]._task.action = 'import_tasks'
    results[2]._task.action = 'import_playbook'


# Generated at 2022-06-11 10:17:06.494270
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    '''
    Test the method IncludedFile.process_include_results()
    '''
    import ansible.executor.task_result
    import ansible.parsing.dataloader
    import ansible.playbook.task
    import ansible.vars.manager

    dataloader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()

    res_0 = ansible.executor.task_result.TaskResult(
        host=ansible.inventory.host.Host('example.com'),
        task=ansible.playbook.task.Task(),
    )


# Generated at 2022-06-11 10:17:14.975290
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    from ansible.playbook.play_context import PlayContext

    loader = FakeLoader()
    variable_manager = FakeVariableManager()

    results = []

    # Create fake results with the Content of a real result file
    # Test the behaviour of include_tasks

# Generated at 2022-06-11 10:17:23.230050
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    import json

    # Create a fake Ansible task that has 3 results with the following include variables:
    #    include: roles/apache/tasks/main.yml  # role with target defined elsewhere
    #    include: "{{ item }}"                 # relative include with loop
    #    include: "{{ item }}"                 # relative include with loop