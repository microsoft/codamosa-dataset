

# Generated at 2022-06-11 10:08:24.151561
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 10:08:35.823047
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """
    Unit test for method __eq__ of class IncludedFile.
    """
    included_file_1 = IncludedFile('/root/ansible/filename', '1', '2', '3')
    included_file_2 = IncludedFile('/root/ansible/filename', '1', '2', '3')
    included_file_3 = IncludedFile('/root/ansible/filename_1', '1', '2', '3')
    included_file_4 = IncludedFile('/root/ansible/filename', '1_1', '2', '3')
    included_file_5 = IncludedFile('/root/ansible/filename', '1', '2_2', '3')
    included_file_6 = IncludedFile('/root/ansible/filename', '1', '2', '3_3')
    included_

# Generated at 2022-06-11 10:08:46.788595
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.plugins.loader import find_plugin_filepaths, get_all_plugin_loaders, get_all_plugin_paths

    def include_result_factory(host, included_file, loop_var=None, index_var=None):
        task = Task()
        task.action = 'include_tasks'
        result = TaskResult(host, task)
        result._result = {
            'include': included_file,
            'include_args': {},
        }
        if loop_var:
            result._result['ansible_loop_var'] = loop_var

# Generated at 2022-06-11 10:08:58.313256
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import unittest
    import ansible.utils.vars
    import ansible.utils.unsafe_proxy
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    class TestIncludeFile(unittest.TestCase):

        def setUp(self):
            self.loader = DataLoader()
            self.variable_manager = VariableManager()
            self.inventory = ansible.utils.vars.Aggregator(loader=self.loader, variables=self.variable_manager)



# Generated at 2022-06-11 10:09:08.839160
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import mock
    import pprint

    class Task:
        def __init__(self, action):
            self.action = action
            self.loop = False
            self.role_name = None
            self.args = { '_raw_params' : "{{myfile}}"}

        def copy(self):
            return Task(self.action)

    class Result:
        def __init__(self, task, host, result):
            self._task = task
            self._host = host
            self._result = result

    class Play:
        pass

    class Host:
        pass


# Generated at 2022-06-11 10:09:09.603186
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-11 10:09:22.492670
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import copy

    loader = DictDataLoader({
        "dir1/dir2/dir3/": [
            'file1.yml',
            'file2.yml',
            'file3.yml',
            'file4.yml',
            'file5.yml',
            'file6.yml'
        ]
    })

    class Host(object):

        def __init__(self, name):
            self.name = name
            self._vars = dict()
            self._fact_cache = dict()

        def get_vars(self):
            return self._vars

        def set_variable(self, k, v):
            self._vars[k] = v

        def get_fact(self, key):
            return self._fact_cache[key]


# Generated at 2022-06-11 10:09:32.559350
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:09:33.487737
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Placeholder
    assert True

# Generated at 2022-06-11 10:09:44.568599
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 10:10:11.736326
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task1 = TaskInclude('fake1')
    task2 = TaskInclude('fake2')
    include_file1 = IncludedFile('filename', dict(a='b'), dict(c='d'), task1)
    include_file2 = IncludedFile('filename', dict(a='b'), dict(c='d'), task2)
    include_file3 = IncludedFile('filename', dict(a='b'), dict(c='d'), task2)
    include_file4 = IncludedFile('filename', dict(a='b'), dict(c='e'), task1)
    assert include_file1 != include_file2
    assert include_file2 == include_file3
    assert include_file1 != include_file3
    assert include_file1 != include_file4

# Generated at 2022-06-11 10:10:23.420232
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.manager import VariableManager

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = loader.load_from_file("tests/inventory", "")

    play_context = PlayContext(remote_addr='127.0.0.1')
    tqm = None
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 10:10:36.702706
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import pytest
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    hosts = [
        'test_host_1',
        'test_host_2'
    ]


# Generated at 2022-06-11 10:10:48.325471
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = None

    pbex = PlaybookExecutor(loader=loader,
                            inventory=None,
                            variable_manager=None,
                            loader_iterator=None)

    results = [None] * 4
    results[0] = pbex.TaskResult(host=pbex.get_host_record('localhost'),
                                 task=pbex.get_task_object('include_tasks'),
                                 return_data=dict(include='foo.yml'))
    results[1] = pbex.TaskResult(host=pbex.get_host_record('localhost'),
                                 task=pbex.get_task_object('include_tasks'),
                                 return_data=dict(include='foo.yml'))


# Generated at 2022-06-11 10:10:58.911745
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.utils.vars import combine_vars
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import callback_loader

    import ansible.constants as C

    names = ["localhost", "foobar", "localhost2"]
    iterator = PlayIterator(names)
    loader = iterator.loader


# Generated at 2022-06-11 10:11:10.427734
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    context = {}
    context['loader'] = DataLoader()
    context['variable_manager'] = VariableManager()
    context['variable_manager'].extra_vars = {'role_name': 'foobar'}
    context['playbook_dir'] = '/etc/ansible/roles'

    host = 'foobar'
    task = dict(
        name='include role',
        hosts=host,
        gather_facts='no',
        roles=['foobar'],
    )
    tasks = [dict(action=task, tags=[], any_errors_fatal=False, when=None)]

# Generated at 2022-06-11 10:11:20.793707
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor import task_queue_manager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    # pylint: disable=line-too-long

    # test execution results

# Generated at 2022-06-11 10:11:24.903553
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # TODO: write proper unit test for method __eq__ of class IncludedFile
    # Possible approach:
    #   - Create mocks for args, vars, task
    #   - call __eq__(other)
    #   - check if results are correct
    pass



# Generated at 2022-06-11 10:11:27.096250
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Used in: test/units/playbook/test_task_include.py
    return (IncludedFile.process_include_results)

# Generated at 2022-06-11 10:11:38.971495
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from unittest import TestCase
    from ansible.mock import patch, MagicMock
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler

    class TestIncludeFile_process_include_results(TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-11 10:12:34.430192
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    item_role_included = IncludedFile('filename', 'args', 'vars', 'task', True)
    item_task_included = IncludedFile('filename', 'args', 'vars', 'task', False)

    # check for role for true result
    item = IncludedFile('filename', 'args', 'vars', 'task', True)
    expected_result = True
    result = item.__eq__(item_role_included)
    assert result == expected_result

    # check for role for false result
    item = IncludedFile('filename1', 'args', 'vars', 'task', True)
    expected_result = False
    result = item.__eq__(item_role_included)
    assert result == expected_result

    # check for task for true result

# Generated at 2022-06-11 10:12:43.249705
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    iterator = None
    loader = None
    variable_manager = None

    included_files = IncludedFile.process_include_results(
        [
            {
                'invocation': {
                    'module_args': {
                        'an_arg': 'a_value'
                    }
                },
                'changed': False,
                'failed': False,
                'item': 'a_value',
                'include': 'another_file.yml',
                'include_args': {
                    'an_arg': 'another_value'
                }
            }
        ],
        iterator, loader, variable_manager
    )

    assert included_files[0]._args == {'an_arg': 'another_value', '_ansible_item_label': 'a_value'}

# Generated at 2022-06-11 10:12:54.558806
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.task_vars import TaskVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-11 10:13:05.403548
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.stats import AggregateStats
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DictDataLoader()
    variable_manager = VariableManager()

    results = []
    included_files = []
    task_vars_cache = {}

    hosts = ['host1', 'host2']

# Generated at 2022-06-11 10:13:14.974210
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.plugins import callback_loader
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars

    display = Display()
    loader = DataLoader()
    display.verbosity = 3
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 10:13:25.697140
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    results = list()
    results.append(Result(host=Host('localhost'), task=Task(), result=dict(include='a.yml')))
    results.append(Result(host=Host('localhost'), task=Task(), result=dict(include='a.yml')))
    results.append(Result(host=Host('localhost'), task=Task(), result=dict(include='b.yml')))
    results

# Generated at 2022-06-11 10:13:38.020990
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    class ansible_result:
        def __init__(self, _host, _task, _result):
            self._host = _host
            self._task = _task
            self._result = _result

    class task:
        def __init__(self, action, loop):
            self.action = action
            self.loop = loop

    class play:
        def __init__(self):
            pass

    class iterator:
        def __init__(self, _play):
            self._play = _play

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()

    host = '127.0.0.1'

# Generated at 2022-06-11 10:13:46.525575
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import variable_manager_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import is_special_var

    import json

    # set up a fake loader and inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=variable_manager_loader, inventory=inventory)

    # set up a new play

# Generated at 2022-06-11 10:13:56.509247
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    class BasePlayContext:
        def __init__(self):
            self.connection = None
            self.remote_addr = None
            self.password = None
            self.port = None
            self.timeout = None
            self.private_key_file = None
            self.timeout = C.DEFAULT_TIMEOUT
            self.new_stdin = None
            self.connection_user = None
            self.become = False
            self.become_method = 'sudo'
            self.become_user = None
           

# Generated at 2022-06-11 10:14:05.796481
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """
    Test __eq__ method of class IncludedFile
    """

    def _make_task(module_name, args, uuid):
        """
        Return an object appearing to be a task.
        """
        from ansible.playbook.task import Task
        from ansible.playbook.block import Block
        task = Task()
        task._attributes = dict(action=module_name, uuid=uuid, args=args)
        task._parent = Block(uuid='parent_uuid')
        return task

    def _check(foo, bar, is_equal):
        """Utility func to check two IncludedFile objects for equality"""
        if is_equal:
            assert foo == bar
            assert bar == foo
        else:
            assert foo != bar
            assert bar != foo


# Generated at 2022-06-11 10:15:40.099753
# Unit test for method __eq__ of class IncludedFile

# Generated at 2022-06-11 10:15:51.331839
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # case 1: no results
    result = IncludedFile._process_include_results(
        results = [],
        iterator = None,
        loader = None,
        variable_manager = None
    )
    assert len(result) == 0

    # case 2: one result without 'skipped' and 'failed'

# Generated at 2022-06-11 10:16:01.571690
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # test_i_f_p_i_r_01
    import ansible.executor.task_result
    import ansible.playbook.task
    import ansible.template.template
    import ansible.template.vars
    import ansible.vars.hostvars
    import tempfile
    import ansible.playbook.task_include
    import ansible.playbook.task_include
    import ansible.utils.plugin_docs
    import ansible.utils.unsafe_proxy
    import os
    import ansible.vars.hostvars
    import ansible.module_utils.six.moves.StringIO
    import shutil
    import jinja2
    import sys

    #inputs

# Generated at 2022-06-11 10:16:13.475020
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:16:23.070241
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # Test setup
    loader = DictDataLoader({
        "A.yml": "",
        "B.yml": "",
        "roles/C/tasks/main.yml": ""
    })
    display = Display()
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader))
    iterator = PlayIterator(Inventory(hosts=[Host('hostname')]), variable_manager=variable_manager)
    iterator.get_next_task = lambda: TaskInclude('name', dict(include='A.yml'))
    iterator._play = Play().load(dict(
        name='test play',
        hosts=['hostname'],
        roles=['C']
    ), variable_manager=variable_manager, loader=loader)

    result = Result()
    result

# Generated at 2022-06-11 10:16:33.379668
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_results = []
    handler_results = []
    class result(object):
        def __init__(self, include_result, task, host):
            self._result = include_result
            self._task = task
            self._host = host

    class task(object):
        def __init__(self, action, parent, loop=False, _role=False, no_log=False):
            self.action = action
            self._parent = parent
            self.loop = loop
            self._role = _role
            self._from_files = dict()
            self.no_log = no_log

    class role(object):
        def __init__(self, role_path):
            self._role_path = role_path

    class play(object):
        def __init__(self, basedir):
            self._

# Generated at 2022-06-11 10:16:43.484271
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class DummyRole:
        def __init__(self):
            self.name = "dummy_role"
            pass

        def get_path(self):
            return "dummy_path"

        def get_vars(self):
            return None

    class DummyTask:
        def __init__(self):
            self.role = DummyRole()
            self.action = 'include'
            self.loop = False
            self.args = {}

    class DummyData:
        def __init__(self, host, task, result):
            self.host = host
            self.task = task
            self.result = result

    # First test

# Generated at 2022-06-11 10:16:54.265021
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys
    import io
    import textwrap
    import json
    import unittest
    import tempfile

    from ansible.executor.task_result import TaskResult
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile
    from ansible.vars.manager import VariableManager

    from .test_playbook_executor import TestPlaybookExecutor

    class TestTaskResult(TaskResult):

        def __init__(self, host, task, result, included_files=[]):
            self._host = host
            self._task

# Generated at 2022-06-11 10:17:05.465301
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    # IncludedFile(filename, args, vars, task, is_role=False):
    included_file_0 = IncludedFile('/tmp/ttt', {'a': 'b'}, {'c': 'd'}, 'task', False)
    included_file_1 = IncludedFile('/tmp/ttt', {'a': 'b'}, {'c': 'd'}, 'task', False)
    included_file_2 = IncludedFile('/tmp/ttt', {'a': 'b'}, {'c': 'e'}, 'task', False)
    included_file_3 = IncludedFile('/tmp/ttt', {'a': 'e'}, {'c': 'd'}, 'task', False)

# Generated at 2022-06-11 10:17:13.994594
# Unit test for method process_include_results of class IncludedFile