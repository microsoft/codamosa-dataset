

# Generated at 2022-06-11 10:08:10.356508
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # CASE 1: Two files are equals
    filename1 = "path/to/file1.yml"
    args1 = {
        "from_file1": "path/to/from_file1.yml",
        "from_file2": "path/to/from_file2.yml"
    }
    vars1 = {
        "from_file1": "from_file1.yml",
        "from_file2": "from_file2.yml"
    }
    task1 = "mytask1"
    included_file1 = IncludedFile(filename1, args1, vars1, task1)

    filename2 = "path/to/file1.yml"

# Generated at 2022-06-11 10:08:23.114912
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import unittest2 as unittest

    class TestIncludedFileProcessIncludeResults(unittest.TestCase):

        def setUp(self):
            self.inc_file = IncludedFile("/tmp/foo", 'bar', 'baz', 'qux')
            self.mock_result = MockResult()
            self.mock_result._result = {'include': 'test_include'}

        def test_process_include_results_returns_list(self):
            self.assertIsInstance(IncludedFile.process_include_results([], MockIterator(), MockLoader(), MockVariableManager()), list)

        def test_process_include_results_returns_list_of_included_files(self):
            results = [self.mock_result, self.mock_result]
            included_files = IncludedFile

# Generated at 2022-06-11 10:08:30.198914
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    IncludedFile_process_include_results_test1()
    IncludedFile_process_include_results_test2()
    IncludedFile_process_include_results_test3()
    IncludedFile_process_include_results_test4()
    IncludedFile_process_include_results_test5()
    IncludedFile_process_include_results_test6()
    IncludedFile_process_include_results_test7()
    IncludedFile_process_include_results_test8()
    return


# Generated at 2022-06-11 10:08:40.295931
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # the __eq__ function of class IncludedFile is used in __contains__ function
    # of list and set, so we use this test to verify the __eq__ function works well
    host1 = 'host1'
    host2 = 'host2'
    ifile = IncludedFile('filename', {}, {}, None)
    ifile.add_host(host1)
    assert host1 in ifile._hosts
    ifile.add_host(host1)
    assert len(ifile._hosts) == 1
    ifile.add_host(host2)
    assert len(ifile._hosts) == 2
    assert host2 in ifile._hosts
    # raise an exception by adding an existed host

# Generated at 2022-06-11 10:08:52.194645
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import ansible.playbook.task
    import ansible.utils.vars
    import ansible.vars.manager
    import ansible.vars.unsafe_proxy
    import tests.unit.utils as utils

    a1 = IncludedFile(filename='/test/file1.yml', args={'a':'b'}, vars={'c':'d'},
        task=ansible.playbook.task.Task())
    a2 = IncludedFile(filename='/test/file1.yml', args={'a':'b'}, vars={'c':'d'},
        task=ansible.playbook.task.Task())

# Generated at 2022-06-11 10:09:04.120660
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    # create TaskResult objects
    tres1 = TaskResult(host="myhost", task=Task(), return_data={'results':[{'include':'test.yml', 'include_args':{'testarg':'test'}}]})
    tres2 = TaskResult(host="myhost2", task=Task(), return_data={'results':[{'include':'test2.yml', 'include_args':{'testarg':'test2'}}]})

# Generated at 2022-06-11 10:09:12.616147
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole

    class Options:
        connection = 'local'

    class Results:
        def __init__(self, _host, _task, _result, _task_result=None):
            self._host = _host
            self._task = _task
            self._result = _result
            self._task_result = _

# Generated at 2022-06-11 10:09:25.336122
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import _serialize_prepared_vars, _serialize_facts
    from ansible.errors import AnsibleParserError

    class FakeDisplay(object):
        def __init__(self):
            self.deprecation_warnings = []

        def display(self, msg, *args, **kwargs):
            pass


# Generated at 2022-06-11 10:09:34.181718
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """Tests if the process_include_results method of class IncludedFile works as intended."""
    import sys
    if sys.version_info[0] == 2:
        import mock
    else:
        from unittest import mock
    from ansible.executor.task_result import TaskResult
    class FakePlay(object):
        pass
    class FakeHost(object):
        pass
    class FakeTask(object):
        def __init__(self):
            self._uuid = ''
            self._parent = None
            self.action = ''
        def copy(self):
            return FakeTask()
    class FakeIterator(object):
        def __init__(self):
            self._play = FakePlay()
    class FakeVariableManager(object):
        def get_vars(self, **kwargs):
            return dict()


# Generated at 2022-06-11 10:09:45.285583
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins import module_loader

    # define an include task for the first task
    # TODO: this needs to be mocked as we are testing against actual modules ...
    task = Task()
    task.action = 'include'
    task.args = {
            '_raw_params': 'test_playbooks/playbook_include/test_playbook_1.yml',
            '_uses_delegate_facts': False,
            '_ansible_check_mode': False,
            '_ansible_debug': False,
            '_ansible_diff': False
    }
    task.set_loader(module_loader)

    # first include results


# Generated at 2022-06-11 10:10:07.102132
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    loader = C.get_config_loader()
    variable_manager = VariableManager()

    hosts = ["localhost", "127.0.0.1", "127.0.0.1"]

# Generated at 2022-06-11 10:10:20.679871
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Create object with all attibutes equal
    task = TaskInclude(None)
    task._role = None
    task._parent = None
    task._uuid = '4b4b4b4b4b4b4b4b4b4b4b4b4b4b4b4b'
    task.action = 'include_tasks'
    task.args = dict()
    task.deprecated_args = dict()
    inc = IncludedFile('test/test_file.yml', dict(), dict(), task)
    inc2 = IncludedFile('test/test_file.yml', dict(), dict(), task)
    res = inc.__eq__(inc2)
    assert res

    # Create object with all attibutes equal except task id
    task2 = TaskInclude(None)
    task2._role

# Generated at 2022-06-11 10:10:30.480903
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    #Test the include_result variable
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'none'

    tqm = None

    task_vars = dict(
        playbook_dir='/path/to/playbook/dir',
        inventory_dir='/path/to/inventory/dir'
    )

    loader = None
    variable_manager = None

    #Test the include_result variable

# Generated at 2022-06-11 10:10:43.167951
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = []

    class Result:
        def __init__(self, host, task, result):
            self.__host = host
            self.__task = task
            self.__result = result

        @property
        def _host(self):
            return self.__host

        @property
        def _task(self):
            return self.__task

        @property
        def _result(self):
            return self.__result

    class Task:
        def __init__(self, parent, no_log, action, loop):
            self.__parent = parent
            self.__action = action
            self.__no_log = no_log
            self.__loop = loop

        @property
        def _parent(self):
            return self.__parent


# Generated at 2022-06-11 10:10:53.018662
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.utils.vars as ansible_vars
    from ansible.vars.manager import VariableManager

    playbook = None
    host = None
    task = None
    variables = {}
    variable_manager = VariableManager(loader=None, inventory=None, variable_manager=None, all_vars=variables)
    variable_manager._fact_cache = {}
    variable_manager.extra_vars = variable_manager.get_vars(play=playbook, host=host, task=task)
    variable_manager.options_vars = variable_manager.get_vars(play=playbook, host=host, task=task)
    var = ansible_vars.VarsModule()

# Generated at 2022-06-11 10:11:06.166320
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_args_1 = {'a': 'b'}
    test_vars_1 = {'c': 'd'}
    test_vars_2 = {'c': 'd', 'e':'f'}
    
    test_included_task1 = TaskInclude(action='include', args={'_raw_params':'test_file1'})
    test_included_task2 = TaskInclude(action='include', args={'_raw_params':'test_file2'})
    test_included_task3 = TaskInclude(action='include', args={'_raw_params':'test_file1'})
    test_included_task4 = TaskInclude(action='include', args={'_raw_params':'test_file2'})


# Generated at 2022-06-11 10:11:15.219709
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    host = Host("localhost")

# Generated at 2022-06-11 10:11:26.249279
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # pylint: disable=redefined-outer-name
    from ansible import constants as C
    from ansible.utils.display import Display
    from ansible.template import Templar
    from ansible.vars.reserved import Reserved
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext # pylint: disable=unused-variable
    from ansible.playbook.play import Play # pylint: disable=unused-variable
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-11 10:11:38.177861
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult

    # input_data example
    #
    # [
    #   {
    #     '_ansible_item_label': u'example',
    #     '_ansible_no_log': False,
    #     '_ansible_verbose_always': True,
    #     'changed': True,
    #     'failed': False,
    #     'invocation': {
    #       'module_args': {
    #         '_raw_params': u'directory=test1 file=test2',
    #         'file': u'test2',
    #         'directory': u'test1'
    #       }
    #     },
    #     'item': u'example',
    #     'stdout': u'',
    #

# Generated at 2022-06-11 10:11:40.872441
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file1 = IncludedFile('/tmp/a', None, None, None)
    included_file2 = IncludedFile('/tmp/a', None, None, None)
    assert included_file1 == included_file2

# Generated at 2022-06-11 10:12:08.492575
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor import task_result
    from ansible.plugins.loader import vars_loader

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    class StubTask:
        class StubPlay:
            PLAYBOOK_VARS = {}
            PARSED_HOSTS = ['stub-host']

        def __init__(self, no_log=False, parent=None, loop=False, action=None):
            self._parent = parent
            self.no_log = no_log
            self.loop = loop
            self.action = action
            self._play = self.StubPlay()

# Generated at 2022-06-11 10:12:14.944802
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import pytest
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils._text import to_text

    result_list = []
    result_list.append(TaskResult(host=None, task=None, 
        result={u'ansible_loop_var': u'item', u'ansible_index_var': u'item_3', u'item': u'secret-include.yml'}))
    result_list.append(TaskResult(host=None, task=None, 
        result={u'ansible_loop_var': u'item', u'ansible_index_var': u'item_4', u'item': u'../common/tasks/access.yml'}))

# Generated at 2022-06-11 10:12:27.957226
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json

    def __traceback_info(res):
        return res._host.name + ',' + res._task.action + ',' + res._task.args['include']

    class Mock(object):
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-11 10:12:32.727401
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import warnings
    warnings.simplefilter("ignore")

    # create a mock Result object
    class Result:
        def __init__(self):
            self._host = "myhost"
            self._task = "mytask"
            self._result = {}

        def __repr__(self):
            return "Result(host=%s,task=%s,result=%s)" % (self._host, self._task, self._result)

    # create a mock Task object
    class Task:
        def __init__(self, action, loop=False, no_log=False, parent=None, role=None, role_name=None, _from_files=None):
            self.action = action
            self.loop = loop
            self.no_log = no_log
            self._parent = parent

# Generated at 2022-06-11 10:12:39.518125
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    import ansible.plugins.loader

    class FakeTask:
        def __init__(self, action, parent=None):
            self.action = action
            self._parent = parent

    class FakeIterator:
        def __init__(self, play):
            self._play = play

    def _fake_variable_manager_get_vars(self, play=None, host=None, task=None):
        return self._variables


# Generated at 2022-06-11 10:12:50.690142
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.executor.task_result import TaskResult

    display = Display()
    variable_manager = VariableManager()
    loader = variable_manager._loader


# Generated at 2022-06-11 10:13:02.183367
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    '''
    This is an example of how to call IncludedFile.process_include_results.
    This method is used by the plugin callback to calculate which files
    were included.
    For the setup of this test, see test/unit/plugins/callbacks/test_plugin_callback_json.py:
    test_include_role_tasks, test_include_tasks and test_include_handlers
    '''
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class MockPlay(object):
        def __init__(self):
            self.hostvars = dict()
            self._vars_cache = dict()

    class MockTask(object):
        def __init__(self, action):
            self._role

# Generated at 2022-06-11 10:13:10.843462
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from collections import namedtuple

    class FakeTask(object):
        def __init__(self):
            self._role_name = None
            self._from_files = dict

# Generated at 2022-06-11 10:13:21.426947
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # Import necessary classes
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Create a loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    loader.set_basedir("test/test_include_results")

    # Create a variable manager
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager._extra_vars = {'omit': "OMITTED"}

    # Create an iterator
    from ansible.executor.task_iterator import TaskIterator
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()

# Generated at 2022-06-11 10:13:33.038175
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Setup test
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.executor.task_result import TaskResult

    loader = None
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(variable_manager.get_vars(loader=loader, play=Play().load(dict(), variable_manager=variable_manager)))

    # Test

# Generated at 2022-06-11 10:14:24.142074
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class MockIncludeResult:
        def __init__(self, result):
            self._result = result

    class MockTask:
        def __init__(self, action, no_log=False):
            self.action = action
            self.no_log = no_log

    class MockPlay:
        pass


# Generated at 2022-06-11 10:14:33.748910
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.executor.task_result as result
    import ansible.playbook.block as block
    from ansible.playbook.task import Task

    block = block.Block()
    block._play = 'play.yml'
    block.vars.update(dict(
        item1=dict(name='test_role1', var='item1'),
        item2=dict(name='test_role2'),
        item3=dict(name='test_role2', from_path='{{ base_role_path }}/test_role2/tasks'),
        item4=dict(name='test_role1', var='item4', omit='omit_token'),
        test_role2=dict(base_role_path='/foo/roles'),
    ))
    block.include_roles = block.resolve_

# Generated at 2022-06-11 10:14:45.829063
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # pylint: disable=import-error,unused-import,no-name-in-module
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.strategy import StrategyBase

    class TestStrategy(StrategyBase):
        def _run_task_internal(self, play_context, new_task, task_vars, host):
            pass

        def run(self):
            host = None
            play_context = PlayContext(play=self._play, options=self._play._options, passwords=None, connection_user=None)
            play_context.become = self._play.become
            play

# Generated at 2022-06-11 10:14:57.006172
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class FakeLoader():
        def __init__(self):
            self._basedir = '.'

        def get_basedir(self):
            return self._basedir

        def path_dwim(self, name):
            return os.path.join(self._basedir, name)

    class FakeTemplate():
        def __init__(self, src):
            self._src = src

        def template(self, name):
            return os.path.join(self._src, name)

    class FakeTask():
        def __init__(self):
            self._role_path = '.'

# Generated at 2022-06-11 10:15:10.208673
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import unittest
    import mock

    class MockClass:
        pass

    class TestIncludedFileMethods(unittest.TestCase):
        def test_process_include_results_no_results(self):
            mock_iterator = MockClass()
            mock_loader = MockClass()
            mock_variable_manager = MockClass()
            included_files = IncludedFile.process_include_results([], mock_iterator, mock_loader, mock_variable_manager)
            self.assertEqual([], included_files)

        def test_process_include_results_nonlist_results(self):
            mock_iterator = MockClass()
            mock_loader = MockClass()
            mock_variable_manager = MockClass()

# Generated at 2022-06-11 10:15:22.607709
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.parsing.dataloader
    import ansible.playbook.base
    import ansible.playbook.role_include
    import ansible.playbook.task_include
    import ansible.playbook.play
    import ansible.playbook.play_context
    loader = ansible.parsing.dataloader.DataLoader()
    fake_play = ansible.playbook.play.Play()
    fake_play.connection = 'local'
    fake_play.hosts = [ u'localhost' ]
    fake_play._variable_manager = ansible.playbook.play_context.VariableManager()
    fake_play._tqm = None # TODO: investigate that
    fake_play.post_validate({}, [])

    fake_include_role = ansible.playbook.role

# Generated at 2022-06-11 10:15:35.940078
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.playbook.task_include
    import ansible.playbook.role_include
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    # Fake a task result
    tr = TaskResult(host='localhost', task=IncludeRole())
    tr._result = {'failed': False, 'include_args': {}, 'include': '../../../data/test_include_role/test.yml'}
    tr._task._role_name = 'test_role'
    tr._task._role_path = 'data/test_include_role'
    tr._task._from_files = {'vars': 'data/test_include_role/vars/main.yaml'}

# Generated at 2022-06-11 10:15:41.995922
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    class FakeIncludedFile:
        def __init__(self, filename, args, vars, task, is_role=False):
            self._filename = filename
            self._args = args
            self._vars = vars
            self._task = task
            self._hosts = []
            self._is_role = is_role

        def add_host(self, host):
            if host not in self._hosts:
                self._hosts.append(host)
                return
            raise ValueError()


# Generated at 2022-06-11 10:15:43.914102
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO: how to test for this class since it relies on ansible.vars.manager?
    pass

# Generated at 2022-06-11 10:15:53.530057
# Unit test for method process_include_results of class IncludedFile