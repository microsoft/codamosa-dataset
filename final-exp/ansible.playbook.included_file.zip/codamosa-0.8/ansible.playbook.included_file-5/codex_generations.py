

# Generated at 2022-06-11 10:08:24.294117
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["tests/ansible/inventory/test_inventory"])
    variable_manager.set_inventory(inventory)
    inventory.clear_pattern_cache()

    playbook_results = list()
    play_context = PlayContext()
    play_context

# Generated at 2022-06-11 10:08:35.985790
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.plugins.loader import become_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    from unit_tests.mock.loader import DictDataLoader
    from unit_tests.mock.inventory import MockInventory
    from unit_tests.mock.vars import MockVarsModule
    from unit_tests.mock.playbook import MockPlaybook
    from unit_tests.mock.task import MockTask

    class MockOptions:
        def __init__(self):
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'

# Generated at 2022-06-11 10:08:45.806255
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Arrange
    filename1 = 'test_file1.yml'
    args1 = 'test_args1'
    vars1 = 'test_vars1'
    task1 = 'test_task1'

    filename2 = 'test_file2.yml'
    args2 = 'test_args2'
    vars2 = 'test_vars2'
    task2 = 'test_task2'

    # Act
    included_file1 = IncludedFile(filename1, args1, vars1, task1)
    included_file2 = IncludedFile(filename2, args2, vars2, task2)

    # Assert
    assert included_file1 != included_file2


# Generated at 2022-06-11 10:08:57.406600
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    context = PlayContext()
    play = Play().load({'name': 'test_IncludedFile___eq__', 'hosts': 'localhost'}, variable_manager=VariableManager(), loader=DataLoader())
    context._play = play
    block = Block()
    task = Task()
    task._role = None
    task._role_name = None
    task._

# Generated at 2022-06-11 10:09:08.206272
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.vars import VariableManager

    # create a fake iterator
    class FakeIterator(object):
        def get_basedir(self):
            return os.path.dirname(os.path.realpath(__file__))

    fake_play = FakeIterator()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'my_var': 'my_value'}

    # create a fake loader
    class FakeLoader(object):
        def get_basedir(self):
            return os.path.dirname(os.path.realpath(__file__))

        def path_dwim(self, included_file):
            return included_file

    loader = FakeLoader()

    # create fake results
    from ansible.executor.task_result import TaskResult

# Generated at 2022-06-11 10:09:20.999132
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # pylint: disable=import-error,unused-variable
    from ansible.executor import task_executor
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.vars.manager import VariableManager

    # load all plugins (so we get new LookupModule plugins for the scenario)
    [ get_all_plugin_loaders() ]

    # construct a play
    play = Play()

    # construct a play context
    play_context = PlayContext()
    play_context.become = play_context.become_method = None

# Generated at 2022-06-11 10:09:31.543266
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # When 3 parameters are the same, then two objects are equal.
    include_file = IncludedFile("filename1", "args1", "vars1", "task1")
    equal_include_file = IncludedFile("filename1", "args1", "vars1", "task1")
    assert include_file == equal_include_file

    # When 2 parameters are the same and one is different, then two objects are not equal.
    include_file = IncludedFile("filename1", "args1", "vars1", "task1")
    not_equal_include_file1 = IncludedFile("filename1", "args1", "vars2", "task1")
    assert include_file != not_equal_include_file1

    # When 1 parameter is the same and 2 are different, then two objects are not equal.
    include_file = IncludedFile

# Generated at 2022-06-11 10:09:41.304008
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.plugins.loader as plugin_loader

    loader = plugin_loader.get_loader()

    # pretend that we executed a task that included a file
    res = type('result', (object,), {'_host': 'fake_host', '_task': type('task', (object,), {'action': 'include', 'args': {'_raw_params': 'some_file.yml'}})})()
    res._result = {'include': 'some_file.yml', 'include_args': {'some_arg': 'some_value'}}

    # pretend that we executed a task that included a file with a var

# Generated at 2022-06-11 10:09:42.398573
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO
    pass

# Generated at 2022-06-11 10:09:47.089562
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile('foo', 'bar', 'baz', 'xyz')
    b = IncludedFile('foo', 'bar', 'xxx', 'xyz')
    c = IncludedFile('foo', 'bar', 'baz', 'xyz')

    assert not (a == b)
    assert a == c

# Generated at 2022-06-11 10:10:12.310951
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_executor import TaskResult
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.vars import VariableManager, HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory


# Generated at 2022-06-11 10:10:23.842872
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import pytest
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    a_host = '192.168.1.1'
    b_host = '192.168.1.2'
    a_host_loop = '192.168.1.3'
    a_host_dict = '192.168.1.4'

    variable_manager = VariableManager()
    loader = variable_manager._loader
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=[]))

# Generated at 2022-06-11 10:10:37.231374
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task

    play = object()
    host = object()
    task = Task()

    results = []
    result = TaskResult(host=host, task=task, return_data=dict(include='foo'))
    results.append(result)
    result = TaskResult(host=host, task=task, return_data=dict(include='foo'))
    results.append(result)
    result = TaskResult(host=host, task=task, return_data=dict(include='bar'))
    results.append(result)
    result = TaskResult(host=host, task=task, return_data=dict(include='bar'))
    results.append(result)

    included_files = IncludedFile.process_include_results

# Generated at 2022-06-11 10:10:38.387913
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO: more specific tests
    pass

# Generated at 2022-06-11 10:10:49.741192
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 10:11:01.288532
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    class AnsibleTestPlayContext(PlayContext):
        def __init__(self, inventory, variable_manager, loader, options, passwords):
            super(AnsibleTestPlayContext, self).__init__(inventory=inventory, variable_manager=variable_manager, loader=loader, options=options, passwords=passwords)

    class AnsibleTestPlay(object):
        def __init__(self, variable_manager):
            self._ds = dict()
            self._ds['hosts'] = 'all'
            self._ds['vars'] = dict()
            self._variable_manager = variable_manager
            self._variable_manager.set

# Generated at 2022-06-11 10:11:12.164877
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.vars.manager
    import ansible.utils.vars

    class MyRole:
        def __init__(self, path):
            self._role_path = path

    class MyIterator:
        def __init__(self, play):
            self._play = play

    class MyLoader:
        def __init__(self, basedir):
            self._basedir = basedir

        def get_basedir(self):
            return self._basedir

    class MyIncludeResult:
        def __init__(self, result, task, host):
            self._result = result
            self._task = task
            self._host = host


# Generated at 2022-06-11 10:11:23.310221
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:11:34.101858
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult

# Generated at 2022-06-11 10:11:43.728701
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # import the modules needed in the test
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task

    # mock up a task, host and loader for the call to IncludedFile.process_include_results
    mytask = Task()
    myhost = Host('foo')
    loader = mytask._loader

    # mock up the iterator needed by process_include_results
    class mock_play_context():
        def __init__(self):
            self.playbook = None
    class mock_iterator():
        def __init__(self):
            self._play = mock_play_context()
            self._play.playbook = 'myplaybook.yml'
    myiterator = mock_iterator()

    # mock up the variable_manager needed by

# Generated at 2022-06-11 10:12:18.924360
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    display.verbosity = 0
    class DummyHandler(object):
        pass
    handler = DummyHandler()
    handler.action = 'include_tasks'
    handler.loop = True
    del handler
    class DummyHost(object):
        def __init__(self, id):
            self.id = id
    def result_factory(host, handler, filename, args, vars, loop=False, parent=None):
        class DummyResult(object):
            pass
        result = DummyResult()
        result._host = host
        result._task = handler
        result.result = {'include': filename, 'include_args': args, 'ansible_loop_var': 'item', 'ansible_index_var': 'item_idx', 'ansible_item_label': 'item_label'}

# Generated at 2022-06-11 10:12:31.925263
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    first_IncludedFile = IncludedFile("filename", dict(a='b'), dict(c='d'), "task")
    included_file_same_filename_same_args_same_vars_different_task = IncludedFile("filename", dict(a='b'), dict(c='d'), "not_same_task")
    included_file_different_filename_same_args_same_vars_same_task = IncludedFile("not_same_filename", dict(a='b'), dict(c='d'), "task")
    included_file_same_filename_different_args_same_vars_same_task = IncludedFile("filename", dict(a='not_same_b'), dict(c='d'), "task")

# Generated at 2022-06-11 10:12:39.175742
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task

    # 1) test equality of two objects (obj1 == obj2)
    # objects are equal if:
    #    1) their filenames are equal
    #    2) their args are equal
    #    3) their vars are equal
    #    4) their tasks have the same UUID
    #    5) their parent tasks have the same UUID
    # all other attributes are not considered in this test
    obj1 = IncludedFile(None, None, None, None)
    obj1.add_host(None)
    obj1._filename = "test_filename"
    obj1._args = "test_args"
    obj1._vars = "test_vars"
    obj2 = IncludedFile(None, None, None, None)

# Generated at 2022-06-11 10:12:50.257688
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import sys

    class Counter(object):
        def get_vars(self, *args, **kwargs):
            return {}
        def get_host_vars(self, *args, **kwargs):
            return {}
        def add_group_vars(self, *args, **kwargs):
            pass
        def add_host_vars(self, *args, **kwargs):
            pass
        def add_host_group_vars(self, *args, **kwargs):
            pass
       

# Generated at 2022-06-11 10:13:01.691439
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # FileA and FileB have different names, they should not be equal
    fileA = IncludedFile("FileA", "ArgsA", "VarsA", "TaskA")
    fileB = IncludedFile("FileB", "ArgsA", "VarsA", "TaskA")
    assert fileB != fileA

    # FileA and FileC have different args, they should not be equal
    fileC = IncludedFile("FileA", "ArgsC", "VarsA", "TaskA")
    assert fileC != fileA

    # FileA and FileD have different vars, they should not be equal
    fileD = IncludedFile("FileA", "ArgsA", "VarsD", "TaskA")
    assert fileD != fileA

    # FileA and FileE have different parent, they should not be equal

# Generated at 2022-06-11 10:13:09.513412
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:13:19.872369
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import reserved_variables

    loader = unittest.mock.Mock()

    play = Play(
        name="test",
        hosts=["local"],
        roles=[],
        task_include='all'
    )

    play._has_handler_tasks = True
    play.post_validate(loader)

    host = Host(name="local")

    play_context = PlayContext()
    play_context.network_os = 'test'

# Generated at 2022-06-11 10:13:30.303280
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_result import TaskResult

    connection_loader.get('local', class_only=True)
    action

# Generated at 2022-06-11 10:13:42.346162
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    
    import playbooks
    import vars_loader
    import variable_manager
    import yaml

    results = []

    # 1. Test Condition:
    #
    #       loop:
    #         - 1
    #         - 2
    #
    #   Expected Result:
    #
    #       results = [ {'include': 'test.ymvl', 'ansible_loop_var': 'item'},
    #                   {'include': 'test.ymvl', 'ansible_loop_var': 'item'} ]
    #
    #       include_files = [ IncludedFile('test.ymvl', {}, {'item': 1}, ...),
    #                         IncludedFile('test.ymvl', {}, {'item': 2}, ...) ]
    #
    #   Actual Result:
    #
    #       results

# Generated at 2022-06-11 10:13:52.381084
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import Variable
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
   

# Generated at 2022-06-11 10:14:56.536703
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import mock
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Results:

        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result

    hosts = mock.MagicMock()
    tasks = [mock.MagicMock()]
    results = [Results(hosts, task, {'include': 'test_include.yml'}) for task in tasks]
    iterator = mock.MagicMock()
    iterator._play = mock.MagicMock()
    loader = mock.MagicMock()
    variable_manager = mock.MagicMock()
    variable_manager.get_vars.return_value = {'omit': TaskQueueManager.OMIT_TOKEN}
    IncludedFile.process_include_results

# Generated at 2022-06-11 10:15:09.517700
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    class IncludedFile(IncludedFile):

        def __init__(self, filename, args, vars, task, is_role=False):
            self._filename = filename
            self._args = args
            self._vars = vars
            self._task = task
            self._hosts = []
            self._is_role = is_role

    # First set of elements for comparison
    filename1 = 'filename1'
    args1 = {'arg11': 'val11', 'arg12': 'val12'}
    vars1 = {'var11': 'val11', 'var12': 'val12'}
    task1 = 'task1'

    # Second set of elements for comparison
    filename2 = 'filename2'
    args2 = {'arg21': 'val21', 'arg22': 'val22'}
   

# Generated at 2022-06-11 10:15:22.101035
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.template import Templar

    included_files = IncludedFile.process_include_results(
        [
            "test_1",
            "test_2",
            "test_3",
            "test_4",
            "test_5",
            "test_6",
            "test_7",
            "test_8",
            "test_9",
            "test_10",
            "test_11",
            "test_12",
            "test_13",
            "test_14",
            "test_15"
        ],
        None,
        None,
        None
    )


# Generated at 2022-06-11 10:15:34.848516
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-11 10:15:45.728357
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.role_include import IncludeRole

    class Host:
        def __init__(self, name):
            self.name = name

    class PlaybookExecutorMock(PlaybookExecutor):
        def __init__(self, loader, inventory, variable_manager, context):
            super(PlaybookExecutorMock, self).__init__(loader, inventory, variable_manager, context)
            self._tqm = TaskQueue

# Generated at 2022-06-11 10:15:54.392804
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class DummyIncludeResult(object):
        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result

    class DummyTask(object):
        def __init__(self, action, loop=False, parent=None):
            self.action = action
            self.loop = loop
            self._uuid = id(self)
            self._parent = parent

    host1 = 'host1'
    host2 = 'host2'

    host1_tasks = []
    host2_tasks = []


# Generated at 2022-06-11 10:16:04.754088
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    loaders = []

# Generated at 2022-06-11 10:16:16.641146
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class Task:
        def __init__(self, uuid):
            self._uuid = uuid
            self._parent = None
        def __eq__(self, other):
            return other._uuid == self._uuid
        def copy(self):
            return Task('copy')
    class Host:
        def __init__(self, name):
            self.name = name
        def __eq__(self, other):
            return other.name == self.name

    def assertEq(expected):
        assert expected == IncludedFile(
            filename='filename',
            args={'arg': 'value'},
            vars={'var': 'value'},
            task=Task('task'),
        )


# Generated at 2022-06-11 10:16:25.443042
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    filename = "test"
    args = {'name': 'role1'}

    vars = {'var1': 'val1'}
    vars_copy = {'var1': 'val1'}

    test_host = 'host'
    test_play = 'play'

    task1 = 'task1'
    task2 = 'task2'

    result_skipped = {'skipped': True}
    result_failed = {'failed': True}


# Generated at 2022-06-11 10:16:35.497548
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task, TaskInclude, IncludeRole
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources='')
    variable_manager.set_inventory(inventory)

    play1 = Play()
    play1._ds = dict(name='test play')
    play1._variable_manager = variable_manager

    play2 = Play()
    play2._