

# Generated at 2022-06-11 10:08:21.207907
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys
    import unittest
    import json

    class MockIncludedFile(IncludedFile):

        def __repr__(self):
            return "%s (args=%s vars=%s): %s" % (self._filename, self._args, self._vars, self._hosts)

    class TestIncludedFile(unittest.TestCase):

        def setUp(self):
            self.results = []
            self.included_files = []
            self.maxDiff = None


# Generated at 2022-06-11 10:08:32.939569
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.job_result import HostResult, TaskResult

    # Setup loading of data
    loader = DataLoader()

    # Setup inventory
    inventory = InventoryManager(loader=loader, sources=[])
    host_group = inventory.add_group('all')
    host_group.add_host(Host('host-1'))

    # Setup variables
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Setup results


# Generated at 2022-06-11 10:08:37.549717
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.executor.task_executor import remove_omit
    from ansible.module_utils._text import to_text
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.vars.manager import create_variable_manager
    from ansible.vars.resolver import pop_include_vars

    results = []

# Generated at 2022-06-11 10:08:49.881163
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader, lookup_loader
    from io import StringIO

    loader = DataLoader()

    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['foo'])
    variable_manager = inventory.get_variable_manager()

# Generated at 2022-06-11 10:09:01.432653
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task

    task_result_ok = TaskResult(host=object(), task=Task(), return_data=dict(invocation=dict(module_args='', module_name='')))
    task_result_ok._result = dict(include = 'foo.yml')
    task_result_ok.is_failed = False
    task_result_ok.is_unreachable = False

    task_result_failed = TaskResult(host=object(), task=Task(), return_data=dict(invocation=dict(module_args='', module_name='')))
    task_result_failed._result = dict(include = 'bar.yml')
    task_result_failed.is_failed = True
    task_result_failed.is_

# Generated at 2022-06-11 10:09:10.518861
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import ansible.playbook
    import ansible.playbook.task

    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import include_loader

    from ansible.plugins.action import ActionModule
    ActionModule._load_action_plugins(include_loader)

    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()

    playbook = ansible.playbook.PlayBook(loader=loader, variable_manager=variable_manager, play_source={'name': 'x', 'hosts': 'all'})
    play = ansible.playbook.Play().load(dict(name='x', hosts='all'), loader=loader, variable_manager=variable_manager)


# Generated at 2022-06-11 10:09:23.231551
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Create first instance of IncludedFile
    filename = 'filename.yml'
    args = ['arg1', 'arg2']
    vars = {'name': 'excel', 'role': 'base'}
    task = None # not implemented
    is_role = True
    ifile1 = IncludedFile(filename, args, vars, task, is_role)

    # Create second instance of IncludedFile
    filename = 'filename.yml'
    args = ['arg1', 'arg2']
    vars = {'name': 'excel', 'role': 'base'}
    task = 'name' # not implemented
    is_role = True
    ifile2 = IncludedFile(filename, args, vars, task, is_role)

    # Neither case is true
    assert not (ifile1 == ifile2)

   

# Generated at 2022-06-11 10:09:33.084834
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    '''Let's instantiate included_file with no arguments and test
    the method process_include_results().'''
    included_file = IncludedFile  # We aren't interested in __init__ for this test

# Generated at 2022-06-11 10:09:44.139340
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar
    from ansible.plugins import module_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

    display = Display()
    display.verbosity = 4

    fake_loader=module_loader._find_actions_in_path()
    action_loader._ACTION_PLUGINS = fake_loader

    variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.verbosity = 4
    templar = Templar(loader=None, variables=variable_manager.get_vars())

    results = []

# Generated at 2022-06-11 10:09:53.848594
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar

    task1 = Task()
    task2 = Task()
    task3 = Task()
    task1._uuid = "aa"
    task2._uuid = "bb"
    task3._uuid = "cc"
    task1._parent = task2
    task2._parent = task3
    task1._role = "role1"
    task2._role = "role2"
    task3._role = "role3"
    task1._role_path = "role_1_path"
    task2._role_path = "role_2_path"

# Generated at 2022-06-11 10:10:19.406324
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from ansible.template import Templar
    import ansible.playbook.role_include
    import json
    import sys

    # pylint: disable=unused-argument
    class MockPlay(Play):
        def __init__(self, play_ds, loader, variable_manager, options, passwords):
            self.name = 'mock_play'
            self.hosts = []
            self._included = []


# Generated at 2022-06-11 10:10:27.157733
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # NOTE: This test requires the collection ansible_collections.foo.bar installed
    # to test loading of collections.
    from ansible.playbook import play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_

# Generated at 2022-06-11 10:10:40.602113
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    def get_fake_task(name, action, args, loop=False):
        """
        create a very simple mock task
        """
        task = type('FakeTask', (object,), {})()
        task.name = name
        task.action = action
        task.args = args
        task.loop = loop
        return task

    # get a fake result set
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()


# Generated at 2022-06-11 10:10:51.434385
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import lookup_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager



# Generated at 2022-06-11 10:11:03.326626
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys
    import os.path
    import unittest
    import ansible.playbook.task
    import ansible.vars.manager

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib'))

    class MockHost(object):
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class MockTask(ansible.playbook.task.Task):
        def __init__(self, loop_var, index_var):
            super(MockTask, self).__init__(None, task_action=None, task_args=dict(), task_deps=set())
            self.loop_var = loop_var
            self.index_

# Generated at 2022-06-11 10:11:13.393170
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = "filename"
    args = "args"
    vars = "vars"
    task = "task"
    a = IncludedFile(filename, args, vars, task)
    b = IncludedFile(filename, args, vars, task)
    assert a == b
    assert not a != b
    b._filename = "not_filename"
    assert not a == b
    assert a != b
    b._filename = filename
    b._args = "not_args"
    assert not a == b
    assert a != b
    b._args = args
    b._vars = "not_vars"
    assert not a == b
    assert a != b
    b._vars = vars
    b._task = "not_task"
    assert not a == b
    assert a != b

# Unit

# Generated at 2022-06-11 10:11:24.538943
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys
    import unittest
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    class TestIncludedFile(unittest.TestCase):

        def setUp(self):
            self.loader = DataLoader()
            self.variable_manager = VariableManager()
            self.inventory = Inventory(self.loader, variable_manager=self.variable_manager, host_list=[])

# Generated at 2022-06-11 10:11:35.893955
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult, TaskResultFailure
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.template import Templar
    from ansible.plugins import module_loader


# Generated at 2022-06-11 10:11:44.478273
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.template import Templar

    assert IncludedFile.process_include_results([], None, None, None) == []

    loader = get_all_plugin_loaders()['action']['include_role']
    Templated = templar.template
    loader.get_basedir = lambda: "/ansible/roles"

    # original_task has no loop and no _role

# Generated at 2022-06-11 10:11:55.201981
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file1 = IncludedFile("filename", "args", "vars", "task")
    included_file2 = IncludedFile("filename", "args", "vars", "task")
    included_file3 = IncludedFile("filename", "args", "vars", "task")
    included_file3._task._uuid = included_file1._task._uuid
    included_file3._task._parent._uuid = included_file1._task._parent._uuid

    assert(included_file1 == included_file2)
    assert(included_file2 == included_file1)
    assert(included_file1 == included_file3)
    assert(included_file3 == included_file1)



# Generated at 2022-06-11 10:12:28.121128
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class DummyModuleReturn(AnsibleBaseYAMLObject):

        def __init__(self, value):
            self.value = value
            super(DummyModuleReturn, self).__init__()

    class DummyModuleResult(object):

        def __init__(self, result):
            self.result = result

    # The actual result structure returned by Ansible.

# Generated at 2022-06-11 10:12:32.919860
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)


# Generated at 2022-06-11 10:12:39.770892
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook import role
    from ansible.template import Templar
    from ansible.vars import VariableManager

    templar = Templar(loader=None, variables={})
    variable_manager = VariableManager(loader=None, variables={})

# Generated at 2022-06-11 10:12:44.728613
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile(1, 1, 1, 1, 1)
    b = IncludedFile(2, 1, 1, 1, 1)
    assert a != b
    assert a == IncludedFile(1, 1, 1, 1, 1)
    #assert a == 1 # will cause crash
    assert a != "notIncludedFile"
    assert a != object()

# Generated at 2022-06-11 10:12:56.142703
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # These test cases ensure that the class IncludedFile is
    # working correctly and that the method __eq__ is working
    # properly.

    # The method __eq__ returns true if the two IncludedFile
    # objects are equal. For the two objects to be equal, the
    # two files included must be the same, the arguments,
    # variables, and tasks must also be the same.

    # To get around the issue that the method __eq__ requires
    # the object to be instantiated (which requires calling
    # the constructor more than once), the test cases pass
    # the same file name, arguments, and task twice. Thus,
    # the method __eq__ should return true since the two objects
    # passed to it will be the same as each other.

    # Create two fake tasks that are exactly the same.
    fake_task1 = FakeTask()


# Generated at 2022-06-11 10:12:58.209602
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print("Testing process_include_results of class IncludedFile")
    print("\tTODO")

    return

# Generated at 2022-06-11 10:13:07.792029
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Set up a simple task to include
    parent_task = TaskInclude()
    parent_task.name = "test task"
    parent_task._role = None
    parent_task._parent = None
    parent_task.action = "include"
    parent_task.args = {}
    parent_task._role_name = None
    parent_task._from_files = dict()
    parent_task.action = 'include'

    # Two IncludedFiles that should compare equal
    inc1 = IncludedFile('test', {}, {}, parent_task)
    inc2 = IncludedFile('test', {}, {}, parent_task)

    # Since we haven't overridden __eq__, this should fail
    assert inc1 != inc2

    # Set up a simple task to include
    parent_task = TaskInclude()

# Generated at 2022-06-11 10:13:17.666285
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    context = PlayContext()
    context._vars = dict()
    context._vars['vars'] = dict()
    context._vars['vars']['var1'] = 'var1_value'
    context._vars['vars']['var2'] = 'var2_value'

    include_task_tpl = dict()
    include_task_tpl['args'] = '{{ vars }}'
    include_task_tpl['name'] = 'test_task_name'

# Generated at 2022-06-11 10:13:28.452303
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    import copy

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost,", "otherhost,"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext(variable_manager=variable_manager)


# Generated at 2022-06-11 10:13:40.644617
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import shared_loader_obj
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    loader = DictDataLoader({})
    shared_loader_obj.module_loader = loader
    p = PlayContext()
    t = Task()
    p.role_path = os.path.join(os.path.dirname(__file__), '../units/roles/test_role_vars/')
    t._role_path = p.role_path
    t._role = 'test_role_vars'

# Generated at 2022-06-11 10:14:35.877356
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [Result(host=u'localhost', task=u'include_tasks', loop_var=u'item'
                     ), Result(host=u'localhost', task=u'import_tasks', loop_var=u'item'
                              ), Result(host=u'localhost', task=u'include_role')]

# Generated at 2022-06-11 10:14:42.420851
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    included_files_list = IncludedFile.process_include_results([TaskResult(host=None, task=None, task_name=None, stdout=None, stderr=None, rc=None)], None, None, None)
    assert included_files_list == [], "The task result is empty, the result should be an empty list"

# Generated at 2022-06-11 10:14:54.727980
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:14:58.992987
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass
#    # Two different include_tasks with same parameter results in 1 element in included_files
#    # TODO: create a test case for this functionality
#    # If this functionality is used, it should be tested
#    pass

# Generated at 2022-06-11 10:15:12.763039
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class Dummy:
        _uuid = ''
        def __init__(self, parent):
            self._parent = parent
    # Test case 1
    # 'self' and 'other' are different include tasks
    self = IncludedFile('/a/b', {}, {}, Dummy(Dummy(None)))
    other = IncludedFile('/a/b', {}, {}, Dummy(Dummy(None)))
    assert self == other

    # Test case 2
    # 'self' and 'other' are the same include tasks
    self = IncludedFile('/a/b', {}, {}, Dummy(Dummy(None)))
    other = self
    assert self == other

    # Test case 3
    # 'self' and 'other' are the different roles

# Generated at 2022-06-11 10:15:23.944891
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars_v2 import HostVarsV2
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    class FakeHost(object):
        def __init__(self, name):
            self.name = name
            self.vars = HostVars(loader=None, variables=None, hostname=name)


# Generated at 2022-06-11 10:15:26.308836
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False, "Not Implemented"



# Generated at 2022-06-11 10:15:39.511768
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class Fake:
        pass
    class FakeIterator:
        _play = Fake()
    class FakeLoader:
        @staticmethod
        def get_basedir():
            return 'Fake_basedir'

    iterator = FakeIterator()
    loader = FakeLoader()
    variable_manager = Fake()

    class FakeHost1:
        pass
    class FakeHost2:
        pass
    class FakeHost3:
        pass

    class FakePlay:
        pass
    class FakeTask:
        def __init__(self, action):
            self._uuid = 42
            self._parent = None
            self.action = action
            self.tags = []
            self._role = None
            self._role_name = None
            self._from_files = dict()


# Generated at 2022-06-11 10:15:46.681996
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Arrange
    filename = "/my/file"
    args = dict(a=1, b=2)
    vars = dict(x=1, y=2)
    task = dict(task=42)
    is_role = True
    other = IncludedFile(filename, args, vars, task, is_role)

    # Act
    result = other.__eq__(other)

    # Assert
    assert result is True


# Generated at 2022-06-11 10:15:54.803443
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_cases = []
    # test case 1
    data = [{"_task": "/tmp/ansible/test/test_playbook/playbooks/testplay.yml:1", "_host": "localhost"}]
    iterator = None
    loader = None
    variable_manager = None
    excepted_result = [IncludedFile("/tmp/ansible/test/test_playbook/playbooks/testplay.yml", {}, {}, "/tmp/ansible/test/test_playbook/playbooks/testplay.yml:1")]
    test_cases.append((data, iterator, loader, variable_manager, excepted_result))

    # test case 2

# Generated at 2022-06-11 10:16:47.452433
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({'foo1': '', 'foo2': ''})
    play = Play.load(dict(name='include test', hosts=['localhost'], gather_facts='no'),
                     loader=loader, variable_manager=VariableManager())
    task = Task.load(dict(action="include", loop="results"), play=play, loader=loader, variable_manager=VariableManager())
    task._role_name = "some_role"
    task._role = Mock(get_path=lambda *args: 'roles/some_role')

    # 2x task include

# Generated at 2022-06-11 10:17:00.424764
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.plugins.loader import action_loader
    from ansible.playbook import Playbook, PlaybookInclude, TaskInclude, Task

    p = Playbook()
    loader = p._loader

    my_include_action = action_loader.get('include', class_only=True)
    include_args = dict({"include": 'test'})
    my_include_action._task = Task(include_args)

    my_playbook_include_action = action_loader.get('include_playbook', class_only=True)
    playbook_include_args = dict({"include_playbook": 'test'})
    my_playbook_include_action._task = Task(playbook_include_args)

    my_include_role_action = action_loader.get('include_role', class_only=True)
   

# Generated at 2022-06-11 10:17:09.402417
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)


# Generated at 2022-06-11 10:17:14.814296
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    inc_file = IncludedFile('/foo/bar.yml', dict(), dict(), dict())
    other = IncludedFile('/foo/bar.yml', dict(), dict(), dict())
    assert inc_file.__eq__(other)

    other._filename = '/bar/foo.yml'
    assert not inc_file.__eq__(other)

    other._filename = '/foo/bar.yml'
    other._args = dict(baz=1)
    assert not inc_file.__eq__(other)

    other._args = dict()
    other._vars = dict(baz=1)
    assert not inc_file.__eq__(other)

    other._vars = dict()
    other._task = dict(baz=1)
    assert not inc_file.__eq__(other)

   

# Generated at 2022-06-11 10:17:23.164067
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import tempfile
    import shutil
    from ansible.module_utils._text import to_bytes

    def create_tempfile(dir, filename, content):
        path = os.path.join(dir, filename)
        with open(path, 'wb') as f:
            f.write(to_bytes(content))


# Generated at 2022-06-11 10:17:35.607764
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """ IncludedFile.__eq__ returns True if objects are equals, False otherwise """
    class MockTemplate:
        class MockPlay:
            class MockRole:
                _role_path = "some_role_path"
            def __init__(self):
                self._role = MockTemplate.MockPlay.MockRole()
        class MockLoader:
            def get_basedir(self):
                return "some_basedir"
            def path_dwim(self, file):
                return file
        class MockVariableManager:
            def get_vars(self, play, host, task):
                return {'value': 'value'}
        class MockTask:
            class MockParent:
                _uuid = 0

            _uuid = 0
