

# Generated at 2022-06-11 10:08:33.527004
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.executor.task_result import TaskResult

    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager._fact_cache = {}
    variable_manager._host_vars_files = []
    variable_manager._host_vars_from_files = []
    variable_manager._vars_from_files = []
    variable_manager._nonpersistent_fact_cache = {}
    variable_manager._extra_vars = {}
    variable_manager._use_fact_cache = False


# Generated at 2022-06-11 10:08:42.170901
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager, HostVars
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins import vars_loader

    class VarsModule(object):
        def get_vars(self, loader, path, entities, cache=True):
            return {"lookup_plugin_vars": True}

    vars_loader.add("test", VarsModule())
    loader = DataLoader()
    variable_manager

# Generated at 2022-06-11 10:08:53.697630
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    import ansible.playbook.play as play
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.roles import Role
    import ansible.playbook.role_include as role_include
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.utils.vars import combine_vars

# Generated at 2022-06-11 10:09:05.459427
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    results = [{'_ansible_item_label': '',
                '_ansible_no_log': False,
                '_ansible_parsed': True,
                '_ansible_start_line': 3,
                '_host': 'test',
                'failed': False,
                'invocation': {'module_args': {'free_form':
                                               'git --git-dir=/opt/apps/example/.git --work-tree=/opt/apps/example/ pull origin master'}},
                'item': '',
                'rc': 0}]

    class TestIterator:
        def __init__(self, play):
            self._play = play

    class TestVars:
        def get_vars(self, play, host, task):
            return {}


# Generated at 2022-06-11 10:09:12.362698
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    Test the method IncludedFile.process_include_results()
    """

    class obj1(object):
        pass

    class obj2(object):
        _uuid = 1
        _parent = obj3()

    class obj3(object):
        _uuid = 2

    class obj4(object):
        play = obj5()

    class obj5(object):
        pass

    class obj6(object):
        pass

    class obj7(object):
        pass

    # noinspection PyTypeChecker
    varman = obj1()
    varman.get_vars = lambda play, host, task: 'task_vars'

    # noinspection PyTypeChecker
    loader = obj1()
    loader.get_basedir = lambda: 'basedir'

# Generated at 2022-06-11 10:09:24.939205
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task

    class FakeIterator:
        _play = None

    class FakePlay:
        pass

    class FakeLoader:
        def get_basedir(self):
            pass

        def path_dwim(self, a):
            pass

    class FakeVariableManager:
        def get_vars(self, play=None, host=None, task=None):
            pass

    class FakeHost:
        def __init__(self, name):
            self.name = name

    class FakeTask(Task):
        def __init__(self, role=None):
            Task.__init__(self)
            self._role = role

    class FakeRole:
        def __init__(self, name):
            self.name = name

    class FakeHandler(Task):
        pass


# Generated at 2022-06-11 10:09:33.973715
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    x = []

    x.append(IncludedFile("/etc/ansible/roles/foo/tasks/main.yml", {}, {}, ""))
    x.append(IncludedFile("/etc/ansible/roles/foo/tasks/bar.yml", {}, {}, ""))
    x.append(IncludedFile("/etc/ansible/roles/foo/tasks/bar.yml", {}, {}, ""))
    x.append(IncludedFile("/etc/ansible/roles/foo/tasks/foo.yml", {}, {}, ""))


# Generated at 2022-06-11 10:09:45.103051
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.plugins.loader import task_loader

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.template import Templar

    # Define mock objects

    class MockTaskForward:

        def __init__(self):
            self.action = 'include'
            self.parent = MockParentTask()
            self.loop = False
            self.action = 'include'
            self.vars = dict()
            self.search_path

# Generated at 2022-06-11 10:09:54.789367
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # initialize some required values
    loader = None
    variable_manager = None
    iterator = None

    # create 2 mock tasks, one with a 'include' result, the other one with a 'include_role' result
    task_include = TaskInclude('/path/to/task/include/file', 1, None)
    task_include_result = {
        "_ansible_no_log": False,
        "changed": False,
        "skip_reason": "Conditional result was False",
        "skipped": True,
        "include": "/path/to/include/file"
    }

# Generated at 2022-06-11 10:09:57.388083
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile(None, None, None, None)
    b = IncludedFile(None, None, None, None)
    assert a == b


# Generated at 2022-06-11 10:10:22.259588
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    def _get_loader():
        loader = DataLoader()
        loader.set_basedir(os.path.join(os.path.dirname(__file__), 'support', 'test-import-include'))
        return loader

    def _get_play_context():
        return PlayContext()


# Generated at 2022-06-11 10:10:23.324462
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test function exists
    assert callable(IncludedFile.process_include_results)

# Generated at 2022-06-11 10:10:36.593809
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 10:10:48.221221
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filenames = ['TEST1.yml', 'TEST2.yml', 'TEST3.yml']
    args = [
            {'_raw_params': 'TEST1.yml', 'tags': ['something']},
            {'_raw_params': 'TEST2.yml', 'tags': ['something']},
            {'_raw_params': 'TEST3.yml', 'tags': ['something']}
    ]
    vars = [
            {'something': 'test1'}, 
            {'something': 'test2'}, 
            {'something': 'test3'}
    ]
    tasks = [
             TaskInclude(), 
             TaskInclude(), 
             TaskInclude()
    ]
    included_files = []

# Generated at 2022-06-11 10:10:58.732928
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    task1 = Task()
    task2 = Task()
    task3 = Task()
    task4 = Task()
    task5 = Task()

    task_include1 = TaskInclude()
    task_include2 = TaskInclude()
    task_include3 = TaskInclude()
    task_include4 = TaskInclude()
    task_include5 = TaskInclude()

    task1._uuid = task2._uuid = task3._uuid = task4._uuid = task5._uuid = 'task_uuid_fake_uuid_123'
    task_include1._uuid = task_include2._uuid = task_include3._uuid = task_include4._uuid = task_include

# Generated at 2022-06-11 10:11:10.256836
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

# Generated at 2022-06-11 10:11:16.839800
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:11:28.001003
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [
        dict(host=dict(name='localhost'), task=dict(_uuid='task1', _parent={'_uuid': 'play1'})),
        dict(host=dict(name='localhost'), task=dict(_uuid='task2', _parent={'_uuid': 'play1'})),
        dict(host=dict(name='localhost'), task=dict(_uuid='task3', _parent={'_uuid': 'play1'})),
    ]

    results[0].update(
        dict(
            result=dict(
                include='web',
                changed=False,
                include_args=dict(
                    a=1,
                    b=2,
                ),
            ),
        ),
    )


# Generated at 2022-06-11 10:11:36.975219
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import pytest
    from ansible.playbook.task import Task

    play = None
    playbook = None

    filename = 'roles/common/tasks/main.yaml'
    args = {'tags': 'bar'}
    vars = {'foo': 'bar'}
    task = Task()

    included_file_one = IncludedFile(filename, args, vars, task)
    included_file_two = IncludedFile(filename, args, vars, task)

    assert included_file_one == included_file_two


# Generated at 2022-06-11 10:11:48.659315
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class FakeProcessResult:
        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result
    class FakeIterator:
        _play = 'test'
    class FakeLoader:
        class FakePlay:
            def __init__(self, path):
                self.path = path
        def __init__(self, play_path):
            self._entries = dict()
            self._entries[play_path] = FakeLoader.FakePlay(play_path)
        def get_basedir(self):
            return '.'
        def path_dwim(self, include_target):
            return include_target

# Generated at 2022-06-11 10:12:29.067765
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    loop_result_1 = {'include': 'foo.yml', 'ansible_loop_var': 'item', 'item': 1}
    loop_result_2 = {'include': 'foo.yml', 'ansible_loop_var': 'item', 'item': 2}
    loop_results = [loop_result_1, loop_result_2]

    class MockIncludeTask(object):
        action = 'include_tasks'

        def __init__(self, loop=False):
            self.loop = loop

    context

# Generated at 2022-06-11 10:12:37.787066
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    class ResultsForTest:
        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result
            self._is_failed = False
            self._is_unreachable = False
            self._is_skipped = False
            self.exception = None
        def is_failed(self): return self._is_failed
        def is_unreachable(self): return self._is_unreachable

# Generated at 2022-06-11 10:12:48.525084
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """
    Test comparison of IncludedFile objects. The __eq__ method is overridden,
    so this is a regression test that __eq__ is implemented correctly.
    """
    try:
        import jinja2
    except ImportError:
        # If jinja2 is not installed, we can't test this.
        return

    from ansible.parsing.dataloader import DataLoader

    from ansible.template.template import (
        AnsibleJ2Template,
    )

    from ansible.plugins.loader import (
        plugin_loader,
    )

    from ansible.vars.manager import (
        VariableManager,
    )

    from ansible.vars.hostvars import (
        HostVars,
    )

    from ansible.inventory.manager import (
        InventoryManager,
    )



# Generated at 2022-06-11 10:12:49.711895
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:13:01.069095
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(param1='value1', param2='value2')
    loader = DataLoader()
    iterator = PlayIterator(loader=loader, variable_manager=variable_manager, all_vars=dict(param3='value3'))

    original_task = TaskInclude(file_name='test_host.yml', params=dict())


# Generated at 2022-06-11 10:13:01.861480
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-11 10:13:09.614339
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.executor.task_result import TaskResult
    from ansible.playbook import task_include
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

    # Test mix of two different include files, one with loops and one without and two different hosts
    # Test different include actions

# Generated at 2022-06-11 10:13:19.968602
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dummy_iterator = DummyIterator()
    dummy_loader = DummyLoader()
    dummy_variable_manager = DummyVariableManager()


# Generated at 2022-06-11 10:13:30.392029
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class FakePlaybook:
        def __init__(self, host_list=None):
            self._entries = host_list

        def hosts(self):
            return self._entries

    class FakeLoader:
        def __init__(self):
            self.basedir = '/fake_dir'

        def get_basedir(self):
            return self.basedir

        def path_dwim(self, include):
            return include

        def path_dwim_relative(self, basedir, relpath, path, is_role=False):
            return os.path.join(basedir, path)

    class FakeResult:
        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result


# Generated at 2022-06-11 10:13:34.380004
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.plugins.loader import lookup_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import RESERVED_TASK_VARS

    loader = lookup_loader

    varmgr = VariableManager()

    task1 = Task()
    task1.action = 'include_role'
    task1.args.update({'name': 'foobar'})
    task1_res = TaskResult(host=None, task=task1, return_data=dict(include_args=dict(), include='foobar'))

    task2 = Task()
    task2.action = 'include_role'

# Generated at 2022-06-11 10:14:57.706252
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task1 = TaskInclude("/tmp/task1")
    task2 = TaskInclude("/tmp/task1")
    task3 = TaskInclude("/tmp/task3")
    task4 = TaskInclude("/tmp/task1", args=dict(a=1))

    inc_file1 = IncludedFile("/tmp/task1", dict(), dict(), task1)
    inc_file2 = IncludedFile("/tmp/task1", dict(), dict(), task2)
    inc_file3 = IncludedFile("/tmp/task3", dict(), dict(), task3)
    inc_file4 = IncludedFile("/tmp/task1", dict(a=1), dict(), task4)
    inc_file5 = IncludedFile("/tmp/task1", dict(), dict(b=2), task1)

    assert inc_file1 == inc

# Generated at 2022-06-11 10:15:10.948648
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Testing empty results
    results = []
    iterator = None
    loader = None
    variable_manager = None
    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert included_files == []

    # Testing non-empty results
    # This test case can be modified by removing/adding entries in the results list
    results = [
        Fake_Result(Fake_Host("host 1"), Fake_Task("task1"), "result 1"),
        Fake_Result(Fake_Host("host 2"), Fake_Task("task1"), "result 2"),
        Fake_Result(Fake_Host("host 1"), Fake_Task("task2"), "result 3"),
        Fake_Result(Fake_Host("host 2"), Fake_Task("task2"), "result 4")
    ]

# Generated at 2022-06-11 10:15:23.059973
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # Test data
    #
    # The format is (results, iterator, loader, variable_manager)
    #
    #   results - the value of ansible.playbook.play_context.C.RESULT_CACHE
    #             after execution of playbook.
    #
    #   iterator - the playbook iterator
    #
    #   loader - the playbook loader
    #
    #   variable_manager - the playbook variable manager

    class FakeIterator:
        class FakeParent:
            pass

        def __init__(self):
            self.fake_parent = FakeIterator.FakeParent()

            self.fake_parent.action = "include"
            self.fake_parent.loop = True


# Generated at 2022-06-11 10:15:36.881493
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.playbook_iterator import PlaybookIterator

    import pytest

    class mock_loader:
        basedir = '/home/playbook/'

    class mock_variable_manager:
        @staticmethod
        def get_vars(play=None, host=None, task=None):
            return {}

    class mock_task:
        def __init__(self, action, loop=False, parent=None, role=None):
            self.action = action
            self.loop = loop
            self._parent = parent
            self._role = role

        def get_search_path(self):
            return ['/home/playbook/']

    results = [
        ]


# Generated at 2022-06-11 10:15:48.136133
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.inventory.host import Host

    task1 = Task()
    task2 = Task()
    playbook = Playbook()
    play = Play()
    host = Host('127.0.0.1')
    play.add_task(task1)
    playbook.add_play(play)
    playbook.add_host(host)

    inc1 = IncludedFile('test.yml', {}, {}, task1)
    inc2 = IncludedFile('test.yml', {}, {}, task1)
    inc3 = IncludedFile('test2.yml', {}, {}, task1)

# Generated at 2022-06-11 10:15:57.066215
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    class MockTask(Task):
        # pylint: disable=too-few-public-methods
        def __init__(self):
            self._parent = None
            self.args = {}
    class MockPlay:
        # pylint: disable=too-few-public-methods
        def __init__(self):
            self.vars = {}
    class MockIterator:
        # pylint: disable=too-few-public-methods
        def __init__(self):
            self._play = MockPlay()
        def get_play_context(self):
            return PlayContext(self._play, connect_timeout=10, network_os=None)

# Generated at 2022-06-11 10:16:07.740643
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Parameters for the method
    results = []
    included_files = []
    task_vars_cache = {}

    # 1st result, action include
    original_host = 'localhost'
    # create original task with action include
    original_task = TaskInclude()
    original_task.action = 'include'
    # create a new result
    res = {}
    res._host = original_host
    res._task = original_task
    res._result = ''
    results.append(res)

    # 2nd result, action include_role
    # create original task with action include_role
    original_task = TaskInclude()
    original_task.action = 'include_role'
    # create a new result
    res = {}
    res._host = original_host
    res._task = original_task
    res

# Generated at 2022-06-11 10:16:19.331550
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor import task_result
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    process_include_results = IncludedFile.process_include_results

    host1 = Host('host1')
    host2 = Host('host2')

    results = []

    # first test, as if the task was included in a role
    # we don't care that it is a handler, we only want to test the template
    # used for the path
    task_include = TaskInclude('included_task', 'role_name/tasks/main.yml')
    task_include._role = 'role_name'

# Generated at 2022-06-11 10:16:28.266340
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # AnsibleError(assertion) -- extends Exception(AssertionError)
    from ansible.errors import AnsibleError
    # TaskInclude(Include) -- extends Task(Base)
    from ansible.playbook.task_include import TaskInclude
    # IncludeRole(Include) -- extends Task(Base)
    from ansible.playbook.role_include import IncludeRole

    # create a object of class TaskInclude
    task = TaskInclude()
    # create a object of class IncludeRole
    role = IncludeRole()

    # create a object of class IncludedFile
    filename = 'test'

# Generated at 2022-06-11 10:16:32.279332
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # input args for tests
    results = []
    iterator = ""
    loader = ""
    variable_manager = ""
    # Test the process_include_results method
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert True
