

# Generated at 2022-06-11 10:08:21.325277
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    This test is based on the test_include_complex_loop in test/integration/targets/include_role/tasks/test_complex_loop.yml
    """

    class Host():
        name = 'a_host'

    class Task():
        _role_name = 'fake'

        def __init__(self, action, loop=False, no_log=False):
            self.action = action
            self.loop = loop
            self.no_log = no_log
            self._parent = None
            self._role = None
            self._from_files = {}
            self.FROM_ARGS = ('vars_from', 'roles_from')


# Generated at 2022-06-11 10:08:33.044506
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Prepare mocks for include result, iterator and templar
    class MockResult:
        def __init__(self, host, task, result,  task_uuid, parent_uuid):
            self._host = host
            self._task = task
            self._result = result
            self._task._uuid = task_uuid
            self._task._parent._uuid = parent_uuid
            return
        def __repr__(self):
            return "MockResult(host=%s, task=%s, result=%s)" % (self._host, self._task, self._result)
        pass

    # Prepare mock iterator
    class MockIterator:
        def __init__(self):
            self._play = "mock_play"
            return

# Generated at 2022-06-11 10:08:41.663893
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    t1 = TaskInclude(dict(free_form='/path/to/file1'))
    t2 = TaskInclude(dict(free_form='/path/to/file2'))

    p1 = IncludedFile('/path/to/file1', dict(a=1), dict(b=1), t1)
    p2 = IncludedFile('/path/to/file2', dict(a=2), dict(b=2), t2)

    assert not p1 == p2

    t3 = TaskInclude(dict(free_form='/path/to/file1'))
    assert t1 == t3

    p3 = IncludedFile('/path/to/file1', dict(a=1), dict(b=1), t1)
    assert p1 == p3

# Generated at 2022-06-11 10:08:53.058151
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from unittest import TestCase, main


# Generated at 2022-06-11 10:09:04.991713
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:09:15.219174
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    '''
    Test the method __eq__ of class IncludedFile
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader

    context = PlayContext()
    context._play = {'name': 'play'}
    context._play_hosts = ['host1']
    context._play_hosts_all = ['host1']
    context._hostvars = {'host1': {}}

    filename = 'tasks.yml'
    args = {}
    vars = {}
    task = Task()
    task._parent = None
    task._role = None
    task._role_name = None
    task._attributes = {}
    task._loader = module_loader
    task._block = None
    task

# Generated at 2022-06-11 10:09:27.327791
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    included_file_1 = IncludedFile('filename_1', dict(), dict(), Task())
    included_file_2 = IncludedFile('filename_1', dict(), dict(), Task())
    included_file_3 = IncludedFile('filename_2', dict(), dict(), Task())
    included_file_4 = IncludedFile('filename_2', dict(), dict(), Task())

    # same task & filename should return True
    assert included_file_1 == included_file_2
    assert included_file_3 == included_file_4

    # same task, different filename should return False
    assert not included_file_1 == included_file_3

    # different task, same filename should return False

# Generated at 2022-06-11 10:09:35.221570
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # test a basic include
    # file A tasks/main.yml: - include: B
    # file B tasks/B.yml: - debug: msg="hello world"
    # expected: IncludedFile("B", dict(), dict(), Task('include', 'A', 1))
    A_tasks = [TaskInclude("B", 1)]
    A_results = [Result("localhost", "A", dict(include="B", include_args=dict()), dict())]
    expected = [IncludedFile("B", dict(), dict(), A_tasks[0])]
    actual = IncludedFile.process_include_results(A_results, A_tasks, dict(), dict())
    assert actual == expected

    # test a loop with an include
    # file A tasks/main.yml: - include: B
    # file B tasks/B

# Generated at 2022-06-11 10:09:46.225735
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    t1 = TaskInclude()
    t2 = TaskInclude()
    p1 = IncludedFile(
        filename="filename",
        args={"a":"A"},
        vars={"b":"B"},
        task=t1,
        is_role=False
    )
    p2 = IncludedFile(
        filename="filename",
        args={"a":"A"},
        vars={"b":"B"},
        task=t1,
        is_role=False
    )
    p3 = IncludedFile(
        filename="filename",
        args={"a":"A"},
        vars={"b":"B", "c":"C"},
        task=t1,
        is_role=False
    )

# Generated at 2022-06-11 10:09:55.898308
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert IncludedFile(1, 2, 3, 4) == IncludedFile(1, 2, 3, 4)
    assert (IncludedFile(1, 2, 3, 4) !=
        IncludedFile(1, 2, 3, 4, is_role=True))
    assert (IncludedFile(1, 2, 3, 4) !=
        IncludedFile(1, 2, 3, 5))
    assert (IncludedFile(1, 2, 3, 4) !=
        IncludedFile(1, 2, 4, 4))
    assert (IncludedFile(1, 2, 3, 4) !=
        IncludedFile(1, 3, 3, 4))
    assert (IncludedFile(1, 2, 3, 4) !=
        IncludedFile(2, 2, 3, 4))

# Generated at 2022-06-11 10:10:20.588880
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert IncludedFile(None, None, None, None) == IncludedFile(None, None, None, None)
    assert IncludedFile(None, {'a': 'A'}, None, None) == IncludedFile(None, {'a': 'A'}, None, None)
    assert IncludedFile(None, {'a': 'A'}, None, None) == IncludedFile(None, {'a': 'B'}, None, None)
    assert IncludedFile(None, None, {'a': 'A'}, None) == IncludedFile(None, None, {'a': 'A'}, None)
    assert IncludedFile(None, None, {'a': 'A'}, None) == IncludedFile(None, None, {'a': 'B'}, None)

# Generated at 2022-06-11 10:10:30.262631
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    class Host:

        def __init__(self, name):
            self.name = name

    class Task:

        class PlayBook:

            def __init__(self, name):
                self.name = name

        def __init__(self, name):
            self.name = name
            self.action = 'included'
            self.loop = False
            self.vars = {}
            self.no_log = False
            self._uid = 0
            self._role = None
            self._parent = None

        def copy(self):

            class TmpTask:

                def __init__(self):
                    self._role_name = None
                    self._from_files = {}
                    self.FROM_ARGS = {}

            new_task = TmpTask()
            return new_task


# Generated at 2022-06-11 10:10:43.001369
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = {
        (1, ('file1', 'args1', 'vars1'), 'host1', 'task1'),
        (1, ('file2', 'args2', 'vars2'), 'host2', 'task2'),
        (1, ('file1', 'args1', 'vars1'), 'host1', 'task1'),
        (1, ('file1', 'args1', 'vars1'), 'host2', 'task1'),
        (1, ('file1', 'args1', 'vars1'), 'host3', 'task1'),
        (2, ('file1', 'args1', 'vars1'), 'host3', 'task1')
    }

    included_files = IncludedFile.process_include_results(results, None, None, None)
    assert len(included_files) == 3


# Generated at 2022-06-11 10:10:52.929930
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    class MockLoader():
        def path_dwim_relative(self, basepath, relpath, name, is_role=False):
            return os.path.join(basepath, relpath, name)

    # results is the result of an include_tasks/include_role  result
    results = []

    # mock an include_tasks/import_tasks result
    include_result = {}
    include_result['include'] = 'task_for_host1.yml'
    include_result['include_type'] = 'tasks'
    include_result['k1'] = 'v1'
    include_result['k2'] = 'v2'
    include_result['ansible_loop_var'] = 'loop_var'
    include_result['ansible_index_var'] = 'index_var'


# Generated at 2022-06-11 10:11:01.505356
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    fake_task = FakeTask()
    fake_task.args = dict(foo='bar')
    fake_task.vars = dict(foo_vars='bar_vars')

    f1 = IncludedFile(None, None, None, None)
    f2 = IncludedFile(None, None, None, fake_task)
    f3 = IncludedFile(None, None, None, None)
    f4 = IncludedFile(None, None, None, fake_task)

    assert f1 == f3
    assert f2 == f4


# Generated at 2022-06-11 10:11:12.313671
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import pytest
    from ansible.executor.task_executor import TaskResult
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    C._ACTION_ALL_INCLUDES = [ "include", "include_tasks", "include_role", "import_tasks", "import_playbook" ]

# Generated at 2022-06-11 10:11:23.516809
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible import utils
    included_files = []

# Generated at 2022-06-11 10:11:34.554853
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    import sys
    import time
    sys.path.append('lib/ansible/module_utils')
    import basic

    required_args = {}
    basic._ANSIBLE_ARGS = required_args
    class MockTaskInclude:
        def __init__(self):
            self.action = 'include'

        def copy(self):
            return MockTaskInclude()

        def get_search_path(self):
            return ['/etc/ansible/roles/roles/includedependent/tasks']

    class MockIterator:
        def __init__(self):
            self._play = {'name': 'include test'}

    class MockResult:
        def __init__(self, host, task, result):
            # A Host object
            self._host = host
            # A TaskInclude object

# Generated at 2022-06-11 10:11:43.915578
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    import copy
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 10:11:55.616709
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.role._role_definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar

    playbook_path = os.path.join(C.DEFAULT_MODULE_PATH, 'test_include.yml')

    pbex = PlaybookExecutor(playbooks=[playbook_path],
                            inventory=None,
                            variable_manager=None,
                            loader=None,
                            options=None,
                            passwords={})
    pbex._tqm._unreachable_hosts = dict()
    iterator = pbex._tqm._get_iterator(pbex._inventory)
   

# Generated at 2022-06-11 10:12:14.159470
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    iterator = None
    loader = None
    variable_manager = None


# Generated at 2022-06-11 10:12:26.811295
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile("test_filename_a", 1, 2, 3)
    b = IncludedFile("test_filename_a", 1, 2, 3)
    c = IncludedFile("test_filename_c", 3, 2, 1)
    d = IncludedFile("test_filename_d", 5, 4, 3)
    e = IncludedFile("test_filename_e", 5, 4, 3)
    f = IncludedFile("test_filename_f", 7, 6, 5)
    g = IncludedFile("test_filename_a", 0, 2, 3)
    h = IncludedFile("test_filename_a", 1, 0, 3)
    i = IncludedFile("test_filename_a", 1, 2, 0)
    j = IncludedFile("test_filename_a", 1, 2, 3)

    assert a == b
    assert a

# Generated at 2022-06-11 10:12:36.748321
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    Tests the process_include_results method of class IncludedFile.
    """

    # test_data is a list of tuples of the form
    # (results, iterator, loader, variable_manager, expected_result)
    test_data = []

    results = [0, 1]
    iterator = 0
    loader = 0
    variable_manager = 0
    expected_result = 0
    test_data.append((results, iterator, loader, variable_manager, expected_result))

    print("Running tests on IncludedFile.process_include_results")
    for data in test_data:
        results, iterator, loader, variable_manager, expected_result = data
        actual_result = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
        assert actual_result == expected_result


# Generated at 2022-06-11 10:12:43.381894
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    filename = 'filename'
    args = dict()
    vars = dict()
    task = Task()
    is_role = False

    # Equal if filename, args, vars, task._uuid and task._parent._uuid are the same
    inc_file = IncludedFile(filename, args, vars, task)
    assert inc_file == IncludedFile(filename, args, vars, task)

    # Not equal if filename is not the same
    assert inc_file != IncludedFile('another_filename', args, vars, task)

    # Not equal if args are not the same
    assert inc_file != IncludedFile(filename, {'key': 'value'}, vars, task)

    # Not equal if vars are

# Generated at 2022-06-11 10:12:54.736064
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys
    import os
    import tempfile
    from ansible.plugins import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler

    class MyInventory(object):
        def __init__(self, loader, groups=None, host_list=None):
            self.loader = loader
            self.groups = groups

# Generated at 2022-06-11 10:13:05.487404
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Setup
    include1 = IncludedFile("test", {}, {}, None, False)
    include2 = IncludedFile("test", {}, {}, None, False)
    include3 = IncludedFile("test", {}, {}, None, False)
    include4 = IncludedFile("test2", {}, {}, None, False)
    include5 = IncludedFile("test", {"extra":"param"}, {}, None, False)
    include6 = IncludedFile("test", {}, {"extra":"var"}, None, False)
    include7 = IncludedFile("test", {}, {}, "task", False)

    # Assert
    assert include1 == include2
    assert include1 != include3
    assert include1 != include4
    assert include1 != include5
    assert include1 != include6
    assert include1 != include7


# Generated at 2022-06-11 10:13:15.066700
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.playbook.play_context as pc
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a task result
    task_executor = TaskExecutor(play_context=pc.PlayContext(), task=None, loader=None, shared_loader_obj=None, variable_manager=None)

# Generated at 2022-06-11 10:13:25.840322
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor import task_executor
    from ansible.inventory import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    loader = DataLoader()
    variables = VariableManager()

    # General play context
    play_context = PlayContext()
    play_context.network_os = 'ios'

    # Play with task and host
    play = Play().load({
        'name': 'test play',
        'hosts': 'localhost',
        'gather_facts': 'no'
    }, loader=loader, variable_manager=variables)

    host = Host(name='localhost')

# Generated at 2022-06-11 10:13:38.155761
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    from ansible.playbook.task import Task

    # included_file1 = IncludedFile(filename, args, vars, task, is_role=False)
    included_file1 = IncludedFile(filename = 'test_file_name',
                                  args = 'test_args',
                                  vars = 'test_vars',
                                  task = Task(task_name = 'test_task_name', action = 'test_action'),
                                  is_role = False)

    # included_file2 = IncludedFile(filename, args, vars, task, is_role=False)

# Generated at 2022-06-11 10:13:46.623973
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    t1 = Task()
    t1._uuid = 'T1'
    t1.action = 'include'
    t1.loop = 'result'
    t1.no_log = False
    t1._parent = None
    t1.role = None

    t2 = Task()
    t2._uuid = 'T2'
    t2.action = 'include_tasks'
    t2.loop = 'result'
    t2.no_log = False
    t2._parent = None
    t2.role = None

    h1 = Handler()
    h1._uuid = 'H1'

# Generated at 2022-06-11 10:14:53.476119
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    class DummyTask:

        def __init__(self, uuid):
            self._uuid = uuid

    class DummyIterator:

        def __init__(self, play):
            self._play = play

    class DummyHandler:

        def __init__(self, parent):
            self._parent = parent

    class DummyRole:

        def __init__(self, path, name):
            self._role_path = path
            self.name = name

    class DummyRole2:

        def __init__(self, path, name):
            self._role_path = path
            self.name = name

    class DummyResult:

        def __init__(self, task, host, result):
            self._task = task
            self._host = host
            self._result = result


# Generated at 2022-06-11 10:15:06.567574
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    obj1 = IncludedFile('/path/to/file.yaml', dict(), dict(), None)
    obj2 = IncludedFile('/path/to/file_diff.txt', dict(), dict(), None)
    obj3 = IncludedFile('/path/to/file.yaml', dict(param='value'), dict(), None)
    obj4 = IncludedFile('/path/to/file.yaml', dict(), dict(param='value'), None)
    obj5 = IncludedFile('/path/to/file.yaml', dict(), dict(), object())
    obj6 = IncludedFile('/path/to/file.yaml', dict(), dict(), object())

    assert obj1 == obj2
    assert obj1 != obj3
    assert obj1 != obj4
    assert obj1 != obj5
    assert obj5 == obj6

# Generated at 2022-06-11 10:15:20.033905
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys

    class PlaybookInventory:
        def __init__(self):
            self.hosts = {}
            self.groups = {}
            self.patterns = []

    class Task:
        def __init__(self, action, parent=None):
            self._uuid = None
            self._parent = parent
            self._role = None
            self.action = action
            self.loop = False
            self._parent = None
            self._from_files = {}
            self._role_name = None

        def get_search_path(self):
            return []

        def copy(self):
            return self

    class Host(object):
        def __init__(self, hostname):
            self.name = hostname

        def __eq__(self, other):
            return self.name == other.name



# Generated at 2022-06-11 10:15:27.108079
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.constants as C
    import ansible.module_utils._text as t
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.utils.listify import listify_lookup_plugin_terms

    loader = DataLoader()
    # For testing purposes, the display is just the default one
    display = Display()

    # create dummy hosts

# Generated at 2022-06-11 10:15:39.602010
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    host = MagicMock()
    host.get_name.return_value = 'localhost'
    host.name = 'localhost'
    task = MagicMock()
    task.action = 'include'
    task.loop = False
    task._uuid = '123'
    task._role = None
    task._parent = MagicMock()
    task._parent._uuid = '1234'
    task.no_log = False
    task.get_search_path.return_value = ['search_path']

    result = dict(changed=False, skipped=False, failed=False)
    iterator = MagicMock()
    iterator._play = 'play'
    loader = MagicMock()
    loader.get_basedir.return_value = 'base_dir'
    variable_manager = MagicMock()
    variable_manager

# Generated at 2022-06-11 10:15:44.462232
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    def included_files_get_hosts(included_files):
        return [inc_file._hosts for inc_file in included_files]

    # include_tasks
    try:
        import ansible.executor.task_queue_manager as task_queue_manager
    except ImportError:
        # old ansible
        from ansible import errors as AnsibleError
        from ansible.callbacks import playbook_on_no_hosts_matched
        import ansible.runner.return_data as return_data

        def task_queue_manager_get_hosts_count(results):
            return len(results._hosts)

        def task_queue_manager_get_results(results):
            host_results = []

# Generated at 2022-06-11 10:15:53.862830
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:16:04.152769
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import ansible.playbook.task

    filename = './test_module'
    args = []
    vars = []
    task = ansible.playbook.task.Task()
    is_role = False
    incF1 = IncludedFile(filename, args, vars, task, is_role)

    filename = './test_module'
    args = []
    vars = []
    task = ansible.playbook.task.Task()
    is_role = False
    incF2 = IncludedFile(filename, args, vars, task, is_role)

    filename = './test_module'
    args = []
    vars = []
    task = ansible.playbook.task.Task()
    is_role = True

# Generated at 2022-06-11 10:16:16.195137
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.play_context import PlayContext

    context = PlayContext()

    # Test __eq__ when files are not equal
    a = IncludedFile('file_a', {}, {}, None)
    b = IncludedFile('file_b', {}, {}, None)
    assert a != b

    # Test __eq__ when files are equal
    c = IncludedFile('file_a', {}, {}, None)
    assert a == c

    # Test __eq__ with different args
    d = IncludedFile('file_a', {'foo': 'bar'}, {}, None)
    assert a != d

    # Test __eq__ with different vars
    e = IncludedFile('file_a', {}, {'foo': 'bar'}, None)
    assert a != e

    # Test __eq__ with different tasks
    f

# Generated at 2022-06-11 10:16:25.202895
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
