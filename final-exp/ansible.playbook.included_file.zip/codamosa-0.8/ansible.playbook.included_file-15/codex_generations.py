

# Generated at 2022-06-11 10:08:21.155000
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    #from ansible.plugins.loader import module_loader
    from ansible.executor.task_result import TaskResult
    from ansible.utils.vars import combine_vars

    class DummyVarsModule(object):
        def __init__(self):
            pass
        def get_vars(self, loader, path, play, host, task):
            return {'role_path': '/tmp/example_playbook/roles/foo'}

   

# Generated at 2022-06-11 10:08:32.883589
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import text_type

    filename1 = text_type(AnsibleUnsafeText(b"file1"))
    filename2 = text_type(AnsibleUnsafeText(b"file2"))
    filename3 = text_type(AnsibleUnsafeText(b"file2"))

    # initialize
    include_task = Task()
    include_task._uuid = "id1"
    include_task.action = "include"
    include_task.args = dict(arg1="arg1", arg2="arg2")
    play = Play()
    play._uuid = "id2"
    include_

# Generated at 2022-06-11 10:08:41.848407
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.playbook.play_context import PlayContext

    loader = DummyLoader()
    variable_manager = DummyVariableManager()
    # Set some variables
    variable_manager._vars_per_host = dict()
    # Set play context
    iterator = PlayContext()
    iterator._play = dict()
    iterator._play['name'] = 'test'
    iterator._play['hosts'] = ['host1']
    # Set 2 hosts results
    results = list()
    # On host1, 2 includes
    result_host1 = dict()
    result_host1['host'] = 'host1'
    result_host1['task'] = dict()
    result_host1['task']['loop'] = True
    result_host1['task']['action'] = 'include'

# Generated at 2022-06-11 10:08:53.249319
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.play_iterator import PlayIterator

    class Host():
        name = 'dummy'
        port = 22
        vars = dict()

    hosts = [Host()]

    class Playbook():
        pass
    pb = Playbook()
    pb.basedir = '/path/to'
    class Play():
        playbook = pb
    play = Play()
    class Task():
        def __init__(self):
            self._parent = play

    task = Task()
    task.action = 'include'
    task.loop = ''
    task.args = dict()
    context = PlayContext()
    iterator = PlayIterator(play=play, inventory=None, variable_manager=None, loader=None)


# Generated at 2022-06-11 10:09:05.081059
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:09:12.141611
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader

    loader, inventory, variable_manager = C.get_implicit_objects()

    playbook_path = "/tmp/ansible_test_playbook.yml"
    results_path = "/tmp/ansible_test_results.yml"

# Generated at 2022-06-11 10:09:24.674088
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class FakeResult:
        def __init__(self, result):
            self._host = 'host1'
            self._task = 'task1'
            self._result = result

    result1 = FakeResult({'include_args': {'_param': 'value'}, 'include': 'main.yml'})
    result2 = FakeResult({'include_args': {'_param': 'value'}, 'include': 'other.yml'})
    result3 = FakeResult({'include_args': {'_param': 'value'}, 'include': 'main.yml'})
    result4 = FakeResult({'include_args': {'_param': 'value'}, 'include': 'main.yml'})
    results = [result1, result2, result3, result4]

    # Fake iterator

# Generated at 2022-06-11 10:09:33.881430
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass
# Copyright (c) 2012-2014 by Ansible, Inc.
# (c) 2012-2014, Michael DeHaan <michael.dehaan@gmail.com>
#
# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Ansible. 

# Generated at 2022-06-11 10:09:45.011800
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager

    options = dict(
        host_list='/dev/null',
        forks=10,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        syntax=None,
        diff=False,
        module_path=None,
        start_at_task=None
    )
    loader = None  # TODO: make mockable
    variable_manager = None  # TODO: make mockable
    inventory = None  # TODO: make mockable

    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=options,
        passwords=None,
    )


# Generated at 2022-06-11 10:09:54.698084
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # true test
    test_filename1 = '/test/filename/1'
    test_filename2 = '/test/filename/2'
    test_args1 = {'arg1': 'arg1_value'}
    test_args2 = {'arg2': 'arg2_value'}

    test_vars1 = {'vars1': 'vars1_value'}
    test_vars2 = {'vars2': 'vars2_value'}

    test_inc1 = IncludedFile(test_filename1, test_args1, test_vars1, None)
    test_inc2 = IncludedFile(test_filename1, test_args1, test_vars1, None)
    test_inc3 = IncludedFile(test_filename2, test_args1, test_vars1, None)



# Generated at 2022-06-11 10:10:20.539814
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:10:29.946948
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task_include import TaskInclude

    host = "localhost"
    task = TaskInclude(action='tasks')
    included_file_1 = IncludedFile("file.yml", {"x": "foo", "y": "bar"}, {"a": 1, "b": 2}, task)
    included_file_2 = IncludedFile("file.yml", {"x": "foo", "y": "bar"}, {"a": 1, "b": 2}, task)
    included_file_3 = IncludedFile("file.yml", {"x": "foo", "y": "bar"}, {"a": 1, "b": 3}, task)

# Generated at 2022-06-11 10:10:42.778232
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:10:52.800160
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.template import Templar

    from ansible.utils.sentinel import Sentinel

# Generated at 2022-06-11 10:11:05.959398
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    '''Test process_include_results method of IncludedFile class'''

    loaded_include_vars = dict(
        ansible_loop_var='item',
        item={'name': 'em0'},
        ansible_index_var='idx',
        idx='0',
        ansible_item_label='item.name',
        _ansible_item_label='item.name',
        ansible_loop='{{ ansible_interfaces }}',
        _ansible_no_log=False,
        _ansible_search_path=[
            '/tmp/roles/test/tasks',
            '/tmp/roles/test/tasks',
        ],
        _ansible_verbosity=4,
        omit='{{ omit_token }}',
        omit_token='*******',
    )


# Generated at 2022-06-11 10:11:14.562910
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    # pretends to play an include_role task, that returns
    # the following results (via a callback)

    # - first include task result is ok but with a loop.
    #   In the loop, we have a loop_var called item, that
    #   contains a dict result.
    # - second include task result is skipped (we do not
    #   expect it to be in the result of process_include_results)
    # - third include task result is ok, with no loop.
    #   It has an include_args that contains args for the
    #   include_role task.

# Generated at 2022-06-11 10:11:25.808066
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders

    loader = get_all_plugin_loaders()[1]

# Generated at 2022-06-11 10:11:37.703989
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(CallbackBase):
        pass

    callback_plugin = TestCallbackModule()
    inventory_manager = InventoryManager(None)

# Generated at 2022-06-11 10:11:45.162325
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [
        Result(host="host_0", task=TaskInclude(name="included task", args={'_raw_params': './included_file.yaml'})),
        Result(host="host_1", task=TaskInclude(name="included task", args={'_raw_params': './included_file.yaml'})),
        Result(host="host_1", task=TaskInclude(name="included task", args={'_raw_params': './included_file.yaml'})),
        Result(host="host_2", task=TaskInclude(name="included task", args={'_raw_params': './included_file.yaml'}))
    ]

    included_files = IncludedFile.process_include_results(results)


# Generated at 2022-06-11 10:11:56.432108
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class FakeLoader(object):
        def __init__(self):
            self._basedir = '/'
        def get_basedir(self):
            return self._basedir
        def path_dwim(self, path):
            return path

    class FakeRole(object):
        def __init__(self):
            self._role_path = '/'
        def get_path(self):
            return self._role_path

    loader = FakeLoader()
    role

# Generated at 2022-06-11 10:12:33.236951
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    hosts_count = 1

# Generated at 2022-06-11 10:12:40.665761
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class FakeLoader(object):
        def __init__(self, basedir):
            self.basedir = basedir

        def get_basedir(self):
            return self.basedir

        def path_dwim_relative(self, *args, **kwargs):
            return os.path.join(*args, **kwargs)

    class FakePlay(object):
        pass

    class FakeHost(object):
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class FakeTask(object):
        def __init__(self, name):
            self.name = name
            self._parent = None
            self._role = None
            self._from_files = dict()
            self._role_name = None

# Generated at 2022-06-11 10:12:51.905917
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Different filename
    file1 = IncludedFile(
        filename = "filename1",
        args = "args1",
        vars = "vars1",
        task = "task1",
        is_role = False
    )
    file2 = IncludedFile(
        filename = "filename2",
        args = "args1",
        vars = "vars1",
        task = "task1",
        is_role = False
    )
    if file1 == file2:
        raise AssertionError("file1 == file2 should return False")

    # Different args
    file1 = IncludedFile(
        filename = "filename1",
        args = "args1",
        vars = "vars1",
        task = "task1",
        is_role = False
    )

# Generated at 2022-06-11 10:12:56.195343
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile('thing.txt', dict(), dict(), dict(), dict())
    a._filename = 'thing.txt'
    a._args = dict()
    a._vars = dict()
    a._task = dict()
    a._hosts = dict()
    b = Includ

# Generated at 2022-06-11 10:13:06.590239
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    ###############################################################
    #
    # Prepare for testing
    #

    # The following values are arbitrary, but will be used as keys in dictionaries
    # or lists, to ensure that the order of elements is preserved.
    host_name = 'arbitrary_host_name'
    task_uuid = 'arbitrary_task_uuid'
    task_parent_uuid = 'arbitrary_task_parent_uuid'
    task_action = 'arbitrary_task_action'

# Generated at 2022-06-11 10:13:16.455221
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook import base
    from ansible.playbook.play import Play
    from ansible.plugins import loader as plugin_loader

    variable_manager = VariableManager()
    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list=['127.0.0.1'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 10:13:27.115866
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [
        {'_host': 'host_1', '_task': 'task_1', 'include': 'include_1', 'include_args': {'v': 'v_1'}},
        {'_host': 'host_1', '_task': 'task_2', 'include': 'include_2'},
        {'_host': 'host_2', '_task': 'task_3', 'include': 'include_3', 'include_args': {'w': 'w_3'}},
    ]

    class Iterator:
        class Play:
            pass

        _play = Play

    iterator = Iterator()
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader

# Generated at 2022-06-11 10:13:39.371241
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    loader, inventory, variable_manager = C.load_extra_vars()
    variable_manager._extra_vars = {}

    t1 = TaskInclude()
    t2 = TaskInclude()
    t3 = TaskInclude()
    t4 = TaskInclude()
    t5 = TaskInclude()
    t6 = TaskInclude()
    t7 = TaskInclude()
    t8 = TaskInclude()
    t9 = TaskInclude()
    t10 = TaskInclude()
    t11 = TaskInclude()

    ifile1 = IncludedFile(filename="./test/test.yml", args={}, vars={}, task=t1)
    ifile2 = IncludedFile(filename="./test/test.yml", args={}, vars={}, task=t1)

# Generated at 2022-06-11 10:13:47.372006
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import unittest
    import tempfile
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    play = Play.load(dict(
        name="test",
        hosts=["local"],
        gather_facts="no",
        tasks=[dict(action=dict(include="included.yml", include_args=dict(foo="bar")),
                    loop=["a", "b", "c"])],
    ),
        loader=loader,
    )
    host = Host("local")
    host.set_variable("omit", "$")

# Generated at 2022-06-11 10:13:57.810360
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

# Generated at 2022-06-11 10:14:57.406933
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.playbook.task_include
    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.inventory.manager
    import ansible.executor.task_result
    import ansible.plugins.loader
    import ansible.vars.manager
    import ansible.template
    import ansible.vars
    import ansible.parsing.dataloader

    class FakeIncludeTask(ansible.playbook.task_include.TaskInclude):
        def __init__(self, task_action):
            ansible.playbook.task_include.TaskInclude.__init__(self)
            self.action = task_action

        def get_search_path(self):
            return [self._dt]


# Generated at 2022-06-11 10:15:10.585810
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile(None, None, None, None)
    b = a
    assert(a == b)

    b = IncludedFile(None, None, None, None)
    assert (a == b)

    b = IncludedFile(None, None, None, None)
    b._filename = None
    assert not (a == b)

    b = IncludedFile(None, None, None, None)
    b._args = None
    assert not (a == b)

    b = IncludedFile(None, None, None, None)
    b._vars = None
    assert not (a == b)

    b = IncludedFile(None, None, None, None)
    b._task._uuid = None
    assert not (a == b)

    b = IncludedFile(None, None, None, None)
    b._task._

# Generated at 2022-06-11 10:15:22.855576
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    fake_results = []


# Generated at 2022-06-11 10:15:36.561944
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    '''
    Test process_include_results() output to detect regressions
    '''

    # set up for test case
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import include_vars_loader
    from ansible.plugins.loader import include_role_loader
    from ansible.plugins.loader import preprocess_loader

    class MockTask(object):
        '''
        minimal mock for task object
        '''

# Generated at 2022-06-11 10:15:47.716354
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    t1 = Task()
    t2 = Task()
    b1 = Block()
    b2 = Block()
    i1 = IncludedFile('', None, None, t1)
    i2 = IncludedFile('', None, None, t2)
    assert i1 != i2
    i1 = IncludedFile('', None, None, t1, is_role=True)
    i2 = IncludedFile('', None, None, t2, is_role=True)
    assert i1 != i2
    t1._uuid = "1"
    t2._uuid = "1"
    assert i1 == i2
    t1._parent = b1
    b1._uuid = "1"
    b2._uu

# Generated at 2022-06-11 10:15:55.192875
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    #
    # This unit test is not to test the correctness of Ansible code.
    # The purpose of this unit test is to show the coverage of Ansible
    # code. So, this unit test is to test that the Ansible code for
    # method process_include_results of class IncludedFile has been
    # executed.
    #
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    results = []

    # Test task._role is not

# Generated at 2022-06-11 10:16:05.707635
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    try:
        from test.support import unit_tests
    except ImportError:
        # In Ansible 2.0, the test support code is not present by default
        # This is not ideal, but better than failing this test
        pass

    skip = True
    if unit_tests:
        skip = False

    if skip:
        return


# Generated at 2022-06-11 10:16:17.460288
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.plugins.loader import include_tasks_loader
    from ansible.vars.manager import VariableManager

    # FIXME: this test should go away when refactoring for Ansible 2.7 is complete
    # FIXME: that should be done by creating a new include_tasks plugin that works like include
    loader = include_tasks_loader.include_tasks('some_path')
    variable_manager = VariableManager()
    iterator = None


# Generated at 2022-06-11 10:16:25.925368
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task

    test_data = pytest.importorskip('test.unit.utils.data')
    data_loader = DataLoader()


# Generated at 2022-06-11 10:16:36.012417
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test basic case
    from ansible.utils.vars import combine_vars  # This should be imported as it is used in process_include_results