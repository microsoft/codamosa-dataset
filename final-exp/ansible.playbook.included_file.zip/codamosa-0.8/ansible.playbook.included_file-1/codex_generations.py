

# Generated at 2022-06-11 10:08:04.854598
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    a = IncludedFile("filename", "args", "vars", "task")
    b = IncludedFile("filename", "args", "vars", "task")
    host1 = "host1"
    host2 = "host2"
    host3 = "host3"

    # adding the same host object should not be an error
    a.add_host(host1)
    a.add_host(host1)

    # adding different host object should increase the included file host
    a.add_host(host2)
    a.add_host(host3)
    assert len(a._hosts) == 3
    assert host1 in a._hosts
    assert host2 in a._hosts
    assert host3 in a._hosts

    # adding the same host object to two different included file objects should not be an error

# Generated at 2022-06-11 10:08:12.845131
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_result import TaskResult

    pl_result = TaskResult(host=object(), task=object())
    pl_result._result = {'include': 'file'}
    pl_result._task = IncludeRole(task=object(), role_name=object())
    pl_result._task._role_name = 'role'

    pl_results = [pl_result]

    loader = DataLoader()
    loader.set_basedir(os.path.realpath('../'))
    variable_manager = VariableManager()

    class Iterator:
        def __init__(self):
            self._play = object()



# Generated at 2022-06-11 10:08:24.968815
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import mock


# Generated at 2022-06-11 10:08:34.120537
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [raw_res(b"/etc/ansible/roles/test1/tasks/test.yml", b"include_tasks",
                       "{{ lookup('pipe','echo foo') }}", raw_item(b"foo"))]
    loader, variable_manager, iterator = (None, None, None)
    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert included_files[0]._filename == "/etc/ansible/roles/test1/tasks/foo"
    assert included_files[0]._args == {}



# Generated at 2022-06-11 10:08:42.438861
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    from ansible.playbook.play import Play
    from ansible.plugins import module_loader

    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 10:08:46.842892
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert IncludedFile('name', 'args', 'vars', 'task') == IncludedFile('name', 'args', 'vars', 'task')
    assert not IncludedFile('nam', 'arg', 'var', 'tas') == IncludedFile('name', 'args', 'vars', 'task')

# Generated at 2022-06-11 10:08:58.364118
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:09:08.869190
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task = None
    includedFile1 = IncludedFile("filename", "args", "vars", task)
    includedFile1._task._uuid = "uuid1"
    includedFile1._task._parent._uuid = "parent_uuid1"
    includedFile2 = IncludedFile("filename", "args", "vars", task)
    includedFile2._task._uuid = "uuid2"
    includedFile2._task._parent._uuid = "parent_uuid2"
    includedFile3 = IncludedFile("filename", "args", "vars", task)
    includedFile3._task._uuid = "uuid3"
    includedFile3._task._parent._uuid = "parent_uuid3"
    includedFile4 = IncludedFile("filename", "args", "vars", task)
    includedFile4._task

# Generated at 2022-06-11 10:09:21.282696
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    class Host:
        def __init__(self, name):
            self.name = name
            self.vars = dict()

        def get_name(self):
            return self.name

    included_file = IncludedFile('a', 'b', 'c', 'd')
    hostA = Host('hostA')
    hostB = Host('hostB')

    included_file.add_host(hostA)
    included_file.add_host(hostB)
    assert included_file._hosts == [hostA, hostB]

    try:
        included_file.add_host(hostB)
        assert False, "Expected ValueError"
    except ValueError:
        pass
    assert included_file._hosts == [hostA, hostB]



# Generated at 2022-06-11 10:09:31.761974
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test setup
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import playbook_loader

    loader = playbook_loader()
    play = Play()
    play._loader = loader
    play._variable_manager._loader = loader
    play._variable_manager._fact_cache = {}

    task_include = TaskInclude()
    task_include._parent = Task()
    task_include._parent._play = play

    task_result = dict()
    task_result['include_args'] = dict()

    task_result['include_args']['name'] = 'include_file_1'
    task_result['include'] = 'inc/include_file_1'
    task_result

# Generated at 2022-06-11 10:10:01.828323
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task

    host = 'localhost'

    # TaskInclude
    task = Task()
    result = TaskResult(host, task)
    result._result['include'] = 'test.yml'
    result._result['include_args'] = dict(a=1, b=2)
    result._result['ansible_search_path'] = ['.']

    # IncludeRole
    task = Task()
    result = TaskResult(host, task)
    result._result['include'] = dict(role='test')
    result._result['include_args'] = dict(a=1, b=2)
    result._result['ansible_search_path'] = ['.']

# Generated at 2022-06-11 10:10:15.760454
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

# Generated at 2022-06-11 10:10:25.271841
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:10:38.748724
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    class FakeTask(Task):
        def __init__(self, action, uuid=None):
            self.action = action
            self._uuid = uuid
            self._parent = None

        def __eq__(self, other):
            return self._uuid == other._uuid

    # Set up
    file1 = IncludedFile('/foo/bar.yml', {}, {}, FakeTask('include'))
    file2 = IncludedFile('/foo/bar.yml', {}, {}, FakeTask('include'))
    assert file1 == file2
    assert file2 == file1

    file3 = IncludedFile('/bar/baz.yml', {}, {}, FakeTask('include'))

# Generated at 2022-06-11 10:10:50.007439
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from collections import namedtuple
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    class FakeOptions():

        _variable_manager = VariableManager()

        def __init__(self):
            self._basedir = None

        def __getattr__(self, attr):
            if attr == 'basedir':
                return self._basedir
            return getattr(self._variable_manager, attr)

        def __setattr__(self, attr, value):
            if attr == 'basedir':
                self._basedir = value
            else:
                setattr(self._variable_manager, attr, value)


# Generated at 2022-06-11 10:11:01.685569
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    import sys
    from ansible.module_utils.six.moves import StringIO

    from ansible.playbook.task import Task

    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.utils.display import Display
    from ansible.executor.task_result import TaskResult

    playbook_dirpath = os.path.dirname(os.path.dirname(__file__))
    default_dirpath = os.path.join(playbook_dirpath, 'module_utils', 'defaults')
    sys.path.insert(0, default_dirpath)

    from action_plugins import get_default_action_plugin_classpath

    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-11 10:11:02.845419
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO - FIXME - write unit test
    return

# Generated at 2022-06-11 10:11:13.088743
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import ansible.inventory.host
    host = ansible.inventory.host.Host(name='testhost')
    task = dict()
    task['action'] = 'include_tasks'
    task['args'] = dict()
    task['args']['_raw_params'] = 'role'

    t1 = IncludedFile(filename='filename1', args=dict(), vars=dict(), task=task)
    t2 = IncludedFile(filename='filename1', args=dict(), vars=dict(), task=task)

    assert t1.__eq__(t2)
    task['args']['_raw_params'] = 'role1'
    t2 = IncludedFile(filename='filename1', args=dict(), vars=dict(), task=task)
    assert t1.__eq__(t2) is False

    t1

# Generated at 2022-06-11 10:11:24.147291
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:11:35.311870
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    display.verbosity = 3
    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-11 10:12:23.294517
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = {}
    play_context.update(C.CLIARGS)

# Generated at 2022-06-11 10:12:34.913496
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Setup
    loader = ('loader')
    iterator = ('iterator')
    variable_manager = ('variable_manager')
    result_success = ('result_success')
    result_success._host=('result_success._host')
    result_success._task=('result_success._task')
    result_success._result=('result_success._result')
    result_failed = ('result_failed')
    result_failed._host=('result_failed._host')
    result_failed._task=('result_failed._task')
    result_failed._result=('result_failed._result')
    result_skipped = ('result_skipped')
    result_skipped._host=('result_skipped._host')
    result_skipped._task=('result_skipped._task')

# Generated at 2022-06-11 10:12:42.521496
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    IncludedFile._process_include_results()
    """
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    plays = [Play().load({'name': 'test', 'hosts': 'all', 'gather_facts': 'no', 'tasks': []}, variable_manager=variable_manager, loader=loader)]
    play_iterator = PlayIterator(plays)

    play = next(play_iterator)
    host = play.get_variable_manager().get_v

# Generated at 2022-06-11 10:12:53.810694
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_result import TaskResult

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.become = 'true'
    play_context.become_method = 'sudo'
    play_context.become_user = 'user'
    play_context.remote_user = 'user'
    play_context.connection = 'ssh'
    play_context.network_os = 'network_os'
   

# Generated at 2022-06-11 10:13:04.854184
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    '''Unit test for method __eq__ of class IncludedFile'''

    # create object TaskInclude
    task = TaskInclude()
    task.action = 'include'
    task.action = 'include_tasks'
    task.action = 'import_tasks'
    task.action = 'import_playbook'

    # create object include
    include1 = IncludedFile(1, 2, 3, task, False)
    include2 = IncludedFile(1, 2, 3, task, False)
    include3 = IncludedFile(4, 2, 3, task, False)
    include4 = IncludedFile(1, 5, 3, task, False)
    include5 = IncludedFile(1, 2, 6, task, False)
    include6 = IncludedFile(1, 2, 3, task, True)

    assert include1 == include1

# Generated at 2022-06-11 10:13:14.385070
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins.loader import get_all_plugin_loaders

    module_loader, lookup_loader, action_loader = get_all_plugin_loaders()

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=module_loader,
        passwords=None,
        stdout_callback=None)

    play_context = PlayContext()
    play_context.network_os = 'test_os'


# Generated at 2022-06-11 10:13:25.060101
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor

    loader = DataLoader()

    play_context = dict(remote_addr='127.0.0.1')
    variable_manager = VariableManager()
    results_dir = '/dev/null'
    iterator = Play.make_play_iterator(loader, play_context, [], results_dir, variable_manager, None)


# Generated at 2022-06-11 10:13:37.390786
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.hostvars import HostVars

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    class AnsibleTask:
        def __init__(self, action, args, task_name, parent_task, no_log):
            self.action = action
            self.args = args
            self.task_name = task_name
            self._parent = parent_task
            self.no_log = no_log

    class AnsibleHost:
        def __init__(self, name):
            self.name = name
            self.vars = HostVars(name=name, variables={})


# Generated at 2022-06-11 10:13:46.048895
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import os
    import shutil
    import tempfile
    import json

    tmpdir = tempfile.mkdtemp()
    tmpdir_roles = os.path.join(tmpdir, 'roles')
    tmpdir_tasks = tempfile.mkdtemp()
    shutil.copytree('test/sanity/include_source_dir', tmpdir_tasks)
    shutil.copytree('test/sanity/include_source_dir_2', os.path.join(tmpdir_tasks, 'include_source_dir_2'))
    shutil.copytree('test/sanity/include_source_dir_3', os.path.join(tmpdir_tasks, 'include_source_dir_3'))


# Generated at 2022-06-11 10:13:55.052385
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing import DataLoader
    from ansible.vars import VariableManager

    basedir = '/home/jtariku/ansible/test/integration/targets/testPlaybook'
    loader  = DataLoader()
    variable_manager = VariableManager()
    iterator = None
    include_file_names = []
    include_files = IncludedFile.process_include_results([], iterator, loader, variable_manager)
    assert 0 == len(include_files)
    for file in include_files:
        include_file_names.append(file._filename)
    assert [] == include_file_names

    results = []
    include_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert 0 == len(include_files)

# Generated at 2022-06-11 10:14:51.514943
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import copy
    import sys
    import unittest

    if sys.version_info[0] == 2:
        from types import ModuleType
    else:
        from types import ModuleType

    class ModuleLoader(object):
        module_name = "lib"
        _module_cache = {}  # {module_name: module_obj}

        def __init__(self, *args, **kwargs):
            pass

        def get_module_source(self, module_name):
            return ""

        def get_module(self, module_name):
            if module_name in self._module_cache:
                return self._module_cache[module_name]

            module = ModuleType(module_name)
            self._module_cache[module_name] = module
            return module


# Generated at 2022-06-11 10:14:59.817025
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible
    ansible_path = ansible.__path__[0]
    import ansible.plugins.loader
    loader_obj = ansible.plugins.loader.PluginLoader()
    assert isinstance(loader_obj, ansible.plugins.loader.PluginLoader)
    import ansible.plugins.filter
    filter_loader_obj = ansible.plugins.filter.FilterModuleLoader(loader_obj, ansible_path)
    assert isinstance(filter_loader_obj, ansible.plugins.filter.FilterModuleLoader)
    import ansible.plugins.lookup
    lookup_loader_obj = ansible.plugins.lookup.LookupModuleLoader(loader_obj, ansible_path)
    assert isinstance(lookup_loader_obj, ansible.plugins.lookup.LookupModuleLoader)

    import ansible.vars

# Generated at 2022-06-11 10:15:14.281693
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # (1) set up the test of the method
    from .manager import TaskManager


# Generated at 2022-06-11 10:15:24.541179
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludedFile
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator

    included_files = []

    class ResultsCollector:
        def __init__(self):
            self.results = []

        def _process_results(self, res):
            self.results.append(res)

    loader = DataLoader()
    host = Host(name="test")
   

# Generated at 2022-06-11 10:15:38.867218
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class TestTaskResult(object):
        _result = {}

        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result

    class TestTask(object):
        def __init__(self, action, loop, no_log, parent, search_path, _uuid, _role):
            self.action = action
            self.loop = loop
            self.no_log = no_log
            self._parent = parent
            self.get_search_path = lambda: search_path
            self._uuid = _uuid
            self._role = _role

    class TestIterator(object):
        _play = {}

    class TestLoader(object):
        def __init__(self, basedir):
            self.basedir = basedir


# Generated at 2022-06-11 10:15:50.273216
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    t1 = TaskInclude()
    t1._parent = Play()
    t2 = TaskInclude()
    t2._parent = Play()
    i1 = IncludedFile('test_1', {'test_1': 'test_1'}, {'test_2': 'test_2'}, t1)
    i2 = IncludedFile('test_1', {'test_1': 'test_1'}, {'test_2': 'test_2'}, t1)
    i3 = IncludedFile('test_1', {'test_1': 'test_1'}, {'test_2': 'test_2'}, t2)
    i4 = IncludedFile('test_1', {'test_1': 'test_1'}, {'test_2': 'test_2'}, t1)

# Generated at 2022-06-11 10:16:00.861740
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import copy
    results = []
    # include with no loop
    res = {'include': 'sample'}
    results.append(copy.deepcopy(res))
    # include with loop
    res['results'] = [{'ansible_loop_var': 'item', 'include': 'sample'}]
    results.append(copy.deepcopy(res))
    # import_tasks with no loop
    res = {'include_tasks': 'sample'}
    results.append(copy.deepcopy(res))
    # import_tasks with loop
    res['results'] = [{'ansible_loop_var': 'item', 'include_tasks': 'sample'}]
    results.append(copy.deepcopy(res))
    # include_role with no loop

# Generated at 2022-06-11 10:16:12.747607
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class Options(object):
        connection = 'local'
        module_path = '/path/to/mymodules'
        forks = 10
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        verbosity = 3
        inventory = Inventory(loader=DataLoader())

    loader = DataLoader()


# Generated at 2022-06-11 10:16:22.280616
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import MockModuleLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.mod_args import ModuleArgsParser
    from io import StringIO
    inventory_string = u'localhost ansible_connection=local\n'
    inventory_string += u'[all]\n'
    inventory_string += u'localhost\n'
   

# Generated at 2022-06-11 10:16:32.331313
# Unit test for method process_include_results of class IncludedFile