

# Generated at 2022-06-11 10:07:58.851593
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False

# Generated at 2022-06-11 10:08:07.509608
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import unittest
    import json
    import os

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

    class TestIncludeFile(unittest.TestCase):
        def test_process_include_results(self):
            from ansible.module_utils.facts.system.distribution import DistributionFactCollector
            from ansible.module_utils.facts.system.distribution import LinuxDistribution
            from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
            from ansible.module_utils.facts.system.distribution import LinuxDistributionFamilyFactory
            from ansible.module_utils.facts.system.distribution import LinuxDistributionFactoryLinux
            from ansible.module_utils.facts.system.distribution import LinuxDistributionFamily

# Generated at 2022-06-11 10:08:17.601774
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile('/a/b/c', ['foo', 'bar'], {'x':1, 'y':2}, 'task1')
    b = IncludedFile('/a/b/c', ['foo', 'bar'], {'x':1, 'y':2}, 'task1')
    c = IncludedFile('/d/e/f', ['foo', 'bar'], {'x':1, 'y':2}, 'task1')

    assert a == b
    assert not (a == c)


# Generated at 2022-06-11 10:08:29.367716
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test configuration
    class FakeResult:
        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result


# Generated at 2022-06-11 10:08:35.940010
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    host = None
    include_filename = 'file.yml'
    include_args = None
    include_vars = None
    task = None
    included_file = IncludedFile(include_filename, include_args, include_vars, task)
    try:
        included_file.add_host(host)
    except ValueError:
        assert 0 # fail
    else:
        assert 1 # success


# Generated at 2022-06-11 10:08:47.062853
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.base import PlaybookBase
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager

    def task_id(task):
        return task._uuid

    class TestPlaybookBase(PlaybookBase):
        def get_task_uuid(self, task):
            return task._uuid

    class TestPlay(Play):
        def __init__(self):
            super(TestPlay, self).__init__()
            self._uuid = 'fake_play_uuid'
            PlaybookBase.__init__(self, None)


# Generated at 2022-06-11 10:08:58.583394
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import unittest
    from unittest import TestCase
    from mock import Mock, MagicMock

    class TestIncludedFile(TestCase):
        def setUp(self):
            self.included_file = IncludedFile

# Generated at 2022-06-11 10:09:05.319134
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile('test_filename', None, None, None)
    host1 = 'test_host1'
    host2 = 'test_host2'
    inc_file.add_host(host1)
    try:
        inc_file.add_host(host1)
        assert False, "Expected including host that is already in included files to fail."
    except ValueError:
        pass



# Generated at 2022-06-11 10:09:12.268777
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # pylint: disable=global-statement
    global display
    class FakeDisplay():
        def __init__(self, verbosity=0):
            self.verbosity = verbosity
        def deprecated(self, msg, version=None, removed=False):
            print("[DEPRECATED] %s" % msg)
        def warning(self, msg, *args, **kwargs):
            print("[WARNING] %s" % msg % args)
    display = FakeDisplay()

    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    import os
    basedir = os.path.real

# Generated at 2022-06-11 10:09:21.286648
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    print("------------------")
    print("Starting test_IncludedFile_add_host")
    print("------------------")
    f = IncludedFile("filename", "args", "vars", None)
    f.add_host("host1")
    f.add_host("host2")
    f.add_host("host1")
    print("------------------")
    print("Finished test_IncludedFile_add_host")
    print("------------------")

if __name__ == '__main__':
    test_IncludedFile_add_host()

# Generated at 2022-06-11 10:09:46.453697
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import collections

    class TaskResult:
        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result

    class MyTask:
        def __init__(self, action, loop, no_log, parent, search_path):
            self.action = action
            self.loop = loop
            self.no_log = no_log
            self._parent = parent
            self._search_path = search_path

        def get_search_path(self):
            return self._search_path

        def copy(self):
            return MyTask(self.action, self.loop, self.no_log, self._parent, self._search_path)

    class MyIterator:
        def __init__(self, play):
            self._play = play

   

# Generated at 2022-06-11 10:09:56.168470
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    class FakeIncludeResult:

        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result

    class FakeHost:

        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return self.name

    class FakeIterator:

        def __init__(self, play):
            self._play = play

    class FakeTask:

        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return self.name


# Generated at 2022-06-11 10:10:06.891981
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.plugins.strategy import ActionModule
    from ansible.utils.vars import combine_vars

    def _create_task(result_handler, parent=None):
        task = Task()
        task._role = None
        task

# Generated at 2022-06-11 10:10:20.589021
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(inventory=None, variable_manager=None, loader=None)

    block = Block()
    task = Task()
    task._task_queue_manager = tqm
    task._parent = block

    task2 = Task()
    task2._task_queue_manager = tqm
    task2._parent = block

    inc_file = IncludedFile('/tmp/foo', dict(), dict(), task)
    inc_file2 = IncludedFile('/tmp/foo', dict(), dict(), task2)
    assert inc_file == inc_file2


# Generated at 2022-06-11 10:10:30.177283
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import __main__
    import yaml
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    inventory = InventoryManager(loader=DataLoader(), sources="localhost")

    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()

    # create the play that will be used to store and run included tasks

# Generated at 2022-06-11 10:10:42.945011
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    '''
    This method tests if the process_include_results method of the IncludedFile class is working as expected.
    :return:
    '''

    # the class will be tested using the following example:
    # role R has a main.yml file with the following contents:
    # tasks:
    #   - include_tasks: foo.yml
    #   - include_tasks:
    #       - include foo.yml
    #       - include bar.yml
    #   - include_tasks:
    #       - include: foo.yml
    #         loop: "{{ var }}"
    #   - import_tasks: foo.yml

    # role R has a tasks/main.yml file with the following contents:
    # - include_tasks: foo.yml
    # - include_t

# Generated at 2022-06-11 10:10:52.895676
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    includedFile_1 = IncludedFile("some/file.yaml", [], [], 0)
    includedFile_2 = IncludedFile("some/file.yaml", [], [], 0)
    includedFile_3 = IncludedFile("some/file.yaml", [], [], 1)
    includedFile_4 = IncludedFile("other/file.yaml", [], [], 0)
    includedFile_5 = IncludedFile("some/file.yaml", ["some", "arguments"], [], 0)
    includedFile_6 = IncludedFile("some/file.yaml", [], ["some", "vars"], 0)

    assert includedFile_1 == includedFile_2
    assert includedFile_1 != includedFile_3
    assert includedFile_1 != includedFile_4
    assert includedFile_1 != includedFile_5
    assert included

# Generated at 2022-06-11 10:11:06.066432
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    task1 = TaskInclude()
    task1._uuid = 'task1_uuid'
    task1._role = None
    var_manager = VariableManager()
    var_manager._fact_cache = dict()
    var_manager._host_vars_files = dict()
    var_manager._host_vars = dict()
    var_manager._host_vars_override = dict()
    var_manager._play_vars = dict()


# Generated at 2022-06-11 10:11:14.815506
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:11:26.068990
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.plugins.loader import plugins
    from ansible.vars.manager import VariableManager

    loader = plugins.loader

    results = dict()

    # test normal task result
    results['foo'] = dict(
        _ansible_parsed=True,
        _ansible_item_result=False,
        changed=False,
        skipped=False,
        msg='ok',
        meta=dict(
            no_log=False,
        ),
        _ansible_no_log=False,
        include='./group_vars/all',
        include_args=dict(
            free_form=True,
        ),
    )
    results['foo']['include_args']['_raw_params'] = './group_vars/all'

    # test task result with loop

# Generated at 2022-06-11 10:12:10.320910
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins import callback_loader
    from ansible.executor import playbook_executor
    from ansible.inventory.host import Host
    from ansible.errors import AnsibleError

    class TestModule(object):
        def __init__(self, *args):
            self.args = args
            pass

        def run(self, tmp=None, task_vars=None):
            pass


# Generated at 2022-06-11 10:12:21.536544
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager, Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    # create fake hosts
    fake_hosts = []
    for i in range(0, 2):
        host = Host(name="fake_host{0}".format(i))
        fake_hosts.append(host)

    # create fake tasks with fake results
    def create_fake_task(action, loop=False, parent=None):
        task = action_loader.get(action, class_only=True)()
        task._role = None


# Generated at 2022-06-11 10:12:33.750961
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # First, mock a set of data to be passed to the method
    results = []
    results.append(('/etc/hosts', {'arg': 'value'}, {'var': 'value'}, 1, True, True))
    results.append(('/etc/ssh/ssh_config', {'arg': 'value'}, {'var': 'value'}, 2, True, True))

    # Define the method return
    expected_return = [
        "/etc/hosts (args=['arg': 'value'] vars={'var': 'value'}): [1]",
        "/etc/ssh/ssh_config (args=['arg': 'value'] vars={'var': 'value'}): [2]"
    ]

    # Call the method

# Generated at 2022-06-11 10:12:41.744779
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.playbook.task_include
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.plugins.loader import callback_loader


# Generated at 2022-06-11 10:12:53.095234
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    import copy
    import mock
    import os

    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    filename = os.path.abspath("included_file.yml")

    args = {}
    args["_raw_params"] = filename
    args["_role_path"] = os.path.dirname(filename)
    args["_parent"] = None

    task = mock.MagicMock()
    task.action = 'include'
    task.loop = False
    task.no_log = False
    task._uuid = "fake_uuid"
   

# Generated at 2022-06-11 10:13:04.269732
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    import io
    import sys
    import tempfile
    import pytest

    # Create sample playbook
    tf = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-11 10:13:10.655675
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task_include import TaskInclude

    def get_task_result(task, host, result):
        from ansible.executor.task_result import TaskResult
        res = TaskResult(task=task, host=host)
        res._result = result
        return res

    play_context = PlayContext()
    loader = DataLoader()
    var_manager = VariableManager(loader=loader)

    host = Host(name='localhost')


# Generated at 2022-06-11 10:13:21.041838
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.playbook.play_context
    import ansible.inventory.host
    import ansible.playbook.task
    import ansible.vars.manager

    host_name = 'localhost'
    hostvars = dict()
    loader = None
    inventory = ansible.inventory.host.Host(name=host_name)
    display = None
    variable_manager = ansible.vars.manager.VariableManager()
    play_context = ansible.playbook.play_context.PlayContext()
    inventory.set_variable(host_name, 'ansible_connection', 'local')

    task_name = 'setup'
    task_action = 'setup'
    task_args = dict()


# Generated at 2022-06-11 10:13:32.485300
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys
    if sys.version_info[0:2] < (2, 7):
        return # Can't use unittest.skipUnless

    import unittest
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.process.worker import TaskResult as WorkerTaskResult
    from ansible.playbook.task import Task

    # results: on-disk role with variables passed at include
    task = Task()
    task.action = 'import_role'
    task.args = {'name': 'foobar'}
    task._role = 'role_test_include'

# Generated at 2022-06-11 10:13:43.247603
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    host = 'dummy_host'
    task = 'dummy_task'
    include_results = [{'include_args' : {'_raw_params' : '/tmp/file.yml'},
                        '_ansible_item_label': '1',
                        'include': '/tmp/file.yml',
                        '_ansible_loop_var': 'item',
                        'ansible_loop': '1',
                        'ansible_index_var': 'var1'}]
    results = [{'_host': host, '_task': task}]
    results[0]['results'] = include_results

    # first test with no loader and variable_manager
    included_files = IncludedFile.process_include_results(results)
    assert len(included_files) == 1

# Generated at 2022-06-11 10:14:57.128812
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:15:10.352389
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.plugins import callback_loader

    # initialize needed objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    callback = callback_loader.get('json')

# Generated at 2022-06-11 10:15:22.732984
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class MyClass:
        """Random class for unit test purpose"""
        def __init__(self):
            self.results = []
            self.tasks = []

    class MyResult:
        """Random class for unit test purpose"""
        def __init__(self, host, task):
            self._host = host
            self._task = task
            self._result = {'include': 'include-file-name'}

    class MyTask:
        """Random class for unit test purpose"""
        def __init__(self, action):
            self.action = action
            self._parent = None

        def __repr__(self):
            return str(self.__class__) + ": " + str(self.__dict__)

        def copy(self):
            return self

    task = MyTask('include')
    task._

# Generated at 2022-06-11 10:15:36.297829
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/functional/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    play_context.loader = loader
    play_context.variable_manager = variable_manager
    play_context.inventory = inventory
    play_context.become = False


# Generated at 2022-06-11 10:15:40.871564
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    assert IncludedFile('filename1', 'args1', 'vars1', 'task1') == IncludedFile('filename1', 'args1', 'vars1', 'task1')
    assert IncludedFile('filename2', 'args2', 'vars2', 'task2') != IncludedFile('filename1', 'args1', 'vars1', 'task1')

# Generated at 2022-06-11 10:15:51.717141
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.executor.task_queue_manager
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins import loader as plugin_loader
    from ansible.plugins.callback import CallbackBase

    class MyLoader(DataLoader):
        def __init__(self, basedir=None):
            self._basedir = basedir

        def get_basedir(self):
            return self._basedir


# Generated at 2022-06-11 10:16:01.869999
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import copy
    import sys

    class FakeHost():
        def __init__(self, name):
            self.name = name

    class FakeTask():
        def __init__(self, uuid, parent, action='include'):
            self._uuid = uuid
            self._parent = parent
            self.action = action

    class FakeResult():
        def __init__(self, task, host, result):
            self._task = task
            self._host = host
            self._result = result


# Generated at 2022-06-11 10:16:13.864396
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor import module_common
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    loader.set_basedir(os.path.join(os.path.dirname(__file__), 'vars'))

    inventory = InventoryManager(loader=loader, sources=['localhost'])
    inventory.subset('all')



# Generated at 2022-06-11 10:16:23.525507
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class FakePlay:
        def __init__(self):
            self._ds = {
                'name': 'fake-play',
                'hosts': 'fake-hosts'
            }
    class FakeHost:
        def __init__(self, name):
            self._ds = {
                'name': name
            }
    class FakeResult:
        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result

    class FakeTask:
        def __init__(self, name):
            self._ds = {
                'name': name
            }
            self.action = name
        def copy(self):
            return FakeTask('fake-copy')
        def __eq__(self, other):
            return self.action == other.action

# Generated at 2022-06-11 10:16:33.826791
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # test setup
    import unittest
    import tempfile
    import runpy
    import shutil
    import sys
    import types
    import json

    sys.path.append(os.path.abspath(os.path.join(__file__, '..', '..', '..', 'lib')))

    import ansible.errors
    import ansible.module_utils
    import ansible.module_utils.facts
    import ansible.module_utils._text
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.plugins
    import ansible.template

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.playbook_include import Playbook