

# Generated at 2022-06-11 10:08:12.594366
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    results = [IncludeResult(host='localhost', task=TaskInclude(), result={'include': './test/test.yml'}, _host='localhost', _task=TaskInclude())]
    included_files = IncludedFile.process_include_results(results, Play().get_iterator(), loader, variable_manager)

    assert included_files[0]._filename == './test/test.yml'
    assert included_files[0]._hosts[0] == 'localhost'



# Generated at 2022-06-11 10:08:24.772490
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.executor.task_result import TaskResult
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    import ansible.constants as C
    import os

    # AnsibleUnsafeText is used to test _ansible_no_log as _ansible_no_log can be set to a string value by mistake

# Generated at 2022-06-11 10:08:36.454839
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Importing unittest causes a warning to be logged by the display plugin
    # Ignore this error since the test is working as expected
    import logging
    logging.captureWarnings(True)
    from ansible.plugins.callback.logging import CallbackModule
    callback_instance = CallbackModule()
    callback_instance._display.verbosity = 4
    callback_instance._display.deprecate("message", "version", "method")

    include_files = [IncludedFile("/tmp/some_file", {}, {}, {})]
    include_files[0].add_host("localhost")

    try:
        include_files[0].add_host("localhost")
    except ValueError:
        # Test is working as expected: An exception is raised if a host is added twice
        pass

# Generated at 2022-06-11 10:08:48.012637
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class DummyParent:
        def __init__(self, uuid):
            self._uuid = uuid

    task = TaskInclude('dummy')
    task._parent = DummyParent('123')
    assert IncludedFile('a', 'b', 'c', task) == IncludedFile('a', 'b', 'c', task)
    assert not (IncludedFile('a', 'b', 'c', task) == IncludedFile('x', 'b', 'c', task))
    assert not (IncludedFile('a', 'b', 'c', task) == IncludedFile('a', 'x', 'c', task))
    assert not (IncludedFile('a', 'b', 'c', task) == IncludedFile('a', 'b', 'x', task))

    task2 = TaskInclude('dummy2')
    task._parent = D

# Generated at 2022-06-11 10:08:59.548290
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    test_file = os.path.splitext(os.path.basename(__file__))[0]
    test_dir = os.path.dirname(__file__)

    def test_include_args(include_path, include_args, expected_path):
        play_path = os.path.join(test_dir, include_path)
        play_data = dict()
        play_data['name'] = 'test include_tasks'
        play_data['hosts'] = 'all'
        play_data['gather_facts'] = 'no'

# Generated at 2022-06-11 10:09:09.557644
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook_include.task_include import TaskInclude
    from ansible.playbook_include.role_include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.utils.path import unfrackpath

    class TestTaskInclude(TaskInclude):
        action = 'include'

    class TestIncludeRole(IncludeRole):
        action = 'include_role'

    class TestVarsManager:
        def __init__(self):
            self.__data = dict()

# Generated at 2022-06-11 10:09:22.007444
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # test 1: object list1 contains object t1 and object t2; object list1 should equal to object list2
    t1 = IncludedFile('filename1', 'args1', 'vars1', 'task1')
    t2 = IncludedFile('filename2', 'args2', 'vars2', 'task2')
    list1 = [t1, t2]
    list2 = [t2, t1]
    assert set(list1) == set(list2)
    # test 2: object list1 contains object t1 and object t2; object list1 should not equal to object list3
    t3 = IncludedFile('filename2', 'args2', 'vars3', 'task3')
    list3 = [t2, t3]
    assert set(list1) != set(list3)

# Generated at 2022-06-11 10:09:32.231476
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Use a simple repr function to validate equality
    included_file = IncludedFile("a","b","c","d")
    included_file.add_host("e")
    assert repr(included_file) == IncludedFile("a","b","c","d").__repr__()
    included_file.add_host("e")
    with pytest.raises(ValueError):
        included_file.add_host("e")
    included_file.add_host("e")
    assert repr(included_file) == IncludedFile("a","b","c","d").__repr__()
    included_file.add_host("f")
    assert repr(included_file) != IncludedFile("a","b","c","d").__repr__()

# Generated at 2022-06-11 10:09:42.251473
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    import os

    loader = DataLoader()

    def create_result(include_str, action, action_result=None, loop=False, ansible_loop_var=None, ansible_index_var=None, **kwargs):
        result = {'include': include_str, 'changed': False, 'failed': False, 'invocation': {'module_args': include_str}, 'skip_reason': ''}
        if action_result is None:
            action_result = result

# Generated at 2022-06-11 10:09:49.655506
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    import pytest
    ImportIncludedFile = IncludedFile("filename.yaml", "args", "vars", "task")

    # test add_host
    ImportIncludedFile.add_host("host1")
    assert ImportIncludedFile._hosts == ["host1"]

    # test add_host with duplicate
    with pytest.raises(ValueError) as excinfo:
        ImportIncludedFile.add_host("host1")
    assert str(excinfo.value) == 'included file already contains this host'


# Generated at 2022-06-11 10:10:20.996561
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class TestIterator:
        class TestPlay:
            pass

    class TestLoader:
        def path_dwim_relative(self, basedir, path, target, is_role=False):
            return "%s/%s/%s" % (basedir, path, target)

    class TestVariableManager:
        def get_vars(self, play, host, task):
            return {'item': host}

    class TestResult:
        def __init__(self, host, task, is_role):
            self._host = host
            self._task = task
            self._result = {'include': '%s.yml' % host}
            if is_role:
                self._result['include_args'] = {'name': '..%s..' % host}


# Generated at 2022-06-11 10:10:31.229920
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="hosts")
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 10:10:43.885614
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor import task_result
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError

    display = Display()

    results = list()

    loader = DataLoader()

    variable_manager = VariableManager()

    # Make sure we have a display to capture any

# Generated at 2022-06-11 10:10:53.360692
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude, IncludeRole
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager

    tt = Templar(variables=dict())

    results = []

# Generated at 2022-06-11 10:11:02.121986
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    results = []
    results.append(IncludedFile())

    included_files = IncludedFile.process_include_results(results, None, None, None)
    assert len(included_files) == 1
    assert included_files[0]._filename == None
    assert included_files[0]._args == None
    assert included_files[0]._vars == None
    assert included_files[0]._task == None
    assert included_files[0]._hosts == []
    assert included_files[0]._is_role == False

# Generated at 2022-06-11 10:11:12.600246
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile('a', 'b', {}, {}, is_role=True)
    b = IncludedFile('a', 'b', {}, {}, is_role=True)
    c = IncludedFile('c', 'b', {}, {}, is_role=True)
    d = IncludedFile('a', 'd', {}, {}, is_role=True)
    e = IncludedFile('a', 'b', {'a':1}, {}, is_role=True)
    f = IncludedFile('a', 'b', {}, {'a':1}, is_role=True)
    g = IncludedFile('a', 'b', {}, {}, is_role=False)
    h = IncludedFile('a', {'a':1}, {}, {}, is_role=True)

    assert a == a
    assert a == b


# Generated at 2022-06-11 10:11:23.903340
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:11:35.111994
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 10:11:42.988258
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # define test cases
    tasks = [
        {
            'include': 'test1.yml',
            'loop': '{{ result }}',
            'loop_control': {
                'loop_var': 'item'
            },
            'action': 'include_tasks',
            'name': ''
        },
        {
            'roles': [
                {
                    'role': 'test_role',
                    'tasks_from': 'tests/tasks/test_include_role.yml'
                }
            ],
            'action': 'include_role',
            'name': 'include role test'
        }
    ]
    play = {
        'name': 'test play',
        'hosts': 'all'
    }

# Generated at 2022-06-11 10:11:54.890771
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:12:31.983344
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Test cases
    class TestCase1:
        def __init__(self):
            self._filename = "filename"
            self._args = ["arg1", "arg2"]
            self._vars = {"var1": "value1", "var2": "value2"}
            self._task = object()
    class TestCase2:
        def __init__(self):
            self._filename = "filename"
            self._args = ["arg1", "arg2"]
            self._vars = {"var1": "value1", "var2": "value2"}
            self._task = object()
            self._task._uuid = 100
            self._task._parent = object()
            self._task._parent._uuid = 200

# Generated at 2022-06-11 10:12:39.200539
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.utils.cache import ResultCache
    from ansible.vars import VariableManager
    from ansible.plugins.loader import connection_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    my_cache = ResultCache()

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    host = inv_manager.get_hosts('localhost')[0]
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)


# Generated at 2022-06-11 10:12:50.310735
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    class MockRole(Role):
        def __init__(self, name, path):
            self._role_name = name
            self._role_path = path

    class MockIterator(object):
        def __init__(self, play):
            self._play = play

    class MockPlay(Play):
        def __init__(self, basedir):
            self._basedir = basedir

        def get_basedir(self):
            return self._basedir

# Generated at 2022-06-11 10:13:01.749598
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Equal
    f = IncludedFile('foo', 'a', 'b', 'c')
    f2 = IncludedFile('foo', 'a', 'b', 'c')
    assert f == f2
    # Different filename
    f = IncludedFile('foo', 'a', 'b', 'c')
    f2 = IncludedFile('bar', 'a', 'b', 'c')
    assert f != f2
    # Different args
    f = IncludedFile('foo', 'a', 'b', 'c')
    f2 = IncludedFile('foo', 'a', 'd', 'c')
    assert f != f2
    # Different vars
    f = IncludedFile('foo', 'a', 'b', 'c')
    f2 = IncludedFile('foo', 'a', 'b', 'd')
    assert f != f2
    # Different

# Generated at 2022-06-11 10:13:09.540016
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task_include import TaskInclude

    pc = PlayContext()
    tr = TaskResult(host=dict(name='host1'), task=dict(name='task1'), task_fields=dict(name='task1', loop='item'))

# Generated at 2022-06-11 10:13:19.870602
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    class MyIterator(object):
        def __init__(self, play):
            self._play = play

        @property
        def play(self):
            return self._play

    class MyPlay(object):
        def __init__(self):
            self.hosts = ['server1']

    class MyHost(object):
        pass

    class MyTask(object):
        def __init__(self, action, parent=None):
            self._uuid = '1111'
            self.action = action
            self.loop = 'with_items'
            self.no_log = False
           

# Generated at 2022-06-11 10:13:30.303501
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import copy
    import unittest.mock
    import ansible.playbook.task_include
    import ansible.playbook.role_include
    import ansible.vars.manager
    import ansible.utils.vars
    import ansible.template


    # initialize objects for use in the test
    mock_loader = unittest.mock.Mock()
    mock_variable_manager = unittest.mock.Mock()

    included_files = []


# Generated at 2022-06-11 10:13:42.345755
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    Ensure the method process_include_results is working correctly
    """
    from ansible.plugins import action
    from ansible.plugins.action.include_tasks import ActionModule as IncludeTasks
    from ansible.plugins.action.role import ActionModule as IncludeRole
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({'./foo.yml': '{"include": "bar.yml"}',
                             './bar.yml': '{"include": "baz.yml"}',
                             './baz.yml': '{"include": "foo.yml"}',
                             './qux.yml': '{}'})

    include_tasks_1 = IncludeTasks()

# Generated at 2022-06-11 10:13:52.336856
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader
    from ansible.vars import VariableManager

    loader = module_loader._loaders['']

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()

    display = Display()
    play_context = PlayContext()


# Generated at 2022-06-11 10:14:02.502313
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    loader = None

    mock_inventory = """
    [localhost]
    127.0.0.1
    """
    inventory = InventoryManager(loader=loader, sources=mock_inventory)
    play_context = PlayContext()
    play = Play().load("localhost", dict(name="test play", hosts=["localhost"]), loader=loader, variable_manager=variable_manager,
        loader=loader)
    tqm = None

# Generated at 2022-06-11 10:15:00.318253
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    
    loader = DataLoader()
    variable_manager = VariableManager()
    hosts = InventoryManager(loader=loader, sources=['./test/inventory'])
    variable_manager.set_inventory(hosts)


# Generated at 2022-06-11 10:15:06.426060
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class FakeIterator:
        _play = object()
    results = [object()]
    loader = object()
    variable_manager = object()
    included_files = IncludedFile.process_include_results(results, FakeIterator(), loader, variable_manager)
    assert included_files == []

# Generated at 2022-06-11 10:15:19.946331
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader


    variable_manager=VariableManager()
    loader=DataLoader()

# Generated at 2022-06-11 10:15:27.067223
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    #setup
    import unittest
    import time

    import ansible.executor.task_result as task_result
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.playbook.play_context import PlayContext

    class IncludeMock(TaskInclude):
        def __init__(self, args, task_list, no_log=False, from_files=None):
            self.action = u'include'
            self.from_files = from_files or {}
            self.no_log = no_log
            self.args = args

# Generated at 2022-06-11 10:15:39.601889
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    task_result = TaskResult('localhost', TaskInclude('included.yml', {}), {}, {'include': 'test.yml'})
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'extra': 'var'}

    result_list = [task_result]
    results = IncludedFile.process_include_results(result_list, Play()._iterator, DataLoader(), variable_manager)
    print(results)
   

# Generated at 2022-06-11 10:15:44.462090
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-11 10:15:48.410054
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    includedfile1 = IncludedFile("filename","args","vars","task")
    includedfile2 = IncludedFile("filename","args","vars","task")
    assert includedfile1 == includedfile2


# Generated at 2022-06-11 10:15:55.399567
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import unittest
    class TestIncludedFile_process_include_results(unittest.TestCase):
        def test_IncludedFile_process_include_results_one_file(self):
            from ansible.executor.task_result import TaskResult
            from ansible.playbook.play_context import PlayContext
            from ansible.playbook.task import Task
            from ansible.playbook.play import Play
            from ansible.inventory.manager import InventoryManager
            from ansible.vars.manager import VariableManager
            include_file_names = ['include_file']

            def path_dwim(path):
                return path

            class FakeLoader():
                def path_dwim(self, path):
                    return path

            loader = FakeLoader()
            host = InventoryManager().get_host('localhost')
           

# Generated at 2022-06-11 10:15:56.385188
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO: Write this test
    pass

# Generated at 2022-06-11 10:16:07.058011
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.factory import Factory as ProcessFactory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import action_loader

    class NullInventory:

        def __init__(self):
            self._hosts = dict()
