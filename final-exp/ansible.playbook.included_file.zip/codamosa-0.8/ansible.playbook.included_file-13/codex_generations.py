

# Generated at 2022-06-11 10:08:14.824693
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # We shouldn't compare objects of different types
    assert IncludedFile(None, None, None, None) != object()


# Generated at 2022-06-11 10:08:26.464478
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    class FakeVariableManager:

        def get_vars(self, _play, host, task):
            return {'foo': 'bar'}

    class FakeTask:

        def __init__(self, action, loop, no_log, parent, role=None):
            self.action = action
            self.loop = loop
            self.no_log = no_log
            self._parent = parent
            self._role = role

        def get_search_path(self):
            return ['./_search_path']

        def copy(self):
            return FakeTask(self.action, self.loop, self.no_log, self._parent, role=self._role)

    class FakeResult:

        def __init__(self, host, task, result, _uuid=None):
            self._host = host
            self._task

# Generated at 2022-06-11 10:08:37.805559
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import plugin_loader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["tests/inventory/host_vars_inventory"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    playbook_path = 'tests/playbooks/include_results.yml'

# Generated at 2022-06-11 10:08:45.649811
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """ Test method __eq__ of class IncludedFile.
    """
    # Test 1: Normal case
    if1 = IncludedFile('f1', 1, 2, 3)
    if2 = IncludedFile('f1', 1, 2, 3)
    if3 = IncludedFile('f1', 1, 3, 3)
    assert if1 == if1
    assert if1 == if2
    assert if1 != if3

    # Test 2: Different types
    assert if1 != 4


# Generated at 2022-06-11 10:08:57.254334
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    task1 = TaskInclude()
    task1._parent = ''
    task1._uuid = ''

    task2 = TaskInclude()
    task2._parent = ''
    task2._uuid = ''

    task3 = TaskInclude()
    task3._parent = None
    task3._uuid = 'notNone'

    task4 = TaskInclude()
    task4._parent = ''
    task4._uuid = ''

    task5 = TaskInclude()
    task5._parent = None
    task5._uuid = 'notNone2'


# Generated at 2022-06-11 10:09:08.086812
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task

    i1 = IncludedFile("file.yml", None, None, Task())
    i2 = IncludedFile("file.yml", None, None, Task())

    assert(i1 == i2)

    i3 = IncludedFile("file.yml", {'a': 1}, {'b': 2}, Task())

    assert(i1 != i3)

    from ansible.playbook.role import Role

    i1 = IncludedFile("file.yml", None, None, Task(Task(), Role()))
    i2 = IncludedFile("file.yml", None, None, Task(Task(), Role()))

    assert(i1 == i2)

    i3 = IncludedFile("file.yml", {'a': 1}, {'b': 2}, Task(Task(), Role()))



# Generated at 2022-06-11 10:09:20.840664
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    filename = "playbook1.yml"
    args = dict()
    vars = dict()
    play = Play()
    task = Task()
    is_role = False
    incFile1 = IncludedFile(filename, args, vars, task)
    incFile2 = IncludedFile(filename, args, vars, task)
    assert incFile1 == incFile2

    filename = "playbook3.yml"
    incFile3 = IncludedFile(filename, args, vars, task)
    assert incFile1 != incFile3

    args = "Args"
    incFile4 = IncludedFile(filename, args, vars, task)
    assert incFile3 != incFile4

    vars = "vars"
   

# Generated at 2022-06-11 10:09:31.461425
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    # Check that it returns true if the files have the same task
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    filename="dummy"
    args="dummy"
    vars="dummy"
    task=Task()
    inc1=IncludedFile(filename, args, vars,task)
    inc2=IncludedFile(filename, args, vars,task)
    assert inc1 == inc2

    # Check that it returns false if the files have different tasks
    task1=Task()
    task2=Task()
    inc1=IncludedFile(filename, args, vars,task1)
    inc2=IncludedFile(filename, args, vars,task2)
    assert not inc1 == inc2


# Generated at 2022-06-11 10:09:41.180152
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved
    from ansible.playbook.play import Play
    from ansible.template import Templar

    # Create temporary file for role
    from tempfile import mkstemp
    from shutil import move, copyfile
    from os import remove, close

    fh, original_file = mkstemp()
    with os.fdopen(fh, 'w') as new_file:
        new_file.write('original file\'s content')
    original_file_content = 'original file\'s content'

    # Create temporary role
   

# Generated at 2022-06-11 10:09:51.751510
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.utils.display import Display
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    class fake_loader(MutableMapping):
        def __init__(self):
            self.contents = {}
            self.basedir = None
        def __setitem__(self, key, value):
            self.contents[key] = value
        def __len__(self):
            return len(self.contents)
        def __getitem__(self, key):
            return self.contents[key]

# Generated at 2022-06-11 10:10:17.620187
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import ansible.playbook

    display.verbosity=1
    class MockTaskInclude:
        def __init__(self):
            self.action='include'
            self.loop=None
            self._parent=None
            self.no_log=None
            self._role_path=None
            self._role=None
            self._role_name=None
            self._from_files=dict()
            self.FROM_ARGS=['vars_from', 'include_vars_from', 'defaults_from']

        def copy(self):
            return MockTaskInclude()

        def get_search_path(self):
            return list()

        def _uuid(self):
            return 'uuid'

        def _parent_uuid(self):
            return 'parent_uuid'


# Generated at 2022-06-11 10:10:26.256318
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import __main__
    import copy

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyBase
    from ansible.vars.manager import VariableManager

    __main__.display = Display()

    class ResultsCollector(object):

        def __init__(self):
            self._result_q = []
            self._host_ok = {}
            self._host_failed = {}
            self._host_skipped = {}

        def _new_result(self, host, task, task_result=None):
            return Result(host, task, task_result)


# Generated at 2022-06-11 10:10:39.825467
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # Create the inventory, loader, variable manager and task queue manager
    loader = DataLoader()
    path = loader.path_dwim('test_include_task.yml')
    parser = InventoryManager(loader=loader, sources=path)
    variable_manager = VariableManager(loader=loader, inventory=parser)
    variable_manager._extra_vars = {'testvar': 'test_value'}
    variable_manager.set_inventory(parser)

    # initialize needed objects
    results_callback = None

# Generated at 2022-06-11 10:10:50.854436
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task

    t1 = Task()
    t1._uuid = 'abcdef'
    t2 = Task()
    t2._uuid = '123456'
    t1._parent = t2
    t2._parent = None

    t1._role = None
    t2._role = None

    loader = None

    variable_manager = None


# Generated at 2022-06-11 10:11:02.910104
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    file1 = IncludedFile('file1', {'a': 1}, {'b': 2}, 'task1')
    file2 = IncludedFile('file2', {'a': 1}, {'b': 2}, 'task1')
    file3 = IncludedFile('file2', {'a': 1}, {'b': 2}, 'task2')
    file4 = IncludedFile('file2', {'a': 2}, {'b': 2}, 'task2')
    file5 = IncludedFile('file2', {'a': 1}, {'b': 3}, 'task2')
    file6 = IncludedFile('file1', {'a': 1}, {'b': 2}, 'task1')

    assert file1 != file2
    assert file2 != file3
    assert file2 != file4
    assert file2 != file5

# Generated at 2022-06-11 10:11:04.025697
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-11 10:11:12.445942
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    incfile_1 = IncludedFile('/etc/ansible/roles', {}, {}, object())
    incfile_2 = IncludedFile('/etc/ansible/roles', {}, {}, object())
    incfile_3 = IncludedFile('/etc/ansible/roles', {'arg': 'value'}, {}, object())
    incfile_4 = IncludedFile('/etc/ansible/roles', {'arg': 'value'}, {}, object())

    assert incfile_1.__eq__(incfile_2)
    assert not incfile_1.__eq__(incfile_3)
    assert incfile_3.__eq__(incfile_4)

# Generated at 2022-06-11 10:11:23.720341
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    def mock_results(**kwargs):
        class obj:
            pass
        o = obj()
        o.__dict__.update(kwargs)
        return o

    class mock_play:
        pass

    class mock_host:
        pass

    class mock_task:
        pass

    class mock_variable_manager:
        def get_vars(self, **kwargs):
            return {}

    class mock_loader:
        def __init__(self, *args, **kwargs):
            pass

    class mock_templar:
        def __init__(self, *args, **kwargs):
            pass

        def template(self, *args, **kwargs):
            return 'template'

    class mock_inventory:
        def __init__(self, *args, **kwargs):
            pass



# Generated at 2022-06-11 10:11:34.941850
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    class DummyResource(IncludedFile):
        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result    

    class TestTask(Task):
        def __init__(self, *args):
            super(TestTask, self).__init__(*args)
            self._uuid = 1

    class TestIncludeTask(TaskInclude):
        def __init__(self, *args):
            super(TestIncludeTask, self).__init__(*args)
            self._uuid = 1


# Generated at 2022-06-11 10:11:44.091578
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins import module_loader
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    fake_loader = module_loader.ModuleLoader(None, '', '', AnsibleCollectionConfig())

    task = Task()
    task.action = C.ACTION_INCLUDE
    task.name = "test"
    task.vars = dict(include="{{ test_include }}")

# Generated at 2022-06-11 10:12:11.969383
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # Test code
    import json
    with open('../unit_test/json/result.json') as f:
        results = json.load(f)

    included_files = IncludedFile.process_include_results(results, None, None, None)
    print(included_files)

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-11 10:12:23.648208
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # some test data
    t1_res = TaskResult(host=dict(name='localhost'), task=None, return_data=dict())
    t1_res._result = dict(failed=False, _ansible_no_log=False, _ansible_item_label='localhost')
    t1_

# Generated at 2022-06-11 10:12:35.219774
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import unittest
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.plugins.filter
    import ansible.plugins.lookup
    import ansible.plugins.test
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.vars.manager import VariableManager

    # this class is used to do the initialization for unit testing,
    # and to wrap the object we're testing with a couple helper methods
    class TestIncludedFile(IncludedFile):
        def __init__(self, filename, args, vars, task, is_role=False):
            super(TestIncludedFile, self).__init

# Generated at 2022-06-11 10:12:42.549959
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:12:53.865264
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import StringIO

    class MockIterator(object):
        def __init__(self):
            self._play = {'name': 'localhost'}

    class MockTask(object):
        def __init__(self, action):
            self.action = action
            self.loop = False
            self.no_log = False
            self._uuid = 'test_uuid'
            self._role_name = None
            self._role = None
            self._parent = None

# Generated at 2022-06-11 10:13:04.896785
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    '''
    test process_include_results of IncludedFile
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.plugins.loader import role_loader


# Generated at 2022-06-11 10:13:14.431393
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class TestIncludedFile:
        def __init__(self, filename, args, vars, task):
            self._filename = filename
            self._args = args
            self._vars = vars
            self._task = task
            self._hosts = []

        def __eq__(self, other):
            return (other._filename == self._filename and
                    other._args == self._args and
                    other._vars == self._vars and
                    other._task._uuid == self._task._uuid and
                    other._task._parent._uuid == self._task._parent._uuid)

        def __repr__(self):
            return "%s (args=%s vars=%s): %s" % (self._filename, self._args, self._vars, self._hosts)


# Generated at 2022-06-11 10:13:25.154007
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    play_context = PlayContext()
    task = AnsibleTaskInclude('include_test/test_test.yml', dict(), play_context, '/test/test.yml')

# Generated at 2022-06-11 10:13:32.485130
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filename = "/return.yml"
    args = "thisisargs"
    vars = "thisisvars"
    task = "thisistask"

    includedFile = IncludedFile(filename, args, vars, task)
    sameIncludedFile = IncludedFile(filename, args, vars, task)
    differentIncludedFile = IncludedFile(filename, args, vars, task)

    assert includedFile == sameIncludedFile
    assert includedFile != differentIncludedFile

# Generated at 2022-06-11 10:13:34.252401
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO: to be implemented
    assert False

# Generated at 2022-06-11 10:14:27.208306
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    loader = DataLoader()
    context = PlayContext()
    context._task = Task()
    context._task.action = 'include_tasks'
    context._task.loop = False
    context._task.no_log = True
    context._task.args = dict()
    context._task._role = None

    play = Play()
    play._loader = loader

# Generated at 2022-06-11 10:14:37.662031
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import os
    import tempfile

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    from ansible.plugins.loader import action_loader

    loader = action_loader._create_loader()

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a nested directory structure
    include_dir = os.path.join(temp_dir, 'include_dir')
    os.mkdir(include_dir)

    include_subdir = os.path.join(include_dir, 'include_subdir')
    os.mkdir(include_subdir)

    # Create a couple of include files

# Generated at 2022-06-11 10:14:50.812341
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # both are TaskInclude
    task_include_a = TaskInclude(action='include', args={'name': '/etc/foo.yml'}, play=None)
    task_include_a._has_run = True
    task_include_a._parent = None
    task_include_b = TaskInclude(action='include', args={'name': '/etc/foo.yml'}, play=None)
    task_include_b._has_run = True
    task_include_b._parent = None
    # one IncludeRole, one TaskInclude
    task_include = TaskInclude(action='include', args={'name': '/etc/foo.yml'}, play=None)
    task_include._has_run = True
    task_include._parent = None

# Generated at 2022-06-11 10:14:59.486016
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    # Set up test data
    included_files = []

    # Test with a single TaskInclude
    task_include = TaskInclude(name='some_include', parent=Task())
    task_include.args = {'_raw_params': 'some_file.yml'}
    task_vars = {'omit': 'omitted-result'}
    iterator = BaseTestIterator()
    loader = BaseTestLoader()
    variable_manager = BaseTestVariableManager()

# Generated at 2022-06-11 10:15:13.615528
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    my_vars = dict(omit='omited')
    my_play = Play().load({'name': 'some play'}, variable_manager=None, loader=None)
    my_task = Task().load(dict(
        include='to_include',
        include_dir='dir_to_include',
        include_tasks='tasks_to_include',
        import_playbook='playbook_to_import',
        import_tasks='tasks_to_import',
        import_role='role_to_import',
        register='result',
        omit='token'
    ), play=my_play, variable_manager=None)
    my_host

# Generated at 2022-06-11 10:15:18.925924
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class IncludedFileTest(IncludedFile):
        def __init__(self, x):
            self.x = x
        def __eq__(self, other):
            return (self.x == other.x)

    assert IncludedFileTest(1) == IncludedFileTest(1)

# Generated at 2022-06-11 10:15:26.548449
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    import ansible.playbook.play_iterator as play_iterator
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    fake_play = play_iterator.Play()
    fake_play._role_name = 'test'
    fake_play._is_role = True

    fake_play.playbook = 'playbook.yml'
    fake_play.basedir = '.'
    fake_play.roles = []
    fake_play.role_vars = {}
    fake_play.extra_vars = {}



# Generated at 2022-06-11 10:15:39.561169
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Initialize test variables
    class Host:
        def __init__(self, host):
            self.name = host
    class Play:
        def __init__(self, play):
            self.name = play
    class Task:
        def __init__(self, task):
            self._parent = task
            self._role_name = None
            self._from_files = {}
    class RunnerResult:
        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result
    class VariableManager:
        def get_vars(self, play=None, host=None, task=None):
            return {}
    class Loader:
        def __init__(self, basedir):
            self.basedir = basedir

# Generated at 2022-06-11 10:15:50.925423
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import pprint
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 10:16:01.082724
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    ##########################################################################
    # Create a PlayContext object, which is required to pass to a TaskExecutor
    # object.
    ##########################################################################
    play_context = PlayContext()

    ##########################################################################
    # Create an inventory, which is required to create a VariableManager object.
    ##########################################################################
    loader = None
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    ##########################################################################
    # Create a ResultCallback for test
    class TestResultCallback:
        def __init__(self):
            self.results = []


# Generated at 2022-06-11 10:17:40.056003
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import callback_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole

    dataloader = DataLoader()