

# Generated at 2022-06-11 10:08:13.010093
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    playbook = unittest_mock.MagicMock()
    playbook.hostvars = unittest_mock.MagicMock()
    playbook._basedir = '/etc/ansible/playbook'

    context = PlayContext(play=playbook)


# Generated at 2022-06-11 10:08:25.070384
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    '''
    Ensure that IncludedFile._process_include_results
    iterates over the include results for each task,
    adds the included files to the included files list,
    and adds hosts to included files in the included files list.
    '''
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager

    # Create results, loader, and variable manager
    # Make VariableManager
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory())

    # Make loader
    loader = DataLoader()

    # Make iterator

# Generated at 2022-06-11 10:08:37.021673
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    class FakeIncludedFile(IncludedFile):

        def __init__(self, filename, args, hosts):
            self._filename = filename
            self._args = args
            self._hosts = hosts

    loader = FakeLoader({'a': ['a', 'b'],
                         'a_a': ['a.a', 'b'],
                         'b': ['b', 'a'],
                         'a_b': ['a.b', 'a'],
                         'a_b_c': ['a.b.c', 'a'],
                         'b_c': ['b.c', 'a']
                         })
    variable_manager = FakeVariableManager()

    results = []

# Generated at 2022-06-11 10:08:49.077163
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import unittest
    import tempfile
    import shutil
    import os

    # Helper method to create a temporary directory and to add it to the class path
    def get_temp_directory(self):
        # Create a temp directory
        temp_directory = tempfile.mkdtemp()
        # Add it to the class path
        self.addCleanup(shutil.rmtree, temp_directory)
        return temp_directory

    def create_file(self, directory, filename, content):
        file_path = os.path.join(directory, filename)
        with open(file_path, 'w') as f:
            f.write(content)
        return file_path

    # Unit test base class

# Generated at 2022-06-11 10:09:00.506341
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    PLAYBOOK_VARS = dict(
        ntp_ip=['192.168.1.1', '10.0.0.1', '127.0.0.1'],
        ntp_hw=['192.168.1.2', '10.0.0.2', '127.0.0.2'],
    )
    HOST_VARS = dict(
        ntp_port=['123', '456', '789'],
    )

    pc = PlayContext()
    g

# Generated at 2022-06-11 10:09:10.102462
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # included_files.append(orig_inc_file)
    included_files = []

    # idx = 0
    idx = 0

    # while 1:
    while 1:

        # try:
        try:

            # pos = included_files[idx:].index(orig_inc_file)
            pos = included_files[idx:].index(orig_inc_file)
            # pos is relative to idx since we are slicing
            # use idx + pos due to relative indexing

            # inc_file = included_files[idx + pos]
            inc_file = included_files[idx + pos]

        # except ValueError:
        except ValueError:

            # included_files.append(orig_inc_file)
            included_files.append(orig_inc_file)
            # inc_

# Generated at 2022-06-11 10:09:22.828280
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader,host_list=[])

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    test_inventory_file = '../../test/ansible_test_inventory.yml'
    inventory.parse_inventory(
        hosts=test_inventory_file,
        groups=test_inventory_file
    )

# Generated at 2022-06-11 10:09:32.812306
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task

    class FakeTask(Task):
        def __init__(self):
            self.action = None
            self.loop = None
            self.loop_args = None
            self.name = None
            self.tags = None
            self.when = None
            self.notify = None
            self.first_available_file = None
            self.args = {}
            self._uuid = None
            self._parent = None

        def __repr__(self):
            return "FakeTask"

    fake_task = FakeTask()

    class FakeHost:
        def __init__(self):
            self.name = "fake_host_name"

    included_file1 = IncludedFile("fake_filename", None, None, fake_task)

# Generated at 2022-06-11 10:09:43.714597
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.plugins.loader import action_loader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['localhost']))
    variable_manager.set_vault_secrets([])
    variable_manager.extra_vars = {'system': 'Linux'}


# Generated at 2022-06-11 10:09:53.481300
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.yaml.objects import AnsibleUnicode

    include_result1 = dict(include='/foo/bar', include_args=dict(one=1, two='two'))
    include_result2 = dict(include='/foo/bar', include_args=dict(one=2, two='two'))
    include_result3 = dict(include='/foo/bar', include_args=dict(one=1, two='three'))

    original_task = AnsibleUnicode()

    include_results = [include_result1, include_result2, include_result3]
    res1 = TaskResult(original_task, include_results[0])
    res2 = TaskResult(original_task, include_results[1])
   

# Generated at 2022-06-11 10:10:15.951195
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved
    import ansible.inventory.manager

    reserved_vars = Reserved(
        'test',
        play=dict(
            name='test',
            path='/some/path',
            _ds=dict(),
            _entries=[],
            _included_file_parents=dict(),
            _vars=dict(),
        ),
        play_uuid='uuid',
        loader=None,
        inventory=ansible.inventory.manager.InventoryManager('/some/path/hosts'),
        variable_manager=VariableManager(),
        options=dict(),
        internal_run=False,
    )

    task_vars = reserved_vars.copy

# Generated at 2022-06-11 10:10:25.402178
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    class FakeIterator():
        def __init__(self, play):
            self._play = play

    class FakeLoader():
        def __init__(self, basedir):
            self.basedir = basedir
        def get_basedir(self):
            return self.basedir

    class FakeVariableManager():
        def __init__(self, variables):
            self.variable_manager = variables

        def get_vars(self, play, host, task):
            return self.variable_manager

    class FakeTask():
        def __init__(self, parent, no_log):
            self._parent = parent
            self.no_log = no_log

        def get_search_path(self):
            return 'test/test_playbook'


# Generated at 2022-06-11 10:10:38.850716
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-11 10:10:50.093031
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert IncludedFile("a","b","c",1) == IncludedFile("a","b","c",1)
    assert IncludedFile("a","b","c",1) == IncludedFile("a","b","c",2)
    assert IncludedFile("a","b","c",1) == IncludedFile("a","b","d",1)
    assert IncludedFile("a","b","c",1) == IncludedFile("a","d","c",1)
    assert IncludedFile("a","b","c",1) == IncludedFile("f","b","c",1)
    assert not IncludedFile("a","b","c",1) == IncludedFile("f","b","c",1,True)
    assert not IncludedFile("a","b","c",1) == IncludedFile("f","b","c",1,True) == IncludedFile("a","b","c",1)

# Generated at 2022-06-11 10:11:02.016067
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    from ansible.playbook.task import Task

    class FakeIterator:
        def __init__(self):
            self._play = 'fake_play'

    class FakeHost:
        def __init__(self, name):
            self.name = name

    class FakeLoader:
        def get_basedir(self):
            return 'fake_basedir'

    class FakeVariableManager:
        def __init__(self, host, task):
            self._host = host
            self._task = task


# Generated at 2022-06-11 10:11:12.563348
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    filenames = ['/path/to/file1.yml', '/path/to/file2.yml']
    args = [
        {'a': 1, 'b': 2},
        {'a': 2, 'b': 2}
    ]
    vars = [
        {'c': 1, 'd': 2},
        {'c': 2, 'd': 2}
    ]
    is_role = False
    included_files = [IncludedFile(filenames[0], args[0], vars[0], is_role),
                      IncludedFile(filenames[1], args[1], vars[1], is_role)]
    #print(included_files[1])
    #print(included_files[1] == included_files[1])

# Generated at 2022-06-11 10:11:23.858996
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    # create mock objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 10:11:35.051307
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    loader, inventory, variable_manager, play_context = Play().load('', '', '', '', False)
    iterator = play_context._play_context.get_iterator()


# Generated at 2022-06-11 10:11:44.147497
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test case: used multiple roles
    # ansible_playbook_path
    ansible_playbook_path = os.path.dirname(os.path.realpath(__file__)) + '/../../../test/integration/targets/test_playbook_include_role'
    loader=DataLoader()
    variable_manager=VariableManager()
    variable_manager._extra_vars = {}
    variable_manager._host_manager = HostManager()
    variable_manager._host_manager.add_group('test_group')
    variable_manager._host_manager.groups['test_group'].add_host(Host(name='test_host'))
    variable_manager._host_manager.get_host('test_host').set_variable('ansible_connection', 'local')
    variable_manager._fact_cache = dict

# Generated at 2022-06-11 10:11:55.757155
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor

    class ResultsCollector(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(ResultsCollector, self).__init__(*args, **kwargs)

# Generated at 2022-06-11 10:12:25.681059
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    context = PlayContext()
    context._init_vars()
    loader = action_loader.get('include', class_only=True)
    play = Play().load({}, loader=loader, variable_manager=None, loader_cache={})
    play._included_files = []
    executor = PlaybookExecutor(playbooks=[play], inventory=None, variable_manager=None, loader=None, options=None, passwords=None)
    display.verbosity = 3
    executor._tqm._stdout_callback

# Generated at 2022-06-11 10:12:36.178768
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Mocked objects
    class MyObj:
        def __init__(self, val):
            self.val = val

        def __eq__(self, other):
            return self.val == other.val

    # Dummy task
    task = MyObj('task_1')
    task.action = 'my_action'

    # Dummy host
    host_1 = MyObj('host_1')
    host_2 = MyObj('host_2')

    # Dummy result

# Generated at 2022-06-11 10:12:43.025693
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.action import ActionBase
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude, IncludeRole
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.module_utils.facts import Facts
    from ansible.module_utils.six import string_types, binary_type
    from ansible.module_utils.six.moves import StringIO
    import json

    class TestActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            results = []

# Generated at 2022-06-11 10:12:53.041975
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class MockTask:
        def __init__(self, parent, uuid):
            self._parent = parent
            self._uuid = uuid

    # create a chain of tasks up to 10 elements long
    chain = []
    for i in range(10):
        chain.append(MockTask(chain[-1] if len(chain) > 0 else None, chr(ord('a') + i)))
    # create a list of IncludedFiles equal to the chain of tasks
    inc_files = [IncludedFile('filename', 'args', 'vars', t) for t in chain]
    # make sure all pairs of IncludedFile are equal
    for i, j in zip(inc_files, inc_files):
        assert i == j

# Generated at 2022-06-11 10:13:04.225267
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    import tempfile
    import shutil
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """
        stores the result for access by unit tests
        """
        def __init__(self, *args, **kwargs):
            super(ResultCallback, self).__init__(*args, **kwargs)
            self.result = None

        def v2_runner_on_ok(self, result, **kwargs):
            self._clean_results(result._result, result._task.action)
            self.result = result

# Generated at 2022-06-11 10:13:06.150763
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = IncludedFile(None, None, None, None)
    b = IncludedFile(None, None, None, None)

    assert a == b

# Generated at 2022-06-11 10:13:16.040886
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    class MockHost:
        def __init__(self, name):
            self._name = name

        def __eq__(self, other):
            if hasattr(other, '_name'):
                return self._name == other._name
            return self._name == other

        def __ne__(self, other):
            return not self == other


# Generated at 2022-06-11 10:13:26.728510
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class FakeObj:
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return (other.value == self.value)

    class Dummy(IncludedFile):
        def __init__(self, filename, args, vars, task, is_role=False):
            super(Dummy, self).__init__(filename, args, vars, task, is_role)

        def add_host(self, host):
            if host not in self._hosts:
                self._hosts.append(host)
                return
            raise ValueError()

    included_object1 = Dummy("file1.yml", None, None, FakeObj("task_name"))

# Generated at 2022-06-11 10:13:39.063078
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
       Test with a set of possible results
       """
    import ansible.playbook
    import ansible.utils
    import ansible.executor.task_result
    import ansible.playbook.play
    import ansible.playbook.task

    fake_loader = DictDataLoader({'default': C.DEFAULT_HANDLER_TASK_PATH})


    fake_inventory = ansible.inventory.Inventory("")
    fake_variable_manager = ansible.utils.plugin_docs.get_variable_manager()
    fake_variable_manager.set_inventory(fake_inventory)


# Generated at 2022-06-11 10:13:47.215706
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    dummy1_vars = dict(a=1, b=2, c=3)

# Generated at 2022-06-11 10:14:37.505763
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    Test-case for class IncludedFile method process_include_results.

    :return:
    """
    import os
    import json
    import stat
    import sys
    import time
    import shutil
    import tempfile
    import unittest
    import subprocess

    import ansible
    import ansible.executor.task_queue_manager
    import ansible.inventory
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.plugins
    import ansible.utils.vars
    import ansible.vars

    from ansible.cli.playbook import PlaybookCLI
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block

# Generated at 2022-06-11 10:14:50.520923
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert IncludedFile("dummy", "dummy", "dummy", "dummy") == IncludedFile("dummy", "dummy", "dummy", "dummy")
    assert IncludedFile("dummy", "dummy", "dummy", "dummy") != "dummy"
    assert IncludedFile("dummy", "dummy", "dummy", "dummy") != IncludedFile("dummy1", "dummy1", "dummy1", "dummy")
    assert IncludedFile("dummy", "dummy", "dummy", "dummy") != IncludedFile("dummy", "dummy1", "dummy1", "dummy")
    assert IncludedFile("dummy", "dummy", "dummy", "dummy") != IncludedFile("dummy", "dummy", "dummy1", "dummy")

# Generated at 2022-06-11 10:14:57.407398
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    failed = 0
    failed += test_IncludedFile___eq___same()
    failed += test_IncludedFile___eq___different_filename_same_args_vars_task()
    failed += test_IncludedFile___eq___same_filename_different_args_vars_task()
    failed += test_IncludedFile___eq___same_filename_different_args()
    failed += test_IncludedFile___eq___different_filename_different_args_vars_task()
    if failed:
        raise Exception("failed %d tests for method IncludedFile.__eq__" % failed)

# Generated at 2022-06-11 10:15:10.586972
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import json
    import sys

    class FakeLoader(object):
        @staticmethod
        def path_dwim_relative(base, path, name, is_role=False):
            return '%s/%s/%s' % (base, path, name)

        def path_dwim(self, name):
            return '%s/%s' % (self.basedir, name)

    class FakeIterator(object):
        def __init__(self):
            self._play = None


# Generated at 2022-06-11 10:15:22.856124
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    """
    Test IncludedFile.process_include_results
    """
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    class MockPlay:
        pass

    class MockIterator:
        def __init__(self):
            self._play = MockPlay()

    class MockLoader:
        def __init__(self, basedir):
            self._basedir = basedir
            self._directory = basedir

        def get_basedir(self):
            return self._basedir

        def path_dwim_relative(self, path1, path2, path3):
            return self._directory + '/' + path3


# Generated at 2022-06-11 10:15:36.563518
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import random
    import string
    import copy
    import tempfile
    import shutil
    import os

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    def random_string(string_length=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(string_length))

    class AnsibleTask(object):
        def __init__(self, action, args):
            self.action = action

# Generated at 2022-06-11 10:15:47.647667
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.strategy import StrategyBase

    class TestStrategy(StrategyBase):
        NAME = 'test_strategy'

    plugin_loader.add_plugin(TestStrategy)



# Generated at 2022-06-11 10:15:55.170100
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    templar = Templar(loader=loader, inventory=inventory, variables={})
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    results = []

    # "original_host" should not be renamed
    original_host = "test_host"
    # "original_task" should not be renamed
    original_

# Generated at 2022-06-11 10:16:04.429629
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert IncludedFile('filename', 'args', 'vars', 'task') == IncludedFile('filename', 'args', 'vars', 'task')
    assert IncludedFile('file', 'args', 'vars', 'task') != IncludedFile('filename', 'args', 'vars', 'task')
    assert IncludedFile('filename', 'a', 'vars', 'task') != IncludedFile('filename', 'args', 'vars', 'task')
    assert IncludedFile('filename', 'args', 'v', 'task') != IncludedFile('filename', 'args', 'vars', 'task')
    assert IncludedFile('filename', 'args', 'vars', 't') != IncludedFile('filename', 'args', 'vars', 'task')

# Generated at 2022-06-11 10:16:16.371528
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    loader = None
    variable_manager = None
    iterator = None