

# Generated at 2022-06-25 05:24:28.987483
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    included_file_0.process_include_results()

# Generated at 2022-06-25 05:24:39.659570
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 11.5
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'kIzp'
    bool_0 = True
    included_file_0 = IncludedFile(float_0, set_0, str_0, bool_0)
    float_0 = -10.15
    set_1 = {float_0, float_0, float_0, float_0}
    str_1 = '\x1e\x1f\x1a\x07\n\t\x13\x1a \x07\t\x0c\x1b\x0c\x1e\x1d\n'
    bool_1 = True

# Generated at 2022-06-25 05:24:48.697530
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 44.0086014922
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'v'
    bool_0 = False
    included_file_0 = IncludedFile(float_0, set_0, str_0, bool_0)
    float_1 = 3.0
    assert included_file_0.__eq__(IncludedFile(float_1, set_0, str_0, bool_0))


# Generated at 2022-06-25 05:24:59.670833
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(str_0, float_0, set_0, bool_0)
    included_file_0.process_include_results(str_0, float_0, float_0, float_0)
    float_0    = 2810.84416
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'z0'
    bool_0 = False
    included_file_0 = IncludedFile(str_0, float_0, set_0, bool_0)
    included_file_0.process_include_results(str_0, float_0, float_0, float_0)
    float_0    = 2810.84416

# Generated at 2022-06-25 05:25:10.005647
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    set_0 = set([chr(9), to_text(10**0), to_text(10**0), to_text(10**0), to_text(10**0), chr(9), chr(9)])
    included_file_0 = IncludedFile(to_text(10**0), set_0, chr(9), chr(9))
    set_1 = set([chr(9), to_text(10**0), to_text(10**0), to_text(10**0), to_text(10**0), chr(9), chr(9)])
    included_file_1 = IncludedFile(to_text(10**0), set_1, chr(9), chr(9))

# Generated at 2022-06-25 05:25:19.400067
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 8343.35287
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'A0'
    bool_0 = False
    included_file_0 = IncludedFile(float_0, set_0, str_0, bool_0)
    float_1 = 633.02
    set_1 = {float_1, float_1, float_1, float_1}
    included_file_1 = IncludedFile(float_1, set_1, str_0, bool_0)
    included_file_2 = IncludedFile(float_0, set_0, str_0, bool_0)
    bool_0 = included_file_0.__eq__(included_file_1)

# Generated at 2022-06-25 05:25:21.735828
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [{'failed': False}]
    iterator = None
    loader = None
    variable_manager = None
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:25:33.009787
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -0.0025036128
    set_0 = {bool_0}
    str_0 = '8Fv#~7F]+b'
    bool_0 = False
    included_file_0 = IncludedFile(float_0, set_0, str_0, bool_0)
    float_1 = 163.329076
    set_1 = {str_0, float_0, float_0, float_1}
    str_1 = '~!@#$%^&*()'
    bool_1 = False
    included_file_1 = IncludedFile(float_1, set_1, str_1, bool_1)
    assert not included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:25:44.885506
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = 3243.49923
    set_0 = {float_0, float_0, float_0, float_0}
    str_0 = 'z0'
    bool_0 = True
    included_file_0 = IncludedFile(float_0, set_0, str_0, bool_0)
    float_1 = 3094.63925
    set_1 = {float_1, float_1, float_1, float_1}
    str_1 = 'z1'
    bool_1 = True
    included_file_1 = IncludedFile(float_1, set_1, str_1, bool_1)
    float_2 = 1145.74137
    set_2 = {float_2, float_2, float_2, float_2}

# Generated at 2022-06-25 05:25:55.545840
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    task_0 = TaskInclude({}, loader=None, play=None, task_vars=None, role=None)
    str_0 = 'z0'
    set_0 = {task_0, task_0}
    bool_0 = False
    original_task = IncludedFile(task_0, str_0, set_0, bool_0)
    task_vars = {}
    iterator = IncludedFile(task_0, str_0, set_0, bool_0)
    loader = IncludedFile(task_0, str_0, set_0, bool_0)
    variable_manager = IncludedFile(task_0, str_0, set_0, bool_0)
    result = IncludedFile.process_include_results(
        task_0, iterator, loader, variable_manager)
    assert result is not None

# Generated at 2022-06-25 05:26:13.986430
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True == True


# Generated at 2022-06-25 05:26:23.409002
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_28 = None
    var_29 = None
    var_

# Generated at 2022-06-25 05:26:30.628337
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = IncludedFile(var_0, var_0, var_0, var_0)
    var_1 = IncludedFile(var_0, var_0, var_0, var_0)
    var_2 = var_0.__eq__(var_1)
    assert var_2 == True


# Generated at 2022-06-25 05:26:35.286979
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test case: 1
    var_0 = None
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    var_1 = included_file_0.process_include_results()
    test_case_0()
    print("TEST: test_IncludedFile_process_include_results is complete")


# Generated at 2022-06-25 05:26:42.250841
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    var_1 = included_file_0.process_include_results()
    assert isinstance(var_1, list)
    assert len(var_1) == 0
    assert isinstance(var_1[0], IncludedFile)
    assert var_1[0]._filename == var_0
    assert var_1[0]._args == var_0
    assert var_1[0]._vars == var_0
    assert var_1[0]._task._uuid == var_0._uuid
    assert var_1[0]._task._parent._uuid == var_0._parent._uuid
    assert var_1[0]._hosts == list()

# Generated at 2022-06-25 05:26:49.656366
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        test_case_0()
    except(TypeError, ArgumentError, AssertionError) as e:
        raise(AssertionError(e))

# Unit tests for method add_host of class IncludedFile

# Generated at 2022-06-25 05:26:52.068140
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = None
    var_1 = IncludedFile(var_0, var_0, var_0, var_0)
    var_2 = IncludedFile.process_include_results(var_0, var_1, var_0, var_0)

# Generated at 2022-06-25 05:26:55.101071
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    var_0 = None
    try:
        var_1 = included_file_0.process_include_results(var_0)
    except:
        print('Exception caught')


# Generated at 2022-06-25 05:26:57.656165
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    var_0 = None
    try:
        var_1 = included_file_0.process_include_results(var_0)
        assert False
    except ValueError as ex:
        print(ex.args)
        assert True
        return
    assert False


# Generated at 2022-06-25 05:27:03.656594
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = IncludedFile(None, None, None, None)
    var_1 = IncludedFile(None, None, None, None)
    var_2 = var_1
    var_1.__eq__(var_2)

    var_3 = var_1.__eq__(var_2)
    assert var_3 == True


# Generated at 2022-06-25 05:27:17.960890
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = None
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    var_1 = included_file_0.process_include_results()

# Generated at 2022-06-25 05:27:20.686853
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = IncludedFile("filename", None, None, None)
    var_1 = IncludedFile("filename", None, None, None)
    var_2 = False
    var_3 = var_0 == var_1
    assert var_2 == var_3


# Generated at 2022-06-25 05:27:27.422203
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    vars = {
        "results": [
            {
                "_host": "localhost",
                "_task": "test_task",
                "ansible_loop_var": "var_0",
                "ansible_index_var": "var_1",
                "failed": False,
                "skipped": False,
                "include": "tasks/main.yml",
                "include_args": {
                    "name": "role_name",
                    "handler_from": "files/handlers.yml",
                    "meta_from": "files/meta.yml",
                    "tasks_from": "files/tasks.yml",
                    "vars_from": "files/vars.yml",
                    "allow_duplicates": True
                }
            }
        ]
    }
    included

# Generated at 2022-06-25 05:27:34.281067
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_1 = None
    var_2 = var_1
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_28 = None
   

# Generated at 2022-06-25 05:27:43.517508
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = u'~/ansible/test_cases/test0.yml'

# Generated at 2022-06-25 05:27:47.905099
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = IncludedFile(None, None, None, None)
    var_1 = IncludedFile(None, None, None, None)
    var_2 = None
    var_3 = var_0 == var_1
    var_4 = var_0 == var_2    
    assert var_3 == True
    assert var_4 == False

# Generated at 2022-06-25 05:27:51.466633
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = None
    included_file_1 = IncludedFile(var_0, var_0, var_0, var_0)
    included_file_1.__eq__()


# Generated at 2022-06-25 05:27:53.917563
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_1 = IncludedFile('unknown', 'unknown', 'unknown', 'unknown')
    var_2 = included_file_1.process_include_results()


# Generated at 2022-06-25 05:28:02.896958
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = 'test_value'
    var_1 = 'test_value'
    var_2 = 'test_value'
    var_3 = 'test_value'
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    included_file_1 = IncludedFile(var_1, var_1, var_1, var_1)
    var_4 = included_file_0.process_include_results(var_0, var_0, var_0)
    var_4 = included_file_1.process_include_results(var_1, var_1, var_1)
    var_4 = included_file_0.process_include_results(var_2, var_2, var_2)

# Generated at 2022-06-25 05:28:11.766886
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import random
    import pytest
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins import module_loader
    from ansible.plugins.connection import Connection
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.reserved import Reserved
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    # Generate a random string for the module_name

# Generated at 2022-06-25 05:28:51.218277
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = None
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    var_1 = included_file_0.process_include_results()

if __name__ == "__main__":
    reader = JUnitXmlReader("../test.xml")
    testcase_list = reader.get_all_testcase()
    print(testcase_list)
    test_obj = create_test_obj(testcase_list[0])
    test_obj.process()
    test_obj.write_file("test.py")
    print(test_obj.get_output())

    # test_case_0()

# Generated at 2022-06-25 05:28:56.001396
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_1 = IncludedFile()
    var_2 = None
    var_3 = [None]
    var_4 = [None]
    var_1.process_include_results(var_2, var_3, var_4)


# Generated at 2022-06-25 05:28:58.095711
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = IncludedFile(None, None, None, None)
    var_1 = var_0.process_include_results()

# Generated at 2022-06-25 05:29:03.749283
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = None
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    var_1 = included_file_0.process_include_results()


# Generated at 2022-06-25 05:29:11.357427
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = None
    var_1 = None
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    included_file_1 = IncludedFile(var_0, var_0, var_0, var_0)
    assert included_file_0.__eq__(included_file_1) == True


# Generated at 2022-06-25 05:29:18.206502
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = None
    var_1 = IncludedFile(var_0, var_0, var_0, var_0)
    var_2 = var_1.process_include_results()
    if var_2 is not None:
        print(var_2)
    else:
        raise RuntimeError("process_include_results() returned None")


# Generated at 2022-06-25 05:29:18.943790
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = IncludedFile.process_include_results()

# Generated at 2022-06-25 05:29:21.763414
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = None
    var_1 = IncludedFile(var_0,var_0,var_0,var_0)
    var_1 = IncludedFile.process_include_results(var_0,var_0,var_0,var_0)


# Generated at 2022-06-25 05:29:22.793254
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:29:27.481812
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = None
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    included_file_1 = IncludedFile(var_0, var_0, var_0, var_0)
    included_file_2 = IncludedFile(var_0, var_0, var_0, var_0)
    assert included_file_0.__eq__(included_file_1) == included_file_0.__eq__(included_file_2)


# Generated at 2022-06-25 05:30:39.041137
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


if __name__ == '__main__':
    import sys
    import nose

    argv = sys.argv[:]
    argv.append('--verbose')
    argv.append('--nocapture')
    nose.runmodule(argv=argv, defaultTest=__file__)

# Generated at 2022-06-25 05:30:49.099573
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    if not hasattr(IncludedFile, "process_include_results"):
        print('No method process_include_results defined for class IncludedFile')
        return

    # Test case 0
    var_0 = None
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    var_1 = included_file_0.process_include_results()
    var_2 = None
    try:
        var_2 = IncludedFile(var_0, var_0, var_0, var_0).process_include_results()
    except Exception as e:
        print('Cannot call method process_include_results of class IncludedFile: ', e)

if __name__ == "__main__":
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:30:56.075044
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = None
    var_1 = IncludedFile(var_0, var_0, var_0, var_0)
    var_2 = var_1.process_include_results()
    output = 'FOOBAR'
    assert var_2 == output, 'Expected: {}, but got: {}'.format(output, var_2)

# Generated at 2022-06-25 05:31:06.462920
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # this is our fake inventory
    class Host:
        def __init__(self, name):
            self.name = name
    inventory = {"testserver": [Host("testserver")]}

    # set up a fake play that only has one task
    class Play:
        pass
    play = Play()
    play._hosts = inventory
    play.hosts = inventory
    play._variable_manager = VariableManager(loader=DataLoader())

    # now the task
    task = Task()
    task._parent = play
    task._role = None
    task._role_name = None
    task

# Generated at 2022-06-25 05:31:15.470582
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    included_file_0 = IncludedFile(var_0, var_1, var_2, var_3)
    included_file_1 = IncludedFile(var_4, var_5, var_6, var_7)
    included_file_2 = IncludedFile(var_4, var_5, var_6, var_7)
    var_10 = included_file_0.__eq__(var_8)
    var_11 = included_file_1.__eq__(var_9)
    var_12 = included_file

# Generated at 2022-06-25 05:31:20.407885
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Pass in a mock object for results that has the same methods as the results
    # object returned by the Ansible run method
    mock_results = mock_IncludedFile()

    # Testing when the condition 'for res in results' is true, the variable iterator
    # is passed in for testing and has the same methods and variables as the iterator
    # object of the Ansible runner _play_executor method
    mock_iterator = mock_Iterator()

    # Testing when the condition 'if original_task.action in C._ACTION_ALL_INCLUDES' is true,
    # the variable loader is passed in for testing and has the same methods and variables as
    # the loader object of the Ansible runner _play_executor method
    mock_loader = mock_Loader()

    # Testing when the condition 'if original_task.action in C._ACTION_ALL_INCLUD

# Generated at 2022-06-25 05:31:24.408074
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = None
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    var_1 = included_file_0.process_include_results(var_0, var_0, var_0, var_0)

# Generated at 2022-06-25 05:31:29.352303
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        test_case_0()
    except:
        print('FAIL: test_IncludedFile_process_include_results')
        return
    print('PASS: test_IncludedFile_process_include_results')

test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:31:34.435953
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = None
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    var_1 = included_file_0.process_include_results()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:31:40.095375
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass  # skip this test if we aren't testing
    var_0 = None
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    var_1 = included_file_0.process_include_results("load_file", "hostname", "action_key")
    print(var_1)

# Generated at 2022-06-25 05:33:24.857840
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = None
    var_1 = IncludedFile(var_0, var_0, var_0, var_0)
    var_2 = None
    var_3 = IncludedFile(var_2, var_2, var_2, var_2)
    var_4 = var_1 == var_3
    var_5 = None
    var_6 = IncludedFile(var_5, var_5, var_5, var_5)
    var_7 = var_1 == var_6
    var_8 = None
    var_9 = IncludedFile(var_8, var_8, var_8, var_8)
    var_10 = var_1 == var_9
    var_11 = None
    var_12 = IncludedFile(var_11, var_11, var_11, var_11)


# Generated at 2022-06-25 05:33:29.915824
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True  # TODO: implement your test here

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:33:34.276191
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert callable(IncludedFile.process_include_results)
    try:
        assert included_file_0.process_include_results([]) == included_file_1
    except AssertionError:
        assert included_file_0.process_include_results([]) == included_file_1

test_case_0()

# Generated at 2022-06-25 05:33:36.685305
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = None
    included_file_0 = IncludedFile(var_0, var_0, var_0, var_0)
    var_1 = included_file_0.__eq__()


# Generated at 2022-06-25 05:33:38.068426
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file = IncludedFile()
    included_file.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:33:43.070097
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = IncludedFile(var_0, var_0, var_0, var_0)
    var_0.process_include_results()
    assert True is True
    assert True is True
    assert True is True
    assert True is True
    assert True is True
    assert True is True
    assert True is True
    assert True is True



# Generated at 2022-06-25 05:33:45.604596
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = None
    var_1 = IncludedFile(var_0, var_0, var_0, var_0)
    var_2 = var_1.process_include_results()

# Generated at 2022-06-25 05:33:56.262423
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_