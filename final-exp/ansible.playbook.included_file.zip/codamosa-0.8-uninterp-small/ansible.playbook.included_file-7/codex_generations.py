

# Generated at 2022-06-25 05:24:36.815625
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    float_0 = 3.60330749738
    tuple_0 = (1,)
    str_0 = '1'
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    included_file_1 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    if included_file_0 == included_file_1:
        assert True
    else:
        assert False


# Generated at 2022-06-25 05:24:43.862936
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert included_file_0.__eq__(bool_0) == bool_0.__eq__(included_file_0) and included_file_0.__eq__(float_0) == float_0.__eq__(included_file_0) and included_file_0.__eq__(tuple_0) == tuple_0.__eq__(included_file_0) and included_file_0.__eq__(str_0) == str_0.__eq__(included_file_0)


# Generated at 2022-06-25 05:24:46.384671
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        process_include_results(inc_file, rep_res, loader_0, varman_1)
    except SystemExit:
        pass


# Generated at 2022-06-25 05:24:54.038303
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO : implement unit test
    bool_0 = False
    int_0 = 2
    str_0 = 'r/'
    tuple_0 = ()
    IncludedFile.process_include_results(bool_0, int_0, str_0, tuple_0)


# Generated at 2022-06-25 05:25:04.740207
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    float_0 = 0.3
    tuple_0 = ('',)
    str_0 = 'qIo+n8Lr5"m{QzBv'
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    bool_1 = True
    float_1 = 0.1
    tuple_1 = ()
    str_1 = 'a^0c%Kv{k&]O8;?B'
    included_file_1 = IncludedFile(bool_0, float_0, tuple_0, str_1)
    assert not included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:25:16.441813
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = False
    float_0 = None
    tuple_0 = ()
    str_0 = 'g+6#osD?oP]V:~'
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    dict_0 = dict()
    dict_0['task_0'] = included_file_0
    dict_0['task_1'] = included_file_0
    dict_0['task_2'] = included_file_0
    bool_1 = False
    IncludedFile.process_include_results(dict_0, bool_0, bool_0, bool_1)

if __name__ == "__main__":
    # Unit test for method __init__ of class IncludedFile
    test_case_0()

    # Unit test for method

# Generated at 2022-06-25 05:25:27.454249
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = 'j0@Xp'
    str_1 = 'a[y'
    float_0 = 0.557699
    str_2 = 'X&'
    included_file_0 = IncludedFile(str_0, float_0, str_1, str_2)
    list_0 = [float_0, str_1, str_2, included_file_0]
    dict_0 = dict(zip(list_0, list_0))
    dict_1 = dict(zip(list_0, list_0))
    dict_2 = dict(zip(list_0, list_0))
    list_1 = [str_1, dict_1]
    dict_3 = dict(zip(list_1, list_1))
    list_2 = [str_1, dict_1]


# Generated at 2022-06-25 05:25:37.311621
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Returns True if the attributes of both objects are equal
    bool_0 = True
    float_0 = 1.838288501824956e-06
    tuple_0 = ()
    str_0 = 'object'
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    bool_1 = False
    float_2 = 3.819460271865179e+39
    tuple_1 = ()
    str_1 = 'role'
    included_file_1 = IncludedFile(bool_1, float_2, tuple_1, str_1)
    bool_2 = False
    float_3 = 3.449817741596707e+24
    tuple_2 = ()
    str_2 = 'role'
    included_file_2 = IncludedFile

# Generated at 2022-06-25 05:25:41.102437
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert len(IncludedFile.process_include_results()) == 0

if __name__ == '__main__':
    import os
    import pytest

    # Run unit tests
    pytest.main(['-x', os.path.basename(__file__)])

# Generated at 2022-06-25 05:25:43.660800
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # create object
    included_file = IncludedFile(filename, args, vars, task)

    # call the method
    included_file.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:26:09.173313
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from mock import patch, MagicMock
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    mock_play_context = MagicMock(PlayContext)
    mock_variable_manager = MagicMock()

    include_file_0 = IncludedFile('/usr/bin/env', {}, {}, TaskInclude(action='include_tasks', args={}, loop=None, defer_results=False, loop_args=None, static_args={}))
    include_file_1 = IncludedFile('/etc/hosts', {}, {}, TaskInclude(action='include_tasks', args={}, loop=None, defer_results=False, loop_args=None, static_args={}))

# Generated at 2022-06-25 05:26:13.019445
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    test_obj = IncludedFile(str_0, var_0, var_0, var_0)
    # test_obj.add_host(str_0)


# Generated at 2022-06-25 05:26:14.872468
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    # Define the parameters that the method will receive
    host = 'host'
    # Invoke the method
    result = IncludedFile.add_host(host)
    # Check for expected result
    assert result is None, 'unexpected result'


# Generated at 2022-06-25 05:26:16.762344
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc_file = IncludedFile(str_0, var_0, var_0, var_0)
    try:
        inc_file.add_host(str_0)
    except ValueError:
        assert False


# Generated at 2022-06-25 05:26:17.963862
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    o = IncludedFile
    o.process_include_results()



# Generated at 2022-06-25 05:26:19.082543
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:26:22.130953
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True


# Generated at 2022-06-25 05:26:24.189555
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        file_0 = IncludedFile(str_0, var_0, var_0, var_0, bool_0)
    except NameError:
        assert int_0 == 2
    except AssertionError:
        print('AssertionError raised')


# Generated at 2022-06-25 05:26:30.220945
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = False
    str_0 = ''
    var_0 = ()
    var_1 = (1,)
    var_2 = (1, 2)
    cls_0 = IncludedFile
    cls_0 = IncludedFile
    cls_1 = cls_0
    obj_0 = cls_0()
    obj_1 = cls_1()
    obj_0._filename = var_1
    obj_0._args = var_0
    obj_0._vars = var_2
    obj_0._task._parent._uuid = var_0
    obj_1._filename = var_1
    obj_1._args = var_0
    obj_1._vars = var_2
    obj_1._task._uuid = var_0
    obj_1._task._parent._

# Generated at 2022-06-25 05:26:31.196245
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

# Generated at 2022-06-25 05:27:03.207500
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [
        (1,2,3),
        {
            "item" : "abcd"
        }
    ]
    included_files = IncludedFile.process_include_results(results, None, None, None)
    assert included_files[0]._filename == results[0]
    assert included_files[1]._filename == results[1]["item"]
    assert included_files[0]._args == None
    assert included_files[0]._vars == None
    assert included_files[0]._task == None
    assert included_files[0]._hosts == []
    assert included_files[0]._is_role == False
    assert included_files[1]._args == None
    assert included_files[1]._vars == None
    assert included_files[1]._task == None

# Generated at 2022-06-25 05:27:11.736837
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = 0
    float_0 = 0.0
    tuple_0 = ()
    str_0 = '0'
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    bool_1 = 0
    float_1 = 0.0
    tuple_1 = ()
    str_1 = '0'
    included_file_1 = IncludedFile(bool_1, float_1, tuple_1, str_1)
    bool_2 = 0
    float_2 = 0.0
    tuple_2 = ()
    str_2 = '0'
    included_file_2 = IncludedFile(bool_2, float_2, tuple_2, str_2)
    bool_3 = 0
    float_3 = 3.2
    tuple_3 = ()

# Generated at 2022-06-25 05:27:17.412532
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = []
    iterator = None
    loader = None
    variable_manager = None
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:27:20.964748
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_0 = []
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    included_files_0 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)

if __name__ == "__main__":
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:31.099333
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = False
    float_0 = None
    tuple_0 = ()
    str_0 = 'g+6#osD?oP]V:~'
    included_file_0 = IncludedFile(str_0, bool_0, tuple_0, float_0)
    bool_0 = True
    float_0 = 3.141592653589793
    tuple_0 = (0, )
    str_0 = 'g+6#osD?oP]V:~'
    included_file_0 = IncludedFile(str_0, bool_0, tuple_0, float_0)
    # TODO: Write unit test for method __eq__ of class IncludedFile
    assert True == True


# Generated at 2022-06-25 05:27:37.325082
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    for i in range(100):
        str_0 = 'e'
        int_0 = 1
        float_0 = 0.1
        int_1 = -2147483648
        str_1 = 'B`'
        dict_0 = {}
        list_0 = []
        str_2 = 'Y['
        int_2 = 0
        dict_1 = {}
        dict_1[int_0] = str_2
        dict_2 = {}
        dict_2[str_0] = dict_1
        dict_3 = {}
        dict_3[str_1] = dict_2
        dict_4 = {}
        dict_4[int_2] = dict_3
        dict_5 = {}
        dict_5[int_2] = dict_4

# Generated at 2022-06-25 05:27:42.366992
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = None
    iterator = None
    loader = None
    variable_manager = None
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Test case for IncludedFile, constructor
# Test case for IncludedFile, add_host
# Test case for IncludedFile, __eq__
# Test case for IncludedFile, __init__
# Test case for IncludedFile, __repr__
# Test case for IncludedFile, process_include_results

# Generated at 2022-06-25 05:27:52.419326
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = False
    float_0 = None
    tuple_0 = ()
    str_0 = 'g+6#osD?oP]V:~'
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    list_0 = [included_file_0]
    included_file_1 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    assert included_file_1 == included_file_0
    included_file_0.add_host(float_0)
    included_file_1.add_host(float_0)
    assert included_file_1.add_host(float_0) != included_file_0.add_host(float_0)
    results = included_file_0.process_

# Generated at 2022-06-25 05:27:55.877413
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Unit Test Variables for method process_include_results
    # iterator, loader, variable_manager
    included_file_0 = IncludedFile(None, None, None, None)
    # Remove the following line when you have implemented this method
    raise NotImplementedError


# Generated at 2022-06-25 05:28:01.613130
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """
    Test if two objects are equal
    """
    included_file_0 = IncludedFile()
    included_file_1 = IncludedFile()
    set_obj = set()
    set_obj.add(included_file_0)
    set_obj.add(included_file_1)
    assert len(set_obj) == 1


# Generated at 2022-06-25 05:28:36.615638
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = dict()
    key_val_0 = None
    dict_0[key_val_0] = str_0
    list_0 = list()
    bool_0 = False
    tuple_0 = ()
    dict_0[key_val_0] = bool_0
    dict_0[key_val_0] = tuple_0
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    IncludedFile_process_include_results = IncludedFile.process_include_results(dict_0, list_0, included_file_0)

test_case_0()
test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:46.560399
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = False
    float_0 = None
    tuple_0 = ()
    str_0 = 'g+6#osD?oP]V:~'
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    bool_1 = True
    float_1 = 15.75
    tuple_1 = (bool_0,)
    str_1 = 'g+6#osD?oP]V:~'
    included_file_1 = IncludedFile(bool_1, float_1, tuple_1, str_1)
    bool_2 = included_file_1 == included_file_0


# Generated at 2022-06-25 05:28:49.273733
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = False
    tuple_0 = ()
    int_0 = None
    IncludedFile.process_include_results(bool_0, tuple_0, tuple_0, int_0)


# Generated at 2022-06-25 05:29:00.287236
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(None, None, None, None)
    included_file_0._filename = 'x!,G|[O,\'Mv(c*|j-L'
    included_file_0._vars = []
    included_file_0._args = {}
    included_file_0._task = 'Bsp:U$KebU5\x03xk\tmk'
    included_file_1 = IncludedFile(None, None, None, None)
    included_file_1._filename = 'x!,G|[O,\'Mv(c*|j-L'
    included_file_1._vars = []
    included_file_1._args = {}
    included_file_1._task = 'Bsp:U$KebU5\x03xk\tmk'

# Generated at 2022-06-25 05:29:04.732782
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

# Create a test for a specific function and run it standalone
if __name__ == "__main__":
    # Load testcases
    tc_name = "test_case_0"
    # Load testcase
    tc = globals()[tc_name]
    # Run the testcase
    tc()

# Generated at 2022-06-25 05:29:06.157225
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False # Replacement for test body for process_include_results


# Generated at 2022-06-25 05:29:17.995323
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    float_0 = 7.65
    tuple_0 = ()
    str_0 = 'EqM6rG`hx"D]_C'
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    included_file_1 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    included_file_2 = IncludedFile(float_0, bool_0, tuple_0, str_0)
    included_file_3 = IncludedFile(bool_0, float_0, str_0, tuple_0)
    included_file_4 = IncludedFile(bool_0, float_0, tuple_0, str_0)


# Generated at 2022-06-25 05:29:23.101250
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    for i in range(100000):
        test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()
    test_IncludedFile_process_include_results()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:24.790084
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:27.208012
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # AssertionError: expected Exception: (no error)
    # included_file_0 = IncludedFile()
    pass

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:30:25.200005
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile()
    included_file_0.process_include_results(included_file_0, included_file_0, included_file_0, included_file_0)


# Generated at 2022-06-25 05:30:28.599768
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert isinstance(IncludedFile(False, None, (), 'g+6#osD?oP]V:~').__eq__(IncludedFile(False, None, (), 'g+6#osD?oP]V:~')), bool)


# Generated at 2022-06-25 05:30:31.235075
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = None
    iterator = None
    loader = None
    variable_manager = None
    included_file = IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:30:37.169218
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = False
    float_0 = None
    tuple_0 = ()
    str_0 = '~/'
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)

    bool_1 = True
    str_1 = 'I'
    included_file_1 = IncludedFile(bool_1, float_0, tuple_0, str_1)

    bool_2 = True
    float_1 = 12.582505094946427
    str_2 = 'F'
    included_file_2 = IncludedFile(bool_2, float_1, tuple_0, str_2)

    bool_3 = True
    int_0 = 0
    float_2 = 1.1578409922337602

# Generated at 2022-06-25 05:30:39.580363
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    x = IncludedFile.process_include_results(bool_0, float_0, tuple_0, str_0)


# Generated at 2022-06-25 05:30:41.538180
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:30:50.738573
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = None
    included_file_0 = IncludedFile(int_0, int_0, int_0, int_0)
    included_file_1 = IncludedFile(int_0, int_0, int_0, int_0)
    included_file_2 = IncludedFile(int_0, int_0, int_0, int_0)
    class_0 = IncludedFile(int_0, int_0, int_0, int_0)
    dict_0 = {}
    dict_0['FAILED'] = {'msg': class_0}
    list_0 = [dict_0, dict_0, dict_0]
    included_file_3 = IncludedFile.process_include_results(list_0, int_0, int_0, int_0)

# Generated at 2022-06-25 05:30:56.013921
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = False
    float_0 = None
    tuple_0 = ()
    str_0 = 'g+6#osD?oP]V:~'
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)


# Generated at 2022-06-25 05:30:59.163708
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_1 = IncludedFile._IncludedFile__process_include_results()

# Generated at 2022-06-25 05:31:04.493379
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = False
    float_0 = None
    tuple_0 = ()
    str_0 = 'g+6#osD?oP]V:~'
    included_file_0 = IncludedFile(bool_0, float_0, tuple_0, str_0)
    bool_1 = False
    float_1 = None
    tuple_1 = ()
    str_1 = 'g+6#osD?oP]V:~'
    included_file_1 = IncludedFile(bool_1, float_1, tuple_1, str_1)

    # verify __eq__ returns correct boolean value
    assert_0 = included_file_0.__eq__(included_file_1)
    assert assert_0 == False


# Generated at 2022-06-25 05:33:56.332639
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()


# Generated at 2022-06-25 05:33:59.622223
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # Setup
    results = []
    iterator = None
    loader = None
    variable_manager = None

    # Invocation
    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)

    # Verification
    expected = []
    assert included_files == expected

# Generated at 2022-06-25 05:34:04.575976
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Implicitly checks for a ValueError: the first argument must be a list, not NoneType
    # Implicitly checks for a <class 'UnboundLocalError'>: local variable 'results' referenced before assignment
    # Implicitly checks for a <class 'UnboundLocalError'>: local variable 'iterator' referenced before assignment
    # Implicitly checks for a ValueError: the first argument must be a list, not str
    included_file_0 = IncludedFile.process_include_results(None, None, None, None)


if __name__ == '__main__':
    test_IncludedFile_process_include_results()