

# Generated at 2022-06-25 05:24:31.831837
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class_dict = {'_task': 1, '_filename': 1, '_args': 1, '_vars': 1, '_hosts': 1, '_is_role': 1}
    iterator_0 = 1
    loader_0 = 1
    variable_manager_0 = 1
    included_files_0 = 1
    IncludedFile.process_include_results(included_files_0, iterator_0, loader_0, variable_manager_0)


# Generated at 2022-06-25 05:24:40.789109
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -724.0
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '>$'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    float_1 = 90.15
    tuple_1 = (float_1,)
    str_1 = 'W8'
    included_file_1 = IncludedFile(tuple_1, bool_0, str_1, tuple_1, str_0)
    bool_1 = included_file_0.__eq__((included_file_1))


# Generated at 2022-06-25 05:24:47.042872
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    test_IncludedFile_process_include_results()
    test_case_0()

# Generated at 2022-06-25 05:24:56.444477
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -1934.2
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    included_file_1 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    bool_1 = included_file_0 == included_file_1
    assert bool_1


# Generated at 2022-06-25 05:25:01.971458
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -1934.2
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    included_file_0 = IncludedFile(tuple_0, str_0, str_0, str_0, str_0)
    assert included_file_0.__eq__(included_file_0) is True


# Generated at 2022-06-25 05:25:10.652858
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -1934.2
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    included_file_1 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:25:21.497082
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -0.3
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '-9.6'
    str_1 = 'default'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_1)
    float_1 = -3.3
    tuple_1 = (False,)
    bool_1 = True
    str_2 = '_1'
    str_3 = 'j+'
    included_file_1 = IncludedFile(float_1, tuple_1, bool_1, str_2, str_3)
    float_2 = -0.3
    tuple_2 = (float_2,)
    bool_2 = True
    str_4 = '-9.6'
   

# Generated at 2022-06-25 05:25:28.476785
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        test_case_0()
    except Exception as err:
        print("Test Case 0:", err)

if __name__ == "__main__":
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:25:34.975946
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = -27
    included_file_0 = IncludedFile(0,0,0,0,0)
    include_0 = IncludedFile(0,0,0,0,0)
    included_file_1 = IncludedFile(0,0,0,0,0)
    included_file_2 = IncludedFile(0,0,0,0,0)
    included_file_4 = IncludedFile(0,0,0,0,0)
    included_file_5 = IncludedFile(0,0,0,0,0)
    include_1 = IncludedFile(0,0,0,0,0)
    included_file_6 = IncludedFile(0,0,0,0,0)
    included_file_7 = IncludedFile(0,0,0,0,0)
    included_file_8

# Generated at 2022-06-25 05:25:38.868914
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    assert True == True # TODO: implement your test here


# Generated at 2022-06-25 05:26:02.385407
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_1 = -98.5969
    tuple_1 = (float_1,)
    float_0 = -1934.2
    bool_0 = True
    str_1 = '1'
    list_0 = []
    bool_1 = False
    int_0 = -77
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_1, bool_0, str_0, tuple_0, str_0)
    included_file_1 = IncludedFile(tuple_1, bool_0, str_0, tuple_0, str_0)
    list_0.append(included_file_0)
    tuple_0 = (float_0,)

# Generated at 2022-06-25 05:26:09.236657
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -1934.2
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    
    int_0 = 20
    tuple_1 = (int_0,)
    str_1 = '![B1] '
    included_file_1 = IncludedFile(tuple_1, bool_0, str_1, tuple_1, str_0)
    
    assert not included_file_0 == included_file_1



# Generated at 2022-06-25 05:26:10.768965
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:14.948108
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 0.9
    tuple_0 = (float_0,)
    bool_0 = False
    str_0 = 'n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    float_1 = 0.5
    tuple_1 = (float_1,)
    bool_1 = True
    str_1 = 'I'
    included_file_1 = IncludedFile(tuple_1, bool_1, str_1, tuple_1, str_1)
    assert (included_file_0 == included_file_1)


# Generated at 2022-06-25 05:26:22.716458
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import random

    # randomize the values
    num_of_iter = random.randint(5, 15)
    results = []
    for i in range(num_of_iter):
        float_0 = random.random()
        tuple_0 = (float_0,)
        bool_0 = random.choice((True, False))
        str_0 = '0n'
        results.append(IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0))

    included_files_list = IncludedFile.process_include_results(results, iterator, loader, variable_manager)

    # verify the number of elements in the list
    assert len(included_files_list) == num_of_iter


# Generated at 2022-06-25 05:26:26.047301
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -1934.2
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    included_file_1 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    included_file_0 == included_file_1


# Generated at 2022-06-25 05:26:31.732100
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    results_0 = []
    included_files_0 = included_file_0.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)


# Generated at 2022-06-25 05:26:39.739694
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -1934.2
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    tuple_1 = (float_0,)
    str_1 = '0n'
    included_file_1 = IncludedFile(tuple_1, bool_0, str_1, tuple_1, str_0)
    tuple_0 = (float_0,)
    float_1 = -1934.2
    tuple_1 = (float_1,)
    bool_1 = True
    str_1 = '0n'

# Generated at 2022-06-25 05:26:43.163948
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # test for method process_include_results
    pass

if __name__ == '__main__':
    # Call test_case_0
    test_case_0()

    # Call test_IncludedFile_process_include_results
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:53.059384
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -1877.83
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '|m:4'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)

    float_1 = -1934.2
    tuple_1 = (float_1,)
    bool_1 = True
    str_1 = '0n'
    included_file_1 = IncludedFile(tuple_1, bool_1, str_1, tuple_1, str_1)
    assert included_file_0.__eq__(included_file_1) == True


# Generated at 2022-06-25 05:27:14.188504
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    tuple_0 = (bool_0, str_0)
    tuple_1 = (float_0,)
    included_file_0 = IncludedFile(tuple_1, tuple_0, str_0, tuple_1, str_0)
    included_file_0.process_include_results(bool_0, str_0, tuple_1, float_0)


if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:14.864353
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:27:18.920919
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    float_0 = -1934.2
    tuple_0 = (float_0,)
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    included_file_1 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    included_file_2 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, bool_0)
    included_file_3 = IncludedFile(tuple_0, bool_0, bool_0, tuple_0, str_0)
    included_file_4 = IncludedFile(tuple_0, bool_0, str_0, bool_0, str_0)


# Generated at 2022-06-25 05:27:25.204846
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile()
    try:
        # Process include results does not exist
        results = included_file_0.process_include_results()
        assert False
    except AttributeError:
        assert True

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:25.708364
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:27:31.517988
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.role_include import IncludeRole
    include_role_0 = IncludeRole()
    included_file_0 = IncludedFile(include_role_0, include_role_0, include_role_0, include_role_0, bool())
    print(included_file_0)
    tuple_0 = (included_file_0,)
    list_0 = []
    results = tuple_0
    list_0.extend(results)
    print(list_0)
    print(results)
    display.deprecated('"include" is deprecated, use include_tasks/import_tasks/import_playbook instead', "2.16")


# Generated at 2022-06-25 05:27:37.454111
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = None
    iterator = None
    loader = None
    variable_manager = None
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:27:44.801557
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -1934.2
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    float_1 = -1718.2
    tuple_1 = (float_1,)
    str_1 = ''
    included_file_1 = IncludedFile(tuple_1, bool_0, str_1, tuple_1, str_1)
    # AssertionError
    assert included_file_0 == included_file_1



# Generated at 2022-06-25 05:27:54.672941
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -1934.2
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    tuple_1 = (tuple_0, list(), set())
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = False
    tuple_2 = (bool_1, bool_2, bool_3, bool_0, bool_0)
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float

# Generated at 2022-06-25 05:28:03.521680
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = {}
    dict_1 = {}
    dict_1['results'] = dict_0
    dict_2 = {}
    dict_2['failures'] = 0
    dict_2['parsed'] = True
    dict_2['changed'] = True
    dict_2['skipped'] = 0
    dict_2['dark'] = 0
    dict_2['processed'] = True
    dict_2['ansible_facts'] = dict_0
    dict_2['ansible_included_var_files'] = dict_0
    dict_2['ansible_skipped'] = False
    dict_3 = {}
    dict_3['ansible_facts'] = dict_0
    dict_3['ansible_included_var_files'] = dict_0
    dict_2['invocation'] = dict

# Generated at 2022-06-25 05:28:43.157796
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 7.2
    tuple_0 = (float_0,)
    included_file_0 = IncludedFile(float_0, float_0, tuple_0, float_0)
    tuple_1 = (tuple_0,)
    included_file_1 = IncludedFile(tuple_1, float_0, tuple_0, float_0, tuple_0)
    included_file_1._filename = tuple_0
    included_file_1._args = float_0
    included_file_1._vars = tuple_0
    included_file_1._task = float_0
    included_file_1._is_role = tuple_0
    included_file_1._hosts = tuple_0
    included_file_1._args = tuple_0
    included_file_1._vars = float_0

# Generated at 2022-06-25 05:28:51.896502
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -1934.2
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    str_1 = 's'
    bool_1 = False
    included_file_1 = IncludedFile(bool_0, tuple_0, bool_1, str_1, bool_1)
    list_0 = [bool_0, str_0, tuple_0, bool_1, str_1, bool_1, included_file_0, included_file_1]
    included_file_0.process_include_results(list_0, tuple_0, tuple_0, list_0)


# Generated at 2022-06-25 05:29:00.248667
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -1880.234
    list_0 = [float_0]
    bool_0 = True
    list_1 = [bool_0]
    tuple_0 = (list_0, list_1)
    str_0 = 'answer'
    tuple_1 = (None, str_0, tuple_0)
    included_file_0 = IncludedFile.process_include_results(tuple_1, tuple_0, tuple_0, tuple_0)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:02.119494
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    #Run the test
    test_case_0()

if __name__ == "__main__":
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:09.509822
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    func_args = ()
    func_kwargs = {}
    # No exception should be raised
    _test_template(test_case_0, func_args, func_kwargs)


# Generated at 2022-06-25 05:29:11.737374
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = IncludedFile.process_include_results(tuple_0, bool_0, str_0, tuple_0)
    assert included_files == None

# Generated at 2022-06-25 05:29:17.972921
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -1934.2
    bool_0 = True
    str_0 = 'i:~A-Yn$z'
    list_0 = [float_0, bool_0, str_0]
    included_file_0 = IncludedFile.process_include_results(list_0, list_0, str_0, str_0)

# Generated at 2022-06-25 05:29:19.475573
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = IncludedFile.process_include_results(test_case_0, test_case_0, test_case_0, test_case_0)

# Generated at 2022-06-25 05:29:20.473582
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO: Implement
    return True



# Generated at 2022-06-25 05:29:25.146935
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -1934.2
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    tuple_0 = (-1934.2,)
    included_file_1 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:30:07.541691
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print("Testing IncludedFile.process_include_results")
    bool_0 = True
    bool_1 = False
    str_0 = '0n'
    str_1 = 'G"{'
    str_2 = ':a'
    dict_0 = dict()
    dict_0[str_2] = str_1
    dict_0[']E-~%nYtI)A_'] = True
    dict_0['$(4'] = -7563.6026
    dict_0['S=W'] = -6078.0782
    dict_0['QJw'] = True
    dict_0[str_0] = str_0
    dict_0[']~EGTv'] = -8460.6967

# Generated at 2022-06-25 05:30:08.364698
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()


# Generated at 2022-06-25 05:30:17.532873
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test with a 0.0 value for a float
    float_0 = 0.0
    # Test with a 0 value for a tuple
    tuple_0 = (0,)
    # Test with a False value for a bool
    bool_0 = False
    # Test with an empty string for a str
    str_0 = ''
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    included_file_1 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    included_file_2 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)

# Generated at 2022-06-25 05:30:19.340152
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile.process_include_results(tuple_0, bool_0, str_0, object_0)

# Generated at 2022-06-25 05:30:24.898698
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -1934.2
    tuple_0 = (float_0,)
    included_file_0 = IncludedFile(tuple_0, True, '0n', tuple_0, '0n')
    int_0 = -1412
    included_file_1 = IncludedFile(tuple_0, True, '0n', tuple_0, '0n')
    included_file_2 = IncludedFile(tuple_0, True, '0n', tuple_0, '0n')
    included_file_3 = IncludedFile(tuple_0, True, '0n', tuple_0, '0n')
    dict_0 = {}
    dict_1 = {}
    dict_0['value'] = dict_1
    dict_1['value'] = dict_0

# Generated at 2022-06-25 05:30:33.259999
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 6239.7
    dict_0 = dict()
    dict_0[-731.97] = -906.72
    dict_0['q'] = '4'
    dict_0[0] = '0'
    dict_0['t'] = -5.5
    dict_0['R'] = dict_0
    dict_0[float_0] = -7
    dict_0[-414.6] = 'F'
    dict_0['m8'] = 'F'
    dict_0['m8'] = dict_0
    dict_0[17] = float_0
    dict_0['9'] = -731.97
    dict_0['cg'] = 6422.7
    dict_0[-1.0] = -906.72
    dict_

# Generated at 2022-06-25 05:30:37.444825
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    tuple_0 = ()
    included_files_0 = IncludedFile.process_include_results(tuple_0, tuple_0, tuple_0, tuple_0)
    tuple_1 = ()
    included_files_1 = IncludedFile.process_include_results(tuple_1, tuple_1, tuple_1, tuple_1)


# Generated at 2022-06-25 05:30:38.117247
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:30:40.468705
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = test_case_0()
    included_file_list = IncludedFile.process_include_results(results)
    print("included_file_list = ", included_file_list)


# Generated at 2022-06-25 05:30:47.101703
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -1113.0
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = 'W'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    IncludedFile.process_include_results(str_0, tuple_0, bool_0, tuple_0)



# Generated at 2022-06-25 05:31:54.082962
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()

# Generated at 2022-06-25 05:31:58.008510
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = '0n'
    tuple_0 = (-1934.2,)
    bool_0 = True
    float_0 = -1934.2
    tuple_1 = (float_0,)
    str_1 = '0n'
    IncludedFile.process_include_results(tuple_0, tuple_1, bool_0, str_1)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:32:10.091369
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_1 = -519.22
    str_1 = 'w6U'
    bool_1 = True
    tuple_1 = (float_1,)
    included_file_1 = IncludedFile(str_1, tuple_1, str_1, tuple_1, bool_1)
    list_0 = [included_file_1]
    IncludedFile.process_include_results(list_0, list_0, list_0, list_0)

if __name__ == '__main__':

    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        print('Test case 0 failed: ' + str(e))

    # Test IncludedFile process_include_results

# Generated at 2022-06-25 05:32:19.585457
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -2256.40579831
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    bool_1 = False
    included_file_1 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, bool_1)
    assert included_file_0 != included_file_1


# Generated at 2022-06-25 05:32:28.680767
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print('Testing process_include_results')
    bool_v = True
    str_v = 'pJT'
    tuple_v = (bool_v,)
    float_v = -100.6
    included_file_v = IncludedFile(tuple_v, str_v, float_v, float_v, float_v)
    included_files = included_file_v.process_include_results(tuple_v, tuple_v, tuple_v, tuple_v)
    return included_files

if __name__ == '__main__':
    test_case_0()
    included_files = test_IncludedFile_process_include_results()
    print('included_files: ', included_files)

# Generated at 2022-06-25 05:32:30.452495
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test init of IncludedFile.process_include_results
    included_file_process_include_results = IncludedFile.process_include_results()


# Generated at 2022-06-25 05:32:39.865242
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -1934.2
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = '0n'
    included_file_0 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_0)
    str_1 = '7r'
    included_file_1 = IncludedFile(tuple_0, bool_0, str_0, tuple_0, str_1)
    included_file_2 = IncludedFile(tuple_0, bool_0, included_file_1, tuple_0, str_0)
    str_2 = '>K}4_s'
    included_file_3 = IncludedFile(str_2, bool_0, str_0, tuple_0, str_0)

# Generated at 2022-06-25 05:32:43.706727
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    process_include_results = IncludedFile.process_include_results


# Generated at 2022-06-25 05:32:47.512235
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(None, None, None, None, False)
    included_file_1 = IncludedFile(None, None, None, None, True)
    assert (included_file_0 == included_file_1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:32:47.929901
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True
