

# Generated at 2022-06-25 05:24:30.833240
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    set_0 = set()
    included_file_0 = IncludedFile(bool_0, set_0, bool_0, set_0)
    included_file_1 = IncludedFile(bool_0, set_0, bool_0, set_0)

    assert included_file_0 == included_file_1

# Generated at 2022-06-25 05:24:42.020913
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins import callback_loader

    from ansible.executor.task_queue_manager import display as display_test
    display_test.verbosity = 1

    inventory = InventoryManager(loader = None, sources = '/Users/nicorellius/Documents/ansible-repo/playbook-repo/simple-playbook/hosts')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Test playbook_executor with dummy data

# Generated at 2022-06-25 05:24:47.996846
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(bool_0, set_0, bool_0, set_0)
    bool_0 = True
    set_0 = set()
    included_file_1 = IncludedFile(bool_0, set_0, bool_0, set_0)
    included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:24:59.249901
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    set_0 = set()
    bool_0 = True
    included_file_2 = IncludedFile(bool_0, set_0, bool_0, set_0)
    included_file_3 = IncludedFile(bool_0, set_0, bool_0, set_0)
    included_file_0 = IncludedFile(bool_0, set_0, bool_0, set_0)
    included_file_1 = IncludedFile(bool_0, set_0, bool_0, set_0)
    dict_0 = dict()
    list_0 = ['msg']
    dict_1 = dict()
    dict_1['failed'] = False
    dict_1['msg'] = list_0
    dict_1['results'] = None
    dict_1['skipped'] = False

# Generated at 2022-06-25 05:25:08.909664
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    set_0 = set()
    included_file_0 = IncludedFile(False, set_0, False, set_0)
    included_file_1 = IncludedFile(False, set_0, False, set_0)
    # Verify equality of included_file_0 and included_file_1
    assert included_file_0 == included_file_1
    # Verify that the assertRaises() context manager captures the TypeError raised
    # when included_file_0 is compared to a str object
    with pytest.raises(TypeError) as exinfo:
        included_file_0 == ""
    assert "unorderable types: IncludedFile() < str()" in str(exinfo.value)


# Generated at 2022-06-25 05:25:14.588503
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(None, None, None, None)
    included_file_1 = IncludedFile(None, None, None, None)
    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:25:19.482964
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    set_0 = set()
    included_file_0 = IncludedFile(bool_0, set_0, bool_0, set_0)
    string_0 = "~c^]gw4|`1y`+jH0R$m("
    set_1 = set()
    dict_0 = dict()
    included_file_1 = IncludedFile(string_0, set_1, dict_0, set_1)
    assert (included_file_0 != included_file_1)


# Generated at 2022-06-25 05:25:25.184156
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    args_0 = ['130', 'a', '\u000e']
    bool_0 = False
    bool_1 = True
    bool_2 = True
    bool_3 = True
    bool_4 = False
    int_0 = 1
    set_0 = set()
    str_0 = 'r.r.'
    str_1 = '.'
    str_2 = '6'
    str_3 = '123'
    str_4 = 'r.r.r'
    tuple_0 = (
        str_0, str_1, str_2, 'H', str_3, '-', bool_3, bool_1, int_0, bool_2)

# Generated at 2022-06-25 05:25:35.618010
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_1 = True
    set_1 = set()
    included_file_1 = IncludedFile(bool_1, set_1, bool_1, set_1)
    bool_2 = True
    set_2 = set()
    included_file_2 = IncludedFile(bool_2, set_2, bool_2, set_2)
    # The return value is a bool
    return_value_1 = included_file_1.__eq__(included_file_2)
    # The return value is a bool
    return_value_2 = included_file_2.__eq__(included_file_1)
    ## Exception: TypeError
    # The returned value is not of type bool
    with pytest.raises(TypeError):
        included_file_1.__eq__(bool_1)
   

# Generated at 2022-06-25 05:25:38.923548
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    set_0 = set()
    included_file_0 = IncludedFile(bool_0, set_0, bool_0, set_0)
    included_file_1 = IncludedFile(bool_0, set_0, bool_0, set_0)
    assert included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:25:57.143506
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    for i in range(10):
        try:
            test_case_0()
        except NameError as e:
            print(e)



# Generated at 2022-06-25 05:26:04.057878
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = IncludedFile('a', 'b', 'b', 'c', 'd')
    var_1 = IncludedFile('a', 'b', 'b', 'c', 'd')
    var_2 = IncludedFile('b', 'c', 'd', 'e', 'f')
    assert var_0 == var_1
    assert not var_0 == var_2


# Generated at 2022-06-25 05:26:11.358951
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Initialize
    test_case_0()

    # Run inclusion
    print('Running Used File Inclusion Results')
    print('+---------------------------------------------------------------------------------------------+')
    print('|                                           INCLUDES:                                          |')
    print('+------------------------+------------+-------------------------+----------------------------+')
    print('|  File Name             | Hosts      |  Args                    | Vars                       |')
    print('+------------------------+------------+-------------------------+----------------------------+')
    print('|  %s                    |            |  %s                   | %s                          |' % (str_0, var_0, var_0))
    print('+------------------------+------------+-------------------------+----------------------------+')

# Run the tests on test case initialization
test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:15.072394
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        IncludedFile.process_include_results(results=var_0, iterator=str_0, loader=str_1, variable_manager=str_2)
    except Exception as e:
        print('Exception: ', e)
        print('Traceback: ')
        traceback.print_tb(e.__traceback__)


# Generated at 2022-06-25 05:26:22.290841
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = IncludedFile('/Users/nicorellius/Documents/ansible-repo/playbook-repo/simple-playbook/hosts', None, None, None)
    var_1 = 'key'
    var_2 = '/Users/nicorellius/Documents/ansible-repo/playbook-repo/simple-playbook/hosts'
    var_0.process_include_results(var_1, var_2)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:23.111256
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test case 0
    assert(test_case_0() == None)

# Generated at 2022-06-25 05:26:30.684712
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = IncludedFile('/Users/nicorellius/Documents/ansible-repo/playbook-repo/simple-playbook/hosts')
    var_1 = IncludedFile('/Users/nicorellius/Documents/ansible-repo/playbook-repo/simple-playbook/hosts')
    var_2 = None
    var_2 = var_0.__eq__(var_1)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 05:26:34.814328
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    var_0 = IncludedFile.process_include_results(var_0, var_1, var_2, var_3)

    print(var_0)


# Generated at 2022-06-25 05:26:36.305309
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:43.532270
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test of the template based include file search path
    # Purpose is to ensure the path is properly searched
    # Requires the addition of a test case and updates to the FileLoader class
    # Test case is in file FileLoader tests
    var_0 = IncludedFile(str_0, var_0, var_0, var_0)
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    # Test of calling function process_include_results with appropriate args
    IncludedFile.process_include_results(var_1, var_2, var_3, var_4)

# Test of the template based include file search path
# Purpose is to ensure the path is properly searched
# Requires the addition of a test case and updates to the FileLoader class
# Test case is in file FileLoader tests

# Generated at 2022-06-25 05:26:57.085727
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    IncludedFile.process_include_results(var_0, var_0, str_0)

test_cases = [test_case_0]


# Generated at 2022-06-25 05:27:07.323854
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = None
    str_0 = '/Users/nicorellius/Documents/ansible-repo/playbook-repo/simple-playbook/hosts'
    var_1 = None
    str_1 = '/Users/nicorellius/Documents/ansible-repo/playbook-repo/simple-playbook/hosts'
    var_2 = []
    included_file_0 = IncludedFile(str_0, var_1, var_2, included_file_0)
    var_3 = None
    str_2 = '/Users/nicorellius/Documents/ansible-repo/playbook-repo/simple-playbook/hosts'
    var_4 = None

# Generated at 2022-06-25 05:27:08.530430
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    t = IncludedFile()
    t.process_include_results(var_0, str_0)


# Generated at 2022-06-25 05:27:12.193057
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = None
    str_0 = '/Users/nicorellius/Documents/ansible-repo/playbook-repo/simple-playbook/hosts'
    assert path_exists(str_0)


# Generated at 2022-06-25 05:27:18.109603
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Create a new empty dictionary
    var_0 = dict()
    test_IncludedFile_process_include_results_0(var_0)
    test_IncludedFile_process_include_results_1(var_0)


# Generated at 2022-06-25 05:27:22.582796
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True


if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:25.598700
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # Mock object for IncludeRole
    class IncludeRole:

        # Mock object for IncludeRole._role_path
        role_path = None

    # Mock object for AnsibleError
    class AnsibleError:

        # Mock object for AnsibleError.message
        message = None


# Generated at 2022-06-25 05:27:30.347105
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = []
    results = [None]
    task_vars_cache = {}
    iterator = None
    loader = None
    variable_manager = None
    try:
        result = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    except Exception as e:
        print("Error {}".format(str(e)))


# Generated at 2022-06-25 05:27:32.609732
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    res = None
    iterator = test_case_0()
    loader = test_case_0()
    variable_manager = test_case_0()
    IncludedFile.process_include_results(res, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:27:34.125468
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = IncludedFile.process_include_results(var_0, str_0)
    assert included_files is not None

# Generated at 2022-06-25 05:27:48.753065
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test create and process_include_results args
    included_files_0 = IncludedFile.process_include_results(test_0_arg_0, test_0_arg_1, test_0_arg_2, test_0_arg_3)
    assert included_files_0 is None


# Generated at 2022-06-25 05:27:51.559292
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    set_0 = set()
    included_file_0 = IncludedFile(set_0, set_0, set_0, set_0)


# Generated at 2022-06-25 05:27:54.010506
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    self, results, iterator, loader, variable_manager = test_case_0()
    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:28:02.975921
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(bool(), set(), bool(), set())
    included_file_1 = IncludedFile(bool(), set(), bool(), set())
    included_file_2 = IncludedFile(bool(), set(), bool(), set())
    included_file_3 = IncludedFile(bool(), set(), bool(), set())
    included_file_4 = IncludedFile(bool(), set(), bool(), set())
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    list_0 = list()

# Generated at 2022-06-25 05:28:07.185455
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [IncludedFile(bool_0, set_0, bool_0, set_0)]
    included_files = IncludedFile.process_include_results(results, set_0, bool_0, bool_0)
    assert isinstance(included_files, list)

if __name__ == "__main__":
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:11.255030
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    set_0 = set()
    included_file_0 = IncludedFile(bool_0, set_0, bool_0, set_0)
    set_1 = set()
    bool_1 = True
    included_file_1 = IncludedFile(bool_1, set_0, bool_1, set_1)
    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:28:16.093044
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = True
    included_file_0 = IncludedFile(bool_0, bool_0, bool_0, bool_0)



# Generated at 2022-06-25 05:28:19.590910
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


if __name__ == "__main__":
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:21.992777
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(True, set(), True, set())
    process_include_results(set(), set(), set(), set())


# Generated at 2022-06-25 05:28:22.575637
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:28:57.925570
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        included_file_0 = IncludedFile.process_include_results(set(), set(), set(), set())
    except TypeError as e:
        print(e)


# Generated at 2022-06-25 05:29:00.795410
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = True
    set_0 = set()
    list_0 = list()
    boolean_0 = bool()
    test_IncludedFile_process_include_results_0(bool_0, set_0, list_0, boolean_0)


# Generated at 2022-06-25 05:29:07.352017
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(__file__, {}, {}, None)
    included_file_1 = IncludedFile(__file__, {}, {}, None)
    if not included_file_0 == included_file_1:
        raise AssertionError("Equals, test_case_0 failed")
    included_file_2 = IncludedFile(__file__, {}, {}, None)
    if included_file_0 == included_file_2:
        raise AssertionError("Equals, test_case_1 failed")
    included_file_3 = IncludedFile(__file__, {}, {}, None)
    if not included_file_1 == included_file_3:
        raise AssertionError("Equals, test_case_2 failed")

# Generated at 2022-06-25 05:29:10.613507
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:21.644248
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(bool_0, set_0, bool_0, set_0)
    loader = DataLoader()
    variable_manager = VariableManager()
    # self.assertEqual(expected, IncludedFile.process_include_results(results, iterator, loader, variable_manager))
    assert False # TODO: implement your test here


if __name__ == '__main__':
    import sys
    import traceback
    import unittest
    loader = unittest.TestLoader()
    loader.testMethodPrefix = 'test_'
    suite = loader.loadTestsFromModule(sys.modules[__name__])
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

# Generated at 2022-06-25 05:29:24.916218
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(True, set(), True, set())
    included_file_1 = IncludedFile(True, set(), True, set())

    eq_result = included_file_0.__eq__(included_file_1)

    assert isinstance(eq_result, bool)



# Generated at 2022-06-25 05:29:26.396426
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(str(), str(), str(), str())

# Test for IncludeFile class when action = include

# Generated at 2022-06-25 05:29:27.137153
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:29:31.894887
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(bool(), set(), bool(), set(), bool())
    bool_0 = included_file_0.__eq__(set())
    assert isinstance(bool_0, bool)


# Generated at 2022-06-25 05:29:37.003177
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(included_file_0, set_0, str_0, str_0)
    included_file_1 = IncludedFile(bool_0, set_0, bool_0, set_0)
    bool_1 = included_file_0 == included_file_1
    assert bool_1 == True


# Generated at 2022-06-25 05:30:53.362290
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    set_0 = set()
    included_file_0 = IncludedFile(bool_0, bool_0, bool_0, bool_0)
    included_file_1 = IncludedFile(bool_0, bool_0, bool_0, bool_0)
    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:31:00.661943
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = True
    int_0 = 0
    int_1 = 1
    int_115 = 115
    int_2 = 2
    int_3 = 3
    int_7 = 7
    int_8 = 8
    mappingproxy_0 = type(dict())
    set_0 = set()
    str_0 = ""
    str_1 = "1"
    str_2 = "2"
    str_3 = "3"
    str_4 = "4"
    str_5 = "5"
    str_6 = "6"
    str_7 = "7"
    str_8 = "8"
    str_9 = "9"

    results = set_0
    iterator = mappingproxy_0
    loader = mappingproxy_0
    variable_manager = mappingproxy_0

# Generated at 2022-06-25 05:31:02.193934
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:31:04.704549
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = True
    set_0 = set()
    included_file_0 = IncludedFile(bool_0, set_0, bool_0, set_0)
    IncludedFile.process_include_results(set_0, set_0, set_0, set_0)

# Generated at 2022-06-25 05:31:09.889097
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    print("\n***********************************************************\n")
    print("Test method __eq__ of class IncludedFile")

    set_0 = set()
    bool_0 = True
    included_file_0 = IncludedFile(str(), set_0, set_0, set_0)
    try:
        ret = included_file_0.__eq__(included_file_0)
    except:
        ret = False
    result = ret

    assert result

    print("***********************************************************\n")


# Generated at 2022-06-25 05:31:12.078716
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile.process_include_results()


# Generated at 2022-06-25 05:31:13.251909
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:31:19.171566
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    included_file_process_include_results = IncludedFile.process_include_results(iterator_0, loader_0, variable_manager_0)

# Generated at 2022-06-25 05:31:23.288388
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    results = []
    iterator = None
    loader = None
    variable_manager = None

    # Call method
    return IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:31:25.144025
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = IncludedFile.process_include_results(bool_0, set_0, set_0, set_0)


# Generated at 2022-06-25 05:32:44.428973
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = True
    set_0 = set()
    included_file_0 = IncludedFile(bool_0, set_0, bool_0, set_0)
    IncludedFile.process_include_results(set_0, set_0, set_0, set_0)

if __name__ == '__main__':
    import numba
    numba.testing.test_pep8(__file__)

# Generated at 2022-06-25 05:32:52.678329
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    results = [
        dict(
            _host=dict(name='test_host'),
            _task=dict(action='include'),
            _result=dict(
                failed=False,
                include='/tmp/test_IncludedFile_process_include_results.py',
                include_args=dict(),
                ansible_loop_var='item',
                ansible_index_var='index_var',
                _ansible_item_label='index_var'
            )
        )
    ]
    iterator = dict(
        play=dict(
            basedir='/tmp'
        )
    )
    loader = dict(
        _basedir='/'
    )

# Generated at 2022-06-25 05:32:56.558711
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = list()
    iterator = object()
    loader = object()
    variable_manager = object()
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)


if __name__ == '__main__':
    print("Testing IncludedFile")
    print("====================")
    test_case_0()
    test_IncludedFile_process_include_results()
    print("====================")
    print("All tests passed")

# Generated at 2022-06-25 05:33:05.874509
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test with a subset of the output of the included_files_0 test_case

    # First, the role_name and included_file are the same, but the task is different
    included_file_1 = IncludedFile('a', {}, {}, 'b', False)
    included_file_1_ = IncludedFile('a', {}, {}, 'c', False)
    assert included_file_1 != included_file_1_

    res_1 = [included_file_1, included_file_1_]
    included_files_1 = IncludedFile.process_include_results(res_1, None, None, None)
    assert len(included_files_1) == 1

    # Now, the role name and task are the same, but the file is different

# Generated at 2022-06-25 05:33:10.300028
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    set_0 = set()
    included_file_0 = IncludedFile(set_0, set_0, set_0, set_0)
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    IncludedFile.process_include_results(set_0, iterator_0, loader_0, variable_manager_0)



# Generated at 2022-06-25 05:33:14.248456
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        IncludedFile.process_include_results(None, None, None, None)
    except TypeError as err:
        print(err.args[0])
        print(err)
        assert str(err) == "process_include_results() missing 4 required positional arguments: 'results', 'iterator', 'loader', and 'variable_manager'"



# Generated at 2022-06-25 05:33:23.764417
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    bool_1 = False
    bool_2 = True
    set_0 = set()
    set_1 = set()
    included_file_0 = IncludedFile(bool_0, set_0, bool_0, set_0)
    included_file_1 = IncludedFile(bool_1, set_0, bool_0, set_0)
    included_file_2 = IncludedFile(bool_2, set_0, bool_0, set_0)
    bool_3 = bool(included_file_0 == included_file_1)
    bool_4 = bool(included_file_0 == included_file_2)
    bool_5 = bool(included_file_1 == included_file_2)

# Generated at 2022-06-25 05:33:24.276722
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:33:36.541782
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    set_0 = set()
    included_file_0 = IncludedFile(bool_0, set_0, bool_0, set_0)
    set_1 = set()
    included_file_1 = IncludedFile(bool_0, set_1, bool_0, set_1)
    int_0 = 0
    assert included_file_0.__eq__(included_file_1) == int_0
    included_file_0 = IncludedFile(bool_0, set_0, bool_0, set_0)
    set_2 = set()
    included_file_1 = IncludedFile(bool_0, set_2, bool_0, set_2)
    assert included_file_0.__eq__(included_file_1) == int_0


# Generated at 2022-06-25 05:33:38.952636
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = None
    iterator = None
    loader = None
    variable_manager = None
    display.debug("Calling IncludedFile.process_include_results()")
    return IncludedFile.process_include_results(results, iterator, loader, variable_manager)