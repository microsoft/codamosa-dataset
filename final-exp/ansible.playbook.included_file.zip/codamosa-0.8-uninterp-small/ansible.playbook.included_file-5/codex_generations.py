

# Generated at 2022-06-25 05:24:53.232420
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = None
    iterator = None
    loader = None
    variable_manager = None
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:25:00.235434
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    dict_0 = {}
    bytes_0 = b''
    set_0 = {dict_0, bytes_0}
    included_file_0 = IncludedFile(dict_0, bytes_0, set_0, dict_0)
    assert included_file_0.__eq__(included_file_0) == True



# Generated at 2022-06-25 05:25:11.983987
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = {}
    bytes_0 = b'D\r\x9e\xa8\\\xbd\x07\xa2a\xb5e\x8b\x87\xf2\x05rq\xc3h\xe3'
    set_0 = {dict_0, bytes_0}
    included_file_0 = IncludedFile(dict_0, bytes_0, set_0, dict_0)
    included_file_1 = IncludedFile(dict_0, bytes_0, set_0, dict_0)
    included_files = [included_file_0, included_file_1]
    iterator = None
    loader = None
    variable_manager = None
    result = IncludedFile.process_include_results(included_files, iterator, loader, variable_manager)
    return result

# Generated at 2022-06-25 05:25:21.461088
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    dict_0 = {}
    bytes_0 = b'D\r\x9e\xa8\\\xbd\x07\xa2a\xb5e\x8b\x87\xf2\x05rq\xc3h\xe3'
    set_0 = {dict_0, bytes_0}
    included_file_0 = IncludedFile(dict_0, bytes_0, set_0, dict_0)
    included_file_1 = IncludedFile(dict_0, bytes_0, set_0, dict_0)
    boolean_value = included_file_0 == included_file_1
    assert boolean_value


# Generated at 2022-06-25 05:25:33.204098
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    dict_0 = {}
    bytes_0 = b'D\r\x9e\xa8\\\xbd\x07\xa2a\xb5e\x8b\x87\xf2\x05rq\xc3h\xe3'
    set_0 = {dict_0, bytes_0}
    included_file_0 = IncludedFile(dict_0, bytes_0, set_0, dict_0)
    dict_0_copy = {}
    bytes_0_copy = b'D\r\x9e\xa8\\\xbd\x07\xa2a\xb5e\x8b\x87\xf2\x05rq\xc3h\xe3'
    set_0_copy = {dict_0_copy, bytes_0_copy}
    included_file_1

# Generated at 2022-06-25 05:25:33.975391
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass



# Generated at 2022-06-25 05:25:45.729719
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {'facet': (int,), 'selector': (dict,)}
    bytes_0 = b'\xed\xdf\x82\xd8\x1a\x9a\x9f\x84\xd4\xb3\x88\xb4\x96\x1a\x8fZ\x9d\x01\x8e\xcb\x03\xcb\xb0\x8a\x83\x9e\x0bx'
    bytes_1 = b't\x08\xa7\x98\xa0\x0b\x85\xb2\x085\xc1\x17\x03'

# Generated at 2022-06-25 05:25:56.878893
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:26:09.094373
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    dict_0 = {}
    bytes_0 = b'D\r\x9e\xa8\\\xbd\x07\xa2a\xb5e\x8b\x87\xf2\x05rq\xc3h\xe3'
    set_0 = {dict_0, bytes_0}
    included_file_0 = IncludedFile(dict_0, bytes_0, set_0, dict_0)
    dict_1 = {}
    bytes_1 = b'D\r\x9e\xa8\\\xbd\x07\xa2a\xb5e\x8b\x87\xf2\x05rq\xc3h\xe3'
    set_1 = {dict_0, bytes_0}

# Generated at 2022-06-25 05:26:14.738331
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = {}
    dict_1 = {'!': '', '_': '"D\r\x9e\xa8\\\xbd\x07\xa2a\xb5e\x8b\x87\xf2\x05rq\xc3h\xe3"', '`': 'D\r\x9e\xa8\\\xbd\x07\xa2a\xb5e\x8b\x87\xf2\x05rq\xc3h\xe3'}
    dict_1['_'] = dict_1['_'][1:-1]

# Generated at 2022-06-25 05:26:37.155616
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bytes_0 = b'2\x84)_\x14\x9a\x83'
    str_0 = '>\xbc\x13\x8cD\xab\x07\x9d'
    int_0 = -34
    included_file_0 = IncludedFile(bytes_0, str_0, str_0, int_0)
    included_file_1 = IncludedFile(bytes_0, str_0, str_0, int_0)
    included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:26:41.005610
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()



# Generated at 2022-06-25 05:26:46.317531
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bytes_0 = b'\xc7%k\xe2\x14\x1e\x89d\x00'
    str_0 = '(X*<E?N'
    int_0 = -1028
    included_file_0 = IncludedFile(bytes_0, str_0, str_0, int_0)
    int_1 = -1028
    included_file_1 = IncludedFile(bytes_0, str_0, str_0, int_1)
    assert included_file_0.__eq__(included_file_1) is True


# Generated at 2022-06-25 05:26:49.954852
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(str_0, str_0, str_0, int_0)
    included_file_1 = IncludedFile(bytes_0, str_0, str_0, int_0)
    included_file_0 == included_file_1


# Generated at 2022-06-25 05:26:57.517631
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\\\xf0\x1b.\x8d'
    bytes_1 = b'3\xa3\x96\x15\xaf'
    included_file_1 = IncludedFile(bytes_0, bytes_1, bytes_1, int_0)
    included_file_2 = IncludedFile(str_0, int_0, int_0, str_0)
    included_file_3 = IncludedFile(bytes_0, str_0, str_0, int_0)
    included_file_4 = IncludedFile(bytes_0, str_0, str_0, int_0)
    included_file_5 = IncludedFile(bytes_0, int_0, int_0, bytes_1)

# Generated at 2022-06-25 05:26:58.276539
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

main()

# Generated at 2022-06-25 05:27:06.563043
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_0 = [None, str_0]
    iterator_0 = IncludedFile(str_0, int_0, bytes_0, int_0)
    loader_0 = 'E]<B5&\x00\x9a'
    variable_manager_0 = IncludedFile(int_0, str_0, str_0, int_0)
    IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:13.430477
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bytes_0 = b'\xc7%k\xe2\x14\x1e\x89d\x00'
    str_0 = '(X*<E?N'
    int_0 = -1028
    included_file_0 = IncludedFile(bytes_0, str_0, str_0, int_0)
    included_file_1 = IncludedFile(bytes_0, str_0, str_0, int_0)
    assert included_file_0 == included_file_1
    str_1 = 'D\x87\xe2i\x1b\x9f\xe4n'
    included_file_1 = IncludedFile(str_1, bytes_0, int_0, str_0)
    assert not included_file_0 == included_file_1


# Generated at 2022-06-25 05:27:22.509267
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    results = [{"_host": "host_0", "_task": "task_0", "_result": {"skipped": True}},
               {"_host": "host_1", "_task": "task_1", "_result": {"failed": True}},
               {"_host": "host_2", "_task": "task_1", "_result": {"ansible_loop_var": "ansible_loop_var_1"}},
              ]

    iterator = "iterator_0"
    loader = "loader_0"
    variable_manager = "variable_manager_0"

    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)

    assert included_files == []


# Generated at 2022-06-25 05:27:29.857005
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bytes_0 = b'\xc7%k\xe2\x14\x1e\x89d\x00'
    bytes_1 = b'\x16\xbf\x1f\xfc\xe5(\x02\x8d\xad'
    bytes_2 = b'\x1d\x83\x03\x17R\xc6\xac\xc3I'
    str_0 = '(X*<E?N'
    str_1 = '\\W\x8a\xb8'
    int_0 = -1028
    bool_0 = True
    int_1 = -1566
    bool_1 = False
    included_file_0 = IncludedFile(bytes_0, str_0, str_0, int_0)

# Generated at 2022-06-25 05:27:46.371283
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(0, 0, 0, 0)  # create object 'IncludedFile'

    included_file_0.__eq__(0)  # test method __eq__ of class IncludedFile


# Generated at 2022-06-25 05:27:53.106432
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # NOTE: The code below is generated, do not edit.
    # Variables
    results = "results"
    iterator = "iterator"
    loader = "loader"
    variable_manager = "variable_manager"

    # Setup
    included_file = IncludedFile(None, None, None, None)

    # Return type
    return_var = included_file.process_include_results(results, 
        iterator, loader, variable_manager)
    assert isinstance(return_var, list)



# Generated at 2022-06-25 05:27:59.164606
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\xc7%k\xe2\x14\x1e\x89d\x00'
    str_0 = '(X*<E?N'
    int_0 = -1028
    included_file_0 = IncludedFile(bytes_0, str_0, str_0, int_0)
    assert included_file_0.process_include_results(bytes_0,bytes_0,bytes_0,bytes_0) == ()

# Tests for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:28:05.879354
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test case:
    # Tested function:
    # Expected result:
    # Input:
    results_0 = []
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    actual = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)
    #assert type(actual) == type(expected) TODO
    assert actual == None
    # Output:


# Generated at 2022-06-25 05:28:12.571739
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_0 = []
    iterator_0 = _IncludeIterator()
    loader_0 = _DataLoader()
    variable_manager_0 = _VariableManager()
    included_file_1 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)


# Generated at 2022-06-25 05:28:22.486886
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:28:28.381493
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bytes_0 = b'\xfc\x8a2\xdf\xce\x9b\x8d\xcf\x1f'
    str_0 = 'x>b_|\x88\xa6=\x9f\x8a\xc3\xde\x99'
    int_0 = -1028
    included_file_0 = IncludedFile(bytes_0, str_0, str_0, int_0)
    bytes_1 = b']\x9a\x8f\x90'
    str_1 = '\x1d\xdc\xaf\xa2\x07\x03\x8f\x8f\x82'
    int_1 = -1028

# Generated at 2022-06-25 05:28:30.538483
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Test cases for class IncludedFile

# Generated at 2022-06-25 05:28:31.942830
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

# TESTS:
# test_IncludedFile_process_include_results: 7

# TOTAL: 7
#
# OK

# Generated at 2022-06-25 05:28:35.832421
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = []
    results = []
    iterator = None
    loader = IncludedFile(bytes_0, str_0, str_0, int_0)
    variable_manager = IncludedFile(bytes_0, str_0, str_0, int_0)
    return_value = IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:29:06.395634
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        results = IncludedFile.process_include_results(included_file_0, str_0, str_0, str_0)
    except:
        pass

test_case_0()

# Generated at 2022-06-25 05:29:13.794412
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    included_file_1 = IncludedFile(None, None, None, None)
    included_file_2 = IncludedFile(None, None, None, None)
    included_files_0 = [included_file_0, included_file_1, included_file_2]
    iterator_0 = IncludedFile.process_include_results(included_files_0)
    assert included_files_0 == iterator_0


# Generated at 2022-06-25 05:29:19.728519
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\xc7%k\xe2\x14\x1e\x89d\x00'
    str_0 = '(X*<E?N'
    int_0 = -1028
    results_0 = list()
    results_0.append(IncludedFile(bytes_0, str_0, str_0, int_0))
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    included_file_0 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)
    assert included_file_0 == [IncludedFile(bytes_0, str_0, str_0, int_0)]

# Generated at 2022-06-25 05:29:25.843528
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\xc7%k\xe2\x14\x1e\x89d\x00'
    str_0 = "(X*<E?N"
    int_0 = -1028
    included_file_0 = IncludedFile(bytes_0, str_0, str_0, int_0)
    # Add a host to included_file_0
    included_file_0.add_host(int_0)
    results = [included_file_0]
    iterator = str_0
    loader = str_0
    variable_manager = str_0
    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    print(included_files)

# Generated at 2022-06-25 05:29:37.161782
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bytes_0 = b'\xc7%k\xe2\x14\x1e\x89d\x00'
    str_0 = '(X*<E?N'
    int_0 = -1028
    included_file_0 = IncludedFile(bytes_0, str_0, str_0, int_0)
    included_file_1 = IncludedFile(bytes_0, str_0, str_0, int_0)
    included_file_2 = IncludedFile(str_0, str_0, str_0, int_0)
    included_file_3 = IncludedFile(str_0, str_0, dict(), int_0)
    included_file_4 = IncludedFile(str_0, str_0, dict(), int_0)

# Generated at 2022-06-25 05:29:46.426647
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:29:51.044766
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\xc7%k\xe2\x14\x1e\x89d\x00'
    int_0 = -1028
    included_file_1 = IncludedFile(bytes_0, int_0, int_0, int_0)
    results = IncludedFile.process_include_results(int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 05:29:54.229927
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [dict(), dict(), dict()]
    iterator = object()
    loader = object()
    variable_manager = object()
    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:30:02.669835
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_0 = []
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    IncludedFile_process_include_results_observed = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)
    IncludedFile_process_include_results_expected = results_0
    assert IncludedFile_process_include_results_observed == IncludedFile_process_include_results_expected

# Generated at 2022-06-25 05:30:09.979964
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bytes_0 = 'M4eR'
    str_0 = '!\x15\rP=*'
    str_1 = '\x00\x14\x1b\xd7WI.\n'
    int_0 = -6
    included_file_0 = IncludedFile(str_0, str_1, bytes_0, int_0)
    bytes_1 = '&\x1eJ\xfb\x13\x0e\xbf\x9d'
    str_2 = '\x0fp\x16\x17\x00\x06T\x0fX\x00'
    int_1 = 83
    included_file_1 = IncludedFile(str_2, str_2, bytes_1, int_1)
    included_file_0._is_role = False

# Generated at 2022-06-25 05:31:23.370213
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_process_include_results_0 = IncludedFile.process_include_results()

# Generated at 2022-06-25 05:31:27.179350
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    IncludedFile.process_include_results(['o', ';', '1', 'p', '\x1d', '\x14', '\x7f', '\x13', '\x12', '\x16'], '\x1b', 'a', '-')


# Generated at 2022-06-25 05:31:32.176527
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    iterator_0 = TaskInclude(module=int())
    loader_0 = AnsibleError()
    variable_manager_0 = IncludeRole()
    # Method process_include_results
    result = IncludedFile.process_include_results(iterator_0, loader_0, variable_manager_0)
    assert result == None


# Generated at 2022-06-25 05:31:35.686656
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert callable(IncludedFile.process_include_results)

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(sys.argv))

# Generated at 2022-06-25 05:31:38.652835
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = []
    iterator = None
    loader = None
    variable_manager = None
    IncludeFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:31:49.727855
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\xc7%k\xe2\x14\x1e\x89d\x00'
    str_0 = '(X*<E?N'
    int_0 = -1028
    list_0 = [bytes_0]
    dict_0 = {'\x00\x00\x00\x00\x00\x00\x00\x00': list_0}
    included_file_0 = IncludedFile(bytes_0, str_0, str_0, int_0)
    results = [included_file_0]
    assert IncludedFile.process_include_results(results, included_file_0, dict_0, included_file_0) == [included_file_0]


# Generated at 2022-06-25 05:31:59.271504
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:32:11.218643
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\xc7%k\xe2\x14\x1e\x89d\x00'
    str_0 = '(X*<E?N'
    int_0 = -1028
    results_0 = []
    original_host_0 = AnsibleHost(str_0)
    original_task_0 = Task()
    include_result_0 = {'include': str_0}
    include_args_0 = {}
    include_result_0['include_args'] = include_args_0
    loop_var_0 = 'ansible_loop_var'
    index_var_0 = 'ansible_index_var'
    if loop_var_0 in include_result_0:
        task_vars_0 = {}

# Generated at 2022-06-25 05:32:19.413162
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\xc7%k\xe2\x14\x1e\x89d\x00'
    str_0 = '(X*<E?N'
    int_0 = -1028
    assert IncludedFile.process_include_results(bytes_0, str_0, int_0, str_0) == -1028

if __name__ == '__main__':
    test_IncludedFile_process_include_results()
    test_case_0()

# Generated at 2022-06-25 05:32:28.917233
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bytes_0 = b'\xc7%k\xe2\x14\x1e\x89d\x00'
    str_0 = '(X*<E?N'
    int_0 = -1028
    included_file_0 = IncludedFile(bytes_0, str_0, str_0, int_0)

    float_0 = -5.5
    float_1 = -5.5
    float_2 = -5.5
    float_3 = -5.5
    float_4 = -5.5
    float_5 = -5.5
    str_1 = '7'
    str_2 = 'U'
    str_3 = 'P'