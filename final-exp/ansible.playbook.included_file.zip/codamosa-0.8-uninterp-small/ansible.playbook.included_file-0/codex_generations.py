

# Generated at 2022-06-25 05:24:33.042646
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)
    list_0 = [included_file_0]
    results = list_0
    iterator = included_file_0
    loader = included_file_0
    variable_manager = included_file_0
    try:
        IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    except IOError as e:
        print ('Expected:', to_text(e))


# Generated at 2022-06-25 05:24:39.314202
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    string = 'tests/fixtures/test_handler_include/test_case_0/results.json'
    iterator = None
    loader = None
    variable_manager = None
    result = IncludedFile.process_include_results(string, iterator, loader, variable_manager)
    assert result is not None

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:24:44.929629
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)
    included_file_1 = IncludedFile(bool_0, bool_1, str_0, int_0)
    assert included_file_0 == included_file_1

# Generated at 2022-06-25 05:24:50.292328
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    bool_0 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)
    original_host = 'pF&ImFFI;7\''
    original_host_0 = original_host
    included_file_0.add_host(original_host_0)


# Generated at 2022-06-25 05:25:01.787020
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Access data
    bool_0 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)
    bool_2 = True
    bool_3 = False
    str_1 = 'Not all paths examined, check warnings for details'
    int_1 = None
    included_file_1 = IncludedFile(bool_2, bool_3, str_1, int_1)
    bool_4 = False
    bool_5 = False
    str_2 = 'Not all paths examined, check warnings for details'
    int_2 = None
    included_file_2 = IncludedFile(bool_4, bool_5, str_2, int_2)

# Generated at 2022-06-25 05:25:11.432559
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    results_0 = []
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    return_value_0 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)
    if return_value_0 != []:
        raise ValueError('Returned values were expected to equal [], but they were not.')


if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:25:18.479947
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)
    assert included_file_0.__eq__(included_file_0)


# Generated at 2022-06-25 05:25:25.459381
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.utils.path import makedirs_safe
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    bool_0 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)
    included_file_1 = IncludedFile(bool_0, bool_1, str_0, int_0)
    bool_2 = (included_file_0 == included_file_1)


# Generated at 2022-06-25 05:25:34.453334
# Unit test for method __eq__ of class IncludedFile

# Generated at 2022-06-25 05:25:38.786811
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 05:26:00.902835
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)

    int_0 = None
    str_0 = 'Not all paths examined, check warnings for details'
    bool_1 = False
    bool_2 = True
    included_file_1 = IncludedFile(bool_2, bool_1, str_0, int_0)

    bool_2 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_2 = IncludedFile(bool_0, bool_1, str_0, int_0)

    bool_2

# Generated at 2022-06-25 05:26:09.736521
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    args = 'localhost'

# Generated at 2022-06-25 05:26:10.596580
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 05:26:11.090611
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:26:12.463890
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = 0
    int_1 = 1
    object_0 = IncludedFile()
    task_executor_0 = object_0.process_include_results()


# Generated at 2022-06-25 05:26:20.745874
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    result_0 = dict()
    result_0['include'] = 'string'
    result_0['include_args'] = dict()
    result_1 = dict()
    result_1['include'] = 'string'
    result_1['include_args'] = dict()
    result_2 = dict()
    result_2['include'] = 'string'
    result_2['include_args'] = dict()
    result_3 = dict()
    result_3['include'] = 'string'
    result_3['include_args'] = dict()
    result_4 = dict()
    result_4['include'] = 'string'
    result_4['include_args'] = dict()
    result_5 = dict()
    result_5['include'] = 'string'
    result_5['include_args'] = dict()
   

# Generated at 2022-06-25 05:26:21.653192
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True


# Generated at 2022-06-25 05:26:28.078515
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test using parameters

    included_file_0 = IncludedFile(None, None, None, None)

    # Test using parameters

    included_file_1 = IncludedFile(None, None, None, None)

    # Test using parameters

    included_file_2 = IncludedFile(None, None, None, None)

    # Test using parameters

    included_file_3 = IncludedFile(None, None, None, None)

    # Test using parameters

    included_file_4 = IncludedFile(None, None, None, None)

    # Test using parameters

    included_file_5 = IncludedFile(None, None, None, None)

    # Test using parameters

    included_file_6 = IncludedFile(None, None, None, None)


# Generated at 2022-06-25 05:26:33.170703
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    iterator_0 = mock.Mock()
    loader_0 = mock.Mock()
    variable_manager_0 = mock.Mock()
    results_0 = mock.Mock()
    included_file_0 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)

# Generated at 2022-06-25 05:26:40.443454
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)
    tuple_0 = ()
    list_0 = [True]
    tuple_1 = (included_file_0,)
    list_1 = [True]
    variable_manager_0 = None
    variable_manager_0 = variable_manager_0
    IncludedFile_process_include_results_ret_val_0 = IncludedFile.process_include_results(list_0, tuple_0, tuple_1, variable_manager_0)
    assert isinstance(IncludedFile_process_include_results_ret_val_0, list)

# Test case for

# Generated at 2022-06-25 05:27:16.122555
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()


# Generated at 2022-06-25 05:27:17.960723
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    try:
        test_case_0()
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 05:27:28.755861
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    my_passwords = dict(vault_pass='secret')
    my_inventory = Inventory(host_list=['my_host'])
    play_source = dict(
            name = "Ansible Play 0",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='ping', args='')),
            ]
        )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    tqm = None

# Generated at 2022-06-25 05:27:30.367733
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert included_file_0.process_include_results(bool_0, bool_1, str_0, int_0) == True

# Generated at 2022-06-25 05:27:33.777248
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)
    included_file_1 = IncludedFile(bool_0, bool_1, str_0, int_0)
    bool_2 = IncludedFile.__eq__(included_file_0, included_file_1)
    assert bool_2 == True


# Generated at 2022-06-25 05:27:35.135540
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:27:37.312065
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(bool(), bool(), str(), int())

    included_file_0.__eq__(str())


# Generated at 2022-06-25 05:27:46.457226
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = False
    bool_1 = True
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, int_0, int_0)
    bool_2 = True
    int_0 = 8
    int_1 = 1
    list_0 = [int_1]
    obj_0 = object()
    int_2 = 4
    list_1 = [int_2]
    value_0 = list_1
    int_3 = 2
    list_2 = [int_3]
    list_3 = [obj_0]
    result_0 = TaskResult(bool_2, int_0, list_1, list_0, list_2, obj_0, False, list_3, value_0, int_1)

# Generated at 2022-06-25 05:27:48.843082
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:54.892135
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = 'Not all paths examined, check warnings for details'
    results = str_0
    iterator = str_0
    loader = str_0
    variable_manager = str_0
    assert IncludedFile.process_include_results(results, iterator, loader, variable_manager) == 'Not all paths examined, check warnings for details'

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:14.854826
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult

    task_include_0 = TaskInclude('tasks.y', 'main', True)
    task_include_1 = TaskInclude('tasks.y', 'main', True)
    dict_0 = {'_ansible_parsed': True, '_ansible_no_log': False, '_ansible_item_label': '', '_ansible_diff': False, 'include': 'something.y', 'changed': False, 'failed': False, 'ansible_loop_var': 'item', 'ansible_item_label': [], 'ansible_no_log': False, 'skip_words': ('',), 'skip_if_unavailable': False, 'omit': ''}
    task

# Generated at 2022-06-25 05:29:26.003911
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = True
    bool_1 = True
    int_0 = None
    included_file_0 = IncludedFile(bool_1, int_0, int_0, int_0)
    included_file_0.add_host(bool_0)
    list_0 = [included_file_0]
    dict_0 = dict()
    dict_0['results'] = list_0
    dict_1 = dict(results=[dict_0])
    dict_2 = dict(results=[dict_0])
    dict_3 = dict(results=[dict_0])
    dict_4 = dict(results=[dict_0])
    dict_5 = dict(results=[dict_0])
    dict_6 = dict(results=[dict_0])
    dict_7 = dict(results=[dict_0])
    dict_

# Generated at 2022-06-25 05:29:37.391750
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)

    int_0 = 2
    str_1 = 'TODO'
    str_2 = '/tasks'
    str_3 = '    - debug: msg="hello"'
    int_1 = -1
    # List[dict]
    list_0 = []

# Generated at 2022-06-25 05:29:46.617472
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)
    assert included_file_0.__eq__(included_file_0) == bool_0
    included_file_1 = IncludedFile(bool_1, bool_0, str_0, int_0)
    included_file_2 = IncludedFile(bool_0, bool_0, str_0, int_0)
    included_file_3 = IncludedFile(bool_0, bool_1, str_1, int_0)
    included_file_4 = IncludedFile(bool_0, bool_1, str_0, int_1)
    assert included_file_2.__eq__(included_file_0) == bool_1

# Generated at 2022-06-25 05:29:48.876246
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    included_file_0 = IncludedFile(None, None, None, None)
    included_file_1 = IncludedFile(None, None, None, None)

    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:29:55.552930
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile()
    results = []
    iterator = [1, 2]
    loader = True

# Generated at 2022-06-25 05:30:04.630904
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)
    bool_2 = True
    bool_3 = False
    str_1 = 'Not all paths examined, check warnings for details'
    int_1 = None
    included_file_1 = IncludedFile(bool_2, bool_3, str_1, int_1)
    assert included_file_0.__eq__(included_file_1) == bool_2


# Generated at 2022-06-25 05:30:06.635870
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert 0 == 0, "Test Failed"


# Generated at 2022-06-25 05:30:11.903090
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    bool_1 = False
    str_0 = 'Not all paths examined, check warnings for details'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)
    bool_2 = True
    bool_3 = False
    str_1 = 'Not all paths examined, check warnings for details'
    int_1 = None
    included_file_1 = IncludedFile(bool_2, bool_3, str_1, int_1)
    # Assert
    assert included_file_0.__eq__(included_file_1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:30:21.697016
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # case 0
    test_case_0()
    # case 1
    bool_0 = True
    bool_1 = False
    str_0 = 'You have a good soul'
    int_0 = None
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, int_0)
    bool_2 = True
    bool_3 = True
    str_1 = 'The vast majority of them are quite content to follow the herd'
    int_1 = None
    included_file_1 = IncludedFile(bool_2, bool_3, str_1, int_1)
    bool_2 = True
    bool_3 = False
    str_1 = 'You have a good soul'
    int_1 = None

# Generated at 2022-06-25 05:32:45.857439
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile(bool(), bool(), str(), bool())
    bool_0 = included_file_0.__eq__(included_file_0)
    assert bool_0 == True


# Generated at 2022-06-25 05:32:53.728740
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile('host', True, 'vars', 'task')
    included_file_1 = IncludedFile('host_1', True, 'vars', 'task')
    included_file_2 = IncludedFile('another_file', True, 'vars', 'task')
    included_file_3 = IncludedFile('another_file', True, 'vars', 'task')
    included_file_4 = IncludedFile('another_file', True, 'vars', 'task')
    included_file_5 = IncludedFile('file', True, 'vars', 'task')
    included_file_6 = IncludedFile('another_file', True, 'vars', 'task')
    included_file_7 = IncludedFile('another_file', True, 'vars', 'task')
    included_files_0 = []
    included

# Generated at 2022-06-25 05:32:56.982841
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = True
    bool_1 = True
    str_0 = 'Not all paths examined, check warnings for details'
    bool_2 = True
    included_file_0 = IncludedFile(bool_0, bool_1, str_0, bool_2)
    var_0 = included_file_0.__eq__(included_file_0)


# Generated at 2022-06-25 05:33:06.400768
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(str_0, bool_0, bool_0, str_0)
    included_files = IncludedFile.process_include_results(bool_0, bool_0, bool_0, bool_0)
    assert_true(isinstance(included_files, list), 'Argument is not of type "list".')
    # Test with a non-empty list
    IncludedFile.process_include_results(list_0, bool_0, bool_0, bool_0)
    assert_true(isinstance(included_files, list), 'Argument is not of type "list".')


if __name__ == "__main__":
    # Unit test
    config_module_0 = importlib.import_module('ansible.config.base')

# Generated at 2022-06-25 05:33:07.512434
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert test_case_0() == None

# Generated at 2022-06-25 05:33:08.437722
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:33:13.253348
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = True
    str_0 = 'Not all paths examined, check warnings for details'
    included_file_0 = IncludedFile(bool_0, bool_0, str_0, bool_0)
    included_file_0.process_include_results(bool_0, bool_0, bool_0, bool_0)

if __name__ == "__main__":
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:33:22.849249
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test open file and do not read
    bool_0 = True
    str_0 = "FprTlQQMyYrzrYywO8yv"
    included_file_0 = IncludedFile(
        bool_0,
        bool_0,
        str_0,
        bool_0,
        bool_0
    )
    bool_1 = False
    str_1 = "n2npNvLcHhWIiDnKgGdN"
    included_file_1 = IncludedFile(
        bool_1,
        bool_1,
        str_1,
        bool_1,
        bool_1
    )
    bool_2 = False
    str_2 = "cO4MZkFWOvA9X2Qie1r6"
    included_file

# Generated at 2022-06-25 05:33:26.968646
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = True
    include_results_0 = [bool_0]
    iterator_0 = bool_0
    loader_0 = bool_0
    variable_manager_0 = bool_0
    str_0 = IncludedFile.process_include_results(include_results_0, iterator_0, loader_0, variable_manager_0)
    print(str_0)


# Generated at 2022-06-25 05:33:33.693954
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = True
    list_0 = ['include_results']
    tuple_0 = (list_0, list_0)
    included_file_0 = IncludedFile.process_include_results(tuple_0, bool_0, bool_0, bool_0)
    var_0 = included_file_0[0]._is_role

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()