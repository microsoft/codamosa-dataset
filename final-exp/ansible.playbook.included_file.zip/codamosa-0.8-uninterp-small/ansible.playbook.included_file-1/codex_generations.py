

# Generated at 2022-06-25 05:24:27.303582
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -460.529013
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1109.8
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    included_file_0 = IncludedFile.process_include_results(included_file_0, included_file_0, included_file_0, included_file_0)
    return included_file_0

# Generated at 2022-06-25 05:24:37.572151
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = {}
    dict_1 = dict_0
    dict_0 = dict_1;
    dict_2 = {}
    dict_1 = dict_2;
    iterator_0 = dict_0
    dict_0 = dict_1;
    dict_1 = {}
    dict_2 = dict_1;
    dict_1 = dict_2;
    loader_0 = dict_0
    dict_0 = dict_1;
    dict_1 = {}
    dict_2 = dict_1;
    dict_1 = dict_2;
    variable_manager_0 = dict_0
    dict_0 = dict_1;
    dict_1 = {}
    dict_2 = dict_1;
    dict_1 = dict_2;
    results_0 = dict_0
    dict_0 = dict_

# Generated at 2022-06-25 05:24:40.307551
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = IncludedFile.process_include_results()

# vim: set expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 05:24:50.340090
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -460.529013
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1109.8
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    float_2 = -460.529013
    dict_1 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_1 = set()
    float_3 = 1109.8
    included_file_1 = IncludedFile(float_2, dict_1, set_1, set_1, float_3)
    # __eq__(self, IncludedFile)
    assert included_file

# Generated at 2022-06-25 05:24:58.817843
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    float_0 = -460.529013
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1109.8
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    included_file_0.add_host(float_0)

# unit test of function IncludedFile.process_include_results

# Generated at 2022-06-25 05:25:05.470262
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    included_file_0 = IncludedFile(dict_0, dict_1, dict_2, dict_3, dict_4, dict_5, dict_6, dict_7, dict_8, dict_9, dict_10, dict_11)


# Generated at 2022-06-25 05:25:06.758085
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

if __name__ == "__main__":
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:25:11.967199
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -837.327961
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1109.8
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    included_file_1 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    included_file_2 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    list_0 = [included_file_1, included_file_2, included_file_0]

# Generated at 2022-06-25 05:25:22.508716
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile
    class_0 = IncludedFile
    dictionary_0 = {'uuid': 'uuid', 'error': 'error', 'msg': 'msg'}
    str_0 = 'msg'
    set_0 = {str_0, str_0}
    str_1 = 'error'
    dictionary_1 = {str_1}
    str_2 = 'uuid'
    dictionary_2 = {str_2, str_2}
    dictionary_3 = {'uid': 'uid', 'uid': 'uid', 'action': 'action', 'result': 'result'}
    str_3 = 'action'
    str_4 = 'result'
    str_5 = 'uid'

# Generated at 2022-06-25 05:25:28.649761
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.play_iterator import PlayIterator

    variable_manager = VariableManager()
    loader = DataLoader()
    # Set start time
    start_time = datetime.now()

    # Create inventory, use path to host conf file as source or hosts in a comma separated string
    inventory = InventoryManager(loader=loader, sources="localhost,")

    # Variable manager takes care of merging all the different sources to give you a unified

# Generated at 2022-06-25 05:25:56.148351
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    inc_file_0 = IncludedFile(str_0, bool_0, bool_0, bool_0)
    inc_file_1 = IncludedFile(str_1, bool_0, bool_0, bool_0)
    assert inc_file_0 != inc_file_1
    bool_0 = bool_1
    assert inc_file_0 == inc_file_1


# Generated at 2022-06-25 05:25:58.339828
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    x = 0
    print("Running test_IncludedFile_process_include_results() ...")
    test_IncludedFile_process_include_results_000()
    print("%d tests passed." % x)


# Generated at 2022-06-25 05:25:58.921419
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False


# Generated at 2022-06-25 05:25:59.928967
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:02.248792
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert test_case_0() == None, "test_case_0 Failed"


# Generated at 2022-06-25 05:26:10.524630
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:26:15.600349
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

# Unit test entry: if run as a script, run all tests
if __name__ == '__main__':
    print("Running tests ...")
    print("Running test 'test_IncludedFile_process_include_results' ...")
    test_IncludedFile_process_include_results()
    print("Test 'test_IncludedFile_process_include_results' ran successfully")
    print("Tests ran successfully")

# Generated at 2022-06-25 05:26:17.053683
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert(IncludedFile.process_include_results(test_case_0)) ==  ('')

# Generated at 2022-06-25 05:26:19.275060
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file = IncludedFile
    str_0 = 'localhost,'
    included_file.process_include_results(str_0)


# Generated at 2022-06-25 05:26:21.707755
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        IncludedFile.process_include_results(str_0)
    except TypeError as texception:
        assert texception == 'process_include_results() takes at least 6 arguments (1 given)'


# Generated at 2022-06-25 05:26:46.179087
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -460.529013
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1109.8
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    float_2 = 763.415978
    dict_1 = {float_2: float_2, float_2: float_2}
    set_1 = set()
    float_3 = -285.9
    set_2 = {float_0, float_1, float_2, float_3}
    included_file_1 = IncludedFile(float_0, dict_1, set_1, set_2, float_2)
   

# Generated at 2022-06-25 05:26:50.024504
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        assert test_case_0() == 'Pass'
    except:
        print('Test Failed')
        return 'Fail'
    print('Success')
    return 'Pass'

# Main method calling
if __name__ == "__main__":
    print(test_IncludedFile_process_include_results())

# Generated at 2022-06-25 05:26:56.054785
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    loop_0 = [1, 1, 1]
    var_0 = {loop_0[0]: loop_0[0], loop_0[1]: loop_0[1], loop_0[2]: loop_0[2]}
    included_file_0 = IncludedFile(var_0, var_0, loop_0, loop_0, loop_0[2])

if __name__ == '__main__':
    # test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:05.383553
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print("Method: process_include_results of Class: IncludedFile")
    float_0 = 159.0811
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1843.82
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    list_0 = list()
    list_1 = list()
    list_1.append(included_file_0)
    float_2 = float_1 / float_0
    float_3 = float_1 / float_0
    float_4 = float_1 / float_1
    list_2 = list()
    list_2.append(float_4)
    list

# Generated at 2022-06-25 05:27:14.760802
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    set_0 = set()
    float_0 = -460.529013
    set_1 = set()
    tuple_0 = (None, set_1, float_0)
    tuple_1 = (None, tuple_0, set_0, None, None)
    tuple_2 = (set_1, None, None, None)
    tuple_3 = (None, tuple_2, None)
    tuple_4 = (tuple_3, None, set_1, None)
    tuple_5 = (tuple_4, tuple_4, tuple_4, tuple_4)
    tuple_6 = (tuple_5, tuple_5)

# Generated at 2022-06-25 05:27:17.057275
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [object()]
    iterator = object()
    loader = object()
    variable_manager = object()
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)

for _ in range(1000):
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:19.244538
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(0, 1, 2, 3)
    # assert process_include_results is False
    assert included_file_0.process_include_results(0, 1, 2, 3) == False

# Generated at 2022-06-25 05:27:28.907527
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(15337.574931, {}, {}, {}, {}, {}, {}, {}, {}, {}, {})
    dict_0 = {}
    dict_2 = {}
    dict_1 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_1['ansible_playbook_python'] = dict_0
    dict_1['playbook_dir'] = dict_1
    dict_1['playbook_dir'] = dict_2
    dict_0['playbook_dir'] = dict_1
    dict_0['playbook_dir'] = dict_3
    dict_3['playbook_dir'] = dict_4
    dict_4['playbook_dir'] = dict_5

# Generated at 2022-06-25 05:27:34.277520
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -460.529013
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1109.8
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    results_0 = [included_file_0]
    IncludedFile.process_include_results(results_0, float_0, float_0, float_0)

if __name__ == "__main__":
    test_IncludedFile_process_include_results()
    test_case_0()

# Generated at 2022-06-25 05:27:34.764183
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:28:08.515978
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = None
    results = included_file_0
    iterator = included_file_0
    loader = included_file_0
    variable_manager = included_file_0
    included_file_0 = IncludedFile.process_include_results(results, iterator, loader, variable_manager)


if __name__ == "__main__":
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:15.111836
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -460.529013
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1109.8
    float_2 = -5.008944E7
    float_3 = 1.41
    dict_1 = {float_2: float_2, float_2: float_2, float_2: float_2}
    float_4 = 3.4142135E9
    float_5 = -88.782738
    float_6 = -1.0
    float_7 = 1.0
    dict_2 = {float_4: float_4, float_4: float_4, float_4: float_4}
    float_8 = 2.2250738

# Generated at 2022-06-25 05:28:17.970584
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -460.529013
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1109.8
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)


# Generated at 2022-06-25 05:28:21.962042
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -460.529013
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1109.8
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    IncludedFile.process_include_results(included_file_0)


if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()
    print('All test cases passed!')

# Generated at 2022-06-25 05:28:24.107145
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None, None)
    included_file_0.process_include_results(None, None, None, None)
    assert True



# Generated at 2022-06-25 05:28:25.042454
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 05:28:35.211449
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:28:41.358148
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_0 = [None, None]
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    included_file_process_include_results_0 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)
    assert included_file_process_include_results_0 == []


# Generated at 2022-06-25 05:28:43.129176
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile()
    included_file_0.process_include_results()

# Generated at 2022-06-25 05:28:47.003188
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print("Testing process_include_results with invalid input")
    try:
        IncludedFile.process_include_results(None, None, None, None)
    except TypeError:
        print("Passed test1")
    else:
        print("Failed test1")


# Generated at 2022-06-25 05:29:46.829459
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = {'F[\x1f': 'X\x0e', 'yP\x0c': 'a\x13', '&\x0c\x07': 'X\x0e', 'p\x04\x00\x00': 'X\x0e', '6m\x00': 'X\x0e', '\x07\x0f': 'X\x0e', '\x01\x00\x00\x00': 'X\x0e'}
    set_0 = set()
    results = []
    iterator = {}
    loader = {}
    variable_manager = {}
    assert IncludedFile.process_include_results(results, iterator, loader, variable_manager) == ([],)

if __name__ == "__main__":
    test_IncludedFile_

# Generated at 2022-06-25 05:29:53.955766
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Declare the arguments
    iterator = None
    loader = None
    variable_manager = None
    # Retrieve the function under test
    func = IncludedFile.process_include_results

    # build test cases
    test_0_args = (iterator, loader, variable_manager)
    test_0_kwargs = {}

    test_cases = [
        (test_0_args, test_0_kwargs),
    ]

    # execute the tests
    results = []
    for test_args, test_kwargs in test_cases:
        try:
            func_result = func(*test_args, **test_kwargs)
        except Exception as e:
            func_result = e

        results.append((func_result, test_args, test_kwargs))
    return results

# Generated at 2022-06-25 05:30:02.168572
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -460.529013
    dict_0 = {}
    set_0 = set()
    float_1 = 1109.8
    included_file_0 = IncludedFile(float_0, dict_0, dict_0, set_0, float_1)
    test_subject = IncludedFile(float_0, dict_0, float_0, float_1)
    assert test_subject is not None


# Generated at 2022-06-25 05:30:09.698030
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [{'include_args': {}, 'ansible_loop_var': 'item', 'ansible_index_var': 'index', 'include': './test-include.yml', '_ansible_item_label': 3.939239, 'ansible_loop': {'last_item': 1000, 'index': 6.88, 'parent': {'last_item': 1000, 'index': 6.88}, 'first_item': 1000, 'name': 'foobar', 'depth': 1, 'type': 'dict', 'children': []}, 'changed': True, '_ansible_no_log': False, '_ansible_item_result': True}]
    iterator = None
    loader = None
    variable_manager = None

# Generated at 2022-06-25 05:30:15.063041
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = {}
    iterator = {}
    loader = {}
    variable_manager = {}
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:30:20.416185
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        IncludedFile.process_include_results(None, None, None, None)
    except TypeError:
        pass
    try:
        IncludedFile.process_include_results(None, None, None, None)
    except TypeError:
        pass
    try:
        IncludedFile.process_include_results(None, None, None, None)
    except TypeError:
        pass

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:30:21.300117
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # Setup test case
    test_case_0()


# Generated at 2022-06-25 05:30:25.054926
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = {'foo': 3.2}
    results = [dict_0]
    IncludedFile.process_include_results(results, None, None, None)

# Generated at 2022-06-25 05:30:32.315491
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = -460.529013
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1109.8
    float_1 = float_0
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    float_0 = float_0
    float_2 = 649.833494
    float_2 = float_2
    float_2 = IncludedFile.process_include_results(float_0, float_0, float_0, float_2)

# Generated at 2022-06-25 05:30:38.353502
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -460.529013
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1109.8
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    assert included_file_0.__eq__(included_file_0)


# Generated at 2022-06-25 05:31:36.940636
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = {}
    variable_manager = variable_manager = VariableManager()
    loader = variable_manager = VariableManager()
    iterator = variable_manager = VariableManager()
    results = variable_manager = VariableManager()
    variable_manager = variable_manager = VariableManager()
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:31:38.351082
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    a = 1
    b = 2
    assert a==b


# Generated at 2022-06-25 05:31:49.760463
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -1368.924167
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 718.8
    float_2 = 0.02213
    float_3 = float_1
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    float_2 = float_2
    float_0 = -408.74067
    dict_1 = {float_0: float_0, float_1: float_2, float_0: float_2}
    included_file_1 = IncludedFile(float_3, dict_1, set_0, set_0, float_1)
    included_file_

# Generated at 2022-06-25 05:31:57.762865
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = -460.529013
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    set_0 = set()
    float_1 = 1109.8
    included_file_0 = IncludedFile(float_0, dict_0, set_0, set_0, float_1)
    float_2 = -254.2
    dict_1 = {float_2: float_0, float_1: float_0, float_0: float_1}
    float_3 = 3169.0
    included_file_1 = IncludedFile(float_2, dict_1, set_0, set_0, float_3)
    float_4 = -1158.9

# Generated at 2022-06-25 05:32:09.875173
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = {'}': 'r'}
    dict_1 = {'b': '9'}
    num_0 = len(dict_0)
    list_0 = []
    long_0 = long(num_0)
    long_1 = long(dict_0)
    long_2 = long(465035345)
    long_3 = long(dict_0)
    long_4 = long(long_1)
    long_5 = long(dict_0)
    long_6 = long(dict_0)
    long_7 = long(dict_0)
    long_8 = long(dict_0)
    long_9 = long(dict_0)
    long_10 = long(dict_0)
    short_0 = short(long_10)

# Generated at 2022-06-25 05:32:13.489195
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO: Mock Ansible results, AnsiblePlayIterator, AnsibleLoader, AnsibleVariableManager
    included_file = IncludedFile()
    # TODO: Mock method call
    included_file.process_include_results()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:32:16.386104
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test case 0:
    test_case_0()

# Test class IncludedFile

# Generated at 2022-06-25 05:32:16.925888
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:32:20.123750
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(5, 5, 5, 5, 5)
    included_file_1 = IncludedFile(5, 5, 5, 5, 5)
    included_file_0.add_host(5)
    included_file_1.add_host(5)


# Generated at 2022-06-25 05:32:21.946160
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    iterator = None
    loader = None
    variable_manager = None
    IncludedFile.process_include_results(iterator,loader,variable_manager)