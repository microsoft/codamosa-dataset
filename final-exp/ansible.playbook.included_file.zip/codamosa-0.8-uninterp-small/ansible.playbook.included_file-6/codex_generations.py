

# Generated at 2022-06-25 05:24:38.949877
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = IncludedFile.process_include_results('Z\x0c\x8b\x0c', '', '\x82\x81', '\x08\x92S')
    assert results == 1


# Generated at 2022-06-25 05:24:39.620682
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False

# Generated at 2022-06-25 05:24:45.529049
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        test_name = sys.argv[1]
    else:
        test_name = 'test_IncludedFile_process_include_results'
    if test_name not in globals():
        print("Test %s not found" % test_name)
    else:
        globals()[test_name]()

# Generated at 2022-06-25 05:24:46.689282
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print(test_case_0())



# Generated at 2022-06-25 05:24:49.751178
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_1 = IncludedFile('', (), (), ())
    included_file_2 = test_case_0()

# Generated at 2022-06-25 05:24:56.255724
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # TODO: Optionally pass in argument to the test
    included_file_0 = None
    IncludedFile.process_include_results(included_file_0, included_file_0, included_file_0, included_file_0)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:24:59.383152
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    assert len(IncludedFile.process_include_results(tuple(), tuple(), tuple(), tuple())) == 0


# Generated at 2022-06-25 05:25:07.082508
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile('', (), (), ())
    included_file_1 = IncludedFile('', (), (), ())
    included_file_2 = IncludedFile('', (), (), ())
    assert included_file_0 == included_file_1
    assert included_file_1 == included_file_0
    assert not included_file_0 == included_file_2
    assert not included_file_1 == included_file_2
    assert not included_file_2 == included_file_0
    assert not included_file_2 == included_file_1



# Generated at 2022-06-25 05:25:17.484621
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.loader import PluginLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.playbook import Playbook

    def _create_include_result(include, **kwargs):
        result = dict()
        result['include'] = include

        # Ansible 2.8 and prior backwards compatibility
        if 'include_args' not in kwargs:
            result['include_args'] = kwargs
        else:
            result['include_args'] = kw

# Generated at 2022-06-25 05:25:24.494320
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    str_0 = ''
    str_1 = '\x0bp'
    tuple_0 = (str_1,)
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    included_file_0.add_host(tuple_0)
    #  The result should be:
    #  None


# Generated at 2022-06-25 05:25:44.761445
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    def mocked_add_host(original_host):
        included_files_1.append(original_host)
    included_files_1 = list()
    setattr(included_file_0, 'add_host', mocked_add_host.__get__(included_file_0))
    include_results_0 = list()
    include_result_0 = dict()
    include_result_0['failed'] = False
    include_results_0.append(include_result_0)
    include_result_1 = dict()
    include_result_1['include'] = '\x12'
    include_results_0.append(include_result_1)
    include_result_2 = dict()
    include_result_2['include_args'] = dict()

# Generated at 2022-06-25 05:25:47.640357
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # zero argument
    # Call the method with correct arguments
    try:
        IncludedFile.__eq__()
    except TypeError:
        pass
    else:
        raise RuntimeError("Expected a TypeError to be raised")


# Generated at 2022-06-25 05:25:58.057731
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
  from ansible.vars import VariableManager
  from ansible.parsing.mod_args import ModuleArgsParser
  from ansible.executor.task_result import TaskResult
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.inventory.manager import InventoryManager
  from ansible.playbook.play import Play
  from ansible.plugins.loader import add_all_plugin_dirs

  add_all_plugin_dirs()

  # prepare test case

# Generated at 2022-06-25 05:26:01.995779
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # This is a static method, it can only be tested with static methods
    pass

if __name__ == '__main__':
    from tests import AnsibleRunner
    AnsibleRunner(None, test_case_0, use_cli=False).run()
    ansible_runner = AnsibleRunner(None, test_IncludedFile_process_include_results, use_cli=False)
    ansible_runner.run()

# Generated at 2022-06-25 05:26:07.542540
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = ''
    str_1 = '\x0bp'
    tuple_0 = (str_1,)
    list_0 = [tuple_0]
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    IncludedFile.process_include_results(list_0, dict_0, dict_1, dict_2, dict_3)

# Generated at 2022-06-25 05:26:14.723096
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    arg_0 = None
    arg_1 = IncludedFile.process_include_results(arg_0, arg_0, arg_0, arg_0)
    arg_2 = IncludedFile.process_include_results(arg_0, arg_0, arg_0, arg_0)
    assert arg_1.__eq__(arg_2) == None


# Generated at 2022-06-25 05:26:23.130726
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Testing variable
    results = ['\x96', '\x83\x1d\x1f', '\x83\x1d\x03\x0e', '\x83\xed\x1f\x1c', '\x83\xed\x03\x0e\x0b', '\x83\xed\x03\x0e\x0b\x1c', '\x83\xed\x1f\x1c\x0b']
    iterator = None
    loader = '\x9f\x9e\x9f'
    variable_manager = '\xdf\x9e\x9c\x9a'
    # Function call
    return IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:26:24.973732
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()


# Generated at 2022-06-25 05:26:31.151664
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    str_0 = ''
    str_1 = '\x0bp'
    tuple_0 = (str_1,)
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    str_2 = '\x0e/@'
    included_file_0.add_host(str_2)


# Generated at 2022-06-25 05:26:35.108922
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

if __name__ == "__main__":
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:48.351566
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:26:55.283392
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = dict()

# Generated at 2022-06-25 05:26:58.313768
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    str_0 = ''
    str_1 = '\x0bp'
    tuple_0 = (str_1,)
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    str_2 = ''
    with raises(ValueError):
        included_file_0.add_host(str_2)

if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-25 05:27:01.613401
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:06.829140
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_0 = tuple()
    iterator_0 = tuple()
    loader_0 = tuple()
    variable_manager_0 = tuple()
    ret_0 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)
    print(ret_0)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:07.697179
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    test_case_0()


# Generated at 2022-06-25 05:27:12.304147
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = ''
    str_1 = '\x0bp'
    tuple_0 = (str_1,)
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    included_file_1 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    assert included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:27:14.321822
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = ''
    str_1 = '\x0bp'
    tuple_0 = (str_1,)
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    assert not included_file_0



# Generated at 2022-06-25 05:27:21.143237
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    str_0 = ''
    str_1 = '\x0bp'
    tuple_0 = (str_1,)
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    str_2 = '\xd0\x1cQ'
    included_file_0.add_host(str_2)
    str_3 = '\xd0\x1cQ'
    included_file_0.add_host(str_3)


# Generated at 2022-06-25 05:27:30.002613
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # The results of the last run.
    results = []
    # The PlayIterator for the current play.
    iterator = ''
    # The PlayContext for the current play.
    loader = ''
    # The VariableManager for the current play.
    variable_manager = ''
    # process the results of a list of include tasks and return a list of included files and their hosts
    # Returns:
    #  included_files -- a list of of IncludedFile objects, one for each set of include args and hosts
    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:27:47.810019
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = ''
    str_1 = '\x0bp'
    tuple_0 = (str_1,)
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    included_file_1 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    result_0 = included_file_0 == included_file_1


# Generated at 2022-06-25 05:27:54.278053
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    import ansible.executor.task_result as task_result
    import ansible.playbook.task as task

    results = []

    t = task.Task()
    h = task_result.TaskResult()
    h._task = t
    h._result = "Test"

    results.append(h)

    ret = IncludedFile.process_include_results(results)
    assert ret is not None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:28:03.195474
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = dict()
    str_1 = '\x0bp'
    dict_1 = {'\x0bp': str_1}
    dict_0['include_args'] = dict_1
    dict_0['failed'] = False
    dict_0['include'] = '\n\n'
    dict_0['ansible_loop_var'] = str_1
    dict_0['ansible_loop'] = '\x0bp'
    dict_0['ansible_item_label'] = str_1
    dict_0['ansible_index_var'] = str_1
    result_data_0 = [dict_0]
    result_data_0[0]['include_results'] = result_data_0

# Generated at 2022-06-25 05:28:04.808803
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:11.509425
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_value_0 = ''
    test_value_1 = ''
    test_value_2 = ''
    test_value_3 = ''
    test_value_4 = ''
    test_value_5 = ''
    test_value_6 = ''
    test_value_7 = ''
    test_value_8 = ''
    test_value_9 = ''
    test_value_10 = ''
    test_value_11 = ''
    test_value_12 = ''
    test_value_13 = ''
    test_value_14 = ''
    test_value_15 = ''
    test_value_16 = ''
    test_value_17 = ''
    test_value_18 = ''
    test_value_19 = ''
    test_value_20 = ''
    test_value_21 = ''
   

# Generated at 2022-06-25 05:28:17.314436
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:28:24.619030
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = 'I'
    str_1 = '~'
    str_2 = 'z'
    str_3 = '\x89\x08\x17\x16\x80\x9f\xbe]\xea\xac\x91\x89\xbb\x1a\xc1\x80\xf9\xab\xcd\x11\xa3\x0b\xda\xf1\xb6\xbf\xe1'
    str_4 = 'r'

# Generated at 2022-06-25 05:28:26.003742
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    class_0 = IncludedFile('', (), (), ())
    class_1 = IncludedFile('', (), (), ())
    assert class_0.__eq__(class_1)


# Generated at 2022-06-25 05:28:36.244870
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Init mock objects
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    test_loader = DataLoader()
    test_inventory = InventoryManager(loader=test_loader, sources=['test/unit/ansible/inventory/hosts'])
    test_variable_manager = VariableManager(loader=test_loader, inventory=test_inventory)

# Generated at 2022-06-25 05:28:47.776264
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # AssertionError: unexpected type in generator: <class 'ModuleDeprecationWarning'>
    try:
        assert isinstance(IncludedFile.process_include_results, object)
        assert len(IncludedFile.process_include_results.__defaults__) == 4
        assert isinstance(IncludedFile.process_include_results.__code__, object)
        assert IncludedFile.process_include_results.__code__.co_argcount == 4
        assert isinstance(IncludedFile.process_include_results.__code__, object)
        assert IncludedFile.process_include_results.__code__.co_varnames == ('results', 'iterator', 'loader', 'variable_manager')
    except AssertionError as e:
        display.error(str(e))


# Generated at 2022-06-25 05:29:12.918853
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = '~'
    str_1 = '\t'
    tuple_0 = (str_1,)
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    included_file_0.process_include_results([included_file_0], tuple_0, tuple_0, tuple_0)

# Generated at 2022-06-25 05:29:14.671928
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False


# Generated at 2022-06-25 05:29:16.851859
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        IncludedFile.process_include_results()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 05:29:18.373406
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:27.407665
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:29:36.618790
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = ''
    str_1 = '\x0bp'
    tuple_0 = (str_1,)
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    str_2 = 'g6Ud'
    tuple_1 = (str_1,)
    included_file_1 = IncludedFile(str_2, tuple_0, tuple_1, tuple_0)
    bool_0 = included_file_0.__eq__(included_file_1)


# Generated at 2022-06-25 05:29:43.643598
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile('', (), (), ())
    included_file_1 = IncludedFile('', (), (), ())
    included_file_2 = IncludedFile('', (), (), ())
    included_file_3 = IncludedFile('', (), (), ())
    included_file_4 = IncludedFile('', (), (), ())
    included_file_5 = IncludedFile('', (), (), ())
    included_file_6 = IncludedFile('', (), (), ())
    included_file_7 = IncludedFile('', (), (), ())
    included_file_8 = IncludedFile('', (), (), ())
    included_file_9 = IncludedFile('', (), (), ())
    included_file_10 = IncludedFile('', (), (), ())
    included_file_11 = IncludedFile('', (), (), ())
    included_file_12 = IncludedFile('', (), (), ())
    included_file

# Generated at 2022-06-25 05:29:48.228250
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # No exception thrown
    argument_0 = IncludedFile.process_include_results(tuple(), tuple(), tuple(), tuple())
    assert 'IncludedFile' in repr(argument_0[0])
    assert 'IncludedFile' in repr(argument_0[1])


if __name__ == "__main__":
    test_IncludedFile_process_include_results()
    test_case_0()

# Generated at 2022-06-25 05:29:51.043696
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
  # Create a new object of class IncludedFile
  includedFile_0 = IncludedFile()
  # Call the process_include_results method of class IncludedFile using the object includedFile_0
  includedFile_0.process_include_results()

# Generated at 2022-06-25 05:30:02.463206
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test fixture 0
    iterator = None
    loader = None
    variable_manager = None
    results = None
    # Test fixture 1
    iterator = None
    loader = None
    variable_manager = None
    results = None
    # Test fixture 2
    iterator = None
    loader = None
    variable_manager = None
    results = None
    # Test fixture 3
    iterator = None
    loader = None
    variable_manager = None
    results = None
    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert included_files == []

if __name__ == '__main__':
    import sys
    sys.exit(0 if not test_case_0() else 1)

# Generated at 2022-06-25 05:30:16.513610
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    print('Test case', test_case_0.__doc__)
    test_case_0()


if __name__ == '__main__':
    test_IncludedFile___eq__()

# Generated at 2022-06-25 05:30:17.952780
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    IncludedFile.process_include_results(tuple, tuple, tuple, tuple)


# Generated at 2022-06-25 05:30:22.202633
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '#'
    tuple_0 = (None, None)
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    str_0 = '@'
    tuple_0 = (None, None)
    included_file_1 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    assert included_file_0.__eq__(included_file_1) == False


# Generated at 2022-06-25 05:30:23.732833
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:30:25.052972
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass  # Pass for now


test_case_0()

# Generated at 2022-06-25 05:30:33.352131
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_cases = []
    op_str_0 = '\x0bb;\x0b'
    test_cases.append(test_case_0)
    test_cases_tuple_0 = (test_cases,)
    included_file = IncludedFile(op_str_0, test_cases_tuple_0, test_cases_tuple_0, test_cases_tuple_0)
    included_files = included_file.process_include_results(test_cases_tuple_0, test_cases_tuple_0, test_cases_tuple_0, test_cases_tuple_0)
    if not included_files:
        raise AssertionError()
    if included_files[0] != included_file:
        raise AssertionError()


# Generated at 2022-06-25 05:30:35.316582
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:30:37.055351
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

# -----------------------------------------------------------------------------

# Output a test-suite summary.

# Generated at 2022-06-25 05:30:39.682282
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = IncludedFile.process_include_results(tuple_0, tuple_0, tuple_0, tuple_0)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:30:48.407027
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '\x0b'
    tuple_0 = ()
    str_1 = ''
    str_2 = '\x0be\xf1'
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    included_file_1 = IncludedFile(str_1, tuple_0, tuple_0, tuple_0)
    included_file_2 = IncludedFile(str_2, tuple_0, tuple_0, tuple_0)
    
    assert included_file_0 == included_file_1
    assert included_file_0 != included_file_2


# Generated at 2022-06-25 05:31:04.387060
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    include_result_0 = IncludedFile.process_include_results(tuple_1, dict(), dict(), dict())
    assert include_result_0 == tuple_0
    assert len(include_result_0) == 0

if __name__ == '__main__':
    print('Executing Unit Tests')
    test_case_0()
    test_IncludedFile_process_include_results()
    print('All Unit Tests Passed')

# Generated at 2022-06-25 05:31:12.998942
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile()
    included_file_0.process_include_results(0, 0, 0, 0)
    included_file_0.process_include_results(0, 0, 0, 0)
    included_file_1 = IncludedFile()
    included_file_1.process_include_results(0, 0, 0, 0)
    included_file_1.process_include_results(0, 0, 0, 0)
    included_file_1.process_include_results(0, 0, 0, 0)


# Generated at 2022-06-25 05:31:24.236950
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:31:34.973785
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Unit test setup
    # ---------------
    results_0 = []
    iterator_0 = IncludedFile
    loader_0 = IncludedFile
    variable_manager_0 = IncludedFile

    # Invoke method
    # -------------
    return_value_0 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)

    # Check return value
    # ------------------
    assert return_value_0 == []

    # Unit test setup
    # ---------------
    results_1 = [IncludedFile]
    iterator_1 = IncludedFile
    loader_1 = IncludedFile
    variable_manager_1 = IncludedFile

    # Invoke method
    # -------------

# Generated at 2022-06-25 05:31:47.299307
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = ''

# Generated at 2022-06-25 05:31:56.856283
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '\x00\x08'
    str_1 = '$'
    tuple_0 = (str_1,)
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    included_file_1 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    assert included_file_0 == included_file_1

test_case_0()
test_IncludedFile___eq__()

# Generated at 2022-06-25 05:32:08.605851
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.mod_args import ModuleArgsParser

    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.options_vars = {'op': 'baz'}

    my_result = ModuleArgsParser.parse_kv('a=hello b=world')
    my_result

# Generated at 2022-06-25 05:32:19.178002
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.parsing import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = {'hostvars': {'abc': {"x": "1234"}, "def": {"x": "1234"}}}
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])

# Generated at 2022-06-25 05:32:29.408839
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:32:34.962261
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = ''
    str_1 = '\x0bp'
    tuple_0 = (str_1,)
    included_file_0 = IncludedFile(str_0, tuple_0, tuple_0, tuple_0)
    IncludedFile.process_include_results((tuple_0, ), tuple_0, tuple_0, tuple_0)
    IncludedFile.process_include_results((tuple_0, ), tuple_0, tuple_0, tuple_0, )



# Generated at 2022-06-25 05:32:55.847347
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = 0 # replace with function call to get results
    iterator = 0 # replace with function call to get iterator
    loader = 0 # replace with function call to get loader
    variable_manager = 0 # replace with function call to get variable_manager
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:32:57.070726
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

# test class for IncludedFile.__eq__(other)

# Generated at 2022-06-25 05:32:59.477224
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = ''
    included_file_0 = IncludedFile(str_0, (), (), ())
    included_files = included_file_0.process_include_results(None, None, None, None)


# Generated at 2022-06-25 05:33:09.254102
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile('PkABSXprdG', (), (), ())
    included_file_1 = IncludedFile('PkABSXprdG', (), (), ())
    included_file_2 = IncludedFile('PkABSXprdG', (), (), ())
    included_file_1 = IncludedFile('k sCIzm', (), (), ())
    included_file_2 = IncludedFile('', (), (), ())
    included_file_1 = IncludedFile('PkABSXprdG', (), (), ())
    included_file_2 = IncludedFile('PkABSXprdG', (), (), ())
    included_file_1 = IncludedFile('PkABSXprdG', (), (), ())
    included_file_2 = IncludedFile('PkABSXprdG', (), (), ())
    included_

# Generated at 2022-06-25 05:33:11.224993
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_IncludedFile_process_include_results_0()
    test_IncludedFile_process_include_results_1()



# Generated at 2022-06-25 05:33:17.611619
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = ' '
    str_1 = 'mG'
    tuple_0 = (str_0,)
    included_file_0 = IncludedFile(str_1, tuple_0, tuple_0, tuple_0)
    bool_0 = included_file_0.__eq__(tuple_0)
    assert bool_0 == False


# Generated at 2022-06-25 05:33:19.797725
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    t0 = IncludedFile(str, tuple, tuple, tuple)
    b0 = IncludedFile.process_include_results(t0, tuple, tuple, tuple)
    assert b0 is not None

# Generated at 2022-06-25 05:33:20.783211
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:33:23.558387
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()


# Generated at 2022-06-25 05:33:24.077118
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass