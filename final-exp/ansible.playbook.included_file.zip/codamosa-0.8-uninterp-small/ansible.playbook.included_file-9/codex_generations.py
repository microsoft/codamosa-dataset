

# Generated at 2022-06-25 05:24:31.590521
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Build input variables
    results = None
    iterator = None
    loader = None
    variable_manager = None

    included_file_0 = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    print(included_file_0)

# Generated at 2022-06-25 05:24:42.324951
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = '-array'
    list_0 = [str_0, str_0, str_0]
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    list_1 = ['tasks', 'tasks', 'tasks']
    str_1 = '-array'
    list_2 = [str_1, str_1, str_1]
    bool_1 = False
    float_1 = 828.0
    included_file_1 = IncludedFile(str_1, bool_1, str_1, float_1)
    included_file_result_0 = IncludedFile.process_include_results(list_0, list_1, list_2, float_1)


# Generated at 2022-06-25 05:24:45.086629
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print('Testing process_include_results')
    #TODO


# Generated at 2022-06-25 05:24:47.376507
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = IncludedFile.process_include_results(loader=loader, play=play, variable_manager=variable_manager, iterator=iterator)

# Generated at 2022-06-25 05:24:53.190901
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    process_include_results_0 = IncludedFile.process_include_results(str(), float(), float(), float())
    print(process_include_results_0)


# Generated at 2022-06-25 05:24:58.888910
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    str_1 = '--key'
    bool_1 = False
    included_file_1 = IncludedFile(str_0, bool_0, str_1, float_0)
    assert included_file_0 == included_file_1, "Instance included_file_0 and included_file_1 are not equal"


# Generated at 2022-06-25 05:25:04.031200
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    str_1 = '-array'
    bool_1 = False
    float_1 = 828.0
    included_file_1 = IncludedFile(str_1, bool_1, str_1, float_1)
    eq(included_file_0, included_file_1)


# Generated at 2022-06-25 05:25:12.325508
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = []
    results_0 = []
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    included_files_0 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:25:13.514981
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True


# Generated at 2022-06-25 05:25:16.992628
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Note, this is really a function and not a method of IncludedFile
    # However, since IncludedFile is a class defined as a data class,
    # it is fine to test it here.
    pass

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:25:35.467838
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    inc_file = IncludedFile('x', 'y', 'z', 'a')
    inc_file.add_host('1')
    inc_file.add_host('1')

    inc_file2 = IncludedFile('x', 'y', 'z', 'a')
    inc_file2.add_host('1')

    result_inc_file = IncludedFile('x', 'y', 'z', 'a')
    result_inc_file.add_host('1')
    result_inc_file.add_host('2')

    inc_file3 = IncludedFile('x', 'y', 'z', 'a')


# Generated at 2022-06-25 05:25:36.220801
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

# Generated at 2022-06-25 05:25:46.061615
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    str_1 = ''
    bool_1 = True
    float_1 = 674.0
    included_file_1 = IncludedFile(str_1, bool_1, str_0, float_1)
    bool_2 = included_file_0.__eq__(included_file_1)
    bool_3 = included_file_1.__eq__(included_file_0)
    assert bool_2 == bool_3
    assert bool_2 != included_file_1
    assert bool_2 != included_file_0
    assert bool_2 != bool_1
    assert bool_

# Generated at 2022-06-25 05:25:51.415330
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    param_0 = '-array'
    param_1 = False
    param_2 = 828.0
    included_file_0 = IncludedFile(param_0, param_1, param_0, param_2)


# Generated at 2022-06-25 05:25:58.000422
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    variable_manager_0 = Mock()

    included_files_0 = IncludedFile.process_include_results(str_0, bool_0, str_0, variable_manager_0)
    assert included_files_0 == [], 'Expected call to IncludedFile.process_include_results() to return "%s", but it returned "%s"' % ([], included_files_0)



# Generated at 2022-06-25 05:26:06.303154
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    included_file_1 = IncludedFile(str_0, bool_0, str_0, float_0)
    included_file_2 = IncludedFile(str_0, bool_0, str_0, float_0)
    included_file_3 = IncludedFile(str_0, bool_0, str_0, float_0)
    included_file_4 = IncludedFile(str_0, bool_0, str_0, float_0)
    assert included_file_0 == included_file_1 == included_file_2 == included_file_3 == included_file_4
    # included_file

# Generated at 2022-06-25 05:26:13.031429
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()

    str_0 = str()
    str_1 = str()
    str_2 = str()
    str_3 = str()
    str_4 = str()
    str_5 = str()
    str_6 = str()
    str_7 = str()

    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()

    int_0 = int()
    int_1 = int()
    int_2 = int()
    int_3 = int()

    list_0 = list()


# Generated at 2022-06-25 05:26:16.018712
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    included_file_1 = IncludedFile(str_0, bool_0, str_0, float_0)
    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:26:24.260162
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    str_1 = '-array'
    bool_1 = False
    float_1 = 828.0
    included_file_1 = IncludedFile(str_1, bool_1, str_1, float_1)
    assert included_file_0 == included_file_1
    str_2 = '-array'
    bool_2 = False
    float_2 = 828.0
    included_file_2 = IncludedFile(str_2, bool_2, str_2, float_2)
    expected_bool_0 = True

# Generated at 2022-06-25 05:26:33.494020
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile('string', 'string', 'string', 'string')
    included_file_1 = IncludedFile('string', 'string', 'string', 'string')
    results = [included_file_0, included_file_1]
    iterator = IncludedFile('included_file_0', 'bool', 'string', 'string')
    loader = 'included_file_0'
    variable_manager = 'included_file_0'
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:26:48.915626
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
  # See http://docs.python.org/library/unittest.html for more information
  # assertEqual(first, second, msg=None)
  # Tests that first and second are equal. Raises AssertionError if they are not.
  included_file__test_case_0 = IncludedFile(str_0, bool_0, str_0, float_0)
  assert included_file__test_case_0.__eq__(included_file_0) == True


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, "-v"])

# Generated at 2022-06-25 05:26:53.556172
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = None
    iterator = None
    loader = None
    variable_manager = None
    inc = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert inc is not None

# Test method process_include_results of class IncludedFile
test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:03.899322
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = '*'
    str_1 = '-'
    str_2 = '_'
    str_3 = 'n'
    str_4 = 'no'
    str_5 = 'no_'
    str_6 = 'no_l'
    str_7 = 'no_lo'
    str_8 = 'no_log'
    str_9 = 'no_log_'
    str_10 = 'no_log_i'
    str_11 = 'no_log_it'
    str_12 = 'no_log_it_'
    str_13 = 'no_log_it_m'
    str_14 = 'no_log_it_ma'
    str_15 = 'no_log_it_mat'
    str_16 = 'no_log_it_matc'

# Generated at 2022-06-25 05:27:06.111522
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:11.223825
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_0 = []
    iterator_0 = 0
    loader_0 = IncludedFile(0, 0, 0, 0)
    variable_manager_0 = ''
    ret_val_0 = IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)

# Generated at 2022-06-25 05:27:14.334273
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_0 = "task_result"
    iterator_0 = "iterator"
    loader_0 = "loader"
    variable_manager_0 = "variable_manager"
    IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)

test_case_0()
test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:19.167882
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = 'aaa'
    bool_1 = True
    float_1 = 6837.0
    included_file_1 = IncludedFile(str_0, bool_1, str_0, float_1, bool_1)

    # verify instance properties
    assert included_file_1._filename == str_0
    assert included_file_1._args == bool_1
    assert included_file_1._vars == str_0
    assert included_file_1._task == float_1
    assert included_file_1._hosts == []
    assert included_file_1._is_role == bool_1

    results = [included_file_1]
    iterator = 'aaa'
    loader = IncludedFile(str_0, bool_1, str_0, float_1, bool_1)
    variable_manager

# Generated at 2022-06-25 05:27:19.957090
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    process_include_results()


# Generated at 2022-06-25 05:27:22.737565
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = IncludedFile.process_include_results([], [], [], [])
    assert included_files == []

# Generated at 2022-06-25 05:27:30.022239
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile('-array', False, '-array', 828.0)
    included_file_1 = IncludedFile('-array', False, '-array', 828.0)
    included_files_0 = [included_file_1]
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_2 = IncludedFile(str_0, bool_0, str_0, float_0)
    included_file_3 = IncludedFile(str_0, bool_0, str_0, float_0)
    included_file_4 = IncludedFile(str_0, bool_0, str_0, float_0)

# Generated at 2022-06-25 05:27:55.153019
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_1 = IncludedFile(str_0, float_0, float_0, float_0)
    # TODO: Uncomment when str_0 is defined
    # IncludedFile.process_include_results(str_0, float_0, float_0, float_0)
    return


# Generated at 2022-06-25 05:28:03.663166
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '0f-E]6ytX9*3GKY"0P$o4.+e|cJ|xR>w@+"%Lkd'
    float_0 = -2.4846888E+24
    str_1 = 'lD*<e'
    bool_0 = False
    included_file_0 = IncludedFile(str_0, float_0, float_0, str_0, bool_0)
    included_file_1 = IncludedFile(str_1, float_0, float_0, str_0, bool_0)
    bool_1 = included_file_0.__eq__(included_file_1)
    assert bool_1 == False, 'Expected False, got %s' % bool_1


# Generated at 2022-06-25 05:28:04.705827
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = IncludedFile.process_include_results()

# Generated at 2022-06-25 05:28:11.448546
# Unit test for method __eq__ of class IncludedFile

# Generated at 2022-06-25 05:28:16.887078
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:25.727802
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)

    str_1 = '-get'
    bool_1 = True
    float_1 = 984.0
    included_file_1 = IncludedFile(str_1, bool_1, str_1, float_1)

    str_2 = '-uid'
    bool_2 = False
    float_2 = 498.0
    included_file_2 = IncludedFile(str_2, bool_2, str_2, float_2)

    str_3 = '-get'
    bool_3 = True
    float_3 = 669.0

# Generated at 2022-06-25 05:28:36.013900
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '0312'
    bool_0 = False
    str_1 = 'vnh'
    float_0 = 628.0
    included_file_0 =  IncludedFile(str_0, bool_0, str_0, float_0)
    str_2 = 'w'
    str_3 = '.'
    bool_1 = False
    included_file_1 = IncludedFile(str_1, str_1, bool_1, float_0)
    bool_2 = True
    if (included_file_0 != included_file_1 == bool_2):
        included_file_1.__eq__(str_3, included_file_1)
    str_4 = 'xyh'

# Generated at 2022-06-25 05:28:42.942100
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile('-array', False, '-array', 828.0)
    included_file_1 = IncludedFile('-array', False, '-array', 828.0)
    included_file_0.__eq__(included_file_1) == True
    return included_file_0
    
    
IncludedFile.process_include_results('results', 'iterator', 'loader', 'variable_manager')

# Generated at 2022-06-25 05:28:48.972809
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    assert included_file_0._filename == str_0
    assert included_file_0._args == bool_0
    assert included_file_0._vars == str_0
    assert included_file_0._task._uuid == float_0


# Generated at 2022-06-25 05:29:00.259758
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test case
    task_vars1 = {}
    task_vars1["changed"] = False
    task_vars1["_ansible_item_label"] = 'eth0'
    task_vars1["ansible_facts"] = {}
    task_vars1["ansible_facts"]['ansible_eth0'] = {'active': True, 'device': 'eth0', 'ipv4': {'address': '192.168.1.13', 'netmask': '255.255.255.0', 'network': '192.168.1.0'}, 'macaddress': '00:0c:29:8d:9d:0c', 'module': 'e1000', 'mtu': 1500, 'type': 'ether', 'ipv6': []}

# Generated at 2022-06-25 05:29:37.901282
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    bool_0 = bool_0
    included_file_1 = IncludedFile(str_0, bool_0, str_0, float_0)
    bool_0 = bool_0
    assert included_file_1 == included_file_0
    bool_0 = True
    included_file_1 = IncludedFile(str_0, bool_0, str_0, float_0)
    assert included_file_1 != included_file_0

# Generated at 2022-06-25 05:29:46.959022
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_24 = bool()

# Generated at 2022-06-25 05:29:52.432849
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    str_1 = '-array'
    bool_1 = False
    float_1 = 828.0
    included_file_1 = IncludedFile(str_1, bool_1, str_1, float_1)
    result = included_file_0 == included_file_1


# Generated at 2022-06-25 05:29:58.320348
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results_1 = {}
    iterator_1 = {}
    loader_1 = {}
    variable_manager_1 = {}
    IncludedFile.process_include_results(results_1, iterator_1, loader_1, variable_manager_1)


# Generated at 2022-06-25 05:30:05.597443
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    str_1 = '-array'
    bool_1 = False
    float_1 = 828.0
    included_file_1 = IncludedFile(str_1, bool_1, str_1, float_1)
    bool_0 = included_file_0 == included_file_1
    print(bool_0)
    print(bool_0)


# Generated at 2022-06-25 05:30:06.736847
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = IncludedFile.process_include_results()


# Generated at 2022-06-25 05:30:07.204093
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:30:12.185151
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    method_result = IncludedFile.process_include_results(0,0,0,0)
    assert method_result
    assert method_result.__len__() == 0
    assert isinstance(method_result, list)

if __name__ == '__main__':
    # Change the test case number below to execute a different test case
    test_case_no = 2
    if test_case_no == 0:
        test_case_0()
    elif test_case_no == 1:
        test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:30:20.085947
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # set up environment
    results_0 = [set()]
    iterator_0 = DistributeAnsible()
    loader_0 = DataLoader()
    variable_manager_0 = GroupData()
    # set up parameters and run test
    try:
        IncludedFile.process_include_results(results_0, iterator_0, loader_0, variable_manager_0)
    except TypeError as err:
        print(err.args)
        print(err)

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print("Usage: %s <method to test>" % sys.argv[0])
        sys.exit(-1)
    else:
        globals()[sys.argv[1]]()

# Generated at 2022-06-25 05:30:22.039036
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    file_path = None
    # TypeError exception raised when file_path not a string
    with pytest.raises(TypeError):
        IncludedFile.process_include_results(file_path)


# Generated at 2022-06-25 05:31:16.207939
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    display.deprecated('test_case_0 has been removed. Remove the call from your code', version='2.14')
    test_case_0()

# Generated at 2022-06-25 05:31:20.002093
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = []
    results = included_files
    iterator = AnsiblePlay()
    loader = AnsibleLoader()
    variable_manager = AnsibleVariableManager()
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:31:28.028074
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_1 = float
    str_1 = str
    bool_1 = bool
    included_file_0 = IncludedFile(str_1, bool_1, str_1, float_1)
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    bool_2 = bool
    str_2 = str
    float_2 = float
    included_file_1 = IncludedFile(str_0, bool_0, str_0, float_0)
    bool_3 = included_file_0.__eq__(included_file_1)
    assert bool_3 is False

# Generated at 2022-06-25 05:31:31.666648
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    assert included_file_0._filename == str_0
    assert not included_file_0._args
    assert included_file_0._vars == str_0
    assert isinstance(included_file_0._task, float)
    # TODO: method __eq__ not yet implemented
    #assert included_file_0.__eq__(included_file_0) == NotImplemented


# Generated at 2022-06-25 05:31:35.079552
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
 
    t = IncludedFile.process_include_results(str_0, float_0, float_0, float_0)
    assert_equals(t, None)


# Generated at 2022-06-25 05:31:36.475384
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = IncludedFile.process_include_results()


# Generated at 2022-06-25 05:31:42.838101
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True

if __name__ == "__main__":
    import sys
    import os
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from plugin_loader import test_case_0

    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:31:48.381224
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = IncludedFile.process_include_results(str_0, bool_0, str_0, float_0)
    assert included_files == bool_0
    assert type(included_files) is list

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:31:59.187527
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from datetime import datetime
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.module_utils.basic import AnsibleModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.stats import AggregateStats
    from ansible.utils.lock import become_prompt


# Generated at 2022-06-25 05:32:07.913283
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'Wx>8'
    bool_0 = True
    float_0 = 0.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    str_1 = '!P'
    bool_1 = True
    float_1 = 0.0
    included_file_1 = IncludedFile(str_1, bool_1, str_1, float_1)
    bool_2 = (included_file_0 == included_file_1)


# Generated at 2022-06-25 05:34:04.625264
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-array'
    bool_0 = False
    float_0 = 828.0
    included_file_0 = IncludedFile(str_0, bool_0, str_0, float_0)
    str_1 = '-array'
    bool_1 = False
    float_1 = 828.0
    included_file_1 = IncludedFile(str_1, bool_1, str_1, float_1)
    assert included_file_0 == included_file_1
