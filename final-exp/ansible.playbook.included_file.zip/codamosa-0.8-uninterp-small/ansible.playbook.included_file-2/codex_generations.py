

# Generated at 2022-06-25 05:24:33.104242
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    bool_0 = getattr(included_file_0, 'process_include_results', None)
    if bool_0:
        bool_0()


# Generated at 2022-06-25 05:24:37.343683
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    loader_0 = None
    variable_manager_0 = None
    results = [None]
    iterator = None
    included_files = IncludedFile.process_include_results(results, iterator, loader_0, variable_manager_0)
    assert included_files == []


# Generated at 2022-06-25 05:24:41.569537
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = []
    included_file_0 = IncludedFile.process_include_results(list_0, str_0, included_file_0, str_0)

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:24:43.555919
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    IncludedFile.process_include_results(list_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 05:24:52.175172
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    list_0 = ['']
    bool_0 = True
    str_0 = '?P%G0h'
    included_file_0 = IncludedFile(bool_0, list_0, bool_0, str_0)
    bool_1 = None
    list_1 = []
    str_1 = '80B5.'
    included_file_1 = IncludedFile(bool_1, list_1, bool_1, str_1)
    bool_2 = None
    list_2 = []
    str_2 = '80B5.'
    included_file_2 = IncludedFile(bool_2, list_2, bool_2, str_2)
    bool_3 = False
    list_3 = ['']
    str_3 = '?P%G0h'
    included_file_3 = Included

# Generated at 2022-06-25 05:24:59.034353
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = []
    iterator = None
    loader = None
    variable_manager = None
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()
    print("Done")

# Generated at 2022-06-25 05:25:03.478549
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()


# Generated at 2022-06-25 05:25:15.780738
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # BEGIN PYTHON 2/3 COMPATIBILITY TEST
    if sys.version_info[0] == 3:
        from ansible.executor.task_result import TaskResult

        results = []
        for _ in range(0, 6, 1):
            iteration_value_0 = None
            dict_0 = dict({('_ansible_no_log', True) : ('_ansible_no_log', True)})
            str_0 = '80B5.'
            dict_1 = dict({('failed', True) : ('failed', True)})
            dict_2 = dict()
            dict_2['_host'] = iter(dict_1.items())
            dict_2['_task'] = str_0
            dict_2['_result'] = dict_0

# Generated at 2022-06-25 05:25:19.842660
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    bool_0 = bool
    dict_0 = dict
    list_0 = list
    str_0 = str
    results_0 = [(1, 1), (2, 2), (3, 3)]
    included_file_0 = IncludedFile(bool_0, dict_0, dict_0, list_0)
    included_file_0.process_include_results(results_0, bool_0, bool_0, bool_0)

# Generated at 2022-06-25 05:25:25.691147
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = []
    bool_0 = None
    str_0 = '80B5.'
    iterator_0 = IncludedFile(bool_0, list_0, bool_0, str_0)
    loader_0 = IncludedFile(bool_0, list_0, bool_0, str_0)
    variable_manager_0 = IncludedFile(bool_0, list_0, bool_0, str_0)
    IncludedFile.process_include_results(list_0, iterator_0, loader_0, variable_manager_0)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:13.563917
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Check that process_include_results fails correctly when called with wrong or missing parameters
    try:
        IncludedFile.process_include_results(var_0, iterator, loader, variable_manager)
    except:
        pass


# Generated at 2022-06-25 05:26:21.869019
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    # Arrange
    var_0 = IncludedFile('filename_1', 'arguments_1', 'variables_1', 'task_1')
    var_1 = IncludedFile('filename_1', 'arguments_1', 'variables_1', 'task_1')
    var_2 = IncludedFile('filename_1', 'arguments_1', 'variables_1', 'task_1')
    var_3 = IncludedFile('filename_1', 'arguments_2', 'variables_1', 'task_1')
    var_4 = IncludedFile('filename_2', 'arguments_1', 'variables_1', 'task_1')
    var_5 = IncludedFile('filename_1', 'arguments_1', 'variables_2', 'task_1')

# Generated at 2022-06-25 05:26:24.425155
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = IncludedFile.__eq__(var_0, var_0)
    assert var_0 == None
    var_0 = IncludedFile.__eq__(var_0, var_0)
    assert var_0 == None


# Generated at 2022-06-25 05:26:30.715404
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = IncludedFile.process_include_results(var_0)
    if var_0 == included_files:
        print("Test Case 0: for test_IncludedFile_process_include_results PASSED")
    else:
        print("Test Case 0: for test_IncludedFile_process_include_results FAILED")

# Generated at 2022-06-25 05:26:33.082303
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    var_0 = IncludedFile()
    var_1 = IncludedFile()
    var_0.__eq__(var_1)


# Generated at 2022-06-25 05:26:34.961577
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    __tracebackhide__ = True

    assert test_case_0() == 'Pass'

__all__ = [
    'IncludedFile',
]

# Generated at 2022-06-25 05:26:35.846858
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    assert test_case_0() == None

# Generated at 2022-06-25 05:26:40.830033
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = IncludedFile.process_include_results('results', 'iterator', 'loader', 'variable_manager')


# Generated at 2022-06-25 05:26:43.960076
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = IncludedFile(None, None, None, None)
    var_1 = "test_value"
    var_2 = IncludedFile.process_include_results(var_1, None, None, None)
    assert var_2 == None


# Generated at 2022-06-25 05:26:47.176417
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import pdb
    pdb.set_trace()
    ic = IncludedFile()
    ic.process_include_results(var_0)



# Generated at 2022-06-25 05:27:10.977029
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False


# Generated at 2022-06-25 05:27:12.619072
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    var_0 = IncludedFile()

    var_1 = IncludedFile()

    assert var_0.__eq__(var_1) == False


# Generated at 2022-06-25 05:27:19.551549
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    #Test case 0
    print("\ntest case 0")

    result_0 = IncludedFile.process_include_results(var_0, iterator_0, loader_0, variable_manager_0)
    print("Expected: ")
    print("\nActual: ")

    print(result_0)
    print("\n")

test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:22.206428
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    """Test case for method __eq__ of class IncludedFile.

    Unit test for method __eq__ of class IncludedFile.
    """

    var_1 = IncludedFile.__eq__(var_0)


# Generated at 2022-06-25 05:27:24.491670
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    included_files = IncludedFile.process_include_results(var_0, iterator, loader, variable_manager)
    assert isinstance(included_files, list)

# Generated at 2022-06-25 05:27:29.234672
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file = IncludedFile(filename=None, args=None, vars=None, task=None, is_role=None)
    included_file.process_include_results(results=None, iterator=None, loader=None, variable_manager=None)

# Generated at 2022-06-25 05:27:35.285605
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Case 1
    # Check if the results are added to included_files
    # The input, results, has been mocked by the mock framework
    # and the function taksi_mock.py
    results = [{'include': './../file.yaml', 'include_args': 'arguments'},
               {'include': './../file.yaml', 'include_args': 'arguments'}]
    iterator = "iterator"
    loader = "loader"
    variable_manager = "variable manager"
    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:27:40.135242
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    var_0 = []
    var_1 = []
    var_2 = 0
    # check that the given item is contained within the list
    assert (var_2 in var_1)
    var_3 = []
    var_4 = 'foo'
    # check that the given item is contained within the list
    assert (var_4 in var_3)
    var_5 = 'bar'
    assert (var_5 == var_4)
    var_6 = 'adsf'
    assert (var_6 in var_3)
    var_7 = []
    var_8 = 'foo'
    # check that the given item is contained within the list
    assert (var_8 in var_7)
    var_9 = 'foo'
    assert (var_9 == var_8)

# Generated at 2022-06-25 05:27:41.058328
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    test_case_0()


# Generated at 2022-06-25 05:27:48.845376
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    global var_0
    include_results = var_0
    iterator = None
    loader = None
    variable_manager = None
    test_1 = IncludedFile(include_results, iterator, loader, variable_manager)
    assert test_1._filename == include_results
    assert test_1._args == iterator
    assert test_1._vars == loader
    assert test_1._task == variable_manager
    assert test_1._hosts == [include_results, iterator, loader, variable_manager]
    assert test_1._is_role == [test_1, test_1, test_1, test_1]

test_case_0()

# Generated at 2022-06-25 05:28:23.052260
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.loader import find_plugin, action_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    class PluginLoaderFail(Exception):
        pass
    def load_plugin(mod_path):
        return None
    find_plugin.orig_find_plugin = find_plugin.find_plugin
    find_plugin.find_plugin = load_plugin

# Generated at 2022-06-25 05:28:23.615998
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()


# Generated at 2022-06-25 05:28:28.003753
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    list_0 = []
    bool_0 = None
    str_0 = '::!n:g"<b%e'
    included_file_0 = IncludedFile(bool_0, list_0, bool_0, str_0)
    list_1 = [0]
    included_file_1 = IncludedFile(bool_0, list_1, bool_0, str_0)
    list_1 = []
    str_1 = '> '
    included_file_2 = IncludedFile(bool_0, list_1, bool_0, str_1)
    bool_1 = bool_0
    str_1 = str_0
    included_file_3 = IncludedFile(bool_1, list_1, bool_0, str_1)
    list_1 = []
    bool_1 = bool_0


# Generated at 2022-06-25 05:28:35.582368
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = []
    bool_0 = None
    included_file_0 = IncludedFile(bool_0, list_0, bool_0, str())
    included_file_1 = IncludedFile(bool_0, list_0, bool_0, str())
    results = [included_file_0, included_file_1]
    iterator = None
    loader = None
    variable_manager = None
    bool_1 = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    assert bool_1 is not None


# Generated at 2022-06-25 05:28:41.232794
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_of_results = []
    iterator = test_case_0()
    loader = test_case_0()
    variable_manager = test_case_0()
    
    # Call the method
    result = IncludedFile.process_include_results(list_of_results, iterator, loader, variable_manager)
    print(result)


# Generated at 2022-06-25 05:28:47.304495
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = None
    iterator = None
    loader = None
    variable_manager = None
    included_files = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    print("Type of the returned value: ", type(included_files))
    print("Output: ", included_files)
    assert included_files == []

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:28:54.212194
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = []
    str_0 = '6lKi_'
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)

    list_1 = []

    list_2 = []
    str_0 = 'n/Y'
    list_2.append(str_0)
    list_2.append(str_0)

    list_3 = []
    str_0 = 'o0XB2|'
    list_3.append(str_0)

    list_4 = []

# Generated at 2022-06-25 05:29:01.328100
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = []
    bool_0 = None
    tuple_0 = (False, 'host', 'task')
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    list_1 = list()
    list_2 = list()
    list_2.append(included_file_0)
    bool_1 = IncludedFile.process_include_results(list_1, iterator_0, loader_0, variable_manager_0)
    bool_2 = IncludedFile.process_include_results(list_2, iterator_0, loader_0, variable_manager_0)
    task_vars_cache_0 = {tuple_0: bool_1}
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_

# Generated at 2022-06-25 05:29:09.070639
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():

    # Case 1
    list_0 = ['N', 'c', 'B']
    bool_0 = None
    str_0 = 'J'
    included_file_0 = IncludedFile(bool_0, list_0, bool_0, str_0)
    included_file_1 = IncludedFile(bool_0, list_0, bool_0, str_0)

    eq_result = included_file_0.__eq__(included_file_1)

    # Check eq_result
    list_0 = ['N', 'c', 'B']
    bool_0 = None
    str_0 = 'J'
    included_file_0 = IncludedFile(bool_0, list_0, bool_0, str_0)

# Generated at 2022-06-25 05:29:18.476434
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    load_fixture_str = 'tests/fixtures/test_IncludedFile.yml'
    load_fixture_str_1 = 'tests/fixtures/test_IncludedFile_1.yml'
    load_fixture_str_2 = 'tests/fixtures/test_IncludedFile_2.yml'
    load_fixture_str_3 = 'tests/fixtures/test_IncludedFile_3.yml'
    load_fixture_str_4 = 'tests/fixtures/test_IncludedFile_4.yml'
    load_fixture_str_5 = 'tests/fixtures/test_IncludedFile_5.yml'
    load_fixture_str_6 = 'tests/fixtures/test_IncludedFile_6.yml'
    load_fixture_str

# Generated at 2022-06-25 05:29:50.570032
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    include_file_0 = test_case_0()
    results = bool_0
    iterator = object()
    loader = object()
    variable_manager = object()
    result_bool = IncludedFile.process_include_results(results, str_0, bool_0, bool_0)
    assert result_bool == result_bool

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:54.579756
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    list_0 = []
    bool_0 = None
    str_0 = '80B5.'
    included_file_0 = IncludedFile(bool_0, list_0, bool_0, str_0)
    included_file_1 = IncludedFile(bool_0, list_0, bool_0, str_0)
    bool_2 = included_file_0.__eq__(included_file_1)
    assert bool_2 == True


# Generated at 2022-06-25 05:30:05.890811
# Unit test for method __eq__ of class IncludedFile

# Generated at 2022-06-25 05:30:11.998700
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.executor import task_queue_manager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    # Create an inventory file.
    inventory_file = '''
        [test_host]
        localhost

        [test_host_2]
        localhost
    '''

    # Create a playbook file.
    playbook_file = '''
        - hosts: test_host
          tasks:
          - name: Include a task file
            include_tasks: tasks/task.yml loop_control=loop_0

        - hosts: test_host_2
          tasks:
          - name: Include a task file
            include_tasks: tasks/task.yml loop_control=loop_0
    '''



# Generated at 2022-06-25 05:30:20.189011
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assertion_result_0 = True
    included_file_0 = IncludedFile(str_0, list_0, bool_0, str_0)
    assertion_result_1 = True
    included_file_1 = IncludedFile(bool_0, list_0, bool_0, str_0)
    assertion_result_2 = True
    assertion_result_3 = True
    list_1 = []
    tuple_0 = (included_file_0, included_file_1)
    bool_1 = False
    assertion_result_4 = True
    bool_2 = False
    list_2 = []
    assertion_result_5 = True
    assertion_result_6 = True
    bool_3 = False
    assertion_result_7 = True
    list_3 = []
    bool_4 = False
    assertion_result

# Generated at 2022-06-25 05:30:31.435369
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = []
    list_1 = []
    dict_0 = {}
    dict_1 = {}
    class_0 = IncludedFile
    class_1 = IncludedFile
    str_0 = '#'
    str_1 = '('
    str_2 = '98i'
    str_3 = '9S'
    str_4 = 'Jm'
    str_5 = 'M'
    str_6 = 'l'
    str_7 = 'Nk'
    str_8 = 'T'
    str_9 = 'V'
    str_10 = '`G'
    str_11 = 'a@0'
    dict_0[str_0] = str_1
    dict_0[str_2] = str_3
    dict_0[str_4] = str_5

# Generated at 2022-06-25 05:30:38.077647
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = [IncludedFile(None, [], None, None)]
    list_1 = []
    included_file_0 = IncludedFile.process_include_results(list_0, list_1, None, None)

tests = [
    test_case_0,
    test_IncludedFile_process_include_results
]

if __name__ == '__main__':
    for test in tests:
        print(to_text(str(test()), errors='surrogate_or_strict'))

# Generated at 2022-06-25 05:30:46.844334
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_1 = []
    bool_1 = None
    included_file_1 = IncludedFile(bool_1, list_1, bool_1, bool_1)
    list_0 = []
    bool_0 = None
    str_0 = '80B5.'
    included_file_0 = IncludedFile(bool_0, list_0, bool_0, str_0)
    results = [included_file_1, included_file_0]
    iterator = list_0
    loader = bool_0
    variable_manager = list_0
    assert IncludedFile.process_include_results(results, iterator, loader, variable_manager) == results

# Generated at 2022-06-25 05:30:50.311656
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

if __name__ == "__main__":
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:30:56.823778
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    bool_0 = None
    list_0 = []
    str_0 = '80B5.'
    included_file_0 = IncludedFile(bool_0, list_0, bool_0, str_0)
    included_file_1 = IncludedFile(bool_0, list_0, bool_0, str_0)
    assert (included_file_0.__eq__(included_file_1) == True)
    str_0 = '0'
    included_file_1 = IncludedFile(bool_0, list_0, bool_0, str_0)
    assert (included_file_0.__eq__(included_file_1) == False)


# Generated at 2022-06-25 05:31:27.135210
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = [1, 2, 3]
    included_file_1 = IncludedFile.process_include_results(list_0, object(), object(), object())


# Generated at 2022-06-25 05:31:30.373824
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [None]
    iterator = [None]
    loader = [None]
    variable_manager = [None]
    results = IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:31:40.199932
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    passed = 0
    errored = 0
    failed = 0
    total = 0
    for i in xrange(5):
        total += 1
        try:
            test_case_0()
            passed += 1
        except Exception:
            errored += 1
            raise

# Generated at 2022-06-25 05:31:51.049048
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # AssertionError: "process_include_results() missing 3 required positional arguments: 'iterator', 'loader', and 'variable_manager'"
    try:
        IncludedFile.process_include_results()
    except SystemExit:
        pass
    except Exception as err:
        assert str(err) == "process_include_results() missing 3 required positional arguments: 'results', 'iterator', and 'variable_manager'"
    else:
        assert False, "Expected Exception"
    
    # AssertionError: "Argument 'results' must be of type 'list'"
    try:
        IncludedFile.process_include_results( set() )
    except SystemExit:
        pass
    except Exception as err:
        assert str(err) == "Argument 'results' must be of type 'list'"

# Generated at 2022-06-25 05:32:00.111443
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    display.verbosity = 3

    loader = DataLoader()
    play_context = PlayContext()

    inventory = {
        'localhost': {
            'hosts': [
                'localhost',
            ],
            'vars': {
                'test_var': 'ansible',
            }
        }
    }
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    mock_iterator = object()


# Generated at 2022-06-25 05:32:01.896436
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:32:11.953713
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    list_0 = []
    bool_0 = None
    str_0 = '80B5.'
    included_file_0 = IncludedFile(bool_0, list_0, bool_0, str_0)
    included_file_1 = IncludedFile(str_0, list_0, str_0, str_0)
    bool_2 = included_file_0.__eq__(included_file_1)
    str_2 = 'c@'
    included_file_1._filename = str_2
    bool_3 = included_file_0.__eq__(included_file_1)
    str_3 = 'iP'
    included_file_1._task._uuid = str_3
    bool_4 = included_file_0.__eq__(included_file_1)
    str

# Generated at 2022-06-25 05:32:17.128082
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(None, None, None, None)
    included_file_0.process_include_results(None, None, None, None)

test_case_0()
test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:32:25.459571
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = dict()
    str_0 = '-L'
    str_1 = 'Bz'
    list_0 = [str_0, str_1]
    uuid_0 = uuid.uuid4()
    dict_0['uuid'] = uuid_0
    str_2 = '|>'
    dict_0['action'] = str_2
    int_0 = 1
    dict_0['loop'] = int_0
    dict_0['hosts'] = list_0
    dict_0['args'] = dict_0
    dict_0['name'] = str_2
    dict_0['task'] = dict_0
    dict_0['play'] = dict_0
    dict_0['block'] = dict_0
    dict_0['vars'] = dict_0
   

# Generated at 2022-06-25 05:32:28.628727
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    for _ in range(20):
        _test_IncludedFile_process_include_results()



# Generated at 2022-06-25 05:33:08.382195
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = []
    list_1 = []
    iterator_0 = Iterator(list_0, list_1)
    list_2 = []
    list_3 = []
    loader_0 = DataLoader(list_2, list_3)
    list_4 = []
    list_5 = []
    variable_manager_0 = VariableManager(list_4, list_5)
    list_6 = []
    list_7 = []
    included_file_0 = IncludedFile.process_include_results(list_6, iterator_0, loader_0, variable_manager_0)

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:33:13.218907
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = []
    bool_0 = None
    str_0 = '80B5.'
    included_file_0 = IncludedFile(bool_0, list_0, bool_0, str_0)
    IncludedFile.process_include_results(list_0, bool_0, bool_0, bool_0)

if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:33:22.504186
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile('/7/y?5:=oRY', [], '0.X^Z*/0d}G[?', 'F4bq3GLy~#Q')
    list_0 = []
    iterator_0 = None
    loader_0 = None
    variable_manager_0 = None
    IncludedFile.process_include_results(list_0, iterator_0, loader_0, variable_manager_0)

if __name__ == '__main__':
    test_case_0()
    # Unit test for method add_host of class IncludedFile
    # test_IncludedFile_add_host()

    # Unit test for method process_include_results of class IncludedFile
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:33:25.381339
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    with pytest.raises(UnboundLocalError):
        list_0 = []
        bool_0 = None
        str_0 = '80B5.'
        included_file_0 = IncludedFile(bool_0, list_0, bool_0, str_0)
        test_case_0()


# Generated at 2022-06-25 05:33:26.903702
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = test_case_0()
    included_file_0.process_include_results()


# Generated at 2022-06-25 05:33:28.430591
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile()
    included_file_0.process_include_results()

# Instruction for how to run the testcase

# Generated at 2022-06-25 05:33:32.490835
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = []
    included_file_0 = IncludedFile.process_include_results(bool_0, list_0, list_0, list_0)

if __name__ == "__main__":
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:33:39.954174
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # No error
    out_0 = None
    # No error
    out_1 = None
    # No error
    out_2 = None
    # No error
    out_3 = None
    # No error
    out_4 = None
    # No error
    out_5 = None
    # No error
    out_6 = None
    # No error
    out_7 = None
    # No error
    out_8 = None
    # No error
    out_9 = None
    # No error
    out_10 = None
    # No error
    out_11 = None
    # No error
    out_12 = None
    # No error
    out_13 = None
    # No error
    out_14 = None
    # No error
    out_15 = None

    results = []
    iterator

# Generated at 2022-06-25 05:33:41.827097
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = []
    bool_0 = None
    str_0 = '80B5.'
    included_file_0 = IncludedFile(bool_0, list_0, bool_0, str_0)

# Generated at 2022-06-25 05:33:44.514329
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    task_iterator_0 = TaskQueueManager(task_source=task_source_0, variable_manager=variable_manager_0, loader=loader_0)
    list_0 = []
    included_file_0 = IncludedFile.process_include_results(list_0, task_iterator_0, loader_0, variable_manager_0)
    assert included_file_0 is not None
