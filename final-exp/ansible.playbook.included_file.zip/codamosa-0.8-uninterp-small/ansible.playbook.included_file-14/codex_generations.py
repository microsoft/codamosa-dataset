

# Generated at 2022-06-25 05:24:24.180073
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '-Kj/%=}FJPo'
    list_0 = [str_0, str_0, str_0]
    list_1 = [str_0, str_0, str_0]
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['msg'] = 'skipping: no hosts matched'
    str_1 = 'host'
    dict_1['host'] = str_1
    dict_2['host'] = str_1
    dict_2['changed'] = False
    dict_1['changed'] = False
    dict_1['invocation'] = dict()
    dict_2['invocation'] = dict()
    dict_1['invocation']['module_args'] = str_0

# Generated at 2022-06-25 05:24:30.269588
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = []
    iterator = object()
    loader = object()
    variable_manager = object()
    assert IncludedFile.process_include_results(results, iterator, loader, variable_manager) == []

test_case_0()
test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:24:41.435595
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:24:48.577978
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    include_results_0 = [IncludedFile(('', '', ''), 99, (), '')]
    iterator_0 = ''
    loader_0 = ''
    variable_manager_0 = ''

    # Call the method with a correct argument
    # The method should return a value
    assert IncludedFile.process_include_results(include_results_0,
                                                iterator_0,
                                                loader_0,
                                                variable_manager_0) is None


# Generated at 2022-06-25 05:24:56.120693
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_1 = IncludedFile(str_0, int_0, tuple_0, str_0)

    array_0 = [included_file_1, included_file_1, included_file_0]
    included_file_1.process_include_results(array_0, included_file_1, included_file_0, included_file_1)


test_case_0()
test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:25:05.414155
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultEditor
    from ansible.plugins import vars as var_loader
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleError
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.plugins import task_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-25 05:25:17.043387
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:25:24.716439
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:25:30.328113
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = included_file_0
    iterator = included_file_0
    loader = included_file_0
    variable_manager = included_file_0
    included_file_0.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:25:37.523766
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '`\n&t@=2NTEFZyYe'
    tuple_0 = ()
    list_0 = [str_0, str_0, str_0]
    int_0 = 99
    included_file_0 = IncludedFile(list_0, int_0, tuple_0, str_0)
    int_1 = 99
    included_file_1 = IncludedFile(list_0, int_1, tuple_0, str_0)
    bool_0 = included_file_0 == included_file_1


# Generated at 2022-06-25 05:25:47.692556
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass

# Generated at 2022-06-25 05:25:58.087552
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = 'l\'J8_q+'
    list_0 = []
    list_1 = []
    str_1 = '9.^+g}d6'
    tuple_0 = ()
    tuple_1 = ()
    int_0 = 100000
    int_1 = 100000

    # Verify that the first case is true
    included_file_0 = IncludedFile(str_0, int_0, tuple_0, list_0)
    included_file_1 = IncludedFile(str_0, int_0, tuple_0, list_0)
    assert included_file_0 == included_file_1

    # Verify that the second case is true
    included_file_0 = IncludedFile(str_0, int_1, tuple_1, list_1)
    included_file_1 = IncludedFile

# Generated at 2022-06-25 05:26:01.532567
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file = IncludedFile.IncludedFile()


# Generated at 2022-06-25 05:26:05.339491
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = []
    iterator = object()
    loader = object()
    variable_manager = object()
    included_file_0 = IncludedFile.process_include_results(results, iterator, loader, variable_manager)


test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:05.921444
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert False


# Generated at 2022-06-25 05:26:12.413708
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = '`\n&t@=2NTEFZyYe'
    list_0 = [str_0, str_0, str_0]
    int_0 = 99
    tuple_0 = ()
    included_file_0 = IncludedFile(list_0, int_0, tuple_0, str_0)
    included_files_0 = IncludedFile.process_include_results([included_file_0], included_file_0, included_file_0, tuple_0)
    assert len(included_files_0) == 1
    assert included_files_0[0] == included_file_0

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:17.291955
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = [(0, 1), (0, 2)]
    iterator = (0, 1, 2, 3, 4)
    loader = 3
    variable_manager = (0)
    class_name = 'IncludedFile'
    method_name = 'process_include_results'
    args = (results, iterator, loader, variable_manager)
    # No output
    method_response = IncludedFile.process_include_results(*args)
    # Return the response
    return method_response



# Generated at 2022-06-25 05:26:25.994849
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.vars import VariableManager

# Generated at 2022-06-25 05:26:36.320671
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print('Test: process_include_results')
    included_file_0 = IncludedFile('/abc/def/ghi', 'abc/def/ghi', 'abc/def/ghi', 'abc/def/ghi')
    included_file_1 = IncludedFile('/abc/def/ghi', 'abc/def/ghi', 'abc/def/ghi', 'abc/def/ghi')
    included_files = [included_file_0, included_file_1]

    included_files = IncludedFile.process_include_results('abc/def/ghi', 'abc/def/ghi', 'abc/def/ghi', 'abc/def/ghi')
    assert included_files == included_files


if __name__ == "__main__":
    print("test start")
    #test_case_

# Generated at 2022-06-25 05:26:45.333447
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = '\x18\t\x11\x18\t\x11\x18\t\x11'
    list_0 = [str_0, str_0, str_0]
    int_0 = 99
    tuple_0 = ()
    included_file_0 = IncludedFile(list_0, int_0, tuple_0, str_0)
    results_0 = [included_file_0]
    IncludedFile.process_include_results(results_0, list_0, list_0, list_0)

if __name__ == "__main__":
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:09.936041
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '`\n&t@=2NTEFZyYe'
    list_0 = [str_0, str_0, str_0]
    int_0 = 99
    tuple_0 = ()
    included_file_0 = IncludedFile(list_0, int_0, tuple_0, str_0)
    included_file_1 = IncludedFile(list_0, int_0, tuple_0, str_0)
    assert included_file_0 == included_file_1


# Generated at 2022-06-25 05:27:14.450669
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = IncludedFile.process_include_results(None, None, None, None)
    included_files_1 = IncludedFile.process_include_results(None, None, None, None)
    included_files_2 = IncludedFile.process_include_results(None, None, None, None)

    assert included_files_0 == included_files_1
    assert included_files_0 == included_files_2

if __name__ == '__main__':
    # unit tests for IncludedFile class
    test_case_0()

# Generated at 2022-06-25 05:27:14.873371
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass 


# Generated at 2022-06-25 05:27:17.855883
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = 699
    list_0 = [int_0, int_0]
    tuple_0 = ()
    included_file_0 = IncludedFile(int_0, list_0, tuple_0, int_0)
    list_1 = [included_file_0]
    IncludedFile.process_include_results(list_1, included_file_0, included_file_0, included_file_0)


# Generated at 2022-06-25 05:27:19.245496
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = IncludedFile.process_include_results([], [], [], [])

# Generated at 2022-06-25 05:27:26.186654
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    list_0 = ['']
    dict_0 = {}
    dict_1 = {}
    dict_0['results'] = dict_1
    dict_1['failed'] = True
    dict_1['skipped'] = False
    dict_2 = {}
    dict_1['include_args'] = dict_2
    dict_1['ansible_loop_var'] = 'item'
    dict_1['_ansible_item_label'] = 'element'
    dict_1['ansible_loop'] = 'element'
    dict_2['name'] = 'element'
    dict_2['role'] = 'element'
    dict_1['include'] = 'element'
    dict_2['private_first'] = 'private/'
    dict_1['ansible_index_var'] = 'item.0'
    dict

# Generated at 2022-06-25 05:27:29.104512
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    try:
        test_case_0()
    except NameError as err:
        print('NameError exception caught')
        print(str(err))
        print(err.args)


# Generated at 2022-06-25 05:27:31.374825
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile.process_include_results(None, None, 0, None)


if __name__ == '__main__':
    test_case_0()
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:27:43.240426
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:27:50.189273
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    import sys
    import base64
    import ansible.plugins.loader
    import ansible.playbook.play
    import ansible.executor.task_queue_manager
    import ansible.template
    import ansible.inventory
    import ansible.vars.manager
    import ansible.parsing.dataloader
    import ansible.inventory.host
    import ansible.vars.hostvars
    import ansible.utils.vars

    # The following is a function used in this test.
    def test_function_0():
        dict_0 = dict()
        dict_0['include_results'] = []
        dict_0['include_results'].append(dict())
        dict_0['include_results'][0]['include'] = 'The HOST'

# Generated at 2022-06-25 05:28:34.106591
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '4fM1m;VmX|'
    int_0 = 80
    class_0 = IncludedFile(str_0, int_0, int_0, str_0)
    try:
        class_0.__eq__(str_0)
        class_0.__eq__(str_0)
    except (RuntimeError, TypeError, NameError):
        assert False
    else:
        assert True


# Generated at 2022-06-25 05:28:42.537753
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = '\x00\x15\x0e\x07\x1bg\x0bL\x1e'
    int_0 = 95
    int_1 = 56
    int_2 = 64
    bool_0 = False
    str_1 = '\x1f\x07<\x11E\x02\x1d\x19\x17\x0e\x13\x19\x14\x06\x0b\x19\x02\x1e\x00'
    str_2 = 'w\x0c\x1d\x05'
    str_3 = '\x0c\x14\x07\x00\x0a6\x17\x07'
    set_0 = set()
    bool_1 = True
    int_3

# Generated at 2022-06-25 05:28:49.463376
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    included_file_0 = IncludedFile('/dev/null', int(), int(), str())

    included_file_1 = IncludedFile.process_include_results(included_file_0, included_file_0, included_file_0, included_file_0)

    assert included_file_0 is not included_file_1


# Generated at 2022-06-25 05:29:00.287155
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    # test case
    str_0 = '`\n&t@=2NTEFZyYe'
    int_0 = 99
    included_file_0 = IncludedFile(str_0, int_0, int_0, str_0)
    included_file_1 = IncludedFile(str_0, int_0, int_0, str_0)
    var_0 = included_file_0 == included_file_1
    # test case
    str_0 = '`\n&t@=2NTEFZyYe'
    int_0 = 99
    included_file_0 = IncludedFile(str_0, int_0, int_0, str_0)
    included_file_1 = IncludedFile(str_0, int_0, int_0, str_0)
    var_0 = included

# Generated at 2022-06-25 05:29:04.496440
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '`\n&t@=2NTEFZyYe'
    int_0 = 99
    included_file_0 = IncludedFile(str_0, int_0, int_0, str_0)
    var_0 = included_file_0 == included_file_0


# Generated at 2022-06-25 05:29:05.799403
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()

# Generated at 2022-06-25 05:29:17.715473
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # test0
    included_file_1 = IncludedFile('\u003b', 'P\u0005', '`\n&t@=2NTEFZyYe',
                        '~\u000a\u0010\u0017\u0013D\\\u0018\u000e\u0015\u0018\u0007\u0014\u001a\u0019')
    included_file_2 = IncludedFile('\u001d\u001c', '\u000b', '\u001e\u001c\u0003\u001f',
                        '\u0004\u0004\u001d\u0015\u0017\u000e\u0012\u0010\u0011\u0015\u0006\u0002')

# Generated at 2022-06-25 05:29:18.828018
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()


test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:21.847100
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    for var_0 in range(0, 100):
        test_case_0()

# Testing the class IncludedFile

# Generated at 2022-06-25 05:29:30.437728
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    str_0 = '`\n&t@=2NTEFZyYe'
    str_1 = '"%ks6-;#QR'
    str_2 = '%nT[AIK&s+'
    str_3 = '-!;.>liWAE'
    int_0 = 99
    included_file_0 = IncludedFile(str_2, int_0, int_0, str_0)
    included_file_1 = IncludedFile(str_0, int_0, int_0, str_0)
    included_file_2 = IncludedFile(str_2, int_0, int_0, str_0)
    included_file_3 = IncludedFile(str_0, int_0, int_0, str_0)

# Generated at 2022-06-25 05:30:49.502166
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile('', 99, 99, '')

    # Test assertion failure
    # assert isinstance(result, IncludedFile)

    included_file_1 = IncludedFile('', 99, 99, '')
    included_files = [included_file_1]
    included_files_len = len(included_files)

    assert included_files_len == 1

# Generated at 2022-06-25 05:30:55.104113
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        # this test is expected to fail
        assert False
    except AssertionError:
        pass

test_cases = [
    test_case_0,
]



# Generated at 2022-06-25 05:31:00.742099
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    dict_0 = dict()
    int_0 = 99
    list_0 = list()
    str_0 = '`\n&t@=2NTEFZyYe'
    int_1 = 99
    dict_1 = dict()
    dict_2 = dict()

    class Dummy(object):
        pass

    dummy_role_0 = Dummy()
    dummy_role_0.name = str_0
    dummy_role_0._role_path = str_0

    class Dummy(object):
        pass

    dummy_play_0 = Dummy()
    dummy_play_0.name = str_0
    dummy_play_0.roles = dict()

    class Dummy(object):
        pass

    dummy_none_0 = Dummy()
    dummy_none_0.name = str_

# Generated at 2022-06-25 05:31:03.868183
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        temp_0 = read_file()
        IncludedFile.process_include_results(temp_0, temp_0, temp_0, temp_0)
    except Exception as error:
        print(error)



# Generated at 2022-06-25 05:31:11.283995
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    results = "results"
    iterator = "iterator"
    loader = "loader"
    variable_manager = "variable_manager"
    var_0 = IncludedFile.process_include_results(results, iterator, loader, variable_manager)
    var_0 = included_file_0
    var_0.add_host("original_host")
    return var_0 == included_file_0


# Generated at 2022-06-25 05:31:15.303539
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = 'mR*nB`r[8l'
    int_0 = 11
    int_1 = 9
    included_file_0 = IncludedFile(str_0, int_0, int_0, str_0)
    included_files_0 = [included_file_0]
    IncludedFile.process_include_results(included_files_0)


# Generated at 2022-06-25 05:31:20.821365
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files_0 = []
    include_file_0 = IncludedFile.process_include_results(included_files_0, object, object, object)
    print(include_file_0)



if __name__ == "__main__":
    test_case_0()
    test_IncludedFile_process_include_results()
else:
    print ("run main() to execute unit tests.")

# Generated at 2022-06-25 05:31:22.449352
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True == True


# Generated at 2022-06-25 05:31:24.038285
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    base_dir_0 = str()
    results_0 = list()
    included_files_0 = IncludedFile.proce

# Generated at 2022-06-25 05:31:27.630196
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass