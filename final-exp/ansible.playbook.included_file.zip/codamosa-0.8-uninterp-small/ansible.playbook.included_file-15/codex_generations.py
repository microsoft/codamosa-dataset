

# Generated at 2022-06-25 05:24:51.280219
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = 1.5
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_0 = 's6<qM/Jauh/ZQ+*x'
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)
    str_1 = 'AAfL}'
    task_0 = TaskInclude(str_1)
    int_0 = 0
    handler_0 = Handler().load_from_file(int_0, task_0)
    str_2 = 'C#Qv\x48\xdd\x7f\x80\x19\x8e\x95\xf5\x07\x00\xae>'
    int_1 = 2
    float_

# Generated at 2022-06-25 05:24:53.393789
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    raise NotImplementedError()

# Generated at 2022-06-25 05:25:04.740677
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    task_parent_0 = TaskInclude.load(dict(tasks=''))
    task_0 = TaskInclude.load(dict(action='foo', tasks=''), task_parent_0)

# Generated at 2022-06-25 05:25:16.439554
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = 0.9016035854744708
    str_0 = '4z3qE'
    list_0 = []
    bool_0 = False
    str_1 = 'c+vf2l;q3\n"8}{'
    str_2 = 'jJ=\t+8W\x1fv`1;n{z\t|Ik\x0b>D\x1f\x1fPS'
    str_3 = 'zNgl'
    str_4 = '~w'
    int_0 = 36
    dict_0 = dict()
    dict_0['m!z6*?U'] = 68
    str_5 = ']\x1b~'
    str_6 = 'D4@\x16\x17\x0c'
   

# Generated at 2022-06-25 05:25:27.457677
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 1.5
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_0 = 's6<qM/Jauh/ZQ+*x'
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)
    float_1 = 0.0

# Generated at 2022-06-25 05:25:33.551694
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 1.5
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_0 = 's6<qM/Jauh/ZQ+*x'
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)
    bool_0 = included_file_0.__eq__(None)
    print(bool_0)
    assert bool_0

    bool_0 = included_file_0.__eq__(None)
    print(bool_0)
    assert bool_0


# Generated at 2022-06-25 05:25:38.788533
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = IncludedFile.process_include_results(None, None, None, None)
    assert included_files is not None



# Generated at 2022-06-25 05:25:46.817545
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 1.5
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_0 = 's6<qM/Jauh/ZQ+*x'
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)
    str_1 = 'u`\\'
    str_2 = '8P/'
    bytes_1 = b'\x0f\xc0\x9c)\x89\xab\xb8\x81\x1d\xee\xeb\x8eP\xe0\x91\x1f\x0c\x1a\xbe\xfc\xaa'
    str_3 = 'hX\x16'
    included_file

# Generated at 2022-06-25 05:25:57.553991
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = 1.5
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_0 = 's6<qM/Jauh/ZQ+*x'
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)
    float_1 = 0.5
    bytes_1 = b'\xde\xc7\x8d\xab\x02\xfd\xbb\x98\xba\xaa\xb1\x0b\x9d'
    str_1 = '<Mv\xe8\xca\x87\x11\xdc'
    included_file_3 = IncludedFile(float_1, bytes_1, float_0, str_1)


# Generated at 2022-06-25 05:26:02.423858
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = 2.2
    list_0 = ['f', 'a', '`', '.', '}', 't', 'R', 'd', 'Gi', 'm', 'm5b', 'm', 'i', 'y', ']', '%', 'Y', '|', 'O', 'l', 'l']
    IncludedFile.process_include_results(list_0, float_0, float_0, float_0)

test_case_0()
test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:24.917648
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # First test case : with no args
    test_case_0()


# Generated at 2022-06-25 05:26:26.433691
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    pass


# Generated at 2022-06-25 05:26:32.507959
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_0 = test_case_0()
    var_1 = IncludedFile(var_0, var_0, var_0, var_0)
    var_2 = var_1.process_include_results(var_0, var_0, var_0, var_0)

if __name__ == "__main__":
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:39.965785
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None

    def test_nonlocal__return_value_0():
        return var_6._play
    var_1 = _
    def test_nonlocal__return_value_1():
        return var_6._host
    var_2 = _
    def test_nonlocal__return_value_2():
        return var_6._task
    var_3 = _

    def test_nonlocal__return_value_3():
        return var_4._ansible_loop_var
    var_5 = _

    def test_nonlocal__return_value_4():
        return var_4.get('ansible_loop_var', 'item')
    var_

# Generated at 2022-06-25 05:26:44.815155
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    print("test_IncludedFile_process_include_results begin ...")
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    print("test_IncludedFile_process_include_results end!")


# use for run one test
#test_IncludedFile_process_include_results()

# use for run all test
test_case_0()
test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:26:53.734209
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:26:57.639230
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    var_0 = IncludedFile.add_host(var_0)


# Generated at 2022-06-25 05:27:01.848767
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

    # Initialize the test case
    test_case = test_case_0()

    # Run target method
    IncludedFile.process_include_results(test_case._var_0)

    # Assert the results
    return

# Generated at 2022-06-25 05:27:05.291421
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    res_0 = IncludedFile.process_include_results(var_0)
    assert res_0 is not None



# Generated at 2022-06-25 05:27:09.901809
# Unit test for method add_host of class IncludedFile
def test_IncludedFile_add_host():
    inc = IncludedFile('test1', [], [], [])
    inc.add_host('test2')
    assert inc._hosts == ['test2']
    try:
        inc.add_host('test2')
        # Should not be reached
        assert False
    except ValueError:
        pass


# Generated at 2022-06-25 05:27:43.240655
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 1.5
    int_0 = 9
    str_0 = 's6<qM/Jauh/ZQ+*x'
    bytes_1 = b'\xbe\xe9\x9d%\x94[\xac\xe8\x83\xd2\xdc}\x87'
    included_file_1 = IncludedFile(int_0, float_0, str_0, bytes_1)
    int_1 = 0
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)

# Generated at 2022-06-25 05:27:49.986373
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile(0, 'l\xe3\x03\x93\x1eV\xc0\xb2\xbc\xd8\xfa\xde\x0e\x13\x9a\x10\x02\x94\xc8', 1, '0\xa5\xd7\xce\x9d\x86\x1f\x04+\x1a\xde\xb2\xaac\xdd\x9b\xab@\x11\xa3\x17\xbb\xd7<\xdd\x1b\x8b\x03\x93\xfc').process_include_results(0, 0, 0, 0)
    print(included_file_0)


# Generated at 2022-06-25 05:27:54.937971
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = 1.5
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_0 = 's6<qM/Jauh/ZQ+*x'
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)


# Generated at 2022-06-25 05:28:03.734653
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 1.5
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_0 = 's6<qM/Jauh/ZQ+*x'
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)
    float_1 = 1.5
    bytes_1 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_1 = 's6<qM/Jauh/ZQ+*x'
    included_file_1 = IncludedFile(float_1, bytes_1, float_1, str_1)
    included_file_2 = IncludedFile(float_0, float_0, float_0, str_0)


# Generated at 2022-06-25 05:28:10.769803
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = 1.5
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_0 = 's6<qM/Jauh/ZQ+*x'
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)
    dict_0 = dict()
    dict_0['include'] = bytes_0
    dict_0['include_args'] = dict()
    dict_0['include_args']['loop_var'] = str_0
    dict_0['include_args']['loop'] = dict_0
    dict_0['include_args']['loop_var'] = str_0
    dict_0['include_args']['var_one'] = str_0
    dict

# Generated at 2022-06-25 05:28:17.139940
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_files = []
    results = []
    iterator = Iterator()
    loader = Loader()
    variable_manager = VariableManager()
    IncludedFile.process_include_results(results, iterator, loader, variable_manager)


# Generated at 2022-06-25 05:28:22.119501
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    included_file_0 = IncludedFile.process_include_results(float_0=1.5, bytes_0=b'\xa5P\xa8\xf1\x1d\xfa/ ', float_0=1.5, str_0='s6<qM/Jauh/ZQ+*x')



# Generated at 2022-06-25 05:28:31.304362
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 1.5
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_0 = 's6<qM/Jauh/ZQ+*x'
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)
    bytes_1 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_1 = 'tN\x1b\x1bqM/Jauh/ZQ+*x'
    tuple_0 = (str_0, float_0, float_0, bytes_1)
    tuple_1 = (float_0, bytes_1, bytes_0, str_0)

# Generated at 2022-06-25 05:28:42.382736
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = 1.5
    dict_0 = dict()
    dict_0['\x0c'] = '\x0c'
    dict_0['\x08'] = '\x08'
    dict_0['\x09'] = '\x09'
    dict_0['\x0b'] = '\x0b'
    dict_0['\x0a'] = '\x0a'
    results_0 = [dict_0]
    iterator_0 = IncludedFile(float_0, str_0, bytes_0, float_0)
    loader_0 = IncludedFile(str_0, float_0, float_0, bytes_0)
    templar_0 = Templar(float_0, float_0, float_0)
    included_file_0 = IncludedFile.process_include

# Generated at 2022-06-25 05:28:51.348207
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    class Iterator:
        def __init__(self, play):
            self._play = play
    class Loader:
        def __init__(self, basedir):
            self._basedir = basedir
        def get_basedir(self):
            return self._basedir
        def path_dwim_relative(self, path1, path2, path3, is_role=False):
            return os.path.join(path1, path2, path3) if is_role else os.path.join(path2, path3)
        def path_dwim(self, filename):
            return filename
    class VariableManager:
        def __init__(self):
            self._vars = dict()
        def get_vars(self, play=None, host=None, task=None):
            return self._v

# Generated at 2022-06-25 05:29:33.621827
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # Test passes
    test_case_0()

if __name__ == '__main__':
    test_IncludedFile_process_include_results()

# Generated at 2022-06-25 05:29:34.313799
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    test_case_0()


# Generated at 2022-06-25 05:29:37.466891
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file = IncludedFile(float_0, bytes_0, float_0, str_0)
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)
    assert included_file == included_file_0


# Generated at 2022-06-25 05:29:41.221750
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # process_include_results is a static method
    targets = [
        test_case_0
    ]
    for target in targets:
        target()

if __name__ == "__main__":
    for func in [ test_case_0 ]:
        func()

# Generated at 2022-06-25 05:29:49.498755
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    float_0 = 1.5
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_0 = 's6<qM/Jauh/ZQ+*x'
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)
    included_file_1 = IncludedFile(float_0, bytes_0, float_0, str_0)
    bool_0 = included_file_0.__eq__(included_file_1)
    assert bool_0 is True


# Generated at 2022-06-25 05:29:52.512310
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():

   # Incorrectly inserted argument
   results = 1
   iterator = None
   loader = None
   variable_manager = None
   expected = None

   IncludedFile.process_include_results(results, iterator, loader, variable_manager)

# Generated at 2022-06-25 05:30:04.538159
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()

# Generated at 2022-06-25 05:30:07.700512
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    # No error should be raised by this method
    IncludedFile.process_include_results()

# Generated at 2022-06-25 05:30:11.555632
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
   args = [ ]
   with patch.object(IncludedFile, 'process_include_results') as mock_process_include_results:
      assert IncludedFile.process_include_results() == mock_process_include_results.return_value
      mock_process_include_results.assert_called_with()


# Generated at 2022-06-25 05:30:21.664977
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    from ansible.playbook.role_include import IncludeRole
    float_0 = 1.5
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_0 = 's6<qM/Jauh/ZQ+*x'
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)
    float_1 = 1.5
    bytes_1 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_1 = 's6<qM/Jauh/ZQ+*x'
    included_file_1 = IncludedFile(float_1, bytes_1, float_1, str_1)
    assert included_file_0 == included_file_

# Generated at 2022-06-25 05:31:18.612860
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    assert True


# Generated at 2022-06-25 05:31:29.664420
# Unit test for method process_include_results of class IncludedFile

# Generated at 2022-06-25 05:31:41.911698
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_3 = 8.
    float_1 = 0.6691706754847969
    str_4 = 'Z#*jnL1\n'
    str_1 = '\x8e\x07'
    bytes_4 = b'\xfa\xcd\x02\x9b\x91\x8d\x03\x87\x88\x0d'
    bytes_2 = b'Y+\xaa\x0c\xcc\xed\x01\x99\x0e\xbf\xf5\x9a\x89\x8a\x03\x11\x95\x8c\x8d'

# Generated at 2022-06-25 05:31:53.235678
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    include_results = []
    iterator = IncludedFile(0.2, 'smF|\xb2\xdf\x8a', '\xbd\x07\xa3\x1e\x86\xe0\x82\x11\x8a\x01\x17\xe0\x80\xe1\xdd', 'JF\xfe\xc4\x8f\x1c')
    loader = IncludedFile(0.2, b'\x95\xa4\xe1c\x8b\r', '\xbd\x07\xa3\x1e\x86\xe0\x82\x11\x8a\x01\x17\xe0\x80\xe1\xdd', 'JF\xfe\xc4\x8f\x1c')
    variable

# Generated at 2022-06-25 05:31:57.160628
# Unit test for method __eq__ of class IncludedFile
def test_IncludedFile___eq__():
    included_file_0 = IncludedFile()
    included_file_1 = IncludedFile()
    included_file_2 = IncludedFile()
    bool_0 = included_file_0 == included_file_1
    assert bool_0 == False
    bool_1 = included_file_1 == included_file_2
    assert bool_1 == False
    bool_2 = included_file_0 == included_file_2
    assert bool_2 == False


# Generated at 2022-06-25 05:32:08.847800
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = 0.08514227132756755
    dict_0 = dict()
    dict_0['include_args'] = dict()
    dict_0['include'] = 'N'
    dict_1 = dict()
    dict_1['_parent'] = dict()

# Generated at 2022-06-25 05:32:20.346769
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    float_0 = 1.5
    bytes_0 = b'\xa5P\xa8\xf1\x1d\xfa/ '
    str_0 = 's6<qM/Jauh/ZQ+*x'
    included_file_0 = IncludedFile(float_0, bytes_0, float_0, str_0)
    float_1 = 3.2
    bytes_1 = b'\xf7\xfe\xe4\xbb\\\x81\xb4\x02N4'

# Generated at 2022-06-25 05:32:21.975661
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    try:
        assert False
    except AssertionError:
        IncludedFile.process_include_results()


# Generated at 2022-06-25 05:32:31.234218
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    str_0 = '\\'
    float_0 = -0.6855355583156097
    bool_0 = False

# Generated at 2022-06-25 05:32:40.346348
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    int_0 = 16
    dict_0 = dict({'3': int_0, '2': int_0, '5': int_0, '4': int_0, '7': int_0, '6': int_0, '9': int_0})
    str_0 = 'gD.G\x06\x1b\x1b\x9b\x14v@8\xd4L'
    str_1 = '7Bx\x01\xc7\xdb\xe3\x85\x11f$\x00'
    float_0 = 0.21809356604876
    float_1 = 1.0
    list_0 = [dict_0, float_1, float_0, float_0, float_1, float_1, float_0, float_0]
    list

# Generated at 2022-06-25 05:34:02.858329
# Unit test for method process_include_results of class IncludedFile
def test_IncludedFile_process_include_results():
    from ansible.results import Result
    import ansible.playbook.block
    r = Result()
    r._host = 'host_0'
    r._task = ansible.playbook.block.Block()
    r._task.loop = 'loop_0'
    r._task.action = 'action_0'
    r._task.no_log = 'no_log_0'
    r._task._uuid = 'uuid_0'
    r._task._parent = 'parent_0'
    r._result = 'result_0'
    r._task._parent._uuid = 'uuid_1'
    results = [r]
    iterator = 'iterator_0'
    loader = 'loader_0'
    variable_manager = 'variable_manager_0'
    assert IncludedFile.process_include_results